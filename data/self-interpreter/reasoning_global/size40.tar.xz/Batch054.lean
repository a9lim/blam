import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302802728758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302802728758 : Closed e302802728758 ∧ code e302802728758 = 1402314356534 := by decide
theorem cert_e302802728758 : check e302802728758 [[],[]] .sourceHead = true := by decide
def e302802728762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302802728762 : Closed e302802728762 ∧ code e302802728762 = 1402314356538 := by decide
theorem cert_e302802728762 : check e302802728762 [[],[]] .sourceHead = true := by decide
def e302802733918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302802733918 : Closed e302802733918 ∧ code e302802733918 = 1402314361694 := by decide
theorem cert_e302802733918 : check e302802733918 [[],[]] .chain = true := by decide
def e302802733934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302802733934 : Closed e302802733934 ∧ code e302802733934 = 1402314361710 := by decide
theorem cert_e302802733934 : check e302802733934 [[],[]] .smaller = true := by decide
def e302802733942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302802733942 : Closed e302802733942 ∧ code e302802733942 = 1402314361718 := by decide
theorem cert_e302802733942 : check e302802733942 [[],[]] .smaller = true := by decide
def e302802733946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302802733946 : Closed e302802733946 ∧ code e302802733946 = 1402314361722 := by decide
theorem cert_e302802733946 : check e302802733946 [[],[]] .chain = true := by decide
def e302802733998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302802733998 : Closed e302802733998 ∧ code e302802733998 = 1402314361774 := by decide
theorem cert_e302802733998 : check e302802733998 [[],[]] .smaller = true := by decide
def e302802734010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302802734010 : Closed e302802734010 ∧ code e302802734010 = 1402314361786 := by decide
theorem cert_e302802734010 : check e302802734010 [[],[]] .smaller = true := by decide
def e302802734038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302802734038 : Closed e302802734038 ∧ code e302802734038 = 1402314361814 := by decide
theorem cert_e302802734038 : check e302802734038 [[],[]] .smaller = true := by decide
def e302802734042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302802734042 : Closed e302802734042 ∧ code e302802734042 = 1402314361818 := by decide
theorem cert_e302802734042 : check e302802734042 [[],[]] .smaller = true := by decide
def e302802734058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302802734058 : Closed e302802734058 ∧ code e302802734058 = 1402314361834 := by decide
theorem cert_e302802734058 : check e302802734058 [[],[]] .chain = true := by decide
def e302802734302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302802734302 : Closed e302802734302 ∧ code e302802734302 = 1402314362078 := by decide
theorem cert_e302802734302 : check e302802734302 [[],[]] .chain = true := by decide
def e302802734318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302802734318 : Closed e302802734318 ∧ code e302802734318 = 1402314362094 := by decide
theorem cert_e302802734318 : check e302802734318 [[],[]] .smaller = true := by decide
def e302802734326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302802734326 : Closed e302802734326 ∧ code e302802734326 = 1402314362102 := by decide
theorem cert_e302802734326 : check e302802734326 [[],[]] .smaller = true := by decide
def e302802734330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302802734330 : Closed e302802734330 ∧ code e302802734330 = 1402314362106 := by decide
theorem cert_e302802734330 : check e302802734330 [[],[]] .chain = true := by decide
def e302802734654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e302802734654 : Closed e302802734654 ∧ code e302802734654 = 1402314362430 := by decide
theorem cert_e302802734654 : check e302802734654 [[],[]] .chain = true := by decide
def e302802734702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302802734702 : Closed e302802734702 ∧ code e302802734702 = 1402314362478 := by decide
theorem cert_e302802734702 : check e302802734702 [[],[]] .smaller = true := by decide
def e302802734714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302802734714 : Closed e302802734714 ∧ code e302802734714 = 1402314362490 := by decide
theorem cert_e302802734714 : check e302802734714 [[],[]] .smaller = true := by decide
def e302802734902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302802734902 : Closed e302802734902 ∧ code e302802734902 = 1402314362678 := by decide
theorem cert_e302802734902 : check e302802734902 [[],[]] .smaller = true := by decide
def e302802734906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302802734906 : Closed e302802734906 ∧ code e302802734906 = 1402314362682 := by decide
theorem cert_e302802734906 : check e302802734906 [[],[]] .smaller = true := by decide
def e302802734990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e302802734990 : Closed e302802734990 ∧ code e302802734990 = 1402314362766 := by decide
theorem cert_e302802734990 : check e302802734990 [[],[]] .chain = true := by decide
def e302802735002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302802735002 : Closed e302802735002 ∧ code e302802735002 = 1402314362778 := by decide
theorem cert_e302802735002 : check e302802735002 [[],[]] .chain = true := by decide
def e302802742382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302802742382 : Closed e302802742382 ∧ code e302802742382 = 1402314370158 := by decide
theorem cert_e302802742382 : check e302802742382 [[],[]] .chain = true := by decide
def e302802742394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302802742394 : Closed e302802742394 ∧ code e302802742394 = 1402314370170 := by decide
theorem cert_e302802742394 : check e302802742394 [[],[]] .chain = true := by decide
def e302802742558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302802742558 : Closed e302802742558 ∧ code e302802742558 = 1402314370334 := by decide
theorem cert_e302802742558 : check e302802742558 [[],[]] .chain = true := by decide
def e302802742726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302802742726 : Closed e302802742726 ∧ code e302802742726 = 1402314370502 := by decide
theorem cert_e302802742726 : check e302802742726 [[],[]] .chain = true := by decide
def e302802742830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e302802742830 : Closed e302802742830 ∧ code e302802742830 = 1402314370606 := by decide
theorem cert_e302802742830 : check e302802742830 [[],[]] .chain = true := by decide
def e302802743010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e302802743010 : Closed e302802743010 ∧ code e302802743010 = 1402314370786 := by decide
theorem cert_e302802743010 : check e302802743010 [[],[]] .chain = true := by decide
def e302802743022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e302802743022 : Closed e302802743022 ∧ code e302802743022 = 1402314370798 := by decide
theorem cert_e302802743022 : check e302802743022 [[],[]] .sourceHead = true := by decide
def e302802743062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302802743062 : Closed e302802743062 ∧ code e302802743062 = 1402314370838 := by decide
theorem cert_e302802743062 : check e302802743062 [[],[]] .chain = true := by decide
def e302802743066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302802743066 : Closed e302802743066 ∧ code e302802743066 = 1402314370842 := by decide
theorem cert_e302802743066 : check e302802743066 [[],[]] .chain = true := by decide
def e302802743110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302802743110 : Closed e302802743110 ∧ code e302802743110 = 1402314370886 := by decide
theorem cert_e302802743110 : check e302802743110 [[],[]] .chain = true := by decide
def e302802743138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302802743138 : Closed e302802743138 ∧ code e302802743138 = 1402314370914 := by decide
theorem cert_e302802743138 : check e302802743138 [[],[]] .chain = true := by decide
def e302802743150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e302802743150 : Closed e302802743150 ∧ code e302802743150 = 1402314370926 := by decide
theorem cert_e302802743150 : check e302802743150 [[],[]] .sourceHead = true := by decide
def e302802743158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e302802743158 : Closed e302802743158 ∧ code e302802743158 = 1402314370934 := by decide
theorem cert_e302802743158 : check e302802743158 [[],[]] .sourceHead = true := by decide
def e302802743518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e302802743518 : Closed e302802743518 ∧ code e302802743518 = 1402314371294 := by decide
theorem cert_e302802743518 : check e302802743518 [[],[]] .chain = true := by decide
def e302802743546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e302802743546 : Closed e302802743546 ∧ code e302802743546 = 1402314371322 := by decide
theorem cert_e302802743546 : check e302802743546 [[],[]] .chain = true := by decide
def e302802744094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302802744094 : Closed e302802744094 ∧ code e302802744094 = 1402314371870 := by decide
theorem cert_e302802744094 : check e302802744094 [[],[]] .chain = true := by decide
def e302802744262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302802744262 : Closed e302802744262 ∧ code e302802744262 = 1402314372038 := by decide
theorem cert_e302802744262 : check e302802744262 [[],[]] .chain = true := by decide
def e302802745406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e302802745406 : Closed e302802745406 ∧ code e302802745406 = 1402314373182 := by decide
theorem cert_e302802745406 : check e302802745406 [[],[]] .chain = true := by decide
def e302802745826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e302802745826 : Closed e302802745826 ∧ code e302802745826 = 1402314373602 := by decide
theorem cert_e302802745826 : check e302802745826 [[],[]] .chain = true := by decide
def e302802745838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e302802745838 : Closed e302802745838 ∧ code e302802745838 = 1402314373614 := by decide
theorem cert_e302802745838 : check e302802745838 [[],[]] .sourceHead = true := by decide
def e302802746398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e302802746398 : Closed e302802746398 ∧ code e302802746398 = 1402314374174 := by decide
theorem cert_e302802746398 : check e302802746398 [[],[]] .chain = true := by decide
def e302802746422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302802746422 : Closed e302802746422 ∧ code e302802746422 = 1402314374198 := by decide
theorem cert_e302802746422 : check e302802746422 [[],[]] .chain = true := by decide
def e302802746426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302802746426 : Closed e302802746426 ∧ code e302802746426 = 1402314374202 := by decide
theorem cert_e302802746426 : check e302802746426 [[],[]] .chain = true := by decide
def e302802746566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302802746566 : Closed e302802746566 ∧ code e302802746566 = 1402314374342 := by decide
theorem cert_e302802746566 : check e302802746566 [[],[]] .chain = true := by decide
def e302802746594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302802746594 : Closed e302802746594 ∧ code e302802746594 = 1402314374370 := by decide
theorem cert_e302802746594 : check e302802746594 [[],[]] .chain = true := by decide
def e302802746606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e302802746606 : Closed e302802746606 ∧ code e302802746606 = 1402314374382 := by decide
theorem cert_e302802746606 : check e302802746606 [[],[]] .sourceHead = true := by decide
def e302802746614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e302802746614 : Closed e302802746614 ∧ code e302802746614 = 1402314374390 := by decide
theorem cert_e302802746614 : check e302802746614 [[],[]] .sourceHead = true := by decide
def e302802769454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e302802769454 : Closed e302802769454 ∧ code e302802769454 = 1402314397230 := by decide
theorem cert_e302802769454 : check e302802769454 [[],[]] .chain = true := by decide
def e302802769634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e302802769634 : Closed e302802769634 ∧ code e302802769634 = 1402314397410 := by decide
theorem cert_e302802769634 : check e302802769634 [[],[]] .chain = true := by decide
def e302802769646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e302802769646 : Closed e302802769646 ∧ code e302802769646 = 1402314397422 := by decide
theorem cert_e302802769646 : check e302802769646 [[],[]] .sourceHead = true := by decide
def e302802769802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e302802769802 : Closed e302802769802 ∧ code e302802769802 = 1402314397578 := by decide
theorem cert_e302802769802 : check e302802769802 [[],[]] .chain = true := by decide
def e302802769826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e302802769826 : Closed e302802769826 ∧ code e302802769826 = 1402314397602 := by decide
theorem cert_e302802769826 : check e302802769826 [[],[]] .chain = true := by decide
def e302802769838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e302802769838 : Closed e302802769838 ∧ code e302802769838 = 1402314397614 := by decide
theorem cert_e302802769838 : check e302802769838 [[],[]] .sourceHead = true := by decide
def e302802769850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e302802769850 : Closed e302802769850 ∧ code e302802769850 = 1402314397626 := by decide
theorem cert_e302802769850 : check e302802769850 [[],[]] .sourceHead = true := by decide
def e302802769982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e302802769982 : Closed e302802769982 ∧ code e302802769982 = 1402314397758 := by decide
theorem cert_e302802769982 : check e302802769982 [[],[]] .chain = true := by decide
def e302802770402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e302802770402 : Closed e302802770402 ∧ code e302802770402 = 1402314398178 := by decide
theorem cert_e302802770402 : check e302802770402 [[],[]] .chain = true := by decide
def e302802770414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e302802770414 : Closed e302802770414 ∧ code e302802770414 = 1402314398190 := by decide
theorem cert_e302802770414 : check e302802770414 [[],[]] .sourceHead = true := by decide
def e302802771470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e302802771470 : Closed e302802771470 ∧ code e302802771470 = 1402314399246 := by decide
theorem cert_e302802771470 : check e302802771470 [[],[]] .chain = true := by decide
def e302802771554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e302802771554 : Closed e302802771554 ∧ code e302802771554 = 1402314399330 := by decide
theorem cert_e302802771554 : check e302802771554 [[],[]] .chain = true := by decide
def e302802771566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e302802771566 : Closed e302802771566 ∧ code e302802771566 = 1402314399342 := by decide
theorem cert_e302802771566 : check e302802771566 [[],[]] .sourceHead = true := by decide
def e302802771578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e302802771578 : Closed e302802771578 ∧ code e302802771578 = 1402314399354 := by decide
theorem cert_e302802771578 : check e302802771578 [[],[]] .sourceHead = true := by decide
def e302802780886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302802780886 : Closed e302802780886 ∧ code e302802780886 = 1402314408662 := by decide
theorem cert_e302802780886 : check e302802780886 [[],[]] .sourceHead = true := by decide
def e302802780890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302802780890 : Closed e302802780890 ∧ code e302802780890 = 1402314408666 := by decide
theorem cert_e302802780890 : check e302802780890 [[],[]] .sourceHead = true := by decide
def e302802780906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302802780906 : Closed e302802780906 ∧ code e302802780906 = 1402314408682 := by decide
theorem cert_e302802780906 : check e302802780906 [[],[]] .sourceHead = true := by decide
def e302802780982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302802780982 : Closed e302802780982 ∧ code e302802780982 = 1402314408758 := by decide
theorem cert_e302802780982 : check e302802780982 [[],[]] .sourceHead = true := by decide
def e302802780986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302802780986 : Closed e302802780986 ∧ code e302802780986 = 1402314408762 := by decide
theorem cert_e302802780986 : check e302802780986 [[],[]] .sourceHead = true := by decide
def e302802781070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e302802781070 : Closed e302802781070 ∧ code e302802781070 = 1402314408846 := by decide
theorem cert_e302802781070 : check e302802781070 [[],[]] .chain = true := by decide
def e302802781082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302802781082 : Closed e302802781082 ∧ code e302802781082 = 1402314408858 := by decide
theorem cert_e302802781082 : check e302802781082 [[],[]] .sourceHead = true := by decide
def e302802782998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302802782998 : Closed e302802782998 ∧ code e302802782998 = 1402314410774 := by decide
theorem cert_e302802782998 : check e302802782998 [[],[]] .chain = true := by decide
def e302802783002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302802783002 : Closed e302802783002 ∧ code e302802783002 = 1402314410778 := by decide
theorem cert_e302802783002 : check e302802783002 [[],[]] .chain = true := by decide
def e302802783046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302802783046 : Closed e302802783046 ∧ code e302802783046 = 1402314410822 := by decide
theorem cert_e302802783046 : check e302802783046 [[],[]] .chain = true := by decide
def e302802783074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302802783074 : Closed e302802783074 ∧ code e302802783074 = 1402314410850 := by decide
theorem cert_e302802783074 : check e302802783074 [[],[]] .chain = true := by decide
def e302802783086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302802783086 : Closed e302802783086 ∧ code e302802783086 = 1402314410862 := by decide
theorem cert_e302802783086 : check e302802783086 [[],[]] .sourceHead = true := by decide
def e302802783094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302802783094 : Closed e302802783094 ∧ code e302802783094 = 1402314410870 := by decide
theorem cert_e302802783094 : check e302802783094 [[],[]] .sourceHead = true := by decide
def e302802783114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e302802783114 : Closed e302802783114 ∧ code e302802783114 = 1402314410890 := by decide
theorem cert_e302802783114 : check e302802783114 [[],[]] .chain = true := by decide
def e302802783138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e302802783138 : Closed e302802783138 ∧ code e302802783138 = 1402314410914 := by decide
theorem cert_e302802783138 : check e302802783138 [[],[]] .chain = true := by decide
def e302802783150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302802783150 : Closed e302802783150 ∧ code e302802783150 = 1402314410926 := by decide
theorem cert_e302802783150 : check e302802783150 [[],[]] .sourceHead = true := by decide
def e302802783162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302802783162 : Closed e302802783162 ∧ code e302802783162 = 1402314410938 := by decide
theorem cert_e302802783162 : check e302802783162 [[],[]] .sourceHead = true := by decide
def e302802783190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302802783190 : Closed e302802783190 ∧ code e302802783190 = 1402314410966 := by decide
theorem cert_e302802783190 : check e302802783190 [[],[]] .sourceHead = true := by decide
def e302802783194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302802783194 : Closed e302802783194 ∧ code e302802783194 = 1402314410970 := by decide
theorem cert_e302802783194 : check e302802783194 [[],[]] .sourceHead = true := by decide
def e302802783262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e302802783262 : Closed e302802783262 ∧ code e302802783262 = 1402314411038 := by decide
theorem cert_e302802783262 : check e302802783262 [[],[]] .chain = true := by decide
def e302802783286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302802783286 : Closed e302802783286 ∧ code e302802783286 = 1402314411062 := by decide
theorem cert_e302802783286 : check e302802783286 [[],[]] .chain = true := by decide
def e302802783290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302802783290 : Closed e302802783290 ∧ code e302802783290 = 1402314411066 := by decide
theorem cert_e302802783290 : check e302802783290 [[],[]] .chain = true := by decide
def e302802783430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302802783430 : Closed e302802783430 ∧ code e302802783430 = 1402314411206 := by decide
theorem cert_e302802783430 : check e302802783430 [[],[]] .chain = true := by decide
def e302802783458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302802783458 : Closed e302802783458 ∧ code e302802783458 = 1402314411234 := by decide
theorem cert_e302802783458 : check e302802783458 [[],[]] .chain = true := by decide
def e302802783470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302802783470 : Closed e302802783470 ∧ code e302802783470 = 1402314411246 := by decide
theorem cert_e302802783470 : check e302802783470 [[],[]] .sourceHead = true := by decide
def e302802783478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302802783478 : Closed e302802783478 ∧ code e302802783478 = 1402314411254 := by decide
theorem cert_e302802783478 : check e302802783478 [[],[]] .sourceHead = true := by decide
def e302802783758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e302802783758 : Closed e302802783758 ∧ code e302802783758 = 1402314411534 := by decide
theorem cert_e302802783758 : check e302802783758 [[],[]] .chain = true := by decide
def e302802783842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e302802783842 : Closed e302802783842 ∧ code e302802783842 = 1402314411618 := by decide
theorem cert_e302802783842 : check e302802783842 [[],[]] .chain = true := by decide
def e302802783854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302802783854 : Closed e302802783854 ∧ code e302802783854 = 1402314411630 := by decide
theorem cert_e302802783854 : check e302802783854 [[],[]] .sourceHead = true := by decide
def e302802783866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302802783866 : Closed e302802783866 ∧ code e302802783866 = 1402314411642 := by decide
theorem cert_e302802783866 : check e302802783866 [[],[]] .sourceHead = true := by decide
def e302802784054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302802784054 : Closed e302802784054 ∧ code e302802784054 = 1402314411830 := by decide
theorem cert_e302802784054 : check e302802784054 [[],[]] .sourceHead = true := by decide
def e302802784058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302802784058 : Closed e302802784058 ∧ code e302802784058 = 1402314411834 := by decide
theorem cert_e302802784058 : check e302802784058 [[],[]] .sourceHead = true := by decide
def e302803082718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e302803082718 : Closed e302803082718 ∧ code e302803082718 = 1402314710494 := by decide
theorem cert_e302803082718 : check e302803082718 [[],[],[.under,.under]] .three = true := by decide
def e302803082734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e302803082734 : Closed e302803082734 ∧ code e302803082734 = 1402314710510 := by decide
theorem cert_e302803082734 : check e302803082734 [[],[],[.under,.under]] .three = true := by decide
def e302803082974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e302803082974 : Closed e302803082974 ∧ code e302803082974 = 1402314710750 := by decide
theorem cert_e302803082974 : check e302803082974 [[],[],[.under,.under]] .three = true := by decide
def e302803082998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e302803082998 : Closed e302803082998 ∧ code e302803082998 = 1402314710774 := by decide
theorem cert_e302803082998 : check e302803082998 [[],[],[.under,.under]] .three = true := by decide
def e302803083118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e302803083118 : Closed e302803083118 ∧ code e302803083118 = 1402314710894 := by decide
theorem cert_e302803083118 : check e302803083118 [[],[],[.under,.under]] .three = true := by decide
def e302803083126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e302803083126 : Closed e302803083126 ∧ code e302803083126 = 1402314710902 := by decide
theorem cert_e302803083126 : check e302803083126 [[],[],[.under,.under]] .three = true := by decide
def e302803088350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e302803088350 : Closed e302803088350 ∧ code e302803088350 = 1402314716126 := by decide
theorem cert_e302803088350 : check e302803088350 [[],[],[.under,.under]] .three = true := by decide
def e302803088366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e302803088366 : Closed e302803088366 ∧ code e302803088366 = 1402314716142 := by decide
theorem cert_e302803088366 : check e302803088366 [[],[],[.under,.under]] .three = true := by decide
def e302803089886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e302803089886 : Closed e302803089886 ∧ code e302803089886 = 1402314717662 := by decide
theorem cert_e302803089886 : check e302803089886 [[],[],[.under,.under]] .three = true := by decide
def e302803089910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e302803089910 : Closed e302803089910 ∧ code e302803089910 = 1402314717686 := by decide
theorem cert_e302803089910 : check e302803089910 [[],[],[.under,.under]] .three = true := by decide
def e302803090670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e302803090670 : Closed e302803090670 ∧ code e302803090670 = 1402314718446 := by decide
theorem cert_e302803090670 : check e302803090670 [[],[],[.under,.under]] .three = true := by decide
def e302803090678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e302803090678 : Closed e302803090678 ∧ code e302803090678 = 1402314718454 := by decide
theorem cert_e302803090678 : check e302803090678 [[],[],[.under,.under]] .three = true := by decide
def e302803146934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e302803146934 : Closed e302803146934 ∧ code e302803146934 = 1402314774710 := by decide
theorem cert_e302803146934 : check e302803146934 [[],[]] .chain = true := by decide
def e302803146966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e302803146966 : Closed e302803146966 ∧ code e302803146966 = 1402314774742 := by decide
theorem cert_e302803146966 : check e302803146966 [[],[]] .chain = true := by decide
def e302803146970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e302803146970 : Closed e302803146970 ∧ code e302803146970 = 1402314774746 := by decide
theorem cert_e302803146970 : check e302803146970 [[],[]] .chain = true := by decide
def e302803146986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e302803146986 : Closed e302803146986 ∧ code e302803146986 = 1402314774762 := by decide
theorem cert_e302803146986 : check e302803146986 [[],[]] .chain = true := by decide
def e302803147318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302803147318 : Closed e302803147318 ∧ code e302803147318 = 1402314775094 := by decide
theorem cert_e302803147318 : check e302803147318 [[],[]] .chain = true := by decide
def e302803147322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302803147322 : Closed e302803147322 ∧ code e302803147322 = 1402314775098 := by decide
theorem cert_e302803147322 : check e302803147322 [[],[]] .chain = true := by decide
def e302803147406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302803147406 : Closed e302803147406 ∧ code e302803147406 = 1402314775182 := by decide
theorem cert_e302803147406 : check e302803147406 [[],[]] .chain = true := by decide
def e302803147462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302803147462 : Closed e302803147462 ∧ code e302803147462 = 1402314775238 := by decide
theorem cert_e302803147462 : check e302803147462 [[],[]] .chain = true := by decide
def e302803147542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302803147542 : Closed e302803147542 ∧ code e302803147542 = 1402314775318 := by decide
theorem cert_e302803147542 : check e302803147542 [[],[]] .chain = true := by decide
def e302803147546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302803147546 : Closed e302803147546 ∧ code e302803147546 = 1402314775322 := by decide
theorem cert_e302803147546 : check e302803147546 [[],[]] .chain = true := by decide
def e302803147590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302803147590 : Closed e302803147590 ∧ code e302803147590 = 1402314775366 := by decide
theorem cert_e302803147590 : check e302803147590 [[],[]] .chain = true := by decide
def e302803147618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302803147618 : Closed e302803147618 ∧ code e302803147618 = 1402314775394 := by decide
theorem cert_e302803147618 : check e302803147618 [[],[]] .chain = true := by decide
def e302803147630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e302803147630 : Closed e302803147630 ∧ code e302803147630 = 1402314775406 := by decide
theorem cert_e302803147630 : check e302803147630 [[],[],[.under,.under]] .three = true := by decide
def e302803147638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e302803147638 : Closed e302803147638 ∧ code e302803147638 = 1402314775414 := by decide
theorem cert_e302803147638 : check e302803147638 [[],[],[.under,.under]] .three = true := by decide
def e302803147702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e302803147702 : Closed e302803147702 ∧ code e302803147702 = 1402314775478 := by decide
theorem cert_e302803147702 : check e302803147702 [[],[],[.under,.under]] .three = true := by decide
def e302803147862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302803147862 : Closed e302803147862 ∧ code e302803147862 = 1402314775638 := by decide
theorem cert_e302803147862 : check e302803147862 [[],[]] .chain = true := by decide
def e302803147866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302803147866 : Closed e302803147866 ∧ code e302803147866 = 1402314775642 := by decide
theorem cert_e302803147866 : check e302803147866 [[],[]] .chain = true := by decide
def e302803147882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302803147882 : Closed e302803147882 ∧ code e302803147882 = 1402314775658 := by decide
theorem cert_e302803147882 : check e302803147882 [[],[]] .chain = true := by decide
def e302803148054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302803148054 : Closed e302803148054 ∧ code e302803148054 = 1402314775830 := by decide
theorem cert_e302803148054 : check e302803148054 [[],[]] .chain = true := by decide
def e302803148058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302803148058 : Closed e302803148058 ∧ code e302803148058 = 1402314775834 := by decide
theorem cert_e302803148058 : check e302803148058 [[],[]] .chain = true := by decide
def e302803148102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302803148102 : Closed e302803148102 ∧ code e302803148102 = 1402314775878 := by decide
theorem cert_e302803148102 : check e302803148102 [[],[]] .chain = true := by decide
def e302803148130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302803148130 : Closed e302803148130 ∧ code e302803148130 = 1402314775906 := by decide
theorem cert_e302803148130 : check e302803148130 [[],[]] .chain = true := by decide
def e302803148142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302803148142 : Closed e302803148142 ∧ code e302803148142 = 1402314775918 := by decide
theorem cert_e302803148142 : check e302803148142 [[],[],[.under,.under]] .three = true := by decide
def e302803148150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302803148150 : Closed e302803148150 ∧ code e302803148150 = 1402314775926 := by decide
theorem cert_e302803148150 : check e302803148150 [[],[],[.under,.under]] .three = true := by decide
def e302803148170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302803148170 : Closed e302803148170 ∧ code e302803148170 = 1402314775946 := by decide
theorem cert_e302803148170 : check e302803148170 [[],[]] .chain = true := by decide
def e302803148194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302803148194 : Closed e302803148194 ∧ code e302803148194 = 1402314775970 := by decide
theorem cert_e302803148194 : check e302803148194 [[],[]] .chain = true := by decide
def e302803148206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302803148206 : Closed e302803148206 ∧ code e302803148206 = 1402314775982 := by decide
theorem cert_e302803148206 : check e302803148206 [[],[],[.under,.under]] .three = true := by decide
def e302803148218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302803148218 : Closed e302803148218 ∧ code e302803148218 = 1402314775994 := by decide
theorem cert_e302803148218 : check e302803148218 [[],[],[.under,.under]] .three = true := by decide
def e302803148246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302803148246 : Closed e302803148246 ∧ code e302803148246 = 1402314776022 := by decide
theorem cert_e302803148246 : check e302803148246 [[],[],[.under,.under]] .three = true := by decide
def e302803148250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302803148250 : Closed e302803148250 ∧ code e302803148250 = 1402314776026 := by decide
theorem cert_e302803148250 : check e302803148250 [[],[],[.under,.under]] .three = true := by decide
def e302803148470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e302803148470 : Closed e302803148470 ∧ code e302803148470 = 1402314776246 := by decide
theorem cert_e302803148470 : check e302803148470 [[],[],[.under,.under]] .three = true := by decide
def e302803148502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e302803148502 : Closed e302803148502 ∧ code e302803148502 = 1402314776278 := by decide
theorem cert_e302803148502 : check e302803148502 [[],[],[.under,.under]] .three = true := by decide
def e302803148506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e302803148506 : Closed e302803148506 ∧ code e302803148506 = 1402314776282 := by decide
theorem cert_e302803148506 : check e302803148506 [[],[],[.under,.under]] .three = true := by decide
def e302803149046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e302803149046 : Closed e302803149046 ∧ code e302803149046 = 1402314776822 := by decide
theorem cert_e302803149046 : check e302803149046 [[],[]] .chain = true := by decide
def e302803149238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e302803149238 : Closed e302803149238 ∧ code e302803149238 = 1402314777014 := by decide
theorem cert_e302803149238 : check e302803149238 [[],[]] .chain = true := by decide
def e302803149242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e302803149242 : Closed e302803149242 ∧ code e302803149242 = 1402314777018 := by decide
theorem cert_e302803149242 : check e302803149242 [[],[]] .chain = true := by decide
def e302803149270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e302803149270 : Closed e302803149270 ∧ code e302803149270 = 1402314777046 := by decide
theorem cert_e302803149270 : check e302803149270 [[],[]] .chain = true := by decide
def e302803149290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e302803149290 : Closed e302803149290 ∧ code e302803149290 = 1402314777066 := by decide
theorem cert_e302803149290 : check e302803149290 [[],[]] .chain = true := by decide
def e302803149430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e302803149430 : Closed e302803149430 ∧ code e302803149430 = 1402314777206 := by decide
theorem cert_e302803149430 : check e302803149430 [[],[]] .chain = true := by decide
def e302803149622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e302803149622 : Closed e302803149622 ∧ code e302803149622 = 1402314777398 := by decide
theorem cert_e302803149622 : check e302803149622 [[],[]] .chain = true := by decide
def e302803149626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e302803149626 : Closed e302803149626 ∧ code e302803149626 = 1402314777402 := by decide
theorem cert_e302803149626 : check e302803149626 [[],[]] .chain = true := by decide
def e302803149710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e302803149710 : Closed e302803149710 ∧ code e302803149710 = 1402314777486 := by decide
theorem cert_e302803149710 : check e302803149710 [[],[]] .chain = true := by decide
def e302803149722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e302803149722 : Closed e302803149722 ∧ code e302803149722 = 1402314777498 := by decide
theorem cert_e302803149722 : check e302803149722 [[],[]] .chain = true := by decide
def e302803150390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302803150390 : Closed e302803150390 ∧ code e302803150390 = 1402314778166 := by decide
theorem cert_e302803150390 : check e302803150390 [[],[]] .chain = true := by decide
def e302803150394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302803150394 : Closed e302803150394 ∧ code e302803150394 = 1402314778170 := by decide
theorem cert_e302803150394 : check e302803150394 [[],[]] .chain = true := by decide
def e302803150478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302803150478 : Closed e302803150478 ∧ code e302803150478 = 1402314778254 := by decide
theorem cert_e302803150478 : check e302803150478 [[],[]] .chain = true := by decide
def e302803150534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302803150534 : Closed e302803150534 ∧ code e302803150534 = 1402314778310 := by decide
theorem cert_e302803150534 : check e302803150534 [[],[]] .chain = true := by decide
def e302803150614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302803150614 : Closed e302803150614 ∧ code e302803150614 = 1402314778390 := by decide
theorem cert_e302803150614 : check e302803150614 [[],[]] .chain = true := by decide
def e302803150618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302803150618 : Closed e302803150618 ∧ code e302803150618 = 1402314778394 := by decide
theorem cert_e302803150618 : check e302803150618 [[],[]] .chain = true := by decide
def e302803150662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302803150662 : Closed e302803150662 ∧ code e302803150662 = 1402314778438 := by decide
theorem cert_e302803150662 : check e302803150662 [[],[]] .chain = true := by decide
def e302803150690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302803150690 : Closed e302803150690 ∧ code e302803150690 = 1402314778466 := by decide
theorem cert_e302803150690 : check e302803150690 [[],[]] .chain = true := by decide
def e302803150702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e302803150702 : Closed e302803150702 ∧ code e302803150702 = 1402314778478 := by decide
theorem cert_e302803150702 : check e302803150702 [[],[],[.under,.under]] .three = true := by decide
def e302803150710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e302803150710 : Closed e302803150710 ∧ code e302803150710 = 1402314778486 := by decide
theorem cert_e302803150710 : check e302803150710 [[],[],[.under,.under]] .three = true := by decide
end Blc.Floor40
