import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302392668886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302392668886 : Closed e302392668886 ∧ code e302392668886 = 1401904296662 := by decide
theorem cert_e302392668886 : check e302392668886 [[],[]] .three = true := by decide
def e302392668890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302392668890 : Closed e302392668890 ∧ code e302392668890 = 1401904296666 := by decide
theorem cert_e302392668890 : check e302392668890 [[],[]] .three = true := by decide
def e302392668906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302392668906 : Closed e302392668906 ∧ code e302392668906 = 1401904296682 := by decide
theorem cert_e302392668906 : check e302392668906 [[],[]] .three = true := by decide
def e302392668982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302392668982 : Closed e302392668982 ∧ code e302392668982 = 1401904296758 := by decide
theorem cert_e302392668982 : check e302392668982 [[],[]] .three = true := by decide
def e302392668986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302392668986 : Closed e302392668986 ∧ code e302392668986 = 1401904296762 := by decide
theorem cert_e302392668986 : check e302392668986 [[],[]] .three = true := by decide
def e302392669082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302392669082 : Closed e302392669082 ∧ code e302392669082 = 1401904296858 := by decide
theorem cert_e302392669082 : check e302392669082 [[],[]] .three = true := by decide
def e302392894318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e302392894318 : Closed e302392894318 ∧ code e302392894318 = 1401904522094 := by decide
theorem cert_e302392894318 : check e302392894318 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302392894326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e302392894326 : Closed e302392894326 ∧ code e302392894326 = 1401904522102 := by decide
theorem cert_e302392894326 : checkPay e302392894326 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302392894382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e302392894382 : Closed e302392894382 ∧ code e302392894382 = 1401904522158 := by decide
theorem cert_e302392894382 : check e302392894382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302392894394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e302392894394 : Closed e302392894394 ∧ code e302392894394 = 1401904522170 := by decide
theorem cert_e302392894394 : check e302392894394 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302392894422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e302392894422 : Closed e302392894422 ∧ code e302392894422 = 1401904522198 := by decide
theorem cert_e302392894422 : check e302392894422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392894426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e302392894426 : Closed e302392894426 ∧ code e302392894426 = 1401904522202 := by decide
theorem cert_e302392894426 : check e302392894426 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302392895726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e302392895726 : Closed e302392895726 ∧ code e302392895726 = 1401904523502 := by decide
theorem cert_e302392895726 : check e302392895726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302392895734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e302392895734 : Closed e302392895734 ∧ code e302392895734 = 1401904523510 := by decide
theorem cert_e302392895734 : checkPay e302392895734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302392896286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e302392896286 : Closed e302392896286 ∧ code e302392896286 = 1401904524062 := by decide
theorem cert_e302392896286 : check e302392896286 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e302392896398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e302392896398 : Closed e302392896398 ∧ code e302392896398 = 1401904524174 := by decide
theorem cert_e302392896398 : check e302392896398 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392896622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e302392896622 : Closed e302392896622 ∧ code e302392896622 = 1401904524398 := by decide
theorem cert_e302392896622 : check e302392896622 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302392896634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e302392896634 : Closed e302392896634 ∧ code e302392896634 = 1401904524410 := by decide
theorem cert_e302392896634 : check e302392896634 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302392896798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302392896798 : Closed e302392896798 ∧ code e302392896798 = 1401904524574 := by decide
theorem cert_e302392896798 : check e302392896798 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302392896966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302392896966 : Closed e302392896966 ∧ code e302392896966 = 1401904524742 := by decide
theorem cert_e302392896966 : check e302392896966 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302392897078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e302392897078 : Closed e302392897078 ∧ code e302392897078 = 1401904524854 := by decide
theorem cert_e302392897078 : check e302392897078 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392897082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e302392897082 : Closed e302392897082 ∧ code e302392897082 = 1401904524858 := by decide
theorem cert_e302392897082 : checkPay e302392897082 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] 0 [] = true := by decide
def e302392897166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302392897166 : Closed e302392897166 ∧ code e302392897166 = 1401904524942 := by decide
theorem cert_e302392897166 : check e302392897166 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392897222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302392897222 : Closed e302392897222 ∧ code e302392897222 = 1401904524998 := by decide
theorem cert_e302392897222 : check e302392897222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392897966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e302392897966 : Closed e302392897966 ∧ code e302392897966 = 1401904525742 := by decide
theorem cert_e302392897966 : check e302392897966 [[],[]] .sourceHead = true := by decide
def e302392897978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e302392897978 : Closed e302392897978 ∧ code e302392897978 = 1401904525754 := by decide
theorem cert_e302392897978 : check e302392897978 [[],[]] .sourceHead = true := by decide
def e302392898026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e302392898026 : Closed e302392898026 ∧ code e302392898026 = 1401904525802 := by decide
theorem cert_e302392898026 : check e302392898026 [[],[]] .sourceHead = true := by decide
def e302392898670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e302392898670 : Closed e302392898670 ∧ code e302392898670 = 1401904526446 := by decide
theorem cert_e302392898670 : check e302392898670 [[],[]] .sourceHead = true := by decide
def e302392898682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e302392898682 : Closed e302392898682 ∧ code e302392898682 = 1401904526458 := by decide
theorem cert_e302392898682 : check e302392898682 [[],[]] .sourceHead = true := by decide
def e302392898846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302392898846 : Closed e302392898846 ∧ code e302392898846 = 1401904526622 := by decide
theorem cert_e302392898846 : check e302392898846 [[],[]] .sourceHead = true := by decide
def e302392899014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302392899014 : Closed e302392899014 ∧ code e302392899014 = 1401904526790 := by decide
theorem cert_e302392899014 : check e302392899014 [[],[]] .sourceHead = true := by decide
def e302392899354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302392899354 : Closed e302392899354 ∧ code e302392899354 = 1401904527130 := by decide
theorem cert_e302392899354 : check e302392899354 [[],[]] .sourceHead = true := by decide
def e302392899398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302392899398 : Closed e302392899398 ∧ code e302392899398 = 1401904527174 := by decide
theorem cert_e302392899398 : check e302392899398 [[],[]] .sourceHead = true := by decide
def e302392899798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e302392899798 : Closed e302392899798 ∧ code e302392899798 = 1401904527574 := by decide
theorem cert_e302392899798 : check e302392899798 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392899802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e302392899802 : Closed e302392899802 ∧ code e302392899802 = 1401904527578 := by decide
theorem cert_e302392899802 : check e302392899802 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392899818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e302392899818 : Closed e302392899818 ∧ code e302392899818 = 1401904527594 := by decide
theorem cert_e302392899818 : check e302392899818 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392900150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e302392900150 : Closed e302392900150 ∧ code e302392900150 = 1401904527926 := by decide
theorem cert_e302392900150 : check e302392900150 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392900154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e302392900154 : Closed e302392900154 ∧ code e302392900154 = 1401904527930 := by decide
theorem cert_e302392900154 : check e302392900154 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392900238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302392900238 : Closed e302392900238 ∧ code e302392900238 = 1401904528014 := by decide
theorem cert_e302392900238 : check e302392900238 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392900294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302392900294 : Closed e302392900294 ∧ code e302392900294 = 1401904528070 := by decide
theorem cert_e302392900294 : check e302392900294 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392900378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302392900378 : Closed e302392900378 ∧ code e302392900378 = 1401904528154 := by decide
theorem cert_e302392900378 : check e302392900378 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392900422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302392900422 : Closed e302392900422 ∧ code e302392900422 = 1401904528198 := by decide
theorem cert_e302392900422 : check e302392900422 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302392904942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e302392904942 : Closed e302392904942 ∧ code e302392904942 = 1401904532718 := by decide
theorem cert_e302392904942 : check e302392904942 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392904950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e302392904950 : Closed e302392904950 ∧ code e302392904950 = 1401904532726 := by decide
theorem cert_e302392904950 : check e302392904950 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392905326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e302392905326 : Closed e302392905326 ∧ code e302392905326 = 1401904533102 := by decide
theorem cert_e302392905326 : checkPay e302392905326 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e302392905338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e302392905338 : Closed e302392905338 ∧ code e302392905338 = 1401904533114 := by decide
theorem cert_e302392905338 : checkPay e302392905338 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e302392905526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e302392905526 : Closed e302392905526 ∧ code e302392905526 = 1401904533302 := by decide
theorem cert_e302392905526 : check e302392905526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302392905530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e302392905530 : Closed e302392905530 ∧ code e302392905530 = 1401904533306 := by decide
theorem cert_e302392905530 : check e302392905530 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392908014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e302392908014 : Closed e302392908014 ∧ code e302392908014 = 1401904535790 := by decide
theorem cert_e302392908014 : check e302392908014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302392908022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e302392908022 : Closed e302392908022 ∧ code e302392908022 = 1401904535798 := by decide
theorem cert_e302392908022 : check e302392908022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392908574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e302392908574 : Closed e302392908574 ∧ code e302392908574 = 1401904536350 := by decide
theorem cert_e302392908574 : check e302392908574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e302392908686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e302392908686 : Closed e302392908686 ∧ code e302392908686 = 1401904536462 := by decide
theorem cert_e302392908686 : check e302392908686 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392908910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302392908910 : Closed e302392908910 ∧ code e302392908910 = 1401904536686 := by decide
theorem cert_e302392908910 : check e302392908910 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392908922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302392908922 : Closed e302392908922 ∧ code e302392908922 = 1401904536698 := by decide
theorem cert_e302392908922 : check e302392908922 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392909086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302392909086 : Closed e302392909086 ∧ code e302392909086 = 1401904536862 := by decide
theorem cert_e302392909086 : check e302392909086 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392909254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302392909254 : Closed e302392909254 ∧ code e302392909254 = 1401904537030 := by decide
theorem cert_e302392909254 : check e302392909254 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392909366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302392909366 : Closed e302392909366 ∧ code e302392909366 = 1401904537142 := by decide
theorem cert_e302392909366 : checkPay e302392909366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302392909370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302392909370 : Closed e302392909370 ∧ code e302392909370 = 1401904537146 := by decide
theorem cert_e302392909370 : checkPay e302392909370 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e302392909454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302392909454 : Closed e302392909454 ∧ code e302392909454 = 1401904537230 := by decide
theorem cert_e302392909454 : check e302392909454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392909510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302392909510 : Closed e302392909510 ∧ code e302392909510 = 1401904537286 := by decide
theorem cert_e302392909510 : check e302392909510 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e302392911646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e302392911646 : Closed e302392911646 ∧ code e302392911646 = 1401904539422 := by decide
theorem cert_e302392911646 : check e302392911646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392911758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e302392911758 : Closed e302392911758 ∧ code e302392911758 = 1401904539534 := by decide
theorem cert_e302392911758 : check e302392911758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392914718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302392914718 : Closed e302392914718 ∧ code e302392914718 = 1401904542494 := by decide
theorem cert_e302392914718 : check e302392914718 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392914886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302392914886 : Closed e302392914886 ∧ code e302392914886 = 1401904542662 := by decide
theorem cert_e302392914886 : check e302392914886 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302392916366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302392916366 : Closed e302392916366 ∧ code e302392916366 = 1401904544142 := by decide
theorem cert_e302392916366 : check e302392916366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392916422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302392916422 : Closed e302392916422 ∧ code e302392916422 = 1401904544198 := by decide
theorem cert_e302392916422 : check e302392916422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392919662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e302392919662 : Closed e302392919662 ∧ code e302392919662 = 1401904547438 := by decide
theorem cert_e302392919662 : checkPay e302392919662 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302392919674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e302392919674 : Closed e302392919674 ∧ code e302392919674 = 1401904547450 := by decide
theorem cert_e302392919674 : checkPay e302392919674 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302392919962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e302392919962 : Closed e302392919962 ∧ code e302392919962 = 1401904547738 := by decide
theorem cert_e302392919962 : checkPay e302392919962 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e302392921198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302392921198 : Closed e302392921198 ∧ code e302392921198 = 1401904548974 := by decide
theorem cert_e302392921198 : checkPay e302392921198 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e302392921210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302392921210 : Closed e302392921210 ∧ code e302392921210 = 1401904548986 := by decide
theorem cert_e302392921210 : checkPay e302392921210 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e302392921374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302392921374 : Closed e302392921374 ∧ code e302392921374 = 1401904549150 := by decide
theorem cert_e302392921374 : checkPay e302392921374 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e302392921542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302392921542 : Closed e302392921542 ∧ code e302392921542 = 1401904549318 := by decide
theorem cert_e302392921542 : checkPay e302392921542 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e302392921882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302392921882 : Closed e302392921882 ∧ code e302392921882 = 1401904549658 := by decide
theorem cert_e302392921882 : checkPay e302392921882 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e302392921926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302392921926 : Closed e302392921926 ∧ code e302392921926 = 1401904549702 := by decide
theorem cert_e302392921926 : checkPay e302392921926 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e302392922910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302392922910 : Closed e302392922910 ∧ code e302392922910 = 1401904550686 := by decide
theorem cert_e302392922910 : checkPay e302392922910 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302392923078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302392923078 : Closed e302392923078 ∧ code e302392923078 = 1401904550854 := by decide
theorem cert_e302392923078 : checkPay e302392923078 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302392925382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302392925382 : Closed e302392925382 ∧ code e302392925382 = 1401904553158 := by decide
theorem cert_e302392925382 : checkPay e302392925382 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302392927030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e302392927030 : Closed e302392927030 ∧ code e302392927030 = 1401904554806 := by decide
theorem cert_e302392927030 : check e302392927030 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392927034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e302392927034 : Closed e302392927034 ∧ code e302392927034 = 1401904554810 := by decide
theorem cert_e302392927034 : check e302392927034 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392927130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e302392927130 : Closed e302392927130 ∧ code e302392927130 = 1401904554906 := by decide
theorem cert_e302392927130 : check e302392927130 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392927798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302392927798 : Closed e302392927798 ∧ code e302392927798 = 1401904555574 := by decide
theorem cert_e302392927798 : check e302392927798 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392927802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302392927802 : Closed e302392927802 ∧ code e302392927802 = 1401904555578 := by decide
theorem cert_e302392927802 : check e302392927802 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392927886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302392927886 : Closed e302392927886 ∧ code e302392927886 = 1401904555662 := by decide
theorem cert_e302392927886 : check e302392927886 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392927942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302392927942 : Closed e302392927942 ∧ code e302392927942 = 1401904555718 := by decide
theorem cert_e302392927942 : check e302392927942 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392928026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302392928026 : Closed e302392928026 ∧ code e302392928026 = 1401904555802 := by decide
theorem cert_e302392928026 : check e302392928026 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392928070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302392928070 : Closed e302392928070 ∧ code e302392928070 = 1401904555846 := by decide
theorem cert_e302392928070 : check e302392928070 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392928654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302392928654 : Closed e302392928654 ∧ code e302392928654 = 1401904556430 := by decide
theorem cert_e302392928654 : check e302392928654 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392928710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302392928710 : Closed e302392928710 ∧ code e302392928710 = 1401904556486 := by decide
theorem cert_e302392928710 : check e302392928710 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392929478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302392929478 : Closed e302392929478 ∧ code e302392929478 = 1401904557254 := by decide
theorem cert_e302392929478 : check e302392929478 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302392940254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302392940254 : Closed e302392940254 ∧ code e302392940254 = 1401904568030 := by decide
theorem cert_e302392940254 : check e302392940254 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392940278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302392940278 : Closed e302392940278 ∧ code e302392940278 = 1401904568054 := by decide
theorem cert_e302392940278 : check e302392940278 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e302392940382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302392940382 : Closed e302392940382 ∧ code e302392940382 = 1401904568158 := by decide
theorem cert_e302392940382 : check e302392940382 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302392940410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302392940410 : Closed e302392940410 ∧ code e302392940410 = 1401904568186 := by decide
theorem cert_e302392940410 : check e302392940410 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392940502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302392940502 : Closed e302392940502 ∧ code e302392940502 = 1401904568278 := by decide
theorem cert_e302392940502 : check e302392940502 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392940506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302392940506 : Closed e302392940506 ∧ code e302392940506 = 1401904568282 := by decide
theorem cert_e302392940506 : check e302392940506 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e302392941022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302392941022 : Closed e302392941022 ∧ code e302392941022 = 1401904568798 := by decide
theorem cert_e302392941022 : check e302392941022 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[],[],[.left,.left],[.left],[],[],[.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e302392941046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302392941046 : Closed e302392941046 ∧ code e302392941046 = 1401904568822 := by decide
theorem cert_e302392941046 : check e302392941046 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e302392941790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302392941790 : Closed e302392941790 ∧ code e302392941790 = 1401904569566 := by decide
theorem cert_e302392941790 : check e302392941790 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392941818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302392941818 : Closed e302392941818 ∧ code e302392941818 = 1401904569594 := by decide
theorem cert_e302392941818 : check e302392941818 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e302392942390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302392942390 : Closed e302392942390 ∧ code e302392942390 = 1401904570166 := by decide
theorem cert_e302392942390 : check e302392942390 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e302392942394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302392942394 : Closed e302392942394 ∧ code e302392942394 = 1401904570170 := by decide
theorem cert_e302392942394 : check e302392942394 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e302392957166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302392957166 : Closed e302392957166 ∧ code e302392957166 = 1401904584942 := by decide
theorem cert_e302392957166 : check e302392957166 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302392957174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302392957174 : Closed e302392957174 ∧ code e302392957174 = 1401904584950 := by decide
theorem cert_e302392957174 : check e302392957174 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302392957726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302392957726 : Closed e302392957726 ∧ code e302392957726 = 1401904585502 := by decide
theorem cert_e302392957726 : check e302392957726 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e302392957838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302392957838 : Closed e302392957838 ∧ code e302392957838 = 1401904585614 := by decide
theorem cert_e302392957838 : check e302392957838 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392958062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302392958062 : Closed e302392958062 ∧ code e302392958062 = 1401904585838 := by decide
theorem cert_e302392958062 : check e302392958062 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302392958074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302392958074 : Closed e302392958074 ∧ code e302392958074 = 1401904585850 := by decide
theorem cert_e302392958074 : check e302392958074 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302392958238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302392958238 : Closed e302392958238 ∧ code e302392958238 = 1401904586014 := by decide
theorem cert_e302392958238 : check e302392958238 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302392958406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302392958406 : Closed e302392958406 ∧ code e302392958406 = 1401904586182 := by decide
theorem cert_e302392958406 : check e302392958406 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302392958518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302392958518 : Closed e302392958518 ∧ code e302392958518 = 1401904586294 := by decide
theorem cert_e302392958518 : check e302392958518 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302392958522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302392958522 : Closed e302392958522 ∧ code e302392958522 = 1401904586298 := by decide
theorem cert_e302392958522 : checkPay e302392958522 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e302392958606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302392958606 : Closed e302392958606 ∧ code e302392958606 = 1401904586382 := by decide
theorem cert_e302392958606 : checkPay e302392958606 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e302392958662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302392958662 : Closed e302392958662 ∧ code e302392958662 = 1401904586438 := by decide
theorem cert_e302392958662 : check e302392958662 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302392960798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302392960798 : Closed e302392960798 ∧ code e302392960798 = 1401904588574 := by decide
theorem cert_e302392960798 : check e302392960798 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e302392960910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302392960910 : Closed e302392960910 ∧ code e302392960910 = 1401904588686 := by decide
theorem cert_e302392960910 : check e302392960910 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e302392963870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302392963870 : Closed e302392963870 ∧ code e302392963870 = 1401904591646 := by decide
theorem cert_e302392963870 : check e302392963870 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302392964038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302392964038 : Closed e302392964038 ∧ code e302392964038 = 1401904591814 := by decide
theorem cert_e302392964038 : check e302392964038 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302392965518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302392965518 : Closed e302392965518 ∧ code e302392965518 = 1401904593294 := by decide
theorem cert_e302392965518 : check e302392965518 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e302392965574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302392965574 : Closed e302392965574 ∧ code e302392965574 = 1401904593350 := by decide
theorem cert_e302392965574 : check e302392965574 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e302393002862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302393002862 : Closed e302393002862 ∧ code e302393002862 = 1401904630638 := by decide
theorem cert_e302393002862 : check e302393002862 [[],[]] .smaller = true := by decide
def e302393002870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302393002870 : Closed e302393002870 ∧ code e302393002870 = 1401904630646 := by decide
theorem cert_e302393002870 : check e302393002870 [[],[]] .smaller = true := by decide
def e302393002926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302393002926 : Closed e302393002926 ∧ code e302393002926 = 1401904630702 := by decide
theorem cert_e302393002926 : check e302393002926 [[],[]] .smaller = true := by decide
def e302393002938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302393002938 : Closed e302393002938 ∧ code e302393002938 = 1401904630714 := by decide
theorem cert_e302393002938 : check e302393002938 [[],[]] .smaller = true := by decide
def e302393002966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302393002966 : Closed e302393002966 ∧ code e302393002966 = 1401904630742 := by decide
theorem cert_e302393002966 : check e302393002966 [[],[]] .smaller = true := by decide
def e302393002970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302393002970 : Closed e302393002970 ∧ code e302393002970 = 1401904630746 := by decide
theorem cert_e302393002970 : check e302393002970 [[],[]] .smaller = true := by decide
def e302393003246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302393003246 : Closed e302393003246 ∧ code e302393003246 = 1401904631022 := by decide
theorem cert_e302393003246 : check e302393003246 [[],[]] .smaller = true := by decide
def e302393003254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302393003254 : Closed e302393003254 ∧ code e302393003254 = 1401904631030 := by decide
theorem cert_e302393003254 : check e302393003254 [[],[]] .smaller = true := by decide
def e302393003630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302393003630 : Closed e302393003630 ∧ code e302393003630 = 1401904631406 := by decide
theorem cert_e302393003630 : check e302393003630 [[],[]] .smaller = true := by decide
def e302393003642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302393003642 : Closed e302393003642 ∧ code e302393003642 = 1401904631418 := by decide
theorem cert_e302393003642 : check e302393003642 [[],[]] .smaller = true := by decide
def e302393003830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302393003830 : Closed e302393003830 ∧ code e302393003830 = 1401904631606 := by decide
theorem cert_e302393003830 : check e302393003830 [[],[]] .smaller = true := by decide
def e302393003834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302393003834 : Closed e302393003834 ∧ code e302393003834 = 1401904631610 := by decide
theorem cert_e302393003834 : check e302393003834 [[],[]] .smaller = true := by decide
def e302393011310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302393011310 : Closed e302393011310 ∧ code e302393011310 = 1401904639086 := by decide
theorem cert_e302393011310 : check e302393011310 [[],[]] .sourceHead = true := by decide
def e302393011322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302393011322 : Closed e302393011322 ∧ code e302393011322 = 1401904639098 := by decide
theorem cert_e302393011322 : check e302393011322 [[],[]] .sourceHead = true := by decide
def e302393011486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302393011486 : Closed e302393011486 ∧ code e302393011486 = 1401904639262 := by decide
theorem cert_e302393011486 : check e302393011486 [[],[]] .sourceHead = true := by decide
def e302393011654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302393011654 : Closed e302393011654 ∧ code e302393011654 = 1401904639430 := by decide
theorem cert_e302393011654 : check e302393011654 [[],[]] .sourceHead = true := by decide
def e302393011994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302393011994 : Closed e302393011994 ∧ code e302393011994 = 1401904639770 := by decide
theorem cert_e302393011994 : check e302393011994 [[],[]] .sourceHead = true := by decide
def e302393012038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302393012038 : Closed e302393012038 ∧ code e302393012038 = 1401904639814 := by decide
theorem cert_e302393012038 : check e302393012038 [[],[]] .sourceHead = true := by decide
def e302393013022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302393013022 : Closed e302393013022 ∧ code e302393013022 = 1401904640798 := by decide
theorem cert_e302393013022 : check e302393013022 [[],[]] .sourceHead = true := by decide
def e302393013190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302393013190 : Closed e302393013190 ∧ code e302393013190 = 1401904640966 := by decide
theorem cert_e302393013190 : check e302393013190 [[],[]] .sourceHead = true := by decide
def e302393015494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302393015494 : Closed e302393015494 ∧ code e302393015494 = 1401904643270 := by decide
theorem cert_e302393015494 : check e302393015494 [[],[]] .sourceHead = true := by decide
def e302393038390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302393038390 : Closed e302393038390 ∧ code e302393038390 = 1401904666166 := by decide
theorem cert_e302393038390 : check e302393038390 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393038394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302393038394 : Closed e302393038394 ∧ code e302393038394 = 1401904666170 := by decide
theorem cert_e302393038394 : check e302393038394 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393038478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302393038478 : Closed e302393038478 ∧ code e302393038478 = 1401904666254 := by decide
theorem cert_e302393038478 : check e302393038478 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393038534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302393038534 : Closed e302393038534 ∧ code e302393038534 = 1401904666310 := by decide
theorem cert_e302393038534 : check e302393038534 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393038618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302393038618 : Closed e302393038618 ∧ code e302393038618 = 1401904666394 := by decide
theorem cert_e302393038618 : check e302393038618 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393038662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302393038662 : Closed e302393038662 ∧ code e302393038662 = 1401904666438 := by decide
theorem cert_e302393038662 : check e302393038662 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393039246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302393039246 : Closed e302393039246 ∧ code e302393039246 = 1401904667022 := by decide
theorem cert_e302393039246 : check e302393039246 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393039302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302393039302 : Closed e302393039302 ∧ code e302393039302 = 1401904667078 := by decide
theorem cert_e302393039302 : check e302393039302 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302393040070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302393040070 : Closed e302393040070 ∧ code e302393040070 = 1401904667846 := by decide
theorem cert_e302393040070 : check e302393040070 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302394136814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302394136814 : Closed e302394136814 ∧ code e302394136814 = 1401905764590 := by decide
theorem cert_e302394136814 : check e302394136814 [[],[]] .sourceHead = true := by decide
def e302394136822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302394136822 : Closed e302394136822 ∧ code e302394136822 = 1401905764598 := by decide
theorem cert_e302394136822 : check e302394136822 [[],[]] .sourceHead = true := by decide
def e302394137374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302394137374 : Closed e302394137374 ∧ code e302394137374 = 1401905765150 := by decide
theorem cert_e302394137374 : check e302394137374 [[],[]] .sourceHead = true := by decide
def e302394137486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302394137486 : Closed e302394137486 ∧ code e302394137486 = 1401905765262 := by decide
theorem cert_e302394137486 : check e302394137486 [[],[]] .sourceHead = true := by decide
def e302394137710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302394137710 : Closed e302394137710 ∧ code e302394137710 = 1401905765486 := by decide
theorem cert_e302394137710 : check e302394137710 [[],[]] .sourceHead = true := by decide
def e302394137722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302394137722 : Closed e302394137722 ∧ code e302394137722 = 1401905765498 := by decide
theorem cert_e302394137722 : check e302394137722 [[],[]] .sourceHead = true := by decide
def e302394137886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302394137886 : Closed e302394137886 ∧ code e302394137886 = 1401905765662 := by decide
theorem cert_e302394137886 : check e302394137886 [[],[]] .sourceHead = true := by decide
def e302394138054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302394138054 : Closed e302394138054 ∧ code e302394138054 = 1401905765830 := by decide
theorem cert_e302394138054 : check e302394138054 [[],[]] .sourceHead = true := by decide
def e302394138166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302394138166 : Closed e302394138166 ∧ code e302394138166 = 1401905765942 := by decide
theorem cert_e302394138166 : check e302394138166 [[],[]] .sourceHead = true := by decide
def e302394138170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302394138170 : Closed e302394138170 ∧ code e302394138170 = 1401905765946 := by decide
theorem cert_e302394138170 : check e302394138170 [[],[]] .sourceHead = true := by decide
end Blc.Floor40
