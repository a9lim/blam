from indexed import *
for p in sorted(HERE.glob('h[0-9]*.json')):
    s=f'{int(p.stem[1:]):040b}';r=json.loads(p.read_text())
    if (HERE/('R'+p.stem[1:]+'.olean')).exists():continue
    _,(cc,mm,rr),aa=r[1];alt= tuple(lc.decode(w)[0] for w in [cc,mm,rr])+([lc.decode(w)[0] for w in aa],)
    mods=emitindex(s,r,alt)
    subprocess.run([sys.executable,'build.py',*mods],check=True,timeout=280)
