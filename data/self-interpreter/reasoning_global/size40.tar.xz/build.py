from pathlib import Path
import os,sys,subprocess,time,json,resource
here=Path(__file__).resolve().parent
root=here.parents[2]
prefix=Path.home()/'.elan/toolchains'/(root/'lean/lean-toolchain').read_text().strip().replace('/','--').replace(':','---')
env=dict(os.environ, LEAN_PATH=':'.join(str(p) for p in [here,root/'lean/.lake/build/lib/lean',prefix/'lib/lean']),LEAN_NUM_THREADS='2')
import fcntl
lock=(here/".lean.lock").open("a")
for name in sys.argv[1:]:
    fcntl.flock(lock,fcntl.LOCK_EX)
    start=time.monotonic()
    with (here/(name+'.log')).open('w') as log:
        p=subprocess.Popen([str(prefix/'bin/lean'),'-j2','-M','900','--root='+str(here),str(here/(name+'.lean')),'-o',str(here/(name+'.olean'))],cwd=here,env=env,stdout=log,stderr=log)
        import signal
        def expire(*_):p.kill()
        signal.signal(signal.SIGALRM,expire);signal.alarm(180)
        _,st,r= os.wait4(p.pid,0);signal.alarm(0);p.returncode=os.waitstatus_to_exitcode(st)
    fcntl.flock(lock,fcntl.LOCK_UN)
    row=dict(module=name,seconds=round(time.monotonic()-start,3),rss_bytes=r.ru_maxrss,code=p.returncode)
    with (here/'build.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
    if p.returncode:print(row,(here/(name+'.log')).read_text()[:6000]);sys.exit(1)
    print(name,row['seconds'],flush=True)
