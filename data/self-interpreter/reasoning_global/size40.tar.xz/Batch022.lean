import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301453730778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e301453730778 : Closed e301453730778 ∧ code e301453730778 = 1400965358554 := by decide
theorem cert_e301453730778 : check e301453730778 [[],[]] .chain = true := by decide
def e301453731502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e301453731502 : Closed e301453731502 ∧ code e301453731502 = 1400965359278 := by decide
theorem cert_e301453731502 : check e301453731502 [[],[]] .chain = true := by decide
def e301453731514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e301453731514 : Closed e301453731514 ∧ code e301453731514 = 1400965359290 := by decide
theorem cert_e301453731514 : check e301453731514 [[],[]] .chain = true := by decide
def e301453731562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e301453731562 : Closed e301453731562 ∧ code e301453731562 = 1400965359338 := by decide
theorem cert_e301453731562 : check e301453731562 [[],[]] .chain = true := by decide
def e301453731754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e301453731754 : Closed e301453731754 ∧ code e301453731754 = 1400965359530 := by decide
theorem cert_e301453731754 : check e301453731754 [[],[]] .chain = true := by decide
def e301453732078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e301453732078 : Closed e301453732078 ∧ code e301453732078 = 1400965359854 := by decide
theorem cert_e301453732078 : check e301453732078 [[],[]] .chain = true := by decide
def e301453732086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e301453732086 : Closed e301453732086 ∧ code e301453732086 = 1400965359862 := by decide
theorem cert_e301453732086 : check e301453732086 [[],[]] .chain = true := by decide
def e301453732270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e301453732270 : Closed e301453732270 ∧ code e301453732270 = 1400965360046 := by decide
theorem cert_e301453732270 : check e301453732270 [[],[]] .chain = true := by decide
def e301453732282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e301453732282 : Closed e301453732282 ∧ code e301453732282 = 1400965360058 := by decide
theorem cert_e301453732282 : check e301453732282 [[],[]] .chain = true := by decide
def e301453732330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e301453732330 : Closed e301453732330 ∧ code e301453732330 = 1400965360106 := by decide
theorem cert_e301453732330 : check e301453732330 [[],[]] .chain = true := by decide
def e301453732462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e301453732462 : Closed e301453732462 ∧ code e301453732462 = 1400965360238 := by decide
theorem cert_e301453732462 : check e301453732462 [[],[]] .chain = true := by decide
def e301453732474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e301453732474 : Closed e301453732474 ∧ code e301453732474 = 1400965360250 := by decide
theorem cert_e301453732474 : check e301453732474 [[],[]] .chain = true := by decide
def e301453732638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e301453732638 : Closed e301453732638 ∧ code e301453732638 = 1400965360414 := by decide
theorem cert_e301453732638 : check e301453732638 [[],[]] .chain = true := by decide
def e301453732750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e301453732750 : Closed e301453732750 ∧ code e301453732750 = 1400965360526 := by decide
theorem cert_e301453732750 : check e301453732750 [[],[]] .chain = true := by decide
def e301453732762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e301453732762 : Closed e301453732762 ∧ code e301453732762 = 1400965360538 := by decide
theorem cert_e301453732762 : check e301453732762 [[],[]] .chain = true := by decide
def e301453732974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e301453732974 : Closed e301453732974 ∧ code e301453732974 = 1400965360750 := by decide
theorem cert_e301453732974 : check e301453732974 [[],[]] .chain = true := by decide
def e301453732986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e301453732986 : Closed e301453732986 ∧ code e301453732986 = 1400965360762 := by decide
theorem cert_e301453732986 : check e301453732986 [[],[]] .chain = true := by decide
def e301453733150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e301453733150 : Closed e301453733150 ∧ code e301453733150 = 1400965360926 := by decide
theorem cert_e301453733150 : check e301453733150 [[],[]] .chain = true := by decide
def e301453733318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e301453733318 : Closed e301453733318 ∧ code e301453733318 = 1400965361094 := by decide
theorem cert_e301453733318 : check e301453733318 [[],[]] .chain = true := by decide
def e301453733430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e301453733430 : Closed e301453733430 ∧ code e301453733430 = 1400965361206 := by decide
theorem cert_e301453733430 : check e301453733430 [[],[]] .chain = true := by decide
def e301453733434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e301453733434 : Closed e301453733434 ∧ code e301453733434 = 1400965361210 := by decide
theorem cert_e301453733434 : check e301453733434 [[],[]] .chain = true := by decide
def e301453733482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e301453733482 : Closed e301453733482 ∧ code e301453733482 = 1400965361258 := by decide
theorem cert_e301453733482 : check e301453733482 [[],[]] .chain = true := by decide
def e301453733518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e301453733518 : Closed e301453733518 ∧ code e301453733518 = 1400965361294 := by decide
theorem cert_e301453733518 : check e301453733518 [[],[]] .chain = true := by decide
def e301453733530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e301453733530 : Closed e301453733530 ∧ code e301453733530 = 1400965361306 := by decide
theorem cert_e301453733530 : check e301453733530 [[],[]] .chain = true := by decide
def e301453733574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e301453733574 : Closed e301453733574 ∧ code e301453733574 = 1400965361350 := by decide
theorem cert_e301453733574 : check e301453733574 [[],[]] .chain = true := by decide
def e301453734326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e301453734326 : Closed e301453734326 ∧ code e301453734326 = 1400965362102 := by decide
theorem cert_e301453734326 : check e301453734326 [[],[]] .chain = true := by decide
def e301453734358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e301453734358 : Closed e301453734358 ∧ code e301453734358 = 1400965362134 := by decide
theorem cert_e301453734358 : check e301453734358 [[],[]] .chain = true := by decide
def e301453734362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e301453734362 : Closed e301453734362 ∧ code e301453734362 = 1400965362138 := by decide
theorem cert_e301453734362 : check e301453734362 [[],[]] .chain = true := by decide
def e301453734742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e301453734742 : Closed e301453734742 ∧ code e301453734742 = 1400965362518 := by decide
theorem cert_e301453734742 : check e301453734742 [[],[]] .chain = true := by decide
def e301453734746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e301453734746 : Closed e301453734746 ∧ code e301453734746 = 1400965362522 := by decide
theorem cert_e301453734746 : check e301453734746 [[],[]] .chain = true := by decide
def e301453734762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e301453734762 : Closed e301453734762 ∧ code e301453734762 = 1400965362538 := by decide
theorem cert_e301453734762 : check e301453734762 [[],[]] .chain = true := by decide
def e301453734826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e301453734826 : Closed e301453734826 ∧ code e301453734826 = 1400965362602 := by decide
theorem cert_e301453734826 : check e301453734826 [[],[]] .chain = true := by decide
def e301453735030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e301453735030 : Closed e301453735030 ∧ code e301453735030 = 1400965362806 := by decide
theorem cert_e301453735030 : check e301453735030 [[],[]] .chain = true := by decide
def e301453735126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e301453735126 : Closed e301453735126 ∧ code e301453735126 = 1400965362902 := by decide
theorem cert_e301453735126 : check e301453735126 [[],[]] .chain = true := by decide
def e301453735130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e301453735130 : Closed e301453735130 ∧ code e301453735130 = 1400965362906 := by decide
theorem cert_e301453735130 : check e301453735130 [[],[]] .chain = true := by decide
def e301453735146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e301453735146 : Closed e301453735146 ∧ code e301453735146 = 1400965362922 := by decide
theorem cert_e301453735146 : check e301453735146 [[],[]] .chain = true := by decide
def e301453735222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e301453735222 : Closed e301453735222 ∧ code e301453735222 = 1400965362998 := by decide
theorem cert_e301453735222 : check e301453735222 [[],[]] .chain = true := by decide
def e301453735226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e301453735226 : Closed e301453735226 ∧ code e301453735226 = 1400965363002 := by decide
theorem cert_e301453735226 : check e301453735226 [[],[]] .chain = true := by decide
def e301453735310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e301453735310 : Closed e301453735310 ∧ code e301453735310 = 1400965363086 := by decide
theorem cert_e301453735310 : check e301453735310 [[],[]] .chain = true := by decide
def e301453735322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e301453735322 : Closed e301453735322 ∧ code e301453735322 = 1400965363098 := by decide
theorem cert_e301453735322 : check e301453735322 [[],[]] .chain = true := by decide
def e301453735478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e301453735478 : Closed e301453735478 ∧ code e301453735478 = 1400965363254 := by decide
theorem cert_e301453735478 : check e301453735478 [[],[]] .chain = true := by decide
def e301453735482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e301453735482 : Closed e301453735482 ∧ code e301453735482 = 1400965363258 := by decide
theorem cert_e301453735482 : check e301453735482 [[],[]] .chain = true := by decide
def e301453735530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e301453735530 : Closed e301453735530 ∧ code e301453735530 = 1400965363306 := by decide
theorem cert_e301453735530 : check e301453735530 [[],[]] .chain = true := by decide
def e301453735566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e301453735566 : Closed e301453735566 ∧ code e301453735566 = 1400965363342 := by decide
theorem cert_e301453735566 : check e301453735566 [[],[]] .chain = true := by decide
def e301453735578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e301453735578 : Closed e301453735578 ∧ code e301453735578 = 1400965363354 := by decide
theorem cert_e301453735578 : check e301453735578 [[],[]] .chain = true := by decide
def e301453735622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e301453735622 : Closed e301453735622 ∧ code e301453735622 = 1400965363398 := by decide
theorem cert_e301453735622 : check e301453735622 [[],[]] .chain = true := by decide
def e301453741806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e301453741806 : Closed e301453741806 ∧ code e301453741806 = 1400965369582 := by decide
theorem cert_e301453741806 : check e301453741806 [[],[]] .chain = true := by decide
def e301453741814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e301453741814 : Closed e301453741814 ∧ code e301453741814 = 1400965369590 := by decide
theorem cert_e301453741814 : check e301453741814 [[],[]] .chain = true := by decide
def e301453741934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e301453741934 : Closed e301453741934 ∧ code e301453741934 = 1400965369710 := by decide
theorem cert_e301453741934 : check e301453741934 [[],[]] .chain = true := by decide
def e301453741946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e301453741946 : Closed e301453741946 ∧ code e301453741946 = 1400965369722 := by decide
theorem cert_e301453741946 : check e301453741946 [[],[]] .chain = true := by decide
def e301453742006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e301453742006 : Closed e301453742006 ∧ code e301453742006 = 1400965369782 := by decide
theorem cert_e301453742006 : check e301453742006 [[],[]] .chain = true := by decide
def e301453742010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e301453742010 : Closed e301453742010 ∧ code e301453742010 = 1400965369786 := by decide
theorem cert_e301453742010 : check e301453742010 [[],[]] .chain = true := by decide
def e301453745390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e301453745390 : Closed e301453745390 ∧ code e301453745390 = 1400965373166 := by decide
theorem cert_e301453745390 : check e301453745390 [[],[]] .chain = true := by decide
def e301453745398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e301453745398 : Closed e301453745398 ∧ code e301453745398 = 1400965373174 := by decide
theorem cert_e301453745398 : check e301453745398 [[],[]] .chain = true := by decide
def e301453745782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e301453745782 : Closed e301453745782 ∧ code e301453745782 = 1400965373558 := by decide
theorem cert_e301453745782 : check e301453745782 [[],[]] .chain = true := by decide
def e301453749614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e301453749614 : Closed e301453749614 ∧ code e301453749614 = 1400965377390 := by decide
theorem cert_e301453749614 : check e301453749614 [[],[]] .chain = true := by decide
def e301453749622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e301453749622 : Closed e301453749622 ∧ code e301453749622 = 1400965377398 := by decide
theorem cert_e301453749622 : check e301453749622 [[],[]] .chain = true := by decide
def e301453749678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e301453749678 : Closed e301453749678 ∧ code e301453749678 = 1400965377454 := by decide
theorem cert_e301453749678 : check e301453749678 [[],[]] .chain = true := by decide
def e301453749690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e301453749690 : Closed e301453749690 ∧ code e301453749690 = 1400965377466 := by decide
theorem cert_e301453749690 : check e301453749690 [[],[]] .chain = true := by decide
def e301453749718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e301453749718 : Closed e301453749718 ∧ code e301453749718 = 1400965377494 := by decide
theorem cert_e301453749718 : check e301453749718 [[],[]] .chain = true := by decide
def e301453749722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e301453749722 : Closed e301453749722 ∧ code e301453749722 = 1400965377498 := by decide
theorem cert_e301453749722 : check e301453749722 [[],[]] .chain = true := by decide
def e301453749934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e301453749934 : Closed e301453749934 ∧ code e301453749934 = 1400965377710 := by decide
theorem cert_e301453749934 : check e301453749934 [[],[]] .chain = true := by decide
def e301453749946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e301453749946 : Closed e301453749946 ∧ code e301453749946 = 1400965377722 := by decide
theorem cert_e301453749946 : check e301453749946 [[],[]] .chain = true := by decide
def e301453749994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e301453749994 : Closed e301453749994 ∧ code e301453749994 = 1400965377770 := by decide
theorem cert_e301453749994 : check e301453749994 [[],[]] .chain = true := by decide
def e301453750102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e301453750102 : Closed e301453750102 ∧ code e301453750102 = 1400965377878 := by decide
theorem cert_e301453750102 : check e301453750102 [[],[]] .chain = true := by decide
def e301453750106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e301453750106 : Closed e301453750106 ∧ code e301453750106 = 1400965377882 := by decide
theorem cert_e301453750106 : check e301453750106 [[],[]] .chain = true := by decide
def e301453750122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e301453750122 : Closed e301453750122 ∧ code e301453750122 = 1400965377898 := by decide
theorem cert_e301453750122 : check e301453750122 [[],[]] .chain = true := by decide
def e301453751150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e301453751150 : Closed e301453751150 ∧ code e301453751150 = 1400965378926 := by decide
theorem cert_e301453751150 : check e301453751150 [[],[]] .chain = true := by decide
def e301453751158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e301453751158 : Closed e301453751158 ∧ code e301453751158 = 1400965378934 := by decide
theorem cert_e301453751158 : check e301453751158 [[],[]] .chain = true := by decide
def e301453751214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e301453751214 : Closed e301453751214 ∧ code e301453751214 = 1400965378990 := by decide
theorem cert_e301453751214 : check e301453751214 [[],[]] .chain = true := by decide
def e301453751226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e301453751226 : Closed e301453751226 ∧ code e301453751226 = 1400965379002 := by decide
theorem cert_e301453751226 : check e301453751226 [[],[]] .chain = true := by decide
def e301453751254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e301453751254 : Closed e301453751254 ∧ code e301453751254 = 1400965379030 := by decide
theorem cert_e301453751254 : check e301453751254 [[],[]] .chain = true := by decide
def e301453751258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e301453751258 : Closed e301453751258 ∧ code e301453751258 = 1400965379034 := by decide
theorem cert_e301453751258 : check e301453751258 [[],[]] .chain = true := by decide
def e301453751534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e301453751534 : Closed e301453751534 ∧ code e301453751534 = 1400965379310 := by decide
theorem cert_e301453751534 : check e301453751534 [[],[]] .chain = true := by decide
def e301453751542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e301453751542 : Closed e301453751542 ∧ code e301453751542 = 1400965379318 := by decide
theorem cert_e301453751542 : check e301453751542 [[],[]] .chain = true := by decide
def e301453751918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e301453751918 : Closed e301453751918 ∧ code e301453751918 = 1400965379694 := by decide
theorem cert_e301453751918 : check e301453751918 [[],[]] .chain = true := by decide
def e301453751930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e301453751930 : Closed e301453751930 ∧ code e301453751930 = 1400965379706 := by decide
theorem cert_e301453751930 : check e301453751930 [[],[]] .chain = true := by decide
def e301453752118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e301453752118 : Closed e301453752118 ∧ code e301453752118 = 1400965379894 := by decide
theorem cert_e301453752118 : check e301453752118 [[],[]] .chain = true := by decide
def e301453752122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e301453752122 : Closed e301453752122 ∧ code e301453752122 = 1400965379898 := by decide
theorem cert_e301453752122 : check e301453752122 [[],[]] .chain = true := by decide
def e301453752558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e301453752558 : Closed e301453752558 ∧ code e301453752558 = 1400965380334 := by decide
theorem cert_e301453752558 : check e301453752558 [[],[]] .chain = true := by decide
def e301453752566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e301453752566 : Closed e301453752566 ∧ code e301453752566 = 1400965380342 := by decide
theorem cert_e301453752566 : check e301453752566 [[],[]] .chain = true := by decide
def e301453752750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e301453752750 : Closed e301453752750 ∧ code e301453752750 = 1400965380526 := by decide
theorem cert_e301453752750 : check e301453752750 [[],[]] .chain = true := by decide
def e301453752762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e301453752762 : Closed e301453752762 ∧ code e301453752762 = 1400965380538 := by decide
theorem cert_e301453752762 : check e301453752762 [[],[]] .chain = true := by decide
def e301453752810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e301453752810 : Closed e301453752810 ∧ code e301453752810 = 1400965380586 := by decide
theorem cert_e301453752810 : check e301453752810 [[],[]] .chain = true := by decide
def e301453752942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e301453752942 : Closed e301453752942 ∧ code e301453752942 = 1400965380718 := by decide
theorem cert_e301453752942 : check e301453752942 [[],[]] .chain = true := by decide
def e301453752954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e301453752954 : Closed e301453752954 ∧ code e301453752954 = 1400965380730 := by decide
theorem cert_e301453752954 : check e301453752954 [[],[]] .chain = true := by decide
def e301453753118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e301453753118 : Closed e301453753118 ∧ code e301453753118 = 1400965380894 := by decide
theorem cert_e301453753118 : check e301453753118 [[],[]] .chain = true := by decide
def e301453753230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e301453753230 : Closed e301453753230 ∧ code e301453753230 = 1400965381006 := by decide
theorem cert_e301453753230 : check e301453753230 [[],[]] .chain = true := by decide
def e301453753242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e301453753242 : Closed e301453753242 ∧ code e301453753242 = 1400965381018 := by decide
theorem cert_e301453753242 : check e301453753242 [[],[]] .chain = true := by decide
def e301453753462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e301453753462 : Closed e301453753462 ∧ code e301453753462 = 1400965381238 := by decide
theorem cert_e301453753462 : check e301453753462 [[],[]] .chain = true := by decide
def e301453753558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e301453753558 : Closed e301453753558 ∧ code e301453753558 = 1400965381334 := by decide
theorem cert_e301453753558 : check e301453753558 [[],[]] .chain = true := by decide
def e301453753562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e301453753562 : Closed e301453753562 ∧ code e301453753562 = 1400965381338 := by decide
theorem cert_e301453753562 : check e301453753562 [[],[]] .chain = true := by decide
def e301453753578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e301453753578 : Closed e301453753578 ∧ code e301453753578 = 1400965381354 := by decide
theorem cert_e301453753578 : check e301453753578 [[],[]] .chain = true := by decide
def e301453753654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e301453753654 : Closed e301453753654 ∧ code e301453753654 = 1400965381430 := by decide
theorem cert_e301453753654 : check e301453753654 [[],[]] .chain = true := by decide
def e301453753658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e301453753658 : Closed e301453753658 ∧ code e301453753658 = 1400965381434 := by decide
theorem cert_e301453753658 : check e301453753658 [[],[]] .chain = true := by decide
def e301453753742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e301453753742 : Closed e301453753742 ∧ code e301453753742 = 1400965381518 := by decide
theorem cert_e301453753742 : check e301453753742 [[],[]] .chain = true := by decide
def e301453753754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e301453753754 : Closed e301453753754 ∧ code e301453753754 = 1400965381530 := by decide
theorem cert_e301453753754 : check e301453753754 [[],[]] .chain = true := by decide
def e301453755358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e301453755358 : Closed e301453755358 ∧ code e301453755358 = 1400965383134 := by decide
theorem cert_e301453755358 : check e301453755358 [[],[]] .chain = true := by decide
def e301453755374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e301453755374 : Closed e301453755374 ∧ code e301453755374 = 1400965383150 := by decide
theorem cert_e301453755374 : check e301453755374 [[],[]] .chain = true := by decide
def e301453757294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301453757294 : Closed e301453757294 ∧ code e301453757294 = 1400965385070 := by decide
theorem cert_e301453757294 : check e301453757294 [[],[]] .chain = true := by decide
def e301453757302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301453757302 : Closed e301453757302 ∧ code e301453757302 = 1400965385078 := by decide
theorem cert_e301453757302 : check e301453757302 [[],[]] .chain = true := by decide
def e301453757358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301453757358 : Closed e301453757358 ∧ code e301453757358 = 1400965385134 := by decide
theorem cert_e301453757358 : check e301453757358 [[],[]] .chain = true := by decide
def e301453757370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301453757370 : Closed e301453757370 ∧ code e301453757370 = 1400965385146 := by decide
theorem cert_e301453757370 : check e301453757370 [[],[]] .chain = true := by decide
def e301453757398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301453757398 : Closed e301453757398 ∧ code e301453757398 = 1400965385174 := by decide
theorem cert_e301453757398 : check e301453757398 [[],[]] .chain = true := by decide
def e301453757402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301453757402 : Closed e301453757402 ∧ code e301453757402 = 1400965385178 := by decide
theorem cert_e301453757402 : check e301453757402 [[],[]] .chain = true := by decide
def e301453757678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301453757678 : Closed e301453757678 ∧ code e301453757678 = 1400965385454 := by decide
theorem cert_e301453757678 : check e301453757678 [[],[]] .chain = true := by decide
def e301453757686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301453757686 : Closed e301453757686 ∧ code e301453757686 = 1400965385462 := by decide
theorem cert_e301453757686 : check e301453757686 [[],[]] .chain = true := by decide
def e301453758062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301453758062 : Closed e301453758062 ∧ code e301453758062 = 1400965385838 := by decide
theorem cert_e301453758062 : check e301453758062 [[],[]] .chain = true := by decide
def e301453758074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301453758074 : Closed e301453758074 ∧ code e301453758074 = 1400965385850 := by decide
theorem cert_e301453758074 : check e301453758074 [[],[]] .chain = true := by decide
def e301453758262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301453758262 : Closed e301453758262 ∧ code e301453758262 = 1400965386038 := by decide
theorem cert_e301453758262 : check e301453758262 [[],[]] .chain = true := by decide
def e301453758266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301453758266 : Closed e301453758266 ∧ code e301453758266 = 1400965386042 := by decide
theorem cert_e301453758266 : check e301453758266 [[],[]] .chain = true := by decide
def e301453763038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e301453763038 : Closed e301453763038 ∧ code e301453763038 = 1400965390814 := by decide
theorem cert_e301453763038 : check e301453763038 [[],[]] .chain = true := by decide
def e301453763062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e301453763062 : Closed e301453763062 ∧ code e301453763062 = 1400965390838 := by decide
theorem cert_e301453763062 : check e301453763062 [[],[]] .chain = true := by decide
def e301453764014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e301453764014 : Closed e301453764014 ∧ code e301453764014 = 1400965391790 := by decide
theorem cert_e301453764014 : check e301453764014 [[],[]] .chain = true := by decide
def e301453764026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e301453764026 : Closed e301453764026 ∧ code e301453764026 = 1400965391802 := by decide
theorem cert_e301453764026 : check e301453764026 [[],[]] .chain = true := by decide
def e301453764074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e301453764074 : Closed e301453764074 ∧ code e301453764074 = 1400965391850 := by decide
theorem cert_e301453764074 : check e301453764074 [[],[]] .chain = true := by decide
def e301453764206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e301453764206 : Closed e301453764206 ∧ code e301453764206 = 1400965391982 := by decide
theorem cert_e301453764206 : check e301453764206 [[],[]] .chain = true := by decide
def e301453764218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e301453764218 : Closed e301453764218 ∧ code e301453764218 = 1400965391994 := by decide
theorem cert_e301453764218 : check e301453764218 [[],[]] .chain = true := by decide
def e301453764382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e301453764382 : Closed e301453764382 ∧ code e301453764382 = 1400965392158 := by decide
theorem cert_e301453764382 : check e301453764382 [[],[]] .chain = true := by decide
def e301453764494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e301453764494 : Closed e301453764494 ∧ code e301453764494 = 1400965392270 := by decide
theorem cert_e301453764494 : check e301453764494 [[],[]] .chain = true := by decide
def e301453764506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e301453764506 : Closed e301453764506 ∧ code e301453764506 = 1400965392282 := by decide
theorem cert_e301453764506 : check e301453764506 [[],[]] .chain = true := by decide
def e301453766894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e301453766894 : Closed e301453766894 ∧ code e301453766894 = 1400965394670 := by decide
theorem cert_e301453766894 : check e301453766894 [[],[]] .chain = true := by decide
def e301453766902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e301453766902 : Closed e301453766902 ∧ code e301453766902 = 1400965394678 := by decide
theorem cert_e301453766902 : check e301453766902 [[],[]] .chain = true := by decide
def e301453767382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e301453767382 : Closed e301453767382 ∧ code e301453767382 = 1400965395158 := by decide
theorem cert_e301453767382 : check e301453767382 [[],[]] .chain = true := by decide
def e301453767386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e301453767386 : Closed e301453767386 ∧ code e301453767386 = 1400965395162 := by decide
theorem cert_e301453767386 : check e301453767386 [[],[]] .chain = true := by decide
def e301453767402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e301453767402 : Closed e301453767402 ∧ code e301453767402 = 1400965395178 := by decide
theorem cert_e301453767402 : check e301453767402 [[],[]] .chain = true := by decide
def e301453767478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e301453767478 : Closed e301453767478 ∧ code e301453767478 = 1400965395254 := by decide
theorem cert_e301453767478 : check e301453767478 [[],[]] .chain = true := by decide
def e301453767482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e301453767482 : Closed e301453767482 ∧ code e301453767482 = 1400965395258 := by decide
theorem cert_e301453767482 : check e301453767482 [[],[]] .chain = true := by decide
def e301453767566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e301453767566 : Closed e301453767566 ∧ code e301453767566 = 1400965395342 := by decide
theorem cert_e301453767566 : check e301453767566 [[],[]] .chain = true := by decide
def e301453767578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e301453767578 : Closed e301453767578 ∧ code e301453767578 = 1400965395354 := by decide
theorem cert_e301453767578 : check e301453767578 [[],[]] .chain = true := by decide
def e301453772654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e301453772654 : Closed e301453772654 ∧ code e301453772654 = 1400965400430 := by decide
theorem cert_e301453772654 : check e301453772654 [[],[]] .chain = true := by decide
def e301453772666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e301453772666 : Closed e301453772666 ∧ code e301453772666 = 1400965400442 := by decide
theorem cert_e301453772666 : check e301453772666 [[],[]] .chain = true := by decide
def e301453772762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e301453772762 : Closed e301453772762 ∧ code e301453772762 = 1400965400538 := by decide
theorem cert_e301453772762 : check e301453772762 [[],[]] .chain = true := by decide
def e301453774062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e301453774062 : Closed e301453774062 ∧ code e301453774062 = 1400965401838 := by decide
theorem cert_e301453774062 : check e301453774062 [[],[]] .chain = true := by decide
def e301453774070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e301453774070 : Closed e301453774070 ∧ code e301453774070 = 1400965401846 := by decide
theorem cert_e301453774070 : check e301453774070 [[],[]] .chain = true := by decide
def e301453774446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e301453774446 : Closed e301453774446 ∧ code e301453774446 = 1400965402222 := by decide
theorem cert_e301453774446 : check e301453774446 [[],[]] .chain = true := by decide
def e301453774458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e301453774458 : Closed e301453774458 ∧ code e301453774458 = 1400965402234 := by decide
theorem cert_e301453774458 : check e301453774458 [[],[]] .chain = true := by decide
def e301453774646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e301453774646 : Closed e301453774646 ∧ code e301453774646 = 1400965402422 := by decide
theorem cert_e301453774646 : check e301453774646 [[],[]] .chain = true := by decide
def e301453774650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e301453774650 : Closed e301453774650 ∧ code e301453774650 = 1400965402426 := by decide
theorem cert_e301453774650 : check e301453774650 [[],[]] .chain = true := by decide
def e301453776558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e301453776558 : Closed e301453776558 ∧ code e301453776558 = 1400965404334 := by decide
theorem cert_e301453776558 : check e301453776558 [[],[]] .chain = true := by decide
def e301453776570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e301453776570 : Closed e301453776570 ∧ code e301453776570 = 1400965404346 := by decide
theorem cert_e301453776570 : check e301453776570 [[],[]] .chain = true := by decide
def e301453776618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e301453776618 : Closed e301453776618 ∧ code e301453776618 = 1400965404394 := by decide
theorem cert_e301453776618 : check e301453776618 [[],[]] .chain = true := by decide
def e301453776810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e301453776810 : Closed e301453776810 ∧ code e301453776810 = 1400965404586 := by decide
theorem cert_e301453776810 : check e301453776810 [[],[]] .chain = true := by decide
def e301453777134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e301453777134 : Closed e301453777134 ∧ code e301453777134 = 1400965404910 := by decide
theorem cert_e301453777134 : check e301453777134 [[],[]] .chain = true := by decide
def e301453777142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e301453777142 : Closed e301453777142 ∧ code e301453777142 = 1400965404918 := by decide
theorem cert_e301453777142 : check e301453777142 [[],[]] .chain = true := by decide
def e301453777326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e301453777326 : Closed e301453777326 ∧ code e301453777326 = 1400965405102 := by decide
theorem cert_e301453777326 : check e301453777326 [[],[]] .chain = true := by decide
def e301453777338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e301453777338 : Closed e301453777338 ∧ code e301453777338 = 1400965405114 := by decide
theorem cert_e301453777338 : check e301453777338 [[],[]] .chain = true := by decide
def e301453777386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e301453777386 : Closed e301453777386 ∧ code e301453777386 = 1400965405162 := by decide
theorem cert_e301453777386 : check e301453777386 [[],[]] .chain = true := by decide
def e301453777518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e301453777518 : Closed e301453777518 ∧ code e301453777518 = 1400965405294 := by decide
theorem cert_e301453777518 : check e301453777518 [[],[]] .chain = true := by decide
def e301453777530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e301453777530 : Closed e301453777530 ∧ code e301453777530 = 1400965405306 := by decide
theorem cert_e301453777530 : check e301453777530 [[],[]] .chain = true := by decide
def e301453777694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e301453777694 : Closed e301453777694 ∧ code e301453777694 = 1400965405470 := by decide
theorem cert_e301453777694 : check e301453777694 [[],[]] .chain = true := by decide
def e301453777806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e301453777806 : Closed e301453777806 ∧ code e301453777806 = 1400965405582 := by decide
theorem cert_e301453777806 : check e301453777806 [[],[]] .chain = true := by decide
def e301453777818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e301453777818 : Closed e301453777818 ∧ code e301453777818 = 1400965405594 := by decide
theorem cert_e301453777818 : check e301453777818 [[],[]] .chain = true := by decide
def e301453778030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e301453778030 : Closed e301453778030 ∧ code e301453778030 = 1400965405806 := by decide
theorem cert_e301453778030 : check e301453778030 [[],[]] .chain = true := by decide
def e301453778042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e301453778042 : Closed e301453778042 ∧ code e301453778042 = 1400965405818 := by decide
theorem cert_e301453778042 : check e301453778042 [[],[]] .chain = true := by decide
def e301453778206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e301453778206 : Closed e301453778206 ∧ code e301453778206 = 1400965405982 := by decide
theorem cert_e301453778206 : check e301453778206 [[],[]] .chain = true := by decide
def e301453778374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e301453778374 : Closed e301453778374 ∧ code e301453778374 = 1400965406150 := by decide
theorem cert_e301453778374 : check e301453778374 [[],[]] .chain = true := by decide
def e301453778486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e301453778486 : Closed e301453778486 ∧ code e301453778486 = 1400965406262 := by decide
theorem cert_e301453778486 : check e301453778486 [[],[]] .chain = true := by decide
def e301453778490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e301453778490 : Closed e301453778490 ∧ code e301453778490 = 1400965406266 := by decide
theorem cert_e301453778490 : check e301453778490 [[],[]] .chain = true := by decide
def e301453778538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e301453778538 : Closed e301453778538 ∧ code e301453778538 = 1400965406314 := by decide
theorem cert_e301453778538 : check e301453778538 [[],[]] .chain = true := by decide
end Blc.Floor40
