import R302902171894Data
namespace Certgen.R302902171894
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl864 : FloorIndex.rangeOK validState 864 12 = true := by decide +kernel
theorem bl876 : FloorIndex.rangeOK validState 876 12 = true := by decide +kernel
theorem bl888 : FloorIndex.rangeOK validState 888 12 = true := by decide +kernel
theorem bl900 : FloorIndex.rangeOK validState 900 12 = true := by decide +kernel
theorem bl912 : FloorIndex.rangeOK validState 912 12 = true := by decide +kernel
theorem bl924 : FloorIndex.rangeOK validState 924 12 = true := by decide +kernel
end Certgen.R302902171894
