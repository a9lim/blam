import R302902178758V0
import R302902178758K0
import R302902178758st0
import R302902178758hs0
import CodeBridge
import Batch063
namespace Certgen.R302902178758
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 166,.app 2 157,.app 3 148,.app 4 119,.app 5 116,.app 6 40,.app 7 20,.lam 8,.app 9 10,.var 0,.app 11 12,.var 0,.lam 13,.lam 14,.app 15 16,.var 1,.app 17 18,.var 2,.lam 19,.var 1,.lam 21,.lam 22,.app 23 24,.var 1,.app 25 38,.lam 26,.app 27 28,.var 0,.app 29 30,.var 0,.lam 31,.lam 32,.app 33 34,.var 1,.app 35 36,.var 2,.lam 37,.var 1,.lam 39,.var 1,.app 41 75,.app 42 55,.lam 43,.app 44 45,.var 0,.app 46 47,.var 0,.lam 48,.lam 49,.app 50 51,.var 1,.app 52 53,.var 2,.lam 54,.var 1,.lam 56,.lam 57,.app 58 59,.var 1,.app 60 73,.lam 61,.app 62 63,.var 0,.app 64 65,.var 0,.lam 66,.lam 67,.app 68 69,.var 1,.app 70 71,.var 2,.lam 72,.var 1,.lam 74,.var 1,.lam 76,.lam 77,.app 78 79,.var 1,.app 80 114,.app 81 94,.lam 82,.app 83 84,.var 0,.app 85 86,.var 0,.lam 87,.lam 88,.app 89 90,.var 1,.app 91 92,.var 2,.lam 93,.var 1,.lam 95,.lam 96,.app 97 98,.var 1,.app 99 112,.lam 100,.app 101 102,.var 0,.app 103 104,.var 0,.lam 105,.lam 106,.app 107 108,.var 1,.app 109 110,.var 2,.lam 111,.var 1,.lam 113,.var 1,.lam 115,.var 1,.lam 117,.lam 118,.var 0,.lam 120,.app 121 126,.app 122 123,.var 0,.lam 124,.lam 125,.var 1,.lam 127,.app 128 133,.app 129 130,.var 0,.lam 131,.lam 132,.var 1,.lam 134,.app 135 140,.app 136 137,.var 0,.lam 138,.lam 139,.var 0,.lam 141,.app 142 147,.app 143 144,.var 0,.lam 145,.lam 146,.var 1,.opaque,.app 149 153,.lam 150,.app 151 152,.var 0,.var 0,.lam 154,.app 155 156,.var 0,.var 0,.app 158 162,.lam 159,.app 160 161,.var 0,.var 0,.lam 163,.app 164 165,.var 0,.var 0,.app 167 171,.lam 168,.app 169 170,.var 0,.var 0,.lam 172,.app 173 174,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 109 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 80 then (st60[i-60]?.getD entry) else (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 80 then (hs60[i-60]?.getD []) else (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302902178758
