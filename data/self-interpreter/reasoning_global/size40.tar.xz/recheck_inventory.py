"""Independent wire enumeration, equality, wall times and max RSS, on macOS."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time

base = Path(__file__).resolve().parent
rows = []
with tempfile.TemporaryDirectory(dir=base) as temp:
    def run(label, cmd, file):
        start=time.monotonic()
        with file.open('wb') as f:
            p=subprocess.Popen(cmd,cwd=base,stdout=f)
            signal.signal(signal.SIGALRM,lambda *_:p.kill())
            signal.alarm(150)
            _,st,usage=os.wait4(p.pid,0)
            signal.alarm(0)
            p.returncode=os.waitstatus_to_exitcode(st)
            assert p.returncode==0
        rows.append(dict(step=label,seconds=round(time.monotonic()-start,4),rss_bytes=usage.ru_maxrss))
    temp=Path(temp)
    for label,src,dst,flags in [('enum','enum.cpp','wires.txt',['clang++','-std=c++20','-O3']),('cross','cross.rs','cross.txt',['rustc','--edition=2021','-O'])]:
        run('compile '+label,[*flags,src,'-o',str(temp/label)],temp/'compile.log')
        run(label,[str(temp/label)],temp/'output')
        assert (temp/'output').read_bytes()==(base/dst).read_bytes()
    run('explicit contractions',[sys.executable,'independent.py'],temp/'comparison')
    print((temp/'comparison').read_text())
(base/'inventory-metrics.json').write_text(json.dumps(rows,indent=1)+'\n')
print(rows)
