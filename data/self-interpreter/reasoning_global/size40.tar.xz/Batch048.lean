import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801301318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801301318 : Closed e302801301318 ∧ code e302801301318 = 1402312929094 := by decide
theorem cert_e302801301318 : check e302801301318 [[],[]] .chain = true := by decide
def e302801301346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801301346 : Closed e302801301346 ∧ code e302801301346 = 1402312929122 := by decide
theorem cert_e302801301346 : check e302801301346 [[],[]] .chain = true := by decide
def e302801301358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e302801301358 : Closed e302801301358 ∧ code e302801301358 = 1402312929134 := by decide
theorem cert_e302801301358 : checkPay e302801301358 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801301366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e302801301366 : Closed e302801301366 ∧ code e302801301366 = 1402312929142 := by decide
theorem cert_e302801301366 : checkPay e302801301366 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801301726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302801301726 : Closed e302801301726 ∧ code e302801301726 = 1402312929502 := by decide
theorem cert_e302801301726 : check e302801301726 [[],[]] .chain = true := by decide
def e302801301754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302801301754 : Closed e302801301754 ∧ code e302801301754 = 1402312929530 := by decide
theorem cert_e302801301754 : check e302801301754 [[],[]] .chain = true := by decide
def e302801302302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302801302302 : Closed e302801302302 ∧ code e302801302302 = 1402312930078 := by decide
theorem cert_e302801302302 : check e302801302302 [[],[]] .chain = true := by decide
def e302801302470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302801302470 : Closed e302801302470 ∧ code e302801302470 = 1402312930246 := by decide
theorem cert_e302801302470 : check e302801302470 [[],[]] .chain = true := by decide
def e302801303614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e302801303614 : Closed e302801303614 ∧ code e302801303614 = 1402312931390 := by decide
theorem cert_e302801303614 : check e302801303614 [[],[]] .chain = true := by decide
def e302801304034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302801304034 : Closed e302801304034 ∧ code e302801304034 = 1402312931810 := by decide
theorem cert_e302801304034 : check e302801304034 [[],[]] .chain = true := by decide
def e302801304046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e302801304046 : Closed e302801304046 ∧ code e302801304046 = 1402312931822 := by decide
theorem cert_e302801304046 : checkPay e302801304046 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801304606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e302801304606 : Closed e302801304606 ∧ code e302801304606 = 1402312932382 := by decide
theorem cert_e302801304606 : check e302801304606 [[],[]] .chain = true := by decide
def e302801304630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801304630 : Closed e302801304630 ∧ code e302801304630 = 1402312932406 := by decide
theorem cert_e302801304630 : check e302801304630 [[],[]] .chain = true := by decide
def e302801304634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801304634 : Closed e302801304634 ∧ code e302801304634 = 1402312932410 := by decide
theorem cert_e302801304634 : check e302801304634 [[],[]] .chain = true := by decide
def e302801304774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801304774 : Closed e302801304774 ∧ code e302801304774 = 1402312932550 := by decide
theorem cert_e302801304774 : check e302801304774 [[],[]] .chain = true := by decide
def e302801304802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801304802 : Closed e302801304802 ∧ code e302801304802 = 1402312932578 := by decide
theorem cert_e302801304802 : check e302801304802 [[],[]] .chain = true := by decide
def e302801304814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e302801304814 : Closed e302801304814 ∧ code e302801304814 = 1402312932590 := by decide
theorem cert_e302801304814 : checkPay e302801304814 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801304822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e302801304822 : Closed e302801304822 ∧ code e302801304822 = 1402312932598 := by decide
theorem cert_e302801304822 : checkPay e302801304822 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801327662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302801327662 : Closed e302801327662 ∧ code e302801327662 = 1402312955438 := by decide
theorem cert_e302801327662 : check e302801327662 [[],[]] .chain = true := by decide
def e302801327842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302801327842 : Closed e302801327842 ∧ code e302801327842 = 1402312955618 := by decide
theorem cert_e302801327842 : check e302801327842 [[],[]] .chain = true := by decide
def e302801327854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e302801327854 : Closed e302801327854 ∧ code e302801327854 = 1402312955630 := by decide
theorem cert_e302801327854 : checkPay e302801327854 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801328010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302801328010 : Closed e302801328010 ∧ code e302801328010 = 1402312955786 := by decide
theorem cert_e302801328010 : check e302801328010 [[],[]] .chain = true := by decide
def e302801328034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302801328034 : Closed e302801328034 ∧ code e302801328034 = 1402312955810 := by decide
theorem cert_e302801328034 : check e302801328034 [[],[]] .chain = true := by decide
def e302801328046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e302801328046 : Closed e302801328046 ∧ code e302801328046 = 1402312955822 := by decide
theorem cert_e302801328046 : checkPay e302801328046 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801328058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e302801328058 : Closed e302801328058 ∧ code e302801328058 = 1402312955834 := by decide
theorem cert_e302801328058 : checkPay e302801328058 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801328190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e302801328190 : Closed e302801328190 ∧ code e302801328190 = 1402312955966 := by decide
theorem cert_e302801328190 : check e302801328190 [[],[]] .chain = true := by decide
def e302801328610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302801328610 : Closed e302801328610 ∧ code e302801328610 = 1402312956386 := by decide
theorem cert_e302801328610 : check e302801328610 [[],[]] .chain = true := by decide
def e302801328622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e302801328622 : Closed e302801328622 ∧ code e302801328622 = 1402312956398 := by decide
theorem cert_e302801328622 : checkPay e302801328622 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801329678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e302801329678 : Closed e302801329678 ∧ code e302801329678 = 1402312957454 := by decide
theorem cert_e302801329678 : check e302801329678 [[],[]] .chain = true := by decide
def e302801329762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302801329762 : Closed e302801329762 ∧ code e302801329762 = 1402312957538 := by decide
theorem cert_e302801329762 : check e302801329762 [[],[]] .chain = true := by decide
def e302801329774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e302801329774 : Closed e302801329774 ∧ code e302801329774 = 1402312957550 := by decide
theorem cert_e302801329774 : checkPay e302801329774 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801329786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e302801329786 : Closed e302801329786 ∧ code e302801329786 = 1402312957562 := by decide
theorem cert_e302801329786 : checkPay e302801329786 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801339094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302801339094 : Closed e302801339094 ∧ code e302801339094 = 1402312966870 := by decide
theorem cert_e302801339094 : checkPay e302801339094 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801339098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302801339098 : Closed e302801339098 ∧ code e302801339098 = 1402312966874 := by decide
theorem cert_e302801339098 : checkPay e302801339098 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801339114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302801339114 : Closed e302801339114 ∧ code e302801339114 = 1402312966890 := by decide
theorem cert_e302801339114 : checkPay e302801339114 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801339190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801339190 : Closed e302801339190 ∧ code e302801339190 = 1402312966966 := by decide
theorem cert_e302801339190 : checkPay e302801339190 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801339194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801339194 : Closed e302801339194 ∧ code e302801339194 = 1402312966970 := by decide
theorem cert_e302801339194 : checkPay e302801339194 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801339278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e302801339278 : Closed e302801339278 ∧ code e302801339278 = 1402312967054 := by decide
theorem cert_e302801339278 : check e302801339278 [[],[]] .chain = true := by decide
def e302801339290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801339290 : Closed e302801339290 ∧ code e302801339290 = 1402312967066 := by decide
theorem cert_e302801339290 : checkPay e302801339290 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801341206 : Closed e302801341206 ∧ code e302801341206 = 1402312968982 := by decide
theorem cert_e302801341206 : check e302801341206 [[],[]] .chain = true := by decide
def e302801341210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801341210 : Closed e302801341210 ∧ code e302801341210 = 1402312968986 := by decide
theorem cert_e302801341210 : check e302801341210 [[],[]] .chain = true := by decide
def e302801341254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801341254 : Closed e302801341254 ∧ code e302801341254 = 1402312969030 := by decide
theorem cert_e302801341254 : check e302801341254 [[],[]] .chain = true := by decide
def e302801341282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801341282 : Closed e302801341282 ∧ code e302801341282 = 1402312969058 := by decide
theorem cert_e302801341282 : check e302801341282 [[],[]] .chain = true := by decide
def e302801341294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302801341294 : Closed e302801341294 ∧ code e302801341294 = 1402312969070 := by decide
theorem cert_e302801341294 : checkPay e302801341294 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302801341302 : Closed e302801341302 ∧ code e302801341302 = 1402312969078 := by decide
theorem cert_e302801341302 : checkPay e302801341302 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302801341322 : Closed e302801341322 ∧ code e302801341322 = 1402312969098 := by decide
theorem cert_e302801341322 : check e302801341322 [[],[]] .chain = true := by decide
def e302801341346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302801341346 : Closed e302801341346 ∧ code e302801341346 = 1402312969122 := by decide
theorem cert_e302801341346 : check e302801341346 [[],[]] .chain = true := by decide
def e302801341358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302801341358 : Closed e302801341358 ∧ code e302801341358 = 1402312969134 := by decide
theorem cert_e302801341358 : checkPay e302801341358 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302801341370 : Closed e302801341370 ∧ code e302801341370 = 1402312969146 := by decide
theorem cert_e302801341370 : checkPay e302801341370 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302801341398 : Closed e302801341398 ∧ code e302801341398 = 1402312969174 := by decide
theorem cert_e302801341398 : checkPay e302801341398 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302801341402 : Closed e302801341402 ∧ code e302801341402 = 1402312969178 := by decide
theorem cert_e302801341402 : checkPay e302801341402 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e302801341470 : Closed e302801341470 ∧ code e302801341470 = 1402312969246 := by decide
theorem cert_e302801341470 : check e302801341470 [[],[]] .chain = true := by decide
def e302801341494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801341494 : Closed e302801341494 ∧ code e302801341494 = 1402312969270 := by decide
theorem cert_e302801341494 : check e302801341494 [[],[]] .chain = true := by decide
def e302801341498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801341498 : Closed e302801341498 ∧ code e302801341498 = 1402312969274 := by decide
theorem cert_e302801341498 : check e302801341498 [[],[]] .chain = true := by decide
def e302801341638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801341638 : Closed e302801341638 ∧ code e302801341638 = 1402312969414 := by decide
theorem cert_e302801341638 : check e302801341638 [[],[]] .chain = true := by decide
def e302801341666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801341666 : Closed e302801341666 ∧ code e302801341666 = 1402312969442 := by decide
theorem cert_e302801341666 : check e302801341666 [[],[]] .chain = true := by decide
def e302801341678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302801341678 : Closed e302801341678 ∧ code e302801341678 = 1402312969454 := by decide
theorem cert_e302801341678 : checkPay e302801341678 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302801341686 : Closed e302801341686 ∧ code e302801341686 = 1402312969462 := by decide
theorem cert_e302801341686 : checkPay e302801341686 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801341966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e302801341966 : Closed e302801341966 ∧ code e302801341966 = 1402312969742 := by decide
theorem cert_e302801341966 : check e302801341966 [[],[]] .chain = true := by decide
def e302801342050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302801342050 : Closed e302801342050 ∧ code e302801342050 = 1402312969826 := by decide
theorem cert_e302801342050 : check e302801342050 [[],[]] .chain = true := by decide
def e302801342062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302801342062 : Closed e302801342062 ∧ code e302801342062 = 1402312969838 := by decide
theorem cert_e302801342062 : checkPay e302801342062 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801342074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302801342074 : Closed e302801342074 ∧ code e302801342074 = 1402312969850 := by decide
theorem cert_e302801342074 : checkPay e302801342074 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801342262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302801342262 : Closed e302801342262 ∧ code e302801342262 = 1402312970038 := by decide
theorem cert_e302801342262 : checkPay e302801342262 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801342266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302801342266 : Closed e302801342266 ∧ code e302801342266 = 1402312970042 := by decide
theorem cert_e302801342266 : checkPay e302801342266 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801358454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e302801358454 : Closed e302801358454 ∧ code e302801358454 = 1402312986230 := by decide
theorem cert_e302801358454 : check e302801358454 [[],[]] .chain = true := by decide
def e302801358646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801358646 : Closed e302801358646 ∧ code e302801358646 = 1402312986422 := by decide
theorem cert_e302801358646 : check e302801358646 [[],[]] .chain = true := by decide
def e302801358650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801358650 : Closed e302801358650 ∧ code e302801358650 = 1402312986426 := by decide
theorem cert_e302801358650 : check e302801358650 [[],[]] .chain = true := by decide
def e302801360566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e302801360566 : Closed e302801360566 ∧ code e302801360566 = 1402312988342 := by decide
private def t_e302801360566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))))))
theorem cert_e302801360566 : ¬ IsSelfInterpreter e302801360566 :=
  wSource (t := t_e302801360566) (replay_sound (ps := []) (t := e302801360566) (by decide)) (by decide)
def e302801360570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e302801360570 : Closed e302801360570 ∧ code e302801360570 = 1402312988346 := by decide
private def t_e302801360570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))))))
theorem cert_e302801360570 : ¬ IsSelfInterpreter e302801360570 :=
  wSource (t := t_e302801360570) (replay_sound (ps := []) (t := e302801360570) (by decide)) (by decide)
def e302801360598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e302801360598 : Closed e302801360598 ∧ code e302801360598 = 1402312988374 := by decide
theorem cert_e302801360598 : check e302801360598 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801360618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e302801360618 : Closed e302801360618 ∧ code e302801360618 = 1402312988394 := by decide
theorem cert_e302801360618 : check e302801360618 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801360726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e302801360726 : Closed e302801360726 ∧ code e302801360726 = 1402312988502 := by decide
theorem cert_e302801360726 : check e302801360726 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801360810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e302801360810 : Closed e302801360810 ∧ code e302801360810 = 1402312988586 := by decide
theorem cert_e302801360810 : check e302801360810 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801361334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e302801361334 : Closed e302801361334 ∧ code e302801361334 = 1402312989110 := by decide
theorem cert_e302801361334 : check e302801361334 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801361338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e302801361338 : Closed e302801361338 ∧ code e302801361338 = 1402312989114 := by decide
theorem cert_e302801361338 : check e302801361338 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801361366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e302801361366 : Closed e302801361366 ∧ code e302801361366 = 1402312989142 := by decide
theorem cert_e302801361366 : check e302801361366 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801361386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e302801361386 : Closed e302801361386 ∧ code e302801361386 = 1402312989162 := by decide
theorem cert_e302801361386 : check e302801361386 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801361718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801361718 : Closed e302801361718 ∧ code e302801361718 = 1402312989494 := by decide
theorem cert_e302801361718 : check e302801361718 [[],[]] .chain = true := by decide
def e302801361722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801361722 : Closed e302801361722 ∧ code e302801361722 = 1402312989498 := by decide
theorem cert_e302801361722 : check e302801361722 [[],[]] .chain = true := by decide
def e302801361818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801361818 : Closed e302801361818 ∧ code e302801361818 = 1402312989594 := by decide
theorem cert_e302801361818 : check e302801361818 [[],[]] .chain = true := by decide
def e302801362038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 1))))))
theorem wire_e302801362038 : Closed e302801362038 ∧ code e302801362038 = 1402312989814 := by decide
theorem cert_e302801362038 : check e302801362038 [[],[]] .chain = true := by decide
def e302801362042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e302801362042 : Closed e302801362042 ∧ code e302801362042 = 1402312989818 := by decide
theorem cert_e302801362042 : check e302801362042 [[],[]] .chain = true := by decide
def e302801362134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e302801362134 : Closed e302801362134 ∧ code e302801362134 = 1402312989910 := by decide
theorem cert_e302801362134 : check e302801362134 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801362230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801362230 : Closed e302801362230 ∧ code e302801362230 = 1402312990006 := by decide
theorem cert_e302801362230 : check e302801362230 [[],[]] .chain = true := by decide
def e302801362234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801362234 : Closed e302801362234 ∧ code e302801362234 = 1402312990010 := by decide
theorem cert_e302801362234 : check e302801362234 [[],[]] .chain = true := by decide
def e302801362318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e302801362318 : Closed e302801362318 ∧ code e302801362318 = 1402312990094 := by decide
theorem cert_e302801362318 : check e302801362318 [[],[]] .chain = true := by decide
def e302801362374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e302801362374 : Closed e302801362374 ∧ code e302801362374 = 1402312990150 := by decide
theorem cert_e302801362374 : check e302801362374 [[],[]] .chain = true := by decide
def e302801362490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e302801362490 : Closed e302801362490 ∧ code e302801362490 = 1402312990266 := by decide
theorem cert_e302801362490 : check e302801362490 [[],[]] .chain = true := by decide
def e302801362538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e302801362538 : Closed e302801362538 ∧ code e302801362538 = 1402312990314 := by decide
theorem cert_e302801362538 : check e302801362538 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801362586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801362586 : Closed e302801362586 ∧ code e302801362586 = 1402312990362 := by decide
theorem cert_e302801362586 : check e302801362586 [[],[]] .chain = true := by decide
def e302801362630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e302801362630 : Closed e302801362630 ∧ code e302801362630 = 1402312990406 := by decide
theorem cert_e302801362630 : check e302801362630 [[],[]] .chain = true := by decide
def e302801364406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e302801364406 : Closed e302801364406 ∧ code e302801364406 = 1402312992182 := by decide
theorem cert_e302801364406 : check e302801364406 [[],[]] .chain = true := by decide
def e302801364438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e302801364438 : Closed e302801364438 ∧ code e302801364438 = 1402312992214 := by decide
theorem cert_e302801364438 : check e302801364438 [[],[]] .chain = true := by decide
def e302801364442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e302801364442 : Closed e302801364442 ∧ code e302801364442 = 1402312992218 := by decide
theorem cert_e302801364442 : check e302801364442 [[],[]] .chain = true := by decide
def e302801364598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e302801364598 : Closed e302801364598 ∧ code e302801364598 = 1402312992374 := by decide
theorem cert_e302801364598 : check e302801364598 [[],[]] .chain = true := by decide
def e302801364790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e302801364790 : Closed e302801364790 ∧ code e302801364790 = 1402312992566 := by decide
theorem cert_e302801364790 : check e302801364790 [[],[]] .chain = true := by decide
def e302801364794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e302801364794 : Closed e302801364794 ∧ code e302801364794 = 1402312992570 := by decide
theorem cert_e302801364794 : check e302801364794 [[],[]] .chain = true := by decide
def e302801367278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e302801367278 : Closed e302801367278 ∧ code e302801367278 = 1402312995054 := by decide
theorem cert_e302801367278 : check e302801367278 [[],[]] .chain = true := by decide
def e302801367286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e302801367286 : Closed e302801367286 ∧ code e302801367286 = 1402312995062 := by decide
theorem cert_e302801367286 : check e302801367286 [[],[]] .chain = true := by decide
def e302801367766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e302801367766 : Closed e302801367766 ∧ code e302801367766 = 1402312995542 := by decide
theorem cert_e302801367766 : check e302801367766 [[],[]] .chain = true := by decide
def e302801367770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e302801367770 : Closed e302801367770 ∧ code e302801367770 = 1402312995546 := by decide
theorem cert_e302801367770 : check e302801367770 [[],[]] .chain = true := by decide
def e302801367786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e302801367786 : Closed e302801367786 ∧ code e302801367786 = 1402312995562 := by decide
theorem cert_e302801367786 : check e302801367786 [[],[]] .chain = true := by decide
def e302801367862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e302801367862 : Closed e302801367862 ∧ code e302801367862 = 1402312995638 := by decide
theorem cert_e302801367862 : check e302801367862 [[],[]] .chain = true := by decide
def e302801367866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e302801367866 : Closed e302801367866 ∧ code e302801367866 = 1402312995642 := by decide
theorem cert_e302801367866 : check e302801367866 [[],[]] .chain = true := by decide
def e302801367950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e302801367950 : Closed e302801367950 ∧ code e302801367950 = 1402312995726 := by decide
theorem cert_e302801367950 : check e302801367950 [[],[]] .chain = true := by decide
def e302801367962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e302801367962 : Closed e302801367962 ∧ code e302801367962 = 1402312995738 := by decide
theorem cert_e302801367962 : check e302801367962 [[],[]] .chain = true := by decide
def e302801369206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e302801369206 : Closed e302801369206 ∧ code e302801369206 = 1402312996982 := by decide
theorem cert_e302801369206 : check e302801369206 [[],[]] .chain = true := by decide
def e302801369450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e302801369450 : Closed e302801369450 ∧ code e302801369450 = 1402312997226 := by decide
theorem cert_e302801369450 : check e302801369450 [[],[]] .chain = true := by decide
def e302801369486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302801369486 : Closed e302801369486 ∧ code e302801369486 = 1402312997262 := by decide
theorem cert_e302801369486 : check e302801369486 [[],[]] .chain = true := by decide
def e302801369498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e302801369498 : Closed e302801369498 ∧ code e302801369498 = 1402312997274 := by decide
theorem cert_e302801369498 : check e302801369498 [[],[]] .chain = true := by decide
def e302801369542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302801369542 : Closed e302801369542 ∧ code e302801369542 = 1402312997318 := by decide
theorem cert_e302801369542 : check e302801369542 [[],[]] .chain = true := by decide
def e302801377462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e302801377462 : Closed e302801377462 ∧ code e302801377462 = 1402313005238 := by decide
theorem cert_e302801377462 : check e302801377462 [[],[]] .chain = true := by decide
def e302801377494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e302801377494 : Closed e302801377494 ∧ code e302801377494 = 1402313005270 := by decide
theorem cert_e302801377494 : check e302801377494 [[],[]] .chain = true := by decide
def e302801377498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e302801377498 : Closed e302801377498 ∧ code e302801377498 = 1402313005274 := by decide
theorem cert_e302801377498 : check e302801377498 [[],[]] .chain = true := by decide
def e302801377514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e302801377514 : Closed e302801377514 ∧ code e302801377514 = 1402313005290 := by decide
theorem cert_e302801377514 : check e302801377514 [[],[]] .chain = true := by decide
def e302801377846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302801377846 : Closed e302801377846 ∧ code e302801377846 = 1402313005622 := by decide
theorem cert_e302801377846 : check e302801377846 [[],[]] .chain = true := by decide
def e302801377850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302801377850 : Closed e302801377850 ∧ code e302801377850 = 1402313005626 := by decide
theorem cert_e302801377850 : check e302801377850 [[],[]] .chain = true := by decide
def e302801377934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302801377934 : Closed e302801377934 ∧ code e302801377934 = 1402313005710 := by decide
theorem cert_e302801377934 : check e302801377934 [[],[]] .chain = true := by decide
def e302801377990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302801377990 : Closed e302801377990 ∧ code e302801377990 = 1402313005766 := by decide
theorem cert_e302801377990 : check e302801377990 [[],[]] .chain = true := by decide
def e302801378070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302801378070 : Closed e302801378070 ∧ code e302801378070 = 1402313005846 := by decide
theorem cert_e302801378070 : check e302801378070 [[],[]] .chain = true := by decide
def e302801378074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302801378074 : Closed e302801378074 ∧ code e302801378074 = 1402313005850 := by decide
theorem cert_e302801378074 : check e302801378074 [[],[]] .chain = true := by decide
def e302801378118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302801378118 : Closed e302801378118 ∧ code e302801378118 = 1402313005894 := by decide
theorem cert_e302801378118 : check e302801378118 [[],[]] .chain = true := by decide
def e302801378146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302801378146 : Closed e302801378146 ∧ code e302801378146 = 1402313005922 := by decide
theorem cert_e302801378146 : check e302801378146 [[],[]] .chain = true := by decide
def e302801378158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e302801378158 : Closed e302801378158 ∧ code e302801378158 = 1402313005934 := by decide
theorem cert_e302801378158 : check e302801378158 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e302801378166 : Closed e302801378166 ∧ code e302801378166 = 1402313005942 := by decide
theorem cert_e302801378166 : check e302801378166 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e302801378230 : Closed e302801378230 ∧ code e302801378230 = 1402313006006 := by decide
theorem cert_e302801378230 : check e302801378230 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e302801378390 : Closed e302801378390 ∧ code e302801378390 = 1402313006166 := by decide
theorem cert_e302801378390 : check e302801378390 [[],[]] .chain = true := by decide
def e302801378394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e302801378394 : Closed e302801378394 ∧ code e302801378394 = 1402313006170 := by decide
theorem cert_e302801378394 : check e302801378394 [[],[]] .chain = true := by decide
def e302801378410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e302801378410 : Closed e302801378410 ∧ code e302801378410 = 1402313006186 := by decide
theorem cert_e302801378410 : check e302801378410 [[],[]] .chain = true := by decide
def e302801378582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302801378582 : Closed e302801378582 ∧ code e302801378582 = 1402313006358 := by decide
theorem cert_e302801378582 : check e302801378582 [[],[]] .chain = true := by decide
def e302801378586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302801378586 : Closed e302801378586 ∧ code e302801378586 = 1402313006362 := by decide
theorem cert_e302801378586 : check e302801378586 [[],[]] .chain = true := by decide
def e302801378630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302801378630 : Closed e302801378630 ∧ code e302801378630 = 1402313006406 := by decide
theorem cert_e302801378630 : check e302801378630 [[],[]] .chain = true := by decide
def e302801378658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302801378658 : Closed e302801378658 ∧ code e302801378658 = 1402313006434 := by decide
theorem cert_e302801378658 : check e302801378658 [[],[]] .chain = true := by decide
def e302801378670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e302801378670 : Closed e302801378670 ∧ code e302801378670 = 1402313006446 := by decide
theorem cert_e302801378670 : check e302801378670 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e302801378678 : Closed e302801378678 ∧ code e302801378678 = 1402313006454 := by decide
theorem cert_e302801378678 : check e302801378678 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e302801378698 : Closed e302801378698 ∧ code e302801378698 = 1402313006474 := by decide
theorem cert_e302801378698 : check e302801378698 [[],[]] .chain = true := by decide
def e302801378722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e302801378722 : Closed e302801378722 ∧ code e302801378722 = 1402313006498 := by decide
theorem cert_e302801378722 : check e302801378722 [[],[]] .chain = true := by decide
def e302801378734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e302801378734 : Closed e302801378734 ∧ code e302801378734 = 1402313006510 := by decide
theorem cert_e302801378734 : check e302801378734 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e302801378746 : Closed e302801378746 ∧ code e302801378746 = 1402313006522 := by decide
theorem cert_e302801378746 : check e302801378746 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e302801378774 : Closed e302801378774 ∧ code e302801378774 = 1402313006550 := by decide
theorem cert_e302801378774 : check e302801378774 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e302801378778 : Closed e302801378778 ∧ code e302801378778 = 1402313006554 := by decide
theorem cert_e302801378778 : check e302801378778 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801378998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e302801378998 : Closed e302801378998 ∧ code e302801378998 = 1402313006774 := by decide
theorem cert_e302801378998 : check e302801378998 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801379030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e302801379030 : Closed e302801379030 ∧ code e302801379030 = 1402313006806 := by decide
theorem cert_e302801379030 : check e302801379030 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801379034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e302801379034 : Closed e302801379034 ∧ code e302801379034 = 1402313006810 := by decide
theorem cert_e302801379034 : check e302801379034 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801379574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e302801379574 : Closed e302801379574 ∧ code e302801379574 = 1402313007350 := by decide
theorem cert_e302801379574 : check e302801379574 [[],[]] .chain = true := by decide
def e302801379766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e302801379766 : Closed e302801379766 ∧ code e302801379766 = 1402313007542 := by decide
theorem cert_e302801379766 : check e302801379766 [[],[]] .chain = true := by decide
def e302801379770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e302801379770 : Closed e302801379770 ∧ code e302801379770 = 1402313007546 := by decide
theorem cert_e302801379770 : check e302801379770 [[],[]] .chain = true := by decide
def e302801379798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e302801379798 : Closed e302801379798 ∧ code e302801379798 = 1402313007574 := by decide
theorem cert_e302801379798 : check e302801379798 [[],[]] .chain = true := by decide
def e302801379818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e302801379818 : Closed e302801379818 ∧ code e302801379818 = 1402313007594 := by decide
theorem cert_e302801379818 : check e302801379818 [[],[]] .chain = true := by decide
def e302801379958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e302801379958 : Closed e302801379958 ∧ code e302801379958 = 1402313007734 := by decide
theorem cert_e302801379958 : check e302801379958 [[],[]] .chain = true := by decide
def e302801380150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801380150 : Closed e302801380150 ∧ code e302801380150 = 1402313007926 := by decide
theorem cert_e302801380150 : check e302801380150 [[],[]] .chain = true := by decide
def e302801380154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801380154 : Closed e302801380154 ∧ code e302801380154 = 1402313007930 := by decide
theorem cert_e302801380154 : check e302801380154 [[],[]] .chain = true := by decide
def e302801380238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e302801380238 : Closed e302801380238 ∧ code e302801380238 = 1402313008014 := by decide
theorem cert_e302801380238 : check e302801380238 [[],[]] .chain = true := by decide
def e302801380250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801380250 : Closed e302801380250 ∧ code e302801380250 = 1402313008026 := by decide
theorem cert_e302801380250 : check e302801380250 [[],[]] .chain = true := by decide
def e302801380918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e302801380918 : Closed e302801380918 ∧ code e302801380918 = 1402313008694 := by decide
theorem cert_e302801380918 : check e302801380918 [[],[]] .chain = true := by decide
def e302801380922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e302801380922 : Closed e302801380922 ∧ code e302801380922 = 1402313008698 := by decide
theorem cert_e302801380922 : check e302801380922 [[],[]] .chain = true := by decide
def e302801381006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e302801381006 : Closed e302801381006 ∧ code e302801381006 = 1402313008782 := by decide
theorem cert_e302801381006 : check e302801381006 [[],[]] .chain = true := by decide
def e302801381062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e302801381062 : Closed e302801381062 ∧ code e302801381062 = 1402313008838 := by decide
theorem cert_e302801381062 : check e302801381062 [[],[]] .chain = true := by decide
def e302801381142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e302801381142 : Closed e302801381142 ∧ code e302801381142 = 1402313008918 := by decide
theorem cert_e302801381142 : check e302801381142 [[],[]] .chain = true := by decide
def e302801381146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e302801381146 : Closed e302801381146 ∧ code e302801381146 = 1402313008922 := by decide
theorem cert_e302801381146 : check e302801381146 [[],[]] .chain = true := by decide
end Blc.Floor40
