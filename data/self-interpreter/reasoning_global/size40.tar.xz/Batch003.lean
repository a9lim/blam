import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e75648666478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75648666478 : Closed e75648666478 ∧ code e75648666478 = 1175160294254 := by decide
theorem cert_e75648666478 : check e75648666478 [[.under],[.under]] .chain = true := by decide
def e75648666486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75648666486 : Closed e75648666486 ∧ code e75648666486 = 1175160294262 := by decide
theorem cert_e75648666486 : check e75648666486 [[.under],[.under]] .chain = true := by decide
def e75648666542 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75648666542 : Closed e75648666542 ∧ code e75648666542 = 1175160294318 := by decide
theorem cert_e75648666542 : check e75648666542 [[.under],[.under]] .chain = true := by decide
def e75648666554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75648666554 : Closed e75648666554 ∧ code e75648666554 = 1175160294330 := by decide
theorem cert_e75648666554 : check e75648666554 [[.under],[.under]] .chain = true := by decide
def e75648666582 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75648666582 : Closed e75648666582 ∧ code e75648666582 = 1175160294358 := by decide
theorem cert_e75648666582 : check e75648666582 [[.under],[.under]] .chain = true := by decide
def e75648666586 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75648666586 : Closed e75648666586 ∧ code e75648666586 = 1175160294362 := by decide
theorem cert_e75648666586 : check e75648666586 [[.under],[.under]] .chain = true := by decide
def e75648666862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75648666862 : Closed e75648666862 ∧ code e75648666862 = 1175160294638 := by decide
theorem cert_e75648666862 : check e75648666862 [[.under],[.under]] .chain = true := by decide
def e75648666870 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75648666870 : Closed e75648666870 ∧ code e75648666870 = 1175160294646 := by decide
theorem cert_e75648666870 : check e75648666870 [[.under],[.under]] .chain = true := by decide
def e75648667246 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75648667246 : Closed e75648667246 ∧ code e75648667246 = 1175160295022 := by decide
theorem cert_e75648667246 : check e75648667246 [[.under],[.under]] .chain = true := by decide
def e75648667258 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75648667258 : Closed e75648667258 ∧ code e75648667258 = 1175160295034 := by decide
theorem cert_e75648667258 : check e75648667258 [[.under],[.under]] .chain = true := by decide
def e75648667446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75648667446 : Closed e75648667446 ∧ code e75648667446 = 1175160295222 := by decide
theorem cert_e75648667446 : check e75648667446 [[.under],[.under]] .chain = true := by decide
def e75648667450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75648667450 : Closed e75648667450 ∧ code e75648667450 = 1175160295226 := by decide
theorem cert_e75648667450 : check e75648667450 [[.under],[.under]] .chain = true := by decide
def e75649256302 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75649256302 : Closed e75649256302 ∧ code e75649256302 = 1175160884078 := by decide
theorem cert_e75649256302 : check e75649256302 [[.under],[.under]] .sourceHead = true := by decide
def e75649256310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75649256310 : Closed e75649256310 ∧ code e75649256310 = 1175160884086 := by decide
theorem cert_e75649256310 : check e75649256310 [[.under],[.under]] .sourceHead = true := by decide
def e75649256366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75649256366 : Closed e75649256366 ∧ code e75649256366 = 1175160884142 := by decide
theorem cert_e75649256366 : check e75649256366 [[.under],[.under]] .sourceHead = true := by decide
def e75649256378 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75649256378 : Closed e75649256378 ∧ code e75649256378 = 1175160884154 := by decide
theorem cert_e75649256378 : check e75649256378 [[.under],[.under]] .sourceHead = true := by decide
def e75649256406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75649256406 : Closed e75649256406 ∧ code e75649256406 = 1175160884182 := by decide
theorem cert_e75649256406 : check e75649256406 [[.under],[.under]] .sourceHead = true := by decide
def e75649256410 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75649256410 : Closed e75649256410 ∧ code e75649256410 = 1175160884186 := by decide
theorem cert_e75649256410 : check e75649256410 [[.under],[.under]] .sourceHead = true := by decide
def e75649256686 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75649256686 : Closed e75649256686 ∧ code e75649256686 = 1175160884462 := by decide
theorem cert_e75649256686 : check e75649256686 [[.under],[.under]] .sourceHead = true := by decide
def e75649256694 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75649256694 : Closed e75649256694 ∧ code e75649256694 = 1175160884470 := by decide
theorem cert_e75649256694 : check e75649256694 [[.under],[.under]] .sourceHead = true := by decide
def e75649257070 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75649257070 : Closed e75649257070 ∧ code e75649257070 = 1175160884846 := by decide
theorem cert_e75649257070 : check e75649257070 [[.under],[.under]] .sourceHead = true := by decide
def e75649257082 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75649257082 : Closed e75649257082 ∧ code e75649257082 = 1175160884858 := by decide
theorem cert_e75649257082 : check e75649257082 [[.under],[.under]] .sourceHead = true := by decide
def e75649257270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75649257270 : Closed e75649257270 ∧ code e75649257270 = 1175160885046 := by decide
theorem cert_e75649257270 : check e75649257270 [[.under],[.under]] .sourceHead = true := by decide
def e75649257274 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75649257274 : Closed e75649257274 ∧ code e75649257274 = 1175160885050 := by decide
theorem cert_e75649257274 : check e75649257274 [[.under],[.under]] .sourceHead = true := by decide
def e75721890678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))))
theorem wire_e75721890678 : Closed e75721890678 ∧ code e75721890678 = 1175233518454 := by decide
theorem cert_e75721890678 : check e75721890678 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e75721890742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))))
theorem wire_e75721890742 : Closed e75721890742 ∧ code e75721890742 = 1175233518518 := by decide
theorem cert_e75721890742 : check e75721890742 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e75721891190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e75721891190 : Closed e75721891190 ∧ code e75721891190 = 1175233518966 := by decide
theorem cert_e75721891190 : check e75721891190 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e75721891286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e75721891286 : Closed e75721891286 ∧ code e75721891286 = 1175233519062 := by decide
private def t_e75721891286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem cert_e75721891286 : ¬ IsSelfInterpreter e75721891286 :=
  wSource (t := t_e75721891286) (replay_sound (ps := []) (t := e75721891286) (by decide)) (by decide)
def e75721891510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e75721891510 : Closed e75721891510 ∧ code e75721891510 = 1175233519286 := by decide
theorem cert_e75721891510 : check e75721891510 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e75721891542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e75721891542 : Closed e75721891542 ∧ code e75721891542 = 1175233519318 := by decide
private def t_e75721891542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem cert_e75721891542 : ¬ IsSelfInterpreter e75721891542 :=
  wSource (t := t_e75721891542) (replay_sound (ps := []) (t := e75721891542) (by decide)) (by decide)
def e75721893750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e75721893750 : Closed e75721893750 ∧ code e75721893750 = 1175233521526 := by decide
theorem cert_e75721893750 : check e75721893750 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e75721893814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e75721893814 : Closed e75721893814 ∧ code e75721893814 = 1175233521590 := by decide
theorem cert_e75721893814 : check e75721893814 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e75721896822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e75721896822 : Closed e75721896822 ∧ code e75721896822 = 1175233524598 := by decide
theorem cert_e75721896822 : check e75721896822 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e75721896918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e75721896918 : Closed e75721896918 ∧ code e75721896918 = 1175233524694 := by decide
theorem cert_e75721896918 : check e75721896918 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e75721898422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e75721898422 : Closed e75721898422 ∧ code e75721898422 = 1175233526198 := by decide
theorem cert_e75721898422 : check e75721898422 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e75721898454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e75721898454 : Closed e75721898454 ∧ code e75721898454 = 1175233526230 := by decide
theorem cert_e75721898454 : check e75721898454 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e75722656622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75722656622 : Closed e75722656622 ∧ code e75722656622 = 1175234284398 := by decide
theorem cert_e75722656622 : check e75722656622 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722656630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75722656630 : Closed e75722656630 ∧ code e75722656630 = 1175234284406 := by decide
theorem cert_e75722656630 : check e75722656630 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722656686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75722656686 : Closed e75722656686 ∧ code e75722656686 = 1175234284462 := by decide
theorem cert_e75722656686 : check e75722656686 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722656698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75722656698 : Closed e75722656698 ∧ code e75722656698 = 1175234284474 := by decide
theorem cert_e75722656698 : check e75722656698 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722656726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75722656726 : Closed e75722656726 ∧ code e75722656726 = 1175234284502 := by decide
theorem cert_e75722656726 : check e75722656726 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722656730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75722656730 : Closed e75722656730 ∧ code e75722656730 = 1175234284506 := by decide
theorem cert_e75722656730 : check e75722656730 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722657006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75722657006 : Closed e75722657006 ∧ code e75722657006 = 1175234284782 := by decide
theorem cert_e75722657006 : check e75722657006 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722657014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75722657014 : Closed e75722657014 ∧ code e75722657014 = 1175234284790 := by decide
theorem cert_e75722657014 : check e75722657014 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722657390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75722657390 : Closed e75722657390 ∧ code e75722657390 = 1175234285166 := by decide
theorem cert_e75722657390 : check e75722657390 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722657402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75722657402 : Closed e75722657402 ∧ code e75722657402 = 1175234285178 := by decide
theorem cert_e75722657402 : check e75722657402 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722657590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75722657590 : Closed e75722657590 ∧ code e75722657590 = 1175234285366 := by decide
theorem cert_e75722657590 : check e75722657590 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722657594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75722657594 : Closed e75722657594 ∧ code e75722657594 = 1175234285370 := by decide
theorem cert_e75722657594 : check e75722657594 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75722927546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e75722927546 : Closed e75722927546 ∧ code e75722927546 = 1175234555322 := by decide
theorem cert_e75722927546 : check e75722927546 [[.under],[.under]] .sourceHead = true := by decide
def e75722927578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e75722927578 : Closed e75722927578 ∧ code e75722927578 = 1175234555354 := by decide
theorem cert_e75722927578 : check e75722927578 [[.under],[.under]] .sourceHead = true := by decide
def e75722927802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e75722927802 : Closed e75722927802 ∧ code e75722927802 = 1175234555578 := by decide
theorem cert_e75722927802 : check e75722927802 [[.under],[.under]] .sourceHead = true := by decide
def e75722927850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e75722927850 : Closed e75722927850 ∧ code e75722927850 = 1175234555626 := by decide
theorem cert_e75722927850 : check e75722927850 [[.under],[.under]] .sourceHead = true := by decide
def e75722927962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e75722927962 : Closed e75722927962 ∧ code e75722927962 = 1175234555738 := by decide
theorem cert_e75722927962 : check e75722927962 [[.under],[.under]] .sourceHead = true := by decide
def e75722927978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e75722927978 : Closed e75722927978 ∧ code e75722927978 = 1175234555754 := by decide
theorem cert_e75722927978 : check e75722927978 [[.under],[.under]] .sourceHead = true := by decide
def e75722929082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e75722929082 : Closed e75722929082 ∧ code e75722929082 = 1175234556858 := by decide
theorem cert_e75722929082 : check e75722929082 [[.under],[.under]] .sourceHead = true := by decide
def e75722929114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e75722929114 : Closed e75722929114 ∧ code e75722929114 = 1175234556890 := by decide
theorem cert_e75722929114 : check e75722929114 [[.under],[.under]] .sourceHead = true := by decide
def e75722930618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e75722930618 : Closed e75722930618 ∧ code e75722930618 = 1175234558394 := by decide
theorem cert_e75722930618 : check e75722930618 [[.under],[.under]] .sourceHead = true := by decide
def e75722930666 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e75722930666 : Closed e75722930666 ∧ code e75722930666 = 1175234558442 := by decide
theorem cert_e75722930666 : check e75722930666 [[.under],[.under]] .sourceHead = true := by decide
def e75722931418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e75722931418 : Closed e75722931418 ∧ code e75722931418 = 1175234559194 := by decide
theorem cert_e75722931418 : check e75722931418 [[.under],[.under]] .sourceHead = true := by decide
def e75722931434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e75722931434 : Closed e75722931434 ∧ code e75722931434 = 1175234559210 := by decide
theorem cert_e75722931434 : check e75722931434 [[.under],[.under]] .sourceHead = true := by decide
def e75723180910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75723180910 : Closed e75723180910 ∧ code e75723180910 = 1175234808686 := by decide
theorem cert_e75723180910 : check e75723180910 [[.under],[.under]] .sourceHead = true := by decide
def e75723180918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75723180918 : Closed e75723180918 ∧ code e75723180918 = 1175234808694 := by decide
theorem cert_e75723180918 : check e75723180918 [[.under],[.under]] .sourceHead = true := by decide
def e75723180974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75723180974 : Closed e75723180974 ∧ code e75723180974 = 1175234808750 := by decide
theorem cert_e75723180974 : check e75723180974 [[.under],[.under]] .sourceHead = true := by decide
def e75723180986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75723180986 : Closed e75723180986 ∧ code e75723180986 = 1175234808762 := by decide
theorem cert_e75723180986 : check e75723180986 [[.under],[.under]] .sourceHead = true := by decide
def e75723181014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75723181014 : Closed e75723181014 ∧ code e75723181014 = 1175234808790 := by decide
theorem cert_e75723181014 : check e75723181014 [[.under],[.under]] .sourceHead = true := by decide
def e75723181018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75723181018 : Closed e75723181018 ∧ code e75723181018 = 1175234808794 := by decide
theorem cert_e75723181018 : check e75723181018 [[.under],[.under]] .sourceHead = true := by decide
def e75723181294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75723181294 : Closed e75723181294 ∧ code e75723181294 = 1175234809070 := by decide
theorem cert_e75723181294 : check e75723181294 [[.under],[.under]] .sourceHead = true := by decide
def e75723181302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75723181302 : Closed e75723181302 ∧ code e75723181302 = 1175234809078 := by decide
theorem cert_e75723181302 : check e75723181302 [[.under],[.under]] .sourceHead = true := by decide
def e75723181678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75723181678 : Closed e75723181678 ∧ code e75723181678 = 1175234809454 := by decide
theorem cert_e75723181678 : check e75723181678 [[.under],[.under]] .sourceHead = true := by decide
def e75723181690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75723181690 : Closed e75723181690 ∧ code e75723181690 = 1175234809466 := by decide
theorem cert_e75723181690 : check e75723181690 [[.under],[.under]] .sourceHead = true := by decide
def e75723181878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75723181878 : Closed e75723181878 ∧ code e75723181878 = 1175234809654 := by decide
theorem cert_e75723181878 : check e75723181878 [[.under],[.under]] .sourceHead = true := by decide
def e75723181882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75723181882 : Closed e75723181882 ∧ code e75723181882 = 1175234809658 := by decide
theorem cert_e75723181882 : check e75723181882 [[.under],[.under]] .sourceHead = true := by decide
def e75725802350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e75725802350 : Closed e75725802350 ∧ code e75725802350 = 1175237430126 := by decide
theorem cert_e75725802350 : check e75725802350 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725802358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e75725802358 : Closed e75725802358 ∧ code e75725802358 = 1175237430134 := by decide
theorem cert_e75725802358 : check e75725802358 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725802414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e75725802414 : Closed e75725802414 ∧ code e75725802414 = 1175237430190 := by decide
theorem cert_e75725802414 : check e75725802414 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725802426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e75725802426 : Closed e75725802426 ∧ code e75725802426 = 1175237430202 := by decide
theorem cert_e75725802426 : check e75725802426 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725802454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e75725802454 : Closed e75725802454 ∧ code e75725802454 = 1175237430230 := by decide
theorem cert_e75725802454 : check e75725802454 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725802458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e75725802458 : Closed e75725802458 ∧ code e75725802458 = 1175237430234 := by decide
theorem cert_e75725802458 : check e75725802458 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725802734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e75725802734 : Closed e75725802734 ∧ code e75725802734 = 1175237430510 := by decide
theorem cert_e75725802734 : check e75725802734 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725802742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e75725802742 : Closed e75725802742 ∧ code e75725802742 = 1175237430518 := by decide
theorem cert_e75725802742 : check e75725802742 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725803118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e75725803118 : Closed e75725803118 ∧ code e75725803118 = 1175237430894 := by decide
theorem cert_e75725803118 : check e75725803118 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725803130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e75725803130 : Closed e75725803130 ∧ code e75725803130 = 1175237430906 := by decide
theorem cert_e75725803130 : check e75725803130 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725803318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e75725803318 : Closed e75725803318 ∧ code e75725803318 = 1175237431094 := by decide
theorem cert_e75725803318 : check e75725803318 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75725803322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e75725803322 : Closed e75725803322 ∧ code e75725803322 = 1175237431098 := by decide
theorem cert_e75725803322 : check e75725803322 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e75728203118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e75728203118 : Closed e75728203118 ∧ code e75728203118 = 1175239830894 := by decide
theorem cert_e75728203118 : check e75728203118 [[.under],[.under]] .chain = true := by decide
def e75728203126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e75728203126 : Closed e75728203126 ∧ code e75728203126 = 1175239830902 := by decide
theorem cert_e75728203126 : check e75728203126 [[.under],[.under]] .chain = true := by decide
def e75728203182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e75728203182 : Closed e75728203182 ∧ code e75728203182 = 1175239830958 := by decide
theorem cert_e75728203182 : check e75728203182 [[.under],[.under]] .chain = true := by decide
def e75728203194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e75728203194 : Closed e75728203194 ∧ code e75728203194 = 1175239830970 := by decide
theorem cert_e75728203194 : check e75728203194 [[.under],[.under]] .chain = true := by decide
def e75728203222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e75728203222 : Closed e75728203222 ∧ code e75728203222 = 1175239830998 := by decide
theorem cert_e75728203222 : check e75728203222 [[.under],[.under]] .chain = true := by decide
def e75728203226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e75728203226 : Closed e75728203226 ∧ code e75728203226 = 1175239831002 := by decide
theorem cert_e75728203226 : check e75728203226 [[.under],[.under]] .chain = true := by decide
def e75728203438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e75728203438 : Closed e75728203438 ∧ code e75728203438 = 1175239831214 := by decide
theorem cert_e75728203438 : check e75728203438 [[.under],[.under]] .chain = true := by decide
def e75728203450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e75728203450 : Closed e75728203450 ∧ code e75728203450 = 1175239831226 := by decide
theorem cert_e75728203450 : check e75728203450 [[.under],[.under]] .chain = true := by decide
def e75728203498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e75728203498 : Closed e75728203498 ∧ code e75728203498 = 1175239831274 := by decide
theorem cert_e75728203498 : check e75728203498 [[.under],[.under]] .chain = true := by decide
def e75728203606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e75728203606 : Closed e75728203606 ∧ code e75728203606 = 1175239831382 := by decide
theorem cert_e75728203606 : check e75728203606 [[.under],[.under]] .chain = true := by decide
def e75728203610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e75728203610 : Closed e75728203610 ∧ code e75728203610 = 1175239831386 := by decide
theorem cert_e75728203610 : check e75728203610 [[.under],[.under]] .chain = true := by decide
def e75728203626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e75728203626 : Closed e75728203626 ∧ code e75728203626 = 1175239831402 := by decide
theorem cert_e75728203626 : check e75728203626 [[.under],[.under]] .chain = true := by decide
def e75728204654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e75728204654 : Closed e75728204654 ∧ code e75728204654 = 1175239832430 := by decide
theorem cert_e75728204654 : check e75728204654 [[.under],[.under]] .chain = true := by decide
def e75728204662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e75728204662 : Closed e75728204662 ∧ code e75728204662 = 1175239832438 := by decide
theorem cert_e75728204662 : check e75728204662 [[.under],[.under]] .chain = true := by decide
def e75728204718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e75728204718 : Closed e75728204718 ∧ code e75728204718 = 1175239832494 := by decide
theorem cert_e75728204718 : check e75728204718 [[.under],[.under]] .chain = true := by decide
def e75728204730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e75728204730 : Closed e75728204730 ∧ code e75728204730 = 1175239832506 := by decide
theorem cert_e75728204730 : check e75728204730 [[.under],[.under]] .chain = true := by decide
def e75728204758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e75728204758 : Closed e75728204758 ∧ code e75728204758 = 1175239832534 := by decide
theorem cert_e75728204758 : check e75728204758 [[.under],[.under]] .chain = true := by decide
def e75728204762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e75728204762 : Closed e75728204762 ∧ code e75728204762 = 1175239832538 := by decide
theorem cert_e75728204762 : check e75728204762 [[.under],[.under]] .chain = true := by decide
def e75728205038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e75728205038 : Closed e75728205038 ∧ code e75728205038 = 1175239832814 := by decide
theorem cert_e75728205038 : check e75728205038 [[.under],[.under]] .chain = true := by decide
def e75728205046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e75728205046 : Closed e75728205046 ∧ code e75728205046 = 1175239832822 := by decide
theorem cert_e75728205046 : check e75728205046 [[.under],[.under]] .chain = true := by decide
def e75728205422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e75728205422 : Closed e75728205422 ∧ code e75728205422 = 1175239833198 := by decide
theorem cert_e75728205422 : check e75728205422 [[.under],[.under]] .chain = true := by decide
def e75728205434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e75728205434 : Closed e75728205434 ∧ code e75728205434 = 1175239833210 := by decide
theorem cert_e75728205434 : check e75728205434 [[.under],[.under]] .chain = true := by decide
def e75728205622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e75728205622 : Closed e75728205622 ∧ code e75728205622 = 1175239833398 := by decide
theorem cert_e75728205622 : check e75728205622 [[.under],[.under]] .chain = true := by decide
def e75728205626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e75728205626 : Closed e75728205626 ∧ code e75728205626 = 1175239833402 := by decide
theorem cert_e75728205626 : check e75728205626 [[.under],[.under]] .chain = true := by decide
def e75728206254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e75728206254 : Closed e75728206254 ∧ code e75728206254 = 1175239834030 := by decide
theorem cert_e75728206254 : check e75728206254 [[.under],[.under]] .chain = true := by decide
def e75728206266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e75728206266 : Closed e75728206266 ∧ code e75728206266 = 1175239834042 := by decide
theorem cert_e75728206266 : check e75728206266 [[.under],[.under]] .chain = true := by decide
def e75728206314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e75728206314 : Closed e75728206314 ∧ code e75728206314 = 1175239834090 := by decide
theorem cert_e75728206314 : check e75728206314 [[.under],[.under]] .chain = true := by decide
def e75728206446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e75728206446 : Closed e75728206446 ∧ code e75728206446 = 1175239834222 := by decide
theorem cert_e75728206446 : check e75728206446 [[.under],[.under]] .chain = true := by decide
def e75728206458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e75728206458 : Closed e75728206458 ∧ code e75728206458 = 1175239834234 := by decide
theorem cert_e75728206458 : check e75728206458 [[.under],[.under]] .chain = true := by decide
def e75728206746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e75728206746 : Closed e75728206746 ∧ code e75728206746 = 1175239834522 := by decide
theorem cert_e75728206746 : check e75728206746 [[.under],[.under]] .chain = true := by decide
def e75728207062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e75728207062 : Closed e75728207062 ∧ code e75728207062 = 1175239834838 := by decide
theorem cert_e75728207062 : check e75728207062 [[.under],[.under]] .chain = true := by decide
def e75728207066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e75728207066 : Closed e75728207066 ∧ code e75728207066 = 1175239834842 := by decide
theorem cert_e75728207066 : check e75728207066 [[.under],[.under]] .chain = true := by decide
def e75728207082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e75728207082 : Closed e75728207082 ∧ code e75728207082 = 1175239834858 := by decide
theorem cert_e75728207082 : check e75728207082 [[.under],[.under]] .chain = true := by decide
def e75728207158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e75728207158 : Closed e75728207158 ∧ code e75728207158 = 1175239834934 := by decide
theorem cert_e75728207158 : check e75728207158 [[.under],[.under]] .chain = true := by decide
def e75728207162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e75728207162 : Closed e75728207162 ∧ code e75728207162 = 1175239834938 := by decide
theorem cert_e75728207162 : check e75728207162 [[.under],[.under]] .chain = true := by decide
def e75728207258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e75728207258 : Closed e75728207258 ∧ code e75728207258 = 1175239835034 := by decide
theorem cert_e75728207258 : check e75728207258 [[.under],[.under]] .chain = true := by decide
def e75728210798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e75728210798 : Closed e75728210798 ∧ code e75728210798 = 1175239838574 := by decide
theorem cert_e75728210798 : check e75728210798 [[.under],[.under]] .chain = true := by decide
def e75728210806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e75728210806 : Closed e75728210806 ∧ code e75728210806 = 1175239838582 := by decide
theorem cert_e75728210806 : check e75728210806 [[.under],[.under]] .chain = true := by decide
def e75728210862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e75728210862 : Closed e75728210862 ∧ code e75728210862 = 1175239838638 := by decide
theorem cert_e75728210862 : check e75728210862 [[.under],[.under]] .chain = true := by decide
def e75728210874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e75728210874 : Closed e75728210874 ∧ code e75728210874 = 1175239838650 := by decide
theorem cert_e75728210874 : check e75728210874 [[.under],[.under]] .chain = true := by decide
def e75728210902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e75728210902 : Closed e75728210902 ∧ code e75728210902 = 1175239838678 := by decide
theorem cert_e75728210902 : check e75728210902 [[.under],[.under]] .chain = true := by decide
def e75728210906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e75728210906 : Closed e75728210906 ∧ code e75728210906 = 1175239838682 := by decide
theorem cert_e75728210906 : check e75728210906 [[.under],[.under]] .chain = true := by decide
def e75728211182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e75728211182 : Closed e75728211182 ∧ code e75728211182 = 1175239838958 := by decide
theorem cert_e75728211182 : check e75728211182 [[.under],[.under]] .chain = true := by decide
def e75728211190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e75728211190 : Closed e75728211190 ∧ code e75728211190 = 1175239838966 := by decide
theorem cert_e75728211190 : check e75728211190 [[.under],[.under]] .chain = true := by decide
def e75728211566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e75728211566 : Closed e75728211566 ∧ code e75728211566 = 1175239839342 := by decide
theorem cert_e75728211566 : check e75728211566 [[.under],[.under]] .chain = true := by decide
def e75728211578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e75728211578 : Closed e75728211578 ∧ code e75728211578 = 1175239839354 := by decide
theorem cert_e75728211578 : check e75728211578 [[.under],[.under]] .chain = true := by decide
def e75728211766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e75728211766 : Closed e75728211766 ∧ code e75728211766 = 1175239839542 := by decide
theorem cert_e75728211766 : check e75728211766 [[.under],[.under]] .chain = true := by decide
def e75728211770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e75728211770 : Closed e75728211770 ∧ code e75728211770 = 1175239839546 := by decide
theorem cert_e75728211770 : check e75728211770 [[.under],[.under]] .chain = true := by decide
def e75728217518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e75728217518 : Closed e75728217518 ∧ code e75728217518 = 1175239845294 := by decide
theorem cert_e75728217518 : check e75728217518 [[.under],[.under]] .chain = true := by decide
def e75728217530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e75728217530 : Closed e75728217530 ∧ code e75728217530 = 1175239845306 := by decide
theorem cert_e75728217530 : check e75728217530 [[.under],[.under]] .chain = true := by decide
def e75728217578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e75728217578 : Closed e75728217578 ∧ code e75728217578 = 1175239845354 := by decide
theorem cert_e75728217578 : check e75728217578 [[.under],[.under]] .chain = true := by decide
def e75728217710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e75728217710 : Closed e75728217710 ∧ code e75728217710 = 1175239845486 := by decide
theorem cert_e75728217710 : check e75728217710 [[.under],[.under]] .chain = true := by decide
def e75728217722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e75728217722 : Closed e75728217722 ∧ code e75728217722 = 1175239845498 := by decide
theorem cert_e75728217722 : check e75728217722 [[.under],[.under]] .chain = true := by decide
def e75728218010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e75728218010 : Closed e75728218010 ∧ code e75728218010 = 1175239845786 := by decide
theorem cert_e75728218010 : check e75728218010 [[.under],[.under]] .chain = true := by decide
def e75728220886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e75728220886 : Closed e75728220886 ∧ code e75728220886 = 1175239848662 := by decide
theorem cert_e75728220886 : check e75728220886 [[.under],[.under]] .chain = true := by decide
def e75728220890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e75728220890 : Closed e75728220890 ∧ code e75728220890 = 1175239848666 := by decide
theorem cert_e75728220890 : check e75728220890 [[.under],[.under]] .chain = true := by decide
def e75728220906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e75728220906 : Closed e75728220906 ∧ code e75728220906 = 1175239848682 := by decide
theorem cert_e75728220906 : check e75728220906 [[.under],[.under]] .chain = true := by decide
def e75728220982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e75728220982 : Closed e75728220982 ∧ code e75728220982 = 1175239848758 := by decide
theorem cert_e75728220982 : check e75728220982 [[.under],[.under]] .chain = true := by decide
def e75728220986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e75728220986 : Closed e75728220986 ∧ code e75728220986 = 1175239848762 := by decide
theorem cert_e75728220986 : check e75728220986 [[.under],[.under]] .chain = true := by decide
def e75728221082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e75728221082 : Closed e75728221082 ∧ code e75728221082 = 1175239848858 := by decide
theorem cert_e75728221082 : check e75728221082 [[.under],[.under]] .chain = true := by decide
def e75728358254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e75728358254 : Closed e75728358254 ∧ code e75728358254 = 1175239986030 := by decide
theorem cert_e75728358254 : check e75728358254 [[.under],[.under]] .chain = true := by decide
def e75728358262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e75728358262 : Closed e75728358262 ∧ code e75728358262 = 1175239986038 := by decide
theorem cert_e75728358262 : check e75728358262 [[.under],[.under]] .chain = true := by decide
def e75728358318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e75728358318 : Closed e75728358318 ∧ code e75728358318 = 1175239986094 := by decide
theorem cert_e75728358318 : check e75728358318 [[.under],[.under]] .chain = true := by decide
def e75728358330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e75728358330 : Closed e75728358330 ∧ code e75728358330 = 1175239986106 := by decide
theorem cert_e75728358330 : check e75728358330 [[.under],[.under]] .chain = true := by decide
def e75728358358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e75728358358 : Closed e75728358358 ∧ code e75728358358 = 1175239986134 := by decide
theorem cert_e75728358358 : check e75728358358 [[.under],[.under]] .chain = true := by decide
def e75728358362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e75728358362 : Closed e75728358362 ∧ code e75728358362 = 1175239986138 := by decide
theorem cert_e75728358362 : check e75728358362 [[.under],[.under]] .chain = true := by decide
def e75728358638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e75728358638 : Closed e75728358638 ∧ code e75728358638 = 1175239986414 := by decide
theorem cert_e75728358638 : check e75728358638 [[.under],[.under]] .chain = true := by decide
def e75728358646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e75728358646 : Closed e75728358646 ∧ code e75728358646 = 1175239986422 := by decide
theorem cert_e75728358646 : check e75728358646 [[.under],[.under]] .chain = true := by decide
def e75728359022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e75728359022 : Closed e75728359022 ∧ code e75728359022 = 1175239986798 := by decide
theorem cert_e75728359022 : check e75728359022 [[.under],[.under]] .chain = true := by decide
def e75728359034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e75728359034 : Closed e75728359034 ∧ code e75728359034 = 1175239986810 := by decide
theorem cert_e75728359034 : check e75728359034 [[.under],[.under]] .chain = true := by decide
def e75728359222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e75728359222 : Closed e75728359222 ∧ code e75728359222 = 1175239986998 := by decide
theorem cert_e75728359222 : check e75728359222 [[.under],[.under]] .chain = true := by decide
def e75728359226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e75728359226 : Closed e75728359226 ∧ code e75728359226 = 1175239987002 := by decide
theorem cert_e75728359226 : check e75728359226 [[.under],[.under]] .chain = true := by decide
def e75728948078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e75728948078 : Closed e75728948078 ∧ code e75728948078 = 1175240575854 := by decide
theorem cert_e75728948078 : check e75728948078 [[.under],[.under]] .sourceHead = true := by decide
def e75728948086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e75728948086 : Closed e75728948086 ∧ code e75728948086 = 1175240575862 := by decide
theorem cert_e75728948086 : check e75728948086 [[.under],[.under]] .sourceHead = true := by decide
def e75728948142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e75728948142 : Closed e75728948142 ∧ code e75728948142 = 1175240575918 := by decide
theorem cert_e75728948142 : check e75728948142 [[.under],[.under]] .sourceHead = true := by decide
def e75728948154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e75728948154 : Closed e75728948154 ∧ code e75728948154 = 1175240575930 := by decide
theorem cert_e75728948154 : check e75728948154 [[.under],[.under]] .sourceHead = true := by decide
end Blc.Floor40
