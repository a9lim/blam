import R302824803182Data
namespace Certgen.R302824803182
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl504 : FloorIndex.rangeOK validState 504 12 = true := by decide +kernel
theorem bl516 : FloorIndex.rangeOK validState 516 8 = true := by decide +kernel
end Certgen.R302824803182
