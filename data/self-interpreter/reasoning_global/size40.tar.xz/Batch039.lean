import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302797168246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e302797168246 : Closed e302797168246 ∧ code e302797168246 = 1402308796022 := by decide
theorem cert_e302797168246 : check e302797168246 [[],[]] .smaller = true := by decide
def e302797168438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302797168438 : Closed e302797168438 ∧ code e302797168438 = 1402308796214 := by decide
theorem cert_e302797168438 : check e302797168438 [[],[]] .smaller = true := by decide
def e302797168442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302797168442 : Closed e302797168442 ∧ code e302797168442 = 1402308796218 := by decide
theorem cert_e302797168442 : check e302797168442 [[],[]] .smaller = true := by decide
def e302797182646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e302797182646 : Closed e302797182646 ∧ code e302797182646 = 1402308810422 := by decide
theorem cert_e302797182646 : check e302797182646 [[],[]] .smaller = true := by decide
def e302797182678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e302797182678 : Closed e302797182678 ∧ code e302797182678 = 1402308810454 := by decide
theorem cert_e302797182678 : check e302797182678 [[],[]] .smaller = true := by decide
def e302797182682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e302797182682 : Closed e302797182682 ∧ code e302797182682 = 1402308810458 := by decide
theorem cert_e302797182682 : check e302797182682 [[],[]] .smaller = true := by decide
def e302797182806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302797182806 : Closed e302797182806 ∧ code e302797182806 = 1402308810582 := by decide
theorem cert_e302797182806 : check e302797182806 [[],[]] .smaller = true := by decide
def e302797182810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302797182810 : Closed e302797182810 ∧ code e302797182810 = 1402308810586 := by decide
theorem cert_e302797182810 : check e302797182810 [[],[]] .smaller = true := by decide
def e302797182826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302797182826 : Closed e302797182826 ∧ code e302797182826 = 1402308810602 := by decide
theorem cert_e302797182826 : check e302797182826 [[],[]] .smaller = true := by decide
def e302797183198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e302797183198 : Closed e302797183198 ∧ code e302797183198 = 1402308810974 := by decide
theorem cert_e302797183198 : check e302797183198 [[],[]] .three = true := by decide
def e302797183214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302797183214 : Closed e302797183214 ∧ code e302797183214 = 1402308810990 := by decide
theorem cert_e302797183214 : check e302797183214 [[],[]] .smaller = true := by decide
def e302797183222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302797183222 : Closed e302797183222 ∧ code e302797183222 = 1402308810998 := by decide
theorem cert_e302797183222 : check e302797183222 [[],[]] .smaller = true := by decide
def e302797183226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e302797183226 : Closed e302797183226 ∧ code e302797183226 = 1402308811002 := by decide
theorem cert_e302797183226 : check e302797183226 [[],[]] .three = true := by decide
def e302797183414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e302797183414 : Closed e302797183414 ∧ code e302797183414 = 1402308811190 := by decide
theorem cert_e302797183414 : check e302797183414 [[],[]] .smaller = true := by decide
def e302797183446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e302797183446 : Closed e302797183446 ∧ code e302797183446 = 1402308811222 := by decide
theorem cert_e302797183446 : check e302797183446 [[],[]] .smaller = true := by decide
def e302797183450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e302797183450 : Closed e302797183450 ∧ code e302797183450 = 1402308811226 := by decide
theorem cert_e302797183450 : check e302797183450 [[],[]] .smaller = true := by decide
def e302797183550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e302797183550 : Closed e302797183550 ∧ code e302797183550 = 1402308811326 := by decide
theorem cert_e302797183550 : check e302797183550 [[],[]] .three = true := by decide
def e302797183606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302797183606 : Closed e302797183606 ∧ code e302797183606 = 1402308811382 := by decide
theorem cert_e302797183606 : check e302797183606 [[],[]] .smaller = true := by decide
def e302797183774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302797183774 : Closed e302797183774 ∧ code e302797183774 = 1402308811550 := by decide
theorem cert_e302797183774 : check e302797183774 [[],[]] .smaller = true := by decide
def e302797183798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302797183798 : Closed e302797183798 ∧ code e302797183798 = 1402308811574 := by decide
theorem cert_e302797183798 : check e302797183798 [[],[]] .smaller = true := by decide
def e302797183802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302797183802 : Closed e302797183802 ∧ code e302797183802 = 1402308811578 := by decide
theorem cert_e302797183802 : check e302797183802 [[],[]] .smaller = true := by decide
def e302797183886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302797183886 : Closed e302797183886 ∧ code e302797183886 = 1402308811662 := by decide
theorem cert_e302797183886 : check e302797183886 [[],[]] .smaller = true := by decide
def e302797183942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e302797183942 : Closed e302797183942 ∧ code e302797183942 = 1402308811718 := by decide
theorem cert_e302797183942 : check e302797183942 [[],[]] .three = true := by decide
def e302797183966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e302797183966 : Closed e302797183966 ∧ code e302797183966 = 1402308811742 := by decide
theorem cert_e302797183966 : check e302797183966 [[],[]] .three = true := by decide
def e302797184110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302797184110 : Closed e302797184110 ∧ code e302797184110 = 1402308811886 := by decide
theorem cert_e302797184110 : check e302797184110 [[],[]] .smaller = true := by decide
def e302797184122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302797184122 : Closed e302797184122 ∧ code e302797184122 = 1402308811898 := by decide
theorem cert_e302797184122 : check e302797184122 [[],[]] .smaller = true := by decide
def e302797184214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302797184214 : Closed e302797184214 ∧ code e302797184214 = 1402308811990 := by decide
theorem cert_e302797184214 : check e302797184214 [[],[]] .smaller = true := by decide
def e302797184218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302797184218 : Closed e302797184218 ∧ code e302797184218 = 1402308811994 := by decide
theorem cert_e302797184218 : check e302797184218 [[],[]] .smaller = true := by decide
def e302797184234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302797184234 : Closed e302797184234 ∧ code e302797184234 = 1402308812010 := by decide
theorem cert_e302797184234 : check e302797184234 [[],[]] .smaller = true := by decide
def e302797184286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302797184286 : Closed e302797184286 ∧ code e302797184286 = 1402308812062 := by decide
theorem cert_e302797184286 : check e302797184286 [[],[]] .smaller = true := by decide
def e302797184310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302797184310 : Closed e302797184310 ∧ code e302797184310 = 1402308812086 := by decide
theorem cert_e302797184310 : check e302797184310 [[],[]] .smaller = true := by decide
def e302797184314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302797184314 : Closed e302797184314 ∧ code e302797184314 = 1402308812090 := by decide
theorem cert_e302797184314 : check e302797184314 [[],[]] .smaller = true := by decide
def e302797184410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302797184410 : Closed e302797184410 ∧ code e302797184410 = 1402308812186 := by decide
theorem cert_e302797184410 : check e302797184410 [[],[]] .smaller = true := by decide
def e302797184454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302797184454 : Closed e302797184454 ∧ code e302797184454 = 1402308812230 := by decide
theorem cert_e302797184454 : check e302797184454 [[],[]] .smaller = true := by decide
def e302797184478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e302797184478 : Closed e302797184478 ∧ code e302797184478 = 1402308812254 := by decide
theorem cert_e302797184478 : check e302797184478 [[],[]] .three = true := by decide
def e302797184494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e302797184494 : Closed e302797184494 ∧ code e302797184494 = 1402308812270 := by decide
theorem cert_e302797184494 : check e302797184494 [[],[]] .three = true := by decide
def e302797184566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302797184566 : Closed e302797184566 ∧ code e302797184566 = 1402308812342 := by decide
theorem cert_e302797184566 : check e302797184566 [[],[]] .smaller = true := by decide
def e302797184570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302797184570 : Closed e302797184570 ∧ code e302797184570 = 1402308812346 := by decide
theorem cert_e302797184570 : check e302797184570 [[],[]] .smaller = true := by decide
def e302797184654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302797184654 : Closed e302797184654 ∧ code e302797184654 = 1402308812430 := by decide
theorem cert_e302797184654 : check e302797184654 [[],[]] .smaller = true := by decide
def e302797184710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302797184710 : Closed e302797184710 ∧ code e302797184710 = 1402308812486 := by decide
theorem cert_e302797184710 : check e302797184710 [[],[]] .smaller = true := by decide
def e302797184734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e302797184734 : Closed e302797184734 ∧ code e302797184734 = 1402308812510 := by decide
theorem cert_e302797184734 : check e302797184734 [[],[]] .three = true := by decide
def e302797184758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e302797184758 : Closed e302797184758 ∧ code e302797184758 = 1402308812534 := by decide
theorem cert_e302797184758 : check e302797184758 [[],[]] .three = true := by decide
def e302797184794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302797184794 : Closed e302797184794 ∧ code e302797184794 = 1402308812570 := by decide
theorem cert_e302797184794 : check e302797184794 [[],[]] .three = true := by decide
def e302797184838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302797184838 : Closed e302797184838 ∧ code e302797184838 = 1402308812614 := by decide
theorem cert_e302797184838 : check e302797184838 [[],[]] .three = true := by decide
def e302797184862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e302797184862 : Closed e302797184862 ∧ code e302797184862 = 1402308812638 := by decide
theorem cert_e302797184862 : check e302797184862 [[],[]] .three = true := by decide
def e302797184878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e302797184878 : Closed e302797184878 ∧ code e302797184878 = 1402308812654 := by decide
theorem cert_e302797184878 : check e302797184878 [[],[]] .three = true := by decide
def e302797184886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e302797184886 : Closed e302797184886 ∧ code e302797184886 = 1402308812662 := by decide
theorem cert_e302797184886 : check e302797184886 [[],[]] .three = true := by decide
def e302797184890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e302797184890 : Closed e302797184890 ∧ code e302797184890 = 1402308812666 := by decide
theorem cert_e302797184890 : check e302797184890 [[],[]] .three = true := by decide
def e302797185518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e302797185518 : Closed e302797185518 ∧ code e302797185518 = 1402308813294 := by decide
theorem cert_e302797185518 : check e302797185518 [[],[]] .smaller = true := by decide
def e302797186486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e302797186486 : Closed e302797186486 ∧ code e302797186486 = 1402308814262 := by decide
theorem cert_e302797186486 : check e302797186486 [[],[]] .smaller = true := by decide
def e302797186518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e302797186518 : Closed e302797186518 ∧ code e302797186518 = 1402308814294 := by decide
theorem cert_e302797186518 : check e302797186518 [[],[]] .smaller = true := by decide
def e302797186522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e302797186522 : Closed e302797186522 ∧ code e302797186522 = 1402308814298 := by decide
theorem cert_e302797186522 : check e302797186522 [[],[]] .smaller = true := by decide
def e302797186622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e302797186622 : Closed e302797186622 ∧ code e302797186622 = 1402308814398 := by decide
theorem cert_e302797186622 : check e302797186622 [[],[]] .three = true := by decide
def e302797186678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e302797186678 : Closed e302797186678 ∧ code e302797186678 = 1402308814454 := by decide
theorem cert_e302797186678 : check e302797186678 [[],[]] .smaller = true := by decide
def e302797186846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302797186846 : Closed e302797186846 ∧ code e302797186846 = 1402308814622 := by decide
theorem cert_e302797186846 : check e302797186846 [[],[]] .smaller = true := by decide
def e302797186870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e302797186870 : Closed e302797186870 ∧ code e302797186870 = 1402308814646 := by decide
theorem cert_e302797186870 : check e302797186870 [[],[]] .smaller = true := by decide
def e302797186874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e302797186874 : Closed e302797186874 ∧ code e302797186874 = 1402308814650 := by decide
theorem cert_e302797186874 : check e302797186874 [[],[]] .smaller = true := by decide
def e302797186958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302797186958 : Closed e302797186958 ∧ code e302797186958 = 1402308814734 := by decide
theorem cert_e302797186958 : check e302797186958 [[],[]] .smaller = true := by decide
def e302797187014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e302797187014 : Closed e302797187014 ∧ code e302797187014 = 1402308814790 := by decide
theorem cert_e302797187014 : check e302797187014 [[],[]] .three = true := by decide
def e302797187038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e302797187038 : Closed e302797187038 ∧ code e302797187038 = 1402308814814 := by decide
theorem cert_e302797187038 : check e302797187038 [[],[]] .three = true := by decide
def e302797189358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e302797189358 : Closed e302797189358 ∧ code e302797189358 = 1402308817134 := by decide
theorem cert_e302797189358 : check e302797189358 [[],[]] .smaller = true := by decide
def e302797189366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e302797189366 : Closed e302797189366 ∧ code e302797189366 = 1402308817142 := by decide
theorem cert_e302797189366 : check e302797189366 [[],[]] .smaller = true := by decide
def e302797189846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302797189846 : Closed e302797189846 ∧ code e302797189846 = 1402308817622 := by decide
theorem cert_e302797189846 : check e302797189846 [[],[]] .smaller = true := by decide
def e302797189850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302797189850 : Closed e302797189850 ∧ code e302797189850 = 1402308817626 := by decide
theorem cert_e302797189850 : check e302797189850 [[],[]] .smaller = true := by decide
def e302797189866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302797189866 : Closed e302797189866 ∧ code e302797189866 = 1402308817642 := by decide
theorem cert_e302797189866 : check e302797189866 [[],[]] .smaller = true := by decide
def e302797189918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302797189918 : Closed e302797189918 ∧ code e302797189918 = 1402308817694 := by decide
theorem cert_e302797189918 : check e302797189918 [[],[]] .smaller = true := by decide
def e302797189942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302797189942 : Closed e302797189942 ∧ code e302797189942 = 1402308817718 := by decide
theorem cert_e302797189942 : check e302797189942 [[],[]] .smaller = true := by decide
def e302797189946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302797189946 : Closed e302797189946 ∧ code e302797189946 = 1402308817722 := by decide
theorem cert_e302797189946 : check e302797189946 [[],[]] .smaller = true := by decide
def e302797190042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302797190042 : Closed e302797190042 ∧ code e302797190042 = 1402308817818 := by decide
theorem cert_e302797190042 : check e302797190042 [[],[]] .smaller = true := by decide
def e302797190086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302797190086 : Closed e302797190086 ∧ code e302797190086 = 1402308817862 := by decide
theorem cert_e302797190086 : check e302797190086 [[],[]] .smaller = true := by decide
def e302797190110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e302797190110 : Closed e302797190110 ∧ code e302797190110 = 1402308817886 := by decide
theorem cert_e302797190110 : check e302797190110 [[],[]] .three = true := by decide
def e302797190126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e302797190126 : Closed e302797190126 ∧ code e302797190126 = 1402308817902 := by decide
theorem cert_e302797190126 : check e302797190126 [[],[]] .three = true := by decide
def e302797191566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302797191566 : Closed e302797191566 ∧ code e302797191566 = 1402308819342 := by decide
theorem cert_e302797191566 : check e302797191566 [[],[]] .smaller = true := by decide
def e302797191622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302797191622 : Closed e302797191622 ∧ code e302797191622 = 1402308819398 := by decide
theorem cert_e302797191622 : check e302797191622 [[],[]] .smaller = true := by decide
def e302797191646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e302797191646 : Closed e302797191646 ∧ code e302797191646 = 1402308819422 := by decide
theorem cert_e302797191646 : check e302797191646 [[],[]] .three = true := by decide
def e302797191670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e302797191670 : Closed e302797191670 ∧ code e302797191670 = 1402308819446 := by decide
theorem cert_e302797191670 : check e302797191670 [[],[]] .three = true := by decide
def e302797192390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302797192390 : Closed e302797192390 ∧ code e302797192390 = 1402308820166 := by decide
theorem cert_e302797192390 : check e302797192390 [[],[]] .three = true := by decide
def e302797192414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e302797192414 : Closed e302797192414 ∧ code e302797192414 = 1402308820190 := by decide
theorem cert_e302797192414 : check e302797192414 [[],[]] .three = true := by decide
def e302797192430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e302797192430 : Closed e302797192430 ∧ code e302797192430 = 1402308820206 := by decide
theorem cert_e302797192430 : check e302797192430 [[],[]] .three = true := by decide
def e302797192438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e302797192438 : Closed e302797192438 ∧ code e302797192438 = 1402308820214 := by decide
theorem cert_e302797192438 : check e302797192438 [[],[]] .three = true := by decide
def e302797192442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e302797192442 : Closed e302797192442 ∧ code e302797192442 = 1402308820218 := by decide
theorem cert_e302797192442 : check e302797192442 [[],[]] .three = true := by decide
def e302797237078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302797237078 : Closed e302797237078 ∧ code e302797237078 = 1402308864854 := by decide
theorem cert_e302797237078 : check e302797237078 [[],[]] .three = true := by decide
def e302797237082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302797237082 : Closed e302797237082 ∧ code e302797237082 = 1402308864858 := by decide
theorem cert_e302797237082 : check e302797237082 [[],[]] .three = true := by decide
def e302797237098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302797237098 : Closed e302797237098 ∧ code e302797237098 = 1402308864874 := by decide
theorem cert_e302797237098 : check e302797237098 [[],[]] .three = true := by decide
def e302797237162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e302797237162 : Closed e302797237162 ∧ code e302797237162 = 1402308864938 := by decide
theorem cert_e302797237162 : check e302797237162 [[],[]] .three = true := by decide
def e302797237358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302797237358 : Closed e302797237358 ∧ code e302797237358 = 1402308865134 := by decide
theorem cert_e302797237358 : check e302797237358 [[],[]] .three = true := by decide
def e302797237366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e302797237366 : Closed e302797237366 ∧ code e302797237366 = 1402308865142 := by decide
theorem cert_e302797237366 : check e302797237366 [[],[]] .three = true := by decide
def e302797237370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302797237370 : Closed e302797237370 ∧ code e302797237370 = 1402308865146 := by decide
theorem cert_e302797237370 : check e302797237370 [[],[]] .three = true := by decide
def e302797237462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302797237462 : Closed e302797237462 ∧ code e302797237462 = 1402308865238 := by decide
theorem cert_e302797237462 : check e302797237462 [[],[]] .three = true := by decide
def e302797237466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302797237466 : Closed e302797237466 ∧ code e302797237466 = 1402308865242 := by decide
theorem cert_e302797237466 : check e302797237466 [[],[]] .three = true := by decide
def e302797237482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302797237482 : Closed e302797237482 ∧ code e302797237482 = 1402308865258 := by decide
theorem cert_e302797237482 : check e302797237482 [[],[]] .three = true := by decide
def e302797237534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302797237534 : Closed e302797237534 ∧ code e302797237534 = 1402308865310 := by decide
theorem cert_e302797237534 : check e302797237534 [[],[]] .three = true := by decide
def e302797237558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302797237558 : Closed e302797237558 ∧ code e302797237558 = 1402308865334 := by decide
theorem cert_e302797237558 : check e302797237558 [[],[]] .three = true := by decide
def e302797237562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302797237562 : Closed e302797237562 ∧ code e302797237562 = 1402308865338 := by decide
theorem cert_e302797237562 : check e302797237562 [[],[]] .three = true := by decide
def e302797237646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e302797237646 : Closed e302797237646 ∧ code e302797237646 = 1402308865422 := by decide
theorem cert_e302797237646 : check e302797237646 [[],[]] .three = true := by decide
def e302797237658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302797237658 : Closed e302797237658 ∧ code e302797237658 = 1402308865434 := by decide
theorem cert_e302797237658 : check e302797237658 [[],[]] .three = true := by decide
def e302797237702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302797237702 : Closed e302797237702 ∧ code e302797237702 = 1402308865478 := by decide
theorem cert_e302797237702 : check e302797237702 [[],[]] .three = true := by decide
def e302797237726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e302797237726 : Closed e302797237726 ∧ code e302797237726 = 1402308865502 := by decide
theorem cert_e302797237726 : check e302797237726 [[],[]] .three = true := by decide
def e302797237742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e302797237742 : Closed e302797237742 ∧ code e302797237742 = 1402308865518 := by decide
theorem cert_e302797237742 : check e302797237742 [[],[]] .three = true := by decide
def e302797237814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302797237814 : Closed e302797237814 ∧ code e302797237814 = 1402308865590 := by decide
theorem cert_e302797237814 : check e302797237814 [[],[]] .three = true := by decide
def e302797237818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302797237818 : Closed e302797237818 ∧ code e302797237818 = 1402308865594 := by decide
theorem cert_e302797237818 : check e302797237818 [[],[]] .three = true := by decide
def e302797237866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e302797237866 : Closed e302797237866 ∧ code e302797237866 = 1402308865642 := by decide
theorem cert_e302797237866 : check e302797237866 [[],[]] .three = true := by decide
def e302797237902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302797237902 : Closed e302797237902 ∧ code e302797237902 = 1402308865678 := by decide
theorem cert_e302797237902 : check e302797237902 [[],[]] .three = true := by decide
def e302797237914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302797237914 : Closed e302797237914 ∧ code e302797237914 = 1402308865690 := by decide
theorem cert_e302797237914 : check e302797237914 [[],[]] .three = true := by decide
def e302797237958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302797237958 : Closed e302797237958 ∧ code e302797237958 = 1402308865734 := by decide
theorem cert_e302797237958 : check e302797237958 [[],[]] .three = true := by decide
def e302797237998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e302797237998 : Closed e302797237998 ∧ code e302797237998 = 1402308865774 := by decide
theorem cert_e302797237998 : check e302797237998 [[],[]] .three = true := by decide
def e302797238042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302797238042 : Closed e302797238042 ∧ code e302797238042 = 1402308865818 := by decide
theorem cert_e302797238042 : check e302797238042 [[],[]] .three = true := by decide
def e302797238086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302797238086 : Closed e302797238086 ∧ code e302797238086 = 1402308865862 := by decide
theorem cert_e302797238086 : check e302797238086 [[],[]] .three = true := by decide
def e302797238110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e302797238110 : Closed e302797238110 ∧ code e302797238110 = 1402308865886 := by decide
theorem cert_e302797238110 : check e302797238110 [[],[]] .three = true := by decide
def e302797238126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e302797238126 : Closed e302797238126 ∧ code e302797238126 = 1402308865902 := by decide
theorem cert_e302797238126 : check e302797238126 [[],[]] .three = true := by decide
def e302797238134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e302797238134 : Closed e302797238134 ∧ code e302797238134 = 1402308865910 := by decide
theorem cert_e302797238134 : check e302797238134 [[],[]] .three = true := by decide
def e302797238138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e302797238138 : Closed e302797238138 ∧ code e302797238138 = 1402308865914 := by decide
theorem cert_e302797238138 : check e302797238138 [[],[]] .three = true := by decide
def e302797238190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e302797238190 : Closed e302797238190 ∧ code e302797238190 = 1402308865966 := by decide
theorem cert_e302797238190 : check e302797238190 [[],[]] .three = true := by decide
def e302797238202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e302797238202 : Closed e302797238202 ∧ code e302797238202 = 1402308865978 := by decide
theorem cert_e302797238202 : check e302797238202 [[],[]] .three = true := by decide
def e302797238510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e302797238510 : Closed e302797238510 ∧ code e302797238510 = 1402308866286 := by decide
theorem cert_e302797238510 : check e302797238510 [[],[]] .three = true := by decide
def e302797238518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e302797238518 : Closed e302797238518 ∧ code e302797238518 = 1402308866294 := by decide
theorem cert_e302797238518 : check e302797238518 [[],[]] .three = true := by decide
def e302797238998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302797238998 : Closed e302797238998 ∧ code e302797238998 = 1402308866774 := by decide
theorem cert_e302797238998 : check e302797238998 [[],[]] .three = true := by decide
def e302797239002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302797239002 : Closed e302797239002 ∧ code e302797239002 = 1402308866778 := by decide
theorem cert_e302797239002 : check e302797239002 [[],[]] .three = true := by decide
def e302797239018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302797239018 : Closed e302797239018 ∧ code e302797239018 = 1402308866794 := by decide
theorem cert_e302797239018 : check e302797239018 [[],[]] .three = true := by decide
def e302797239070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302797239070 : Closed e302797239070 ∧ code e302797239070 = 1402308866846 := by decide
theorem cert_e302797239070 : check e302797239070 [[],[]] .three = true := by decide
def e302797239094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302797239094 : Closed e302797239094 ∧ code e302797239094 = 1402308866870 := by decide
theorem cert_e302797239094 : check e302797239094 [[],[]] .three = true := by decide
def e302797239098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302797239098 : Closed e302797239098 ∧ code e302797239098 = 1402308866874 := by decide
theorem cert_e302797239098 : check e302797239098 [[],[]] .three = true := by decide
def e302797239182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e302797239182 : Closed e302797239182 ∧ code e302797239182 = 1402308866958 := by decide
theorem cert_e302797239182 : check e302797239182 [[],[]] .three = true := by decide
def e302797239194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302797239194 : Closed e302797239194 ∧ code e302797239194 = 1402308866970 := by decide
theorem cert_e302797239194 : check e302797239194 [[],[]] .three = true := by decide
def e302797239238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302797239238 : Closed e302797239238 ∧ code e302797239238 = 1402308867014 := by decide
theorem cert_e302797239238 : check e302797239238 [[],[]] .three = true := by decide
def e302797239262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e302797239262 : Closed e302797239262 ∧ code e302797239262 = 1402308867038 := by decide
theorem cert_e302797239262 : check e302797239262 [[],[]] .three = true := by decide
def e302797239278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e302797239278 : Closed e302797239278 ∧ code e302797239278 = 1402308867054 := by decide
theorem cert_e302797239278 : check e302797239278 [[],[]] .three = true := by decide
def e302797240438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e302797240438 : Closed e302797240438 ∧ code e302797240438 = 1402308868214 := by decide
theorem cert_e302797240438 : check e302797240438 [[],[]] .three = true := by decide
def e302797240682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e302797240682 : Closed e302797240682 ∧ code e302797240682 = 1402308868458 := by decide
theorem cert_e302797240682 : check e302797240682 [[],[]] .three = true := by decide
def e302797240718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302797240718 : Closed e302797240718 ∧ code e302797240718 = 1402308868494 := by decide
theorem cert_e302797240718 : check e302797240718 [[],[]] .three = true := by decide
def e302797240730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e302797240730 : Closed e302797240730 ∧ code e302797240730 = 1402308868506 := by decide
theorem cert_e302797240730 : check e302797240730 [[],[]] .three = true := by decide
def e302797240774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302797240774 : Closed e302797240774 ∧ code e302797240774 = 1402308868550 := by decide
theorem cert_e302797240774 : check e302797240774 [[],[]] .three = true := by decide
def e302797240814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e302797240814 : Closed e302797240814 ∧ code e302797240814 = 1402308868590 := by decide
theorem cert_e302797240814 : check e302797240814 [[],[]] .three = true := by decide
def e302797241542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302797241542 : Closed e302797241542 ∧ code e302797241542 = 1402308869318 := by decide
theorem cert_e302797241542 : check e302797241542 [[],[]] .three = true := by decide
def e302797241566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e302797241566 : Closed e302797241566 ∧ code e302797241566 = 1402308869342 := by decide
theorem cert_e302797241566 : check e302797241566 [[],[]] .three = true := by decide
def e302797241582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e302797241582 : Closed e302797241582 ∧ code e302797241582 = 1402308869358 := by decide
theorem cert_e302797241582 : check e302797241582 [[],[]] .three = true := by decide
def e302797241590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e302797241590 : Closed e302797241590 ∧ code e302797241590 = 1402308869366 := by decide
theorem cert_e302797241590 : check e302797241590 [[],[]] .three = true := by decide
def e302797241594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e302797241594 : Closed e302797241594 ∧ code e302797241594 = 1402308869370 := by decide
theorem cert_e302797241594 : check e302797241594 [[],[]] .three = true := by decide
def e302797241966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e302797241966 : Closed e302797241966 ∧ code e302797241966 = 1402308869742 := by decide
theorem cert_e302797241966 : check e302797241966 [[],[]] .three = true := by decide
def e302797241978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e302797241978 : Closed e302797241978 ∧ code e302797241978 = 1402308869754 := by decide
theorem cert_e302797241978 : check e302797241978 [[],[]] .three = true := by decide
def e302799760622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e302799760622 : Closed e302799760622 ∧ code e302799760622 = 1402311388398 := by decide
theorem cert_e302799760622 : check e302799760622 [[],[],[.under,.under]] .sourceHead = true := by decide
def e302799760630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e302799760630 : Closed e302799760630 ∧ code e302799760630 = 1402311388406 := by decide
theorem cert_e302799760630 : check e302799760630 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e302799762670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e302799762670 : Closed e302799762670 ∧ code e302799762670 = 1402311390446 := by decide
theorem cert_e302799762670 : check e302799762670 [[],[],[.under,.under]] .sourceHead = true := by decide
def e302799762678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e302799762678 : Closed e302799762678 ∧ code e302799762678 = 1402311390454 := by decide
theorem cert_e302799762678 : check e302799762678 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .chain = true := by decide
def e302799770862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e302799770862 : Closed e302799770862 ∧ code e302799770862 = 1402311398638 := by decide
theorem cert_e302799770862 : check e302799770862 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e302799770870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e302799770870 : Closed e302799770870 ∧ code e302799770870 = 1402311398646 := by decide
theorem cert_e302799770870 : check e302799770870 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] .identityHead = true := by decide
def e302799809774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302799809774 : Closed e302799809774 ∧ code e302799809774 = 1402311437550 := by decide
theorem cert_e302799809774 : checkPay e302799809774 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under]] = true := by decide
def e302799809782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302799809782 : Closed e302799809782 ∧ code e302799809782 = 1402311437558 := by decide
theorem cert_e302799809782 : check e302799809782 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302799811822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302799811822 : Closed e302799811822 ∧ code e302799811822 = 1402311439598 := by decide
theorem cert_e302799811822 : checkPay e302799811822 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under]] = true := by decide
def e302799811830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302799811830 : Closed e302799811830 ∧ code e302799811830 = 1402311439606 := by decide
theorem cert_e302799811830 : check e302799811830 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302799860974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302799860974 : Closed e302799860974 ∧ code e302799860974 = 1402311488750 := by decide
theorem cert_e302799860974 : check e302799860974 [[.left,.left],[.left,.left],[.left],[],[],[]] .identityHead = true := by decide
def e302799860982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302799860982 : Closed e302799860982 ∧ code e302799860982 = 1402311488758 := by decide
theorem cert_e302799860982 : checkPay e302799860982 [[.left,.left],[.left,.left],[.left],[],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[]] 0 [[],[.under,.under]] = true := by decide
def e302800800622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e302800800622 : Closed e302800800622 ∧ code e302800800622 = 1402312428398 := by decide
theorem cert_e302800800622 : check e302800800622 [[],[]] .chain = true := by decide
def e302800800630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e302800800630 : Closed e302800800630 ∧ code e302800800630 = 1402312428406 := by decide
theorem cert_e302800800630 : check e302800800630 [[],[]] .chain = true := by decide
def e302800800694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e302800800694 : Closed e302800800694 ∧ code e302800800694 = 1402312428470 := by decide
theorem cert_e302800800694 : check e302800800694 [[],[]] .chain = true := by decide
def e302800801134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e302800801134 : Closed e302800801134 ∧ code e302800801134 = 1402312428910 := by decide
theorem cert_e302800801134 : check e302800801134 [[],[]] .chain = true := by decide
def e302800801142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e302800801142 : Closed e302800801142 ∧ code e302800801142 = 1402312428918 := by decide
theorem cert_e302800801142 : check e302800801142 [[],[]] .chain = true := by decide
def e302800801198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e302800801198 : Closed e302800801198 ∧ code e302800801198 = 1402312428974 := by decide
theorem cert_e302800801198 : check e302800801198 [[],[]] .chain = true := by decide
def e302800801210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e302800801210 : Closed e302800801210 ∧ code e302800801210 = 1402312428986 := by decide
theorem cert_e302800801210 : check e302800801210 [[],[]] .chain = true := by decide
def e302800801238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e302800801238 : Closed e302800801238 ∧ code e302800801238 = 1402312429014 := by decide
theorem cert_e302800801238 : check e302800801238 [[],[]] .chain = true := by decide
end Blc.Floor40
