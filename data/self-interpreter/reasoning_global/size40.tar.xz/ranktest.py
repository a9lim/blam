from candidates import *
from regular40 import om
def profile(t,c):
    if t[0]=='V':return 0,{t[1]:0},True
    if t[0]=='L':
        b,m,ok=profile(t[1],c)
        return b+1,{k-1:v+1 for k,v in m.items() if k},ok and m.get(0,-1000)<=-c
    f,m,ok=profile(t[1],c);a,n,ok2=profile(t[2],c)
    return max(0,f-1,a-c),{k:max(m.get(k,-1000)-1,n.get(k,-1000)-c) for k in m.keys()|n.keys()},ok and ok2
if __name__=='__main__':
    done={}
    for s in open('open.txt').read().split():
        e=lc.decode(s)[0]
        for c in (1,2,3,4):
            for kind,t in [('raw',e),('D',A(e,om[1])),('DD',A(A(e,om[1]),om[1]))]:
                n,m,ok=profile(t,c)
                if n==0 and ok and kind!='DD':done[s]=(c,kind);break
            if s in done:break
    print(Counter(done.values()))
    for s in open('open.txt').read().split():
        if not (HERE/('r'+str(int(s,2))+'.json')).exists() or 'bottom1' in (HERE/('r'+str(int(s,2))+'.json')).read_text()[:80]:
            print(s,done.get(s))
    (HERE/'ranks.json').write_text(json.dumps(done))
