import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302820728094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302820728094 : Closed e302820728094 ∧ code e302820728094 = 1402332355870 := by decide
theorem cert_e302820728094 : check e302820728094 [[],[]] .chain = true := by decide
def e302820728262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302820728262 : Closed e302820728262 ∧ code e302820728262 = 1402332356038 := by decide
theorem cert_e302820728262 : check e302820728262 [[],[]] .chain = true := by decide
def e302820728374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302820728374 : Closed e302820728374 ∧ code e302820728374 = 1402332356150 := by decide
theorem cert_e302820728374 : check e302820728374 [[],[]] .chain = true := by decide
def e302820728378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302820728378 : Closed e302820728378 ∧ code e302820728378 = 1402332356154 := by decide
theorem cert_e302820728378 : check e302820728378 [[],[]] .chain = true := by decide
def e302820728462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302820728462 : Closed e302820728462 ∧ code e302820728462 = 1402332356238 := by decide
theorem cert_e302820728462 : check e302820728462 [[],[]] .chain = true := by decide
def e302820728518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302820728518 : Closed e302820728518 ∧ code e302820728518 = 1402332356294 := by decide
theorem cert_e302820728518 : check e302820728518 [[],[]] .chain = true := by decide
def e302820730654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302820730654 : Closed e302820730654 ∧ code e302820730654 = 1402332358430 := by decide
theorem cert_e302820730654 : check e302820730654 [[],[]] .chain = true := by decide
def e302820730766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302820730766 : Closed e302820730766 ∧ code e302820730766 = 1402332358542 := by decide
theorem cert_e302820730766 : check e302820730766 [[],[]] .chain = true := by decide
def e302820733150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302820733150 : Closed e302820733150 ∧ code e302820733150 = 1402332360926 := by decide
theorem cert_e302820733150 : check e302820733150 [[],[]] .chain = true := by decide
def e302820733178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302820733178 : Closed e302820733178 ∧ code e302820733178 = 1402332360954 := by decide
theorem cert_e302820733178 : check e302820733178 [[],[]] .chain = true := by decide
def e302820733726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302820733726 : Closed e302820733726 ∧ code e302820733726 = 1402332361502 := by decide
theorem cert_e302820733726 : check e302820733726 [[],[]] .chain = true := by decide
def e302820733894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302820733894 : Closed e302820733894 ∧ code e302820733894 = 1402332361670 := by decide
theorem cert_e302820733894 : check e302820733894 [[],[]] .chain = true := by decide
def e302820735086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302820735086 : Closed e302820735086 ∧ code e302820735086 = 1402332362862 := by decide
theorem cert_e302820735086 : check e302820735086 [[],[]] .chain = true := by decide
def e302820735098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302820735098 : Closed e302820735098 ∧ code e302820735098 = 1402332362874 := by decide
theorem cert_e302820735098 : check e302820735098 [[],[]] .chain = true := by decide
def e302820735374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302820735374 : Closed e302820735374 ∧ code e302820735374 = 1402332363150 := by decide
theorem cert_e302820735374 : check e302820735374 [[],[]] .chain = true := by decide
def e302820735430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302820735430 : Closed e302820735430 ∧ code e302820735430 = 1402332363206 := by decide
theorem cert_e302820735430 : check e302820735430 [[],[]] .chain = true := by decide
def e302820737902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302820737902 : Closed e302820737902 ∧ code e302820737902 = 1402332365678 := by decide
theorem cert_e302820737902 : check e302820737902 [[],[]] .chain = true := by decide
def e302820737914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302820737914 : Closed e302820737914 ∧ code e302820737914 = 1402332365690 := by decide
theorem cert_e302820737914 : check e302820737914 [[],[]] .chain = true := by decide
def e302820737966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302820737966 : Closed e302820737966 ∧ code e302820737966 = 1402332365742 := by decide
theorem cert_e302820737966 : check e302820737966 [[],[]] .chain = true := by decide
def e302820738026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302820738026 : Closed e302820738026 ∧ code e302820738026 = 1402332365802 := by decide
theorem cert_e302820738026 : check e302820738026 [[],[]] .chain = true := by decide
def e302820738670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302820738670 : Closed e302820738670 ∧ code e302820738670 = 1402332366446 := by decide
theorem cert_e302820738670 : check e302820738670 [[],[]] .chain = true := by decide
def e302820738682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302820738682 : Closed e302820738682 ∧ code e302820738682 = 1402332366458 := by decide
theorem cert_e302820738682 : check e302820738682 [[],[]] .chain = true := by decide
def e302820738970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302820738970 : Closed e302820738970 ∧ code e302820738970 = 1402332366746 := by decide
theorem cert_e302820738970 : check e302820738970 [[],[]] .chain = true := by decide
def e302820740206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302820740206 : Closed e302820740206 ∧ code e302820740206 = 1402332367982 := by decide
theorem cert_e302820740206 : check e302820740206 [[],[]] .chain = true := by decide
def e302820740218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302820740218 : Closed e302820740218 ∧ code e302820740218 = 1402332367994 := by decide
theorem cert_e302820740218 : check e302820740218 [[],[]] .chain = true := by decide
def e302820740382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302820740382 : Closed e302820740382 ∧ code e302820740382 = 1402332368158 := by decide
theorem cert_e302820740382 : check e302820740382 [[],[]] .chain = true := by decide
def e302820740550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302820740550 : Closed e302820740550 ∧ code e302820740550 = 1402332368326 := by decide
theorem cert_e302820740550 : check e302820740550 [[],[]] .chain = true := by decide
def e302820740890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302820740890 : Closed e302820740890 ∧ code e302820740890 = 1402332368666 := by decide
theorem cert_e302820740890 : check e302820740890 [[],[]] .chain = true := by decide
def e302820740934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302820740934 : Closed e302820740934 ∧ code e302820740934 = 1402332368710 := by decide
theorem cert_e302820740934 : check e302820740934 [[],[]] .chain = true := by decide
def e302820741342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302820741342 : Closed e302820741342 ∧ code e302820741342 = 1402332369118 := by decide
theorem cert_e302820741342 : check e302820741342 [[],[]] .chain = true := by decide
def e302820741370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302820741370 : Closed e302820741370 ∧ code e302820741370 = 1402332369146 := by decide
theorem cert_e302820741370 : check e302820741370 [[],[]] .chain = true := by decide
def e302820741918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302820741918 : Closed e302820741918 ∧ code e302820741918 = 1402332369694 := by decide
theorem cert_e302820741918 : check e302820741918 [[],[]] .chain = true := by decide
def e302820742086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302820742086 : Closed e302820742086 ∧ code e302820742086 = 1402332369862 := by decide
theorem cert_e302820742086 : check e302820742086 [[],[]] .chain = true := by decide
def e302820744246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302820744246 : Closed e302820744246 ∧ code e302820744246 = 1402332372022 := by decide
theorem cert_e302820744246 : check e302820744246 [[],[]] .chain = true := by decide
def e302820744250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302820744250 : Closed e302820744250 ∧ code e302820744250 = 1402332372026 := by decide
theorem cert_e302820744250 : check e302820744250 [[],[]] .chain = true := by decide
def e302820744390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302820744390 : Closed e302820744390 ∧ code e302820744390 = 1402332372166 := by decide
theorem cert_e302820744390 : check e302820744390 [[],[]] .chain = true := by decide
def e302820745654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e302820745654 : Closed e302820745654 ∧ code e302820745654 = 1402332373430 := by decide
theorem cert_e302820745654 : check e302820745654 [[],[]] .chain = true := by decide
def e302820745658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e302820745658 : Closed e302820745658 ∧ code e302820745658 = 1402332373434 := by decide
theorem cert_e302820745658 : check e302820745658 [[],[]] .chain = true := by decide
def e302820745686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e302820745686 : Closed e302820745686 ∧ code e302820745686 = 1402332373462 := by decide
theorem cert_e302820745686 : check e302820745686 [[],[]] .chain = true := by decide
def e302820745706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e302820745706 : Closed e302820745706 ∧ code e302820745706 = 1402332373482 := by decide
theorem cert_e302820745706 : check e302820745706 [[],[]] .chain = true := by decide
def e302820746038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e302820746038 : Closed e302820746038 ∧ code e302820746038 = 1402332373814 := by decide
theorem cert_e302820746038 : check e302820746038 [[],[]] .chain = true := by decide
def e302820746042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e302820746042 : Closed e302820746042 ∧ code e302820746042 = 1402332373818 := by decide
theorem cert_e302820746042 : check e302820746042 [[],[]] .chain = true := by decide
def e302820746138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e302820746138 : Closed e302820746138 ∧ code e302820746138 = 1402332373914 := by decide
theorem cert_e302820746138 : check e302820746138 [[],[]] .chain = true := by decide
def e302820746806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302820746806 : Closed e302820746806 ∧ code e302820746806 = 1402332374582 := by decide
theorem cert_e302820746806 : check e302820746806 [[],[]] .chain = true := by decide
def e302820746810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302820746810 : Closed e302820746810 ∧ code e302820746810 = 1402332374586 := by decide
theorem cert_e302820746810 : check e302820746810 [[],[]] .chain = true := by decide
def e302820746894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302820746894 : Closed e302820746894 ∧ code e302820746894 = 1402332374670 := by decide
theorem cert_e302820746894 : check e302820746894 [[],[]] .chain = true := by decide
def e302820746950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302820746950 : Closed e302820746950 ∧ code e302820746950 = 1402332374726 := by decide
theorem cert_e302820746950 : check e302820746950 [[],[]] .chain = true := by decide
def e302820747034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302820747034 : Closed e302820747034 ∧ code e302820747034 = 1402332374810 := by decide
theorem cert_e302820747034 : check e302820747034 [[],[]] .chain = true := by decide
def e302820747078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302820747078 : Closed e302820747078 ∧ code e302820747078 = 1402332374854 := by decide
theorem cert_e302820747078 : check e302820747078 [[],[]] .chain = true := by decide
def e302820747374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302820747374 : Closed e302820747374 ∧ code e302820747374 = 1402332375150 := by decide
theorem cert_e302820747374 : check e302820747374 [[],[]] .chain = true := by decide
def e302820747386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302820747386 : Closed e302820747386 ∧ code e302820747386 = 1402332375162 := by decide
theorem cert_e302820747386 : check e302820747386 [[],[]] .chain = true := by decide
def e302820747662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302820747662 : Closed e302820747662 ∧ code e302820747662 = 1402332375438 := by decide
theorem cert_e302820747662 : check e302820747662 [[],[]] .chain = true := by decide
def e302820747718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302820747718 : Closed e302820747718 ∧ code e302820747718 = 1402332375494 := by decide
theorem cert_e302820747718 : check e302820747718 [[],[]] .chain = true := by decide
def e302820748342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302820748342 : Closed e302820748342 ∧ code e302820748342 = 1402332376118 := by decide
theorem cert_e302820748342 : check e302820748342 [[],[]] .chain = true := by decide
def e302820748346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302820748346 : Closed e302820748346 ∧ code e302820748346 = 1402332376122 := by decide
theorem cert_e302820748346 : check e302820748346 [[],[]] .chain = true := by decide
def e302820748486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302820748486 : Closed e302820748486 ∧ code e302820748486 = 1402332376262 := by decide
theorem cert_e302820748486 : check e302820748486 [[],[]] .chain = true := by decide
def e302820759262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302820759262 : Closed e302820759262 ∧ code e302820759262 = 1402332387038 := by decide
theorem cert_e302820759262 : check e302820759262 [[],[]] .chain = true := by decide
def e302820759286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302820759286 : Closed e302820759286 ∧ code e302820759286 = 1402332387062 := by decide
theorem cert_e302820759286 : check e302820759286 [[],[]] .chain = true := by decide
def e302820759390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302820759390 : Closed e302820759390 ∧ code e302820759390 = 1402332387166 := by decide
theorem cert_e302820759390 : check e302820759390 [[],[]] .chain = true := by decide
def e302820759418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302820759418 : Closed e302820759418 ∧ code e302820759418 = 1402332387194 := by decide
theorem cert_e302820759418 : check e302820759418 [[],[]] .chain = true := by decide
def e302820759510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302820759510 : Closed e302820759510 ∧ code e302820759510 = 1402332387286 := by decide
theorem cert_e302820759510 : check e302820759510 [[],[]] .chain = true := by decide
def e302820759514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302820759514 : Closed e302820759514 ∧ code e302820759514 = 1402332387290 := by decide
theorem cert_e302820759514 : check e302820759514 [[],[]] .chain = true := by decide
def e302820760030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302820760030 : Closed e302820760030 ∧ code e302820760030 = 1402332387806 := by decide
theorem cert_e302820760030 : check e302820760030 [[],[]] .chain = true := by decide
def e302820760054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302820760054 : Closed e302820760054 ∧ code e302820760054 = 1402332387830 := by decide
theorem cert_e302820760054 : check e302820760054 [[],[]] .chain = true := by decide
def e302820760798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302820760798 : Closed e302820760798 ∧ code e302820760798 = 1402332388574 := by decide
theorem cert_e302820760798 : check e302820760798 [[],[]] .chain = true := by decide
def e302820760826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302820760826 : Closed e302820760826 ∧ code e302820760826 = 1402332388602 := by decide
theorem cert_e302820760826 : check e302820760826 [[],[]] .chain = true := by decide
def e302820761150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e302820761150 : Closed e302820761150 ∧ code e302820761150 = 1402332388926 := by decide
theorem cert_e302820761150 : check e302820761150 [[],[]] .chain = true := by decide
def e302820761374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e302820761374 : Closed e302820761374 ∧ code e302820761374 = 1402332389150 := by decide
theorem cert_e302820761374 : check e302820761374 [[],[]] .chain = true := by decide
def e302820761398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820761398 : Closed e302820761398 ∧ code e302820761398 = 1402332389174 := by decide
theorem cert_e302820761398 : check e302820761398 [[],[]] .chain = true := by decide
def e302820761402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820761402 : Closed e302820761402 ∧ code e302820761402 = 1402332389178 := by decide
theorem cert_e302820761402 : check e302820761402 [[],[]] .chain = true := by decide
def e302820776174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302820776174 : Closed e302820776174 ∧ code e302820776174 = 1402332403950 := by decide
theorem cert_e302820776174 : check e302820776174 [[],[]] .chain = true := by decide
def e302820776182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302820776182 : Closed e302820776182 ∧ code e302820776182 = 1402332403958 := by decide
theorem cert_e302820776182 : check e302820776182 [[],[]] .chain = true := by decide
def e302820776734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302820776734 : Closed e302820776734 ∧ code e302820776734 = 1402332404510 := by decide
theorem cert_e302820776734 : check e302820776734 [[],[]] .chain = true := by decide
def e302820776846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302820776846 : Closed e302820776846 ∧ code e302820776846 = 1402332404622 := by decide
theorem cert_e302820776846 : check e302820776846 [[],[]] .chain = true := by decide
def e302820777070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302820777070 : Closed e302820777070 ∧ code e302820777070 = 1402332404846 := by decide
theorem cert_e302820777070 : check e302820777070 [[],[]] .chain = true := by decide
def e302820777082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302820777082 : Closed e302820777082 ∧ code e302820777082 = 1402332404858 := by decide
theorem cert_e302820777082 : check e302820777082 [[],[]] .chain = true := by decide
def e302820777246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302820777246 : Closed e302820777246 ∧ code e302820777246 = 1402332405022 := by decide
theorem cert_e302820777246 : check e302820777246 [[],[]] .chain = true := by decide
def e302820777414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302820777414 : Closed e302820777414 ∧ code e302820777414 = 1402332405190 := by decide
theorem cert_e302820777414 : check e302820777414 [[],[]] .chain = true := by decide
def e302820777526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302820777526 : Closed e302820777526 ∧ code e302820777526 = 1402332405302 := by decide
theorem cert_e302820777526 : check e302820777526 [[],[]] .chain = true := by decide
def e302820777530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302820777530 : Closed e302820777530 ∧ code e302820777530 = 1402332405306 := by decide
theorem cert_e302820777530 : check e302820777530 [[],[]] .chain = true := by decide
def e302820777614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302820777614 : Closed e302820777614 ∧ code e302820777614 = 1402332405390 := by decide
theorem cert_e302820777614 : check e302820777614 [[],[]] .chain = true := by decide
def e302820777670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302820777670 : Closed e302820777670 ∧ code e302820777670 = 1402332405446 := by decide
theorem cert_e302820777670 : check e302820777670 [[],[]] .chain = true := by decide
def e302820779806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302820779806 : Closed e302820779806 ∧ code e302820779806 = 1402332407582 := by decide
theorem cert_e302820779806 : check e302820779806 [[],[]] .chain = true := by decide
def e302820779918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302820779918 : Closed e302820779918 ∧ code e302820779918 = 1402332407694 := by decide
theorem cert_e302820779918 : check e302820779918 [[],[]] .chain = true := by decide
def e302820782302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e302820782302 : Closed e302820782302 ∧ code e302820782302 = 1402332410078 := by decide
theorem cert_e302820782302 : check e302820782302 [[],[]] .chain = true := by decide
def e302820782330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e302820782330 : Closed e302820782330 ∧ code e302820782330 = 1402332410106 := by decide
theorem cert_e302820782330 : check e302820782330 [[],[]] .chain = true := by decide
def e302820782878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302820782878 : Closed e302820782878 ∧ code e302820782878 = 1402332410654 := by decide
theorem cert_e302820782878 : check e302820782878 [[],[]] .chain = true := by decide
def e302820783046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302820783046 : Closed e302820783046 ∧ code e302820783046 = 1402332410822 := by decide
theorem cert_e302820783046 : check e302820783046 [[],[]] .chain = true := by decide
def e302820784238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e302820784238 : Closed e302820784238 ∧ code e302820784238 = 1402332412014 := by decide
theorem cert_e302820784238 : check e302820784238 [[],[]] .chain = true := by decide
def e302820784250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e302820784250 : Closed e302820784250 ∧ code e302820784250 = 1402332412026 := by decide
theorem cert_e302820784250 : check e302820784250 [[],[]] .chain = true := by decide
def e302820784526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302820784526 : Closed e302820784526 ∧ code e302820784526 = 1402332412302 := by decide
theorem cert_e302820784526 : check e302820784526 [[],[]] .chain = true := by decide
def e302820784582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302820784582 : Closed e302820784582 ∧ code e302820784582 = 1402332412358 := by decide
theorem cert_e302820784582 : check e302820784582 [[],[]] .chain = true := by decide
def e302820821870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302820821870 : Closed e302820821870 ∧ code e302820821870 = 1402332449646 := by decide
theorem cert_e302820821870 : check e302820821870 [[],[]] .smaller = true := by decide
def e302820821878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302820821878 : Closed e302820821878 ∧ code e302820821878 = 1402332449654 := by decide
theorem cert_e302820821878 : check e302820821878 [[],[]] .smaller = true := by decide
def e302820821934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302820821934 : Closed e302820821934 ∧ code e302820821934 = 1402332449710 := by decide
theorem cert_e302820821934 : check e302820821934 [[],[]] .smaller = true := by decide
def e302820821946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302820821946 : Closed e302820821946 ∧ code e302820821946 = 1402332449722 := by decide
theorem cert_e302820821946 : check e302820821946 [[],[]] .smaller = true := by decide
def e302820821974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302820821974 : Closed e302820821974 ∧ code e302820821974 = 1402332449750 := by decide
theorem cert_e302820821974 : check e302820821974 [[],[]] .smaller = true := by decide
def e302820821978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302820821978 : Closed e302820821978 ∧ code e302820821978 = 1402332449754 := by decide
theorem cert_e302820821978 : check e302820821978 [[],[]] .smaller = true := by decide
def e302820822254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302820822254 : Closed e302820822254 ∧ code e302820822254 = 1402332450030 := by decide
theorem cert_e302820822254 : check e302820822254 [[],[]] .smaller = true := by decide
def e302820822262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302820822262 : Closed e302820822262 ∧ code e302820822262 = 1402332450038 := by decide
theorem cert_e302820822262 : check e302820822262 [[],[]] .smaller = true := by decide
def e302820822590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e302820822590 : Closed e302820822590 ∧ code e302820822590 = 1402332450366 := by decide
theorem cert_e302820822590 : check e302820822590 [[],[]] .chain = true := by decide
def e302820822638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302820822638 : Closed e302820822638 ∧ code e302820822638 = 1402332450414 := by decide
theorem cert_e302820822638 : check e302820822638 [[],[]] .smaller = true := by decide
def e302820822650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302820822650 : Closed e302820822650 ∧ code e302820822650 = 1402332450426 := by decide
theorem cert_e302820822650 : check e302820822650 [[],[]] .smaller = true := by decide
def e302820822838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820822838 : Closed e302820822838 ∧ code e302820822838 = 1402332450614 := by decide
theorem cert_e302820822838 : check e302820822838 [[],[]] .smaller = true := by decide
def e302820822842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820822842 : Closed e302820822842 ∧ code e302820822842 = 1402332450618 := by decide
theorem cert_e302820822842 : check e302820822842 [[],[]] .smaller = true := by decide
def e302820822926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e302820822926 : Closed e302820822926 ∧ code e302820822926 = 1402332450702 := by decide
theorem cert_e302820822926 : check e302820822926 [[],[]] .chain = true := by decide
def e302820830318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302820830318 : Closed e302820830318 ∧ code e302820830318 = 1402332458094 := by decide
theorem cert_e302820830318 : check e302820830318 [[],[]] .chain = true := by decide
def e302820830330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302820830330 : Closed e302820830330 ∧ code e302820830330 = 1402332458106 := by decide
theorem cert_e302820830330 : check e302820830330 [[],[]] .chain = true := by decide
def e302820830494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302820830494 : Closed e302820830494 ∧ code e302820830494 = 1402332458270 := by decide
theorem cert_e302820830494 : check e302820830494 [[],[]] .chain = true := by decide
def e302820830662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302820830662 : Closed e302820830662 ∧ code e302820830662 = 1402332458438 := by decide
theorem cert_e302820830662 : check e302820830662 [[],[]] .chain = true := by decide
def e302820831002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302820831002 : Closed e302820831002 ∧ code e302820831002 = 1402332458778 := by decide
theorem cert_e302820831002 : check e302820831002 [[],[]] .chain = true := by decide
def e302820831046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302820831046 : Closed e302820831046 ∧ code e302820831046 = 1402332458822 := by decide
theorem cert_e302820831046 : check e302820831046 [[],[]] .chain = true := by decide
def e302820831454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e302820831454 : Closed e302820831454 ∧ code e302820831454 = 1402332459230 := by decide
theorem cert_e302820831454 : check e302820831454 [[],[]] .chain = true := by decide
def e302820831482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e302820831482 : Closed e302820831482 ∧ code e302820831482 = 1402332459258 := by decide
theorem cert_e302820831482 : check e302820831482 [[],[]] .chain = true := by decide
def e302820832030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302820832030 : Closed e302820832030 ∧ code e302820832030 = 1402332459806 := by decide
theorem cert_e302820832030 : check e302820832030 [[],[]] .chain = true := by decide
def e302820832198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302820832198 : Closed e302820832198 ∧ code e302820832198 = 1402332459974 := by decide
theorem cert_e302820832198 : check e302820832198 [[],[]] .chain = true := by decide
def e302820834358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302820834358 : Closed e302820834358 ∧ code e302820834358 = 1402332462134 := by decide
theorem cert_e302820834358 : check e302820834358 [[],[]] .chain = true := by decide
def e302820834362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302820834362 : Closed e302820834362 ∧ code e302820834362 = 1402332462138 := by decide
theorem cert_e302820834362 : check e302820834362 [[],[]] .chain = true := by decide
def e302820834502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302820834502 : Closed e302820834502 ∧ code e302820834502 = 1402332462278 := by decide
theorem cert_e302820834502 : check e302820834502 [[],[]] .chain = true := by decide
def e302820853534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302820853534 : Closed e302820853534 ∧ code e302820853534 = 1402332481310 := by decide
theorem cert_e302820853534 : check e302820853534 [[],[]] .chain = true := by decide
def e302820853646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302820853646 : Closed e302820853646 ∧ code e302820853646 = 1402332481422 := by decide
theorem cert_e302820853646 : check e302820853646 [[],[]] .chain = true := by decide
def e302820857398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302820857398 : Closed e302820857398 ∧ code e302820857398 = 1402332485174 := by decide
theorem cert_e302820857398 : check e302820857398 [[],[]] .chain = true := by decide
def e302820857402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302820857402 : Closed e302820857402 ∧ code e302820857402 = 1402332485178 := by decide
theorem cert_e302820857402 : check e302820857402 [[],[]] .chain = true := by decide
def e302820857486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302820857486 : Closed e302820857486 ∧ code e302820857486 = 1402332485262 := by decide
theorem cert_e302820857486 : check e302820857486 [[],[]] .chain = true := by decide
def e302820857542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302820857542 : Closed e302820857542 ∧ code e302820857542 = 1402332485318 := by decide
theorem cert_e302820857542 : check e302820857542 [[],[]] .chain = true := by decide
def e302820857626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302820857626 : Closed e302820857626 ∧ code e302820857626 = 1402332485402 := by decide
theorem cert_e302820857626 : check e302820857626 [[],[]] .chain = true := by decide
def e302820857670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302820857670 : Closed e302820857670 ∧ code e302820857670 = 1402332485446 := by decide
theorem cert_e302820857670 : check e302820857670 [[],[]] .chain = true := by decide
def e302820857966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e302820857966 : Closed e302820857966 ∧ code e302820857966 = 1402332485742 := by decide
theorem cert_e302820857966 : check e302820857966 [[],[]] .chain = true := by decide
def e302820857978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e302820857978 : Closed e302820857978 ∧ code e302820857978 = 1402332485754 := by decide
theorem cert_e302820857978 : check e302820857978 [[],[]] .chain = true := by decide
def e302820858254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302820858254 : Closed e302820858254 ∧ code e302820858254 = 1402332486030 := by decide
theorem cert_e302820858254 : check e302820858254 [[],[]] .chain = true := by decide
def e302820858310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302820858310 : Closed e302820858310 ∧ code e302820858310 = 1402332486086 := by decide
theorem cert_e302820858310 : check e302820858310 [[],[]] .chain = true := by decide
def e302820858934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302820858934 : Closed e302820858934 ∧ code e302820858934 = 1402332486710 := by decide
theorem cert_e302820858934 : check e302820858934 [[],[]] .chain = true := by decide
def e302820858938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302820858938 : Closed e302820858938 ∧ code e302820858938 = 1402332486714 := by decide
theorem cert_e302820858938 : check e302820858938 [[],[]] .chain = true := by decide
def e302820859078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302820859078 : Closed e302820859078 ∧ code e302820859078 = 1402332486854 := by decide
theorem cert_e302820859078 : check e302820859078 [[],[]] .chain = true := by decide
def e302821938910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302821938910 : Closed e302821938910 ∧ code e302821938910 = 1402333566686 := by decide
theorem cert_e302821938910 : check e302821938910 [[],[]] .chain = true := by decide
def e302821938934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302821938934 : Closed e302821938934 ∧ code e302821938934 = 1402333566710 := by decide
theorem cert_e302821938934 : check e302821938934 [[],[]] .chain = true := by decide
def e302821939038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302821939038 : Closed e302821939038 ∧ code e302821939038 = 1402333566814 := by decide
theorem cert_e302821939038 : check e302821939038 [[],[]] .chain = true := by decide
def e302821939066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302821939066 : Closed e302821939066 ∧ code e302821939066 = 1402333566842 := by decide
theorem cert_e302821939066 : check e302821939066 [[],[]] .chain = true := by decide
def e302821939158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302821939158 : Closed e302821939158 ∧ code e302821939158 = 1402333566934 := by decide
theorem cert_e302821939158 : check e302821939158 [[],[]] .chain = true := by decide
def e302821939162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302821939162 : Closed e302821939162 ∧ code e302821939162 = 1402333566938 := by decide
theorem cert_e302821939162 : check e302821939162 [[],[]] .chain = true := by decide
def e302821939678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302821939678 : Closed e302821939678 ∧ code e302821939678 = 1402333567454 := by decide
theorem cert_e302821939678 : check e302821939678 [[],[]] .chain = true := by decide
def e302821939702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302821939702 : Closed e302821939702 ∧ code e302821939702 = 1402333567478 := by decide
theorem cert_e302821939702 : check e302821939702 [[],[]] .chain = true := by decide
def e302821940446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302821940446 : Closed e302821940446 ∧ code e302821940446 = 1402333568222 := by decide
theorem cert_e302821940446 : check e302821940446 [[],[]] .chain = true := by decide
def e302821940474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302821940474 : Closed e302821940474 ∧ code e302821940474 = 1402333568250 := by decide
theorem cert_e302821940474 : check e302821940474 [[],[]] .chain = true := by decide
def e302821941046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302821941046 : Closed e302821941046 ∧ code e302821941046 = 1402333568822 := by decide
theorem cert_e302821941046 : check e302821941046 [[],[]] .chain = true := by decide
def e302821941050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302821941050 : Closed e302821941050 ∧ code e302821941050 = 1402333568826 := by decide
theorem cert_e302821941050 : check e302821941050 [[],[]] .chain = true := by decide
def e302821955822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302821955822 : Closed e302821955822 ∧ code e302821955822 = 1402333583598 := by decide
theorem cert_e302821955822 : check e302821955822 [[],[]] .chain = true := by decide
def e302821955830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302821955830 : Closed e302821955830 ∧ code e302821955830 = 1402333583606 := by decide
theorem cert_e302821955830 : check e302821955830 [[],[]] .chain = true := by decide
def e302821956382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302821956382 : Closed e302821956382 ∧ code e302821956382 = 1402333584158 := by decide
theorem cert_e302821956382 : check e302821956382 [[],[]] .chain = true := by decide
def e302821956494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302821956494 : Closed e302821956494 ∧ code e302821956494 = 1402333584270 := by decide
theorem cert_e302821956494 : check e302821956494 [[],[]] .chain = true := by decide
def e302821956718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302821956718 : Closed e302821956718 ∧ code e302821956718 = 1402333584494 := by decide
theorem cert_e302821956718 : check e302821956718 [[],[]] .chain = true := by decide
def e302821956730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302821956730 : Closed e302821956730 ∧ code e302821956730 = 1402333584506 := by decide
theorem cert_e302821956730 : check e302821956730 [[],[]] .chain = true := by decide
def e302821956894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302821956894 : Closed e302821956894 ∧ code e302821956894 = 1402333584670 := by decide
theorem cert_e302821956894 : check e302821956894 [[],[]] .chain = true := by decide
def e302821957062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302821957062 : Closed e302821957062 ∧ code e302821957062 = 1402333584838 := by decide
theorem cert_e302821957062 : check e302821957062 [[],[]] .chain = true := by decide
def e302821957174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302821957174 : Closed e302821957174 ∧ code e302821957174 = 1402333584950 := by decide
theorem cert_e302821957174 : check e302821957174 [[],[]] .chain = true := by decide
def e302821957178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302821957178 : Closed e302821957178 ∧ code e302821957178 = 1402333584954 := by decide
theorem cert_e302821957178 : check e302821957178 [[],[]] .chain = true := by decide
def e302821957262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302821957262 : Closed e302821957262 ∧ code e302821957262 = 1402333585038 := by decide
theorem cert_e302821957262 : check e302821957262 [[],[]] .chain = true := by decide
def e302821957318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302821957318 : Closed e302821957318 ∧ code e302821957318 = 1402333585094 := by decide
theorem cert_e302821957318 : check e302821957318 [[],[]] .chain = true := by decide
def e302821959454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302821959454 : Closed e302821959454 ∧ code e302821959454 = 1402333587230 := by decide
theorem cert_e302821959454 : check e302821959454 [[],[]] .chain = true := by decide
def e302821959566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302821959566 : Closed e302821959566 ∧ code e302821959566 = 1402333587342 := by decide
theorem cert_e302821959566 : check e302821959566 [[],[]] .chain = true := by decide
end Blc.Floor40
