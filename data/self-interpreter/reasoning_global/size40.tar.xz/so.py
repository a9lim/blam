from regular40 import *
def slots(b,d=1):
    if tFree:=free(b):
        if min(tFree)>=d:yield lc.shift(-d,0,b)
    if b[0]=='L':yield from slots(b[1],d+1)
    if b[0]=='A':
        yield from slots(b[1],d);yield from slots(b[2],d)
def recover(b,r,d=1):
    if b==lc.shift(d,0,r):return V(d)
    if b[0]=='V':return b if b[1]<d else None
    if b[0]=='L':
        v=recover(b[1],r,d+1)
        return L(v) if v else None
    x=recover(b[1],r,d);y=recover(b[2],r,d)
    return A(x,y) if x and y else None
@lru_cache(10000)
def so(t):
    if t[0]=='V':return ('var',)
    if t[0]=='A':return ('app',) if so(t[1]) and so(t[2]) else None
    b=t[1]
    if not so(b):return None
    if not free(t):return ('closed',)
    if not occ(b):return ('dead',)
    for r in slots(b):
        if (g:=recover(b,r)) and so(r):
            return ('obj',r,g)
    return None
if __name__=='__main__':
    for s in open('open.txt').read().split():
        if (HERE/('r'+str(int(s,2))+'.json')).exists() and 'bottom1' not in (HERE/('r'+str(int(s,2))+'.json')).read_text()[:120]:continue
        e=lc.decode(s)[0];res=None
        for mode,t in [('src',e),('K',A(e,L(L(V(1)))))]:
            ps=[]
            for _ in range(32):
                if so(t):res=(mode,ps);break
                p=normal_path(t)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps.append(p)
            if res:break
        print(s,res)
