import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302818359866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 0)))))
theorem wire_e302818359866 : Closed e302818359866 ∧ code e302818359866 = 1402329987642 := by decide
theorem cert_e302818359866 : check e302818359866 [[],[]] .chain = true := by decide
def e302818360006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 1))))))
theorem wire_e302818360006 : Closed e302818360006 ∧ code e302818360006 = 1402329987782 := by decide
theorem cert_e302818360006 : check e302818360006 [[],[]] .chain = true := by decide
def e302818360090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 0)))))
theorem wire_e302818360090 : Closed e302818360090 ∧ code e302818360090 = 1402329987866 := by decide
theorem cert_e302818360090 : check e302818360090 [[],[]] .chain = true := by decide
def e302818360134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 1))))))
theorem wire_e302818360134 : Closed e302818360134 ∧ code e302818360134 = 1402329987910 := by decide
theorem cert_e302818360134 : check e302818360134 [[],[]] .chain = true := by decide
def e302818368634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e302818368634 : Closed e302818368634 ∧ code e302818368634 = 1402329996410 := by decide
theorem cert_e302818368634 : check e302818368634 [[],[]] .chain = true := by decide
def e302818368966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 1))))))
theorem wire_e302818368966 : Closed e302818368966 ∧ code e302818368966 = 1402329996742 := by decide
theorem cert_e302818368966 : check e302818368966 [[],[]] .chain = true := by decide
def e302818369082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e302818369082 : Closed e302818369082 ∧ code e302818369082 = 1402329996858 := by decide
theorem cert_e302818369082 : check e302818369082 [[],[]] .chain = true := by decide
def e302818369222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 1))))))
theorem wire_e302818369222 : Closed e302818369222 ∧ code e302818369222 = 1402329996998 := by decide
theorem cert_e302818369222 : check e302818369222 [[],[]] .chain = true := by decide
def e302818380922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e302818380922 : Closed e302818380922 ∧ code e302818380922 = 1402330008698 := by decide
theorem cert_e302818380922 : check e302818380922 [[],[]] .chain = true := by decide
def e302818381254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 1))))))
theorem wire_e302818381254 : Closed e302818381254 ∧ code e302818381254 = 1402330009030 := by decide
theorem cert_e302818381254 : check e302818381254 [[],[]] .chain = true := by decide
def e302818381594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e302818381594 : Closed e302818381594 ∧ code e302818381594 = 1402330009370 := by decide
theorem cert_e302818381594 : check e302818381594 [[],[]] .chain = true := by decide
def e302818381638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 1))))))
theorem wire_e302818381638 : Closed e302818381638 ∧ code e302818381638 = 1402330009414 := by decide
theorem cert_e302818381638 : check e302818381638 [[],[]] .chain = true := by decide
def e302818387514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e302818387514 : Closed e302818387514 ∧ code e302818387514 = 1402330015290 := by decide
theorem cert_e302818387514 : check e302818387514 [[],[]] .chain = true := by decide
def e302818387654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 1))))))
theorem wire_e302818387654 : Closed e302818387654 ∧ code e302818387654 = 1402330015430 := by decide
theorem cert_e302818387654 : check e302818387654 [[],[]] .chain = true := by decide
def e302818387738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e302818387738 : Closed e302818387738 ∧ code e302818387738 = 1402330015514 := by decide
theorem cert_e302818387738 : check e302818387738 [[],[]] .chain = true := by decide
def e302818387782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 1))))))
theorem wire_e302818387782 : Closed e302818387782 ∧ code e302818387782 = 1402330015558 := by decide
theorem cert_e302818387782 : check e302818387782 [[],[]] .chain = true := by decide
def e302818462574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302818462574 : Closed e302818462574 ∧ code e302818462574 = 1402330090350 := by decide
theorem cert_e302818462574 : check e302818462574 [[],[]] .chain = true := by decide
def e302818462582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302818462582 : Closed e302818462582 ∧ code e302818462582 = 1402330090358 := by decide
theorem cert_e302818462582 : check e302818462582 [[],[]] .chain = true := by decide
def e302818462638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302818462638 : Closed e302818462638 ∧ code e302818462638 = 1402330090414 := by decide
theorem cert_e302818462638 : check e302818462638 [[],[]] .chain = true := by decide
def e302818462650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302818462650 : Closed e302818462650 ∧ code e302818462650 = 1402330090426 := by decide
theorem cert_e302818462650 : check e302818462650 [[],[]] .chain = true := by decide
def e302818462678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302818462678 : Closed e302818462678 ∧ code e302818462678 = 1402330090454 := by decide
theorem cert_e302818462678 : check e302818462678 [[],[]] .chain = true := by decide
def e302818462682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302818462682 : Closed e302818462682 ∧ code e302818462682 = 1402330090458 := by decide
theorem cert_e302818462682 : check e302818462682 [[],[]] .chain = true := by decide
def e302818462958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302818462958 : Closed e302818462958 ∧ code e302818462958 = 1402330090734 := by decide
theorem cert_e302818462958 : check e302818462958 [[],[]] .chain = true := by decide
def e302818462966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302818462966 : Closed e302818462966 ∧ code e302818462966 = 1402330090742 := by decide
theorem cert_e302818462966 : check e302818462966 [[],[]] .chain = true := by decide
def e302818463342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302818463342 : Closed e302818463342 ∧ code e302818463342 = 1402330091118 := by decide
theorem cert_e302818463342 : check e302818463342 [[],[]] .chain = true := by decide
def e302818463354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302818463354 : Closed e302818463354 ∧ code e302818463354 = 1402330091130 := by decide
theorem cert_e302818463354 : check e302818463354 [[],[]] .chain = true := by decide
def e302818463542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302818463542 : Closed e302818463542 ∧ code e302818463542 = 1402330091318 := by decide
theorem cert_e302818463542 : check e302818463542 [[],[]] .chain = true := by decide
def e302818463546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302818463546 : Closed e302818463546 ∧ code e302818463546 = 1402330091322 := by decide
theorem cert_e302818463546 : check e302818463546 [[],[]] .chain = true := by decide
def e302818793182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302818793182 : Closed e302818793182 ∧ code e302818793182 = 1402330420958 := by decide
theorem cert_e302818793182 : check e302818793182 [[],[]] .chain = true := by decide
def e302818793206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302818793206 : Closed e302818793206 ∧ code e302818793206 = 1402330420982 := by decide
theorem cert_e302818793206 : check e302818793206 [[],[]] .chain = true := by decide
def e302818793310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302818793310 : Closed e302818793310 ∧ code e302818793310 = 1402330421086 := by decide
theorem cert_e302818793310 : check e302818793310 [[],[]] .chain = true := by decide
def e302818793338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302818793338 : Closed e302818793338 ∧ code e302818793338 = 1402330421114 := by decide
theorem cert_e302818793338 : check e302818793338 [[],[]] .chain = true := by decide
def e302818793430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302818793430 : Closed e302818793430 ∧ code e302818793430 = 1402330421206 := by decide
theorem cert_e302818793430 : check e302818793430 [[],[]] .chain = true := by decide
def e302818793434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302818793434 : Closed e302818793434 ∧ code e302818793434 = 1402330421210 := by decide
theorem cert_e302818793434 : check e302818793434 [[],[]] .chain = true := by decide
def e302818793950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302818793950 : Closed e302818793950 ∧ code e302818793950 = 1402330421726 := by decide
theorem cert_e302818793950 : check e302818793950 [[],[]] .chain = true := by decide
def e302818793974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302818793974 : Closed e302818793974 ∧ code e302818793974 = 1402330421750 := by decide
theorem cert_e302818793974 : check e302818793974 [[],[]] .chain = true := by decide
def e302818794718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302818794718 : Closed e302818794718 ∧ code e302818794718 = 1402330422494 := by decide
theorem cert_e302818794718 : check e302818794718 [[],[]] .chain = true := by decide
def e302818794746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302818794746 : Closed e302818794746 ∧ code e302818794746 = 1402330422522 := by decide
theorem cert_e302818794746 : check e302818794746 [[],[]] .chain = true := by decide
def e302818795318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302818795318 : Closed e302818795318 ∧ code e302818795318 = 1402330423094 := by decide
theorem cert_e302818795318 : check e302818795318 [[],[]] .chain = true := by decide
def e302818795322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302818795322 : Closed e302818795322 ∧ code e302818795322 = 1402330423098 := by decide
theorem cert_e302818795322 : check e302818795322 [[],[]] .chain = true := by decide
def e302818810094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302818810094 : Closed e302818810094 ∧ code e302818810094 = 1402330437870 := by decide
theorem cert_e302818810094 : check e302818810094 [[],[]] .chain = true := by decide
def e302818810102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302818810102 : Closed e302818810102 ∧ code e302818810102 = 1402330437878 := by decide
theorem cert_e302818810102 : check e302818810102 [[],[]] .chain = true := by decide
def e302818810654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302818810654 : Closed e302818810654 ∧ code e302818810654 = 1402330438430 := by decide
theorem cert_e302818810654 : check e302818810654 [[],[]] .chain = true := by decide
def e302818810766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302818810766 : Closed e302818810766 ∧ code e302818810766 = 1402330438542 := by decide
theorem cert_e302818810766 : check e302818810766 [[],[]] .chain = true := by decide
def e302818810990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302818810990 : Closed e302818810990 ∧ code e302818810990 = 1402330438766 := by decide
theorem cert_e302818810990 : check e302818810990 [[],[]] .chain = true := by decide
def e302818811002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302818811002 : Closed e302818811002 ∧ code e302818811002 = 1402330438778 := by decide
theorem cert_e302818811002 : check e302818811002 [[],[]] .chain = true := by decide
def e302818811166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302818811166 : Closed e302818811166 ∧ code e302818811166 = 1402330438942 := by decide
theorem cert_e302818811166 : check e302818811166 [[],[]] .chain = true := by decide
def e302818811334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302818811334 : Closed e302818811334 ∧ code e302818811334 = 1402330439110 := by decide
theorem cert_e302818811334 : check e302818811334 [[],[]] .chain = true := by decide
def e302818811446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302818811446 : Closed e302818811446 ∧ code e302818811446 = 1402330439222 := by decide
theorem cert_e302818811446 : check e302818811446 [[],[]] .chain = true := by decide
def e302818811450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302818811450 : Closed e302818811450 ∧ code e302818811450 = 1402330439226 := by decide
theorem cert_e302818811450 : check e302818811450 [[],[]] .chain = true := by decide
def e302818811534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302818811534 : Closed e302818811534 ∧ code e302818811534 = 1402330439310 := by decide
theorem cert_e302818811534 : check e302818811534 [[],[]] .chain = true := by decide
def e302818811590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302818811590 : Closed e302818811590 ∧ code e302818811590 = 1402330439366 := by decide
theorem cert_e302818811590 : check e302818811590 [[],[]] .chain = true := by decide
def e302818813726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302818813726 : Closed e302818813726 ∧ code e302818813726 = 1402330441502 := by decide
theorem cert_e302818813726 : check e302818813726 [[],[]] .chain = true := by decide
def e302818813838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302818813838 : Closed e302818813838 ∧ code e302818813838 = 1402330441614 := by decide
theorem cert_e302818813838 : check e302818813838 [[],[]] .chain = true := by decide
def e302818816798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302818816798 : Closed e302818816798 ∧ code e302818816798 = 1402330444574 := by decide
theorem cert_e302818816798 : check e302818816798 [[],[]] .chain = true := by decide
def e302818816966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302818816966 : Closed e302818816966 ∧ code e302818816966 = 1402330444742 := by decide
theorem cert_e302818816966 : check e302818816966 [[],[]] .chain = true := by decide
def e302818818446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302818818446 : Closed e302818818446 ∧ code e302818818446 = 1402330446222 := by decide
theorem cert_e302818818446 : check e302818818446 [[],[]] .chain = true := by decide
def e302818818502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302818818502 : Closed e302818818502 ∧ code e302818818502 = 1402330446278 := by decide
theorem cert_e302818818502 : check e302818818502 [[],[]] .chain = true := by decide
def e302819052398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302819052398 : Closed e302819052398 ∧ code e302819052398 = 1402330680174 := by decide
theorem cert_e302819052398 : check e302819052398 [[],[]] .chain = true := by decide
def e302819052406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302819052406 : Closed e302819052406 ∧ code e302819052406 = 1402330680182 := by decide
theorem cert_e302819052406 : check e302819052406 [[],[]] .chain = true := by decide
def e302819052462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302819052462 : Closed e302819052462 ∧ code e302819052462 = 1402330680238 := by decide
theorem cert_e302819052462 : check e302819052462 [[],[]] .chain = true := by decide
def e302819052474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302819052474 : Closed e302819052474 ∧ code e302819052474 = 1402330680250 := by decide
theorem cert_e302819052474 : check e302819052474 [[],[]] .chain = true := by decide
def e302819052502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302819052502 : Closed e302819052502 ∧ code e302819052502 = 1402330680278 := by decide
theorem cert_e302819052502 : check e302819052502 [[],[]] .chain = true := by decide
def e302819052506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302819052506 : Closed e302819052506 ∧ code e302819052506 = 1402330680282 := by decide
theorem cert_e302819052506 : check e302819052506 [[],[]] .chain = true := by decide
def e302819052782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302819052782 : Closed e302819052782 ∧ code e302819052782 = 1402330680558 := by decide
theorem cert_e302819052782 : check e302819052782 [[],[]] .chain = true := by decide
def e302819052790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302819052790 : Closed e302819052790 ∧ code e302819052790 = 1402330680566 := by decide
theorem cert_e302819052790 : check e302819052790 [[],[]] .chain = true := by decide
def e302819053166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302819053166 : Closed e302819053166 ∧ code e302819053166 = 1402330680942 := by decide
theorem cert_e302819053166 : check e302819053166 [[],[]] .chain = true := by decide
def e302819053178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302819053178 : Closed e302819053178 ∧ code e302819053178 = 1402330680954 := by decide
theorem cert_e302819053178 : check e302819053178 [[],[]] .chain = true := by decide
def e302819053366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302819053366 : Closed e302819053366 ∧ code e302819053366 = 1402330681142 := by decide
theorem cert_e302819053366 : check e302819053366 [[],[]] .chain = true := by decide
def e302819053370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302819053370 : Closed e302819053370 ∧ code e302819053370 = 1402330681146 := by decide
theorem cert_e302819053370 : check e302819053370 [[],[]] .chain = true := by decide
def e302819323322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e302819323322 : Closed e302819323322 ∧ code e302819323322 = 1402330951098 := by decide
theorem cert_e302819323322 : check e302819323322 [[],[]] .chain = true := by decide
def e302819323354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e302819323354 : Closed e302819323354 ∧ code e302819323354 = 1402330951130 := by decide
theorem cert_e302819323354 : check e302819323354 [[],[]] .chain = true := by decide
def e302819323578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e302819323578 : Closed e302819323578 ∧ code e302819323578 = 1402330951354 := by decide
theorem cert_e302819323578 : check e302819323578 [[],[]] .chain = true := by decide
def e302819323626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e302819323626 : Closed e302819323626 ∧ code e302819323626 = 1402330951402 := by decide
theorem cert_e302819323626 : check e302819323626 [[],[]] .chain = true := by decide
def e302819323738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e302819323738 : Closed e302819323738 ∧ code e302819323738 = 1402330951514 := by decide
theorem cert_e302819323738 : check e302819323738 [[],[]] .chain = true := by decide
def e302819323754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e302819323754 : Closed e302819323754 ∧ code e302819323754 = 1402330951530 := by decide
theorem cert_e302819323754 : check e302819323754 [[],[]] .chain = true := by decide
def e302819324858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e302819324858 : Closed e302819324858 ∧ code e302819324858 = 1402330952634 := by decide
theorem cert_e302819324858 : check e302819324858 [[],[]] .chain = true := by decide
def e302819324890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e302819324890 : Closed e302819324890 ∧ code e302819324890 = 1402330952666 := by decide
theorem cert_e302819324890 : check e302819324890 [[],[]] .chain = true := by decide
def e302819326394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e302819326394 : Closed e302819326394 ∧ code e302819326394 = 1402330954170 := by decide
theorem cert_e302819326394 : check e302819326394 [[],[]] .chain = true := by decide
def e302819326442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e302819326442 : Closed e302819326442 ∧ code e302819326442 = 1402330954218 := by decide
theorem cert_e302819326442 : check e302819326442 [[],[]] .chain = true := by decide
def e302819327194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e302819327194 : Closed e302819327194 ∧ code e302819327194 = 1402330954970 := by decide
theorem cert_e302819327194 : check e302819327194 [[],[]] .chain = true := by decide
def e302819327210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e302819327210 : Closed e302819327210 ∧ code e302819327210 = 1402330954986 := by decide
theorem cert_e302819327210 : check e302819327210 [[],[]] .chain = true := by decide
def e302819358434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e302819358434 : Closed e302819358434 ∧ code e302819358434 = 1402330986210 := by decide
theorem cert_e302819358434 : check e302819358434 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e302819358562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e302819358562 : Closed e302819358562 ∧ code e302819358562 = 1402330986338 := by decide
private def t_e302819358562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))
theorem cert_e302819358562 : ¬ IsSelfInterpreter e302819358562 :=
  wSource (t := t_e302819358562) (replay_sound (ps := []) (t := e302819358562) (by decide)) (by decide)
def e302819359458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e302819359458 : Closed e302819359458 ∧ code e302819359458 = 1402330987234 := by decide
theorem cert_e302819359458 : check e302819359458 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e302819359650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e302819359650 : Closed e302819359650 ∧ code e302819359650 = 1402330987426 := by decide
theorem cert_e302819359650 : check e302819359650 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e302819360098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e302819360098 : Closed e302819360098 ∧ code e302819360098 = 1402330987874 := by decide
private def t_e302819360098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))
theorem cert_e302819360098 : ¬ IsSelfInterpreter e302819360098 :=
  wSource (t := t_e302819360098) (replay_sound (ps := []) (t := e302819360098) (by decide)) (by decide)
def e302819360162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e302819360162 : Closed e302819360162 ∧ code e302819360162 = 1402330987938 := by decide
theorem cert_e302819360162 : check e302819360162 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e302819364578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))))
theorem wire_e302819364578 : Closed e302819364578 ∧ code e302819364578 = 1402330992354 := by decide
theorem cert_e302819364578 : check e302819364578 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e302819364706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))))
theorem wire_e302819364706 : Closed e302819364706 ∧ code e302819364706 = 1402330992482 := by decide
theorem cert_e302819364706 : check e302819364706 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e302819370722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))))
theorem wire_e302819370722 : Closed e302819370722 ∧ code e302819370722 = 1402330998498 := by decide
theorem cert_e302819370722 : check e302819370722 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e302819370914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))))
theorem wire_e302819370914 : Closed e302819370914 ∧ code e302819370914 = 1402330998690 := by decide
theorem cert_e302819370914 : check e302819370914 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e302819373922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))))
theorem wire_e302819373922 : Closed e302819373922 ∧ code e302819373922 = 1402331001698 := by decide
theorem cert_e302819373922 : check e302819373922 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e302819373986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))))
theorem wire_e302819373986 : Closed e302819373986 ∧ code e302819373986 = 1402331001762 := by decide
theorem cert_e302819373986 : check e302819373986 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e302819380078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302819380078 : Closed e302819380078 ∧ code e302819380078 = 1402331007854 := by decide
theorem cert_e302819380078 : check e302819380078 [[],[],[.under,.left]] .chain = true := by decide
def e302819380086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302819380086 : Closed e302819380086 ∧ code e302819380086 = 1402331007862 := by decide
theorem cert_e302819380086 : check e302819380086 [[],[],[.under,.left]] .chain = true := by decide
def e302819380142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302819380142 : Closed e302819380142 ∧ code e302819380142 = 1402331007918 := by decide
theorem cert_e302819380142 : check e302819380142 [[],[],[.under,.left]] .chain = true := by decide
def e302819380154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302819380154 : Closed e302819380154 ∧ code e302819380154 = 1402331007930 := by decide
theorem cert_e302819380154 : check e302819380154 [[],[],[.under,.left]] .chain = true := by decide
def e302819380182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302819380182 : Closed e302819380182 ∧ code e302819380182 = 1402331007958 := by decide
theorem cert_e302819380182 : check e302819380182 [[],[],[.under,.left]] .chain = true := by decide
def e302819380186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302819380186 : Closed e302819380186 ∧ code e302819380186 = 1402331007962 := by decide
theorem cert_e302819380186 : check e302819380186 [[],[],[.under,.left]] .chain = true := by decide
def e302819380462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302819380462 : Closed e302819380462 ∧ code e302819380462 = 1402331008238 := by decide
theorem cert_e302819380462 : check e302819380462 [[],[],[.under,.left]] .chain = true := by decide
def e302819380470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302819380470 : Closed e302819380470 ∧ code e302819380470 = 1402331008246 := by decide
theorem cert_e302819380470 : check e302819380470 [[],[],[.under,.left]] .chain = true := by decide
def e302819380846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302819380846 : Closed e302819380846 ∧ code e302819380846 = 1402331008622 := by decide
theorem cert_e302819380846 : check e302819380846 [[],[],[.under,.left]] .chain = true := by decide
def e302819380858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302819380858 : Closed e302819380858 ∧ code e302819380858 = 1402331008634 := by decide
theorem cert_e302819380858 : check e302819380858 [[],[],[.under,.left]] .chain = true := by decide
def e302819381046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302819381046 : Closed e302819381046 ∧ code e302819381046 = 1402331008822 := by decide
theorem cert_e302819381046 : check e302819381046 [[],[],[.under,.left]] .chain = true := by decide
def e302819381050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302819381050 : Closed e302819381050 ∧ code e302819381050 = 1402331008826 := by decide
theorem cert_e302819381050 : check e302819381050 [[],[],[.under,.left]] .chain = true := by decide
def e302819576686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302819576686 : Closed e302819576686 ∧ code e302819576686 = 1402331204462 := by decide
theorem cert_e302819576686 : check e302819576686 [[],[]] .chain = true := by decide
def e302819576694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302819576694 : Closed e302819576694 ∧ code e302819576694 = 1402331204470 := by decide
theorem cert_e302819576694 : check e302819576694 [[],[]] .chain = true := by decide
def e302819576750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302819576750 : Closed e302819576750 ∧ code e302819576750 = 1402331204526 := by decide
theorem cert_e302819576750 : check e302819576750 [[],[]] .chain = true := by decide
def e302819576762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302819576762 : Closed e302819576762 ∧ code e302819576762 = 1402331204538 := by decide
theorem cert_e302819576762 : check e302819576762 [[],[]] .chain = true := by decide
def e302819576790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302819576790 : Closed e302819576790 ∧ code e302819576790 = 1402331204566 := by decide
theorem cert_e302819576790 : check e302819576790 [[],[]] .chain = true := by decide
def e302819576794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302819576794 : Closed e302819576794 ∧ code e302819576794 = 1402331204570 := by decide
theorem cert_e302819576794 : check e302819576794 [[],[]] .chain = true := by decide
def e302819577070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302819577070 : Closed e302819577070 ∧ code e302819577070 = 1402331204846 := by decide
theorem cert_e302819577070 : check e302819577070 [[],[]] .chain = true := by decide
def e302819577078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302819577078 : Closed e302819577078 ∧ code e302819577078 = 1402331204854 := by decide
theorem cert_e302819577078 : check e302819577078 [[],[]] .chain = true := by decide
def e302819577454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302819577454 : Closed e302819577454 ∧ code e302819577454 = 1402331205230 := by decide
theorem cert_e302819577454 : check e302819577454 [[],[]] .chain = true := by decide
def e302819577466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302819577466 : Closed e302819577466 ∧ code e302819577466 = 1402331205242 := by decide
theorem cert_e302819577466 : check e302819577466 [[],[]] .chain = true := by decide
def e302819577654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302819577654 : Closed e302819577654 ∧ code e302819577654 = 1402331205430 := by decide
theorem cert_e302819577654 : check e302819577654 [[],[]] .chain = true := by decide
def e302819577658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302819577658 : Closed e302819577658 ∧ code e302819577658 = 1402331205434 := by decide
theorem cert_e302819577658 : check e302819577658 [[],[]] .chain = true := by decide
def e302820384222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e302820384222 : Closed e302820384222 ∧ code e302820384222 = 1402332011998 := by decide
theorem cert_e302820384222 : check e302820384222 [[],[]] .smaller = true := by decide
def e302820384238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e302820384238 : Closed e302820384238 ∧ code e302820384238 = 1402332012014 := by decide
theorem cert_e302820384238 : check e302820384238 [[],[]] .smaller = true := by decide
def e302820384478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e302820384478 : Closed e302820384478 ∧ code e302820384478 = 1402332012254 := by decide
theorem cert_e302820384478 : check e302820384478 [[],[]] .smaller = true := by decide
def e302820384502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e302820384502 : Closed e302820384502 ∧ code e302820384502 = 1402332012278 := by decide
theorem cert_e302820384502 : check e302820384502 [[],[]] .smaller = true := by decide
def e302820384622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e302820384622 : Closed e302820384622 ∧ code e302820384622 = 1402332012398 := by decide
theorem cert_e302820384622 : check e302820384622 [[],[]] .smaller = true := by decide
def e302820384630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e302820384630 : Closed e302820384630 ∧ code e302820384630 = 1402332012406 := by decide
theorem cert_e302820384630 : check e302820384630 [[],[]] .smaller = true := by decide
def e302820389854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e302820389854 : Closed e302820389854 ∧ code e302820389854 = 1402332017630 := by decide
theorem cert_e302820389854 : check e302820389854 [[],[]] .smaller = true := by decide
def e302820389870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e302820389870 : Closed e302820389870 ∧ code e302820389870 = 1402332017646 := by decide
theorem cert_e302820389870 : check e302820389870 [[],[]] .smaller = true := by decide
def e302820391390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e302820391390 : Closed e302820391390 ∧ code e302820391390 = 1402332019166 := by decide
theorem cert_e302820391390 : check e302820391390 [[],[]] .smaller = true := by decide
def e302820391414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e302820391414 : Closed e302820391414 ∧ code e302820391414 = 1402332019190 := by decide
theorem cert_e302820391414 : check e302820391414 [[],[]] .smaller = true := by decide
def e302820392174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e302820392174 : Closed e302820392174 ∧ code e302820392174 = 1402332019950 := by decide
theorem cert_e302820392174 : check e302820392174 [[],[]] .smaller = true := by decide
def e302820392182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e302820392182 : Closed e302820392182 ∧ code e302820392182 = 1402332019958 := by decide
theorem cert_e302820392182 : check e302820392182 [[],[]] .smaller = true := by decide
def e302820448990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302820448990 : Closed e302820448990 ∧ code e302820448990 = 1402332076766 := by decide
theorem cert_e302820448990 : check e302820448990 [[],[]] .chain = true := by decide
def e302820449014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302820449014 : Closed e302820449014 ∧ code e302820449014 = 1402332076790 := by decide
theorem cert_e302820449014 : check e302820449014 [[],[]] .chain = true := by decide
def e302820449118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302820449118 : Closed e302820449118 ∧ code e302820449118 = 1402332076894 := by decide
theorem cert_e302820449118 : check e302820449118 [[],[]] .chain = true := by decide
def e302820449134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e302820449134 : Closed e302820449134 ∧ code e302820449134 = 1402332076910 := by decide
theorem cert_e302820449134 : check e302820449134 [[],[]] .smaller = true := by decide
def e302820449142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e302820449142 : Closed e302820449142 ∧ code e302820449142 = 1402332076918 := by decide
theorem cert_e302820449142 : check e302820449142 [[],[]] .smaller = true := by decide
def e302820449146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302820449146 : Closed e302820449146 ∧ code e302820449146 = 1402332076922 := by decide
theorem cert_e302820449146 : check e302820449146 [[],[]] .chain = true := by decide
def e302820449206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e302820449206 : Closed e302820449206 ∧ code e302820449206 = 1402332076982 := by decide
theorem cert_e302820449206 : check e302820449206 [[],[]] .smaller = true := by decide
def e302820449238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302820449238 : Closed e302820449238 ∧ code e302820449238 = 1402332077014 := by decide
theorem cert_e302820449238 : check e302820449238 [[],[]] .chain = true := by decide
def e302820449242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302820449242 : Closed e302820449242 ∧ code e302820449242 = 1402332077018 := by decide
theorem cert_e302820449242 : check e302820449242 [[],[]] .chain = true := by decide
def e302820449630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e302820449630 : Closed e302820449630 ∧ code e302820449630 = 1402332077406 := by decide
theorem cert_e302820449630 : check e302820449630 [[],[]] .chain = true := by decide
def e302820449646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302820449646 : Closed e302820449646 ∧ code e302820449646 = 1402332077422 := by decide
theorem cert_e302820449646 : check e302820449646 [[],[]] .smaller = true := by decide
def e302820449654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302820449654 : Closed e302820449654 ∧ code e302820449654 = 1402332077430 := by decide
theorem cert_e302820449654 : check e302820449654 [[],[]] .smaller = true := by decide
def e302820449658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e302820449658 : Closed e302820449658 ∧ code e302820449658 = 1402332077434 := by decide
theorem cert_e302820449658 : check e302820449658 [[],[]] .chain = true := by decide
def e302820449710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302820449710 : Closed e302820449710 ∧ code e302820449710 = 1402332077486 := by decide
theorem cert_e302820449710 : check e302820449710 [[],[]] .smaller = true := by decide
def e302820449722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302820449722 : Closed e302820449722 ∧ code e302820449722 = 1402332077498 := by decide
theorem cert_e302820449722 : check e302820449722 [[],[]] .smaller = true := by decide
def e302820449750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302820449750 : Closed e302820449750 ∧ code e302820449750 = 1402332077526 := by decide
theorem cert_e302820449750 : check e302820449750 [[],[]] .smaller = true := by decide
def e302820449754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302820449754 : Closed e302820449754 ∧ code e302820449754 = 1402332077530 := by decide
theorem cert_e302820449754 : check e302820449754 [[],[]] .smaller = true := by decide
def e302820449770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e302820449770 : Closed e302820449770 ∧ code e302820449770 = 1402332077546 := by decide
theorem cert_e302820449770 : check e302820449770 [[],[]] .chain = true := by decide
def e302820449974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e302820449974 : Closed e302820449974 ∧ code e302820449974 = 1402332077750 := by decide
theorem cert_e302820449974 : check e302820449974 [[],[]] .smaller = true := by decide
def e302820450006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e302820450006 : Closed e302820450006 ∧ code e302820450006 = 1402332077782 := by decide
theorem cert_e302820450006 : check e302820450006 [[],[]] .smaller = true := by decide
def e302820450010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e302820450010 : Closed e302820450010 ∧ code e302820450010 = 1402332077786 := by decide
theorem cert_e302820450010 : check e302820450010 [[],[]] .smaller = true := by decide
def e302820450134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302820450134 : Closed e302820450134 ∧ code e302820450134 = 1402332077910 := by decide
theorem cert_e302820450134 : check e302820450134 [[],[]] .chain = true := by decide
def e302820450138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302820450138 : Closed e302820450138 ∧ code e302820450138 = 1402332077914 := by decide
theorem cert_e302820450138 : check e302820450138 [[],[]] .chain = true := by decide
def e302820450154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302820450154 : Closed e302820450154 ∧ code e302820450154 = 1402332077930 := by decide
theorem cert_e302820450154 : check e302820450154 [[],[]] .chain = true := by decide
def e302820451294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e302820451294 : Closed e302820451294 ∧ code e302820451294 = 1402332079070 := by decide
theorem cert_e302820451294 : check e302820451294 [[],[]] .chain = true := by decide
def e302820451310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e302820451310 : Closed e302820451310 ∧ code e302820451310 = 1402332079086 := by decide
theorem cert_e302820451310 : check e302820451310 [[],[]] .chain = true := by decide
def e302820452062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302820452062 : Closed e302820452062 ∧ code e302820452062 = 1402332079838 := by decide
theorem cert_e302820452062 : check e302820452062 [[],[]] .chain = true := by decide
def e302820452086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302820452086 : Closed e302820452086 ∧ code e302820452086 = 1402332079862 := by decide
theorem cert_e302820452086 : check e302820452086 [[],[]] .chain = true := by decide
def e302820452190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302820452190 : Closed e302820452190 ∧ code e302820452190 = 1402332079966 := by decide
theorem cert_e302820452190 : check e302820452190 [[],[]] .chain = true := by decide
def e302820452206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e302820452206 : Closed e302820452206 ∧ code e302820452206 = 1402332079982 := by decide
theorem cert_e302820452206 : check e302820452206 [[],[]] .smaller = true := by decide
end Blc.Floor40
