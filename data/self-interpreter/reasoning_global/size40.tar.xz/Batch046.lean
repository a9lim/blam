import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801122078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302801122078 : Closed e302801122078 ∧ code e302801122078 = 1402312749854 := by decide
theorem cert_e302801122078 : check e302801122078 [[],[]] .chain = true := by decide
def e302801122246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302801122246 : Closed e302801122246 ∧ code e302801122246 = 1402312750022 := by decide
theorem cert_e302801122246 : check e302801122246 [[],[]] .chain = true := by decide
def e302801123438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302801123438 : Closed e302801123438 ∧ code e302801123438 = 1402312751214 := by decide
theorem cert_e302801123438 : check e302801123438 [[],[]] .chain = true := by decide
def e302801123450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302801123450 : Closed e302801123450 ∧ code e302801123450 = 1402312751226 := by decide
theorem cert_e302801123450 : check e302801123450 [[],[]] .chain = true := by decide
def e302801123726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302801123726 : Closed e302801123726 ∧ code e302801123726 = 1402312751502 := by decide
theorem cert_e302801123726 : check e302801123726 [[],[]] .chain = true := by decide
def e302801123782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302801123782 : Closed e302801123782 ∧ code e302801123782 = 1402312751558 := by decide
theorem cert_e302801123782 : check e302801123782 [[],[]] .chain = true := by decide
def e302801161054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e302801161054 : Closed e302801161054 ∧ code e302801161054 = 1402312788830 := by decide
theorem cert_e302801161054 : check e302801161054 [[],[]] .chain = true := by decide
def e302801161070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302801161070 : Closed e302801161070 ∧ code e302801161070 = 1402312788846 := by decide
theorem cert_e302801161070 : check e302801161070 [[],[]] .smaller = true := by decide
def e302801161078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302801161078 : Closed e302801161078 ∧ code e302801161078 = 1402312788854 := by decide
theorem cert_e302801161078 : check e302801161078 [[],[]] .smaller = true := by decide
def e302801161082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e302801161082 : Closed e302801161082 ∧ code e302801161082 = 1402312788858 := by decide
theorem cert_e302801161082 : check e302801161082 [[],[]] .chain = true := by decide
def e302801161134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302801161134 : Closed e302801161134 ∧ code e302801161134 = 1402312788910 := by decide
theorem cert_e302801161134 : check e302801161134 [[],[]] .smaller = true := by decide
def e302801161146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302801161146 : Closed e302801161146 ∧ code e302801161146 = 1402312788922 := by decide
theorem cert_e302801161146 : check e302801161146 [[],[]] .smaller = true := by decide
def e302801161174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302801161174 : Closed e302801161174 ∧ code e302801161174 = 1402312788950 := by decide
theorem cert_e302801161174 : check e302801161174 [[],[]] .smaller = true := by decide
def e302801161178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302801161178 : Closed e302801161178 ∧ code e302801161178 = 1402312788954 := by decide
theorem cert_e302801161178 : check e302801161178 [[],[]] .smaller = true := by decide
def e302801161194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e302801161194 : Closed e302801161194 ∧ code e302801161194 = 1402312788970 := by decide
theorem cert_e302801161194 : check e302801161194 [[],[]] .chain = true := by decide
def e302801161438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801161438 : Closed e302801161438 ∧ code e302801161438 = 1402312789214 := by decide
theorem cert_e302801161438 : check e302801161438 [[],[]] .chain = true := by decide
def e302801161454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801161454 : Closed e302801161454 ∧ code e302801161454 = 1402312789230 := by decide
theorem cert_e302801161454 : check e302801161454 [[],[]] .smaller = true := by decide
def e302801161462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801161462 : Closed e302801161462 ∧ code e302801161462 = 1402312789238 := by decide
theorem cert_e302801161462 : check e302801161462 [[],[]] .smaller = true := by decide
def e302801161466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801161466 : Closed e302801161466 ∧ code e302801161466 = 1402312789242 := by decide
theorem cert_e302801161466 : check e302801161466 [[],[]] .chain = true := by decide
def e302801161790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e302801161790 : Closed e302801161790 ∧ code e302801161790 = 1402312789566 := by decide
theorem cert_e302801161790 : check e302801161790 [[],[]] .chain = true := by decide
def e302801161838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801161838 : Closed e302801161838 ∧ code e302801161838 = 1402312789614 := by decide
theorem cert_e302801161838 : check e302801161838 [[],[]] .smaller = true := by decide
def e302801161850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801161850 : Closed e302801161850 ∧ code e302801161850 = 1402312789626 := by decide
theorem cert_e302801161850 : check e302801161850 [[],[]] .smaller = true := by decide
def e302801162038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801162038 : Closed e302801162038 ∧ code e302801162038 = 1402312789814 := by decide
theorem cert_e302801162038 : check e302801162038 [[],[]] .smaller = true := by decide
def e302801162042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801162042 : Closed e302801162042 ∧ code e302801162042 = 1402312789818 := by decide
theorem cert_e302801162042 : check e302801162042 [[],[]] .smaller = true := by decide
def e302801162126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e302801162126 : Closed e302801162126 ∧ code e302801162126 = 1402312789902 := by decide
theorem cert_e302801162126 : check e302801162126 [[],[]] .chain = true := by decide
def e302801162138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801162138 : Closed e302801162138 ∧ code e302801162138 = 1402312789914 := by decide
theorem cert_e302801162138 : check e302801162138 [[],[]] .chain = true := by decide
def e302801169518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302801169518 : Closed e302801169518 ∧ code e302801169518 = 1402312797294 := by decide
theorem cert_e302801169518 : check e302801169518 [[],[]] .chain = true := by decide
def e302801169530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302801169530 : Closed e302801169530 ∧ code e302801169530 = 1402312797306 := by decide
theorem cert_e302801169530 : check e302801169530 [[],[]] .chain = true := by decide
def e302801169694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302801169694 : Closed e302801169694 ∧ code e302801169694 = 1402312797470 := by decide
theorem cert_e302801169694 : check e302801169694 [[],[]] .chain = true := by decide
def e302801169862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302801169862 : Closed e302801169862 ∧ code e302801169862 = 1402312797638 := by decide
theorem cert_e302801169862 : check e302801169862 [[],[]] .chain = true := by decide
def e302801169966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302801169966 : Closed e302801169966 ∧ code e302801169966 = 1402312797742 := by decide
theorem cert_e302801169966 : check e302801169966 [[],[]] .chain = true := by decide
def e302801170146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302801170146 : Closed e302801170146 ∧ code e302801170146 = 1402312797922 := by decide
theorem cert_e302801170146 : check e302801170146 [[],[]] .chain = true := by decide
def e302801170158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e302801170158 : Closed e302801170158 ∧ code e302801170158 = 1402312797934 := by decide
theorem cert_e302801170158 : check e302801170158 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801170198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801170198 : Closed e302801170198 ∧ code e302801170198 = 1402312797974 := by decide
theorem cert_e302801170198 : check e302801170198 [[],[]] .chain = true := by decide
def e302801170202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801170202 : Closed e302801170202 ∧ code e302801170202 = 1402312797978 := by decide
theorem cert_e302801170202 : check e302801170202 [[],[]] .chain = true := by decide
def e302801170246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801170246 : Closed e302801170246 ∧ code e302801170246 = 1402312798022 := by decide
theorem cert_e302801170246 : check e302801170246 [[],[]] .chain = true := by decide
def e302801170274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801170274 : Closed e302801170274 ∧ code e302801170274 = 1402312798050 := by decide
theorem cert_e302801170274 : check e302801170274 [[],[]] .chain = true := by decide
def e302801170286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e302801170286 : Closed e302801170286 ∧ code e302801170286 = 1402312798062 := by decide
theorem cert_e302801170286 : check e302801170286 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801170294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e302801170294 : Closed e302801170294 ∧ code e302801170294 = 1402312798070 := by decide
theorem cert_e302801170294 : check e302801170294 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801170654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302801170654 : Closed e302801170654 ∧ code e302801170654 = 1402312798430 := by decide
theorem cert_e302801170654 : check e302801170654 [[],[]] .chain = true := by decide
def e302801170682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302801170682 : Closed e302801170682 ∧ code e302801170682 = 1402312798458 := by decide
theorem cert_e302801170682 : check e302801170682 [[],[]] .chain = true := by decide
def e302801171230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302801171230 : Closed e302801171230 ∧ code e302801171230 = 1402312799006 := by decide
theorem cert_e302801171230 : check e302801171230 [[],[]] .chain = true := by decide
def e302801171398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302801171398 : Closed e302801171398 ∧ code e302801171398 = 1402312799174 := by decide
theorem cert_e302801171398 : check e302801171398 [[],[]] .chain = true := by decide
def e302801172542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e302801172542 : Closed e302801172542 ∧ code e302801172542 = 1402312800318 := by decide
theorem cert_e302801172542 : check e302801172542 [[],[]] .chain = true := by decide
def e302801172962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302801172962 : Closed e302801172962 ∧ code e302801172962 = 1402312800738 := by decide
theorem cert_e302801172962 : check e302801172962 [[],[]] .chain = true := by decide
def e302801172974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e302801172974 : Closed e302801172974 ∧ code e302801172974 = 1402312800750 := by decide
theorem cert_e302801172974 : check e302801172974 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801173534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e302801173534 : Closed e302801173534 ∧ code e302801173534 = 1402312801310 := by decide
theorem cert_e302801173534 : check e302801173534 [[],[]] .chain = true := by decide
def e302801173558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801173558 : Closed e302801173558 ∧ code e302801173558 = 1402312801334 := by decide
theorem cert_e302801173558 : check e302801173558 [[],[]] .chain = true := by decide
def e302801173562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801173562 : Closed e302801173562 ∧ code e302801173562 = 1402312801338 := by decide
theorem cert_e302801173562 : check e302801173562 [[],[]] .chain = true := by decide
def e302801173702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801173702 : Closed e302801173702 ∧ code e302801173702 = 1402312801478 := by decide
theorem cert_e302801173702 : check e302801173702 [[],[]] .chain = true := by decide
def e302801173730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801173730 : Closed e302801173730 ∧ code e302801173730 = 1402312801506 := by decide
theorem cert_e302801173730 : check e302801173730 [[],[]] .chain = true := by decide
def e302801173742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e302801173742 : Closed e302801173742 ∧ code e302801173742 = 1402312801518 := by decide
theorem cert_e302801173742 : check e302801173742 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801173750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e302801173750 : Closed e302801173750 ∧ code e302801173750 = 1402312801526 := by decide
theorem cert_e302801173750 : check e302801173750 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801192366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e302801192366 : Closed e302801192366 ∧ code e302801192366 = 1402312820142 := by decide
theorem cert_e302801192366 : check e302801192366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801192378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e302801192378 : Closed e302801192378 ∧ code e302801192378 = 1402312820154 := by decide
theorem cert_e302801192378 : check e302801192378 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302801192426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e302801192426 : Closed e302801192426 ∧ code e302801192426 = 1402312820202 := by decide
theorem cert_e302801192426 : check e302801192426 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801192558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801192558 : Closed e302801192558 ∧ code e302801192558 = 1402312820334 := by decide
theorem cert_e302801192558 : check e302801192558 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[],[]] .identityHead = true := by decide
def e302801192570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801192570 : Closed e302801192570 ∧ code e302801192570 = 1402312820346 := by decide
theorem cert_e302801192570 : check e302801192570 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e302801192734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302801192734 : Closed e302801192734 ∧ code e302801192734 = 1402312820510 := by decide
theorem cert_e302801192734 : check e302801192734 [[],[]] .chain = true := by decide
def e302801192846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302801192846 : Closed e302801192846 ∧ code e302801192846 = 1402312820622 := by decide
theorem cert_e302801192846 : check e302801192846 [[],[]] .chain = true := by decide
def e302801192858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801192858 : Closed e302801192858 ∧ code e302801192858 = 1402312820634 := by decide
theorem cert_e302801192858 : checkPay e302801192858 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left]] 0 [[]] = true := by decide
def e302801196598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302801196598 : Closed e302801196598 ∧ code e302801196598 = 1402312824374 := by decide
theorem cert_e302801196598 : check e302801196598 [[],[]] .chain = true := by decide
def e302801196602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302801196602 : Closed e302801196602 ∧ code e302801196602 = 1402312824378 := by decide
theorem cert_e302801196602 : check e302801196602 [[],[]] .chain = true := by decide
def e302801196686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302801196686 : Closed e302801196686 ∧ code e302801196686 = 1402312824462 := by decide
theorem cert_e302801196686 : check e302801196686 [[],[]] .chain = true := by decide
def e302801196742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302801196742 : Closed e302801196742 ∧ code e302801196742 = 1402312824518 := by decide
theorem cert_e302801196742 : check e302801196742 [[],[]] .chain = true := by decide
def e302801196822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801196822 : Closed e302801196822 ∧ code e302801196822 = 1402312824598 := by decide
theorem cert_e302801196822 : check e302801196822 [[],[]] .chain = true := by decide
def e302801196826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801196826 : Closed e302801196826 ∧ code e302801196826 = 1402312824602 := by decide
theorem cert_e302801196826 : check e302801196826 [[],[]] .chain = true := by decide
def e302801196870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801196870 : Closed e302801196870 ∧ code e302801196870 = 1402312824646 := by decide
theorem cert_e302801196870 : check e302801196870 [[],[]] .chain = true := by decide
def e302801196898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801196898 : Closed e302801196898 ∧ code e302801196898 = 1402312824674 := by decide
theorem cert_e302801196898 : check e302801196898 [[],[]] .chain = true := by decide
def e302801196910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e302801196910 : Closed e302801196910 ∧ code e302801196910 = 1402312824686 := by decide
theorem cert_e302801196910 : check e302801196910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801196918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e302801196918 : Closed e302801196918 ∧ code e302801196918 = 1402312824694 := by decide
theorem cert_e302801196918 : check e302801196918 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801196982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e302801196982 : Closed e302801196982 ∧ code e302801196982 = 1402312824758 := by decide
theorem cert_e302801196982 : check e302801196982 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302801197166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302801197166 : Closed e302801197166 ∧ code e302801197166 = 1402312824942 := by decide
theorem cert_e302801197166 : check e302801197166 [[],[]] .chain = true := by decide
def e302801197178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302801197178 : Closed e302801197178 ∧ code e302801197178 = 1402312824954 := by decide
theorem cert_e302801197178 : check e302801197178 [[],[]] .chain = true := by decide
def e302801197454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302801197454 : Closed e302801197454 ∧ code e302801197454 = 1402312825230 := by decide
theorem cert_e302801197454 : check e302801197454 [[],[]] .chain = true := by decide
def e302801197510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302801197510 : Closed e302801197510 ∧ code e302801197510 = 1402312825286 := by decide
theorem cert_e302801197510 : check e302801197510 [[],[]] .chain = true := by decide
def e302801198110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 3)))))))))
theorem wire_e302801198110 : Closed e302801198110 ∧ code e302801198110 = 1402312825886 := by decide
theorem cert_e302801198110 : check e302801198110 [[],[]] .chain = true := by decide
def e302801198134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801198134 : Closed e302801198134 ∧ code e302801198134 = 1402312825910 := by decide
theorem cert_e302801198134 : check e302801198134 [[],[]] .chain = true := by decide
def e302801198138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801198138 : Closed e302801198138 ∧ code e302801198138 = 1402312825914 := by decide
theorem cert_e302801198138 : check e302801198138 [[],[]] .chain = true := by decide
def e302801198278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801198278 : Closed e302801198278 ∧ code e302801198278 = 1402312826054 := by decide
theorem cert_e302801198278 : check e302801198278 [[],[]] .chain = true := by decide
def e302801198306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801198306 : Closed e302801198306 ∧ code e302801198306 = 1402312826082 := by decide
theorem cert_e302801198306 : check e302801198306 [[],[]] .chain = true := by decide
def e302801198318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e302801198318 : Closed e302801198318 ∧ code e302801198318 = 1402312826094 := by decide
theorem cert_e302801198318 : check e302801198318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801198326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e302801198326 : Closed e302801198326 ∧ code e302801198326 = 1402312826102 := by decide
theorem cert_e302801198326 : check e302801198326 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801198710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e302801198710 : Closed e302801198710 ∧ code e302801198710 = 1402312826486 := by decide
theorem cert_e302801198710 : check e302801198710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801231086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801231086 : Closed e302801231086 ∧ code e302801231086 = 1402312858862 := by decide
theorem cert_e302801231086 : check e302801231086 [[],[]] .chain = true := by decide
def e302801231094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801231094 : Closed e302801231094 ∧ code e302801231094 = 1402312858870 := by decide
theorem cert_e302801231094 : check e302801231094 [[],[]] .chain = true := by decide
def e302801231470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801231470 : Closed e302801231470 ∧ code e302801231470 = 1402312859246 := by decide
theorem cert_e302801231470 : check e302801231470 [[],[]] .chain = true := by decide
def e302801231482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801231482 : Closed e302801231482 ∧ code e302801231482 = 1402312859258 := by decide
theorem cert_e302801231482 : check e302801231482 [[],[]] .chain = true := by decide
def e302801231670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801231670 : Closed e302801231670 ∧ code e302801231670 = 1402312859446 := by decide
theorem cert_e302801231670 : check e302801231670 [[],[]] .chain = true := by decide
def e302801231674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801231674 : Closed e302801231674 ∧ code e302801231674 = 1402312859450 := by decide
theorem cert_e302801231674 : check e302801231674 [[],[]] .chain = true := by decide
def e302801235310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e302801235310 : Closed e302801235310 ∧ code e302801235310 = 1402312863086 := by decide
theorem cert_e302801235310 : checkPay e302801235310 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801235322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e302801235322 : Closed e302801235322 ∧ code e302801235322 = 1402312863098 := by decide
theorem cert_e302801235322 : check e302801235322 [[],[]] .chain = true := by decide
def e302801235374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e302801235374 : Closed e302801235374 ∧ code e302801235374 = 1402312863150 := by decide
theorem cert_e302801235374 : checkPay e302801235374 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801235386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e302801235386 : Closed e302801235386 ∧ code e302801235386 = 1402312863162 := by decide
theorem cert_e302801235386 : check e302801235386 [[],[]] .smaller = true := by decide
def e302801235418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e302801235418 : Closed e302801235418 ∧ code e302801235418 = 1402312863194 := by decide
theorem cert_e302801235418 : check e302801235418 [[],[]] .smaller = true := by decide
def e302801235434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e302801235434 : Closed e302801235434 ∧ code e302801235434 = 1402312863210 := by decide
theorem cert_e302801235434 : check e302801235434 [[],[]] .chain = true := by decide
def e302801235630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e302801235630 : Closed e302801235630 ∧ code e302801235630 = 1402312863406 := by decide
theorem cert_e302801235630 : checkPay e302801235630 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left]] = true := by decide
def e302801235642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e302801235642 : Closed e302801235642 ∧ code e302801235642 = 1402312863418 := by decide
theorem cert_e302801235642 : check e302801235642 [[],[]] .smaller = true := by decide
def e302801235690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e302801235690 : Closed e302801235690 ∧ code e302801235690 = 1402312863466 := by decide
theorem cert_e302801235690 : check e302801235690 [[],[]] .smaller = true := by decide
def e302801235802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e302801235802 : Closed e302801235802 ∧ code e302801235802 = 1402312863578 := by decide
theorem cert_e302801235802 : check e302801235802 [[],[]] .smaller = true := by decide
def e302801235818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e302801235818 : Closed e302801235818 ∧ code e302801235818 = 1402312863594 := by decide
theorem cert_e302801235818 : check e302801235818 [[],[]] .smaller = true := by decide
def e302801235882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e302801235882 : Closed e302801235882 ∧ code e302801235882 = 1402312863658 := by decide
theorem cert_e302801235882 : check e302801235882 [[],[]] .chain = true := by decide
def e302801236846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e302801236846 : Closed e302801236846 ∧ code e302801236846 = 1402312864622 := by decide
theorem cert_e302801236846 : checkPay e302801236846 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801236858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e302801236858 : Closed e302801236858 ∧ code e302801236858 = 1402312864634 := by decide
theorem cert_e302801236858 : check e302801236858 [[],[]] .chain = true := by decide
def e302801236910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e302801236910 : Closed e302801236910 ∧ code e302801236910 = 1402312864686 := by decide
theorem cert_e302801236910 : checkPay e302801236910 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e302801236922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e302801236922 : Closed e302801236922 ∧ code e302801236922 = 1402312864698 := by decide
theorem cert_e302801236922 : check e302801236922 [[],[]] .smaller = true := by decide
def e302801236954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e302801236954 : Closed e302801236954 ∧ code e302801236954 = 1402312864730 := by decide
theorem cert_e302801236954 : check e302801236954 [[],[]] .smaller = true := by decide
def e302801236970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e302801236970 : Closed e302801236970 ∧ code e302801236970 = 1402312864746 := by decide
theorem cert_e302801236970 : check e302801236970 [[],[]] .chain = true := by decide
def e302801237614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801237614 : Closed e302801237614 ∧ code e302801237614 = 1402312865390 := by decide
theorem cert_e302801237614 : check e302801237614 [[],[]] .chain = true := by decide
def e302801237626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801237626 : Closed e302801237626 ∧ code e302801237626 = 1402312865402 := by decide
theorem cert_e302801237626 : check e302801237626 [[],[]] .chain = true := by decide
def e302801237914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801237914 : Closed e302801237914 ∧ code e302801237914 = 1402312865690 := by decide
theorem cert_e302801237914 : check e302801237914 [[],[]] .chain = true := by decide
def e302801238254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 2))))))
theorem wire_e302801238254 : Closed e302801238254 ∧ code e302801238254 = 1402312866030 := by decide
theorem cert_e302801238254 : check e302801238254 [[],[]] .chain = true := by decide
def e302801238266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 0))))))
theorem wire_e302801238266 : Closed e302801238266 ∧ code e302801238266 = 1402312866042 := by decide
theorem cert_e302801238266 : check e302801238266 [[],[]] .chain = true := by decide
def e302801238446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e302801238446 : Closed e302801238446 ∧ code e302801238446 = 1402312866222 := by decide
theorem cert_e302801238446 : checkPay e302801238446 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e302801238458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e302801238458 : Closed e302801238458 ∧ code e302801238458 = 1402312866234 := by decide
theorem cert_e302801238458 : check e302801238458 [[],[]] .smaller = true := by decide
def e302801238506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e302801238506 : Closed e302801238506 ∧ code e302801238506 = 1402312866282 := by decide
theorem cert_e302801238506 : check e302801238506 [[],[]] .smaller = true := by decide
def e302801238638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801238638 : Closed e302801238638 ∧ code e302801238638 = 1402312866414 := by decide
theorem cert_e302801238638 : check e302801238638 [[],[]] .chain = true := by decide
def e302801238650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801238650 : Closed e302801238650 ∧ code e302801238650 = 1402312866426 := by decide
theorem cert_e302801238650 : check e302801238650 [[],[]] .chain = true := by decide
def e302801238814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e302801238814 : Closed e302801238814 ∧ code e302801238814 = 1402312866590 := by decide
theorem cert_e302801238814 : check e302801238814 [[],[]] .chain = true := by decide
def e302801238982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e302801238982 : Closed e302801238982 ∧ code e302801238982 = 1402312866758 := by decide
theorem cert_e302801238982 : check e302801238982 [[],[]] .chain = true := by decide
def e302801239258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e302801239258 : Closed e302801239258 ∧ code e302801239258 = 1402312867034 := by decide
theorem cert_e302801239258 : check e302801239258 [[],[]] .smaller = true := by decide
def e302801239274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e302801239274 : Closed e302801239274 ∧ code e302801239274 = 1402312867050 := by decide
theorem cert_e302801239274 : check e302801239274 [[],[]] .smaller = true := by decide
def e302801239610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 0))))))
theorem wire_e302801239610 : Closed e302801239610 ∧ code e302801239610 = 1402312867386 := by decide
theorem cert_e302801239610 : check e302801239610 [[],[]] .chain = true := by decide
def e302801239658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e302801239658 : Closed e302801239658 ∧ code e302801239658 = 1402312867434 := by decide
theorem cert_e302801239658 : check e302801239658 [[],[]] .chain = true := by decide
def e302801239706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801239706 : Closed e302801239706 ∧ code e302801239706 = 1402312867482 := by decide
theorem cert_e302801239706 : check e302801239706 [[],[]] .chain = true := by decide
def e302801239750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e302801239750 : Closed e302801239750 ∧ code e302801239750 = 1402312867526 := by decide
theorem cert_e302801239750 : check e302801239750 [[],[]] .chain = true := by decide
def e302801242990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302801242990 : Closed e302801242990 ∧ code e302801242990 = 1402312870766 := by decide
theorem cert_e302801242990 : check e302801242990 [[],[]] .chain = true := by decide
def e302801242998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302801242998 : Closed e302801242998 ∧ code e302801242998 = 1402312870774 := by decide
theorem cert_e302801242998 : check e302801242998 [[],[]] .chain = true := by decide
def e302801243054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302801243054 : Closed e302801243054 ∧ code e302801243054 = 1402312870830 := by decide
theorem cert_e302801243054 : check e302801243054 [[],[]] .chain = true := by decide
def e302801243066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302801243066 : Closed e302801243066 ∧ code e302801243066 = 1402312870842 := by decide
theorem cert_e302801243066 : check e302801243066 [[],[]] .chain = true := by decide
def e302801243094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302801243094 : Closed e302801243094 ∧ code e302801243094 = 1402312870870 := by decide
theorem cert_e302801243094 : check e302801243094 [[],[]] .chain = true := by decide
def e302801243098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302801243098 : Closed e302801243098 ∧ code e302801243098 = 1402312870874 := by decide
theorem cert_e302801243098 : check e302801243098 [[],[]] .chain = true := by decide
def e302801243374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302801243374 : Closed e302801243374 ∧ code e302801243374 = 1402312871150 := by decide
theorem cert_e302801243374 : check e302801243374 [[],[]] .chain = true := by decide
def e302801243382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302801243382 : Closed e302801243382 ∧ code e302801243382 = 1402312871158 := by decide
theorem cert_e302801243382 : check e302801243382 [[],[]] .chain = true := by decide
def e302801243758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302801243758 : Closed e302801243758 ∧ code e302801243758 = 1402312871534 := by decide
theorem cert_e302801243758 : check e302801243758 [[],[]] .chain = true := by decide
def e302801243770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302801243770 : Closed e302801243770 ∧ code e302801243770 = 1402312871546 := by decide
theorem cert_e302801243770 : check e302801243770 [[],[]] .chain = true := by decide
def e302801243958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302801243958 : Closed e302801243958 ∧ code e302801243958 = 1402312871734 := by decide
theorem cert_e302801243958 : check e302801243958 [[],[]] .chain = true := by decide
def e302801243962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302801243962 : Closed e302801243962 ∧ code e302801243962 = 1402312871738 := by decide
theorem cert_e302801243962 : check e302801243962 [[],[]] .chain = true := by decide
def e302801248734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e302801248734 : Closed e302801248734 ∧ code e302801248734 = 1402312876510 := by decide
theorem cert_e302801248734 : check e302801248734 [[],[]] .chain = true := by decide
def e302801248758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e302801248758 : Closed e302801248758 ∧ code e302801248758 = 1402312876534 := by decide
theorem cert_e302801248758 : check e302801248758 [[],[]] .chain = true := by decide
def e302801249710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e302801249710 : Closed e302801249710 ∧ code e302801249710 = 1402312877486 := by decide
theorem cert_e302801249710 : check e302801249710 [[],[]] .chain = true := by decide
def e302801249722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e302801249722 : Closed e302801249722 ∧ code e302801249722 = 1402312877498 := by decide
theorem cert_e302801249722 : check e302801249722 [[],[]] .chain = true := by decide
def e302801249770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e302801249770 : Closed e302801249770 ∧ code e302801249770 = 1402312877546 := by decide
theorem cert_e302801249770 : check e302801249770 [[],[]] .chain = true := by decide
def e302801249902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e302801249902 : Closed e302801249902 ∧ code e302801249902 = 1402312877678 := by decide
theorem cert_e302801249902 : check e302801249902 [[],[]] .chain = true := by decide
def e302801249914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e302801249914 : Closed e302801249914 ∧ code e302801249914 = 1402312877690 := by decide
theorem cert_e302801249914 : check e302801249914 [[],[]] .chain = true := by decide
def e302801250078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e302801250078 : Closed e302801250078 ∧ code e302801250078 = 1402312877854 := by decide
theorem cert_e302801250078 : check e302801250078 [[],[]] .chain = true := by decide
def e302801250190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e302801250190 : Closed e302801250190 ∧ code e302801250190 = 1402312877966 := by decide
theorem cert_e302801250190 : check e302801250190 [[],[]] .chain = true := by decide
def e302801250202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e302801250202 : Closed e302801250202 ∧ code e302801250202 = 1402312877978 := by decide
theorem cert_e302801250202 : check e302801250202 [[],[]] .chain = true := by decide
def e302801253150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302801253150 : Closed e302801253150 ∧ code e302801253150 = 1402312880926 := by decide
theorem cert_e302801253150 : check e302801253150 [[],[]] .chain = true := by decide
def e302801253318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302801253318 : Closed e302801253318 ∧ code e302801253318 = 1402312881094 := by decide
theorem cert_e302801253318 : check e302801253318 [[],[]] .chain = true := by decide
def e302801254518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e302801254518 : Closed e302801254518 ∧ code e302801254518 = 1402312882294 := by decide
theorem cert_e302801254518 : check e302801254518 [[],[]] .chain = true := by decide
def e302801254762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e302801254762 : Closed e302801254762 ∧ code e302801254762 = 1402312882538 := by decide
theorem cert_e302801254762 : check e302801254762 [[],[]] .chain = true := by decide
def e302801254798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302801254798 : Closed e302801254798 ∧ code e302801254798 = 1402312882574 := by decide
theorem cert_e302801254798 : check e302801254798 [[],[]] .chain = true := by decide
def e302801254810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e302801254810 : Closed e302801254810 ∧ code e302801254810 = 1402312882586 := by decide
theorem cert_e302801254810 : check e302801254810 [[],[]] .chain = true := by decide
def e302801254854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302801254854 : Closed e302801254854 ∧ code e302801254854 = 1402312882630 := by decide
theorem cert_e302801254854 : check e302801254854 [[],[]] .chain = true := by decide
def e302801269102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e302801269102 : Closed e302801269102 ∧ code e302801269102 = 1402312896878 := by decide
theorem cert_e302801269102 : check e302801269102 [[],[]] .chain = true := by decide
def e302801269110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e302801269110 : Closed e302801269110 ∧ code e302801269110 = 1402312896886 := by decide
theorem cert_e302801269110 : check e302801269110 [[],[]] .chain = true := by decide
def e302801269166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e302801269166 : Closed e302801269166 ∧ code e302801269166 = 1402312896942 := by decide
theorem cert_e302801269166 : check e302801269166 [[],[]] .chain = true := by decide
def e302801269178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e302801269178 : Closed e302801269178 ∧ code e302801269178 = 1402312896954 := by decide
theorem cert_e302801269178 : check e302801269178 [[],[]] .chain = true := by decide
def e302801269226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 0))))))
theorem wire_e302801269226 : Closed e302801269226 ∧ code e302801269226 = 1402312897002 := by decide
theorem cert_e302801269226 : check e302801269226 [[],[]] .chain = true := by decide
end Blc.Floor40
