import R302824803566Data
namespace Certgen.R302824803566
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl72 : FloorIndex.rangeOK validState 72 12 = true := by decide +kernel
theorem bl84 : FloorIndex.rangeOK validState 84 5 = true := by decide +kernel
end Certgen.R302824803566
