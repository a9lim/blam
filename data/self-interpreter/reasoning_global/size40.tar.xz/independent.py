from candidates import *
raw=(HERE/'cross.txt').read_text().splitlines()
assert len(raw)==len(set(raw))==53008
kept=set()
for s in raw:
    e=lc.decode(s)[0]
    if all(wire(red(e,p))>=40 for p in subpaths(e) if at(e,p)[0]=='A' and at(e,p)[1][0]=='L'):
        kept.add(s)
assert kept==set((HERE/'wires.txt').read_text().splitlines())
print(len(kept),'equal wires, zero symmetric difference')
