import R302824803258V0
import R302824803258K0
import R302824803258st0
import R302824803258hs0
import CodeBridge
import Batch060
namespace Certgen.R302824803258
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 84,.app 2 75,.app 3 66,.app 4 37,.app 5 22,.app 6 10,.lam 7,.app 8 9,.var 0,.var 0,.lam 11,.lam 12,.app 13 14,.var 1,.lam 15,.app 16 17,.var 2,.app 18 21,.app 19 20,.var 1,.var 2,.var 0,.lam 23,.lam 24,.app 25 36,.app 26 27,.var 1,.app 28 32,.lam 29,.app 30 31,.var 0,.var 0,.lam 33,.app 34 35,.var 0,.var 0,.var 0,.lam 38,.app 39 44,.app 40 41,.var 0,.lam 42,.lam 43,.var 1,.lam 45,.app 46 51,.app 47 48,.var 0,.lam 49,.lam 50,.var 1,.lam 52,.app 53 58,.app 54 55,.var 0,.lam 56,.lam 57,.var 0,.lam 59,.app 60 65,.app 61 62,.var 0,.lam 63,.lam 64,.var 1,.opaque,.app 67 71,.lam 68,.app 69 70,.var 0,.var 0,.lam 72,.app 73 74,.var 0,.var 0,.app 76 80,.lam 77,.app 78 79,.var 0,.var 0,.lam 81,.app 82 83,.var 0,.var 0,.app 85 89,.lam 86,.app 87 88,.var 0,.var 0,.lam 90,.app 91 92,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 55 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else entry
def hs (i : Nat) : List Nat := (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD [])))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302824803258
