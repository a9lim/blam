from regular40 import *
from smart_probe import apps_spine,appall
from itertools import product
def target_steps(c,m,r,args):
    t=appall(A(A(c,L(m)),r),args)
    for i in range(50):
        p=head_path(t)
        if p is None:return i
        t=bounded(t,p)
        if t is None:return
def configs():
    D=om[1]
    x,y=V(1),V(0)
    bodies=[x,y,I,A(x,y),A(y,x),A(x,om),A(y,om),A(A(x,om),y),A(A(x,y),om),
        A(A(x,om),om),A(A(y,om),om),A(A(x,D),y),A(x,A(y,om)),A(y,A(x,om)),
        A(A(y,x),om),A(A(x,om),V(2)),A(A(x,x),y),A(A(y,y),x)]
    cs=[V(1),KI,L(L(V(1))),I,D,L(A(V(0),om)),L(A(V(0),D)),L(A(A(V(0),om),om)),*[L(L(v)) for v in bodies]]
    rs=[R,om,L(om),D]
    ms=[I,KI,L(L(V(1))),D]
    for m in ms:
        for aa in [[],[om],[om,om],[om]*3,[om]*4,[om]*6,[D,D],[I,om],[om,I],[D,om],[om,D],[D,D,om,om]]:
            for c,r in product(cs,rs):
                k=target_steps(c,m,r,aa)
                if k is not None:yield c,m,r,aa,k
def probe(e,c,m,r,aa):
    return appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa)
def tests(s,options):
    e=lc.decode(s)[0]
    for c,m,r,aa,k in options:
        q=probe(e,c,m,r,aa)
        t=q;ps=[]
        for i in range(35):
            p=weak_path(t)
            if p is None:break
            # First positively recognize a literal omega prefix.
            h,args=apps_spine(t)
            if h==om[1] and args and args[0]==om[1]:
                return ('omega',list(map(lc.enc,[c,m,r])),list(map(lc.enc,aa)),k,ps,[],0,'site',None)
            t=bounded(t,p)
            if t is None:break
            ps.append(p)
        # A source beta reduct with irreversible head disagreement.
        if t is not None and weak_path(t) is None:
            want=appall(A(A(c,L(m)),r),aa)
            for _ in range(k):want=red(want,head_path(want))
            b1,h1,a1=spine(t);b2,h2,a2=spine(want)
            if b1>b2 or h1[0]=='V' and (b1,h1,len(a1))!=(b2,h2,len(a2)):
                return ('mismatch',list(map(lc.enc,[c,m,r])),list(map(lc.enc,aa)),k,ps,[],0,'site',None)
def main():
    opts=list(configs())
    seen=set();opts=[o for o in opts if not ((str(o) in seen) or seen.add(str(o)))]
    print('options',len(opts),flush=True)
    for s in (HERE/'open.txt').read_text().split():
        pr=HERE/('r'+str(int(s,2))+'.json')
        if pr.exists() and json.loads(pr.read_text())[1]!='bottom1':continue
        r=tests(s,opts)
        if r:(HERE/('p'+str(int(s,2))+'.json')).write_text(json.dumps(r))
        print(s,(r[:3] if r else 'open'),flush=True)
if __name__=='__main__':main()
