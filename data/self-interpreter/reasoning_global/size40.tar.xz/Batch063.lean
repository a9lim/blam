import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302896274542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302896274542 : Closed e302896274542 ∧ code e302896274542 = 1402407902318 := by decide
theorem cert_e302896274542 : check e302896274542 [[],[],[],[]] .sourceHead = true := by decide
def e302896274554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302896274554 : Closed e302896274554 ∧ code e302896274554 = 1402407902330 := by decide
theorem cert_e302896274554 : check e302896274554 [[],[],[],[]] .sourceHead = true := by decide
def e302896274718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302896274718 : Closed e302896274718 ∧ code e302896274718 = 1402407902494 := by decide
theorem cert_e302896274718 : check e302896274718 [[],[],[],[]] .sourceHead = true := by decide
def e302896274886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302896274886 : Closed e302896274886 ∧ code e302896274886 = 1402407902662 := by decide
theorem cert_e302896274886 : check e302896274886 [[],[],[],[]] .sourceHead = true := by decide
def e302896274998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302896274998 : Closed e302896274998 ∧ code e302896274998 = 1402407902774 := by decide
theorem cert_e302896274998 : check e302896274998 [[],[],[],[]] .sourceHead = true := by decide
def e302896275002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302896275002 : Closed e302896275002 ∧ code e302896275002 = 1402407902778 := by decide
theorem cert_e302896275002 : check e302896275002 [[],[],[],[]] .sourceHead = true := by decide
def e302896275086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302896275086 : Closed e302896275086 ∧ code e302896275086 = 1402407902862 := by decide
theorem cert_e302896275086 : check e302896275086 [[],[],[],[]] .sourceHead = true := by decide
def e302896275142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302896275142 : Closed e302896275142 ∧ code e302896275142 = 1402407902918 := by decide
theorem cert_e302896275142 : check e302896275142 [[],[],[],[]] .sourceHead = true := by decide
def e302896277278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302896277278 : Closed e302896277278 ∧ code e302896277278 = 1402407905054 := by decide
theorem cert_e302896277278 : check e302896277278 [[],[],[],[]] .sourceHead = true := by decide
def e302896277390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302896277390 : Closed e302896277390 ∧ code e302896277390 = 1402407905166 := by decide
theorem cert_e302896277390 : check e302896277390 [[],[],[],[]] .sourceHead = true := by decide
def e302896279774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e302896279774 : Closed e302896279774 ∧ code e302896279774 = 1402407907550 := by decide
theorem cert_e302896279774 : check e302896279774 [[],[],[],[]] .sourceHead = true := by decide
def e302896279802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e302896279802 : Closed e302896279802 ∧ code e302896279802 = 1402407907578 := by decide
theorem cert_e302896279802 : check e302896279802 [[],[],[],[]] .sourceHead = true := by decide
def e302896280350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302896280350 : Closed e302896280350 ∧ code e302896280350 = 1402407908126 := by decide
theorem cert_e302896280350 : check e302896280350 [[],[],[],[]] .sourceHead = true := by decide
def e302896280518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302896280518 : Closed e302896280518 ∧ code e302896280518 = 1402407908294 := by decide
theorem cert_e302896280518 : check e302896280518 [[],[],[],[]] .sourceHead = true := by decide
def e302896281710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e302896281710 : Closed e302896281710 ∧ code e302896281710 = 1402407909486 := by decide
theorem cert_e302896281710 : check e302896281710 [[],[],[],[]] .sourceHead = true := by decide
def e302896281722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e302896281722 : Closed e302896281722 ∧ code e302896281722 = 1402407909498 := by decide
theorem cert_e302896281722 : check e302896281722 [[],[],[],[]] .sourceHead = true := by decide
def e302896281998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302896281998 : Closed e302896281998 ∧ code e302896281998 = 1402407909774 := by decide
theorem cert_e302896281998 : check e302896281998 [[],[],[],[]] .sourceHead = true := by decide
def e302896282054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302896282054 : Closed e302896282054 ∧ code e302896282054 = 1402407909830 := by decide
theorem cert_e302896282054 : check e302896282054 [[],[],[],[]] .sourceHead = true := by decide
def e302896319342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302896319342 : Closed e302896319342 ∧ code e302896319342 = 1402407947118 := by decide
theorem cert_e302896319342 : check e302896319342 [[],[],[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302896319350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302896319350 : Closed e302896319350 ∧ code e302896319350 = 1402407947126 := by decide
private def t_e302896319350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e302896319350 : ¬ IsSelfInterpreter e302896319350 :=
  wSource (t := t_e302896319350) (replay_sound (ps := []) (t := e302896319350) (by decide)) (by decide)
def e302896319406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302896319406 : Closed e302896319406 ∧ code e302896319406 = 1402407947182 := by decide
theorem cert_e302896319406 : checkPay e302896319406 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e302896319418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302896319418 : Closed e302896319418 ∧ code e302896319418 = 1402407947194 := by decide
theorem cert_e302896319418 : checkPay e302896319418 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302896319446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302896319446 : Closed e302896319446 ∧ code e302896319446 = 1402407947222 := by decide
private def t_e302896319446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e302896319446 : ¬ IsSelfInterpreter e302896319446 :=
  wSource (t := t_e302896319446) (replay_sound (ps := []) (t := e302896319446) (by decide)) (by decide)
def e302896319450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302896319450 : Closed e302896319450 ∧ code e302896319450 = 1402407947226 := by decide
theorem cert_e302896319450 : check e302896319450 [[],[],[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302896319726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302896319726 : Closed e302896319726 ∧ code e302896319726 = 1402407947502 := by decide
theorem cert_e302896319726 : checkPay e302896319726 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e302896319734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302896319734 : Closed e302896319734 ∧ code e302896319734 = 1402407947510 := by decide
theorem cert_e302896319734 : check e302896319734 [[],[],[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302896320062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e302896320062 : Closed e302896320062 ∧ code e302896320062 = 1402407947838 := by decide
theorem cert_e302896320062 : check e302896320062 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e302896320110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302896320110 : Closed e302896320110 ∧ code e302896320110 = 1402407947886 := by decide
theorem cert_e302896320110 : check e302896320110 [[],[],[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302896320122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302896320122 : Closed e302896320122 ∧ code e302896320122 = 1402407947898 := by decide
theorem cert_e302896320122 : check e302896320122 [[],[],[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302896320310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302896320310 : Closed e302896320310 ∧ code e302896320310 = 1402407948086 := by decide
theorem cert_e302896320310 : check e302896320310 [[],[],[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302896320314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302896320314 : Closed e302896320314 ∧ code e302896320314 = 1402407948090 := by decide
theorem cert_e302896320314 : check e302896320314 [[],[],[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302896320398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e302896320398 : Closed e302896320398 ∧ code e302896320398 = 1402407948174 := by decide
theorem cert_e302896320398 : check e302896320398 [[],[],[],[],[.under],[.under,.under]] .chain = true := by decide
def e302896327790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302896327790 : Closed e302896327790 ∧ code e302896327790 = 1402407955566 := by decide
theorem cert_e302896327790 : check e302896327790 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896327802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302896327802 : Closed e302896327802 ∧ code e302896327802 = 1402407955578 := by decide
theorem cert_e302896327802 : check e302896327802 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896327966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302896327966 : Closed e302896327966 ∧ code e302896327966 = 1402407955742 := by decide
theorem cert_e302896327966 : check e302896327966 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896328134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302896328134 : Closed e302896328134 ∧ code e302896328134 = 1402407955910 := by decide
theorem cert_e302896328134 : check e302896328134 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896328474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302896328474 : Closed e302896328474 ∧ code e302896328474 = 1402407956250 := by decide
theorem cert_e302896328474 : check e302896328474 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302896328518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302896328518 : Closed e302896328518 ∧ code e302896328518 = 1402407956294 := by decide
theorem cert_e302896328518 : check e302896328518 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302896328926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e302896328926 : Closed e302896328926 ∧ code e302896328926 = 1402407956702 := by decide
theorem cert_e302896328926 : checkPay e302896328926 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896328954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e302896328954 : Closed e302896328954 ∧ code e302896328954 = 1402407956730 := by decide
theorem cert_e302896328954 : checkPay e302896328954 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e302896329502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302896329502 : Closed e302896329502 ∧ code e302896329502 = 1402407957278 := by decide
theorem cert_e302896329502 : checkPay e302896329502 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e302896329670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302896329670 : Closed e302896329670 ∧ code e302896329670 = 1402407957446 := by decide
theorem cert_e302896329670 : checkPay e302896329670 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[]] = true := by decide
def e302896331830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302896331830 : Closed e302896331830 ∧ code e302896331830 = 1402407959606 := by decide
theorem cert_e302896331830 : check e302896331830 [[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896331834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302896331834 : Closed e302896331834 ∧ code e302896331834 = 1402407959610 := by decide
theorem cert_e302896331834 : check e302896331834 [[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e302896331974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302896331974 : Closed e302896331974 ∧ code e302896331974 = 1402407959750 := by decide
theorem cert_e302896331974 : check e302896331974 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302896351006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302896351006 : Closed e302896351006 ∧ code e302896351006 = 1402407978782 := by decide
theorem cert_e302896351006 : check e302896351006 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e302896351118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302896351118 : Closed e302896351118 ∧ code e302896351118 = 1402407978894 := by decide
theorem cert_e302896351118 : check e302896351118 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e302896354870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302896354870 : Closed e302896354870 ∧ code e302896354870 = 1402407982646 := by decide
theorem cert_e302896354870 : check e302896354870 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896354874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302896354874 : Closed e302896354874 ∧ code e302896354874 = 1402407982650 := by decide
theorem cert_e302896354874 : check e302896354874 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896354958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302896354958 : Closed e302896354958 ∧ code e302896354958 = 1402407982734 := by decide
theorem cert_e302896354958 : check e302896354958 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896355014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302896355014 : Closed e302896355014 ∧ code e302896355014 = 1402407982790 := by decide
theorem cert_e302896355014 : check e302896355014 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896355098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302896355098 : Closed e302896355098 ∧ code e302896355098 = 1402407982874 := by decide
theorem cert_e302896355098 : check e302896355098 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e302896355142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302896355142 : Closed e302896355142 ∧ code e302896355142 = 1402407982918 := by decide
theorem cert_e302896355142 : check e302896355142 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e302896355438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e302896355438 : Closed e302896355438 ∧ code e302896355438 = 1402407983214 := by decide
theorem cert_e302896355438 : check e302896355438 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896355450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e302896355450 : Closed e302896355450 ∧ code e302896355450 = 1402407983226 := by decide
theorem cert_e302896355450 : check e302896355450 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896355726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302896355726 : Closed e302896355726 ∧ code e302896355726 = 1402407983502 := by decide
theorem cert_e302896355726 : check e302896355726 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896355782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302896355782 : Closed e302896355782 ∧ code e302896355782 = 1402407983558 := by decide
theorem cert_e302896355782 : check e302896355782 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e302896356406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302896356406 : Closed e302896356406 ∧ code e302896356406 = 1402407984182 := by decide
theorem cert_e302896356406 : check e302896356406 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302896356410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302896356410 : Closed e302896356410 ∧ code e302896356410 = 1402407984186 := by decide
theorem cert_e302896356410 : check e302896356410 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302896356550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302896356550 : Closed e302896356550 ∧ code e302896356550 = 1402407984326 := by decide
theorem cert_e302896356550 : check e302896356550 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e302897436382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302897436382 : Closed e302897436382 ∧ code e302897436382 = 1402409064158 := by decide
theorem cert_e302897436382 : check e302897436382 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897436406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302897436406 : Closed e302897436406 ∧ code e302897436406 = 1402409064182 := by decide
theorem cert_e302897436406 : check e302897436406 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897436510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302897436510 : Closed e302897436510 ∧ code e302897436510 = 1402409064286 := by decide
theorem cert_e302897436510 : check e302897436510 [[],[],[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302897436538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302897436538 : Closed e302897436538 ∧ code e302897436538 = 1402409064314 := by decide
private def t_e302897436538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem cert_e302897436538 : ¬ IsSelfInterpreter e302897436538 :=
  wSource (t := t_e302897436538) (replay_sound (ps := []) (t := e302897436538) (by decide)) (by decide)
def e302897436630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302897436630 : Closed e302897436630 ∧ code e302897436630 = 1402409064406 := by decide
theorem cert_e302897436630 : check e302897436630 [[],[],[],[],[],[],[.under,.left]] .chain = true := by decide
def e302897436634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302897436634 : Closed e302897436634 ∧ code e302897436634 = 1402409064410 := by decide
private def t_e302897436634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem cert_e302897436634 : ¬ IsSelfInterpreter e302897436634 :=
  wSource (t := t_e302897436634) (replay_sound (ps := []) (t := e302897436634) (by decide)) (by decide)
def e302897437150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302897437150 : Closed e302897437150 ∧ code e302897437150 = 1402409064926 := by decide
theorem cert_e302897437150 : check e302897437150 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897437174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302897437174 : Closed e302897437174 ∧ code e302897437174 = 1402409064950 := by decide
theorem cert_e302897437174 : check e302897437174 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897437918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302897437918 : Closed e302897437918 ∧ code e302897437918 = 1402409065694 := by decide
theorem cert_e302897437918 : checkPay e302897437918 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e302897437946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302897437946 : Closed e302897437946 ∧ code e302897437946 = 1402409065722 := by decide
theorem cert_e302897437946 : check e302897437946 [[],[],[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e302897438518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302897438518 : Closed e302897438518 ∧ code e302897438518 = 1402409066294 := by decide
theorem cert_e302897438518 : check e302897438518 [[],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e302897438522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302897438522 : Closed e302897438522 ∧ code e302897438522 = 1402409066298 := by decide
theorem cert_e302897438522 : check e302897438522 [[],[],[],[],[],[],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e302897453294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302897453294 : Closed e302897453294 ∧ code e302897453294 = 1402409081070 := by decide
def e302897453302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302897453302 : Closed e302897453302 ∧ code e302897453302 = 1402409081078 := by decide
def e302897453854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302897453854 : Closed e302897453854 ∧ code e302897453854 = 1402409081630 := by decide
private def t_e302897453854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem cert_e302897453854 : ¬ IsSelfInterpreter e302897453854 :=
  wSource (t := t_e302897453854) (replay_sound (ps := []) (t := e302897453854) (by decide)) (by decide)
def e302897453966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302897453966 : Closed e302897453966 ∧ code e302897453966 = 1402409081742 := by decide
private def t_e302897453966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem cert_e302897453966 : ¬ IsSelfInterpreter e302897453966 :=
  wSource (t := t_e302897453966) (replay_sound (ps := []) (t := e302897453966) (by decide)) (by decide)
def e302897454190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302897454190 : Closed e302897454190 ∧ code e302897454190 = 1402409081966 := by decide
def e302897454202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302897454202 : Closed e302897454202 ∧ code e302897454202 = 1402409081978 := by decide
def e302897454366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302897454366 : Closed e302897454366 ∧ code e302897454366 = 1402409082142 := by decide
private def t_e302897454366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem cert_e302897454366 : ¬ IsSelfInterpreter e302897454366 :=
  wSource (t := t_e302897454366) (replay_sound (ps := []) (t := e302897454366) (by decide)) (by decide)
def e302897454534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302897454534 : Closed e302897454534 ∧ code e302897454534 = 1402409082310 := by decide
private def t_e302897454534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e302897454534 : ¬ IsSelfInterpreter e302897454534 :=
  wSource (t := t_e302897454534) (replay_sound (ps := []) (t := e302897454534) (by decide)) (by decide)
def e302897454646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302897454646 : Closed e302897454646 ∧ code e302897454646 = 1402409082422 := by decide
def e302897454650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302897454650 : Closed e302897454650 ∧ code e302897454650 = 1402409082426 := by decide
def e302897454734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302897454734 : Closed e302897454734 ∧ code e302897454734 = 1402409082510 := by decide
private def t_e302897454734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem cert_e302897454734 : ¬ IsSelfInterpreter e302897454734 :=
  wSource (t := t_e302897454734) (replay_sound (ps := []) (t := e302897454734) (by decide)) (by decide)
def e302897454790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302897454790 : Closed e302897454790 ∧ code e302897454790 = 1402409082566 := by decide
private def t_e302897454790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e302897454790 : ¬ IsSelfInterpreter e302897454790 :=
  wSource (t := t_e302897454790) (replay_sound (ps := []) (t := e302897454790) (by decide)) (by decide)
def e302897456926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302897456926 : Closed e302897456926 ∧ code e302897456926 = 1402409084702 := by decide
def e302897457038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302897457038 : Closed e302897457038 ∧ code e302897457038 = 1402409084814 := by decide
def e302897459998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302897459998 : Closed e302897459998 ∧ code e302897459998 = 1402409087774 := by decide
def e302897460166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302897460166 : Closed e302897460166 ∧ code e302897460166 = 1402409087942 := by decide
def e302897461646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302897461646 : Closed e302897461646 ∧ code e302897461646 = 1402409089422 := by decide
def e302897461702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302897461702 : Closed e302897461702 ∧ code e302897461702 = 1402409089478 := by decide
def e302897695598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302897695598 : Closed e302897695598 ∧ code e302897695598 = 1402409323374 := by decide
theorem cert_e302897695598 : check e302897695598 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897695606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302897695606 : Closed e302897695606 ∧ code e302897695606 = 1402409323382 := by decide
theorem cert_e302897695606 : check e302897695606 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897695662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302897695662 : Closed e302897695662 ∧ code e302897695662 = 1402409323438 := by decide
theorem cert_e302897695662 : check e302897695662 [[],[],[],[],[],[],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e302897695674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302897695674 : Closed e302897695674 ∧ code e302897695674 = 1402409323450 := by decide
private def t_e302897695674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e302897695674 : ¬ IsSelfInterpreter e302897695674 :=
  wSource (t := t_e302897695674) (replay_sound (ps := []) (t := e302897695674) (by decide)) (by decide)
def e302897695702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302897695702 : Closed e302897695702 ∧ code e302897695702 = 1402409323478 := by decide
theorem cert_e302897695702 : check e302897695702 [[],[],[],[],[],[],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e302897695706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302897695706 : Closed e302897695706 ∧ code e302897695706 = 1402409323482 := by decide
private def t_e302897695706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e302897695706 : ¬ IsSelfInterpreter e302897695706 :=
  wSource (t := t_e302897695706) (replay_sound (ps := []) (t := e302897695706) (by decide)) (by decide)
def e302897695982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302897695982 : Closed e302897695982 ∧ code e302897695982 = 1402409323758 := by decide
theorem cert_e302897695982 : check e302897695982 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897695990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302897695990 : Closed e302897695990 ∧ code e302897695990 = 1402409323766 := by decide
theorem cert_e302897695990 : check e302897695990 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e302897696366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302897696366 : Closed e302897696366 ∧ code e302897696366 = 1402409324142 := by decide
theorem cert_e302897696366 : check e302897696366 [[],[],[],[],[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e302897696378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302897696378 : Closed e302897696378 ∧ code e302897696378 = 1402409324154 := by decide
theorem cert_e302897696378 : check e302897696378 [[],[],[],[],[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e302897696566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302897696566 : Closed e302897696566 ∧ code e302897696566 = 1402409324342 := by decide
theorem cert_e302897696566 : check e302897696566 [[],[],[],[],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302897696570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302897696570 : Closed e302897696570 ∧ code e302897696570 = 1402409324346 := by decide
theorem cert_e302897696570 : check e302897696570 [[],[],[],[],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e302902154974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302902154974 : Closed e302902154974 ∧ code e302902154974 = 1402413782750 := by decide
theorem cert_e302902154974 : check e302902154974 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e302902154998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302902154998 : Closed e302902154998 ∧ code e302902154998 = 1402413782774 := by decide
theorem cert_e302902154998 : check e302902154998 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e302902155102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302902155102 : Closed e302902155102 ∧ code e302902155102 = 1402413782878 := by decide
def e302902155130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302902155130 : Closed e302902155130 ∧ code e302902155130 = 1402413782906 := by decide
def e302902155222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302902155222 : Closed e302902155222 ∧ code e302902155222 = 1402413782998 := by decide
theorem cert_e302902155222 : check e302902155222 [[],[],[],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e302902155226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302902155226 : Closed e302902155226 ∧ code e302902155226 = 1402413783002 := by decide
def e302902155742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302902155742 : Closed e302902155742 ∧ code e302902155742 = 1402413783518 := by decide
theorem cert_e302902155742 : check e302902155742 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e302902155766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302902155766 : Closed e302902155766 ∧ code e302902155766 = 1402413783542 := by decide
theorem cert_e302902155766 : check e302902155766 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e302902156510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302902156510 : Closed e302902156510 ∧ code e302902156510 = 1402413784286 := by decide
theorem cert_e302902156510 : check e302902156510 [[],[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e302902156538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302902156538 : Closed e302902156538 ∧ code e302902156538 = 1402413784314 := by decide
theorem cert_e302902156538 : check e302902156538 [[],[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e302902157110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302902157110 : Closed e302902157110 ∧ code e302902157110 = 1402413784886 := by decide
theorem cert_e302902157110 : check e302902157110 [[],[],[],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e302902157114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302902157114 : Closed e302902157114 ∧ code e302902157114 = 1402413784890 := by decide
def e302902171886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302902171886 : Closed e302902171886 ∧ code e302902171886 = 1402413799662 := by decide
theorem cert_e302902171886 : check e302902171886 [[],[],[],[.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302902171894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302902171894 : Closed e302902171894 ∧ code e302902171894 = 1402413799670 := by decide
def e302902172446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302902172446 : Closed e302902172446 ∧ code e302902172446 = 1402413800222 := by decide
theorem cert_e302902172446 : check e302902172446 [[],[],[],[.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e302902172558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302902172558 : Closed e302902172558 ∧ code e302902172558 = 1402413800334 := by decide
theorem cert_e302902172558 : check e302902172558 [[],[],[],[.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.left],[],[]] .chain = true := by decide
def e302902172782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302902172782 : Closed e302902172782 ∧ code e302902172782 = 1402413800558 := by decide
def e302902172794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302902172794 : Closed e302902172794 ∧ code e302902172794 = 1402413800570 := by decide
def e302902172958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302902172958 : Closed e302902172958 ∧ code e302902172958 = 1402413800734 := by decide
theorem cert_e302902172958 : check e302902172958 [[],[],[],[.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e302902173126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302902173126 : Closed e302902173126 ∧ code e302902173126 = 1402413800902 := by decide
private def t_e302902173126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e302902173126 : ¬ IsSelfInterpreter e302902173126 :=
  wSource (t := t_e302902173126) (replay_sound (ps := []) (t := e302902173126) (by decide)) (by decide)
def e302902173238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302902173238 : Closed e302902173238 ∧ code e302902173238 = 1402413801014 := by decide
def e302902173242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302902173242 : Closed e302902173242 ∧ code e302902173242 = 1402413801018 := by decide
theorem cert_e302902173242 : check e302902173242 [[],[],[],[.left],[.left],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302902173326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302902173326 : Closed e302902173326 ∧ code e302902173326 = 1402413801102 := by decide
def e302902173382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302902173382 : Closed e302902173382 ∧ code e302902173382 = 1402413801158 := by decide
private def t_e302902173382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e302902173382 : ¬ IsSelfInterpreter e302902173382 :=
  wSource (t := t_e302902173382) (replay_sound (ps := []) (t := e302902173382) (by decide)) (by decide)
def e302902175518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302902175518 : Closed e302902175518 ∧ code e302902175518 = 1402413803294 := by decide
def e302902175630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302902175630 : Closed e302902175630 ∧ code e302902175630 = 1402413803406 := by decide
theorem cert_e302902175630 : check e302902175630 [[],[],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e302902178590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302902178590 : Closed e302902178590 ∧ code e302902178590 = 1402413806366 := by decide
def e302902178758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302902178758 : Closed e302902178758 ∧ code e302902178758 = 1402413806534 := by decide
def e302902180238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302902180238 : Closed e302902180238 ∧ code e302902180238 = 1402413808014 := by decide
def e302902180294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302902180294 : Closed e302902180294 ∧ code e302902180294 = 1402413808070 := by decide
def e350578128610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e350578128610 : Closed e350578128610 ∧ code e350578128610 = 1450089756386 := by decide
theorem cert_e350578128610 : check e350578128610 [[.left],[.left]] .chain = true := by decide
def e350578128738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578128738 : Closed e350578128738 ∧ code e350578128738 = 1450089756514 := by decide
theorem cert_e350578128738 : check e350578128738 [[.left],[.left]] .chain = true := by decide
def e350578129762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578129762 : Closed e350578129762 ∧ code e350578129762 = 1450089757538 := by decide
theorem cert_e350578129762 : check e350578129762 [[.left],[.left]] .chain = true := by decide
def e350578136802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e350578136802 : Closed e350578136802 ∧ code e350578136802 = 1450089764578 := by decide
theorem cert_e350578136802 : check e350578136802 [[.left],[.left]] .chain = true := by decide
def e350578136930 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578136930 : Closed e350578136930 ∧ code e350578136930 = 1450089764706 := by decide
theorem cert_e350578136930 : check e350578136930 [[.left],[.left]] .chain = true := by decide
def e350578137826 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e350578137826 : Closed e350578137826 ∧ code e350578137826 = 1450089765602 := by decide
theorem cert_e350578137826 : check e350578137826 [[.left],[.left]] .chain = true := by decide
def e350578138018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e350578138018 : Closed e350578138018 ∧ code e350578138018 = 1450089765794 := by decide
theorem cert_e350578138018 : check e350578138018 [[.left],[.left]] .chain = true := by decide
def e350578138466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578138466 : Closed e350578138466 ∧ code e350578138466 = 1450089766242 := by decide
theorem cert_e350578138466 : check e350578138466 [[.left],[.left]] .chain = true := by decide
def e350578138530 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e350578138530 : Closed e350578138530 ∧ code e350578138530 = 1450089766306 := by decide
theorem cert_e350578138530 : check e350578138530 [[.left],[.left]] .chain = true := by decide
def e350578142050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578142050 : Closed e350578142050 ∧ code e350578142050 = 1450089769826 := by decide
theorem cert_e350578142050 : check e350578142050 [[.left],[.left]] .chain = true := by decide
def e350578142562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578142562 : Closed e350578142562 ∧ code e350578142562 = 1450089770338 := by decide
theorem cert_e350578142562 : check e350578142562 [[.left],[.left]] .chain = true := by decide
def e350578142626 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e350578142626 : Closed e350578142626 ∧ code e350578142626 = 1450089770402 := by decide
theorem cert_e350578142626 : check e350578142626 [[.left],[.left]] .chain = true := by decide
def e350578177762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e350578177762 : Closed e350578177762 ∧ code e350578177762 = 1450089805538 := by decide
theorem cert_e350578177762 : check e350578177762 [[.left],[.left]] .chain = true := by decide
def e350578177890 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578177890 : Closed e350578177890 ∧ code e350578177890 = 1450089805666 := by decide
theorem cert_e350578177890 : check e350578177890 [[.left],[.left]] .chain = true := by decide
def e350578178914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578178914 : Closed e350578178914 ∧ code e350578178914 = 1450089806690 := by decide
theorem cert_e350578178914 : check e350578178914 [[.left],[.left]] .chain = true := by decide
def e350578200290 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350578200290 : Closed e350578200290 ∧ code e350578200290 = 1450089828066 := by decide
theorem cert_e350578200290 : check e350578200290 [[.left],[.left]] .chain = true := by decide
def e350578200418 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578200418 : Closed e350578200418 ∧ code e350578200418 = 1450089828194 := by decide
theorem cert_e350578200418 : check e350578200418 [[.left],[.left]] .chain = true := by decide
def e350578206562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578206562 : Closed e350578206562 ∧ code e350578206562 = 1450089834338 := by decide
theorem cert_e350578206562 : check e350578206562 [[.left],[.left]] .chain = true := by decide
def e350578226914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e350578226914 : Closed e350578226914 ∧ code e350578226914 = 1450089854690 := by decide
theorem cert_e350578226914 : check e350578226914 [[.left],[.left]] .chain = true := by decide
def e350578227042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578227042 : Closed e350578227042 ∧ code e350578227042 = 1450089854818 := by decide
theorem cert_e350578227042 : check e350578227042 [[.left],[.left]] .chain = true := by decide
def e350578227938 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e350578227938 : Closed e350578227938 ∧ code e350578227938 = 1450089855714 := by decide
theorem cert_e350578227938 : check e350578227938 [[.left],[.left]] .chain = true := by decide
def e350578228130 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e350578228130 : Closed e350578228130 ∧ code e350578228130 = 1450089855906 := by decide
theorem cert_e350578228130 : check e350578228130 [[.left],[.left]] .chain = true := by decide
def e350578228578 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578228578 : Closed e350578228578 ∧ code e350578228578 = 1450089856354 := by decide
theorem cert_e350578228578 : check e350578228578 [[.left],[.left]] .chain = true := by decide
def e350578228642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e350578228642 : Closed e350578228642 ∧ code e350578228642 = 1450089856418 := by decide
theorem cert_e350578228642 : check e350578228642 [[.left],[.left]] .chain = true := by decide
def e350578233058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350578233058 : Closed e350578233058 ∧ code e350578233058 = 1450089860834 := by decide
theorem cert_e350578233058 : check e350578233058 [[.left],[.left]] .chain = true := by decide
def e350578233186 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578233186 : Closed e350578233186 ∧ code e350578233186 = 1450089860962 := by decide
theorem cert_e350578233186 : check e350578233186 [[.left],[.left]] .chain = true := by decide
def e350578239202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350578239202 : Closed e350578239202 ∧ code e350578239202 = 1450089866978 := by decide
theorem cert_e350578239202 : check e350578239202 [[.left],[.left]] .chain = true := by decide
def e350578239394 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350578239394 : Closed e350578239394 ∧ code e350578239394 = 1450089867170 := by decide
theorem cert_e350578239394 : check e350578239394 [[.left],[.left]] .chain = true := by decide
end Blc.Floor40
