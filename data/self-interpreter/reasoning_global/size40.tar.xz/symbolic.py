from candidates import *
from functools import lru_cache
class M:
    def __init__(self,kind):self.kind=kind;self.N=('N',)
    def call(self,h,stack):
        k=self.kind
        if h[0]=='N':
            x,*args=stack
            if k==2:return x,[('B',x),x,*args]
            return x,[('A',x,('B',x)),*args]
        if h[0]=='B':
            x=h[1];y,z,*args=stack
            if k==2:return x,[('A',z,('K',y)),*args]
            return x,[('A',y,('K',z)),*args]
        if h[0]=='K':
            _,*args=stack
            return h[1],args
        x,y=h[1:];return x,[y,*stack]
def show(x,d=5):
 if d==0:return '…'
 if x[0]=='A':return '('+show(x[1],d-1)+' '+show(x[2],d-1)+')'
 return x[0]+('('+show(x[1],d-1)+')' if len(x)>1 else '')
if __name__=='__main__':
 for k in [2,3]:
    m=M(k);h=m.N;ss=[h]
    print('CASE',k)
    for j in range(65):
        if h[0]!='A':print(j,show(h,5),' '.join(show(x,4) for x in ss[:4]),'stack',len(ss))
        try:h,ss=m.call(h,ss)
        except ValueError:print('STOP');break
