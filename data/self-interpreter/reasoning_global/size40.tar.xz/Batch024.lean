import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301453958266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e301453958266 : Closed e301453958266 ∧ code e301453958266 = 1400965586042 := by decide
theorem cert_e301453958266 : check e301453958266 [[],[]] .chain = true := by decide
def e301453958430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e301453958430 : Closed e301453958430 ∧ code e301453958430 = 1400965586206 := by decide
theorem cert_e301453958430 : check e301453958430 [[],[]] .chain = true := by decide
def e301453958598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e301453958598 : Closed e301453958598 ∧ code e301453958598 = 1400965586374 := by decide
theorem cert_e301453958598 : check e301453958598 [[],[]] .chain = true := by decide
def e301453958710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e301453958710 : Closed e301453958710 ∧ code e301453958710 = 1400965586486 := by decide
theorem cert_e301453958710 : check e301453958710 [[],[]] .chain = true := by decide
def e301453958714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e301453958714 : Closed e301453958714 ∧ code e301453958714 = 1400965586490 := by decide
theorem cert_e301453958714 : check e301453958714 [[],[]] .chain = true := by decide
def e301453958762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e301453958762 : Closed e301453958762 ∧ code e301453958762 = 1400965586538 := by decide
theorem cert_e301453958762 : check e301453958762 [[],[]] .chain = true := by decide
def e301453958798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e301453958798 : Closed e301453958798 ∧ code e301453958798 = 1400965586574 := by decide
theorem cert_e301453958798 : check e301453958798 [[],[]] .chain = true := by decide
def e301453958810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e301453958810 : Closed e301453958810 ∧ code e301453958810 = 1400965586586 := by decide
theorem cert_e301453958810 : check e301453958810 [[],[]] .chain = true := by decide
def e301453958854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e301453958854 : Closed e301453958854 ∧ code e301453958854 = 1400965586630 := by decide
theorem cert_e301453958854 : check e301453958854 [[],[]] .chain = true := by decide
def e301453959646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e301453959646 : Closed e301453959646 ∧ code e301453959646 = 1400965587422 := by decide
theorem cert_e301453959646 : check e301453959646 [[],[]] .chain = true := by decide
def e301453959670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e301453959670 : Closed e301453959670 ∧ code e301453959670 = 1400965587446 := by decide
theorem cert_e301453959670 : check e301453959670 [[],[]] .chain = true := by decide
def e301453960622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e301453960622 : Closed e301453960622 ∧ code e301453960622 = 1400965588398 := by decide
theorem cert_e301453960622 : check e301453960622 [[],[]] .chain = true := by decide
def e301453960634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e301453960634 : Closed e301453960634 ∧ code e301453960634 = 1400965588410 := by decide
theorem cert_e301453960634 : check e301453960634 [[],[]] .chain = true := by decide
def e301453960682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e301453960682 : Closed e301453960682 ∧ code e301453960682 = 1400965588458 := by decide
theorem cert_e301453960682 : check e301453960682 [[],[]] .chain = true := by decide
def e301453960814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453960814 : Closed e301453960814 ∧ code e301453960814 = 1400965588590 := by decide
theorem cert_e301453960814 : check e301453960814 [[],[]] .chain = true := by decide
def e301453960826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453960826 : Closed e301453960826 ∧ code e301453960826 = 1400965588602 := by decide
theorem cert_e301453960826 : check e301453960826 [[],[]] .chain = true := by decide
def e301453960990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e301453960990 : Closed e301453960990 ∧ code e301453960990 = 1400965588766 := by decide
theorem cert_e301453960990 : check e301453960990 [[],[]] .chain = true := by decide
def e301453961102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e301453961102 : Closed e301453961102 ∧ code e301453961102 = 1400965588878 := by decide
theorem cert_e301453961102 : check e301453961102 [[],[]] .chain = true := by decide
def e301453961114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453961114 : Closed e301453961114 ∧ code e301453961114 = 1400965588890 := by decide
theorem cert_e301453961114 : check e301453961114 [[],[]] .chain = true := by decide
def e301453964062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e301453964062 : Closed e301453964062 ∧ code e301453964062 = 1400965591838 := by decide
theorem cert_e301453964062 : check e301453964062 [[],[]] .chain = true := by decide
def e301453964230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e301453964230 : Closed e301453964230 ∧ code e301453964230 = 1400965592006 := by decide
theorem cert_e301453964230 : check e301453964230 [[],[]] .chain = true := by decide
def e301453965430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e301453965430 : Closed e301453965430 ∧ code e301453965430 = 1400965593206 := by decide
theorem cert_e301453965430 : check e301453965430 [[],[]] .chain = true := by decide
def e301453965674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e301453965674 : Closed e301453965674 ∧ code e301453965674 = 1400965593450 := by decide
theorem cert_e301453965674 : check e301453965674 [[],[]] .chain = true := by decide
def e301453965710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e301453965710 : Closed e301453965710 ∧ code e301453965710 = 1400965593486 := by decide
theorem cert_e301453965710 : check e301453965710 [[],[]] .chain = true := by decide
def e301453965722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453965722 : Closed e301453965722 ∧ code e301453965722 = 1400965593498 := by decide
theorem cert_e301453965722 : check e301453965722 [[],[]] .chain = true := by decide
def e301453965766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e301453965766 : Closed e301453965766 ∧ code e301453965766 = 1400965593542 := by decide
theorem cert_e301453965766 : check e301453965766 [[],[]] .chain = true := by decide
def e301454011222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e301454011222 : Closed e301454011222 ∧ code e301454011222 = 1400965638998 := by decide
theorem cert_e301454011222 : check e301454011222 [[],[]] .chain = true := by decide
def e301454011226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e301454011226 : Closed e301454011226 ∧ code e301454011226 = 1400965639002 := by decide
theorem cert_e301454011226 : check e301454011226 [[],[]] .chain = true := by decide
def e301454011242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e301454011242 : Closed e301454011242 ∧ code e301454011242 = 1400965639018 := by decide
theorem cert_e301454011242 : check e301454011242 [[],[]] .chain = true := by decide
def e301454011306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e301454011306 : Closed e301454011306 ∧ code e301454011306 = 1400965639082 := by decide
theorem cert_e301454011306 : check e301454011306 [[],[]] .chain = true := by decide
def e301454011510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e301454011510 : Closed e301454011510 ∧ code e301454011510 = 1400965639286 := by decide
theorem cert_e301454011510 : check e301454011510 [[],[]] .chain = true := by decide
def e301454011606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e301454011606 : Closed e301454011606 ∧ code e301454011606 = 1400965639382 := by decide
theorem cert_e301454011606 : check e301454011606 [[],[]] .chain = true := by decide
def e301454011610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e301454011610 : Closed e301454011610 ∧ code e301454011610 = 1400965639386 := by decide
theorem cert_e301454011610 : check e301454011610 [[],[]] .chain = true := by decide
def e301454011626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e301454011626 : Closed e301454011626 ∧ code e301454011626 = 1400965639402 := by decide
theorem cert_e301454011626 : check e301454011626 [[],[]] .chain = true := by decide
def e301454011702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e301454011702 : Closed e301454011702 ∧ code e301454011702 = 1400965639478 := by decide
theorem cert_e301454011702 : check e301454011702 [[],[]] .chain = true := by decide
def e301454011706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e301454011706 : Closed e301454011706 ∧ code e301454011706 = 1400965639482 := by decide
theorem cert_e301454011706 : check e301454011706 [[],[]] .chain = true := by decide
def e301454011790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e301454011790 : Closed e301454011790 ∧ code e301454011790 = 1400965639566 := by decide
theorem cert_e301454011790 : check e301454011790 [[],[]] .chain = true := by decide
def e301454011802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e301454011802 : Closed e301454011802 ∧ code e301454011802 = 1400965639578 := by decide
theorem cert_e301454011802 : check e301454011802 [[],[]] .chain = true := by decide
def e301454011958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e301454011958 : Closed e301454011958 ∧ code e301454011958 = 1400965639734 := by decide
theorem cert_e301454011958 : check e301454011958 [[],[]] .chain = true := by decide
def e301454011962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e301454011962 : Closed e301454011962 ∧ code e301454011962 = 1400965639738 := by decide
theorem cert_e301454011962 : check e301454011962 [[],[]] .chain = true := by decide
def e301454012010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e301454012010 : Closed e301454012010 ∧ code e301454012010 = 1400965639786 := by decide
theorem cert_e301454012010 : check e301454012010 [[],[]] .chain = true := by decide
def e301454012046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e301454012046 : Closed e301454012046 ∧ code e301454012046 = 1400965639822 := by decide
theorem cert_e301454012046 : check e301454012046 [[],[]] .chain = true := by decide
def e301454012058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e301454012058 : Closed e301454012058 ∧ code e301454012058 = 1400965639834 := by decide
theorem cert_e301454012058 : check e301454012058 [[],[]] .chain = true := by decide
def e301454012102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e301454012102 : Closed e301454012102 ∧ code e301454012102 = 1400965639878 := by decide
theorem cert_e301454012102 : check e301454012102 [[],[]] .chain = true := by decide
def e301454012654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e301454012654 : Closed e301454012654 ∧ code e301454012654 = 1400965640430 := by decide
theorem cert_e301454012654 : check e301454012654 [[],[]] .chain = true := by decide
def e301454012662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e301454012662 : Closed e301454012662 ∧ code e301454012662 = 1400965640438 := by decide
theorem cert_e301454012662 : check e301454012662 [[],[]] .chain = true := by decide
def e301454013142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e301454013142 : Closed e301454013142 ∧ code e301454013142 = 1400965640918 := by decide
theorem cert_e301454013142 : check e301454013142 [[],[]] .chain = true := by decide
def e301454013146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e301454013146 : Closed e301454013146 ∧ code e301454013146 = 1400965640922 := by decide
theorem cert_e301454013146 : check e301454013146 [[],[]] .chain = true := by decide
def e301454013162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e301454013162 : Closed e301454013162 ∧ code e301454013162 = 1400965640938 := by decide
theorem cert_e301454013162 : check e301454013162 [[],[]] .chain = true := by decide
def e301454013238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e301454013238 : Closed e301454013238 ∧ code e301454013238 = 1400965641014 := by decide
theorem cert_e301454013238 : check e301454013238 [[],[]] .chain = true := by decide
def e301454013242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e301454013242 : Closed e301454013242 ∧ code e301454013242 = 1400965641018 := by decide
theorem cert_e301454013242 : check e301454013242 [[],[]] .chain = true := by decide
def e301454013326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e301454013326 : Closed e301454013326 ∧ code e301454013326 = 1400965641102 := by decide
theorem cert_e301454013326 : check e301454013326 [[],[]] .chain = true := by decide
def e301454013338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e301454013338 : Closed e301454013338 ∧ code e301454013338 = 1400965641114 := by decide
theorem cert_e301454013338 : check e301454013338 [[],[]] .chain = true := by decide
def e301454014582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e301454014582 : Closed e301454014582 ∧ code e301454014582 = 1400965642358 := by decide
theorem cert_e301454014582 : check e301454014582 [[],[]] .chain = true := by decide
def e301454014826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e301454014826 : Closed e301454014826 ∧ code e301454014826 = 1400965642602 := by decide
theorem cert_e301454014826 : check e301454014826 [[],[]] .chain = true := by decide
def e301454014862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e301454014862 : Closed e301454014862 ∧ code e301454014862 = 1400965642638 := by decide
theorem cert_e301454014862 : check e301454014862 [[],[]] .chain = true := by decide
def e301454014874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e301454014874 : Closed e301454014874 ∧ code e301454014874 = 1400965642650 := by decide
theorem cert_e301454014874 : check e301454014874 [[],[]] .chain = true := by decide
def e301454014918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e301454014918 : Closed e301454014918 ∧ code e301454014918 = 1400965642694 := by decide
theorem cert_e301454014918 : check e301454014918 [[],[]] .chain = true := by decide
def e301455912378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e301455912378 : Closed e301455912378 ∧ code e301455912378 = 1400967540154 := by decide
theorem cert_e301455912378 : check e301455912378 [[],[]] .chain = true := by decide
def e301455912410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e301455912410 : Closed e301455912410 ∧ code e301455912410 = 1400967540186 := by decide
theorem cert_e301455912410 : check e301455912410 [[],[]] .chain = true := by decide
def e301455912634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e301455912634 : Closed e301455912634 ∧ code e301455912634 = 1400967540410 := by decide
theorem cert_e301455912634 : check e301455912634 [[],[]] .chain = true := by decide
def e301455912682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e301455912682 : Closed e301455912682 ∧ code e301455912682 = 1400967540458 := by decide
theorem cert_e301455912682 : check e301455912682 [[],[]] .chain = true := by decide
def e301455912794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e301455912794 : Closed e301455912794 ∧ code e301455912794 = 1400967540570 := by decide
theorem cert_e301455912794 : check e301455912794 [[],[]] .chain = true := by decide
def e301455912810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e301455912810 : Closed e301455912810 ∧ code e301455912810 = 1400967540586 := by decide
theorem cert_e301455912810 : check e301455912810 [[],[]] .chain = true := by decide
def e301455913914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e301455913914 : Closed e301455913914 ∧ code e301455913914 = 1400967541690 := by decide
theorem cert_e301455913914 : check e301455913914 [[],[]] .chain = true := by decide
def e301455913946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e301455913946 : Closed e301455913946 ∧ code e301455913946 = 1400967541722 := by decide
theorem cert_e301455913946 : check e301455913946 [[],[]] .chain = true := by decide
def e301455915450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e301455915450 : Closed e301455915450 ∧ code e301455915450 = 1400967543226 := by decide
theorem cert_e301455915450 : check e301455915450 [[],[]] .chain = true := by decide
def e301455915498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e301455915498 : Closed e301455915498 ∧ code e301455915498 = 1400967543274 := by decide
theorem cert_e301455915498 : check e301455915498 [[],[]] .chain = true := by decide
def e301455916250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e301455916250 : Closed e301455916250 ∧ code e301455916250 = 1400967544026 := by decide
theorem cert_e301455916250 : check e301455916250 [[],[]] .chain = true := by decide
def e301455916266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e301455916266 : Closed e301455916266 ∧ code e301455916266 = 1400967544042 := by decide
theorem cert_e301455916266 : check e301455916266 [[],[]] .chain = true := by decide
def e301455969134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301455969134 : Closed e301455969134 ∧ code e301455969134 = 1400967596910 := by decide
theorem cert_e301455969134 : check e301455969134 [[],[]] .chain = true := by decide
def e301455969142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301455969142 : Closed e301455969142 ∧ code e301455969142 = 1400967596918 := by decide
theorem cert_e301455969142 : check e301455969142 [[],[]] .chain = true := by decide
def e301455969198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301455969198 : Closed e301455969198 ∧ code e301455969198 = 1400967596974 := by decide
theorem cert_e301455969198 : check e301455969198 [[],[]] .chain = true := by decide
def e301455969210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301455969210 : Closed e301455969210 ∧ code e301455969210 = 1400967596986 := by decide
theorem cert_e301455969210 : check e301455969210 [[],[]] .chain = true := by decide
def e301455969238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301455969238 : Closed e301455969238 ∧ code e301455969238 = 1400967597014 := by decide
theorem cert_e301455969238 : check e301455969238 [[],[]] .chain = true := by decide
def e301455969242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301455969242 : Closed e301455969242 ∧ code e301455969242 = 1400967597018 := by decide
theorem cert_e301455969242 : check e301455969242 [[],[]] .chain = true := by decide
def e301455969518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301455969518 : Closed e301455969518 ∧ code e301455969518 = 1400967597294 := by decide
theorem cert_e301455969518 : check e301455969518 [[],[]] .chain = true := by decide
def e301455969526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301455969526 : Closed e301455969526 ∧ code e301455969526 = 1400967597302 := by decide
theorem cert_e301455969526 : check e301455969526 [[],[]] .chain = true := by decide
def e301455969902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301455969902 : Closed e301455969902 ∧ code e301455969902 = 1400967597678 := by decide
theorem cert_e301455969902 : check e301455969902 [[],[]] .chain = true := by decide
def e301455969914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301455969914 : Closed e301455969914 ∧ code e301455969914 = 1400967597690 := by decide
theorem cert_e301455969914 : check e301455969914 [[],[]] .chain = true := by decide
def e301455970102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301455970102 : Closed e301455970102 ∧ code e301455970102 = 1400967597878 := by decide
theorem cert_e301455970102 : check e301455970102 [[],[]] .chain = true := by decide
def e301455970106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301455970106 : Closed e301455970106 ∧ code e301455970106 = 1400967597882 := by decide
theorem cert_e301455970106 : check e301455970106 [[],[]] .chain = true := by decide
def e301456174558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e301456174558 : Closed e301456174558 ∧ code e301456174558 = 1400967802334 := by decide
theorem cert_e301456174558 : check e301456174558 [[],[]] .chain = true := by decide
def e301456174574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e301456174574 : Closed e301456174574 ∧ code e301456174574 = 1400967802350 := by decide
theorem cert_e301456174574 : check e301456174574 [[],[]] .chain = true := by decide
def e301456174942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e301456174942 : Closed e301456174942 ∧ code e301456174942 = 1400967802718 := by decide
theorem cert_e301456174942 : check e301456174942 [[],[]] .chain = true := by decide
def e301456174970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e301456174970 : Closed e301456174970 ∧ code e301456174970 = 1400967802746 := by decide
theorem cert_e301456174970 : check e301456174970 [[],[]] .chain = true := by decide
def e301456175022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e301456175022 : Closed e301456175022 ∧ code e301456175022 = 1400967802798 := by decide
theorem cert_e301456175022 : check e301456175022 [[],[]] .chain = true := by decide
def e301456175034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e301456175034 : Closed e301456175034 ∧ code e301456175034 = 1400967802810 := by decide
theorem cert_e301456175034 : check e301456175034 [[],[]] .chain = true := by decide
def e301456176094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e301456176094 : Closed e301456176094 ∧ code e301456176094 = 1400967803870 := by decide
theorem cert_e301456176094 : check e301456176094 [[],[]] .chain = true := by decide
def e301456176110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e301456176110 : Closed e301456176110 ∧ code e301456176110 = 1400967803886 := by decide
theorem cert_e301456176110 : check e301456176110 [[],[]] .chain = true := by decide
def e301456178398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e301456178398 : Closed e301456178398 ∧ code e301456178398 = 1400967806174 := by decide
theorem cert_e301456178398 : check e301456178398 [[],[]] .chain = true := by decide
def e301456178426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e301456178426 : Closed e301456178426 ∧ code e301456178426 = 1400967806202 := by decide
theorem cert_e301456178426 : check e301456178426 [[],[]] .chain = true := by decide
def e301456178798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e301456178798 : Closed e301456178798 ∧ code e301456178798 = 1400967806574 := by decide
theorem cert_e301456178798 : check e301456178798 [[],[]] .chain = true := by decide
def e301456178810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e301456178810 : Closed e301456178810 ∧ code e301456178810 = 1400967806586 := by decide
theorem cert_e301456178810 : check e301456178810 [[],[]] .chain = true := by decide
def e301456207214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e301456207214 : Closed e301456207214 ∧ code e301456207214 = 1400967834990 := by decide
theorem cert_e301456207214 : check e301456207214 [[],[]] .chain = true := by decide
def e301456207222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e301456207222 : Closed e301456207222 ∧ code e301456207222 = 1400967834998 := by decide
theorem cert_e301456207222 : check e301456207222 [[],[]] .chain = true := by decide
def e301456207278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e301456207278 : Closed e301456207278 ∧ code e301456207278 = 1400967835054 := by decide
theorem cert_e301456207278 : check e301456207278 [[],[]] .chain = true := by decide
def e301456207290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e301456207290 : Closed e301456207290 ∧ code e301456207290 = 1400967835066 := by decide
theorem cert_e301456207290 : check e301456207290 [[],[]] .chain = true := by decide
def e301456207318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e301456207318 : Closed e301456207318 ∧ code e301456207318 = 1400967835094 := by decide
theorem cert_e301456207318 : check e301456207318 [[],[]] .chain = true := by decide
def e301456207322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e301456207322 : Closed e301456207322 ∧ code e301456207322 = 1400967835098 := by decide
theorem cert_e301456207322 : check e301456207322 [[],[]] .chain = true := by decide
def e301456207534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e301456207534 : Closed e301456207534 ∧ code e301456207534 = 1400967835310 := by decide
theorem cert_e301456207534 : check e301456207534 [[],[]] .chain = true := by decide
def e301456207546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e301456207546 : Closed e301456207546 ∧ code e301456207546 = 1400967835322 := by decide
theorem cert_e301456207546 : check e301456207546 [[],[]] .chain = true := by decide
def e301456207594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e301456207594 : Closed e301456207594 ∧ code e301456207594 = 1400967835370 := by decide
theorem cert_e301456207594 : check e301456207594 [[],[]] .chain = true := by decide
def e301456207702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e301456207702 : Closed e301456207702 ∧ code e301456207702 = 1400967835478 := by decide
theorem cert_e301456207702 : check e301456207702 [[],[]] .chain = true := by decide
def e301456207706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e301456207706 : Closed e301456207706 ∧ code e301456207706 = 1400967835482 := by decide
theorem cert_e301456207706 : check e301456207706 [[],[]] .chain = true := by decide
def e301456207722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e301456207722 : Closed e301456207722 ∧ code e301456207722 = 1400967835498 := by decide
theorem cert_e301456207722 : check e301456207722 [[],[]] .chain = true := by decide
def e301456208750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e301456208750 : Closed e301456208750 ∧ code e301456208750 = 1400967836526 := by decide
theorem cert_e301456208750 : check e301456208750 [[],[]] .chain = true := by decide
def e301456208758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e301456208758 : Closed e301456208758 ∧ code e301456208758 = 1400967836534 := by decide
theorem cert_e301456208758 : check e301456208758 [[],[]] .chain = true := by decide
def e301456208814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e301456208814 : Closed e301456208814 ∧ code e301456208814 = 1400967836590 := by decide
theorem cert_e301456208814 : check e301456208814 [[],[]] .chain = true := by decide
def e301456208826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e301456208826 : Closed e301456208826 ∧ code e301456208826 = 1400967836602 := by decide
theorem cert_e301456208826 : check e301456208826 [[],[]] .chain = true := by decide
def e301456208854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e301456208854 : Closed e301456208854 ∧ code e301456208854 = 1400967836630 := by decide
theorem cert_e301456208854 : check e301456208854 [[],[]] .chain = true := by decide
def e301456208858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e301456208858 : Closed e301456208858 ∧ code e301456208858 = 1400967836634 := by decide
theorem cert_e301456208858 : check e301456208858 [[],[]] .chain = true := by decide
def e301456209134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e301456209134 : Closed e301456209134 ∧ code e301456209134 = 1400967836910 := by decide
theorem cert_e301456209134 : check e301456209134 [[],[]] .chain = true := by decide
def e301456209142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e301456209142 : Closed e301456209142 ∧ code e301456209142 = 1400967836918 := by decide
theorem cert_e301456209142 : check e301456209142 [[],[]] .chain = true := by decide
def e301456209518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e301456209518 : Closed e301456209518 ∧ code e301456209518 = 1400967837294 := by decide
theorem cert_e301456209518 : check e301456209518 [[],[]] .chain = true := by decide
def e301456209530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e301456209530 : Closed e301456209530 ∧ code e301456209530 = 1400967837306 := by decide
theorem cert_e301456209530 : check e301456209530 [[],[]] .chain = true := by decide
def e301456209718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e301456209718 : Closed e301456209718 ∧ code e301456209718 = 1400967837494 := by decide
theorem cert_e301456209718 : check e301456209718 [[],[]] .chain = true := by decide
def e301456209722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e301456209722 : Closed e301456209722 ∧ code e301456209722 = 1400967837498 := by decide
theorem cert_e301456209722 : check e301456209722 [[],[]] .chain = true := by decide
def e301456210350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e301456210350 : Closed e301456210350 ∧ code e301456210350 = 1400967838126 := by decide
theorem cert_e301456210350 : check e301456210350 [[],[]] .chain = true := by decide
def e301456210362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e301456210362 : Closed e301456210362 ∧ code e301456210362 = 1400967838138 := by decide
theorem cert_e301456210362 : check e301456210362 [[],[]] .chain = true := by decide
def e301456210410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e301456210410 : Closed e301456210410 ∧ code e301456210410 = 1400967838186 := by decide
theorem cert_e301456210410 : check e301456210410 [[],[]] .chain = true := by decide
def e301456210542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e301456210542 : Closed e301456210542 ∧ code e301456210542 = 1400967838318 := by decide
theorem cert_e301456210542 : check e301456210542 [[],[]] .chain = true := by decide
def e301456210554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e301456210554 : Closed e301456210554 ∧ code e301456210554 = 1400967838330 := by decide
theorem cert_e301456210554 : check e301456210554 [[],[]] .chain = true := by decide
def e301456210842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e301456210842 : Closed e301456210842 ∧ code e301456210842 = 1400967838618 := by decide
theorem cert_e301456210842 : check e301456210842 [[],[]] .chain = true := by decide
def e301456211158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e301456211158 : Closed e301456211158 ∧ code e301456211158 = 1400967838934 := by decide
theorem cert_e301456211158 : check e301456211158 [[],[]] .chain = true := by decide
def e301456211162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e301456211162 : Closed e301456211162 ∧ code e301456211162 = 1400967838938 := by decide
theorem cert_e301456211162 : check e301456211162 [[],[]] .chain = true := by decide
def e301456211178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e301456211178 : Closed e301456211178 ∧ code e301456211178 = 1400967838954 := by decide
theorem cert_e301456211178 : check e301456211178 [[],[]] .chain = true := by decide
def e301456211254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e301456211254 : Closed e301456211254 ∧ code e301456211254 = 1400967839030 := by decide
theorem cert_e301456211254 : check e301456211254 [[],[]] .chain = true := by decide
def e301456211258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e301456211258 : Closed e301456211258 ∧ code e301456211258 = 1400967839034 := by decide
theorem cert_e301456211258 : check e301456211258 [[],[]] .chain = true := by decide
def e301456211354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e301456211354 : Closed e301456211354 ∧ code e301456211354 = 1400967839130 := by decide
theorem cert_e301456211354 : check e301456211354 [[],[]] .chain = true := by decide
def e301456212958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e301456212958 : Closed e301456212958 ∧ code e301456212958 = 1400967840734 := by decide
theorem cert_e301456212958 : check e301456212958 [[],[]] .chain = true := by decide
def e301456212974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e301456212974 : Closed e301456212974 ∧ code e301456212974 = 1400967840750 := by decide
theorem cert_e301456212974 : check e301456212974 [[],[]] .chain = true := by decide
def e301456214894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e301456214894 : Closed e301456214894 ∧ code e301456214894 = 1400967842670 := by decide
theorem cert_e301456214894 : check e301456214894 [[],[]] .chain = true := by decide
def e301456214902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e301456214902 : Closed e301456214902 ∧ code e301456214902 = 1400967842678 := by decide
theorem cert_e301456214902 : check e301456214902 [[],[]] .chain = true := by decide
def e301456214958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e301456214958 : Closed e301456214958 ∧ code e301456214958 = 1400967842734 := by decide
theorem cert_e301456214958 : check e301456214958 [[],[]] .chain = true := by decide
def e301456214970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e301456214970 : Closed e301456214970 ∧ code e301456214970 = 1400967842746 := by decide
theorem cert_e301456214970 : check e301456214970 [[],[]] .chain = true := by decide
def e301456214998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e301456214998 : Closed e301456214998 ∧ code e301456214998 = 1400967842774 := by decide
theorem cert_e301456214998 : check e301456214998 [[],[]] .chain = true := by decide
def e301456215002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e301456215002 : Closed e301456215002 ∧ code e301456215002 = 1400967842778 := by decide
theorem cert_e301456215002 : check e301456215002 [[],[]] .chain = true := by decide
def e301456215278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e301456215278 : Closed e301456215278 ∧ code e301456215278 = 1400967843054 := by decide
theorem cert_e301456215278 : check e301456215278 [[],[]] .chain = true := by decide
def e301456215286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e301456215286 : Closed e301456215286 ∧ code e301456215286 = 1400967843062 := by decide
theorem cert_e301456215286 : check e301456215286 [[],[]] .chain = true := by decide
def e301456215662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e301456215662 : Closed e301456215662 ∧ code e301456215662 = 1400967843438 := by decide
theorem cert_e301456215662 : check e301456215662 [[],[]] .chain = true := by decide
def e301456215674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e301456215674 : Closed e301456215674 ∧ code e301456215674 = 1400967843450 := by decide
theorem cert_e301456215674 : check e301456215674 [[],[]] .chain = true := by decide
def e301456215862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e301456215862 : Closed e301456215862 ∧ code e301456215862 = 1400967843638 := by decide
theorem cert_e301456215862 : check e301456215862 [[],[]] .chain = true := by decide
def e301456215866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e301456215866 : Closed e301456215866 ∧ code e301456215866 = 1400967843642 := by decide
theorem cert_e301456215866 : check e301456215866 [[],[]] .chain = true := by decide
def e301456220638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e301456220638 : Closed e301456220638 ∧ code e301456220638 = 1400967848414 := by decide
theorem cert_e301456220638 : check e301456220638 [[],[]] .chain = true := by decide
def e301456220662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e301456220662 : Closed e301456220662 ∧ code e301456220662 = 1400967848438 := by decide
theorem cert_e301456220662 : check e301456220662 [[],[]] .chain = true := by decide
def e301456221614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e301456221614 : Closed e301456221614 ∧ code e301456221614 = 1400967849390 := by decide
theorem cert_e301456221614 : check e301456221614 [[],[]] .chain = true := by decide
def e301456221626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e301456221626 : Closed e301456221626 ∧ code e301456221626 = 1400967849402 := by decide
theorem cert_e301456221626 : check e301456221626 [[],[]] .chain = true := by decide
def e301456221674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e301456221674 : Closed e301456221674 ∧ code e301456221674 = 1400967849450 := by decide
theorem cert_e301456221674 : check e301456221674 [[],[]] .chain = true := by decide
def e301456221806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e301456221806 : Closed e301456221806 ∧ code e301456221806 = 1400967849582 := by decide
theorem cert_e301456221806 : check e301456221806 [[],[]] .chain = true := by decide
def e301456221818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e301456221818 : Closed e301456221818 ∧ code e301456221818 = 1400967849594 := by decide
theorem cert_e301456221818 : check e301456221818 [[],[]] .chain = true := by decide
def e301456222106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e301456222106 : Closed e301456222106 ∧ code e301456222106 = 1400967849882 := by decide
theorem cert_e301456222106 : check e301456222106 [[],[]] .chain = true := by decide
def e301456224494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e301456224494 : Closed e301456224494 ∧ code e301456224494 = 1400967852270 := by decide
theorem cert_e301456224494 : check e301456224494 [[],[]] .chain = true := by decide
def e301456224502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e301456224502 : Closed e301456224502 ∧ code e301456224502 = 1400967852278 := by decide
theorem cert_e301456224502 : check e301456224502 [[],[]] .chain = true := by decide
def e301456224982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e301456224982 : Closed e301456224982 ∧ code e301456224982 = 1400967852758 := by decide
theorem cert_e301456224982 : check e301456224982 [[],[]] .chain = true := by decide
def e301456224986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e301456224986 : Closed e301456224986 ∧ code e301456224986 = 1400967852762 := by decide
theorem cert_e301456224986 : check e301456224986 [[],[]] .chain = true := by decide
def e301456225002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e301456225002 : Closed e301456225002 ∧ code e301456225002 = 1400967852778 := by decide
theorem cert_e301456225002 : check e301456225002 [[],[]] .chain = true := by decide
def e301456225078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e301456225078 : Closed e301456225078 ∧ code e301456225078 = 1400967852854 := by decide
theorem cert_e301456225078 : check e301456225078 [[],[]] .chain = true := by decide
def e301456225082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e301456225082 : Closed e301456225082 ∧ code e301456225082 = 1400967852858 := by decide
theorem cert_e301456225082 : check e301456225082 [[],[]] .chain = true := by decide
def e301456225178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e301456225178 : Closed e301456225178 ∧ code e301456225178 = 1400967852954 := by decide
theorem cert_e301456225178 : check e301456225178 [[],[]] .chain = true := by decide
end Blc.Floor40
