import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301456362350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e301456362350 : Closed e301456362350 ∧ code e301456362350 = 1400967990126 := by decide
theorem cert_e301456362350 : check e301456362350 [[],[]] .chain = true := by decide
def e301456362358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e301456362358 : Closed e301456362358 ∧ code e301456362358 = 1400967990134 := by decide
theorem cert_e301456362358 : check e301456362358 [[],[]] .chain = true := by decide
def e301456362414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e301456362414 : Closed e301456362414 ∧ code e301456362414 = 1400967990190 := by decide
theorem cert_e301456362414 : check e301456362414 [[],[]] .chain = true := by decide
def e301456362426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e301456362426 : Closed e301456362426 ∧ code e301456362426 = 1400967990202 := by decide
theorem cert_e301456362426 : check e301456362426 [[],[]] .chain = true := by decide
def e301456362454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e301456362454 : Closed e301456362454 ∧ code e301456362454 = 1400967990230 := by decide
theorem cert_e301456362454 : check e301456362454 [[],[]] .chain = true := by decide
def e301456362458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e301456362458 : Closed e301456362458 ∧ code e301456362458 = 1400967990234 := by decide
theorem cert_e301456362458 : check e301456362458 [[],[]] .chain = true := by decide
def e301456362734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e301456362734 : Closed e301456362734 ∧ code e301456362734 = 1400967990510 := by decide
theorem cert_e301456362734 : check e301456362734 [[],[]] .chain = true := by decide
def e301456362742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e301456362742 : Closed e301456362742 ∧ code e301456362742 = 1400967990518 := by decide
theorem cert_e301456362742 : check e301456362742 [[],[]] .chain = true := by decide
def e301456363118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e301456363118 : Closed e301456363118 ∧ code e301456363118 = 1400967990894 := by decide
theorem cert_e301456363118 : check e301456363118 [[],[]] .chain = true := by decide
def e301456363130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e301456363130 : Closed e301456363130 ∧ code e301456363130 = 1400967990906 := by decide
theorem cert_e301456363130 : check e301456363130 [[],[]] .chain = true := by decide
def e301456363318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e301456363318 : Closed e301456363318 ∧ code e301456363318 = 1400967991094 := by decide
theorem cert_e301456363318 : check e301456363318 [[],[]] .chain = true := by decide
def e301456363322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e301456363322 : Closed e301456363322 ∧ code e301456363322 = 1400967991098 := by decide
theorem cert_e301456363322 : check e301456363322 [[],[]] .chain = true := by decide
def e301456692958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e301456692958 : Closed e301456692958 ∧ code e301456692958 = 1400968320734 := by decide
theorem cert_e301456692958 : check e301456692958 [[],[],[.under]] .smaller = true := by decide
def e301456692982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e301456692982 : Closed e301456692982 ∧ code e301456692982 = 1400968320758 := by decide
theorem cert_e301456692982 : check e301456692982 [[],[],[.under]] .smaller = true := by decide
def e301456693086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e301456693086 : Closed e301456693086 ∧ code e301456693086 = 1400968320862 := by decide
theorem cert_e301456693086 : check e301456693086 [[],[],[.under]] .smaller = true := by decide
def e301456693114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e301456693114 : Closed e301456693114 ∧ code e301456693114 = 1400968320890 := by decide
theorem cert_e301456693114 : check e301456693114 [[],[],[.under]] .smaller = true := by decide
def e301456693206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e301456693206 : Closed e301456693206 ∧ code e301456693206 = 1400968320982 := by decide
theorem cert_e301456693206 : check e301456693206 [[],[],[.under]] .smaller = true := by decide
def e301456693210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e301456693210 : Closed e301456693210 ∧ code e301456693210 = 1400968320986 := by decide
theorem cert_e301456693210 : check e301456693210 [[],[],[.under]] .smaller = true := by decide
def e301456693726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e301456693726 : Closed e301456693726 ∧ code e301456693726 = 1400968321502 := by decide
theorem cert_e301456693726 : check e301456693726 [[],[],[.under]] .smaller = true := by decide
def e301456693750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e301456693750 : Closed e301456693750 ∧ code e301456693750 = 1400968321526 := by decide
theorem cert_e301456693750 : check e301456693750 [[],[],[.under]] .smaller = true := by decide
def e301456694494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e301456694494 : Closed e301456694494 ∧ code e301456694494 = 1400968322270 := by decide
theorem cert_e301456694494 : check e301456694494 [[],[],[.under]] .smaller = true := by decide
def e301456694522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e301456694522 : Closed e301456694522 ∧ code e301456694522 = 1400968322298 := by decide
theorem cert_e301456694522 : check e301456694522 [[],[],[.under]] .smaller = true := by decide
def e301456695094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e301456695094 : Closed e301456695094 ∧ code e301456695094 = 1400968322870 := by decide
theorem cert_e301456695094 : check e301456695094 [[],[],[.under]] .smaller = true := by decide
def e301456695098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e301456695098 : Closed e301456695098 ∧ code e301456695098 = 1400968322874 := by decide
theorem cert_e301456695098 : check e301456695098 [[],[],[.under]] .smaller = true := by decide
def e301456709870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e301456709870 : Closed e301456709870 ∧ code e301456709870 = 1400968337646 := by decide
theorem cert_e301456709870 : check e301456709870 [[],[],[.under]] .smaller = true := by decide
def e301456709878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e301456709878 : Closed e301456709878 ∧ code e301456709878 = 1400968337654 := by decide
theorem cert_e301456709878 : check e301456709878 [[],[],[.under]] .smaller = true := by decide
def e301456710430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e301456710430 : Closed e301456710430 ∧ code e301456710430 = 1400968338206 := by decide
theorem cert_e301456710430 : check e301456710430 [[],[],[.under]] .smaller = true := by decide
def e301456710542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e301456710542 : Closed e301456710542 ∧ code e301456710542 = 1400968338318 := by decide
theorem cert_e301456710542 : check e301456710542 [[],[],[.under]] .smaller = true := by decide
def e301456710766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e301456710766 : Closed e301456710766 ∧ code e301456710766 = 1400968338542 := by decide
theorem cert_e301456710766 : check e301456710766 [[],[],[.under]] .smaller = true := by decide
def e301456710778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e301456710778 : Closed e301456710778 ∧ code e301456710778 = 1400968338554 := by decide
theorem cert_e301456710778 : check e301456710778 [[],[],[.under]] .smaller = true := by decide
def e301456710942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e301456710942 : Closed e301456710942 ∧ code e301456710942 = 1400968338718 := by decide
theorem cert_e301456710942 : check e301456710942 [[],[],[.under]] .smaller = true := by decide
def e301456711110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e301456711110 : Closed e301456711110 ∧ code e301456711110 = 1400968338886 := by decide
theorem cert_e301456711110 : check e301456711110 [[],[],[.under]] .smaller = true := by decide
def e301456711222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e301456711222 : Closed e301456711222 ∧ code e301456711222 = 1400968338998 := by decide
theorem cert_e301456711222 : check e301456711222 [[],[],[.under]] .smaller = true := by decide
def e301456711226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e301456711226 : Closed e301456711226 ∧ code e301456711226 = 1400968339002 := by decide
theorem cert_e301456711226 : check e301456711226 [[],[],[.under]] .smaller = true := by decide
def e301456711310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e301456711310 : Closed e301456711310 ∧ code e301456711310 = 1400968339086 := by decide
theorem cert_e301456711310 : check e301456711310 [[],[],[.under]] .smaller = true := by decide
def e301456711366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e301456711366 : Closed e301456711366 ∧ code e301456711366 = 1400968339142 := by decide
theorem cert_e301456711366 : check e301456711366 [[],[],[.under]] .smaller = true := by decide
def e301456713502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e301456713502 : Closed e301456713502 ∧ code e301456713502 = 1400968341278 := by decide
theorem cert_e301456713502 : check e301456713502 [[],[],[.under]] .smaller = true := by decide
def e301456713614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e301456713614 : Closed e301456713614 ∧ code e301456713614 = 1400968341390 := by decide
theorem cert_e301456713614 : check e301456713614 [[],[],[.under]] .smaller = true := by decide
def e301456716574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e301456716574 : Closed e301456716574 ∧ code e301456716574 = 1400968344350 := by decide
theorem cert_e301456716574 : check e301456716574 [[],[],[.under]] .smaller = true := by decide
def e301456716742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e301456716742 : Closed e301456716742 ∧ code e301456716742 = 1400968344518 := by decide
theorem cert_e301456716742 : check e301456716742 [[],[],[.under]] .smaller = true := by decide
def e301456718222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e301456718222 : Closed e301456718222 ∧ code e301456718222 = 1400968345998 := by decide
theorem cert_e301456718222 : check e301456718222 [[],[],[.under]] .smaller = true := by decide
def e301456718278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e301456718278 : Closed e301456718278 ∧ code e301456718278 = 1400968346054 := by decide
theorem cert_e301456718278 : check e301456718278 [[],[],[.under]] .smaller = true := by decide
def e301464563130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e301464563130 : Closed e301464563130 ∧ code e301464563130 = 1400976190906 := by decide
def e301464563162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e301464563162 : Closed e301464563162 ∧ code e301464563162 = 1400976190938 := by decide
def e301464563386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e301464563386 : Closed e301464563386 ∧ code e301464563386 = 1400976191162 := by decide
def e301464563434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e301464563434 : Closed e301464563434 ∧ code e301464563434 = 1400976191210 := by decide
def e301464563546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e301464563546 : Closed e301464563546 ∧ code e301464563546 = 1400976191322 := by decide
def e301464563562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e301464563562 : Closed e301464563562 ∧ code e301464563562 = 1400976191338 := by decide
def e301464564666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e301464564666 : Closed e301464564666 ∧ code e301464564666 = 1400976192442 := by decide
def e301464564698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e301464564698 : Closed e301464564698 ∧ code e301464564698 = 1400976192474 := by decide
def e301464566202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e301464566202 : Closed e301464566202 ∧ code e301464566202 = 1400976193978 := by decide
def e301464566250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e301464566250 : Closed e301464566250 ∧ code e301464566250 = 1400976194026 := by decide
def e301464567002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e301464567002 : Closed e301464567002 ∧ code e301464567002 = 1400976194778 := by decide
def e301464567018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e301464567018 : Closed e301464567018 ∧ code e301464567018 = 1400976194794 := by decide
def e301464816494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301464816494 : Closed e301464816494 ∧ code e301464816494 = 1400976444270 := by decide
def e301464816502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301464816502 : Closed e301464816502 ∧ code e301464816502 = 1400976444278 := by decide
def e301464816558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301464816558 : Closed e301464816558 ∧ code e301464816558 = 1400976444334 := by decide
def e301464816570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301464816570 : Closed e301464816570 ∧ code e301464816570 = 1400976444346 := by decide
def e301464816598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301464816598 : Closed e301464816598 ∧ code e301464816598 = 1400976444374 := by decide
def e301464816602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301464816602 : Closed e301464816602 ∧ code e301464816602 = 1400976444378 := by decide
def e301464816878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301464816878 : Closed e301464816878 ∧ code e301464816878 = 1400976444654 := by decide
theorem cert_e301464816878 : check e301464816878 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e301464816886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301464816886 : Closed e301464816886 ∧ code e301464816886 = 1400976444662 := by decide
theorem cert_e301464816886 : check e301464816886 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e301464817262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301464817262 : Closed e301464817262 ∧ code e301464817262 = 1400976445038 := by decide
theorem cert_e301464817262 : check e301464817262 [[],[],[.left],[],[.left],[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e301464817274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301464817274 : Closed e301464817274 ∧ code e301464817274 = 1400976445050 := by decide
def e301464817462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301464817462 : Closed e301464817462 ∧ code e301464817462 = 1400976445238 := by decide
theorem cert_e301464817462 : check e301464817462 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e301464817466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301464817466 : Closed e301464817466 ∧ code e301464817466 = 1400976445242 := by decide
theorem cert_e301464817466 : check e301464817466 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e301465611742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e301465611742 : Closed e301465611742 ∧ code e301465611742 = 1400977239518 := by decide
theorem cert_e301465611742 : check e301465611742 [[],[],[]] .smaller = true := by decide
def e301465611758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e301465611758 : Closed e301465611758 ∧ code e301465611758 = 1400977239534 := by decide
theorem cert_e301465611758 : check e301465611758 [[],[],[]] .smaller = true := by decide
def e301465612126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e301465612126 : Closed e301465612126 ∧ code e301465612126 = 1400977239902 := by decide
theorem cert_e301465612126 : check e301465612126 [[],[],[]] .smaller = true := by decide
def e301465612154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e301465612154 : Closed e301465612154 ∧ code e301465612154 = 1400977239930 := by decide
theorem cert_e301465612154 : check e301465612154 [[],[],[]] .smaller = true := by decide
def e301465612206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e301465612206 : Closed e301465612206 ∧ code e301465612206 = 1400977239982 := by decide
theorem cert_e301465612206 : check e301465612206 [[],[],[]] .smaller = true := by decide
def e301465612218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e301465612218 : Closed e301465612218 ∧ code e301465612218 = 1400977239994 := by decide
theorem cert_e301465612218 : check e301465612218 [[],[],[]] .smaller = true := by decide
def e301465613278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e301465613278 : Closed e301465613278 ∧ code e301465613278 = 1400977241054 := by decide
theorem cert_e301465613278 : check e301465613278 [[],[],[]] .smaller = true := by decide
def e301465613294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e301465613294 : Closed e301465613294 ∧ code e301465613294 = 1400977241070 := by decide
theorem cert_e301465613294 : check e301465613294 [[],[],[]] .smaller = true := by decide
def e301465615582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e301465615582 : Closed e301465615582 ∧ code e301465615582 = 1400977243358 := by decide
theorem cert_e301465615582 : check e301465615582 [[],[],[]] .smaller = true := by decide
def e301465615610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e301465615610 : Closed e301465615610 ∧ code e301465615610 = 1400977243386 := by decide
theorem cert_e301465615610 : check e301465615610 [[],[],[]] .smaller = true := by decide
def e301465615982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e301465615982 : Closed e301465615982 ∧ code e301465615982 = 1400977243758 := by decide
theorem cert_e301465615982 : check e301465615982 [[],[],[]] .smaller = true := by decide
def e301465615994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e301465615994 : Closed e301465615994 ∧ code e301465615994 = 1400977243770 := by decide
theorem cert_e301465615994 : check e301465615994 [[],[],[]] .smaller = true := by decide
def e301465644398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e301465644398 : Closed e301465644398 ∧ code e301465644398 = 1400977272174 := by decide
theorem cert_e301465644398 : check e301465644398 [[],[],[]] .smaller = true := by decide
def e301465644406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e301465644406 : Closed e301465644406 ∧ code e301465644406 = 1400977272182 := by decide
theorem cert_e301465644406 : check e301465644406 [[],[],[]] .smaller = true := by decide
def e301465644462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e301465644462 : Closed e301465644462 ∧ code e301465644462 = 1400977272238 := by decide
theorem cert_e301465644462 : check e301465644462 [[],[],[]] .smaller = true := by decide
def e301465644474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e301465644474 : Closed e301465644474 ∧ code e301465644474 = 1400977272250 := by decide
theorem cert_e301465644474 : check e301465644474 [[],[],[]] .smaller = true := by decide
def e301465644502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e301465644502 : Closed e301465644502 ∧ code e301465644502 = 1400977272278 := by decide
theorem cert_e301465644502 : check e301465644502 [[],[],[]] .smaller = true := by decide
def e301465644506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e301465644506 : Closed e301465644506 ∧ code e301465644506 = 1400977272282 := by decide
theorem cert_e301465644506 : check e301465644506 [[],[],[]] .smaller = true := by decide
def e301465644718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e301465644718 : Closed e301465644718 ∧ code e301465644718 = 1400977272494 := by decide
theorem cert_e301465644718 : check e301465644718 [[],[],[]] .smaller = true := by decide
def e301465644730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e301465644730 : Closed e301465644730 ∧ code e301465644730 = 1400977272506 := by decide
theorem cert_e301465644730 : check e301465644730 [[],[],[]] .smaller = true := by decide
def e301465644778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e301465644778 : Closed e301465644778 ∧ code e301465644778 = 1400977272554 := by decide
theorem cert_e301465644778 : check e301465644778 [[],[],[]] .smaller = true := by decide
def e301465644886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e301465644886 : Closed e301465644886 ∧ code e301465644886 = 1400977272662 := by decide
theorem cert_e301465644886 : check e301465644886 [[],[],[]] .smaller = true := by decide
def e301465644890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e301465644890 : Closed e301465644890 ∧ code e301465644890 = 1400977272666 := by decide
theorem cert_e301465644890 : check e301465644890 [[],[],[]] .smaller = true := by decide
def e301465644906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e301465644906 : Closed e301465644906 ∧ code e301465644906 = 1400977272682 := by decide
theorem cert_e301465644906 : check e301465644906 [[],[],[]] .smaller = true := by decide
def e301465645934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e301465645934 : Closed e301465645934 ∧ code e301465645934 = 1400977273710 := by decide
theorem cert_e301465645934 : check e301465645934 [[],[],[]] .smaller = true := by decide
def e301465645942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e301465645942 : Closed e301465645942 ∧ code e301465645942 = 1400977273718 := by decide
theorem cert_e301465645942 : check e301465645942 [[],[],[]] .smaller = true := by decide
def e301465645998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e301465645998 : Closed e301465645998 ∧ code e301465645998 = 1400977273774 := by decide
theorem cert_e301465645998 : check e301465645998 [[],[],[]] .smaller = true := by decide
def e301465646010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e301465646010 : Closed e301465646010 ∧ code e301465646010 = 1400977273786 := by decide
theorem cert_e301465646010 : check e301465646010 [[],[],[]] .smaller = true := by decide
def e301465646038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e301465646038 : Closed e301465646038 ∧ code e301465646038 = 1400977273814 := by decide
theorem cert_e301465646038 : check e301465646038 [[],[],[]] .smaller = true := by decide
def e301465646042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e301465646042 : Closed e301465646042 ∧ code e301465646042 = 1400977273818 := by decide
theorem cert_e301465646042 : check e301465646042 [[],[],[]] .smaller = true := by decide
def e301465646318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e301465646318 : Closed e301465646318 ∧ code e301465646318 = 1400977274094 := by decide
theorem cert_e301465646318 : check e301465646318 [[],[],[]] .smaller = true := by decide
def e301465646326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e301465646326 : Closed e301465646326 ∧ code e301465646326 = 1400977274102 := by decide
theorem cert_e301465646326 : check e301465646326 [[],[],[]] .smaller = true := by decide
def e301465646702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e301465646702 : Closed e301465646702 ∧ code e301465646702 = 1400977274478 := by decide
theorem cert_e301465646702 : check e301465646702 [[],[],[]] .smaller = true := by decide
def e301465646714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e301465646714 : Closed e301465646714 ∧ code e301465646714 = 1400977274490 := by decide
theorem cert_e301465646714 : check e301465646714 [[],[],[]] .smaller = true := by decide
def e301465646902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e301465646902 : Closed e301465646902 ∧ code e301465646902 = 1400977274678 := by decide
theorem cert_e301465646902 : check e301465646902 [[],[],[]] .smaller = true := by decide
def e301465646906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e301465646906 : Closed e301465646906 ∧ code e301465646906 = 1400977274682 := by decide
theorem cert_e301465646906 : check e301465646906 [[],[],[]] .smaller = true := by decide
def e301465647534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e301465647534 : Closed e301465647534 ∧ code e301465647534 = 1400977275310 := by decide
theorem cert_e301465647534 : check e301465647534 [[],[],[]] .smaller = true := by decide
def e301465647546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e301465647546 : Closed e301465647546 ∧ code e301465647546 = 1400977275322 := by decide
theorem cert_e301465647546 : check e301465647546 [[],[],[]] .smaller = true := by decide
def e301465647594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e301465647594 : Closed e301465647594 ∧ code e301465647594 = 1400977275370 := by decide
theorem cert_e301465647594 : check e301465647594 [[],[],[]] .smaller = true := by decide
def e301465647726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e301465647726 : Closed e301465647726 ∧ code e301465647726 = 1400977275502 := by decide
theorem cert_e301465647726 : check e301465647726 [[],[],[]] .smaller = true := by decide
def e301465647738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e301465647738 : Closed e301465647738 ∧ code e301465647738 = 1400977275514 := by decide
theorem cert_e301465647738 : check e301465647738 [[],[],[]] .smaller = true := by decide
def e301465648026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e301465648026 : Closed e301465648026 ∧ code e301465648026 = 1400977275802 := by decide
theorem cert_e301465648026 : check e301465648026 [[],[],[]] .smaller = true := by decide
def e301465648342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e301465648342 : Closed e301465648342 ∧ code e301465648342 = 1400977276118 := by decide
theorem cert_e301465648342 : check e301465648342 [[],[],[]] .smaller = true := by decide
def e301465648346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e301465648346 : Closed e301465648346 ∧ code e301465648346 = 1400977276122 := by decide
theorem cert_e301465648346 : check e301465648346 [[],[],[]] .smaller = true := by decide
def e301465648362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e301465648362 : Closed e301465648362 ∧ code e301465648362 = 1400977276138 := by decide
theorem cert_e301465648362 : check e301465648362 [[],[],[]] .smaller = true := by decide
def e301465648438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e301465648438 : Closed e301465648438 ∧ code e301465648438 = 1400977276214 := by decide
theorem cert_e301465648438 : check e301465648438 [[],[],[]] .smaller = true := by decide
def e301465648442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e301465648442 : Closed e301465648442 ∧ code e301465648442 = 1400977276218 := by decide
theorem cert_e301465648442 : check e301465648442 [[],[],[]] .smaller = true := by decide
def e301465648538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e301465648538 : Closed e301465648538 ∧ code e301465648538 = 1400977276314 := by decide
theorem cert_e301465648538 : check e301465648538 [[],[],[]] .smaller = true := by decide
def e301465650142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e301465650142 : Closed e301465650142 ∧ code e301465650142 = 1400977277918 := by decide
theorem cert_e301465650142 : check e301465650142 [[],[],[]] .smaller = true := by decide
def e301465650158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e301465650158 : Closed e301465650158 ∧ code e301465650158 = 1400977277934 := by decide
theorem cert_e301465650158 : check e301465650158 [[],[],[]] .smaller = true := by decide
def e301465652078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e301465652078 : Closed e301465652078 ∧ code e301465652078 = 1400977279854 := by decide
theorem cert_e301465652078 : check e301465652078 [[],[],[]] .smaller = true := by decide
def e301465652086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e301465652086 : Closed e301465652086 ∧ code e301465652086 = 1400977279862 := by decide
theorem cert_e301465652086 : check e301465652086 [[],[],[]] .smaller = true := by decide
def e301465652142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e301465652142 : Closed e301465652142 ∧ code e301465652142 = 1400977279918 := by decide
theorem cert_e301465652142 : check e301465652142 [[],[],[]] .smaller = true := by decide
def e301465652154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e301465652154 : Closed e301465652154 ∧ code e301465652154 = 1400977279930 := by decide
theorem cert_e301465652154 : check e301465652154 [[],[],[]] .smaller = true := by decide
def e301465652182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e301465652182 : Closed e301465652182 ∧ code e301465652182 = 1400977279958 := by decide
theorem cert_e301465652182 : check e301465652182 [[],[],[]] .smaller = true := by decide
def e301465652186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e301465652186 : Closed e301465652186 ∧ code e301465652186 = 1400977279962 := by decide
theorem cert_e301465652186 : check e301465652186 [[],[],[]] .smaller = true := by decide
def e301465652462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e301465652462 : Closed e301465652462 ∧ code e301465652462 = 1400977280238 := by decide
theorem cert_e301465652462 : check e301465652462 [[],[],[]] .smaller = true := by decide
def e301465652470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e301465652470 : Closed e301465652470 ∧ code e301465652470 = 1400977280246 := by decide
theorem cert_e301465652470 : check e301465652470 [[],[],[]] .smaller = true := by decide
def e301465652846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e301465652846 : Closed e301465652846 ∧ code e301465652846 = 1400977280622 := by decide
theorem cert_e301465652846 : check e301465652846 [[],[],[]] .smaller = true := by decide
def e301465652858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e301465652858 : Closed e301465652858 ∧ code e301465652858 = 1400977280634 := by decide
theorem cert_e301465652858 : check e301465652858 [[],[],[]] .smaller = true := by decide
def e301465653046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e301465653046 : Closed e301465653046 ∧ code e301465653046 = 1400977280822 := by decide
theorem cert_e301465653046 : check e301465653046 [[],[],[]] .smaller = true := by decide
def e301465653050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e301465653050 : Closed e301465653050 ∧ code e301465653050 = 1400977280826 := by decide
theorem cert_e301465653050 : check e301465653050 [[],[],[]] .smaller = true := by decide
def e301465657822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e301465657822 : Closed e301465657822 ∧ code e301465657822 = 1400977285598 := by decide
theorem cert_e301465657822 : check e301465657822 [[],[],[]] .smaller = true := by decide
def e301465657846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e301465657846 : Closed e301465657846 ∧ code e301465657846 = 1400977285622 := by decide
theorem cert_e301465657846 : check e301465657846 [[],[],[]] .smaller = true := by decide
def e301465658798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e301465658798 : Closed e301465658798 ∧ code e301465658798 = 1400977286574 := by decide
theorem cert_e301465658798 : check e301465658798 [[],[],[]] .smaller = true := by decide
def e301465658810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e301465658810 : Closed e301465658810 ∧ code e301465658810 = 1400977286586 := by decide
theorem cert_e301465658810 : check e301465658810 [[],[],[]] .smaller = true := by decide
def e301465658858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e301465658858 : Closed e301465658858 ∧ code e301465658858 = 1400977286634 := by decide
theorem cert_e301465658858 : check e301465658858 [[],[],[]] .smaller = true := by decide
def e301465658990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e301465658990 : Closed e301465658990 ∧ code e301465658990 = 1400977286766 := by decide
theorem cert_e301465658990 : check e301465658990 [[],[],[]] .smaller = true := by decide
def e301465659002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e301465659002 : Closed e301465659002 ∧ code e301465659002 = 1400977286778 := by decide
theorem cert_e301465659002 : check e301465659002 [[],[],[]] .smaller = true := by decide
def e301465659290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e301465659290 : Closed e301465659290 ∧ code e301465659290 = 1400977287066 := by decide
theorem cert_e301465659290 : check e301465659290 [[],[],[]] .smaller = true := by decide
def e301465661678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e301465661678 : Closed e301465661678 ∧ code e301465661678 = 1400977289454 := by decide
theorem cert_e301465661678 : check e301465661678 [[],[],[]] .smaller = true := by decide
def e301465661686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e301465661686 : Closed e301465661686 ∧ code e301465661686 = 1400977289462 := by decide
theorem cert_e301465661686 : check e301465661686 [[],[],[]] .smaller = true := by decide
def e301465662166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e301465662166 : Closed e301465662166 ∧ code e301465662166 = 1400977289942 := by decide
theorem cert_e301465662166 : check e301465662166 [[],[],[]] .smaller = true := by decide
def e301465662170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e301465662170 : Closed e301465662170 ∧ code e301465662170 = 1400977289946 := by decide
theorem cert_e301465662170 : check e301465662170 [[],[],[]] .smaller = true := by decide
def e301465662186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e301465662186 : Closed e301465662186 ∧ code e301465662186 = 1400977289962 := by decide
theorem cert_e301465662186 : check e301465662186 [[],[],[]] .smaller = true := by decide
def e301465662262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e301465662262 : Closed e301465662262 ∧ code e301465662262 = 1400977290038 := by decide
theorem cert_e301465662262 : check e301465662262 [[],[],[]] .smaller = true := by decide
def e301465662266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e301465662266 : Closed e301465662266 ∧ code e301465662266 = 1400977290042 := by decide
theorem cert_e301465662266 : check e301465662266 [[],[],[]] .smaller = true := by decide
def e301465662362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e301465662362 : Closed e301465662362 ∧ code e301465662362 = 1400977290138 := by decide
theorem cert_e301465662362 : check e301465662362 [[],[],[]] .smaller = true := by decide
def e301465799534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e301465799534 : Closed e301465799534 ∧ code e301465799534 = 1400977427310 := by decide
theorem cert_e301465799534 : check e301465799534 [[],[],[]] .smaller = true := by decide
def e301465799542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e301465799542 : Closed e301465799542 ∧ code e301465799542 = 1400977427318 := by decide
theorem cert_e301465799542 : check e301465799542 [[],[],[]] .smaller = true := by decide
def e301465799598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e301465799598 : Closed e301465799598 ∧ code e301465799598 = 1400977427374 := by decide
theorem cert_e301465799598 : check e301465799598 [[],[],[]] .smaller = true := by decide
def e301465799610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e301465799610 : Closed e301465799610 ∧ code e301465799610 = 1400977427386 := by decide
theorem cert_e301465799610 : check e301465799610 [[],[],[]] .smaller = true := by decide
def e301465799638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e301465799638 : Closed e301465799638 ∧ code e301465799638 = 1400977427414 := by decide
theorem cert_e301465799638 : check e301465799638 [[],[],[]] .smaller = true := by decide
def e301465799642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e301465799642 : Closed e301465799642 ∧ code e301465799642 = 1400977427418 := by decide
theorem cert_e301465799642 : check e301465799642 [[],[],[]] .smaller = true := by decide
def e301465799918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e301465799918 : Closed e301465799918 ∧ code e301465799918 = 1400977427694 := by decide
theorem cert_e301465799918 : check e301465799918 [[],[],[]] .smaller = true := by decide
def e301465799926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e301465799926 : Closed e301465799926 ∧ code e301465799926 = 1400977427702 := by decide
theorem cert_e301465799926 : check e301465799926 [[],[],[]] .smaller = true := by decide
def e301465800302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e301465800302 : Closed e301465800302 ∧ code e301465800302 = 1400977428078 := by decide
theorem cert_e301465800302 : check e301465800302 [[],[],[]] .smaller = true := by decide
def e301465800314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e301465800314 : Closed e301465800314 ∧ code e301465800314 = 1400977428090 := by decide
theorem cert_e301465800314 : check e301465800314 [[],[],[]] .smaller = true := by decide
def e301465800502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e301465800502 : Closed e301465800502 ∧ code e301465800502 = 1400977428278 := by decide
theorem cert_e301465800502 : check e301465800502 [[],[],[]] .smaller = true := by decide
def e301465800506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e301465800506 : Closed e301465800506 ∧ code e301465800506 = 1400977428282 := by decide
theorem cert_e301465800506 : check e301465800506 [[],[],[]] .smaller = true := by decide
def e301466389358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e301466389358 : Closed e301466389358 ∧ code e301466389358 = 1400978017134 := by decide
theorem cert_e301466389358 : check e301466389358 [[],[],[]] .smaller = true := by decide
def e301466389366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e301466389366 : Closed e301466389366 ∧ code e301466389366 = 1400978017142 := by decide
theorem cert_e301466389366 : check e301466389366 [[],[],[]] .smaller = true := by decide
def e301466389422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e301466389422 : Closed e301466389422 ∧ code e301466389422 = 1400978017198 := by decide
theorem cert_e301466389422 : check e301466389422 [[],[],[]] .smaller = true := by decide
def e301466389434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e301466389434 : Closed e301466389434 ∧ code e301466389434 = 1400978017210 := by decide
theorem cert_e301466389434 : check e301466389434 [[],[],[]] .smaller = true := by decide
end Blc.Floor40
