import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e75728948182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e75728948182 : Closed e75728948182 ∧ code e75728948182 = 1175240575958 := by decide
theorem cert_e75728948182 : check e75728948182 [[.under],[.under]] .sourceHead = true := by decide
def e75728948186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e75728948186 : Closed e75728948186 ∧ code e75728948186 = 1175240575962 := by decide
theorem cert_e75728948186 : check e75728948186 [[.under],[.under]] .sourceHead = true := by decide
def e75728948462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e75728948462 : Closed e75728948462 ∧ code e75728948462 = 1175240576238 := by decide
theorem cert_e75728948462 : check e75728948462 [[.under],[.under]] .sourceHead = true := by decide
def e75728948470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e75728948470 : Closed e75728948470 ∧ code e75728948470 = 1175240576246 := by decide
theorem cert_e75728948470 : check e75728948470 [[.under],[.under]] .sourceHead = true := by decide
def e75728948846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e75728948846 : Closed e75728948846 ∧ code e75728948846 = 1175240576622 := by decide
theorem cert_e75728948846 : check e75728948846 [[.under],[.under]] .sourceHead = true := by decide
def e75728948858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e75728948858 : Closed e75728948858 ∧ code e75728948858 = 1175240576634 := by decide
theorem cert_e75728948858 : check e75728948858 [[.under],[.under]] .sourceHead = true := by decide
def e75728949046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e75728949046 : Closed e75728949046 ∧ code e75728949046 = 1175240576822 := by decide
theorem cert_e75728949046 : check e75728949046 [[.under],[.under]] .sourceHead = true := by decide
def e75728949050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e75728949050 : Closed e75728949050 ∧ code e75728949050 = 1175240576826 := by decide
theorem cert_e75728949050 : check e75728949050 [[.under],[.under]] .sourceHead = true := by decide
def e75799550830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e75799550830 : Closed e75799550830 ∧ code e75799550830 = 1175311178606 := by decide
theorem cert_e75799550830 : check e75799550830 [[.under]] .sourceHead = true := by decide
def e75799550838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e75799550838 : Closed e75799550838 ∧ code e75799550838 = 1175311178614 := by decide
theorem cert_e75799550838 : check e75799550838 [[.under]] .sourceHead = true := by decide
def e75799550902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e75799550902 : Closed e75799550902 ∧ code e75799550902 = 1175311178678 := by decide
theorem cert_e75799550902 : check e75799550902 [[.under]] .sourceHead = true := by decide
def e75799551342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e75799551342 : Closed e75799551342 ∧ code e75799551342 = 1175311179118 := by decide
theorem cert_e75799551342 : check e75799551342 [[.under]] .sourceHead = true := by decide
def e75799551350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e75799551350 : Closed e75799551350 ∧ code e75799551350 = 1175311179126 := by decide
theorem cert_e75799551350 : check e75799551350 [[.under]] .sourceHead = true := by decide
def e75799551406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e75799551406 : Closed e75799551406 ∧ code e75799551406 = 1175311179182 := by decide
theorem cert_e75799551406 : check e75799551406 [[.under]] .sourceHead = true := by decide
def e75799551418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e75799551418 : Closed e75799551418 ∧ code e75799551418 = 1175311179194 := by decide
theorem cert_e75799551418 : check e75799551418 [[.under]] .sourceHead = true := by decide
def e75799551446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e75799551446 : Closed e75799551446 ∧ code e75799551446 = 1175311179222 := by decide
theorem cert_e75799551446 : check e75799551446 [[.under]] .sourceHead = true := by decide
def e75799551450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e75799551450 : Closed e75799551450 ∧ code e75799551450 = 1175311179226 := by decide
theorem cert_e75799551450 : check e75799551450 [[.under]] .sourceHead = true := by decide
def e75799551670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e75799551670 : Closed e75799551670 ∧ code e75799551670 = 1175311179446 := by decide
theorem cert_e75799551670 : check e75799551670 [[.under]] .sourceHead = true := by decide
def e75799551702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e75799551702 : Closed e75799551702 ∧ code e75799551702 = 1175311179478 := by decide
theorem cert_e75799551702 : check e75799551702 [[.under]] .sourceHead = true := by decide
def e75799551706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e75799551706 : Closed e75799551706 ∧ code e75799551706 = 1175311179482 := by decide
theorem cert_e75799551706 : check e75799551706 [[.under]] .sourceHead = true := by decide
def e75799553902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e75799553902 : Closed e75799553902 ∧ code e75799553902 = 1175311181678 := by decide
theorem cert_e75799553902 : check e75799553902 [[.under]] .sourceHead = true := by decide
def e75799553910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e75799553910 : Closed e75799553910 ∧ code e75799553910 = 1175311181686 := by decide
theorem cert_e75799553910 : check e75799553910 [[.under]] .sourceHead = true := by decide
def e75799553974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e75799553974 : Closed e75799553974 ∧ code e75799553974 = 1175311181750 := by decide
theorem cert_e75799553974 : check e75799553974 [[.under]] .sourceHead = true := by decide
def e75799555310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e75799555310 : Closed e75799555310 ∧ code e75799555310 = 1175311183086 := by decide
theorem cert_e75799555310 : check e75799555310 [[.under]] .sourceHead = true := by decide
def e75799555318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e75799555318 : Closed e75799555318 ∧ code e75799555318 = 1175311183094 := by decide
theorem cert_e75799555318 : check e75799555318 [[.under]] .sourceHead = true := by decide
def e75799555702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e75799555702 : Closed e75799555702 ∧ code e75799555702 = 1175311183478 := by decide
theorem cert_e75799555702 : check e75799555702 [[.under]] .sourceHead = true := by decide
def e75799556974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e75799556974 : Closed e75799556974 ∧ code e75799556974 = 1175311184750 := by decide
theorem cert_e75799556974 : check e75799556974 [[.under]] .sourceHead = true := by decide
def e75799556982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e75799556982 : Closed e75799556982 ∧ code e75799556982 = 1175311184758 := by decide
theorem cert_e75799556982 : check e75799556982 [[.under]] .sourceHead = true := by decide
def e75799557038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e75799557038 : Closed e75799557038 ∧ code e75799557038 = 1175311184814 := by decide
theorem cert_e75799557038 : check e75799557038 [[.under]] .sourceHead = true := by decide
def e75799557050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e75799557050 : Closed e75799557050 ∧ code e75799557050 = 1175311184826 := by decide
theorem cert_e75799557050 : check e75799557050 [[.under]] .sourceHead = true := by decide
def e75799557078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e75799557078 : Closed e75799557078 ∧ code e75799557078 = 1175311184854 := by decide
theorem cert_e75799557078 : check e75799557078 [[.under]] .sourceHead = true := by decide
def e75799557082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e75799557082 : Closed e75799557082 ∧ code e75799557082 = 1175311184858 := by decide
theorem cert_e75799557082 : check e75799557082 [[.under]] .sourceHead = true := by decide
def e75799557358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e75799557358 : Closed e75799557358 ∧ code e75799557358 = 1175311185134 := by decide
theorem cert_e75799557358 : check e75799557358 [[.under]] .sourceHead = true := by decide
def e75799557366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e75799557366 : Closed e75799557366 ∧ code e75799557366 = 1175311185142 := by decide
theorem cert_e75799557366 : check e75799557366 [[.under]] .sourceHead = true := by decide
def e75799557742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e75799557742 : Closed e75799557742 ∧ code e75799557742 = 1175311185518 := by decide
theorem cert_e75799557742 : check e75799557742 [[.under]] .sourceHead = true := by decide
def e75799557754 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e75799557754 : Closed e75799557754 ∧ code e75799557754 = 1175311185530 := by decide
theorem cert_e75799557754 : check e75799557754 [[.under]] .sourceHead = true := by decide
def e75799557942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e75799557942 : Closed e75799557942 ∧ code e75799557942 = 1175311185718 := by decide
theorem cert_e75799557942 : check e75799557942 [[.under]] .sourceHead = true := by decide
def e75799557946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e75799557946 : Closed e75799557946 ∧ code e75799557946 = 1175311185722 := by decide
theorem cert_e75799557946 : check e75799557946 [[.under]] .sourceHead = true := by decide
def e75799558582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e75799558582 : Closed e75799558582 ∧ code e75799558582 = 1175311186358 := by decide
theorem cert_e75799558582 : check e75799558582 [[.under]] .sourceHead = true := by decide
def e75799558614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e75799558614 : Closed e75799558614 ∧ code e75799558614 = 1175311186390 := by decide
theorem cert_e75799558614 : check e75799558614 [[.under]] .sourceHead = true := by decide
def e75799558618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e75799558618 : Closed e75799558618 ∧ code e75799558618 = 1175311186394 := by decide
theorem cert_e75799558618 : check e75799558618 [[.under]] .sourceHead = true := by decide
def e75799558774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e75799558774 : Closed e75799558774 ∧ code e75799558774 = 1175311186550 := by decide
theorem cert_e75799558774 : check e75799558774 [[.under]] .sourceHead = true := by decide
def e75799558966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e75799558966 : Closed e75799558966 ∧ code e75799558966 = 1175311186742 := by decide
theorem cert_e75799558966 : check e75799558966 [[.under]] .sourceHead = true := by decide
def e75799558970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e75799558970 : Closed e75799558970 ∧ code e75799558970 = 1175311186746 := by decide
theorem cert_e75799558970 : check e75799558970 [[.under]] .sourceHead = true := by decide
def e75799566190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e75799566190 : Closed e75799566190 ∧ code e75799566190 = 1175311193966 := by decide
theorem cert_e75799566190 : check e75799566190 [[.under]] .sourceHead = true := by decide
def e75799566198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e75799566198 : Closed e75799566198 ∧ code e75799566198 = 1175311193974 := by decide
theorem cert_e75799566198 : check e75799566198 [[.under]] .sourceHead = true := by decide
def e75799566262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e75799566262 : Closed e75799566262 ∧ code e75799566262 = 1175311194038 := by decide
theorem cert_e75799566262 : check e75799566262 [[.under]] .sourceHead = true := by decide
def e75799567598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e75799567598 : Closed e75799567598 ∧ code e75799567598 = 1175311195374 := by decide
theorem cert_e75799567598 : check e75799567598 [[.under]] .sourceHead = true := by decide
def e75799567606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e75799567606 : Closed e75799567606 ∧ code e75799567606 = 1175311195382 := by decide
theorem cert_e75799567606 : check e75799567606 [[.under]] .sourceHead = true := by decide
def e75799567990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e75799567990 : Closed e75799567990 ∧ code e75799567990 = 1175311195766 := by decide
theorem cert_e75799567990 : check e75799567990 [[.under]] .sourceHead = true := by decide
def e75799579502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e75799579502 : Closed e75799579502 ∧ code e75799579502 = 1175311207278 := by decide
theorem cert_e75799579502 : check e75799579502 [[.under]] .sourceHead = true := by decide
def e75799579510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e75799579510 : Closed e75799579510 ∧ code e75799579510 = 1175311207286 := by decide
theorem cert_e75799579510 : check e75799579510 [[.under]] .sourceHead = true := by decide
def e75799579566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e75799579566 : Closed e75799579566 ∧ code e75799579566 = 1175311207342 := by decide
theorem cert_e75799579566 : check e75799579566 [[.under]] .sourceHead = true := by decide
def e75799579578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e75799579578 : Closed e75799579578 ∧ code e75799579578 = 1175311207354 := by decide
theorem cert_e75799579578 : check e75799579578 [[.under]] .sourceHead = true := by decide
def e75799579606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e75799579606 : Closed e75799579606 ∧ code e75799579606 = 1175311207382 := by decide
theorem cert_e75799579606 : check e75799579606 [[.under]] .sourceHead = true := by decide
def e75799579610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e75799579610 : Closed e75799579610 ∧ code e75799579610 = 1175311207386 := by decide
theorem cert_e75799579610 : check e75799579610 [[.under]] .sourceHead = true := by decide
def e75799579886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e75799579886 : Closed e75799579886 ∧ code e75799579886 = 1175311207662 := by decide
theorem cert_e75799579886 : check e75799579886 [[.under]] .sourceHead = true := by decide
def e75799579894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e75799579894 : Closed e75799579894 ∧ code e75799579894 = 1175311207670 := by decide
theorem cert_e75799579894 : check e75799579894 [[.under]] .sourceHead = true := by decide
def e75799580270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e75799580270 : Closed e75799580270 ∧ code e75799580270 = 1175311208046 := by decide
theorem cert_e75799580270 : check e75799580270 [[.under]] .sourceHead = true := by decide
def e75799580282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e75799580282 : Closed e75799580282 ∧ code e75799580282 = 1175311208058 := by decide
theorem cert_e75799580282 : check e75799580282 [[.under]] .sourceHead = true := by decide
def e75799580470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e75799580470 : Closed e75799580470 ∧ code e75799580470 = 1175311208246 := by decide
theorem cert_e75799580470 : check e75799580470 [[.under]] .sourceHead = true := by decide
def e75799580474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e75799580474 : Closed e75799580474 ∧ code e75799580474 = 1175311208250 := by decide
theorem cert_e75799580474 : check e75799580474 [[.under]] .sourceHead = true := by decide
def e75799586230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e75799586230 : Closed e75799586230 ∧ code e75799586230 = 1175311214006 := by decide
theorem cert_e75799586230 : check e75799586230 [[.under]] .sourceHead = true := by decide
def e75799586262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e75799586262 : Closed e75799586262 ∧ code e75799586262 = 1175311214038 := by decide
theorem cert_e75799586262 : check e75799586262 [[.under]] .sourceHead = true := by decide
def e75799586266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e75799586266 : Closed e75799586266 ∧ code e75799586266 = 1175311214042 := by decide
theorem cert_e75799586266 : check e75799586266 [[.under]] .sourceHead = true := by decide
def e75799586422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e75799586422 : Closed e75799586422 ∧ code e75799586422 = 1175311214198 := by decide
theorem cert_e75799586422 : check e75799586422 [[.under]] .sourceHead = true := by decide
def e75799586614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e75799586614 : Closed e75799586614 ∧ code e75799586614 = 1175311214390 := by decide
theorem cert_e75799586614 : check e75799586614 [[.under]] .sourceHead = true := by decide
def e75799586618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e75799586618 : Closed e75799586618 ∧ code e75799586618 = 1175311214394 := by decide
theorem cert_e75799586618 : check e75799586618 [[.under]] .sourceHead = true := by decide
def e75799923566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e75799923566 : Closed e75799923566 ∧ code e75799923566 = 1175311551342 := by decide
theorem cert_e75799923566 : check e75799923566 [[.under]] .sourceHead = true := by decide
def e75799923574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e75799923574 : Closed e75799923574 ∧ code e75799923574 = 1175311551350 := by decide
theorem cert_e75799923574 : check e75799923574 [[.under]] .sourceHead = true := by decide
def e75799923630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e75799923630 : Closed e75799923630 ∧ code e75799923630 = 1175311551406 := by decide
theorem cert_e75799923630 : check e75799923630 [[.under]] .sourceHead = true := by decide
def e75799923642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e75799923642 : Closed e75799923642 ∧ code e75799923642 = 1175311551418 := by decide
theorem cert_e75799923642 : check e75799923642 [[.under]] .sourceHead = true := by decide
def e75799923670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e75799923670 : Closed e75799923670 ∧ code e75799923670 = 1175311551446 := by decide
theorem cert_e75799923670 : check e75799923670 [[.under]] .sourceHead = true := by decide
def e75799923674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e75799923674 : Closed e75799923674 ∧ code e75799923674 = 1175311551450 := by decide
theorem cert_e75799923674 : check e75799923674 [[.under]] .sourceHead = true := by decide
def e75799923950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e75799923950 : Closed e75799923950 ∧ code e75799923950 = 1175311551726 := by decide
theorem cert_e75799923950 : check e75799923950 [[.under]] .sourceHead = true := by decide
def e75799923958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e75799923958 : Closed e75799923958 ∧ code e75799923958 = 1175311551734 := by decide
theorem cert_e75799923958 : check e75799923958 [[.under]] .sourceHead = true := by decide
def e75799924334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e75799924334 : Closed e75799924334 ∧ code e75799924334 = 1175311552110 := by decide
theorem cert_e75799924334 : check e75799924334 [[.under]] .sourceHead = true := by decide
def e75799924346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e75799924346 : Closed e75799924346 ∧ code e75799924346 = 1175311552122 := by decide
theorem cert_e75799924346 : check e75799924346 [[.under]] .sourceHead = true := by decide
def e75799924534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e75799924534 : Closed e75799924534 ∧ code e75799924534 = 1175311552310 := by decide
theorem cert_e75799924534 : check e75799924534 [[.under]] .sourceHead = true := by decide
def e75799924538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e75799924538 : Closed e75799924538 ∧ code e75799924538 = 1175311552314 := by decide
theorem cert_e75799924538 : check e75799924538 [[.under]] .sourceHead = true := by decide
def e76453817710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e76453817710 : Closed e76453817710 ∧ code e76453817710 = 1175965445486 := by decide
theorem cert_e76453817710 : check e76453817710 [[.under]] .sourceHead = true := by decide
def e76453817718 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e76453817718 : Closed e76453817718 ∧ code e76453817718 = 1175965445494 := by decide
theorem cert_e76453817718 : check e76453817718 [[.under]] .sourceHead = true := by decide
def e76453817774 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e76453817774 : Closed e76453817774 ∧ code e76453817774 = 1175965445550 := by decide
theorem cert_e76453817774 : check e76453817774 [[.under]] .sourceHead = true := by decide
def e76453817786 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e76453817786 : Closed e76453817786 ∧ code e76453817786 = 1175965445562 := by decide
theorem cert_e76453817786 : check e76453817786 [[.under]] .sourceHead = true := by decide
def e76453817814 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e76453817814 : Closed e76453817814 ∧ code e76453817814 = 1175965445590 := by decide
theorem cert_e76453817814 : check e76453817814 [[.under]] .sourceHead = true := by decide
def e76453817818 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e76453817818 : Closed e76453817818 ∧ code e76453817818 = 1175965445594 := by decide
theorem cert_e76453817818 : check e76453817818 [[.under]] .sourceHead = true := by decide
def e76453818030 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e76453818030 : Closed e76453818030 ∧ code e76453818030 = 1175965445806 := by decide
theorem cert_e76453818030 : check e76453818030 [[.under]] .sourceHead = true := by decide
def e76453818042 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e76453818042 : Closed e76453818042 ∧ code e76453818042 = 1175965445818 := by decide
theorem cert_e76453818042 : check e76453818042 [[.under]] .sourceHead = true := by decide
def e76453818090 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e76453818090 : Closed e76453818090 ∧ code e76453818090 = 1175965445866 := by decide
theorem cert_e76453818090 : check e76453818090 [[.under]] .sourceHead = true := by decide
def e76453818198 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e76453818198 : Closed e76453818198 ∧ code e76453818198 = 1175965445974 := by decide
theorem cert_e76453818198 : check e76453818198 [[.under]] .sourceHead = true := by decide
def e76453818202 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e76453818202 : Closed e76453818202 ∧ code e76453818202 = 1175965445978 := by decide
theorem cert_e76453818202 : check e76453818202 [[.under]] .sourceHead = true := by decide
def e76453818218 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e76453818218 : Closed e76453818218 ∧ code e76453818218 = 1175965445994 := by decide
theorem cert_e76453818218 : check e76453818218 [[.under]] .sourceHead = true := by decide
def e76453819246 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e76453819246 : Closed e76453819246 ∧ code e76453819246 = 1175965447022 := by decide
theorem cert_e76453819246 : check e76453819246 [[.under]] .sourceHead = true := by decide
def e76453819254 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e76453819254 : Closed e76453819254 ∧ code e76453819254 = 1175965447030 := by decide
theorem cert_e76453819254 : check e76453819254 [[.under]] .sourceHead = true := by decide
def e76453819310 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e76453819310 : Closed e76453819310 ∧ code e76453819310 = 1175965447086 := by decide
theorem cert_e76453819310 : check e76453819310 [[.under]] .sourceHead = true := by decide
def e76453819322 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e76453819322 : Closed e76453819322 ∧ code e76453819322 = 1175965447098 := by decide
theorem cert_e76453819322 : check e76453819322 [[.under]] .sourceHead = true := by decide
def e76453819350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e76453819350 : Closed e76453819350 ∧ code e76453819350 = 1175965447126 := by decide
theorem cert_e76453819350 : check e76453819350 [[.under]] .sourceHead = true := by decide
def e76453819354 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e76453819354 : Closed e76453819354 ∧ code e76453819354 = 1175965447130 := by decide
theorem cert_e76453819354 : check e76453819354 [[.under]] .sourceHead = true := by decide
def e76453819630 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e76453819630 : Closed e76453819630 ∧ code e76453819630 = 1175965447406 := by decide
theorem cert_e76453819630 : check e76453819630 [[.under]] .sourceHead = true := by decide
def e76453819638 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e76453819638 : Closed e76453819638 ∧ code e76453819638 = 1175965447414 := by decide
theorem cert_e76453819638 : check e76453819638 [[.under]] .sourceHead = true := by decide
def e76453820014 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e76453820014 : Closed e76453820014 ∧ code e76453820014 = 1175965447790 := by decide
theorem cert_e76453820014 : check e76453820014 [[.under]] .sourceHead = true := by decide
def e76453820026 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e76453820026 : Closed e76453820026 ∧ code e76453820026 = 1175965447802 := by decide
theorem cert_e76453820026 : check e76453820026 [[.under]] .sourceHead = true := by decide
def e76453820214 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e76453820214 : Closed e76453820214 ∧ code e76453820214 = 1175965447990 := by decide
theorem cert_e76453820214 : check e76453820214 [[.under]] .sourceHead = true := by decide
def e76453820218 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e76453820218 : Closed e76453820218 ∧ code e76453820218 = 1175965447994 := by decide
theorem cert_e76453820218 : check e76453820218 [[.under]] .sourceHead = true := by decide
def e76453820846 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e76453820846 : Closed e76453820846 ∧ code e76453820846 = 1175965448622 := by decide
theorem cert_e76453820846 : check e76453820846 [[.under]] .sourceHead = true := by decide
def e76453820858 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e76453820858 : Closed e76453820858 ∧ code e76453820858 = 1175965448634 := by decide
theorem cert_e76453820858 : check e76453820858 [[.under]] .sourceHead = true := by decide
def e76453820906 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e76453820906 : Closed e76453820906 ∧ code e76453820906 = 1175965448682 := by decide
theorem cert_e76453820906 : check e76453820906 [[.under]] .sourceHead = true := by decide
def e76453821038 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e76453821038 : Closed e76453821038 ∧ code e76453821038 = 1175965448814 := by decide
theorem cert_e76453821038 : check e76453821038 [[.under]] .sourceHead = true := by decide
def e76453821050 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e76453821050 : Closed e76453821050 ∧ code e76453821050 = 1175965448826 := by decide
theorem cert_e76453821050 : check e76453821050 [[.under]] .sourceHead = true := by decide
def e76453821338 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e76453821338 : Closed e76453821338 ∧ code e76453821338 = 1175965449114 := by decide
theorem cert_e76453821338 : check e76453821338 [[.under]] .sourceHead = true := by decide
def e76453821654 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e76453821654 : Closed e76453821654 ∧ code e76453821654 = 1175965449430 := by decide
theorem cert_e76453821654 : check e76453821654 [[.under]] .sourceHead = true := by decide
def e76453821658 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e76453821658 : Closed e76453821658 ∧ code e76453821658 = 1175965449434 := by decide
theorem cert_e76453821658 : check e76453821658 [[.under]] .sourceHead = true := by decide
def e76453821674 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e76453821674 : Closed e76453821674 ∧ code e76453821674 = 1175965449450 := by decide
theorem cert_e76453821674 : check e76453821674 [[.under]] .sourceHead = true := by decide
def e76453821750 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e76453821750 : Closed e76453821750 ∧ code e76453821750 = 1175965449526 := by decide
theorem cert_e76453821750 : check e76453821750 [[.under]] .sourceHead = true := by decide
def e76453821754 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e76453821754 : Closed e76453821754 ∧ code e76453821754 = 1175965449530 := by decide
theorem cert_e76453821754 : check e76453821754 [[.under]] .sourceHead = true := by decide
def e76453821850 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e76453821850 : Closed e76453821850 ∧ code e76453821850 = 1175965449626 := by decide
theorem cert_e76453821850 : check e76453821850 [[.under]] .sourceHead = true := by decide
def e76453825390 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e76453825390 : Closed e76453825390 ∧ code e76453825390 = 1175965453166 := by decide
theorem cert_e76453825390 : check e76453825390 [[.under]] .sourceHead = true := by decide
def e76453825398 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e76453825398 : Closed e76453825398 ∧ code e76453825398 = 1175965453174 := by decide
theorem cert_e76453825398 : check e76453825398 [[.under]] .sourceHead = true := by decide
def e76453825454 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e76453825454 : Closed e76453825454 ∧ code e76453825454 = 1175965453230 := by decide
theorem cert_e76453825454 : check e76453825454 [[.under]] .sourceHead = true := by decide
def e76453825466 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e76453825466 : Closed e76453825466 ∧ code e76453825466 = 1175965453242 := by decide
theorem cert_e76453825466 : check e76453825466 [[.under]] .sourceHead = true := by decide
def e76453825494 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e76453825494 : Closed e76453825494 ∧ code e76453825494 = 1175965453270 := by decide
theorem cert_e76453825494 : check e76453825494 [[.under]] .sourceHead = true := by decide
def e76453825498 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e76453825498 : Closed e76453825498 ∧ code e76453825498 = 1175965453274 := by decide
theorem cert_e76453825498 : check e76453825498 [[.under]] .sourceHead = true := by decide
def e76453825774 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e76453825774 : Closed e76453825774 ∧ code e76453825774 = 1175965453550 := by decide
theorem cert_e76453825774 : check e76453825774 [[.under]] .sourceHead = true := by decide
def e76453825782 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e76453825782 : Closed e76453825782 ∧ code e76453825782 = 1175965453558 := by decide
theorem cert_e76453825782 : check e76453825782 [[.under]] .sourceHead = true := by decide
def e76453826158 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e76453826158 : Closed e76453826158 ∧ code e76453826158 = 1175965453934 := by decide
theorem cert_e76453826158 : check e76453826158 [[.under]] .sourceHead = true := by decide
def e76453826170 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e76453826170 : Closed e76453826170 ∧ code e76453826170 = 1175965453946 := by decide
theorem cert_e76453826170 : check e76453826170 [[.under]] .sourceHead = true := by decide
def e76453826358 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e76453826358 : Closed e76453826358 ∧ code e76453826358 = 1175965454134 := by decide
theorem cert_e76453826358 : check e76453826358 [[.under]] .sourceHead = true := by decide
def e76453826362 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e76453826362 : Closed e76453826362 ∧ code e76453826362 = 1175965454138 := by decide
theorem cert_e76453826362 : check e76453826362 [[.under]] .sourceHead = true := by decide
def e76453832110 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e76453832110 : Closed e76453832110 ∧ code e76453832110 = 1175965459886 := by decide
theorem cert_e76453832110 : check e76453832110 [[.under]] .sourceHead = true := by decide
def e76453832122 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e76453832122 : Closed e76453832122 ∧ code e76453832122 = 1175965459898 := by decide
theorem cert_e76453832122 : check e76453832122 [[.under]] .sourceHead = true := by decide
def e76453832170 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e76453832170 : Closed e76453832170 ∧ code e76453832170 = 1175965459946 := by decide
theorem cert_e76453832170 : check e76453832170 [[.under]] .sourceHead = true := by decide
def e76453832302 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e76453832302 : Closed e76453832302 ∧ code e76453832302 = 1175965460078 := by decide
theorem cert_e76453832302 : check e76453832302 [[.under]] .sourceHead = true := by decide
def e76453832314 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e76453832314 : Closed e76453832314 ∧ code e76453832314 = 1175965460090 := by decide
theorem cert_e76453832314 : check e76453832314 [[.under]] .sourceHead = true := by decide
def e76453832602 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e76453832602 : Closed e76453832602 ∧ code e76453832602 = 1175965460378 := by decide
theorem cert_e76453832602 : check e76453832602 [[.under]] .sourceHead = true := by decide
def e76453835478 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e76453835478 : Closed e76453835478 ∧ code e76453835478 = 1175965463254 := by decide
theorem cert_e76453835478 : check e76453835478 [[.under]] .sourceHead = true := by decide
def e76453835482 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e76453835482 : Closed e76453835482 ∧ code e76453835482 = 1175965463258 := by decide
theorem cert_e76453835482 : check e76453835482 [[.under]] .sourceHead = true := by decide
def e76453835498 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e76453835498 : Closed e76453835498 ∧ code e76453835498 = 1175965463274 := by decide
theorem cert_e76453835498 : check e76453835498 [[.under]] .sourceHead = true := by decide
def e76453835574 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e76453835574 : Closed e76453835574 ∧ code e76453835574 = 1175965463350 := by decide
theorem cert_e76453835574 : check e76453835574 [[.under]] .sourceHead = true := by decide
def e76453835578 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e76453835578 : Closed e76453835578 ∧ code e76453835578 = 1175965463354 := by decide
theorem cert_e76453835578 : check e76453835578 [[.under]] .sourceHead = true := by decide
def e76453835674 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e76453835674 : Closed e76453835674 ∧ code e76453835674 = 1175965463450 := by decide
theorem cert_e76453835674 : check e76453835674 [[.under]] .sourceHead = true := by decide
def e76453972846 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e76453972846 : Closed e76453972846 ∧ code e76453972846 = 1175965600622 := by decide
theorem cert_e76453972846 : check e76453972846 [[.under]] .sourceHead = true := by decide
def e76453972854 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e76453972854 : Closed e76453972854 ∧ code e76453972854 = 1175965600630 := by decide
theorem cert_e76453972854 : check e76453972854 [[.under]] .sourceHead = true := by decide
def e76453972910 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e76453972910 : Closed e76453972910 ∧ code e76453972910 = 1175965600686 := by decide
theorem cert_e76453972910 : check e76453972910 [[.under]] .sourceHead = true := by decide
def e76453972922 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e76453972922 : Closed e76453972922 ∧ code e76453972922 = 1175965600698 := by decide
theorem cert_e76453972922 : check e76453972922 [[.under]] .sourceHead = true := by decide
def e76453972950 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e76453972950 : Closed e76453972950 ∧ code e76453972950 = 1175965600726 := by decide
theorem cert_e76453972950 : check e76453972950 [[.under]] .sourceHead = true := by decide
def e76453972954 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e76453972954 : Closed e76453972954 ∧ code e76453972954 = 1175965600730 := by decide
theorem cert_e76453972954 : check e76453972954 [[.under]] .sourceHead = true := by decide
def e76453973230 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e76453973230 : Closed e76453973230 ∧ code e76453973230 = 1175965601006 := by decide
theorem cert_e76453973230 : check e76453973230 [[.under]] .sourceHead = true := by decide
def e76453973238 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e76453973238 : Closed e76453973238 ∧ code e76453973238 = 1175965601014 := by decide
theorem cert_e76453973238 : check e76453973238 [[.under]] .sourceHead = true := by decide
def e76453973614 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e76453973614 : Closed e76453973614 ∧ code e76453973614 = 1175965601390 := by decide
theorem cert_e76453973614 : check e76453973614 [[.under]] .sourceHead = true := by decide
def e76453973626 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e76453973626 : Closed e76453973626 ∧ code e76453973626 = 1175965601402 := by decide
theorem cert_e76453973626 : check e76453973626 [[.under]] .sourceHead = true := by decide
def e76453973814 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e76453973814 : Closed e76453973814 ∧ code e76453973814 = 1175965601590 := by decide
theorem cert_e76453973814 : check e76453973814 [[.under]] .sourceHead = true := by decide
def e76453973818 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e76453973818 : Closed e76453973818 ∧ code e76453973818 = 1175965601594 := by decide
theorem cert_e76453973818 : check e76453973818 [[.under]] .sourceHead = true := by decide
def e76454562670 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e76454562670 : Closed e76454562670 ∧ code e76454562670 = 1175966190446 := by decide
theorem cert_e76454562670 : check e76454562670 [[.under]] .sourceHead = true := by decide
def e76454562678 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e76454562678 : Closed e76454562678 ∧ code e76454562678 = 1175966190454 := by decide
theorem cert_e76454562678 : check e76454562678 [[.under]] .sourceHead = true := by decide
def e76454562734 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e76454562734 : Closed e76454562734 ∧ code e76454562734 = 1175966190510 := by decide
theorem cert_e76454562734 : check e76454562734 [[.under]] .sourceHead = true := by decide
def e76454562746 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e76454562746 : Closed e76454562746 ∧ code e76454562746 = 1175966190522 := by decide
theorem cert_e76454562746 : check e76454562746 [[.under]] .sourceHead = true := by decide
def e76454562774 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e76454562774 : Closed e76454562774 ∧ code e76454562774 = 1175966190550 := by decide
theorem cert_e76454562774 : check e76454562774 [[.under]] .sourceHead = true := by decide
def e76454562778 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e76454562778 : Closed e76454562778 ∧ code e76454562778 = 1175966190554 := by decide
theorem cert_e76454562778 : check e76454562778 [[.under]] .sourceHead = true := by decide
def e76454563054 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e76454563054 : Closed e76454563054 ∧ code e76454563054 = 1175966190830 := by decide
theorem cert_e76454563054 : check e76454563054 [[.under]] .sourceHead = true := by decide
def e76454563062 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e76454563062 : Closed e76454563062 ∧ code e76454563062 = 1175966190838 := by decide
theorem cert_e76454563062 : check e76454563062 [[.under]] .sourceHead = true := by decide
end Blc.Floor40
