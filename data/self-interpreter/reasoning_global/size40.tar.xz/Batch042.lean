import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302800886982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302800886982 : Closed e302800886982 ∧ code e302800886982 = 1402312514758 := by decide
theorem cert_e302800886982 : check e302800886982 [[],[]] .chain = true := by decide
def e302800887010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302800887010 : Closed e302800887010 ∧ code e302800887010 = 1402312514786 := by decide
theorem cert_e302800887010 : check e302800887010 [[],[]] .chain = true := by decide
def e302800887022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800887022 : Closed e302800887022 ∧ code e302800887022 = 1402312514798 := by decide
theorem cert_e302800887022 : check e302800887022 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800887030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800887030 : Closed e302800887030 ∧ code e302800887030 = 1402312514806 := by decide
theorem cert_e302800887030 : check e302800887030 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800888054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 1))))))
theorem wire_e302800888054 : Closed e302800888054 ∧ code e302800888054 = 1402312515830 := by decide
theorem cert_e302800888054 : check e302800888054 [[],[]] .chain = true := by decide
def e302800888246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e302800888246 : Closed e302800888246 ∧ code e302800888246 = 1402312516022 := by decide
theorem cert_e302800888246 : check e302800888246 [[],[]] .chain = true := by decide
def e302800888250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e302800888250 : Closed e302800888250 ∧ code e302800888250 = 1402312516026 := by decide
theorem cert_e302800888250 : check e302800888250 [[],[]] .chain = true := by decide
def e302800888278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e302800888278 : Closed e302800888278 ∧ code e302800888278 = 1402312516054 := by decide
theorem cert_e302800888278 : check e302800888278 [[],[]] .chain = true := by decide
def e302800888298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e302800888298 : Closed e302800888298 ∧ code e302800888298 = 1402312516074 := by decide
theorem cert_e302800888298 : check e302800888298 [[],[]] .chain = true := by decide
def e302800888438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e302800888438 : Closed e302800888438 ∧ code e302800888438 = 1402312516214 := by decide
theorem cert_e302800888438 : check e302800888438 [[],[]] .chain = true := by decide
def e302800888630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e302800888630 : Closed e302800888630 ∧ code e302800888630 = 1402312516406 := by decide
theorem cert_e302800888630 : check e302800888630 [[],[]] .chain = true := by decide
def e302800888634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e302800888634 : Closed e302800888634 ∧ code e302800888634 = 1402312516410 := by decide
theorem cert_e302800888634 : check e302800888634 [[],[]] .chain = true := by decide
def e302800888718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 2)))))))
theorem wire_e302800888718 : Closed e302800888718 ∧ code e302800888718 = 1402312516494 := by decide
theorem cert_e302800888718 : check e302800888718 [[],[]] .chain = true := by decide
def e302800888730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e302800888730 : Closed e302800888730 ∧ code e302800888730 = 1402312516506 := by decide
theorem cert_e302800888730 : check e302800888730 [[],[]] .chain = true := by decide
def e302800889398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302800889398 : Closed e302800889398 ∧ code e302800889398 = 1402312517174 := by decide
theorem cert_e302800889398 : check e302800889398 [[],[]] .chain = true := by decide
def e302800889402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302800889402 : Closed e302800889402 ∧ code e302800889402 = 1402312517178 := by decide
theorem cert_e302800889402 : check e302800889402 [[],[]] .chain = true := by decide
def e302800889486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302800889486 : Closed e302800889486 ∧ code e302800889486 = 1402312517262 := by decide
theorem cert_e302800889486 : check e302800889486 [[],[]] .chain = true := by decide
def e302800889542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302800889542 : Closed e302800889542 ∧ code e302800889542 = 1402312517318 := by decide
theorem cert_e302800889542 : check e302800889542 [[],[]] .chain = true := by decide
def e302800889622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302800889622 : Closed e302800889622 ∧ code e302800889622 = 1402312517398 := by decide
theorem cert_e302800889622 : check e302800889622 [[],[]] .chain = true := by decide
def e302800889626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302800889626 : Closed e302800889626 ∧ code e302800889626 = 1402312517402 := by decide
theorem cert_e302800889626 : check e302800889626 [[],[]] .chain = true := by decide
def e302800889670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302800889670 : Closed e302800889670 ∧ code e302800889670 = 1402312517446 := by decide
theorem cert_e302800889670 : check e302800889670 [[],[]] .chain = true := by decide
def e302800889698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302800889698 : Closed e302800889698 ∧ code e302800889698 = 1402312517474 := by decide
theorem cert_e302800889698 : check e302800889698 [[],[]] .chain = true := by decide
def e302800889710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e302800889710 : Closed e302800889710 ∧ code e302800889710 = 1402312517486 := by decide
theorem cert_e302800889710 : check e302800889710 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302800889718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e302800889718 : Closed e302800889718 ∧ code e302800889718 = 1402312517494 := by decide
theorem cert_e302800889718 : check e302800889718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302800889782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e302800889782 : Closed e302800889782 ∧ code e302800889782 = 1402312517558 := by decide
theorem cert_e302800889782 : check e302800889782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302800889966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e302800889966 : Closed e302800889966 ∧ code e302800889966 = 1402312517742 := by decide
theorem cert_e302800889966 : check e302800889966 [[],[]] .chain = true := by decide
def e302800889978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e302800889978 : Closed e302800889978 ∧ code e302800889978 = 1402312517754 := by decide
theorem cert_e302800889978 : check e302800889978 [[],[]] .chain = true := by decide
def e302800890254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302800890254 : Closed e302800890254 ∧ code e302800890254 = 1402312518030 := by decide
theorem cert_e302800890254 : check e302800890254 [[],[]] .chain = true := by decide
def e302800890310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302800890310 : Closed e302800890310 ∧ code e302800890310 = 1402312518086 := by decide
theorem cert_e302800890310 : check e302800890310 [[],[]] .chain = true := by decide
def e302800890910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 3))))))))
theorem wire_e302800890910 : Closed e302800890910 ∧ code e302800890910 = 1402312518686 := by decide
theorem cert_e302800890910 : check e302800890910 [[],[]] .chain = true := by decide
def e302800890934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302800890934 : Closed e302800890934 ∧ code e302800890934 = 1402312518710 := by decide
theorem cert_e302800890934 : check e302800890934 [[],[]] .chain = true := by decide
def e302800890938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302800890938 : Closed e302800890938 ∧ code e302800890938 = 1402312518714 := by decide
theorem cert_e302800890938 : check e302800890938 [[],[]] .chain = true := by decide
def e302800891078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302800891078 : Closed e302800891078 ∧ code e302800891078 = 1402312518854 := by decide
theorem cert_e302800891078 : check e302800891078 [[],[]] .chain = true := by decide
def e302800891106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302800891106 : Closed e302800891106 ∧ code e302800891106 = 1402312518882 := by decide
theorem cert_e302800891106 : check e302800891106 [[],[]] .chain = true := by decide
def e302800891118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800891118 : Closed e302800891118 ∧ code e302800891118 = 1402312518894 := by decide
theorem cert_e302800891118 : check e302800891118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302800891126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800891126 : Closed e302800891126 ∧ code e302800891126 = 1402312518902 := by decide
theorem cert_e302800891126 : check e302800891126 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302800891510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e302800891510 : Closed e302800891510 ∧ code e302800891510 = 1402312519286 := by decide
theorem cert_e302800891510 : check e302800891510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302800897902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e302800897902 : Closed e302800897902 ∧ code e302800897902 = 1402312525678 := by decide
theorem cert_e302800897902 : check e302800897902 [[],[]] .chain = true := by decide
def e302800897910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e302800897910 : Closed e302800897910 ∧ code e302800897910 = 1402312525686 := by decide
theorem cert_e302800897910 : check e302800897910 [[],[]] .chain = true := by decide
def e302800897966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e302800897966 : Closed e302800897966 ∧ code e302800897966 = 1402312525742 := by decide
theorem cert_e302800897966 : check e302800897966 [[],[]] .chain = true := by decide
def e302800897978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e302800897978 : Closed e302800897978 ∧ code e302800897978 = 1402312525754 := by decide
theorem cert_e302800897978 : check e302800897978 [[],[]] .chain = true := by decide
def e302800898006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))
theorem wire_e302800898006 : Closed e302800898006 ∧ code e302800898006 = 1402312525782 := by decide
theorem cert_e302800898006 : check e302800898006 [[],[]] .chain = true := by decide
def e302800898010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))
theorem wire_e302800898010 : Closed e302800898010 ∧ code e302800898010 = 1402312525786 := by decide
theorem cert_e302800898010 : check e302800898010 [[],[]] .chain = true := by decide
def e302800899502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e302800899502 : Closed e302800899502 ∧ code e302800899502 = 1402312527278 := by decide
theorem cert_e302800899502 : check e302800899502 [[],[]] .chain = true := by decide
def e302800899514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e302800899514 : Closed e302800899514 ∧ code e302800899514 = 1402312527290 := by decide
theorem cert_e302800899514 : check e302800899514 [[],[]] .chain = true := by decide
def e302800899562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e302800899562 : Closed e302800899562 ∧ code e302800899562 = 1402312527338 := by decide
theorem cert_e302800899562 : check e302800899562 [[],[]] .chain = true := by decide
def e302800899758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e302800899758 : Closed e302800899758 ∧ code e302800899758 = 1402312527534 := by decide
theorem cert_e302800899758 : check e302800899758 [[],[]] .chain = true := by decide
def e302800899770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e302800899770 : Closed e302800899770 ∧ code e302800899770 = 1402312527546 := by decide
theorem cert_e302800899770 : check e302800899770 [[],[]] .chain = true := by decide
def e302800900010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e302800900010 : Closed e302800900010 ∧ code e302800900010 = 1402312527786 := by decide
theorem cert_e302800900010 : check e302800900010 [[],[]] .chain = true := by decide
def e302800900974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e302800900974 : Closed e302800900974 ∧ code e302800900974 = 1402312528750 := by decide
theorem cert_e302800900974 : check e302800900974 [[],[]] .chain = true := by decide
def e302800900982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e302800900982 : Closed e302800900982 ∧ code e302800900982 = 1402312528758 := by decide
theorem cert_e302800900982 : check e302800900982 [[],[]] .chain = true := by decide
def e302800901038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e302800901038 : Closed e302800901038 ∧ code e302800901038 = 1402312528814 := by decide
theorem cert_e302800901038 : check e302800901038 [[],[]] .chain = true := by decide
def e302800901050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e302800901050 : Closed e302800901050 ∧ code e302800901050 = 1402312528826 := by decide
theorem cert_e302800901050 : check e302800901050 [[],[]] .chain = true := by decide
def e302800901078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e302800901078 : Closed e302800901078 ∧ code e302800901078 = 1402312528854 := by decide
theorem cert_e302800901078 : check e302800901078 [[],[]] .chain = true := by decide
def e302800901082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e302800901082 : Closed e302800901082 ∧ code e302800901082 = 1402312528858 := by decide
theorem cert_e302800901082 : check e302800901082 [[],[]] .chain = true := by decide
def e302800901358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800901358 : Closed e302800901358 ∧ code e302800901358 = 1402312529134 := by decide
theorem cert_e302800901358 : check e302800901358 [[],[]] .chain = true := by decide
def e302800901366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800901366 : Closed e302800901366 ∧ code e302800901366 = 1402312529142 := by decide
theorem cert_e302800901366 : check e302800901366 [[],[]] .chain = true := by decide
def e302800901742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e302800901742 : Closed e302800901742 ∧ code e302800901742 = 1402312529518 := by decide
theorem cert_e302800901742 : check e302800901742 [[],[]] .chain = true := by decide
def e302800901754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e302800901754 : Closed e302800901754 ∧ code e302800901754 = 1402312529530 := by decide
theorem cert_e302800901754 : check e302800901754 [[],[]] .chain = true := by decide
def e302800901942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800901942 : Closed e302800901942 ∧ code e302800901942 = 1402312529718 := by decide
theorem cert_e302800901942 : check e302800901942 [[],[]] .chain = true := by decide
def e302800901946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800901946 : Closed e302800901946 ∧ code e302800901946 = 1402312529722 := by decide
theorem cert_e302800901946 : check e302800901946 [[],[]] .chain = true := by decide
def e302800902382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e302800902382 : Closed e302800902382 ∧ code e302800902382 = 1402312530158 := by decide
theorem cert_e302800902382 : check e302800902382 [[],[]] .chain = true := by decide
def e302800902390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e302800902390 : Closed e302800902390 ∧ code e302800902390 = 1402312530166 := by decide
theorem cert_e302800902390 : check e302800902390 [[],[]] .chain = true := by decide
def e302800902574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e302800902574 : Closed e302800902574 ∧ code e302800902574 = 1402312530350 := by decide
theorem cert_e302800902574 : check e302800902574 [[],[]] .chain = true := by decide
def e302800902586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e302800902586 : Closed e302800902586 ∧ code e302800902586 = 1402312530362 := by decide
theorem cert_e302800902586 : check e302800902586 [[],[]] .chain = true := by decide
def e302800902634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e302800902634 : Closed e302800902634 ∧ code e302800902634 = 1402312530410 := by decide
theorem cert_e302800902634 : check e302800902634 [[],[]] .chain = true := by decide
def e302800902766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e302800902766 : Closed e302800902766 ∧ code e302800902766 = 1402312530542 := by decide
theorem cert_e302800902766 : check e302800902766 [[],[]] .chain = true := by decide
def e302800902778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e302800902778 : Closed e302800902778 ∧ code e302800902778 = 1402312530554 := by decide
theorem cert_e302800902778 : check e302800902778 [[],[]] .chain = true := by decide
def e302800902942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e302800902942 : Closed e302800902942 ∧ code e302800902942 = 1402312530718 := by decide
theorem cert_e302800902942 : check e302800902942 [[],[]] .chain = true := by decide
def e302800903054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e302800903054 : Closed e302800903054 ∧ code e302800903054 = 1402312530830 := by decide
theorem cert_e302800903054 : check e302800903054 [[],[]] .chain = true := by decide
def e302800903066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e302800903066 : Closed e302800903066 ∧ code e302800903066 = 1402312530842 := by decide
theorem cert_e302800903066 : check e302800903066 [[],[]] .chain = true := by decide
def e302800903278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e302800903278 : Closed e302800903278 ∧ code e302800903278 = 1402312531054 := by decide
theorem cert_e302800903278 : check e302800903278 [[],[]] .chain = true := by decide
def e302800903290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e302800903290 : Closed e302800903290 ∧ code e302800903290 = 1402312531066 := by decide
theorem cert_e302800903290 : check e302800903290 [[],[]] .chain = true := by decide
def e302800903454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302800903454 : Closed e302800903454 ∧ code e302800903454 = 1402312531230 := by decide
theorem cert_e302800903454 : check e302800903454 [[],[]] .chain = true := by decide
def e302800903622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302800903622 : Closed e302800903622 ∧ code e302800903622 = 1402312531398 := by decide
theorem cert_e302800903622 : check e302800903622 [[],[]] .chain = true := by decide
def e302800903734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800903734 : Closed e302800903734 ∧ code e302800903734 = 1402312531510 := by decide
theorem cert_e302800903734 : check e302800903734 [[],[]] .chain = true := by decide
def e302800903738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800903738 : Closed e302800903738 ∧ code e302800903738 = 1402312531514 := by decide
theorem cert_e302800903738 : check e302800903738 [[],[]] .chain = true := by decide
def e302800903786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e302800903786 : Closed e302800903786 ∧ code e302800903786 = 1402312531562 := by decide
theorem cert_e302800903786 : check e302800903786 [[],[]] .chain = true := by decide
def e302800903822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800903822 : Closed e302800903822 ∧ code e302800903822 = 1402312531598 := by decide
theorem cert_e302800903822 : check e302800903822 [[],[]] .chain = true := by decide
def e302800903834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e302800903834 : Closed e302800903834 ∧ code e302800903834 = 1402312531610 := by decide
theorem cert_e302800903834 : check e302800903834 [[],[]] .chain = true := by decide
def e302800903878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800903878 : Closed e302800903878 ∧ code e302800903878 = 1402312531654 := by decide
theorem cert_e302800903878 : check e302800903878 [[],[]] .chain = true := by decide
def e302800908654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e302800908654 : Closed e302800908654 ∧ code e302800908654 = 1402312536430 := by decide
theorem cert_e302800908654 : check e302800908654 [[],[]] .chain = true := by decide
def e302800908662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e302800908662 : Closed e302800908662 ∧ code e302800908662 = 1402312536438 := by decide
theorem cert_e302800908662 : check e302800908662 [[],[]] .chain = true := by decide
def e302800908718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e302800908718 : Closed e302800908718 ∧ code e302800908718 = 1402312536494 := by decide
theorem cert_e302800908718 : check e302800908718 [[],[]] .chain = true := by decide
def e302800908730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e302800908730 : Closed e302800908730 ∧ code e302800908730 = 1402312536506 := by decide
theorem cert_e302800908730 : check e302800908730 [[],[]] .chain = true := by decide
def e302800908778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e302800908778 : Closed e302800908778 ∧ code e302800908778 = 1402312536554 := by decide
theorem cert_e302800908778 : check e302800908778 [[],[]] .chain = true := by decide
def e302800909422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e302800909422 : Closed e302800909422 ∧ code e302800909422 = 1402312537198 := by decide
theorem cert_e302800909422 : check e302800909422 [[],[]] .chain = true := by decide
def e302800909434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e302800909434 : Closed e302800909434 ∧ code e302800909434 = 1402312537210 := by decide
theorem cert_e302800909434 : check e302800909434 [[],[]] .chain = true := by decide
def e302800909598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302800909598 : Closed e302800909598 ∧ code e302800909598 = 1402312537374 := by decide
theorem cert_e302800909598 : check e302800909598 [[],[]] .chain = true := by decide
def e302800909766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302800909766 : Closed e302800909766 ∧ code e302800909766 = 1402312537542 := by decide
theorem cert_e302800909766 : check e302800909766 [[],[]] .chain = true := by decide
def e302800909870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e302800909870 : Closed e302800909870 ∧ code e302800909870 = 1402312537646 := by decide
theorem cert_e302800909870 : check e302800909870 [[],[]] .chain = true := by decide
def e302800910050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e302800910050 : Closed e302800910050 ∧ code e302800910050 = 1402312537826 := by decide
theorem cert_e302800910050 : check e302800910050 [[],[]] .chain = true := by decide
def e302800910062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e302800910062 : Closed e302800910062 ∧ code e302800910062 = 1402312537838 := by decide
theorem cert_e302800910062 : check e302800910062 [[],[]] .sourceHead = true := by decide
def e302800910102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800910102 : Closed e302800910102 ∧ code e302800910102 = 1402312537878 := by decide
theorem cert_e302800910102 : check e302800910102 [[],[]] .chain = true := by decide
def e302800910106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800910106 : Closed e302800910106 ∧ code e302800910106 = 1402312537882 := by decide
theorem cert_e302800910106 : check e302800910106 [[],[]] .chain = true := by decide
def e302800910150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800910150 : Closed e302800910150 ∧ code e302800910150 = 1402312537926 := by decide
theorem cert_e302800910150 : check e302800910150 [[],[]] .chain = true := by decide
def e302800910178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800910178 : Closed e302800910178 ∧ code e302800910178 = 1402312537954 := by decide
theorem cert_e302800910178 : check e302800910178 [[],[]] .chain = true := by decide
def e302800910190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e302800910190 : Closed e302800910190 ∧ code e302800910190 = 1402312537966 := by decide
theorem cert_e302800910190 : check e302800910190 [[],[]] .sourceHead = true := by decide
def e302800910198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e302800910198 : Closed e302800910198 ∧ code e302800910198 = 1402312537974 := by decide
theorem cert_e302800910198 : check e302800910198 [[],[]] .sourceHead = true := by decide
def e302800910510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e302800910510 : Closed e302800910510 ∧ code e302800910510 = 1402312538286 := by decide
theorem cert_e302800910510 : check e302800910510 [[],[]] .chain = true := by decide
def e302800910522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e302800910522 : Closed e302800910522 ∧ code e302800910522 = 1402312538298 := by decide
theorem cert_e302800910522 : check e302800910522 [[],[]] .chain = true := by decide
def e302800910894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e302800910894 : Closed e302800910894 ∧ code e302800910894 = 1402312538670 := by decide
theorem cert_e302800910894 : check e302800910894 [[],[]] .chain = true := by decide
def e302800911074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e302800911074 : Closed e302800911074 ∧ code e302800911074 = 1402312538850 := by decide
theorem cert_e302800911074 : check e302800911074 [[],[]] .chain = true := by decide
def e302800911086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e302800911086 : Closed e302800911086 ∧ code e302800911086 = 1402312538862 := by decide
theorem cert_e302800911086 : check e302800911086 [[],[]] .sourceHead = true := by decide
def e302800911242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e302800911242 : Closed e302800911242 ∧ code e302800911242 = 1402312539018 := by decide
theorem cert_e302800911242 : check e302800911242 [[],[]] .chain = true := by decide
def e302800911266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e302800911266 : Closed e302800911266 ∧ code e302800911266 = 1402312539042 := by decide
theorem cert_e302800911266 : check e302800911266 [[],[]] .chain = true := by decide
def e302800911278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e302800911278 : Closed e302800911278 ∧ code e302800911278 = 1402312539054 := by decide
theorem cert_e302800911278 : check e302800911278 [[],[]] .sourceHead = true := by decide
def e302800911290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e302800911290 : Closed e302800911290 ∧ code e302800911290 = 1402312539066 := by decide
theorem cert_e302800911290 : check e302800911290 [[],[]] .sourceHead = true := by decide
def e302800911446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e302800911446 : Closed e302800911446 ∧ code e302800911446 = 1402312539222 := by decide
theorem cert_e302800911446 : check e302800911446 [[],[]] .chain = true := by decide
def e302800911450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e302800911450 : Closed e302800911450 ∧ code e302800911450 = 1402312539226 := by decide
theorem cert_e302800911450 : check e302800911450 [[],[]] .chain = true := by decide
def e302800911466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e302800911466 : Closed e302800911466 ∧ code e302800911466 = 1402312539242 := by decide
theorem cert_e302800911466 : check e302800911466 [[],[]] .chain = true := by decide
def e302800911638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800911638 : Closed e302800911638 ∧ code e302800911638 = 1402312539414 := by decide
theorem cert_e302800911638 : check e302800911638 [[],[]] .chain = true := by decide
def e302800911642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800911642 : Closed e302800911642 ∧ code e302800911642 = 1402312539418 := by decide
theorem cert_e302800911642 : check e302800911642 [[],[]] .chain = true := by decide
def e302800911686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800911686 : Closed e302800911686 ∧ code e302800911686 = 1402312539462 := by decide
theorem cert_e302800911686 : check e302800911686 [[],[]] .chain = true := by decide
def e302800911714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800911714 : Closed e302800911714 ∧ code e302800911714 = 1402312539490 := by decide
theorem cert_e302800911714 : check e302800911714 [[],[]] .chain = true := by decide
def e302800911726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e302800911726 : Closed e302800911726 ∧ code e302800911726 = 1402312539502 := by decide
theorem cert_e302800911726 : check e302800911726 [[],[]] .sourceHead = true := by decide
def e302800911734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e302800911734 : Closed e302800911734 ∧ code e302800911734 = 1402312539510 := by decide
theorem cert_e302800911734 : check e302800911734 [[],[]] .sourceHead = true := by decide
def e302800911754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e302800911754 : Closed e302800911754 ∧ code e302800911754 = 1402312539530 := by decide
theorem cert_e302800911754 : check e302800911754 [[],[]] .chain = true := by decide
def e302800911778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e302800911778 : Closed e302800911778 ∧ code e302800911778 = 1402312539554 := by decide
theorem cert_e302800911778 : check e302800911778 [[],[]] .chain = true := by decide
def e302800911790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e302800911790 : Closed e302800911790 ∧ code e302800911790 = 1402312539566 := by decide
theorem cert_e302800911790 : check e302800911790 [[],[]] .sourceHead = true := by decide
def e302800911802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e302800911802 : Closed e302800911802 ∧ code e302800911802 = 1402312539578 := by decide
theorem cert_e302800911802 : check e302800911802 [[],[]] .sourceHead = true := by decide
def e302800911830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e302800911830 : Closed e302800911830 ∧ code e302800911830 = 1402312539606 := by decide
theorem cert_e302800911830 : check e302800911830 [[],[]] .sourceHead = true := by decide
def e302800911834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e302800911834 : Closed e302800911834 ∧ code e302800911834 = 1402312539610 := by decide
theorem cert_e302800911834 : check e302800911834 [[],[]] .sourceHead = true := by decide
def e302800912878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e302800912878 : Closed e302800912878 ∧ code e302800912878 = 1402312540654 := by decide
theorem cert_e302800912878 : check e302800912878 [[],[]] .chain = true := by decide
def e302800912886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e302800912886 : Closed e302800912886 ∧ code e302800912886 = 1402312540662 := by decide
theorem cert_e302800912886 : check e302800912886 [[],[]] .chain = true := by decide
def e302800913262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e302800913262 : Closed e302800913262 ∧ code e302800913262 = 1402312541038 := by decide
theorem cert_e302800913262 : check e302800913262 [[],[]] .chain = true := by decide
def e302800913274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e302800913274 : Closed e302800913274 ∧ code e302800913274 = 1402312541050 := by decide
theorem cert_e302800913274 : check e302800913274 [[],[]] .chain = true := by decide
def e302800913326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e302800913326 : Closed e302800913326 ∧ code e302800913326 = 1402312541102 := by decide
theorem cert_e302800913326 : check e302800913326 [[],[]] .chain = true := by decide
def e302800913386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e302800913386 : Closed e302800913386 ∧ code e302800913386 = 1402312541162 := by decide
theorem cert_e302800913386 : check e302800913386 [[],[]] .chain = true := by decide
def e302800913646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e302800913646 : Closed e302800913646 ∧ code e302800913646 = 1402312541422 := by decide
theorem cert_e302800913646 : check e302800913646 [[],[]] .chain = true := by decide
def e302800913654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e302800913654 : Closed e302800913654 ∧ code e302800913654 = 1402312541430 := by decide
theorem cert_e302800913654 : check e302800913654 [[],[]] .chain = true := by decide
def e302800914030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e302800914030 : Closed e302800914030 ∧ code e302800914030 = 1402312541806 := by decide
theorem cert_e302800914030 : check e302800914030 [[],[]] .chain = true := by decide
def e302800914042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e302800914042 : Closed e302800914042 ∧ code e302800914042 = 1402312541818 := by decide
theorem cert_e302800914042 : check e302800914042 [[],[]] .chain = true := by decide
def e302800914206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e302800914206 : Closed e302800914206 ∧ code e302800914206 = 1402312541982 := by decide
theorem cert_e302800914206 : check e302800914206 [[],[]] .chain = true := by decide
def e302800914318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e302800914318 : Closed e302800914318 ∧ code e302800914318 = 1402312542094 := by decide
theorem cert_e302800914318 : check e302800914318 [[],[]] .chain = true := by decide
def e302800914330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e302800914330 : Closed e302800914330 ∧ code e302800914330 = 1402312542106 := by decide
theorem cert_e302800914330 : check e302800914330 [[],[]] .chain = true := by decide
def e302800915566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302800915566 : Closed e302800915566 ∧ code e302800915566 = 1402312543342 := by decide
theorem cert_e302800915566 : check e302800915566 [[],[]] .chain = true := by decide
def e302800915578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302800915578 : Closed e302800915578 ∧ code e302800915578 = 1402312543354 := by decide
theorem cert_e302800915578 : check e302800915578 [[],[]] .chain = true := by decide
def e302800915742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302800915742 : Closed e302800915742 ∧ code e302800915742 = 1402312543518 := by decide
theorem cert_e302800915742 : check e302800915742 [[],[]] .chain = true := by decide
def e302800915910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302800915910 : Closed e302800915910 ∧ code e302800915910 = 1402312543686 := by decide
theorem cert_e302800915910 : check e302800915910 [[],[]] .chain = true := by decide
def e302800916014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e302800916014 : Closed e302800916014 ∧ code e302800916014 = 1402312543790 := by decide
theorem cert_e302800916014 : check e302800916014 [[],[]] .chain = true := by decide
def e302800916194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e302800916194 : Closed e302800916194 ∧ code e302800916194 = 1402312543970 := by decide
theorem cert_e302800916194 : check e302800916194 [[],[]] .chain = true := by decide
def e302800916206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e302800916206 : Closed e302800916206 ∧ code e302800916206 = 1402312543982 := by decide
theorem cert_e302800916206 : check e302800916206 [[],[]] .sourceHead = true := by decide
def e302800916246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302800916246 : Closed e302800916246 ∧ code e302800916246 = 1402312544022 := by decide
theorem cert_e302800916246 : check e302800916246 [[],[]] .chain = true := by decide
def e302800916250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302800916250 : Closed e302800916250 ∧ code e302800916250 = 1402312544026 := by decide
theorem cert_e302800916250 : check e302800916250 [[],[]] .chain = true := by decide
def e302800916294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302800916294 : Closed e302800916294 ∧ code e302800916294 = 1402312544070 := by decide
theorem cert_e302800916294 : check e302800916294 [[],[]] .chain = true := by decide
def e302800916322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302800916322 : Closed e302800916322 ∧ code e302800916322 = 1402312544098 := by decide
theorem cert_e302800916322 : check e302800916322 [[],[]] .chain = true := by decide
def e302800916334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e302800916334 : Closed e302800916334 ∧ code e302800916334 = 1402312544110 := by decide
theorem cert_e302800916334 : check e302800916334 [[],[]] .sourceHead = true := by decide
def e302800916342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e302800916342 : Closed e302800916342 ∧ code e302800916342 = 1402312544118 := by decide
theorem cert_e302800916342 : check e302800916342 [[],[]] .sourceHead = true := by decide
def e302800916702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e302800916702 : Closed e302800916702 ∧ code e302800916702 = 1402312544478 := by decide
theorem cert_e302800916702 : check e302800916702 [[],[]] .chain = true := by decide
def e302800916730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e302800916730 : Closed e302800916730 ∧ code e302800916730 = 1402312544506 := by decide
theorem cert_e302800916730 : check e302800916730 [[],[]] .chain = true := by decide
def e302800917278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302800917278 : Closed e302800917278 ∧ code e302800917278 = 1402312545054 := by decide
theorem cert_e302800917278 : check e302800917278 [[],[]] .chain = true := by decide
def e302800917446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302800917446 : Closed e302800917446 ∧ code e302800917446 = 1402312545222 := by decide
theorem cert_e302800917446 : check e302800917446 [[],[]] .chain = true := by decide
def e302800918590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e302800918590 : Closed e302800918590 ∧ code e302800918590 = 1402312546366 := by decide
theorem cert_e302800918590 : check e302800918590 [[],[]] .chain = true := by decide
def e302800919010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e302800919010 : Closed e302800919010 ∧ code e302800919010 = 1402312546786 := by decide
theorem cert_e302800919010 : check e302800919010 [[],[]] .chain = true := by decide
def e302800919022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e302800919022 : Closed e302800919022 ∧ code e302800919022 = 1402312546798 := by decide
theorem cert_e302800919022 : check e302800919022 [[],[]] .sourceHead = true := by decide
def e302800919582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e302800919582 : Closed e302800919582 ∧ code e302800919582 = 1402312547358 := by decide
theorem cert_e302800919582 : check e302800919582 [[],[]] .chain = true := by decide
def e302800919606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302800919606 : Closed e302800919606 ∧ code e302800919606 = 1402312547382 := by decide
theorem cert_e302800919606 : check e302800919606 [[],[]] .chain = true := by decide
def e302800919610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302800919610 : Closed e302800919610 ∧ code e302800919610 = 1402312547386 := by decide
theorem cert_e302800919610 : check e302800919610 [[],[]] .chain = true := by decide
def e302800919750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302800919750 : Closed e302800919750 ∧ code e302800919750 = 1402312547526 := by decide
theorem cert_e302800919750 : check e302800919750 [[],[]] .chain = true := by decide
end Blc.Floor40
