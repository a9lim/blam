import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801510318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e302801510318 : Closed e302801510318 ∧ code e302801510318 = 1402313138094 := by decide
theorem cert_e302801510318 : check e302801510318 [[],[]] .chain = true := by decide
def e302801510330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e302801510330 : Closed e302801510330 ∧ code e302801510330 = 1402313138106 := by decide
theorem cert_e302801510330 : check e302801510330 [[],[]] .chain = true := by decide
def e302801512222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e302801512222 : Closed e302801512222 ∧ code e302801512222 = 1402313139998 := by decide
theorem cert_e302801512222 : check e302801512222 [[],[]] .smaller = true := by decide
def e302801512334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e302801512334 : Closed e302801512334 ∧ code e302801512334 = 1402313140110 := by decide
theorem cert_e302801512334 : check e302801512334 [[],[]] .smaller = true := by decide
def e302801512382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e302801512382 : Closed e302801512382 ∧ code e302801512382 = 1402313140158 := by decide
theorem cert_e302801512382 : check e302801512382 [[],[]] .chain = true := by decide
def e302801512430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e302801512430 : Closed e302801512430 ∧ code e302801512430 = 1402313140206 := by decide
theorem cert_e302801512430 : check e302801512430 [[],[]] .chain = true := by decide
def e302801515294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e302801515294 : Closed e302801515294 ∧ code e302801515294 = 1402313143070 := by decide
theorem cert_e302801515294 : check e302801515294 [[],[]] .smaller = true := by decide
def e302801515462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e302801515462 : Closed e302801515462 ∧ code e302801515462 = 1402313143238 := by decide
theorem cert_e302801515462 : check e302801515462 [[],[]] .smaller = true := by decide
def e302801515486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e302801515486 : Closed e302801515486 ∧ code e302801515486 = 1402313143262 := by decide
theorem cert_e302801515486 : check e302801515486 [[],[]] .smaller = true := by decide
def e302801515502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e302801515502 : Closed e302801515502 ∧ code e302801515502 = 1402313143278 := by decide
theorem cert_e302801515502 : check e302801515502 [[],[]] .smaller = true := by decide
def e302801516942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e302801516942 : Closed e302801516942 ∧ code e302801516942 = 1402313144718 := by decide
theorem cert_e302801516942 : check e302801516942 [[],[]] .smaller = true := by decide
def e302801516990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e302801516990 : Closed e302801516990 ∧ code e302801516990 = 1402313144766 := by decide
theorem cert_e302801516990 : check e302801516990 [[],[]] .chain = true := by decide
def e302801516998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e302801516998 : Closed e302801516998 ∧ code e302801516998 = 1402313144774 := by decide
theorem cert_e302801516998 : check e302801516998 [[],[]] .smaller = true := by decide
def e302801517022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e302801517022 : Closed e302801517022 ∧ code e302801517022 = 1402313144798 := by decide
theorem cert_e302801517022 : check e302801517022 [[],[]] .smaller = true := by decide
def e302801517046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e302801517046 : Closed e302801517046 ∧ code e302801517046 = 1402313144822 := by decide
theorem cert_e302801517046 : check e302801517046 [[],[]] .smaller = true := by decide
def e302801517050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e302801517050 : Closed e302801517050 ∧ code e302801517050 = 1402313144826 := by decide
theorem cert_e302801517050 : check e302801517050 [[],[]] .chain = true := by decide
def e302801517806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e302801517806 : Closed e302801517806 ∧ code e302801517806 = 1402313145582 := by decide
theorem cert_e302801517806 : check e302801517806 [[],[]] .smaller = true := by decide
def e302801517814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e302801517814 : Closed e302801517814 ∧ code e302801517814 = 1402313145590 := by decide
theorem cert_e302801517814 : check e302801517814 [[],[]] .smaller = true := by decide
def e302801518190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e302801518190 : Closed e302801518190 ∧ code e302801518190 = 1402313145966 := by decide
theorem cert_e302801518190 : check e302801518190 [[],[]] .chain = true := by decide
def e302801518202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e302801518202 : Closed e302801518202 ∧ code e302801518202 = 1402313145978 := by decide
theorem cert_e302801518202 : check e302801518202 [[],[]] .chain = true := by decide
def e302801574622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302801574622 : Closed e302801574622 ∧ code e302801574622 = 1402313202398 := by decide
theorem cert_e302801574622 : check e302801574622 [[],[]] .chain = true := by decide
def e302801574646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302801574646 : Closed e302801574646 ∧ code e302801574646 = 1402313202422 := by decide
theorem cert_e302801574646 : check e302801574646 [[],[]] .chain = true := by decide
def e302801574750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302801574750 : Closed e302801574750 ∧ code e302801574750 = 1402313202526 := by decide
theorem cert_e302801574750 : check e302801574750 [[],[]] .chain = true := by decide
def e302801574766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e302801574766 : Closed e302801574766 ∧ code e302801574766 = 1402313202542 := by decide
theorem cert_e302801574766 : check e302801574766 [[],[]] .smaller = true := by decide
def e302801574774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e302801574774 : Closed e302801574774 ∧ code e302801574774 = 1402313202550 := by decide
theorem cert_e302801574774 : check e302801574774 [[],[]] .smaller = true := by decide
def e302801574778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302801574778 : Closed e302801574778 ∧ code e302801574778 = 1402313202554 := by decide
theorem cert_e302801574778 : check e302801574778 [[],[]] .chain = true := by decide
def e302801574838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e302801574838 : Closed e302801574838 ∧ code e302801574838 = 1402313202614 := by decide
theorem cert_e302801574838 : check e302801574838 [[],[]] .smaller = true := by decide
def e302801574870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302801574870 : Closed e302801574870 ∧ code e302801574870 = 1402313202646 := by decide
theorem cert_e302801574870 : check e302801574870 [[],[]] .chain = true := by decide
def e302801574874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302801574874 : Closed e302801574874 ∧ code e302801574874 = 1402313202650 := by decide
theorem cert_e302801574874 : check e302801574874 [[],[]] .chain = true := by decide
def e302801575262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e302801575262 : Closed e302801575262 ∧ code e302801575262 = 1402313203038 := by decide
theorem cert_e302801575262 : check e302801575262 [[],[]] .chain = true := by decide
def e302801575278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302801575278 : Closed e302801575278 ∧ code e302801575278 = 1402313203054 := by decide
theorem cert_e302801575278 : check e302801575278 [[],[]] .smaller = true := by decide
def e302801575286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302801575286 : Closed e302801575286 ∧ code e302801575286 = 1402313203062 := by decide
theorem cert_e302801575286 : check e302801575286 [[],[]] .smaller = true := by decide
def e302801575290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e302801575290 : Closed e302801575290 ∧ code e302801575290 = 1402313203066 := by decide
theorem cert_e302801575290 : check e302801575290 [[],[]] .chain = true := by decide
def e302801575342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302801575342 : Closed e302801575342 ∧ code e302801575342 = 1402313203118 := by decide
theorem cert_e302801575342 : check e302801575342 [[],[]] .smaller = true := by decide
def e302801575354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302801575354 : Closed e302801575354 ∧ code e302801575354 = 1402313203130 := by decide
theorem cert_e302801575354 : check e302801575354 [[],[]] .smaller = true := by decide
def e302801575382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302801575382 : Closed e302801575382 ∧ code e302801575382 = 1402313203158 := by decide
theorem cert_e302801575382 : check e302801575382 [[],[]] .smaller = true := by decide
def e302801575386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302801575386 : Closed e302801575386 ∧ code e302801575386 = 1402313203162 := by decide
theorem cert_e302801575386 : check e302801575386 [[],[]] .smaller = true := by decide
def e302801575402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e302801575402 : Closed e302801575402 ∧ code e302801575402 = 1402313203178 := by decide
theorem cert_e302801575402 : check e302801575402 [[],[]] .chain = true := by decide
def e302801575606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e302801575606 : Closed e302801575606 ∧ code e302801575606 = 1402313203382 := by decide
theorem cert_e302801575606 : check e302801575606 [[],[]] .smaller = true := by decide
def e302801575638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e302801575638 : Closed e302801575638 ∧ code e302801575638 = 1402313203414 := by decide
theorem cert_e302801575638 : check e302801575638 [[],[]] .smaller = true := by decide
def e302801575642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e302801575642 : Closed e302801575642 ∧ code e302801575642 = 1402313203418 := by decide
theorem cert_e302801575642 : check e302801575642 [[],[]] .smaller = true := by decide
def e302801575766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302801575766 : Closed e302801575766 ∧ code e302801575766 = 1402313203542 := by decide
theorem cert_e302801575766 : check e302801575766 [[],[]] .chain = true := by decide
def e302801575770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302801575770 : Closed e302801575770 ∧ code e302801575770 = 1402313203546 := by decide
theorem cert_e302801575770 : check e302801575770 [[],[]] .chain = true := by decide
def e302801575786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302801575786 : Closed e302801575786 ∧ code e302801575786 = 1402313203562 := by decide
theorem cert_e302801575786 : check e302801575786 [[],[]] .chain = true := by decide
def e302801577694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302801577694 : Closed e302801577694 ∧ code e302801577694 = 1402313205470 := by decide
theorem cert_e302801577694 : check e302801577694 [[],[]] .chain = true := by decide
def e302801577718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302801577718 : Closed e302801577718 ∧ code e302801577718 = 1402313205494 := by decide
theorem cert_e302801577718 : check e302801577718 [[],[]] .chain = true := by decide
def e302801577822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302801577822 : Closed e302801577822 ∧ code e302801577822 = 1402313205598 := by decide
theorem cert_e302801577822 : check e302801577822 [[],[]] .chain = true := by decide
def e302801577838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e302801577838 : Closed e302801577838 ∧ code e302801577838 = 1402313205614 := by decide
theorem cert_e302801577838 : check e302801577838 [[],[]] .smaller = true := by decide
def e302801577846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e302801577846 : Closed e302801577846 ∧ code e302801577846 = 1402313205622 := by decide
theorem cert_e302801577846 : check e302801577846 [[],[]] .smaller = true := by decide
def e302801577850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302801577850 : Closed e302801577850 ∧ code e302801577850 = 1402313205626 := by decide
theorem cert_e302801577850 : check e302801577850 [[],[]] .chain = true := by decide
def e302801577910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e302801577910 : Closed e302801577910 ∧ code e302801577910 = 1402313205686 := by decide
theorem cert_e302801577910 : check e302801577910 [[],[]] .smaller = true := by decide
def e302801577942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302801577942 : Closed e302801577942 ∧ code e302801577942 = 1402313205718 := by decide
theorem cert_e302801577942 : check e302801577942 [[],[]] .chain = true := by decide
def e302801577946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302801577946 : Closed e302801577946 ∧ code e302801577946 = 1402313205722 := by decide
theorem cert_e302801577946 : check e302801577946 [[],[]] .chain = true := by decide
def e302801578462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302801578462 : Closed e302801578462 ∧ code e302801578462 = 1402313206238 := by decide
theorem cert_e302801578462 : check e302801578462 [[],[]] .chain = true := by decide
def e302801578486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302801578486 : Closed e302801578486 ∧ code e302801578486 = 1402313206262 := by decide
theorem cert_e302801578486 : check e302801578486 [[],[]] .chain = true := by decide
def e302801579230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801579230 : Closed e302801579230 ∧ code e302801579230 = 1402313207006 := by decide
theorem cert_e302801579230 : check e302801579230 [[],[]] .chain = true := by decide
def e302801579246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801579246 : Closed e302801579246 ∧ code e302801579246 = 1402313207022 := by decide
theorem cert_e302801579246 : check e302801579246 [[],[]] .smaller = true := by decide
def e302801579254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801579254 : Closed e302801579254 ∧ code e302801579254 = 1402313207030 := by decide
theorem cert_e302801579254 : check e302801579254 [[],[]] .smaller = true := by decide
def e302801579258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801579258 : Closed e302801579258 ∧ code e302801579258 = 1402313207034 := by decide
theorem cert_e302801579258 : check e302801579258 [[],[]] .chain = true := by decide
def e302801579638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302801579638 : Closed e302801579638 ∧ code e302801579638 = 1402313207414 := by decide
theorem cert_e302801579638 : check e302801579638 [[],[]] .smaller = true := by decide
def e302801579830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801579830 : Closed e302801579830 ∧ code e302801579830 = 1402313207606 := by decide
theorem cert_e302801579830 : check e302801579830 [[],[]] .chain = true := by decide
def e302801579834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801579834 : Closed e302801579834 ∧ code e302801579834 = 1402313207610 := by decide
theorem cert_e302801579834 : check e302801579834 [[],[]] .chain = true := by decide
def e302801580894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e302801580894 : Closed e302801580894 ∧ code e302801580894 = 1402313208670 := by decide
theorem cert_e302801580894 : check e302801580894 [[],[]] .chain = true := by decide
def e302801580910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302801580910 : Closed e302801580910 ∧ code e302801580910 = 1402313208686 := by decide
theorem cert_e302801580910 : check e302801580910 [[],[]] .smaller = true := by decide
def e302801580918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302801580918 : Closed e302801580918 ∧ code e302801580918 = 1402313208694 := by decide
theorem cert_e302801580918 : check e302801580918 [[],[]] .smaller = true := by decide
def e302801580922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e302801580922 : Closed e302801580922 ∧ code e302801580922 = 1402313208698 := by decide
theorem cert_e302801580922 : check e302801580922 [[],[]] .chain = true := by decide
def e302801580974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302801580974 : Closed e302801580974 ∧ code e302801580974 = 1402313208750 := by decide
theorem cert_e302801580974 : check e302801580974 [[],[]] .smaller = true := by decide
def e302801580986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302801580986 : Closed e302801580986 ∧ code e302801580986 = 1402313208762 := by decide
theorem cert_e302801580986 : check e302801580986 [[],[]] .smaller = true := by decide
def e302801581014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302801581014 : Closed e302801581014 ∧ code e302801581014 = 1402313208790 := by decide
theorem cert_e302801581014 : check e302801581014 [[],[]] .smaller = true := by decide
def e302801581018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302801581018 : Closed e302801581018 ∧ code e302801581018 = 1402313208794 := by decide
theorem cert_e302801581018 : check e302801581018 [[],[]] .smaller = true := by decide
def e302801581034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e302801581034 : Closed e302801581034 ∧ code e302801581034 = 1402313208810 := by decide
theorem cert_e302801581034 : check e302801581034 [[],[]] .chain = true := by decide
def e302801581278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801581278 : Closed e302801581278 ∧ code e302801581278 = 1402313209054 := by decide
theorem cert_e302801581278 : check e302801581278 [[],[]] .chain = true := by decide
def e302801581294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801581294 : Closed e302801581294 ∧ code e302801581294 = 1402313209070 := by decide
theorem cert_e302801581294 : check e302801581294 [[],[]] .smaller = true := by decide
def e302801581302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801581302 : Closed e302801581302 ∧ code e302801581302 = 1402313209078 := by decide
theorem cert_e302801581302 : check e302801581302 [[],[]] .smaller = true := by decide
def e302801581306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801581306 : Closed e302801581306 ∧ code e302801581306 = 1402313209082 := by decide
theorem cert_e302801581306 : check e302801581306 [[],[]] .chain = true := by decide
def e302801581678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801581678 : Closed e302801581678 ∧ code e302801581678 = 1402313209454 := by decide
theorem cert_e302801581678 : check e302801581678 [[],[]] .smaller = true := by decide
def e302801581690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801581690 : Closed e302801581690 ∧ code e302801581690 = 1402313209466 := by decide
theorem cert_e302801581690 : check e302801581690 [[],[]] .smaller = true := by decide
def e302801581878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801581878 : Closed e302801581878 ∧ code e302801581878 = 1402313209654 := by decide
theorem cert_e302801581878 : check e302801581878 [[],[]] .smaller = true := by decide
def e302801581882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801581882 : Closed e302801581882 ∧ code e302801581882 = 1402313209658 := by decide
theorem cert_e302801581882 : check e302801581882 [[],[]] .smaller = true := by decide
def e302801581978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801581978 : Closed e302801581978 ∧ code e302801581978 = 1402313209754 := by decide
theorem cert_e302801581978 : check e302801581978 [[],[]] .chain = true := by decide
def e302801582518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e302801582518 : Closed e302801582518 ∧ code e302801582518 = 1402313210294 := by decide
theorem cert_e302801582518 : check e302801582518 [[],[]] .smaller = true := by decide
def e302801582550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e302801582550 : Closed e302801582550 ∧ code e302801582550 = 1402313210326 := by decide
theorem cert_e302801582550 : check e302801582550 [[],[]] .smaller = true := by decide
def e302801582554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e302801582554 : Closed e302801582554 ∧ code e302801582554 = 1402313210330 := by decide
theorem cert_e302801582554 : check e302801582554 [[],[]] .smaller = true := by decide
def e302801582710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302801582710 : Closed e302801582710 ∧ code e302801582710 = 1402313210486 := by decide
theorem cert_e302801582710 : check e302801582710 [[],[]] .smaller = true := by decide
def e302801582902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801582902 : Closed e302801582902 ∧ code e302801582902 = 1402313210678 := by decide
theorem cert_e302801582902 : check e302801582902 [[],[]] .smaller = true := by decide
def e302801582906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801582906 : Closed e302801582906 ∧ code e302801582906 = 1402313210682 := by decide
theorem cert_e302801582906 : check e302801582906 [[],[]] .smaller = true := by decide
def e302801583070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 3))))))))
theorem wire_e302801583070 : Closed e302801583070 ∧ code e302801583070 = 1402313210846 := by decide
theorem cert_e302801583070 : check e302801583070 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e302801583318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302801583318 : Closed e302801583318 ∧ code e302801583318 = 1402313211094 := by decide
theorem cert_e302801583318 : check e302801583318 [[],[]] .chain = true := by decide
def e302801583322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302801583322 : Closed e302801583322 ∧ code e302801583322 = 1402313211098 := by decide
theorem cert_e302801583322 : check e302801583322 [[],[]] .chain = true := by decide
def e302801583338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302801583338 : Closed e302801583338 ∧ code e302801583338 = 1402313211114 := by decide
theorem cert_e302801583338 : check e302801583338 [[],[]] .chain = true := by decide
def e302801583414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801583414 : Closed e302801583414 ∧ code e302801583414 = 1402313211190 := by decide
theorem cert_e302801583414 : check e302801583414 [[],[]] .chain = true := by decide
def e302801583418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801583418 : Closed e302801583418 ∧ code e302801583418 = 1402313211194 := by decide
theorem cert_e302801583418 : check e302801583418 [[],[]] .chain = true := by decide
def e302801583514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801583514 : Closed e302801583514 ∧ code e302801583514 = 1402313211290 := by decide
theorem cert_e302801583514 : check e302801583514 [[],[]] .chain = true := by decide
def e302801583582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 3))))))))
theorem wire_e302801583582 : Closed e302801583582 ∧ code e302801583582 = 1402313211358 := by decide
theorem cert_e302801583582 : check e302801583582 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e302801583598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 3)) (.var 2))))))))
theorem wire_e302801583598 : Closed e302801583598 ∧ code e302801583598 = 1402313211374 := by decide
theorem cert_e302801583598 : check e302801583598 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801586110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e302801586110 : Closed e302801586110 ∧ code e302801586110 = 1402313213886 := by decide
theorem cert_e302801586110 : check e302801586110 [[],[]] .chain = true := by decide
def e302801586158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e302801586158 : Closed e302801586158 ∧ code e302801586158 = 1402313213934 := by decide
theorem cert_e302801586158 : check e302801586158 [[],[]] .chain = true := by decide
def e302801589982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302801589982 : Closed e302801589982 ∧ code e302801589982 = 1402313217758 := by decide
theorem cert_e302801589982 : check e302801589982 [[],[]] .chain = true := by decide
def e302801590006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302801590006 : Closed e302801590006 ∧ code e302801590006 = 1402313217782 := by decide
theorem cert_e302801590006 : check e302801590006 [[],[]] .chain = true := by decide
def e302801590110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302801590110 : Closed e302801590110 ∧ code e302801590110 = 1402313217886 := by decide
theorem cert_e302801590110 : check e302801590110 [[],[]] .chain = true := by decide
def e302801590126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e302801590126 : Closed e302801590126 ∧ code e302801590126 = 1402313217902 := by decide
theorem cert_e302801590126 : check e302801590126 [[],[]] .smaller = true := by decide
def e302801590134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e302801590134 : Closed e302801590134 ∧ code e302801590134 = 1402313217910 := by decide
theorem cert_e302801590134 : check e302801590134 [[],[]] .smaller = true := by decide
def e302801590138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302801590138 : Closed e302801590138 ∧ code e302801590138 = 1402313217914 := by decide
theorem cert_e302801590138 : check e302801590138 [[],[]] .chain = true := by decide
def e302801590198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e302801590198 : Closed e302801590198 ∧ code e302801590198 = 1402313217974 := by decide
theorem cert_e302801590198 : check e302801590198 [[],[]] .smaller = true := by decide
def e302801590230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302801590230 : Closed e302801590230 ∧ code e302801590230 = 1402313218006 := by decide
theorem cert_e302801590230 : check e302801590230 [[],[]] .chain = true := by decide
def e302801590234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302801590234 : Closed e302801590234 ∧ code e302801590234 = 1402313218010 := by decide
theorem cert_e302801590234 : check e302801590234 [[],[]] .chain = true := by decide
def e302801590750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302801590750 : Closed e302801590750 ∧ code e302801590750 = 1402313218526 := by decide
theorem cert_e302801590750 : check e302801590750 [[],[]] .chain = true := by decide
def e302801590774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302801590774 : Closed e302801590774 ∧ code e302801590774 = 1402313218550 := by decide
theorem cert_e302801590774 : check e302801590774 [[],[]] .chain = true := by decide
def e302801591518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302801591518 : Closed e302801591518 ∧ code e302801591518 = 1402313219294 := by decide
theorem cert_e302801591518 : check e302801591518 [[],[]] .chain = true := by decide
def e302801591534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e302801591534 : Closed e302801591534 ∧ code e302801591534 = 1402313219310 := by decide
theorem cert_e302801591534 : check e302801591534 [[],[]] .smaller = true := by decide
def e302801591542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e302801591542 : Closed e302801591542 ∧ code e302801591542 = 1402313219318 := by decide
theorem cert_e302801591542 : check e302801591542 [[],[]] .smaller = true := by decide
def e302801591546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302801591546 : Closed e302801591546 ∧ code e302801591546 = 1402313219322 := by decide
theorem cert_e302801591546 : check e302801591546 [[],[]] .chain = true := by decide
def e302801591926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e302801591926 : Closed e302801591926 ∧ code e302801591926 = 1402313219702 := by decide
theorem cert_e302801591926 : check e302801591926 [[],[]] .smaller = true := by decide
def e302801592118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801592118 : Closed e302801592118 ∧ code e302801592118 = 1402313219894 := by decide
theorem cert_e302801592118 : check e302801592118 [[],[]] .chain = true := by decide
def e302801592122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801592122 : Closed e302801592122 ∧ code e302801592122 = 1402313219898 := by decide
theorem cert_e302801592122 : check e302801592122 [[],[]] .chain = true := by decide
def e302801601470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e302801601470 : Closed e302801601470 ∧ code e302801601470 = 1402313229246 := by decide
theorem cert_e302801601470 : check e302801601470 [[],[]] .chain = true := by decide
def e302801601526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e302801601526 : Closed e302801601526 ∧ code e302801601526 = 1402313229302 := by decide
theorem cert_e302801601526 : check e302801601526 [[],[]] .chain = true := by decide
def e302801603422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302801603422 : Closed e302801603422 ∧ code e302801603422 = 1402313231198 := by decide
theorem cert_e302801603422 : check e302801603422 [[],[]] .chain = true := by decide
def e302801603438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302801603438 : Closed e302801603438 ∧ code e302801603438 = 1402313231214 := by decide
theorem cert_e302801603438 : check e302801603438 [[],[]] .smaller = true := by decide
def e302801603446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302801603446 : Closed e302801603446 ∧ code e302801603446 = 1402313231222 := by decide
theorem cert_e302801603446 : check e302801603446 [[],[]] .smaller = true := by decide
def e302801603450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302801603450 : Closed e302801603450 ∧ code e302801603450 = 1402313231226 := by decide
theorem cert_e302801603450 : check e302801603450 [[],[]] .chain = true := by decide
def e302801603502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302801603502 : Closed e302801603502 ∧ code e302801603502 = 1402313231278 := by decide
theorem cert_e302801603502 : check e302801603502 [[],[]] .smaller = true := by decide
def e302801603514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302801603514 : Closed e302801603514 ∧ code e302801603514 = 1402313231290 := by decide
theorem cert_e302801603514 : check e302801603514 [[],[]] .smaller = true := by decide
def e302801603542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302801603542 : Closed e302801603542 ∧ code e302801603542 = 1402313231318 := by decide
theorem cert_e302801603542 : check e302801603542 [[],[]] .smaller = true := by decide
def e302801603546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302801603546 : Closed e302801603546 ∧ code e302801603546 = 1402313231322 := by decide
theorem cert_e302801603546 : check e302801603546 [[],[]] .smaller = true := by decide
def e302801603562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302801603562 : Closed e302801603562 ∧ code e302801603562 = 1402313231338 := by decide
theorem cert_e302801603562 : check e302801603562 [[],[]] .chain = true := by decide
def e302801603806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302801603806 : Closed e302801603806 ∧ code e302801603806 = 1402313231582 := by decide
theorem cert_e302801603806 : check e302801603806 [[],[]] .chain = true := by decide
def e302801603822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302801603822 : Closed e302801603822 ∧ code e302801603822 = 1402313231598 := by decide
theorem cert_e302801603822 : check e302801603822 [[],[]] .smaller = true := by decide
def e302801603830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302801603830 : Closed e302801603830 ∧ code e302801603830 = 1402313231606 := by decide
theorem cert_e302801603830 : check e302801603830 [[],[]] .smaller = true := by decide
def e302801603834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302801603834 : Closed e302801603834 ∧ code e302801603834 = 1402313231610 := by decide
theorem cert_e302801603834 : check e302801603834 [[],[]] .chain = true := by decide
def e302801604206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302801604206 : Closed e302801604206 ∧ code e302801604206 = 1402313231982 := by decide
theorem cert_e302801604206 : check e302801604206 [[],[]] .smaller = true := by decide
def e302801604218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302801604218 : Closed e302801604218 ∧ code e302801604218 = 1402313231994 := by decide
theorem cert_e302801604218 : check e302801604218 [[],[]] .smaller = true := by decide
def e302801604406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801604406 : Closed e302801604406 ∧ code e302801604406 = 1402313232182 := by decide
theorem cert_e302801604406 : check e302801604406 [[],[]] .smaller = true := by decide
def e302801604410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801604410 : Closed e302801604410 ∧ code e302801604410 = 1402313232186 := by decide
theorem cert_e302801604410 : check e302801604410 [[],[]] .smaller = true := by decide
def e302801604506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302801604506 : Closed e302801604506 ∧ code e302801604506 = 1402313232282 := by decide
theorem cert_e302801604506 : check e302801604506 [[],[]] .chain = true := by decide
def e302801610166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e302801610166 : Closed e302801610166 ∧ code e302801610166 = 1402313237942 := by decide
theorem cert_e302801610166 : check e302801610166 [[],[]] .smaller = true := by decide
def e302801610198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e302801610198 : Closed e302801610198 ∧ code e302801610198 = 1402313237974 := by decide
theorem cert_e302801610198 : check e302801610198 [[],[]] .smaller = true := by decide
def e302801610202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e302801610202 : Closed e302801610202 ∧ code e302801610202 = 1402313237978 := by decide
theorem cert_e302801610202 : check e302801610202 [[],[]] .smaller = true := by decide
def e302801610358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e302801610358 : Closed e302801610358 ∧ code e302801610358 = 1402313238134 := by decide
theorem cert_e302801610358 : check e302801610358 [[],[]] .smaller = true := by decide
def e302801610550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801610550 : Closed e302801610550 ∧ code e302801610550 = 1402313238326 := by decide
theorem cert_e302801610550 : check e302801610550 [[],[]] .smaller = true := by decide
def e302801610554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801610554 : Closed e302801610554 ∧ code e302801610554 = 1402313238330 := by decide
theorem cert_e302801610554 : check e302801610554 [[],[]] .smaller = true := by decide
def e302801610718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 3)))))))))
theorem wire_e302801610718 : Closed e302801610718 ∧ code e302801610718 = 1402313238494 := by decide
theorem cert_e302801610718 : checkPay e302801610718 [[.left,.left],[.left,.left],[.left],[],[],[.left]] 1 [] = true := by decide
def e302801613038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e302801613038 : Closed e302801613038 ∧ code e302801613038 = 1402313240814 := by decide
theorem cert_e302801613038 : check e302801613038 [[],[]] .chain = true := by decide
def e302801613046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e302801613046 : Closed e302801613046 ∧ code e302801613046 = 1402313240822 := by decide
theorem cert_e302801613046 : check e302801613046 [[],[]] .chain = true := by decide
def e302801613526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302801613526 : Closed e302801613526 ∧ code e302801613526 = 1402313241302 := by decide
theorem cert_e302801613526 : check e302801613526 [[],[]] .chain = true := by decide
def e302801613530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302801613530 : Closed e302801613530 ∧ code e302801613530 = 1402313241306 := by decide
theorem cert_e302801613530 : check e302801613530 [[],[]] .chain = true := by decide
def e302801613546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302801613546 : Closed e302801613546 ∧ code e302801613546 = 1402313241322 := by decide
theorem cert_e302801613546 : check e302801613546 [[],[]] .chain = true := by decide
def e302801613622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801613622 : Closed e302801613622 ∧ code e302801613622 = 1402313241398 := by decide
theorem cert_e302801613622 : check e302801613622 [[],[]] .chain = true := by decide
def e302801613626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801613626 : Closed e302801613626 ∧ code e302801613626 = 1402313241402 := by decide
theorem cert_e302801613626 : check e302801613626 [[],[]] .chain = true := by decide
def e302801613722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302801613722 : Closed e302801613722 ∧ code e302801613722 = 1402313241498 := by decide
theorem cert_e302801613722 : check e302801613722 [[],[]] .chain = true := by decide
def e302801613790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 3)))))))))
theorem wire_e302801613790 : Closed e302801613790 ∧ code e302801613790 = 1402313241566 := by decide
theorem cert_e302801613790 : check e302801613790 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e302801613806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 3) (.var 2)))))))))
theorem wire_e302801613806 : Closed e302801613806 ∧ code e302801613806 = 1402313241582 := by decide
theorem cert_e302801613806 : check e302801613806 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e302801838958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e302801838958 : Closed e302801838958 ∧ code e302801838958 = 1402313466734 := by decide
theorem cert_e302801838958 : check e302801838958 [[],[]] .chain = true := by decide
def e302801838966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e302801838966 : Closed e302801838966 ∧ code e302801838966 = 1402313466742 := by decide
theorem cert_e302801838966 : check e302801838966 [[],[]] .chain = true := by decide
def e302801839022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e302801839022 : Closed e302801839022 ∧ code e302801839022 = 1402313466798 := by decide
theorem cert_e302801839022 : check e302801839022 [[],[]] .chain = true := by decide
def e302801839034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e302801839034 : Closed e302801839034 ∧ code e302801839034 = 1402313466810 := by decide
theorem cert_e302801839034 : check e302801839034 [[],[]] .chain = true := by decide
def e302801839062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e302801839062 : Closed e302801839062 ∧ code e302801839062 = 1402313466838 := by decide
theorem cert_e302801839062 : check e302801839062 [[],[]] .chain = true := by decide
def e302801839066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e302801839066 : Closed e302801839066 ∧ code e302801839066 = 1402313466842 := by decide
theorem cert_e302801839066 : check e302801839066 [[],[]] .chain = true := by decide
def e302801840366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302801840366 : Closed e302801840366 ∧ code e302801840366 = 1402313468142 := by decide
theorem cert_e302801840366 : check e302801840366 [[],[]] .chain = true := by decide
def e302801840374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302801840374 : Closed e302801840374 ∧ code e302801840374 = 1402313468150 := by decide
theorem cert_e302801840374 : check e302801840374 [[],[]] .chain = true := by decide
end Blc.Floor40
