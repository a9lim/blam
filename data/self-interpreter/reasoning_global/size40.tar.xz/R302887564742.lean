import CodeBridge
import R302887564742Blk0
import R302887564742Blk6
namespace Certgen.R302887564742
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit14 : Term := .var 0
def lit17 : Term := .var 1
def lit15 : Term := .var 2
def lit16 : Term := .lam lit17
def lit2 : Term := .app lit14 lit14
def lit12 : Term := .app lit17 lit14
def lit1 : Term := .lam lit2
def lit11 : Term := .app lit12 lit15
def lit10 : Term := .lam lit11
def lit9 : Term := .lam lit10
def lit7 : Term := .app lit14 lit9
def lit6 : Term := .app lit7 lit16
def lit5 : Term := .lam lit6
def lit0 : Term := .app lit1 lit5
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub17 : model.term 17 = lit17 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit16 := by rw [model.lam_eq 16 17 (by rfl), sub17]; rfl
theorem sub15 : model.term 15 = lit15 := model.var_eq 15 2 (by rfl)
theorem sub14 : model.term 14 = lit14 := model.var_eq 14 0 (by rfl)
theorem sub13 : model.term 13 = lit17 := model.var_eq 13 1 (by rfl)
theorem sub12 : model.term 12 = lit12 := by rw [model.app_eq 12 13 14 (by rfl), sub13, sub14]; rfl
theorem sub11 : model.term 11 = lit11 := by rw [model.app_eq 11 12 15 (by rfl), sub12, sub15]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit14 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit7 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit6 := by rw [model.app_eq 6 7 16 (by rfl), sub7, sub16]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.lam_eq 5 6 (by rfl), sub6]; rfl
theorem sub4 : model.term 4 = lit14 := model.var_eq 4 0 (by rfl)
theorem sub3 : model.term 3 = lit14 := model.var_eq 3 0 (by rfl)
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 4 (by rfl), sub3, sub4]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 5 (by rfl), sub1, sub5]; rfl
theorem allValid (i : Nat) (h : i < 107) : validState i = true := by
 by_cases h48 : i < 48
 · by_cases h24 : i < 24
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
   · by_cases h36 : i < 36
     · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
 · by_cases h72 : i < 72
   · by_cases h60 : i < 60
     · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
   · by_cases h84 : i < 84
     · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
     · by_cases h96 : i < 96
       · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 107
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302887564742 := by
 intro he
 have hp : replay [] e302887564742 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302887564742
