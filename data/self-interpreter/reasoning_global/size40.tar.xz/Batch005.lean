import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e76454563438 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e76454563438 : Closed e76454563438 ∧ code e76454563438 = 1175966191214 := by decide
theorem cert_e76454563438 : check e76454563438 [[.under]] .sourceHead = true := by decide
def e76454563450 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e76454563450 : Closed e76454563450 ∧ code e76454563450 = 1175966191226 := by decide
theorem cert_e76454563450 : check e76454563450 [[.under]] .sourceHead = true := by decide
def e76454563638 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e76454563638 : Closed e76454563638 ∧ code e76454563638 = 1175966191414 := by decide
theorem cert_e76454563638 : check e76454563638 [[.under]] .sourceHead = true := by decide
def e76454563642 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e76454563642 : Closed e76454563642 ∧ code e76454563642 = 1175966191418 := by decide
theorem cert_e76454563642 : check e76454563642 [[.under]] .sourceHead = true := by decide
def e87644532154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e87644532154 : Closed e87644532154 ∧ code e87644532154 = 1187156159930 := by decide
theorem cert_e87644532154 : check e87644532154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644532186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e87644532186 : Closed e87644532186 ∧ code e87644532186 = 1187156159962 := by decide
theorem cert_e87644532186 : check e87644532186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644532442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.var 0)))
theorem wire_e87644532442 : Closed e87644532442 ∧ code e87644532442 = 1187156160218 := by decide
theorem cert_e87644532442 : check e87644532442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644534202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e87644534202 : Closed e87644534202 ∧ code e87644534202 = 1187156161978 := by decide
theorem cert_e87644534202 : check e87644534202 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644534234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e87644534234 : Closed e87644534234 ∧ code e87644534234 = 1187156162010 := by decide
theorem cert_e87644534234 : check e87644534234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644534458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e87644534458 : Closed e87644534458 ∧ code e87644534458 = 1187156162234 := by decide
theorem cert_e87644534458 : check e87644534458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644534506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e87644534506 : Closed e87644534506 ∧ code e87644534506 = 1187156162282 := by decide
theorem cert_e87644534506 : check e87644534506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644534618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e87644534618 : Closed e87644534618 ∧ code e87644534618 = 1187156162394 := by decide
theorem cert_e87644534618 : check e87644534618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644534634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e87644534634 : Closed e87644534634 ∧ code e87644534634 = 1187156162410 := by decide
theorem cert_e87644534634 : check e87644534634 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644535514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.var 0)))
theorem wire_e87644535514 : Closed e87644535514 ∧ code e87644535514 = 1187156163290 := by decide
theorem cert_e87644535514 : check e87644535514 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644535642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e87644535642 : Closed e87644535642 ∧ code e87644535642 = 1187156163418 := by decide
theorem cert_e87644535642 : check e87644535642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644535658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e87644535658 : Closed e87644535658 ∧ code e87644535658 = 1187156163434 := by decide
theorem cert_e87644535658 : check e87644535658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644544442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e87644544442 : Closed e87644544442 ∧ code e87644544442 = 1187156172218 := by decide
theorem cert_e87644544442 : check e87644544442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644544474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e87644544474 : Closed e87644544474 ∧ code e87644544474 = 1187156172250 := by decide
theorem cert_e87644544474 : check e87644544474 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644544730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e87644544730 : Closed e87644544730 ∧ code e87644544730 = 1187156172506 := by decide
theorem cert_e87644544730 : check e87644544730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644550074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e87644550074 : Closed e87644550074 ∧ code e87644550074 = 1187156177850 := by decide
theorem cert_e87644550074 : check e87644550074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644550106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e87644550106 : Closed e87644550106 ∧ code e87644550106 = 1187156177882 := by decide
theorem cert_e87644550106 : check e87644550106 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644551642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.var 0)))
theorem wire_e87644551642 : Closed e87644551642 ∧ code e87644551642 = 1187156179418 := by decide
theorem cert_e87644551642 : check e87644551642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644556730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e87644556730 : Closed e87644556730 ∧ code e87644556730 = 1187156184506 := by decide
theorem cert_e87644556730 : check e87644556730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644556762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e87644556762 : Closed e87644556762 ∧ code e87644556762 = 1187156184538 := by decide
theorem cert_e87644556762 : check e87644556762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644556986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e87644556986 : Closed e87644556986 ∧ code e87644556986 = 1187156184762 := by decide
theorem cert_e87644556986 : check e87644556986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644557034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e87644557034 : Closed e87644557034 ∧ code e87644557034 = 1187156184810 := by decide
theorem cert_e87644557034 : check e87644557034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644557146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e87644557146 : Closed e87644557146 ∧ code e87644557146 = 1187156184922 := by decide
theorem cert_e87644557146 : check e87644557146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644557162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e87644557162 : Closed e87644557162 ∧ code e87644557162 = 1187156184938 := by decide
theorem cert_e87644557162 : check e87644557162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644558266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e87644558266 : Closed e87644558266 ∧ code e87644558266 = 1187156186042 := by decide
theorem cert_e87644558266 : check e87644558266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644558298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e87644558298 : Closed e87644558298 ∧ code e87644558298 = 1187156186074 := by decide
theorem cert_e87644558298 : check e87644558298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644559802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e87644559802 : Closed e87644559802 ∧ code e87644559802 = 1187156187578 := by decide
theorem cert_e87644559802 : check e87644559802 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644559850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e87644559850 : Closed e87644559850 ∧ code e87644559850 = 1187156187626 := by decide
theorem cert_e87644559850 : check e87644559850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644560602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e87644560602 : Closed e87644560602 ∧ code e87644560602 = 1187156188378 := by decide
theorem cert_e87644560602 : check e87644560602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644560618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e87644560618 : Closed e87644560618 ∧ code e87644560618 = 1187156188394 := by decide
theorem cert_e87644560618 : check e87644560618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644563162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e87644563162 : Closed e87644563162 ∧ code e87644563162 = 1187156190938 := by decide
theorem cert_e87644563162 : check e87644563162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644563290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e87644563290 : Closed e87644563290 ∧ code e87644563290 = 1187156191066 := by decide
theorem cert_e87644563290 : check e87644563290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644563306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e87644563306 : Closed e87644563306 ∧ code e87644563306 = 1187156191082 := by decide
theorem cert_e87644563306 : check e87644563306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644563930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.var 0)))
theorem wire_e87644563930 : Closed e87644563930 ∧ code e87644563930 = 1187156191706 := by decide
theorem cert_e87644563930 : check e87644563930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644564698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e87644564698 : Closed e87644564698 ∧ code e87644564698 = 1187156192474 := by decide
theorem cert_e87644564698 : check e87644564698 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644564714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e87644564714 : Closed e87644564714 ∧ code e87644564714 = 1187156192490 := by decide
theorem cert_e87644564714 : check e87644564714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644593594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e87644593594 : Closed e87644593594 ∧ code e87644593594 = 1187156221370 := by decide
theorem cert_e87644593594 : check e87644593594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644593626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e87644593626 : Closed e87644593626 ∧ code e87644593626 = 1187156221402 := by decide
theorem cert_e87644593626 : check e87644593626 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644593882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e87644593882 : Closed e87644593882 ∧ code e87644593882 = 1187156221658 := by decide
theorem cert_e87644593882 : check e87644593882 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644599226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e87644599226 : Closed e87644599226 ∧ code e87644599226 = 1187156227002 := by decide
theorem cert_e87644599226 : check e87644599226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644599258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e87644599258 : Closed e87644599258 ∧ code e87644599258 = 1187156227034 := by decide
theorem cert_e87644599258 : check e87644599258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644600794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e87644600794 : Closed e87644600794 ∧ code e87644600794 = 1187156228570 := by decide
theorem cert_e87644600794 : check e87644600794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644646842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e87644646842 : Closed e87644646842 ∧ code e87644646842 = 1187156274618 := by decide
theorem cert_e87644646842 : check e87644646842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644646874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e87644646874 : Closed e87644646874 ∧ code e87644646874 = 1187156274650 := by decide
theorem cert_e87644646874 : check e87644646874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644647098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e87644647098 : Closed e87644647098 ∧ code e87644647098 = 1187156274874 := by decide
theorem cert_e87644647098 : check e87644647098 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644647146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e87644647146 : Closed e87644647146 ∧ code e87644647146 = 1187156274922 := by decide
theorem cert_e87644647146 : check e87644647146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644647258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e87644647258 : Closed e87644647258 ∧ code e87644647258 = 1187156275034 := by decide
theorem cert_e87644647258 : check e87644647258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644647274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e87644647274 : Closed e87644647274 ∧ code e87644647274 = 1187156275050 := by decide
theorem cert_e87644647274 : check e87644647274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644648378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e87644648378 : Closed e87644648378 ∧ code e87644648378 = 1187156276154 := by decide
theorem cert_e87644648378 : check e87644648378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644648410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e87644648410 : Closed e87644648410 ∧ code e87644648410 = 1187156276186 := by decide
theorem cert_e87644648410 : check e87644648410 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644649914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e87644649914 : Closed e87644649914 ∧ code e87644649914 = 1187156277690 := by decide
theorem cert_e87644649914 : check e87644649914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644649962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e87644649962 : Closed e87644649962 ∧ code e87644649962 = 1187156277738 := by decide
theorem cert_e87644649962 : check e87644649962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644650714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e87644650714 : Closed e87644650714 ∧ code e87644650714 = 1187156278490 := by decide
theorem cert_e87644650714 : check e87644650714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644650730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e87644650730 : Closed e87644650730 ∧ code e87644650730 = 1187156278506 := by decide
theorem cert_e87644650730 : check e87644650730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644673754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e87644673754 : Closed e87644673754 ∧ code e87644673754 = 1187156301530 := by decide
theorem cert_e87644673754 : check e87644673754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644673882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e87644673882 : Closed e87644673882 ∧ code e87644673882 = 1187156301658 := by decide
theorem cert_e87644673882 : check e87644673882 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644673898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e87644673898 : Closed e87644673898 ∧ code e87644673898 = 1187156301674 := by decide
theorem cert_e87644673898 : check e87644673898 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644674522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e87644674522 : Closed e87644674522 ∧ code e87644674522 = 1187156302298 := by decide
theorem cert_e87644674522 : check e87644674522 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644675290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e87644675290 : Closed e87644675290 ∧ code e87644675290 = 1187156303066 := by decide
theorem cert_e87644675290 : check e87644675290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87644675306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e87644675306 : Closed e87644675306 ∧ code e87644675306 = 1187156303082 := by decide
theorem cert_e87644675306 : check e87644675306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e87646023098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e87646023098 : Closed e87646023098 ∧ code e87646023098 = 1187157650874 := by decide
theorem cert_e87646023098 : check e87646023098 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e87646023130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e87646023130 : Closed e87646023130 ∧ code e87646023130 = 1187157650906 := by decide
private def t_e87646023130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem cert_e87646023130 : ¬ IsSelfInterpreter e87646023130 :=
  wSource (t := t_e87646023130) (replay_sound (ps := []) (t := e87646023130) (by decide)) (by decide)
def e87646023354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e87646023354 : Closed e87646023354 ∧ code e87646023354 = 1187157651130 := by decide
theorem cert_e87646023354 : checkPay e87646023354 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e87646023402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e87646023402 : Closed e87646023402 ∧ code e87646023402 = 1187157651178 := by decide
theorem cert_e87646023402 : checkPay e87646023402 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e87646023514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e87646023514 : Closed e87646023514 ∧ code e87646023514 = 1187157651290 := by decide
private def t_e87646023514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem cert_e87646023514 : ¬ IsSelfInterpreter e87646023514 :=
  wSource (t := t_e87646023514) (replay_sound (ps := []) (t := e87646023514) (by decide)) (by decide)
def e87646023530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e87646023530 : Closed e87646023530 ∧ code e87646023530 = 1187157651306 := by decide
theorem cert_e87646023530 : check e87646023530 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e87646024634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e87646024634 : Closed e87646024634 ∧ code e87646024634 = 1187157652410 := by decide
theorem cert_e87646024634 : checkPay e87646024634 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e87646024666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e87646024666 : Closed e87646024666 ∧ code e87646024666 = 1187157652442 := by decide
theorem cert_e87646024666 : check e87646024666 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e87646026170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e87646026170 : Closed e87646026170 ∧ code e87646026170 = 1187157653946 := by decide
theorem cert_e87646026170 : check e87646026170 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e87646026218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e87646026218 : Closed e87646026218 ∧ code e87646026218 = 1187157653994 := by decide
theorem cert_e87646026218 : check e87646026218 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e87646026970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e87646026970 : Closed e87646026970 ∧ code e87646026970 = 1187157654746 := by decide
theorem cert_e87646026970 : check e87646026970 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e87646026986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e87646026986 : Closed e87646026986 ∧ code e87646026986 = 1187157654762 := by decide
theorem cert_e87646026986 : check e87646026986 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e94512049690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512049690 : Closed e94512049690 ∧ code e94512049690 = 1194023677466 := by decide
theorem cert_e94512049690 : check e94512049690 [] .sourceHead = true := by decide
def e94512051738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512051738 : Closed e94512051738 ∧ code e94512051738 = 1194023679514 := by decide
theorem cert_e94512051738 : check e94512051738 [] .sourceHead = true := by decide
def e94512068122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512068122 : Closed e94512068122 ∧ code e94512068122 = 1194023695898 := by decide
theorem cert_e94512068122 : check e94512068122 [] .sourceHead = true := by decide
def e94512180762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512180762 : Closed e94512180762 ∧ code e94512180762 = 1194023808538 := by decide
theorem cert_e94512180762 : check e94512180762 [] .sourceHead = true := by decide
def e94512182810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512182810 : Closed e94512182810 ∧ code e94512182810 = 1194023810586 := by decide
theorem cert_e94512182810 : check e94512182810 [] .sourceHead = true := by decide
def e94512197146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512197146 : Closed e94512197146 ∧ code e94512197146 = 1194023824922 := by decide
theorem cert_e94512197146 : check e94512197146 [] .sourceHead = true := by decide
def e94512200218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512200218 : Closed e94512200218 ∧ code e94512200218 = 1194023827994 := by decide
theorem cert_e94512200218 : check e94512200218 [] .sourceHead = true := by decide
def e94512207386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512207386 : Closed e94512207386 ∧ code e94512207386 = 1194023835162 := by decide
theorem cert_e94512207386 : check e94512207386 [] .sourceHead = true := by decide
def e94512208410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512208410 : Closed e94512208410 ∧ code e94512208410 = 1194023836186 := by decide
theorem cert_e94512208410 : check e94512208410 [] .sourceHead = true := by decide
def e94512264730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512264730 : Closed e94512264730 ∧ code e94512264730 = 1194023892506 := by decide
theorem cert_e94512264730 : check e94512264730 [] .sourceHead = true := by decide
def e94512272922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512272922 : Closed e94512272922 ∧ code e94512272922 = 1194023900698 := by decide
theorem cert_e94512272922 : check e94512272922 [] .sourceHead = true := by decide
def e94512273946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512273946 : Closed e94512273946 ∧ code e94512273946 = 1194023901722 := by decide
theorem cert_e94512273946 : check e94512273946 [] .sourceHead = true := by decide
def e94512836122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512836122 : Closed e94512836122 ∧ code e94512836122 = 1194024463898 := by decide
theorem cert_e94512836122 : check e94512836122 [] .sourceHead = true := by decide
def e94512838170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512838170 : Closed e94512838170 ∧ code e94512838170 = 1194024465946 := by decide
theorem cert_e94512838170 : check e94512838170 [] .sourceHead = true := by decide
def e94512854554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94512854554 : Closed e94512854554 ∧ code e94512854554 = 1194024482330 := by decide
theorem cert_e94512854554 : check e94512854554 [] .sourceHead = true := by decide
def e94513196570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513196570 : Closed e94513196570 ∧ code e94513196570 = 1194024824346 := by decide
theorem cert_e94513196570 : check e94513196570 [] .sourceHead = true := by decide
def e94513198618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513198618 : Closed e94513198618 ∧ code e94513198618 = 1194024826394 := by decide
theorem cert_e94513198618 : check e94513198618 [] .sourceHead = true := by decide
def e94513296922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513296922 : Closed e94513296922 ∧ code e94513296922 = 1194024924698 := by decide
theorem cert_e94513296922 : check e94513296922 [] .sourceHead = true := by decide
def e94513622554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513622554 : Closed e94513622554 ∧ code e94513622554 = 1194025250330 := by decide
theorem cert_e94513622554 : check e94513622554 [] .sourceHead = true := by decide
def e94513624602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513624602 : Closed e94513624602 ∧ code e94513624602 = 1194025252378 := by decide
theorem cert_e94513624602 : check e94513624602 [] .sourceHead = true := by decide
def e94513638938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513638938 : Closed e94513638938 ∧ code e94513638938 = 1194025266714 := by decide
theorem cert_e94513638938 : check e94513638938 [] .sourceHead = true := by decide
def e94513642010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513642010 : Closed e94513642010 ∧ code e94513642010 = 1194025269786 := by decide
theorem cert_e94513642010 : check e94513642010 [] .sourceHead = true := by decide
def e94513649178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513649178 : Closed e94513649178 ∧ code e94513649178 = 1194025276954 := by decide
theorem cert_e94513649178 : check e94513649178 [] .sourceHead = true := by decide
def e94513650202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513650202 : Closed e94513650202 ∧ code e94513650202 = 1194025277978 := by decide
theorem cert_e94513650202 : check e94513650202 [] .sourceHead = true := by decide
def e94513720858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513720858 : Closed e94513720858 ∧ code e94513720858 = 1194025348634 := by decide
theorem cert_e94513720858 : check e94513720858 [] .sourceHead = true := by decide
def e94513722906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513722906 : Closed e94513722906 ∧ code e94513722906 = 1194025350682 := by decide
theorem cert_e94513722906 : check e94513722906 [] .sourceHead = true := by decide
def e94513819162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513819162 : Closed e94513819162 ∧ code e94513819162 = 1194025446938 := by decide
theorem cert_e94513819162 : check e94513819162 [] .sourceHead = true := by decide
def e94513822234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513822234 : Closed e94513822234 ∧ code e94513822234 = 1194025450010 := by decide
theorem cert_e94513822234 : check e94513822234 [] .sourceHead = true := by decide
def e94513870362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513870362 : Closed e94513870362 ∧ code e94513870362 = 1194025498138 := by decide
theorem cert_e94513870362 : check e94513870362 [] .sourceHead = true := by decide
def e94513871386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94513871386 : Closed e94513871386 ∧ code e94513871386 = 1194025499162 := by decide
theorem cert_e94513871386 : check e94513871386 [] .sourceHead = true := by decide
def e94514034202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94514034202 : Closed e94514034202 ∧ code e94514034202 = 1194025661978 := by decide
theorem cert_e94514034202 : check e94514034202 [] .sourceHead = true := by decide
def e94514042394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94514042394 : Closed e94514042394 ∧ code e94514042394 = 1194025670170 := by decide
theorem cert_e94514042394 : check e94514042394 [] .sourceHead = true := by decide
def e94514043418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94514043418 : Closed e94514043418 ∧ code e94514043418 = 1194025671194 := by decide
theorem cert_e94514043418 : check e94514043418 [] .sourceHead = true := by decide
def e94514083354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94514083354 : Closed e94514083354 ∧ code e94514083354 = 1194025711130 := by decide
theorem cert_e94514083354 : check e94514083354 [] .sourceHead = true := by decide
def e94514132506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94514132506 : Closed e94514132506 ∧ code e94514132506 = 1194025760282 := by decide
theorem cert_e94514132506 : check e94514132506 [] .sourceHead = true := by decide
def e94514133530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94514133530 : Closed e94514133530 ∧ code e94514133530 = 1194025761306 := by decide
theorem cert_e94514133530 : check e94514133530 [] .sourceHead = true := by decide
def e94515981850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94515981850 : Closed e94515981850 ∧ code e94515981850 = 1194027609626 := by decide
theorem cert_e94515981850 : check e94515981850 [] .sourceHead = true := by decide
def e94515983898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94515983898 : Closed e94515983898 ∧ code e94515983898 = 1194027611674 := by decide
theorem cert_e94515983898 : check e94515983898 [] .sourceHead = true := by decide
def e94516000282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94516000282 : Closed e94516000282 ∧ code e94516000282 = 1194027628058 := by decide
theorem cert_e94516000282 : check e94516000282 [] .sourceHead = true := by decide
def e94516342298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94516342298 : Closed e94516342298 ∧ code e94516342298 = 1194027970074 := by decide
theorem cert_e94516342298 : check e94516342298 [] .sourceHead = true := by decide
def e94516344346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94516344346 : Closed e94516344346 ∧ code e94516344346 = 1194027972122 := by decide
theorem cert_e94516344346 : check e94516344346 [] .sourceHead = true := by decide
def e94516442650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94516442650 : Closed e94516442650 ∧ code e94516442650 = 1194028070426 := by decide
theorem cert_e94516442650 : check e94516442650 [] .sourceHead = true := by decide
def e94519389722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519389722 : Closed e94519389722 ∧ code e94519389722 = 1194031017498 := by decide
theorem cert_e94519389722 : check e94519389722 [] .sourceHead = true := by decide
def e94519391770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519391770 : Closed e94519391770 ∧ code e94519391770 = 1194031019546 := by decide
theorem cert_e94519391770 : check e94519391770 [] .sourceHead = true := by decide
def e94519406106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519406106 : Closed e94519406106 ∧ code e94519406106 = 1194031033882 := by decide
theorem cert_e94519406106 : check e94519406106 [] .sourceHead = true := by decide
def e94519409178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519409178 : Closed e94519409178 ∧ code e94519409178 = 1194031036954 := by decide
theorem cert_e94519409178 : check e94519409178 [] .sourceHead = true := by decide
def e94519416346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519416346 : Closed e94519416346 ∧ code e94519416346 = 1194031044122 := by decide
theorem cert_e94519416346 : check e94519416346 [] .sourceHead = true := by decide
def e94519417370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519417370 : Closed e94519417370 ∧ code e94519417370 = 1194031045146 := by decide
theorem cert_e94519417370 : check e94519417370 [] .sourceHead = true := by decide
def e94519488026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519488026 : Closed e94519488026 ∧ code e94519488026 = 1194031115802 := by decide
theorem cert_e94519488026 : check e94519488026 [] .sourceHead = true := by decide
def e94519490074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519490074 : Closed e94519490074 ∧ code e94519490074 = 1194031117850 := by decide
theorem cert_e94519490074 : check e94519490074 [] .sourceHead = true := by decide
def e94519586330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519586330 : Closed e94519586330 ∧ code e94519586330 = 1194031214106 := by decide
theorem cert_e94519586330 : check e94519586330 [] .sourceHead = true := by decide
def e94519589402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519589402 : Closed e94519589402 ∧ code e94519589402 = 1194031217178 := by decide
theorem cert_e94519589402 : check e94519589402 [] .sourceHead = true := by decide
def e94519637530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519637530 : Closed e94519637530 ∧ code e94519637530 = 1194031265306 := by decide
theorem cert_e94519637530 : check e94519637530 [] .sourceHead = true := by decide
def e94519638554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94519638554 : Closed e94519638554 ∧ code e94519638554 = 1194031266330 := by decide
theorem cert_e94519638554 : check e94519638554 [] .sourceHead = true := by decide
def e94521112090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94521112090 : Closed e94521112090 ∧ code e94521112090 = 1194032739866 := by decide
theorem cert_e94521112090 : check e94521112090 [] .sourceHead = true := by decide
def e94521120282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94521120282 : Closed e94521120282 ∧ code e94521120282 = 1194032748058 := by decide
theorem cert_e94521120282 : check e94521120282 [] .sourceHead = true := by decide
def e94521121306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94521121306 : Closed e94521121306 ∧ code e94521121306 = 1194032749082 := by decide
theorem cert_e94521121306 : check e94521121306 [] .sourceHead = true := by decide
def e94521161242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94521161242 : Closed e94521161242 ∧ code e94521161242 = 1194032789018 := by decide
theorem cert_e94521161242 : check e94521161242 [] .sourceHead = true := by decide
def e94521210394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94521210394 : Closed e94521210394 ∧ code e94521210394 = 1194032838170 := by decide
theorem cert_e94521210394 : check e94521210394 [] .sourceHead = true := by decide
def e94521211418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94521211418 : Closed e94521211418 ∧ code e94521211418 = 1194032839194 := by decide
theorem cert_e94521211418 : check e94521211418 [] .sourceHead = true := by decide
def e94607470106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607470106 : Closed e94607470106 ∧ code e94607470106 = 1194119097882 := by decide
theorem cert_e94607470106 : check e94607470106 [] .sourceHead = true := by decide
def e94607472154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607472154 : Closed e94607472154 ∧ code e94607472154 = 1194119099930 := by decide
theorem cert_e94607472154 : check e94607472154 [] .sourceHead = true := by decide
def e94607486490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607486490 : Closed e94607486490 ∧ code e94607486490 = 1194119114266 := by decide
theorem cert_e94607486490 : check e94607486490 [] .sourceHead = true := by decide
def e94607489562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607489562 : Closed e94607489562 ∧ code e94607489562 = 1194119117338 := by decide
theorem cert_e94607489562 : check e94607489562 [] .sourceHead = true := by decide
def e94607496730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607496730 : Closed e94607496730 ∧ code e94607496730 = 1194119124506 := by decide
theorem cert_e94607496730 : check e94607496730 [] .sourceHead = true := by decide
def e94607497754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607497754 : Closed e94607497754 ∧ code e94607497754 = 1194119125530 := by decide
theorem cert_e94607497754 : check e94607497754 [] .sourceHead = true := by decide
def e94607568410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607568410 : Closed e94607568410 ∧ code e94607568410 = 1194119196186 := by decide
theorem cert_e94607568410 : check e94607568410 [] .sourceHead = true := by decide
def e94607570458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607570458 : Closed e94607570458 ∧ code e94607570458 = 1194119198234 := by decide
theorem cert_e94607570458 : check e94607570458 [] .sourceHead = true := by decide
def e94607666714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607666714 : Closed e94607666714 ∧ code e94607666714 = 1194119294490 := by decide
theorem cert_e94607666714 : check e94607666714 [] .sourceHead = true := by decide
def e94607669786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607669786 : Closed e94607669786 ∧ code e94607669786 = 1194119297562 := by decide
theorem cert_e94607669786 : check e94607669786 [] .sourceHead = true := by decide
def e94607717914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607717914 : Closed e94607717914 ∧ code e94607717914 = 1194119345690 := by decide
theorem cert_e94607717914 : check e94607717914 [] .sourceHead = true := by decide
def e94607718938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e94607718938 : Closed e94607718938 ∧ code e94607718938 = 1194119346714 := by decide
theorem cert_e94607718938 : check e94607718938 [] .sourceHead = true := by decide
def e94925577070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e94925577070 : Closed e94925577070 ∧ code e94925577070 = 1194437204846 := by decide
theorem cert_e94925577070 : check e94925577070 [] .sourceHead = true := by decide
def e94925577078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e94925577078 : Closed e94925577078 ∧ code e94925577078 = 1194437204854 := by decide
theorem cert_e94925577078 : check e94925577078 [] .sourceHead = true := by decide
def e94925577142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e94925577142 : Closed e94925577142 ∧ code e94925577142 = 1194437204918 := by decide
theorem cert_e94925577142 : check e94925577142 [] .sourceHead = true := by decide
def e94925577582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e94925577582 : Closed e94925577582 ∧ code e94925577582 = 1194437205358 := by decide
theorem cert_e94925577582 : check e94925577582 [] .sourceHead = true := by decide
def e94925577590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e94925577590 : Closed e94925577590 ∧ code e94925577590 = 1194437205366 := by decide
theorem cert_e94925577590 : check e94925577590 [] .sourceHead = true := by decide
def e94925577646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e94925577646 : Closed e94925577646 ∧ code e94925577646 = 1194437205422 := by decide
theorem cert_e94925577646 : check e94925577646 [] .sourceHead = true := by decide
def e94925577658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e94925577658 : Closed e94925577658 ∧ code e94925577658 = 1194437205434 := by decide
theorem cert_e94925577658 : check e94925577658 [] .sourceHead = true := by decide
def e94925577686 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e94925577686 : Closed e94925577686 ∧ code e94925577686 = 1194437205462 := by decide
theorem cert_e94925577686 : check e94925577686 [] .sourceHead = true := by decide
def e94925577690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e94925577690 : Closed e94925577690 ∧ code e94925577690 = 1194437205466 := by decide
theorem cert_e94925577690 : check e94925577690 [] .sourceHead = true := by decide
def e94925577910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e94925577910 : Closed e94925577910 ∧ code e94925577910 = 1194437205686 := by decide
theorem cert_e94925577910 : check e94925577910 [] .sourceHead = true := by decide
def e94925577942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e94925577942 : Closed e94925577942 ∧ code e94925577942 = 1194437205718 := by decide
theorem cert_e94925577942 : check e94925577942 [] .sourceHead = true := by decide
def e94925577946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e94925577946 : Closed e94925577946 ∧ code e94925577946 = 1194437205722 := by decide
theorem cert_e94925577946 : check e94925577946 [] .sourceHead = true := by decide
end Blc.Floor40
