import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302895975286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302895975286 : Closed e302895975286 ∧ code e302895975286 = 1402407603062 := by decide
theorem cert_e302895975286 : check e302895975286 [[],[],[],[]] .chain = true := by decide
def e302895975290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302895975290 : Closed e302895975290 ∧ code e302895975290 = 1402407603066 := by decide
theorem cert_e302895975290 : check e302895975290 [[],[],[],[]] .chain = true := by decide
def e302895975342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302895975342 : Closed e302895975342 ∧ code e302895975342 = 1402407603118 := by decide
theorem cert_e302895975342 : check e302895975342 [[],[],[],[]] .chain = true := by decide
def e302895975354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302895975354 : Closed e302895975354 ∧ code e302895975354 = 1402407603130 := by decide
theorem cert_e302895975354 : check e302895975354 [[],[],[],[]] .chain = true := by decide
def e302895975382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302895975382 : Closed e302895975382 ∧ code e302895975382 = 1402407603158 := by decide
theorem cert_e302895975382 : check e302895975382 [[],[],[],[]] .chain = true := by decide
def e302895975386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302895975386 : Closed e302895975386 ∧ code e302895975386 = 1402407603162 := by decide
theorem cert_e302895975386 : check e302895975386 [[],[],[],[]] .chain = true := by decide
def e302895975402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302895975402 : Closed e302895975402 ∧ code e302895975402 = 1402407603178 := by decide
theorem cert_e302895975402 : check e302895975402 [[],[],[],[]] .chain = true := by decide
def e302895975646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302895975646 : Closed e302895975646 ∧ code e302895975646 = 1402407603422 := by decide
theorem cert_e302895975646 : check e302895975646 [[],[],[],[]] .chain = true := by decide
def e302895975662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302895975662 : Closed e302895975662 ∧ code e302895975662 = 1402407603438 := by decide
theorem cert_e302895975662 : check e302895975662 [[],[],[],[]] .chain = true := by decide
def e302895975670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302895975670 : Closed e302895975670 ∧ code e302895975670 = 1402407603446 := by decide
theorem cert_e302895975670 : check e302895975670 [[],[],[],[]] .chain = true := by decide
def e302895975674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302895975674 : Closed e302895975674 ∧ code e302895975674 = 1402407603450 := by decide
theorem cert_e302895975674 : check e302895975674 [[],[],[],[]] .chain = true := by decide
def e302895976046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302895976046 : Closed e302895976046 ∧ code e302895976046 = 1402407603822 := by decide
theorem cert_e302895976046 : check e302895976046 [[],[],[],[]] .chain = true := by decide
def e302895976058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302895976058 : Closed e302895976058 ∧ code e302895976058 = 1402407603834 := by decide
theorem cert_e302895976058 : check e302895976058 [[],[],[],[]] .chain = true := by decide
def e302895976246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302895976246 : Closed e302895976246 ∧ code e302895976246 = 1402407604022 := by decide
theorem cert_e302895976246 : check e302895976246 [[],[],[],[]] .chain = true := by decide
def e302895976250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302895976250 : Closed e302895976250 ∧ code e302895976250 = 1402407604026 := by decide
theorem cert_e302895976250 : check e302895976250 [[],[],[],[]] .chain = true := by decide
def e302895976346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302895976346 : Closed e302895976346 ∧ code e302895976346 = 1402407604122 := by decide
theorem cert_e302895976346 : check e302895976346 [[],[],[],[]] .chain = true := by decide
def e302895982006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e302895982006 : Closed e302895982006 ∧ code e302895982006 = 1402407609782 := by decide
theorem cert_e302895982006 : check e302895982006 [[],[],[],[]] .chain = true := by decide
def e302895982038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e302895982038 : Closed e302895982038 ∧ code e302895982038 = 1402407609814 := by decide
theorem cert_e302895982038 : check e302895982038 [[],[],[],[]] .chain = true := by decide
def e302895982042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e302895982042 : Closed e302895982042 ∧ code e302895982042 = 1402407609818 := by decide
theorem cert_e302895982042 : check e302895982042 [[],[],[],[]] .chain = true := by decide
def e302895982142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e302895982142 : Closed e302895982142 ∧ code e302895982142 = 1402407609918 := by decide
theorem cert_e302895982142 : check e302895982142 [[],[],[],[],[.under,.under]] .three = true := by decide
def e302895982198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e302895982198 : Closed e302895982198 ∧ code e302895982198 = 1402407609974 := by decide
theorem cert_e302895982198 : check e302895982198 [[],[],[],[]] .chain = true := by decide
def e302895982390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e302895982390 : Closed e302895982390 ∧ code e302895982390 = 1402407610166 := by decide
theorem cert_e302895982390 : check e302895982390 [[],[],[],[]] .chain = true := by decide
def e302895982394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e302895982394 : Closed e302895982394 ∧ code e302895982394 = 1402407610170 := by decide
theorem cert_e302895982394 : check e302895982394 [[],[],[],[]] .chain = true := by decide
def e302895982534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e302895982534 : Closed e302895982534 ∧ code e302895982534 = 1402407610310 := by decide
theorem cert_e302895982534 : check e302895982534 [[],[],[],[],[.under,.under]] .three = true := by decide
def e302895984878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e302895984878 : Closed e302895984878 ∧ code e302895984878 = 1402407612654 := by decide
theorem cert_e302895984878 : check e302895984878 [[],[],[],[]] .chain = true := by decide
def e302895984886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e302895984886 : Closed e302895984886 ∧ code e302895984886 = 1402407612662 := by decide
theorem cert_e302895984886 : check e302895984886 [[],[],[],[]] .chain = true := by decide
def e302895985366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302895985366 : Closed e302895985366 ∧ code e302895985366 = 1402407613142 := by decide
theorem cert_e302895985366 : check e302895985366 [[],[],[],[]] .chain = true := by decide
def e302895985370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302895985370 : Closed e302895985370 ∧ code e302895985370 = 1402407613146 := by decide
theorem cert_e302895985370 : check e302895985370 [[],[],[],[]] .chain = true := by decide
def e302895985386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302895985386 : Closed e302895985386 ∧ code e302895985386 = 1402407613162 := by decide
theorem cert_e302895985386 : check e302895985386 [[],[],[],[]] .chain = true := by decide
def e302895985438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302895985438 : Closed e302895985438 ∧ code e302895985438 = 1402407613214 := by decide
theorem cert_e302895985438 : check e302895985438 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.under],[.under,.under,.under]] .identityHead = true := by decide
def e302895985462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302895985462 : Closed e302895985462 ∧ code e302895985462 = 1402407613238 := by decide
theorem cert_e302895985462 : check e302895985462 [[],[],[],[]] .chain = true := by decide
def e302895985466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302895985466 : Closed e302895985466 ∧ code e302895985466 = 1402407613242 := by decide
theorem cert_e302895985466 : check e302895985466 [[],[],[],[]] .chain = true := by decide
def e302895985562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302895985562 : Closed e302895985562 ∧ code e302895985562 = 1402407613338 := by decide
theorem cert_e302895985562 : check e302895985562 [[],[],[],[]] .chain = true := by decide
def e302895985606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302895985606 : Closed e302895985606 ∧ code e302895985606 = 1402407613382 := by decide
theorem cert_e302895985606 : check e302895985606 [[],[],[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302896210798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e302896210798 : Closed e302896210798 ∧ code e302896210798 = 1402407838574 := by decide
theorem cert_e302896210798 : check e302896210798 [[],[],[],[]] .sourceHead = true := by decide
def e302896210806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e302896210806 : Closed e302896210806 ∧ code e302896210806 = 1402407838582 := by decide
theorem cert_e302896210806 : check e302896210806 [[],[],[],[]] .sourceHead = true := by decide
def e302896210862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e302896210862 : Closed e302896210862 ∧ code e302896210862 = 1402407838638 := by decide
theorem cert_e302896210862 : check e302896210862 [[],[],[],[]] .sourceHead = true := by decide
def e302896210874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e302896210874 : Closed e302896210874 ∧ code e302896210874 = 1402407838650 := by decide
theorem cert_e302896210874 : check e302896210874 [[],[],[],[]] .sourceHead = true := by decide
def e302896210902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e302896210902 : Closed e302896210902 ∧ code e302896210902 = 1402407838678 := by decide
theorem cert_e302896210902 : check e302896210902 [[],[],[],[]] .sourceHead = true := by decide
def e302896210906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e302896210906 : Closed e302896210906 ∧ code e302896210906 = 1402407838682 := by decide
theorem cert_e302896210906 : check e302896210906 [[],[],[],[]] .sourceHead = true := by decide
def e302896212206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302896212206 : Closed e302896212206 ∧ code e302896212206 = 1402407839982 := by decide
theorem cert_e302896212206 : check e302896212206 [[],[],[],[]] .sourceHead = true := by decide
def e302896212214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302896212214 : Closed e302896212214 ∧ code e302896212214 = 1402407839990 := by decide
theorem cert_e302896212214 : check e302896212214 [[],[],[],[]] .sourceHead = true := by decide
def e302896212766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302896212766 : Closed e302896212766 ∧ code e302896212766 = 1402407840542 := by decide
theorem cert_e302896212766 : check e302896212766 [[],[],[],[]] .sourceHead = true := by decide
def e302896212878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302896212878 : Closed e302896212878 ∧ code e302896212878 = 1402407840654 := by decide
theorem cert_e302896212878 : check e302896212878 [[],[],[],[]] .sourceHead = true := by decide
def e302896213102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302896213102 : Closed e302896213102 ∧ code e302896213102 = 1402407840878 := by decide
theorem cert_e302896213102 : check e302896213102 [[],[],[],[]] .sourceHead = true := by decide
def e302896213114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302896213114 : Closed e302896213114 ∧ code e302896213114 = 1402407840890 := by decide
theorem cert_e302896213114 : check e302896213114 [[],[],[],[]] .sourceHead = true := by decide
def e302896213278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302896213278 : Closed e302896213278 ∧ code e302896213278 = 1402407841054 := by decide
theorem cert_e302896213278 : check e302896213278 [[],[],[],[]] .sourceHead = true := by decide
def e302896213446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302896213446 : Closed e302896213446 ∧ code e302896213446 = 1402407841222 := by decide
theorem cert_e302896213446 : check e302896213446 [[],[],[],[]] .sourceHead = true := by decide
def e302896213558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302896213558 : Closed e302896213558 ∧ code e302896213558 = 1402407841334 := by decide
theorem cert_e302896213558 : check e302896213558 [[],[],[],[]] .sourceHead = true := by decide
def e302896213562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302896213562 : Closed e302896213562 ∧ code e302896213562 = 1402407841338 := by decide
theorem cert_e302896213562 : check e302896213562 [[],[],[],[]] .sourceHead = true := by decide
def e302896213646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302896213646 : Closed e302896213646 ∧ code e302896213646 = 1402407841422 := by decide
theorem cert_e302896213646 : check e302896213646 [[],[],[],[]] .sourceHead = true := by decide
def e302896213702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302896213702 : Closed e302896213702 ∧ code e302896213702 = 1402407841478 := by decide
theorem cert_e302896213702 : check e302896213702 [[],[],[],[]] .sourceHead = true := by decide
def e302896214446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302896214446 : Closed e302896214446 ∧ code e302896214446 = 1402407842222 := by decide
theorem cert_e302896214446 : check e302896214446 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e302896214458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302896214458 : Closed e302896214458 ∧ code e302896214458 = 1402407842234 := by decide
theorem cert_e302896214458 : check e302896214458 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e302896214506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302896214506 : Closed e302896214506 ∧ code e302896214506 = 1402407842282 := by decide
theorem cert_e302896214506 : check e302896214506 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e302896215150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302896215150 : Closed e302896215150 ∧ code e302896215150 = 1402407842926 := by decide
theorem cert_e302896215150 : check e302896215150 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e302896215162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302896215162 : Closed e302896215162 ∧ code e302896215162 = 1402407842938 := by decide
theorem cert_e302896215162 : check e302896215162 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e302896215326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302896215326 : Closed e302896215326 ∧ code e302896215326 = 1402407843102 := by decide
theorem cert_e302896215326 : check e302896215326 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e302896215494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302896215494 : Closed e302896215494 ∧ code e302896215494 = 1402407843270 := by decide
theorem cert_e302896215494 : check e302896215494 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e302896215834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302896215834 : Closed e302896215834 ∧ code e302896215834 = 1402407843610 := by decide
private def t_e302896215834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem cert_e302896215834 : ¬ IsSelfInterpreter e302896215834 :=
  wSource (t := t_e302896215834) (replay_sound (ps := []) (t := e302896215834) (by decide)) (by decide)
def e302896215878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302896215878 : Closed e302896215878 ∧ code e302896215878 = 1402407843654 := by decide
private def t_e302896215878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem cert_e302896215878 : ¬ IsSelfInterpreter e302896215878 :=
  wSource (t := t_e302896215878) (replay_sound (ps := []) (t := e302896215878) (by decide)) (by decide)
def e302896216278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e302896216278 : Closed e302896216278 ∧ code e302896216278 = 1402407844054 := by decide
theorem cert_e302896216278 : check e302896216278 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e302896216282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e302896216282 : Closed e302896216282 ∧ code e302896216282 = 1402407844058 := by decide
theorem cert_e302896216282 : check e302896216282 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e302896216298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e302896216298 : Closed e302896216298 ∧ code e302896216298 = 1402407844074 := by decide
theorem cert_e302896216298 : check e302896216298 [[],[],[],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e302896216630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302896216630 : Closed e302896216630 ∧ code e302896216630 = 1402407844406 := by decide
theorem cert_e302896216630 : check e302896216630 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e302896216634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302896216634 : Closed e302896216634 ∧ code e302896216634 = 1402407844410 := by decide
theorem cert_e302896216634 : check e302896216634 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e302896216718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302896216718 : Closed e302896216718 ∧ code e302896216718 = 1402407844494 := by decide
theorem cert_e302896216718 : check e302896216718 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e302896216774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302896216774 : Closed e302896216774 ∧ code e302896216774 = 1402407844550 := by decide
theorem cert_e302896216774 : check e302896216774 [[],[],[],[],[.under,.left,.left]] .sourceHead = true := by decide
def e302896216858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302896216858 : Closed e302896216858 ∧ code e302896216858 = 1402407844634 := by decide
private def t_e302896216858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem cert_e302896216858 : ¬ IsSelfInterpreter e302896216858 :=
  wSource (t := t_e302896216858) (replay_sound (ps := []) (t := e302896216858) (by decide)) (by decide)
def e302896216902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302896216902 : Closed e302896216902 ∧ code e302896216902 = 1402407844678 := by decide
private def t_e302896216902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem cert_e302896216902 : ¬ IsSelfInterpreter e302896216902 :=
  wSource (t := t_e302896216902) (replay_sound (ps := []) (t := e302896216902) (by decide)) (by decide)
def e302896219886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e302896219886 : Closed e302896219886 ∧ code e302896219886 = 1402407847662 := by decide
theorem cert_e302896219886 : check e302896219886 [[],[],[],[]] .sourceHead = true := by decide
def e302896219894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e302896219894 : Closed e302896219894 ∧ code e302896219894 = 1402407847670 := by decide
theorem cert_e302896219894 : check e302896219894 [[],[],[],[]] .sourceHead = true := by decide
def e302896220078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e302896220078 : Closed e302896220078 ∧ code e302896220078 = 1402407847854 := by decide
theorem cert_e302896220078 : check e302896220078 [[],[],[],[]] .sourceHead = true := by decide
def e302896220118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e302896220118 : Closed e302896220118 ∧ code e302896220118 = 1402407847894 := by decide
theorem cert_e302896220118 : check e302896220118 [[],[],[],[]] .sourceHead = true := by decide
def e302896221422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e302896221422 : Closed e302896221422 ∧ code e302896221422 = 1402407849198 := by decide
theorem cert_e302896221422 : check e302896221422 [[],[],[],[]] .sourceHead = true := by decide
def e302896221430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e302896221430 : Closed e302896221430 ∧ code e302896221430 = 1402407849206 := by decide
theorem cert_e302896221430 : check e302896221430 [[],[],[],[]] .sourceHead = true := by decide
def e302896221806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e302896221806 : Closed e302896221806 ∧ code e302896221806 = 1402407849582 := by decide
theorem cert_e302896221806 : check e302896221806 [[],[],[],[]] .sourceHead = true := by decide
def e302896221818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e302896221818 : Closed e302896221818 ∧ code e302896221818 = 1402407849594 := by decide
theorem cert_e302896221818 : check e302896221818 [[],[],[],[]] .sourceHead = true := by decide
def e302896222006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e302896222006 : Closed e302896222006 ∧ code e302896222006 = 1402407849782 := by decide
theorem cert_e302896222006 : check e302896222006 [[],[],[],[]] .sourceHead = true := by decide
def e302896222010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e302896222010 : Closed e302896222010 ∧ code e302896222010 = 1402407849786 := by decide
theorem cert_e302896222010 : check e302896222010 [[],[],[],[]] .sourceHead = true := by decide
def e302896224494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e302896224494 : Closed e302896224494 ∧ code e302896224494 = 1402407852270 := by decide
theorem cert_e302896224494 : check e302896224494 [[],[],[],[]] .sourceHead = true := by decide
def e302896224502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e302896224502 : Closed e302896224502 ∧ code e302896224502 = 1402407852278 := by decide
theorem cert_e302896224502 : check e302896224502 [[],[],[],[]] .sourceHead = true := by decide
def e302896225054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e302896225054 : Closed e302896225054 ∧ code e302896225054 = 1402407852830 := by decide
theorem cert_e302896225054 : check e302896225054 [[],[],[],[]] .sourceHead = true := by decide
def e302896225166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e302896225166 : Closed e302896225166 ∧ code e302896225166 = 1402407852942 := by decide
theorem cert_e302896225166 : check e302896225166 [[],[],[],[]] .sourceHead = true := by decide
def e302896225390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302896225390 : Closed e302896225390 ∧ code e302896225390 = 1402407853166 := by decide
theorem cert_e302896225390 : check e302896225390 [[],[],[],[]] .sourceHead = true := by decide
def e302896225402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302896225402 : Closed e302896225402 ∧ code e302896225402 = 1402407853178 := by decide
theorem cert_e302896225402 : check e302896225402 [[],[],[],[]] .sourceHead = true := by decide
def e302896225566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302896225566 : Closed e302896225566 ∧ code e302896225566 = 1402407853342 := by decide
theorem cert_e302896225566 : check e302896225566 [[],[],[],[]] .sourceHead = true := by decide
def e302896225734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302896225734 : Closed e302896225734 ∧ code e302896225734 = 1402407853510 := by decide
theorem cert_e302896225734 : check e302896225734 [[],[],[],[]] .sourceHead = true := by decide
def e302896225846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302896225846 : Closed e302896225846 ∧ code e302896225846 = 1402407853622 := by decide
theorem cert_e302896225846 : check e302896225846 [[],[],[],[]] .sourceHead = true := by decide
def e302896225850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302896225850 : Closed e302896225850 ∧ code e302896225850 = 1402407853626 := by decide
theorem cert_e302896225850 : check e302896225850 [[],[],[],[]] .sourceHead = true := by decide
def e302896225934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302896225934 : Closed e302896225934 ∧ code e302896225934 = 1402407853710 := by decide
theorem cert_e302896225934 : check e302896225934 [[],[],[],[]] .sourceHead = true := by decide
def e302896225990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302896225990 : Closed e302896225990 ∧ code e302896225990 = 1402407853766 := by decide
theorem cert_e302896225990 : check e302896225990 [[],[],[],[]] .sourceHead = true := by decide
def e302896228126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302896228126 : Closed e302896228126 ∧ code e302896228126 = 1402407855902 := by decide
theorem cert_e302896228126 : check e302896228126 [[],[],[],[]] .sourceHead = true := by decide
def e302896228238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302896228238 : Closed e302896228238 ∧ code e302896228238 = 1402407856014 := by decide
theorem cert_e302896228238 : check e302896228238 [[],[],[],[]] .sourceHead = true := by decide
def e302896230622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302896230622 : Closed e302896230622 ∧ code e302896230622 = 1402407858398 := by decide
theorem cert_e302896230622 : check e302896230622 [[],[],[],[]] .sourceHead = true := by decide
def e302896230650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302896230650 : Closed e302896230650 ∧ code e302896230650 = 1402407858426 := by decide
theorem cert_e302896230650 : check e302896230650 [[],[],[],[]] .sourceHead = true := by decide
def e302896231198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302896231198 : Closed e302896231198 ∧ code e302896231198 = 1402407858974 := by decide
theorem cert_e302896231198 : check e302896231198 [[],[],[],[]] .sourceHead = true := by decide
def e302896231366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302896231366 : Closed e302896231366 ∧ code e302896231366 = 1402407859142 := by decide
theorem cert_e302896231366 : check e302896231366 [[],[],[],[]] .sourceHead = true := by decide
def e302896232558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302896232558 : Closed e302896232558 ∧ code e302896232558 = 1402407860334 := by decide
theorem cert_e302896232558 : check e302896232558 [[],[],[],[]] .sourceHead = true := by decide
def e302896232570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302896232570 : Closed e302896232570 ∧ code e302896232570 = 1402407860346 := by decide
theorem cert_e302896232570 : check e302896232570 [[],[],[],[]] .sourceHead = true := by decide
def e302896232846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302896232846 : Closed e302896232846 ∧ code e302896232846 = 1402407860622 := by decide
theorem cert_e302896232846 : check e302896232846 [[],[],[],[]] .sourceHead = true := by decide
def e302896232902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302896232902 : Closed e302896232902 ∧ code e302896232902 = 1402407860678 := by decide
theorem cert_e302896232902 : check e302896232902 [[],[],[],[]] .sourceHead = true := by decide
def e302896235374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302896235374 : Closed e302896235374 ∧ code e302896235374 = 1402407863150 := by decide
theorem cert_e302896235374 : check e302896235374 [[],[],[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e302896235386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302896235386 : Closed e302896235386 ∧ code e302896235386 = 1402407863162 := by decide
private def t_e302896235386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem cert_e302896235386 : ¬ IsSelfInterpreter e302896235386 :=
  wSource (t := t_e302896235386) (replay_sound (ps := []) (t := e302896235386) (by decide)) (by decide)
def e302896235438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302896235438 : Closed e302896235438 ∧ code e302896235438 = 1402407863214 := by decide
theorem cert_e302896235438 : check e302896235438 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e302896235498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302896235498 : Closed e302896235498 ∧ code e302896235498 = 1402407863274 := by decide
private def t_e302896235498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem cert_e302896235498 : ¬ IsSelfInterpreter e302896235498 :=
  wSource (t := t_e302896235498) (replay_sound (ps := []) (t := e302896235498) (by decide)) (by decide)
def e302896236142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302896236142 : Closed e302896236142 ∧ code e302896236142 = 1402407863918 := by decide
theorem cert_e302896236142 : check e302896236142 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e302896236154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302896236154 : Closed e302896236154 ∧ code e302896236154 = 1402407863930 := by decide
theorem cert_e302896236154 : check e302896236154 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e302896236442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302896236442 : Closed e302896236442 ∧ code e302896236442 = 1402407864218 := by decide
theorem cert_e302896236442 : check e302896236442 [[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e302896237678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302896237678 : Closed e302896237678 ∧ code e302896237678 = 1402407865454 := by decide
theorem cert_e302896237678 : check e302896237678 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896237690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302896237690 : Closed e302896237690 ∧ code e302896237690 = 1402407865466 := by decide
theorem cert_e302896237690 : check e302896237690 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896237854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302896237854 : Closed e302896237854 ∧ code e302896237854 = 1402407865630 := by decide
theorem cert_e302896237854 : check e302896237854 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896238022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302896238022 : Closed e302896238022 ∧ code e302896238022 = 1402407865798 := by decide
theorem cert_e302896238022 : check e302896238022 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896238362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302896238362 : Closed e302896238362 ∧ code e302896238362 = 1402407866138 := by decide
theorem cert_e302896238362 : check e302896238362 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e302896238406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302896238406 : Closed e302896238406 ∧ code e302896238406 = 1402407866182 := by decide
theorem cert_e302896238406 : check e302896238406 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e302896238814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302896238814 : Closed e302896238814 ∧ code e302896238814 = 1402407866590 := by decide
theorem cert_e302896238814 : check e302896238814 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896238842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302896238842 : Closed e302896238842 ∧ code e302896238842 = 1402407866618 := by decide
theorem cert_e302896238842 : check e302896238842 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896239390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302896239390 : Closed e302896239390 ∧ code e302896239390 = 1402407867166 := by decide
theorem cert_e302896239390 : check e302896239390 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896239558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302896239558 : Closed e302896239558 ∧ code e302896239558 = 1402407867334 := by decide
theorem cert_e302896239558 : check e302896239558 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302896241718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302896241718 : Closed e302896241718 ∧ code e302896241718 = 1402407869494 := by decide
private def t_e302896241718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem cert_e302896241718 : ¬ IsSelfInterpreter e302896241718 :=
  wSource (t := t_e302896241718) (replay_sound (ps := []) (t := e302896241718) (by decide)) (by decide)
def e302896241722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302896241722 : Closed e302896241722 ∧ code e302896241722 = 1402407869498 := by decide
private def t_e302896241722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem cert_e302896241722 : ¬ IsSelfInterpreter e302896241722 :=
  wSource (t := t_e302896241722) (replay_sound (ps := []) (t := e302896241722) (by decide)) (by decide)
def e302896241862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302896241862 : Closed e302896241862 ∧ code e302896241862 = 1402407869638 := by decide
private def t_e302896241862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem cert_e302896241862 : ¬ IsSelfInterpreter e302896241862 :=
  wSource (t := t_e302896241862) (replay_sound (ps := []) (t := e302896241862) (by decide)) (by decide)
def e302896243126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e302896243126 : Closed e302896243126 ∧ code e302896243126 = 1402407870902 := by decide
theorem cert_e302896243126 : check e302896243126 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e302896243130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e302896243130 : Closed e302896243130 ∧ code e302896243130 = 1402407870906 := by decide
private def t_e302896243130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem cert_e302896243130 : ¬ IsSelfInterpreter e302896243130 :=
  wSource (t := t_e302896243130) (replay_sound (ps := []) (t := e302896243130) (by decide)) (by decide)
def e302896243158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e302896243158 : Closed e302896243158 ∧ code e302896243158 = 1402407870934 := by decide
theorem cert_e302896243158 : check e302896243158 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e302896243178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e302896243178 : Closed e302896243178 ∧ code e302896243178 = 1402407870954 := by decide
private def t_e302896243178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem cert_e302896243178 : ¬ IsSelfInterpreter e302896243178 :=
  wSource (t := t_e302896243178) (replay_sound (ps := []) (t := e302896243178) (by decide)) (by decide)
def e302896243510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e302896243510 : Closed e302896243510 ∧ code e302896243510 = 1402407871286 := by decide
theorem cert_e302896243510 : check e302896243510 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e302896243514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e302896243514 : Closed e302896243514 ∧ code e302896243514 = 1402407871290 := by decide
theorem cert_e302896243514 : check e302896243514 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e302896243610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e302896243610 : Closed e302896243610 ∧ code e302896243610 = 1402407871386 := by decide
theorem cert_e302896243610 : check e302896243610 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e302896244278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302896244278 : Closed e302896244278 ∧ code e302896244278 = 1402407872054 := by decide
theorem cert_e302896244278 : check e302896244278 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e302896244282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302896244282 : Closed e302896244282 ∧ code e302896244282 = 1402407872058 := by decide
theorem cert_e302896244282 : check e302896244282 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e302896244366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302896244366 : Closed e302896244366 ∧ code e302896244366 = 1402407872142 := by decide
theorem cert_e302896244366 : check e302896244366 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e302896244422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302896244422 : Closed e302896244422 ∧ code e302896244422 = 1402407872198 := by decide
theorem cert_e302896244422 : check e302896244422 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e302896244506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302896244506 : Closed e302896244506 ∧ code e302896244506 = 1402407872282 := by decide
theorem cert_e302896244506 : check e302896244506 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e302896244550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302896244550 : Closed e302896244550 ∧ code e302896244550 = 1402407872326 := by decide
theorem cert_e302896244550 : check e302896244550 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e302896244846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302896244846 : Closed e302896244846 ∧ code e302896244846 = 1402407872622 := by decide
theorem cert_e302896244846 : check e302896244846 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e302896244858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302896244858 : Closed e302896244858 ∧ code e302896244858 = 1402407872634 := by decide
theorem cert_e302896244858 : check e302896244858 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e302896245134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302896245134 : Closed e302896245134 ∧ code e302896245134 = 1402407872910 := by decide
theorem cert_e302896245134 : check e302896245134 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e302896245190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302896245190 : Closed e302896245190 ∧ code e302896245190 = 1402407872966 := by decide
theorem cert_e302896245190 : check e302896245190 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e302896245814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302896245814 : Closed e302896245814 ∧ code e302896245814 = 1402407873590 := by decide
private def t_e302896245814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem cert_e302896245814 : ¬ IsSelfInterpreter e302896245814 :=
  wSource (t := t_e302896245814) (replay_sound (ps := []) (t := e302896245814) (by decide)) (by decide)
def e302896245818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302896245818 : Closed e302896245818 ∧ code e302896245818 = 1402407873594 := by decide
private def t_e302896245818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem cert_e302896245818 : ¬ IsSelfInterpreter e302896245818 :=
  wSource (t := t_e302896245818) (replay_sound (ps := []) (t := e302896245818) (by decide)) (by decide)
def e302896245958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302896245958 : Closed e302896245958 ∧ code e302896245958 = 1402407873734 := by decide
private def t_e302896245958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem cert_e302896245958 : ¬ IsSelfInterpreter e302896245958 :=
  wSource (t := t_e302896245958) (replay_sound (ps := []) (t := e302896245958) (by decide)) (by decide)
def e302896256734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302896256734 : Closed e302896256734 ∧ code e302896256734 = 1402407884510 := by decide
theorem cert_e302896256734 : check e302896256734 [[],[],[],[]] .chain = true := by decide
def e302896256758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302896256758 : Closed e302896256758 ∧ code e302896256758 = 1402407884534 := by decide
theorem cert_e302896256758 : check e302896256758 [[],[],[],[]] .chain = true := by decide
def e302896256862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302896256862 : Closed e302896256862 ∧ code e302896256862 = 1402407884638 := by decide
theorem cert_e302896256862 : check e302896256862 [[],[],[],[]] .chain = true := by decide
def e302896256890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302896256890 : Closed e302896256890 ∧ code e302896256890 = 1402407884666 := by decide
theorem cert_e302896256890 : check e302896256890 [[],[],[],[]] .chain = true := by decide
def e302896256982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302896256982 : Closed e302896256982 ∧ code e302896256982 = 1402407884758 := by decide
theorem cert_e302896256982 : check e302896256982 [[],[],[],[]] .chain = true := by decide
def e302896256986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302896256986 : Closed e302896256986 ∧ code e302896256986 = 1402407884762 := by decide
theorem cert_e302896256986 : check e302896256986 [[],[],[],[]] .chain = true := by decide
def e302896257502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302896257502 : Closed e302896257502 ∧ code e302896257502 = 1402407885278 := by decide
theorem cert_e302896257502 : check e302896257502 [[],[],[],[]] .chain = true := by decide
def e302896257526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302896257526 : Closed e302896257526 ∧ code e302896257526 = 1402407885302 := by decide
theorem cert_e302896257526 : check e302896257526 [[],[],[],[]] .chain = true := by decide
def e302896258270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302896258270 : Closed e302896258270 ∧ code e302896258270 = 1402407886046 := by decide
theorem cert_e302896258270 : check e302896258270 [[],[],[],[]] .chain = true := by decide
def e302896258298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302896258298 : Closed e302896258298 ∧ code e302896258298 = 1402407886074 := by decide
theorem cert_e302896258298 : check e302896258298 [[],[],[],[]] .chain = true := by decide
def e302896258622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e302896258622 : Closed e302896258622 ∧ code e302896258622 = 1402407886398 := by decide
theorem cert_e302896258622 : check e302896258622 [[],[],[],[]] .sourceHead = true := by decide
def e302896258846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e302896258846 : Closed e302896258846 ∧ code e302896258846 = 1402407886622 := by decide
theorem cert_e302896258846 : check e302896258846 [[],[],[],[]] .sourceHead = true := by decide
def e302896258870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302896258870 : Closed e302896258870 ∧ code e302896258870 = 1402407886646 := by decide
theorem cert_e302896258870 : check e302896258870 [[],[],[],[]] .chain = true := by decide
def e302896258874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302896258874 : Closed e302896258874 ∧ code e302896258874 = 1402407886650 := by decide
theorem cert_e302896258874 : check e302896258874 [[],[],[],[]] .chain = true := by decide
def e302896273646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302896273646 : Closed e302896273646 ∧ code e302896273646 = 1402407901422 := by decide
theorem cert_e302896273646 : check e302896273646 [[],[],[],[]] .sourceHead = true := by decide
def e302896273654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302896273654 : Closed e302896273654 ∧ code e302896273654 = 1402407901430 := by decide
theorem cert_e302896273654 : check e302896273654 [[],[],[],[]] .sourceHead = true := by decide
def e302896274206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302896274206 : Closed e302896274206 ∧ code e302896274206 = 1402407901982 := by decide
theorem cert_e302896274206 : check e302896274206 [[],[],[],[]] .sourceHead = true := by decide
def e302896274318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302896274318 : Closed e302896274318 ∧ code e302896274318 = 1402407902094 := by decide
theorem cert_e302896274318 : check e302896274318 [[],[],[],[]] .sourceHead = true := by decide
end Blc.Floor40
