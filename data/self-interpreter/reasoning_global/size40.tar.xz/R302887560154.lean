import CodeBridge
import Batch060
namespace Certgen.R302887560154
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 35,.app 2 15,.lam 3,.app 4 14,.app 5 6,.var 0,.lam 7,.lam 8,.app 9 13,.app 10 11,.var 0,.lam 12,.var 3,.var 1,.var 0,.lam 16,.lam 17,.app 18 34,.app 19 20,.var 0,.lam 21,.lam 22,.app 23 33,.app 24 25,.var 0,.lam 26,.lam 27,.app 28 32,.app 29 30,.var 0,.lam 31,.var 3,.var 1,.var 0,.var 1,.lam 36,.app 37 47,.app 38 39,.var 0,.lam 40,.lam 41,.app 42 46,.app 43 44,.var 0,.lam 45,.var 3,.var 1,.var 0]
def values : Array (List AClo) := #[[⟨20,[3,1]⟩],[⟨6,[4]⟩],[⟨34,[3,1]⟩],[⟨14,[4]⟩],[⟨15,[]⟩],[⟨25,[7,5,2,0]⟩,⟨25,[8,6,3,1]⟩],[⟨11,[10,9,4]⟩],[⟨33,[7,5,2,0]⟩,⟨33,[8,6,3,1]⟩],[⟨13,[10,9,4]⟩],[⟨20,[2,0]⟩],[⟨34,[2,0]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨35,[]⟩,0⟩],[⟨⟨15,[]⟩,1⟩],[⟨⟨34,[2,0]⟩,1⟩],[⟨⟨34,[3,1]⟩,1⟩],[⟨⟨20,[2,0]⟩,3⟩],[⟨⟨20,[3,1]⟩,4⟩],[⟨⟨33,[7,5,2,0]⟩,1⟩],[⟨⟨33,[8,6,3,1]⟩,1⟩],[⟨⟨25,[7,5,2,0]⟩,7⟩],[⟨⟨25,[8,6,3,1]⟩,8⟩],[⟨⟨14,[4]⟩,1⟩],[⟨⟨6,[4]⟩,11⟩],[⟨⟨13,[10,9,4]⟩,1⟩],[⟨⟨11,[10,9,4]⟩,13⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[]⟩,2⟩,⟨⟨3,[4]⟩,1⟩,⟨⟨4,[4]⟩,11⟩,⟨⟨5,[4]⟩,12⟩,⟨⟨6,[4]⟩,5⟩,⟨⟨7,[9,4]⟩,3⟩,⟨⟨8,[10,9,4]⟩,1⟩,⟨⟨9,[10,9,4]⟩,13⟩,⟨⟨10,[10,9,4]⟩,14⟩,⟨⟨13,[10,9,4]⟩,9⟩,⟨⟨13,[10,9,4]⟩,10⟩,⟨⟨14,[4]⟩,6⟩,⟨⟨15,[]⟩,6⟩,⟨⟨15,[]⟩,12⟩,⟨⟨16,[0]⟩,4⟩,⟨⟨16,[1]⟩,11⟩,⟨⟨17,[2,0]⟩,1⟩,⟨⟨17,[3,1]⟩,1⟩,⟨⟨18,[2,0]⟩,3⟩,⟨⟨18,[3,1]⟩,4⟩,⟨⟨19,[2,0]⟩,5⟩,⟨⟨19,[3,1]⟩,6⟩,⟨⟨20,[2,0]⟩,9⟩,⟨⟨20,[2,0]⟩,10⟩,⟨⟨20,[3,1]⟩,14⟩,⟨⟨21,[5,2,0]⟩,7⟩,⟨⟨21,[5,2,0]⟩,8⟩,⟨⟨21,[6,3,1]⟩,13⟩,⟨⟨22,[7,5,2,0]⟩,1⟩,⟨⟨22,[8,6,3,1]⟩,1⟩,⟨⟨23,[7,5,2,0]⟩,7⟩,⟨⟨23,[8,6,3,1]⟩,8⟩,⟨⟨24,[7,5,2,0]⟩,9⟩,⟨⟨24,[8,6,3,1]⟩,10⟩,⟨⟨33,[7,5,2,0]⟩,9⟩,⟨⟨33,[8,6,3,1]⟩,9⟩,⟨⟨34,[2,0]⟩,14⟩,⟨⟨34,[3,1]⟩,5⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[15],[7],[8],[9],[10],[38],[24],[25],[14],[16],[17],[18],[19],[20],[21],[22],[23],[39],[13],[27],[28],[29],[30],[30],[31],[32],[33],[34],[35],[36,37],[12],[36,37],[11],[26],[6]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 4=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<40 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 exact range_sound block36 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit47 : Term := .var 0
def lit46 : Term := .var 1
def lit45 : Term := .var 3
def lit44 : Term := .lam lit45
def lit42 : Term := .app lit47 lit44
def lit41 : Term := .app lit42 lit46
def lit40 : Term := .lam lit41
def lit39 : Term := .lam lit40
def lit37 : Term := .app lit47 lit39
def lit36 : Term := .app lit37 lit47
def lit35 : Term := .lam lit36
def lit20 : Term := .lam lit35
def lit18 : Term := .app lit47 lit20
def lit17 : Term := .app lit18 lit46
def lit16 : Term := .lam lit17
def lit15 : Term := .lam lit16
def lit1 : Term := .app lit35 lit15
def lit0 : Term := .app lit1 lit35
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub47 : model.term 47 = lit47 := model.var_eq 47 0 (by rfl)
theorem sub46 : model.term 46 = lit46 := model.var_eq 46 1 (by rfl)
theorem sub45 : model.term 45 = lit45 := model.var_eq 45 3 (by rfl)
theorem sub44 : model.term 44 = lit44 := by rw [model.lam_eq 44 45 (by rfl), sub45]; rfl
theorem sub43 : model.term 43 = lit47 := model.var_eq 43 0 (by rfl)
theorem sub42 : model.term 42 = lit42 := by rw [model.app_eq 42 43 44 (by rfl), sub43, sub44]; rfl
theorem sub41 : model.term 41 = lit41 := by rw [model.app_eq 41 42 46 (by rfl), sub42, sub46]; rfl
theorem sub40 : model.term 40 = lit40 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit39 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit47 := model.var_eq 38 0 (by rfl)
theorem sub37 : model.term 37 = lit37 := by rw [model.app_eq 37 38 39 (by rfl), sub38, sub39]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.app_eq 36 37 47 (by rfl), sub37, sub47]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit46 := model.var_eq 34 1 (by rfl)
theorem sub33 : model.term 33 = lit47 := model.var_eq 33 0 (by rfl)
theorem sub32 : model.term 32 = lit46 := model.var_eq 32 1 (by rfl)
theorem sub31 : model.term 31 = lit45 := model.var_eq 31 3 (by rfl)
theorem sub30 : model.term 30 = lit44 := by rw [model.lam_eq 30 31 (by rfl), sub31]; rfl
theorem sub29 : model.term 29 = lit47 := model.var_eq 29 0 (by rfl)
theorem sub28 : model.term 28 = lit42 := by rw [model.app_eq 28 29 30 (by rfl), sub29, sub30]; rfl
theorem sub27 : model.term 27 = lit41 := by rw [model.app_eq 27 28 32 (by rfl), sub28, sub32]; rfl
theorem sub26 : model.term 26 = lit40 := by rw [model.lam_eq 26 27 (by rfl), sub27]; rfl
theorem sub25 : model.term 25 = lit39 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit47 := model.var_eq 24 0 (by rfl)
theorem sub23 : model.term 23 = lit37 := by rw [model.app_eq 23 24 25 (by rfl), sub24, sub25]; rfl
theorem sub22 : model.term 22 = lit36 := by rw [model.app_eq 22 23 33 (by rfl), sub23, sub33]; rfl
theorem sub21 : model.term 21 = lit35 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit20 := by rw [model.lam_eq 20 21 (by rfl), sub21]; rfl
theorem sub19 : model.term 19 = lit47 := model.var_eq 19 0 (by rfl)
theorem sub18 : model.term 18 = lit18 := by rw [model.app_eq 18 19 20 (by rfl), sub19, sub20]; rfl
theorem sub17 : model.term 17 = lit17 := by rw [model.app_eq 17 18 34 (by rfl), sub18, sub34]; rfl
theorem sub16 : model.term 16 = lit16 := by rw [model.lam_eq 16 17 (by rfl), sub17]; rfl
theorem sub15 : model.term 15 = lit15 := by rw [model.lam_eq 15 16 (by rfl), sub16]; rfl
theorem sub14 : model.term 14 = lit47 := model.var_eq 14 0 (by rfl)
theorem sub13 : model.term 13 = lit46 := model.var_eq 13 1 (by rfl)
theorem sub12 : model.term 12 = lit45 := model.var_eq 12 3 (by rfl)
theorem sub11 : model.term 11 = lit44 := by rw [model.lam_eq 11 12 (by rfl), sub12]; rfl
theorem sub10 : model.term 10 = lit47 := model.var_eq 10 0 (by rfl)
theorem sub9 : model.term 9 = lit42 := by rw [model.app_eq 9 10 11 (by rfl), sub10, sub11]; rfl
theorem sub8 : model.term 8 = lit41 := by rw [model.app_eq 8 9 13 (by rfl), sub9, sub13]; rfl
theorem sub7 : model.term 7 = lit40 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit39 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit47 := model.var_eq 5 0 (by rfl)
theorem sub4 : model.term 4 = lit37 := by rw [model.app_eq 4 5 6 (by rfl), sub5, sub6]; rfl
theorem sub3 : model.term 3 = lit36 := by rw [model.app_eq 3 4 14 (by rfl), sub4, sub14]; rfl
theorem sub2 : model.term 2 = lit35 := by rw [model.lam_eq 2 3 (by rfl), sub3]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 15 (by rfl), sub2, sub15]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 35 (by rfl), sub1, sub35]; rfl
theorem excluded : ¬ IsSelfInterpreter e302887560154 := by
 intro he
 have hp : replay [[],[]] e302887560154 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R302887560154
