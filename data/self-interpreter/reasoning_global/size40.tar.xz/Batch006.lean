import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e94925580142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e94925580142 : Closed e94925580142 ∧ code e94925580142 = 1194437207918 := by decide
theorem cert_e94925580142 : check e94925580142 [] .sourceHead = true := by decide
def e94925580150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e94925580150 : Closed e94925580150 ∧ code e94925580150 = 1194437207926 := by decide
theorem cert_e94925580150 : check e94925580150 [] .sourceHead = true := by decide
def e94925580214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e94925580214 : Closed e94925580214 ∧ code e94925580214 = 1194437207990 := by decide
theorem cert_e94925580214 : check e94925580214 [] .sourceHead = true := by decide
def e94925581550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e94925581550 : Closed e94925581550 ∧ code e94925581550 = 1194437209326 := by decide
theorem cert_e94925581550 : check e94925581550 [] .sourceHead = true := by decide
def e94925581558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e94925581558 : Closed e94925581558 ∧ code e94925581558 = 1194437209334 := by decide
theorem cert_e94925581558 : check e94925581558 [] .sourceHead = true := by decide
def e94925581942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e94925581942 : Closed e94925581942 ∧ code e94925581942 = 1194437209718 := by decide
theorem cert_e94925581942 : check e94925581942 [] .sourceHead = true := by decide
def e94925583214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e94925583214 : Closed e94925583214 ∧ code e94925583214 = 1194437210990 := by decide
theorem cert_e94925583214 : check e94925583214 [] .sourceHead = true := by decide
def e94925583222 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e94925583222 : Closed e94925583222 ∧ code e94925583222 = 1194437210998 := by decide
theorem cert_e94925583222 : check e94925583222 [] .sourceHead = true := by decide
def e94925583278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e94925583278 : Closed e94925583278 ∧ code e94925583278 = 1194437211054 := by decide
theorem cert_e94925583278 : check e94925583278 [] .sourceHead = true := by decide
def e94925583290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e94925583290 : Closed e94925583290 ∧ code e94925583290 = 1194437211066 := by decide
theorem cert_e94925583290 : check e94925583290 [] .sourceHead = true := by decide
def e94925583318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e94925583318 : Closed e94925583318 ∧ code e94925583318 = 1194437211094 := by decide
theorem cert_e94925583318 : check e94925583318 [] .sourceHead = true := by decide
def e94925583322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e94925583322 : Closed e94925583322 ∧ code e94925583322 = 1194437211098 := by decide
theorem cert_e94925583322 : check e94925583322 [] .sourceHead = true := by decide
def e94925583598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e94925583598 : Closed e94925583598 ∧ code e94925583598 = 1194437211374 := by decide
theorem cert_e94925583598 : check e94925583598 [] .sourceHead = true := by decide
def e94925583606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e94925583606 : Closed e94925583606 ∧ code e94925583606 = 1194437211382 := by decide
theorem cert_e94925583606 : check e94925583606 [] .sourceHead = true := by decide
def e94925583982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e94925583982 : Closed e94925583982 ∧ code e94925583982 = 1194437211758 := by decide
theorem cert_e94925583982 : check e94925583982 [] .sourceHead = true := by decide
def e94925583994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e94925583994 : Closed e94925583994 ∧ code e94925583994 = 1194437211770 := by decide
theorem cert_e94925583994 : check e94925583994 [] .sourceHead = true := by decide
def e94925584182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e94925584182 : Closed e94925584182 ∧ code e94925584182 = 1194437211958 := by decide
theorem cert_e94925584182 : check e94925584182 [] .sourceHead = true := by decide
def e94925584186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e94925584186 : Closed e94925584186 ∧ code e94925584186 = 1194437211962 := by decide
theorem cert_e94925584186 : check e94925584186 [] .sourceHead = true := by decide
def e94925584822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e94925584822 : Closed e94925584822 ∧ code e94925584822 = 1194437212598 := by decide
theorem cert_e94925584822 : check e94925584822 [] .sourceHead = true := by decide
def e94925584854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e94925584854 : Closed e94925584854 ∧ code e94925584854 = 1194437212630 := by decide
theorem cert_e94925584854 : check e94925584854 [] .sourceHead = true := by decide
def e94925584858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e94925584858 : Closed e94925584858 ∧ code e94925584858 = 1194437212634 := by decide
theorem cert_e94925584858 : check e94925584858 [] .sourceHead = true := by decide
def e94925585014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e94925585014 : Closed e94925585014 ∧ code e94925585014 = 1194437212790 := by decide
theorem cert_e94925585014 : check e94925585014 [] .sourceHead = true := by decide
def e94925585206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e94925585206 : Closed e94925585206 ∧ code e94925585206 = 1194437212982 := by decide
theorem cert_e94925585206 : check e94925585206 [] .sourceHead = true := by decide
def e94925585210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e94925585210 : Closed e94925585210 ∧ code e94925585210 = 1194437212986 := by decide
theorem cert_e94925585210 : check e94925585210 [] .sourceHead = true := by decide
def e94925592430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e94925592430 : Closed e94925592430 ∧ code e94925592430 = 1194437220206 := by decide
theorem cert_e94925592430 : check e94925592430 [] .sourceHead = true := by decide
def e94925592438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e94925592438 : Closed e94925592438 ∧ code e94925592438 = 1194437220214 := by decide
theorem cert_e94925592438 : check e94925592438 [] .sourceHead = true := by decide
def e94925592502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e94925592502 : Closed e94925592502 ∧ code e94925592502 = 1194437220278 := by decide
theorem cert_e94925592502 : check e94925592502 [] .sourceHead = true := by decide
def e94925593838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e94925593838 : Closed e94925593838 ∧ code e94925593838 = 1194437221614 := by decide
theorem cert_e94925593838 : check e94925593838 [] .sourceHead = true := by decide
def e94925593846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e94925593846 : Closed e94925593846 ∧ code e94925593846 = 1194437221622 := by decide
theorem cert_e94925593846 : check e94925593846 [] .sourceHead = true := by decide
def e94925594230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e94925594230 : Closed e94925594230 ∧ code e94925594230 = 1194437222006 := by decide
theorem cert_e94925594230 : check e94925594230 [] .sourceHead = true := by decide
def e94925605742 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e94925605742 : Closed e94925605742 ∧ code e94925605742 = 1194437233518 := by decide
theorem cert_e94925605742 : check e94925605742 [] .sourceHead = true := by decide
def e94925605750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e94925605750 : Closed e94925605750 ∧ code e94925605750 = 1194437233526 := by decide
theorem cert_e94925605750 : check e94925605750 [] .sourceHead = true := by decide
def e94925605806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e94925605806 : Closed e94925605806 ∧ code e94925605806 = 1194437233582 := by decide
theorem cert_e94925605806 : check e94925605806 [] .sourceHead = true := by decide
def e94925605818 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e94925605818 : Closed e94925605818 ∧ code e94925605818 = 1194437233594 := by decide
theorem cert_e94925605818 : check e94925605818 [] .sourceHead = true := by decide
def e94925605846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e94925605846 : Closed e94925605846 ∧ code e94925605846 = 1194437233622 := by decide
theorem cert_e94925605846 : check e94925605846 [] .sourceHead = true := by decide
def e94925605850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e94925605850 : Closed e94925605850 ∧ code e94925605850 = 1194437233626 := by decide
theorem cert_e94925605850 : check e94925605850 [] .sourceHead = true := by decide
def e94925606126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e94925606126 : Closed e94925606126 ∧ code e94925606126 = 1194437233902 := by decide
theorem cert_e94925606126 : check e94925606126 [] .sourceHead = true := by decide
def e94925606134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e94925606134 : Closed e94925606134 ∧ code e94925606134 = 1194437233910 := by decide
theorem cert_e94925606134 : check e94925606134 [] .sourceHead = true := by decide
def e94925606510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e94925606510 : Closed e94925606510 ∧ code e94925606510 = 1194437234286 := by decide
theorem cert_e94925606510 : check e94925606510 [] .sourceHead = true := by decide
def e94925606522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e94925606522 : Closed e94925606522 ∧ code e94925606522 = 1194437234298 := by decide
theorem cert_e94925606522 : check e94925606522 [] .sourceHead = true := by decide
def e94925606710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e94925606710 : Closed e94925606710 ∧ code e94925606710 = 1194437234486 := by decide
theorem cert_e94925606710 : check e94925606710 [] .sourceHead = true := by decide
def e94925606714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e94925606714 : Closed e94925606714 ∧ code e94925606714 = 1194437234490 := by decide
theorem cert_e94925606714 : check e94925606714 [] .sourceHead = true := by decide
def e94925612470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e94925612470 : Closed e94925612470 ∧ code e94925612470 = 1194437240246 := by decide
theorem cert_e94925612470 : check e94925612470 [] .sourceHead = true := by decide
def e94925612502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e94925612502 : Closed e94925612502 ∧ code e94925612502 = 1194437240278 := by decide
theorem cert_e94925612502 : check e94925612502 [] .sourceHead = true := by decide
def e94925612506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e94925612506 : Closed e94925612506 ∧ code e94925612506 = 1194437240282 := by decide
theorem cert_e94925612506 : check e94925612506 [] .sourceHead = true := by decide
def e94925612662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e94925612662 : Closed e94925612662 ∧ code e94925612662 = 1194437240438 := by decide
theorem cert_e94925612662 : check e94925612662 [] .sourceHead = true := by decide
def e94925612854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e94925612854 : Closed e94925612854 ∧ code e94925612854 = 1194437240630 := by decide
theorem cert_e94925612854 : check e94925612854 [] .sourceHead = true := by decide
def e94925612858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e94925612858 : Closed e94925612858 ∧ code e94925612858 = 1194437240634 := by decide
theorem cert_e94925612858 : check e94925612858 [] .sourceHead = true := by decide
def e94925949806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e94925949806 : Closed e94925949806 ∧ code e94925949806 = 1194437577582 := by decide
theorem cert_e94925949806 : check e94925949806 [] .sourceHead = true := by decide
def e94925949814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e94925949814 : Closed e94925949814 ∧ code e94925949814 = 1194437577590 := by decide
theorem cert_e94925949814 : check e94925949814 [] .sourceHead = true := by decide
def e94925949870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e94925949870 : Closed e94925949870 ∧ code e94925949870 = 1194437577646 := by decide
theorem cert_e94925949870 : check e94925949870 [] .sourceHead = true := by decide
def e94925949882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e94925949882 : Closed e94925949882 ∧ code e94925949882 = 1194437577658 := by decide
theorem cert_e94925949882 : check e94925949882 [] .sourceHead = true := by decide
def e94925949910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e94925949910 : Closed e94925949910 ∧ code e94925949910 = 1194437577686 := by decide
theorem cert_e94925949910 : check e94925949910 [] .sourceHead = true := by decide
def e94925949914 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e94925949914 : Closed e94925949914 ∧ code e94925949914 = 1194437577690 := by decide
theorem cert_e94925949914 : check e94925949914 [] .sourceHead = true := by decide
def e94925950190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e94925950190 : Closed e94925950190 ∧ code e94925950190 = 1194437577966 := by decide
theorem cert_e94925950190 : check e94925950190 [] .sourceHead = true := by decide
def e94925950198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e94925950198 : Closed e94925950198 ∧ code e94925950198 = 1194437577974 := by decide
theorem cert_e94925950198 : check e94925950198 [] .sourceHead = true := by decide
def e94925950574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e94925950574 : Closed e94925950574 ∧ code e94925950574 = 1194437578350 := by decide
theorem cert_e94925950574 : check e94925950574 [] .sourceHead = true := by decide
def e94925950586 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e94925950586 : Closed e94925950586 ∧ code e94925950586 = 1194437578362 := by decide
theorem cert_e94925950586 : check e94925950586 [] .sourceHead = true := by decide
def e94925950774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e94925950774 : Closed e94925950774 ∧ code e94925950774 = 1194437578550 := by decide
theorem cert_e94925950774 : check e94925950774 [] .sourceHead = true := by decide
def e94925950778 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e94925950778 : Closed e94925950778 ∧ code e94925950778 = 1194437578554 := by decide
theorem cert_e94925950778 : check e94925950778 [] .sourceHead = true := by decide
def e104262097774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e104262097774 : Closed e104262097774 ∧ code e104262097774 = 1203773725550 := by decide
theorem cert_e104262097774 : check e104262097774 [] .sourceHead = true := by decide
def e104262097782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e104262097782 : Closed e104262097782 ∧ code e104262097782 = 1203773725558 := by decide
theorem cert_e104262097782 : check e104262097782 [] .sourceHead = true := by decide
def e104262097846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e104262097846 : Closed e104262097846 ∧ code e104262097846 = 1203773725622 := by decide
theorem cert_e104262097846 : check e104262097846 [] .sourceHead = true := by decide
def e104262098286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e104262098286 : Closed e104262098286 ∧ code e104262098286 = 1203773726062 := by decide
theorem cert_e104262098286 : check e104262098286 [] .sourceHead = true := by decide
def e104262098294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e104262098294 : Closed e104262098294 ∧ code e104262098294 = 1203773726070 := by decide
theorem cert_e104262098294 : check e104262098294 [] .sourceHead = true := by decide
def e104262098350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e104262098350 : Closed e104262098350 ∧ code e104262098350 = 1203773726126 := by decide
theorem cert_e104262098350 : check e104262098350 [] .sourceHead = true := by decide
def e104262098362 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e104262098362 : Closed e104262098362 ∧ code e104262098362 = 1203773726138 := by decide
theorem cert_e104262098362 : check e104262098362 [] .sourceHead = true := by decide
def e104262098390 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e104262098390 : Closed e104262098390 ∧ code e104262098390 = 1203773726166 := by decide
theorem cert_e104262098390 : check e104262098390 [] .sourceHead = true := by decide
def e104262098394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e104262098394 : Closed e104262098394 ∧ code e104262098394 = 1203773726170 := by decide
theorem cert_e104262098394 : check e104262098394 [] .sourceHead = true := by decide
def e104262098614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e104262098614 : Closed e104262098614 ∧ code e104262098614 = 1203773726390 := by decide
theorem cert_e104262098614 : check e104262098614 [] .sourceHead = true := by decide
def e104262098646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e104262098646 : Closed e104262098646 ∧ code e104262098646 = 1203773726422 := by decide
theorem cert_e104262098646 : check e104262098646 [] .sourceHead = true := by decide
def e104262098650 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e104262098650 : Closed e104262098650 ∧ code e104262098650 = 1203773726426 := by decide
theorem cert_e104262098650 : check e104262098650 [] .sourceHead = true := by decide
def e104262100846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e104262100846 : Closed e104262100846 ∧ code e104262100846 = 1203773728622 := by decide
theorem cert_e104262100846 : check e104262100846 [] .sourceHead = true := by decide
def e104262100854 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e104262100854 : Closed e104262100854 ∧ code e104262100854 = 1203773728630 := by decide
theorem cert_e104262100854 : check e104262100854 [] .sourceHead = true := by decide
def e104262100918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e104262100918 : Closed e104262100918 ∧ code e104262100918 = 1203773728694 := by decide
theorem cert_e104262100918 : check e104262100918 [] .sourceHead = true := by decide
def e104262102254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e104262102254 : Closed e104262102254 ∧ code e104262102254 = 1203773730030 := by decide
theorem cert_e104262102254 : check e104262102254 [] .sourceHead = true := by decide
def e104262102262 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e104262102262 : Closed e104262102262 ∧ code e104262102262 = 1203773730038 := by decide
theorem cert_e104262102262 : check e104262102262 [] .sourceHead = true := by decide
def e104262102646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e104262102646 : Closed e104262102646 ∧ code e104262102646 = 1203773730422 := by decide
theorem cert_e104262102646 : check e104262102646 [] .sourceHead = true := by decide
def e104262103918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e104262103918 : Closed e104262103918 ∧ code e104262103918 = 1203773731694 := by decide
theorem cert_e104262103918 : check e104262103918 [] .sourceHead = true := by decide
def e104262103926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e104262103926 : Closed e104262103926 ∧ code e104262103926 = 1203773731702 := by decide
theorem cert_e104262103926 : check e104262103926 [] .sourceHead = true := by decide
def e104262103982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e104262103982 : Closed e104262103982 ∧ code e104262103982 = 1203773731758 := by decide
theorem cert_e104262103982 : check e104262103982 [] .sourceHead = true := by decide
def e104262103994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e104262103994 : Closed e104262103994 ∧ code e104262103994 = 1203773731770 := by decide
theorem cert_e104262103994 : check e104262103994 [] .sourceHead = true := by decide
def e104262104022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e104262104022 : Closed e104262104022 ∧ code e104262104022 = 1203773731798 := by decide
theorem cert_e104262104022 : check e104262104022 [] .sourceHead = true := by decide
def e104262104026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e104262104026 : Closed e104262104026 ∧ code e104262104026 = 1203773731802 := by decide
theorem cert_e104262104026 : check e104262104026 [] .sourceHead = true := by decide
def e104262104302 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e104262104302 : Closed e104262104302 ∧ code e104262104302 = 1203773732078 := by decide
theorem cert_e104262104302 : check e104262104302 [] .sourceHead = true := by decide
def e104262104310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e104262104310 : Closed e104262104310 ∧ code e104262104310 = 1203773732086 := by decide
theorem cert_e104262104310 : check e104262104310 [] .sourceHead = true := by decide
def e104262104686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e104262104686 : Closed e104262104686 ∧ code e104262104686 = 1203773732462 := by decide
theorem cert_e104262104686 : check e104262104686 [] .sourceHead = true := by decide
def e104262104698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e104262104698 : Closed e104262104698 ∧ code e104262104698 = 1203773732474 := by decide
theorem cert_e104262104698 : check e104262104698 [] .sourceHead = true := by decide
def e104262104886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e104262104886 : Closed e104262104886 ∧ code e104262104886 = 1203773732662 := by decide
theorem cert_e104262104886 : check e104262104886 [] .sourceHead = true := by decide
def e104262104890 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e104262104890 : Closed e104262104890 ∧ code e104262104890 = 1203773732666 := by decide
theorem cert_e104262104890 : check e104262104890 [] .sourceHead = true := by decide
def e104262105526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e104262105526 : Closed e104262105526 ∧ code e104262105526 = 1203773733302 := by decide
theorem cert_e104262105526 : check e104262105526 [] .sourceHead = true := by decide
def e104262105558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e104262105558 : Closed e104262105558 ∧ code e104262105558 = 1203773733334 := by decide
theorem cert_e104262105558 : check e104262105558 [] .sourceHead = true := by decide
def e104262105562 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e104262105562 : Closed e104262105562 ∧ code e104262105562 = 1203773733338 := by decide
theorem cert_e104262105562 : check e104262105562 [] .sourceHead = true := by decide
def e104262105718 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e104262105718 : Closed e104262105718 ∧ code e104262105718 = 1203773733494 := by decide
theorem cert_e104262105718 : check e104262105718 [] .sourceHead = true := by decide
def e104262105910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e104262105910 : Closed e104262105910 ∧ code e104262105910 = 1203773733686 := by decide
theorem cert_e104262105910 : check e104262105910 [] .sourceHead = true := by decide
def e104262105914 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e104262105914 : Closed e104262105914 ∧ code e104262105914 = 1203773733690 := by decide
theorem cert_e104262105914 : check e104262105914 [] .sourceHead = true := by decide
def e104262113134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e104262113134 : Closed e104262113134 ∧ code e104262113134 = 1203773740910 := by decide
theorem cert_e104262113134 : check e104262113134 [] .sourceHead = true := by decide
def e104262113142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e104262113142 : Closed e104262113142 ∧ code e104262113142 = 1203773740918 := by decide
theorem cert_e104262113142 : check e104262113142 [] .sourceHead = true := by decide
def e104262113206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e104262113206 : Closed e104262113206 ∧ code e104262113206 = 1203773740982 := by decide
theorem cert_e104262113206 : check e104262113206 [] .sourceHead = true := by decide
def e104262114542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e104262114542 : Closed e104262114542 ∧ code e104262114542 = 1203773742318 := by decide
theorem cert_e104262114542 : check e104262114542 [] .sourceHead = true := by decide
def e104262114550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e104262114550 : Closed e104262114550 ∧ code e104262114550 = 1203773742326 := by decide
theorem cert_e104262114550 : check e104262114550 [] .sourceHead = true := by decide
def e104262114934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e104262114934 : Closed e104262114934 ∧ code e104262114934 = 1203773742710 := by decide
theorem cert_e104262114934 : check e104262114934 [] .sourceHead = true := by decide
def e104262126446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e104262126446 : Closed e104262126446 ∧ code e104262126446 = 1203773754222 := by decide
theorem cert_e104262126446 : check e104262126446 [] .sourceHead = true := by decide
def e104262126454 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e104262126454 : Closed e104262126454 ∧ code e104262126454 = 1203773754230 := by decide
theorem cert_e104262126454 : check e104262126454 [] .sourceHead = true := by decide
def e104262126510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e104262126510 : Closed e104262126510 ∧ code e104262126510 = 1203773754286 := by decide
theorem cert_e104262126510 : check e104262126510 [] .sourceHead = true := by decide
def e104262126522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e104262126522 : Closed e104262126522 ∧ code e104262126522 = 1203773754298 := by decide
theorem cert_e104262126522 : check e104262126522 [] .sourceHead = true := by decide
def e104262126550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e104262126550 : Closed e104262126550 ∧ code e104262126550 = 1203773754326 := by decide
theorem cert_e104262126550 : check e104262126550 [] .sourceHead = true := by decide
def e104262126554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e104262126554 : Closed e104262126554 ∧ code e104262126554 = 1203773754330 := by decide
theorem cert_e104262126554 : check e104262126554 [] .sourceHead = true := by decide
def e104262126830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e104262126830 : Closed e104262126830 ∧ code e104262126830 = 1203773754606 := by decide
theorem cert_e104262126830 : check e104262126830 [] .sourceHead = true := by decide
def e104262126838 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e104262126838 : Closed e104262126838 ∧ code e104262126838 = 1203773754614 := by decide
theorem cert_e104262126838 : check e104262126838 [] .sourceHead = true := by decide
def e104262127214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e104262127214 : Closed e104262127214 ∧ code e104262127214 = 1203773754990 := by decide
theorem cert_e104262127214 : check e104262127214 [] .sourceHead = true := by decide
def e104262127226 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e104262127226 : Closed e104262127226 ∧ code e104262127226 = 1203773755002 := by decide
theorem cert_e104262127226 : check e104262127226 [] .sourceHead = true := by decide
def e104262127414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e104262127414 : Closed e104262127414 ∧ code e104262127414 = 1203773755190 := by decide
theorem cert_e104262127414 : check e104262127414 [] .sourceHead = true := by decide
def e104262127418 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e104262127418 : Closed e104262127418 ∧ code e104262127418 = 1203773755194 := by decide
theorem cert_e104262127418 : check e104262127418 [] .sourceHead = true := by decide
def e104262133174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e104262133174 : Closed e104262133174 ∧ code e104262133174 = 1203773760950 := by decide
theorem cert_e104262133174 : check e104262133174 [] .sourceHead = true := by decide
def e104262133206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e104262133206 : Closed e104262133206 ∧ code e104262133206 = 1203773760982 := by decide
theorem cert_e104262133206 : check e104262133206 [] .sourceHead = true := by decide
def e104262133210 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e104262133210 : Closed e104262133210 ∧ code e104262133210 = 1203773760986 := by decide
theorem cert_e104262133210 : check e104262133210 [] .sourceHead = true := by decide
def e104262133366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e104262133366 : Closed e104262133366 ∧ code e104262133366 = 1203773761142 := by decide
theorem cert_e104262133366 : check e104262133366 [] .sourceHead = true := by decide
def e104262133558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e104262133558 : Closed e104262133558 ∧ code e104262133558 = 1203773761334 := by decide
theorem cert_e104262133558 : check e104262133558 [] .sourceHead = true := by decide
def e104262133562 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e104262133562 : Closed e104262133562 ∧ code e104262133562 = 1203773761338 := by decide
theorem cert_e104262133562 : check e104262133562 [] .sourceHead = true := by decide
def e107810478958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e107810478958 : Closed e107810478958 ∧ code e107810478958 = 1207322106734 := by decide
theorem cert_e107810478958 : check e107810478958 [] .sourceHead = true := by decide
def e107810478966 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e107810478966 : Closed e107810478966 ∧ code e107810478966 = 1207322106742 := by decide
theorem cert_e107810478966 : check e107810478966 [] .sourceHead = true := by decide
def e107810479030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e107810479030 : Closed e107810479030 ∧ code e107810479030 = 1207322106806 := by decide
theorem cert_e107810479030 : check e107810479030 [] .sourceHead = true := by decide
def e107810479470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e107810479470 : Closed e107810479470 ∧ code e107810479470 = 1207322107246 := by decide
theorem cert_e107810479470 : check e107810479470 [] .sourceHead = true := by decide
def e107810479478 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e107810479478 : Closed e107810479478 ∧ code e107810479478 = 1207322107254 := by decide
theorem cert_e107810479478 : check e107810479478 [] .sourceHead = true := by decide
def e107810479534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e107810479534 : Closed e107810479534 ∧ code e107810479534 = 1207322107310 := by decide
theorem cert_e107810479534 : check e107810479534 [] .sourceHead = true := by decide
def e107810479546 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e107810479546 : Closed e107810479546 ∧ code e107810479546 = 1207322107322 := by decide
theorem cert_e107810479546 : check e107810479546 [] .sourceHead = true := by decide
def e107810479574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e107810479574 : Closed e107810479574 ∧ code e107810479574 = 1207322107350 := by decide
theorem cert_e107810479574 : check e107810479574 [] .sourceHead = true := by decide
def e107810479578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e107810479578 : Closed e107810479578 ∧ code e107810479578 = 1207322107354 := by decide
theorem cert_e107810479578 : check e107810479578 [] .sourceHead = true := by decide
def e107810479798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e107810479798 : Closed e107810479798 ∧ code e107810479798 = 1207322107574 := by decide
theorem cert_e107810479798 : check e107810479798 [] .sourceHead = true := by decide
def e107810479830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e107810479830 : Closed e107810479830 ∧ code e107810479830 = 1207322107606 := by decide
theorem cert_e107810479830 : check e107810479830 [] .sourceHead = true := by decide
def e107810479834 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e107810479834 : Closed e107810479834 ∧ code e107810479834 = 1207322107610 := by decide
theorem cert_e107810479834 : check e107810479834 [] .sourceHead = true := by decide
def e107810482030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e107810482030 : Closed e107810482030 ∧ code e107810482030 = 1207322109806 := by decide
theorem cert_e107810482030 : check e107810482030 [] .sourceHead = true := by decide
def e107810482038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e107810482038 : Closed e107810482038 ∧ code e107810482038 = 1207322109814 := by decide
theorem cert_e107810482038 : check e107810482038 [] .sourceHead = true := by decide
def e107810482102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e107810482102 : Closed e107810482102 ∧ code e107810482102 = 1207322109878 := by decide
theorem cert_e107810482102 : check e107810482102 [] .sourceHead = true := by decide
def e107810483438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e107810483438 : Closed e107810483438 ∧ code e107810483438 = 1207322111214 := by decide
theorem cert_e107810483438 : check e107810483438 [] .sourceHead = true := by decide
def e107810483446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e107810483446 : Closed e107810483446 ∧ code e107810483446 = 1207322111222 := by decide
theorem cert_e107810483446 : check e107810483446 [] .sourceHead = true := by decide
def e107810483830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e107810483830 : Closed e107810483830 ∧ code e107810483830 = 1207322111606 := by decide
theorem cert_e107810483830 : check e107810483830 [] .sourceHead = true := by decide
def e107810485102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e107810485102 : Closed e107810485102 ∧ code e107810485102 = 1207322112878 := by decide
theorem cert_e107810485102 : check e107810485102 [] .sourceHead = true := by decide
def e107810485110 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e107810485110 : Closed e107810485110 ∧ code e107810485110 = 1207322112886 := by decide
theorem cert_e107810485110 : check e107810485110 [] .sourceHead = true := by decide
def e107810485166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e107810485166 : Closed e107810485166 ∧ code e107810485166 = 1207322112942 := by decide
theorem cert_e107810485166 : check e107810485166 [] .sourceHead = true := by decide
def e107810485178 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e107810485178 : Closed e107810485178 ∧ code e107810485178 = 1207322112954 := by decide
theorem cert_e107810485178 : check e107810485178 [] .sourceHead = true := by decide
def e107810485206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e107810485206 : Closed e107810485206 ∧ code e107810485206 = 1207322112982 := by decide
theorem cert_e107810485206 : check e107810485206 [] .sourceHead = true := by decide
def e107810485210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e107810485210 : Closed e107810485210 ∧ code e107810485210 = 1207322112986 := by decide
theorem cert_e107810485210 : check e107810485210 [] .sourceHead = true := by decide
def e107810485486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e107810485486 : Closed e107810485486 ∧ code e107810485486 = 1207322113262 := by decide
theorem cert_e107810485486 : check e107810485486 [] .sourceHead = true := by decide
def e107810485494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e107810485494 : Closed e107810485494 ∧ code e107810485494 = 1207322113270 := by decide
theorem cert_e107810485494 : check e107810485494 [] .sourceHead = true := by decide
def e107810485870 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e107810485870 : Closed e107810485870 ∧ code e107810485870 = 1207322113646 := by decide
theorem cert_e107810485870 : check e107810485870 [] .sourceHead = true := by decide
def e107810485882 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e107810485882 : Closed e107810485882 ∧ code e107810485882 = 1207322113658 := by decide
theorem cert_e107810485882 : check e107810485882 [] .sourceHead = true := by decide
def e107810486070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e107810486070 : Closed e107810486070 ∧ code e107810486070 = 1207322113846 := by decide
theorem cert_e107810486070 : check e107810486070 [] .sourceHead = true := by decide
def e107810486074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e107810486074 : Closed e107810486074 ∧ code e107810486074 = 1207322113850 := by decide
theorem cert_e107810486074 : check e107810486074 [] .sourceHead = true := by decide
def e107810486710 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e107810486710 : Closed e107810486710 ∧ code e107810486710 = 1207322114486 := by decide
theorem cert_e107810486710 : check e107810486710 [] .sourceHead = true := by decide
def e107810486742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e107810486742 : Closed e107810486742 ∧ code e107810486742 = 1207322114518 := by decide
theorem cert_e107810486742 : check e107810486742 [] .sourceHead = true := by decide
def e107810486746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e107810486746 : Closed e107810486746 ∧ code e107810486746 = 1207322114522 := by decide
theorem cert_e107810486746 : check e107810486746 [] .sourceHead = true := by decide
def e107810486902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e107810486902 : Closed e107810486902 ∧ code e107810486902 = 1207322114678 := by decide
theorem cert_e107810486902 : check e107810486902 [] .sourceHead = true := by decide
def e107810487094 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e107810487094 : Closed e107810487094 ∧ code e107810487094 = 1207322114870 := by decide
theorem cert_e107810487094 : check e107810487094 [] .sourceHead = true := by decide
def e107810487098 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e107810487098 : Closed e107810487098 ∧ code e107810487098 = 1207322114874 := by decide
theorem cert_e107810487098 : check e107810487098 [] .sourceHead = true := by decide
def e107810494318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e107810494318 : Closed e107810494318 ∧ code e107810494318 = 1207322122094 := by decide
theorem cert_e107810494318 : check e107810494318 [] .sourceHead = true := by decide
def e107810494326 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e107810494326 : Closed e107810494326 ∧ code e107810494326 = 1207322122102 := by decide
theorem cert_e107810494326 : check e107810494326 [] .sourceHead = true := by decide
def e107810494390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e107810494390 : Closed e107810494390 ∧ code e107810494390 = 1207322122166 := by decide
theorem cert_e107810494390 : check e107810494390 [] .sourceHead = true := by decide
def e107810495726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e107810495726 : Closed e107810495726 ∧ code e107810495726 = 1207322123502 := by decide
theorem cert_e107810495726 : check e107810495726 [] .sourceHead = true := by decide
end Blc.Floor40
