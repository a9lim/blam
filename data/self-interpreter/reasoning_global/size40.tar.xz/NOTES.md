# Size 40 complete

Every exact closed-source BLC self-interpreter has at least 41 bits. REPORT-40.md contains the full classification, certificate implications, new rank lemma, parity argument, evidence boundary and reproduction instructions. No residual or audit item remains within this lane.

- 130,880,047 closed length-40 wires checked independently. 53,008 pass width, pair and public-interface conditions. Direct contraction filtering reproduces the triple generator’s 10,284 wires exactly.
- 9,978 finite predicates and 306 complete Lean exclusions. Of the 92 residuals, 49 regular, 42 weighted rank, one swap parity. Zero rows use the stronger single-object pruning test.
- Ledger, exact residual theorem names/statements/axioms and complete-proof table: ledger.json, residuals.tsv and complete.tsv.
- Clean proof dependency closure: 346 modules in 182.370 s, peak RSS 887,816,192 bytes. Audit40.log and recheck.json are the successful clean replay's results. The full inventory check including compilation took 6.381 s. All checks confined to this directory plus read-only dependencies. Size 41 is untouched.
