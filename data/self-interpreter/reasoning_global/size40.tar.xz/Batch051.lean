import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801840926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302801840926 : Closed e302801840926 ∧ code e302801840926 = 1402313468702 := by decide
theorem cert_e302801840926 : check e302801840926 [[],[]] .chain = true := by decide
def e302801841038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302801841038 : Closed e302801841038 ∧ code e302801841038 = 1402313468814 := by decide
theorem cert_e302801841038 : check e302801841038 [[],[]] .chain = true := by decide
def e302801841262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302801841262 : Closed e302801841262 ∧ code e302801841262 = 1402313469038 := by decide
theorem cert_e302801841262 : check e302801841262 [[],[]] .chain = true := by decide
def e302801841274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302801841274 : Closed e302801841274 ∧ code e302801841274 = 1402313469050 := by decide
theorem cert_e302801841274 : check e302801841274 [[],[]] .chain = true := by decide
def e302801841438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302801841438 : Closed e302801841438 ∧ code e302801841438 = 1402313469214 := by decide
theorem cert_e302801841438 : check e302801841438 [[],[]] .chain = true := by decide
def e302801841606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302801841606 : Closed e302801841606 ∧ code e302801841606 = 1402313469382 := by decide
theorem cert_e302801841606 : check e302801841606 [[],[]] .chain = true := by decide
def e302801841718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302801841718 : Closed e302801841718 ∧ code e302801841718 = 1402313469494 := by decide
theorem cert_e302801841718 : check e302801841718 [[],[]] .chain = true := by decide
def e302801841722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302801841722 : Closed e302801841722 ∧ code e302801841722 = 1402313469498 := by decide
theorem cert_e302801841722 : check e302801841722 [[],[]] .chain = true := by decide
def e302801841806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302801841806 : Closed e302801841806 ∧ code e302801841806 = 1402313469582 := by decide
theorem cert_e302801841806 : check e302801841806 [[],[]] .chain = true := by decide
def e302801841862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302801841862 : Closed e302801841862 ∧ code e302801841862 = 1402313469638 := by decide
theorem cert_e302801841862 : check e302801841862 [[],[]] .chain = true := by decide
def e302801842542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e302801842542 : Closed e302801842542 ∧ code e302801842542 = 1402313470318 := by decide
theorem cert_e302801842542 : check e302801842542 [[],[]] .chain = true := by decide
def e302801842550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e302801842550 : Closed e302801842550 ∧ code e302801842550 = 1402313470326 := by decide
theorem cert_e302801842550 : check e302801842550 [[],[]] .chain = true := by decide
def e302801842606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302801842606 : Closed e302801842606 ∧ code e302801842606 = 1402313470382 := by decide
theorem cert_e302801842606 : check e302801842606 [[],[]] .chain = true := by decide
def e302801842618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302801842618 : Closed e302801842618 ∧ code e302801842618 = 1402313470394 := by decide
theorem cert_e302801842618 : check e302801842618 [[],[]] .chain = true := by decide
def e302801842666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302801842666 : Closed e302801842666 ∧ code e302801842666 = 1402313470442 := by decide
theorem cert_e302801842666 : check e302801842666 [[],[]] .chain = true := by decide
def e302801843310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302801843310 : Closed e302801843310 ∧ code e302801843310 = 1402313471086 := by decide
theorem cert_e302801843310 : check e302801843310 [[],[]] .chain = true := by decide
def e302801843322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302801843322 : Closed e302801843322 ∧ code e302801843322 = 1402313471098 := by decide
theorem cert_e302801843322 : check e302801843322 [[],[]] .chain = true := by decide
def e302801843486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302801843486 : Closed e302801843486 ∧ code e302801843486 = 1402313471262 := by decide
theorem cert_e302801843486 : check e302801843486 [[],[]] .chain = true := by decide
def e302801843654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302801843654 : Closed e302801843654 ∧ code e302801843654 = 1402313471430 := by decide
theorem cert_e302801843654 : check e302801843654 [[],[]] .chain = true := by decide
def e302801843758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302801843758 : Closed e302801843758 ∧ code e302801843758 = 1402313471534 := by decide
theorem cert_e302801843758 : check e302801843758 [[],[]] .chain = true := by decide
def e302801843938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302801843938 : Closed e302801843938 ∧ code e302801843938 = 1402313471714 := by decide
theorem cert_e302801843938 : check e302801843938 [[],[]] .chain = true := by decide
def e302801843950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e302801843950 : Closed e302801843950 ∧ code e302801843950 = 1402313471726 := by decide
theorem cert_e302801843950 : check e302801843950 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801843990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801843990 : Closed e302801843990 ∧ code e302801843990 = 1402313471766 := by decide
theorem cert_e302801843990 : check e302801843990 [[],[]] .chain = true := by decide
def e302801843994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801843994 : Closed e302801843994 ∧ code e302801843994 = 1402313471770 := by decide
theorem cert_e302801843994 : check e302801843994 [[],[]] .chain = true := by decide
def e302801844038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801844038 : Closed e302801844038 ∧ code e302801844038 = 1402313471814 := by decide
theorem cert_e302801844038 : check e302801844038 [[],[]] .chain = true := by decide
def e302801844066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801844066 : Closed e302801844066 ∧ code e302801844066 = 1402313471842 := by decide
theorem cert_e302801844066 : check e302801844066 [[],[]] .chain = true := by decide
def e302801844078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e302801844078 : Closed e302801844078 ∧ code e302801844078 = 1402313471854 := by decide
theorem cert_e302801844078 : check e302801844078 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801844086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e302801844086 : Closed e302801844086 ∧ code e302801844086 = 1402313471862 := by decide
theorem cert_e302801844086 : check e302801844086 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801844406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e302801844406 : Closed e302801844406 ∧ code e302801844406 = 1402313472182 := by decide
theorem cert_e302801844406 : check e302801844406 [[],[]] .chain = true := by decide
def e302801844438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e302801844438 : Closed e302801844438 ∧ code e302801844438 = 1402313472214 := by decide
theorem cert_e302801844438 : check e302801844438 [[],[]] .chain = true := by decide
def e302801844442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e302801844442 : Closed e302801844442 ∧ code e302801844442 = 1402313472218 := by decide
theorem cert_e302801844442 : check e302801844442 [[],[]] .chain = true := by decide
def e302801844458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e302801844458 : Closed e302801844458 ∧ code e302801844458 = 1402313472234 := by decide
theorem cert_e302801844458 : check e302801844458 [[],[]] .chain = true := by decide
def e302801844790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302801844790 : Closed e302801844790 ∧ code e302801844790 = 1402313472566 := by decide
theorem cert_e302801844790 : check e302801844790 [[],[]] .chain = true := by decide
def e302801844794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302801844794 : Closed e302801844794 ∧ code e302801844794 = 1402313472570 := by decide
theorem cert_e302801844794 : check e302801844794 [[],[]] .chain = true := by decide
def e302801844878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302801844878 : Closed e302801844878 ∧ code e302801844878 = 1402313472654 := by decide
theorem cert_e302801844878 : check e302801844878 [[],[]] .chain = true := by decide
def e302801844934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302801844934 : Closed e302801844934 ∧ code e302801844934 = 1402313472710 := by decide
theorem cert_e302801844934 : check e302801844934 [[],[]] .chain = true := by decide
def e302801845014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801845014 : Closed e302801845014 ∧ code e302801845014 = 1402313472790 := by decide
theorem cert_e302801845014 : check e302801845014 [[],[]] .chain = true := by decide
def e302801845018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801845018 : Closed e302801845018 ∧ code e302801845018 = 1402313472794 := by decide
theorem cert_e302801845018 : check e302801845018 [[],[]] .chain = true := by decide
def e302801845062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801845062 : Closed e302801845062 ∧ code e302801845062 = 1402313472838 := by decide
theorem cert_e302801845062 : check e302801845062 [[],[]] .chain = true := by decide
def e302801845090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801845090 : Closed e302801845090 ∧ code e302801845090 = 1402313472866 := by decide
theorem cert_e302801845090 : check e302801845090 [[],[]] .chain = true := by decide
def e302801845102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e302801845102 : Closed e302801845102 ∧ code e302801845102 = 1402313472878 := by decide
theorem cert_e302801845102 : check e302801845102 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801845110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e302801845110 : Closed e302801845110 ∧ code e302801845110 = 1402313472886 := by decide
theorem cert_e302801845110 : check e302801845110 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302801845174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e302801845174 : Closed e302801845174 ∧ code e302801845174 = 1402313472950 := by decide
theorem cert_e302801845174 : check e302801845174 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302801848046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e302801848046 : Closed e302801848046 ∧ code e302801848046 = 1402313475822 := by decide
theorem cert_e302801848046 : check e302801848046 [[],[]] .chain = true := by decide
def e302801848054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e302801848054 : Closed e302801848054 ∧ code e302801848054 = 1402313475830 := by decide
theorem cert_e302801848054 : check e302801848054 [[],[]] .chain = true := by decide
def e302801848238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e302801848238 : Closed e302801848238 ∧ code e302801848238 = 1402313476014 := by decide
theorem cert_e302801848238 : check e302801848238 [[],[]] .chain = true := by decide
def e302801848278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e302801848278 : Closed e302801848278 ∧ code e302801848278 = 1402313476054 := by decide
theorem cert_e302801848278 : check e302801848278 [[],[]] .chain = true := by decide
def e302801849582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e302801849582 : Closed e302801849582 ∧ code e302801849582 = 1402313477358 := by decide
theorem cert_e302801849582 : check e302801849582 [[],[]] .chain = true := by decide
def e302801849590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e302801849590 : Closed e302801849590 ∧ code e302801849590 = 1402313477366 := by decide
theorem cert_e302801849590 : check e302801849590 [[],[]] .chain = true := by decide
def e302801849966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801849966 : Closed e302801849966 ∧ code e302801849966 = 1402313477742 := by decide
theorem cert_e302801849966 : check e302801849966 [[],[]] .chain = true := by decide
def e302801849978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801849978 : Closed e302801849978 ∧ code e302801849978 = 1402313477754 := by decide
theorem cert_e302801849978 : check e302801849978 [[],[]] .chain = true := by decide
def e302801850166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801850166 : Closed e302801850166 ∧ code e302801850166 = 1402313477942 := by decide
theorem cert_e302801850166 : check e302801850166 [[],[]] .chain = true := by decide
def e302801850170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801850170 : Closed e302801850170 ∧ code e302801850170 = 1402313477946 := by decide
theorem cert_e302801850170 : check e302801850170 [[],[]] .chain = true := by decide
def e302801852654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e302801852654 : Closed e302801852654 ∧ code e302801852654 = 1402313480430 := by decide
theorem cert_e302801852654 : check e302801852654 [[],[]] .chain = true := by decide
def e302801852662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e302801852662 : Closed e302801852662 ∧ code e302801852662 = 1402313480438 := by decide
theorem cert_e302801852662 : check e302801852662 [[],[]] .chain = true := by decide
def e302801853214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e302801853214 : Closed e302801853214 ∧ code e302801853214 = 1402313480990 := by decide
theorem cert_e302801853214 : check e302801853214 [[],[]] .chain = true := by decide
def e302801853326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e302801853326 : Closed e302801853326 ∧ code e302801853326 = 1402313481102 := by decide
theorem cert_e302801853326 : check e302801853326 [[],[]] .chain = true := by decide
def e302801853550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302801853550 : Closed e302801853550 ∧ code e302801853550 = 1402313481326 := by decide
theorem cert_e302801853550 : check e302801853550 [[],[]] .chain = true := by decide
def e302801853562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302801853562 : Closed e302801853562 ∧ code e302801853562 = 1402313481338 := by decide
theorem cert_e302801853562 : check e302801853562 [[],[]] .chain = true := by decide
def e302801853726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302801853726 : Closed e302801853726 ∧ code e302801853726 = 1402313481502 := by decide
theorem cert_e302801853726 : check e302801853726 [[],[]] .chain = true := by decide
def e302801853894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302801853894 : Closed e302801853894 ∧ code e302801853894 = 1402313481670 := by decide
theorem cert_e302801853894 : check e302801853894 [[],[]] .chain = true := by decide
def e302801854006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302801854006 : Closed e302801854006 ∧ code e302801854006 = 1402313481782 := by decide
theorem cert_e302801854006 : check e302801854006 [[],[]] .chain = true := by decide
def e302801854010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302801854010 : Closed e302801854010 ∧ code e302801854010 = 1402313481786 := by decide
theorem cert_e302801854010 : check e302801854010 [[],[]] .chain = true := by decide
def e302801854094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302801854094 : Closed e302801854094 ∧ code e302801854094 = 1402313481870 := by decide
theorem cert_e302801854094 : check e302801854094 [[],[]] .chain = true := by decide
def e302801854150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302801854150 : Closed e302801854150 ∧ code e302801854150 = 1402313481926 := by decide
theorem cert_e302801854150 : check e302801854150 [[],[]] .chain = true := by decide
def e302801856286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302801856286 : Closed e302801856286 ∧ code e302801856286 = 1402313484062 := by decide
theorem cert_e302801856286 : check e302801856286 [[],[]] .chain = true := by decide
def e302801856398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302801856398 : Closed e302801856398 ∧ code e302801856398 = 1402313484174 := by decide
theorem cert_e302801856398 : check e302801856398 [[],[]] .chain = true := by decide
def e302801858782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302801858782 : Closed e302801858782 ∧ code e302801858782 = 1402313486558 := by decide
theorem cert_e302801858782 : check e302801858782 [[],[]] .chain = true := by decide
def e302801858810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302801858810 : Closed e302801858810 ∧ code e302801858810 = 1402313486586 := by decide
theorem cert_e302801858810 : check e302801858810 [[],[]] .chain = true := by decide
def e302801859358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302801859358 : Closed e302801859358 ∧ code e302801859358 = 1402313487134 := by decide
theorem cert_e302801859358 : check e302801859358 [[],[]] .chain = true := by decide
def e302801859526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302801859526 : Closed e302801859526 ∧ code e302801859526 = 1402313487302 := by decide
theorem cert_e302801859526 : check e302801859526 [[],[]] .chain = true := by decide
def e302801860718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302801860718 : Closed e302801860718 ∧ code e302801860718 = 1402313488494 := by decide
theorem cert_e302801860718 : check e302801860718 [[],[]] .chain = true := by decide
def e302801860730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302801860730 : Closed e302801860730 ∧ code e302801860730 = 1402313488506 := by decide
theorem cert_e302801860730 : check e302801860730 [[],[]] .chain = true := by decide
def e302801861006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302801861006 : Closed e302801861006 ∧ code e302801861006 = 1402313488782 := by decide
theorem cert_e302801861006 : check e302801861006 [[],[]] .chain = true := by decide
def e302801861062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302801861062 : Closed e302801861062 ∧ code e302801861062 = 1402313488838 := by decide
theorem cert_e302801861062 : check e302801861062 [[],[]] .chain = true := by decide
def e302801863150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e302801863150 : Closed e302801863150 ∧ code e302801863150 = 1402313490926 := by decide
theorem cert_e302801863150 : check e302801863150 [[],[]] .chain = true := by decide
def e302801863158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e302801863158 : Closed e302801863158 ∧ code e302801863158 = 1402313490934 := by decide
theorem cert_e302801863158 : check e302801863158 [[],[]] .chain = true := by decide
def e302801863534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302801863534 : Closed e302801863534 ∧ code e302801863534 = 1402313491310 := by decide
theorem cert_e302801863534 : check e302801863534 [[],[]] .chain = true := by decide
def e302801863546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302801863546 : Closed e302801863546 ∧ code e302801863546 = 1402313491322 := by decide
theorem cert_e302801863546 : check e302801863546 [[],[]] .chain = true := by decide
def e302801863598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302801863598 : Closed e302801863598 ∧ code e302801863598 = 1402313491374 := by decide
theorem cert_e302801863598 : check e302801863598 [[],[]] .chain = true := by decide
def e302801863658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302801863658 : Closed e302801863658 ∧ code e302801863658 = 1402313491434 := by decide
theorem cert_e302801863658 : check e302801863658 [[],[]] .chain = true := by decide
def e302801863918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e302801863918 : Closed e302801863918 ∧ code e302801863918 = 1402313491694 := by decide
theorem cert_e302801863918 : check e302801863918 [[],[]] .chain = true := by decide
def e302801863926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e302801863926 : Closed e302801863926 ∧ code e302801863926 = 1402313491702 := by decide
theorem cert_e302801863926 : check e302801863926 [[],[]] .chain = true := by decide
def e302801864302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302801864302 : Closed e302801864302 ∧ code e302801864302 = 1402313492078 := by decide
theorem cert_e302801864302 : check e302801864302 [[],[]] .chain = true := by decide
def e302801864314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302801864314 : Closed e302801864314 ∧ code e302801864314 = 1402313492090 := by decide
theorem cert_e302801864314 : check e302801864314 [[],[]] .chain = true := by decide
def e302801864478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e302801864478 : Closed e302801864478 ∧ code e302801864478 = 1402313492254 := by decide
theorem cert_e302801864478 : check e302801864478 [[],[]] .chain = true := by decide
def e302801864590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e302801864590 : Closed e302801864590 ∧ code e302801864590 = 1402313492366 := by decide
theorem cert_e302801864590 : check e302801864590 [[],[]] .chain = true := by decide
def e302801864602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801864602 : Closed e302801864602 ∧ code e302801864602 = 1402313492378 := by decide
theorem cert_e302801864602 : check e302801864602 [[],[]] .chain = true := by decide
def e302801865838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302801865838 : Closed e302801865838 ∧ code e302801865838 = 1402313493614 := by decide
theorem cert_e302801865838 : check e302801865838 [[],[]] .chain = true := by decide
def e302801865850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302801865850 : Closed e302801865850 ∧ code e302801865850 = 1402313493626 := by decide
theorem cert_e302801865850 : check e302801865850 [[],[]] .chain = true := by decide
def e302801866014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302801866014 : Closed e302801866014 ∧ code e302801866014 = 1402313493790 := by decide
theorem cert_e302801866014 : check e302801866014 [[],[]] .chain = true := by decide
def e302801866182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302801866182 : Closed e302801866182 ∧ code e302801866182 = 1402313493958 := by decide
theorem cert_e302801866182 : check e302801866182 [[],[]] .chain = true := by decide
def e302801866286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e302801866286 : Closed e302801866286 ∧ code e302801866286 = 1402313494062 := by decide
theorem cert_e302801866286 : check e302801866286 [[],[]] .chain = true := by decide
def e302801866466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e302801866466 : Closed e302801866466 ∧ code e302801866466 = 1402313494242 := by decide
theorem cert_e302801866466 : check e302801866466 [[],[]] .chain = true := by decide
def e302801866478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e302801866478 : Closed e302801866478 ∧ code e302801866478 = 1402313494254 := by decide
theorem cert_e302801866478 : check e302801866478 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801866518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302801866518 : Closed e302801866518 ∧ code e302801866518 = 1402313494294 := by decide
theorem cert_e302801866518 : check e302801866518 [[],[]] .chain = true := by decide
def e302801866522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302801866522 : Closed e302801866522 ∧ code e302801866522 = 1402313494298 := by decide
theorem cert_e302801866522 : check e302801866522 [[],[]] .chain = true := by decide
def e302801866566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302801866566 : Closed e302801866566 ∧ code e302801866566 = 1402313494342 := by decide
theorem cert_e302801866566 : check e302801866566 [[],[]] .chain = true := by decide
def e302801866594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302801866594 : Closed e302801866594 ∧ code e302801866594 = 1402313494370 := by decide
theorem cert_e302801866594 : check e302801866594 [[],[]] .chain = true := by decide
def e302801866606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e302801866606 : Closed e302801866606 ∧ code e302801866606 = 1402313494382 := by decide
theorem cert_e302801866606 : check e302801866606 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801866614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e302801866614 : Closed e302801866614 ∧ code e302801866614 = 1402313494390 := by decide
theorem cert_e302801866614 : check e302801866614 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801866974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302801866974 : Closed e302801866974 ∧ code e302801866974 = 1402313494750 := by decide
theorem cert_e302801866974 : check e302801866974 [[],[]] .chain = true := by decide
def e302801867002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302801867002 : Closed e302801867002 ∧ code e302801867002 = 1402313494778 := by decide
theorem cert_e302801867002 : check e302801867002 [[],[]] .chain = true := by decide
def e302801867550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302801867550 : Closed e302801867550 ∧ code e302801867550 = 1402313495326 := by decide
theorem cert_e302801867550 : check e302801867550 [[],[]] .chain = true := by decide
def e302801867718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302801867718 : Closed e302801867718 ∧ code e302801867718 = 1402313495494 := by decide
theorem cert_e302801867718 : check e302801867718 [[],[]] .chain = true := by decide
def e302801868862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e302801868862 : Closed e302801868862 ∧ code e302801868862 = 1402313496638 := by decide
theorem cert_e302801868862 : check e302801868862 [[],[]] .chain = true := by decide
def e302801869282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302801869282 : Closed e302801869282 ∧ code e302801869282 = 1402313497058 := by decide
theorem cert_e302801869282 : check e302801869282 [[],[]] .chain = true := by decide
def e302801869294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e302801869294 : Closed e302801869294 ∧ code e302801869294 = 1402313497070 := by decide
theorem cert_e302801869294 : check e302801869294 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801869854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e302801869854 : Closed e302801869854 ∧ code e302801869854 = 1402313497630 := by decide
theorem cert_e302801869854 : check e302801869854 [[],[]] .chain = true := by decide
def e302801869878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801869878 : Closed e302801869878 ∧ code e302801869878 = 1402313497654 := by decide
theorem cert_e302801869878 : check e302801869878 [[],[]] .chain = true := by decide
def e302801869882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801869882 : Closed e302801869882 ∧ code e302801869882 = 1402313497658 := by decide
theorem cert_e302801869882 : check e302801869882 [[],[]] .chain = true := by decide
def e302801870022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801870022 : Closed e302801870022 ∧ code e302801870022 = 1402313497798 := by decide
theorem cert_e302801870022 : check e302801870022 [[],[]] .chain = true := by decide
def e302801870050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801870050 : Closed e302801870050 ∧ code e302801870050 = 1402313497826 := by decide
theorem cert_e302801870050 : check e302801870050 [[],[]] .chain = true := by decide
def e302801870062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e302801870062 : Closed e302801870062 ∧ code e302801870062 = 1402313497838 := by decide
theorem cert_e302801870062 : check e302801870062 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801870070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e302801870070 : Closed e302801870070 ∧ code e302801870070 = 1402313497846 := by decide
theorem cert_e302801870070 : check e302801870070 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801871094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e302801871094 : Closed e302801871094 ∧ code e302801871094 = 1402313498870 := by decide
theorem cert_e302801871094 : check e302801871094 [[],[]] .chain = true := by decide
def e302801871286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e302801871286 : Closed e302801871286 ∧ code e302801871286 = 1402313499062 := by decide
theorem cert_e302801871286 : check e302801871286 [[],[]] .chain = true := by decide
def e302801871290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e302801871290 : Closed e302801871290 ∧ code e302801871290 = 1402313499066 := by decide
theorem cert_e302801871290 : check e302801871290 [[],[]] .chain = true := by decide
def e302801871318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e302801871318 : Closed e302801871318 ∧ code e302801871318 = 1402313499094 := by decide
theorem cert_e302801871318 : check e302801871318 [[],[]] .chain = true := by decide
def e302801871338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e302801871338 : Closed e302801871338 ∧ code e302801871338 = 1402313499114 := by decide
theorem cert_e302801871338 : check e302801871338 [[],[]] .chain = true := by decide
def e302801871478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e302801871478 : Closed e302801871478 ∧ code e302801871478 = 1402313499254 := by decide
theorem cert_e302801871478 : check e302801871478 [[],[]] .chain = true := by decide
def e302801871670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e302801871670 : Closed e302801871670 ∧ code e302801871670 = 1402313499446 := by decide
theorem cert_e302801871670 : check e302801871670 [[],[]] .chain = true := by decide
def e302801871674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e302801871674 : Closed e302801871674 ∧ code e302801871674 = 1402313499450 := by decide
theorem cert_e302801871674 : check e302801871674 [[],[]] .chain = true := by decide
def e302801871758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e302801871758 : Closed e302801871758 ∧ code e302801871758 = 1402313499534 := by decide
theorem cert_e302801871758 : check e302801871758 [[],[]] .chain = true := by decide
def e302801871770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e302801871770 : Closed e302801871770 ∧ code e302801871770 = 1402313499546 := by decide
theorem cert_e302801871770 : check e302801871770 [[],[]] .chain = true := by decide
def e302801872438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302801872438 : Closed e302801872438 ∧ code e302801872438 = 1402313500214 := by decide
theorem cert_e302801872438 : check e302801872438 [[],[]] .chain = true := by decide
def e302801872442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302801872442 : Closed e302801872442 ∧ code e302801872442 = 1402313500218 := by decide
theorem cert_e302801872442 : check e302801872442 [[],[]] .chain = true := by decide
def e302801872526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302801872526 : Closed e302801872526 ∧ code e302801872526 = 1402313500302 := by decide
theorem cert_e302801872526 : check e302801872526 [[],[]] .chain = true := by decide
def e302801872582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302801872582 : Closed e302801872582 ∧ code e302801872582 = 1402313500358 := by decide
theorem cert_e302801872582 : check e302801872582 [[],[]] .chain = true := by decide
def e302801872662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302801872662 : Closed e302801872662 ∧ code e302801872662 = 1402313500438 := by decide
theorem cert_e302801872662 : check e302801872662 [[],[]] .chain = true := by decide
def e302801872666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302801872666 : Closed e302801872666 ∧ code e302801872666 = 1402313500442 := by decide
theorem cert_e302801872666 : check e302801872666 [[],[]] .chain = true := by decide
def e302801872710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302801872710 : Closed e302801872710 ∧ code e302801872710 = 1402313500486 := by decide
theorem cert_e302801872710 : check e302801872710 [[],[]] .chain = true := by decide
def e302801872738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302801872738 : Closed e302801872738 ∧ code e302801872738 = 1402313500514 := by decide
theorem cert_e302801872738 : check e302801872738 [[],[]] .chain = true := by decide
def e302801872750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e302801872750 : Closed e302801872750 ∧ code e302801872750 = 1402313500526 := by decide
theorem cert_e302801872750 : check e302801872750 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e302801872758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e302801872758 : Closed e302801872758 ∧ code e302801872758 = 1402313500534 := by decide
theorem cert_e302801872758 : check e302801872758 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e302801872822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e302801872822 : Closed e302801872822 ∧ code e302801872822 = 1402313500598 := by decide
theorem cert_e302801872822 : check e302801872822 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302801873006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302801873006 : Closed e302801873006 ∧ code e302801873006 = 1402313500782 := by decide
theorem cert_e302801873006 : check e302801873006 [[],[]] .chain = true := by decide
def e302801873018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302801873018 : Closed e302801873018 ∧ code e302801873018 = 1402313500794 := by decide
theorem cert_e302801873018 : check e302801873018 [[],[]] .chain = true := by decide
def e302801873294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302801873294 : Closed e302801873294 ∧ code e302801873294 = 1402313501070 := by decide
theorem cert_e302801873294 : check e302801873294 [[],[]] .chain = true := by decide
def e302801873350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302801873350 : Closed e302801873350 ∧ code e302801873350 = 1402313501126 := by decide
theorem cert_e302801873350 : check e302801873350 [[],[]] .chain = true := by decide
def e302801873950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e302801873950 : Closed e302801873950 ∧ code e302801873950 = 1402313501726 := by decide
theorem cert_e302801873950 : check e302801873950 [[],[]] .chain = true := by decide
def e302801873974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801873974 : Closed e302801873974 ∧ code e302801873974 = 1402313501750 := by decide
theorem cert_e302801873974 : check e302801873974 [[],[]] .chain = true := by decide
def e302801873978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801873978 : Closed e302801873978 ∧ code e302801873978 = 1402313501754 := by decide
theorem cert_e302801873978 : check e302801873978 [[],[]] .chain = true := by decide
def e302801874118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801874118 : Closed e302801874118 ∧ code e302801874118 = 1402313501894 := by decide
theorem cert_e302801874118 : check e302801874118 [[],[]] .chain = true := by decide
def e302801874146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801874146 : Closed e302801874146 ∧ code e302801874146 = 1402313501922 := by decide
theorem cert_e302801874146 : check e302801874146 [[],[]] .chain = true := by decide
def e302801874158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e302801874158 : Closed e302801874158 ∧ code e302801874158 = 1402313501934 := by decide
theorem cert_e302801874158 : checkPay e302801874158 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e302801874166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e302801874166 : Closed e302801874166 ∧ code e302801874166 = 1402313501942 := by decide
theorem cert_e302801874166 : checkPay e302801874166 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [[]] = true := by decide
def e302801874550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e302801874550 : Closed e302801874550 ∧ code e302801874550 = 1402313502326 := by decide
theorem cert_e302801874550 : check e302801874550 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e302801884894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302801884894 : Closed e302801884894 ∧ code e302801884894 = 1402313512670 := by decide
theorem cert_e302801884894 : check e302801884894 [[],[]] .chain = true := by decide
def e302801884918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302801884918 : Closed e302801884918 ∧ code e302801884918 = 1402313512694 := by decide
theorem cert_e302801884918 : check e302801884918 [[],[]] .chain = true := by decide
def e302801885022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302801885022 : Closed e302801885022 ∧ code e302801885022 = 1402313512798 := by decide
theorem cert_e302801885022 : check e302801885022 [[],[]] .chain = true := by decide
def e302801885050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302801885050 : Closed e302801885050 ∧ code e302801885050 = 1402313512826 := by decide
theorem cert_e302801885050 : check e302801885050 [[],[]] .chain = true := by decide
def e302801885142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302801885142 : Closed e302801885142 ∧ code e302801885142 = 1402313512918 := by decide
theorem cert_e302801885142 : check e302801885142 [[],[]] .chain = true := by decide
def e302801885146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302801885146 : Closed e302801885146 ∧ code e302801885146 = 1402313512922 := by decide
theorem cert_e302801885146 : check e302801885146 [[],[]] .chain = true := by decide
def e302801885662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302801885662 : Closed e302801885662 ∧ code e302801885662 = 1402313513438 := by decide
theorem cert_e302801885662 : check e302801885662 [[],[]] .chain = true := by decide
def e302801885686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302801885686 : Closed e302801885686 ∧ code e302801885686 = 1402313513462 := by decide
theorem cert_e302801885686 : check e302801885686 [[],[]] .chain = true := by decide
def e302801886430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302801886430 : Closed e302801886430 ∧ code e302801886430 = 1402313514206 := by decide
theorem cert_e302801886430 : check e302801886430 [[],[]] .chain = true := by decide
def e302801886458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302801886458 : Closed e302801886458 ∧ code e302801886458 = 1402313514234 := by decide
theorem cert_e302801886458 : check e302801886458 [[],[]] .chain = true := by decide
def e302801886782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e302801886782 : Closed e302801886782 ∧ code e302801886782 = 1402313514558 := by decide
theorem cert_e302801886782 : check e302801886782 [[],[]] .chain = true := by decide
def e302801887006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e302801887006 : Closed e302801887006 ∧ code e302801887006 = 1402313514782 := by decide
theorem cert_e302801887006 : check e302801887006 [[],[]] .chain = true := by decide
end Blc.Floor40
