import CodeBridge
import R302902173238Blk0
import R302902173238Blk6
namespace Certgen.R302902173238
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit102 : Term := .var 0
def lit82 : Term := .var 1
def lit45 : Term := .var 2
def lit101 : Term := .lam lit102
def lit81 : Term := .lam lit82
def lit73 : Term := .lam lit101
def lit98 : Term := .app lit102 lit102
def lit80 : Term := .lam lit81
def lit97 : Term := .lam lit98
def lit71 : Term := .app lit102 lit73
def lit44 : Term := .app lit45 lit81
def lit78 : Term := .app lit102 lit80
def lit43 : Term := .app lit44 lit82
def lit42 : Term := .lam lit43
def lit92 : Term := .app lit97 lit97
def lit41 : Term := .lam lit42
def lit39 : Term := .app lit102 lit41
def lit37 : Term := .app lit102 lit39
def lit36 : Term := .lam lit37
def lit77 : Term := .app lit78 lit92
def lit76 : Term := .lam lit77
def lit35 : Term := .app lit36 lit81
def lit34 : Term := .app lit35 lit82
def lit33 : Term := .lam lit34
def lit70 : Term := .app lit71 lit76
def lit32 : Term := .lam lit33
def lit69 : Term := .lam lit70
def lit63 : Term := .app lit78 lit69
def lit62 : Term := .lam lit63
def lit56 : Term := .app lit78 lit62
def lit55 : Term := .lam lit56
def lit18 : Term := .app lit36 lit32
def lit4 : Term := .app lit36 lit18
def lit3 : Term := .app lit4 lit80
def lit2 : Term := .app lit3 lit55
def lit1 : Term := .app lit2 lit92
def lit0 : Term := .app lit1 lit101
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub102 : model.term 102 = lit102 := model.var_eq 102 0 (by rfl)
theorem sub101 : model.term 101 = lit101 := by rw [model.lam_eq 101 102 (by rfl), sub102]; rfl
theorem sub100 : model.term 100 = lit102 := model.var_eq 100 0 (by rfl)
theorem sub99 : model.term 99 = lit102 := model.var_eq 99 0 (by rfl)
theorem sub98 : model.term 98 = lit98 := by rw [model.app_eq 98 99 100 (by rfl), sub99, sub100]; rfl
theorem sub97 : model.term 97 = lit97 := by rw [model.lam_eq 97 98 (by rfl), sub98]; rfl
theorem sub96 : model.term 96 = lit102 := model.var_eq 96 0 (by rfl)
theorem sub95 : model.term 95 = lit102 := model.var_eq 95 0 (by rfl)
theorem sub94 : model.term 94 = lit98 := by rw [model.app_eq 94 95 96 (by rfl), sub95, sub96]; rfl
theorem sub93 : model.term 93 = lit97 := by rw [model.lam_eq 93 94 (by rfl), sub94]; rfl
theorem sub92 : model.term 92 = lit92 := by rw [model.app_eq 92 93 97 (by rfl), sub93, sub97]; rfl
theorem sub91 : model.term 91 = lit102 := model.var_eq 91 0 (by rfl)
theorem sub90 : model.term 90 = lit102 := model.var_eq 90 0 (by rfl)
theorem sub89 : model.term 89 = lit98 := by rw [model.app_eq 89 90 91 (by rfl), sub90, sub91]; rfl
theorem sub88 : model.term 88 = lit97 := by rw [model.lam_eq 88 89 (by rfl), sub89]; rfl
theorem sub87 : model.term 87 = lit102 := model.var_eq 87 0 (by rfl)
theorem sub86 : model.term 86 = lit102 := model.var_eq 86 0 (by rfl)
theorem sub85 : model.term 85 = lit98 := by rw [model.app_eq 85 86 87 (by rfl), sub86, sub87]; rfl
theorem sub84 : model.term 84 = lit97 := by rw [model.lam_eq 84 85 (by rfl), sub85]; rfl
theorem sub83 : model.term 83 = lit92 := by rw [model.app_eq 83 84 88 (by rfl), sub84, sub88]; rfl
theorem sub82 : model.term 82 = lit82 := model.var_eq 82 1 (by rfl)
theorem sub81 : model.term 81 = lit81 := by rw [model.lam_eq 81 82 (by rfl), sub82]; rfl
theorem sub80 : model.term 80 = lit80 := by rw [model.lam_eq 80 81 (by rfl), sub81]; rfl
theorem sub79 : model.term 79 = lit102 := model.var_eq 79 0 (by rfl)
theorem sub78 : model.term 78 = lit78 := by rw [model.app_eq 78 79 80 (by rfl), sub79, sub80]; rfl
theorem sub77 : model.term 77 = lit77 := by rw [model.app_eq 77 78 83 (by rfl), sub78, sub83]; rfl
theorem sub76 : model.term 76 = lit76 := by rw [model.lam_eq 76 77 (by rfl), sub77]; rfl
theorem sub75 : model.term 75 = lit102 := model.var_eq 75 0 (by rfl)
theorem sub74 : model.term 74 = lit101 := by rw [model.lam_eq 74 75 (by rfl), sub75]; rfl
theorem sub73 : model.term 73 = lit73 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit102 := model.var_eq 72 0 (by rfl)
theorem sub71 : model.term 71 = lit71 := by rw [model.app_eq 71 72 73 (by rfl), sub72, sub73]; rfl
theorem sub70 : model.term 70 = lit70 := by rw [model.app_eq 70 71 76 (by rfl), sub71, sub76]; rfl
theorem sub69 : model.term 69 = lit69 := by rw [model.lam_eq 69 70 (by rfl), sub70]; rfl
theorem sub68 : model.term 68 = lit82 := model.var_eq 68 1 (by rfl)
theorem sub67 : model.term 67 = lit81 := by rw [model.lam_eq 67 68 (by rfl), sub68]; rfl
theorem sub66 : model.term 66 = lit80 := by rw [model.lam_eq 66 67 (by rfl), sub67]; rfl
theorem sub65 : model.term 65 = lit102 := model.var_eq 65 0 (by rfl)
theorem sub64 : model.term 64 = lit78 := by rw [model.app_eq 64 65 66 (by rfl), sub65, sub66]; rfl
theorem sub63 : model.term 63 = lit63 := by rw [model.app_eq 63 64 69 (by rfl), sub64, sub69]; rfl
theorem sub62 : model.term 62 = lit62 := by rw [model.lam_eq 62 63 (by rfl), sub63]; rfl
theorem sub61 : model.term 61 = lit82 := model.var_eq 61 1 (by rfl)
theorem sub60 : model.term 60 = lit81 := by rw [model.lam_eq 60 61 (by rfl), sub61]; rfl
theorem sub59 : model.term 59 = lit80 := by rw [model.lam_eq 59 60 (by rfl), sub60]; rfl
theorem sub58 : model.term 58 = lit102 := model.var_eq 58 0 (by rfl)
theorem sub57 : model.term 57 = lit78 := by rw [model.app_eq 57 58 59 (by rfl), sub58, sub59]; rfl
theorem sub56 : model.term 56 = lit56 := by rw [model.app_eq 56 57 62 (by rfl), sub57, sub62]; rfl
theorem sub55 : model.term 55 = lit55 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit82 := model.var_eq 54 1 (by rfl)
theorem sub53 : model.term 53 = lit81 := by rw [model.lam_eq 53 54 (by rfl), sub54]; rfl
theorem sub52 : model.term 52 = lit80 := by rw [model.lam_eq 52 53 (by rfl), sub53]; rfl
theorem sub51 : model.term 51 = lit82 := model.var_eq 51 1 (by rfl)
theorem sub50 : model.term 50 = lit82 := model.var_eq 50 1 (by rfl)
theorem sub49 : model.term 49 = lit81 := by rw [model.lam_eq 49 50 (by rfl), sub50]; rfl
theorem sub48 : model.term 48 = lit82 := model.var_eq 48 1 (by rfl)
theorem sub47 : model.term 47 = lit82 := model.var_eq 47 1 (by rfl)
theorem sub46 : model.term 46 = lit81 := by rw [model.lam_eq 46 47 (by rfl), sub47]; rfl
theorem sub45 : model.term 45 = lit45 := model.var_eq 45 2 (by rfl)
theorem sub44 : model.term 44 = lit44 := by rw [model.app_eq 44 45 46 (by rfl), sub45, sub46]; rfl
theorem sub43 : model.term 43 = lit43 := by rw [model.app_eq 43 44 48 (by rfl), sub44, sub48]; rfl
theorem sub42 : model.term 42 = lit42 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit41 := by rw [model.lam_eq 41 42 (by rfl), sub42]; rfl
theorem sub40 : model.term 40 = lit102 := model.var_eq 40 0 (by rfl)
theorem sub39 : model.term 39 = lit39 := by rw [model.app_eq 39 40 41 (by rfl), sub40, sub41]; rfl
theorem sub38 : model.term 38 = lit102 := model.var_eq 38 0 (by rfl)
theorem sub37 : model.term 37 = lit37 := by rw [model.app_eq 37 38 39 (by rfl), sub38, sub39]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.lam_eq 36 37 (by rfl), sub37]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.app_eq 35 36 49 (by rfl), sub36, sub49]; rfl
theorem sub34 : model.term 34 = lit34 := by rw [model.app_eq 34 35 51 (by rfl), sub35, sub51]; rfl
theorem sub33 : model.term 33 = lit33 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit32 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit82 := model.var_eq 31 1 (by rfl)
theorem sub30 : model.term 30 = lit82 := model.var_eq 30 1 (by rfl)
theorem sub29 : model.term 29 = lit81 := by rw [model.lam_eq 29 30 (by rfl), sub30]; rfl
theorem sub28 : model.term 28 = lit45 := model.var_eq 28 2 (by rfl)
theorem sub27 : model.term 27 = lit44 := by rw [model.app_eq 27 28 29 (by rfl), sub28, sub29]; rfl
theorem sub26 : model.term 26 = lit43 := by rw [model.app_eq 26 27 31 (by rfl), sub27, sub31]; rfl
theorem sub25 : model.term 25 = lit42 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit41 := by rw [model.lam_eq 24 25 (by rfl), sub25]; rfl
theorem sub23 : model.term 23 = lit102 := model.var_eq 23 0 (by rfl)
theorem sub22 : model.term 22 = lit39 := by rw [model.app_eq 22 23 24 (by rfl), sub23, sub24]; rfl
theorem sub21 : model.term 21 = lit102 := model.var_eq 21 0 (by rfl)
theorem sub20 : model.term 20 = lit37 := by rw [model.app_eq 20 21 22 (by rfl), sub21, sub22]; rfl
theorem sub19 : model.term 19 = lit36 := by rw [model.lam_eq 19 20 (by rfl), sub20]; rfl
theorem sub18 : model.term 18 = lit18 := by rw [model.app_eq 18 19 32 (by rfl), sub19, sub32]; rfl
theorem sub17 : model.term 17 = lit82 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit82 := model.var_eq 16 1 (by rfl)
theorem sub15 : model.term 15 = lit81 := by rw [model.lam_eq 15 16 (by rfl), sub16]; rfl
theorem sub14 : model.term 14 = lit45 := model.var_eq 14 2 (by rfl)
theorem sub13 : model.term 13 = lit44 := by rw [model.app_eq 13 14 15 (by rfl), sub14, sub15]; rfl
theorem sub12 : model.term 12 = lit43 := by rw [model.app_eq 12 13 17 (by rfl), sub13, sub17]; rfl
theorem sub11 : model.term 11 = lit42 := by rw [model.lam_eq 11 12 (by rfl), sub12]; rfl
theorem sub10 : model.term 10 = lit41 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit102 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit39 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit102 := model.var_eq 7 0 (by rfl)
theorem sub6 : model.term 6 = lit37 := by rw [model.app_eq 6 7 8 (by rfl), sub7, sub8]; rfl
theorem sub5 : model.term 5 = lit36 := by rw [model.lam_eq 5 6 (by rfl), sub6]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 18 (by rfl), sub5, sub18]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 52 (by rfl), sub4, sub52]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 55 (by rfl), sub3, sub55]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 92 (by rfl), sub2, sub92]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 101 (by rfl), sub1, sub101]; rfl
theorem allValid (i : Nat) (h : i < 143) : validState i = true := by
 by_cases h72 : i < 72
 · by_cases h36 : i < 36
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · by_cases h24 : i < 24
       · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
   · by_cases h48 : i < 48
     · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
     · by_cases h60 : i < 60
       · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
 · by_cases h108 : i < 108
   · by_cases h84 : i < 84
     · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
     · by_cases h96 : i < 96
       · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
   · by_cases h120 : i < 120
     · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
     · by_cases h132 : i < 132
       · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 143
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302902173238 := by
 intro he
 have hp : replay [[.left,.left,.left,.left],[.left,.left,.left,.left]] (call e302902173238 (.lam (.lam (.var 1))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.var 0))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 4) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302902173238
