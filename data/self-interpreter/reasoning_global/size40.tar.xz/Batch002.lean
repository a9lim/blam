import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e75192287978 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75192287978 : Closed e75192287978 ∧ code e75192287978 = 1174703915754 := by decide
theorem cert_e75192287978 : check e75192287978 [[.under]] .width = true := by decide
def e75192288054 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75192288054 : Closed e75192288054 ∧ code e75192288054 = 1174703915830 := by decide
theorem cert_e75192288054 : check e75192288054 [[.under]] .width = true := by decide
def e75192288058 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75192288058 : Closed e75192288058 ∧ code e75192288058 = 1174703915834 := by decide
theorem cert_e75192288058 : check e75192288058 [[.under]] .width = true := by decide
def e75192288154 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75192288154 : Closed e75192288154 ∧ code e75192288154 = 1174703915930 := by decide
theorem cert_e75192288154 : check e75192288154 [[.under]] .width = true := by decide
def e75193828054 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75193828054 : Closed e75193828054 ∧ code e75193828054 = 1174705455830 := by decide
theorem cert_e75193828054 : check e75193828054 [[.under]] .width = true := by decide
def e75193828058 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75193828058 : Closed e75193828058 ∧ code e75193828058 = 1174705455834 := by decide
theorem cert_e75193828058 : check e75193828058 [[.under]] .width = true := by decide
def e75193828074 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75193828074 : Closed e75193828074 ∧ code e75193828074 = 1174705455850 := by decide
theorem cert_e75193828074 : check e75193828074 [[.under]] .width = true := by decide
def e75193828150 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75193828150 : Closed e75193828150 ∧ code e75193828150 = 1174705455926 := by decide
theorem cert_e75193828150 : check e75193828150 [[.under]] .width = true := by decide
def e75193828154 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75193828154 : Closed e75193828154 ∧ code e75193828154 = 1174705455930 := by decide
theorem cert_e75193828154 : check e75193828154 [[.under]] .width = true := by decide
def e75193828250 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75193828250 : Closed e75193828250 ∧ code e75193828250 = 1174705456026 := by decide
theorem cert_e75193828250 : check e75193828250 [[.under]] .width = true := by decide
def e75193860822 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75193860822 : Closed e75193860822 ∧ code e75193860822 = 1174705488598 := by decide
theorem cert_e75193860822 : check e75193860822 [[.under]] .width = true := by decide
def e75193860826 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75193860826 : Closed e75193860826 ∧ code e75193860826 = 1174705488602 := by decide
theorem cert_e75193860826 : check e75193860826 [[.under]] .width = true := by decide
def e75193860842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75193860842 : Closed e75193860842 ∧ code e75193860842 = 1174705488618 := by decide
theorem cert_e75193860842 : check e75193860842 [[.under]] .width = true := by decide
def e75193860918 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75193860918 : Closed e75193860918 ∧ code e75193860918 = 1174705488694 := by decide
theorem cert_e75193860918 : check e75193860918 [[.under]] .width = true := by decide
def e75193860922 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75193860922 : Closed e75193860922 ∧ code e75193860922 = 1174705488698 := by decide
theorem cert_e75193860922 : check e75193860922 [[.under]] .width = true := by decide
def e75193861018 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75193861018 : Closed e75193861018 ∧ code e75193861018 = 1174705488794 := by decide
theorem cert_e75193861018 : check e75193861018 [[.under]] .width = true := by decide
def e75614956910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e75614956910 : Closed e75614956910 ∧ code e75614956910 = 1175126584686 := by decide
theorem cert_e75614956910 : check e75614956910 [[.under],[.under]] .three = true := by decide
def e75614956918 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e75614956918 : Closed e75614956918 ∧ code e75614956918 = 1175126584694 := by decide
theorem cert_e75614956918 : check e75614956918 [[.under],[.under]] .three = true := by decide
def e75614956974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e75614956974 : Closed e75614956974 ∧ code e75614956974 = 1175126584750 := by decide
theorem cert_e75614956974 : check e75614956974 [[.under],[.under]] .three = true := by decide
def e75614956986 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e75614956986 : Closed e75614956986 ∧ code e75614956986 = 1175126584762 := by decide
theorem cert_e75614956986 : check e75614956986 [[.under],[.under]] .three = true := by decide
def e75614957014 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e75614957014 : Closed e75614957014 ∧ code e75614957014 = 1175126584790 := by decide
theorem cert_e75614957014 : check e75614957014 [[.under],[.under]] .three = true := by decide
def e75614957018 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e75614957018 : Closed e75614957018 ∧ code e75614957018 = 1175126584794 := by decide
theorem cert_e75614957018 : check e75614957018 [[.under],[.under]] .three = true := by decide
def e75614957230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e75614957230 : Closed e75614957230 ∧ code e75614957230 = 1175126585006 := by decide
theorem cert_e75614957230 : check e75614957230 [[.under],[.under]] .three = true := by decide
def e75614957242 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e75614957242 : Closed e75614957242 ∧ code e75614957242 = 1175126585018 := by decide
theorem cert_e75614957242 : check e75614957242 [[.under],[.under]] .three = true := by decide
def e75614957290 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e75614957290 : Closed e75614957290 ∧ code e75614957290 = 1175126585066 := by decide
theorem cert_e75614957290 : check e75614957290 [[.under],[.under]] .three = true := by decide
def e75614957398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e75614957398 : Closed e75614957398 ∧ code e75614957398 = 1175126585174 := by decide
theorem cert_e75614957398 : check e75614957398 [[.under],[.under]] .three = true := by decide
def e75614957402 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e75614957402 : Closed e75614957402 ∧ code e75614957402 = 1175126585178 := by decide
theorem cert_e75614957402 : check e75614957402 [[.under],[.under]] .three = true := by decide
def e75614957418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e75614957418 : Closed e75614957418 ∧ code e75614957418 = 1175126585194 := by decide
theorem cert_e75614957418 : check e75614957418 [[.under],[.under]] .three = true := by decide
def e75614958446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e75614958446 : Closed e75614958446 ∧ code e75614958446 = 1175126586222 := by decide
theorem cert_e75614958446 : check e75614958446 [[.under],[.under]] .three = true := by decide
def e75614958454 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e75614958454 : Closed e75614958454 ∧ code e75614958454 = 1175126586230 := by decide
theorem cert_e75614958454 : check e75614958454 [[.under],[.under]] .three = true := by decide
def e75614958510 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e75614958510 : Closed e75614958510 ∧ code e75614958510 = 1175126586286 := by decide
theorem cert_e75614958510 : check e75614958510 [[.under],[.under]] .three = true := by decide
def e75614958522 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e75614958522 : Closed e75614958522 ∧ code e75614958522 = 1175126586298 := by decide
theorem cert_e75614958522 : check e75614958522 [[.under],[.under]] .three = true := by decide
def e75614958550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e75614958550 : Closed e75614958550 ∧ code e75614958550 = 1175126586326 := by decide
theorem cert_e75614958550 : check e75614958550 [[.under],[.under]] .three = true := by decide
def e75614958554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e75614958554 : Closed e75614958554 ∧ code e75614958554 = 1175126586330 := by decide
theorem cert_e75614958554 : check e75614958554 [[.under],[.under]] .three = true := by decide
def e75614958830 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e75614958830 : Closed e75614958830 ∧ code e75614958830 = 1175126586606 := by decide
theorem cert_e75614958830 : check e75614958830 [[.under],[.under]] .three = true := by decide
def e75614958838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e75614958838 : Closed e75614958838 ∧ code e75614958838 = 1175126586614 := by decide
theorem cert_e75614958838 : check e75614958838 [[.under],[.under]] .three = true := by decide
def e75614959214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e75614959214 : Closed e75614959214 ∧ code e75614959214 = 1175126586990 := by decide
theorem cert_e75614959214 : check e75614959214 [[.under],[.under]] .three = true := by decide
def e75614959226 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e75614959226 : Closed e75614959226 ∧ code e75614959226 = 1175126587002 := by decide
theorem cert_e75614959226 : check e75614959226 [[.under],[.under]] .three = true := by decide
def e75614959414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e75614959414 : Closed e75614959414 ∧ code e75614959414 = 1175126587190 := by decide
theorem cert_e75614959414 : check e75614959414 [[.under],[.under]] .three = true := by decide
def e75614959418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e75614959418 : Closed e75614959418 ∧ code e75614959418 = 1175126587194 := by decide
theorem cert_e75614959418 : check e75614959418 [[.under],[.under]] .three = true := by decide
def e75614960046 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e75614960046 : Closed e75614960046 ∧ code e75614960046 = 1175126587822 := by decide
theorem cert_e75614960046 : check e75614960046 [[.under],[.under]] .three = true := by decide
def e75614960058 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e75614960058 : Closed e75614960058 ∧ code e75614960058 = 1175126587834 := by decide
theorem cert_e75614960058 : check e75614960058 [[.under],[.under]] .three = true := by decide
def e75614960106 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e75614960106 : Closed e75614960106 ∧ code e75614960106 = 1175126587882 := by decide
theorem cert_e75614960106 : check e75614960106 [[.under],[.under]] .three = true := by decide
def e75614960238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e75614960238 : Closed e75614960238 ∧ code e75614960238 = 1175126588014 := by decide
theorem cert_e75614960238 : check e75614960238 [[.under],[.under]] .three = true := by decide
def e75614960250 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e75614960250 : Closed e75614960250 ∧ code e75614960250 = 1175126588026 := by decide
theorem cert_e75614960250 : check e75614960250 [[.under],[.under]] .three = true := by decide
def e75614960538 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e75614960538 : Closed e75614960538 ∧ code e75614960538 = 1175126588314 := by decide
theorem cert_e75614960538 : check e75614960538 [[.under],[.under]] .three = true := by decide
def e75614960854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e75614960854 : Closed e75614960854 ∧ code e75614960854 = 1175126588630 := by decide
theorem cert_e75614960854 : check e75614960854 [[.under],[.under]] .three = true := by decide
def e75614960858 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e75614960858 : Closed e75614960858 ∧ code e75614960858 = 1175126588634 := by decide
theorem cert_e75614960858 : check e75614960858 [[.under],[.under]] .three = true := by decide
def e75614960874 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e75614960874 : Closed e75614960874 ∧ code e75614960874 = 1175126588650 := by decide
theorem cert_e75614960874 : check e75614960874 [[.under],[.under]] .three = true := by decide
def e75614960950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e75614960950 : Closed e75614960950 ∧ code e75614960950 = 1175126588726 := by decide
theorem cert_e75614960950 : check e75614960950 [[.under],[.under]] .three = true := by decide
def e75614960954 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e75614960954 : Closed e75614960954 ∧ code e75614960954 = 1175126588730 := by decide
theorem cert_e75614960954 : check e75614960954 [[.under],[.under]] .three = true := by decide
def e75614961050 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e75614961050 : Closed e75614961050 ∧ code e75614961050 = 1175126588826 := by decide
theorem cert_e75614961050 : check e75614961050 [[.under],[.under]] .three = true := by decide
def e75614964590 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75614964590 : Closed e75614964590 ∧ code e75614964590 = 1175126592366 := by decide
theorem cert_e75614964590 : check e75614964590 [[.under],[.under]] .three = true := by decide
def e75614964598 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75614964598 : Closed e75614964598 ∧ code e75614964598 = 1175126592374 := by decide
theorem cert_e75614964598 : check e75614964598 [[.under],[.under]] .three = true := by decide
def e75614964654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75614964654 : Closed e75614964654 ∧ code e75614964654 = 1175126592430 := by decide
theorem cert_e75614964654 : check e75614964654 [[.under],[.under]] .three = true := by decide
def e75614964666 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75614964666 : Closed e75614964666 ∧ code e75614964666 = 1175126592442 := by decide
theorem cert_e75614964666 : check e75614964666 [[.under],[.under]] .three = true := by decide
def e75614964694 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75614964694 : Closed e75614964694 ∧ code e75614964694 = 1175126592470 := by decide
theorem cert_e75614964694 : check e75614964694 [[.under],[.under]] .three = true := by decide
def e75614964698 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75614964698 : Closed e75614964698 ∧ code e75614964698 = 1175126592474 := by decide
theorem cert_e75614964698 : check e75614964698 [[.under],[.under]] .three = true := by decide
def e75614964974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75614964974 : Closed e75614964974 ∧ code e75614964974 = 1175126592750 := by decide
theorem cert_e75614964974 : check e75614964974 [[.under],[.under]] .three = true := by decide
def e75614964982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75614964982 : Closed e75614964982 ∧ code e75614964982 = 1175126592758 := by decide
theorem cert_e75614964982 : check e75614964982 [[.under],[.under]] .three = true := by decide
def e75614965358 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75614965358 : Closed e75614965358 ∧ code e75614965358 = 1175126593134 := by decide
theorem cert_e75614965358 : check e75614965358 [[.under],[.under]] .three = true := by decide
def e75614965370 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75614965370 : Closed e75614965370 ∧ code e75614965370 = 1175126593146 := by decide
theorem cert_e75614965370 : check e75614965370 [[.under],[.under]] .three = true := by decide
def e75614965558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75614965558 : Closed e75614965558 ∧ code e75614965558 = 1175126593334 := by decide
theorem cert_e75614965558 : check e75614965558 [[.under],[.under]] .three = true := by decide
def e75614965562 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75614965562 : Closed e75614965562 ∧ code e75614965562 = 1175126593338 := by decide
theorem cert_e75614965562 : check e75614965562 [[.under],[.under]] .three = true := by decide
def e75614971310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e75614971310 : Closed e75614971310 ∧ code e75614971310 = 1175126599086 := by decide
theorem cert_e75614971310 : check e75614971310 [[.under],[.under]] .three = true := by decide
def e75614971322 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e75614971322 : Closed e75614971322 ∧ code e75614971322 = 1175126599098 := by decide
theorem cert_e75614971322 : check e75614971322 [[.under],[.under]] .three = true := by decide
def e75614971370 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e75614971370 : Closed e75614971370 ∧ code e75614971370 = 1175126599146 := by decide
theorem cert_e75614971370 : check e75614971370 [[.under],[.under]] .three = true := by decide
def e75614971502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e75614971502 : Closed e75614971502 ∧ code e75614971502 = 1175126599278 := by decide
theorem cert_e75614971502 : check e75614971502 [[.under],[.under]] .three = true := by decide
def e75614971514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e75614971514 : Closed e75614971514 ∧ code e75614971514 = 1175126599290 := by decide
theorem cert_e75614971514 : check e75614971514 [[.under],[.under]] .three = true := by decide
def e75614971802 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e75614971802 : Closed e75614971802 ∧ code e75614971802 = 1175126599578 := by decide
theorem cert_e75614971802 : check e75614971802 [[.under],[.under]] .three = true := by decide
def e75614974678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e75614974678 : Closed e75614974678 ∧ code e75614974678 = 1175126602454 := by decide
theorem cert_e75614974678 : check e75614974678 [[.under],[.under]] .three = true := by decide
def e75614974682 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e75614974682 : Closed e75614974682 ∧ code e75614974682 = 1175126602458 := by decide
theorem cert_e75614974682 : check e75614974682 [[.under],[.under]] .three = true := by decide
def e75614974698 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e75614974698 : Closed e75614974698 ∧ code e75614974698 = 1175126602474 := by decide
theorem cert_e75614974698 : check e75614974698 [[.under],[.under]] .three = true := by decide
def e75614974774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e75614974774 : Closed e75614974774 ∧ code e75614974774 = 1175126602550 := by decide
theorem cert_e75614974774 : check e75614974774 [[.under],[.under]] .three = true := by decide
def e75614974778 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e75614974778 : Closed e75614974778 ∧ code e75614974778 = 1175126602554 := by decide
theorem cert_e75614974778 : check e75614974778 [[.under],[.under]] .three = true := by decide
def e75614974874 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e75614974874 : Closed e75614974874 ∧ code e75614974874 = 1175126602650 := by decide
theorem cert_e75614974874 : check e75614974874 [[.under],[.under]] .three = true := by decide
def e75615112046 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75615112046 : Closed e75615112046 ∧ code e75615112046 = 1175126739822 := by decide
theorem cert_e75615112046 : check e75615112046 [[.under],[.under]] .chain = true := by decide
def e75615112054 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75615112054 : Closed e75615112054 ∧ code e75615112054 = 1175126739830 := by decide
theorem cert_e75615112054 : check e75615112054 [[.under],[.under]] .chain = true := by decide
def e75615112110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75615112110 : Closed e75615112110 ∧ code e75615112110 = 1175126739886 := by decide
theorem cert_e75615112110 : check e75615112110 [[.under],[.under]] .chain = true := by decide
def e75615112122 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75615112122 : Closed e75615112122 ∧ code e75615112122 = 1175126739898 := by decide
theorem cert_e75615112122 : check e75615112122 [[.under],[.under]] .chain = true := by decide
def e75615112150 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75615112150 : Closed e75615112150 ∧ code e75615112150 = 1175126739926 := by decide
theorem cert_e75615112150 : check e75615112150 [[.under],[.under]] .chain = true := by decide
def e75615112154 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75615112154 : Closed e75615112154 ∧ code e75615112154 = 1175126739930 := by decide
theorem cert_e75615112154 : check e75615112154 [[.under],[.under]] .chain = true := by decide
def e75615112430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75615112430 : Closed e75615112430 ∧ code e75615112430 = 1175126740206 := by decide
theorem cert_e75615112430 : check e75615112430 [[.under],[.under]] .chain = true := by decide
def e75615112438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75615112438 : Closed e75615112438 ∧ code e75615112438 = 1175126740214 := by decide
theorem cert_e75615112438 : check e75615112438 [[.under],[.under]] .chain = true := by decide
def e75615112814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75615112814 : Closed e75615112814 ∧ code e75615112814 = 1175126740590 := by decide
theorem cert_e75615112814 : check e75615112814 [[.under],[.under]] .chain = true := by decide
def e75615112826 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75615112826 : Closed e75615112826 ∧ code e75615112826 = 1175126740602 := by decide
theorem cert_e75615112826 : check e75615112826 [[.under],[.under]] .chain = true := by decide
def e75615113014 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75615113014 : Closed e75615113014 ∧ code e75615113014 = 1175126740790 := by decide
theorem cert_e75615113014 : check e75615113014 [[.under],[.under]] .chain = true := by decide
def e75615113018 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75615113018 : Closed e75615113018 ∧ code e75615113018 = 1175126740794 := by decide
theorem cert_e75615113018 : check e75615113018 [[.under],[.under]] .chain = true := by decide
def e75615701870 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75615701870 : Closed e75615701870 ∧ code e75615701870 = 1175127329646 := by decide
theorem cert_e75615701870 : check e75615701870 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615701878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75615701878 : Closed e75615701878 ∧ code e75615701878 = 1175127329654 := by decide
theorem cert_e75615701878 : check e75615701878 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615701934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75615701934 : Closed e75615701934 ∧ code e75615701934 = 1175127329710 := by decide
theorem cert_e75615701934 : check e75615701934 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615701946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75615701946 : Closed e75615701946 ∧ code e75615701946 = 1175127329722 := by decide
theorem cert_e75615701946 : check e75615701946 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615701974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75615701974 : Closed e75615701974 ∧ code e75615701974 = 1175127329750 := by decide
theorem cert_e75615701974 : check e75615701974 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615701978 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75615701978 : Closed e75615701978 ∧ code e75615701978 = 1175127329754 := by decide
theorem cert_e75615701978 : check e75615701978 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615702254 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75615702254 : Closed e75615702254 ∧ code e75615702254 = 1175127330030 := by decide
theorem cert_e75615702254 : check e75615702254 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615702262 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75615702262 : Closed e75615702262 ∧ code e75615702262 = 1175127330038 := by decide
theorem cert_e75615702262 : check e75615702262 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615702638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75615702638 : Closed e75615702638 ∧ code e75615702638 = 1175127330414 := by decide
theorem cert_e75615702638 : check e75615702638 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615702650 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75615702650 : Closed e75615702650 ∧ code e75615702650 = 1175127330426 := by decide
theorem cert_e75615702650 : check e75615702650 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615702838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75615702838 : Closed e75615702838 ∧ code e75615702838 = 1175127330614 := by decide
theorem cert_e75615702838 : check e75615702838 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75615702842 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75615702842 : Closed e75615702842 ∧ code e75615702842 = 1175127330618 := by decide
theorem cert_e75615702842 : check e75615702842 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e75648511342 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e75648511342 : Closed e75648511342 ∧ code e75648511342 = 1175160139118 := by decide
theorem cert_e75648511342 : check e75648511342 [[.under],[.under]] .three = true := by decide
def e75648511350 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e75648511350 : Closed e75648511350 ∧ code e75648511350 = 1175160139126 := by decide
theorem cert_e75648511350 : check e75648511350 [[.under],[.under]] .three = true := by decide
def e75648511406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e75648511406 : Closed e75648511406 ∧ code e75648511406 = 1175160139182 := by decide
theorem cert_e75648511406 : check e75648511406 [[.under],[.under]] .three = true := by decide
def e75648511418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e75648511418 : Closed e75648511418 ∧ code e75648511418 = 1175160139194 := by decide
theorem cert_e75648511418 : check e75648511418 [[.under],[.under]] .three = true := by decide
def e75648511446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e75648511446 : Closed e75648511446 ∧ code e75648511446 = 1175160139222 := by decide
theorem cert_e75648511446 : check e75648511446 [[.under],[.under]] .three = true := by decide
def e75648511450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e75648511450 : Closed e75648511450 ∧ code e75648511450 = 1175160139226 := by decide
theorem cert_e75648511450 : check e75648511450 [[.under],[.under]] .three = true := by decide
def e75648511662 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e75648511662 : Closed e75648511662 ∧ code e75648511662 = 1175160139438 := by decide
theorem cert_e75648511662 : check e75648511662 [[.under],[.under]] .three = true := by decide
def e75648511674 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e75648511674 : Closed e75648511674 ∧ code e75648511674 = 1175160139450 := by decide
theorem cert_e75648511674 : check e75648511674 [[.under],[.under]] .three = true := by decide
def e75648511722 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e75648511722 : Closed e75648511722 ∧ code e75648511722 = 1175160139498 := by decide
theorem cert_e75648511722 : check e75648511722 [[.under],[.under]] .three = true := by decide
def e75648511830 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e75648511830 : Closed e75648511830 ∧ code e75648511830 = 1175160139606 := by decide
theorem cert_e75648511830 : check e75648511830 [[.under],[.under]] .three = true := by decide
def e75648511834 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e75648511834 : Closed e75648511834 ∧ code e75648511834 = 1175160139610 := by decide
theorem cert_e75648511834 : check e75648511834 [[.under],[.under]] .three = true := by decide
def e75648511850 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e75648511850 : Closed e75648511850 ∧ code e75648511850 = 1175160139626 := by decide
theorem cert_e75648511850 : check e75648511850 [[.under],[.under]] .three = true := by decide
def e75648512878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e75648512878 : Closed e75648512878 ∧ code e75648512878 = 1175160140654 := by decide
theorem cert_e75648512878 : check e75648512878 [[.under],[.under]] .three = true := by decide
def e75648512886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e75648512886 : Closed e75648512886 ∧ code e75648512886 = 1175160140662 := by decide
theorem cert_e75648512886 : check e75648512886 [[.under],[.under]] .three = true := by decide
def e75648512942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e75648512942 : Closed e75648512942 ∧ code e75648512942 = 1175160140718 := by decide
theorem cert_e75648512942 : check e75648512942 [[.under],[.under]] .three = true := by decide
def e75648512954 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e75648512954 : Closed e75648512954 ∧ code e75648512954 = 1175160140730 := by decide
theorem cert_e75648512954 : check e75648512954 [[.under],[.under]] .three = true := by decide
def e75648512982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e75648512982 : Closed e75648512982 ∧ code e75648512982 = 1175160140758 := by decide
theorem cert_e75648512982 : check e75648512982 [[.under],[.under]] .three = true := by decide
def e75648512986 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e75648512986 : Closed e75648512986 ∧ code e75648512986 = 1175160140762 := by decide
theorem cert_e75648512986 : check e75648512986 [[.under],[.under]] .three = true := by decide
def e75648513262 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e75648513262 : Closed e75648513262 ∧ code e75648513262 = 1175160141038 := by decide
theorem cert_e75648513262 : check e75648513262 [[.under],[.under]] .three = true := by decide
def e75648513270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e75648513270 : Closed e75648513270 ∧ code e75648513270 = 1175160141046 := by decide
theorem cert_e75648513270 : check e75648513270 [[.under],[.under]] .three = true := by decide
def e75648513646 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e75648513646 : Closed e75648513646 ∧ code e75648513646 = 1175160141422 := by decide
theorem cert_e75648513646 : check e75648513646 [[.under],[.under]] .three = true := by decide
def e75648513658 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e75648513658 : Closed e75648513658 ∧ code e75648513658 = 1175160141434 := by decide
theorem cert_e75648513658 : check e75648513658 [[.under],[.under]] .three = true := by decide
def e75648513846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e75648513846 : Closed e75648513846 ∧ code e75648513846 = 1175160141622 := by decide
theorem cert_e75648513846 : check e75648513846 [[.under],[.under]] .three = true := by decide
def e75648513850 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e75648513850 : Closed e75648513850 ∧ code e75648513850 = 1175160141626 := by decide
theorem cert_e75648513850 : check e75648513850 [[.under],[.under]] .three = true := by decide
def e75648514478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e75648514478 : Closed e75648514478 ∧ code e75648514478 = 1175160142254 := by decide
theorem cert_e75648514478 : check e75648514478 [[.under],[.under]] .three = true := by decide
def e75648514490 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e75648514490 : Closed e75648514490 ∧ code e75648514490 = 1175160142266 := by decide
theorem cert_e75648514490 : check e75648514490 [[.under],[.under]] .three = true := by decide
def e75648514538 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e75648514538 : Closed e75648514538 ∧ code e75648514538 = 1175160142314 := by decide
theorem cert_e75648514538 : check e75648514538 [[.under],[.under]] .three = true := by decide
def e75648514670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e75648514670 : Closed e75648514670 ∧ code e75648514670 = 1175160142446 := by decide
theorem cert_e75648514670 : check e75648514670 [[.under],[.under]] .three = true := by decide
def e75648514682 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e75648514682 : Closed e75648514682 ∧ code e75648514682 = 1175160142458 := by decide
theorem cert_e75648514682 : check e75648514682 [[.under],[.under]] .three = true := by decide
def e75648514970 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e75648514970 : Closed e75648514970 ∧ code e75648514970 = 1175160142746 := by decide
theorem cert_e75648514970 : check e75648514970 [[.under],[.under]] .three = true := by decide
def e75648515286 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e75648515286 : Closed e75648515286 ∧ code e75648515286 = 1175160143062 := by decide
theorem cert_e75648515286 : check e75648515286 [[.under],[.under]] .three = true := by decide
def e75648515290 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e75648515290 : Closed e75648515290 ∧ code e75648515290 = 1175160143066 := by decide
theorem cert_e75648515290 : check e75648515290 [[.under],[.under]] .three = true := by decide
def e75648515306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e75648515306 : Closed e75648515306 ∧ code e75648515306 = 1175160143082 := by decide
theorem cert_e75648515306 : check e75648515306 [[.under],[.under]] .three = true := by decide
def e75648515382 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e75648515382 : Closed e75648515382 ∧ code e75648515382 = 1175160143158 := by decide
theorem cert_e75648515382 : check e75648515382 [[.under],[.under]] .three = true := by decide
def e75648515386 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e75648515386 : Closed e75648515386 ∧ code e75648515386 = 1175160143162 := by decide
theorem cert_e75648515386 : check e75648515386 [[.under],[.under]] .three = true := by decide
def e75648515482 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e75648515482 : Closed e75648515482 ∧ code e75648515482 = 1175160143258 := by decide
theorem cert_e75648515482 : check e75648515482 [[.under],[.under]] .three = true := by decide
def e75648519022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e75648519022 : Closed e75648519022 ∧ code e75648519022 = 1175160146798 := by decide
theorem cert_e75648519022 : check e75648519022 [[.under],[.under]] .three = true := by decide
def e75648519030 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e75648519030 : Closed e75648519030 ∧ code e75648519030 = 1175160146806 := by decide
theorem cert_e75648519030 : check e75648519030 [[.under],[.under]] .three = true := by decide
def e75648519086 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e75648519086 : Closed e75648519086 ∧ code e75648519086 = 1175160146862 := by decide
theorem cert_e75648519086 : check e75648519086 [[.under],[.under]] .three = true := by decide
def e75648519098 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e75648519098 : Closed e75648519098 ∧ code e75648519098 = 1175160146874 := by decide
theorem cert_e75648519098 : check e75648519098 [[.under],[.under]] .three = true := by decide
def e75648519126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e75648519126 : Closed e75648519126 ∧ code e75648519126 = 1175160146902 := by decide
theorem cert_e75648519126 : check e75648519126 [[.under],[.under]] .three = true := by decide
def e75648519130 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e75648519130 : Closed e75648519130 ∧ code e75648519130 = 1175160146906 := by decide
theorem cert_e75648519130 : check e75648519130 [[.under],[.under]] .three = true := by decide
def e75648519406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e75648519406 : Closed e75648519406 ∧ code e75648519406 = 1175160147182 := by decide
theorem cert_e75648519406 : check e75648519406 [[.under],[.under]] .three = true := by decide
def e75648519414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e75648519414 : Closed e75648519414 ∧ code e75648519414 = 1175160147190 := by decide
theorem cert_e75648519414 : check e75648519414 [[.under],[.under]] .three = true := by decide
def e75648519790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e75648519790 : Closed e75648519790 ∧ code e75648519790 = 1175160147566 := by decide
theorem cert_e75648519790 : check e75648519790 [[.under],[.under]] .three = true := by decide
def e75648519802 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e75648519802 : Closed e75648519802 ∧ code e75648519802 = 1175160147578 := by decide
theorem cert_e75648519802 : check e75648519802 [[.under],[.under]] .three = true := by decide
def e75648519990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e75648519990 : Closed e75648519990 ∧ code e75648519990 = 1175160147766 := by decide
theorem cert_e75648519990 : check e75648519990 [[.under],[.under]] .three = true := by decide
def e75648519994 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e75648519994 : Closed e75648519994 ∧ code e75648519994 = 1175160147770 := by decide
theorem cert_e75648519994 : check e75648519994 [[.under],[.under]] .three = true := by decide
def e75648525742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e75648525742 : Closed e75648525742 ∧ code e75648525742 = 1175160153518 := by decide
theorem cert_e75648525742 : check e75648525742 [[.under],[.under]] .three = true := by decide
def e75648525754 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e75648525754 : Closed e75648525754 ∧ code e75648525754 = 1175160153530 := by decide
theorem cert_e75648525754 : check e75648525754 [[.under],[.under]] .three = true := by decide
def e75648525802 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e75648525802 : Closed e75648525802 ∧ code e75648525802 = 1175160153578 := by decide
theorem cert_e75648525802 : check e75648525802 [[.under],[.under]] .three = true := by decide
def e75648525934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e75648525934 : Closed e75648525934 ∧ code e75648525934 = 1175160153710 := by decide
theorem cert_e75648525934 : check e75648525934 [[.under],[.under]] .three = true := by decide
def e75648525946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e75648525946 : Closed e75648525946 ∧ code e75648525946 = 1175160153722 := by decide
theorem cert_e75648525946 : check e75648525946 [[.under],[.under]] .three = true := by decide
def e75648526234 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e75648526234 : Closed e75648526234 ∧ code e75648526234 = 1175160154010 := by decide
theorem cert_e75648526234 : check e75648526234 [[.under],[.under]] .three = true := by decide
def e75648529110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e75648529110 : Closed e75648529110 ∧ code e75648529110 = 1175160156886 := by decide
theorem cert_e75648529110 : check e75648529110 [[.under],[.under]] .three = true := by decide
def e75648529114 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e75648529114 : Closed e75648529114 ∧ code e75648529114 = 1175160156890 := by decide
theorem cert_e75648529114 : check e75648529114 [[.under],[.under]] .three = true := by decide
def e75648529130 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e75648529130 : Closed e75648529130 ∧ code e75648529130 = 1175160156906 := by decide
theorem cert_e75648529130 : check e75648529130 [[.under],[.under]] .three = true := by decide
def e75648529206 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e75648529206 : Closed e75648529206 ∧ code e75648529206 = 1175160156982 := by decide
theorem cert_e75648529206 : check e75648529206 [[.under],[.under]] .three = true := by decide
def e75648529210 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e75648529210 : Closed e75648529210 ∧ code e75648529210 = 1175160156986 := by decide
theorem cert_e75648529210 : check e75648529210 [[.under],[.under]] .three = true := by decide
def e75648529306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e75648529306 : Closed e75648529306 ∧ code e75648529306 = 1175160157082 := by decide
theorem cert_e75648529306 : check e75648529306 [[.under],[.under]] .three = true := by decide
end Blc.Floor40
