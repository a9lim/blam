import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302796661742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e302796661742 : Closed e302796661742 ∧ code e302796661742 = 1402308289518 := by decide
theorem cert_e302796661742 : check e302796661742 [[],[]] .three = true := by decide
def e302796662494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e302796662494 : Closed e302796662494 ∧ code e302796662494 = 1402308290270 := by decide
theorem cert_e302796662494 : check e302796662494 [[],[]] .three = true := by decide
def e302796662518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e302796662518 : Closed e302796662518 ∧ code e302796662518 = 1402308290294 := by decide
theorem cert_e302796662518 : check e302796662518 [[],[]] .three = true := by decide
def e302796662622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e302796662622 : Closed e302796662622 ∧ code e302796662622 = 1402308290398 := by decide
theorem cert_e302796662622 : check e302796662622 [[],[]] .three = true := by decide
def e302796662638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e302796662638 : Closed e302796662638 ∧ code e302796662638 = 1402308290414 := by decide
theorem cert_e302796662638 : check e302796662638 [[],[]] .smaller = true := by decide
def e302796662646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e302796662646 : Closed e302796662646 ∧ code e302796662646 = 1402308290422 := by decide
theorem cert_e302796662646 : check e302796662646 [[],[]] .smaller = true := by decide
def e302796662650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e302796662650 : Closed e302796662650 ∧ code e302796662650 = 1402308290426 := by decide
theorem cert_e302796662650 : check e302796662650 [[],[]] .three = true := by decide
def e302796662710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e302796662710 : Closed e302796662710 ∧ code e302796662710 = 1402308290486 := by decide
theorem cert_e302796662710 : check e302796662710 [[],[]] .smaller = true := by decide
def e302796662742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e302796662742 : Closed e302796662742 ∧ code e302796662742 = 1402308290518 := by decide
theorem cert_e302796662742 : check e302796662742 [[],[]] .three = true := by decide
def e302796662746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e302796662746 : Closed e302796662746 ∧ code e302796662746 = 1402308290522 := by decide
theorem cert_e302796662746 : check e302796662746 [[],[]] .three = true := by decide
def e302796663262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e302796663262 : Closed e302796663262 ∧ code e302796663262 = 1402308291038 := by decide
theorem cert_e302796663262 : check e302796663262 [[],[]] .three = true := by decide
def e302796663286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e302796663286 : Closed e302796663286 ∧ code e302796663286 = 1402308291062 := by decide
theorem cert_e302796663286 : check e302796663286 [[],[]] .three = true := by decide
def e302796664030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e302796664030 : Closed e302796664030 ∧ code e302796664030 = 1402308291806 := by decide
theorem cert_e302796664030 : check e302796664030 [[],[]] .three = true := by decide
def e302796664046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e302796664046 : Closed e302796664046 ∧ code e302796664046 = 1402308291822 := by decide
theorem cert_e302796664046 : check e302796664046 [[],[]] .smaller = true := by decide
def e302796664054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e302796664054 : Closed e302796664054 ∧ code e302796664054 = 1402308291830 := by decide
theorem cert_e302796664054 : check e302796664054 [[],[]] .smaller = true := by decide
def e302796664058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e302796664058 : Closed e302796664058 ∧ code e302796664058 = 1402308291834 := by decide
theorem cert_e302796664058 : check e302796664058 [[],[]] .three = true := by decide
def e302796664382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 4))))))))
theorem wire_e302796664382 : Closed e302796664382 ∧ code e302796664382 = 1402308292158 := by decide
theorem cert_e302796664382 : check e302796664382 [[],[]] .three = true := by decide
def e302796664438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e302796664438 : Closed e302796664438 ∧ code e302796664438 = 1402308292214 := by decide
theorem cert_e302796664438 : check e302796664438 [[],[]] .smaller = true := by decide
def e302796664606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 3))))))))
theorem wire_e302796664606 : Closed e302796664606 ∧ code e302796664606 = 1402308292382 := by decide
theorem cert_e302796664606 : check e302796664606 [[],[]] .three = true := by decide
def e302796664630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796664630 : Closed e302796664630 ∧ code e302796664630 = 1402308292406 := by decide
theorem cert_e302796664630 : check e302796664630 [[],[]] .three = true := by decide
def e302796664634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796664634 : Closed e302796664634 ∧ code e302796664634 = 1402308292410 := by decide
theorem cert_e302796664634 : check e302796664634 [[],[]] .three = true := by decide
def e302796665310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e302796665310 : Closed e302796665310 ∧ code e302796665310 = 1402308293086 := by decide
theorem cert_e302796665310 : check e302796665310 [[],[]] .three = true := by decide
def e302796665326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e302796665326 : Closed e302796665326 ∧ code e302796665326 = 1402308293102 := by decide
theorem cert_e302796665326 : check e302796665326 [[],[]] .smaller = true := by decide
def e302796665334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e302796665334 : Closed e302796665334 ∧ code e302796665334 = 1402308293110 := by decide
theorem cert_e302796665334 : check e302796665334 [[],[]] .three = true := by decide
def e302796665694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e302796665694 : Closed e302796665694 ∧ code e302796665694 = 1402308293470 := by decide
theorem cert_e302796665694 : check e302796665694 [[],[]] .three = true := by decide
def e302796665710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302796665710 : Closed e302796665710 ∧ code e302796665710 = 1402308293486 := by decide
theorem cert_e302796665710 : check e302796665710 [[],[]] .smaller = true := by decide
def e302796665718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e302796665718 : Closed e302796665718 ∧ code e302796665718 = 1402308293494 := by decide
theorem cert_e302796665718 : check e302796665718 [[],[]] .smaller = true := by decide
def e302796665722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302796665722 : Closed e302796665722 ∧ code e302796665722 = 1402308293498 := by decide
theorem cert_e302796665722 : check e302796665722 [[],[]] .three = true := by decide
def e302796665774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302796665774 : Closed e302796665774 ∧ code e302796665774 = 1402308293550 := by decide
theorem cert_e302796665774 : check e302796665774 [[],[]] .smaller = true := by decide
def e302796665786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e302796665786 : Closed e302796665786 ∧ code e302796665786 = 1402308293562 := by decide
theorem cert_e302796665786 : check e302796665786 [[],[]] .smaller = true := by decide
def e302796665814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e302796665814 : Closed e302796665814 ∧ code e302796665814 = 1402308293590 := by decide
theorem cert_e302796665814 : check e302796665814 [[],[]] .smaller = true := by decide
def e302796665818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e302796665818 : Closed e302796665818 ∧ code e302796665818 = 1402308293594 := by decide
theorem cert_e302796665818 : check e302796665818 [[],[]] .smaller = true := by decide
def e302796665834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302796665834 : Closed e302796665834 ∧ code e302796665834 = 1402308293610 := by decide
theorem cert_e302796665834 : check e302796665834 [[],[]] .three = true := by decide
def e302796666078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e302796666078 : Closed e302796666078 ∧ code e302796666078 = 1402308293854 := by decide
theorem cert_e302796666078 : check e302796666078 [[],[]] .three = true := by decide
def e302796666094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e302796666094 : Closed e302796666094 ∧ code e302796666094 = 1402308293870 := by decide
theorem cert_e302796666094 : check e302796666094 [[],[]] .smaller = true := by decide
def e302796666102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e302796666102 : Closed e302796666102 ∧ code e302796666102 = 1402308293878 := by decide
theorem cert_e302796666102 : check e302796666102 [[],[]] .smaller = true := by decide
def e302796666106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e302796666106 : Closed e302796666106 ∧ code e302796666106 = 1402308293882 := by decide
theorem cert_e302796666106 : check e302796666106 [[],[]] .three = true := by decide
def e302796666430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 4))))))))
theorem wire_e302796666430 : Closed e302796666430 ∧ code e302796666430 = 1402308294206 := by decide
theorem cert_e302796666430 : check e302796666430 [[],[]] .three = true := by decide
def e302796666478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302796666478 : Closed e302796666478 ∧ code e302796666478 = 1402308294254 := by decide
theorem cert_e302796666478 : check e302796666478 [[],[]] .smaller = true := by decide
def e302796666490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302796666490 : Closed e302796666490 ∧ code e302796666490 = 1402308294266 := by decide
theorem cert_e302796666490 : check e302796666490 [[],[]] .smaller = true := by decide
def e302796666654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))))))))
theorem wire_e302796666654 : Closed e302796666654 ∧ code e302796666654 = 1402308294430 := by decide
theorem cert_e302796666654 : check e302796666654 [[],[]] .smaller = true := by decide
def e302796666678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796666678 : Closed e302796666678 ∧ code e302796666678 = 1402308294454 := by decide
theorem cert_e302796666678 : check e302796666678 [[],[]] .smaller = true := by decide
def e302796666682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796666682 : Closed e302796666682 ∧ code e302796666682 = 1402308294458 := by decide
theorem cert_e302796666682 : check e302796666682 [[],[]] .smaller = true := by decide
def e302796666766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 2))))))))
theorem wire_e302796666766 : Closed e302796666766 ∧ code e302796666766 = 1402308294542 := by decide
theorem cert_e302796666766 : check e302796666766 [[],[]] .three = true := by decide
def e302796666778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796666778 : Closed e302796666778 ∧ code e302796666778 = 1402308294554 := by decide
theorem cert_e302796666778 : check e302796666778 [[],[]] .three = true := by decide
def e302796667102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e302796667102 : Closed e302796667102 ∧ code e302796667102 = 1402308294878 := by decide
theorem cert_e302796667102 : check e302796667102 [[],[]] .three = true := by decide
def e302796667118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e302796667118 : Closed e302796667118 ∧ code e302796667118 = 1402308294894 := by decide
theorem cert_e302796667118 : check e302796667118 [[],[]] .smaller = true := by decide
def e302796667126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e302796667126 : Closed e302796667126 ∧ code e302796667126 = 1402308294902 := by decide
theorem cert_e302796667126 : check e302796667126 [[],[]] .smaller = true := by decide
def e302796667130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e302796667130 : Closed e302796667130 ∧ code e302796667130 = 1402308294906 := by decide
theorem cert_e302796667130 : check e302796667130 [[],[]] .three = true := by decide
def e302796667318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e302796667318 : Closed e302796667318 ∧ code e302796667318 = 1402308295094 := by decide
theorem cert_e302796667318 : check e302796667318 [[],[]] .smaller = true := by decide
def e302796667350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e302796667350 : Closed e302796667350 ∧ code e302796667350 = 1402308295126 := by decide
theorem cert_e302796667350 : check e302796667350 [[],[]] .smaller = true := by decide
def e302796667354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e302796667354 : Closed e302796667354 ∧ code e302796667354 = 1402308295130 := by decide
theorem cert_e302796667354 : check e302796667354 [[],[]] .smaller = true := by decide
def e302796667454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 4))))))))
theorem wire_e302796667454 : Closed e302796667454 ∧ code e302796667454 = 1402308295230 := by decide
theorem cert_e302796667454 : check e302796667454 [[],[]] .three = true := by decide
def e302796667510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e302796667510 : Closed e302796667510 ∧ code e302796667510 = 1402308295286 := by decide
theorem cert_e302796667510 : check e302796667510 [[],[]] .smaller = true := by decide
def e302796667678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))))))))
theorem wire_e302796667678 : Closed e302796667678 ∧ code e302796667678 = 1402308295454 := by decide
theorem cert_e302796667678 : check e302796667678 [[],[]] .smaller = true := by decide
def e302796667702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796667702 : Closed e302796667702 ∧ code e302796667702 = 1402308295478 := by decide
theorem cert_e302796667702 : check e302796667702 [[],[]] .smaller = true := by decide
def e302796667706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796667706 : Closed e302796667706 ∧ code e302796667706 = 1402308295482 := by decide
theorem cert_e302796667706 : check e302796667706 [[],[]] .smaller = true := by decide
def e302796667790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))))
theorem wire_e302796667790 : Closed e302796667790 ∧ code e302796667790 = 1402308295566 := by decide
theorem cert_e302796667790 : check e302796667790 [[],[]] .smaller = true := by decide
def e302796667846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.var 1))))))))
theorem wire_e302796667846 : Closed e302796667846 ∧ code e302796667846 = 1402308295622 := by decide
theorem cert_e302796667846 : check e302796667846 [[],[]] .three = true := by decide
def e302796667870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 3)))))))
theorem wire_e302796667870 : Closed e302796667870 ∧ code e302796667870 = 1402308295646 := by decide
theorem cert_e302796667870 : check e302796667870 [[],[]] .three = true := by decide
def e302796668014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302796668014 : Closed e302796668014 ∧ code e302796668014 = 1402308295790 := by decide
theorem cert_e302796668014 : check e302796668014 [[],[]] .three = true := by decide
def e302796668022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e302796668022 : Closed e302796668022 ∧ code e302796668022 = 1402308295798 := by decide
theorem cert_e302796668022 : check e302796668022 [[],[]] .three = true := by decide
def e302796668026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302796668026 : Closed e302796668026 ∧ code e302796668026 = 1402308295802 := by decide
theorem cert_e302796668026 : check e302796668026 [[],[]] .three = true := by decide
def e302796668118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e302796668118 : Closed e302796668118 ∧ code e302796668118 = 1402308295894 := by decide
theorem cert_e302796668118 : check e302796668118 [[],[]] .three = true := by decide
def e302796668122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302796668122 : Closed e302796668122 ∧ code e302796668122 = 1402308295898 := by decide
theorem cert_e302796668122 : check e302796668122 [[],[]] .three = true := by decide
def e302796668138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302796668138 : Closed e302796668138 ∧ code e302796668138 = 1402308295914 := by decide
theorem cert_e302796668138 : check e302796668138 [[],[]] .three = true := by decide
def e302796668190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302796668190 : Closed e302796668190 ∧ code e302796668190 = 1402308295966 := by decide
theorem cert_e302796668190 : check e302796668190 [[],[]] .three = true := by decide
def e302796668214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796668214 : Closed e302796668214 ∧ code e302796668214 = 1402308295990 := by decide
theorem cert_e302796668214 : check e302796668214 [[],[]] .three = true := by decide
def e302796668218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796668218 : Closed e302796668218 ∧ code e302796668218 = 1402308295994 := by decide
theorem cert_e302796668218 : check e302796668218 [[],[]] .three = true := by decide
def e302796668302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 2))))))))
theorem wire_e302796668302 : Closed e302796668302 ∧ code e302796668302 = 1402308296078 := by decide
theorem cert_e302796668302 : check e302796668302 [[],[]] .three = true := by decide
def e302796668314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796668314 : Closed e302796668314 ∧ code e302796668314 = 1402308296090 := by decide
theorem cert_e302796668314 : check e302796668314 [[],[]] .three = true := by decide
def e302796668358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302796668358 : Closed e302796668358 ∧ code e302796668358 = 1402308296134 := by decide
theorem cert_e302796668358 : check e302796668358 [[],[]] .three = true := by decide
def e302796668382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 3)))))))
theorem wire_e302796668382 : Closed e302796668382 ∧ code e302796668382 = 1402308296158 := by decide
theorem cert_e302796668382 : check e302796668382 [[],[]] .three = true := by decide
def e302796668398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 2)))))))
theorem wire_e302796668398 : Closed e302796668398 ∧ code e302796668398 = 1402308296174 := by decide
theorem cert_e302796668398 : check e302796668398 [[],[]] .three = true := by decide
def e302796670910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e302796670910 : Closed e302796670910 ∧ code e302796670910 = 1402308298686 := by decide
theorem cert_e302796670910 : check e302796670910 [[],[]] .three = true := by decide
def e302796670958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e302796670958 : Closed e302796670958 ∧ code e302796670958 = 1402308298734 := by decide
theorem cert_e302796670958 : check e302796670958 [[],[]] .three = true := by decide
def e302796674782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302796674782 : Closed e302796674782 ∧ code e302796674782 = 1402308302558 := by decide
theorem cert_e302796674782 : check e302796674782 [[],[]] .three = true := by decide
def e302796674806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302796674806 : Closed e302796674806 ∧ code e302796674806 = 1402308302582 := by decide
theorem cert_e302796674806 : check e302796674806 [[],[]] .three = true := by decide
def e302796674910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302796674910 : Closed e302796674910 ∧ code e302796674910 = 1402308302686 := by decide
theorem cert_e302796674910 : check e302796674910 [[],[]] .three = true := by decide
def e302796674926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e302796674926 : Closed e302796674926 ∧ code e302796674926 = 1402308302702 := by decide
theorem cert_e302796674926 : check e302796674926 [[],[]] .smaller = true := by decide
def e302796674934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e302796674934 : Closed e302796674934 ∧ code e302796674934 = 1402308302710 := by decide
theorem cert_e302796674934 : check e302796674934 [[],[]] .smaller = true := by decide
def e302796674938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302796674938 : Closed e302796674938 ∧ code e302796674938 = 1402308302714 := by decide
theorem cert_e302796674938 : check e302796674938 [[],[]] .three = true := by decide
def e302796674998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e302796674998 : Closed e302796674998 ∧ code e302796674998 = 1402308302774 := by decide
theorem cert_e302796674998 : check e302796674998 [[],[]] .smaller = true := by decide
def e302796675030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302796675030 : Closed e302796675030 ∧ code e302796675030 = 1402308302806 := by decide
theorem cert_e302796675030 : check e302796675030 [[],[]] .three = true := by decide
def e302796675034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302796675034 : Closed e302796675034 ∧ code e302796675034 = 1402308302810 := by decide
theorem cert_e302796675034 : check e302796675034 [[],[]] .three = true := by decide
def e302796675550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302796675550 : Closed e302796675550 ∧ code e302796675550 = 1402308303326 := by decide
theorem cert_e302796675550 : check e302796675550 [[],[]] .three = true := by decide
def e302796675574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302796675574 : Closed e302796675574 ∧ code e302796675574 = 1402308303350 := by decide
theorem cert_e302796675574 : check e302796675574 [[],[]] .three = true := by decide
def e302796676318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302796676318 : Closed e302796676318 ∧ code e302796676318 = 1402308304094 := by decide
theorem cert_e302796676318 : check e302796676318 [[],[]] .three = true := by decide
def e302796676334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e302796676334 : Closed e302796676334 ∧ code e302796676334 = 1402308304110 := by decide
theorem cert_e302796676334 : check e302796676334 [[],[]] .smaller = true := by decide
def e302796676342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e302796676342 : Closed e302796676342 ∧ code e302796676342 = 1402308304118 := by decide
theorem cert_e302796676342 : check e302796676342 [[],[]] .smaller = true := by decide
def e302796676346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302796676346 : Closed e302796676346 ∧ code e302796676346 = 1402308304122 := by decide
theorem cert_e302796676346 : check e302796676346 [[],[]] .three = true := by decide
def e302796676670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e302796676670 : Closed e302796676670 ∧ code e302796676670 = 1402308304446 := by decide
theorem cert_e302796676670 : check e302796676670 [[],[]] .three = true := by decide
def e302796676726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e302796676726 : Closed e302796676726 ∧ code e302796676726 = 1402308304502 := by decide
theorem cert_e302796676726 : check e302796676726 [[],[]] .smaller = true := by decide
def e302796676894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e302796676894 : Closed e302796676894 ∧ code e302796676894 = 1402308304670 := by decide
theorem cert_e302796676894 : check e302796676894 [[],[]] .three = true := by decide
def e302796676918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796676918 : Closed e302796676918 ∧ code e302796676918 = 1402308304694 := by decide
theorem cert_e302796676918 : check e302796676918 [[],[]] .three = true := by decide
def e302796676922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796676922 : Closed e302796676922 ∧ code e302796676922 = 1402308304698 := by decide
theorem cert_e302796676922 : check e302796676922 [[],[]] .three = true := by decide
def e302796686270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e302796686270 : Closed e302796686270 ∧ code e302796686270 = 1402308314046 := by decide
theorem cert_e302796686270 : check e302796686270 [[],[]] .three = true := by decide
def e302796686302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e302796686302 : Closed e302796686302 ∧ code e302796686302 = 1402308314078 := by decide
theorem cert_e302796686302 : check e302796686302 [[],[]] .smaller = true := by decide
def e302796686318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e302796686318 : Closed e302796686318 ∧ code e302796686318 = 1402308314094 := by decide
theorem cert_e302796686318 : check e302796686318 [[],[]] .smaller = true := by decide
def e302796686326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e302796686326 : Closed e302796686326 ∧ code e302796686326 = 1402308314102 := by decide
theorem cert_e302796686326 : check e302796686326 [[],[]] .three = true := by decide
def e302796688222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e302796688222 : Closed e302796688222 ∧ code e302796688222 = 1402308315998 := by decide
theorem cert_e302796688222 : check e302796688222 [[],[]] .three = true := by decide
def e302796688238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302796688238 : Closed e302796688238 ∧ code e302796688238 = 1402308316014 := by decide
theorem cert_e302796688238 : check e302796688238 [[],[]] .smaller = true := by decide
def e302796688246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302796688246 : Closed e302796688246 ∧ code e302796688246 = 1402308316022 := by decide
theorem cert_e302796688246 : check e302796688246 [[],[]] .smaller = true := by decide
def e302796688250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e302796688250 : Closed e302796688250 ∧ code e302796688250 = 1402308316026 := by decide
theorem cert_e302796688250 : check e302796688250 [[],[]] .three = true := by decide
def e302796688302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302796688302 : Closed e302796688302 ∧ code e302796688302 = 1402308316078 := by decide
theorem cert_e302796688302 : check e302796688302 [[],[]] .smaller = true := by decide
def e302796688314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302796688314 : Closed e302796688314 ∧ code e302796688314 = 1402308316090 := by decide
theorem cert_e302796688314 : check e302796688314 [[],[]] .smaller = true := by decide
def e302796688342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302796688342 : Closed e302796688342 ∧ code e302796688342 = 1402308316118 := by decide
theorem cert_e302796688342 : check e302796688342 [[],[]] .smaller = true := by decide
def e302796688346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302796688346 : Closed e302796688346 ∧ code e302796688346 = 1402308316122 := by decide
theorem cert_e302796688346 : check e302796688346 [[],[]] .smaller = true := by decide
def e302796688362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e302796688362 : Closed e302796688362 ∧ code e302796688362 = 1402308316138 := by decide
theorem cert_e302796688362 : check e302796688362 [[],[]] .three = true := by decide
def e302796688606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e302796688606 : Closed e302796688606 ∧ code e302796688606 = 1402308316382 := by decide
theorem cert_e302796688606 : check e302796688606 [[],[]] .three = true := by decide
def e302796688622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302796688622 : Closed e302796688622 ∧ code e302796688622 = 1402308316398 := by decide
theorem cert_e302796688622 : check e302796688622 [[],[]] .smaller = true := by decide
def e302796688630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302796688630 : Closed e302796688630 ∧ code e302796688630 = 1402308316406 := by decide
theorem cert_e302796688630 : check e302796688630 [[],[]] .smaller = true := by decide
def e302796688634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e302796688634 : Closed e302796688634 ∧ code e302796688634 = 1402308316410 := by decide
theorem cert_e302796688634 : check e302796688634 [[],[]] .three = true := by decide
def e302796688958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e302796688958 : Closed e302796688958 ∧ code e302796688958 = 1402308316734 := by decide
theorem cert_e302796688958 : check e302796688958 [[],[]] .three = true := by decide
def e302796689006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302796689006 : Closed e302796689006 ∧ code e302796689006 = 1402308316782 := by decide
theorem cert_e302796689006 : check e302796689006 [[],[]] .smaller = true := by decide
def e302796689018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302796689018 : Closed e302796689018 ∧ code e302796689018 = 1402308316794 := by decide
theorem cert_e302796689018 : check e302796689018 [[],[]] .smaller = true := by decide
def e302796689182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e302796689182 : Closed e302796689182 ∧ code e302796689182 = 1402308316958 := by decide
theorem cert_e302796689182 : check e302796689182 [[],[]] .smaller = true := by decide
def e302796689206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796689206 : Closed e302796689206 ∧ code e302796689206 = 1402308316982 := by decide
theorem cert_e302796689206 : check e302796689206 [[],[]] .smaller = true := by decide
def e302796689210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796689210 : Closed e302796689210 ∧ code e302796689210 = 1402308316986 := by decide
theorem cert_e302796689210 : check e302796689210 [[],[]] .smaller = true := by decide
def e302796689294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e302796689294 : Closed e302796689294 ∧ code e302796689294 = 1402308317070 := by decide
theorem cert_e302796689294 : check e302796689294 [[],[]] .three = true := by decide
def e302796689306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796689306 : Closed e302796689306 ∧ code e302796689306 = 1402308317082 := by decide
theorem cert_e302796689306 : check e302796689306 [[],[]] .three = true := by decide
def e302796693998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e302796693998 : Closed e302796693998 ∧ code e302796693998 = 1402308321774 := by decide
theorem cert_e302796693998 : check e302796693998 [[],[]] .smaller = true := by decide
def e302796694966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e302796694966 : Closed e302796694966 ∧ code e302796694966 = 1402308322742 := by decide
theorem cert_e302796694966 : check e302796694966 [[],[]] .smaller = true := by decide
def e302796694998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e302796694998 : Closed e302796694998 ∧ code e302796694998 = 1402308322774 := by decide
theorem cert_e302796694998 : check e302796694998 [[],[]] .smaller = true := by decide
def e302796695002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e302796695002 : Closed e302796695002 ∧ code e302796695002 = 1402308322778 := by decide
theorem cert_e302796695002 : check e302796695002 [[],[]] .smaller = true := by decide
def e302796695102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e302796695102 : Closed e302796695102 ∧ code e302796695102 = 1402308322878 := by decide
theorem cert_e302796695102 : check e302796695102 [[],[]] .three = true := by decide
def e302796695158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e302796695158 : Closed e302796695158 ∧ code e302796695158 = 1402308322934 := by decide
theorem cert_e302796695158 : check e302796695158 [[],[]] .smaller = true := by decide
def e302796695326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302796695326 : Closed e302796695326 ∧ code e302796695326 = 1402308323102 := by decide
theorem cert_e302796695326 : check e302796695326 [[],[]] .smaller = true := by decide
def e302796695350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796695350 : Closed e302796695350 ∧ code e302796695350 = 1402308323126 := by decide
theorem cert_e302796695350 : check e302796695350 [[],[]] .smaller = true := by decide
def e302796695354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796695354 : Closed e302796695354 ∧ code e302796695354 = 1402308323130 := by decide
theorem cert_e302796695354 : check e302796695354 [[],[]] .smaller = true := by decide
def e302796695438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302796695438 : Closed e302796695438 ∧ code e302796695438 = 1402308323214 := by decide
theorem cert_e302796695438 : check e302796695438 [[],[]] .smaller = true := by decide
def e302796695494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e302796695494 : Closed e302796695494 ∧ code e302796695494 = 1402308323270 := by decide
theorem cert_e302796695494 : check e302796695494 [[],[]] .three = true := by decide
def e302796695518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 3))))))))
theorem wire_e302796695518 : Closed e302796695518 ∧ code e302796695518 = 1402308323294 := by decide
theorem cert_e302796695518 : check e302796695518 [[],[]] .three = true := by decide
def e302796697838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e302796697838 : Closed e302796697838 ∧ code e302796697838 = 1402308325614 := by decide
theorem cert_e302796697838 : check e302796697838 [[],[]] .three = true := by decide
def e302796697846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e302796697846 : Closed e302796697846 ∧ code e302796697846 = 1402308325622 := by decide
theorem cert_e302796697846 : check e302796697846 [[],[]] .three = true := by decide
def e302796698326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302796698326 : Closed e302796698326 ∧ code e302796698326 = 1402308326102 := by decide
theorem cert_e302796698326 : check e302796698326 [[],[]] .three = true := by decide
def e302796698330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302796698330 : Closed e302796698330 ∧ code e302796698330 = 1402308326106 := by decide
theorem cert_e302796698330 : check e302796698330 [[],[]] .three = true := by decide
def e302796698346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302796698346 : Closed e302796698346 ∧ code e302796698346 = 1402308326122 := by decide
theorem cert_e302796698346 : check e302796698346 [[],[]] .three = true := by decide
def e302796698398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302796698398 : Closed e302796698398 ∧ code e302796698398 = 1402308326174 := by decide
theorem cert_e302796698398 : check e302796698398 [[],[]] .three = true := by decide
def e302796698422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796698422 : Closed e302796698422 ∧ code e302796698422 = 1402308326198 := by decide
theorem cert_e302796698422 : check e302796698422 [[],[]] .three = true := by decide
def e302796698426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796698426 : Closed e302796698426 ∧ code e302796698426 = 1402308326202 := by decide
theorem cert_e302796698426 : check e302796698426 [[],[]] .three = true := by decide
def e302796698510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e302796698510 : Closed e302796698510 ∧ code e302796698510 = 1402308326286 := by decide
theorem cert_e302796698510 : check e302796698510 [[],[]] .three = true := by decide
def e302796698522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796698522 : Closed e302796698522 ∧ code e302796698522 = 1402308326298 := by decide
theorem cert_e302796698522 : check e302796698522 [[],[]] .three = true := by decide
def e302796698566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302796698566 : Closed e302796698566 ∧ code e302796698566 = 1402308326342 := by decide
theorem cert_e302796698566 : check e302796698566 [[],[]] .three = true := by decide
def e302796698590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 3))))))))
theorem wire_e302796698590 : Closed e302796698590 ∧ code e302796698590 = 1402308326366 := by decide
theorem cert_e302796698590 : check e302796698590 [[],[]] .three = true := by decide
def e302796698606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 2))))))))
theorem wire_e302796698606 : Closed e302796698606 ∧ code e302796698606 = 1402308326382 := by decide
theorem cert_e302796698606 : check e302796698606 [[],[]] .three = true := by decide
def e302796705502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e302796705502 : Closed e302796705502 ∧ code e302796705502 = 1402308333278 := by decide
theorem cert_e302796705502 : check e302796705502 [[],[]] .three = true := by decide
def e302796705518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e302796705518 : Closed e302796705518 ∧ code e302796705518 = 1402308333294 := by decide
theorem cert_e302796705518 : check e302796705518 [[],[]] .smaller = true := by decide
def e302796705526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e302796705526 : Closed e302796705526 ∧ code e302796705526 = 1402308333302 := by decide
theorem cert_e302796705526 : check e302796705526 [[],[]] .smaller = true := by decide
def e302796705530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 4)))) (.var 0)))))))
theorem wire_e302796705530 : Closed e302796705530 ∧ code e302796705530 = 1402308333306 := by decide
theorem cert_e302796705530 : check e302796705530 [[],[]] .three = true := by decide
def e302796705646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e302796705646 : Closed e302796705646 ∧ code e302796705646 = 1402308333422 := by decide
theorem cert_e302796705646 : check e302796705646 [[],[]] .smaller = true := by decide
def e302796705658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e302796705658 : Closed e302796705658 ∧ code e302796705658 = 1402308333434 := by decide
theorem cert_e302796705658 : check e302796705658 [[],[]] .smaller = true := by decide
def e302796705718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e302796705718 : Closed e302796705718 ∧ code e302796705718 = 1402308333494 := by decide
theorem cert_e302796705718 : check e302796705718 [[],[]] .smaller = true := by decide
def e302796705722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e302796705722 : Closed e302796705722 ∧ code e302796705722 = 1402308333498 := by decide
theorem cert_e302796705722 : check e302796705722 [[],[]] .smaller = true := by decide
def e302796705754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 1)))) (.var 0)))))))
theorem wire_e302796705754 : Closed e302796705754 ∧ code e302796705754 = 1402308333530 := by decide
theorem cert_e302796705754 : check e302796705754 [[],[]] .three = true := by decide
def e302796708318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e302796708318 : Closed e302796708318 ∧ code e302796708318 = 1402308336094 := by decide
theorem cert_e302796708318 : check e302796708318 [[],[]] .three = true := by decide
def e302796708334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e302796708334 : Closed e302796708334 ∧ code e302796708334 = 1402308336110 := by decide
theorem cert_e302796708334 : check e302796708334 [[],[]] .smaller = true := by decide
def e302796708342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e302796708342 : Closed e302796708342 ∧ code e302796708342 = 1402308336118 := by decide
theorem cert_e302796708342 : check e302796708342 [[],[]] .three = true := by decide
def e302796709086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e302796709086 : Closed e302796709086 ∧ code e302796709086 = 1402308336862 := by decide
theorem cert_e302796709086 : check e302796709086 [[],[]] .three = true := by decide
def e302796709114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e302796709114 : Closed e302796709114 ∧ code e302796709114 = 1402308336890 := by decide
theorem cert_e302796709114 : check e302796709114 [[],[]] .three = true := by decide
end Blc.Floor40
