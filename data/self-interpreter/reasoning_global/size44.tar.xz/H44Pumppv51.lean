import H44Pumppv50
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3664 : R t3664 t1 := result (f := t3661) (a := t3663) (u := t3661) (v := t3667) (refl t3661) (awb t0 t3658 t3663 t3665 (refl _)) pv3667
theorem pv3662 : R t3662 t1 := result (f := t0) (a := t3661) (u := t0) (v := t3664) (refl t0) (aw (rh t3661)) pv3664
theorem pv3659 : R t3659 t1 := result (f := t2) (a := t3658) (u := t2) (v := t3662) (refl t2) (aw (ra t0 t3658)) pv3662
theorem pv3660 : R t3660 t1 := result (f := t3659) (a := t3631) (u := t1) (v := t3631) pv3659 (aw (ri t3631)) pv3631
theorem pv3651 : R t3651 t1 := result (f := t3647) (a := t3650) (u := t3634) (v := t3660) pv3647 (awb t2 t3631 t3650 t3658 (refl _)) pv3660
theorem pv3648 : R t3648 t1 := result (f := t0) (a := t3647) (u := t0) (v := t3651) (refl t0) (aw (rh t3647)) pv3651
theorem pv3649 : R t3649 t3634 := result (f := t3648) (a := t3634) (u := t1) (v := t3634) pv3648 (aw (ri t3634)) (refl t3634)
theorem pv3646 : R t3646 t3634 := result (f := t3636) (a := t3645) (u := t3636) (v := t3649) (refl t3636) (awb t0 t3634 t3645 t3647 (refl _)) pv3649
theorem pv3640 : R t3640 t3634 := result (f := t3638) (a := t1) (u := t3638) (v := t3646) (refl t3638) (aw (ra t3636 t1)) pv3646
theorem pv3766 : R t3766 t3765 := result (f := t1) (a := t3765) (u := t1) (v := t3765) (refl t1) (aw (ri t3765)) (refl t3765)
theorem pv3764 : R t3764 t3765 := result (f := t22) (a := t3743) (u := t24) (v := t3766) pv22 (aw (ra t1 t3743)) pv3766
theorem pv3762 : R t3762 t3765 := result (f := t3746) (a := t1) (u := t3746) (v := t3764) (refl t3746) (awb t0 t3743 t1 t1 (cI)) pv3764
theorem pv3793 : R t3793 t3792 := result (f := t1) (a := t3792) (u := t1) (v := t3792) (refl t1) (aw (ri t3792)) (refl t3792)
theorem pv3791 : R t3791 t3792 := result (f := t22) (a := t3770) (u := t24) (v := t3793) pv22 (aw (ra t1 t3770)) pv3793
theorem pv3789 : R t3789 t3792 := result (f := t3773) (a := t1) (u := t3773) (v := t3791) (refl t3773) (awb t0 t3770 t1 t1 (cI)) pv3791
theorem pv3795 : R t3795 t1 := result (f := t3640) (a := t1) (u := t3634) (v := t3712) pv3640 (awb t2 t3631 t1 t1 (cI)) pv3712
theorem pv3796 : R t3796 t1 := result (f := t3795) (a := t1) (u := t1) (v := t1) pv3795 (aw (ri t1)) (refl t1)
theorem pv3770 : R t3770 t1 := result (f := t3768) (a := t1) (u := t3768) (v := t3796) (refl t3768) (awb t3640 t1 t1 t1 (cI)) pv3796
theorem pv3794 : R t3794 t1 := result (f := t28) (a := t3770) (u := t1) (v := t3770) pv28 (aw (ri t3770)) pv3770
theorem pv3790 : R t3790 t1 := result (f := t3789) (a := t1) (u := t3792) (v := t3794) pv3789 (awb t1 t3770 t1 t1 (cI)) pv3794
theorem pv3784 : R t3784 t1 := result (f := t3782) (a := t1) (u := t3782) (v := t3790) (refl t3782) (awb t3773 t1 t1 t1 (cI)) pv3790
theorem pv3788 : R t3788 t3787 := result (f := t3784) (a := t3787) (u := t1) (v := t3787) pv3784 (aw (ri t3787)) (refl t3787)
theorem pv3785 : R t3785 t3787 := result (f := t0) (a := t3784) (u := t0) (v := t3788) (refl t0) (aw (rh t3784)) pv3788
theorem pv3798 : R t3798 t3797 := result (f := t3784) (a := t3797) (u := t1) (v := t3797) pv3784 (aw (ri t3797)) (refl t3797)
theorem pv3786 : R t3786 t3797 := result (f := t3785) (a := t3770) (u := t3787) (v := t3798) pv3785 (aw (ra t3784 t3770)) pv3798
theorem pv3783 : R t3783 t3797 := result (f := t3773) (a := t3782) (u := t3773) (v := t3786) (refl t3773) (awb t0 t3770 t3782 t3784 (refl _)) pv3786
theorem pv3777 : R t3777 t3797 := result (f := t3775) (a := t1) (u := t3775) (v := t3783) (refl t3775) (aw (ra t3773 t1)) pv3783
theorem pv3809 : R t3809 t1 := result (f := t3784) (a := t1) (u := t1) (v := t1) pv3784 (aw (ri t1)) (refl t1)
theorem pv3810 : R t3810 t1 := result (f := t3809) (a := t3770) (u := t1) (v := t3770) pv3809 (aw (ri t3770)) pv3770
theorem pv3807 : R t3807 t1 := result (f := t3777) (a := t1) (u := t3797) (v := t3810) pv3777 (awb t3784 t3770 t1 t1 (cI)) pv3810
theorem pv3808 : R t3808 t1 := result (f := t3807) (a := t1) (u := t1) (v := t1) pv3807 (aw (ri t1)) (refl t1)
theorem pv3804 : R t3804 t1 := result (f := t3802) (a := t1) (u := t3802) (v := t3808) (refl t3802) (awb t3777 t1 t1 t1 (cI)) pv3808
theorem pv3805 : R t3805 t1 := result (f := t3784) (a := t3804) (u := t1) (v := t3804) pv3784 (aw (ri t3804)) pv3804
theorem pv3806 : R t3806 t1 := result (f := t3805) (a := t3770) (u := t1) (v := t3770) pv3805 (aw (ri t3770)) pv3770
theorem pv3803 : R t3803 t1 := result (f := t3777) (a := t3802) (u := t3797) (v := t3806) pv3777 (awb t3784 t3770 t3802 t3804 (refl _)) pv3806
theorem pv3799 : R t3799 t1 := result (f := t3780) (a := t1) (u := t3780) (v := t3803) (refl t3780) (aw (ra t3777 t1)) pv3803
theorem pv3800 : R t3800 t1 := result (f := t3784) (a := t3799) (u := t1) (v := t3799) pv3784 (aw (ri t3799)) pv3799
theorem pv3801 : R t3801 t1 := result (f := t3800) (a := t3770) (u := t1) (v := t3770) pv3800 (aw (ri t3770)) pv3770
theorem pv3781 : R t3781 t1 := result (f := t3777) (a := t3780) (u := t3797) (v := t3801) pv3777 (awb t3784 t3770 t3780 t3799 (refl _)) pv3801
theorem pv3778 : R t3778 t1 := result (f := t0) (a := t3777) (u := t0) (v := t3781) (refl t0) (aw (rh t3777)) pv3781
theorem pv3779 : R t3779 t1 := result (f := t3778) (a := t3770) (u := t1) (v := t3770) pv3778 (aw (ri t3770)) pv3770
theorem pv3776 : R t3776 t1 := result (f := t3773) (a := t3775) (u := t3773) (v := t3779) (refl t3773) (awb t0 t3770 t3775 t3777 (refl _)) pv3779
theorem pv3774 : R t3774 t1 := result (f := t0) (a := t3773) (u := t0) (v := t3776) (refl t0) (aw (rh t3773)) pv3776
theorem pv3771 : R t3771 t1 := result (f := t2) (a := t3770) (u := t2) (v := t3774) (refl t2) (aw (ra t0 t3770)) pv3774
theorem pv3772 : R t3772 t1 := result (f := t3771) (a := t3631) (u := t1) (v := t3631) pv3771 (aw (ri t3631)) pv3631
theorem pv3769 : R t3769 t1 := result (f := t3640) (a := t3768) (u := t3634) (v := t3772) pv3640 (awb t2 t3631 t3768 t3770 (refl _)) pv3772
theorem pv3743 : R t3743 t1 := result (f := t3643) (a := t1) (u := t3643) (v := t3769) (refl t3643) (aw (ra t3640 t1)) pv3769
theorem pv3767 : R t3767 t1 := result (f := t28) (a := t3743) (u := t1) (v := t3743) pv28 (aw (ri t3743)) pv3743
theorem pv3763 : R t3763 t1 := result (f := t3762) (a := t1) (u := t3765) (v := t3767) pv3762 (awb t1 t3743 t1 t1 (cI)) pv3767
theorem pv3757 : R t3757 t1 := result (f := t3755) (a := t1) (u := t3755) (v := t3763) (refl t3755) (awb t3746 t1 t1 t1 (cI)) pv3763
theorem pv3761 : R t3761 t3760 := result (f := t3757) (a := t3760) (u := t1) (v := t3760) pv3757 (aw (ri t3760)) (refl t3760)
theorem pv3758 : R t3758 t3760 := result (f := t0) (a := t3757) (u := t0) (v := t3761) (refl t0) (aw (rh t3757)) pv3761
theorem pv3812 : R t3812 t3811 := result (f := t3757) (a := t3811) (u := t1) (v := t3811) pv3757 (aw (ri t3811)) (refl t3811)
theorem pv3759 : R t3759 t3811 := result (f := t3758) (a := t3743) (u := t3760) (v := t3812) pv3758 (aw (ra t3757 t3743)) pv3812
theorem pv3756 : R t3756 t3811 := result (f := t3746) (a := t3755) (u := t3746) (v := t3759) (refl t3746) (awb t0 t3743 t3755 t3757 (refl _)) pv3759
end Blc.H44.Pump
