import H44Ordered0P0
namespace Blc.H44Chain
open Term SelfintControl SelfintLowerBound ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
theorem oh0_32 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 2) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_15 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 0 2 = 0)
theorem oh0_33 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 2) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_17 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 0 2 = 0)
theorem oh0_34 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 2) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_19 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 0 2 = 0)
theorem oh0_35 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_9 = 0 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 0
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 0 else if a = 2 then 0 else 0) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_31 (push 0 ρ) rfl a0 a1)
    · exact (oh0_32 (push 1 ρ) rfl a0 a1)
    · exact (oh0_33 (push 2 ρ) rfl a0 a1)
    · exact (oh0_34 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_36 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_10 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_9 ρ a1) (oh0_35 ρ a0 a1) (by decide : opm0 0 0 = 0)
theorem oh0_37 (ρ : Env 3) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_3 = 3 := by
  exact a1
theorem oh0_38 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 3) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_13 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 0 3 = 0)
theorem oh0_39 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 3) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_15 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 0 3 = 0)
theorem oh0_40 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 3) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_17 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 0 3 = 0)
theorem oh0_41 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 3) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_19 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 0 3 = 0)
theorem oh0_42 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_9 = 0 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 0
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 0 else if a = 2 then 0 else 0) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_38 (push 0 ρ) rfl a0 a1)
    · exact (oh0_39 (push 1 ρ) rfl a0 a1)
    · exact (oh0_40 (push 2 ρ) rfl a0 a1)
    · exact (oh0_41 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_43 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_10 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_9 ρ a1) (oh0_42 ρ a0 a1) (by decide : opm0 0 0 = 0)
theorem oh0_44 (ρ : Env 3) (a0 : ρ 0 = 0) : eval gm0 ρ ob0_11 = 0 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_10) = 0
  have h : (fun a => eval gm0 (push a ρ) ob0_10) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 0 else if a = 2 then 0 else 0) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_22 (push 0 ρ) rfl a0)
    · exact (oh0_29 (push 1 ρ) rfl a0)
    · exact (oh0_36 (push 2 ρ) rfl a0)
    · exact (oh0_43 (push 3 ρ) rfl a0)
  rw [h]
  decide
theorem oh0_45 (ρ : Env 3) (a0 : ρ 0 = 0) : eval gm0 ρ ob0_12 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_11) (oh0_0 ρ a0) (oh0_44 ρ a0) (by decide : opm0 0 0 = 0)
theorem oh0_46 (ρ : Env 3) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_4 = 1 := by
  exact a2
theorem oh0_47 (ρ : Env 3) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_6 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_4) (a := ob0_5) (oh0_46 ρ a2) (oh0_11 ρ) (by decide : opm0 1 1 = 2)
theorem oh0_48 (ρ : Env 3) (a0 : ρ 0 = 0) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_7 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_47 ρ a2) (oh0_0 ρ a0) (by decide : opm0 2 0 = 2)
theorem oh0_49 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 0) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_48 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 2 0 = 2)
theorem oh0_50 (ρ : Env 3) (a0 : ρ 0 = 1) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_7 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_47 ρ a2) (oh0_2 ρ a0) (by decide : opm0 2 1 = 2)
theorem oh0_51 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 0) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_50 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 2 0 = 2)
theorem oh0_52 (ρ : Env 3) (a0 : ρ 0 = 2) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_47 ρ a2) (oh0_4 ρ a0) (by decide : opm0 2 2 = 3)
theorem oh0_53 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 0) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_52 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_54 (ρ : Env 3) (a0 : ρ 0 = 3) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_47 ρ a2) (oh0_6 ρ a0) (by decide : opm0 2 3 = 3)
theorem oh0_55 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 0) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_54 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_56 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_9 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 2 else if a = 1 then 2 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_49 (push 0 ρ) rfl a0 a1)
    · exact (oh0_51 (push 1 ρ) rfl a0 a1)
    · exact (oh0_53 (push 2 ρ) rfl a0 a1)
    · exact (oh0_55 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_57 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_10 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_23 ρ a1) (oh0_56 ρ a0 a1) (by decide : opm0 1 1 = 2)
theorem oh0_58 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 1) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_48 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 2 1 = 2)
theorem oh0_59 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 1) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_50 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 2 1 = 2)
theorem oh0_60 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 1) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_52 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_61 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 1) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_54 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_62 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_9 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 2 else if a = 1 then 2 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_58 (push 0 ρ) rfl a0 a1)
    · exact (oh0_59 (push 1 ρ) rfl a0 a1)
    · exact (oh0_60 (push 2 ρ) rfl a0 a1)
    · exact (oh0_61 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_63 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_10 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_23 ρ a1) (oh0_62 ρ a0 a1) (by decide : opm0 1 1 = 2)
end Blc.H44Chain
