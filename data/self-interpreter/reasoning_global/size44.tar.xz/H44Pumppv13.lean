import H44Pumppv12
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1020 : R t1020 t1 := result (f := t2) (a := t1019) (u := t2) (v := t1023) (refl t2) (aw (ra t0 t1019)) pv1023
theorem pv1021 : R t1021 t1 := result (f := t1020) (a := t907) (u := t1) (v := t907) pv1020 (aw (ri t907)) pv907
theorem pv920 : R t920 t1 := result (f := t916) (a := t919) (u := t910) (v := t1021) pv916 (awb t2 t907 t919 t1019 (refl _)) pv1021
theorem pv917 : R t917 t1 := result (f := t0) (a := t916) (u := t0) (v := t920) (refl t0) (aw (rh t916)) pv920
theorem pv918 : R t918 t910 := result (f := t917) (a := t910) (u := t1) (v := t910) pv917 (aw (ri t910)) (refl t910)
theorem pv915 : R t915 t910 := result (f := t912) (a := t914) (u := t912) (v := t918) (refl t912) (awb t0 t910 t914 t916 (refl _)) pv918
theorem pv913 : R t913 t910 := result (f := t0) (a := t912) (u := t0) (v := t915) (refl t0) (aw (rh t912)) pv915
theorem pv911 : R t911 t910 := result (f := t2) (a := t910) (u := t2) (v := t913) (refl t2) (aw (ra t0 t910)) pv913
theorem pv908 : R t908 t910 := result (f := t59) (a := t907) (u := t46) (v := t911) pv59 (aw (ra t2 t907)) pv911
theorem pv909 : R t909 t1 := result (f := t908) (a := t1) (u := t910) (v := t988) pv908 (awb t2 t907 t1 t1 (cI)) pv988
theorem pv906 : R t906 t1 := result (f := t182) (a := t905) (u := t149) (v := t909) pv182 (awb t59 t1 t905 t907 (refl _)) pv909
theorem pv823 : R t823 t1 := result (f := t185) (a := t1) (u := t185) (v := t906) (refl t185) (aw (ra t182 t1)) pv906
theorem pv904 : R t904 t1 := result (f := t3) (a := t823) (u := t1) (v := t823) pv3 (aw (ri t823)) pv823
theorem pv902 : R t902 t1 := result (f := t839) (a := t1) (u := t826) (v := t904) pv839 (awb t2 t823 t1 t1 (cI)) pv904
theorem pv903 : R t903 t1 := result (f := t902) (a := t1) (u := t1) (v := t1) pv902 (aw (ri t1)) (refl t1)
theorem pv877 : R t877 t1 := result (f := t875) (a := t1) (u := t875) (v := t903) (refl t875) (awb t839 t1 t1 t1 (cI)) pv903
theorem pv901 : R t901 t1 := result (f := t28) (a := t877) (u := t1) (v := t877) pv28 (aw (ri t877)) pv877
theorem pv897 : R t897 t1 := result (f := t896) (a := t1) (u := t899) (v := t901) pv896 (awb t1 t877 t1 t1 (cI)) pv901
theorem pv891 : R t891 t1 := result (f := t889) (a := t1) (u := t889) (v := t897) (refl t889) (awb t880 t1 t1 t1 (cI)) pv897
theorem pv895 : R t895 t894 := result (f := t891) (a := t894) (u := t1) (v := t894) pv891 (aw (ri t894)) (refl t894)
theorem pv892 : R t892 t894 := result (f := t0) (a := t891) (u := t0) (v := t895) (refl t0) (aw (rh t891)) pv895
theorem pv1102 : R t1102 t1101 := result (f := t891) (a := t1101) (u := t1) (v := t1101) pv891 (aw (ri t1101)) (refl t1101)
theorem pv893 : R t893 t1101 := result (f := t892) (a := t877) (u := t894) (v := t1102) pv892 (aw (ra t891 t877)) pv1102
theorem pv890 : R t890 t1101 := result (f := t880) (a := t889) (u := t880) (v := t893) (refl t880) (awb t0 t877 t889 t891 (refl _)) pv893
theorem pv884 : R t884 t1101 := result (f := t882) (a := t1) (u := t882) (v := t890) (refl t882) (aw (ra t880 t1)) pv890
theorem pv1113 : R t1113 t1 := result (f := t891) (a := t1) (u := t1) (v := t1) pv891 (aw (ri t1)) (refl t1)
theorem pv1114 : R t1114 t1 := result (f := t1113) (a := t877) (u := t1) (v := t877) pv1113 (aw (ri t877)) pv877
theorem pv1111 : R t1111 t1 := result (f := t884) (a := t1) (u := t1101) (v := t1114) pv884 (awb t891 t877 t1 t1 (cI)) pv1114
theorem pv1112 : R t1112 t1 := result (f := t1111) (a := t1) (u := t1) (v := t1) pv1111 (aw (ri t1)) (refl t1)
theorem pv1108 : R t1108 t1 := result (f := t1106) (a := t1) (u := t1106) (v := t1112) (refl t1106) (awb t884 t1 t1 t1 (cI)) pv1112
theorem pv1109 : R t1109 t1 := result (f := t891) (a := t1108) (u := t1) (v := t1108) pv891 (aw (ri t1108)) pv1108
theorem pv1110 : R t1110 t1 := result (f := t1109) (a := t877) (u := t1) (v := t877) pv1109 (aw (ri t877)) pv877
theorem pv1107 : R t1107 t1 := result (f := t884) (a := t1106) (u := t1101) (v := t1110) pv884 (awb t891 t877 t1106 t1108 (refl _)) pv1110
theorem pv1103 : R t1103 t1 := result (f := t887) (a := t1) (u := t887) (v := t1107) (refl t887) (aw (ra t884 t1)) pv1107
theorem pv1104 : R t1104 t1 := result (f := t891) (a := t1103) (u := t1) (v := t1103) pv891 (aw (ri t1103)) pv1103
theorem pv1105 : R t1105 t1 := result (f := t1104) (a := t877) (u := t1) (v := t877) pv1104 (aw (ri t877)) pv877
theorem pv888 : R t888 t1 := result (f := t884) (a := t887) (u := t1101) (v := t1105) pv884 (awb t891 t877 t887 t1103 (refl _)) pv1105
theorem pv885 : R t885 t1 := result (f := t0) (a := t884) (u := t0) (v := t888) (refl t0) (aw (rh t884)) pv888
theorem pv886 : R t886 t1 := result (f := t885) (a := t877) (u := t1) (v := t877) pv885 (aw (ri t877)) pv877
theorem pv883 : R t883 t1 := result (f := t880) (a := t882) (u := t880) (v := t886) (refl t880) (awb t0 t877 t882 t884 (refl _)) pv886
theorem pv881 : R t881 t1 := result (f := t0) (a := t880) (u := t0) (v := t883) (refl t0) (aw (rh t880)) pv883
theorem pv878 : R t878 t1 := result (f := t2) (a := t877) (u := t2) (v := t881) (refl t2) (aw (ra t0 t877)) pv881
theorem pv879 : R t879 t1 := result (f := t878) (a := t823) (u := t1) (v := t823) pv878 (aw (ri t823)) pv823
theorem pv876 : R t876 t1 := result (f := t839) (a := t875) (u := t826) (v := t879) pv839 (awb t2 t823 t875 t877 (refl _)) pv879
theorem pv850 : R t850 t1 := result (f := t842) (a := t1) (u := t842) (v := t876) (refl t842) (aw (ra t839 t1)) pv876
theorem pv874 : R t874 t1 := result (f := t28) (a := t850) (u := t1) (v := t850) pv28 (aw (ri t850)) pv850
theorem pv870 : R t870 t1 := result (f := t869) (a := t1) (u := t872) (v := t874) pv869 (awb t1 t850 t1 t1 (cI)) pv874
theorem pv864 : R t864 t1 := result (f := t862) (a := t1) (u := t862) (v := t870) (refl t862) (awb t853 t1 t1 t1 (cI)) pv870
theorem pv868 : R t868 t867 := result (f := t864) (a := t867) (u := t1) (v := t867) pv864 (aw (ri t867)) (refl t867)
theorem pv865 : R t865 t867 := result (f := t0) (a := t864) (u := t0) (v := t868) (refl t0) (aw (rh t864)) pv868
theorem pv1116 : R t1116 t1115 := result (f := t864) (a := t1115) (u := t1) (v := t1115) pv864 (aw (ri t1115)) (refl t1115)
theorem pv866 : R t866 t1115 := result (f := t865) (a := t850) (u := t867) (v := t1116) pv865 (aw (ra t864 t850)) pv1116
theorem pv863 : R t863 t1115 := result (f := t853) (a := t862) (u := t853) (v := t866) (refl t853) (awb t0 t850 t862 t864 (refl _)) pv866
theorem pv857 : R t857 t1115 := result (f := t855) (a := t1) (u := t855) (v := t863) (refl t855) (aw (ra t853 t1)) pv863
theorem pv1127 : R t1127 t1 := result (f := t864) (a := t1) (u := t1) (v := t1) pv864 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
