import H44Pumppv76
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5340 : R t5340 t1 := result (f := t5339) (a := t1) (u := t1) (v := t1) pv5339 (aw (ri t1)) (refl t1)
theorem pv5314 : R t5314 t1 := result (f := t5312) (a := t1) (u := t5312) (v := t5340) (refl t5312) (awb t5276 t1 t1 t1 (cI)) pv5340
theorem pv5338 : R t5338 t1 := result (f := t28) (a := t5314) (u := t1) (v := t5314) pv28 (aw (ri t5314)) pv5314
theorem pv5334 : R t5334 t1 := result (f := t5333) (a := t1) (u := t5336) (v := t5338) pv5333 (awb t1 t5314 t1 t1 (cI)) pv5338
theorem pv5328 : R t5328 t1 := result (f := t5326) (a := t1) (u := t5326) (v := t5334) (refl t5326) (awb t5317 t1 t1 t1 (cI)) pv5334
theorem pv5332 : R t5332 t5331 := result (f := t5328) (a := t5331) (u := t1) (v := t5331) pv5328 (aw (ri t5331)) (refl t5331)
theorem pv5329 : R t5329 t5331 := result (f := t0) (a := t5328) (u := t0) (v := t5332) (refl t0) (aw (rh t5328)) pv5332
theorem pv5539 : R t5539 t5538 := result (f := t5328) (a := t5538) (u := t1) (v := t5538) pv5328 (aw (ri t5538)) (refl t5538)
theorem pv5330 : R t5330 t5538 := result (f := t5329) (a := t5314) (u := t5331) (v := t5539) pv5329 (aw (ra t5328 t5314)) pv5539
theorem pv5327 : R t5327 t5538 := result (f := t5317) (a := t5326) (u := t5317) (v := t5330) (refl t5317) (awb t0 t5314 t5326 t5328 (refl _)) pv5330
theorem pv5321 : R t5321 t5538 := result (f := t5319) (a := t1) (u := t5319) (v := t5327) (refl t5319) (aw (ra t5317 t1)) pv5327
theorem pv5550 : R t5550 t1 := result (f := t5328) (a := t1) (u := t1) (v := t1) pv5328 (aw (ri t1)) (refl t1)
theorem pv5551 : R t5551 t1 := result (f := t5550) (a := t5314) (u := t1) (v := t5314) pv5550 (aw (ri t5314)) pv5314
theorem pv5548 : R t5548 t1 := result (f := t5321) (a := t1) (u := t5538) (v := t5551) pv5321 (awb t5328 t5314 t1 t1 (cI)) pv5551
theorem pv5549 : R t5549 t1 := result (f := t5548) (a := t1) (u := t1) (v := t1) pv5548 (aw (ri t1)) (refl t1)
theorem pv5545 : R t5545 t1 := result (f := t5543) (a := t1) (u := t5543) (v := t5549) (refl t5543) (awb t5321 t1 t1 t1 (cI)) pv5549
theorem pv5546 : R t5546 t1 := result (f := t5328) (a := t5545) (u := t1) (v := t5545) pv5328 (aw (ri t5545)) pv5545
theorem pv5547 : R t5547 t1 := result (f := t5546) (a := t5314) (u := t1) (v := t5314) pv5546 (aw (ri t5314)) pv5314
theorem pv5544 : R t5544 t1 := result (f := t5321) (a := t5543) (u := t5538) (v := t5547) pv5321 (awb t5328 t5314 t5543 t5545 (refl _)) pv5547
theorem pv5540 : R t5540 t1 := result (f := t5324) (a := t1) (u := t5324) (v := t5544) (refl t5324) (aw (ra t5321 t1)) pv5544
theorem pv5541 : R t5541 t1 := result (f := t5328) (a := t5540) (u := t1) (v := t5540) pv5328 (aw (ri t5540)) pv5540
theorem pv5542 : R t5542 t1 := result (f := t5541) (a := t5314) (u := t1) (v := t5314) pv5541 (aw (ri t5314)) pv5314
theorem pv5325 : R t5325 t1 := result (f := t5321) (a := t5324) (u := t5538) (v := t5542) pv5321 (awb t5328 t5314 t5324 t5540 (refl _)) pv5542
theorem pv5322 : R t5322 t1 := result (f := t0) (a := t5321) (u := t0) (v := t5325) (refl t0) (aw (rh t5321)) pv5325
theorem pv5323 : R t5323 t1 := result (f := t5322) (a := t5314) (u := t1) (v := t5314) pv5322 (aw (ri t5314)) pv5314
theorem pv5320 : R t5320 t1 := result (f := t5317) (a := t5319) (u := t5317) (v := t5323) (refl t5317) (awb t0 t5314 t5319 t5321 (refl _)) pv5323
theorem pv5318 : R t5318 t1 := result (f := t0) (a := t5317) (u := t0) (v := t5320) (refl t0) (aw (rh t5317)) pv5320
theorem pv5315 : R t5315 t1 := result (f := t2) (a := t5314) (u := t2) (v := t5318) (refl t2) (aw (ra t0 t5314)) pv5318
theorem pv5316 : R t5316 t1 := result (f := t5315) (a := t5260) (u := t1) (v := t5260) pv5315 (aw (ri t5260)) pv5260
theorem pv5313 : R t5313 t1 := result (f := t5276) (a := t5312) (u := t5263) (v := t5316) pv5276 (awb t2 t5260 t5312 t5314 (refl _)) pv5316
theorem pv5287 : R t5287 t1 := result (f := t5279) (a := t1) (u := t5279) (v := t5313) (refl t5279) (aw (ra t5276 t1)) pv5313
theorem pv5311 : R t5311 t1 := result (f := t28) (a := t5287) (u := t1) (v := t5287) pv28 (aw (ri t5287)) pv5287
theorem pv5307 : R t5307 t1 := result (f := t5306) (a := t1) (u := t5309) (v := t5311) pv5306 (awb t1 t5287 t1 t1 (cI)) pv5311
theorem pv5301 : R t5301 t1 := result (f := t5299) (a := t1) (u := t5299) (v := t5307) (refl t5299) (awb t5290 t1 t1 t1 (cI)) pv5307
theorem pv5305 : R t5305 t5304 := result (f := t5301) (a := t5304) (u := t1) (v := t5304) pv5301 (aw (ri t5304)) (refl t5304)
theorem pv5302 : R t5302 t5304 := result (f := t0) (a := t5301) (u := t0) (v := t5305) (refl t0) (aw (rh t5301)) pv5305
theorem pv5553 : R t5553 t5552 := result (f := t5301) (a := t5552) (u := t1) (v := t5552) pv5301 (aw (ri t5552)) (refl t5552)
theorem pv5303 : R t5303 t5552 := result (f := t5302) (a := t5287) (u := t5304) (v := t5553) pv5302 (aw (ra t5301 t5287)) pv5553
theorem pv5300 : R t5300 t5552 := result (f := t5290) (a := t5299) (u := t5290) (v := t5303) (refl t5290) (awb t0 t5287 t5299 t5301 (refl _)) pv5303
theorem pv5294 : R t5294 t5552 := result (f := t5292) (a := t1) (u := t5292) (v := t5300) (refl t5292) (aw (ra t5290 t1)) pv5300
theorem pv5564 : R t5564 t1 := result (f := t5301) (a := t1) (u := t1) (v := t1) pv5301 (aw (ri t1)) (refl t1)
theorem pv5565 : R t5565 t1 := result (f := t5564) (a := t5287) (u := t1) (v := t5287) pv5564 (aw (ri t5287)) pv5287
theorem pv5562 : R t5562 t1 := result (f := t5294) (a := t1) (u := t5552) (v := t5565) pv5294 (awb t5301 t5287 t1 t1 (cI)) pv5565
theorem pv5563 : R t5563 t1 := result (f := t5562) (a := t1) (u := t1) (v := t1) pv5562 (aw (ri t1)) (refl t1)
theorem pv5559 : R t5559 t1 := result (f := t5557) (a := t1) (u := t5557) (v := t5563) (refl t5557) (awb t5294 t1 t1 t1 (cI)) pv5563
theorem pv5560 : R t5560 t1 := result (f := t5301) (a := t5559) (u := t1) (v := t5559) pv5301 (aw (ri t5559)) pv5559
theorem pv5561 : R t5561 t1 := result (f := t5560) (a := t5287) (u := t1) (v := t5287) pv5560 (aw (ri t5287)) pv5287
theorem pv5558 : R t5558 t1 := result (f := t5294) (a := t5557) (u := t5552) (v := t5561) pv5294 (awb t5301 t5287 t5557 t5559 (refl _)) pv5561
theorem pv5554 : R t5554 t1 := result (f := t5297) (a := t1) (u := t5297) (v := t5558) (refl t5297) (aw (ra t5294 t1)) pv5558
theorem pv5555 : R t5555 t1 := result (f := t5301) (a := t5554) (u := t1) (v := t5554) pv5301 (aw (ri t5554)) pv5554
theorem pv5556 : R t5556 t1 := result (f := t5555) (a := t5287) (u := t1) (v := t5287) pv5555 (aw (ri t5287)) pv5287
theorem pv5298 : R t5298 t1 := result (f := t5294) (a := t5297) (u := t5552) (v := t5556) pv5294 (awb t5301 t5287 t5297 t5554 (refl _)) pv5556
theorem pv5295 : R t5295 t1 := result (f := t0) (a := t5294) (u := t0) (v := t5298) (refl t0) (aw (rh t5294)) pv5298
theorem pv5296 : R t5296 t1 := result (f := t5295) (a := t5287) (u := t1) (v := t5287) pv5295 (aw (ri t5287)) pv5287
theorem pv5293 : R t5293 t1 := result (f := t5290) (a := t5292) (u := t5290) (v := t5296) (refl t5290) (awb t0 t5287 t5292 t5294 (refl _)) pv5296
end Blc.H44.Pump
