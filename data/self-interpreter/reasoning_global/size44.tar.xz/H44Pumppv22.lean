import H44Pumppv21
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1745 : R t1745 t1 := result (f := t1674) (a := t1) (u := t1735) (v := t1748) pv1674 (awb t1681 t1667 t1 t1 (cI)) pv1748
theorem pv1746 : R t1746 t1 := result (f := t1745) (a := t1) (u := t1) (v := t1) pv1745 (aw (ri t1)) (refl t1)
theorem pv1742 : R t1742 t1 := result (f := t1740) (a := t1) (u := t1740) (v := t1746) (refl t1740) (awb t1674 t1 t1 t1 (cI)) pv1746
theorem pv1743 : R t1743 t1 := result (f := t1681) (a := t1742) (u := t1) (v := t1742) pv1681 (aw (ri t1742)) pv1742
theorem pv1744 : R t1744 t1 := result (f := t1743) (a := t1667) (u := t1) (v := t1667) pv1743 (aw (ri t1667)) pv1667
theorem pv1741 : R t1741 t1 := result (f := t1674) (a := t1740) (u := t1735) (v := t1744) pv1674 (awb t1681 t1667 t1740 t1742 (refl _)) pv1744
theorem pv1737 : R t1737 t1 := result (f := t1677) (a := t1) (u := t1677) (v := t1741) (refl t1677) (aw (ra t1674 t1)) pv1741
theorem pv1738 : R t1738 t1 := result (f := t1681) (a := t1737) (u := t1) (v := t1737) pv1681 (aw (ri t1737)) pv1737
theorem pv1739 : R t1739 t1 := result (f := t1738) (a := t1667) (u := t1) (v := t1667) pv1738 (aw (ri t1667)) pv1667
theorem pv1678 : R t1678 t1 := result (f := t1674) (a := t1677) (u := t1735) (v := t1739) pv1674 (awb t1681 t1667 t1677 t1737 (refl _)) pv1739
theorem pv1675 : R t1675 t1 := result (f := t0) (a := t1674) (u := t0) (v := t1678) (refl t0) (aw (rh t1674)) pv1678
theorem pv1676 : R t1676 t1 := result (f := t1675) (a := t1667) (u := t1) (v := t1667) pv1675 (aw (ri t1667)) pv1667
theorem pv1673 : R t1673 t1 := result (f := t1670) (a := t1672) (u := t1670) (v := t1676) (refl t1670) (awb t0 t1667 t1672 t1674 (refl _)) pv1676
theorem pv1671 : R t1671 t1 := result (f := t0) (a := t1670) (u := t0) (v := t1673) (refl t0) (aw (rh t1670)) pv1673
theorem pv1668 : R t1668 t1 := result (f := t2) (a := t1667) (u := t2) (v := t1671) (refl t2) (aw (ra t0 t1667)) pv1671
theorem pv1669 : R t1669 t1 := result (f := t1668) (a := t1555) (u := t1) (v := t1555) pv1668 (aw (ri t1555)) pv1555
theorem pv1568 : R t1568 t1 := result (f := t1564) (a := t1567) (u := t1558) (v := t1669) pv1564 (awb t2 t1555 t1567 t1667 (refl _)) pv1669
theorem pv1565 : R t1565 t1 := result (f := t0) (a := t1564) (u := t0) (v := t1568) (refl t0) (aw (rh t1564)) pv1568
theorem pv1566 : R t1566 t1558 := result (f := t1565) (a := t1558) (u := t1) (v := t1558) pv1565 (aw (ri t1558)) (refl t1558)
theorem pv1563 : R t1563 t1558 := result (f := t1560) (a := t1562) (u := t1560) (v := t1566) (refl t1560) (awb t0 t1558 t1562 t1564 (refl _)) pv1566
theorem pv1561 : R t1561 t1558 := result (f := t0) (a := t1560) (u := t0) (v := t1563) (refl t0) (aw (rh t1560)) pv1563
theorem pv1559 : R t1559 t1558 := result (f := t2) (a := t1558) (u := t2) (v := t1561) (refl t2) (aw (ra t0 t1558)) pv1561
theorem pv1556 : R t1556 t1558 := result (f := t59) (a := t1555) (u := t46) (v := t1559) pv59 (aw (ra t2 t1555)) pv1559
theorem pv1557 : R t1557 t1 := result (f := t1556) (a := t1) (u := t1558) (v := t1636) pv1556 (awb t2 t1555 t1 t1 (cI)) pv1636
theorem pv1554 : R t1554 t1 := result (f := t1417) (a := t1553) (u := t149) (v := t1557) pv1417 (awb t59 t1 t1553 t1555 (refl _)) pv1557
theorem pv1471 : R t1471 t1 := result (f := t1420) (a := t1) (u := t1420) (v := t1554) (refl t1420) (aw (ra t1417 t1)) pv1554
theorem pv1552 : R t1552 t1 := result (f := t3) (a := t1471) (u := t1) (v := t1471) pv3 (aw (ri t1471)) pv1471
theorem pv1550 : R t1550 t1 := result (f := t1487) (a := t1) (u := t1474) (v := t1552) pv1487 (awb t2 t1471 t1 t1 (cI)) pv1552
theorem pv1551 : R t1551 t1 := result (f := t1550) (a := t1) (u := t1) (v := t1) pv1550 (aw (ri t1)) (refl t1)
theorem pv1525 : R t1525 t1 := result (f := t1523) (a := t1) (u := t1523) (v := t1551) (refl t1523) (awb t1487 t1 t1 t1 (cI)) pv1551
theorem pv1549 : R t1549 t1 := result (f := t28) (a := t1525) (u := t1) (v := t1525) pv28 (aw (ri t1525)) pv1525
theorem pv1545 : R t1545 t1 := result (f := t1544) (a := t1) (u := t1547) (v := t1549) pv1544 (awb t1 t1525 t1 t1 (cI)) pv1549
theorem pv1539 : R t1539 t1 := result (f := t1537) (a := t1) (u := t1537) (v := t1545) (refl t1537) (awb t1528 t1 t1 t1 (cI)) pv1545
theorem pv1543 : R t1543 t1542 := result (f := t1539) (a := t1542) (u := t1) (v := t1542) pv1539 (aw (ri t1542)) (refl t1542)
theorem pv1540 : R t1540 t1542 := result (f := t0) (a := t1539) (u := t0) (v := t1543) (refl t0) (aw (rh t1539)) pv1543
theorem pv1750 : R t1750 t1749 := result (f := t1539) (a := t1749) (u := t1) (v := t1749) pv1539 (aw (ri t1749)) (refl t1749)
theorem pv1541 : R t1541 t1749 := result (f := t1540) (a := t1525) (u := t1542) (v := t1750) pv1540 (aw (ra t1539 t1525)) pv1750
theorem pv1538 : R t1538 t1749 := result (f := t1528) (a := t1537) (u := t1528) (v := t1541) (refl t1528) (awb t0 t1525 t1537 t1539 (refl _)) pv1541
theorem pv1532 : R t1532 t1749 := result (f := t1530) (a := t1) (u := t1530) (v := t1538) (refl t1530) (aw (ra t1528 t1)) pv1538
theorem pv1761 : R t1761 t1 := result (f := t1539) (a := t1) (u := t1) (v := t1) pv1539 (aw (ri t1)) (refl t1)
theorem pv1762 : R t1762 t1 := result (f := t1761) (a := t1525) (u := t1) (v := t1525) pv1761 (aw (ri t1525)) pv1525
theorem pv1759 : R t1759 t1 := result (f := t1532) (a := t1) (u := t1749) (v := t1762) pv1532 (awb t1539 t1525 t1 t1 (cI)) pv1762
theorem pv1760 : R t1760 t1 := result (f := t1759) (a := t1) (u := t1) (v := t1) pv1759 (aw (ri t1)) (refl t1)
theorem pv1756 : R t1756 t1 := result (f := t1754) (a := t1) (u := t1754) (v := t1760) (refl t1754) (awb t1532 t1 t1 t1 (cI)) pv1760
theorem pv1757 : R t1757 t1 := result (f := t1539) (a := t1756) (u := t1) (v := t1756) pv1539 (aw (ri t1756)) pv1756
theorem pv1758 : R t1758 t1 := result (f := t1757) (a := t1525) (u := t1) (v := t1525) pv1757 (aw (ri t1525)) pv1525
theorem pv1755 : R t1755 t1 := result (f := t1532) (a := t1754) (u := t1749) (v := t1758) pv1532 (awb t1539 t1525 t1754 t1756 (refl _)) pv1758
theorem pv1751 : R t1751 t1 := result (f := t1535) (a := t1) (u := t1535) (v := t1755) (refl t1535) (aw (ra t1532 t1)) pv1755
theorem pv1752 : R t1752 t1 := result (f := t1539) (a := t1751) (u := t1) (v := t1751) pv1539 (aw (ri t1751)) pv1751
theorem pv1753 : R t1753 t1 := result (f := t1752) (a := t1525) (u := t1) (v := t1525) pv1752 (aw (ri t1525)) pv1525
theorem pv1536 : R t1536 t1 := result (f := t1532) (a := t1535) (u := t1749) (v := t1753) pv1532 (awb t1539 t1525 t1535 t1751 (refl _)) pv1753
theorem pv1533 : R t1533 t1 := result (f := t0) (a := t1532) (u := t0) (v := t1536) (refl t0) (aw (rh t1532)) pv1536
theorem pv1534 : R t1534 t1 := result (f := t1533) (a := t1525) (u := t1) (v := t1525) pv1533 (aw (ri t1525)) pv1525
theorem pv1531 : R t1531 t1 := result (f := t1528) (a := t1530) (u := t1528) (v := t1534) (refl t1528) (awb t0 t1525 t1530 t1532 (refl _)) pv1534
theorem pv1529 : R t1529 t1 := result (f := t0) (a := t1528) (u := t0) (v := t1531) (refl t0) (aw (rh t1528)) pv1531
end Blc.H44.Pump
