import H44F4846201355482Proof4
namespace Blc.H44.H44F4846201355482
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h180 (ρ : Env) (a0 : Fits s38 (ρ 0)) (a1 : Fits s59 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len9 d9 c9 sub15 ((h88 ρ a2) 9 mem64) (smaller (h130 ρ a0 a1) sub15)
theorem h181 (ρ : Env) (a0 : Fits s39 (ρ 0)) (a1 : Fits s37 (ρ 1)) (a2 : Fits s60 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len35 d35 c35 sub15 ((h90 ρ a2) 35 mem65) (smaller (h110 ρ a0 a1) sub11)
theorem h182 (ρ : Env) (a0 : Fits s31 (ρ 0)) (a1 : Fits s59 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len9 d9 c9 sub15 ((h88 ρ a2) 9 mem64) (smaller (h131 ρ a0 a1) sub15)
theorem h183 (ρ : Env) (a0 : Fits s37 (ρ 0)) (a1 : Fits s26 (ρ 1)) (a2 : Fits s50 (ρ 2)) : All tab ρ b4 s31 :=
  appAll len38 d38 c38 sub11 ((h91 ρ a2) 38 mem66) (smaller (h112 ρ a0 a1) sub15)
theorem h184 (ρ : Env) (a0 : Fits s41 (ρ 0)) (a1 : Fits s7 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len9 d9 c9 sub15 ((h88 ρ a2) 9 mem64) (smaller (h111 ρ a0 a1) sub15)
theorem h185 (ρ : Env) (a0 : Fits s35 (ρ 0)) (a1 : Fits s7 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len51 d51 c51 sub15 ((h88 ρ a2) 51 mem67) (smaller (h106 ρ a0 a1) sub14)
theorem h186 (ρ : Env) (a0 : Fits s43 (ρ 0)) (a1 : Fits s12 (ρ 1)) (a2 : Fits s55 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len35 d35 c35 sub15 ((h94 ρ a2) 35 mem47) (smaller (h121 ρ a0 a1) sub11)
theorem h187 (ρ : Env) (a0 : Fits s45 (ρ 0)) (a1 : Fits s59 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len57 d57 c57 sub15 ((h88 ρ a2) 57 mem68) (smaller (h132 ρ a0 a1) sub53)
theorem h188 (ρ : Env) (a0 : Fits s46 (ρ 0)) (a1 : Fits s44 (ρ 1)) (a2 : Fits s60 (ρ 2)) : All tab ρ b4 s34 :=
  appAll len59 d59 c59 sub53 ((h90 ρ a2) 59 mem69) (smaller (h116 ρ a0 a1) sub23)
theorem h189 (ρ : Env) (a0 : Fits s47 (ρ 0)) (a1 : Fits s59 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s34 :=
  appAll len41 d41 c41 sub53 ((h88 ρ a2) 41 mem62) (smaller (h133 ρ a0 a1) sub53)
theorem h190 (ρ : Env) (a0 : Fits s44 (ρ 0)) (a1 : Fits s26 (ρ 1)) (a2 : Fits s50 (ρ 2)) : All tab ρ b4 s47 :=
  appAll len62 d62 c62 sub23 ((h91 ρ a2) 62 mem70) (smaller (h117 ρ a0 a1) sub15)
theorem h191 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s31 (ρ 1)) (a2 : Fits s58 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len35 d35 c35 sub15 ((h93 ρ a2) 35 mem51) (smaller (h119 ρ a0 a1) sub11)
theorem h192 (ρ : Env) (a0 : Fits s44 (ρ 0)) (a1 : Fits s59 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len9 d9 c9 sub15 ((h88 ρ a2) 9 mem64) (smaller (h134 ρ a0 a1) sub15)
theorem h193 (ρ : Env) (a0 : Fits s48 (ρ 0)) (a1 : Fits s31 (ρ 1)) (a2 : Fits s60 (ρ 2)) : All tab ρ b4 s7 :=
  appAll len35 d35 c35 sub15 ((h90 ρ a2) 35 mem65) (smaller (h119 ρ a0 a1) sub11)
theorem h194 (ρ : Env) (a0 : Fits s31 (ρ 0)) (a1 : Fits s26 (ρ 1)) (a2 : Fits s50 (ρ 2)) : All tab ρ b4 s31 :=
  appAll len38 d38 c38 sub11 ((h91 ρ a2) 38 mem66) (smaller (h120 ρ a0 a1) sub15)
theorem h195 (ρ : Env) (a0 : Fits s43 (ρ 0)) (a1 : Fits s12 (ρ 1)) (a2 : Fits s55 (ρ 2)) : All tab ρ b4 s31 :=
  appAll len66 d66 c66 sub11 ((h94 ρ a2) 66 mem53) (smaller (h121 ρ a0 a1) sub11)
theorem h196 (ρ : Env) (a0 : Fits s45 (ρ 0)) (a1 : Fits s59 (ρ 1)) (a2 : Fits s52 (ρ 2)) : All tab ρ b4 s31 :=
  appAll len71 d71 c71 sub11 ((h88 ρ a2) 71 mem71) (smaller (h132 ρ a0 a1) sub53)
theorem h197 (ρ : Env) (a0 : Fits s3 (ρ 0)) (a1 : Fits s4 (ρ 1)) : All tab ρ b5 s5 :=
  (consAll (lamAt d8 c8 (smaller (h135 (Types.cons s6 ρ) sub1 a0 a1) sub15)) (consAll (lamAt d11 c11 (smaller (h137 (Types.cons s9 ρ) sub2 a0 a1) sub15)) Positive.none))
theorem h198 (ρ : Env) (a0 : Fits s1 (ρ 0)) (a1 : Fits s5 (ρ 1)) : All tab ρ b5 s6 :=
  (consAll (lamAt d10 c10 (smaller (h136 (Types.cons s8 ρ) sub3 a0 a1) sub15)) Positive.none)
theorem h199 (ρ : Env) (a0 : Fits s10 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b5 s11 :=
  (consAll (lamAt d16 c16 (smaller (h138 (Types.cons s13 ρ) sub6 a0 a1) sub110)) (consAll (lamAt d72 c72 (smaller (h168 (Types.cons s42 ρ) sub30 a0 a1) sub27)) Positive.none))
theorem h200 (ρ : Env) (a0 : Fits s16 (ρ 0)) (a1 : Fits s17 (ρ 1)) : All tab ρ b5 s18 :=
  (consAll (lamAt d22 c22 (smaller (h139 (Types.cons s19 ρ) sub7 a0 a1) sub110)) (consAll (lamAt d26 c26 (smaller (h141 (Types.cons s23 ρ) sub8 a0 a1) sub91)) Positive.none))
theorem h201 (ρ : Env) (a0 : Fits s15 (ρ 0)) (a1 : Fits s18 (ρ 1)) : All tab ρ b5 s19 :=
  (consAll (lamAt d25 c25 (smaller (h140 (Types.cons s22 ρ) sub9 a0 a1) sub91)) Positive.none)
theorem h202 (ρ : Env) (a0 : Fits s27 (ρ 0)) (a1 : Fits s17 (ρ 1)) : All tab ρ b5 s28 :=
  (consAll (lamAt d33 c33 (smaller (h142 (Types.cons s29 ρ) sub10 a0 a1) sub15)) (consAll (lamAt d35 c35 (smaller (h144 (Types.cons s31 ρ) sub11 a0 a1) sub15)) (consAll (lamAt d46 c46 (smaller (h150 (Types.cons s38 ρ) sub17 a0 a1) sub15)) (consAll (lamAt d55 c55 (smaller (h162 (Types.cons s44 ρ) sub25 a0 a1) sub15)) (consAll (lamAt d56 c56 (smaller (h157 (Types.cons s45 ρ) sub22 a0 a1) sub15)) (consAll (lamAt d59 c59 (smaller (h159 (Types.cons s47 ρ) sub23 a0 a1) sub53)) (consAll (lamAt d70 c70 (smaller (h167 (Types.cons s45 ρ) sub22 a0 a1) sub11)) Positive.none)))))))
theorem h203 (ρ : Env) (a0 : Fits s25 (ρ 0)) (a1 : Fits s28 (ρ 1)) : All tab ρ b5 s29 :=
  (consAll (lamAt d34 c34 (smaller (h143 (Types.cons s30 ρ) sub12 a0 a1) sub15)) Positive.none)
theorem h204 (ρ : Env) (a0 : Fits s26 (ρ 0)) (a1 : Fits s15 (ρ 1)) : All tab ρ b5 s27 :=
  (consAll (lamAt d37 c37 (smaller (h145 (Types.cons s25 ρ) sub16 a0 a1) sub11)) (consAll (lamAt d48 c48 (smaller (h152 (Types.cons s37 ρ) sub20 a0 a1) sub11)) (consAll (lamAt d61 c61 (smaller (h160 (Types.cons s44 ρ) sub25 a0 a1) sub23)) (consAll (lamAt d66 c66 (smaller (h164 (Types.cons s31 ρ) sub11 a0 a1) sub11)) Positive.none))))
theorem h205 (ρ : Env) (a0 : Fits s7 (ρ 0)) (a1 : Fits s17 (ρ 1)) : All tab ρ b5 s32 :=
  (consAll (lamAt d40 c40 (smaller (h146 (Types.cons s33 ρ) sub13 a0 a1) sub111)) (consAll (lamAt d43 c43 (smaller (h148 (Types.cons s35 ρ) sub14 a0 a1) sub53)) (consAll (lamAt d65 c65 (smaller (h146 (Types.cons s33 ρ) sub13 a0 a1) sub53)) Positive.none)))
theorem h206 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s32 (ρ 1)) : All tab ρ b5 s33 :=
  (consAll (lamAt d42 c42 (smaller (h147 (Types.cons s7 ρ) sub15 a0 a1) sub53)) Positive.none)
theorem h207 (ρ : Env) (a0 : Fits s21 (ρ 0)) (a1 : Fits s24 (ρ 1)) : All tab ρ b5 s25 :=
  (consAll (lamAt d44 c44 (smaller (h149 (Types.cons s36 ρ) sub21 a0 a1) sub15)) Positive.none)
theorem h208 (ρ : Env) (a0 : Fits s37 (ρ 0)) (a1 : Fits s28 (ρ 1)) : All tab ρ b5 s38 :=
  (consAll (lamAt d47 c47 (smaller (h151 (Types.cons s39 ρ) sub18 a0 a1) sub15)) Positive.none)
theorem h209 (ρ : Env) (a0 : Fits s7 (ρ 0)) (a1 : Fits s17 (ρ 1)) : All tab ρ b5 s40 :=
  (consAll (lamAt d50 c50 (smaller (h153 (Types.cons s41 ρ) sub19 a0 a1) sub15)) (consAll (lamAt d51 c51 (smaller (h155 (Types.cons s35 ρ) sub14 a0 a1) sub15)) Positive.none))
theorem h210 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s40 (ρ 1)) : All tab ρ b5 s41 :=
  (consAll (lamAt d9 c9 (smaller (h154 (Types.cons s7 ρ) sub15 a0 a1) sub15)) Positive.none)
theorem h211 (ρ : Env) (a0 : Fits s12 (ρ 0)) (a1 : Fits s20 (ρ 1)) : All tab ρ b5 s21 :=
  (consAll (lamAt d54 c54 (smaller (h156 (Types.cons s43 ρ) sub27 a0 a1) sub15)) (consAll (lamAt d68 c68 (smaller (h166 (Types.cons s43 ρ) sub27 a0 a1) sub11)) Positive.none))
theorem h212 (ρ : Env) (a0 : Fits s44 (ρ 0)) (a1 : Fits s28 (ρ 1)) : All tab ρ b5 s45 :=
  (consAll (lamAt d58 c58 (smaller (h158 (Types.cons s46 ρ) sub24 a0 a1) sub53)) Positive.none)
theorem h213 (ρ : Env) (a0 : Fits s31 (ρ 0)) (a1 : Fits s24 (ρ 1)) : All tab ρ b5 s44 :=
  (consAll (lamAt d64 c64 (smaller (h161 (Types.cons s48 ρ) sub26 a0 a1) sub15)) Positive.none)
theorem h214 (ρ : Env) (a0 : Fits s31 (ρ 0)) (a1 : Fits s28 (ρ 1)) : All tab ρ b5 s44 :=
  (consAll (lamAt d64 c64 (smaller (h163 (Types.cons s48 ρ) sub26 a0 a1) sub15)) Positive.none)
theorem h215 (ρ : Env) (a0 : Fits s42 (ρ 0)) (a1 : Fits s21 (ρ 1)) : All tab ρ b5 s43 :=
  (consAll (lamAt d67 c67 (smaller (h165 (Types.cons s12 ρ) sub28 a0 a1) sub11)) Positive.none)
end Blc.H44.H44F4846201355482
