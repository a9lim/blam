import More
namespace Blc.Floor44.Alt
open Term SelfintSharp SelfintLowerBound SelfintControl SelfintProbe Round3Floor38
theorem transfer {e f : Term} (hc : Closed f) (h : BetaJoin (.app f (.var 0)) (.app e (.var 0)))
    (he : IsSelfInterpreter e) : IsSelfInterpreter f :=
  ⟨hc,fun m hm => join_trans (join_appL _ h) (he.2 m hm)⟩
theorem shorter {e f t : Term} {p q : List (List Direction)} (prev : SelfintSizeBound 38)
    (hc : Closed f) (cost : (blcCode f).length < 38)
    (he : replay p (.app e (.var 0)) = some t) (hf : replay q (.app f (.var 0)) = some t) :
    ¬ IsSelfInterpreter e := fun h =>
  Nat.not_le_of_lt cost (prev _ (transfer hc ⟨_,replay_sound hf,replay_sound he⟩ h))
theorem lost {e u : Term} {p : List (List Direction)}
    (hr : replay p (.app e (.var 0)) = some u) (hc : Closed u) : ¬ IsSelfInterpreter e := by
  intro he
  let s := streamOf (blcCode identity) identity
  have hx := join_after_betas (betas_appL s (replay_sound hr))
    (contract_join he (M := identity) (by decide) (.var 0) identity)
  obtain ⟨w,hw,hw'⟩ := hx
  have hn : NFt (.app (.app (.var 0) (.lam identity)) identity) := by decide
  have eq := normalForm_betas_eq (fun _ => nft_no_beta hn) hw'
  have hclosed := betas_scope hw 0 ⟨hc,by decide⟩
  subst w
  exact Nat.lt_irrefl 0 hclosed.1.1
end Blc.Floor44.Alt
