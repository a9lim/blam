import H44Literals
import H44Lib0
import H44Lib100
namespace Blc.H44
theorem ex_e4836620504886 : ¬ IsSelfInterpreter e4836620504886 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4836620504886 1 = true)
#print axioms ex_e4836620504886
theorem ex_e4837794910006 : ¬ IsSelfInterpreter e4837794910006 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4837794910006 1 = true)
#print axioms ex_e4837794910006
theorem ex_e4838372965610 : ¬ IsSelfInterpreter e4838372965610 := Lib100.excluded (by decide : Types.has Lib100.tab Lib100.env e4838372965610 2 = true)
#print axioms ex_e4838372965610
theorem ex_e4838381689070 : ¬ IsSelfInterpreter e4838381689070 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381689070 1 = true)
#print axioms ex_e4838381689070
theorem ex_e4838381689078 : ¬ IsSelfInterpreter e4838381689078 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381689078 1 = true)
#print axioms ex_e4838381689078
theorem ex_e4838381695774 : ¬ IsSelfInterpreter e4838381695774 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381695774 1 = true)
#print axioms ex_e4838381695774
end Blc.H44
