import H44Literals
import H44ChainRows
import H44F4846363266838
import H44Lib0
import H44Lib1
namespace Blc.H44
theorem ex_e4846201494882 : ¬ IsSelfInterpreter e4846201494882 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4846201494882 3 = true)
#print axioms ex_e4846201494882
theorem ex_e4846206860506 : ¬ IsSelfInterpreter e4846206860506 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846206860506 1 = true)
#print axioms ex_e4846206860506
theorem ex_e4846363262038 : ¬ IsSelfInterpreter e4846363262038 := Blc.H44Chain.ex_e4846363262038
#print axioms ex_e4846363262038
theorem ex_e4846363266606 : ¬ IsSelfInterpreter e4846363266606 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846363266606 1 = true)
#print axioms ex_e4846363266606
theorem ex_e4846363266838 : ¬ IsSelfInterpreter e4846363266838 := H44F4846363266838.excluded
#print axioms ex_e4846363266838
theorem ex_e4846363275578 : ¬ IsSelfInterpreter e4846363275578 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4846363275578 3 = true)
#print axioms ex_e4846363275578
end Blc.H44
