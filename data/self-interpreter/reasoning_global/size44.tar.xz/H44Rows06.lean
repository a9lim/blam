import H44Literals
import H44Lib0
import H44Lib1
import H44Lib15
import H44Lib4
import H44Lib7
namespace Blc.H44
theorem ex_e4838381820358 : ¬ IsSelfInterpreter e4838381820358 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381820358 1 = true)
#print axioms ex_e4838381820358
theorem ex_e4838382903098 : ¬ IsSelfInterpreter e4838382903098 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4838382903098 3 = true)
#print axioms ex_e4838382903098
theorem ex_e4838387621686 : ¬ IsSelfInterpreter e4838387621686 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838387621686 1 = true)
#print axioms ex_e4838387621686
theorem ex_e4845892013878 : ¬ IsSelfInterpreter e4845892013878 := Lib7.excluded (by decide : Types.has Lib7.tab Lib7.env e4845892013878 3 = true)
#print axioms ex_e4845892013878
theorem ex_e4845892538170 : ¬ IsSelfInterpreter e4845892538170 := Lib15.excluded (by decide : Types.has Lib15.tab Lib15.env e4845892538170 1 = true)
#print axioms ex_e4845892538170
theorem ex_e4845894635130 : ¬ IsSelfInterpreter e4845894635130 := Lib4.excluded (by decide : Types.has Lib4.tab Lib4.env e4845894635130 4 = true)
#print axioms ex_e4845894635130
end Blc.H44
