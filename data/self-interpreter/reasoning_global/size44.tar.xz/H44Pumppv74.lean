import H44Pumppv73
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5282 : R t5282 t5263 := result (f := t5281) (a := t1) (u := t5284) (v := t5286) pv5281 (awb t1 t5263 t1 t1 (cI)) pv5286
theorem pv5276 : R t5276 t5263 := result (f := t5274) (a := t1) (u := t5274) (v := t5282) (refl t5274) (awb t5265 t1 t1 t1 (cI)) pv5282
theorem pv5310 : R t5310 t5309 := result (f := t1) (a := t5309) (u := t1) (v := t5309) (refl t1) (aw (ri t5309)) (refl t5309)
theorem pv5308 : R t5308 t5309 := result (f := t22) (a := t5287) (u := t24) (v := t5310) pv22 (aw (ra t1 t5287)) pv5310
theorem pv5306 : R t5306 t5309 := result (f := t5290) (a := t1) (u := t5290) (v := t5308) (refl t5290) (awb t0 t5287 t1 t1 (cI)) pv5308
theorem pv5337 : R t5337 t5336 := result (f := t1) (a := t5336) (u := t1) (v := t5336) (refl t1) (aw (ri t5336)) (refl t5336)
theorem pv5335 : R t5335 t5336 := result (f := t22) (a := t5314) (u := t24) (v := t5337) pv22 (aw (ra t1 t5314)) pv5337
theorem pv5333 : R t5333 t5336 := result (f := t5317) (a := t1) (u := t5317) (v := t5335) (refl t5317) (awb t0 t5314 t1 t1 (cI)) pv5335
theorem pv5369 : R t5369 t5368 := result (f := t1) (a := t5368) (u := t1) (v := t5368) (refl t1) (aw (ri t5368)) (refl t5368)
theorem pv5367 : R t5367 t5368 := result (f := t22) (a := t5347) (u := t24) (v := t5369) pv22 (aw (ra t1 t5347)) pv5369
theorem pv5365 : R t5365 t5368 := result (f := t5349) (a := t1) (u := t5349) (v := t5367) (refl t5349) (awb t0 t5347 t1 t1 (cI)) pv5367
theorem pv5370 : R t5370 t5347 := result (f := t28) (a := t5347) (u := t1) (v := t5347) pv28 (aw (ri t5347)) (refl t5347)
theorem pv5366 : R t5366 t5347 := result (f := t5365) (a := t1) (u := t5368) (v := t5370) pv5365 (awb t1 t5347 t1 t1 (cI)) pv5370
theorem pv5360 : R t5360 t5347 := result (f := t5358) (a := t1) (u := t5358) (v := t5366) (refl t5358) (awb t5349 t1 t1 t1 (cI)) pv5366
theorem pv5394 : R t5394 t5393 := result (f := t1) (a := t5393) (u := t1) (v := t5393) (refl t1) (aw (ri t5393)) (refl t5393)
theorem pv5392 : R t5392 t5393 := result (f := t22) (a := t5371) (u := t24) (v := t5394) pv22 (aw (ra t1 t5371)) pv5394
theorem pv5390 : R t5390 t5393 := result (f := t5374) (a := t1) (u := t5374) (v := t5392) (refl t5374) (awb t0 t5371 t1 t1 (cI)) pv5392
theorem pv5421 : R t5421 t5420 := result (f := t1) (a := t5420) (u := t1) (v := t5420) (refl t1) (aw (ri t5420)) (refl t5420)
theorem pv5419 : R t5419 t5420 := result (f := t22) (a := t5398) (u := t24) (v := t5421) pv22 (aw (ra t1 t5398)) pv5421
theorem pv5417 : R t5417 t5420 := result (f := t5401) (a := t1) (u := t5401) (v := t5419) (refl t5401) (awb t0 t5398 t1 t1 (cI)) pv5419
theorem pv5426 : R t5426 t1 := result (f := t4811) (a := t1) (u := t149) (v := t231) pv4811 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv5427 : R t5427 t1 := result (f := t5426) (a := t1) (u := t1) (v := t1) pv5426 (aw (ri t1)) (refl t1)
theorem pv5344 : R t5344 t1 := result (f := t5342) (a := t1) (u := t5342) (v := t5427) (refl t5342) (awb t4811 t1 t1 t1 (cI)) pv5427
theorem pv5425 : R t5425 t1 := result (f := t3) (a := t5344) (u := t1) (v := t5344) pv3 (aw (ri t5344)) pv5344
theorem pv5423 : R t5423 t1 := result (f := t5360) (a := t1) (u := t5347) (v := t5425) pv5360 (awb t2 t5344 t1 t1 (cI)) pv5425
theorem pv5424 : R t5424 t1 := result (f := t5423) (a := t1) (u := t1) (v := t1) pv5423 (aw (ri t1)) (refl t1)
theorem pv5398 : R t5398 t1 := result (f := t5396) (a := t1) (u := t5396) (v := t5424) (refl t5396) (awb t5360 t1 t1 t1 (cI)) pv5424
theorem pv5422 : R t5422 t1 := result (f := t28) (a := t5398) (u := t1) (v := t5398) pv28 (aw (ri t5398)) pv5398
theorem pv5418 : R t5418 t1 := result (f := t5417) (a := t1) (u := t5420) (v := t5422) pv5417 (awb t1 t5398 t1 t1 (cI)) pv5422
theorem pv5412 : R t5412 t1 := result (f := t5410) (a := t1) (u := t5410) (v := t5418) (refl t5410) (awb t5401 t1 t1 t1 (cI)) pv5418
theorem pv5416 : R t5416 t5415 := result (f := t5412) (a := t5415) (u := t1) (v := t5415) pv5412 (aw (ri t5415)) (refl t5415)
theorem pv5413 : R t5413 t5415 := result (f := t0) (a := t5412) (u := t0) (v := t5416) (refl t0) (aw (rh t5412)) pv5416
theorem pv5429 : R t5429 t5428 := result (f := t5412) (a := t5428) (u := t1) (v := t5428) pv5412 (aw (ri t5428)) (refl t5428)
theorem pv5414 : R t5414 t5428 := result (f := t5413) (a := t5398) (u := t5415) (v := t5429) pv5413 (aw (ra t5412 t5398)) pv5429
theorem pv5411 : R t5411 t5428 := result (f := t5401) (a := t5410) (u := t5401) (v := t5414) (refl t5401) (awb t0 t5398 t5410 t5412 (refl _)) pv5414
theorem pv5405 : R t5405 t5428 := result (f := t5403) (a := t1) (u := t5403) (v := t5411) (refl t5403) (aw (ra t5401 t1)) pv5411
theorem pv5440 : R t5440 t1 := result (f := t5412) (a := t1) (u := t1) (v := t1) pv5412 (aw (ri t1)) (refl t1)
theorem pv5441 : R t5441 t1 := result (f := t5440) (a := t5398) (u := t1) (v := t5398) pv5440 (aw (ri t5398)) pv5398
theorem pv5438 : R t5438 t1 := result (f := t5405) (a := t1) (u := t5428) (v := t5441) pv5405 (awb t5412 t5398 t1 t1 (cI)) pv5441
theorem pv5439 : R t5439 t1 := result (f := t5438) (a := t1) (u := t1) (v := t1) pv5438 (aw (ri t1)) (refl t1)
theorem pv5435 : R t5435 t1 := result (f := t5433) (a := t1) (u := t5433) (v := t5439) (refl t5433) (awb t5405 t1 t1 t1 (cI)) pv5439
theorem pv5436 : R t5436 t1 := result (f := t5412) (a := t5435) (u := t1) (v := t5435) pv5412 (aw (ri t5435)) pv5435
theorem pv5437 : R t5437 t1 := result (f := t5436) (a := t5398) (u := t1) (v := t5398) pv5436 (aw (ri t5398)) pv5398
theorem pv5434 : R t5434 t1 := result (f := t5405) (a := t5433) (u := t5428) (v := t5437) pv5405 (awb t5412 t5398 t5433 t5435 (refl _)) pv5437
theorem pv5430 : R t5430 t1 := result (f := t5408) (a := t1) (u := t5408) (v := t5434) (refl t5408) (aw (ra t5405 t1)) pv5434
theorem pv5431 : R t5431 t1 := result (f := t5412) (a := t5430) (u := t1) (v := t5430) pv5412 (aw (ri t5430)) pv5430
theorem pv5432 : R t5432 t1 := result (f := t5431) (a := t5398) (u := t1) (v := t5398) pv5431 (aw (ri t5398)) pv5398
theorem pv5409 : R t5409 t1 := result (f := t5405) (a := t5408) (u := t5428) (v := t5432) pv5405 (awb t5412 t5398 t5408 t5430 (refl _)) pv5432
theorem pv5406 : R t5406 t1 := result (f := t0) (a := t5405) (u := t0) (v := t5409) (refl t0) (aw (rh t5405)) pv5409
theorem pv5407 : R t5407 t1 := result (f := t5406) (a := t5398) (u := t1) (v := t5398) pv5406 (aw (ri t5398)) pv5398
theorem pv5404 : R t5404 t1 := result (f := t5401) (a := t5403) (u := t5401) (v := t5407) (refl t5401) (awb t0 t5398 t5403 t5405 (refl _)) pv5407
theorem pv5402 : R t5402 t1 := result (f := t0) (a := t5401) (u := t0) (v := t5404) (refl t0) (aw (rh t5401)) pv5404
theorem pv5399 : R t5399 t1 := result (f := t2) (a := t5398) (u := t2) (v := t5402) (refl t2) (aw (ra t0 t5398)) pv5402
theorem pv5400 : R t5400 t1 := result (f := t5399) (a := t5344) (u := t1) (v := t5344) pv5399 (aw (ri t5344)) pv5344
theorem pv5397 : R t5397 t1 := result (f := t5360) (a := t5396) (u := t5347) (v := t5400) pv5360 (awb t2 t5344 t5396 t5398 (refl _)) pv5400
end Blc.H44.Pump
