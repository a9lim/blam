import H44Literals
import H44F4846434772678
import H44F4846434860086
import H44Lib0
import H44Lib4
namespace Blc.H44
theorem ex_e4846434750074 : ¬ IsSelfInterpreter e4846434750074 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846434750074 1 = true)
#print axioms ex_e4846434750074
theorem ex_e4846434752758 : ¬ IsSelfInterpreter e4846434752758 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846434752758 1 = true)
#print axioms ex_e4846434752758
theorem ex_e4846434754190 : ¬ IsSelfInterpreter e4846434754190 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846434754190 1 = true)
#print axioms ex_e4846434754190
theorem ex_e4846434772678 : ¬ IsSelfInterpreter e4846434772678 := H44F4846434772678.excluded
#print axioms ex_e4846434772678
theorem ex_e4846434860086 : ¬ IsSelfInterpreter e4846434860086 := H44F4846434860086.excluded
#print axioms ex_e4846434860086
theorem ex_e4846435966202 : ¬ IsSelfInterpreter e4846435966202 := Lib4.excluded (by decide : Types.has Lib4.tab Lib4.env e4846435966202 4 = true)
#print axioms ex_e4846435966202
end Blc.H44
