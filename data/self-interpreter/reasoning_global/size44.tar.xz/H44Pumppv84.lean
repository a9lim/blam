import H44Pumppv83
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5713 : R t5713 t1 := result (f := t5705) (a := t1) (u := t5705) (v := t5739) (refl t5705) (aw (ra t5702 t1)) pv5739
theorem pv5737 : R t5737 t1 := result (f := t28) (a := t5713) (u := t1) (v := t5713) pv28 (aw (ri t5713)) pv5713
theorem pv5733 : R t5733 t1 := result (f := t5732) (a := t1) (u := t5735) (v := t5737) pv5732 (awb t1 t5713 t1 t1 (cI)) pv5737
theorem pv5727 : R t5727 t1 := result (f := t5725) (a := t1) (u := t5725) (v := t5733) (refl t5725) (awb t5716 t1 t1 t1 (cI)) pv5733
theorem pv5731 : R t5731 t5730 := result (f := t5727) (a := t5730) (u := t1) (v := t5730) pv5727 (aw (ri t5730)) (refl t5730)
theorem pv5728 : R t5728 t5730 := result (f := t0) (a := t5727) (u := t0) (v := t5731) (refl t0) (aw (rh t5727)) pv5731
theorem pv5979 : R t5979 t5978 := result (f := t5727) (a := t5978) (u := t1) (v := t5978) pv5727 (aw (ri t5978)) (refl t5978)
theorem pv5729 : R t5729 t5978 := result (f := t5728) (a := t5713) (u := t5730) (v := t5979) pv5728 (aw (ra t5727 t5713)) pv5979
theorem pv5726 : R t5726 t5978 := result (f := t5716) (a := t5725) (u := t5716) (v := t5729) (refl t5716) (awb t0 t5713 t5725 t5727 (refl _)) pv5729
theorem pv5720 : R t5720 t5978 := result (f := t5718) (a := t1) (u := t5718) (v := t5726) (refl t5718) (aw (ra t5716 t1)) pv5726
theorem pv5990 : R t5990 t1 := result (f := t5727) (a := t1) (u := t1) (v := t1) pv5727 (aw (ri t1)) (refl t1)
theorem pv5991 : R t5991 t1 := result (f := t5990) (a := t5713) (u := t1) (v := t5713) pv5990 (aw (ri t5713)) pv5713
theorem pv5988 : R t5988 t1 := result (f := t5720) (a := t1) (u := t5978) (v := t5991) pv5720 (awb t5727 t5713 t1 t1 (cI)) pv5991
theorem pv5989 : R t5989 t1 := result (f := t5988) (a := t1) (u := t1) (v := t1) pv5988 (aw (ri t1)) (refl t1)
theorem pv5985 : R t5985 t1 := result (f := t5983) (a := t1) (u := t5983) (v := t5989) (refl t5983) (awb t5720 t1 t1 t1 (cI)) pv5989
theorem pv5986 : R t5986 t1 := result (f := t5727) (a := t5985) (u := t1) (v := t5985) pv5727 (aw (ri t5985)) pv5985
theorem pv5987 : R t5987 t1 := result (f := t5986) (a := t5713) (u := t1) (v := t5713) pv5986 (aw (ri t5713)) pv5713
theorem pv5984 : R t5984 t1 := result (f := t5720) (a := t5983) (u := t5978) (v := t5987) pv5720 (awb t5727 t5713 t5983 t5985 (refl _)) pv5987
theorem pv5980 : R t5980 t1 := result (f := t5723) (a := t1) (u := t5723) (v := t5984) (refl t5723) (aw (ra t5720 t1)) pv5984
theorem pv5981 : R t5981 t1 := result (f := t5727) (a := t5980) (u := t1) (v := t5980) pv5727 (aw (ri t5980)) pv5980
theorem pv5982 : R t5982 t1 := result (f := t5981) (a := t5713) (u := t1) (v := t5713) pv5981 (aw (ri t5713)) pv5713
theorem pv5724 : R t5724 t1 := result (f := t5720) (a := t5723) (u := t5978) (v := t5982) pv5720 (awb t5727 t5713 t5723 t5980 (refl _)) pv5982
theorem pv5721 : R t5721 t1 := result (f := t0) (a := t5720) (u := t0) (v := t5724) (refl t0) (aw (rh t5720)) pv5724
theorem pv5722 : R t5722 t1 := result (f := t5721) (a := t5713) (u := t1) (v := t5713) pv5721 (aw (ri t5713)) pv5713
theorem pv5719 : R t5719 t1 := result (f := t5716) (a := t5718) (u := t5716) (v := t5722) (refl t5716) (awb t0 t5713 t5718 t5720 (refl _)) pv5722
theorem pv5717 : R t5717 t1 := result (f := t0) (a := t5716) (u := t0) (v := t5719) (refl t0) (aw (rh t5716)) pv5719
theorem pv5714 : R t5714 t1 := result (f := t2) (a := t5713) (u := t2) (v := t5717) (refl t2) (aw (ra t0 t5713)) pv5717
theorem pv5715 : R t5715 t1 := result (f := t5714) (a := t5686) (u := t1) (v := t5686) pv5714 (aw (ri t5686)) pv5686
theorem pv5706 : R t5706 t1 := result (f := t5702) (a := t5705) (u := t5689) (v := t5715) pv5702 (awb t2 t5686 t5705 t5713 (refl _)) pv5715
theorem pv5703 : R t5703 t1 := result (f := t0) (a := t5702) (u := t0) (v := t5706) (refl t0) (aw (rh t5702)) pv5706
theorem pv5704 : R t5704 t5689 := result (f := t5703) (a := t5689) (u := t1) (v := t5689) pv5703 (aw (ri t5689)) (refl t5689)
theorem pv5701 : R t5701 t5689 := result (f := t5691) (a := t5700) (u := t5691) (v := t5704) (refl t5691) (awb t0 t5689 t5700 t5702 (refl _)) pv5704
theorem pv5695 : R t5695 t5689 := result (f := t5693) (a := t1) (u := t5693) (v := t5701) (refl t5693) (aw (ra t5691 t1)) pv5701
theorem pv6015 : R t6015 t6014 := result (f := t1) (a := t6014) (u := t1) (v := t6014) (refl t1) (aw (ri t6014)) (refl t6014)
theorem pv6013 : R t6013 t6014 := result (f := t22) (a := t5992) (u := t24) (v := t6015) pv22 (aw (ra t1 t5992)) pv6015
theorem pv6011 : R t6011 t6014 := result (f := t5995) (a := t1) (u := t5995) (v := t6013) (refl t5995) (awb t0 t5992 t1 t1 (cI)) pv6013
theorem pv6042 : R t6042 t6041 := result (f := t1) (a := t6041) (u := t1) (v := t6041) (refl t1) (aw (ri t6041)) (refl t6041)
theorem pv6040 : R t6040 t6041 := result (f := t22) (a := t6019) (u := t24) (v := t6042) pv22 (aw (ra t1 t6019)) pv6042
theorem pv6038 : R t6038 t6041 := result (f := t6022) (a := t1) (u := t6022) (v := t6040) (refl t6022) (awb t0 t6019 t1 t1 (cI)) pv6040
theorem pv6044 : R t6044 t1 := result (f := t5695) (a := t1) (u := t5689) (v := t5767) pv5695 (awb t2 t5686 t1 t1 (cI)) pv5767
theorem pv6045 : R t6045 t1 := result (f := t6044) (a := t1) (u := t1) (v := t1) pv6044 (aw (ri t1)) (refl t1)
theorem pv6019 : R t6019 t1 := result (f := t6017) (a := t1) (u := t6017) (v := t6045) (refl t6017) (awb t5695 t1 t1 t1 (cI)) pv6045
theorem pv6043 : R t6043 t1 := result (f := t28) (a := t6019) (u := t1) (v := t6019) pv28 (aw (ri t6019)) pv6019
theorem pv6039 : R t6039 t1 := result (f := t6038) (a := t1) (u := t6041) (v := t6043) pv6038 (awb t1 t6019 t1 t1 (cI)) pv6043
theorem pv6033 : R t6033 t1 := result (f := t6031) (a := t1) (u := t6031) (v := t6039) (refl t6031) (awb t6022 t1 t1 t1 (cI)) pv6039
theorem pv6037 : R t6037 t6036 := result (f := t6033) (a := t6036) (u := t1) (v := t6036) pv6033 (aw (ri t6036)) (refl t6036)
theorem pv6034 : R t6034 t6036 := result (f := t0) (a := t6033) (u := t0) (v := t6037) (refl t0) (aw (rh t6033)) pv6037
theorem pv6047 : R t6047 t6046 := result (f := t6033) (a := t6046) (u := t1) (v := t6046) pv6033 (aw (ri t6046)) (refl t6046)
theorem pv6035 : R t6035 t6046 := result (f := t6034) (a := t6019) (u := t6036) (v := t6047) pv6034 (aw (ra t6033 t6019)) pv6047
theorem pv6032 : R t6032 t6046 := result (f := t6022) (a := t6031) (u := t6022) (v := t6035) (refl t6022) (awb t0 t6019 t6031 t6033 (refl _)) pv6035
theorem pv6026 : R t6026 t6046 := result (f := t6024) (a := t1) (u := t6024) (v := t6032) (refl t6024) (aw (ra t6022 t1)) pv6032
theorem pv6058 : R t6058 t1 := result (f := t6033) (a := t1) (u := t1) (v := t1) pv6033 (aw (ri t1)) (refl t1)
theorem pv6059 : R t6059 t1 := result (f := t6058) (a := t6019) (u := t1) (v := t6019) pv6058 (aw (ri t6019)) pv6019
theorem pv6056 : R t6056 t1 := result (f := t6026) (a := t1) (u := t6046) (v := t6059) pv6026 (awb t6033 t6019 t1 t1 (cI)) pv6059
theorem pv6057 : R t6057 t1 := result (f := t6056) (a := t1) (u := t1) (v := t1) pv6056 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
