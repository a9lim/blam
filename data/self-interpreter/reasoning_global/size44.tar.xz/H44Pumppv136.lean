import H44Pumppv135
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9537 : R t9537 t1 := result (f := t0) (a := t9536) (u := t0) (v := t9539) (refl t0) (aw (rh t9536)) pv9539
theorem pv9534 : R t9534 t1 := result (f := t2) (a := t9533) (u := t2) (v := t9537) (refl t2) (aw (ra t0 t9533)) pv9537
theorem pv9535 : R t9535 t1 := result (f := t9534) (a := t9227) (u := t1) (v := t9227) pv9534 (aw (ri t9227)) pv9227
theorem pv9240 : R t9240 t1 := result (f := t9236) (a := t9239) (u := t9230) (v := t9535) pv9236 (awb t2 t9227 t9239 t9533 (refl _)) pv9535
theorem pv9237 : R t9237 t1 := result (f := t0) (a := t9236) (u := t0) (v := t9240) (refl t0) (aw (rh t9236)) pv9240
theorem pv9238 : R t9238 t9230 := result (f := t9237) (a := t9230) (u := t1) (v := t9230) pv9237 (aw (ri t9230)) (refl t9230)
theorem pv9235 : R t9235 t9230 := result (f := t9232) (a := t9234) (u := t9232) (v := t9238) (refl t9232) (awb t0 t9230 t9234 t9236 (refl _)) pv9238
theorem pv9233 : R t9233 t9230 := result (f := t0) (a := t9232) (u := t0) (v := t9235) (refl t0) (aw (rh t9232)) pv9235
theorem pv9231 : R t9231 t9230 := result (f := t2) (a := t9230) (u := t2) (v := t9233) (refl t2) (aw (ra t0 t9230)) pv9233
theorem pv9228 : R t9228 t9230 := result (f := t59) (a := t9227) (u := t46) (v := t9231) pv59 (aw (ra t2 t9227)) pv9231
theorem pv9229 : R t9229 t1 := result (f := t9228) (a := t1) (u := t9230) (v := t9308) pv9228 (awb t2 t9227 t1 t1 (cI)) pv9308
theorem pv6506 : R t6506 t1 := result (f := t6502) (a := t6505) (u := t149) (v := t9229) pv6502 (awb t59 t1 t6505 t9227 (refl _)) pv9229
theorem pv6503 : R t6503 t1 := result (f := t0) (a := t6502) (u := t0) (v := t6506) (refl t0) (aw (rh t6502)) pv6506
theorem pv6504 : R t6504 t149 := result (f := t6503) (a := t6488) (u := t1) (v := t6488) pv6503 (aw (ri t6488)) pv6488
theorem pv6501 : R t6501 t149 := result (f := t6491) (a := t6500) (u := t6491) (v := t6504) (refl t6491) (awb t0 t6488 t6500 t6502 (refl _)) pv6504
theorem pv6495 : R t6495 t149 := result (f := t6493) (a := t1) (u := t6493) (v := t6501) (refl t6493) (aw (ra t6491 t1)) pv6501
theorem pv9640 : R t9640 t9639 := result (f := t1) (a := t9639) (u := t1) (v := t9639) (refl t1) (aw (ri t9639)) (refl t9639)
theorem pv9638 : R t9638 t9639 := result (f := t22) (a := t9618) (u := t24) (v := t9640) pv22 (aw (ra t1 t9618)) pv9640
theorem pv9636 : R t9636 t9639 := result (f := t9620) (a := t1) (u := t9620) (v := t9638) (refl t9620) (awb t0 t9618 t1 t1 (cI)) pv9638
theorem pv9641 : R t9641 t9618 := result (f := t28) (a := t9618) (u := t1) (v := t9618) pv28 (aw (ri t9618)) (refl t9618)
theorem pv9637 : R t9637 t9618 := result (f := t9636) (a := t1) (u := t9639) (v := t9641) pv9636 (awb t1 t9618 t1 t1 (cI)) pv9641
theorem pv9631 : R t9631 t9618 := result (f := t9629) (a := t1) (u := t9629) (v := t9637) (refl t9629) (awb t9620 t1 t1 t1 (cI)) pv9637
theorem pv9665 : R t9665 t9664 := result (f := t1) (a := t9664) (u := t1) (v := t9664) (refl t1) (aw (ri t9664)) (refl t9664)
theorem pv9663 : R t9663 t9664 := result (f := t22) (a := t9642) (u := t24) (v := t9665) pv22 (aw (ra t1 t9642)) pv9665
theorem pv9661 : R t9661 t9664 := result (f := t9645) (a := t1) (u := t9645) (v := t9663) (refl t9645) (awb t0 t9642 t1 t1 (cI)) pv9663
theorem pv9692 : R t9692 t9691 := result (f := t1) (a := t9691) (u := t1) (v := t9691) (refl t1) (aw (ri t9691)) (refl t9691)
theorem pv9690 : R t9690 t9691 := result (f := t22) (a := t9669) (u := t24) (v := t9692) pv22 (aw (ra t1 t9669)) pv9692
theorem pv9688 : R t9688 t9691 := result (f := t9672) (a := t1) (u := t9672) (v := t9690) (refl t9672) (awb t0 t9669 t1 t1 (cI)) pv9690
theorem pv9724 : R t9724 t9723 := result (f := t1) (a := t9723) (u := t1) (v := t9723) (refl t1) (aw (ri t9723)) (refl t9723)
theorem pv9722 : R t9722 t9723 := result (f := t22) (a := t9702) (u := t24) (v := t9724) pv22 (aw (ra t1 t9702)) pv9724
theorem pv9720 : R t9720 t9723 := result (f := t9704) (a := t1) (u := t9704) (v := t9722) (refl t9704) (awb t0 t9702 t1 t1 (cI)) pv9722
theorem pv9725 : R t9725 t9702 := result (f := t28) (a := t9702) (u := t1) (v := t9702) pv28 (aw (ri t9702)) (refl t9702)
theorem pv9721 : R t9721 t9702 := result (f := t9720) (a := t1) (u := t9723) (v := t9725) pv9720 (awb t1 t9702 t1 t1 (cI)) pv9725
theorem pv9715 : R t9715 t9702 := result (f := t9713) (a := t1) (u := t9713) (v := t9721) (refl t9713) (awb t9704 t1 t1 t1 (cI)) pv9721
theorem pv9749 : R t9749 t9748 := result (f := t1) (a := t9748) (u := t1) (v := t9748) (refl t1) (aw (ri t9748)) (refl t9748)
theorem pv9747 : R t9747 t9748 := result (f := t22) (a := t9726) (u := t24) (v := t9749) pv22 (aw (ra t1 t9726)) pv9749
theorem pv9745 : R t9745 t9748 := result (f := t9729) (a := t1) (u := t9729) (v := t9747) (refl t9729) (awb t0 t9726 t1 t1 (cI)) pv9747
theorem pv9776 : R t9776 t9775 := result (f := t1) (a := t9775) (u := t1) (v := t9775) (refl t1) (aw (ri t9775)) (refl t9775)
theorem pv9774 : R t9774 t9775 := result (f := t22) (a := t9753) (u := t24) (v := t9776) pv22 (aw (ra t1 t9753)) pv9776
theorem pv9772 : R t9772 t9775 := result (f := t9756) (a := t1) (u := t9756) (v := t9774) (refl t9756) (awb t0 t9753 t1 t1 (cI)) pv9774
theorem pv9781 : R t9781 t1 := result (f := t6495) (a := t1) (u := t149) (v := t231) pv6495 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv9782 : R t9782 t1 := result (f := t9781) (a := t1) (u := t1) (v := t1) pv9781 (aw (ri t1)) (refl t1)
theorem pv9699 : R t9699 t1 := result (f := t9697) (a := t1) (u := t9697) (v := t9782) (refl t9697) (awb t6495 t1 t1 t1 (cI)) pv9782
theorem pv9780 : R t9780 t1 := result (f := t3) (a := t9699) (u := t1) (v := t9699) pv3 (aw (ri t9699)) pv9699
theorem pv9778 : R t9778 t1 := result (f := t9715) (a := t1) (u := t9702) (v := t9780) pv9715 (awb t2 t9699 t1 t1 (cI)) pv9780
theorem pv9779 : R t9779 t1 := result (f := t9778) (a := t1) (u := t1) (v := t1) pv9778 (aw (ri t1)) (refl t1)
theorem pv9753 : R t9753 t1 := result (f := t9751) (a := t1) (u := t9751) (v := t9779) (refl t9751) (awb t9715 t1 t1 t1 (cI)) pv9779
theorem pv9777 : R t9777 t1 := result (f := t28) (a := t9753) (u := t1) (v := t9753) pv28 (aw (ri t9753)) pv9753
theorem pv9773 : R t9773 t1 := result (f := t9772) (a := t1) (u := t9775) (v := t9777) pv9772 (awb t1 t9753 t1 t1 (cI)) pv9777
theorem pv9767 : R t9767 t1 := result (f := t9765) (a := t1) (u := t9765) (v := t9773) (refl t9765) (awb t9756 t1 t1 t1 (cI)) pv9773
theorem pv9771 : R t9771 t9770 := result (f := t9767) (a := t9770) (u := t1) (v := t9770) pv9767 (aw (ri t9770)) (refl t9770)
theorem pv9768 : R t9768 t9770 := result (f := t0) (a := t9767) (u := t0) (v := t9771) (refl t0) (aw (rh t9767)) pv9771
theorem pv9784 : R t9784 t9783 := result (f := t9767) (a := t9783) (u := t1) (v := t9783) pv9767 (aw (ri t9783)) (refl t9783)
theorem pv9769 : R t9769 t9783 := result (f := t9768) (a := t9753) (u := t9770) (v := t9784) pv9768 (aw (ra t9767 t9753)) pv9784
theorem pv9766 : R t9766 t9783 := result (f := t9756) (a := t9765) (u := t9756) (v := t9769) (refl t9756) (awb t0 t9753 t9765 t9767 (refl _)) pv9769
end Blc.H44.Pump
