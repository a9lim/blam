import H44Pumppv49
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3710 : R t3710 t1 := result (f := t3647) (a := t1) (u := t3634) (v := t3712) pv3647 (awb t2 t3631 t1 t1 (cI)) pv3712
theorem pv3711 : R t3711 t1 := result (f := t3710) (a := t1) (u := t1) (v := t1) pv3710 (aw (ri t1)) (refl t1)
theorem pv3685 : R t3685 t1 := result (f := t3683) (a := t1) (u := t3683) (v := t3711) (refl t3683) (awb t3647 t1 t1 t1 (cI)) pv3711
theorem pv3709 : R t3709 t1 := result (f := t28) (a := t3685) (u := t1) (v := t3685) pv28 (aw (ri t3685)) pv3685
theorem pv3705 : R t3705 t1 := result (f := t3704) (a := t1) (u := t3707) (v := t3709) pv3704 (awb t1 t3685 t1 t1 (cI)) pv3709
theorem pv3699 : R t3699 t1 := result (f := t3697) (a := t1) (u := t3697) (v := t3705) (refl t3697) (awb t3688 t1 t1 t1 (cI)) pv3705
theorem pv3703 : R t3703 t3702 := result (f := t3699) (a := t3702) (u := t1) (v := t3702) pv3699 (aw (ri t3702)) (refl t3702)
theorem pv3700 : R t3700 t3702 := result (f := t0) (a := t3699) (u := t0) (v := t3703) (refl t0) (aw (rh t3699)) pv3703
theorem pv3716 : R t3716 t3715 := result (f := t3699) (a := t3715) (u := t1) (v := t3715) pv3699 (aw (ri t3715)) (refl t3715)
theorem pv3701 : R t3701 t3715 := result (f := t3700) (a := t3685) (u := t3702) (v := t3716) pv3700 (aw (ra t3699 t3685)) pv3716
theorem pv3698 : R t3698 t3715 := result (f := t3688) (a := t3697) (u := t3688) (v := t3701) (refl t3688) (awb t0 t3685 t3697 t3699 (refl _)) pv3701
theorem pv3692 : R t3692 t3715 := result (f := t3690) (a := t1) (u := t3690) (v := t3698) (refl t3690) (aw (ra t3688 t1)) pv3698
theorem pv3727 : R t3727 t1 := result (f := t3699) (a := t1) (u := t1) (v := t1) pv3699 (aw (ri t1)) (refl t1)
theorem pv3728 : R t3728 t1 := result (f := t3727) (a := t3685) (u := t1) (v := t3685) pv3727 (aw (ri t3685)) pv3685
theorem pv3725 : R t3725 t1 := result (f := t3692) (a := t1) (u := t3715) (v := t3728) pv3692 (awb t3699 t3685 t1 t1 (cI)) pv3728
theorem pv3726 : R t3726 t1 := result (f := t3725) (a := t1) (u := t1) (v := t1) pv3725 (aw (ri t1)) (refl t1)
theorem pv3722 : R t3722 t1 := result (f := t3720) (a := t1) (u := t3720) (v := t3726) (refl t3720) (awb t3692 t1 t1 t1 (cI)) pv3726
theorem pv3723 : R t3723 t1 := result (f := t3699) (a := t3722) (u := t1) (v := t3722) pv3699 (aw (ri t3722)) pv3722
theorem pv3724 : R t3724 t1 := result (f := t3723) (a := t3685) (u := t1) (v := t3685) pv3723 (aw (ri t3685)) pv3685
theorem pv3721 : R t3721 t1 := result (f := t3692) (a := t3720) (u := t3715) (v := t3724) pv3692 (awb t3699 t3685 t3720 t3722 (refl _)) pv3724
theorem pv3717 : R t3717 t1 := result (f := t3695) (a := t1) (u := t3695) (v := t3721) (refl t3695) (aw (ra t3692 t1)) pv3721
theorem pv3718 : R t3718 t1 := result (f := t3699) (a := t3717) (u := t1) (v := t3717) pv3699 (aw (ri t3717)) pv3717
theorem pv3719 : R t3719 t1 := result (f := t3718) (a := t3685) (u := t1) (v := t3685) pv3718 (aw (ri t3685)) pv3685
theorem pv3696 : R t3696 t1 := result (f := t3692) (a := t3695) (u := t3715) (v := t3719) pv3692 (awb t3699 t3685 t3695 t3717 (refl _)) pv3719
theorem pv3693 : R t3693 t1 := result (f := t0) (a := t3692) (u := t0) (v := t3696) (refl t0) (aw (rh t3692)) pv3696
theorem pv3694 : R t3694 t1 := result (f := t3693) (a := t3685) (u := t1) (v := t3685) pv3693 (aw (ri t3685)) pv3685
theorem pv3691 : R t3691 t1 := result (f := t3688) (a := t3690) (u := t3688) (v := t3694) (refl t3688) (awb t0 t3685 t3690 t3692 (refl _)) pv3694
theorem pv3689 : R t3689 t1 := result (f := t0) (a := t3688) (u := t0) (v := t3691) (refl t0) (aw (rh t3688)) pv3691
theorem pv3686 : R t3686 t1 := result (f := t2) (a := t3685) (u := t2) (v := t3689) (refl t2) (aw (ra t0 t3685)) pv3689
theorem pv3687 : R t3687 t1 := result (f := t3686) (a := t3631) (u := t1) (v := t3631) pv3686 (aw (ri t3631)) pv3631
theorem pv3684 : R t3684 t1 := result (f := t3647) (a := t3683) (u := t3634) (v := t3687) pv3647 (awb t2 t3631 t3683 t3685 (refl _)) pv3687
theorem pv3658 : R t3658 t1 := result (f := t3650) (a := t1) (u := t3650) (v := t3684) (refl t3650) (aw (ra t3647 t1)) pv3684
theorem pv3682 : R t3682 t1 := result (f := t28) (a := t3658) (u := t1) (v := t3658) pv28 (aw (ri t3658)) pv3658
theorem pv3678 : R t3678 t1 := result (f := t3677) (a := t1) (u := t3680) (v := t3682) pv3677 (awb t1 t3658 t1 t1 (cI)) pv3682
theorem pv3672 : R t3672 t1 := result (f := t3670) (a := t1) (u := t3670) (v := t3678) (refl t3670) (awb t3661 t1 t1 t1 (cI)) pv3678
theorem pv3676 : R t3676 t3675 := result (f := t3672) (a := t3675) (u := t1) (v := t3675) pv3672 (aw (ri t3675)) (refl t3675)
theorem pv3673 : R t3673 t3675 := result (f := t0) (a := t3672) (u := t0) (v := t3676) (refl t0) (aw (rh t3672)) pv3676
theorem pv3730 : R t3730 t3729 := result (f := t3672) (a := t3729) (u := t1) (v := t3729) pv3672 (aw (ri t3729)) (refl t3729)
theorem pv3674 : R t3674 t3729 := result (f := t3673) (a := t3658) (u := t3675) (v := t3730) pv3673 (aw (ra t3672 t3658)) pv3730
theorem pv3671 : R t3671 t3729 := result (f := t3661) (a := t3670) (u := t3661) (v := t3674) (refl t3661) (awb t0 t3658 t3670 t3672 (refl _)) pv3674
theorem pv3665 : R t3665 t3729 := result (f := t3663) (a := t1) (u := t3663) (v := t3671) (refl t3663) (aw (ra t3661 t1)) pv3671
theorem pv3741 : R t3741 t1 := result (f := t3672) (a := t1) (u := t1) (v := t1) pv3672 (aw (ri t1)) (refl t1)
theorem pv3742 : R t3742 t1 := result (f := t3741) (a := t3658) (u := t1) (v := t3658) pv3741 (aw (ri t3658)) pv3658
theorem pv3739 : R t3739 t1 := result (f := t3665) (a := t1) (u := t3729) (v := t3742) pv3665 (awb t3672 t3658 t1 t1 (cI)) pv3742
theorem pv3740 : R t3740 t1 := result (f := t3739) (a := t1) (u := t1) (v := t1) pv3739 (aw (ri t1)) (refl t1)
theorem pv3736 : R t3736 t1 := result (f := t3734) (a := t1) (u := t3734) (v := t3740) (refl t3734) (awb t3665 t1 t1 t1 (cI)) pv3740
theorem pv3737 : R t3737 t1 := result (f := t3672) (a := t3736) (u := t1) (v := t3736) pv3672 (aw (ri t3736)) pv3736
theorem pv3738 : R t3738 t1 := result (f := t3737) (a := t3658) (u := t1) (v := t3658) pv3737 (aw (ri t3658)) pv3658
theorem pv3735 : R t3735 t1 := result (f := t3665) (a := t3734) (u := t3729) (v := t3738) pv3665 (awb t3672 t3658 t3734 t3736 (refl _)) pv3738
theorem pv3731 : R t3731 t1 := result (f := t3668) (a := t1) (u := t3668) (v := t3735) (refl t3668) (aw (ra t3665 t1)) pv3735
theorem pv3732 : R t3732 t1 := result (f := t3672) (a := t3731) (u := t1) (v := t3731) pv3672 (aw (ri t3731)) pv3731
theorem pv3733 : R t3733 t1 := result (f := t3732) (a := t3658) (u := t1) (v := t3658) pv3732 (aw (ri t3658)) pv3658
theorem pv3669 : R t3669 t1 := result (f := t3665) (a := t3668) (u := t3729) (v := t3733) pv3665 (awb t3672 t3658 t3668 t3731 (refl _)) pv3733
theorem pv3666 : R t3666 t1 := result (f := t0) (a := t3665) (u := t0) (v := t3669) (refl t0) (aw (rh t3665)) pv3669
theorem pv3667 : R t3667 t1 := result (f := t3666) (a := t3658) (u := t1) (v := t3658) pv3666 (aw (ri t3658)) pv3658
end Blc.H44.Pump
