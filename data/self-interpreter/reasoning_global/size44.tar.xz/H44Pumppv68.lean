import H44Pumppv67
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv4864 : R t4864 t1 := result (f := t4838) (a := t4863) (u := t4858) (v := t4867) pv4838 (awb t4845 t4831 t4863 t4865 (refl _)) pv4867
theorem pv4860 : R t4860 t1 := result (f := t4841) (a := t1) (u := t4841) (v := t4864) (refl t4841) (aw (ra t4838 t1)) pv4864
theorem pv4861 : R t4861 t1 := result (f := t4845) (a := t4860) (u := t1) (v := t4860) pv4845 (aw (ri t4860)) pv4860
theorem pv4862 : R t4862 t1 := result (f := t4861) (a := t4831) (u := t1) (v := t4831) pv4861 (aw (ri t4831)) pv4831
theorem pv4842 : R t4842 t1 := result (f := t4838) (a := t4841) (u := t4858) (v := t4862) pv4838 (awb t4845 t4831 t4841 t4860 (refl _)) pv4862
theorem pv4839 : R t4839 t1 := result (f := t0) (a := t4838) (u := t0) (v := t4842) (refl t0) (aw (rh t4838)) pv4842
theorem pv4840 : R t4840 t1 := result (f := t4839) (a := t4831) (u := t1) (v := t4831) pv4839 (aw (ri t4831)) pv4831
theorem pv4837 : R t4837 t1 := result (f := t4834) (a := t4836) (u := t4834) (v := t4840) (refl t4834) (awb t0 t4831 t4836 t4838 (refl _)) pv4840
theorem pv4835 : R t4835 t1 := result (f := t0) (a := t4834) (u := t0) (v := t4837) (refl t0) (aw (rh t4834)) pv4837
theorem pv4832 : R t4832 t1 := result (f := t2) (a := t4831) (u := t2) (v := t4835) (refl t2) (aw (ra t0 t4831)) pv4835
theorem pv4833 : R t4833 t149 := result (f := t4832) (a := t149) (u := t1) (v := t149) pv4832 (aw (ri t149)) (refl t149)
theorem pv4830 : R t4830 t149 := result (f := t3942) (a := t4829) (u := t151) (v := t4833) pv3942 (awb t2 t149 t4829 t4831 (refl _)) pv4833
theorem pv4804 : R t4804 t149 := result (f := t3945) (a := t1) (u := t3945) (v := t4830) (refl t3945) (aw (ra t3942 t1)) pv4830
theorem pv4828 : R t4828 t149 := result (f := t28) (a := t4804) (u := t1) (v := t4804) pv28 (aw (ri t4804)) pv4804
theorem pv4824 : R t4824 t149 := result (f := t4823) (a := t1) (u := t4826) (v := t4828) pv4823 (awb t1 t4804 t1 t1 (cI)) pv4828
theorem pv4818 : R t4818 t149 := result (f := t4816) (a := t1) (u := t4816) (v := t4824) (refl t4816) (awb t4807 t1 t1 t1 (cI)) pv4824
theorem pv4897 : R t4897 t4896 := result (f := t1) (a := t4896) (u := t1) (v := t4896) (refl t1) (aw (ri t4896)) (refl t4896)
theorem pv4895 : R t4895 t4896 := result (f := t22) (a := t4875) (u := t24) (v := t4897) pv22 (aw (ra t1 t4875)) pv4897
theorem pv4893 : R t4893 t4896 := result (f := t4877) (a := t1) (u := t4877) (v := t4895) (refl t4877) (awb t0 t4875 t1 t1 (cI)) pv4895
theorem pv4898 : R t4898 t4875 := result (f := t28) (a := t4875) (u := t1) (v := t4875) pv28 (aw (ri t4875)) (refl t4875)
theorem pv4894 : R t4894 t4875 := result (f := t4893) (a := t1) (u := t4896) (v := t4898) pv4893 (awb t1 t4875 t1 t1 (cI)) pv4898
theorem pv4888 : R t4888 t4875 := result (f := t4886) (a := t1) (u := t4886) (v := t4894) (refl t4886) (awb t4877 t1 t1 t1 (cI)) pv4894
theorem pv4922 : R t4922 t4921 := result (f := t1) (a := t4921) (u := t1) (v := t4921) (refl t1) (aw (ri t4921)) (refl t4921)
theorem pv4920 : R t4920 t4921 := result (f := t22) (a := t4899) (u := t24) (v := t4922) pv22 (aw (ra t1 t4899)) pv4922
theorem pv4918 : R t4918 t4921 := result (f := t4902) (a := t1) (u := t4902) (v := t4920) (refl t4902) (awb t0 t4899 t1 t1 (cI)) pv4920
theorem pv4949 : R t4949 t4948 := result (f := t1) (a := t4948) (u := t1) (v := t4948) (refl t1) (aw (ri t4948)) (refl t4948)
theorem pv4947 : R t4947 t4948 := result (f := t22) (a := t4926) (u := t24) (v := t4949) pv22 (aw (ra t1 t4926)) pv4949
theorem pv4945 : R t4945 t4948 := result (f := t4929) (a := t1) (u := t4929) (v := t4947) (refl t4929) (awb t0 t4926 t1 t1 (cI)) pv4947
theorem pv4981 : R t4981 t4980 := result (f := t1) (a := t4980) (u := t1) (v := t4980) (refl t1) (aw (ri t4980)) (refl t4980)
theorem pv4979 : R t4979 t4980 := result (f := t22) (a := t4959) (u := t24) (v := t4981) pv22 (aw (ra t1 t4959)) pv4981
theorem pv4977 : R t4977 t4980 := result (f := t4961) (a := t1) (u := t4961) (v := t4979) (refl t4961) (awb t0 t4959 t1 t1 (cI)) pv4979
theorem pv4982 : R t4982 t4959 := result (f := t28) (a := t4959) (u := t1) (v := t4959) pv28 (aw (ri t4959)) (refl t4959)
theorem pv4978 : R t4978 t4959 := result (f := t4977) (a := t1) (u := t4980) (v := t4982) pv4977 (awb t1 t4959 t1 t1 (cI)) pv4982
theorem pv4972 : R t4972 t4959 := result (f := t4970) (a := t1) (u := t4970) (v := t4978) (refl t4970) (awb t4961 t1 t1 t1 (cI)) pv4978
theorem pv5006 : R t5006 t5005 := result (f := t1) (a := t5005) (u := t1) (v := t5005) (refl t1) (aw (ri t5005)) (refl t5005)
theorem pv5004 : R t5004 t5005 := result (f := t22) (a := t4983) (u := t24) (v := t5006) pv22 (aw (ra t1 t4983)) pv5006
theorem pv5002 : R t5002 t5005 := result (f := t4986) (a := t1) (u := t4986) (v := t5004) (refl t4986) (awb t0 t4983 t1 t1 (cI)) pv5004
theorem pv5033 : R t5033 t5032 := result (f := t1) (a := t5032) (u := t1) (v := t5032) (refl t1) (aw (ri t5032)) (refl t5032)
theorem pv5031 : R t5031 t5032 := result (f := t22) (a := t5010) (u := t24) (v := t5033) pv22 (aw (ra t1 t5010)) pv5033
theorem pv5029 : R t5029 t5032 := result (f := t5013) (a := t1) (u := t5013) (v := t5031) (refl t5013) (awb t0 t5010 t1 t1 (cI)) pv5031
theorem pv5038 : R t5038 t1 := result (f := t4818) (a := t1) (u := t149) (v := t231) pv4818 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv5039 : R t5039 t1 := result (f := t5038) (a := t1) (u := t1) (v := t1) pv5038 (aw (ri t1)) (refl t1)
theorem pv4956 : R t4956 t1 := result (f := t4954) (a := t1) (u := t4954) (v := t5039) (refl t4954) (awb t4818 t1 t1 t1 (cI)) pv5039
theorem pv5037 : R t5037 t1 := result (f := t3) (a := t4956) (u := t1) (v := t4956) pv3 (aw (ri t4956)) pv4956
theorem pv5035 : R t5035 t1 := result (f := t4972) (a := t1) (u := t4959) (v := t5037) pv4972 (awb t2 t4956 t1 t1 (cI)) pv5037
theorem pv5036 : R t5036 t1 := result (f := t5035) (a := t1) (u := t1) (v := t1) pv5035 (aw (ri t1)) (refl t1)
theorem pv5010 : R t5010 t1 := result (f := t5008) (a := t1) (u := t5008) (v := t5036) (refl t5008) (awb t4972 t1 t1 t1 (cI)) pv5036
theorem pv5034 : R t5034 t1 := result (f := t28) (a := t5010) (u := t1) (v := t5010) pv28 (aw (ri t5010)) pv5010
theorem pv5030 : R t5030 t1 := result (f := t5029) (a := t1) (u := t5032) (v := t5034) pv5029 (awb t1 t5010 t1 t1 (cI)) pv5034
theorem pv5024 : R t5024 t1 := result (f := t5022) (a := t1) (u := t5022) (v := t5030) (refl t5022) (awb t5013 t1 t1 t1 (cI)) pv5030
theorem pv5028 : R t5028 t5027 := result (f := t5024) (a := t5027) (u := t1) (v := t5027) pv5024 (aw (ri t5027)) (refl t5027)
theorem pv5025 : R t5025 t5027 := result (f := t0) (a := t5024) (u := t0) (v := t5028) (refl t0) (aw (rh t5024)) pv5028
theorem pv5041 : R t5041 t5040 := result (f := t5024) (a := t5040) (u := t1) (v := t5040) pv5024 (aw (ri t5040)) (refl t5040)
theorem pv5026 : R t5026 t5040 := result (f := t5025) (a := t5010) (u := t5027) (v := t5041) pv5025 (aw (ra t5024 t5010)) pv5041
theorem pv5023 : R t5023 t5040 := result (f := t5013) (a := t5022) (u := t5013) (v := t5026) (refl t5013) (awb t0 t5010 t5022 t5024 (refl _)) pv5026
end Blc.H44.Pump
