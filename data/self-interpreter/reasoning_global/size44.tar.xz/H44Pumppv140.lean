import H44Pumppv139
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9657 : R t9657 t9659 := result (f := t0) (a := t9656) (u := t0) (v := t9660) (refl t0) (aw (rh t9656)) pv9660
theorem pv9908 : R t9908 t9907 := result (f := t9656) (a := t9907) (u := t1) (v := t9907) pv9656 (aw (ri t9907)) (refl t9907)
theorem pv9658 : R t9658 t9907 := result (f := t9657) (a := t9642) (u := t9659) (v := t9908) pv9657 (aw (ra t9656 t9642)) pv9908
theorem pv9655 : R t9655 t9907 := result (f := t9645) (a := t9654) (u := t9645) (v := t9658) (refl t9645) (awb t0 t9642 t9654 t9656 (refl _)) pv9658
theorem pv9649 : R t9649 t9907 := result (f := t9647) (a := t1) (u := t9647) (v := t9655) (refl t9647) (aw (ra t9645 t1)) pv9655
theorem pv9919 : R t9919 t1 := result (f := t9656) (a := t1) (u := t1) (v := t1) pv9656 (aw (ri t1)) (refl t1)
theorem pv9920 : R t9920 t1 := result (f := t9919) (a := t9642) (u := t1) (v := t9642) pv9919 (aw (ri t9642)) pv9642
theorem pv9917 : R t9917 t1 := result (f := t9649) (a := t1) (u := t9907) (v := t9920) pv9649 (awb t9656 t9642 t1 t1 (cI)) pv9920
theorem pv9918 : R t9918 t1 := result (f := t9917) (a := t1) (u := t1) (v := t1) pv9917 (aw (ri t1)) (refl t1)
theorem pv9914 : R t9914 t1 := result (f := t9912) (a := t1) (u := t9912) (v := t9918) (refl t9912) (awb t9649 t1 t1 t1 (cI)) pv9918
theorem pv9915 : R t9915 t1 := result (f := t9656) (a := t9914) (u := t1) (v := t9914) pv9656 (aw (ri t9914)) pv9914
theorem pv9916 : R t9916 t1 := result (f := t9915) (a := t9642) (u := t1) (v := t9642) pv9915 (aw (ri t9642)) pv9642
theorem pv9913 : R t9913 t1 := result (f := t9649) (a := t9912) (u := t9907) (v := t9916) pv9649 (awb t9656 t9642 t9912 t9914 (refl _)) pv9916
theorem pv9909 : R t9909 t1 := result (f := t9652) (a := t1) (u := t9652) (v := t9913) (refl t9652) (aw (ra t9649 t1)) pv9913
theorem pv9910 : R t9910 t1 := result (f := t9656) (a := t9909) (u := t1) (v := t9909) pv9656 (aw (ri t9909)) pv9909
theorem pv9911 : R t9911 t1 := result (f := t9910) (a := t9642) (u := t1) (v := t9642) pv9910 (aw (ri t9642)) pv9642
theorem pv9653 : R t9653 t1 := result (f := t9649) (a := t9652) (u := t9907) (v := t9911) pv9649 (awb t9656 t9642 t9652 t9909 (refl _)) pv9911
theorem pv9650 : R t9650 t1 := result (f := t0) (a := t9649) (u := t0) (v := t9653) (refl t0) (aw (rh t9649)) pv9653
theorem pv9651 : R t9651 t1 := result (f := t9650) (a := t9642) (u := t1) (v := t9642) pv9650 (aw (ri t9642)) pv9642
theorem pv9648 : R t9648 t1 := result (f := t9645) (a := t9647) (u := t9645) (v := t9651) (refl t9645) (awb t0 t9642 t9647 t9649 (refl _)) pv9651
theorem pv9646 : R t9646 t1 := result (f := t0) (a := t9645) (u := t0) (v := t9648) (refl t0) (aw (rh t9645)) pv9648
theorem pv9643 : R t9643 t1 := result (f := t2) (a := t9642) (u := t2) (v := t9646) (refl t2) (aw (ra t0 t9642)) pv9646
theorem pv9644 : R t9644 t1 := result (f := t9643) (a := t9615) (u := t1) (v := t9615) pv9643 (aw (ri t9615)) pv9615
theorem pv9635 : R t9635 t1 := result (f := t9631) (a := t9634) (u := t9618) (v := t9644) pv9631 (awb t2 t9615 t9634 t9642 (refl _)) pv9644
theorem pv9632 : R t9632 t1 := result (f := t0) (a := t9631) (u := t0) (v := t9635) (refl t0) (aw (rh t9631)) pv9635
theorem pv9633 : R t9633 t9618 := result (f := t9632) (a := t9618) (u := t1) (v := t9618) pv9632 (aw (ri t9618)) (refl t9618)
theorem pv9630 : R t9630 t9618 := result (f := t9620) (a := t9629) (u := t9620) (v := t9633) (refl t9620) (awb t0 t9618 t9629 t9631 (refl _)) pv9633
theorem pv9624 : R t9624 t9618 := result (f := t9622) (a := t1) (u := t9622) (v := t9630) (refl t9622) (aw (ra t9620 t1)) pv9630
theorem pv9944 : R t9944 t9943 := result (f := t1) (a := t9943) (u := t1) (v := t9943) (refl t1) (aw (ri t9943)) (refl t9943)
theorem pv9942 : R t9942 t9943 := result (f := t22) (a := t9921) (u := t24) (v := t9944) pv22 (aw (ra t1 t9921)) pv9944
theorem pv9940 : R t9940 t9943 := result (f := t9924) (a := t1) (u := t9924) (v := t9942) (refl t9924) (awb t0 t9921 t1 t1 (cI)) pv9942
theorem pv9971 : R t9971 t9970 := result (f := t1) (a := t9970) (u := t1) (v := t9970) (refl t1) (aw (ri t9970)) (refl t9970)
theorem pv9969 : R t9969 t9970 := result (f := t22) (a := t9948) (u := t24) (v := t9971) pv22 (aw (ra t1 t9948)) pv9971
theorem pv9967 : R t9967 t9970 := result (f := t9951) (a := t1) (u := t9951) (v := t9969) (refl t9951) (awb t0 t9948 t1 t1 (cI)) pv9969
theorem pv9973 : R t9973 t1 := result (f := t9624) (a := t1) (u := t9618) (v := t9696) pv9624 (awb t2 t9615 t1 t1 (cI)) pv9696
theorem pv9974 : R t9974 t1 := result (f := t9973) (a := t1) (u := t1) (v := t1) pv9973 (aw (ri t1)) (refl t1)
theorem pv9948 : R t9948 t1 := result (f := t9946) (a := t1) (u := t9946) (v := t9974) (refl t9946) (awb t9624 t1 t1 t1 (cI)) pv9974
theorem pv9972 : R t9972 t1 := result (f := t28) (a := t9948) (u := t1) (v := t9948) pv28 (aw (ri t9948)) pv9948
theorem pv9968 : R t9968 t1 := result (f := t9967) (a := t1) (u := t9970) (v := t9972) pv9967 (awb t1 t9948 t1 t1 (cI)) pv9972
theorem pv9962 : R t9962 t1 := result (f := t9960) (a := t1) (u := t9960) (v := t9968) (refl t9960) (awb t9951 t1 t1 t1 (cI)) pv9968
theorem pv9966 : R t9966 t9965 := result (f := t9962) (a := t9965) (u := t1) (v := t9965) pv9962 (aw (ri t9965)) (refl t9965)
theorem pv9963 : R t9963 t9965 := result (f := t0) (a := t9962) (u := t0) (v := t9966) (refl t0) (aw (rh t9962)) pv9966
theorem pv9976 : R t9976 t9975 := result (f := t9962) (a := t9975) (u := t1) (v := t9975) pv9962 (aw (ri t9975)) (refl t9975)
theorem pv9964 : R t9964 t9975 := result (f := t9963) (a := t9948) (u := t9965) (v := t9976) pv9963 (aw (ra t9962 t9948)) pv9976
theorem pv9961 : R t9961 t9975 := result (f := t9951) (a := t9960) (u := t9951) (v := t9964) (refl t9951) (awb t0 t9948 t9960 t9962 (refl _)) pv9964
theorem pv9955 : R t9955 t9975 := result (f := t9953) (a := t1) (u := t9953) (v := t9961) (refl t9953) (aw (ra t9951 t1)) pv9961
theorem pv9987 : R t9987 t1 := result (f := t9962) (a := t1) (u := t1) (v := t1) pv9962 (aw (ri t1)) (refl t1)
theorem pv9988 : R t9988 t1 := result (f := t9987) (a := t9948) (u := t1) (v := t9948) pv9987 (aw (ri t9948)) pv9948
theorem pv9985 : R t9985 t1 := result (f := t9955) (a := t1) (u := t9975) (v := t9988) pv9955 (awb t9962 t9948 t1 t1 (cI)) pv9988
theorem pv9986 : R t9986 t1 := result (f := t9985) (a := t1) (u := t1) (v := t1) pv9985 (aw (ri t1)) (refl t1)
theorem pv9982 : R t9982 t1 := result (f := t9980) (a := t1) (u := t9980) (v := t9986) (refl t9980) (awb t9955 t1 t1 t1 (cI)) pv9986
theorem pv9983 : R t9983 t1 := result (f := t9962) (a := t9982) (u := t1) (v := t9982) pv9962 (aw (ri t9982)) pv9982
theorem pv9984 : R t9984 t1 := result (f := t9983) (a := t9948) (u := t1) (v := t9948) pv9983 (aw (ri t9948)) pv9948
theorem pv9981 : R t9981 t1 := result (f := t9955) (a := t9980) (u := t9975) (v := t9984) pv9955 (awb t9962 t9948 t9980 t9982 (refl _)) pv9984
theorem pv9977 : R t9977 t1 := result (f := t9958) (a := t1) (u := t9958) (v := t9981) (refl t9958) (aw (ra t9955 t1)) pv9981
end Blc.H44.Pump
