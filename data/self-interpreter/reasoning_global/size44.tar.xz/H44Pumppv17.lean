import H44Pumppv16
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1310 : R t1310 t1 := result (f := t1252) (a := t1309) (u := t1) (v := t1309) pv1252 (aw (ri t1309)) pv1309
theorem pv1311 : R t1311 t1 := result (f := t1310) (a := t1238) (u := t1) (v := t1238) pv1310 (aw (ri t1238)) pv1238
theorem pv1249 : R t1249 t1 := result (f := t1245) (a := t1248) (u := t1307) (v := t1311) pv1245 (awb t1252 t1238 t1248 t1309 (refl _)) pv1311
theorem pv1246 : R t1246 t1 := result (f := t0) (a := t1245) (u := t0) (v := t1249) (refl t0) (aw (rh t1245)) pv1249
theorem pv1247 : R t1247 t1 := result (f := t1246) (a := t1238) (u := t1) (v := t1238) pv1246 (aw (ri t1238)) pv1238
theorem pv1244 : R t1244 t1 := result (f := t1241) (a := t1243) (u := t1241) (v := t1247) (refl t1241) (awb t0 t1238 t1243 t1245 (refl _)) pv1247
theorem pv1242 : R t1242 t1 := result (f := t0) (a := t1241) (u := t0) (v := t1244) (refl t0) (aw (rh t1241)) pv1244
theorem pv1239 : R t1239 t1 := result (f := t2) (a := t1238) (u := t2) (v := t1242) (refl t2) (aw (ra t0 t1238)) pv1242
theorem pv1240 : R t1240 t1 := result (f := t1239) (a := t1211) (u := t1) (v := t1211) pv1239 (aw (ri t1211)) pv1211
theorem pv1231 : R t1231 t1 := result (f := t1227) (a := t1230) (u := t1214) (v := t1240) pv1227 (awb t2 t1211 t1230 t1238 (refl _)) pv1240
theorem pv1228 : R t1228 t1 := result (f := t0) (a := t1227) (u := t0) (v := t1231) (refl t0) (aw (rh t1227)) pv1231
theorem pv1229 : R t1229 t1214 := result (f := t1228) (a := t1214) (u := t1) (v := t1214) pv1228 (aw (ri t1214)) (refl t1214)
theorem pv1226 : R t1226 t1214 := result (f := t1216) (a := t1225) (u := t1216) (v := t1229) (refl t1216) (awb t0 t1214 t1225 t1227 (refl _)) pv1229
theorem pv1220 : R t1220 t1214 := result (f := t1218) (a := t1) (u := t1218) (v := t1226) (refl t1218) (aw (ra t1216 t1)) pv1226
theorem pv1344 : R t1344 t1343 := result (f := t1) (a := t1343) (u := t1) (v := t1343) (refl t1) (aw (ri t1343)) (refl t1343)
theorem pv1342 : R t1342 t1343 := result (f := t22) (a := t1321) (u := t24) (v := t1344) pv22 (aw (ra t1 t1321)) pv1344
theorem pv1340 : R t1340 t1343 := result (f := t1324) (a := t1) (u := t1324) (v := t1342) (refl t1324) (awb t0 t1321 t1 t1 (cI)) pv1342
theorem pv1371 : R t1371 t1370 := result (f := t1) (a := t1370) (u := t1) (v := t1370) (refl t1) (aw (ri t1370)) (refl t1370)
theorem pv1369 : R t1369 t1370 := result (f := t22) (a := t1348) (u := t24) (v := t1371) pv22 (aw (ra t1 t1348)) pv1371
theorem pv1367 : R t1367 t1370 := result (f := t1351) (a := t1) (u := t1351) (v := t1369) (refl t1351) (awb t0 t1348 t1 t1 (cI)) pv1369
theorem pv1373 : R t1373 t1 := result (f := t1220) (a := t1) (u := t1214) (v := t1292) pv1220 (awb t2 t1211 t1 t1 (cI)) pv1292
theorem pv1374 : R t1374 t1 := result (f := t1373) (a := t1) (u := t1) (v := t1) pv1373 (aw (ri t1)) (refl t1)
theorem pv1348 : R t1348 t1 := result (f := t1346) (a := t1) (u := t1346) (v := t1374) (refl t1346) (awb t1220 t1 t1 t1 (cI)) pv1374
theorem pv1372 : R t1372 t1 := result (f := t28) (a := t1348) (u := t1) (v := t1348) pv28 (aw (ri t1348)) pv1348
theorem pv1368 : R t1368 t1 := result (f := t1367) (a := t1) (u := t1370) (v := t1372) pv1367 (awb t1 t1348 t1 t1 (cI)) pv1372
theorem pv1362 : R t1362 t1 := result (f := t1360) (a := t1) (u := t1360) (v := t1368) (refl t1360) (awb t1351 t1 t1 t1 (cI)) pv1368
theorem pv1366 : R t1366 t1365 := result (f := t1362) (a := t1365) (u := t1) (v := t1365) pv1362 (aw (ri t1365)) (refl t1365)
theorem pv1363 : R t1363 t1365 := result (f := t0) (a := t1362) (u := t0) (v := t1366) (refl t0) (aw (rh t1362)) pv1366
theorem pv1376 : R t1376 t1375 := result (f := t1362) (a := t1375) (u := t1) (v := t1375) pv1362 (aw (ri t1375)) (refl t1375)
theorem pv1364 : R t1364 t1375 := result (f := t1363) (a := t1348) (u := t1365) (v := t1376) pv1363 (aw (ra t1362 t1348)) pv1376
theorem pv1361 : R t1361 t1375 := result (f := t1351) (a := t1360) (u := t1351) (v := t1364) (refl t1351) (awb t0 t1348 t1360 t1362 (refl _)) pv1364
theorem pv1355 : R t1355 t1375 := result (f := t1353) (a := t1) (u := t1353) (v := t1361) (refl t1353) (aw (ra t1351 t1)) pv1361
theorem pv1387 : R t1387 t1 := result (f := t1362) (a := t1) (u := t1) (v := t1) pv1362 (aw (ri t1)) (refl t1)
theorem pv1388 : R t1388 t1 := result (f := t1387) (a := t1348) (u := t1) (v := t1348) pv1387 (aw (ri t1348)) pv1348
theorem pv1385 : R t1385 t1 := result (f := t1355) (a := t1) (u := t1375) (v := t1388) pv1355 (awb t1362 t1348 t1 t1 (cI)) pv1388
theorem pv1386 : R t1386 t1 := result (f := t1385) (a := t1) (u := t1) (v := t1) pv1385 (aw (ri t1)) (refl t1)
theorem pv1382 : R t1382 t1 := result (f := t1380) (a := t1) (u := t1380) (v := t1386) (refl t1380) (awb t1355 t1 t1 t1 (cI)) pv1386
theorem pv1383 : R t1383 t1 := result (f := t1362) (a := t1382) (u := t1) (v := t1382) pv1362 (aw (ri t1382)) pv1382
theorem pv1384 : R t1384 t1 := result (f := t1383) (a := t1348) (u := t1) (v := t1348) pv1383 (aw (ri t1348)) pv1348
theorem pv1381 : R t1381 t1 := result (f := t1355) (a := t1380) (u := t1375) (v := t1384) pv1355 (awb t1362 t1348 t1380 t1382 (refl _)) pv1384
theorem pv1377 : R t1377 t1 := result (f := t1358) (a := t1) (u := t1358) (v := t1381) (refl t1358) (aw (ra t1355 t1)) pv1381
theorem pv1378 : R t1378 t1 := result (f := t1362) (a := t1377) (u := t1) (v := t1377) pv1362 (aw (ri t1377)) pv1377
theorem pv1379 : R t1379 t1 := result (f := t1378) (a := t1348) (u := t1) (v := t1348) pv1378 (aw (ri t1348)) pv1348
theorem pv1359 : R t1359 t1 := result (f := t1355) (a := t1358) (u := t1375) (v := t1379) pv1355 (awb t1362 t1348 t1358 t1377 (refl _)) pv1379
theorem pv1356 : R t1356 t1 := result (f := t0) (a := t1355) (u := t0) (v := t1359) (refl t0) (aw (rh t1355)) pv1359
theorem pv1357 : R t1357 t1 := result (f := t1356) (a := t1348) (u := t1) (v := t1348) pv1356 (aw (ri t1348)) pv1348
theorem pv1354 : R t1354 t1 := result (f := t1351) (a := t1353) (u := t1351) (v := t1357) (refl t1351) (awb t0 t1348 t1353 t1355 (refl _)) pv1357
theorem pv1352 : R t1352 t1 := result (f := t0) (a := t1351) (u := t0) (v := t1354) (refl t0) (aw (rh t1351)) pv1354
theorem pv1349 : R t1349 t1 := result (f := t2) (a := t1348) (u := t2) (v := t1352) (refl t2) (aw (ra t0 t1348)) pv1352
theorem pv1350 : R t1350 t1 := result (f := t1349) (a := t1211) (u := t1) (v := t1211) pv1349 (aw (ri t1211)) pv1211
theorem pv1347 : R t1347 t1 := result (f := t1220) (a := t1346) (u := t1214) (v := t1350) pv1220 (awb t2 t1211 t1346 t1348 (refl _)) pv1350
theorem pv1321 : R t1321 t1 := result (f := t1223) (a := t1) (u := t1223) (v := t1347) (refl t1223) (aw (ra t1220 t1)) pv1347
theorem pv1345 : R t1345 t1 := result (f := t28) (a := t1321) (u := t1) (v := t1321) pv28 (aw (ri t1321)) pv1321
theorem pv1341 : R t1341 t1 := result (f := t1340) (a := t1) (u := t1343) (v := t1345) pv1340 (awb t1 t1321 t1 t1 (cI)) pv1345
theorem pv1335 : R t1335 t1 := result (f := t1333) (a := t1) (u := t1333) (v := t1341) (refl t1333) (awb t1324 t1 t1 t1 (cI)) pv1341
end Blc.H44.Pump
