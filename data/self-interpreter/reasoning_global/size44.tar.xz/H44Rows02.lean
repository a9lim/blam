import H44Literals
import H44Lib0
import H44Lib1
namespace Blc.H44
theorem ex_e4786842212806 : ¬ IsSelfInterpreter e4786842212806 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786842212806 1 = true)
#print axioms ex_e4786842212806
theorem ex_e4786843295542 : ¬ IsSelfInterpreter e4786843295542 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786843295542 1 = true)
#print axioms ex_e4786843295542
theorem ex_e4786843295546 : ¬ IsSelfInterpreter e4786843295546 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4786843295546 3 = true)
#print axioms ex_e4786843295546
theorem ex_e4786848014134 : ¬ IsSelfInterpreter e4786848014134 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786848014134 1 = true)
#print axioms ex_e4786848014134
theorem ex_e4816487845686 : ¬ IsSelfInterpreter e4816487845686 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4816487845686 1 = true)
#print axioms ex_e4816487845686
theorem ex_e4816487845690 : ¬ IsSelfInterpreter e4816487845690 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4816487845690 3 = true)
#print axioms ex_e4816487845690
end Blc.H44
