import H44Pumppv137
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9830 : R t9830 t9833 := result (f := t9814) (a := t1) (u := t9814) (v := t9832) (refl t9814) (awb t0 t9811 t1 t1 (cI)) pv9832
theorem pv9861 : R t9861 t9860 := result (f := t1) (a := t9860) (u := t1) (v := t9860) (refl t1) (aw (ri t9860)) (refl t9860)
theorem pv9859 : R t9859 t9860 := result (f := t22) (a := t9838) (u := t24) (v := t9861) pv22 (aw (ra t1 t9838)) pv9861
theorem pv9857 : R t9857 t9860 := result (f := t9841) (a := t1) (u := t9841) (v := t9859) (refl t9841) (awb t0 t9838 t1 t1 (cI)) pv9859
theorem pv9863 : R t9863 t1 := result (f := t9708) (a := t1) (u := t9702) (v := t9780) pv9708 (awb t2 t9699 t1 t1 (cI)) pv9780
theorem pv9864 : R t9864 t1 := result (f := t9863) (a := t1) (u := t1) (v := t1) pv9863 (aw (ri t1)) (refl t1)
theorem pv9838 : R t9838 t1 := result (f := t9836) (a := t1) (u := t9836) (v := t9864) (refl t9836) (awb t9708 t1 t1 t1 (cI)) pv9864
theorem pv9862 : R t9862 t1 := result (f := t28) (a := t9838) (u := t1) (v := t9838) pv28 (aw (ri t9838)) pv9838
theorem pv9858 : R t9858 t1 := result (f := t9857) (a := t1) (u := t9860) (v := t9862) pv9857 (awb t1 t9838 t1 t1 (cI)) pv9862
theorem pv9852 : R t9852 t1 := result (f := t9850) (a := t1) (u := t9850) (v := t9858) (refl t9850) (awb t9841 t1 t1 t1 (cI)) pv9858
theorem pv9856 : R t9856 t9855 := result (f := t9852) (a := t9855) (u := t1) (v := t9855) pv9852 (aw (ri t9855)) (refl t9855)
theorem pv9853 : R t9853 t9855 := result (f := t0) (a := t9852) (u := t0) (v := t9856) (refl t0) (aw (rh t9852)) pv9856
theorem pv9866 : R t9866 t9865 := result (f := t9852) (a := t9865) (u := t1) (v := t9865) pv9852 (aw (ri t9865)) (refl t9865)
theorem pv9854 : R t9854 t9865 := result (f := t9853) (a := t9838) (u := t9855) (v := t9866) pv9853 (aw (ra t9852 t9838)) pv9866
theorem pv9851 : R t9851 t9865 := result (f := t9841) (a := t9850) (u := t9841) (v := t9854) (refl t9841) (awb t0 t9838 t9850 t9852 (refl _)) pv9854
theorem pv9845 : R t9845 t9865 := result (f := t9843) (a := t1) (u := t9843) (v := t9851) (refl t9843) (aw (ra t9841 t1)) pv9851
theorem pv9877 : R t9877 t1 := result (f := t9852) (a := t1) (u := t1) (v := t1) pv9852 (aw (ri t1)) (refl t1)
theorem pv9878 : R t9878 t1 := result (f := t9877) (a := t9838) (u := t1) (v := t9838) pv9877 (aw (ri t9838)) pv9838
theorem pv9875 : R t9875 t1 := result (f := t9845) (a := t1) (u := t9865) (v := t9878) pv9845 (awb t9852 t9838 t1 t1 (cI)) pv9878
theorem pv9876 : R t9876 t1 := result (f := t9875) (a := t1) (u := t1) (v := t1) pv9875 (aw (ri t1)) (refl t1)
theorem pv9872 : R t9872 t1 := result (f := t9870) (a := t1) (u := t9870) (v := t9876) (refl t9870) (awb t9845 t1 t1 t1 (cI)) pv9876
theorem pv9873 : R t9873 t1 := result (f := t9852) (a := t9872) (u := t1) (v := t9872) pv9852 (aw (ri t9872)) pv9872
theorem pv9874 : R t9874 t1 := result (f := t9873) (a := t9838) (u := t1) (v := t9838) pv9873 (aw (ri t9838)) pv9838
theorem pv9871 : R t9871 t1 := result (f := t9845) (a := t9870) (u := t9865) (v := t9874) pv9845 (awb t9852 t9838 t9870 t9872 (refl _)) pv9874
theorem pv9867 : R t9867 t1 := result (f := t9848) (a := t1) (u := t9848) (v := t9871) (refl t9848) (aw (ra t9845 t1)) pv9871
theorem pv9868 : R t9868 t1 := result (f := t9852) (a := t9867) (u := t1) (v := t9867) pv9852 (aw (ri t9867)) pv9867
theorem pv9869 : R t9869 t1 := result (f := t9868) (a := t9838) (u := t1) (v := t9838) pv9868 (aw (ri t9838)) pv9838
theorem pv9849 : R t9849 t1 := result (f := t9845) (a := t9848) (u := t9865) (v := t9869) pv9845 (awb t9852 t9838 t9848 t9867 (refl _)) pv9869
theorem pv9846 : R t9846 t1 := result (f := t0) (a := t9845) (u := t0) (v := t9849) (refl t0) (aw (rh t9845)) pv9849
theorem pv9847 : R t9847 t1 := result (f := t9846) (a := t9838) (u := t1) (v := t9838) pv9846 (aw (ri t9838)) pv9838
theorem pv9844 : R t9844 t1 := result (f := t9841) (a := t9843) (u := t9841) (v := t9847) (refl t9841) (awb t0 t9838 t9843 t9845 (refl _)) pv9847
theorem pv9842 : R t9842 t1 := result (f := t0) (a := t9841) (u := t0) (v := t9844) (refl t0) (aw (rh t9841)) pv9844
theorem pv9839 : R t9839 t1 := result (f := t2) (a := t9838) (u := t2) (v := t9842) (refl t2) (aw (ra t0 t9838)) pv9842
theorem pv9840 : R t9840 t1 := result (f := t9839) (a := t9699) (u := t1) (v := t9699) pv9839 (aw (ri t9699)) pv9699
theorem pv9837 : R t9837 t1 := result (f := t9708) (a := t9836) (u := t9702) (v := t9840) pv9708 (awb t2 t9699 t9836 t9838 (refl _)) pv9840
theorem pv9811 : R t9811 t1 := result (f := t9711) (a := t1) (u := t9711) (v := t9837) (refl t9711) (aw (ra t9708 t1)) pv9837
theorem pv9835 : R t9835 t1 := result (f := t28) (a := t9811) (u := t1) (v := t9811) pv28 (aw (ri t9811)) pv9811
theorem pv9831 : R t9831 t1 := result (f := t9830) (a := t1) (u := t9833) (v := t9835) pv9830 (awb t1 t9811 t1 t1 (cI)) pv9835
theorem pv9825 : R t9825 t1 := result (f := t9823) (a := t1) (u := t9823) (v := t9831) (refl t9823) (awb t9814 t1 t1 t1 (cI)) pv9831
theorem pv9829 : R t9829 t9828 := result (f := t9825) (a := t9828) (u := t1) (v := t9828) pv9825 (aw (ri t9828)) (refl t9828)
theorem pv9826 : R t9826 t9828 := result (f := t0) (a := t9825) (u := t0) (v := t9829) (refl t0) (aw (rh t9825)) pv9829
theorem pv9880 : R t9880 t9879 := result (f := t9825) (a := t9879) (u := t1) (v := t9879) pv9825 (aw (ri t9879)) (refl t9879)
theorem pv9827 : R t9827 t9879 := result (f := t9826) (a := t9811) (u := t9828) (v := t9880) pv9826 (aw (ra t9825 t9811)) pv9880
theorem pv9824 : R t9824 t9879 := result (f := t9814) (a := t9823) (u := t9814) (v := t9827) (refl t9814) (awb t0 t9811 t9823 t9825 (refl _)) pv9827
theorem pv9818 : R t9818 t9879 := result (f := t9816) (a := t1) (u := t9816) (v := t9824) (refl t9816) (aw (ra t9814 t1)) pv9824
theorem pv9891 : R t9891 t1 := result (f := t9825) (a := t1) (u := t1) (v := t1) pv9825 (aw (ri t1)) (refl t1)
theorem pv9892 : R t9892 t1 := result (f := t9891) (a := t9811) (u := t1) (v := t9811) pv9891 (aw (ri t9811)) pv9811
theorem pv9889 : R t9889 t1 := result (f := t9818) (a := t1) (u := t9879) (v := t9892) pv9818 (awb t9825 t9811 t1 t1 (cI)) pv9892
theorem pv9890 : R t9890 t1 := result (f := t9889) (a := t1) (u := t1) (v := t1) pv9889 (aw (ri t1)) (refl t1)
theorem pv9886 : R t9886 t1 := result (f := t9884) (a := t1) (u := t9884) (v := t9890) (refl t9884) (awb t9818 t1 t1 t1 (cI)) pv9890
theorem pv9887 : R t9887 t1 := result (f := t9825) (a := t9886) (u := t1) (v := t9886) pv9825 (aw (ri t9886)) pv9886
theorem pv9888 : R t9888 t1 := result (f := t9887) (a := t9811) (u := t1) (v := t9811) pv9887 (aw (ri t9811)) pv9811
theorem pv9885 : R t9885 t1 := result (f := t9818) (a := t9884) (u := t9879) (v := t9888) pv9818 (awb t9825 t9811 t9884 t9886 (refl _)) pv9888
theorem pv9881 : R t9881 t1 := result (f := t9821) (a := t1) (u := t9821) (v := t9885) (refl t9821) (aw (ra t9818 t1)) pv9885
theorem pv9882 : R t9882 t1 := result (f := t9825) (a := t9881) (u := t1) (v := t9881) pv9825 (aw (ri t9881)) pv9881
end Blc.H44.Pump
