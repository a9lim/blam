import H44Pumppv8
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv783 : R t783 t785 := result (f := t0) (a := t782) (u := t0) (v := t786) (refl t0) (aw (rh t782)) pv786
theorem pv796 : R t796 t795 := result (f := t782) (a := t795) (u := t1) (v := t795) pv782 (aw (ri t795)) (refl t795)
theorem pv784 : R t784 t795 := result (f := t783) (a := t768) (u := t785) (v := t796) pv783 (aw (ra t782 t768)) pv796
theorem pv781 : R t781 t795 := result (f := t771) (a := t780) (u := t771) (v := t784) (refl t771) (awb t0 t768 t780 t782 (refl _)) pv784
theorem pv775 : R t775 t795 := result (f := t773) (a := t1) (u := t773) (v := t781) (refl t773) (aw (ra t771 t1)) pv781
theorem pv807 : R t807 t1 := result (f := t782) (a := t1) (u := t1) (v := t1) pv782 (aw (ri t1)) (refl t1)
theorem pv808 : R t808 t1 := result (f := t807) (a := t768) (u := t1) (v := t768) pv807 (aw (ri t768)) pv768
theorem pv805 : R t805 t1 := result (f := t775) (a := t1) (u := t795) (v := t808) pv775 (awb t782 t768 t1 t1 (cI)) pv808
theorem pv806 : R t806 t1 := result (f := t805) (a := t1) (u := t1) (v := t1) pv805 (aw (ri t1)) (refl t1)
theorem pv802 : R t802 t1 := result (f := t800) (a := t1) (u := t800) (v := t806) (refl t800) (awb t775 t1 t1 t1 (cI)) pv806
theorem pv803 : R t803 t1 := result (f := t782) (a := t802) (u := t1) (v := t802) pv782 (aw (ri t802)) pv802
theorem pv804 : R t804 t1 := result (f := t803) (a := t768) (u := t1) (v := t768) pv803 (aw (ri t768)) pv768
theorem pv801 : R t801 t1 := result (f := t775) (a := t800) (u := t795) (v := t804) pv775 (awb t782 t768 t800 t802 (refl _)) pv804
theorem pv797 : R t797 t1 := result (f := t778) (a := t1) (u := t778) (v := t801) (refl t778) (aw (ra t775 t1)) pv801
theorem pv798 : R t798 t1 := result (f := t782) (a := t797) (u := t1) (v := t797) pv782 (aw (ri t797)) pv797
theorem pv799 : R t799 t1 := result (f := t798) (a := t768) (u := t1) (v := t768) pv798 (aw (ri t768)) pv768
theorem pv779 : R t779 t1 := result (f := t775) (a := t778) (u := t795) (v := t799) pv775 (awb t782 t768 t778 t797 (refl _)) pv799
theorem pv776 : R t776 t1 := result (f := t0) (a := t775) (u := t0) (v := t779) (refl t0) (aw (rh t775)) pv779
theorem pv777 : R t777 t1 := result (f := t776) (a := t768) (u := t1) (v := t768) pv776 (aw (ri t768)) pv768
theorem pv774 : R t774 t1 := result (f := t771) (a := t773) (u := t771) (v := t777) (refl t771) (awb t0 t768 t773 t775 (refl _)) pv777
theorem pv772 : R t772 t1 := result (f := t0) (a := t771) (u := t0) (v := t774) (refl t0) (aw (rh t771)) pv774
theorem pv769 : R t769 t1 := result (f := t2) (a := t768) (u := t2) (v := t772) (refl t2) (aw (ra t0 t768)) pv772
theorem pv770 : R t770 t1 := result (f := t769) (a := t435) (u := t1) (v := t435) pv769 (aw (ri t435)) pv435
theorem pv767 : R t767 t1 := result (f := t444) (a := t766) (u := t438) (v := t770) pv444 (awb t2 t435 t766 t768 (refl _)) pv770
theorem pv741 : R t741 t1 := result (f := t447) (a := t1) (u := t447) (v := t767) (refl t447) (aw (ra t444 t1)) pv767
theorem pv765 : R t765 t1 := result (f := t28) (a := t741) (u := t1) (v := t741) pv28 (aw (ri t741)) pv741
theorem pv761 : R t761 t1 := result (f := t760) (a := t1) (u := t763) (v := t765) pv760 (awb t1 t741 t1 t1 (cI)) pv765
theorem pv755 : R t755 t1 := result (f := t753) (a := t1) (u := t753) (v := t761) (refl t753) (awb t744 t1 t1 t1 (cI)) pv761
theorem pv759 : R t759 t758 := result (f := t755) (a := t758) (u := t1) (v := t758) pv755 (aw (ri t758)) (refl t758)
theorem pv756 : R t756 t758 := result (f := t0) (a := t755) (u := t0) (v := t759) (refl t0) (aw (rh t755)) pv759
theorem pv810 : R t810 t809 := result (f := t755) (a := t809) (u := t1) (v := t809) pv755 (aw (ri t809)) (refl t809)
theorem pv757 : R t757 t809 := result (f := t756) (a := t741) (u := t758) (v := t810) pv756 (aw (ra t755 t741)) pv810
theorem pv754 : R t754 t809 := result (f := t744) (a := t753) (u := t744) (v := t757) (refl t744) (awb t0 t741 t753 t755 (refl _)) pv757
theorem pv748 : R t748 t809 := result (f := t746) (a := t1) (u := t746) (v := t754) (refl t746) (aw (ra t744 t1)) pv754
theorem pv821 : R t821 t1 := result (f := t755) (a := t1) (u := t1) (v := t1) pv755 (aw (ri t1)) (refl t1)
theorem pv822 : R t822 t1 := result (f := t821) (a := t741) (u := t1) (v := t741) pv821 (aw (ri t741)) pv741
theorem pv819 : R t819 t1 := result (f := t748) (a := t1) (u := t809) (v := t822) pv748 (awb t755 t741 t1 t1 (cI)) pv822
theorem pv820 : R t820 t1 := result (f := t819) (a := t1) (u := t1) (v := t1) pv819 (aw (ri t1)) (refl t1)
theorem pv816 : R t816 t1 := result (f := t814) (a := t1) (u := t814) (v := t820) (refl t814) (awb t748 t1 t1 t1 (cI)) pv820
theorem pv817 : R t817 t1 := result (f := t755) (a := t816) (u := t1) (v := t816) pv755 (aw (ri t816)) pv816
theorem pv818 : R t818 t1 := result (f := t817) (a := t741) (u := t1) (v := t741) pv817 (aw (ri t741)) pv741
theorem pv815 : R t815 t1 := result (f := t748) (a := t814) (u := t809) (v := t818) pv748 (awb t755 t741 t814 t816 (refl _)) pv818
theorem pv811 : R t811 t1 := result (f := t751) (a := t1) (u := t751) (v := t815) (refl t751) (aw (ra t748 t1)) pv815
theorem pv812 : R t812 t1 := result (f := t755) (a := t811) (u := t1) (v := t811) pv755 (aw (ri t811)) pv811
theorem pv813 : R t813 t1 := result (f := t812) (a := t741) (u := t1) (v := t741) pv812 (aw (ri t741)) pv741
theorem pv752 : R t752 t1 := result (f := t748) (a := t751) (u := t809) (v := t813) pv748 (awb t755 t741 t751 t811 (refl _)) pv813
theorem pv749 : R t749 t1 := result (f := t0) (a := t748) (u := t0) (v := t752) (refl t0) (aw (rh t748)) pv752
theorem pv750 : R t750 t1 := result (f := t749) (a := t741) (u := t1) (v := t741) pv749 (aw (ri t741)) pv741
theorem pv747 : R t747 t1 := result (f := t744) (a := t746) (u := t744) (v := t750) (refl t744) (awb t0 t741 t746 t748 (refl _)) pv750
theorem pv745 : R t745 t1 := result (f := t0) (a := t744) (u := t0) (v := t747) (refl t0) (aw (rh t744)) pv747
theorem pv742 : R t742 t1 := result (f := t2) (a := t741) (u := t2) (v := t745) (refl t2) (aw (ra t0 t741)) pv745
theorem pv743 : R t743 t1 := result (f := t742) (a := t435) (u := t1) (v := t435) pv742 (aw (ri t435)) pv435
theorem pv448 : R t448 t1 := result (f := t444) (a := t447) (u := t438) (v := t743) pv444 (awb t2 t435 t447 t741 (refl _)) pv743
theorem pv445 : R t445 t1 := result (f := t0) (a := t444) (u := t0) (v := t448) (refl t0) (aw (rh t444)) pv448
theorem pv446 : R t446 t438 := result (f := t445) (a := t438) (u := t1) (v := t438) pv445 (aw (ri t438)) (refl t438)
end Blc.H44.Pump
