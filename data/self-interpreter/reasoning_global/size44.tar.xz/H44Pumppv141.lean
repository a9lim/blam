import H44Pumppv140
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9978 : R t9978 t1 := result (f := t9962) (a := t9977) (u := t1) (v := t9977) pv9962 (aw (ri t9977)) pv9977
theorem pv9979 : R t9979 t1 := result (f := t9978) (a := t9948) (u := t1) (v := t9948) pv9978 (aw (ri t9948)) pv9948
theorem pv9959 : R t9959 t1 := result (f := t9955) (a := t9958) (u := t9975) (v := t9979) pv9955 (awb t9962 t9948 t9958 t9977 (refl _)) pv9979
theorem pv9956 : R t9956 t1 := result (f := t0) (a := t9955) (u := t0) (v := t9959) (refl t0) (aw (rh t9955)) pv9959
theorem pv9957 : R t9957 t1 := result (f := t9956) (a := t9948) (u := t1) (v := t9948) pv9956 (aw (ri t9948)) pv9948
theorem pv9954 : R t9954 t1 := result (f := t9951) (a := t9953) (u := t9951) (v := t9957) (refl t9951) (awb t0 t9948 t9953 t9955 (refl _)) pv9957
theorem pv9952 : R t9952 t1 := result (f := t0) (a := t9951) (u := t0) (v := t9954) (refl t0) (aw (rh t9951)) pv9954
theorem pv9949 : R t9949 t1 := result (f := t2) (a := t9948) (u := t2) (v := t9952) (refl t2) (aw (ra t0 t9948)) pv9952
theorem pv9950 : R t9950 t1 := result (f := t9949) (a := t9615) (u := t1) (v := t9615) pv9949 (aw (ri t9615)) pv9615
theorem pv9947 : R t9947 t1 := result (f := t9624) (a := t9946) (u := t9618) (v := t9950) pv9624 (awb t2 t9615 t9946 t9948 (refl _)) pv9950
theorem pv9921 : R t9921 t1 := result (f := t9627) (a := t1) (u := t9627) (v := t9947) (refl t9627) (aw (ra t9624 t1)) pv9947
theorem pv9945 : R t9945 t1 := result (f := t28) (a := t9921) (u := t1) (v := t9921) pv28 (aw (ri t9921)) pv9921
theorem pv9941 : R t9941 t1 := result (f := t9940) (a := t1) (u := t9943) (v := t9945) pv9940 (awb t1 t9921 t1 t1 (cI)) pv9945
theorem pv9935 : R t9935 t1 := result (f := t9933) (a := t1) (u := t9933) (v := t9941) (refl t9933) (awb t9924 t1 t1 t1 (cI)) pv9941
theorem pv9939 : R t9939 t9938 := result (f := t9935) (a := t9938) (u := t1) (v := t9938) pv9935 (aw (ri t9938)) (refl t9938)
theorem pv9936 : R t9936 t9938 := result (f := t0) (a := t9935) (u := t0) (v := t9939) (refl t0) (aw (rh t9935)) pv9939
theorem pv9990 : R t9990 t9989 := result (f := t9935) (a := t9989) (u := t1) (v := t9989) pv9935 (aw (ri t9989)) (refl t9989)
theorem pv9937 : R t9937 t9989 := result (f := t9936) (a := t9921) (u := t9938) (v := t9990) pv9936 (aw (ra t9935 t9921)) pv9990
theorem pv9934 : R t9934 t9989 := result (f := t9924) (a := t9933) (u := t9924) (v := t9937) (refl t9924) (awb t0 t9921 t9933 t9935 (refl _)) pv9937
theorem pv9928 : R t9928 t9989 := result (f := t9926) (a := t1) (u := t9926) (v := t9934) (refl t9926) (aw (ra t9924 t1)) pv9934
theorem pv10001 : R t10001 t1 := result (f := t9935) (a := t1) (u := t1) (v := t1) pv9935 (aw (ri t1)) (refl t1)
theorem pv10002 : R t10002 t1 := result (f := t10001) (a := t9921) (u := t1) (v := t9921) pv10001 (aw (ri t9921)) pv9921
theorem pv9999 : R t9999 t1 := result (f := t9928) (a := t1) (u := t9989) (v := t10002) pv9928 (awb t9935 t9921 t1 t1 (cI)) pv10002
theorem pv10000 : R t10000 t1 := result (f := t9999) (a := t1) (u := t1) (v := t1) pv9999 (aw (ri t1)) (refl t1)
theorem pv9996 : R t9996 t1 := result (f := t9994) (a := t1) (u := t9994) (v := t10000) (refl t9994) (awb t9928 t1 t1 t1 (cI)) pv10000
theorem pv9997 : R t9997 t1 := result (f := t9935) (a := t9996) (u := t1) (v := t9996) pv9935 (aw (ri t9996)) pv9996
theorem pv9998 : R t9998 t1 := result (f := t9997) (a := t9921) (u := t1) (v := t9921) pv9997 (aw (ri t9921)) pv9921
theorem pv9995 : R t9995 t1 := result (f := t9928) (a := t9994) (u := t9989) (v := t9998) pv9928 (awb t9935 t9921 t9994 t9996 (refl _)) pv9998
theorem pv9991 : R t9991 t1 := result (f := t9931) (a := t1) (u := t9931) (v := t9995) (refl t9931) (aw (ra t9928 t1)) pv9995
theorem pv9992 : R t9992 t1 := result (f := t9935) (a := t9991) (u := t1) (v := t9991) pv9935 (aw (ri t9991)) pv9991
theorem pv9993 : R t9993 t1 := result (f := t9992) (a := t9921) (u := t1) (v := t9921) pv9992 (aw (ri t9921)) pv9921
theorem pv9932 : R t9932 t1 := result (f := t9928) (a := t9931) (u := t9989) (v := t9993) pv9928 (awb t9935 t9921 t9931 t9991 (refl _)) pv9993
theorem pv9929 : R t9929 t1 := result (f := t0) (a := t9928) (u := t0) (v := t9932) (refl t0) (aw (rh t9928)) pv9932
theorem pv9930 : R t9930 t1 := result (f := t9929) (a := t9921) (u := t1) (v := t9921) pv9929 (aw (ri t9921)) pv9921
theorem pv9927 : R t9927 t1 := result (f := t9924) (a := t9926) (u := t9924) (v := t9930) (refl t9924) (awb t0 t9921 t9926 t9928 (refl _)) pv9930
theorem pv9925 : R t9925 t1 := result (f := t0) (a := t9924) (u := t0) (v := t9927) (refl t0) (aw (rh t9924)) pv9927
theorem pv9922 : R t9922 t1 := result (f := t2) (a := t9921) (u := t2) (v := t9925) (refl t2) (aw (ra t0 t9921)) pv9925
theorem pv9923 : R t9923 t1 := result (f := t9922) (a := t9615) (u := t1) (v := t9615) pv9922 (aw (ri t9615)) pv9615
theorem pv9628 : R t9628 t1 := result (f := t9624) (a := t9627) (u := t9618) (v := t9923) pv9624 (awb t2 t9615 t9627 t9921 (refl _)) pv9923
theorem pv9625 : R t9625 t1 := result (f := t0) (a := t9624) (u := t0) (v := t9628) (refl t0) (aw (rh t9624)) pv9628
theorem pv9626 : R t9626 t9618 := result (f := t9625) (a := t9618) (u := t1) (v := t9618) pv9625 (aw (ri t9618)) (refl t9618)
theorem pv9623 : R t9623 t9618 := result (f := t9620) (a := t9622) (u := t9620) (v := t9626) (refl t9620) (awb t0 t9618 t9622 t9624 (refl _)) pv9626
theorem pv9621 : R t9621 t9618 := result (f := t0) (a := t9620) (u := t0) (v := t9623) (refl t0) (aw (rh t9620)) pv9623
theorem pv9619 : R t9619 t9618 := result (f := t2) (a := t9618) (u := t2) (v := t9621) (refl t2) (aw (ra t0 t9618)) pv9621
theorem pv9616 : R t9616 t9618 := result (f := t59) (a := t9615) (u := t46) (v := t9619) pv59 (aw (ra t2 t9615)) pv9619
theorem pv9617 : R t9617 t1 := result (f := t9616) (a := t1) (u := t9618) (v := t9696) pv9616 (awb t2 t9615 t1 t1 (cI)) pv9696
theorem pv6499 : R t6499 t1 := result (f := t6495) (a := t6498) (u := t149) (v := t9617) pv6495 (awb t59 t1 t6498 t9615 (refl _)) pv9617
theorem pv6496 : R t6496 t1 := result (f := t0) (a := t6495) (u := t0) (v := t6499) (refl t0) (aw (rh t6495)) pv6499
theorem pv6497 : R t6497 t149 := result (f := t6496) (a := t6488) (u := t1) (v := t6488) pv6496 (aw (ri t6488)) pv6488
theorem pv6494 : R t6494 t149 := result (f := t6491) (a := t6493) (u := t6491) (v := t6497) (refl t6491) (awb t0 t6488 t6493 t6495 (refl _)) pv6497
theorem pv6492 : R t6492 t149 := result (f := t0) (a := t6491) (u := t0) (v := t6494) (refl t0) (aw (rh t6491)) pv6494
theorem pv6489 : R t6489 t149 := result (f := t2) (a := t6488) (u := t2) (v := t6492) (refl t2) (aw (ra t0 t6488)) pv6492
theorem pv6490 : R t6490 t149 := result (f := t6489) (a := t3935) (u := t149) (v := t7321) pv6489 (awb t59 t1 t3935 t7319 (refl _)) pv7321
theorem pv6481 : R t6481 t149 := result (f := t6477) (a := t6480) (u := t6464) (v := t6490) pv6477 (awb t2 t3935 t6480 t6488 (refl _)) pv6490
theorem pv6478 : R t6478 t149 := result (f := t0) (a := t6477) (u := t0) (v := t6481) (refl t0) (aw (rh t6477)) pv6481
end Blc.H44.Pump
