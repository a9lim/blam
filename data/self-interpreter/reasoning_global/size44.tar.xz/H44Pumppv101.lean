import H44Pumppv100
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv7216 : R t7216 t1 := result (f := t7214) (a := t1) (u := t7214) (v := t7220) (refl t7214) (awb t6992 t1 t1 t1 (cI)) pv7220
theorem pv7217 : R t7217 t1 := result (f := t6999) (a := t7216) (u := t1) (v := t7216) pv6999 (aw (ri t7216)) pv7216
theorem pv7218 : R t7218 t1 := result (f := t7217) (a := t6985) (u := t1) (v := t6985) pv7217 (aw (ri t6985)) pv6985
theorem pv7215 : R t7215 t1 := result (f := t6992) (a := t7214) (u := t7209) (v := t7218) pv6992 (awb t6999 t6985 t7214 t7216 (refl _)) pv7218
theorem pv7211 : R t7211 t1 := result (f := t6995) (a := t1) (u := t6995) (v := t7215) (refl t6995) (aw (ra t6992 t1)) pv7215
theorem pv7212 : R t7212 t1 := result (f := t6999) (a := t7211) (u := t1) (v := t7211) pv6999 (aw (ri t7211)) pv7211
theorem pv7213 : R t7213 t1 := result (f := t7212) (a := t6985) (u := t1) (v := t6985) pv7212 (aw (ri t6985)) pv6985
theorem pv6996 : R t6996 t1 := result (f := t6992) (a := t6995) (u := t7209) (v := t7213) pv6992 (awb t6999 t6985 t6995 t7211 (refl _)) pv7213
theorem pv6993 : R t6993 t1 := result (f := t0) (a := t6992) (u := t0) (v := t6996) (refl t0) (aw (rh t6992)) pv6996
theorem pv6994 : R t6994 t1 := result (f := t6993) (a := t6985) (u := t1) (v := t6985) pv6993 (aw (ri t6985)) pv6985
theorem pv6991 : R t6991 t1 := result (f := t6988) (a := t6990) (u := t6988) (v := t6994) (refl t6988) (awb t0 t6985 t6990 t6992 (refl _)) pv6994
theorem pv6989 : R t6989 t1 := result (f := t0) (a := t6988) (u := t0) (v := t6991) (refl t0) (aw (rh t6988)) pv6991
theorem pv6986 : R t6986 t1 := result (f := t2) (a := t6985) (u := t2) (v := t6989) (refl t2) (aw (ra t0 t6985)) pv6989
theorem pv6987 : R t6987 t1 := result (f := t6986) (a := t6931) (u := t1) (v := t6931) pv6986 (aw (ri t6931)) pv6931
theorem pv6984 : R t6984 t1 := result (f := t6947) (a := t6983) (u := t6934) (v := t6987) pv6947 (awb t2 t6931 t6983 t6985 (refl _)) pv6987
theorem pv6958 : R t6958 t1 := result (f := t6950) (a := t1) (u := t6950) (v := t6984) (refl t6950) (aw (ra t6947 t1)) pv6984
theorem pv6982 : R t6982 t1 := result (f := t28) (a := t6958) (u := t1) (v := t6958) pv28 (aw (ri t6958)) pv6958
theorem pv6978 : R t6978 t1 := result (f := t6977) (a := t1) (u := t6980) (v := t6982) pv6977 (awb t1 t6958 t1 t1 (cI)) pv6982
theorem pv6972 : R t6972 t1 := result (f := t6970) (a := t1) (u := t6970) (v := t6978) (refl t6970) (awb t6961 t1 t1 t1 (cI)) pv6978
theorem pv6976 : R t6976 t6975 := result (f := t6972) (a := t6975) (u := t1) (v := t6975) pv6972 (aw (ri t6975)) (refl t6975)
theorem pv6973 : R t6973 t6975 := result (f := t0) (a := t6972) (u := t0) (v := t6976) (refl t0) (aw (rh t6972)) pv6976
theorem pv7224 : R t7224 t7223 := result (f := t6972) (a := t7223) (u := t1) (v := t7223) pv6972 (aw (ri t7223)) (refl t7223)
theorem pv6974 : R t6974 t7223 := result (f := t6973) (a := t6958) (u := t6975) (v := t7224) pv6973 (aw (ra t6972 t6958)) pv7224
theorem pv6971 : R t6971 t7223 := result (f := t6961) (a := t6970) (u := t6961) (v := t6974) (refl t6961) (awb t0 t6958 t6970 t6972 (refl _)) pv6974
theorem pv6965 : R t6965 t7223 := result (f := t6963) (a := t1) (u := t6963) (v := t6971) (refl t6963) (aw (ra t6961 t1)) pv6971
theorem pv7235 : R t7235 t1 := result (f := t6972) (a := t1) (u := t1) (v := t1) pv6972 (aw (ri t1)) (refl t1)
theorem pv7236 : R t7236 t1 := result (f := t7235) (a := t6958) (u := t1) (v := t6958) pv7235 (aw (ri t6958)) pv6958
theorem pv7233 : R t7233 t1 := result (f := t6965) (a := t1) (u := t7223) (v := t7236) pv6965 (awb t6972 t6958 t1 t1 (cI)) pv7236
theorem pv7234 : R t7234 t1 := result (f := t7233) (a := t1) (u := t1) (v := t1) pv7233 (aw (ri t1)) (refl t1)
theorem pv7230 : R t7230 t1 := result (f := t7228) (a := t1) (u := t7228) (v := t7234) (refl t7228) (awb t6965 t1 t1 t1 (cI)) pv7234
theorem pv7231 : R t7231 t1 := result (f := t6972) (a := t7230) (u := t1) (v := t7230) pv6972 (aw (ri t7230)) pv7230
theorem pv7232 : R t7232 t1 := result (f := t7231) (a := t6958) (u := t1) (v := t6958) pv7231 (aw (ri t6958)) pv6958
theorem pv7229 : R t7229 t1 := result (f := t6965) (a := t7228) (u := t7223) (v := t7232) pv6965 (awb t6972 t6958 t7228 t7230 (refl _)) pv7232
theorem pv7225 : R t7225 t1 := result (f := t6968) (a := t1) (u := t6968) (v := t7229) (refl t6968) (aw (ra t6965 t1)) pv7229
theorem pv7226 : R t7226 t1 := result (f := t6972) (a := t7225) (u := t1) (v := t7225) pv6972 (aw (ri t7225)) pv7225
theorem pv7227 : R t7227 t1 := result (f := t7226) (a := t6958) (u := t1) (v := t6958) pv7226 (aw (ri t6958)) pv6958
theorem pv6969 : R t6969 t1 := result (f := t6965) (a := t6968) (u := t7223) (v := t7227) pv6965 (awb t6972 t6958 t6968 t7225 (refl _)) pv7227
theorem pv6966 : R t6966 t1 := result (f := t0) (a := t6965) (u := t0) (v := t6969) (refl t0) (aw (rh t6965)) pv6969
theorem pv6967 : R t6967 t1 := result (f := t6966) (a := t6958) (u := t1) (v := t6958) pv6966 (aw (ri t6958)) pv6958
theorem pv6964 : R t6964 t1 := result (f := t6961) (a := t6963) (u := t6961) (v := t6967) (refl t6961) (awb t0 t6958 t6963 t6965 (refl _)) pv6967
theorem pv6962 : R t6962 t1 := result (f := t0) (a := t6961) (u := t0) (v := t6964) (refl t0) (aw (rh t6961)) pv6964
theorem pv6959 : R t6959 t1 := result (f := t2) (a := t6958) (u := t2) (v := t6962) (refl t2) (aw (ra t0 t6958)) pv6962
theorem pv6960 : R t6960 t1 := result (f := t6959) (a := t6931) (u := t1) (v := t6931) pv6959 (aw (ri t6931)) pv6931
theorem pv6951 : R t6951 t1 := result (f := t6947) (a := t6950) (u := t6934) (v := t6960) pv6947 (awb t2 t6931 t6950 t6958 (refl _)) pv6960
theorem pv6948 : R t6948 t1 := result (f := t0) (a := t6947) (u := t0) (v := t6951) (refl t0) (aw (rh t6947)) pv6951
theorem pv6949 : R t6949 t6934 := result (f := t6948) (a := t6934) (u := t1) (v := t6934) pv6948 (aw (ri t6934)) (refl t6934)
theorem pv6946 : R t6946 t6934 := result (f := t6936) (a := t6945) (u := t6936) (v := t6949) (refl t6936) (awb t0 t6934 t6945 t6947 (refl _)) pv6949
theorem pv6940 : R t6940 t6934 := result (f := t6938) (a := t1) (u := t6938) (v := t6946) (refl t6938) (aw (ra t6936 t1)) pv6946
theorem pv7260 : R t7260 t7259 := result (f := t1) (a := t7259) (u := t1) (v := t7259) (refl t1) (aw (ri t7259)) (refl t7259)
theorem pv7258 : R t7258 t7259 := result (f := t22) (a := t7237) (u := t24) (v := t7260) pv22 (aw (ra t1 t7237)) pv7260
theorem pv7256 : R t7256 t7259 := result (f := t7240) (a := t1) (u := t7240) (v := t7258) (refl t7240) (awb t0 t7237 t1 t1 (cI)) pv7258
theorem pv7287 : R t7287 t7286 := result (f := t1) (a := t7286) (u := t1) (v := t7286) (refl t1) (aw (ri t7286)) (refl t7286)
theorem pv7285 : R t7285 t7286 := result (f := t22) (a := t7264) (u := t24) (v := t7287) pv22 (aw (ra t1 t7264)) pv7287
theorem pv7283 : R t7283 t7286 := result (f := t7267) (a := t1) (u := t7267) (v := t7285) (refl t7267) (awb t0 t7264 t1 t1 (cI)) pv7285
theorem pv7289 : R t7289 t1 := result (f := t6940) (a := t1) (u := t6934) (v := t7012) pv6940 (awb t2 t6931 t1 t1 (cI)) pv7012
end Blc.H44.Pump
