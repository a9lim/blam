import H44Pumppv92
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6687 : R t6687 t1 := result (f := t6684) (a := t6686) (u := t6684) (v := t6690) (refl t6684) (awb t0 t6681 t6686 t6688 (refl _)) pv6690
theorem pv6685 : R t6685 t1 := result (f := t0) (a := t6684) (u := t0) (v := t6687) (refl t0) (aw (rh t6684)) pv6687
theorem pv6682 : R t6682 t1 := result (f := t2) (a := t6681) (u := t2) (v := t6685) (refl t2) (aw (ra t0 t6681)) pv6685
theorem pv6683 : R t6683 t1 := result (f := t6682) (a := t6627) (u := t1) (v := t6627) pv6682 (aw (ri t6627)) pv6627
theorem pv6680 : R t6680 t1 := result (f := t6643) (a := t6679) (u := t6630) (v := t6683) pv6643 (awb t2 t6627 t6679 t6681 (refl _)) pv6683
theorem pv6654 : R t6654 t1 := result (f := t6646) (a := t1) (u := t6646) (v := t6680) (refl t6646) (aw (ra t6643 t1)) pv6680
theorem pv6678 : R t6678 t1 := result (f := t28) (a := t6654) (u := t1) (v := t6654) pv28 (aw (ri t6654)) pv6654
theorem pv6674 : R t6674 t1 := result (f := t6673) (a := t1) (u := t6676) (v := t6678) pv6673 (awb t1 t6654 t1 t1 (cI)) pv6678
theorem pv6668 : R t6668 t1 := result (f := t6666) (a := t1) (u := t6666) (v := t6674) (refl t6666) (awb t6657 t1 t1 t1 (cI)) pv6674
theorem pv6672 : R t6672 t6671 := result (f := t6668) (a := t6671) (u := t1) (v := t6671) pv6668 (aw (ri t6671)) (refl t6671)
theorem pv6669 : R t6669 t6671 := result (f := t0) (a := t6668) (u := t0) (v := t6672) (refl t0) (aw (rh t6668)) pv6672
theorem pv6726 : R t6726 t6725 := result (f := t6668) (a := t6725) (u := t1) (v := t6725) pv6668 (aw (ri t6725)) (refl t6725)
theorem pv6670 : R t6670 t6725 := result (f := t6669) (a := t6654) (u := t6671) (v := t6726) pv6669 (aw (ra t6668 t6654)) pv6726
theorem pv6667 : R t6667 t6725 := result (f := t6657) (a := t6666) (u := t6657) (v := t6670) (refl t6657) (awb t0 t6654 t6666 t6668 (refl _)) pv6670
theorem pv6661 : R t6661 t6725 := result (f := t6659) (a := t1) (u := t6659) (v := t6667) (refl t6659) (aw (ra t6657 t1)) pv6667
theorem pv6737 : R t6737 t1 := result (f := t6668) (a := t1) (u := t1) (v := t1) pv6668 (aw (ri t1)) (refl t1)
theorem pv6738 : R t6738 t1 := result (f := t6737) (a := t6654) (u := t1) (v := t6654) pv6737 (aw (ri t6654)) pv6654
theorem pv6735 : R t6735 t1 := result (f := t6661) (a := t1) (u := t6725) (v := t6738) pv6661 (awb t6668 t6654 t1 t1 (cI)) pv6738
theorem pv6736 : R t6736 t1 := result (f := t6735) (a := t1) (u := t1) (v := t1) pv6735 (aw (ri t1)) (refl t1)
theorem pv6732 : R t6732 t1 := result (f := t6730) (a := t1) (u := t6730) (v := t6736) (refl t6730) (awb t6661 t1 t1 t1 (cI)) pv6736
theorem pv6733 : R t6733 t1 := result (f := t6668) (a := t6732) (u := t1) (v := t6732) pv6668 (aw (ri t6732)) pv6732
theorem pv6734 : R t6734 t1 := result (f := t6733) (a := t6654) (u := t1) (v := t6654) pv6733 (aw (ri t6654)) pv6654
theorem pv6731 : R t6731 t1 := result (f := t6661) (a := t6730) (u := t6725) (v := t6734) pv6661 (awb t6668 t6654 t6730 t6732 (refl _)) pv6734
theorem pv6727 : R t6727 t1 := result (f := t6664) (a := t1) (u := t6664) (v := t6731) (refl t6664) (aw (ra t6661 t1)) pv6731
theorem pv6728 : R t6728 t1 := result (f := t6668) (a := t6727) (u := t1) (v := t6727) pv6668 (aw (ri t6727)) pv6727
theorem pv6729 : R t6729 t1 := result (f := t6728) (a := t6654) (u := t1) (v := t6654) pv6728 (aw (ri t6654)) pv6654
theorem pv6665 : R t6665 t1 := result (f := t6661) (a := t6664) (u := t6725) (v := t6729) pv6661 (awb t6668 t6654 t6664 t6727 (refl _)) pv6729
theorem pv6662 : R t6662 t1 := result (f := t0) (a := t6661) (u := t0) (v := t6665) (refl t0) (aw (rh t6661)) pv6665
theorem pv6663 : R t6663 t1 := result (f := t6662) (a := t6654) (u := t1) (v := t6654) pv6662 (aw (ri t6654)) pv6654
theorem pv6660 : R t6660 t1 := result (f := t6657) (a := t6659) (u := t6657) (v := t6663) (refl t6657) (awb t0 t6654 t6659 t6661 (refl _)) pv6663
theorem pv6658 : R t6658 t1 := result (f := t0) (a := t6657) (u := t0) (v := t6660) (refl t0) (aw (rh t6657)) pv6660
theorem pv6655 : R t6655 t1 := result (f := t2) (a := t6654) (u := t2) (v := t6658) (refl t2) (aw (ra t0 t6654)) pv6658
theorem pv6656 : R t6656 t1 := result (f := t6655) (a := t6627) (u := t1) (v := t6627) pv6655 (aw (ri t6627)) pv6627
theorem pv6647 : R t6647 t1 := result (f := t6643) (a := t6646) (u := t6630) (v := t6656) pv6643 (awb t2 t6627 t6646 t6654 (refl _)) pv6656
theorem pv6644 : R t6644 t1 := result (f := t0) (a := t6643) (u := t0) (v := t6647) (refl t0) (aw (rh t6643)) pv6647
theorem pv6645 : R t6645 t6630 := result (f := t6644) (a := t6630) (u := t1) (v := t6630) pv6644 (aw (ri t6630)) (refl t6630)
theorem pv6642 : R t6642 t6630 := result (f := t6632) (a := t6641) (u := t6632) (v := t6645) (refl t6632) (awb t0 t6630 t6641 t6643 (refl _)) pv6645
theorem pv6636 : R t6636 t6630 := result (f := t6634) (a := t1) (u := t6634) (v := t6642) (refl t6634) (aw (ra t6632 t1)) pv6642
theorem pv6762 : R t6762 t6761 := result (f := t1) (a := t6761) (u := t1) (v := t6761) (refl t1) (aw (ri t6761)) (refl t6761)
theorem pv6760 : R t6760 t6761 := result (f := t22) (a := t6739) (u := t24) (v := t6762) pv22 (aw (ra t1 t6739)) pv6762
theorem pv6758 : R t6758 t6761 := result (f := t6742) (a := t1) (u := t6742) (v := t6760) (refl t6742) (awb t0 t6739 t1 t1 (cI)) pv6760
theorem pv6789 : R t6789 t6788 := result (f := t1) (a := t6788) (u := t1) (v := t6788) (refl t1) (aw (ri t6788)) (refl t6788)
theorem pv6787 : R t6787 t6788 := result (f := t22) (a := t6766) (u := t24) (v := t6789) pv22 (aw (ra t1 t6766)) pv6789
theorem pv6785 : R t6785 t6788 := result (f := t6769) (a := t1) (u := t6769) (v := t6787) (refl t6769) (awb t0 t6766 t1 t1 (cI)) pv6787
theorem pv6791 : R t6791 t1 := result (f := t6636) (a := t1) (u := t6630) (v := t6708) pv6636 (awb t2 t6627 t1 t1 (cI)) pv6708
theorem pv6792 : R t6792 t1 := result (f := t6791) (a := t1) (u := t1) (v := t1) pv6791 (aw (ri t1)) (refl t1)
theorem pv6766 : R t6766 t1 := result (f := t6764) (a := t1) (u := t6764) (v := t6792) (refl t6764) (awb t6636 t1 t1 t1 (cI)) pv6792
theorem pv6790 : R t6790 t1 := result (f := t28) (a := t6766) (u := t1) (v := t6766) pv28 (aw (ri t6766)) pv6766
theorem pv6786 : R t6786 t1 := result (f := t6785) (a := t1) (u := t6788) (v := t6790) pv6785 (awb t1 t6766 t1 t1 (cI)) pv6790
theorem pv6780 : R t6780 t1 := result (f := t6778) (a := t1) (u := t6778) (v := t6786) (refl t6778) (awb t6769 t1 t1 t1 (cI)) pv6786
theorem pv6784 : R t6784 t6783 := result (f := t6780) (a := t6783) (u := t1) (v := t6783) pv6780 (aw (ri t6783)) (refl t6783)
theorem pv6781 : R t6781 t6783 := result (f := t0) (a := t6780) (u := t0) (v := t6784) (refl t0) (aw (rh t6780)) pv6784
theorem pv6794 : R t6794 t6793 := result (f := t6780) (a := t6793) (u := t1) (v := t6793) pv6780 (aw (ri t6793)) (refl t6793)
theorem pv6782 : R t6782 t6793 := result (f := t6781) (a := t6766) (u := t6783) (v := t6794) pv6781 (aw (ra t6780 t6766)) pv6794
theorem pv6779 : R t6779 t6793 := result (f := t6769) (a := t6778) (u := t6769) (v := t6782) (refl t6769) (awb t0 t6766 t6778 t6780 (refl _)) pv6782
end Blc.H44.Pump
