import H44PumpN55
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pa25 : R t25 t24 := result (f := t1) (a := t24) (u := t1) (v := t24) (refl t1) (aw (ri t24)) (refl t24)
theorem pa22 : R t22 t24 := result (f := t0) (a := t1) (u := t0) (v := t25) (refl t0) (aw (rh t1)) pa25
theorem pa27 : R t27 t26 := result (f := t1) (a := t26) (u := t1) (v := t26) (refl t1) (aw (ri t26)) (refl t26)
theorem pa23 : R t23 t26 := result (f := t22) (a := t1) (u := t24) (v := t27) pa22 (aw (ra t1 t1)) pa27
theorem pa20 : R t20 t26 := result (f := t4) (a := t1) (u := t4) (v := t23) (refl t4) (awb t0 t1 t1 t1 (cI)) pa23
theorem pa28 : R t28 t1 := result (f := t1) (a := t1) (u := t1) (v := t1) (refl t1) (aw (ri t1)) (refl t1)
theorem pa29 : R t29 t1 := result (f := t28) (a := t1) (u := t1) (v := t1) pa28 (aw (ri t1)) (refl t1)
theorem pa21 : R t21 t1 := result (f := t20) (a := t1) (u := t26) (v := t29) pa20 (awb t1 t1 t1 t1 (cI)) pa29
theorem pa15 : R t15 t1 := result (f := t13) (a := t1) (u := t13) (v := t21) (refl t13) (awb t4 t1 t1 t1 (cI)) pa21
theorem pa19 : R t19 t18 := result (f := t15) (a := t18) (u := t1) (v := t18) pa15 (aw (ri t18)) (refl t18)
theorem pa16 : R t16 t18 := result (f := t0) (a := t15) (u := t0) (v := t19) (refl t0) (aw (rh t15)) pa19
theorem pa31 : R t31 t30 := result (f := t15) (a := t30) (u := t1) (v := t30) pa15 (aw (ri t30)) (refl t30)
theorem pa17 : R t17 t30 := result (f := t16) (a := t1) (u := t18) (v := t31) pa16 (aw (ra t15 t1)) pa31
theorem pa14 : R t14 t30 := result (f := t4) (a := t13) (u := t4) (v := t17) (refl t4) (awb t0 t1 t13 t15 (refl _)) pa17
theorem pa8 : R t8 t30 := result (f := t6) (a := t1) (u := t6) (v := t14) (refl t6) (aw (ra t4 t1)) pa14
theorem pa42 : R t42 t1 := result (f := t15) (a := t1) (u := t1) (v := t1) pa15 (aw (ri t1)) (refl t1)
theorem pa43 : R t43 t1 := result (f := t42) (a := t1) (u := t1) (v := t1) pa42 (aw (ri t1)) (refl t1)
theorem pa40 : R t40 t1 := result (f := t8) (a := t1) (u := t30) (v := t43) pa8 (awb t15 t1 t1 t1 (cI)) pa43
theorem pa41 : R t41 t1 := result (f := t40) (a := t1) (u := t1) (v := t1) pa40 (aw (ri t1)) (refl t1)
theorem pa37 : R t37 t1 := result (f := t35) (a := t1) (u := t35) (v := t41) (refl t35) (awb t8 t1 t1 t1 (cI)) pa41
theorem pa38 : R t38 t1 := result (f := t15) (a := t37) (u := t1) (v := t37) pa15 (aw (ri t37)) pa37
theorem pa39 : R t39 t1 := result (f := t38) (a := t1) (u := t1) (v := t1) pa38 (aw (ri t1)) (refl t1)
theorem pa36 : R t36 t1 := result (f := t8) (a := t35) (u := t30) (v := t39) pa8 (awb t15 t1 t35 t37 (refl _)) pa39
theorem pa32 : R t32 t1 := result (f := t11) (a := t1) (u := t11) (v := t36) (refl t11) (aw (ra t8 t1)) pa36
theorem pa33 : R t33 t1 := result (f := t15) (a := t32) (u := t1) (v := t32) pa15 (aw (ri t32)) pa32
theorem pa34 : R t34 t1 := result (f := t33) (a := t1) (u := t1) (v := t1) pa33 (aw (ri t1)) (refl t1)
theorem pa12 : R t12 t1 := result (f := t8) (a := t11) (u := t30) (v := t34) pa8 (awb t15 t1 t11 t32 (refl _)) pa34
theorem pa9 : R t9 t1 := result (f := t0) (a := t8) (u := t0) (v := t12) (refl t0) (aw (rh t8)) pa12
theorem pa10 : R t10 t1 := result (f := t9) (a := t1) (u := t1) (v := t1) pa9 (aw (ri t1)) (refl t1)
theorem pa7 : R t7 t1 := result (f := t4) (a := t6) (u := t4) (v := t10) (refl t4) (awb t0 t1 t6 t8 (refl _)) pa10
theorem pa5 : R t5 t1 := result (f := t0) (a := t4) (u := t0) (v := t7) (refl t0) (aw (rh t4)) pa7
theorem pa3 : R t3 t1 := result (f := t2) (a := t1) (u := t2) (v := t5) (refl t2) (aw (ra t0 t1)) pa5
end Blc.H44.Pump
