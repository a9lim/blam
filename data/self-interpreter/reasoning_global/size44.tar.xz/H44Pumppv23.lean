import H44Pumppv22
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1526 : R t1526 t1 := result (f := t2) (a := t1525) (u := t2) (v := t1529) (refl t2) (aw (ra t0 t1525)) pv1529
theorem pv1527 : R t1527 t1 := result (f := t1526) (a := t1471) (u := t1) (v := t1471) pv1526 (aw (ri t1471)) pv1471
theorem pv1524 : R t1524 t1 := result (f := t1487) (a := t1523) (u := t1474) (v := t1527) pv1487 (awb t2 t1471 t1523 t1525 (refl _)) pv1527
theorem pv1498 : R t1498 t1 := result (f := t1490) (a := t1) (u := t1490) (v := t1524) (refl t1490) (aw (ra t1487 t1)) pv1524
theorem pv1522 : R t1522 t1 := result (f := t28) (a := t1498) (u := t1) (v := t1498) pv28 (aw (ri t1498)) pv1498
theorem pv1518 : R t1518 t1 := result (f := t1517) (a := t1) (u := t1520) (v := t1522) pv1517 (awb t1 t1498 t1 t1 (cI)) pv1522
theorem pv1512 : R t1512 t1 := result (f := t1510) (a := t1) (u := t1510) (v := t1518) (refl t1510) (awb t1501 t1 t1 t1 (cI)) pv1518
theorem pv1516 : R t1516 t1515 := result (f := t1512) (a := t1515) (u := t1) (v := t1515) pv1512 (aw (ri t1515)) (refl t1515)
theorem pv1513 : R t1513 t1515 := result (f := t0) (a := t1512) (u := t0) (v := t1516) (refl t0) (aw (rh t1512)) pv1516
theorem pv1764 : R t1764 t1763 := result (f := t1512) (a := t1763) (u := t1) (v := t1763) pv1512 (aw (ri t1763)) (refl t1763)
theorem pv1514 : R t1514 t1763 := result (f := t1513) (a := t1498) (u := t1515) (v := t1764) pv1513 (aw (ra t1512 t1498)) pv1764
theorem pv1511 : R t1511 t1763 := result (f := t1501) (a := t1510) (u := t1501) (v := t1514) (refl t1501) (awb t0 t1498 t1510 t1512 (refl _)) pv1514
theorem pv1505 : R t1505 t1763 := result (f := t1503) (a := t1) (u := t1503) (v := t1511) (refl t1503) (aw (ra t1501 t1)) pv1511
theorem pv1775 : R t1775 t1 := result (f := t1512) (a := t1) (u := t1) (v := t1) pv1512 (aw (ri t1)) (refl t1)
theorem pv1776 : R t1776 t1 := result (f := t1775) (a := t1498) (u := t1) (v := t1498) pv1775 (aw (ri t1498)) pv1498
theorem pv1773 : R t1773 t1 := result (f := t1505) (a := t1) (u := t1763) (v := t1776) pv1505 (awb t1512 t1498 t1 t1 (cI)) pv1776
theorem pv1774 : R t1774 t1 := result (f := t1773) (a := t1) (u := t1) (v := t1) pv1773 (aw (ri t1)) (refl t1)
theorem pv1770 : R t1770 t1 := result (f := t1768) (a := t1) (u := t1768) (v := t1774) (refl t1768) (awb t1505 t1 t1 t1 (cI)) pv1774
theorem pv1771 : R t1771 t1 := result (f := t1512) (a := t1770) (u := t1) (v := t1770) pv1512 (aw (ri t1770)) pv1770
theorem pv1772 : R t1772 t1 := result (f := t1771) (a := t1498) (u := t1) (v := t1498) pv1771 (aw (ri t1498)) pv1498
theorem pv1769 : R t1769 t1 := result (f := t1505) (a := t1768) (u := t1763) (v := t1772) pv1505 (awb t1512 t1498 t1768 t1770 (refl _)) pv1772
theorem pv1765 : R t1765 t1 := result (f := t1508) (a := t1) (u := t1508) (v := t1769) (refl t1508) (aw (ra t1505 t1)) pv1769
theorem pv1766 : R t1766 t1 := result (f := t1512) (a := t1765) (u := t1) (v := t1765) pv1512 (aw (ri t1765)) pv1765
theorem pv1767 : R t1767 t1 := result (f := t1766) (a := t1498) (u := t1) (v := t1498) pv1766 (aw (ri t1498)) pv1498
theorem pv1509 : R t1509 t1 := result (f := t1505) (a := t1508) (u := t1763) (v := t1767) pv1505 (awb t1512 t1498 t1508 t1765 (refl _)) pv1767
theorem pv1506 : R t1506 t1 := result (f := t0) (a := t1505) (u := t0) (v := t1509) (refl t0) (aw (rh t1505)) pv1509
theorem pv1507 : R t1507 t1 := result (f := t1506) (a := t1498) (u := t1) (v := t1498) pv1506 (aw (ri t1498)) pv1498
theorem pv1504 : R t1504 t1 := result (f := t1501) (a := t1503) (u := t1501) (v := t1507) (refl t1501) (awb t0 t1498 t1503 t1505 (refl _)) pv1507
theorem pv1502 : R t1502 t1 := result (f := t0) (a := t1501) (u := t0) (v := t1504) (refl t0) (aw (rh t1501)) pv1504
theorem pv1499 : R t1499 t1 := result (f := t2) (a := t1498) (u := t2) (v := t1502) (refl t2) (aw (ra t0 t1498)) pv1502
theorem pv1500 : R t1500 t1 := result (f := t1499) (a := t1471) (u := t1) (v := t1471) pv1499 (aw (ri t1471)) pv1471
theorem pv1491 : R t1491 t1 := result (f := t1487) (a := t1490) (u := t1474) (v := t1500) pv1487 (awb t2 t1471 t1490 t1498 (refl _)) pv1500
theorem pv1488 : R t1488 t1 := result (f := t0) (a := t1487) (u := t0) (v := t1491) (refl t0) (aw (rh t1487)) pv1491
theorem pv1489 : R t1489 t1474 := result (f := t1488) (a := t1474) (u := t1) (v := t1474) pv1488 (aw (ri t1474)) (refl t1474)
theorem pv1486 : R t1486 t1474 := result (f := t1476) (a := t1485) (u := t1476) (v := t1489) (refl t1476) (awb t0 t1474 t1485 t1487 (refl _)) pv1489
theorem pv1480 : R t1480 t1474 := result (f := t1478) (a := t1) (u := t1478) (v := t1486) (refl t1478) (aw (ra t1476 t1)) pv1486
theorem pv1800 : R t1800 t1799 := result (f := t1) (a := t1799) (u := t1) (v := t1799) (refl t1) (aw (ri t1799)) (refl t1799)
theorem pv1798 : R t1798 t1799 := result (f := t22) (a := t1777) (u := t24) (v := t1800) pv22 (aw (ra t1 t1777)) pv1800
theorem pv1796 : R t1796 t1799 := result (f := t1780) (a := t1) (u := t1780) (v := t1798) (refl t1780) (awb t0 t1777 t1 t1 (cI)) pv1798
theorem pv1827 : R t1827 t1826 := result (f := t1) (a := t1826) (u := t1) (v := t1826) (refl t1) (aw (ri t1826)) (refl t1826)
theorem pv1825 : R t1825 t1826 := result (f := t22) (a := t1804) (u := t24) (v := t1827) pv22 (aw (ra t1 t1804)) pv1827
theorem pv1823 : R t1823 t1826 := result (f := t1807) (a := t1) (u := t1807) (v := t1825) (refl t1807) (awb t0 t1804 t1 t1 (cI)) pv1825
theorem pv1829 : R t1829 t1 := result (f := t1480) (a := t1) (u := t1474) (v := t1552) pv1480 (awb t2 t1471 t1 t1 (cI)) pv1552
theorem pv1830 : R t1830 t1 := result (f := t1829) (a := t1) (u := t1) (v := t1) pv1829 (aw (ri t1)) (refl t1)
theorem pv1804 : R t1804 t1 := result (f := t1802) (a := t1) (u := t1802) (v := t1830) (refl t1802) (awb t1480 t1 t1 t1 (cI)) pv1830
theorem pv1828 : R t1828 t1 := result (f := t28) (a := t1804) (u := t1) (v := t1804) pv28 (aw (ri t1804)) pv1804
theorem pv1824 : R t1824 t1 := result (f := t1823) (a := t1) (u := t1826) (v := t1828) pv1823 (awb t1 t1804 t1 t1 (cI)) pv1828
theorem pv1818 : R t1818 t1 := result (f := t1816) (a := t1) (u := t1816) (v := t1824) (refl t1816) (awb t1807 t1 t1 t1 (cI)) pv1824
theorem pv1822 : R t1822 t1821 := result (f := t1818) (a := t1821) (u := t1) (v := t1821) pv1818 (aw (ri t1821)) (refl t1821)
theorem pv1819 : R t1819 t1821 := result (f := t0) (a := t1818) (u := t0) (v := t1822) (refl t0) (aw (rh t1818)) pv1822
theorem pv1832 : R t1832 t1831 := result (f := t1818) (a := t1831) (u := t1) (v := t1831) pv1818 (aw (ri t1831)) (refl t1831)
theorem pv1820 : R t1820 t1831 := result (f := t1819) (a := t1804) (u := t1821) (v := t1832) pv1819 (aw (ra t1818 t1804)) pv1832
theorem pv1817 : R t1817 t1831 := result (f := t1807) (a := t1816) (u := t1807) (v := t1820) (refl t1807) (awb t0 t1804 t1816 t1818 (refl _)) pv1820
theorem pv1811 : R t1811 t1831 := result (f := t1809) (a := t1) (u := t1809) (v := t1817) (refl t1809) (aw (ra t1807 t1)) pv1817
theorem pv1843 : R t1843 t1 := result (f := t1818) (a := t1) (u := t1) (v := t1) pv1818 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
