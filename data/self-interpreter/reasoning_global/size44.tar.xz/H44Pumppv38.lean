import H44Pumppv37
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2872 : R t2872 t2871 := result (f := t2855) (a := t2871) (u := t1) (v := t2871) pv2855 (aw (ri t2871)) (refl t2871)
theorem pv2857 : R t2857 t2871 := result (f := t2856) (a := t2841) (u := t2858) (v := t2872) pv2856 (aw (ra t2855 t2841)) pv2872
theorem pv2854 : R t2854 t2871 := result (f := t2844) (a := t2853) (u := t2844) (v := t2857) (refl t2844) (awb t0 t2841 t2853 t2855 (refl _)) pv2857
theorem pv2848 : R t2848 t2871 := result (f := t2846) (a := t1) (u := t2846) (v := t2854) (refl t2846) (aw (ra t2844 t1)) pv2854
theorem pv2883 : R t2883 t1 := result (f := t2855) (a := t1) (u := t1) (v := t1) pv2855 (aw (ri t1)) (refl t1)
theorem pv2884 : R t2884 t1 := result (f := t2883) (a := t2841) (u := t1) (v := t2841) pv2883 (aw (ri t2841)) pv2841
theorem pv2881 : R t2881 t1 := result (f := t2848) (a := t1) (u := t2871) (v := t2884) pv2848 (awb t2855 t2841 t1 t1 (cI)) pv2884
theorem pv2882 : R t2882 t1 := result (f := t2881) (a := t1) (u := t1) (v := t1) pv2881 (aw (ri t1)) (refl t1)
theorem pv2878 : R t2878 t1 := result (f := t2876) (a := t1) (u := t2876) (v := t2882) (refl t2876) (awb t2848 t1 t1 t1 (cI)) pv2882
theorem pv2879 : R t2879 t1 := result (f := t2855) (a := t2878) (u := t1) (v := t2878) pv2855 (aw (ri t2878)) pv2878
theorem pv2880 : R t2880 t1 := result (f := t2879) (a := t2841) (u := t1) (v := t2841) pv2879 (aw (ri t2841)) pv2841
theorem pv2877 : R t2877 t1 := result (f := t2848) (a := t2876) (u := t2871) (v := t2880) pv2848 (awb t2855 t2841 t2876 t2878 (refl _)) pv2880
theorem pv2873 : R t2873 t1 := result (f := t2851) (a := t1) (u := t2851) (v := t2877) (refl t2851) (aw (ra t2848 t1)) pv2877
theorem pv2874 : R t2874 t1 := result (f := t2855) (a := t2873) (u := t1) (v := t2873) pv2855 (aw (ri t2873)) pv2873
theorem pv2875 : R t2875 t1 := result (f := t2874) (a := t2841) (u := t1) (v := t2841) pv2874 (aw (ri t2841)) pv2841
theorem pv2852 : R t2852 t1 := result (f := t2848) (a := t2851) (u := t2871) (v := t2875) pv2848 (awb t2855 t2841 t2851 t2873 (refl _)) pv2875
theorem pv2849 : R t2849 t1 := result (f := t0) (a := t2848) (u := t0) (v := t2852) (refl t0) (aw (rh t2848)) pv2852
theorem pv2850 : R t2850 t1 := result (f := t2849) (a := t2841) (u := t1) (v := t2841) pv2849 (aw (ri t2841)) pv2841
theorem pv2847 : R t2847 t1 := result (f := t2844) (a := t2846) (u := t2844) (v := t2850) (refl t2844) (awb t0 t2841 t2846 t2848 (refl _)) pv2850
theorem pv2845 : R t2845 t1 := result (f := t0) (a := t2844) (u := t0) (v := t2847) (refl t0) (aw (rh t2844)) pv2847
theorem pv2842 : R t2842 t1 := result (f := t2) (a := t2841) (u := t2) (v := t2845) (refl t2) (aw (ra t0 t2841)) pv2845
theorem pv2843 : R t2843 t1 := result (f := t2842) (a := t2787) (u := t1) (v := t2787) pv2842 (aw (ri t2787)) pv2787
theorem pv2840 : R t2840 t1 := result (f := t2803) (a := t2839) (u := t2790) (v := t2843) pv2803 (awb t2 t2787 t2839 t2841 (refl _)) pv2843
theorem pv2814 : R t2814 t1 := result (f := t2806) (a := t1) (u := t2806) (v := t2840) (refl t2806) (aw (ra t2803 t1)) pv2840
theorem pv2838 : R t2838 t1 := result (f := t28) (a := t2814) (u := t1) (v := t2814) pv28 (aw (ri t2814)) pv2814
theorem pv2834 : R t2834 t1 := result (f := t2833) (a := t1) (u := t2836) (v := t2838) pv2833 (awb t1 t2814 t1 t1 (cI)) pv2838
theorem pv2828 : R t2828 t1 := result (f := t2826) (a := t1) (u := t2826) (v := t2834) (refl t2826) (awb t2817 t1 t1 t1 (cI)) pv2834
theorem pv2832 : R t2832 t2831 := result (f := t2828) (a := t2831) (u := t1) (v := t2831) pv2828 (aw (ri t2831)) (refl t2831)
theorem pv2829 : R t2829 t2831 := result (f := t0) (a := t2828) (u := t0) (v := t2832) (refl t0) (aw (rh t2828)) pv2832
theorem pv2886 : R t2886 t2885 := result (f := t2828) (a := t2885) (u := t1) (v := t2885) pv2828 (aw (ri t2885)) (refl t2885)
theorem pv2830 : R t2830 t2885 := result (f := t2829) (a := t2814) (u := t2831) (v := t2886) pv2829 (aw (ra t2828 t2814)) pv2886
theorem pv2827 : R t2827 t2885 := result (f := t2817) (a := t2826) (u := t2817) (v := t2830) (refl t2817) (awb t0 t2814 t2826 t2828 (refl _)) pv2830
theorem pv2821 : R t2821 t2885 := result (f := t2819) (a := t1) (u := t2819) (v := t2827) (refl t2819) (aw (ra t2817 t1)) pv2827
theorem pv2897 : R t2897 t1 := result (f := t2828) (a := t1) (u := t1) (v := t1) pv2828 (aw (ri t1)) (refl t1)
theorem pv2898 : R t2898 t1 := result (f := t2897) (a := t2814) (u := t1) (v := t2814) pv2897 (aw (ri t2814)) pv2814
theorem pv2895 : R t2895 t1 := result (f := t2821) (a := t1) (u := t2885) (v := t2898) pv2821 (awb t2828 t2814 t1 t1 (cI)) pv2898
theorem pv2896 : R t2896 t1 := result (f := t2895) (a := t1) (u := t1) (v := t1) pv2895 (aw (ri t1)) (refl t1)
theorem pv2892 : R t2892 t1 := result (f := t2890) (a := t1) (u := t2890) (v := t2896) (refl t2890) (awb t2821 t1 t1 t1 (cI)) pv2896
theorem pv2893 : R t2893 t1 := result (f := t2828) (a := t2892) (u := t1) (v := t2892) pv2828 (aw (ri t2892)) pv2892
theorem pv2894 : R t2894 t1 := result (f := t2893) (a := t2814) (u := t1) (v := t2814) pv2893 (aw (ri t2814)) pv2814
theorem pv2891 : R t2891 t1 := result (f := t2821) (a := t2890) (u := t2885) (v := t2894) pv2821 (awb t2828 t2814 t2890 t2892 (refl _)) pv2894
theorem pv2887 : R t2887 t1 := result (f := t2824) (a := t1) (u := t2824) (v := t2891) (refl t2824) (aw (ra t2821 t1)) pv2891
theorem pv2888 : R t2888 t1 := result (f := t2828) (a := t2887) (u := t1) (v := t2887) pv2828 (aw (ri t2887)) pv2887
theorem pv2889 : R t2889 t1 := result (f := t2888) (a := t2814) (u := t1) (v := t2814) pv2888 (aw (ri t2814)) pv2814
theorem pv2825 : R t2825 t1 := result (f := t2821) (a := t2824) (u := t2885) (v := t2889) pv2821 (awb t2828 t2814 t2824 t2887 (refl _)) pv2889
theorem pv2822 : R t2822 t1 := result (f := t0) (a := t2821) (u := t0) (v := t2825) (refl t0) (aw (rh t2821)) pv2825
theorem pv2823 : R t2823 t1 := result (f := t2822) (a := t2814) (u := t1) (v := t2814) pv2822 (aw (ri t2814)) pv2814
theorem pv2820 : R t2820 t1 := result (f := t2817) (a := t2819) (u := t2817) (v := t2823) (refl t2817) (awb t0 t2814 t2819 t2821 (refl _)) pv2823
theorem pv2818 : R t2818 t1 := result (f := t0) (a := t2817) (u := t0) (v := t2820) (refl t0) (aw (rh t2817)) pv2820
theorem pv2815 : R t2815 t1 := result (f := t2) (a := t2814) (u := t2) (v := t2818) (refl t2) (aw (ra t0 t2814)) pv2818
theorem pv2816 : R t2816 t1 := result (f := t2815) (a := t2787) (u := t1) (v := t2787) pv2815 (aw (ri t2787)) pv2787
theorem pv2807 : R t2807 t1 := result (f := t2803) (a := t2806) (u := t2790) (v := t2816) pv2803 (awb t2 t2787 t2806 t2814 (refl _)) pv2816
theorem pv2804 : R t2804 t1 := result (f := t0) (a := t2803) (u := t0) (v := t2807) (refl t0) (aw (rh t2803)) pv2807
theorem pv2805 : R t2805 t2790 := result (f := t2804) (a := t2790) (u := t1) (v := t2790) pv2804 (aw (ri t2790)) (refl t2790)
theorem pv2802 : R t2802 t2790 := result (f := t2792) (a := t2801) (u := t2792) (v := t2805) (refl t2792) (awb t0 t2790 t2801 t2803 (refl _)) pv2805
end Blc.H44.Pump
