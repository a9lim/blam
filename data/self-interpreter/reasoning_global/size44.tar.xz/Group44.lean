import Blc.SelfintControl
namespace Blc.Floor44
structure Group where
  terms : List Term
  reject : ∀ t ∈ terms, ¬ IsSelfInterpreter t
def emptyGroup : Group := ⟨[],by simp⟩
def add (t : Term) (h : ¬ IsSelfInterpreter t) (r : Group) : Group :=
  ⟨t :: r.terms, by
    intro u hu
    rcases List.mem_cons.mp hu with rfl | h'
    · exact h
    · exact r.reject u h'⟩
def merge (a b : Group) : Group :=
  ⟨a.terms ++ b.terms, by
    intro t h
    rcases List.mem_append.mp h with h | h
    · exact a.reject t h
    · exact b.reject t h⟩
end Blc.Floor44
