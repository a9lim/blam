import H44Pumppv18
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1437 : R t1437 t1457 := result (f := t1435) (a := t1) (u := t1435) (v := t1443) (refl t1435) (aw (ra t1433 t1)) pv1443
theorem pv1469 : R t1469 t1 := result (f := t1444) (a := t1) (u := t1) (v := t1) pv1444 (aw (ri t1)) (refl t1)
theorem pv1470 : R t1470 t1 := result (f := t1469) (a := t1430) (u := t1) (v := t1430) pv1469 (aw (ri t1430)) pv1430
theorem pv1467 : R t1467 t1 := result (f := t1437) (a := t1) (u := t1457) (v := t1470) pv1437 (awb t1444 t1430 t1 t1 (cI)) pv1470
theorem pv1468 : R t1468 t1 := result (f := t1467) (a := t1) (u := t1) (v := t1) pv1467 (aw (ri t1)) (refl t1)
theorem pv1464 : R t1464 t1 := result (f := t1462) (a := t1) (u := t1462) (v := t1468) (refl t1462) (awb t1437 t1 t1 t1 (cI)) pv1468
theorem pv1465 : R t1465 t1 := result (f := t1444) (a := t1464) (u := t1) (v := t1464) pv1444 (aw (ri t1464)) pv1464
theorem pv1466 : R t1466 t1 := result (f := t1465) (a := t1430) (u := t1) (v := t1430) pv1465 (aw (ri t1430)) pv1430
theorem pv1463 : R t1463 t1 := result (f := t1437) (a := t1462) (u := t1457) (v := t1466) pv1437 (awb t1444 t1430 t1462 t1464 (refl _)) pv1466
theorem pv1459 : R t1459 t1 := result (f := t1440) (a := t1) (u := t1440) (v := t1463) (refl t1440) (aw (ra t1437 t1)) pv1463
theorem pv1460 : R t1460 t1 := result (f := t1444) (a := t1459) (u := t1) (v := t1459) pv1444 (aw (ri t1459)) pv1459
theorem pv1461 : R t1461 t1 := result (f := t1460) (a := t1430) (u := t1) (v := t1430) pv1460 (aw (ri t1430)) pv1430
theorem pv1441 : R t1441 t1 := result (f := t1437) (a := t1440) (u := t1457) (v := t1461) pv1437 (awb t1444 t1430 t1440 t1459 (refl _)) pv1461
theorem pv1438 : R t1438 t1 := result (f := t0) (a := t1437) (u := t0) (v := t1441) (refl t0) (aw (rh t1437)) pv1441
theorem pv1439 : R t1439 t1 := result (f := t1438) (a := t1430) (u := t1) (v := t1430) pv1438 (aw (ri t1430)) pv1430
theorem pv1436 : R t1436 t1 := result (f := t1433) (a := t1435) (u := t1433) (v := t1439) (refl t1433) (awb t0 t1430 t1435 t1437 (refl _)) pv1439
theorem pv1434 : R t1434 t1 := result (f := t0) (a := t1433) (u := t0) (v := t1436) (refl t0) (aw (rh t1433)) pv1436
theorem pv1431 : R t1431 t1 := result (f := t2) (a := t1430) (u := t2) (v := t1434) (refl t2) (aw (ra t0 t1430)) pv1434
theorem pv1432 : R t1432 t149 := result (f := t1431) (a := t149) (u := t1) (v := t149) pv1431 (aw (ri t149)) (refl t149)
theorem pv1429 : R t1429 t149 := result (f := t157) (a := t1428) (u := t151) (v := t1432) pv157 (awb t2 t149 t1428 t1430 (refl _)) pv1432
theorem pv1403 : R t1403 t149 := result (f := t160) (a := t1) (u := t160) (v := t1429) (refl t160) (aw (ra t157 t1)) pv1429
theorem pv1427 : R t1427 t149 := result (f := t28) (a := t1403) (u := t1) (v := t1403) pv28 (aw (ri t1403)) pv1403
theorem pv1423 : R t1423 t149 := result (f := t1422) (a := t1) (u := t1425) (v := t1427) pv1422 (awb t1 t1403 t1 t1 (cI)) pv1427
theorem pv1417 : R t1417 t149 := result (f := t1415) (a := t1) (u := t1415) (v := t1423) (refl t1415) (awb t1406 t1 t1 t1 (cI)) pv1423
theorem pv1496 : R t1496 t1495 := result (f := t1) (a := t1495) (u := t1) (v := t1495) (refl t1) (aw (ri t1495)) (refl t1495)
theorem pv1494 : R t1494 t1495 := result (f := t22) (a := t1474) (u := t24) (v := t1496) pv22 (aw (ra t1 t1474)) pv1496
theorem pv1492 : R t1492 t1495 := result (f := t1476) (a := t1) (u := t1476) (v := t1494) (refl t1476) (awb t0 t1474 t1 t1 (cI)) pv1494
theorem pv1497 : R t1497 t1474 := result (f := t28) (a := t1474) (u := t1) (v := t1474) pv28 (aw (ri t1474)) (refl t1474)
theorem pv1493 : R t1493 t1474 := result (f := t1492) (a := t1) (u := t1495) (v := t1497) pv1492 (awb t1 t1474 t1 t1 (cI)) pv1497
theorem pv1487 : R t1487 t1474 := result (f := t1485) (a := t1) (u := t1485) (v := t1493) (refl t1485) (awb t1476 t1 t1 t1 (cI)) pv1493
theorem pv1521 : R t1521 t1520 := result (f := t1) (a := t1520) (u := t1) (v := t1520) (refl t1) (aw (ri t1520)) (refl t1520)
theorem pv1519 : R t1519 t1520 := result (f := t22) (a := t1498) (u := t24) (v := t1521) pv22 (aw (ra t1 t1498)) pv1521
theorem pv1517 : R t1517 t1520 := result (f := t1501) (a := t1) (u := t1501) (v := t1519) (refl t1501) (awb t0 t1498 t1 t1 (cI)) pv1519
theorem pv1548 : R t1548 t1547 := result (f := t1) (a := t1547) (u := t1) (v := t1547) (refl t1) (aw (ri t1547)) (refl t1547)
theorem pv1546 : R t1546 t1547 := result (f := t22) (a := t1525) (u := t24) (v := t1548) pv22 (aw (ra t1 t1525)) pv1548
theorem pv1544 : R t1544 t1547 := result (f := t1528) (a := t1) (u := t1528) (v := t1546) (refl t1528) (awb t0 t1525 t1 t1 (cI)) pv1546
theorem pv1580 : R t1580 t1579 := result (f := t1) (a := t1579) (u := t1) (v := t1579) (refl t1) (aw (ri t1579)) (refl t1579)
theorem pv1578 : R t1578 t1579 := result (f := t22) (a := t1558) (u := t24) (v := t1580) pv22 (aw (ra t1 t1558)) pv1580
theorem pv1576 : R t1576 t1579 := result (f := t1560) (a := t1) (u := t1560) (v := t1578) (refl t1560) (awb t0 t1558 t1 t1 (cI)) pv1578
theorem pv1581 : R t1581 t1558 := result (f := t28) (a := t1558) (u := t1) (v := t1558) pv28 (aw (ri t1558)) (refl t1558)
theorem pv1577 : R t1577 t1558 := result (f := t1576) (a := t1) (u := t1579) (v := t1581) pv1576 (awb t1 t1558 t1 t1 (cI)) pv1581
theorem pv1571 : R t1571 t1558 := result (f := t1569) (a := t1) (u := t1569) (v := t1577) (refl t1569) (awb t1560 t1 t1 t1 (cI)) pv1577
theorem pv1605 : R t1605 t1604 := result (f := t1) (a := t1604) (u := t1) (v := t1604) (refl t1) (aw (ri t1604)) (refl t1604)
theorem pv1603 : R t1603 t1604 := result (f := t22) (a := t1582) (u := t24) (v := t1605) pv22 (aw (ra t1 t1582)) pv1605
theorem pv1601 : R t1601 t1604 := result (f := t1585) (a := t1) (u := t1585) (v := t1603) (refl t1585) (awb t0 t1582 t1 t1 (cI)) pv1603
theorem pv1632 : R t1632 t1631 := result (f := t1) (a := t1631) (u := t1) (v := t1631) (refl t1) (aw (ri t1631)) (refl t1631)
theorem pv1630 : R t1630 t1631 := result (f := t22) (a := t1609) (u := t24) (v := t1632) pv22 (aw (ra t1 t1609)) pv1632
theorem pv1628 : R t1628 t1631 := result (f := t1612) (a := t1) (u := t1612) (v := t1630) (refl t1612) (awb t0 t1609 t1 t1 (cI)) pv1630
theorem pv1637 : R t1637 t1 := result (f := t1417) (a := t1) (u := t149) (v := t231) pv1417 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv1638 : R t1638 t1 := result (f := t1637) (a := t1) (u := t1) (v := t1) pv1637 (aw (ri t1)) (refl t1)
theorem pv1555 : R t1555 t1 := result (f := t1553) (a := t1) (u := t1553) (v := t1638) (refl t1553) (awb t1417 t1 t1 t1 (cI)) pv1638
theorem pv1636 : R t1636 t1 := result (f := t3) (a := t1555) (u := t1) (v := t1555) pv3 (aw (ri t1555)) pv1555
theorem pv1634 : R t1634 t1 := result (f := t1571) (a := t1) (u := t1558) (v := t1636) pv1571 (awb t2 t1555 t1 t1 (cI)) pv1636
theorem pv1635 : R t1635 t1 := result (f := t1634) (a := t1) (u := t1) (v := t1) pv1634 (aw (ri t1)) (refl t1)
theorem pv1609 : R t1609 t1 := result (f := t1607) (a := t1) (u := t1607) (v := t1635) (refl t1607) (awb t1571 t1 t1 t1 (cI)) pv1635
end Blc.H44.Pump
