from wireterms import *
rows=['import Alt','import Blc.SelfintKernelFloor38','namespace Blc.Floor44.Alternative','open Term SelfintSharp SelfintLowerBound']
for s,r in json.loads((HERE/'alternatives.json').read_text()).items():
    e=lc.decode(s)[0];n='e'+str(int(s,2));u=A(e,V(0))
    for p in r[1]:u=red(u,p)
    rows += [f'def {n} : Term := {expr(e)}',f'theorem wire_{n} : Closed {n} ∧ code {n} = {int("1"+s,2)} := by decide']
    if r[0]=='lostC':
        rows+= [f'theorem cert_{n} : ¬ IsSelfInterpreter {n} := Alt.lost (u := {expr(u)}) (p := {paths(r[1])}) (by decide) (by decide)']
    else:
        f=lc.decode(r[2])[0];v=A(f,V(0))
        for p in r[3]:v=red(v,p)
        assert u==v and wire(f)<44
        rows += [f'theorem cert_{n} : ¬ IsSelfInterpreter {n} :=',
                 f'  Alt.shorter (f := {expr(f)}) (t := {expr(u)}) (p := {paths(r[1])}) (q := {paths(r[3])}) SelfintSingleObject.selfintSizeBound_38 (by decide) (by decide) (by decide) (by decide)']
    rows.append(f'#print axioms cert_{n}')
(HERE/'Alternative.lean').write_text('\n'.join(rows)+'\nend Blc.Floor44.Alternative\n')
