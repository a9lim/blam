import H44Clocks
import H44T4846363331350V55
namespace Blc.H44
open Term SelfintSharp SelfintLowerBound SelfintProbe SelfintControl WeakHeadClock Types
namespace T4846363331350
theorem excluded : ¬ IsSelfInterpreter e4846363331350 := by
  intro he
  have hp : replay [] e4846363331350 = some src := by decide
  obtain ⟨_,hc⟩ := clocks_replay (rawCount he) hp
  exact Types.noClock (m := tab) (by exact (v78 Types.empty) 0 (by decide)) (by decide) hc
#print axioms excluded
end T4846363331350
end Blc.H44
