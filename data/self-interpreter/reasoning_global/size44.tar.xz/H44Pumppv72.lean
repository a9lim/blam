import H44Pumppv71
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv4914 : R t4914 t4916 := result (f := t0) (a := t4913) (u := t0) (v := t4917) (refl t0) (aw (rh t4913)) pv4917
theorem pv5165 : R t5165 t5164 := result (f := t4913) (a := t5164) (u := t1) (v := t5164) pv4913 (aw (ri t5164)) (refl t5164)
theorem pv4915 : R t4915 t5164 := result (f := t4914) (a := t4899) (u := t4916) (v := t5165) pv4914 (aw (ra t4913 t4899)) pv5165
theorem pv4912 : R t4912 t5164 := result (f := t4902) (a := t4911) (u := t4902) (v := t4915) (refl t4902) (awb t0 t4899 t4911 t4913 (refl _)) pv4915
theorem pv4906 : R t4906 t5164 := result (f := t4904) (a := t1) (u := t4904) (v := t4912) (refl t4904) (aw (ra t4902 t1)) pv4912
theorem pv5176 : R t5176 t1 := result (f := t4913) (a := t1) (u := t1) (v := t1) pv4913 (aw (ri t1)) (refl t1)
theorem pv5177 : R t5177 t1 := result (f := t5176) (a := t4899) (u := t1) (v := t4899) pv5176 (aw (ri t4899)) pv4899
theorem pv5174 : R t5174 t1 := result (f := t4906) (a := t1) (u := t5164) (v := t5177) pv4906 (awb t4913 t4899 t1 t1 (cI)) pv5177
theorem pv5175 : R t5175 t1 := result (f := t5174) (a := t1) (u := t1) (v := t1) pv5174 (aw (ri t1)) (refl t1)
theorem pv5171 : R t5171 t1 := result (f := t5169) (a := t1) (u := t5169) (v := t5175) (refl t5169) (awb t4906 t1 t1 t1 (cI)) pv5175
theorem pv5172 : R t5172 t1 := result (f := t4913) (a := t5171) (u := t1) (v := t5171) pv4913 (aw (ri t5171)) pv5171
theorem pv5173 : R t5173 t1 := result (f := t5172) (a := t4899) (u := t1) (v := t4899) pv5172 (aw (ri t4899)) pv4899
theorem pv5170 : R t5170 t1 := result (f := t4906) (a := t5169) (u := t5164) (v := t5173) pv4906 (awb t4913 t4899 t5169 t5171 (refl _)) pv5173
theorem pv5166 : R t5166 t1 := result (f := t4909) (a := t1) (u := t4909) (v := t5170) (refl t4909) (aw (ra t4906 t1)) pv5170
theorem pv5167 : R t5167 t1 := result (f := t4913) (a := t5166) (u := t1) (v := t5166) pv4913 (aw (ri t5166)) pv5166
theorem pv5168 : R t5168 t1 := result (f := t5167) (a := t4899) (u := t1) (v := t4899) pv5167 (aw (ri t4899)) pv4899
theorem pv4910 : R t4910 t1 := result (f := t4906) (a := t4909) (u := t5164) (v := t5168) pv4906 (awb t4913 t4899 t4909 t5166 (refl _)) pv5168
theorem pv4907 : R t4907 t1 := result (f := t0) (a := t4906) (u := t0) (v := t4910) (refl t0) (aw (rh t4906)) pv4910
theorem pv4908 : R t4908 t1 := result (f := t4907) (a := t4899) (u := t1) (v := t4899) pv4907 (aw (ri t4899)) pv4899
theorem pv4905 : R t4905 t1 := result (f := t4902) (a := t4904) (u := t4902) (v := t4908) (refl t4902) (awb t0 t4899 t4904 t4906 (refl _)) pv4908
theorem pv4903 : R t4903 t1 := result (f := t0) (a := t4902) (u := t0) (v := t4905) (refl t0) (aw (rh t4902)) pv4905
theorem pv4900 : R t4900 t1 := result (f := t2) (a := t4899) (u := t2) (v := t4903) (refl t2) (aw (ra t0 t4899)) pv4903
theorem pv4901 : R t4901 t1 := result (f := t4900) (a := t4872) (u := t1) (v := t4872) pv4900 (aw (ri t4872)) pv4872
theorem pv4892 : R t4892 t1 := result (f := t4888) (a := t4891) (u := t4875) (v := t4901) pv4888 (awb t2 t4872 t4891 t4899 (refl _)) pv4901
theorem pv4889 : R t4889 t1 := result (f := t0) (a := t4888) (u := t0) (v := t4892) (refl t0) (aw (rh t4888)) pv4892
theorem pv4890 : R t4890 t4875 := result (f := t4889) (a := t4875) (u := t1) (v := t4875) pv4889 (aw (ri t4875)) (refl t4875)
theorem pv4887 : R t4887 t4875 := result (f := t4877) (a := t4886) (u := t4877) (v := t4890) (refl t4877) (awb t0 t4875 t4886 t4888 (refl _)) pv4890
theorem pv4881 : R t4881 t4875 := result (f := t4879) (a := t1) (u := t4879) (v := t4887) (refl t4879) (aw (ra t4877 t1)) pv4887
theorem pv5201 : R t5201 t5200 := result (f := t1) (a := t5200) (u := t1) (v := t5200) (refl t1) (aw (ri t5200)) (refl t5200)
theorem pv5199 : R t5199 t5200 := result (f := t22) (a := t5178) (u := t24) (v := t5201) pv22 (aw (ra t1 t5178)) pv5201
theorem pv5197 : R t5197 t5200 := result (f := t5181) (a := t1) (u := t5181) (v := t5199) (refl t5181) (awb t0 t5178 t1 t1 (cI)) pv5199
theorem pv5228 : R t5228 t5227 := result (f := t1) (a := t5227) (u := t1) (v := t5227) (refl t1) (aw (ri t5227)) (refl t5227)
theorem pv5226 : R t5226 t5227 := result (f := t22) (a := t5205) (u := t24) (v := t5228) pv22 (aw (ra t1 t5205)) pv5228
theorem pv5224 : R t5224 t5227 := result (f := t5208) (a := t1) (u := t5208) (v := t5226) (refl t5208) (awb t0 t5205 t1 t1 (cI)) pv5226
theorem pv5230 : R t5230 t1 := result (f := t4881) (a := t1) (u := t4875) (v := t4953) pv4881 (awb t2 t4872 t1 t1 (cI)) pv4953
theorem pv5231 : R t5231 t1 := result (f := t5230) (a := t1) (u := t1) (v := t1) pv5230 (aw (ri t1)) (refl t1)
theorem pv5205 : R t5205 t1 := result (f := t5203) (a := t1) (u := t5203) (v := t5231) (refl t5203) (awb t4881 t1 t1 t1 (cI)) pv5231
theorem pv5229 : R t5229 t1 := result (f := t28) (a := t5205) (u := t1) (v := t5205) pv28 (aw (ri t5205)) pv5205
theorem pv5225 : R t5225 t1 := result (f := t5224) (a := t1) (u := t5227) (v := t5229) pv5224 (awb t1 t5205 t1 t1 (cI)) pv5229
theorem pv5219 : R t5219 t1 := result (f := t5217) (a := t1) (u := t5217) (v := t5225) (refl t5217) (awb t5208 t1 t1 t1 (cI)) pv5225
theorem pv5223 : R t5223 t5222 := result (f := t5219) (a := t5222) (u := t1) (v := t5222) pv5219 (aw (ri t5222)) (refl t5222)
theorem pv5220 : R t5220 t5222 := result (f := t0) (a := t5219) (u := t0) (v := t5223) (refl t0) (aw (rh t5219)) pv5223
theorem pv5233 : R t5233 t5232 := result (f := t5219) (a := t5232) (u := t1) (v := t5232) pv5219 (aw (ri t5232)) (refl t5232)
theorem pv5221 : R t5221 t5232 := result (f := t5220) (a := t5205) (u := t5222) (v := t5233) pv5220 (aw (ra t5219 t5205)) pv5233
theorem pv5218 : R t5218 t5232 := result (f := t5208) (a := t5217) (u := t5208) (v := t5221) (refl t5208) (awb t0 t5205 t5217 t5219 (refl _)) pv5221
theorem pv5212 : R t5212 t5232 := result (f := t5210) (a := t1) (u := t5210) (v := t5218) (refl t5210) (aw (ra t5208 t1)) pv5218
theorem pv5244 : R t5244 t1 := result (f := t5219) (a := t1) (u := t1) (v := t1) pv5219 (aw (ri t1)) (refl t1)
theorem pv5245 : R t5245 t1 := result (f := t5244) (a := t5205) (u := t1) (v := t5205) pv5244 (aw (ri t5205)) pv5205
theorem pv5242 : R t5242 t1 := result (f := t5212) (a := t1) (u := t5232) (v := t5245) pv5212 (awb t5219 t5205 t1 t1 (cI)) pv5245
theorem pv5243 : R t5243 t1 := result (f := t5242) (a := t1) (u := t1) (v := t1) pv5242 (aw (ri t1)) (refl t1)
theorem pv5239 : R t5239 t1 := result (f := t5237) (a := t1) (u := t5237) (v := t5243) (refl t5237) (awb t5212 t1 t1 t1 (cI)) pv5243
theorem pv5240 : R t5240 t1 := result (f := t5219) (a := t5239) (u := t1) (v := t5239) pv5219 (aw (ri t5239)) pv5239
theorem pv5241 : R t5241 t1 := result (f := t5240) (a := t5205) (u := t1) (v := t5205) pv5240 (aw (ri t5205)) pv5205
theorem pv5238 : R t5238 t1 := result (f := t5212) (a := t5237) (u := t5232) (v := t5241) pv5212 (awb t5219 t5205 t5237 t5239 (refl _)) pv5241
theorem pv5234 : R t5234 t1 := result (f := t5215) (a := t1) (u := t5215) (v := t5238) (refl t5215) (aw (ra t5212 t1)) pv5238
end Blc.H44.Pump
