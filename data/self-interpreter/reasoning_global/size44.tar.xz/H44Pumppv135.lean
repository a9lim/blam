import H44Pumppv134
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9586 : R t9586 t1 := result (f := t9585) (a := t1) (u := t1) (v := t1) pv9585 (aw (ri t1)) (refl t1)
theorem pv9560 : R t9560 t1 := result (f := t9558) (a := t1) (u := t9558) (v := t9586) (refl t9558) (awb t9236 t1 t1 t1 (cI)) pv9586
theorem pv9584 : R t9584 t1 := result (f := t28) (a := t9560) (u := t1) (v := t9560) pv28 (aw (ri t9560)) pv9560
theorem pv9580 : R t9580 t1 := result (f := t9579) (a := t1) (u := t9582) (v := t9584) pv9579 (awb t1 t9560 t1 t1 (cI)) pv9584
theorem pv9574 : R t9574 t1 := result (f := t9572) (a := t1) (u := t9572) (v := t9580) (refl t9572) (awb t9563 t1 t1 t1 (cI)) pv9580
theorem pv9578 : R t9578 t9577 := result (f := t9574) (a := t9577) (u := t1) (v := t9577) pv9574 (aw (ri t9577)) (refl t9577)
theorem pv9575 : R t9575 t9577 := result (f := t0) (a := t9574) (u := t0) (v := t9578) (refl t0) (aw (rh t9574)) pv9578
theorem pv9588 : R t9588 t9587 := result (f := t9574) (a := t9587) (u := t1) (v := t9587) pv9574 (aw (ri t9587)) (refl t9587)
theorem pv9576 : R t9576 t9587 := result (f := t9575) (a := t9560) (u := t9577) (v := t9588) pv9575 (aw (ra t9574 t9560)) pv9588
theorem pv9573 : R t9573 t9587 := result (f := t9563) (a := t9572) (u := t9563) (v := t9576) (refl t9563) (awb t0 t9560 t9572 t9574 (refl _)) pv9576
theorem pv9567 : R t9567 t9587 := result (f := t9565) (a := t1) (u := t9565) (v := t9573) (refl t9565) (aw (ra t9563 t1)) pv9573
theorem pv9599 : R t9599 t1 := result (f := t9574) (a := t1) (u := t1) (v := t1) pv9574 (aw (ri t1)) (refl t1)
theorem pv9600 : R t9600 t1 := result (f := t9599) (a := t9560) (u := t1) (v := t9560) pv9599 (aw (ri t9560)) pv9560
theorem pv9597 : R t9597 t1 := result (f := t9567) (a := t1) (u := t9587) (v := t9600) pv9567 (awb t9574 t9560 t1 t1 (cI)) pv9600
theorem pv9598 : R t9598 t1 := result (f := t9597) (a := t1) (u := t1) (v := t1) pv9597 (aw (ri t1)) (refl t1)
theorem pv9594 : R t9594 t1 := result (f := t9592) (a := t1) (u := t9592) (v := t9598) (refl t9592) (awb t9567 t1 t1 t1 (cI)) pv9598
theorem pv9595 : R t9595 t1 := result (f := t9574) (a := t9594) (u := t1) (v := t9594) pv9574 (aw (ri t9594)) pv9594
theorem pv9596 : R t9596 t1 := result (f := t9595) (a := t9560) (u := t1) (v := t9560) pv9595 (aw (ri t9560)) pv9560
theorem pv9593 : R t9593 t1 := result (f := t9567) (a := t9592) (u := t9587) (v := t9596) pv9567 (awb t9574 t9560 t9592 t9594 (refl _)) pv9596
theorem pv9589 : R t9589 t1 := result (f := t9570) (a := t1) (u := t9570) (v := t9593) (refl t9570) (aw (ra t9567 t1)) pv9593
theorem pv9590 : R t9590 t1 := result (f := t9574) (a := t9589) (u := t1) (v := t9589) pv9574 (aw (ri t9589)) pv9589
theorem pv9591 : R t9591 t1 := result (f := t9590) (a := t9560) (u := t1) (v := t9560) pv9590 (aw (ri t9560)) pv9560
theorem pv9571 : R t9571 t1 := result (f := t9567) (a := t9570) (u := t9587) (v := t9591) pv9567 (awb t9574 t9560 t9570 t9589 (refl _)) pv9591
theorem pv9568 : R t9568 t1 := result (f := t0) (a := t9567) (u := t0) (v := t9571) (refl t0) (aw (rh t9567)) pv9571
theorem pv9569 : R t9569 t1 := result (f := t9568) (a := t9560) (u := t1) (v := t9560) pv9568 (aw (ri t9560)) pv9560
theorem pv9566 : R t9566 t1 := result (f := t9563) (a := t9565) (u := t9563) (v := t9569) (refl t9563) (awb t0 t9560 t9565 t9567 (refl _)) pv9569
theorem pv9564 : R t9564 t1 := result (f := t0) (a := t9563) (u := t0) (v := t9566) (refl t0) (aw (rh t9563)) pv9566
theorem pv9561 : R t9561 t1 := result (f := t2) (a := t9560) (u := t2) (v := t9564) (refl t2) (aw (ra t0 t9560)) pv9564
theorem pv9562 : R t9562 t1 := result (f := t9561) (a := t9227) (u := t1) (v := t9227) pv9561 (aw (ri t9227)) pv9227
theorem pv9559 : R t9559 t1 := result (f := t9236) (a := t9558) (u := t9230) (v := t9562) pv9236 (awb t2 t9227 t9558 t9560 (refl _)) pv9562
theorem pv9533 : R t9533 t1 := result (f := t9239) (a := t1) (u := t9239) (v := t9559) (refl t9239) (aw (ra t9236 t1)) pv9559
theorem pv9557 : R t9557 t1 := result (f := t28) (a := t9533) (u := t1) (v := t9533) pv28 (aw (ri t9533)) pv9533
theorem pv9553 : R t9553 t1 := result (f := t9552) (a := t1) (u := t9555) (v := t9557) pv9552 (awb t1 t9533 t1 t1 (cI)) pv9557
theorem pv9547 : R t9547 t1 := result (f := t9545) (a := t1) (u := t9545) (v := t9553) (refl t9545) (awb t9536 t1 t1 t1 (cI)) pv9553
theorem pv9551 : R t9551 t9550 := result (f := t9547) (a := t9550) (u := t1) (v := t9550) pv9547 (aw (ri t9550)) (refl t9550)
theorem pv9548 : R t9548 t9550 := result (f := t0) (a := t9547) (u := t0) (v := t9551) (refl t0) (aw (rh t9547)) pv9551
theorem pv9602 : R t9602 t9601 := result (f := t9547) (a := t9601) (u := t1) (v := t9601) pv9547 (aw (ri t9601)) (refl t9601)
theorem pv9549 : R t9549 t9601 := result (f := t9548) (a := t9533) (u := t9550) (v := t9602) pv9548 (aw (ra t9547 t9533)) pv9602
theorem pv9546 : R t9546 t9601 := result (f := t9536) (a := t9545) (u := t9536) (v := t9549) (refl t9536) (awb t0 t9533 t9545 t9547 (refl _)) pv9549
theorem pv9540 : R t9540 t9601 := result (f := t9538) (a := t1) (u := t9538) (v := t9546) (refl t9538) (aw (ra t9536 t1)) pv9546
theorem pv9613 : R t9613 t1 := result (f := t9547) (a := t1) (u := t1) (v := t1) pv9547 (aw (ri t1)) (refl t1)
theorem pv9614 : R t9614 t1 := result (f := t9613) (a := t9533) (u := t1) (v := t9533) pv9613 (aw (ri t9533)) pv9533
theorem pv9611 : R t9611 t1 := result (f := t9540) (a := t1) (u := t9601) (v := t9614) pv9540 (awb t9547 t9533 t1 t1 (cI)) pv9614
theorem pv9612 : R t9612 t1 := result (f := t9611) (a := t1) (u := t1) (v := t1) pv9611 (aw (ri t1)) (refl t1)
theorem pv9608 : R t9608 t1 := result (f := t9606) (a := t1) (u := t9606) (v := t9612) (refl t9606) (awb t9540 t1 t1 t1 (cI)) pv9612
theorem pv9609 : R t9609 t1 := result (f := t9547) (a := t9608) (u := t1) (v := t9608) pv9547 (aw (ri t9608)) pv9608
theorem pv9610 : R t9610 t1 := result (f := t9609) (a := t9533) (u := t1) (v := t9533) pv9609 (aw (ri t9533)) pv9533
theorem pv9607 : R t9607 t1 := result (f := t9540) (a := t9606) (u := t9601) (v := t9610) pv9540 (awb t9547 t9533 t9606 t9608 (refl _)) pv9610
theorem pv9603 : R t9603 t1 := result (f := t9543) (a := t1) (u := t9543) (v := t9607) (refl t9543) (aw (ra t9540 t1)) pv9607
theorem pv9604 : R t9604 t1 := result (f := t9547) (a := t9603) (u := t1) (v := t9603) pv9547 (aw (ri t9603)) pv9603
theorem pv9605 : R t9605 t1 := result (f := t9604) (a := t9533) (u := t1) (v := t9533) pv9604 (aw (ri t9533)) pv9533
theorem pv9544 : R t9544 t1 := result (f := t9540) (a := t9543) (u := t9601) (v := t9605) pv9540 (awb t9547 t9533 t9543 t9603 (refl _)) pv9605
theorem pv9541 : R t9541 t1 := result (f := t0) (a := t9540) (u := t0) (v := t9544) (refl t0) (aw (rh t9540)) pv9544
theorem pv9542 : R t9542 t1 := result (f := t9541) (a := t9533) (u := t1) (v := t9533) pv9541 (aw (ri t9533)) pv9533
theorem pv9539 : R t9539 t1 := result (f := t9536) (a := t9538) (u := t9536) (v := t9542) (refl t9536) (awb t0 t9533 t9538 t9540 (refl _)) pv9542
end Blc.H44.Pump
