import H44Pumppv79
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5679 : R t5679 t1 := result (f := t5677) (a := t1) (u := t5677) (v := t5683) (refl t5677) (awb t5654 t1 t1 t1 (cI)) pv5683
theorem pv5680 : R t5680 t1 := result (f := t5661) (a := t5679) (u := t1) (v := t5679) pv5661 (aw (ri t5679)) pv5679
theorem pv5681 : R t5681 t1 := result (f := t5680) (a := t1211) (u := t1) (v := t1211) pv5680 (aw (ri t1211)) pv1211
theorem pv5678 : R t5678 t1 := result (f := t5654) (a := t5677) (u := t5672) (v := t5681) pv5654 (awb t5661 t1211 t5677 t5679 (refl _)) pv5681
theorem pv5674 : R t5674 t1 := result (f := t5657) (a := t1) (u := t5657) (v := t5678) (refl t5657) (aw (ra t5654 t1)) pv5678
theorem pv5675 : R t5675 t1 := result (f := t5661) (a := t5674) (u := t1) (v := t5674) pv5661 (aw (ri t5674)) pv5674
theorem pv5676 : R t5676 t1 := result (f := t5675) (a := t1211) (u := t1) (v := t1211) pv5675 (aw (ri t1211)) pv1211
theorem pv5658 : R t5658 t1 := result (f := t5654) (a := t5657) (u := t5672) (v := t5676) pv5654 (awb t5661 t1211 t5657 t5674 (refl _)) pv5676
theorem pv5655 : R t5655 t1 := result (f := t0) (a := t5654) (u := t0) (v := t5658) (refl t0) (aw (rh t5654)) pv5658
theorem pv5656 : R t5656 t1 := result (f := t5655) (a := t1211) (u := t1) (v := t1211) pv5655 (aw (ri t1211)) pv1211
theorem pv5653 : R t5653 t1 := result (f := t5650) (a := t5652) (u := t5650) (v := t5656) (refl t5650) (awb t0 t1211 t5652 t5654 (refl _)) pv5656
theorem pv5651 : R t5651 t1 := result (f := t0) (a := t5650) (u := t0) (v := t5653) (refl t0) (aw (rh t5650)) pv5653
theorem pv5648 : R t5648 t1 := result (f := t2) (a := t1211) (u := t2) (v := t5651) (refl t2) (aw (ra t0 t1211)) pv5651
theorem pv5649 : R t5649 t149 := result (f := t5648) (a := t149) (u := t1) (v := t149) pv5648 (aw (ri t149)) (refl t149)
theorem pv3937 : R t3937 t149 := result (f := t3936) (a := t149) (u := t151) (v := t5649) pv3936 (awb t2 t149 t149 t1211 (refl _)) pv5649
theorem pv123 : R t123 t149 := result (f := t122) (a := t62) (u := t151) (v := t3937) pv122 (awb t2 t149 t62 t3935 (refl _)) pv3937
theorem pv120 : R t120 t149 := result (f := t83) (a := t119) (u := t70) (v := t123) pv83 (awb t2 t62 t119 t121 (refl _)) pv123
theorem pv94 : R t94 t149 := result (f := t86) (a := t1) (u := t86) (v := t120) (refl t86) (aw (ra t83 t1)) pv120
theorem pv118 : R t118 t149 := result (f := t28) (a := t94) (u := t1) (v := t94) pv28 (aw (ri t94)) pv94
theorem pv114 : R t114 t149 := result (f := t113) (a := t1) (u := t116) (v := t118) pv113 (awb t1 t94 t1 t1 (cI)) pv118
theorem pv108 : R t108 t149 := result (f := t106) (a := t1) (u := t106) (v := t114) (refl t106) (awb t97 t1 t1 t1 (cI)) pv114
theorem pv5711 : R t5711 t5710 := result (f := t1) (a := t5710) (u := t1) (v := t5710) (refl t1) (aw (ri t5710)) (refl t5710)
theorem pv5709 : R t5709 t5710 := result (f := t22) (a := t5689) (u := t24) (v := t5711) pv22 (aw (ra t1 t5689)) pv5711
theorem pv5707 : R t5707 t5710 := result (f := t5691) (a := t1) (u := t5691) (v := t5709) (refl t5691) (awb t0 t5689 t1 t1 (cI)) pv5709
theorem pv5712 : R t5712 t5689 := result (f := t28) (a := t5689) (u := t1) (v := t5689) pv28 (aw (ri t5689)) (refl t5689)
theorem pv5708 : R t5708 t5689 := result (f := t5707) (a := t1) (u := t5710) (v := t5712) pv5707 (awb t1 t5689 t1 t1 (cI)) pv5712
theorem pv5702 : R t5702 t5689 := result (f := t5700) (a := t1) (u := t5700) (v := t5708) (refl t5700) (awb t5691 t1 t1 t1 (cI)) pv5708
theorem pv5736 : R t5736 t5735 := result (f := t1) (a := t5735) (u := t1) (v := t5735) (refl t1) (aw (ri t5735)) (refl t5735)
theorem pv5734 : R t5734 t5735 := result (f := t22) (a := t5713) (u := t24) (v := t5736) pv22 (aw (ra t1 t5713)) pv5736
theorem pv5732 : R t5732 t5735 := result (f := t5716) (a := t1) (u := t5716) (v := t5734) (refl t5716) (awb t0 t5713 t1 t1 (cI)) pv5734
theorem pv5763 : R t5763 t5762 := result (f := t1) (a := t5762) (u := t1) (v := t5762) (refl t1) (aw (ri t5762)) (refl t5762)
theorem pv5761 : R t5761 t5762 := result (f := t22) (a := t5740) (u := t24) (v := t5763) pv22 (aw (ra t1 t5740)) pv5763
theorem pv5759 : R t5759 t5762 := result (f := t5743) (a := t1) (u := t5743) (v := t5761) (refl t5743) (awb t0 t5740 t1 t1 (cI)) pv5761
theorem pv5795 : R t5795 t5794 := result (f := t1) (a := t5794) (u := t1) (v := t5794) (refl t1) (aw (ri t5794)) (refl t5794)
theorem pv5793 : R t5793 t5794 := result (f := t22) (a := t5773) (u := t24) (v := t5795) pv22 (aw (ra t1 t5773)) pv5795
theorem pv5791 : R t5791 t5794 := result (f := t5775) (a := t1) (u := t5775) (v := t5793) (refl t5775) (awb t0 t5773 t1 t1 (cI)) pv5793
theorem pv5796 : R t5796 t5773 := result (f := t28) (a := t5773) (u := t1) (v := t5773) pv28 (aw (ri t5773)) (refl t5773)
theorem pv5792 : R t5792 t5773 := result (f := t5791) (a := t1) (u := t5794) (v := t5796) pv5791 (awb t1 t5773 t1 t1 (cI)) pv5796
theorem pv5786 : R t5786 t5773 := result (f := t5784) (a := t1) (u := t5784) (v := t5792) (refl t5784) (awb t5775 t1 t1 t1 (cI)) pv5792
theorem pv5820 : R t5820 t5819 := result (f := t1) (a := t5819) (u := t1) (v := t5819) (refl t1) (aw (ri t5819)) (refl t5819)
theorem pv5818 : R t5818 t5819 := result (f := t22) (a := t5797) (u := t24) (v := t5820) pv22 (aw (ra t1 t5797)) pv5820
theorem pv5816 : R t5816 t5819 := result (f := t5800) (a := t1) (u := t5800) (v := t5818) (refl t5800) (awb t0 t5797 t1 t1 (cI)) pv5818
theorem pv5847 : R t5847 t5846 := result (f := t1) (a := t5846) (u := t1) (v := t5846) (refl t1) (aw (ri t5846)) (refl t5846)
theorem pv5845 : R t5845 t5846 := result (f := t22) (a := t5824) (u := t24) (v := t5847) pv22 (aw (ra t1 t5824)) pv5847
theorem pv5843 : R t5843 t5846 := result (f := t5827) (a := t1) (u := t5827) (v := t5845) (refl t5827) (awb t0 t5824 t1 t1 (cI)) pv5845
theorem pv5852 : R t5852 t1 := result (f := t108) (a := t1) (u := t149) (v := t231) pv108 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv5853 : R t5853 t1 := result (f := t5852) (a := t1) (u := t1) (v := t1) pv5852 (aw (ri t1)) (refl t1)
theorem pv5770 : R t5770 t1 := result (f := t5768) (a := t1) (u := t5768) (v := t5853) (refl t5768) (awb t108 t1 t1 t1 (cI)) pv5853
theorem pv5851 : R t5851 t1 := result (f := t3) (a := t5770) (u := t1) (v := t5770) pv3 (aw (ri t5770)) pv5770
theorem pv5849 : R t5849 t1 := result (f := t5786) (a := t1) (u := t5773) (v := t5851) pv5786 (awb t2 t5770 t1 t1 (cI)) pv5851
theorem pv5850 : R t5850 t1 := result (f := t5849) (a := t1) (u := t1) (v := t1) pv5849 (aw (ri t1)) (refl t1)
theorem pv5824 : R t5824 t1 := result (f := t5822) (a := t1) (u := t5822) (v := t5850) (refl t5822) (awb t5786 t1 t1 t1 (cI)) pv5850
theorem pv5848 : R t5848 t1 := result (f := t28) (a := t5824) (u := t1) (v := t5824) pv28 (aw (ri t5824)) pv5824
theorem pv5844 : R t5844 t1 := result (f := t5843) (a := t1) (u := t5846) (v := t5848) pv5843 (awb t1 t5824 t1 t1 (cI)) pv5848
theorem pv5838 : R t5838 t1 := result (f := t5836) (a := t1) (u := t5836) (v := t5844) (refl t5836) (awb t5827 t1 t1 t1 (cI)) pv5844
end Blc.H44.Pump
