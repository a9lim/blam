import H44Literals
import H44Lib0
import H44Lib102
namespace Blc.H44
theorem ex_e4838381702254 : ¬ IsSelfInterpreter e4838381702254 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381702254 1 = true)
#print axioms ex_e4838381702254
theorem ex_e4838381703966 : ¬ IsSelfInterpreter e4838381703966 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381703966 1 = true)
#print axioms ex_e4838381703966
theorem ex_e4838381708998 : ¬ IsSelfInterpreter e4838381708998 := Lib102.excluded (by decide : Types.has Lib102.tab Lib102.env e4838381708998 1 = true)
#print axioms ex_e4838381708998
theorem ex_e4838381820014 : ¬ IsSelfInterpreter e4838381820014 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381820014 1 = true)
#print axioms ex_e4838381820014
theorem ex_e4838381820026 : ¬ IsSelfInterpreter e4838381820026 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381820026 1 = true)
#print axioms ex_e4838381820026
theorem ex_e4838381820302 : ¬ IsSelfInterpreter e4838381820302 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4838381820302 1 = true)
#print axioms ex_e4838381820302
end Blc.H44
