"""Reconstruct the Lean predicate, object, rank and finite machine evidence from data."""
import json
from pathlib import Path
import makebatch,makeextra,packgen,packsplit
from wireterms import HERE
def render():
    first=json.loads((HERE/'certs.json').read_text())
    wires=sorted((HERE/'wires.txt').read_text().splitlines())
    assert len(wires)==len(first)==188768 and set(wires)==first.keys()
    for i in range(0,len(wires),160):
        rows=[v for w in wires[i:i+160] for v in makebatch.emit(w,first[w])]
        (HERE/f'Batch{i//160:04}.lean').write_text(makebatch.prefix()+'\n'.join(rows)+'\nend Blc.Floor44\n')
    del first
    extra=sorted((w,r) for w,r in json.loads((HERE/'extra.json').read_text()).items() if r!=['open'])
    for i in range(0,len(extra),22):
        rows=[v for w,r in extra[i:i+22] for v in makeextra.entry(w,r)]
        (HERE/f'More{i//22:03}.lean').write_text(makeextra.HEAD+'\n'.join(rows)+'\nend Blc.Floor44.Additional\n')
    layouts=json.loads((HERE/'machine-layouts.json').read_text())
    charts=json.loads((HERE/'machine-certs.json').read_text())
    for w,(block,split,*classic) in layouts.items():
        kind,row=charts[w]
        if block:
            packgen.render(w,row,'strict' if kind=='reg' else 'safe',block,bool(classic))
            if split:packsplit.split('R'+str(int(w,2)),split)
        else:packgen.emit(w,row,classic=True)
if __name__=='__main__':render()

def small_modules():
    from exactgen import generate
    for w,r in json.loads((HERE/'exact.json').read_text()).items():generate(w,r)
    import altgen
    import csv
    from wireterms import lc,expr
    with (HERE/'helper-manifest.tsv').open() as f:helper=list(csv.DictReader(f,delimiter='\t'))
    indexes={w:i//160 for i,w in enumerate(sorted((HERE/'wires.txt').read_text().splitlines()))}
    rows=sorted({r['literal_file'].removesuffix('.lean') for r in helper})
    batches=sorted({f"Batch{indexes[r['wire']]:04}" for r in helper})
    br=['import '+m for m in rows+batches]+['namespace Blc.Floor44.Help44']
    lits=['import H44Base','namespace Blc.H44','open Term SelfintLowerBound',
          'private def sentinel (t : Term) := (blcCode t).foldl (fun n b => 2*n + if b then 1 else 0) 1']
    for r in helper:
        w=r['wire'];n='e'+str(int(w,2))
        br.extend([f'theorem same_{n} : Blc.H44.{n} = Blc.Floor44.{n} := rfl',f'#print axioms same_{n}',
                   f'theorem ex_{n} : ¬ IsSelfInterpreter Blc.Floor44.{n} := Blc.H44.ex_{n}',f'#print axioms ex_{n}'])
        lits.extend([f'def {n} : Term := {expr(lc.decode(w)[0])}',f'theorem wire_{n} : Closed {n} ∧ sentinel {n} = {int("1"+w,2)} := by decide'])
    for name,ls,end in [('H44Bridge',br,'Blc.Floor44.Help44'),('H44Literals',lits,'Blc.H44')]:
        (HERE/(name+'.lean')).write_text('\n'.join(ls+['end '+end])+'\n')
