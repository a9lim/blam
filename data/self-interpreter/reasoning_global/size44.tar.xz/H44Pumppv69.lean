import H44Pumppv68
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5017 : R t5017 t5040 := result (f := t5015) (a := t1) (u := t5015) (v := t5023) (refl t5015) (aw (ra t5013 t1)) pv5023
theorem pv5052 : R t5052 t1 := result (f := t5024) (a := t1) (u := t1) (v := t1) pv5024 (aw (ri t1)) (refl t1)
theorem pv5053 : R t5053 t1 := result (f := t5052) (a := t5010) (u := t1) (v := t5010) pv5052 (aw (ri t5010)) pv5010
theorem pv5050 : R t5050 t1 := result (f := t5017) (a := t1) (u := t5040) (v := t5053) pv5017 (awb t5024 t5010 t1 t1 (cI)) pv5053
theorem pv5051 : R t5051 t1 := result (f := t5050) (a := t1) (u := t1) (v := t1) pv5050 (aw (ri t1)) (refl t1)
theorem pv5047 : R t5047 t1 := result (f := t5045) (a := t1) (u := t5045) (v := t5051) (refl t5045) (awb t5017 t1 t1 t1 (cI)) pv5051
theorem pv5048 : R t5048 t1 := result (f := t5024) (a := t5047) (u := t1) (v := t5047) pv5024 (aw (ri t5047)) pv5047
theorem pv5049 : R t5049 t1 := result (f := t5048) (a := t5010) (u := t1) (v := t5010) pv5048 (aw (ri t5010)) pv5010
theorem pv5046 : R t5046 t1 := result (f := t5017) (a := t5045) (u := t5040) (v := t5049) pv5017 (awb t5024 t5010 t5045 t5047 (refl _)) pv5049
theorem pv5042 : R t5042 t1 := result (f := t5020) (a := t1) (u := t5020) (v := t5046) (refl t5020) (aw (ra t5017 t1)) pv5046
theorem pv5043 : R t5043 t1 := result (f := t5024) (a := t5042) (u := t1) (v := t5042) pv5024 (aw (ri t5042)) pv5042
theorem pv5044 : R t5044 t1 := result (f := t5043) (a := t5010) (u := t1) (v := t5010) pv5043 (aw (ri t5010)) pv5010
theorem pv5021 : R t5021 t1 := result (f := t5017) (a := t5020) (u := t5040) (v := t5044) pv5017 (awb t5024 t5010 t5020 t5042 (refl _)) pv5044
theorem pv5018 : R t5018 t1 := result (f := t0) (a := t5017) (u := t0) (v := t5021) (refl t0) (aw (rh t5017)) pv5021
theorem pv5019 : R t5019 t1 := result (f := t5018) (a := t5010) (u := t1) (v := t5010) pv5018 (aw (ri t5010)) pv5010
theorem pv5016 : R t5016 t1 := result (f := t5013) (a := t5015) (u := t5013) (v := t5019) (refl t5013) (awb t0 t5010 t5015 t5017 (refl _)) pv5019
theorem pv5014 : R t5014 t1 := result (f := t0) (a := t5013) (u := t0) (v := t5016) (refl t0) (aw (rh t5013)) pv5016
theorem pv5011 : R t5011 t1 := result (f := t2) (a := t5010) (u := t2) (v := t5014) (refl t2) (aw (ra t0 t5010)) pv5014
theorem pv5012 : R t5012 t1 := result (f := t5011) (a := t4956) (u := t1) (v := t4956) pv5011 (aw (ri t4956)) pv4956
theorem pv5009 : R t5009 t1 := result (f := t4972) (a := t5008) (u := t4959) (v := t5012) pv4972 (awb t2 t4956 t5008 t5010 (refl _)) pv5012
theorem pv4983 : R t4983 t1 := result (f := t4975) (a := t1) (u := t4975) (v := t5009) (refl t4975) (aw (ra t4972 t1)) pv5009
theorem pv5007 : R t5007 t1 := result (f := t28) (a := t4983) (u := t1) (v := t4983) pv28 (aw (ri t4983)) pv4983
theorem pv5003 : R t5003 t1 := result (f := t5002) (a := t1) (u := t5005) (v := t5007) pv5002 (awb t1 t4983 t1 t1 (cI)) pv5007
theorem pv4997 : R t4997 t1 := result (f := t4995) (a := t1) (u := t4995) (v := t5003) (refl t4995) (awb t4986 t1 t1 t1 (cI)) pv5003
theorem pv5001 : R t5001 t5000 := result (f := t4997) (a := t5000) (u := t1) (v := t5000) pv4997 (aw (ri t5000)) (refl t5000)
theorem pv4998 : R t4998 t5000 := result (f := t0) (a := t4997) (u := t0) (v := t5001) (refl t0) (aw (rh t4997)) pv5001
theorem pv5055 : R t5055 t5054 := result (f := t4997) (a := t5054) (u := t1) (v := t5054) pv4997 (aw (ri t5054)) (refl t5054)
theorem pv4999 : R t4999 t5054 := result (f := t4998) (a := t4983) (u := t5000) (v := t5055) pv4998 (aw (ra t4997 t4983)) pv5055
theorem pv4996 : R t4996 t5054 := result (f := t4986) (a := t4995) (u := t4986) (v := t4999) (refl t4986) (awb t0 t4983 t4995 t4997 (refl _)) pv4999
theorem pv4990 : R t4990 t5054 := result (f := t4988) (a := t1) (u := t4988) (v := t4996) (refl t4988) (aw (ra t4986 t1)) pv4996
theorem pv5066 : R t5066 t1 := result (f := t4997) (a := t1) (u := t1) (v := t1) pv4997 (aw (ri t1)) (refl t1)
theorem pv5067 : R t5067 t1 := result (f := t5066) (a := t4983) (u := t1) (v := t4983) pv5066 (aw (ri t4983)) pv4983
theorem pv5064 : R t5064 t1 := result (f := t4990) (a := t1) (u := t5054) (v := t5067) pv4990 (awb t4997 t4983 t1 t1 (cI)) pv5067
theorem pv5065 : R t5065 t1 := result (f := t5064) (a := t1) (u := t1) (v := t1) pv5064 (aw (ri t1)) (refl t1)
theorem pv5061 : R t5061 t1 := result (f := t5059) (a := t1) (u := t5059) (v := t5065) (refl t5059) (awb t4990 t1 t1 t1 (cI)) pv5065
theorem pv5062 : R t5062 t1 := result (f := t4997) (a := t5061) (u := t1) (v := t5061) pv4997 (aw (ri t5061)) pv5061
theorem pv5063 : R t5063 t1 := result (f := t5062) (a := t4983) (u := t1) (v := t4983) pv5062 (aw (ri t4983)) pv4983
theorem pv5060 : R t5060 t1 := result (f := t4990) (a := t5059) (u := t5054) (v := t5063) pv4990 (awb t4997 t4983 t5059 t5061 (refl _)) pv5063
theorem pv5056 : R t5056 t1 := result (f := t4993) (a := t1) (u := t4993) (v := t5060) (refl t4993) (aw (ra t4990 t1)) pv5060
theorem pv5057 : R t5057 t1 := result (f := t4997) (a := t5056) (u := t1) (v := t5056) pv4997 (aw (ri t5056)) pv5056
theorem pv5058 : R t5058 t1 := result (f := t5057) (a := t4983) (u := t1) (v := t4983) pv5057 (aw (ri t4983)) pv4983
theorem pv4994 : R t4994 t1 := result (f := t4990) (a := t4993) (u := t5054) (v := t5058) pv4990 (awb t4997 t4983 t4993 t5056 (refl _)) pv5058
theorem pv4991 : R t4991 t1 := result (f := t0) (a := t4990) (u := t0) (v := t4994) (refl t0) (aw (rh t4990)) pv4994
theorem pv4992 : R t4992 t1 := result (f := t4991) (a := t4983) (u := t1) (v := t4983) pv4991 (aw (ri t4983)) pv4983
theorem pv4989 : R t4989 t1 := result (f := t4986) (a := t4988) (u := t4986) (v := t4992) (refl t4986) (awb t0 t4983 t4988 t4990 (refl _)) pv4992
theorem pv4987 : R t4987 t1 := result (f := t0) (a := t4986) (u := t0) (v := t4989) (refl t0) (aw (rh t4986)) pv4989
theorem pv4984 : R t4984 t1 := result (f := t2) (a := t4983) (u := t2) (v := t4987) (refl t2) (aw (ra t0 t4983)) pv4987
theorem pv4985 : R t4985 t1 := result (f := t4984) (a := t4956) (u := t1) (v := t4956) pv4984 (aw (ri t4956)) pv4956
theorem pv4976 : R t4976 t1 := result (f := t4972) (a := t4975) (u := t4959) (v := t4985) pv4972 (awb t2 t4956 t4975 t4983 (refl _)) pv4985
theorem pv4973 : R t4973 t1 := result (f := t0) (a := t4972) (u := t0) (v := t4976) (refl t0) (aw (rh t4972)) pv4976
theorem pv4974 : R t4974 t4959 := result (f := t4973) (a := t4959) (u := t1) (v := t4959) pv4973 (aw (ri t4959)) (refl t4959)
theorem pv4971 : R t4971 t4959 := result (f := t4961) (a := t4970) (u := t4961) (v := t4974) (refl t4961) (awb t0 t4959 t4970 t4972 (refl _)) pv4974
theorem pv4965 : R t4965 t4959 := result (f := t4963) (a := t1) (u := t4963) (v := t4971) (refl t4963) (aw (ra t4961 t1)) pv4971
theorem pv5091 : R t5091 t5090 := result (f := t1) (a := t5090) (u := t1) (v := t5090) (refl t1) (aw (ri t5090)) (refl t5090)
theorem pv5089 : R t5089 t5090 := result (f := t22) (a := t5068) (u := t24) (v := t5091) pv22 (aw (ra t1 t5068)) pv5091
end Blc.H44.Pump
