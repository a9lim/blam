from reggen import *
def vec(xs):
    w=max(xs,default=0).bit_length() or 1
    n=sum(x<<(i*w) for i,x in enumerate(xs))
    return f'⟨{w},0x{n:x}⟩'
def rows(rs):
    offsets=[];vs=[]
    for r in rs:
        offsets.append(len(vs));vs.extend(r)
    return f'⟨{vec(offsets)},{vec([len(r) for r in rs])},{vec(vs)}⟩'
def packed(c):
    states=[(p,tuple(e),sp) for p,e,sp in c['states']]
    envs=[()];ids={():0};cls=[];clids={};frs=[];frids={}
    def intern(v,ls,mp):
        if v not in mp:mp[v]=len(ls);ls.append(v)
        return mp[v]
    def env(e):return intern(tuple(e),envs,ids)
    def cl(c):return intern((c[0],env(c[1])),cls,clids)
    def fr(v):return intern((cl(v[0]),v[1]),frs,frids)
    vals=[[cl(a) for a in v] for v in c['values']]
    ks=[[fr(a) for a in v] for v in c['konts']]
    se=[env(e) for _,e,_ in states]
    vs=[vec([t[0] for t in states]),vec(se),vec([t[2] for t in states]),rows(envs),vec([p for p,_ in cls]),vec([e for _,e in cls]),vec([v for v,_ in frs]),vec([k for _,k in frs]),rows(vals),rows(ks),rows(c['hints'])]
    return 'def d : Packed.Data := ⟨'+','.join(vs)+'⟩'
def render(s,row,mode='strict',bsize=24,classic=False):
    c=emit(s,row,classic=classic);path=HERE/('R'+str(int(s,2))+'.lean')
    src=path.read_text();n=len(c['states'])
    before=src[:src.index('def values :')].replace('import Reg','import Packed')
    after=src[src.index('open Blc Blc.Term'):]
    pre,proof=after.split('theorem excluded :',1)
    pre=pre.replace('def model : Model P', 'def P (i : Nat) := code[i]?.getD .opaque\ndef model : Model P')
    sv=f'Packed.valid d P {n}';fn='Packed.excludes'
    if mode=='safe':
        before=before.replace('import Packed','import SafePacked')
        sv=f'SafePacked.valid d P {n}';fn='SafePacked.excludes'
        kind=row[1];cont,m,r,aa,k=dt(kind);q=appall(A(A(cont,L(m)),r),aa)
        for _ in range(k):q=red(q,head_path(q))
        assert spine(q)[0]==0 and spine(q)[1][0]=='V'
        proof=proof.replace('  exact regular_no_clock model closed root n h',f'  have hj := Blc.Floor44.Safe.probe he (by decide) (tgt := {expr(q)}) (k := {k}) (by decide) hp\n  exact {fn} d model {n} (by decide) allok (by decide) (by repeat constructor) hj n h')
    else:
        proof=proof.replace('regular_no_clock model closed root n h',f'{fn} d model {n} (by decide) allok (by decide) n h')
    blocks=[]
    for i in range(0,n,bsize):
        blocks.append(f'theorem ok{i} : Certgen.FloorIndex.rangeOK ({sv}) {i} {min(n-i,bsize)} = true := by decide +kernel')
    def split(js,depth):
        if len(js)==1:return f'exact Certgen.FloorIndex.rangeOK_at ok{js[0]} (by omega) (by omega)'
        k=len(js)//2;b=js[k];pad=' '*depth
        return f'by_cases h{b} : i<{b}\n{pad}· {split(js[:k],depth+2)}\n{pad}· {split(js[k:],depth+2)}'
    blocks.append(f'theorem allok (i : Nat) (h : i<{n}) : {sv} i = true := by\n '+split(list(range(0,n,bsize)),1))
    path.write_text(before+pre+packed(c)+'\n'+'\n'.join(blocks)+'\ntheorem excluded :'+proof)
if __name__=='__main__':
    import sys
    for p in sorted((HERE/'reg').glob('*.json')):
        s=p.stem
        if (HERE/'obj'/('R'+str(int(s,2))+'.olean')).exists():continue
        r=json.loads(p.read_text())
        if int(sys.argv[1])<=r[0]<int(sys.argv[2]):render(s,r)
