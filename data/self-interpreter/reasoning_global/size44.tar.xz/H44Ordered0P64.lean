import H44Ordered0P32
namespace Blc.H44Chain
open Term SelfintControl SelfintLowerBound ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
theorem oh0_64 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 2) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_48 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 2 2 = 3)
theorem oh0_65 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 2) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_50 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 2 2 = 3)
theorem oh0_66 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 2) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_52 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_67 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 2) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_54 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_68 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_64 (push 0 ρ) rfl a0 a1)
    · exact (oh0_65 (push 1 ρ) rfl a0 a1)
    · exact (oh0_66 (push 2 ρ) rfl a0 a1)
    · exact (oh0_67 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_69 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_23 ρ a1) (oh0_68 ρ a0 a1) (by decide : opm0 1 3 = 3)
theorem oh0_70 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 3) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_48 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 2 3 = 3)
theorem oh0_71 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 3) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_50 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 2 3 = 3)
theorem oh0_72 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 3) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_52 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_73 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 3) (a2 : ρ 2 = 1) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_54 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_74 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_70 (push 0 ρ) rfl a0 a1)
    · exact (oh0_71 (push 1 ρ) rfl a0 a1)
    · exact (oh0_72 (push 2 ρ) rfl a0 a1)
    · exact (oh0_73 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_75 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_23 ρ a1) (oh0_74 ρ a0 a1) (by decide : opm0 1 3 = 3)
theorem oh0_76 (ρ : Env 3) (a0 : ρ 0 = 1) : eval gm0 ρ ob0_11 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_10) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_10) = (fun a : Fin 4 => if a = 0 then 2 else if a = 1 then 2 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_57 (push 0 ρ) rfl a0)
    · exact (oh0_63 (push 1 ρ) rfl a0)
    · exact (oh0_69 (push 2 ρ) rfl a0)
    · exact (oh0_75 (push 3 ρ) rfl a0)
  rw [h]
  decide
theorem oh0_77 (ρ : Env 3) (a0 : ρ 0 = 1) : eval gm0 ρ ob0_12 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_11) (oh0_2 ρ a0) (oh0_76 ρ a0) (by decide : opm0 1 1 = 2)
theorem oh0_78 (ρ : Env 3) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_4 = 2 := by
  exact a2
theorem oh0_79 (ρ : Env 3) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_6 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_4) (a := ob0_5) (oh0_78 ρ a2) (oh0_11 ρ) (by decide : opm0 2 1 = 2)
theorem oh0_80 (ρ : Env 3) (a0 : ρ 0 = 0) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_7 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_79 ρ a2) (oh0_0 ρ a0) (by decide : opm0 2 0 = 2)
theorem oh0_81 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 0) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_80 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 2 0 = 2)
theorem oh0_82 (ρ : Env 3) (a0 : ρ 0 = 1) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_7 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_79 ρ a2) (oh0_2 ρ a0) (by decide : opm0 2 1 = 2)
theorem oh0_83 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 0) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_82 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 2 0 = 2)
theorem oh0_84 (ρ : Env 3) (a0 : ρ 0 = 2) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_79 ρ a2) (oh0_4 ρ a0) (by decide : opm0 2 2 = 3)
theorem oh0_85 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 0) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_84 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_86 (ρ : Env 3) (a0 : ρ 0 = 3) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_79 ρ a2) (oh0_6 ρ a0) (by decide : opm0 2 3 = 3)
theorem oh0_87 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 0) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_86 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_88 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_9 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 2 else if a = 1 then 2 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_81 (push 0 ρ) rfl a0 a1)
    · exact (oh0_83 (push 1 ρ) rfl a0 a1)
    · exact (oh0_85 (push 2 ρ) rfl a0 a1)
    · exact (oh0_87 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_89 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_10 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_30 ρ a1) (oh0_88 ρ a0 a1) (by decide : opm0 2 1 = 2)
theorem oh0_90 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 1) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_80 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 2 1 = 2)
theorem oh0_91 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 1) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_82 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 2 1 = 2)
theorem oh0_92 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 1) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_84 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_93 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 1) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_86 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_94 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_9 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 2 else if a = 1 then 2 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_90 (push 0 ρ) rfl a0 a1)
    · exact (oh0_91 (push 1 ρ) rfl a0 a1)
    · exact (oh0_92 (push 2 ρ) rfl a0 a1)
    · exact (oh0_93 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_95 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_10 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_30 ρ a1) (oh0_94 ρ a0 a1) (by decide : opm0 2 1 = 2)
end Blc.H44Chain
