import H44Pumppv25
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2008 : R t2008 t1 := result (f := t2004) (a := t2007) (u := t2027) (v := t2031) pv2004 (awb t2011 t1997 t2007 t2029 (refl _)) pv2031
theorem pv2005 : R t2005 t1 := result (f := t0) (a := t2004) (u := t0) (v := t2008) (refl t0) (aw (rh t2004)) pv2008
theorem pv2006 : R t2006 t1 := result (f := t2005) (a := t1997) (u := t1) (v := t1997) pv2005 (aw (ri t1997)) pv1997
theorem pv2003 : R t2003 t1 := result (f := t2000) (a := t2002) (u := t2000) (v := t2006) (refl t2000) (awb t0 t1997 t2002 t2004 (refl _)) pv2006
theorem pv2001 : R t2001 t1 := result (f := t0) (a := t2000) (u := t0) (v := t2003) (refl t0) (aw (rh t2000)) pv2003
theorem pv1998 : R t1998 t1 := result (f := t2) (a := t1997) (u := t2) (v := t2001) (refl t2) (aw (ra t0 t1997)) pv2001
theorem pv1999 : R t1999 t1 := result (f := t1998) (a := t1943) (u := t1) (v := t1943) pv1998 (aw (ri t1943)) pv1943
theorem pv1996 : R t1996 t1 := result (f := t1959) (a := t1995) (u := t1946) (v := t1999) pv1959 (awb t2 t1943 t1995 t1997 (refl _)) pv1999
theorem pv1970 : R t1970 t1 := result (f := t1962) (a := t1) (u := t1962) (v := t1996) (refl t1962) (aw (ra t1959 t1)) pv1996
theorem pv1994 : R t1994 t1 := result (f := t28) (a := t1970) (u := t1) (v := t1970) pv28 (aw (ri t1970)) pv1970
theorem pv1990 : R t1990 t1 := result (f := t1989) (a := t1) (u := t1992) (v := t1994) pv1989 (awb t1 t1970 t1 t1 (cI)) pv1994
theorem pv1984 : R t1984 t1 := result (f := t1982) (a := t1) (u := t1982) (v := t1990) (refl t1982) (awb t1973 t1 t1 t1 (cI)) pv1990
theorem pv1988 : R t1988 t1987 := result (f := t1984) (a := t1987) (u := t1) (v := t1987) pv1984 (aw (ri t1987)) (refl t1987)
theorem pv1985 : R t1985 t1987 := result (f := t0) (a := t1984) (u := t0) (v := t1988) (refl t0) (aw (rh t1984)) pv1988
theorem pv2042 : R t2042 t2041 := result (f := t1984) (a := t2041) (u := t1) (v := t2041) pv1984 (aw (ri t2041)) (refl t2041)
theorem pv1986 : R t1986 t2041 := result (f := t1985) (a := t1970) (u := t1987) (v := t2042) pv1985 (aw (ra t1984 t1970)) pv2042
theorem pv1983 : R t1983 t2041 := result (f := t1973) (a := t1982) (u := t1973) (v := t1986) (refl t1973) (awb t0 t1970 t1982 t1984 (refl _)) pv1986
theorem pv1977 : R t1977 t2041 := result (f := t1975) (a := t1) (u := t1975) (v := t1983) (refl t1975) (aw (ra t1973 t1)) pv1983
theorem pv2053 : R t2053 t1 := result (f := t1984) (a := t1) (u := t1) (v := t1) pv1984 (aw (ri t1)) (refl t1)
theorem pv2054 : R t2054 t1 := result (f := t2053) (a := t1970) (u := t1) (v := t1970) pv2053 (aw (ri t1970)) pv1970
theorem pv2051 : R t2051 t1 := result (f := t1977) (a := t1) (u := t2041) (v := t2054) pv1977 (awb t1984 t1970 t1 t1 (cI)) pv2054
theorem pv2052 : R t2052 t1 := result (f := t2051) (a := t1) (u := t1) (v := t1) pv2051 (aw (ri t1)) (refl t1)
theorem pv2048 : R t2048 t1 := result (f := t2046) (a := t1) (u := t2046) (v := t2052) (refl t2046) (awb t1977 t1 t1 t1 (cI)) pv2052
theorem pv2049 : R t2049 t1 := result (f := t1984) (a := t2048) (u := t1) (v := t2048) pv1984 (aw (ri t2048)) pv2048
theorem pv2050 : R t2050 t1 := result (f := t2049) (a := t1970) (u := t1) (v := t1970) pv2049 (aw (ri t1970)) pv1970
theorem pv2047 : R t2047 t1 := result (f := t1977) (a := t2046) (u := t2041) (v := t2050) pv1977 (awb t1984 t1970 t2046 t2048 (refl _)) pv2050
theorem pv2043 : R t2043 t1 := result (f := t1980) (a := t1) (u := t1980) (v := t2047) (refl t1980) (aw (ra t1977 t1)) pv2047
theorem pv2044 : R t2044 t1 := result (f := t1984) (a := t2043) (u := t1) (v := t2043) pv1984 (aw (ri t2043)) pv2043
theorem pv2045 : R t2045 t1 := result (f := t2044) (a := t1970) (u := t1) (v := t1970) pv2044 (aw (ri t1970)) pv1970
theorem pv1981 : R t1981 t1 := result (f := t1977) (a := t1980) (u := t2041) (v := t2045) pv1977 (awb t1984 t1970 t1980 t2043 (refl _)) pv2045
theorem pv1978 : R t1978 t1 := result (f := t0) (a := t1977) (u := t0) (v := t1981) (refl t0) (aw (rh t1977)) pv1981
theorem pv1979 : R t1979 t1 := result (f := t1978) (a := t1970) (u := t1) (v := t1970) pv1978 (aw (ri t1970)) pv1970
theorem pv1976 : R t1976 t1 := result (f := t1973) (a := t1975) (u := t1973) (v := t1979) (refl t1973) (awb t0 t1970 t1975 t1977 (refl _)) pv1979
theorem pv1974 : R t1974 t1 := result (f := t0) (a := t1973) (u := t0) (v := t1976) (refl t0) (aw (rh t1973)) pv1976
theorem pv1971 : R t1971 t1 := result (f := t2) (a := t1970) (u := t2) (v := t1974) (refl t2) (aw (ra t0 t1970)) pv1974
theorem pv1972 : R t1972 t1 := result (f := t1971) (a := t1943) (u := t1) (v := t1943) pv1971 (aw (ri t1943)) pv1943
theorem pv1963 : R t1963 t1 := result (f := t1959) (a := t1962) (u := t1946) (v := t1972) pv1959 (awb t2 t1943 t1962 t1970 (refl _)) pv1972
theorem pv1960 : R t1960 t1 := result (f := t0) (a := t1959) (u := t0) (v := t1963) (refl t0) (aw (rh t1959)) pv1963
theorem pv1961 : R t1961 t1946 := result (f := t1960) (a := t1946) (u := t1) (v := t1946) pv1960 (aw (ri t1946)) (refl t1946)
theorem pv1958 : R t1958 t1946 := result (f := t1948) (a := t1957) (u := t1948) (v := t1961) (refl t1948) (awb t0 t1946 t1957 t1959 (refl _)) pv1961
theorem pv1952 : R t1952 t1946 := result (f := t1950) (a := t1) (u := t1950) (v := t1958) (refl t1950) (aw (ra t1948 t1)) pv1958
theorem pv2078 : R t2078 t2077 := result (f := t1) (a := t2077) (u := t1) (v := t2077) (refl t1) (aw (ri t2077)) (refl t2077)
theorem pv2076 : R t2076 t2077 := result (f := t22) (a := t2055) (u := t24) (v := t2078) pv22 (aw (ra t1 t2055)) pv2078
theorem pv2074 : R t2074 t2077 := result (f := t2058) (a := t1) (u := t2058) (v := t2076) (refl t2058) (awb t0 t2055 t1 t1 (cI)) pv2076
theorem pv2105 : R t2105 t2104 := result (f := t1) (a := t2104) (u := t1) (v := t2104) (refl t1) (aw (ri t2104)) (refl t2104)
theorem pv2103 : R t2103 t2104 := result (f := t22) (a := t2082) (u := t24) (v := t2105) pv22 (aw (ra t1 t2082)) pv2105
theorem pv2101 : R t2101 t2104 := result (f := t2085) (a := t1) (u := t2085) (v := t2103) (refl t2085) (awb t0 t2082 t1 t1 (cI)) pv2103
theorem pv2107 : R t2107 t1 := result (f := t1952) (a := t1) (u := t1946) (v := t2024) pv1952 (awb t2 t1943 t1 t1 (cI)) pv2024
theorem pv2108 : R t2108 t1 := result (f := t2107) (a := t1) (u := t1) (v := t1) pv2107 (aw (ri t1)) (refl t1)
theorem pv2082 : R t2082 t1 := result (f := t2080) (a := t1) (u := t2080) (v := t2108) (refl t2080) (awb t1952 t1 t1 t1 (cI)) pv2108
theorem pv2106 : R t2106 t1 := result (f := t28) (a := t2082) (u := t1) (v := t2082) pv28 (aw (ri t2082)) pv2082
theorem pv2102 : R t2102 t1 := result (f := t2101) (a := t1) (u := t2104) (v := t2106) pv2101 (awb t1 t2082 t1 t1 (cI)) pv2106
theorem pv2096 : R t2096 t1 := result (f := t2094) (a := t1) (u := t2094) (v := t2102) (refl t2094) (awb t2085 t1 t1 t1 (cI)) pv2102
theorem pv2100 : R t2100 t2099 := result (f := t2096) (a := t2099) (u := t1) (v := t2099) pv2096 (aw (ri t2099)) (refl t2099)
theorem pv2097 : R t2097 t2099 := result (f := t0) (a := t2096) (u := t0) (v := t2100) (refl t0) (aw (rh t2096)) pv2100
end Blc.H44.Pump
