"""Compile the entire local import graph into empty objects and audit the kernel's reported axioms."""
import concurrent.futures as futures
import csv,ctypes,heapq,json,os,re,subprocess,sys,tempfile,time
from collections import defaultdict,deque
from pathlib import Path
BASE=Path(__file__).resolve().parent
REPO=next(p for p in BASE.parents if (p/'lean/lean-toolchain').is_file())
PREFIX=Path.home()/'.elan/toolchains'/(REPO/'lean/lean-toolchain').read_text().strip().replace('/','--').replace(':','---')
LIB=REPO/'lean/.lake/build/lib/lean'
ALLOW={'propext','Classical.choice','Quot.sound'}
RAM=985_000_000
PROC=ctypes.CDLL('/usr/lib/libproc.dylib') if sys.platform=='darwin' else None
def rss(pid,buf):
    if PROC:
        return ctypes.c_uint64.from_buffer(buf,8).value if PROC.proc_pidinfo(pid,4,0,buf,len(buf))>=16 else 0
    try:return int(Path(f'/proc/{pid}/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    except FileNotFoundError:return 0
def ledger():
    for l in (BASE/'ledger.json').open():
        if l.strip() not in ('[',']'):yield json.loads(l.strip().removesuffix(','))
def graph():
    deps={};local={p.stem for p in BASE.glob('*.lean')}
    def visit(m):
        if m in deps:return
        s=(BASE/(m+'.lean')).read_text()
        assert not re.search(r'^\s*(?:private\s+)?axiom\s|\b(?:sorryAx|native_decide|admit)\b|:=\s*(?:by\s+)?sorry\b|^\s*sorry\s*$',s,re.M),m
        ds=set(re.findall(r'^import ([\w.]+)',s,re.M))
        deps[m]=ds&local
        for d in sorted(deps[m]):visit(d)
    for m in sorted({r['module'] for r in ledger()}|{'Residuals'}):visit(m)
    return deps
def compile_module(m,out,lonely):
    env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[out,LIB,PREFIX/'lib/lean'])),LEAN_NUM_THREADS='2')
    args=[PREFIX/'bin/lean','-j2','-M','900','--root='+str(BASE),BASE/(m+'.lean'),'-o',out/(m+'.olean')]
    start=time.monotonic();limit=450 if lonely else 180;guard=None
    with (out/(m+'.log')).open('w') as log:
        p=subprocess.Popen(args,cwd=out,env=env,stdout=log,stderr=log)
        buf=ctypes.create_string_buffer(128)
        while True:
            pid,status,usage=os.wait4(p.pid,os.WNOHANG)
            if pid:break
            if guard is None:
                if rss(p.pid,buf)>RAM:guard='RSS'
                elif time.monotonic()-start>limit:guard='time'
                if guard:p.kill()
            time.sleep(.035)
        p.returncode=os.waitstatus_to_exitcode(status)
    return dict(module=m,code=p.returncode,guard=guard,alone=lonely,seconds=round(time.monotonic()-start,3),
        rss_bytes=usage.ru_maxrss*(1 if sys.platform=='darwin' else 1024))
def check():
    start=time.monotonic();g=graph();back=defaultdict(list)
    pending={m:len(ds) for m,ds in g.items()}
    for m,ds in g.items():
        for d in ds:back[d].append(m)
    # Make shared dependencies ready first; limit resident children to four.
    ready=[(-len(back[m]),m) for m,v in pending.items() if not v];heapq.heapify(ready)
    retry=deque();active={};done=0;metrics=[]
    with tempfile.TemporaryDirectory(prefix='checked-',dir=BASE) as path, futures.ThreadPoolExecutor(max_workers=4) as pool:
        out=Path(path)
        with (BASE/'check-progress.log').open('w',buffering=1) as prog:
            while ready or retry or active:
                if retry and not active:
                    m=retry.popleft();active[pool.submit(compile_module,m,out,True)]=(m,True)
                elif not retry and not any(alone for _,alone in active.values()):
                    while len(active)<4 and ready:
                        _,m=heapq.heappop(ready);active[pool.submit(compile_module,m,out,False)]=(m,False)
                finished,_=futures.wait(active,return_when=futures.FIRST_COMPLETED)
                for job in finished:
                    m,alone=active.pop(job);r=job.result();metrics.append(r)
                    if r['code']:
                        log=(out/(m+'.log')).read_text()
                        if not alone:
                            retry.append(m);print('retrying alone',r,file=prog)
                            if 'object file' in log and 'does not exist' in log:time.sleep(60)
                            continue
                        print('failed',r,log[-3000:],flush=True);raise RuntimeError(m)
                    done+=1
                    if done%200==0:print(done,'/',len(g),round(time.monotonic()-start),file=prog)
                    for d in back[m]:
                        pending[d]-=1
                        if pending[d]==0:heapq.heappush(ready,(-len(back[d]),d))
        assert done==len(g)
        ax={}
        for m in g:
            s=(out/(m+'.log')).read_text()
            assert not re.search(r"declaration uses 'sorry'|: error:",s),m
            for th,ls in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",s):
                assert set(ls.split(', '))<=ALLOW,(th,ls)
                if th in ax:assert ax[th]==ls
                ax[th]=ls
            for th in re.findall(r"'([^']+)' does not depend on any axioms",s):ax[th]=''
        with (BASE/'complete.tsv').open() as f:complete=list(csv.DictReader(f,delimiter='\t'))
        for r in complete:assert ax.get(r['theorem'])==r['axioms'],(r,ax.get(r['theorem']))
        with (BASE/'helper-manifest.tsv').open() as f:
            for r in csv.DictReader(f,delimiter='\t'):
                assert ax[r['identity']]=='' and ax[r['literal_theorem']]==r['axioms']
        assert set(ax['Blc.Floor44.residuals_excluded'].split(', '))<=ALLOW
        assert {r['theorem'] for r in complete}=={r['theorem'] for r in ledger() if r['strength']=='complete'}
    peak=max(metrics,key=lambda r:r['rss_bytes'])
    result=dict(modules=done,attempts=len(metrics),complete_axioms=len(complete),seconds=round(time.monotonic()-start,3),
        peak_rss_bytes=peak['rss_bytes'],peak_module=peak['module'],max_child_seconds=max(r['seconds'] for r in metrics),
        retries=[r for r in metrics if r['code']],residual_axioms=ax['Blc.Floor44.residuals_excluded'])
    (BASE/'check-metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    print(f"{done} modules, {len(complete)} complete axiom reports, 75 definitional bridges and the collected theorem checked.")
    print(json.dumps(result))
if __name__=='__main__':check()
