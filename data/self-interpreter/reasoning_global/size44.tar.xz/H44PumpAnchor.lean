import H44Pumppa0
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem anchor : R (.ap (.a .h) .i) .i := pa3
end Blc.H44.Pump
