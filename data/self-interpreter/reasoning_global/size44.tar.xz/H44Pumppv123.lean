import H44Pumppv122
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv8752 : R t8752 t1 := result (f := t8751) (a := t8478) (u := t1) (v := t8478) pv8751 (aw (ri t8478)) pv8478
theorem pv8749 : R t8749 t1 := result (f := t8485) (a := t8748) (u := t8743) (v := t8752) pv8485 (awb t8492 t8478 t8748 t8750 (refl _)) pv8752
theorem pv8745 : R t8745 t1 := result (f := t8488) (a := t1) (u := t8488) (v := t8749) (refl t8488) (aw (ra t8485 t1)) pv8749
theorem pv8746 : R t8746 t1 := result (f := t8492) (a := t8745) (u := t1) (v := t8745) pv8492 (aw (ri t8745)) pv8745
theorem pv8747 : R t8747 t1 := result (f := t8746) (a := t8478) (u := t1) (v := t8478) pv8746 (aw (ri t8478)) pv8478
theorem pv8489 : R t8489 t1 := result (f := t8485) (a := t8488) (u := t8743) (v := t8747) pv8485 (awb t8492 t8478 t8488 t8745 (refl _)) pv8747
theorem pv8486 : R t8486 t1 := result (f := t0) (a := t8485) (u := t0) (v := t8489) (refl t0) (aw (rh t8485)) pv8489
theorem pv8487 : R t8487 t1 := result (f := t8486) (a := t8478) (u := t1) (v := t8478) pv8486 (aw (ri t8478)) pv8478
theorem pv8484 : R t8484 t1 := result (f := t8481) (a := t8483) (u := t8481) (v := t8487) (refl t8481) (awb t0 t8478 t8483 t8485 (refl _)) pv8487
theorem pv8482 : R t8482 t1 := result (f := t0) (a := t8481) (u := t0) (v := t8484) (refl t0) (aw (rh t8481)) pv8484
theorem pv8479 : R t8479 t1 := result (f := t2) (a := t8478) (u := t2) (v := t8482) (refl t2) (aw (ra t0 t8478)) pv8482
theorem pv8480 : R t8480 t1 := result (f := t8479) (a := t8451) (u := t1) (v := t8451) pv8479 (aw (ri t8451)) pv8451
theorem pv8471 : R t8471 t1 := result (f := t8467) (a := t8470) (u := t8454) (v := t8480) pv8467 (awb t2 t8451 t8470 t8478 (refl _)) pv8480
theorem pv8468 : R t8468 t1 := result (f := t0) (a := t8467) (u := t0) (v := t8471) (refl t0) (aw (rh t8467)) pv8471
theorem pv8469 : R t8469 t8454 := result (f := t8468) (a := t8454) (u := t1) (v := t8454) pv8468 (aw (ri t8454)) (refl t8454)
theorem pv8466 : R t8466 t8454 := result (f := t8456) (a := t8465) (u := t8456) (v := t8469) (refl t8456) (awb t0 t8454 t8465 t8467 (refl _)) pv8469
theorem pv8460 : R t8460 t8454 := result (f := t8458) (a := t1) (u := t8458) (v := t8466) (refl t8458) (aw (ra t8456 t1)) pv8466
theorem pv8780 : R t8780 t8779 := result (f := t1) (a := t8779) (u := t1) (v := t8779) (refl t1) (aw (ri t8779)) (refl t8779)
theorem pv8778 : R t8778 t8779 := result (f := t22) (a := t8757) (u := t24) (v := t8780) pv22 (aw (ra t1 t8757)) pv8780
theorem pv8776 : R t8776 t8779 := result (f := t8760) (a := t1) (u := t8760) (v := t8778) (refl t8760) (awb t0 t8757 t1 t1 (cI)) pv8778
theorem pv8807 : R t8807 t8806 := result (f := t1) (a := t8806) (u := t1) (v := t8806) (refl t1) (aw (ri t8806)) (refl t8806)
theorem pv8805 : R t8805 t8806 := result (f := t22) (a := t8784) (u := t24) (v := t8807) pv22 (aw (ra t1 t8784)) pv8807
theorem pv8803 : R t8803 t8806 := result (f := t8787) (a := t1) (u := t8787) (v := t8805) (refl t8787) (awb t0 t8784 t1 t1 (cI)) pv8805
theorem pv8809 : R t8809 t1 := result (f := t8460) (a := t1) (u := t8454) (v := t8532) pv8460 (awb t2 t8451 t1 t1 (cI)) pv8532
theorem pv8810 : R t8810 t1 := result (f := t8809) (a := t1) (u := t1) (v := t1) pv8809 (aw (ri t1)) (refl t1)
theorem pv8784 : R t8784 t1 := result (f := t8782) (a := t1) (u := t8782) (v := t8810) (refl t8782) (awb t8460 t1 t1 t1 (cI)) pv8810
theorem pv8808 : R t8808 t1 := result (f := t28) (a := t8784) (u := t1) (v := t8784) pv28 (aw (ri t8784)) pv8784
theorem pv8804 : R t8804 t1 := result (f := t8803) (a := t1) (u := t8806) (v := t8808) pv8803 (awb t1 t8784 t1 t1 (cI)) pv8808
theorem pv8798 : R t8798 t1 := result (f := t8796) (a := t1) (u := t8796) (v := t8804) (refl t8796) (awb t8787 t1 t1 t1 (cI)) pv8804
theorem pv8802 : R t8802 t8801 := result (f := t8798) (a := t8801) (u := t1) (v := t8801) pv8798 (aw (ri t8801)) (refl t8801)
theorem pv8799 : R t8799 t8801 := result (f := t0) (a := t8798) (u := t0) (v := t8802) (refl t0) (aw (rh t8798)) pv8802
theorem pv8812 : R t8812 t8811 := result (f := t8798) (a := t8811) (u := t1) (v := t8811) pv8798 (aw (ri t8811)) (refl t8811)
theorem pv8800 : R t8800 t8811 := result (f := t8799) (a := t8784) (u := t8801) (v := t8812) pv8799 (aw (ra t8798 t8784)) pv8812
theorem pv8797 : R t8797 t8811 := result (f := t8787) (a := t8796) (u := t8787) (v := t8800) (refl t8787) (awb t0 t8784 t8796 t8798 (refl _)) pv8800
theorem pv8791 : R t8791 t8811 := result (f := t8789) (a := t1) (u := t8789) (v := t8797) (refl t8789) (aw (ra t8787 t1)) pv8797
theorem pv8823 : R t8823 t1 := result (f := t8798) (a := t1) (u := t1) (v := t1) pv8798 (aw (ri t1)) (refl t1)
theorem pv8824 : R t8824 t1 := result (f := t8823) (a := t8784) (u := t1) (v := t8784) pv8823 (aw (ri t8784)) pv8784
theorem pv8821 : R t8821 t1 := result (f := t8791) (a := t1) (u := t8811) (v := t8824) pv8791 (awb t8798 t8784 t1 t1 (cI)) pv8824
theorem pv8822 : R t8822 t1 := result (f := t8821) (a := t1) (u := t1) (v := t1) pv8821 (aw (ri t1)) (refl t1)
theorem pv8818 : R t8818 t1 := result (f := t8816) (a := t1) (u := t8816) (v := t8822) (refl t8816) (awb t8791 t1 t1 t1 (cI)) pv8822
theorem pv8819 : R t8819 t1 := result (f := t8798) (a := t8818) (u := t1) (v := t8818) pv8798 (aw (ri t8818)) pv8818
theorem pv8820 : R t8820 t1 := result (f := t8819) (a := t8784) (u := t1) (v := t8784) pv8819 (aw (ri t8784)) pv8784
theorem pv8817 : R t8817 t1 := result (f := t8791) (a := t8816) (u := t8811) (v := t8820) pv8791 (awb t8798 t8784 t8816 t8818 (refl _)) pv8820
theorem pv8813 : R t8813 t1 := result (f := t8794) (a := t1) (u := t8794) (v := t8817) (refl t8794) (aw (ra t8791 t1)) pv8817
theorem pv8814 : R t8814 t1 := result (f := t8798) (a := t8813) (u := t1) (v := t8813) pv8798 (aw (ri t8813)) pv8813
theorem pv8815 : R t8815 t1 := result (f := t8814) (a := t8784) (u := t1) (v := t8784) pv8814 (aw (ri t8784)) pv8784
theorem pv8795 : R t8795 t1 := result (f := t8791) (a := t8794) (u := t8811) (v := t8815) pv8791 (awb t8798 t8784 t8794 t8813 (refl _)) pv8815
theorem pv8792 : R t8792 t1 := result (f := t0) (a := t8791) (u := t0) (v := t8795) (refl t0) (aw (rh t8791)) pv8795
theorem pv8793 : R t8793 t1 := result (f := t8792) (a := t8784) (u := t1) (v := t8784) pv8792 (aw (ri t8784)) pv8784
theorem pv8790 : R t8790 t1 := result (f := t8787) (a := t8789) (u := t8787) (v := t8793) (refl t8787) (awb t0 t8784 t8789 t8791 (refl _)) pv8793
theorem pv8788 : R t8788 t1 := result (f := t0) (a := t8787) (u := t0) (v := t8790) (refl t0) (aw (rh t8787)) pv8790
theorem pv8785 : R t8785 t1 := result (f := t2) (a := t8784) (u := t2) (v := t8788) (refl t2) (aw (ra t0 t8784)) pv8788
theorem pv8786 : R t8786 t1 := result (f := t8785) (a := t8451) (u := t1) (v := t8451) pv8785 (aw (ri t8451)) pv8451
theorem pv8783 : R t8783 t1 := result (f := t8460) (a := t8782) (u := t8454) (v := t8786) pv8460 (awb t2 t8451 t8782 t8784 (refl _)) pv8786
theorem pv8757 : R t8757 t1 := result (f := t8463) (a := t1) (u := t8463) (v := t8783) (refl t8463) (aw (ra t8460 t1)) pv8783
end Blc.H44.Pump
