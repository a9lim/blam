from reggen import *
from regular_terms import mask
def compile_term(t):
    nodes=[]
    def go(t):
        i=len(nodes); nodes.append(None)
        if t[0] in ('V','C'): n=t
        elif t[0]=='L': n=('L',go(t[1]))
        else: n=('A',go(t[1]),go(t[2]))
        nodes[i]=n; return i
    go(t); return nodes

def machine(t,cap=4000):
    nodes=compile_term(mask(t));p=0;e=();stack=0
    cls=[];clmap={};frames=[None];frmmap={};seen={};states=[];succ=[]
    def intern(x,ls,m):
        if x not in m:m[x]=len(ls);ls.append(x)
        return m[x]
    outcome=None
    for step in range(cap):
        s=(p,e,stack)
        if s in seen:outcome=('cycle',seen[s]);break
        seen[s]=len(states);states.append(s)
        tag,*vs=nodes[p]
        if tag=='V':
            p,e=cls[e[vs[0]]]
        elif tag=='C':
            ss=stack;arity=0
            while ss:_,ss=frames[ss];arity+=1
            outcome=('rigid',vs[0]-len(e),arity);break
        elif tag=='L':
            if not stack:outcome=('lam',);break
            a,stack=frames[stack];p=vs[0];e=(a,)+e
        else:
            f,a=vs;ac=intern((a,e),cls,clmap);stack=intern((ac,stack),frames,frmmap);p=f
    if outcome is None:return None
    return outcome,nodes,cls,frames,states

def obs(o):return '(.rigid %d %d)'%(o[1],o[2]) if o[0]=='rigid' else '.lam'
def generate(s,row):
    k,o,w,n=row;e=lc.decode(s)[0]
    c,m,r,aa,_=dt(k)
    target=appall(A(A(c,L(m)),r),aa); rr=machine(target,500)
    assert tuple(w)==rr[0] and o[0]!='cycle'
    name='E'+str(int(s,2))
    (HERE/(name+'.lean')).write_text(f'''import Concrete
namespace Blc.Floor44.{name}
open Term SelfintSharp Concrete
set_option maxRecDepth 30000
set_option maxHeartbeats 8000000
def e : Term := {expr(e)}
theorem wire_e : Closed e ∧ code e = {int("1"+s,2)} := by decide
theorem excluded : ¬ IsSelfInterpreter e :=
  Concrete.reject (c := {expr(c)}) (m := {expr(m)}) (r := {expr(r)}) (args := [{','.join(map(expr,aa))}])
    (x := {obs(o)}) (y := {obs(w)}) (n := {n}) (k := {len(rr[-1])}) (by decide) (by decide +kernel) (by decide +kernel) (by decide)
#print axioms excluded
end Blc.Floor44.{name}
''')
