import H44Pumppv138
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9883 : R t9883 t1 := result (f := t9882) (a := t9811) (u := t1) (v := t9811) pv9882 (aw (ri t9811)) pv9811
theorem pv9822 : R t9822 t1 := result (f := t9818) (a := t9821) (u := t9879) (v := t9883) pv9818 (awb t9825 t9811 t9821 t9881 (refl _)) pv9883
theorem pv9819 : R t9819 t1 := result (f := t0) (a := t9818) (u := t0) (v := t9822) (refl t0) (aw (rh t9818)) pv9822
theorem pv9820 : R t9820 t1 := result (f := t9819) (a := t9811) (u := t1) (v := t9811) pv9819 (aw (ri t9811)) pv9811
theorem pv9817 : R t9817 t1 := result (f := t9814) (a := t9816) (u := t9814) (v := t9820) (refl t9814) (awb t0 t9811 t9816 t9818 (refl _)) pv9820
theorem pv9815 : R t9815 t1 := result (f := t0) (a := t9814) (u := t0) (v := t9817) (refl t0) (aw (rh t9814)) pv9817
theorem pv9812 : R t9812 t1 := result (f := t2) (a := t9811) (u := t2) (v := t9815) (refl t2) (aw (ra t0 t9811)) pv9815
theorem pv9813 : R t9813 t1 := result (f := t9812) (a := t9699) (u := t1) (v := t9699) pv9812 (aw (ri t9699)) pv9699
theorem pv9712 : R t9712 t1 := result (f := t9708) (a := t9711) (u := t9702) (v := t9813) pv9708 (awb t2 t9699 t9711 t9811 (refl _)) pv9813
theorem pv9709 : R t9709 t1 := result (f := t0) (a := t9708) (u := t0) (v := t9712) (refl t0) (aw (rh t9708)) pv9712
theorem pv9710 : R t9710 t9702 := result (f := t9709) (a := t9702) (u := t1) (v := t9702) pv9709 (aw (ri t9702)) (refl t9702)
theorem pv9707 : R t9707 t9702 := result (f := t9704) (a := t9706) (u := t9704) (v := t9710) (refl t9704) (awb t0 t9702 t9706 t9708 (refl _)) pv9710
theorem pv9705 : R t9705 t9702 := result (f := t0) (a := t9704) (u := t0) (v := t9707) (refl t0) (aw (rh t9704)) pv9707
theorem pv9703 : R t9703 t9702 := result (f := t2) (a := t9702) (u := t2) (v := t9705) (refl t2) (aw (ra t0 t9702)) pv9705
theorem pv9700 : R t9700 t9702 := result (f := t59) (a := t9699) (u := t46) (v := t9703) pv59 (aw (ra t2 t9699)) pv9703
theorem pv9701 : R t9701 t1 := result (f := t9700) (a := t1) (u := t9702) (v := t9780) pv9700 (awb t2 t9699 t1 t1 (cI)) pv9780
theorem pv9698 : R t9698 t1 := result (f := t6495) (a := t9697) (u := t149) (v := t9701) pv6495 (awb t59 t1 t9697 t9699 (refl _)) pv9701
theorem pv9615 : R t9615 t1 := result (f := t6498) (a := t1) (u := t6498) (v := t9698) (refl t6498) (aw (ra t6495 t1)) pv9698
theorem pv9696 : R t9696 t1 := result (f := t3) (a := t9615) (u := t1) (v := t9615) pv3 (aw (ri t9615)) pv9615
theorem pv9694 : R t9694 t1 := result (f := t9631) (a := t1) (u := t9618) (v := t9696) pv9631 (awb t2 t9615 t1 t1 (cI)) pv9696
theorem pv9695 : R t9695 t1 := result (f := t9694) (a := t1) (u := t1) (v := t1) pv9694 (aw (ri t1)) (refl t1)
theorem pv9669 : R t9669 t1 := result (f := t9667) (a := t1) (u := t9667) (v := t9695) (refl t9667) (awb t9631 t1 t1 t1 (cI)) pv9695
theorem pv9693 : R t9693 t1 := result (f := t28) (a := t9669) (u := t1) (v := t9669) pv28 (aw (ri t9669)) pv9669
theorem pv9689 : R t9689 t1 := result (f := t9688) (a := t1) (u := t9691) (v := t9693) pv9688 (awb t1 t9669 t1 t1 (cI)) pv9693
theorem pv9683 : R t9683 t1 := result (f := t9681) (a := t1) (u := t9681) (v := t9689) (refl t9681) (awb t9672 t1 t1 t1 (cI)) pv9689
theorem pv9687 : R t9687 t9686 := result (f := t9683) (a := t9686) (u := t1) (v := t9686) pv9683 (aw (ri t9686)) (refl t9686)
theorem pv9684 : R t9684 t9686 := result (f := t0) (a := t9683) (u := t0) (v := t9687) (refl t0) (aw (rh t9683)) pv9687
theorem pv9894 : R t9894 t9893 := result (f := t9683) (a := t9893) (u := t1) (v := t9893) pv9683 (aw (ri t9893)) (refl t9893)
theorem pv9685 : R t9685 t9893 := result (f := t9684) (a := t9669) (u := t9686) (v := t9894) pv9684 (aw (ra t9683 t9669)) pv9894
theorem pv9682 : R t9682 t9893 := result (f := t9672) (a := t9681) (u := t9672) (v := t9685) (refl t9672) (awb t0 t9669 t9681 t9683 (refl _)) pv9685
theorem pv9676 : R t9676 t9893 := result (f := t9674) (a := t1) (u := t9674) (v := t9682) (refl t9674) (aw (ra t9672 t1)) pv9682
theorem pv9905 : R t9905 t1 := result (f := t9683) (a := t1) (u := t1) (v := t1) pv9683 (aw (ri t1)) (refl t1)
theorem pv9906 : R t9906 t1 := result (f := t9905) (a := t9669) (u := t1) (v := t9669) pv9905 (aw (ri t9669)) pv9669
theorem pv9903 : R t9903 t1 := result (f := t9676) (a := t1) (u := t9893) (v := t9906) pv9676 (awb t9683 t9669 t1 t1 (cI)) pv9906
theorem pv9904 : R t9904 t1 := result (f := t9903) (a := t1) (u := t1) (v := t1) pv9903 (aw (ri t1)) (refl t1)
theorem pv9900 : R t9900 t1 := result (f := t9898) (a := t1) (u := t9898) (v := t9904) (refl t9898) (awb t9676 t1 t1 t1 (cI)) pv9904
theorem pv9901 : R t9901 t1 := result (f := t9683) (a := t9900) (u := t1) (v := t9900) pv9683 (aw (ri t9900)) pv9900
theorem pv9902 : R t9902 t1 := result (f := t9901) (a := t9669) (u := t1) (v := t9669) pv9901 (aw (ri t9669)) pv9669
theorem pv9899 : R t9899 t1 := result (f := t9676) (a := t9898) (u := t9893) (v := t9902) pv9676 (awb t9683 t9669 t9898 t9900 (refl _)) pv9902
theorem pv9895 : R t9895 t1 := result (f := t9679) (a := t1) (u := t9679) (v := t9899) (refl t9679) (aw (ra t9676 t1)) pv9899
theorem pv9896 : R t9896 t1 := result (f := t9683) (a := t9895) (u := t1) (v := t9895) pv9683 (aw (ri t9895)) pv9895
theorem pv9897 : R t9897 t1 := result (f := t9896) (a := t9669) (u := t1) (v := t9669) pv9896 (aw (ri t9669)) pv9669
theorem pv9680 : R t9680 t1 := result (f := t9676) (a := t9679) (u := t9893) (v := t9897) pv9676 (awb t9683 t9669 t9679 t9895 (refl _)) pv9897
theorem pv9677 : R t9677 t1 := result (f := t0) (a := t9676) (u := t0) (v := t9680) (refl t0) (aw (rh t9676)) pv9680
theorem pv9678 : R t9678 t1 := result (f := t9677) (a := t9669) (u := t1) (v := t9669) pv9677 (aw (ri t9669)) pv9669
theorem pv9675 : R t9675 t1 := result (f := t9672) (a := t9674) (u := t9672) (v := t9678) (refl t9672) (awb t0 t9669 t9674 t9676 (refl _)) pv9678
theorem pv9673 : R t9673 t1 := result (f := t0) (a := t9672) (u := t0) (v := t9675) (refl t0) (aw (rh t9672)) pv9675
theorem pv9670 : R t9670 t1 := result (f := t2) (a := t9669) (u := t2) (v := t9673) (refl t2) (aw (ra t0 t9669)) pv9673
theorem pv9671 : R t9671 t1 := result (f := t9670) (a := t9615) (u := t1) (v := t9615) pv9670 (aw (ri t9615)) pv9615
theorem pv9668 : R t9668 t1 := result (f := t9631) (a := t9667) (u := t9618) (v := t9671) pv9631 (awb t2 t9615 t9667 t9669 (refl _)) pv9671
theorem pv9642 : R t9642 t1 := result (f := t9634) (a := t1) (u := t9634) (v := t9668) (refl t9634) (aw (ra t9631 t1)) pv9668
theorem pv9666 : R t9666 t1 := result (f := t28) (a := t9642) (u := t1) (v := t9642) pv28 (aw (ri t9642)) pv9642
theorem pv9662 : R t9662 t1 := result (f := t9661) (a := t1) (u := t9664) (v := t9666) pv9661 (awb t1 t9642 t1 t1 (cI)) pv9666
theorem pv9656 : R t9656 t1 := result (f := t9654) (a := t1) (u := t9654) (v := t9662) (refl t9654) (awb t9645 t1 t1 t1 (cI)) pv9662
theorem pv9660 : R t9660 t9659 := result (f := t9656) (a := t9659) (u := t1) (v := t9659) pv9656 (aw (ri t9659)) (refl t9659)
end Blc.H44.Pump
