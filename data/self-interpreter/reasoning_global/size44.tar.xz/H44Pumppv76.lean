import H44Pumppv75
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5517 : R t5517 t1 := result (f := t5515) (a := t1) (u := t5515) (v := t5521) (refl t5515) (awb t5490 t1 t1 t1 (cI)) pv5521
theorem pv5518 : R t5518 t1 := result (f := t5497) (a := t5517) (u := t1) (v := t5517) pv5497 (aw (ri t5517)) pv5517
theorem pv5519 : R t5519 t1 := result (f := t5518) (a := t5483) (u := t1) (v := t5483) pv5518 (aw (ri t5483)) pv5483
theorem pv5516 : R t5516 t1 := result (f := t5490) (a := t5515) (u := t5510) (v := t5519) pv5490 (awb t5497 t5483 t5515 t5517 (refl _)) pv5519
theorem pv5512 : R t5512 t1 := result (f := t5493) (a := t1) (u := t5493) (v := t5516) (refl t5493) (aw (ra t5490 t1)) pv5516
theorem pv5513 : R t5513 t1 := result (f := t5497) (a := t5512) (u := t1) (v := t5512) pv5497 (aw (ri t5512)) pv5512
theorem pv5514 : R t5514 t1 := result (f := t5513) (a := t5483) (u := t1) (v := t5483) pv5513 (aw (ri t5483)) pv5483
theorem pv5494 : R t5494 t1 := result (f := t5490) (a := t5493) (u := t5510) (v := t5514) pv5490 (awb t5497 t5483 t5493 t5512 (refl _)) pv5514
theorem pv5491 : R t5491 t1 := result (f := t0) (a := t5490) (u := t0) (v := t5494) (refl t0) (aw (rh t5490)) pv5494
theorem pv5492 : R t5492 t1 := result (f := t5491) (a := t5483) (u := t1) (v := t5483) pv5491 (aw (ri t5483)) pv5483
theorem pv5489 : R t5489 t1 := result (f := t5486) (a := t5488) (u := t5486) (v := t5492) (refl t5486) (awb t0 t5483 t5488 t5490 (refl _)) pv5492
theorem pv5487 : R t5487 t1 := result (f := t0) (a := t5486) (u := t0) (v := t5489) (refl t0) (aw (rh t5486)) pv5489
theorem pv5484 : R t5484 t1 := result (f := t2) (a := t5483) (u := t2) (v := t5487) (refl t2) (aw (ra t0 t5483)) pv5487
theorem pv5485 : R t5485 t1 := result (f := t5484) (a := t5344) (u := t1) (v := t5344) pv5484 (aw (ri t5344)) pv5344
theorem pv5482 : R t5482 t1 := result (f := t5353) (a := t5481) (u := t5347) (v := t5485) pv5353 (awb t2 t5344 t5481 t5483 (refl _)) pv5485
theorem pv5456 : R t5456 t1 := result (f := t5356) (a := t1) (u := t5356) (v := t5482) (refl t5356) (aw (ra t5353 t1)) pv5482
theorem pv5480 : R t5480 t1 := result (f := t28) (a := t5456) (u := t1) (v := t5456) pv28 (aw (ri t5456)) pv5456
theorem pv5476 : R t5476 t1 := result (f := t5475) (a := t1) (u := t5478) (v := t5480) pv5475 (awb t1 t5456 t1 t1 (cI)) pv5480
theorem pv5470 : R t5470 t1 := result (f := t5468) (a := t1) (u := t5468) (v := t5476) (refl t5468) (awb t5459 t1 t1 t1 (cI)) pv5476
theorem pv5474 : R t5474 t5473 := result (f := t5470) (a := t5473) (u := t1) (v := t5473) pv5470 (aw (ri t5473)) (refl t5473)
theorem pv5471 : R t5471 t5473 := result (f := t0) (a := t5470) (u := t0) (v := t5474) (refl t0) (aw (rh t5470)) pv5474
theorem pv5525 : R t5525 t5524 := result (f := t5470) (a := t5524) (u := t1) (v := t5524) pv5470 (aw (ri t5524)) (refl t5524)
theorem pv5472 : R t5472 t5524 := result (f := t5471) (a := t5456) (u := t5473) (v := t5525) pv5471 (aw (ra t5470 t5456)) pv5525
theorem pv5469 : R t5469 t5524 := result (f := t5459) (a := t5468) (u := t5459) (v := t5472) (refl t5459) (awb t0 t5456 t5468 t5470 (refl _)) pv5472
theorem pv5463 : R t5463 t5524 := result (f := t5461) (a := t1) (u := t5461) (v := t5469) (refl t5461) (aw (ra t5459 t1)) pv5469
theorem pv5536 : R t5536 t1 := result (f := t5470) (a := t1) (u := t1) (v := t1) pv5470 (aw (ri t1)) (refl t1)
theorem pv5537 : R t5537 t1 := result (f := t5536) (a := t5456) (u := t1) (v := t5456) pv5536 (aw (ri t5456)) pv5456
theorem pv5534 : R t5534 t1 := result (f := t5463) (a := t1) (u := t5524) (v := t5537) pv5463 (awb t5470 t5456 t1 t1 (cI)) pv5537
theorem pv5535 : R t5535 t1 := result (f := t5534) (a := t1) (u := t1) (v := t1) pv5534 (aw (ri t1)) (refl t1)
theorem pv5531 : R t5531 t1 := result (f := t5529) (a := t1) (u := t5529) (v := t5535) (refl t5529) (awb t5463 t1 t1 t1 (cI)) pv5535
theorem pv5532 : R t5532 t1 := result (f := t5470) (a := t5531) (u := t1) (v := t5531) pv5470 (aw (ri t5531)) pv5531
theorem pv5533 : R t5533 t1 := result (f := t5532) (a := t5456) (u := t1) (v := t5456) pv5532 (aw (ri t5456)) pv5456
theorem pv5530 : R t5530 t1 := result (f := t5463) (a := t5529) (u := t5524) (v := t5533) pv5463 (awb t5470 t5456 t5529 t5531 (refl _)) pv5533
theorem pv5526 : R t5526 t1 := result (f := t5466) (a := t1) (u := t5466) (v := t5530) (refl t5466) (aw (ra t5463 t1)) pv5530
theorem pv5527 : R t5527 t1 := result (f := t5470) (a := t5526) (u := t1) (v := t5526) pv5470 (aw (ri t5526)) pv5526
theorem pv5528 : R t5528 t1 := result (f := t5527) (a := t5456) (u := t1) (v := t5456) pv5527 (aw (ri t5456)) pv5456
theorem pv5467 : R t5467 t1 := result (f := t5463) (a := t5466) (u := t5524) (v := t5528) pv5463 (awb t5470 t5456 t5466 t5526 (refl _)) pv5528
theorem pv5464 : R t5464 t1 := result (f := t0) (a := t5463) (u := t0) (v := t5467) (refl t0) (aw (rh t5463)) pv5467
theorem pv5465 : R t5465 t1 := result (f := t5464) (a := t5456) (u := t1) (v := t5456) pv5464 (aw (ri t5456)) pv5456
theorem pv5462 : R t5462 t1 := result (f := t5459) (a := t5461) (u := t5459) (v := t5465) (refl t5459) (awb t0 t5456 t5461 t5463 (refl _)) pv5465
theorem pv5460 : R t5460 t1 := result (f := t0) (a := t5459) (u := t0) (v := t5462) (refl t0) (aw (rh t5459)) pv5462
theorem pv5457 : R t5457 t1 := result (f := t2) (a := t5456) (u := t2) (v := t5460) (refl t2) (aw (ra t0 t5456)) pv5460
theorem pv5458 : R t5458 t1 := result (f := t5457) (a := t5344) (u := t1) (v := t5344) pv5457 (aw (ri t5344)) pv5344
theorem pv5357 : R t5357 t1 := result (f := t5353) (a := t5356) (u := t5347) (v := t5458) pv5353 (awb t2 t5344 t5356 t5456 (refl _)) pv5458
theorem pv5354 : R t5354 t1 := result (f := t0) (a := t5353) (u := t0) (v := t5357) (refl t0) (aw (rh t5353)) pv5357
theorem pv5355 : R t5355 t5347 := result (f := t5354) (a := t5347) (u := t1) (v := t5347) pv5354 (aw (ri t5347)) (refl t5347)
theorem pv5352 : R t5352 t5347 := result (f := t5349) (a := t5351) (u := t5349) (v := t5355) (refl t5349) (awb t0 t5347 t5351 t5353 (refl _)) pv5355
theorem pv5350 : R t5350 t5347 := result (f := t0) (a := t5349) (u := t0) (v := t5352) (refl t0) (aw (rh t5349)) pv5352
theorem pv5348 : R t5348 t5347 := result (f := t2) (a := t5347) (u := t2) (v := t5350) (refl t2) (aw (ra t0 t5347)) pv5350
theorem pv5345 : R t5345 t5347 := result (f := t59) (a := t5344) (u := t46) (v := t5348) pv59 (aw (ra t2 t5344)) pv5348
theorem pv5346 : R t5346 t1 := result (f := t5345) (a := t1) (u := t5347) (v := t5425) pv5345 (awb t2 t5344 t1 t1 (cI)) pv5425
theorem pv5343 : R t5343 t1 := result (f := t4811) (a := t5342) (u := t149) (v := t5346) pv4811 (awb t59 t1 t5342 t5344 (refl _)) pv5346
theorem pv5260 : R t5260 t1 := result (f := t4814) (a := t1) (u := t4814) (v := t5343) (refl t4814) (aw (ra t4811 t1)) pv5343
theorem pv5341 : R t5341 t1 := result (f := t3) (a := t5260) (u := t1) (v := t5260) pv3 (aw (ri t5260)) pv5260
theorem pv5339 : R t5339 t1 := result (f := t5276) (a := t1) (u := t5263) (v := t5341) pv5276 (awb t2 t5260 t1 t1 (cI)) pv5341
end Blc.H44.Pump
