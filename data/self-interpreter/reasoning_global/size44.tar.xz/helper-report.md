# Size 44 remaining applications

**All 75 supplied wires have unconditional, kernel-checked exclusions.** This fills the size-44 lane’s 75 missing entries. Combining these theorems with that lane’s reported ledger gives 188,768 covered layouts, comprising 179,166 finite-predicate rows, 9,599 unconditional negative propositions and three shorter-function propositions conditional on the previous-size floor. This helper independently checks the 75 new statements. The global floor of 45 follows once the coordinator accepts the original inventory, certificates, handwritten implications and previous-size floor.

## Checked argument

For each successful wire `w`, let `N` be its unsigned binary value. The independently constructed de Bruijn term is `Blc.H44.eN`. In `H44Literals.lean`, `wire_eN` proves that it is closed and that folding its BLC bits from the initial numeral 1 gives the numeral represented by the bitstring `1w`. The initial 1 preserves leading zeros. The individual row module proves `Blc.H44.ex_eN : ¬ Blc.IsSelfInterpreter Blc.H44.eN`. In `H44Bridge.lean`, `Blc.Floor44.Help44.same_eN` proves by reflexivity that this term equals the originating batch’s `Blc.Floor44.eN`. The bridge then exports `Blc.Floor44.Help44.ex_eN : ¬ Blc.IsSelfInterpreter Blc.Floor44.eN`. The equality needs no axiom. No smaller-size premise occurs in any row.

| Proof source | Wires | What the kernel verified |
|---|---:|---|
| Existing recursive intersection-arrow rules | 59 | The source has the required type in a previously proved generic rule. Of the 25 rules, Lib0 covers 43, Lib1 covers eight, Lib4 covers four, and Lib2, Lib3, Lib7 and Lib15 each cover one. |
| New generic recursive intersection-arrow rules | 5 | Lib100, Lib101 and Lib102 cover one, three and one respectively. Each table gives a generic contract contradiction, and the source term satisfies its premise. |
| Individual six-arrow derivation | 1 | The closed source has bottom type, which precludes the weak-head clock required of an interpreter. |
| Intersection-arrow derivations extracted from call-by-name flow | 7 | Four ordinary finite analyses, two analyses tracking a color of each argument and one analysis keeping exact closures produced finite positive derivations. The proofs check each variable, abstraction, application and required type inclusion. |
| Closed macro reductions and a descending weak-head clock | 1 | The 11-edge cycle and the path from the literal rule out the clock required of an interpreter. |
| Finite ordered application algebra | 2 | A four-grade table violates the contract inequality. One proof acts directly on the literal and one first takes an explicit beta reduction. |

**Recursive typing.** A finite table gives each arrow its domain and codomain as sets of types. Mutual references are permitted. The `Types.preserved` and `Types.star` theorems preserve positive grading along ordinary beta reduction. For the generic rules, a positive grading of the checked contract source cannot survive in the normal target at that grade. The interpreter contract requires the two sides to join. The individual derivations either prevent joining the rigid target or give bottom grade on a closed term that the interpreter contract requires to have a weak-head clock. The exploratory flow evaluator, type synthesizer and its quotient of equivalent arrows only propose finite derivations. They do not enter any final proof.

**Ordered semantics.** The application table is monotone and the lambda grade is the least row that bounds the graded body for every possible argument. Subject reduction bounds the grade of a normal result by the source grade. Both certificates use the four-grade table with rows `0000`, `2233`, `2233`, `3333`. The kernel checks the required evaluations for the quotation, continuation, source and normal target. For the second wire it also checks the contraction path and preservation of self-interpretation under those contractions.

## Final clock exclusion

The last wire is `01000110100001100001110000101111001100010110`, decimal `4846363276054`, from `Batch1156.lean`. Its literal is `(λa.a a) H`, with `H = λa.a (λb.a (λc.a (c I) b))` and `I = λx.x`. Its first weak-head contraction gives `H H`.

Put `A(x) = λy.x (λz.x (z I) y)` and `B(x,y) = λz.x (z I) y` for closed operands. The checked head rules send `H u` to `u A(u)`, `A(x) u` to `x B(x,u)`, `B(x,y) u` to `x (u I) y`, and `I u` to `u`. The 32 positive beta summaries used by `H44PumpAnchor.lean` prove `A(H) I →* I`. Consequently `B(A(H),y) I →* y` for every closed macro operand y, by reducing first to `A(H) (I I) y`, then to `I y`. This simplification exposes the recurrent demanded application.

The certificate contains 10,003 shared syntax nodes and 7,810 further positive beta summaries. Each summary composes reductions of the function, a concrete weak-head contraction, and reductions of the result. The 36 demand edges start at `H H`. Edge 25 starts an 11-edge cycle with eight strict decreases. Demanding the function of an application cannot increase its weak-head clock. Contracting the exposed head redex strictly decreases that clock, and subsequent beta reductions cannot increase it. Strong induction on the natural-valued clock rules out the cycle. The 25 preceding edges transfer this contradiction back to `H H`. The interpreter contract requires a weak-head clock at the original literal, so `Blc.H44.Pump.excluded` follows. `H44PumpBase.lean` proves the rule semantics and clock comparisons, and `H44PumpCycle.lean` checks the cycle inequalities. The finite call-by-need search found the demanded calls. Every positive reduction and every demand edge used in the proof is checked in Lean.

## Rechecking

From the helper directory, run `timeout 585 python3 -B check.py`. The script builds each local proof module in dependency order into an empty temporary directory, with one Lean process at a time, using `-j2 -M 900`. It imports the size-44 lane’s batch modules and `RegularBase` from its existing objects, plus the repository’s pinned build. For a relocated package, set `H44_REPO` to the repository and `H44_LANE_OBJECTS` to the directory containing the recompiled size-44 batch and support objects. The bridge imports 25 original batch modules. It requires one exclusion for each of the 75 distinct intake wires, an empty unresolved list, a sentinel numeral for each exact source wire, kernel-reported axiom lists for both versions of each result, the axiom-free definitional identities and the axiom allowlist. The fresh check writes `verification.json`.

The clean run compiled 405 helper modules in 115.434 seconds. The largest process used 506,232,832 bytes maximum RSS (H44Bridge). The other lane’s imports came from its existing objects. Discovery timing and whole-lane RSS were not measured.

## Per-wire manifest

`manifest.tsv` contains the wire, bridge file and fully qualified theorem, exact statement, axioms, proof method, own literal proof file and theorem, and definitional bridge. Each decimal value N below names the theorem `Blc.Floor44.Help44.ex_eN`. The 72 recursive-type exclusions use `propext, Classical.choice, Quot.sound`. The two ordered exclusions and the clock exclusion use `propext, Quot.sound`.

| 44-bit wire | Decimal N | Method |
|---|---:|---|
| `01000101011010100011000011000000111100111010` | 4770149175098 | new_table |
| `01000101100110100011000011000000111001101110` | 4783034076782 | reuse |
| `01000101100110100011000011000000111100110110` | 4783034076982 | reuse |
| `01000101100110100011000011000000111100111010` | 4783034076986 | new_table |
| `01000101101010000001011100001111001101100010` | 4786765230946 | flow_types |
| `01000101101010000110000001011000111100110110` | 4786842079030 | reuse |
| `01000101101010000110000001011001100011101110` | 4786842081518 | reuse |
| `01000101101010000110000001011001100011110110` | 4786842081526 | reuse |
| `01000101101010000110000001011011001100011110` | 4786842088222 | reuse |
| `01000101101010000110000001011100110001101110` | 4786842094702 | reuse |
| `01000101101010000110000001011101001100011110` | 4786842096414 | reuse |
| `01000101101010000110000001011110011101000110` | 4786842101574 | ordered_reduct |
| `01000101101010000110000001111001100111000110` | 4786842212806 | reuse |
| `01000101101010000110000110000001111100110110` | 4786843295542 | reuse |
| `01000101101010000110000110000001111100111010` | 4786843295546 | reuse |
| `01000101101010000110011000000001111100110110` | 4786848014134 | reuse |
| `01000110000101101101000011000000111100110110` | 4816487845686 | reuse |
| `01000110000101101101000011000000111100111010` | 4816487845690 | reuse |
| `01000110000110110000110011000000111001111010` | 4817624501882 | reuse |
| `01000110010110001101000011000000111100110110` | 4834204585782 | reuse |
| `01000110010110100011000011000000111100110110` | 4834573684534 | reuse |
| `01000110010110100011000011000000111100111010` | 4834573684538 | new_table |
| `01000110011000011011000011000000111100110110` | 4836586950454 | reuse |
| `01000110011000011011000011000000111100111010` | 4836586950458 | reuse |
| `01000110011000011101000011000000111100110110` | 4836620504886 | reuse |
| `01000110011001100011000011000000111100110110` | 4837794910006 | reuse |
| `01000110011010000101100000000111110011101010` | 4838372965610 | new_table |
| `01000110011010000110000001011001100011101110` | 4838381689070 | reuse |
| `01000110011010000110000001011001100011110110` | 4838381689078 | reuse |
| `01000110011010000110000001011011001100011110` | 4838381695774 | reuse |
| `01000110011010000110000001011100110001101110` | 4838381702254 | reuse |
| `01000110011010000110000001011101001100011110` | 4838381703966 | reuse |
| `01000110011010000110000001011110011011000110` | 4838381708998 | new_table |
| `01000110011010000110000001111001100001101110` | 4838381820014 | reuse |
| `01000110011010000110000001111001100001111010` | 4838381820026 | reuse |
| `01000110011010000110000001111001100110001110` | 4838381820302 | reuse |
| `01000110011010000110000001111001100111000110` | 4838381820358 | reuse |
| `01000110011010000110000110000001111100111010` | 4838382903098 | reuse |
| `01000110011010000110011000000001111100110110` | 4838387621686 | reuse |
| `01000110100001000101101011000000111100110110` | 4845892013878 | reuse |
| `01000110100001000101101101000000111100111010` | 4845892538170 | reuse |
| `01000110100001000101110101000000111001111010` | 4845894635130 | reuse |
| `01000110100001011000000001111100110001111010` | 4846200015994 | reuse |
| `01000110100001011000000001111100110011011010` | 4846200016090 | reuse |
| `01000110100001011000000001111100110011101010` | 4846200016106 | reuse |
| `01000110100001011000000101110100111101100010` | 4846201032546 | reuse |
| `01000110100001011000000111000011110011011010` | 4846201355482 | flow_types |
| `01000110100001011000000111001100111101100010` | 4846201392994 | reuse |
| `01000110100001011000000111100101110101100010` | 4846201494882 | reuse |
| `01000110100001011000011100000011110011011010` | 4846206860506 | reuse |
| `01000110100001100001110000101011110001010110` | 4846363262038 | ordered_table |
| `01000110100001100001110000101100111000101110` | 4846363266606 | reuse |
| `01000110100001100001110000101100111100010110` | 4846363266838 | flow_types |
| `01000110100001100001110000101111000100111010` | 4846363275578 | reuse |
| `01000110100001100001110000101111001100010110` | 4846363276054 | macro_clock |
| `01000110100001100001110000111001011000101110` | 4846363317806 | reuse |
| `01000110100001100001110000111001011110001010` | 4846363318154 | reuse |
| `01000110100001100001110000111001100111100010` | 4846363318754 | reuse |
| `01000110100001100001110000111001111001100010` | 4846363319906 | reuse |
| `01000110100001100001110000111100101100010110` | 4846363331350 | direct_type |
| `01000110100001100001110000111100101110001010` | 4846363331466 | reuse |
| `01000110100001100001110000111100110000011110` | 4846363331614 | flow_types |
| `01000110100001100001110000111100110011100010` | 4846363331810 | reuse |
| `01000110100001100001110000111100111000001110` | 4846363332110 | flow_types |
| `01000110100001100001110000111100111001100010` | 4846363332194 | reuse |
| `01000110100001100101100000011110011000111010` | 4846426121786 | reuse |
| `01000110100001100110000001011000111001111010` | 4846434750074 | reuse |
| `01000110100001100110000001011001100011110110` | 4846434752758 | reuse |
| `01000110100001100110000001011001111010001110` | 4846434754190 | reuse |
| `01000110100001100110000001011110011011000110` | 4846434772678 | flow_types |
| `01000110100001100110000001110011110000110110` | 4846434860086 | flow_types |
| `01000110100001100110000110000001110011111010` | 4846435966202 | reuse |
| `01000110100001100110011000000001011111010110` | 4846440683478 | reuse |
| `01000110100001100110011000000101100011110110` | 4846440700150 | reuse |
| `01000110100001100110011000000111100110001110` | 4846440708494 | reuse |
