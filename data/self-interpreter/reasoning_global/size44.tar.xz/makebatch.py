from wireterms import *
import sys
STEP=160
def emit(s,r):
    e=lc.decode(s)[0];k=r[0];name='e'+str(int(s,2))
    rows=[f'def {name} : Term := {expr(e)}',f'theorem wire_{name} : Closed {name} ∧ code {name} = {int("1"+s,2)} := by decide']
    if k=='open':return rows
    if k=='payload':
        rows.append(f'theorem cert_{name} : checkPay {name} {paths(r[1])} {r[2]} {paths(r[3])} = true := by decide')
    elif k.startswith('W'):
        t=e if k=='Wsource' else A(A(e,V(1)),lc.bitlist('0010',V(0)))
        for p in r[1]:t=red(t,p)
        start=name if k=='Wsource' else '(inv '+name+')'
        rows.extend([f'private def t_{name} : Term := {expr(t)}',f'theorem cert_{name} : ¬ IsSelfInterpreter {name} :=',f'  w{k[1:].title()} (t := t_{name}) (replay_sound (ps := {paths(r[1])}) (t := {start}) (by decide)) (by decide)'])
        rows.append(f'#print axioms cert_{name}')
    else:rows.append(f'theorem cert_{name} : check {name} {paths(r[1])} .{k} = true := by decide')
    return rows
def prefix():
    return 'import Floor44\nnamespace Blc.Floor44\nopen Term SelfintSharp SelfintLowerBound Round3Floor38\nset_option maxRecDepth 20000\n'
def load_rows():
    rows={}
    for p in sorted(HERE.glob('pass1-*.jsonl')):
        with p.open() as f:
            for line in f:
                if line.endswith('\n'):
                    s,r=json.loads(line);assert s not in rows;rows[s]=r
    return rows
def main():
    rows=load_rows();wires=sorted((HERE/'wires.txt').read_text().splitlines())
    for start in range(0,len(wires),STEP):
        ws=wires[start:start+STEP]
        if not all(s in rows for s in ws):continue
        out=prefix()+''.join(v+'\n' for s in ws for v in emit(s,rows[s]))+'end Blc.Floor44\n'
        (HERE/f'Batch{start//STEP:04}.lean').write_text(out)
    print(len(rows),Counter(r[0] for r in rows.values()),flush=True)
    (HERE/'open.txt').write_text(''.join(s+'\n' for s in wires if rows.get(s)==['open']))
if __name__=='__main__':main()
