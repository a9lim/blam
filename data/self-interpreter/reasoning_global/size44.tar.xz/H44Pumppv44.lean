import H44Pumppv43
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3205 : R t3205 t3208 := result (f := t3189) (a := t1) (u := t3189) (v := t3207) (refl t3189) (awb t0 t3186 t1 t1 (cI)) pv3207
theorem pv3236 : R t3236 t3235 := result (f := t1) (a := t3235) (u := t1) (v := t3235) (refl t1) (aw (ri t3235)) (refl t3235)
theorem pv3234 : R t3234 t3235 := result (f := t22) (a := t3213) (u := t24) (v := t3236) pv22 (aw (ra t1 t3213)) pv3236
theorem pv3232 : R t3232 t3235 := result (f := t3216) (a := t1) (u := t3216) (v := t3234) (refl t3216) (awb t0 t3213 t1 t1 (cI)) pv3234
theorem pv3268 : R t3268 t3267 := result (f := t1) (a := t3267) (u := t1) (v := t3267) (refl t1) (aw (ri t3267)) (refl t3267)
theorem pv3266 : R t3266 t3267 := result (f := t22) (a := t3246) (u := t24) (v := t3268) pv22 (aw (ra t1 t3246)) pv3268
theorem pv3264 : R t3264 t3267 := result (f := t3248) (a := t1) (u := t3248) (v := t3266) (refl t3248) (awb t0 t3246 t1 t1 (cI)) pv3266
theorem pv3269 : R t3269 t3246 := result (f := t28) (a := t3246) (u := t1) (v := t3246) pv28 (aw (ri t3246)) (refl t3246)
theorem pv3265 : R t3265 t3246 := result (f := t3264) (a := t1) (u := t3267) (v := t3269) pv3264 (awb t1 t3246 t1 t1 (cI)) pv3269
theorem pv3259 : R t3259 t3246 := result (f := t3257) (a := t1) (u := t3257) (v := t3265) (refl t3257) (awb t3248 t1 t1 t1 (cI)) pv3265
theorem pv3293 : R t3293 t3292 := result (f := t1) (a := t3292) (u := t1) (v := t3292) (refl t1) (aw (ri t3292)) (refl t3292)
theorem pv3291 : R t3291 t3292 := result (f := t22) (a := t3270) (u := t24) (v := t3293) pv22 (aw (ra t1 t3270)) pv3293
theorem pv3289 : R t3289 t3292 := result (f := t3273) (a := t1) (u := t3273) (v := t3291) (refl t3273) (awb t0 t3270 t1 t1 (cI)) pv3291
theorem pv3320 : R t3320 t3319 := result (f := t1) (a := t3319) (u := t1) (v := t3319) (refl t1) (aw (ri t3319)) (refl t3319)
theorem pv3318 : R t3318 t3319 := result (f := t22) (a := t3297) (u := t24) (v := t3320) pv22 (aw (ra t1 t3297)) pv3320
theorem pv3316 : R t3316 t3319 := result (f := t3300) (a := t1) (u := t3300) (v := t3318) (refl t3300) (awb t0 t3297 t1 t1 (cI)) pv3318
theorem pv3325 : R t3325 t1 := result (f := t3105) (a := t1) (u := t149) (v := t231) pv3105 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv3326 : R t3326 t1 := result (f := t3325) (a := t1) (u := t1) (v := t1) pv3325 (aw (ri t1)) (refl t1)
theorem pv3243 : R t3243 t1 := result (f := t3241) (a := t1) (u := t3241) (v := t3326) (refl t3241) (awb t3105 t1 t1 t1 (cI)) pv3326
theorem pv3324 : R t3324 t1 := result (f := t3) (a := t3243) (u := t1) (v := t3243) pv3 (aw (ri t3243)) pv3243
theorem pv3322 : R t3322 t1 := result (f := t3259) (a := t1) (u := t3246) (v := t3324) pv3259 (awb t2 t3243 t1 t1 (cI)) pv3324
theorem pv3323 : R t3323 t1 := result (f := t3322) (a := t1) (u := t1) (v := t1) pv3322 (aw (ri t1)) (refl t1)
theorem pv3297 : R t3297 t1 := result (f := t3295) (a := t1) (u := t3295) (v := t3323) (refl t3295) (awb t3259 t1 t1 t1 (cI)) pv3323
theorem pv3321 : R t3321 t1 := result (f := t28) (a := t3297) (u := t1) (v := t3297) pv28 (aw (ri t3297)) pv3297
theorem pv3317 : R t3317 t1 := result (f := t3316) (a := t1) (u := t3319) (v := t3321) pv3316 (awb t1 t3297 t1 t1 (cI)) pv3321
theorem pv3311 : R t3311 t1 := result (f := t3309) (a := t1) (u := t3309) (v := t3317) (refl t3309) (awb t3300 t1 t1 t1 (cI)) pv3317
theorem pv3315 : R t3315 t3314 := result (f := t3311) (a := t3314) (u := t1) (v := t3314) pv3311 (aw (ri t3314)) (refl t3314)
theorem pv3312 : R t3312 t3314 := result (f := t0) (a := t3311) (u := t0) (v := t3315) (refl t0) (aw (rh t3311)) pv3315
theorem pv3328 : R t3328 t3327 := result (f := t3311) (a := t3327) (u := t1) (v := t3327) pv3311 (aw (ri t3327)) (refl t3327)
theorem pv3313 : R t3313 t3327 := result (f := t3312) (a := t3297) (u := t3314) (v := t3328) pv3312 (aw (ra t3311 t3297)) pv3328
theorem pv3310 : R t3310 t3327 := result (f := t3300) (a := t3309) (u := t3300) (v := t3313) (refl t3300) (awb t0 t3297 t3309 t3311 (refl _)) pv3313
theorem pv3304 : R t3304 t3327 := result (f := t3302) (a := t1) (u := t3302) (v := t3310) (refl t3302) (aw (ra t3300 t1)) pv3310
theorem pv3339 : R t3339 t1 := result (f := t3311) (a := t1) (u := t1) (v := t1) pv3311 (aw (ri t1)) (refl t1)
theorem pv3340 : R t3340 t1 := result (f := t3339) (a := t3297) (u := t1) (v := t3297) pv3339 (aw (ri t3297)) pv3297
theorem pv3337 : R t3337 t1 := result (f := t3304) (a := t1) (u := t3327) (v := t3340) pv3304 (awb t3311 t3297 t1 t1 (cI)) pv3340
theorem pv3338 : R t3338 t1 := result (f := t3337) (a := t1) (u := t1) (v := t1) pv3337 (aw (ri t1)) (refl t1)
theorem pv3334 : R t3334 t1 := result (f := t3332) (a := t1) (u := t3332) (v := t3338) (refl t3332) (awb t3304 t1 t1 t1 (cI)) pv3338
theorem pv3335 : R t3335 t1 := result (f := t3311) (a := t3334) (u := t1) (v := t3334) pv3311 (aw (ri t3334)) pv3334
theorem pv3336 : R t3336 t1 := result (f := t3335) (a := t3297) (u := t1) (v := t3297) pv3335 (aw (ri t3297)) pv3297
theorem pv3333 : R t3333 t1 := result (f := t3304) (a := t3332) (u := t3327) (v := t3336) pv3304 (awb t3311 t3297 t3332 t3334 (refl _)) pv3336
theorem pv3329 : R t3329 t1 := result (f := t3307) (a := t1) (u := t3307) (v := t3333) (refl t3307) (aw (ra t3304 t1)) pv3333
theorem pv3330 : R t3330 t1 := result (f := t3311) (a := t3329) (u := t1) (v := t3329) pv3311 (aw (ri t3329)) pv3329
theorem pv3331 : R t3331 t1 := result (f := t3330) (a := t3297) (u := t1) (v := t3297) pv3330 (aw (ri t3297)) pv3297
theorem pv3308 : R t3308 t1 := result (f := t3304) (a := t3307) (u := t3327) (v := t3331) pv3304 (awb t3311 t3297 t3307 t3329 (refl _)) pv3331
theorem pv3305 : R t3305 t1 := result (f := t0) (a := t3304) (u := t0) (v := t3308) (refl t0) (aw (rh t3304)) pv3308
theorem pv3306 : R t3306 t1 := result (f := t3305) (a := t3297) (u := t1) (v := t3297) pv3305 (aw (ri t3297)) pv3297
theorem pv3303 : R t3303 t1 := result (f := t3300) (a := t3302) (u := t3300) (v := t3306) (refl t3300) (awb t0 t3297 t3302 t3304 (refl _)) pv3306
theorem pv3301 : R t3301 t1 := result (f := t0) (a := t3300) (u := t0) (v := t3303) (refl t0) (aw (rh t3300)) pv3303
theorem pv3298 : R t3298 t1 := result (f := t2) (a := t3297) (u := t2) (v := t3301) (refl t2) (aw (ra t0 t3297)) pv3301
theorem pv3299 : R t3299 t1 := result (f := t3298) (a := t3243) (u := t1) (v := t3243) pv3298 (aw (ri t3243)) pv3243
theorem pv3296 : R t3296 t1 := result (f := t3259) (a := t3295) (u := t3246) (v := t3299) pv3259 (awb t2 t3243 t3295 t3297 (refl _)) pv3299
theorem pv3270 : R t3270 t1 := result (f := t3262) (a := t1) (u := t3262) (v := t3296) (refl t3262) (aw (ra t3259 t1)) pv3296
theorem pv3294 : R t3294 t1 := result (f := t28) (a := t3270) (u := t1) (v := t3270) pv28 (aw (ri t3270)) pv3270
theorem pv3290 : R t3290 t1 := result (f := t3289) (a := t1) (u := t3292) (v := t3294) pv3289 (awb t1 t3270 t1 t1 (cI)) pv3294
theorem pv3284 : R t3284 t1 := result (f := t3282) (a := t1) (u := t3282) (v := t3290) (refl t3282) (awb t3273 t1 t1 t1 (cI)) pv3290
end Blc.H44.Pump
