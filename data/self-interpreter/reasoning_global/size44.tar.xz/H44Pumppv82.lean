import H44Pumppv81
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5788 : R t5788 t5773 := result (f := t5787) (a := t5773) (u := t1) (v := t5773) pv5787 (aw (ri t5773)) (refl t5773)
theorem pv5785 : R t5785 t5773 := result (f := t5775) (a := t5784) (u := t5775) (v := t5788) (refl t5775) (awb t0 t5773 t5784 t5786 (refl _)) pv5788
theorem pv5779 : R t5779 t5773 := result (f := t5777) (a := t1) (u := t5777) (v := t5785) (refl t5777) (aw (ra t5775 t1)) pv5785
theorem pv5905 : R t5905 t5904 := result (f := t1) (a := t5904) (u := t1) (v := t5904) (refl t1) (aw (ri t5904)) (refl t5904)
theorem pv5903 : R t5903 t5904 := result (f := t22) (a := t5882) (u := t24) (v := t5905) pv22 (aw (ra t1 t5882)) pv5905
theorem pv5901 : R t5901 t5904 := result (f := t5885) (a := t1) (u := t5885) (v := t5903) (refl t5885) (awb t0 t5882 t1 t1 (cI)) pv5903
theorem pv5932 : R t5932 t5931 := result (f := t1) (a := t5931) (u := t1) (v := t5931) (refl t1) (aw (ri t5931)) (refl t5931)
theorem pv5930 : R t5930 t5931 := result (f := t22) (a := t5909) (u := t24) (v := t5932) pv22 (aw (ra t1 t5909)) pv5932
theorem pv5928 : R t5928 t5931 := result (f := t5912) (a := t1) (u := t5912) (v := t5930) (refl t5912) (awb t0 t5909 t1 t1 (cI)) pv5930
theorem pv5934 : R t5934 t1 := result (f := t5779) (a := t1) (u := t5773) (v := t5851) pv5779 (awb t2 t5770 t1 t1 (cI)) pv5851
theorem pv5935 : R t5935 t1 := result (f := t5934) (a := t1) (u := t1) (v := t1) pv5934 (aw (ri t1)) (refl t1)
theorem pv5909 : R t5909 t1 := result (f := t5907) (a := t1) (u := t5907) (v := t5935) (refl t5907) (awb t5779 t1 t1 t1 (cI)) pv5935
theorem pv5933 : R t5933 t1 := result (f := t28) (a := t5909) (u := t1) (v := t5909) pv28 (aw (ri t5909)) pv5909
theorem pv5929 : R t5929 t1 := result (f := t5928) (a := t1) (u := t5931) (v := t5933) pv5928 (awb t1 t5909 t1 t1 (cI)) pv5933
theorem pv5923 : R t5923 t1 := result (f := t5921) (a := t1) (u := t5921) (v := t5929) (refl t5921) (awb t5912 t1 t1 t1 (cI)) pv5929
theorem pv5927 : R t5927 t5926 := result (f := t5923) (a := t5926) (u := t1) (v := t5926) pv5923 (aw (ri t5926)) (refl t5926)
theorem pv5924 : R t5924 t5926 := result (f := t0) (a := t5923) (u := t0) (v := t5927) (refl t0) (aw (rh t5923)) pv5927
theorem pv5937 : R t5937 t5936 := result (f := t5923) (a := t5936) (u := t1) (v := t5936) pv5923 (aw (ri t5936)) (refl t5936)
theorem pv5925 : R t5925 t5936 := result (f := t5924) (a := t5909) (u := t5926) (v := t5937) pv5924 (aw (ra t5923 t5909)) pv5937
theorem pv5922 : R t5922 t5936 := result (f := t5912) (a := t5921) (u := t5912) (v := t5925) (refl t5912) (awb t0 t5909 t5921 t5923 (refl _)) pv5925
theorem pv5916 : R t5916 t5936 := result (f := t5914) (a := t1) (u := t5914) (v := t5922) (refl t5914) (aw (ra t5912 t1)) pv5922
theorem pv5948 : R t5948 t1 := result (f := t5923) (a := t1) (u := t1) (v := t1) pv5923 (aw (ri t1)) (refl t1)
theorem pv5949 : R t5949 t1 := result (f := t5948) (a := t5909) (u := t1) (v := t5909) pv5948 (aw (ri t5909)) pv5909
theorem pv5946 : R t5946 t1 := result (f := t5916) (a := t1) (u := t5936) (v := t5949) pv5916 (awb t5923 t5909 t1 t1 (cI)) pv5949
theorem pv5947 : R t5947 t1 := result (f := t5946) (a := t1) (u := t1) (v := t1) pv5946 (aw (ri t1)) (refl t1)
theorem pv5943 : R t5943 t1 := result (f := t5941) (a := t1) (u := t5941) (v := t5947) (refl t5941) (awb t5916 t1 t1 t1 (cI)) pv5947
theorem pv5944 : R t5944 t1 := result (f := t5923) (a := t5943) (u := t1) (v := t5943) pv5923 (aw (ri t5943)) pv5943
theorem pv5945 : R t5945 t1 := result (f := t5944) (a := t5909) (u := t1) (v := t5909) pv5944 (aw (ri t5909)) pv5909
theorem pv5942 : R t5942 t1 := result (f := t5916) (a := t5941) (u := t5936) (v := t5945) pv5916 (awb t5923 t5909 t5941 t5943 (refl _)) pv5945
theorem pv5938 : R t5938 t1 := result (f := t5919) (a := t1) (u := t5919) (v := t5942) (refl t5919) (aw (ra t5916 t1)) pv5942
theorem pv5939 : R t5939 t1 := result (f := t5923) (a := t5938) (u := t1) (v := t5938) pv5923 (aw (ri t5938)) pv5938
theorem pv5940 : R t5940 t1 := result (f := t5939) (a := t5909) (u := t1) (v := t5909) pv5939 (aw (ri t5909)) pv5909
theorem pv5920 : R t5920 t1 := result (f := t5916) (a := t5919) (u := t5936) (v := t5940) pv5916 (awb t5923 t5909 t5919 t5938 (refl _)) pv5940
theorem pv5917 : R t5917 t1 := result (f := t0) (a := t5916) (u := t0) (v := t5920) (refl t0) (aw (rh t5916)) pv5920
theorem pv5918 : R t5918 t1 := result (f := t5917) (a := t5909) (u := t1) (v := t5909) pv5917 (aw (ri t5909)) pv5909
theorem pv5915 : R t5915 t1 := result (f := t5912) (a := t5914) (u := t5912) (v := t5918) (refl t5912) (awb t0 t5909 t5914 t5916 (refl _)) pv5918
theorem pv5913 : R t5913 t1 := result (f := t0) (a := t5912) (u := t0) (v := t5915) (refl t0) (aw (rh t5912)) pv5915
theorem pv5910 : R t5910 t1 := result (f := t2) (a := t5909) (u := t2) (v := t5913) (refl t2) (aw (ra t0 t5909)) pv5913
theorem pv5911 : R t5911 t1 := result (f := t5910) (a := t5770) (u := t1) (v := t5770) pv5910 (aw (ri t5770)) pv5770
theorem pv5908 : R t5908 t1 := result (f := t5779) (a := t5907) (u := t5773) (v := t5911) pv5779 (awb t2 t5770 t5907 t5909 (refl _)) pv5911
theorem pv5882 : R t5882 t1 := result (f := t5782) (a := t1) (u := t5782) (v := t5908) (refl t5782) (aw (ra t5779 t1)) pv5908
theorem pv5906 : R t5906 t1 := result (f := t28) (a := t5882) (u := t1) (v := t5882) pv28 (aw (ri t5882)) pv5882
theorem pv5902 : R t5902 t1 := result (f := t5901) (a := t1) (u := t5904) (v := t5906) pv5901 (awb t1 t5882 t1 t1 (cI)) pv5906
theorem pv5896 : R t5896 t1 := result (f := t5894) (a := t1) (u := t5894) (v := t5902) (refl t5894) (awb t5885 t1 t1 t1 (cI)) pv5902
theorem pv5900 : R t5900 t5899 := result (f := t5896) (a := t5899) (u := t1) (v := t5899) pv5896 (aw (ri t5899)) (refl t5899)
theorem pv5897 : R t5897 t5899 := result (f := t0) (a := t5896) (u := t0) (v := t5900) (refl t0) (aw (rh t5896)) pv5900
theorem pv5951 : R t5951 t5950 := result (f := t5896) (a := t5950) (u := t1) (v := t5950) pv5896 (aw (ri t5950)) (refl t5950)
theorem pv5898 : R t5898 t5950 := result (f := t5897) (a := t5882) (u := t5899) (v := t5951) pv5897 (aw (ra t5896 t5882)) pv5951
theorem pv5895 : R t5895 t5950 := result (f := t5885) (a := t5894) (u := t5885) (v := t5898) (refl t5885) (awb t0 t5882 t5894 t5896 (refl _)) pv5898
theorem pv5889 : R t5889 t5950 := result (f := t5887) (a := t1) (u := t5887) (v := t5895) (refl t5887) (aw (ra t5885 t1)) pv5895
theorem pv5962 : R t5962 t1 := result (f := t5896) (a := t1) (u := t1) (v := t1) pv5896 (aw (ri t1)) (refl t1)
theorem pv5963 : R t5963 t1 := result (f := t5962) (a := t5882) (u := t1) (v := t5882) pv5962 (aw (ri t5882)) pv5882
theorem pv5960 : R t5960 t1 := result (f := t5889) (a := t1) (u := t5950) (v := t5963) pv5889 (awb t5896 t5882 t1 t1 (cI)) pv5963
theorem pv5961 : R t5961 t1 := result (f := t5960) (a := t1) (u := t1) (v := t1) pv5960 (aw (ri t1)) (refl t1)
theorem pv5957 : R t5957 t1 := result (f := t5955) (a := t1) (u := t5955) (v := t5961) (refl t5955) (awb t5889 t1 t1 t1 (cI)) pv5961
end Blc.H44.Pump
