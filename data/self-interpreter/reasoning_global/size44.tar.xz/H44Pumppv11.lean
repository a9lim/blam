import H44Pumppv10
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv999 : R t999 t1 := result (f := t975) (a := t998) (u := t1) (v := t998) pv975 (aw (ri t998)) pv998
theorem pv1000 : R t1000 t1 := result (f := t999) (a := t961) (u := t1) (v := t961) pv999 (aw (ri t961)) pv961
theorem pv997 : R t997 t1 := result (f := t968) (a := t996) (u := t991) (v := t1000) pv968 (awb t975 t961 t996 t998 (refl _)) pv1000
theorem pv993 : R t993 t1 := result (f := t971) (a := t1) (u := t971) (v := t997) (refl t971) (aw (ra t968 t1)) pv997
theorem pv994 : R t994 t1 := result (f := t975) (a := t993) (u := t1) (v := t993) pv975 (aw (ri t993)) pv993
theorem pv995 : R t995 t1 := result (f := t994) (a := t961) (u := t1) (v := t961) pv994 (aw (ri t961)) pv961
theorem pv972 : R t972 t1 := result (f := t968) (a := t971) (u := t991) (v := t995) pv968 (awb t975 t961 t971 t993 (refl _)) pv995
theorem pv969 : R t969 t1 := result (f := t0) (a := t968) (u := t0) (v := t972) (refl t0) (aw (rh t968)) pv972
theorem pv970 : R t970 t1 := result (f := t969) (a := t961) (u := t1) (v := t961) pv969 (aw (ri t961)) pv961
theorem pv967 : R t967 t1 := result (f := t964) (a := t966) (u := t964) (v := t970) (refl t964) (awb t0 t961 t966 t968 (refl _)) pv970
theorem pv965 : R t965 t1 := result (f := t0) (a := t964) (u := t0) (v := t967) (refl t0) (aw (rh t964)) pv967
theorem pv962 : R t962 t1 := result (f := t2) (a := t961) (u := t2) (v := t965) (refl t2) (aw (ra t0 t961)) pv965
theorem pv963 : R t963 t1 := result (f := t962) (a := t907) (u := t1) (v := t907) pv962 (aw (ri t907)) pv907
theorem pv960 : R t960 t1 := result (f := t923) (a := t959) (u := t910) (v := t963) pv923 (awb t2 t907 t959 t961 (refl _)) pv963
theorem pv934 : R t934 t1 := result (f := t926) (a := t1) (u := t926) (v := t960) (refl t926) (aw (ra t923 t1)) pv960
theorem pv958 : R t958 t1 := result (f := t28) (a := t934) (u := t1) (v := t934) pv28 (aw (ri t934)) pv934
theorem pv954 : R t954 t1 := result (f := t953) (a := t1) (u := t956) (v := t958) pv953 (awb t1 t934 t1 t1 (cI)) pv958
theorem pv948 : R t948 t1 := result (f := t946) (a := t1) (u := t946) (v := t954) (refl t946) (awb t937 t1 t1 t1 (cI)) pv954
theorem pv952 : R t952 t951 := result (f := t948) (a := t951) (u := t1) (v := t951) pv948 (aw (ri t951)) (refl t951)
theorem pv949 : R t949 t951 := result (f := t0) (a := t948) (u := t0) (v := t952) (refl t0) (aw (rh t948)) pv952
theorem pv1006 : R t1006 t1005 := result (f := t948) (a := t1005) (u := t1) (v := t1005) pv948 (aw (ri t1005)) (refl t1005)
theorem pv950 : R t950 t1005 := result (f := t949) (a := t934) (u := t951) (v := t1006) pv949 (aw (ra t948 t934)) pv1006
theorem pv947 : R t947 t1005 := result (f := t937) (a := t946) (u := t937) (v := t950) (refl t937) (awb t0 t934 t946 t948 (refl _)) pv950
theorem pv941 : R t941 t1005 := result (f := t939) (a := t1) (u := t939) (v := t947) (refl t939) (aw (ra t937 t1)) pv947
theorem pv1017 : R t1017 t1 := result (f := t948) (a := t1) (u := t1) (v := t1) pv948 (aw (ri t1)) (refl t1)
theorem pv1018 : R t1018 t1 := result (f := t1017) (a := t934) (u := t1) (v := t934) pv1017 (aw (ri t934)) pv934
theorem pv1015 : R t1015 t1 := result (f := t941) (a := t1) (u := t1005) (v := t1018) pv941 (awb t948 t934 t1 t1 (cI)) pv1018
theorem pv1016 : R t1016 t1 := result (f := t1015) (a := t1) (u := t1) (v := t1) pv1015 (aw (ri t1)) (refl t1)
theorem pv1012 : R t1012 t1 := result (f := t1010) (a := t1) (u := t1010) (v := t1016) (refl t1010) (awb t941 t1 t1 t1 (cI)) pv1016
theorem pv1013 : R t1013 t1 := result (f := t948) (a := t1012) (u := t1) (v := t1012) pv948 (aw (ri t1012)) pv1012
theorem pv1014 : R t1014 t1 := result (f := t1013) (a := t934) (u := t1) (v := t934) pv1013 (aw (ri t934)) pv934
theorem pv1011 : R t1011 t1 := result (f := t941) (a := t1010) (u := t1005) (v := t1014) pv941 (awb t948 t934 t1010 t1012 (refl _)) pv1014
theorem pv1007 : R t1007 t1 := result (f := t944) (a := t1) (u := t944) (v := t1011) (refl t944) (aw (ra t941 t1)) pv1011
theorem pv1008 : R t1008 t1 := result (f := t948) (a := t1007) (u := t1) (v := t1007) pv948 (aw (ri t1007)) pv1007
theorem pv1009 : R t1009 t1 := result (f := t1008) (a := t934) (u := t1) (v := t934) pv1008 (aw (ri t934)) pv934
theorem pv945 : R t945 t1 := result (f := t941) (a := t944) (u := t1005) (v := t1009) pv941 (awb t948 t934 t944 t1007 (refl _)) pv1009
theorem pv942 : R t942 t1 := result (f := t0) (a := t941) (u := t0) (v := t945) (refl t0) (aw (rh t941)) pv945
theorem pv943 : R t943 t1 := result (f := t942) (a := t934) (u := t1) (v := t934) pv942 (aw (ri t934)) pv934
theorem pv940 : R t940 t1 := result (f := t937) (a := t939) (u := t937) (v := t943) (refl t937) (awb t0 t934 t939 t941 (refl _)) pv943
theorem pv938 : R t938 t1 := result (f := t0) (a := t937) (u := t0) (v := t940) (refl t0) (aw (rh t937)) pv940
theorem pv935 : R t935 t1 := result (f := t2) (a := t934) (u := t2) (v := t938) (refl t2) (aw (ra t0 t934)) pv938
theorem pv936 : R t936 t1 := result (f := t935) (a := t907) (u := t1) (v := t907) pv935 (aw (ri t907)) pv907
theorem pv927 : R t927 t1 := result (f := t923) (a := t926) (u := t910) (v := t936) pv923 (awb t2 t907 t926 t934 (refl _)) pv936
theorem pv924 : R t924 t1 := result (f := t0) (a := t923) (u := t0) (v := t927) (refl t0) (aw (rh t923)) pv927
theorem pv925 : R t925 t910 := result (f := t924) (a := t910) (u := t1) (v := t910) pv924 (aw (ri t910)) (refl t910)
theorem pv922 : R t922 t910 := result (f := t912) (a := t921) (u := t912) (v := t925) (refl t912) (awb t0 t910 t921 t923 (refl _)) pv925
theorem pv916 : R t916 t910 := result (f := t914) (a := t1) (u := t914) (v := t922) (refl t914) (aw (ra t912 t1)) pv922
theorem pv1042 : R t1042 t1041 := result (f := t1) (a := t1041) (u := t1) (v := t1041) (refl t1) (aw (ri t1041)) (refl t1041)
theorem pv1040 : R t1040 t1041 := result (f := t22) (a := t1019) (u := t24) (v := t1042) pv22 (aw (ra t1 t1019)) pv1042
theorem pv1038 : R t1038 t1041 := result (f := t1022) (a := t1) (u := t1022) (v := t1040) (refl t1022) (awb t0 t1019 t1 t1 (cI)) pv1040
theorem pv1069 : R t1069 t1068 := result (f := t1) (a := t1068) (u := t1) (v := t1068) (refl t1) (aw (ri t1068)) (refl t1068)
theorem pv1067 : R t1067 t1068 := result (f := t22) (a := t1046) (u := t24) (v := t1069) pv22 (aw (ra t1 t1046)) pv1069
theorem pv1065 : R t1065 t1068 := result (f := t1049) (a := t1) (u := t1049) (v := t1067) (refl t1049) (awb t0 t1046 t1 t1 (cI)) pv1067
theorem pv1071 : R t1071 t1 := result (f := t916) (a := t1) (u := t910) (v := t988) pv916 (awb t2 t907 t1 t1 (cI)) pv988
theorem pv1072 : R t1072 t1 := result (f := t1071) (a := t1) (u := t1) (v := t1) pv1071 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
