import H44Pumppv27
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1949 : R t1949 t1946 := result (f := t0) (a := t1948) (u := t0) (v := t1951) (refl t0) (aw (rh t1948)) pv1951
theorem pv1947 : R t1947 t1946 := result (f := t2) (a := t1946) (u := t2) (v := t1949) (refl t2) (aw (ra t0 t1946)) pv1949
theorem pv1944 : R t1944 t1946 := result (f := t59) (a := t1943) (u := t46) (v := t1947) pv59 (aw (ra t2 t1943)) pv1947
theorem pv1945 : R t1945 t1 := result (f := t1944) (a := t1) (u := t1946) (v := t2024) pv1944 (awb t2 t1943 t1 t1 (cI)) pv2024
theorem pv1942 : R t1942 t1 := result (f := t1410) (a := t1941) (u := t149) (v := t1945) pv1410 (awb t59 t1 t1941 t1943 (refl _)) pv1945
theorem pv1859 : R t1859 t1 := result (f := t1413) (a := t1) (u := t1413) (v := t1942) (refl t1413) (aw (ra t1410 t1)) pv1942
theorem pv1940 : R t1940 t1 := result (f := t3) (a := t1859) (u := t1) (v := t1859) pv3 (aw (ri t1859)) pv1859
theorem pv1938 : R t1938 t1 := result (f := t1875) (a := t1) (u := t1862) (v := t1940) pv1875 (awb t2 t1859 t1 t1 (cI)) pv1940
theorem pv1939 : R t1939 t1 := result (f := t1938) (a := t1) (u := t1) (v := t1) pv1938 (aw (ri t1)) (refl t1)
theorem pv1913 : R t1913 t1 := result (f := t1911) (a := t1) (u := t1911) (v := t1939) (refl t1911) (awb t1875 t1 t1 t1 (cI)) pv1939
theorem pv1937 : R t1937 t1 := result (f := t28) (a := t1913) (u := t1) (v := t1913) pv28 (aw (ri t1913)) pv1913
theorem pv1933 : R t1933 t1 := result (f := t1932) (a := t1) (u := t1935) (v := t1937) pv1932 (awb t1 t1913 t1 t1 (cI)) pv1937
theorem pv1927 : R t1927 t1 := result (f := t1925) (a := t1) (u := t1925) (v := t1933) (refl t1925) (awb t1916 t1 t1 t1 (cI)) pv1933
theorem pv1931 : R t1931 t1930 := result (f := t1927) (a := t1930) (u := t1) (v := t1930) pv1927 (aw (ri t1930)) (refl t1930)
theorem pv1928 : R t1928 t1930 := result (f := t0) (a := t1927) (u := t0) (v := t1931) (refl t0) (aw (rh t1927)) pv1931
theorem pv2138 : R t2138 t2137 := result (f := t1927) (a := t2137) (u := t1) (v := t2137) pv1927 (aw (ri t2137)) (refl t2137)
theorem pv1929 : R t1929 t2137 := result (f := t1928) (a := t1913) (u := t1930) (v := t2138) pv1928 (aw (ra t1927 t1913)) pv2138
theorem pv1926 : R t1926 t2137 := result (f := t1916) (a := t1925) (u := t1916) (v := t1929) (refl t1916) (awb t0 t1913 t1925 t1927 (refl _)) pv1929
theorem pv1920 : R t1920 t2137 := result (f := t1918) (a := t1) (u := t1918) (v := t1926) (refl t1918) (aw (ra t1916 t1)) pv1926
theorem pv2149 : R t2149 t1 := result (f := t1927) (a := t1) (u := t1) (v := t1) pv1927 (aw (ri t1)) (refl t1)
theorem pv2150 : R t2150 t1 := result (f := t2149) (a := t1913) (u := t1) (v := t1913) pv2149 (aw (ri t1913)) pv1913
theorem pv2147 : R t2147 t1 := result (f := t1920) (a := t1) (u := t2137) (v := t2150) pv1920 (awb t1927 t1913 t1 t1 (cI)) pv2150
theorem pv2148 : R t2148 t1 := result (f := t2147) (a := t1) (u := t1) (v := t1) pv2147 (aw (ri t1)) (refl t1)
theorem pv2144 : R t2144 t1 := result (f := t2142) (a := t1) (u := t2142) (v := t2148) (refl t2142) (awb t1920 t1 t1 t1 (cI)) pv2148
theorem pv2145 : R t2145 t1 := result (f := t1927) (a := t2144) (u := t1) (v := t2144) pv1927 (aw (ri t2144)) pv2144
theorem pv2146 : R t2146 t1 := result (f := t2145) (a := t1913) (u := t1) (v := t1913) pv2145 (aw (ri t1913)) pv1913
theorem pv2143 : R t2143 t1 := result (f := t1920) (a := t2142) (u := t2137) (v := t2146) pv1920 (awb t1927 t1913 t2142 t2144 (refl _)) pv2146
theorem pv2139 : R t2139 t1 := result (f := t1923) (a := t1) (u := t1923) (v := t2143) (refl t1923) (aw (ra t1920 t1)) pv2143
theorem pv2140 : R t2140 t1 := result (f := t1927) (a := t2139) (u := t1) (v := t2139) pv1927 (aw (ri t2139)) pv2139
theorem pv2141 : R t2141 t1 := result (f := t2140) (a := t1913) (u := t1) (v := t1913) pv2140 (aw (ri t1913)) pv1913
theorem pv1924 : R t1924 t1 := result (f := t1920) (a := t1923) (u := t2137) (v := t2141) pv1920 (awb t1927 t1913 t1923 t2139 (refl _)) pv2141
theorem pv1921 : R t1921 t1 := result (f := t0) (a := t1920) (u := t0) (v := t1924) (refl t0) (aw (rh t1920)) pv1924
theorem pv1922 : R t1922 t1 := result (f := t1921) (a := t1913) (u := t1) (v := t1913) pv1921 (aw (ri t1913)) pv1913
theorem pv1919 : R t1919 t1 := result (f := t1916) (a := t1918) (u := t1916) (v := t1922) (refl t1916) (awb t0 t1913 t1918 t1920 (refl _)) pv1922
theorem pv1917 : R t1917 t1 := result (f := t0) (a := t1916) (u := t0) (v := t1919) (refl t0) (aw (rh t1916)) pv1919
theorem pv1914 : R t1914 t1 := result (f := t2) (a := t1913) (u := t2) (v := t1917) (refl t2) (aw (ra t0 t1913)) pv1917
theorem pv1915 : R t1915 t1 := result (f := t1914) (a := t1859) (u := t1) (v := t1859) pv1914 (aw (ri t1859)) pv1859
theorem pv1912 : R t1912 t1 := result (f := t1875) (a := t1911) (u := t1862) (v := t1915) pv1875 (awb t2 t1859 t1911 t1913 (refl _)) pv1915
theorem pv1886 : R t1886 t1 := result (f := t1878) (a := t1) (u := t1878) (v := t1912) (refl t1878) (aw (ra t1875 t1)) pv1912
theorem pv1910 : R t1910 t1 := result (f := t28) (a := t1886) (u := t1) (v := t1886) pv28 (aw (ri t1886)) pv1886
theorem pv1906 : R t1906 t1 := result (f := t1905) (a := t1) (u := t1908) (v := t1910) pv1905 (awb t1 t1886 t1 t1 (cI)) pv1910
theorem pv1900 : R t1900 t1 := result (f := t1898) (a := t1) (u := t1898) (v := t1906) (refl t1898) (awb t1889 t1 t1 t1 (cI)) pv1906
theorem pv1904 : R t1904 t1903 := result (f := t1900) (a := t1903) (u := t1) (v := t1903) pv1900 (aw (ri t1903)) (refl t1903)
theorem pv1901 : R t1901 t1903 := result (f := t0) (a := t1900) (u := t0) (v := t1904) (refl t0) (aw (rh t1900)) pv1904
theorem pv2152 : R t2152 t2151 := result (f := t1900) (a := t2151) (u := t1) (v := t2151) pv1900 (aw (ri t2151)) (refl t2151)
theorem pv1902 : R t1902 t2151 := result (f := t1901) (a := t1886) (u := t1903) (v := t2152) pv1901 (aw (ra t1900 t1886)) pv2152
theorem pv1899 : R t1899 t2151 := result (f := t1889) (a := t1898) (u := t1889) (v := t1902) (refl t1889) (awb t0 t1886 t1898 t1900 (refl _)) pv1902
theorem pv1893 : R t1893 t2151 := result (f := t1891) (a := t1) (u := t1891) (v := t1899) (refl t1891) (aw (ra t1889 t1)) pv1899
theorem pv2163 : R t2163 t1 := result (f := t1900) (a := t1) (u := t1) (v := t1) pv1900 (aw (ri t1)) (refl t1)
theorem pv2164 : R t2164 t1 := result (f := t2163) (a := t1886) (u := t1) (v := t1886) pv2163 (aw (ri t1886)) pv1886
theorem pv2161 : R t2161 t1 := result (f := t1893) (a := t1) (u := t2151) (v := t2164) pv1893 (awb t1900 t1886 t1 t1 (cI)) pv2164
theorem pv2162 : R t2162 t1 := result (f := t2161) (a := t1) (u := t1) (v := t1) pv2161 (aw (ri t1)) (refl t1)
theorem pv2158 : R t2158 t1 := result (f := t2156) (a := t1) (u := t2156) (v := t2162) (refl t2156) (awb t1893 t1 t1 t1 (cI)) pv2162
theorem pv2159 : R t2159 t1 := result (f := t1900) (a := t2158) (u := t1) (v := t2158) pv1900 (aw (ri t2158)) pv2158
theorem pv2160 : R t2160 t1 := result (f := t2159) (a := t1886) (u := t1) (v := t1886) pv2159 (aw (ri t1886)) pv1886
end Blc.H44.Pump
