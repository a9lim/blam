import H44ChainModel
namespace Blc.H44Chain
open Term SelfintControl SelfintLowerBound ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
private def sentinel (t : Term) : Nat := (blcCode t).foldl (fun n b => 2*n + if b then 1 else 0) 1
def opm0 (i j : Fin 4) : Fin 4 := match i.val,j.val with
  | 0,0 => 0
  | 0,1 => 0
  | 0,2 => 0
  | 0,3 => 0
  | 1,0 => 2
  | 1,1 => 2
  | 2,0 => 2
  | 2,1 => 2
  | _,_ => 3
def gm0 : Algebra 3 := ⟨opm0,0,by decide,by decide,by decide⟩
theorem bm0_0 : Typed gm0 (rho (n := 3) 1 0) (churchBit false) 1 := typed_eval _ _
theorem bm0_1 : Typed gm0 (rho (n := 3) 1 0) (churchBit true) 1 := typed_eval _ _
theorem sm0_0 : Typed gm0 (rho (n := 3) 1 0) (streamOf [] (.var 0)) 0 := .var _ _ (Nat.le_refl _)
theorem sm0_1 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false] (.var 0)) 1 := pairGrade bm0_0 sm0_0 (by decide) (by decide)
theorem sm0_2 : Typed gm0 (rho (n := 3) 1 0) (streamOf [true,false] (.var 0)) 1 := pairGrade bm0_1 sm0_1 (by decide) (by decide)
theorem sm0_3 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_2 (by decide) (by decide)
theorem sm0_4 : Typed gm0 (rho (n := 3) 1 0) (streamOf [true,false,true,false] (.var 0)) 1 := pairGrade bm0_1 sm0_3 (by decide) (by decide)
theorem sm0_5 : Typed gm0 (rho (n := 3) 1 0) (streamOf [true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_1 sm0_4 (by decide) (by decide)
theorem sm0_6 : Typed gm0 (rho (n := 3) 1 0) (streamOf [true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_1 sm0_5 (by decide) (by decide)
theorem sm0_7 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_6 (by decide) (by decide)
theorem sm0_8 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_7 (by decide) (by decide)
theorem sm0_9 : Typed gm0 (rho (n := 3) 1 0) (streamOf [true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_1 sm0_8 (by decide) (by decide)
theorem sm0_10 : Typed gm0 (rho (n := 3) 1 0) (streamOf [true,true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_1 sm0_9 (by decide) (by decide)
theorem sm0_11 : Typed gm0 (rho (n := 3) 1 0) (streamOf [true,true,true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_1 sm0_10 (by decide) (by decide)
theorem sm0_12 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,true,true,true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_11 (by decide) (by decide)
theorem sm0_13 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,false,true,true,true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_12 (by decide) (by decide)
theorem sm0_14 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,false,false,true,true,true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_13 (by decide) (by decide)
theorem sm0_15 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,false,false,false,true,true,true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_14 (by decide) (by decide)
theorem sm0_16 : Typed gm0 (rho (n := 3) 1 0) (streamOf [false,false,false,false,false,true,true,true,false,false,true,true,true,false,true,false] (.var 0)) 1 := pairGrade bm0_0 sm0_15 (by decide) (by decide)

def ob0_0 : Term := .var 0
def ob0_1 : Term := .app ob0_0 ob0_0
def ob0_2 : Term := .lam ob0_1
def ob0_3 : Term := .var 1
def ob0_4 : Term := .var 2
def ob0_5 : Term := .lam ob0_0
def ob0_6 : Term := .app ob0_4 ob0_5
def ob0_7 : Term := .app ob0_6 ob0_0
def ob0_8 : Term := .app ob0_7 ob0_3
def ob0_9 : Term := .lam ob0_8
def ob0_10 : Term := .app ob0_3 ob0_9
def ob0_11 : Term := .lam ob0_10
def ob0_12 : Term := .app ob0_0 ob0_11
def ob0_13 : Term := .lam ob0_12
def ob0_14 : Term := .app ob0_2 ob0_13
end Blc.H44Chain
