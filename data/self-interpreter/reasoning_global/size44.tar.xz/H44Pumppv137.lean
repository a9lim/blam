import H44Pumppv136
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9760 : R t9760 t9783 := result (f := t9758) (a := t1) (u := t9758) (v := t9766) (refl t9758) (aw (ra t9756 t1)) pv9766
theorem pv9795 : R t9795 t1 := result (f := t9767) (a := t1) (u := t1) (v := t1) pv9767 (aw (ri t1)) (refl t1)
theorem pv9796 : R t9796 t1 := result (f := t9795) (a := t9753) (u := t1) (v := t9753) pv9795 (aw (ri t9753)) pv9753
theorem pv9793 : R t9793 t1 := result (f := t9760) (a := t1) (u := t9783) (v := t9796) pv9760 (awb t9767 t9753 t1 t1 (cI)) pv9796
theorem pv9794 : R t9794 t1 := result (f := t9793) (a := t1) (u := t1) (v := t1) pv9793 (aw (ri t1)) (refl t1)
theorem pv9790 : R t9790 t1 := result (f := t9788) (a := t1) (u := t9788) (v := t9794) (refl t9788) (awb t9760 t1 t1 t1 (cI)) pv9794
theorem pv9791 : R t9791 t1 := result (f := t9767) (a := t9790) (u := t1) (v := t9790) pv9767 (aw (ri t9790)) pv9790
theorem pv9792 : R t9792 t1 := result (f := t9791) (a := t9753) (u := t1) (v := t9753) pv9791 (aw (ri t9753)) pv9753
theorem pv9789 : R t9789 t1 := result (f := t9760) (a := t9788) (u := t9783) (v := t9792) pv9760 (awb t9767 t9753 t9788 t9790 (refl _)) pv9792
theorem pv9785 : R t9785 t1 := result (f := t9763) (a := t1) (u := t9763) (v := t9789) (refl t9763) (aw (ra t9760 t1)) pv9789
theorem pv9786 : R t9786 t1 := result (f := t9767) (a := t9785) (u := t1) (v := t9785) pv9767 (aw (ri t9785)) pv9785
theorem pv9787 : R t9787 t1 := result (f := t9786) (a := t9753) (u := t1) (v := t9753) pv9786 (aw (ri t9753)) pv9753
theorem pv9764 : R t9764 t1 := result (f := t9760) (a := t9763) (u := t9783) (v := t9787) pv9760 (awb t9767 t9753 t9763 t9785 (refl _)) pv9787
theorem pv9761 : R t9761 t1 := result (f := t0) (a := t9760) (u := t0) (v := t9764) (refl t0) (aw (rh t9760)) pv9764
theorem pv9762 : R t9762 t1 := result (f := t9761) (a := t9753) (u := t1) (v := t9753) pv9761 (aw (ri t9753)) pv9753
theorem pv9759 : R t9759 t1 := result (f := t9756) (a := t9758) (u := t9756) (v := t9762) (refl t9756) (awb t0 t9753 t9758 t9760 (refl _)) pv9762
theorem pv9757 : R t9757 t1 := result (f := t0) (a := t9756) (u := t0) (v := t9759) (refl t0) (aw (rh t9756)) pv9759
theorem pv9754 : R t9754 t1 := result (f := t2) (a := t9753) (u := t2) (v := t9757) (refl t2) (aw (ra t0 t9753)) pv9757
theorem pv9755 : R t9755 t1 := result (f := t9754) (a := t9699) (u := t1) (v := t9699) pv9754 (aw (ri t9699)) pv9699
theorem pv9752 : R t9752 t1 := result (f := t9715) (a := t9751) (u := t9702) (v := t9755) pv9715 (awb t2 t9699 t9751 t9753 (refl _)) pv9755
theorem pv9726 : R t9726 t1 := result (f := t9718) (a := t1) (u := t9718) (v := t9752) (refl t9718) (aw (ra t9715 t1)) pv9752
theorem pv9750 : R t9750 t1 := result (f := t28) (a := t9726) (u := t1) (v := t9726) pv28 (aw (ri t9726)) pv9726
theorem pv9746 : R t9746 t1 := result (f := t9745) (a := t1) (u := t9748) (v := t9750) pv9745 (awb t1 t9726 t1 t1 (cI)) pv9750
theorem pv9740 : R t9740 t1 := result (f := t9738) (a := t1) (u := t9738) (v := t9746) (refl t9738) (awb t9729 t1 t1 t1 (cI)) pv9746
theorem pv9744 : R t9744 t9743 := result (f := t9740) (a := t9743) (u := t1) (v := t9743) pv9740 (aw (ri t9743)) (refl t9743)
theorem pv9741 : R t9741 t9743 := result (f := t0) (a := t9740) (u := t0) (v := t9744) (refl t0) (aw (rh t9740)) pv9744
theorem pv9798 : R t9798 t9797 := result (f := t9740) (a := t9797) (u := t1) (v := t9797) pv9740 (aw (ri t9797)) (refl t9797)
theorem pv9742 : R t9742 t9797 := result (f := t9741) (a := t9726) (u := t9743) (v := t9798) pv9741 (aw (ra t9740 t9726)) pv9798
theorem pv9739 : R t9739 t9797 := result (f := t9729) (a := t9738) (u := t9729) (v := t9742) (refl t9729) (awb t0 t9726 t9738 t9740 (refl _)) pv9742
theorem pv9733 : R t9733 t9797 := result (f := t9731) (a := t1) (u := t9731) (v := t9739) (refl t9731) (aw (ra t9729 t1)) pv9739
theorem pv9809 : R t9809 t1 := result (f := t9740) (a := t1) (u := t1) (v := t1) pv9740 (aw (ri t1)) (refl t1)
theorem pv9810 : R t9810 t1 := result (f := t9809) (a := t9726) (u := t1) (v := t9726) pv9809 (aw (ri t9726)) pv9726
theorem pv9807 : R t9807 t1 := result (f := t9733) (a := t1) (u := t9797) (v := t9810) pv9733 (awb t9740 t9726 t1 t1 (cI)) pv9810
theorem pv9808 : R t9808 t1 := result (f := t9807) (a := t1) (u := t1) (v := t1) pv9807 (aw (ri t1)) (refl t1)
theorem pv9804 : R t9804 t1 := result (f := t9802) (a := t1) (u := t9802) (v := t9808) (refl t9802) (awb t9733 t1 t1 t1 (cI)) pv9808
theorem pv9805 : R t9805 t1 := result (f := t9740) (a := t9804) (u := t1) (v := t9804) pv9740 (aw (ri t9804)) pv9804
theorem pv9806 : R t9806 t1 := result (f := t9805) (a := t9726) (u := t1) (v := t9726) pv9805 (aw (ri t9726)) pv9726
theorem pv9803 : R t9803 t1 := result (f := t9733) (a := t9802) (u := t9797) (v := t9806) pv9733 (awb t9740 t9726 t9802 t9804 (refl _)) pv9806
theorem pv9799 : R t9799 t1 := result (f := t9736) (a := t1) (u := t9736) (v := t9803) (refl t9736) (aw (ra t9733 t1)) pv9803
theorem pv9800 : R t9800 t1 := result (f := t9740) (a := t9799) (u := t1) (v := t9799) pv9740 (aw (ri t9799)) pv9799
theorem pv9801 : R t9801 t1 := result (f := t9800) (a := t9726) (u := t1) (v := t9726) pv9800 (aw (ri t9726)) pv9726
theorem pv9737 : R t9737 t1 := result (f := t9733) (a := t9736) (u := t9797) (v := t9801) pv9733 (awb t9740 t9726 t9736 t9799 (refl _)) pv9801
theorem pv9734 : R t9734 t1 := result (f := t0) (a := t9733) (u := t0) (v := t9737) (refl t0) (aw (rh t9733)) pv9737
theorem pv9735 : R t9735 t1 := result (f := t9734) (a := t9726) (u := t1) (v := t9726) pv9734 (aw (ri t9726)) pv9726
theorem pv9732 : R t9732 t1 := result (f := t9729) (a := t9731) (u := t9729) (v := t9735) (refl t9729) (awb t0 t9726 t9731 t9733 (refl _)) pv9735
theorem pv9730 : R t9730 t1 := result (f := t0) (a := t9729) (u := t0) (v := t9732) (refl t0) (aw (rh t9729)) pv9732
theorem pv9727 : R t9727 t1 := result (f := t2) (a := t9726) (u := t2) (v := t9730) (refl t2) (aw (ra t0 t9726)) pv9730
theorem pv9728 : R t9728 t1 := result (f := t9727) (a := t9699) (u := t1) (v := t9699) pv9727 (aw (ri t9699)) pv9699
theorem pv9719 : R t9719 t1 := result (f := t9715) (a := t9718) (u := t9702) (v := t9728) pv9715 (awb t2 t9699 t9718 t9726 (refl _)) pv9728
theorem pv9716 : R t9716 t1 := result (f := t0) (a := t9715) (u := t0) (v := t9719) (refl t0) (aw (rh t9715)) pv9719
theorem pv9717 : R t9717 t9702 := result (f := t9716) (a := t9702) (u := t1) (v := t9702) pv9716 (aw (ri t9702)) (refl t9702)
theorem pv9714 : R t9714 t9702 := result (f := t9704) (a := t9713) (u := t9704) (v := t9717) (refl t9704) (awb t0 t9702 t9713 t9715 (refl _)) pv9717
theorem pv9708 : R t9708 t9702 := result (f := t9706) (a := t1) (u := t9706) (v := t9714) (refl t9706) (aw (ra t9704 t1)) pv9714
theorem pv9834 : R t9834 t9833 := result (f := t1) (a := t9833) (u := t1) (v := t9833) (refl t1) (aw (ri t9833)) (refl t9833)
theorem pv9832 : R t9832 t9833 := result (f := t22) (a := t9811) (u := t24) (v := t9834) pv22 (aw (ra t1 t9811)) pv9834
end Blc.H44.Pump
