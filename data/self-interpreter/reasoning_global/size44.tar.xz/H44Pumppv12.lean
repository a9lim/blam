import H44Pumppv11
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1046 : R t1046 t1 := result (f := t1044) (a := t1) (u := t1044) (v := t1072) (refl t1044) (awb t916 t1 t1 t1 (cI)) pv1072
theorem pv1070 : R t1070 t1 := result (f := t28) (a := t1046) (u := t1) (v := t1046) pv28 (aw (ri t1046)) pv1046
theorem pv1066 : R t1066 t1 := result (f := t1065) (a := t1) (u := t1068) (v := t1070) pv1065 (awb t1 t1046 t1 t1 (cI)) pv1070
theorem pv1060 : R t1060 t1 := result (f := t1058) (a := t1) (u := t1058) (v := t1066) (refl t1058) (awb t1049 t1 t1 t1 (cI)) pv1066
theorem pv1064 : R t1064 t1063 := result (f := t1060) (a := t1063) (u := t1) (v := t1063) pv1060 (aw (ri t1063)) (refl t1063)
theorem pv1061 : R t1061 t1063 := result (f := t0) (a := t1060) (u := t0) (v := t1064) (refl t0) (aw (rh t1060)) pv1064
theorem pv1074 : R t1074 t1073 := result (f := t1060) (a := t1073) (u := t1) (v := t1073) pv1060 (aw (ri t1073)) (refl t1073)
theorem pv1062 : R t1062 t1073 := result (f := t1061) (a := t1046) (u := t1063) (v := t1074) pv1061 (aw (ra t1060 t1046)) pv1074
theorem pv1059 : R t1059 t1073 := result (f := t1049) (a := t1058) (u := t1049) (v := t1062) (refl t1049) (awb t0 t1046 t1058 t1060 (refl _)) pv1062
theorem pv1053 : R t1053 t1073 := result (f := t1051) (a := t1) (u := t1051) (v := t1059) (refl t1051) (aw (ra t1049 t1)) pv1059
theorem pv1085 : R t1085 t1 := result (f := t1060) (a := t1) (u := t1) (v := t1) pv1060 (aw (ri t1)) (refl t1)
theorem pv1086 : R t1086 t1 := result (f := t1085) (a := t1046) (u := t1) (v := t1046) pv1085 (aw (ri t1046)) pv1046
theorem pv1083 : R t1083 t1 := result (f := t1053) (a := t1) (u := t1073) (v := t1086) pv1053 (awb t1060 t1046 t1 t1 (cI)) pv1086
theorem pv1084 : R t1084 t1 := result (f := t1083) (a := t1) (u := t1) (v := t1) pv1083 (aw (ri t1)) (refl t1)
theorem pv1080 : R t1080 t1 := result (f := t1078) (a := t1) (u := t1078) (v := t1084) (refl t1078) (awb t1053 t1 t1 t1 (cI)) pv1084
theorem pv1081 : R t1081 t1 := result (f := t1060) (a := t1080) (u := t1) (v := t1080) pv1060 (aw (ri t1080)) pv1080
theorem pv1082 : R t1082 t1 := result (f := t1081) (a := t1046) (u := t1) (v := t1046) pv1081 (aw (ri t1046)) pv1046
theorem pv1079 : R t1079 t1 := result (f := t1053) (a := t1078) (u := t1073) (v := t1082) pv1053 (awb t1060 t1046 t1078 t1080 (refl _)) pv1082
theorem pv1075 : R t1075 t1 := result (f := t1056) (a := t1) (u := t1056) (v := t1079) (refl t1056) (aw (ra t1053 t1)) pv1079
theorem pv1076 : R t1076 t1 := result (f := t1060) (a := t1075) (u := t1) (v := t1075) pv1060 (aw (ri t1075)) pv1075
theorem pv1077 : R t1077 t1 := result (f := t1076) (a := t1046) (u := t1) (v := t1046) pv1076 (aw (ri t1046)) pv1046
theorem pv1057 : R t1057 t1 := result (f := t1053) (a := t1056) (u := t1073) (v := t1077) pv1053 (awb t1060 t1046 t1056 t1075 (refl _)) pv1077
theorem pv1054 : R t1054 t1 := result (f := t0) (a := t1053) (u := t0) (v := t1057) (refl t0) (aw (rh t1053)) pv1057
theorem pv1055 : R t1055 t1 := result (f := t1054) (a := t1046) (u := t1) (v := t1046) pv1054 (aw (ri t1046)) pv1046
theorem pv1052 : R t1052 t1 := result (f := t1049) (a := t1051) (u := t1049) (v := t1055) (refl t1049) (awb t0 t1046 t1051 t1053 (refl _)) pv1055
theorem pv1050 : R t1050 t1 := result (f := t0) (a := t1049) (u := t0) (v := t1052) (refl t0) (aw (rh t1049)) pv1052
theorem pv1047 : R t1047 t1 := result (f := t2) (a := t1046) (u := t2) (v := t1050) (refl t2) (aw (ra t0 t1046)) pv1050
theorem pv1048 : R t1048 t1 := result (f := t1047) (a := t907) (u := t1) (v := t907) pv1047 (aw (ri t907)) pv907
theorem pv1045 : R t1045 t1 := result (f := t916) (a := t1044) (u := t910) (v := t1048) pv916 (awb t2 t907 t1044 t1046 (refl _)) pv1048
theorem pv1019 : R t1019 t1 := result (f := t919) (a := t1) (u := t919) (v := t1045) (refl t919) (aw (ra t916 t1)) pv1045
theorem pv1043 : R t1043 t1 := result (f := t28) (a := t1019) (u := t1) (v := t1019) pv28 (aw (ri t1019)) pv1019
theorem pv1039 : R t1039 t1 := result (f := t1038) (a := t1) (u := t1041) (v := t1043) pv1038 (awb t1 t1019 t1 t1 (cI)) pv1043
theorem pv1033 : R t1033 t1 := result (f := t1031) (a := t1) (u := t1031) (v := t1039) (refl t1031) (awb t1022 t1 t1 t1 (cI)) pv1039
theorem pv1037 : R t1037 t1036 := result (f := t1033) (a := t1036) (u := t1) (v := t1036) pv1033 (aw (ri t1036)) (refl t1036)
theorem pv1034 : R t1034 t1036 := result (f := t0) (a := t1033) (u := t0) (v := t1037) (refl t0) (aw (rh t1033)) pv1037
theorem pv1088 : R t1088 t1087 := result (f := t1033) (a := t1087) (u := t1) (v := t1087) pv1033 (aw (ri t1087)) (refl t1087)
theorem pv1035 : R t1035 t1087 := result (f := t1034) (a := t1019) (u := t1036) (v := t1088) pv1034 (aw (ra t1033 t1019)) pv1088
theorem pv1032 : R t1032 t1087 := result (f := t1022) (a := t1031) (u := t1022) (v := t1035) (refl t1022) (awb t0 t1019 t1031 t1033 (refl _)) pv1035
theorem pv1026 : R t1026 t1087 := result (f := t1024) (a := t1) (u := t1024) (v := t1032) (refl t1024) (aw (ra t1022 t1)) pv1032
theorem pv1099 : R t1099 t1 := result (f := t1033) (a := t1) (u := t1) (v := t1) pv1033 (aw (ri t1)) (refl t1)
theorem pv1100 : R t1100 t1 := result (f := t1099) (a := t1019) (u := t1) (v := t1019) pv1099 (aw (ri t1019)) pv1019
theorem pv1097 : R t1097 t1 := result (f := t1026) (a := t1) (u := t1087) (v := t1100) pv1026 (awb t1033 t1019 t1 t1 (cI)) pv1100
theorem pv1098 : R t1098 t1 := result (f := t1097) (a := t1) (u := t1) (v := t1) pv1097 (aw (ri t1)) (refl t1)
theorem pv1094 : R t1094 t1 := result (f := t1092) (a := t1) (u := t1092) (v := t1098) (refl t1092) (awb t1026 t1 t1 t1 (cI)) pv1098
theorem pv1095 : R t1095 t1 := result (f := t1033) (a := t1094) (u := t1) (v := t1094) pv1033 (aw (ri t1094)) pv1094
theorem pv1096 : R t1096 t1 := result (f := t1095) (a := t1019) (u := t1) (v := t1019) pv1095 (aw (ri t1019)) pv1019
theorem pv1093 : R t1093 t1 := result (f := t1026) (a := t1092) (u := t1087) (v := t1096) pv1026 (awb t1033 t1019 t1092 t1094 (refl _)) pv1096
theorem pv1089 : R t1089 t1 := result (f := t1029) (a := t1) (u := t1029) (v := t1093) (refl t1029) (aw (ra t1026 t1)) pv1093
theorem pv1090 : R t1090 t1 := result (f := t1033) (a := t1089) (u := t1) (v := t1089) pv1033 (aw (ri t1089)) pv1089
theorem pv1091 : R t1091 t1 := result (f := t1090) (a := t1019) (u := t1) (v := t1019) pv1090 (aw (ri t1019)) pv1019
theorem pv1030 : R t1030 t1 := result (f := t1026) (a := t1029) (u := t1087) (v := t1091) pv1026 (awb t1033 t1019 t1029 t1089 (refl _)) pv1091
theorem pv1027 : R t1027 t1 := result (f := t0) (a := t1026) (u := t0) (v := t1030) (refl t0) (aw (rh t1026)) pv1030
theorem pv1028 : R t1028 t1 := result (f := t1027) (a := t1019) (u := t1) (v := t1019) pv1027 (aw (ri t1019)) pv1019
theorem pv1025 : R t1025 t1 := result (f := t1022) (a := t1024) (u := t1022) (v := t1028) (refl t1022) (awb t0 t1019 t1024 t1026 (refl _)) pv1028
theorem pv1023 : R t1023 t1 := result (f := t0) (a := t1022) (u := t0) (v := t1025) (refl t0) (aw (rh t1022)) pv1025
end Blc.H44.Pump
