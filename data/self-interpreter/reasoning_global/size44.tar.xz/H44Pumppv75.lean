import H44Pumppv74
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5371 : R t5371 t1 := result (f := t5363) (a := t1) (u := t5363) (v := t5397) (refl t5363) (aw (ra t5360 t1)) pv5397
theorem pv5395 : R t5395 t1 := result (f := t28) (a := t5371) (u := t1) (v := t5371) pv28 (aw (ri t5371)) pv5371
theorem pv5391 : R t5391 t1 := result (f := t5390) (a := t1) (u := t5393) (v := t5395) pv5390 (awb t1 t5371 t1 t1 (cI)) pv5395
theorem pv5385 : R t5385 t1 := result (f := t5383) (a := t1) (u := t5383) (v := t5391) (refl t5383) (awb t5374 t1 t1 t1 (cI)) pv5391
theorem pv5389 : R t5389 t5388 := result (f := t5385) (a := t5388) (u := t1) (v := t5388) pv5385 (aw (ri t5388)) (refl t5388)
theorem pv5386 : R t5386 t5388 := result (f := t0) (a := t5385) (u := t0) (v := t5389) (refl t0) (aw (rh t5385)) pv5389
theorem pv5443 : R t5443 t5442 := result (f := t5385) (a := t5442) (u := t1) (v := t5442) pv5385 (aw (ri t5442)) (refl t5442)
theorem pv5387 : R t5387 t5442 := result (f := t5386) (a := t5371) (u := t5388) (v := t5443) pv5386 (aw (ra t5385 t5371)) pv5443
theorem pv5384 : R t5384 t5442 := result (f := t5374) (a := t5383) (u := t5374) (v := t5387) (refl t5374) (awb t0 t5371 t5383 t5385 (refl _)) pv5387
theorem pv5378 : R t5378 t5442 := result (f := t5376) (a := t1) (u := t5376) (v := t5384) (refl t5376) (aw (ra t5374 t1)) pv5384
theorem pv5454 : R t5454 t1 := result (f := t5385) (a := t1) (u := t1) (v := t1) pv5385 (aw (ri t1)) (refl t1)
theorem pv5455 : R t5455 t1 := result (f := t5454) (a := t5371) (u := t1) (v := t5371) pv5454 (aw (ri t5371)) pv5371
theorem pv5452 : R t5452 t1 := result (f := t5378) (a := t1) (u := t5442) (v := t5455) pv5378 (awb t5385 t5371 t1 t1 (cI)) pv5455
theorem pv5453 : R t5453 t1 := result (f := t5452) (a := t1) (u := t1) (v := t1) pv5452 (aw (ri t1)) (refl t1)
theorem pv5449 : R t5449 t1 := result (f := t5447) (a := t1) (u := t5447) (v := t5453) (refl t5447) (awb t5378 t1 t1 t1 (cI)) pv5453
theorem pv5450 : R t5450 t1 := result (f := t5385) (a := t5449) (u := t1) (v := t5449) pv5385 (aw (ri t5449)) pv5449
theorem pv5451 : R t5451 t1 := result (f := t5450) (a := t5371) (u := t1) (v := t5371) pv5450 (aw (ri t5371)) pv5371
theorem pv5448 : R t5448 t1 := result (f := t5378) (a := t5447) (u := t5442) (v := t5451) pv5378 (awb t5385 t5371 t5447 t5449 (refl _)) pv5451
theorem pv5444 : R t5444 t1 := result (f := t5381) (a := t1) (u := t5381) (v := t5448) (refl t5381) (aw (ra t5378 t1)) pv5448
theorem pv5445 : R t5445 t1 := result (f := t5385) (a := t5444) (u := t1) (v := t5444) pv5385 (aw (ri t5444)) pv5444
theorem pv5446 : R t5446 t1 := result (f := t5445) (a := t5371) (u := t1) (v := t5371) pv5445 (aw (ri t5371)) pv5371
theorem pv5382 : R t5382 t1 := result (f := t5378) (a := t5381) (u := t5442) (v := t5446) pv5378 (awb t5385 t5371 t5381 t5444 (refl _)) pv5446
theorem pv5379 : R t5379 t1 := result (f := t0) (a := t5378) (u := t0) (v := t5382) (refl t0) (aw (rh t5378)) pv5382
theorem pv5380 : R t5380 t1 := result (f := t5379) (a := t5371) (u := t1) (v := t5371) pv5379 (aw (ri t5371)) pv5371
theorem pv5377 : R t5377 t1 := result (f := t5374) (a := t5376) (u := t5374) (v := t5380) (refl t5374) (awb t0 t5371 t5376 t5378 (refl _)) pv5380
theorem pv5375 : R t5375 t1 := result (f := t0) (a := t5374) (u := t0) (v := t5377) (refl t0) (aw (rh t5374)) pv5377
theorem pv5372 : R t5372 t1 := result (f := t2) (a := t5371) (u := t2) (v := t5375) (refl t2) (aw (ra t0 t5371)) pv5375
theorem pv5373 : R t5373 t1 := result (f := t5372) (a := t5344) (u := t1) (v := t5344) pv5372 (aw (ri t5344)) pv5344
theorem pv5364 : R t5364 t1 := result (f := t5360) (a := t5363) (u := t5347) (v := t5373) pv5360 (awb t2 t5344 t5363 t5371 (refl _)) pv5373
theorem pv5361 : R t5361 t1 := result (f := t0) (a := t5360) (u := t0) (v := t5364) (refl t0) (aw (rh t5360)) pv5364
theorem pv5362 : R t5362 t5347 := result (f := t5361) (a := t5347) (u := t1) (v := t5347) pv5361 (aw (ri t5347)) (refl t5347)
theorem pv5359 : R t5359 t5347 := result (f := t5349) (a := t5358) (u := t5349) (v := t5362) (refl t5349) (awb t0 t5347 t5358 t5360 (refl _)) pv5362
theorem pv5353 : R t5353 t5347 := result (f := t5351) (a := t1) (u := t5351) (v := t5359) (refl t5351) (aw (ra t5349 t1)) pv5359
theorem pv5479 : R t5479 t5478 := result (f := t1) (a := t5478) (u := t1) (v := t5478) (refl t1) (aw (ri t5478)) (refl t5478)
theorem pv5477 : R t5477 t5478 := result (f := t22) (a := t5456) (u := t24) (v := t5479) pv22 (aw (ra t1 t5456)) pv5479
theorem pv5475 : R t5475 t5478 := result (f := t5459) (a := t1) (u := t5459) (v := t5477) (refl t5459) (awb t0 t5456 t1 t1 (cI)) pv5477
theorem pv5506 : R t5506 t5505 := result (f := t1) (a := t5505) (u := t1) (v := t5505) (refl t1) (aw (ri t5505)) (refl t5505)
theorem pv5504 : R t5504 t5505 := result (f := t22) (a := t5483) (u := t24) (v := t5506) pv22 (aw (ra t1 t5483)) pv5506
theorem pv5502 : R t5502 t5505 := result (f := t5486) (a := t1) (u := t5486) (v := t5504) (refl t5486) (awb t0 t5483 t1 t1 (cI)) pv5504
theorem pv5508 : R t5508 t1 := result (f := t5353) (a := t1) (u := t5347) (v := t5425) pv5353 (awb t2 t5344 t1 t1 (cI)) pv5425
theorem pv5509 : R t5509 t1 := result (f := t5508) (a := t1) (u := t1) (v := t1) pv5508 (aw (ri t1)) (refl t1)
theorem pv5483 : R t5483 t1 := result (f := t5481) (a := t1) (u := t5481) (v := t5509) (refl t5481) (awb t5353 t1 t1 t1 (cI)) pv5509
theorem pv5507 : R t5507 t1 := result (f := t28) (a := t5483) (u := t1) (v := t5483) pv28 (aw (ri t5483)) pv5483
theorem pv5503 : R t5503 t1 := result (f := t5502) (a := t1) (u := t5505) (v := t5507) pv5502 (awb t1 t5483 t1 t1 (cI)) pv5507
theorem pv5497 : R t5497 t1 := result (f := t5495) (a := t1) (u := t5495) (v := t5503) (refl t5495) (awb t5486 t1 t1 t1 (cI)) pv5503
theorem pv5501 : R t5501 t5500 := result (f := t5497) (a := t5500) (u := t1) (v := t5500) pv5497 (aw (ri t5500)) (refl t5500)
theorem pv5498 : R t5498 t5500 := result (f := t0) (a := t5497) (u := t0) (v := t5501) (refl t0) (aw (rh t5497)) pv5501
theorem pv5511 : R t5511 t5510 := result (f := t5497) (a := t5510) (u := t1) (v := t5510) pv5497 (aw (ri t5510)) (refl t5510)
theorem pv5499 : R t5499 t5510 := result (f := t5498) (a := t5483) (u := t5500) (v := t5511) pv5498 (aw (ra t5497 t5483)) pv5511
theorem pv5496 : R t5496 t5510 := result (f := t5486) (a := t5495) (u := t5486) (v := t5499) (refl t5486) (awb t0 t5483 t5495 t5497 (refl _)) pv5499
theorem pv5490 : R t5490 t5510 := result (f := t5488) (a := t1) (u := t5488) (v := t5496) (refl t5488) (aw (ra t5486 t1)) pv5496
theorem pv5522 : R t5522 t1 := result (f := t5497) (a := t1) (u := t1) (v := t1) pv5497 (aw (ri t1)) (refl t1)
theorem pv5523 : R t5523 t1 := result (f := t5522) (a := t5483) (u := t1) (v := t5483) pv5522 (aw (ri t5483)) pv5483
theorem pv5520 : R t5520 t1 := result (f := t5490) (a := t1) (u := t5510) (v := t5523) pv5490 (awb t5497 t5483 t1 t1 (cI)) pv5523
theorem pv5521 : R t5521 t1 := result (f := t5520) (a := t1) (u := t1) (v := t1) pv5520 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
