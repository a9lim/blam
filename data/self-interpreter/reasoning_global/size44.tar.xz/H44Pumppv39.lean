import H44Pumppv38
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2796 : R t2796 t2790 := result (f := t2794) (a := t1) (u := t2794) (v := t2802) (refl t2794) (aw (ra t2792 t1)) pv2802
theorem pv2922 : R t2922 t2921 := result (f := t1) (a := t2921) (u := t1) (v := t2921) (refl t1) (aw (ri t2921)) (refl t2921)
theorem pv2920 : R t2920 t2921 := result (f := t22) (a := t2899) (u := t24) (v := t2922) pv22 (aw (ra t1 t2899)) pv2922
theorem pv2918 : R t2918 t2921 := result (f := t2902) (a := t1) (u := t2902) (v := t2920) (refl t2902) (awb t0 t2899 t1 t1 (cI)) pv2920
theorem pv2949 : R t2949 t2948 := result (f := t1) (a := t2948) (u := t1) (v := t2948) (refl t1) (aw (ri t2948)) (refl t2948)
theorem pv2947 : R t2947 t2948 := result (f := t22) (a := t2926) (u := t24) (v := t2949) pv22 (aw (ra t1 t2926)) pv2949
theorem pv2945 : R t2945 t2948 := result (f := t2929) (a := t1) (u := t2929) (v := t2947) (refl t2929) (awb t0 t2926 t1 t1 (cI)) pv2947
theorem pv2951 : R t2951 t1 := result (f := t2796) (a := t1) (u := t2790) (v := t2868) pv2796 (awb t2 t2787 t1 t1 (cI)) pv2868
theorem pv2952 : R t2952 t1 := result (f := t2951) (a := t1) (u := t1) (v := t1) pv2951 (aw (ri t1)) (refl t1)
theorem pv2926 : R t2926 t1 := result (f := t2924) (a := t1) (u := t2924) (v := t2952) (refl t2924) (awb t2796 t1 t1 t1 (cI)) pv2952
theorem pv2950 : R t2950 t1 := result (f := t28) (a := t2926) (u := t1) (v := t2926) pv28 (aw (ri t2926)) pv2926
theorem pv2946 : R t2946 t1 := result (f := t2945) (a := t1) (u := t2948) (v := t2950) pv2945 (awb t1 t2926 t1 t1 (cI)) pv2950
theorem pv2940 : R t2940 t1 := result (f := t2938) (a := t1) (u := t2938) (v := t2946) (refl t2938) (awb t2929 t1 t1 t1 (cI)) pv2946
theorem pv2944 : R t2944 t2943 := result (f := t2940) (a := t2943) (u := t1) (v := t2943) pv2940 (aw (ri t2943)) (refl t2943)
theorem pv2941 : R t2941 t2943 := result (f := t0) (a := t2940) (u := t0) (v := t2944) (refl t0) (aw (rh t2940)) pv2944
theorem pv2954 : R t2954 t2953 := result (f := t2940) (a := t2953) (u := t1) (v := t2953) pv2940 (aw (ri t2953)) (refl t2953)
theorem pv2942 : R t2942 t2953 := result (f := t2941) (a := t2926) (u := t2943) (v := t2954) pv2941 (aw (ra t2940 t2926)) pv2954
theorem pv2939 : R t2939 t2953 := result (f := t2929) (a := t2938) (u := t2929) (v := t2942) (refl t2929) (awb t0 t2926 t2938 t2940 (refl _)) pv2942
theorem pv2933 : R t2933 t2953 := result (f := t2931) (a := t1) (u := t2931) (v := t2939) (refl t2931) (aw (ra t2929 t1)) pv2939
theorem pv2965 : R t2965 t1 := result (f := t2940) (a := t1) (u := t1) (v := t1) pv2940 (aw (ri t1)) (refl t1)
theorem pv2966 : R t2966 t1 := result (f := t2965) (a := t2926) (u := t1) (v := t2926) pv2965 (aw (ri t2926)) pv2926
theorem pv2963 : R t2963 t1 := result (f := t2933) (a := t1) (u := t2953) (v := t2966) pv2933 (awb t2940 t2926 t1 t1 (cI)) pv2966
theorem pv2964 : R t2964 t1 := result (f := t2963) (a := t1) (u := t1) (v := t1) pv2963 (aw (ri t1)) (refl t1)
theorem pv2960 : R t2960 t1 := result (f := t2958) (a := t1) (u := t2958) (v := t2964) (refl t2958) (awb t2933 t1 t1 t1 (cI)) pv2964
theorem pv2961 : R t2961 t1 := result (f := t2940) (a := t2960) (u := t1) (v := t2960) pv2940 (aw (ri t2960)) pv2960
theorem pv2962 : R t2962 t1 := result (f := t2961) (a := t2926) (u := t1) (v := t2926) pv2961 (aw (ri t2926)) pv2926
theorem pv2959 : R t2959 t1 := result (f := t2933) (a := t2958) (u := t2953) (v := t2962) pv2933 (awb t2940 t2926 t2958 t2960 (refl _)) pv2962
theorem pv2955 : R t2955 t1 := result (f := t2936) (a := t1) (u := t2936) (v := t2959) (refl t2936) (aw (ra t2933 t1)) pv2959
theorem pv2956 : R t2956 t1 := result (f := t2940) (a := t2955) (u := t1) (v := t2955) pv2940 (aw (ri t2955)) pv2955
theorem pv2957 : R t2957 t1 := result (f := t2956) (a := t2926) (u := t1) (v := t2926) pv2956 (aw (ri t2926)) pv2926
theorem pv2937 : R t2937 t1 := result (f := t2933) (a := t2936) (u := t2953) (v := t2957) pv2933 (awb t2940 t2926 t2936 t2955 (refl _)) pv2957
theorem pv2934 : R t2934 t1 := result (f := t0) (a := t2933) (u := t0) (v := t2937) (refl t0) (aw (rh t2933)) pv2937
theorem pv2935 : R t2935 t1 := result (f := t2934) (a := t2926) (u := t1) (v := t2926) pv2934 (aw (ri t2926)) pv2926
theorem pv2932 : R t2932 t1 := result (f := t2929) (a := t2931) (u := t2929) (v := t2935) (refl t2929) (awb t0 t2926 t2931 t2933 (refl _)) pv2935
theorem pv2930 : R t2930 t1 := result (f := t0) (a := t2929) (u := t0) (v := t2932) (refl t0) (aw (rh t2929)) pv2932
theorem pv2927 : R t2927 t1 := result (f := t2) (a := t2926) (u := t2) (v := t2930) (refl t2) (aw (ra t0 t2926)) pv2930
theorem pv2928 : R t2928 t1 := result (f := t2927) (a := t2787) (u := t1) (v := t2787) pv2927 (aw (ri t2787)) pv2787
theorem pv2925 : R t2925 t1 := result (f := t2796) (a := t2924) (u := t2790) (v := t2928) pv2796 (awb t2 t2787 t2924 t2926 (refl _)) pv2928
theorem pv2899 : R t2899 t1 := result (f := t2799) (a := t1) (u := t2799) (v := t2925) (refl t2799) (aw (ra t2796 t1)) pv2925
theorem pv2923 : R t2923 t1 := result (f := t28) (a := t2899) (u := t1) (v := t2899) pv28 (aw (ri t2899)) pv2899
theorem pv2919 : R t2919 t1 := result (f := t2918) (a := t1) (u := t2921) (v := t2923) pv2918 (awb t1 t2899 t1 t1 (cI)) pv2923
theorem pv2913 : R t2913 t1 := result (f := t2911) (a := t1) (u := t2911) (v := t2919) (refl t2911) (awb t2902 t1 t1 t1 (cI)) pv2919
theorem pv2917 : R t2917 t2916 := result (f := t2913) (a := t2916) (u := t1) (v := t2916) pv2913 (aw (ri t2916)) (refl t2916)
theorem pv2914 : R t2914 t2916 := result (f := t0) (a := t2913) (u := t0) (v := t2917) (refl t0) (aw (rh t2913)) pv2917
theorem pv2968 : R t2968 t2967 := result (f := t2913) (a := t2967) (u := t1) (v := t2967) pv2913 (aw (ri t2967)) (refl t2967)
theorem pv2915 : R t2915 t2967 := result (f := t2914) (a := t2899) (u := t2916) (v := t2968) pv2914 (aw (ra t2913 t2899)) pv2968
theorem pv2912 : R t2912 t2967 := result (f := t2902) (a := t2911) (u := t2902) (v := t2915) (refl t2902) (awb t0 t2899 t2911 t2913 (refl _)) pv2915
theorem pv2906 : R t2906 t2967 := result (f := t2904) (a := t1) (u := t2904) (v := t2912) (refl t2904) (aw (ra t2902 t1)) pv2912
theorem pv2979 : R t2979 t1 := result (f := t2913) (a := t1) (u := t1) (v := t1) pv2913 (aw (ri t1)) (refl t1)
theorem pv2980 : R t2980 t1 := result (f := t2979) (a := t2899) (u := t1) (v := t2899) pv2979 (aw (ri t2899)) pv2899
theorem pv2977 : R t2977 t1 := result (f := t2906) (a := t1) (u := t2967) (v := t2980) pv2906 (awb t2913 t2899 t1 t1 (cI)) pv2980
theorem pv2978 : R t2978 t1 := result (f := t2977) (a := t1) (u := t1) (v := t1) pv2977 (aw (ri t1)) (refl t1)
theorem pv2974 : R t2974 t1 := result (f := t2972) (a := t1) (u := t2972) (v := t2978) (refl t2972) (awb t2906 t1 t1 t1 (cI)) pv2978
theorem pv2975 : R t2975 t1 := result (f := t2913) (a := t2974) (u := t1) (v := t2974) pv2913 (aw (ri t2974)) pv2974
theorem pv2976 : R t2976 t1 := result (f := t2975) (a := t2899) (u := t1) (v := t2899) pv2975 (aw (ri t2899)) pv2899
end Blc.H44.Pump
