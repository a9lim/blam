import H44Pumppv111
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv8056 : R t8056 t1 := result (f := t8040) (a := t8055) (u := t1) (v := t8055) pv8040 (aw (ri t8055)) pv8055
theorem pv8057 : R t8057 t1 := result (f := t8056) (a := t8026) (u := t1) (v := t8026) pv8056 (aw (ri t8026)) pv8026
theorem pv8037 : R t8037 t1 := result (f := t8033) (a := t8036) (u := t8053) (v := t8057) pv8033 (awb t8040 t8026 t8036 t8055 (refl _)) pv8057
theorem pv8034 : R t8034 t1 := result (f := t0) (a := t8033) (u := t0) (v := t8037) (refl t0) (aw (rh t8033)) pv8037
theorem pv8035 : R t8035 t1 := result (f := t8034) (a := t8026) (u := t1) (v := t8026) pv8034 (aw (ri t8026)) pv8026
theorem pv8032 : R t8032 t1 := result (f := t8029) (a := t8031) (u := t8029) (v := t8035) (refl t8029) (awb t0 t8026 t8031 t8033 (refl _)) pv8035
theorem pv8030 : R t8030 t1 := result (f := t0) (a := t8029) (u := t0) (v := t8032) (refl t0) (aw (rh t8029)) pv8032
theorem pv8027 : R t8027 t1 := result (f := t2) (a := t8026) (u := t2) (v := t8030) (refl t2) (aw (ra t0 t8026)) pv8030
theorem pv8028 : R t8028 t1 := result (f := t8027) (a := t7887) (u := t1) (v := t7887) pv8027 (aw (ri t7887)) pv7887
theorem pv8025 : R t8025 t1 := result (f := t7896) (a := t8024) (u := t7890) (v := t8028) pv7896 (awb t2 t7887 t8024 t8026 (refl _)) pv8028
theorem pv7999 : R t7999 t1 := result (f := t7899) (a := t1) (u := t7899) (v := t8025) (refl t7899) (aw (ra t7896 t1)) pv8025
theorem pv8023 : R t8023 t1 := result (f := t28) (a := t7999) (u := t1) (v := t7999) pv28 (aw (ri t7999)) pv7999
theorem pv8019 : R t8019 t1 := result (f := t8018) (a := t1) (u := t8021) (v := t8023) pv8018 (awb t1 t7999 t1 t1 (cI)) pv8023
theorem pv8013 : R t8013 t1 := result (f := t8011) (a := t1) (u := t8011) (v := t8019) (refl t8011) (awb t8002 t1 t1 t1 (cI)) pv8019
theorem pv8017 : R t8017 t8016 := result (f := t8013) (a := t8016) (u := t1) (v := t8016) pv8013 (aw (ri t8016)) (refl t8016)
theorem pv8014 : R t8014 t8016 := result (f := t0) (a := t8013) (u := t0) (v := t8017) (refl t0) (aw (rh t8013)) pv8017
theorem pv8068 : R t8068 t8067 := result (f := t8013) (a := t8067) (u := t1) (v := t8067) pv8013 (aw (ri t8067)) (refl t8067)
theorem pv8015 : R t8015 t8067 := result (f := t8014) (a := t7999) (u := t8016) (v := t8068) pv8014 (aw (ra t8013 t7999)) pv8068
theorem pv8012 : R t8012 t8067 := result (f := t8002) (a := t8011) (u := t8002) (v := t8015) (refl t8002) (awb t0 t7999 t8011 t8013 (refl _)) pv8015
theorem pv8006 : R t8006 t8067 := result (f := t8004) (a := t1) (u := t8004) (v := t8012) (refl t8004) (aw (ra t8002 t1)) pv8012
theorem pv8079 : R t8079 t1 := result (f := t8013) (a := t1) (u := t1) (v := t1) pv8013 (aw (ri t1)) (refl t1)
theorem pv8080 : R t8080 t1 := result (f := t8079) (a := t7999) (u := t1) (v := t7999) pv8079 (aw (ri t7999)) pv7999
theorem pv8077 : R t8077 t1 := result (f := t8006) (a := t1) (u := t8067) (v := t8080) pv8006 (awb t8013 t7999 t1 t1 (cI)) pv8080
theorem pv8078 : R t8078 t1 := result (f := t8077) (a := t1) (u := t1) (v := t1) pv8077 (aw (ri t1)) (refl t1)
theorem pv8074 : R t8074 t1 := result (f := t8072) (a := t1) (u := t8072) (v := t8078) (refl t8072) (awb t8006 t1 t1 t1 (cI)) pv8078
theorem pv8075 : R t8075 t1 := result (f := t8013) (a := t8074) (u := t1) (v := t8074) pv8013 (aw (ri t8074)) pv8074
theorem pv8076 : R t8076 t1 := result (f := t8075) (a := t7999) (u := t1) (v := t7999) pv8075 (aw (ri t7999)) pv7999
theorem pv8073 : R t8073 t1 := result (f := t8006) (a := t8072) (u := t8067) (v := t8076) pv8006 (awb t8013 t7999 t8072 t8074 (refl _)) pv8076
theorem pv8069 : R t8069 t1 := result (f := t8009) (a := t1) (u := t8009) (v := t8073) (refl t8009) (aw (ra t8006 t1)) pv8073
theorem pv8070 : R t8070 t1 := result (f := t8013) (a := t8069) (u := t1) (v := t8069) pv8013 (aw (ri t8069)) pv8069
theorem pv8071 : R t8071 t1 := result (f := t8070) (a := t7999) (u := t1) (v := t7999) pv8070 (aw (ri t7999)) pv7999
theorem pv8010 : R t8010 t1 := result (f := t8006) (a := t8009) (u := t8067) (v := t8071) pv8006 (awb t8013 t7999 t8009 t8069 (refl _)) pv8071
theorem pv8007 : R t8007 t1 := result (f := t0) (a := t8006) (u := t0) (v := t8010) (refl t0) (aw (rh t8006)) pv8010
theorem pv8008 : R t8008 t1 := result (f := t8007) (a := t7999) (u := t1) (v := t7999) pv8007 (aw (ri t7999)) pv7999
theorem pv8005 : R t8005 t1 := result (f := t8002) (a := t8004) (u := t8002) (v := t8008) (refl t8002) (awb t0 t7999 t8004 t8006 (refl _)) pv8008
theorem pv8003 : R t8003 t1 := result (f := t0) (a := t8002) (u := t0) (v := t8005) (refl t0) (aw (rh t8002)) pv8005
theorem pv8000 : R t8000 t1 := result (f := t2) (a := t7999) (u := t2) (v := t8003) (refl t2) (aw (ra t0 t7999)) pv8003
theorem pv8001 : R t8001 t1 := result (f := t8000) (a := t7887) (u := t1) (v := t7887) pv8000 (aw (ri t7887)) pv7887
theorem pv7900 : R t7900 t1 := result (f := t7896) (a := t7899) (u := t7890) (v := t8001) pv7896 (awb t2 t7887 t7899 t7999 (refl _)) pv8001
theorem pv7897 : R t7897 t1 := result (f := t0) (a := t7896) (u := t0) (v := t7900) (refl t0) (aw (rh t7896)) pv7900
theorem pv7898 : R t7898 t7890 := result (f := t7897) (a := t7890) (u := t1) (v := t7890) pv7897 (aw (ri t7890)) (refl t7890)
theorem pv7895 : R t7895 t7890 := result (f := t7892) (a := t7894) (u := t7892) (v := t7898) (refl t7892) (awb t0 t7890 t7894 t7896 (refl _)) pv7898
theorem pv7893 : R t7893 t7890 := result (f := t0) (a := t7892) (u := t0) (v := t7895) (refl t0) (aw (rh t7892)) pv7895
theorem pv7891 : R t7891 t7890 := result (f := t2) (a := t7890) (u := t2) (v := t7893) (refl t2) (aw (ra t0 t7890)) pv7893
theorem pv7888 : R t7888 t7890 := result (f := t59) (a := t7887) (u := t46) (v := t7891) pv59 (aw (ra t2 t7887)) pv7891
theorem pv7889 : R t7889 t1 := result (f := t7888) (a := t1) (u := t7890) (v := t7968) pv7888 (awb t2 t7887 t1 t1 (cI)) pv7968
theorem pv7886 : R t7886 t1 := result (f := t7353) (a := t7885) (u := t149) (v := t7889) pv7353 (awb t59 t1 t7885 t7887 (refl _)) pv7889
theorem pv7803 : R t7803 t1 := result (f := t7356) (a := t1) (u := t7356) (v := t7886) (refl t7356) (aw (ra t7353 t1)) pv7886
theorem pv7884 : R t7884 t1 := result (f := t3) (a := t7803) (u := t1) (v := t7803) pv3 (aw (ri t7803)) pv7803
theorem pv7882 : R t7882 t1 := result (f := t7819) (a := t1) (u := t7806) (v := t7884) pv7819 (awb t2 t7803 t1 t1 (cI)) pv7884
theorem pv7883 : R t7883 t1 := result (f := t7882) (a := t1) (u := t1) (v := t1) pv7882 (aw (ri t1)) (refl t1)
theorem pv7857 : R t7857 t1 := result (f := t7855) (a := t1) (u := t7855) (v := t7883) (refl t7855) (awb t7819 t1 t1 t1 (cI)) pv7883
theorem pv7881 : R t7881 t1 := result (f := t28) (a := t7857) (u := t1) (v := t7857) pv28 (aw (ri t7857)) pv7857
theorem pv7877 : R t7877 t1 := result (f := t7876) (a := t1) (u := t7879) (v := t7881) pv7876 (awb t1 t7857 t1 t1 (cI)) pv7881
theorem pv7871 : R t7871 t1 := result (f := t7869) (a := t1) (u := t7869) (v := t7877) (refl t7869) (awb t7860 t1 t1 t1 (cI)) pv7877
end Blc.H44.Pump
