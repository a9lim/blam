import H44Pumppv24
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1418 : R t1418 t1 := result (f := t0) (a := t1417) (u := t0) (v := t1421) (refl t0) (aw (rh t1417)) pv1421
theorem pv1419 : R t1419 t149 := result (f := t1418) (a := t1403) (u := t1) (v := t1403) pv1418 (aw (ri t1403)) pv1403
theorem pv1416 : R t1416 t149 := result (f := t1406) (a := t1415) (u := t1406) (v := t1419) (refl t1406) (awb t0 t1403 t1415 t1417 (refl _)) pv1419
theorem pv1410 : R t1410 t149 := result (f := t1408) (a := t1) (u := t1408) (v := t1416) (refl t1408) (aw (ra t1406 t1)) pv1416
theorem pv1884 : R t1884 t1883 := result (f := t1) (a := t1883) (u := t1) (v := t1883) (refl t1) (aw (ri t1883)) (refl t1883)
theorem pv1882 : R t1882 t1883 := result (f := t22) (a := t1862) (u := t24) (v := t1884) pv22 (aw (ra t1 t1862)) pv1884
theorem pv1880 : R t1880 t1883 := result (f := t1864) (a := t1) (u := t1864) (v := t1882) (refl t1864) (awb t0 t1862 t1 t1 (cI)) pv1882
theorem pv1885 : R t1885 t1862 := result (f := t28) (a := t1862) (u := t1) (v := t1862) pv28 (aw (ri t1862)) (refl t1862)
theorem pv1881 : R t1881 t1862 := result (f := t1880) (a := t1) (u := t1883) (v := t1885) pv1880 (awb t1 t1862 t1 t1 (cI)) pv1885
theorem pv1875 : R t1875 t1862 := result (f := t1873) (a := t1) (u := t1873) (v := t1881) (refl t1873) (awb t1864 t1 t1 t1 (cI)) pv1881
theorem pv1909 : R t1909 t1908 := result (f := t1) (a := t1908) (u := t1) (v := t1908) (refl t1) (aw (ri t1908)) (refl t1908)
theorem pv1907 : R t1907 t1908 := result (f := t22) (a := t1886) (u := t24) (v := t1909) pv22 (aw (ra t1 t1886)) pv1909
theorem pv1905 : R t1905 t1908 := result (f := t1889) (a := t1) (u := t1889) (v := t1907) (refl t1889) (awb t0 t1886 t1 t1 (cI)) pv1907
theorem pv1936 : R t1936 t1935 := result (f := t1) (a := t1935) (u := t1) (v := t1935) (refl t1) (aw (ri t1935)) (refl t1935)
theorem pv1934 : R t1934 t1935 := result (f := t22) (a := t1913) (u := t24) (v := t1936) pv22 (aw (ra t1 t1913)) pv1936
theorem pv1932 : R t1932 t1935 := result (f := t1916) (a := t1) (u := t1916) (v := t1934) (refl t1916) (awb t0 t1913 t1 t1 (cI)) pv1934
theorem pv1968 : R t1968 t1967 := result (f := t1) (a := t1967) (u := t1) (v := t1967) (refl t1) (aw (ri t1967)) (refl t1967)
theorem pv1966 : R t1966 t1967 := result (f := t22) (a := t1946) (u := t24) (v := t1968) pv22 (aw (ra t1 t1946)) pv1968
theorem pv1964 : R t1964 t1967 := result (f := t1948) (a := t1) (u := t1948) (v := t1966) (refl t1948) (awb t0 t1946 t1 t1 (cI)) pv1966
theorem pv1969 : R t1969 t1946 := result (f := t28) (a := t1946) (u := t1) (v := t1946) pv28 (aw (ri t1946)) (refl t1946)
theorem pv1965 : R t1965 t1946 := result (f := t1964) (a := t1) (u := t1967) (v := t1969) pv1964 (awb t1 t1946 t1 t1 (cI)) pv1969
theorem pv1959 : R t1959 t1946 := result (f := t1957) (a := t1) (u := t1957) (v := t1965) (refl t1957) (awb t1948 t1 t1 t1 (cI)) pv1965
theorem pv1993 : R t1993 t1992 := result (f := t1) (a := t1992) (u := t1) (v := t1992) (refl t1) (aw (ri t1992)) (refl t1992)
theorem pv1991 : R t1991 t1992 := result (f := t22) (a := t1970) (u := t24) (v := t1993) pv22 (aw (ra t1 t1970)) pv1993
theorem pv1989 : R t1989 t1992 := result (f := t1973) (a := t1) (u := t1973) (v := t1991) (refl t1973) (awb t0 t1970 t1 t1 (cI)) pv1991
theorem pv2020 : R t2020 t2019 := result (f := t1) (a := t2019) (u := t1) (v := t2019) (refl t1) (aw (ri t2019)) (refl t2019)
theorem pv2018 : R t2018 t2019 := result (f := t22) (a := t1997) (u := t24) (v := t2020) pv22 (aw (ra t1 t1997)) pv2020
theorem pv2016 : R t2016 t2019 := result (f := t2000) (a := t1) (u := t2000) (v := t2018) (refl t2000) (awb t0 t1997 t1 t1 (cI)) pv2018
theorem pv2025 : R t2025 t1 := result (f := t1410) (a := t1) (u := t149) (v := t231) pv1410 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv2026 : R t2026 t1 := result (f := t2025) (a := t1) (u := t1) (v := t1) pv2025 (aw (ri t1)) (refl t1)
theorem pv1943 : R t1943 t1 := result (f := t1941) (a := t1) (u := t1941) (v := t2026) (refl t1941) (awb t1410 t1 t1 t1 (cI)) pv2026
theorem pv2024 : R t2024 t1 := result (f := t3) (a := t1943) (u := t1) (v := t1943) pv3 (aw (ri t1943)) pv1943
theorem pv2022 : R t2022 t1 := result (f := t1959) (a := t1) (u := t1946) (v := t2024) pv1959 (awb t2 t1943 t1 t1 (cI)) pv2024
theorem pv2023 : R t2023 t1 := result (f := t2022) (a := t1) (u := t1) (v := t1) pv2022 (aw (ri t1)) (refl t1)
theorem pv1997 : R t1997 t1 := result (f := t1995) (a := t1) (u := t1995) (v := t2023) (refl t1995) (awb t1959 t1 t1 t1 (cI)) pv2023
theorem pv2021 : R t2021 t1 := result (f := t28) (a := t1997) (u := t1) (v := t1997) pv28 (aw (ri t1997)) pv1997
theorem pv2017 : R t2017 t1 := result (f := t2016) (a := t1) (u := t2019) (v := t2021) pv2016 (awb t1 t1997 t1 t1 (cI)) pv2021
theorem pv2011 : R t2011 t1 := result (f := t2009) (a := t1) (u := t2009) (v := t2017) (refl t2009) (awb t2000 t1 t1 t1 (cI)) pv2017
theorem pv2015 : R t2015 t2014 := result (f := t2011) (a := t2014) (u := t1) (v := t2014) pv2011 (aw (ri t2014)) (refl t2014)
theorem pv2012 : R t2012 t2014 := result (f := t0) (a := t2011) (u := t0) (v := t2015) (refl t0) (aw (rh t2011)) pv2015
theorem pv2028 : R t2028 t2027 := result (f := t2011) (a := t2027) (u := t1) (v := t2027) pv2011 (aw (ri t2027)) (refl t2027)
theorem pv2013 : R t2013 t2027 := result (f := t2012) (a := t1997) (u := t2014) (v := t2028) pv2012 (aw (ra t2011 t1997)) pv2028
theorem pv2010 : R t2010 t2027 := result (f := t2000) (a := t2009) (u := t2000) (v := t2013) (refl t2000) (awb t0 t1997 t2009 t2011 (refl _)) pv2013
theorem pv2004 : R t2004 t2027 := result (f := t2002) (a := t1) (u := t2002) (v := t2010) (refl t2002) (aw (ra t2000 t1)) pv2010
theorem pv2039 : R t2039 t1 := result (f := t2011) (a := t1) (u := t1) (v := t1) pv2011 (aw (ri t1)) (refl t1)
theorem pv2040 : R t2040 t1 := result (f := t2039) (a := t1997) (u := t1) (v := t1997) pv2039 (aw (ri t1997)) pv1997
theorem pv2037 : R t2037 t1 := result (f := t2004) (a := t1) (u := t2027) (v := t2040) pv2004 (awb t2011 t1997 t1 t1 (cI)) pv2040
theorem pv2038 : R t2038 t1 := result (f := t2037) (a := t1) (u := t1) (v := t1) pv2037 (aw (ri t1)) (refl t1)
theorem pv2034 : R t2034 t1 := result (f := t2032) (a := t1) (u := t2032) (v := t2038) (refl t2032) (awb t2004 t1 t1 t1 (cI)) pv2038
theorem pv2035 : R t2035 t1 := result (f := t2011) (a := t2034) (u := t1) (v := t2034) pv2011 (aw (ri t2034)) pv2034
theorem pv2036 : R t2036 t1 := result (f := t2035) (a := t1997) (u := t1) (v := t1997) pv2035 (aw (ri t1997)) pv1997
theorem pv2033 : R t2033 t1 := result (f := t2004) (a := t2032) (u := t2027) (v := t2036) pv2004 (awb t2011 t1997 t2032 t2034 (refl _)) pv2036
theorem pv2029 : R t2029 t1 := result (f := t2007) (a := t1) (u := t2007) (v := t2033) (refl t2007) (aw (ra t2004 t1)) pv2033
theorem pv2030 : R t2030 t1 := result (f := t2011) (a := t2029) (u := t1) (v := t2029) pv2011 (aw (ri t2029)) pv2029
theorem pv2031 : R t2031 t1 := result (f := t2030) (a := t1997) (u := t1) (v := t1997) pv2030 (aw (ri t1997)) pv1997
end Blc.H44.Pump
