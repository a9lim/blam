import H44Pumppv64
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv4486 : R t4486 t4694 := result (f := t4485) (a := t4470) (u := t4487) (v := t4695) pv4485 (aw (ra t4484 t4470)) pv4695
theorem pv4483 : R t4483 t4694 := result (f := t4473) (a := t4482) (u := t4473) (v := t4486) (refl t4473) (awb t0 t4470 t4482 t4484 (refl _)) pv4486
theorem pv4477 : R t4477 t4694 := result (f := t4475) (a := t1) (u := t4475) (v := t4483) (refl t4475) (aw (ra t4473 t1)) pv4483
theorem pv4706 : R t4706 t1 := result (f := t4484) (a := t1) (u := t1) (v := t1) pv4484 (aw (ri t1)) (refl t1)
theorem pv4707 : R t4707 t1 := result (f := t4706) (a := t4470) (u := t1) (v := t4470) pv4706 (aw (ri t4470)) pv4470
theorem pv4704 : R t4704 t1 := result (f := t4477) (a := t1) (u := t4694) (v := t4707) pv4477 (awb t4484 t4470 t1 t1 (cI)) pv4707
theorem pv4705 : R t4705 t1 := result (f := t4704) (a := t1) (u := t1) (v := t1) pv4704 (aw (ri t1)) (refl t1)
theorem pv4701 : R t4701 t1 := result (f := t4699) (a := t1) (u := t4699) (v := t4705) (refl t4699) (awb t4477 t1 t1 t1 (cI)) pv4705
theorem pv4702 : R t4702 t1 := result (f := t4484) (a := t4701) (u := t1) (v := t4701) pv4484 (aw (ri t4701)) pv4701
theorem pv4703 : R t4703 t1 := result (f := t4702) (a := t4470) (u := t1) (v := t4470) pv4702 (aw (ri t4470)) pv4470
theorem pv4700 : R t4700 t1 := result (f := t4477) (a := t4699) (u := t4694) (v := t4703) pv4477 (awb t4484 t4470 t4699 t4701 (refl _)) pv4703
theorem pv4696 : R t4696 t1 := result (f := t4480) (a := t1) (u := t4480) (v := t4700) (refl t4480) (aw (ra t4477 t1)) pv4700
theorem pv4697 : R t4697 t1 := result (f := t4484) (a := t4696) (u := t1) (v := t4696) pv4484 (aw (ri t4696)) pv4696
theorem pv4698 : R t4698 t1 := result (f := t4697) (a := t4470) (u := t1) (v := t4470) pv4697 (aw (ri t4470)) pv4470
theorem pv4481 : R t4481 t1 := result (f := t4477) (a := t4480) (u := t4694) (v := t4698) pv4477 (awb t4484 t4470 t4480 t4696 (refl _)) pv4698
theorem pv4478 : R t4478 t1 := result (f := t0) (a := t4477) (u := t0) (v := t4481) (refl t0) (aw (rh t4477)) pv4481
theorem pv4479 : R t4479 t1 := result (f := t4478) (a := t4470) (u := t1) (v := t4470) pv4478 (aw (ri t4470)) pv4470
theorem pv4476 : R t4476 t1 := result (f := t4473) (a := t4475) (u := t4473) (v := t4479) (refl t4473) (awb t0 t4470 t4475 t4477 (refl _)) pv4479
theorem pv4474 : R t4474 t1 := result (f := t0) (a := t4473) (u := t0) (v := t4476) (refl t0) (aw (rh t4473)) pv4476
theorem pv4471 : R t4471 t1 := result (f := t2) (a := t4470) (u := t2) (v := t4474) (refl t2) (aw (ra t0 t4470)) pv4474
theorem pv4472 : R t4472 t1 := result (f := t4471) (a := t4416) (u := t1) (v := t4416) pv4471 (aw (ri t4416)) pv4416
theorem pv4469 : R t4469 t1 := result (f := t4432) (a := t4468) (u := t4419) (v := t4472) pv4432 (awb t2 t4416 t4468 t4470 (refl _)) pv4472
theorem pv4443 : R t4443 t1 := result (f := t4435) (a := t1) (u := t4435) (v := t4469) (refl t4435) (aw (ra t4432 t1)) pv4469
theorem pv4467 : R t4467 t1 := result (f := t28) (a := t4443) (u := t1) (v := t4443) pv28 (aw (ri t4443)) pv4443
theorem pv4463 : R t4463 t1 := result (f := t4462) (a := t1) (u := t4465) (v := t4467) pv4462 (awb t1 t4443 t1 t1 (cI)) pv4467
theorem pv4457 : R t4457 t1 := result (f := t4455) (a := t1) (u := t4455) (v := t4463) (refl t4455) (awb t4446 t1 t1 t1 (cI)) pv4463
theorem pv4461 : R t4461 t4460 := result (f := t4457) (a := t4460) (u := t1) (v := t4460) pv4457 (aw (ri t4460)) (refl t4460)
theorem pv4458 : R t4458 t4460 := result (f := t0) (a := t4457) (u := t0) (v := t4461) (refl t0) (aw (rh t4457)) pv4461
theorem pv4709 : R t4709 t4708 := result (f := t4457) (a := t4708) (u := t1) (v := t4708) pv4457 (aw (ri t4708)) (refl t4708)
theorem pv4459 : R t4459 t4708 := result (f := t4458) (a := t4443) (u := t4460) (v := t4709) pv4458 (aw (ra t4457 t4443)) pv4709
theorem pv4456 : R t4456 t4708 := result (f := t4446) (a := t4455) (u := t4446) (v := t4459) (refl t4446) (awb t0 t4443 t4455 t4457 (refl _)) pv4459
theorem pv4450 : R t4450 t4708 := result (f := t4448) (a := t1) (u := t4448) (v := t4456) (refl t4448) (aw (ra t4446 t1)) pv4456
theorem pv4720 : R t4720 t1 := result (f := t4457) (a := t1) (u := t1) (v := t1) pv4457 (aw (ri t1)) (refl t1)
theorem pv4721 : R t4721 t1 := result (f := t4720) (a := t4443) (u := t1) (v := t4443) pv4720 (aw (ri t4443)) pv4443
theorem pv4718 : R t4718 t1 := result (f := t4450) (a := t1) (u := t4708) (v := t4721) pv4450 (awb t4457 t4443 t1 t1 (cI)) pv4721
theorem pv4719 : R t4719 t1 := result (f := t4718) (a := t1) (u := t1) (v := t1) pv4718 (aw (ri t1)) (refl t1)
theorem pv4715 : R t4715 t1 := result (f := t4713) (a := t1) (u := t4713) (v := t4719) (refl t4713) (awb t4450 t1 t1 t1 (cI)) pv4719
theorem pv4716 : R t4716 t1 := result (f := t4457) (a := t4715) (u := t1) (v := t4715) pv4457 (aw (ri t4715)) pv4715
theorem pv4717 : R t4717 t1 := result (f := t4716) (a := t4443) (u := t1) (v := t4443) pv4716 (aw (ri t4443)) pv4443
theorem pv4714 : R t4714 t1 := result (f := t4450) (a := t4713) (u := t4708) (v := t4717) pv4450 (awb t4457 t4443 t4713 t4715 (refl _)) pv4717
theorem pv4710 : R t4710 t1 := result (f := t4453) (a := t1) (u := t4453) (v := t4714) (refl t4453) (aw (ra t4450 t1)) pv4714
theorem pv4711 : R t4711 t1 := result (f := t4457) (a := t4710) (u := t1) (v := t4710) pv4457 (aw (ri t4710)) pv4710
theorem pv4712 : R t4712 t1 := result (f := t4711) (a := t4443) (u := t1) (v := t4443) pv4711 (aw (ri t4443)) pv4443
theorem pv4454 : R t4454 t1 := result (f := t4450) (a := t4453) (u := t4708) (v := t4712) pv4450 (awb t4457 t4443 t4453 t4710 (refl _)) pv4712
theorem pv4451 : R t4451 t1 := result (f := t0) (a := t4450) (u := t0) (v := t4454) (refl t0) (aw (rh t4450)) pv4454
theorem pv4452 : R t4452 t1 := result (f := t4451) (a := t4443) (u := t1) (v := t4443) pv4451 (aw (ri t4443)) pv4443
theorem pv4449 : R t4449 t1 := result (f := t4446) (a := t4448) (u := t4446) (v := t4452) (refl t4446) (awb t0 t4443 t4448 t4450 (refl _)) pv4452
theorem pv4447 : R t4447 t1 := result (f := t0) (a := t4446) (u := t0) (v := t4449) (refl t0) (aw (rh t4446)) pv4449
theorem pv4444 : R t4444 t1 := result (f := t2) (a := t4443) (u := t2) (v := t4447) (refl t2) (aw (ra t0 t4443)) pv4447
theorem pv4445 : R t4445 t1 := result (f := t4444) (a := t4416) (u := t1) (v := t4416) pv4444 (aw (ri t4416)) pv4416
theorem pv4436 : R t4436 t1 := result (f := t4432) (a := t4435) (u := t4419) (v := t4445) pv4432 (awb t2 t4416 t4435 t4443 (refl _)) pv4445
theorem pv4433 : R t4433 t1 := result (f := t0) (a := t4432) (u := t0) (v := t4436) (refl t0) (aw (rh t4432)) pv4436
theorem pv4434 : R t4434 t4419 := result (f := t4433) (a := t4419) (u := t1) (v := t4419) pv4433 (aw (ri t4419)) (refl t4419)
theorem pv4431 : R t4431 t4419 := result (f := t4421) (a := t4430) (u := t4421) (v := t4434) (refl t4421) (awb t0 t4419 t4430 t4432 (refl _)) pv4434
theorem pv4425 : R t4425 t4419 := result (f := t4423) (a := t1) (u := t4423) (v := t4431) (refl t4423) (aw (ra t4421 t1)) pv4431
end Blc.H44.Pump
