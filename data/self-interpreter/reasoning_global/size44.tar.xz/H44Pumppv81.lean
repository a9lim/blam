import H44Pumppv80
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5842 : R t5842 t5841 := result (f := t5838) (a := t5841) (u := t1) (v := t5841) pv5838 (aw (ri t5841)) (refl t5841)
theorem pv5839 : R t5839 t5841 := result (f := t0) (a := t5838) (u := t0) (v := t5842) (refl t0) (aw (rh t5838)) pv5842
theorem pv5855 : R t5855 t5854 := result (f := t5838) (a := t5854) (u := t1) (v := t5854) pv5838 (aw (ri t5854)) (refl t5854)
theorem pv5840 : R t5840 t5854 := result (f := t5839) (a := t5824) (u := t5841) (v := t5855) pv5839 (aw (ra t5838 t5824)) pv5855
theorem pv5837 : R t5837 t5854 := result (f := t5827) (a := t5836) (u := t5827) (v := t5840) (refl t5827) (awb t0 t5824 t5836 t5838 (refl _)) pv5840
theorem pv5831 : R t5831 t5854 := result (f := t5829) (a := t1) (u := t5829) (v := t5837) (refl t5829) (aw (ra t5827 t1)) pv5837
theorem pv5866 : R t5866 t1 := result (f := t5838) (a := t1) (u := t1) (v := t1) pv5838 (aw (ri t1)) (refl t1)
theorem pv5867 : R t5867 t1 := result (f := t5866) (a := t5824) (u := t1) (v := t5824) pv5866 (aw (ri t5824)) pv5824
theorem pv5864 : R t5864 t1 := result (f := t5831) (a := t1) (u := t5854) (v := t5867) pv5831 (awb t5838 t5824 t1 t1 (cI)) pv5867
theorem pv5865 : R t5865 t1 := result (f := t5864) (a := t1) (u := t1) (v := t1) pv5864 (aw (ri t1)) (refl t1)
theorem pv5861 : R t5861 t1 := result (f := t5859) (a := t1) (u := t5859) (v := t5865) (refl t5859) (awb t5831 t1 t1 t1 (cI)) pv5865
theorem pv5862 : R t5862 t1 := result (f := t5838) (a := t5861) (u := t1) (v := t5861) pv5838 (aw (ri t5861)) pv5861
theorem pv5863 : R t5863 t1 := result (f := t5862) (a := t5824) (u := t1) (v := t5824) pv5862 (aw (ri t5824)) pv5824
theorem pv5860 : R t5860 t1 := result (f := t5831) (a := t5859) (u := t5854) (v := t5863) pv5831 (awb t5838 t5824 t5859 t5861 (refl _)) pv5863
theorem pv5856 : R t5856 t1 := result (f := t5834) (a := t1) (u := t5834) (v := t5860) (refl t5834) (aw (ra t5831 t1)) pv5860
theorem pv5857 : R t5857 t1 := result (f := t5838) (a := t5856) (u := t1) (v := t5856) pv5838 (aw (ri t5856)) pv5856
theorem pv5858 : R t5858 t1 := result (f := t5857) (a := t5824) (u := t1) (v := t5824) pv5857 (aw (ri t5824)) pv5824
theorem pv5835 : R t5835 t1 := result (f := t5831) (a := t5834) (u := t5854) (v := t5858) pv5831 (awb t5838 t5824 t5834 t5856 (refl _)) pv5858
theorem pv5832 : R t5832 t1 := result (f := t0) (a := t5831) (u := t0) (v := t5835) (refl t0) (aw (rh t5831)) pv5835
theorem pv5833 : R t5833 t1 := result (f := t5832) (a := t5824) (u := t1) (v := t5824) pv5832 (aw (ri t5824)) pv5824
theorem pv5830 : R t5830 t1 := result (f := t5827) (a := t5829) (u := t5827) (v := t5833) (refl t5827) (awb t0 t5824 t5829 t5831 (refl _)) pv5833
theorem pv5828 : R t5828 t1 := result (f := t0) (a := t5827) (u := t0) (v := t5830) (refl t0) (aw (rh t5827)) pv5830
theorem pv5825 : R t5825 t1 := result (f := t2) (a := t5824) (u := t2) (v := t5828) (refl t2) (aw (ra t0 t5824)) pv5828
theorem pv5826 : R t5826 t1 := result (f := t5825) (a := t5770) (u := t1) (v := t5770) pv5825 (aw (ri t5770)) pv5770
theorem pv5823 : R t5823 t1 := result (f := t5786) (a := t5822) (u := t5773) (v := t5826) pv5786 (awb t2 t5770 t5822 t5824 (refl _)) pv5826
theorem pv5797 : R t5797 t1 := result (f := t5789) (a := t1) (u := t5789) (v := t5823) (refl t5789) (aw (ra t5786 t1)) pv5823
theorem pv5821 : R t5821 t1 := result (f := t28) (a := t5797) (u := t1) (v := t5797) pv28 (aw (ri t5797)) pv5797
theorem pv5817 : R t5817 t1 := result (f := t5816) (a := t1) (u := t5819) (v := t5821) pv5816 (awb t1 t5797 t1 t1 (cI)) pv5821
theorem pv5811 : R t5811 t1 := result (f := t5809) (a := t1) (u := t5809) (v := t5817) (refl t5809) (awb t5800 t1 t1 t1 (cI)) pv5817
theorem pv5815 : R t5815 t5814 := result (f := t5811) (a := t5814) (u := t1) (v := t5814) pv5811 (aw (ri t5814)) (refl t5814)
theorem pv5812 : R t5812 t5814 := result (f := t0) (a := t5811) (u := t0) (v := t5815) (refl t0) (aw (rh t5811)) pv5815
theorem pv5869 : R t5869 t5868 := result (f := t5811) (a := t5868) (u := t1) (v := t5868) pv5811 (aw (ri t5868)) (refl t5868)
theorem pv5813 : R t5813 t5868 := result (f := t5812) (a := t5797) (u := t5814) (v := t5869) pv5812 (aw (ra t5811 t5797)) pv5869
theorem pv5810 : R t5810 t5868 := result (f := t5800) (a := t5809) (u := t5800) (v := t5813) (refl t5800) (awb t0 t5797 t5809 t5811 (refl _)) pv5813
theorem pv5804 : R t5804 t5868 := result (f := t5802) (a := t1) (u := t5802) (v := t5810) (refl t5802) (aw (ra t5800 t1)) pv5810
theorem pv5880 : R t5880 t1 := result (f := t5811) (a := t1) (u := t1) (v := t1) pv5811 (aw (ri t1)) (refl t1)
theorem pv5881 : R t5881 t1 := result (f := t5880) (a := t5797) (u := t1) (v := t5797) pv5880 (aw (ri t5797)) pv5797
theorem pv5878 : R t5878 t1 := result (f := t5804) (a := t1) (u := t5868) (v := t5881) pv5804 (awb t5811 t5797 t1 t1 (cI)) pv5881
theorem pv5879 : R t5879 t1 := result (f := t5878) (a := t1) (u := t1) (v := t1) pv5878 (aw (ri t1)) (refl t1)
theorem pv5875 : R t5875 t1 := result (f := t5873) (a := t1) (u := t5873) (v := t5879) (refl t5873) (awb t5804 t1 t1 t1 (cI)) pv5879
theorem pv5876 : R t5876 t1 := result (f := t5811) (a := t5875) (u := t1) (v := t5875) pv5811 (aw (ri t5875)) pv5875
theorem pv5877 : R t5877 t1 := result (f := t5876) (a := t5797) (u := t1) (v := t5797) pv5876 (aw (ri t5797)) pv5797
theorem pv5874 : R t5874 t1 := result (f := t5804) (a := t5873) (u := t5868) (v := t5877) pv5804 (awb t5811 t5797 t5873 t5875 (refl _)) pv5877
theorem pv5870 : R t5870 t1 := result (f := t5807) (a := t1) (u := t5807) (v := t5874) (refl t5807) (aw (ra t5804 t1)) pv5874
theorem pv5871 : R t5871 t1 := result (f := t5811) (a := t5870) (u := t1) (v := t5870) pv5811 (aw (ri t5870)) pv5870
theorem pv5872 : R t5872 t1 := result (f := t5871) (a := t5797) (u := t1) (v := t5797) pv5871 (aw (ri t5797)) pv5797
theorem pv5808 : R t5808 t1 := result (f := t5804) (a := t5807) (u := t5868) (v := t5872) pv5804 (awb t5811 t5797 t5807 t5870 (refl _)) pv5872
theorem pv5805 : R t5805 t1 := result (f := t0) (a := t5804) (u := t0) (v := t5808) (refl t0) (aw (rh t5804)) pv5808
theorem pv5806 : R t5806 t1 := result (f := t5805) (a := t5797) (u := t1) (v := t5797) pv5805 (aw (ri t5797)) pv5797
theorem pv5803 : R t5803 t1 := result (f := t5800) (a := t5802) (u := t5800) (v := t5806) (refl t5800) (awb t0 t5797 t5802 t5804 (refl _)) pv5806
theorem pv5801 : R t5801 t1 := result (f := t0) (a := t5800) (u := t0) (v := t5803) (refl t0) (aw (rh t5800)) pv5803
theorem pv5798 : R t5798 t1 := result (f := t2) (a := t5797) (u := t2) (v := t5801) (refl t2) (aw (ra t0 t5797)) pv5801
theorem pv5799 : R t5799 t1 := result (f := t5798) (a := t5770) (u := t1) (v := t5770) pv5798 (aw (ri t5770)) pv5770
theorem pv5790 : R t5790 t1 := result (f := t5786) (a := t5789) (u := t5773) (v := t5799) pv5786 (awb t2 t5770 t5789 t5797 (refl _)) pv5799
theorem pv5787 : R t5787 t1 := result (f := t0) (a := t5786) (u := t0) (v := t5790) (refl t0) (aw (rh t5786)) pv5790
end Blc.H44.Pump
