from collections import Counter
from functools import lru_cache
from pathlib import Path
import json
import lc
HERE = Path(__file__).resolve().parent
def V(n): return ('V',n)
def L(t): return ('L',t)
def A(f,a): return ('A',f,a)
I=L(V(0))
KI=L(I)
om=A(L(A(V(0),V(0))),L(A(V(0),V(0))))
wire=lru_cache(32768)(lc.size)
def bounded(t,p):
    u=red(t,p)
    return u if wire(u)<=600 else None
def appall(t,args):
    for a in args:t=A(t,a)
    return t
def head_path(t):
    if t[0]=='L':
        p=head_path(t[1]);return None if p is None else ['under']+p
    if t[0]=='A':
        if t[1][0]=='L':return []
        p=head_path(t[1]);return None if p is None else ['left']+p
    return None

def at(t,p):
    for d in p:t=t[2] if d=='right' else t[1]
    return t

def red(t,p):
    if not p:return lc.beta(t[1],t[2])
    d,*q=p
    if d=='under':return L(red(t[1],q))
    if d=='left':return A(red(t[1],q),t[2])
    return A(t[1],red(t[2],q))

def occ(t,n=0):
    if t[0]=='V':return int(t[1]==n)
    if t[0]=='L':return occ(t[1],n+1)
    return occ(t[1],n)+occ(t[2],n)

def free(t,d=0):
    if t[0]=='V':return {t[1]-d} if t[1]>=d else set()
    if t[0]=='L':return free(t[1],d+1)
    return free(t[1],d)|free(t[2],d)

def counts(t):
    if t[0]=='V':return 0,1,t[1]
    if t[0]=='L':
        a,b,c=counts(t[1]); return a+1,b,c
    return tuple(x+y for x,y in zip(counts(t[1]),counts(t[2])))

def spine(t):
    binders=0
    while t[0]=='L':
        binders+=1
        t=t[1]
    args=[]
    while t[0]=='A':
        args.append(t[2]); t=t[1]
    return binders,t,list(reversed(args))

def subpaths(t):
    yield []
    if t[0]=='L':
        for p in subpaths(t[1]):yield ['under']+p
    elif t[0]=='A':
        for p in subpaths(t[1]):yield ['left']+p
        for p in subpaths(t[2]):yield ['right']+p

def expr(t):
    if t[0]=='V':return f'(.var {t[1]})'
    if t[0]=='L':return f'(.lam {expr(t[1])})'
    return f'(.app {expr(t[1])} {expr(t[2])})'
def paths(ps):
    return '['+','.join('['+','.join('.'+s for s in p)+']' for p in ps)+']'
