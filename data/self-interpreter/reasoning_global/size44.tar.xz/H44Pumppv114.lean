import H44Pumppv113
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv7821 : R t7821 t7806 := result (f := t7820) (a := t7806) (u := t1) (v := t7806) pv7820 (aw (ri t7806)) (refl t7806)
theorem pv7818 : R t7818 t7806 := result (f := t7808) (a := t7817) (u := t7808) (v := t7821) (refl t7808) (awb t0 t7806 t7817 t7819 (refl _)) pv7821
theorem pv7812 : R t7812 t7806 := result (f := t7810) (a := t1) (u := t7810) (v := t7818) (refl t7810) (aw (ra t7808 t1)) pv7818
theorem pv8132 : R t8132 t8131 := result (f := t1) (a := t8131) (u := t1) (v := t8131) (refl t1) (aw (ri t8131)) (refl t8131)
theorem pv8130 : R t8130 t8131 := result (f := t22) (a := t8109) (u := t24) (v := t8132) pv22 (aw (ra t1 t8109)) pv8132
theorem pv8128 : R t8128 t8131 := result (f := t8112) (a := t1) (u := t8112) (v := t8130) (refl t8112) (awb t0 t8109 t1 t1 (cI)) pv8130
theorem pv8159 : R t8159 t8158 := result (f := t1) (a := t8158) (u := t1) (v := t8158) (refl t1) (aw (ri t8158)) (refl t8158)
theorem pv8157 : R t8157 t8158 := result (f := t22) (a := t8136) (u := t24) (v := t8159) pv22 (aw (ra t1 t8136)) pv8159
theorem pv8155 : R t8155 t8158 := result (f := t8139) (a := t1) (u := t8139) (v := t8157) (refl t8139) (awb t0 t8136 t1 t1 (cI)) pv8157
theorem pv8161 : R t8161 t1 := result (f := t7812) (a := t1) (u := t7806) (v := t7884) pv7812 (awb t2 t7803 t1 t1 (cI)) pv7884
theorem pv8162 : R t8162 t1 := result (f := t8161) (a := t1) (u := t1) (v := t1) pv8161 (aw (ri t1)) (refl t1)
theorem pv8136 : R t8136 t1 := result (f := t8134) (a := t1) (u := t8134) (v := t8162) (refl t8134) (awb t7812 t1 t1 t1 (cI)) pv8162
theorem pv8160 : R t8160 t1 := result (f := t28) (a := t8136) (u := t1) (v := t8136) pv28 (aw (ri t8136)) pv8136
theorem pv8156 : R t8156 t1 := result (f := t8155) (a := t1) (u := t8158) (v := t8160) pv8155 (awb t1 t8136 t1 t1 (cI)) pv8160
theorem pv8150 : R t8150 t1 := result (f := t8148) (a := t1) (u := t8148) (v := t8156) (refl t8148) (awb t8139 t1 t1 t1 (cI)) pv8156
theorem pv8154 : R t8154 t8153 := result (f := t8150) (a := t8153) (u := t1) (v := t8153) pv8150 (aw (ri t8153)) (refl t8153)
theorem pv8151 : R t8151 t8153 := result (f := t0) (a := t8150) (u := t0) (v := t8154) (refl t0) (aw (rh t8150)) pv8154
theorem pv8164 : R t8164 t8163 := result (f := t8150) (a := t8163) (u := t1) (v := t8163) pv8150 (aw (ri t8163)) (refl t8163)
theorem pv8152 : R t8152 t8163 := result (f := t8151) (a := t8136) (u := t8153) (v := t8164) pv8151 (aw (ra t8150 t8136)) pv8164
theorem pv8149 : R t8149 t8163 := result (f := t8139) (a := t8148) (u := t8139) (v := t8152) (refl t8139) (awb t0 t8136 t8148 t8150 (refl _)) pv8152
theorem pv8143 : R t8143 t8163 := result (f := t8141) (a := t1) (u := t8141) (v := t8149) (refl t8141) (aw (ra t8139 t1)) pv8149
theorem pv8175 : R t8175 t1 := result (f := t8150) (a := t1) (u := t1) (v := t1) pv8150 (aw (ri t1)) (refl t1)
theorem pv8176 : R t8176 t1 := result (f := t8175) (a := t8136) (u := t1) (v := t8136) pv8175 (aw (ri t8136)) pv8136
theorem pv8173 : R t8173 t1 := result (f := t8143) (a := t1) (u := t8163) (v := t8176) pv8143 (awb t8150 t8136 t1 t1 (cI)) pv8176
theorem pv8174 : R t8174 t1 := result (f := t8173) (a := t1) (u := t1) (v := t1) pv8173 (aw (ri t1)) (refl t1)
theorem pv8170 : R t8170 t1 := result (f := t8168) (a := t1) (u := t8168) (v := t8174) (refl t8168) (awb t8143 t1 t1 t1 (cI)) pv8174
theorem pv8171 : R t8171 t1 := result (f := t8150) (a := t8170) (u := t1) (v := t8170) pv8150 (aw (ri t8170)) pv8170
theorem pv8172 : R t8172 t1 := result (f := t8171) (a := t8136) (u := t1) (v := t8136) pv8171 (aw (ri t8136)) pv8136
theorem pv8169 : R t8169 t1 := result (f := t8143) (a := t8168) (u := t8163) (v := t8172) pv8143 (awb t8150 t8136 t8168 t8170 (refl _)) pv8172
theorem pv8165 : R t8165 t1 := result (f := t8146) (a := t1) (u := t8146) (v := t8169) (refl t8146) (aw (ra t8143 t1)) pv8169
theorem pv8166 : R t8166 t1 := result (f := t8150) (a := t8165) (u := t1) (v := t8165) pv8150 (aw (ri t8165)) pv8165
theorem pv8167 : R t8167 t1 := result (f := t8166) (a := t8136) (u := t1) (v := t8136) pv8166 (aw (ri t8136)) pv8136
theorem pv8147 : R t8147 t1 := result (f := t8143) (a := t8146) (u := t8163) (v := t8167) pv8143 (awb t8150 t8136 t8146 t8165 (refl _)) pv8167
theorem pv8144 : R t8144 t1 := result (f := t0) (a := t8143) (u := t0) (v := t8147) (refl t0) (aw (rh t8143)) pv8147
theorem pv8145 : R t8145 t1 := result (f := t8144) (a := t8136) (u := t1) (v := t8136) pv8144 (aw (ri t8136)) pv8136
theorem pv8142 : R t8142 t1 := result (f := t8139) (a := t8141) (u := t8139) (v := t8145) (refl t8139) (awb t0 t8136 t8141 t8143 (refl _)) pv8145
theorem pv8140 : R t8140 t1 := result (f := t0) (a := t8139) (u := t0) (v := t8142) (refl t0) (aw (rh t8139)) pv8142
theorem pv8137 : R t8137 t1 := result (f := t2) (a := t8136) (u := t2) (v := t8140) (refl t2) (aw (ra t0 t8136)) pv8140
theorem pv8138 : R t8138 t1 := result (f := t8137) (a := t7803) (u := t1) (v := t7803) pv8137 (aw (ri t7803)) pv7803
theorem pv8135 : R t8135 t1 := result (f := t7812) (a := t8134) (u := t7806) (v := t8138) pv7812 (awb t2 t7803 t8134 t8136 (refl _)) pv8138
theorem pv8109 : R t8109 t1 := result (f := t7815) (a := t1) (u := t7815) (v := t8135) (refl t7815) (aw (ra t7812 t1)) pv8135
theorem pv8133 : R t8133 t1 := result (f := t28) (a := t8109) (u := t1) (v := t8109) pv28 (aw (ri t8109)) pv8109
theorem pv8129 : R t8129 t1 := result (f := t8128) (a := t1) (u := t8131) (v := t8133) pv8128 (awb t1 t8109 t1 t1 (cI)) pv8133
theorem pv8123 : R t8123 t1 := result (f := t8121) (a := t1) (u := t8121) (v := t8129) (refl t8121) (awb t8112 t1 t1 t1 (cI)) pv8129
theorem pv8127 : R t8127 t8126 := result (f := t8123) (a := t8126) (u := t1) (v := t8126) pv8123 (aw (ri t8126)) (refl t8126)
theorem pv8124 : R t8124 t8126 := result (f := t0) (a := t8123) (u := t0) (v := t8127) (refl t0) (aw (rh t8123)) pv8127
theorem pv8178 : R t8178 t8177 := result (f := t8123) (a := t8177) (u := t1) (v := t8177) pv8123 (aw (ri t8177)) (refl t8177)
theorem pv8125 : R t8125 t8177 := result (f := t8124) (a := t8109) (u := t8126) (v := t8178) pv8124 (aw (ra t8123 t8109)) pv8178
theorem pv8122 : R t8122 t8177 := result (f := t8112) (a := t8121) (u := t8112) (v := t8125) (refl t8112) (awb t0 t8109 t8121 t8123 (refl _)) pv8125
theorem pv8116 : R t8116 t8177 := result (f := t8114) (a := t1) (u := t8114) (v := t8122) (refl t8114) (aw (ra t8112 t1)) pv8122
theorem pv8189 : R t8189 t1 := result (f := t8123) (a := t1) (u := t1) (v := t1) pv8123 (aw (ri t1)) (refl t1)
theorem pv8190 : R t8190 t1 := result (f := t8189) (a := t8109) (u := t1) (v := t8109) pv8189 (aw (ri t8109)) pv8109
theorem pv8187 : R t8187 t1 := result (f := t8116) (a := t1) (u := t8177) (v := t8190) pv8116 (awb t8123 t8109 t1 t1 (cI)) pv8190
theorem pv8188 : R t8188 t1 := result (f := t8187) (a := t1) (u := t1) (v := t1) pv8187 (aw (ri t1)) (refl t1)
theorem pv8184 : R t8184 t1 := result (f := t8182) (a := t1) (u := t8182) (v := t8188) (refl t8182) (awb t8116 t1 t1 t1 (cI)) pv8188
end Blc.H44.Pump
