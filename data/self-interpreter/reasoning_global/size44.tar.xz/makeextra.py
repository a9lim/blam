from wireterms import *
from so import so
def plan(t):
    tag=so(t)
    if t[0]=='V':return '.v'
    if t[0]=='A':return f'(.a {plan(t[1])} {plan(t[2])})'
    hb=plan(t[1])
    if tag==('closed',):return f'(.c {hb})'
    if tag==('dead',):return f'(.d {hb})'
    _,r,g=tag
    return f'(.slot {expr(r)} {expr(g)} {hb} {plan(r)})'
HEAD='import More\nnamespace Blc.Floor44.Additional\nopen Term SelfintSharp SelfintSingleObject SelfintLowerBound Round3Floor38 WeakHeadClock\nset_option maxRecDepth 12000\nset_option maxHeartbeats 1800000\n'
def entry(s,r):
    e=lc.decode(s)[0];n='e'+str(int(s,2));k,ps,*rest=r
    rows=[f'def {n} : Term := {expr(e)}',f'theorem wire_{n} : Closed {n} ∧ code {n} = {int("1"+s,2)} := by decide']
    if not(k.startswith('so') or k.startswith('rank') or k=='Wsource'):
        return rows+[f'theorem cert_{n} : check {n} {paths(ps)} .{k} = true := by decide']
    term=e
    start=n
    if k=='soK':term=A(e,L(L(V(1))));start=f'(.app {n} churchTrue)'
    if k=='rankdelta':term=A(e,om[1]);start=f'(.app {n} diag)'
    for p in ps:term=red(term,p)
    u='t'+n
    rows += [f'private def {u} : Term := {expr(term)}',f'theorem cert_{n} : ¬ IsSelfInterpreter {n} := by',f'  have hp : replay {paths(ps)} {start} = some {u} := by decide']
    if k=='Wsource':rows.append('  exact wSource (replay_sound hp) (by decide)')
    elif k.startswith('so'):
        rows += [f'  have hs := Plan.sound {plan(term)} {u} (by decide)', '  intro he',
        ('  exact specialized_not_so he (replay_sound hp) hs' if k=='soK' else '  exact selfInterpreter_not_so (reduct_interp (replay_sound hp) he) hs')]
    else:
        c=rest[0];cl='deltaCount' if k=='rankdelta' else 'rawCount'
        rows+=['  intro he',f'  obtain ⟨_,h⟩ := clocks_replay ({cl} he) hp',f'  exact Weighted.no_clock {c} (by decide : Closed {u}) (by decide) (by decide) h']
    rows.append(f'#print axioms cert_{n}')
    return rows
def data():
    return sorted((s,r) for p in HERE.glob('extra-*.jsonl') for s,r in map(json.loads,p.open()) if r!=['open'])
if __name__=='__main__':
    rows=data()
    for j in range(0,len(rows),22):
        (HERE/f'More{j//22:03}.lean').write_text(HEAD+'\n'.join(x for s,r in rows[j:j+22] for x in entry(s,r))+'\nend Blc.Floor44.Additional\n')
