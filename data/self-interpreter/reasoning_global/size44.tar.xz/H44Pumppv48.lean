import H44Pumppv47
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3176 : R t3176 t1 := result (f := t0) (a := t3175) (u := t0) (v := t3179) (refl t0) (aw (rh t3175)) pv3179
theorem pv3177 : R t3177 t3162 := result (f := t3176) (a := t3162) (u := t1) (v := t3162) pv3176 (aw (ri t3162)) (refl t3162)
theorem pv3174 : R t3174 t3162 := result (f := t3164) (a := t3173) (u := t3164) (v := t3177) (refl t3164) (awb t0 t3162 t3173 t3175 (refl _)) pv3177
theorem pv3168 : R t3168 t3162 := result (f := t3166) (a := t1) (u := t3166) (v := t3174) (refl t3166) (aw (ra t3164 t1)) pv3174
theorem pv3488 : R t3488 t3487 := result (f := t1) (a := t3487) (u := t1) (v := t3487) (refl t1) (aw (ri t3487)) (refl t3487)
theorem pv3486 : R t3486 t3487 := result (f := t22) (a := t3465) (u := t24) (v := t3488) pv22 (aw (ra t1 t3465)) pv3488
theorem pv3484 : R t3484 t3487 := result (f := t3468) (a := t1) (u := t3468) (v := t3486) (refl t3468) (awb t0 t3465 t1 t1 (cI)) pv3486
theorem pv3515 : R t3515 t3514 := result (f := t1) (a := t3514) (u := t1) (v := t3514) (refl t1) (aw (ri t3514)) (refl t3514)
theorem pv3513 : R t3513 t3514 := result (f := t22) (a := t3492) (u := t24) (v := t3515) pv22 (aw (ra t1 t3492)) pv3515
theorem pv3511 : R t3511 t3514 := result (f := t3495) (a := t1) (u := t3495) (v := t3513) (refl t3495) (awb t0 t3492 t1 t1 (cI)) pv3513
theorem pv3517 : R t3517 t1 := result (f := t3168) (a := t1) (u := t3162) (v := t3240) pv3168 (awb t2 t3159 t1 t1 (cI)) pv3240
theorem pv3518 : R t3518 t1 := result (f := t3517) (a := t1) (u := t1) (v := t1) pv3517 (aw (ri t1)) (refl t1)
theorem pv3492 : R t3492 t1 := result (f := t3490) (a := t1) (u := t3490) (v := t3518) (refl t3490) (awb t3168 t1 t1 t1 (cI)) pv3518
theorem pv3516 : R t3516 t1 := result (f := t28) (a := t3492) (u := t1) (v := t3492) pv28 (aw (ri t3492)) pv3492
theorem pv3512 : R t3512 t1 := result (f := t3511) (a := t1) (u := t3514) (v := t3516) pv3511 (awb t1 t3492 t1 t1 (cI)) pv3516
theorem pv3506 : R t3506 t1 := result (f := t3504) (a := t1) (u := t3504) (v := t3512) (refl t3504) (awb t3495 t1 t1 t1 (cI)) pv3512
theorem pv3510 : R t3510 t3509 := result (f := t3506) (a := t3509) (u := t1) (v := t3509) pv3506 (aw (ri t3509)) (refl t3509)
theorem pv3507 : R t3507 t3509 := result (f := t0) (a := t3506) (u := t0) (v := t3510) (refl t0) (aw (rh t3506)) pv3510
theorem pv3520 : R t3520 t3519 := result (f := t3506) (a := t3519) (u := t1) (v := t3519) pv3506 (aw (ri t3519)) (refl t3519)
theorem pv3508 : R t3508 t3519 := result (f := t3507) (a := t3492) (u := t3509) (v := t3520) pv3507 (aw (ra t3506 t3492)) pv3520
theorem pv3505 : R t3505 t3519 := result (f := t3495) (a := t3504) (u := t3495) (v := t3508) (refl t3495) (awb t0 t3492 t3504 t3506 (refl _)) pv3508
theorem pv3499 : R t3499 t3519 := result (f := t3497) (a := t1) (u := t3497) (v := t3505) (refl t3497) (aw (ra t3495 t1)) pv3505
theorem pv3531 : R t3531 t1 := result (f := t3506) (a := t1) (u := t1) (v := t1) pv3506 (aw (ri t1)) (refl t1)
theorem pv3532 : R t3532 t1 := result (f := t3531) (a := t3492) (u := t1) (v := t3492) pv3531 (aw (ri t3492)) pv3492
theorem pv3529 : R t3529 t1 := result (f := t3499) (a := t1) (u := t3519) (v := t3532) pv3499 (awb t3506 t3492 t1 t1 (cI)) pv3532
theorem pv3530 : R t3530 t1 := result (f := t3529) (a := t1) (u := t1) (v := t1) pv3529 (aw (ri t1)) (refl t1)
theorem pv3526 : R t3526 t1 := result (f := t3524) (a := t1) (u := t3524) (v := t3530) (refl t3524) (awb t3499 t1 t1 t1 (cI)) pv3530
theorem pv3527 : R t3527 t1 := result (f := t3506) (a := t3526) (u := t1) (v := t3526) pv3506 (aw (ri t3526)) pv3526
theorem pv3528 : R t3528 t1 := result (f := t3527) (a := t3492) (u := t1) (v := t3492) pv3527 (aw (ri t3492)) pv3492
theorem pv3525 : R t3525 t1 := result (f := t3499) (a := t3524) (u := t3519) (v := t3528) pv3499 (awb t3506 t3492 t3524 t3526 (refl _)) pv3528
theorem pv3521 : R t3521 t1 := result (f := t3502) (a := t1) (u := t3502) (v := t3525) (refl t3502) (aw (ra t3499 t1)) pv3525
theorem pv3522 : R t3522 t1 := result (f := t3506) (a := t3521) (u := t1) (v := t3521) pv3506 (aw (ri t3521)) pv3521
theorem pv3523 : R t3523 t1 := result (f := t3522) (a := t3492) (u := t1) (v := t3492) pv3522 (aw (ri t3492)) pv3492
theorem pv3503 : R t3503 t1 := result (f := t3499) (a := t3502) (u := t3519) (v := t3523) pv3499 (awb t3506 t3492 t3502 t3521 (refl _)) pv3523
theorem pv3500 : R t3500 t1 := result (f := t0) (a := t3499) (u := t0) (v := t3503) (refl t0) (aw (rh t3499)) pv3503
theorem pv3501 : R t3501 t1 := result (f := t3500) (a := t3492) (u := t1) (v := t3492) pv3500 (aw (ri t3492)) pv3492
theorem pv3498 : R t3498 t1 := result (f := t3495) (a := t3497) (u := t3495) (v := t3501) (refl t3495) (awb t0 t3492 t3497 t3499 (refl _)) pv3501
theorem pv3496 : R t3496 t1 := result (f := t0) (a := t3495) (u := t0) (v := t3498) (refl t0) (aw (rh t3495)) pv3498
theorem pv3493 : R t3493 t1 := result (f := t2) (a := t3492) (u := t2) (v := t3496) (refl t2) (aw (ra t0 t3492)) pv3496
theorem pv3494 : R t3494 t1 := result (f := t3493) (a := t3159) (u := t1) (v := t3159) pv3493 (aw (ri t3159)) pv3159
theorem pv3491 : R t3491 t1 := result (f := t3168) (a := t3490) (u := t3162) (v := t3494) pv3168 (awb t2 t3159 t3490 t3492 (refl _)) pv3494
theorem pv3465 : R t3465 t1 := result (f := t3171) (a := t1) (u := t3171) (v := t3491) (refl t3171) (aw (ra t3168 t1)) pv3491
theorem pv3489 : R t3489 t1 := result (f := t28) (a := t3465) (u := t1) (v := t3465) pv28 (aw (ri t3465)) pv3465
theorem pv3485 : R t3485 t1 := result (f := t3484) (a := t1) (u := t3487) (v := t3489) pv3484 (awb t1 t3465 t1 t1 (cI)) pv3489
theorem pv3479 : R t3479 t1 := result (f := t3477) (a := t1) (u := t3477) (v := t3485) (refl t3477) (awb t3468 t1 t1 t1 (cI)) pv3485
theorem pv3483 : R t3483 t3482 := result (f := t3479) (a := t3482) (u := t1) (v := t3482) pv3479 (aw (ri t3482)) (refl t3482)
theorem pv3480 : R t3480 t3482 := result (f := t0) (a := t3479) (u := t0) (v := t3483) (refl t0) (aw (rh t3479)) pv3483
theorem pv3534 : R t3534 t3533 := result (f := t3479) (a := t3533) (u := t1) (v := t3533) pv3479 (aw (ri t3533)) (refl t3533)
theorem pv3481 : R t3481 t3533 := result (f := t3480) (a := t3465) (u := t3482) (v := t3534) pv3480 (aw (ra t3479 t3465)) pv3534
theorem pv3478 : R t3478 t3533 := result (f := t3468) (a := t3477) (u := t3468) (v := t3481) (refl t3468) (awb t0 t3465 t3477 t3479 (refl _)) pv3481
theorem pv3472 : R t3472 t3533 := result (f := t3470) (a := t1) (u := t3470) (v := t3478) (refl t3470) (aw (ra t3468 t1)) pv3478
theorem pv3545 : R t3545 t1 := result (f := t3479) (a := t1) (u := t1) (v := t1) pv3479 (aw (ri t1)) (refl t1)
theorem pv3546 : R t3546 t1 := result (f := t3545) (a := t3465) (u := t1) (v := t3465) pv3545 (aw (ri t3465)) pv3465
theorem pv3543 : R t3543 t1 := result (f := t3472) (a := t1) (u := t3533) (v := t3546) pv3472 (awb t3479 t3465 t1 t1 (cI)) pv3546
theorem pv3544 : R t3544 t1 := result (f := t3543) (a := t1) (u := t1) (v := t1) pv3543 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
