from wireterms import *
remaining=set((HERE/'wires.txt').read_text().splitlines())
assert len(remaining)==188768
seen=0;n=0
with (HERE/'cross.txt').open() as f:
    for line in f:
        s=line.rstrip();seen+=1;e,end=lc.decode(s)
        assert end==44
        if all(wire(red(e,p))>=44 for p in subpaths(e) if at(e,p)[0]=='A' and at(e,p)[1][0]=='L'):
            remaining.remove(s);n+=1
assert seen==1319488 and n==188768 and not remaining
print(seen,'structurally eligible;',n,'equal survivors, zero symmetric difference')
