import H44Pumppv52
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3610 : R t3610 t1 := result (f := t3609) (a := t3601) (u := t1) (v := t3601) pv3609 (aw (ri t3601)) pv3601
theorem pv3607 : R t3607 t1 := result (f := t3604) (a := t3606) (u := t3604) (v := t3610) (refl t3604) (awb t0 t3601 t3606 t3608 (refl _)) pv3610
theorem pv3605 : R t3605 t1 := result (f := t0) (a := t3604) (u := t0) (v := t3607) (refl t0) (aw (rh t3604)) pv3607
theorem pv3602 : R t3602 t1 := result (f := t2) (a := t3601) (u := t2) (v := t3605) (refl t2) (aw (ra t0 t3601)) pv3605
theorem pv3603 : R t3603 t1 := result (f := t3602) (a := t3547) (u := t1) (v := t3547) pv3602 (aw (ri t3547)) pv3547
theorem pv3600 : R t3600 t1 := result (f := t3563) (a := t3599) (u := t3550) (v := t3603) pv3563 (awb t2 t3547 t3599 t3601 (refl _)) pv3603
theorem pv3574 : R t3574 t1 := result (f := t3566) (a := t1) (u := t3566) (v := t3600) (refl t3566) (aw (ra t3563 t1)) pv3600
theorem pv3598 : R t3598 t1 := result (f := t28) (a := t3574) (u := t1) (v := t3574) pv28 (aw (ri t3574)) pv3574
theorem pv3594 : R t3594 t1 := result (f := t3593) (a := t1) (u := t3596) (v := t3598) pv3593 (awb t1 t3574 t1 t1 (cI)) pv3598
theorem pv3588 : R t3588 t1 := result (f := t3586) (a := t1) (u := t3586) (v := t3594) (refl t3586) (awb t3577 t1 t1 t1 (cI)) pv3594
theorem pv3592 : R t3592 t3591 := result (f := t3588) (a := t3591) (u := t1) (v := t3591) pv3588 (aw (ri t3591)) (refl t3591)
theorem pv3589 : R t3589 t3591 := result (f := t0) (a := t3588) (u := t0) (v := t3592) (refl t0) (aw (rh t3588)) pv3592
theorem pv3840 : R t3840 t3839 := result (f := t3588) (a := t3839) (u := t1) (v := t3839) pv3588 (aw (ri t3839)) (refl t3839)
theorem pv3590 : R t3590 t3839 := result (f := t3589) (a := t3574) (u := t3591) (v := t3840) pv3589 (aw (ra t3588 t3574)) pv3840
theorem pv3587 : R t3587 t3839 := result (f := t3577) (a := t3586) (u := t3577) (v := t3590) (refl t3577) (awb t0 t3574 t3586 t3588 (refl _)) pv3590
theorem pv3581 : R t3581 t3839 := result (f := t3579) (a := t1) (u := t3579) (v := t3587) (refl t3579) (aw (ra t3577 t1)) pv3587
theorem pv3851 : R t3851 t1 := result (f := t3588) (a := t1) (u := t1) (v := t1) pv3588 (aw (ri t1)) (refl t1)
theorem pv3852 : R t3852 t1 := result (f := t3851) (a := t3574) (u := t1) (v := t3574) pv3851 (aw (ri t3574)) pv3574
theorem pv3849 : R t3849 t1 := result (f := t3581) (a := t1) (u := t3839) (v := t3852) pv3581 (awb t3588 t3574 t1 t1 (cI)) pv3852
theorem pv3850 : R t3850 t1 := result (f := t3849) (a := t1) (u := t1) (v := t1) pv3849 (aw (ri t1)) (refl t1)
theorem pv3846 : R t3846 t1 := result (f := t3844) (a := t1) (u := t3844) (v := t3850) (refl t3844) (awb t3581 t1 t1 t1 (cI)) pv3850
theorem pv3847 : R t3847 t1 := result (f := t3588) (a := t3846) (u := t1) (v := t3846) pv3588 (aw (ri t3846)) pv3846
theorem pv3848 : R t3848 t1 := result (f := t3847) (a := t3574) (u := t1) (v := t3574) pv3847 (aw (ri t3574)) pv3574
theorem pv3845 : R t3845 t1 := result (f := t3581) (a := t3844) (u := t3839) (v := t3848) pv3581 (awb t3588 t3574 t3844 t3846 (refl _)) pv3848
theorem pv3841 : R t3841 t1 := result (f := t3584) (a := t1) (u := t3584) (v := t3845) (refl t3584) (aw (ra t3581 t1)) pv3845
theorem pv3842 : R t3842 t1 := result (f := t3588) (a := t3841) (u := t1) (v := t3841) pv3588 (aw (ri t3841)) pv3841
theorem pv3843 : R t3843 t1 := result (f := t3842) (a := t3574) (u := t1) (v := t3574) pv3842 (aw (ri t3574)) pv3574
theorem pv3585 : R t3585 t1 := result (f := t3581) (a := t3584) (u := t3839) (v := t3843) pv3581 (awb t3588 t3574 t3584 t3841 (refl _)) pv3843
theorem pv3582 : R t3582 t1 := result (f := t0) (a := t3581) (u := t0) (v := t3585) (refl t0) (aw (rh t3581)) pv3585
theorem pv3583 : R t3583 t1 := result (f := t3582) (a := t3574) (u := t1) (v := t3574) pv3582 (aw (ri t3574)) pv3574
theorem pv3580 : R t3580 t1 := result (f := t3577) (a := t3579) (u := t3577) (v := t3583) (refl t3577) (awb t0 t3574 t3579 t3581 (refl _)) pv3583
theorem pv3578 : R t3578 t1 := result (f := t0) (a := t3577) (u := t0) (v := t3580) (refl t0) (aw (rh t3577)) pv3580
theorem pv3575 : R t3575 t1 := result (f := t2) (a := t3574) (u := t2) (v := t3578) (refl t2) (aw (ra t0 t3574)) pv3578
theorem pv3576 : R t3576 t1 := result (f := t3575) (a := t3547) (u := t1) (v := t3547) pv3575 (aw (ri t3547)) pv3547
theorem pv3567 : R t3567 t1 := result (f := t3563) (a := t3566) (u := t3550) (v := t3576) pv3563 (awb t2 t3547 t3566 t3574 (refl _)) pv3576
theorem pv3564 : R t3564 t1 := result (f := t0) (a := t3563) (u := t0) (v := t3567) (refl t0) (aw (rh t3563)) pv3567
theorem pv3565 : R t3565 t3550 := result (f := t3564) (a := t3550) (u := t1) (v := t3550) pv3564 (aw (ri t3550)) (refl t3550)
theorem pv3562 : R t3562 t3550 := result (f := t3552) (a := t3561) (u := t3552) (v := t3565) (refl t3552) (awb t0 t3550 t3561 t3563 (refl _)) pv3565
theorem pv3556 : R t3556 t3550 := result (f := t3554) (a := t1) (u := t3554) (v := t3562) (refl t3554) (aw (ra t3552 t1)) pv3562
theorem pv3876 : R t3876 t3875 := result (f := t1) (a := t3875) (u := t1) (v := t3875) (refl t1) (aw (ri t3875)) (refl t3875)
theorem pv3874 : R t3874 t3875 := result (f := t22) (a := t3853) (u := t24) (v := t3876) pv22 (aw (ra t1 t3853)) pv3876
theorem pv3872 : R t3872 t3875 := result (f := t3856) (a := t1) (u := t3856) (v := t3874) (refl t3856) (awb t0 t3853 t1 t1 (cI)) pv3874
theorem pv3903 : R t3903 t3902 := result (f := t1) (a := t3902) (u := t1) (v := t3902) (refl t1) (aw (ri t3902)) (refl t3902)
theorem pv3901 : R t3901 t3902 := result (f := t22) (a := t3880) (u := t24) (v := t3903) pv22 (aw (ra t1 t3880)) pv3903
theorem pv3899 : R t3899 t3902 := result (f := t3883) (a := t1) (u := t3883) (v := t3901) (refl t3883) (awb t0 t3880 t1 t1 (cI)) pv3901
theorem pv3905 : R t3905 t1 := result (f := t3556) (a := t1) (u := t3550) (v := t3628) pv3556 (awb t2 t3547 t1 t1 (cI)) pv3628
theorem pv3906 : R t3906 t1 := result (f := t3905) (a := t1) (u := t1) (v := t1) pv3905 (aw (ri t1)) (refl t1)
theorem pv3880 : R t3880 t1 := result (f := t3878) (a := t1) (u := t3878) (v := t3906) (refl t3878) (awb t3556 t1 t1 t1 (cI)) pv3906
theorem pv3904 : R t3904 t1 := result (f := t28) (a := t3880) (u := t1) (v := t3880) pv28 (aw (ri t3880)) pv3880
theorem pv3900 : R t3900 t1 := result (f := t3899) (a := t1) (u := t3902) (v := t3904) pv3899 (awb t1 t3880 t1 t1 (cI)) pv3904
theorem pv3894 : R t3894 t1 := result (f := t3892) (a := t1) (u := t3892) (v := t3900) (refl t3892) (awb t3883 t1 t1 t1 (cI)) pv3900
theorem pv3898 : R t3898 t3897 := result (f := t3894) (a := t3897) (u := t1) (v := t3897) pv3894 (aw (ri t3897)) (refl t3897)
theorem pv3895 : R t3895 t3897 := result (f := t0) (a := t3894) (u := t0) (v := t3898) (refl t0) (aw (rh t3894)) pv3898
theorem pv3908 : R t3908 t3907 := result (f := t3894) (a := t3907) (u := t1) (v := t3907) pv3894 (aw (ri t3907)) (refl t3907)
theorem pv3896 : R t3896 t3907 := result (f := t3895) (a := t3880) (u := t3897) (v := t3908) pv3895 (aw (ra t3894 t3880)) pv3908
end Blc.H44.Pump
