import H44Pumppv99
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv7127 : R t7127 t1 := result (f := t7027) (a := t1) (u := t7027) (v := t7153) (refl t7027) (aw (ra t7024 t1)) pv7153
theorem pv7151 : R t7151 t1 := result (f := t28) (a := t7127) (u := t1) (v := t7127) pv28 (aw (ri t7127)) pv7127
theorem pv7147 : R t7147 t1 := result (f := t7146) (a := t1) (u := t7149) (v := t7151) pv7146 (awb t1 t7127 t1 t1 (cI)) pv7151
theorem pv7141 : R t7141 t1 := result (f := t7139) (a := t1) (u := t7139) (v := t7147) (refl t7139) (awb t7130 t1 t1 t1 (cI)) pv7147
theorem pv7145 : R t7145 t7144 := result (f := t7141) (a := t7144) (u := t1) (v := t7144) pv7141 (aw (ri t7144)) (refl t7144)
theorem pv7142 : R t7142 t7144 := result (f := t0) (a := t7141) (u := t0) (v := t7145) (refl t0) (aw (rh t7141)) pv7145
theorem pv7196 : R t7196 t7195 := result (f := t7141) (a := t7195) (u := t1) (v := t7195) pv7141 (aw (ri t7195)) (refl t7195)
theorem pv7143 : R t7143 t7195 := result (f := t7142) (a := t7127) (u := t7144) (v := t7196) pv7142 (aw (ra t7141 t7127)) pv7196
theorem pv7140 : R t7140 t7195 := result (f := t7130) (a := t7139) (u := t7130) (v := t7143) (refl t7130) (awb t0 t7127 t7139 t7141 (refl _)) pv7143
theorem pv7134 : R t7134 t7195 := result (f := t7132) (a := t1) (u := t7132) (v := t7140) (refl t7132) (aw (ra t7130 t1)) pv7140
theorem pv7207 : R t7207 t1 := result (f := t7141) (a := t1) (u := t1) (v := t1) pv7141 (aw (ri t1)) (refl t1)
theorem pv7208 : R t7208 t1 := result (f := t7207) (a := t7127) (u := t1) (v := t7127) pv7207 (aw (ri t7127)) pv7127
theorem pv7205 : R t7205 t1 := result (f := t7134) (a := t1) (u := t7195) (v := t7208) pv7134 (awb t7141 t7127 t1 t1 (cI)) pv7208
theorem pv7206 : R t7206 t1 := result (f := t7205) (a := t1) (u := t1) (v := t1) pv7205 (aw (ri t1)) (refl t1)
theorem pv7202 : R t7202 t1 := result (f := t7200) (a := t1) (u := t7200) (v := t7206) (refl t7200) (awb t7134 t1 t1 t1 (cI)) pv7206
theorem pv7203 : R t7203 t1 := result (f := t7141) (a := t7202) (u := t1) (v := t7202) pv7141 (aw (ri t7202)) pv7202
theorem pv7204 : R t7204 t1 := result (f := t7203) (a := t7127) (u := t1) (v := t7127) pv7203 (aw (ri t7127)) pv7127
theorem pv7201 : R t7201 t1 := result (f := t7134) (a := t7200) (u := t7195) (v := t7204) pv7134 (awb t7141 t7127 t7200 t7202 (refl _)) pv7204
theorem pv7197 : R t7197 t1 := result (f := t7137) (a := t1) (u := t7137) (v := t7201) (refl t7137) (aw (ra t7134 t1)) pv7201
theorem pv7198 : R t7198 t1 := result (f := t7141) (a := t7197) (u := t1) (v := t7197) pv7141 (aw (ri t7197)) pv7197
theorem pv7199 : R t7199 t1 := result (f := t7198) (a := t7127) (u := t1) (v := t7127) pv7198 (aw (ri t7127)) pv7127
theorem pv7138 : R t7138 t1 := result (f := t7134) (a := t7137) (u := t7195) (v := t7199) pv7134 (awb t7141 t7127 t7137 t7197 (refl _)) pv7199
theorem pv7135 : R t7135 t1 := result (f := t0) (a := t7134) (u := t0) (v := t7138) (refl t0) (aw (rh t7134)) pv7138
theorem pv7136 : R t7136 t1 := result (f := t7135) (a := t7127) (u := t1) (v := t7127) pv7135 (aw (ri t7127)) pv7127
theorem pv7133 : R t7133 t1 := result (f := t7130) (a := t7132) (u := t7130) (v := t7136) (refl t7130) (awb t0 t7127 t7132 t7134 (refl _)) pv7136
theorem pv7131 : R t7131 t1 := result (f := t0) (a := t7130) (u := t0) (v := t7133) (refl t0) (aw (rh t7130)) pv7133
theorem pv7128 : R t7128 t1 := result (f := t2) (a := t7127) (u := t2) (v := t7131) (refl t2) (aw (ra t0 t7127)) pv7131
theorem pv7129 : R t7129 t1 := result (f := t7128) (a := t7015) (u := t1) (v := t7015) pv7128 (aw (ri t7015)) pv7015
theorem pv7028 : R t7028 t1 := result (f := t7024) (a := t7027) (u := t7018) (v := t7129) pv7024 (awb t2 t7015 t7027 t7127 (refl _)) pv7129
theorem pv7025 : R t7025 t1 := result (f := t0) (a := t7024) (u := t0) (v := t7028) (refl t0) (aw (rh t7024)) pv7028
theorem pv7026 : R t7026 t7018 := result (f := t7025) (a := t7018) (u := t1) (v := t7018) pv7025 (aw (ri t7018)) (refl t7018)
theorem pv7023 : R t7023 t7018 := result (f := t7020) (a := t7022) (u := t7020) (v := t7026) (refl t7020) (awb t0 t7018 t7022 t7024 (refl _)) pv7026
theorem pv7021 : R t7021 t7018 := result (f := t0) (a := t7020) (u := t0) (v := t7023) (refl t0) (aw (rh t7020)) pv7023
theorem pv7019 : R t7019 t7018 := result (f := t2) (a := t7018) (u := t2) (v := t7021) (refl t2) (aw (ra t0 t7018)) pv7021
theorem pv7016 : R t7016 t7018 := result (f := t59) (a := t7015) (u := t46) (v := t7019) pv59 (aw (ra t2 t7015)) pv7019
theorem pv7017 : R t7017 t1 := result (f := t7016) (a := t1) (u := t7018) (v := t7096) pv7016 (awb t2 t7015 t1 t1 (cI)) pv7096
theorem pv7014 : R t7014 t1 := result (f := t6522) (a := t7013) (u := t149) (v := t7017) pv6522 (awb t59 t1 t7013 t7015 (refl _)) pv7017
theorem pv6931 : R t6931 t1 := result (f := t6525) (a := t1) (u := t6525) (v := t7014) (refl t6525) (aw (ra t6522 t1)) pv7014
theorem pv7012 : R t7012 t1 := result (f := t3) (a := t6931) (u := t1) (v := t6931) pv3 (aw (ri t6931)) pv6931
theorem pv7010 : R t7010 t1 := result (f := t6947) (a := t1) (u := t6934) (v := t7012) pv6947 (awb t2 t6931 t1 t1 (cI)) pv7012
theorem pv7011 : R t7011 t1 := result (f := t7010) (a := t1) (u := t1) (v := t1) pv7010 (aw (ri t1)) (refl t1)
theorem pv6985 : R t6985 t1 := result (f := t6983) (a := t1) (u := t6983) (v := t7011) (refl t6983) (awb t6947 t1 t1 t1 (cI)) pv7011
theorem pv7009 : R t7009 t1 := result (f := t28) (a := t6985) (u := t1) (v := t6985) pv28 (aw (ri t6985)) pv6985
theorem pv7005 : R t7005 t1 := result (f := t7004) (a := t1) (u := t7007) (v := t7009) pv7004 (awb t1 t6985 t1 t1 (cI)) pv7009
theorem pv6999 : R t6999 t1 := result (f := t6997) (a := t1) (u := t6997) (v := t7005) (refl t6997) (awb t6988 t1 t1 t1 (cI)) pv7005
theorem pv7003 : R t7003 t7002 := result (f := t6999) (a := t7002) (u := t1) (v := t7002) pv6999 (aw (ri t7002)) (refl t7002)
theorem pv7000 : R t7000 t7002 := result (f := t0) (a := t6999) (u := t0) (v := t7003) (refl t0) (aw (rh t6999)) pv7003
theorem pv7210 : R t7210 t7209 := result (f := t6999) (a := t7209) (u := t1) (v := t7209) pv6999 (aw (ri t7209)) (refl t7209)
theorem pv7001 : R t7001 t7209 := result (f := t7000) (a := t6985) (u := t7002) (v := t7210) pv7000 (aw (ra t6999 t6985)) pv7210
theorem pv6998 : R t6998 t7209 := result (f := t6988) (a := t6997) (u := t6988) (v := t7001) (refl t6988) (awb t0 t6985 t6997 t6999 (refl _)) pv7001
theorem pv6992 : R t6992 t7209 := result (f := t6990) (a := t1) (u := t6990) (v := t6998) (refl t6990) (aw (ra t6988 t1)) pv6998
theorem pv7221 : R t7221 t1 := result (f := t6999) (a := t1) (u := t1) (v := t1) pv6999 (aw (ri t1)) (refl t1)
theorem pv7222 : R t7222 t1 := result (f := t7221) (a := t6985) (u := t1) (v := t6985) pv7221 (aw (ri t6985)) pv6985
theorem pv7219 : R t7219 t1 := result (f := t6992) (a := t1) (u := t7209) (v := t7222) pv6992 (awb t6999 t6985 t1 t1 (cI)) pv7222
theorem pv7220 : R t7220 t1 := result (f := t7219) (a := t1) (u := t1) (v := t1) pv7219 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
