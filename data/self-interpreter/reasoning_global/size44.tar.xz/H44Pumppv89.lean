import H44Pumppv88
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6160 : R t6160 t1 := result (f := t6159) (a := t1) (u := t6161) (v := t6239) pv6159 (awb t2 t6158 t1 t1 (cI)) pv6239
theorem pv6157 : R t6157 t1 := result (f := t101) (a := t6156) (u := t149) (v := t6160) pv101 (awb t59 t1 t6156 t6158 (refl _)) pv6160
theorem pv6074 : R t6074 t1 := result (f := t104) (a := t1) (u := t104) (v := t6157) (refl t104) (aw (ra t101 t1)) pv6157
theorem pv6155 : R t6155 t1 := result (f := t3) (a := t6074) (u := t1) (v := t6074) pv3 (aw (ri t6074)) pv6074
theorem pv6153 : R t6153 t1 := result (f := t6090) (a := t1) (u := t6077) (v := t6155) pv6090 (awb t2 t6074 t1 t1 (cI)) pv6155
theorem pv6154 : R t6154 t1 := result (f := t6153) (a := t1) (u := t1) (v := t1) pv6153 (aw (ri t1)) (refl t1)
theorem pv6128 : R t6128 t1 := result (f := t6126) (a := t1) (u := t6126) (v := t6154) (refl t6126) (awb t6090 t1 t1 t1 (cI)) pv6154
theorem pv6152 : R t6152 t1 := result (f := t28) (a := t6128) (u := t1) (v := t6128) pv28 (aw (ri t6128)) pv6128
theorem pv6148 : R t6148 t1 := result (f := t6147) (a := t1) (u := t6150) (v := t6152) pv6147 (awb t1 t6128 t1 t1 (cI)) pv6152
theorem pv6142 : R t6142 t1 := result (f := t6140) (a := t1) (u := t6140) (v := t6148) (refl t6140) (awb t6131 t1 t1 t1 (cI)) pv6148
theorem pv6146 : R t6146 t6145 := result (f := t6142) (a := t6145) (u := t1) (v := t6145) pv6142 (aw (ri t6145)) (refl t6145)
theorem pv6143 : R t6143 t6145 := result (f := t0) (a := t6142) (u := t0) (v := t6146) (refl t0) (aw (rh t6142)) pv6146
theorem pv6353 : R t6353 t6352 := result (f := t6142) (a := t6352) (u := t1) (v := t6352) pv6142 (aw (ri t6352)) (refl t6352)
theorem pv6144 : R t6144 t6352 := result (f := t6143) (a := t6128) (u := t6145) (v := t6353) pv6143 (aw (ra t6142 t6128)) pv6353
theorem pv6141 : R t6141 t6352 := result (f := t6131) (a := t6140) (u := t6131) (v := t6144) (refl t6131) (awb t0 t6128 t6140 t6142 (refl _)) pv6144
theorem pv6135 : R t6135 t6352 := result (f := t6133) (a := t1) (u := t6133) (v := t6141) (refl t6133) (aw (ra t6131 t1)) pv6141
theorem pv6364 : R t6364 t1 := result (f := t6142) (a := t1) (u := t1) (v := t1) pv6142 (aw (ri t1)) (refl t1)
theorem pv6365 : R t6365 t1 := result (f := t6364) (a := t6128) (u := t1) (v := t6128) pv6364 (aw (ri t6128)) pv6128
theorem pv6362 : R t6362 t1 := result (f := t6135) (a := t1) (u := t6352) (v := t6365) pv6135 (awb t6142 t6128 t1 t1 (cI)) pv6365
theorem pv6363 : R t6363 t1 := result (f := t6362) (a := t1) (u := t1) (v := t1) pv6362 (aw (ri t1)) (refl t1)
theorem pv6359 : R t6359 t1 := result (f := t6357) (a := t1) (u := t6357) (v := t6363) (refl t6357) (awb t6135 t1 t1 t1 (cI)) pv6363
theorem pv6360 : R t6360 t1 := result (f := t6142) (a := t6359) (u := t1) (v := t6359) pv6142 (aw (ri t6359)) pv6359
theorem pv6361 : R t6361 t1 := result (f := t6360) (a := t6128) (u := t1) (v := t6128) pv6360 (aw (ri t6128)) pv6128
theorem pv6358 : R t6358 t1 := result (f := t6135) (a := t6357) (u := t6352) (v := t6361) pv6135 (awb t6142 t6128 t6357 t6359 (refl _)) pv6361
theorem pv6354 : R t6354 t1 := result (f := t6138) (a := t1) (u := t6138) (v := t6358) (refl t6138) (aw (ra t6135 t1)) pv6358
theorem pv6355 : R t6355 t1 := result (f := t6142) (a := t6354) (u := t1) (v := t6354) pv6142 (aw (ri t6354)) pv6354
theorem pv6356 : R t6356 t1 := result (f := t6355) (a := t6128) (u := t1) (v := t6128) pv6355 (aw (ri t6128)) pv6128
theorem pv6139 : R t6139 t1 := result (f := t6135) (a := t6138) (u := t6352) (v := t6356) pv6135 (awb t6142 t6128 t6138 t6354 (refl _)) pv6356
theorem pv6136 : R t6136 t1 := result (f := t0) (a := t6135) (u := t0) (v := t6139) (refl t0) (aw (rh t6135)) pv6139
theorem pv6137 : R t6137 t1 := result (f := t6136) (a := t6128) (u := t1) (v := t6128) pv6136 (aw (ri t6128)) pv6128
theorem pv6134 : R t6134 t1 := result (f := t6131) (a := t6133) (u := t6131) (v := t6137) (refl t6131) (awb t0 t6128 t6133 t6135 (refl _)) pv6137
theorem pv6132 : R t6132 t1 := result (f := t0) (a := t6131) (u := t0) (v := t6134) (refl t0) (aw (rh t6131)) pv6134
theorem pv6129 : R t6129 t1 := result (f := t2) (a := t6128) (u := t2) (v := t6132) (refl t2) (aw (ra t0 t6128)) pv6132
theorem pv6130 : R t6130 t1 := result (f := t6129) (a := t6074) (u := t1) (v := t6074) pv6129 (aw (ri t6074)) pv6074
theorem pv6127 : R t6127 t1 := result (f := t6090) (a := t6126) (u := t6077) (v := t6130) pv6090 (awb t2 t6074 t6126 t6128 (refl _)) pv6130
theorem pv6101 : R t6101 t1 := result (f := t6093) (a := t1) (u := t6093) (v := t6127) (refl t6093) (aw (ra t6090 t1)) pv6127
theorem pv6125 : R t6125 t1 := result (f := t28) (a := t6101) (u := t1) (v := t6101) pv28 (aw (ri t6101)) pv6101
theorem pv6121 : R t6121 t1 := result (f := t6120) (a := t1) (u := t6123) (v := t6125) pv6120 (awb t1 t6101 t1 t1 (cI)) pv6125
theorem pv6115 : R t6115 t1 := result (f := t6113) (a := t1) (u := t6113) (v := t6121) (refl t6113) (awb t6104 t1 t1 t1 (cI)) pv6121
theorem pv6119 : R t6119 t6118 := result (f := t6115) (a := t6118) (u := t1) (v := t6118) pv6115 (aw (ri t6118)) (refl t6118)
theorem pv6116 : R t6116 t6118 := result (f := t0) (a := t6115) (u := t0) (v := t6119) (refl t0) (aw (rh t6115)) pv6119
theorem pv6367 : R t6367 t6366 := result (f := t6115) (a := t6366) (u := t1) (v := t6366) pv6115 (aw (ri t6366)) (refl t6366)
theorem pv6117 : R t6117 t6366 := result (f := t6116) (a := t6101) (u := t6118) (v := t6367) pv6116 (aw (ra t6115 t6101)) pv6367
theorem pv6114 : R t6114 t6366 := result (f := t6104) (a := t6113) (u := t6104) (v := t6117) (refl t6104) (awb t0 t6101 t6113 t6115 (refl _)) pv6117
theorem pv6108 : R t6108 t6366 := result (f := t6106) (a := t1) (u := t6106) (v := t6114) (refl t6106) (aw (ra t6104 t1)) pv6114
theorem pv6378 : R t6378 t1 := result (f := t6115) (a := t1) (u := t1) (v := t1) pv6115 (aw (ri t1)) (refl t1)
theorem pv6379 : R t6379 t1 := result (f := t6378) (a := t6101) (u := t1) (v := t6101) pv6378 (aw (ri t6101)) pv6101
theorem pv6376 : R t6376 t1 := result (f := t6108) (a := t1) (u := t6366) (v := t6379) pv6108 (awb t6115 t6101 t1 t1 (cI)) pv6379
theorem pv6377 : R t6377 t1 := result (f := t6376) (a := t1) (u := t1) (v := t1) pv6376 (aw (ri t1)) (refl t1)
theorem pv6373 : R t6373 t1 := result (f := t6371) (a := t1) (u := t6371) (v := t6377) (refl t6371) (awb t6108 t1 t1 t1 (cI)) pv6377
theorem pv6374 : R t6374 t1 := result (f := t6115) (a := t6373) (u := t1) (v := t6373) pv6115 (aw (ri t6373)) pv6373
theorem pv6375 : R t6375 t1 := result (f := t6374) (a := t6101) (u := t1) (v := t6101) pv6374 (aw (ri t6101)) pv6101
theorem pv6372 : R t6372 t1 := result (f := t6108) (a := t6371) (u := t6366) (v := t6375) pv6108 (awb t6115 t6101 t6371 t6373 (refl _)) pv6375
theorem pv6368 : R t6368 t1 := result (f := t6111) (a := t1) (u := t6111) (v := t6372) (refl t6111) (aw (ra t6108 t1)) pv6372
theorem pv6369 : R t6369 t1 := result (f := t6115) (a := t6368) (u := t1) (v := t6368) pv6115 (aw (ri t6368)) pv6368
end Blc.H44.Pump
