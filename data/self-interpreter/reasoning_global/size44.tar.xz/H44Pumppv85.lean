import H44Pumppv84
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6053 : R t6053 t1 := result (f := t6051) (a := t1) (u := t6051) (v := t6057) (refl t6051) (awb t6026 t1 t1 t1 (cI)) pv6057
theorem pv6054 : R t6054 t1 := result (f := t6033) (a := t6053) (u := t1) (v := t6053) pv6033 (aw (ri t6053)) pv6053
theorem pv6055 : R t6055 t1 := result (f := t6054) (a := t6019) (u := t1) (v := t6019) pv6054 (aw (ri t6019)) pv6019
theorem pv6052 : R t6052 t1 := result (f := t6026) (a := t6051) (u := t6046) (v := t6055) pv6026 (awb t6033 t6019 t6051 t6053 (refl _)) pv6055
theorem pv6048 : R t6048 t1 := result (f := t6029) (a := t1) (u := t6029) (v := t6052) (refl t6029) (aw (ra t6026 t1)) pv6052
theorem pv6049 : R t6049 t1 := result (f := t6033) (a := t6048) (u := t1) (v := t6048) pv6033 (aw (ri t6048)) pv6048
theorem pv6050 : R t6050 t1 := result (f := t6049) (a := t6019) (u := t1) (v := t6019) pv6049 (aw (ri t6019)) pv6019
theorem pv6030 : R t6030 t1 := result (f := t6026) (a := t6029) (u := t6046) (v := t6050) pv6026 (awb t6033 t6019 t6029 t6048 (refl _)) pv6050
theorem pv6027 : R t6027 t1 := result (f := t0) (a := t6026) (u := t0) (v := t6030) (refl t0) (aw (rh t6026)) pv6030
theorem pv6028 : R t6028 t1 := result (f := t6027) (a := t6019) (u := t1) (v := t6019) pv6027 (aw (ri t6019)) pv6019
theorem pv6025 : R t6025 t1 := result (f := t6022) (a := t6024) (u := t6022) (v := t6028) (refl t6022) (awb t0 t6019 t6024 t6026 (refl _)) pv6028
theorem pv6023 : R t6023 t1 := result (f := t0) (a := t6022) (u := t0) (v := t6025) (refl t0) (aw (rh t6022)) pv6025
theorem pv6020 : R t6020 t1 := result (f := t2) (a := t6019) (u := t2) (v := t6023) (refl t2) (aw (ra t0 t6019)) pv6023
theorem pv6021 : R t6021 t1 := result (f := t6020) (a := t5686) (u := t1) (v := t5686) pv6020 (aw (ri t5686)) pv5686
theorem pv6018 : R t6018 t1 := result (f := t5695) (a := t6017) (u := t5689) (v := t6021) pv5695 (awb t2 t5686 t6017 t6019 (refl _)) pv6021
theorem pv5992 : R t5992 t1 := result (f := t5698) (a := t1) (u := t5698) (v := t6018) (refl t5698) (aw (ra t5695 t1)) pv6018
theorem pv6016 : R t6016 t1 := result (f := t28) (a := t5992) (u := t1) (v := t5992) pv28 (aw (ri t5992)) pv5992
theorem pv6012 : R t6012 t1 := result (f := t6011) (a := t1) (u := t6014) (v := t6016) pv6011 (awb t1 t5992 t1 t1 (cI)) pv6016
theorem pv6006 : R t6006 t1 := result (f := t6004) (a := t1) (u := t6004) (v := t6012) (refl t6004) (awb t5995 t1 t1 t1 (cI)) pv6012
theorem pv6010 : R t6010 t6009 := result (f := t6006) (a := t6009) (u := t1) (v := t6009) pv6006 (aw (ri t6009)) (refl t6009)
theorem pv6007 : R t6007 t6009 := result (f := t0) (a := t6006) (u := t0) (v := t6010) (refl t0) (aw (rh t6006)) pv6010
theorem pv6061 : R t6061 t6060 := result (f := t6006) (a := t6060) (u := t1) (v := t6060) pv6006 (aw (ri t6060)) (refl t6060)
theorem pv6008 : R t6008 t6060 := result (f := t6007) (a := t5992) (u := t6009) (v := t6061) pv6007 (aw (ra t6006 t5992)) pv6061
theorem pv6005 : R t6005 t6060 := result (f := t5995) (a := t6004) (u := t5995) (v := t6008) (refl t5995) (awb t0 t5992 t6004 t6006 (refl _)) pv6008
theorem pv5999 : R t5999 t6060 := result (f := t5997) (a := t1) (u := t5997) (v := t6005) (refl t5997) (aw (ra t5995 t1)) pv6005
theorem pv6072 : R t6072 t1 := result (f := t6006) (a := t1) (u := t1) (v := t1) pv6006 (aw (ri t1)) (refl t1)
theorem pv6073 : R t6073 t1 := result (f := t6072) (a := t5992) (u := t1) (v := t5992) pv6072 (aw (ri t5992)) pv5992
theorem pv6070 : R t6070 t1 := result (f := t5999) (a := t1) (u := t6060) (v := t6073) pv5999 (awb t6006 t5992 t1 t1 (cI)) pv6073
theorem pv6071 : R t6071 t1 := result (f := t6070) (a := t1) (u := t1) (v := t1) pv6070 (aw (ri t1)) (refl t1)
theorem pv6067 : R t6067 t1 := result (f := t6065) (a := t1) (u := t6065) (v := t6071) (refl t6065) (awb t5999 t1 t1 t1 (cI)) pv6071
theorem pv6068 : R t6068 t1 := result (f := t6006) (a := t6067) (u := t1) (v := t6067) pv6006 (aw (ri t6067)) pv6067
theorem pv6069 : R t6069 t1 := result (f := t6068) (a := t5992) (u := t1) (v := t5992) pv6068 (aw (ri t5992)) pv5992
theorem pv6066 : R t6066 t1 := result (f := t5999) (a := t6065) (u := t6060) (v := t6069) pv5999 (awb t6006 t5992 t6065 t6067 (refl _)) pv6069
theorem pv6062 : R t6062 t1 := result (f := t6002) (a := t1) (u := t6002) (v := t6066) (refl t6002) (aw (ra t5999 t1)) pv6066
theorem pv6063 : R t6063 t1 := result (f := t6006) (a := t6062) (u := t1) (v := t6062) pv6006 (aw (ri t6062)) pv6062
theorem pv6064 : R t6064 t1 := result (f := t6063) (a := t5992) (u := t1) (v := t5992) pv6063 (aw (ri t5992)) pv5992
theorem pv6003 : R t6003 t1 := result (f := t5999) (a := t6002) (u := t6060) (v := t6064) pv5999 (awb t6006 t5992 t6002 t6062 (refl _)) pv6064
theorem pv6000 : R t6000 t1 := result (f := t0) (a := t5999) (u := t0) (v := t6003) (refl t0) (aw (rh t5999)) pv6003
theorem pv6001 : R t6001 t1 := result (f := t6000) (a := t5992) (u := t1) (v := t5992) pv6000 (aw (ri t5992)) pv5992
theorem pv5998 : R t5998 t1 := result (f := t5995) (a := t5997) (u := t5995) (v := t6001) (refl t5995) (awb t0 t5992 t5997 t5999 (refl _)) pv6001
theorem pv5996 : R t5996 t1 := result (f := t0) (a := t5995) (u := t0) (v := t5998) (refl t0) (aw (rh t5995)) pv5998
theorem pv5993 : R t5993 t1 := result (f := t2) (a := t5992) (u := t2) (v := t5996) (refl t2) (aw (ra t0 t5992)) pv5996
theorem pv5994 : R t5994 t1 := result (f := t5993) (a := t5686) (u := t1) (v := t5686) pv5993 (aw (ri t5686)) pv5686
theorem pv5699 : R t5699 t1 := result (f := t5695) (a := t5698) (u := t5689) (v := t5994) pv5695 (awb t2 t5686 t5698 t5992 (refl _)) pv5994
theorem pv5696 : R t5696 t1 := result (f := t0) (a := t5695) (u := t0) (v := t5699) (refl t0) (aw (rh t5695)) pv5699
theorem pv5697 : R t5697 t5689 := result (f := t5696) (a := t5689) (u := t1) (v := t5689) pv5696 (aw (ri t5689)) (refl t5689)
theorem pv5694 : R t5694 t5689 := result (f := t5691) (a := t5693) (u := t5691) (v := t5697) (refl t5691) (awb t0 t5689 t5693 t5695 (refl _)) pv5697
theorem pv5692 : R t5692 t5689 := result (f := t0) (a := t5691) (u := t0) (v := t5694) (refl t0) (aw (rh t5691)) pv5694
theorem pv5690 : R t5690 t5689 := result (f := t2) (a := t5689) (u := t2) (v := t5692) (refl t2) (aw (ra t0 t5689)) pv5692
theorem pv5687 : R t5687 t5689 := result (f := t59) (a := t5686) (u := t46) (v := t5690) pv59 (aw (ra t2 t5686)) pv5690
theorem pv5688 : R t5688 t1 := result (f := t5687) (a := t1) (u := t5689) (v := t5767) pv5687 (awb t2 t5686 t1 t1 (cI)) pv5767
theorem pv112 : R t112 t1 := result (f := t108) (a := t111) (u := t149) (v := t5688) pv108 (awb t59 t1 t111 t5686 (refl _)) pv5688
theorem pv109 : R t109 t1 := result (f := t0) (a := t108) (u := t0) (v := t112) (refl t0) (aw (rh t108)) pv112
theorem pv110 : R t110 t149 := result (f := t109) (a := t94) (u := t1) (v := t94) pv109 (aw (ri t94)) pv94
theorem pv107 : R t107 t149 := result (f := t97) (a := t106) (u := t97) (v := t110) (refl t97) (awb t0 t94 t106 t108 (refl _)) pv110
end Blc.H44.Pump
