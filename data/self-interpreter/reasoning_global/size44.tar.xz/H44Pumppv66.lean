import H44Pumppv65
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv4745 : R t4745 t4744 := result (f := t1) (a := t4744) (u := t1) (v := t4744) (refl t1) (aw (ri t4744)) (refl t4744)
theorem pv4743 : R t4743 t4744 := result (f := t22) (a := t4722) (u := t24) (v := t4745) pv22 (aw (ra t1 t4722)) pv4745
theorem pv4741 : R t4741 t4744 := result (f := t4725) (a := t1) (u := t4725) (v := t4743) (refl t4725) (awb t0 t4722 t1 t1 (cI)) pv4743
theorem pv4772 : R t4772 t4771 := result (f := t1) (a := t4771) (u := t1) (v := t4771) (refl t1) (aw (ri t4771)) (refl t4771)
theorem pv4770 : R t4770 t4771 := result (f := t22) (a := t4749) (u := t24) (v := t4772) pv22 (aw (ra t1 t4749)) pv4772
theorem pv4768 : R t4768 t4771 := result (f := t4752) (a := t1) (u := t4752) (v := t4770) (refl t4752) (awb t0 t4749 t1 t1 (cI)) pv4770
theorem pv4774 : R t4774 t1 := result (f := t4425) (a := t1) (u := t4419) (v := t4497) pv4425 (awb t2 t4416 t1 t1 (cI)) pv4497
theorem pv4775 : R t4775 t1 := result (f := t4774) (a := t1) (u := t1) (v := t1) pv4774 (aw (ri t1)) (refl t1)
theorem pv4749 : R t4749 t1 := result (f := t4747) (a := t1) (u := t4747) (v := t4775) (refl t4747) (awb t4425 t1 t1 t1 (cI)) pv4775
theorem pv4773 : R t4773 t1 := result (f := t28) (a := t4749) (u := t1) (v := t4749) pv28 (aw (ri t4749)) pv4749
theorem pv4769 : R t4769 t1 := result (f := t4768) (a := t1) (u := t4771) (v := t4773) pv4768 (awb t1 t4749 t1 t1 (cI)) pv4773
theorem pv4763 : R t4763 t1 := result (f := t4761) (a := t1) (u := t4761) (v := t4769) (refl t4761) (awb t4752 t1 t1 t1 (cI)) pv4769
theorem pv4767 : R t4767 t4766 := result (f := t4763) (a := t4766) (u := t1) (v := t4766) pv4763 (aw (ri t4766)) (refl t4766)
theorem pv4764 : R t4764 t4766 := result (f := t0) (a := t4763) (u := t0) (v := t4767) (refl t0) (aw (rh t4763)) pv4767
theorem pv4777 : R t4777 t4776 := result (f := t4763) (a := t4776) (u := t1) (v := t4776) pv4763 (aw (ri t4776)) (refl t4776)
theorem pv4765 : R t4765 t4776 := result (f := t4764) (a := t4749) (u := t4766) (v := t4777) pv4764 (aw (ra t4763 t4749)) pv4777
theorem pv4762 : R t4762 t4776 := result (f := t4752) (a := t4761) (u := t4752) (v := t4765) (refl t4752) (awb t0 t4749 t4761 t4763 (refl _)) pv4765
theorem pv4756 : R t4756 t4776 := result (f := t4754) (a := t1) (u := t4754) (v := t4762) (refl t4754) (aw (ra t4752 t1)) pv4762
theorem pv4788 : R t4788 t1 := result (f := t4763) (a := t1) (u := t1) (v := t1) pv4763 (aw (ri t1)) (refl t1)
theorem pv4789 : R t4789 t1 := result (f := t4788) (a := t4749) (u := t1) (v := t4749) pv4788 (aw (ri t4749)) pv4749
theorem pv4786 : R t4786 t1 := result (f := t4756) (a := t1) (u := t4776) (v := t4789) pv4756 (awb t4763 t4749 t1 t1 (cI)) pv4789
theorem pv4787 : R t4787 t1 := result (f := t4786) (a := t1) (u := t1) (v := t1) pv4786 (aw (ri t1)) (refl t1)
theorem pv4783 : R t4783 t1 := result (f := t4781) (a := t1) (u := t4781) (v := t4787) (refl t4781) (awb t4756 t1 t1 t1 (cI)) pv4787
theorem pv4784 : R t4784 t1 := result (f := t4763) (a := t4783) (u := t1) (v := t4783) pv4763 (aw (ri t4783)) pv4783
theorem pv4785 : R t4785 t1 := result (f := t4784) (a := t4749) (u := t1) (v := t4749) pv4784 (aw (ri t4749)) pv4749
theorem pv4782 : R t4782 t1 := result (f := t4756) (a := t4781) (u := t4776) (v := t4785) pv4756 (awb t4763 t4749 t4781 t4783 (refl _)) pv4785
theorem pv4778 : R t4778 t1 := result (f := t4759) (a := t1) (u := t4759) (v := t4782) (refl t4759) (aw (ra t4756 t1)) pv4782
theorem pv4779 : R t4779 t1 := result (f := t4763) (a := t4778) (u := t1) (v := t4778) pv4763 (aw (ri t4778)) pv4778
theorem pv4780 : R t4780 t1 := result (f := t4779) (a := t4749) (u := t1) (v := t4749) pv4779 (aw (ri t4749)) pv4749
theorem pv4760 : R t4760 t1 := result (f := t4756) (a := t4759) (u := t4776) (v := t4780) pv4756 (awb t4763 t4749 t4759 t4778 (refl _)) pv4780
theorem pv4757 : R t4757 t1 := result (f := t0) (a := t4756) (u := t0) (v := t4760) (refl t0) (aw (rh t4756)) pv4760
theorem pv4758 : R t4758 t1 := result (f := t4757) (a := t4749) (u := t1) (v := t4749) pv4757 (aw (ri t4749)) pv4749
theorem pv4755 : R t4755 t1 := result (f := t4752) (a := t4754) (u := t4752) (v := t4758) (refl t4752) (awb t0 t4749 t4754 t4756 (refl _)) pv4758
theorem pv4753 : R t4753 t1 := result (f := t0) (a := t4752) (u := t0) (v := t4755) (refl t0) (aw (rh t4752)) pv4755
theorem pv4750 : R t4750 t1 := result (f := t2) (a := t4749) (u := t2) (v := t4753) (refl t2) (aw (ra t0 t4749)) pv4753
theorem pv4751 : R t4751 t1 := result (f := t4750) (a := t4416) (u := t1) (v := t4416) pv4750 (aw (ri t4416)) pv4416
theorem pv4748 : R t4748 t1 := result (f := t4425) (a := t4747) (u := t4419) (v := t4751) pv4425 (awb t2 t4416 t4747 t4749 (refl _)) pv4751
theorem pv4722 : R t4722 t1 := result (f := t4428) (a := t1) (u := t4428) (v := t4748) (refl t4428) (aw (ra t4425 t1)) pv4748
theorem pv4746 : R t4746 t1 := result (f := t28) (a := t4722) (u := t1) (v := t4722) pv28 (aw (ri t4722)) pv4722
theorem pv4742 : R t4742 t1 := result (f := t4741) (a := t1) (u := t4744) (v := t4746) pv4741 (awb t1 t4722 t1 t1 (cI)) pv4746
theorem pv4736 : R t4736 t1 := result (f := t4734) (a := t1) (u := t4734) (v := t4742) (refl t4734) (awb t4725 t1 t1 t1 (cI)) pv4742
theorem pv4740 : R t4740 t4739 := result (f := t4736) (a := t4739) (u := t1) (v := t4739) pv4736 (aw (ri t4739)) (refl t4739)
theorem pv4737 : R t4737 t4739 := result (f := t0) (a := t4736) (u := t0) (v := t4740) (refl t0) (aw (rh t4736)) pv4740
theorem pv4791 : R t4791 t4790 := result (f := t4736) (a := t4790) (u := t1) (v := t4790) pv4736 (aw (ri t4790)) (refl t4790)
theorem pv4738 : R t4738 t4790 := result (f := t4737) (a := t4722) (u := t4739) (v := t4791) pv4737 (aw (ra t4736 t4722)) pv4791
theorem pv4735 : R t4735 t4790 := result (f := t4725) (a := t4734) (u := t4725) (v := t4738) (refl t4725) (awb t0 t4722 t4734 t4736 (refl _)) pv4738
theorem pv4729 : R t4729 t4790 := result (f := t4727) (a := t1) (u := t4727) (v := t4735) (refl t4727) (aw (ra t4725 t1)) pv4735
theorem pv4802 : R t4802 t1 := result (f := t4736) (a := t1) (u := t1) (v := t1) pv4736 (aw (ri t1)) (refl t1)
theorem pv4803 : R t4803 t1 := result (f := t4802) (a := t4722) (u := t1) (v := t4722) pv4802 (aw (ri t4722)) pv4722
theorem pv4800 : R t4800 t1 := result (f := t4729) (a := t1) (u := t4790) (v := t4803) pv4729 (awb t4736 t4722 t1 t1 (cI)) pv4803
theorem pv4801 : R t4801 t1 := result (f := t4800) (a := t1) (u := t1) (v := t1) pv4800 (aw (ri t1)) (refl t1)
theorem pv4797 : R t4797 t1 := result (f := t4795) (a := t1) (u := t4795) (v := t4801) (refl t4795) (awb t4729 t1 t1 t1 (cI)) pv4801
theorem pv4798 : R t4798 t1 := result (f := t4736) (a := t4797) (u := t1) (v := t4797) pv4736 (aw (ri t4797)) pv4797
theorem pv4799 : R t4799 t1 := result (f := t4798) (a := t4722) (u := t1) (v := t4722) pv4798 (aw (ri t4722)) pv4722
theorem pv4796 : R t4796 t1 := result (f := t4729) (a := t4795) (u := t4790) (v := t4799) pv4729 (awb t4736 t4722 t4795 t4797 (refl _)) pv4799
end Blc.H44.Pump
