import H44Ordered0P128
namespace Blc.H44Chain
open Term SelfintControl SelfintLowerBound ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
private def sentinel (t : Term) : Nat := (blcCode t).foldl (fun n b => 2*n + if b then 1 else 0) 1
def e4846363262038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e4846363262038 : Closed e4846363262038 ∧ sentinel e4846363262038 = 22438549306454 := by decide
theorem ex_e4846363262038 : ¬ IsSelfInterpreter e4846363262038 := by
  intro he
  have hz := necessary gm0 (m := (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))) (by decide) (by decide) sm0_16 he (oh0_143 (rho (n := 3) 1 0))
  exact (by decide : ¬ eval gm0 (rho (n := 3) 1 0) (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))) (.var 0)) ≤ opm0 (opm0 2 1) 1) hz
#print axioms ex_e4846363262038

end Blc.H44Chain
