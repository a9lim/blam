import H44Pumppv14
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1160 : R t1160 t1 := result (f := t0) (a := t1159) (u := t0) (v := t1162) (refl t0) (aw (rh t1159)) pv1162
theorem pv1157 : R t1157 t1 := result (f := t2) (a := t1156) (u := t2) (v := t1160) (refl t2) (aw (ra t0 t1156)) pv1160
theorem pv1158 : R t1158 t1 := result (f := t1157) (a := t823) (u := t1) (v := t823) pv1157 (aw (ri t823)) pv823
theorem pv1155 : R t1155 t1 := result (f := t832) (a := t1154) (u := t826) (v := t1158) pv832 (awb t2 t823 t1154 t1156 (refl _)) pv1158
theorem pv1129 : R t1129 t1 := result (f := t835) (a := t1) (u := t835) (v := t1155) (refl t835) (aw (ra t832 t1)) pv1155
theorem pv1153 : R t1153 t1 := result (f := t28) (a := t1129) (u := t1) (v := t1129) pv28 (aw (ri t1129)) pv1129
theorem pv1149 : R t1149 t1 := result (f := t1148) (a := t1) (u := t1151) (v := t1153) pv1148 (awb t1 t1129 t1 t1 (cI)) pv1153
theorem pv1143 : R t1143 t1 := result (f := t1141) (a := t1) (u := t1141) (v := t1149) (refl t1141) (awb t1132 t1 t1 t1 (cI)) pv1149
theorem pv1147 : R t1147 t1146 := result (f := t1143) (a := t1146) (u := t1) (v := t1146) pv1143 (aw (ri t1146)) (refl t1146)
theorem pv1144 : R t1144 t1146 := result (f := t0) (a := t1143) (u := t0) (v := t1147) (refl t0) (aw (rh t1143)) pv1147
theorem pv1198 : R t1198 t1197 := result (f := t1143) (a := t1197) (u := t1) (v := t1197) pv1143 (aw (ri t1197)) (refl t1197)
theorem pv1145 : R t1145 t1197 := result (f := t1144) (a := t1129) (u := t1146) (v := t1198) pv1144 (aw (ra t1143 t1129)) pv1198
theorem pv1142 : R t1142 t1197 := result (f := t1132) (a := t1141) (u := t1132) (v := t1145) (refl t1132) (awb t0 t1129 t1141 t1143 (refl _)) pv1145
theorem pv1136 : R t1136 t1197 := result (f := t1134) (a := t1) (u := t1134) (v := t1142) (refl t1134) (aw (ra t1132 t1)) pv1142
theorem pv1209 : R t1209 t1 := result (f := t1143) (a := t1) (u := t1) (v := t1) pv1143 (aw (ri t1)) (refl t1)
theorem pv1210 : R t1210 t1 := result (f := t1209) (a := t1129) (u := t1) (v := t1129) pv1209 (aw (ri t1129)) pv1129
theorem pv1207 : R t1207 t1 := result (f := t1136) (a := t1) (u := t1197) (v := t1210) pv1136 (awb t1143 t1129 t1 t1 (cI)) pv1210
theorem pv1208 : R t1208 t1 := result (f := t1207) (a := t1) (u := t1) (v := t1) pv1207 (aw (ri t1)) (refl t1)
theorem pv1204 : R t1204 t1 := result (f := t1202) (a := t1) (u := t1202) (v := t1208) (refl t1202) (awb t1136 t1 t1 t1 (cI)) pv1208
theorem pv1205 : R t1205 t1 := result (f := t1143) (a := t1204) (u := t1) (v := t1204) pv1143 (aw (ri t1204)) pv1204
theorem pv1206 : R t1206 t1 := result (f := t1205) (a := t1129) (u := t1) (v := t1129) pv1205 (aw (ri t1129)) pv1129
theorem pv1203 : R t1203 t1 := result (f := t1136) (a := t1202) (u := t1197) (v := t1206) pv1136 (awb t1143 t1129 t1202 t1204 (refl _)) pv1206
theorem pv1199 : R t1199 t1 := result (f := t1139) (a := t1) (u := t1139) (v := t1203) (refl t1139) (aw (ra t1136 t1)) pv1203
theorem pv1200 : R t1200 t1 := result (f := t1143) (a := t1199) (u := t1) (v := t1199) pv1143 (aw (ri t1199)) pv1199
theorem pv1201 : R t1201 t1 := result (f := t1200) (a := t1129) (u := t1) (v := t1129) pv1200 (aw (ri t1129)) pv1129
theorem pv1140 : R t1140 t1 := result (f := t1136) (a := t1139) (u := t1197) (v := t1201) pv1136 (awb t1143 t1129 t1139 t1199 (refl _)) pv1201
theorem pv1137 : R t1137 t1 := result (f := t0) (a := t1136) (u := t0) (v := t1140) (refl t0) (aw (rh t1136)) pv1140
theorem pv1138 : R t1138 t1 := result (f := t1137) (a := t1129) (u := t1) (v := t1129) pv1137 (aw (ri t1129)) pv1129
theorem pv1135 : R t1135 t1 := result (f := t1132) (a := t1134) (u := t1132) (v := t1138) (refl t1132) (awb t0 t1129 t1134 t1136 (refl _)) pv1138
theorem pv1133 : R t1133 t1 := result (f := t0) (a := t1132) (u := t0) (v := t1135) (refl t0) (aw (rh t1132)) pv1135
theorem pv1130 : R t1130 t1 := result (f := t2) (a := t1129) (u := t2) (v := t1133) (refl t2) (aw (ra t0 t1129)) pv1133
theorem pv1131 : R t1131 t1 := result (f := t1130) (a := t823) (u := t1) (v := t823) pv1130 (aw (ri t823)) pv823
theorem pv836 : R t836 t1 := result (f := t832) (a := t835) (u := t826) (v := t1131) pv832 (awb t2 t823 t835 t1129 (refl _)) pv1131
theorem pv833 : R t833 t1 := result (f := t0) (a := t832) (u := t0) (v := t836) (refl t0) (aw (rh t832)) pv836
theorem pv834 : R t834 t826 := result (f := t833) (a := t826) (u := t1) (v := t826) pv833 (aw (ri t826)) (refl t826)
theorem pv831 : R t831 t826 := result (f := t828) (a := t830) (u := t828) (v := t834) (refl t828) (awb t0 t826 t830 t832 (refl _)) pv834
theorem pv829 : R t829 t826 := result (f := t0) (a := t828) (u := t0) (v := t831) (refl t0) (aw (rh t828)) pv831
theorem pv827 : R t827 t826 := result (f := t2) (a := t826) (u := t2) (v := t829) (refl t2) (aw (ra t0 t826)) pv829
theorem pv824 : R t824 t826 := result (f := t59) (a := t823) (u := t46) (v := t827) pv59 (aw (ra t2 t823)) pv827
theorem pv825 : R t825 t1 := result (f := t824) (a := t1) (u := t826) (v := t904) pv824 (awb t2 t823 t1 t1 (cI)) pv904
theorem pv186 : R t186 t1 := result (f := t182) (a := t185) (u := t149) (v := t825) pv182 (awb t59 t1 t185 t823 (refl _)) pv825
theorem pv183 : R t183 t1 := result (f := t0) (a := t182) (u := t0) (v := t186) (refl t0) (aw (rh t182)) pv186
theorem pv184 : R t184 t149 := result (f := t183) (a := t175) (u := t1) (v := t175) pv183 (aw (ri t175)) pv175
theorem pv181 : R t181 t149 := result (f := t178) (a := t180) (u := t178) (v := t184) (refl t178) (awb t0 t175 t180 t182 (refl _)) pv184
theorem pv179 : R t179 t149 := result (f := t0) (a := t178) (u := t0) (v := t181) (refl t0) (aw (rh t178)) pv181
theorem pv176 : R t176 t149 := result (f := t2) (a := t175) (u := t2) (v := t179) (refl t2) (aw (ra t0 t175)) pv179
theorem pv1236 : R t1236 t1235 := result (f := t1) (a := t1235) (u := t1) (v := t1235) (refl t1) (aw (ri t1235)) (refl t1235)
theorem pv1234 : R t1234 t1235 := result (f := t22) (a := t1214) (u := t24) (v := t1236) pv22 (aw (ra t1 t1214)) pv1236
theorem pv1232 : R t1232 t1235 := result (f := t1216) (a := t1) (u := t1216) (v := t1234) (refl t1216) (awb t0 t1214 t1 t1 (cI)) pv1234
theorem pv1237 : R t1237 t1214 := result (f := t28) (a := t1214) (u := t1) (v := t1214) pv28 (aw (ri t1214)) (refl t1214)
theorem pv1233 : R t1233 t1214 := result (f := t1232) (a := t1) (u := t1235) (v := t1237) pv1232 (awb t1 t1214 t1 t1 (cI)) pv1237
theorem pv1227 : R t1227 t1214 := result (f := t1225) (a := t1) (u := t1225) (v := t1233) (refl t1225) (awb t1216 t1 t1 t1 (cI)) pv1233
theorem pv1261 : R t1261 t1260 := result (f := t1) (a := t1260) (u := t1) (v := t1260) (refl t1) (aw (ri t1260)) (refl t1260)
theorem pv1259 : R t1259 t1260 := result (f := t22) (a := t1238) (u := t24) (v := t1261) pv22 (aw (ra t1 t1238)) pv1261
theorem pv1257 : R t1257 t1260 := result (f := t1241) (a := t1) (u := t1241) (v := t1259) (refl t1241) (awb t0 t1238 t1 t1 (cI)) pv1259
end Blc.H44.Pump
