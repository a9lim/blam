import H44Pumppv15
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1288 : R t1288 t1287 := result (f := t1) (a := t1287) (u := t1) (v := t1287) (refl t1) (aw (ri t1287)) (refl t1287)
theorem pv1286 : R t1286 t1287 := result (f := t22) (a := t1265) (u := t24) (v := t1288) pv22 (aw (ra t1 t1265)) pv1288
theorem pv1284 : R t1284 t1287 := result (f := t1268) (a := t1) (u := t1268) (v := t1286) (refl t1268) (awb t0 t1265 t1 t1 (cI)) pv1286
theorem pv1211 : R t1211 t1 := result (f := t149) (a := t1) (u := t149) (v := t231) (refl t149) (awb t59 t1 t1 t1 (cI)) pv231
theorem pv1292 : R t1292 t1 := result (f := t3) (a := t1211) (u := t1) (v := t1211) pv3 (aw (ri t1211)) pv1211
theorem pv1290 : R t1290 t1 := result (f := t1227) (a := t1) (u := t1214) (v := t1292) pv1227 (awb t2 t1211 t1 t1 (cI)) pv1292
theorem pv1291 : R t1291 t1 := result (f := t1290) (a := t1) (u := t1) (v := t1) pv1290 (aw (ri t1)) (refl t1)
theorem pv1265 : R t1265 t1 := result (f := t1263) (a := t1) (u := t1263) (v := t1291) (refl t1263) (awb t1227 t1 t1 t1 (cI)) pv1291
theorem pv1289 : R t1289 t1 := result (f := t28) (a := t1265) (u := t1) (v := t1265) pv28 (aw (ri t1265)) pv1265
theorem pv1285 : R t1285 t1 := result (f := t1284) (a := t1) (u := t1287) (v := t1289) pv1284 (awb t1 t1265 t1 t1 (cI)) pv1289
theorem pv1279 : R t1279 t1 := result (f := t1277) (a := t1) (u := t1277) (v := t1285) (refl t1277) (awb t1268 t1 t1 t1 (cI)) pv1285
theorem pv1283 : R t1283 t1282 := result (f := t1279) (a := t1282) (u := t1) (v := t1282) pv1279 (aw (ri t1282)) (refl t1282)
theorem pv1280 : R t1280 t1282 := result (f := t0) (a := t1279) (u := t0) (v := t1283) (refl t0) (aw (rh t1279)) pv1283
theorem pv1294 : R t1294 t1293 := result (f := t1279) (a := t1293) (u := t1) (v := t1293) pv1279 (aw (ri t1293)) (refl t1293)
theorem pv1281 : R t1281 t1293 := result (f := t1280) (a := t1265) (u := t1282) (v := t1294) pv1280 (aw (ra t1279 t1265)) pv1294
theorem pv1278 : R t1278 t1293 := result (f := t1268) (a := t1277) (u := t1268) (v := t1281) (refl t1268) (awb t0 t1265 t1277 t1279 (refl _)) pv1281
theorem pv1272 : R t1272 t1293 := result (f := t1270) (a := t1) (u := t1270) (v := t1278) (refl t1270) (aw (ra t1268 t1)) pv1278
theorem pv1305 : R t1305 t1 := result (f := t1279) (a := t1) (u := t1) (v := t1) pv1279 (aw (ri t1)) (refl t1)
theorem pv1306 : R t1306 t1 := result (f := t1305) (a := t1265) (u := t1) (v := t1265) pv1305 (aw (ri t1265)) pv1265
theorem pv1303 : R t1303 t1 := result (f := t1272) (a := t1) (u := t1293) (v := t1306) pv1272 (awb t1279 t1265 t1 t1 (cI)) pv1306
theorem pv1304 : R t1304 t1 := result (f := t1303) (a := t1) (u := t1) (v := t1) pv1303 (aw (ri t1)) (refl t1)
theorem pv1300 : R t1300 t1 := result (f := t1298) (a := t1) (u := t1298) (v := t1304) (refl t1298) (awb t1272 t1 t1 t1 (cI)) pv1304
theorem pv1301 : R t1301 t1 := result (f := t1279) (a := t1300) (u := t1) (v := t1300) pv1279 (aw (ri t1300)) pv1300
theorem pv1302 : R t1302 t1 := result (f := t1301) (a := t1265) (u := t1) (v := t1265) pv1301 (aw (ri t1265)) pv1265
theorem pv1299 : R t1299 t1 := result (f := t1272) (a := t1298) (u := t1293) (v := t1302) pv1272 (awb t1279 t1265 t1298 t1300 (refl _)) pv1302
theorem pv1295 : R t1295 t1 := result (f := t1275) (a := t1) (u := t1275) (v := t1299) (refl t1275) (aw (ra t1272 t1)) pv1299
theorem pv1296 : R t1296 t1 := result (f := t1279) (a := t1295) (u := t1) (v := t1295) pv1279 (aw (ri t1295)) pv1295
theorem pv1297 : R t1297 t1 := result (f := t1296) (a := t1265) (u := t1) (v := t1265) pv1296 (aw (ri t1265)) pv1265
theorem pv1276 : R t1276 t1 := result (f := t1272) (a := t1275) (u := t1293) (v := t1297) pv1272 (awb t1279 t1265 t1275 t1295 (refl _)) pv1297
theorem pv1273 : R t1273 t1 := result (f := t0) (a := t1272) (u := t0) (v := t1276) (refl t0) (aw (rh t1272)) pv1276
theorem pv1274 : R t1274 t1 := result (f := t1273) (a := t1265) (u := t1) (v := t1265) pv1273 (aw (ri t1265)) pv1265
theorem pv1271 : R t1271 t1 := result (f := t1268) (a := t1270) (u := t1268) (v := t1274) (refl t1268) (awb t0 t1265 t1270 t1272 (refl _)) pv1274
theorem pv1269 : R t1269 t1 := result (f := t0) (a := t1268) (u := t0) (v := t1271) (refl t0) (aw (rh t1268)) pv1271
theorem pv1266 : R t1266 t1 := result (f := t2) (a := t1265) (u := t2) (v := t1269) (refl t2) (aw (ra t0 t1265)) pv1269
theorem pv1267 : R t1267 t1 := result (f := t1266) (a := t1211) (u := t1) (v := t1211) pv1266 (aw (ri t1211)) pv1211
theorem pv1264 : R t1264 t1 := result (f := t1227) (a := t1263) (u := t1214) (v := t1267) pv1227 (awb t2 t1211 t1263 t1265 (refl _)) pv1267
theorem pv1238 : R t1238 t1 := result (f := t1230) (a := t1) (u := t1230) (v := t1264) (refl t1230) (aw (ra t1227 t1)) pv1264
theorem pv1262 : R t1262 t1 := result (f := t28) (a := t1238) (u := t1) (v := t1238) pv28 (aw (ri t1238)) pv1238
theorem pv1258 : R t1258 t1 := result (f := t1257) (a := t1) (u := t1260) (v := t1262) pv1257 (awb t1 t1238 t1 t1 (cI)) pv1262
theorem pv1252 : R t1252 t1 := result (f := t1250) (a := t1) (u := t1250) (v := t1258) (refl t1250) (awb t1241 t1 t1 t1 (cI)) pv1258
theorem pv1256 : R t1256 t1255 := result (f := t1252) (a := t1255) (u := t1) (v := t1255) pv1252 (aw (ri t1255)) (refl t1255)
theorem pv1253 : R t1253 t1255 := result (f := t0) (a := t1252) (u := t0) (v := t1256) (refl t0) (aw (rh t1252)) pv1256
theorem pv1308 : R t1308 t1307 := result (f := t1252) (a := t1307) (u := t1) (v := t1307) pv1252 (aw (ri t1307)) (refl t1307)
theorem pv1254 : R t1254 t1307 := result (f := t1253) (a := t1238) (u := t1255) (v := t1308) pv1253 (aw (ra t1252 t1238)) pv1308
theorem pv1251 : R t1251 t1307 := result (f := t1241) (a := t1250) (u := t1241) (v := t1254) (refl t1241) (awb t0 t1238 t1250 t1252 (refl _)) pv1254
theorem pv1245 : R t1245 t1307 := result (f := t1243) (a := t1) (u := t1243) (v := t1251) (refl t1243) (aw (ra t1241 t1)) pv1251
theorem pv1319 : R t1319 t1 := result (f := t1252) (a := t1) (u := t1) (v := t1) pv1252 (aw (ri t1)) (refl t1)
theorem pv1320 : R t1320 t1 := result (f := t1319) (a := t1238) (u := t1) (v := t1238) pv1319 (aw (ri t1238)) pv1238
theorem pv1317 : R t1317 t1 := result (f := t1245) (a := t1) (u := t1307) (v := t1320) pv1245 (awb t1252 t1238 t1 t1 (cI)) pv1320
theorem pv1318 : R t1318 t1 := result (f := t1317) (a := t1) (u := t1) (v := t1) pv1317 (aw (ri t1)) (refl t1)
theorem pv1314 : R t1314 t1 := result (f := t1312) (a := t1) (u := t1312) (v := t1318) (refl t1312) (awb t1245 t1 t1 t1 (cI)) pv1318
theorem pv1315 : R t1315 t1 := result (f := t1252) (a := t1314) (u := t1) (v := t1314) pv1252 (aw (ri t1314)) pv1314
theorem pv1316 : R t1316 t1 := result (f := t1315) (a := t1238) (u := t1) (v := t1238) pv1315 (aw (ri t1238)) pv1238
theorem pv1313 : R t1313 t1 := result (f := t1245) (a := t1312) (u := t1307) (v := t1316) pv1245 (awb t1252 t1238 t1312 t1314 (refl _)) pv1316
theorem pv1309 : R t1309 t1 := result (f := t1248) (a := t1) (u := t1248) (v := t1313) (refl t1248) (aw (ra t1245 t1)) pv1313
end Blc.H44.Pump
