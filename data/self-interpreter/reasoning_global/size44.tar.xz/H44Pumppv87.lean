import H44Pumppv86
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6218 : R t6218 t1 := result (f := t6215) (a := t6217) (u := t6215) (v := t6221) (refl t6215) (awb t0 t6212 t6217 t6219 (refl _)) pv6221
theorem pv6216 : R t6216 t1 := result (f := t0) (a := t6215) (u := t0) (v := t6218) (refl t0) (aw (rh t6215)) pv6218
theorem pv6213 : R t6213 t1 := result (f := t2) (a := t6212) (u := t2) (v := t6216) (refl t2) (aw (ra t0 t6212)) pv6216
theorem pv6214 : R t6214 t1 := result (f := t6213) (a := t6158) (u := t1) (v := t6158) pv6213 (aw (ri t6158)) pv6158
theorem pv6211 : R t6211 t1 := result (f := t6174) (a := t6210) (u := t6161) (v := t6214) pv6174 (awb t2 t6158 t6210 t6212 (refl _)) pv6214
theorem pv6185 : R t6185 t1 := result (f := t6177) (a := t1) (u := t6177) (v := t6211) (refl t6177) (aw (ra t6174 t1)) pv6211
theorem pv6209 : R t6209 t1 := result (f := t28) (a := t6185) (u := t1) (v := t6185) pv28 (aw (ri t6185)) pv6185
theorem pv6205 : R t6205 t1 := result (f := t6204) (a := t1) (u := t6207) (v := t6209) pv6204 (awb t1 t6185 t1 t1 (cI)) pv6209
theorem pv6199 : R t6199 t1 := result (f := t6197) (a := t1) (u := t6197) (v := t6205) (refl t6197) (awb t6188 t1 t1 t1 (cI)) pv6205
theorem pv6203 : R t6203 t6202 := result (f := t6199) (a := t6202) (u := t1) (v := t6202) pv6199 (aw (ri t6202)) (refl t6202)
theorem pv6200 : R t6200 t6202 := result (f := t0) (a := t6199) (u := t0) (v := t6203) (refl t0) (aw (rh t6199)) pv6203
theorem pv6257 : R t6257 t6256 := result (f := t6199) (a := t6256) (u := t1) (v := t6256) pv6199 (aw (ri t6256)) (refl t6256)
theorem pv6201 : R t6201 t6256 := result (f := t6200) (a := t6185) (u := t6202) (v := t6257) pv6200 (aw (ra t6199 t6185)) pv6257
theorem pv6198 : R t6198 t6256 := result (f := t6188) (a := t6197) (u := t6188) (v := t6201) (refl t6188) (awb t0 t6185 t6197 t6199 (refl _)) pv6201
theorem pv6192 : R t6192 t6256 := result (f := t6190) (a := t1) (u := t6190) (v := t6198) (refl t6190) (aw (ra t6188 t1)) pv6198
theorem pv6268 : R t6268 t1 := result (f := t6199) (a := t1) (u := t1) (v := t1) pv6199 (aw (ri t1)) (refl t1)
theorem pv6269 : R t6269 t1 := result (f := t6268) (a := t6185) (u := t1) (v := t6185) pv6268 (aw (ri t6185)) pv6185
theorem pv6266 : R t6266 t1 := result (f := t6192) (a := t1) (u := t6256) (v := t6269) pv6192 (awb t6199 t6185 t1 t1 (cI)) pv6269
theorem pv6267 : R t6267 t1 := result (f := t6266) (a := t1) (u := t1) (v := t1) pv6266 (aw (ri t1)) (refl t1)
theorem pv6263 : R t6263 t1 := result (f := t6261) (a := t1) (u := t6261) (v := t6267) (refl t6261) (awb t6192 t1 t1 t1 (cI)) pv6267
theorem pv6264 : R t6264 t1 := result (f := t6199) (a := t6263) (u := t1) (v := t6263) pv6199 (aw (ri t6263)) pv6263
theorem pv6265 : R t6265 t1 := result (f := t6264) (a := t6185) (u := t1) (v := t6185) pv6264 (aw (ri t6185)) pv6185
theorem pv6262 : R t6262 t1 := result (f := t6192) (a := t6261) (u := t6256) (v := t6265) pv6192 (awb t6199 t6185 t6261 t6263 (refl _)) pv6265
theorem pv6258 : R t6258 t1 := result (f := t6195) (a := t1) (u := t6195) (v := t6262) (refl t6195) (aw (ra t6192 t1)) pv6262
theorem pv6259 : R t6259 t1 := result (f := t6199) (a := t6258) (u := t1) (v := t6258) pv6199 (aw (ri t6258)) pv6258
theorem pv6260 : R t6260 t1 := result (f := t6259) (a := t6185) (u := t1) (v := t6185) pv6259 (aw (ri t6185)) pv6185
theorem pv6196 : R t6196 t1 := result (f := t6192) (a := t6195) (u := t6256) (v := t6260) pv6192 (awb t6199 t6185 t6195 t6258 (refl _)) pv6260
theorem pv6193 : R t6193 t1 := result (f := t0) (a := t6192) (u := t0) (v := t6196) (refl t0) (aw (rh t6192)) pv6196
theorem pv6194 : R t6194 t1 := result (f := t6193) (a := t6185) (u := t1) (v := t6185) pv6193 (aw (ri t6185)) pv6185
theorem pv6191 : R t6191 t1 := result (f := t6188) (a := t6190) (u := t6188) (v := t6194) (refl t6188) (awb t0 t6185 t6190 t6192 (refl _)) pv6194
theorem pv6189 : R t6189 t1 := result (f := t0) (a := t6188) (u := t0) (v := t6191) (refl t0) (aw (rh t6188)) pv6191
theorem pv6186 : R t6186 t1 := result (f := t2) (a := t6185) (u := t2) (v := t6189) (refl t2) (aw (ra t0 t6185)) pv6189
theorem pv6187 : R t6187 t1 := result (f := t6186) (a := t6158) (u := t1) (v := t6158) pv6186 (aw (ri t6158)) pv6158
theorem pv6178 : R t6178 t1 := result (f := t6174) (a := t6177) (u := t6161) (v := t6187) pv6174 (awb t2 t6158 t6177 t6185 (refl _)) pv6187
theorem pv6175 : R t6175 t1 := result (f := t0) (a := t6174) (u := t0) (v := t6178) (refl t0) (aw (rh t6174)) pv6178
theorem pv6176 : R t6176 t6161 := result (f := t6175) (a := t6161) (u := t1) (v := t6161) pv6175 (aw (ri t6161)) (refl t6161)
theorem pv6173 : R t6173 t6161 := result (f := t6163) (a := t6172) (u := t6163) (v := t6176) (refl t6163) (awb t0 t6161 t6172 t6174 (refl _)) pv6176
theorem pv6167 : R t6167 t6161 := result (f := t6165) (a := t1) (u := t6165) (v := t6173) (refl t6165) (aw (ra t6163 t1)) pv6173
theorem pv6293 : R t6293 t6292 := result (f := t1) (a := t6292) (u := t1) (v := t6292) (refl t1) (aw (ri t6292)) (refl t6292)
theorem pv6291 : R t6291 t6292 := result (f := t22) (a := t6270) (u := t24) (v := t6293) pv22 (aw (ra t1 t6270)) pv6293
theorem pv6289 : R t6289 t6292 := result (f := t6273) (a := t1) (u := t6273) (v := t6291) (refl t6273) (awb t0 t6270 t1 t1 (cI)) pv6291
theorem pv6320 : R t6320 t6319 := result (f := t1) (a := t6319) (u := t1) (v := t6319) (refl t1) (aw (ri t6319)) (refl t6319)
theorem pv6318 : R t6318 t6319 := result (f := t22) (a := t6297) (u := t24) (v := t6320) pv22 (aw (ra t1 t6297)) pv6320
theorem pv6316 : R t6316 t6319 := result (f := t6300) (a := t1) (u := t6300) (v := t6318) (refl t6300) (awb t0 t6297 t1 t1 (cI)) pv6318
theorem pv6322 : R t6322 t1 := result (f := t6167) (a := t1) (u := t6161) (v := t6239) pv6167 (awb t2 t6158 t1 t1 (cI)) pv6239
theorem pv6323 : R t6323 t1 := result (f := t6322) (a := t1) (u := t1) (v := t1) pv6322 (aw (ri t1)) (refl t1)
theorem pv6297 : R t6297 t1 := result (f := t6295) (a := t1) (u := t6295) (v := t6323) (refl t6295) (awb t6167 t1 t1 t1 (cI)) pv6323
theorem pv6321 : R t6321 t1 := result (f := t28) (a := t6297) (u := t1) (v := t6297) pv28 (aw (ri t6297)) pv6297
theorem pv6317 : R t6317 t1 := result (f := t6316) (a := t1) (u := t6319) (v := t6321) pv6316 (awb t1 t6297 t1 t1 (cI)) pv6321
theorem pv6311 : R t6311 t1 := result (f := t6309) (a := t1) (u := t6309) (v := t6317) (refl t6309) (awb t6300 t1 t1 t1 (cI)) pv6317
theorem pv6315 : R t6315 t6314 := result (f := t6311) (a := t6314) (u := t1) (v := t6314) pv6311 (aw (ri t6314)) (refl t6314)
theorem pv6312 : R t6312 t6314 := result (f := t0) (a := t6311) (u := t0) (v := t6315) (refl t0) (aw (rh t6311)) pv6315
theorem pv6325 : R t6325 t6324 := result (f := t6311) (a := t6324) (u := t1) (v := t6324) pv6311 (aw (ri t6324)) (refl t6324)
theorem pv6313 : R t6313 t6324 := result (f := t6312) (a := t6297) (u := t6314) (v := t6325) pv6312 (aw (ra t6311 t6297)) pv6325
theorem pv6310 : R t6310 t6324 := result (f := t6300) (a := t6309) (u := t6300) (v := t6313) (refl t6300) (awb t0 t6297 t6309 t6311 (refl _)) pv6313
end Blc.H44.Pump
