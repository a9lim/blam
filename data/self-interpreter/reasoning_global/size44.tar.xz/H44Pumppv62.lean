import H44Pumppv61
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv4525 : R t4525 t4524 := result (f := t1) (a := t4524) (u := t1) (v := t4524) (refl t1) (aw (ri t4524)) (refl t4524)
theorem pv4523 : R t4523 t4524 := result (f := t22) (a := t4503) (u := t24) (v := t4525) pv22 (aw (ra t1 t4503)) pv4525
theorem pv4521 : R t4521 t4524 := result (f := t4505) (a := t1) (u := t4505) (v := t4523) (refl t4505) (awb t0 t4503 t1 t1 (cI)) pv4523
theorem pv4526 : R t4526 t4503 := result (f := t28) (a := t4503) (u := t1) (v := t4503) pv28 (aw (ri t4503)) (refl t4503)
theorem pv4522 : R t4522 t4503 := result (f := t4521) (a := t1) (u := t4524) (v := t4526) pv4521 (awb t1 t4503 t1 t1 (cI)) pv4526
theorem pv4516 : R t4516 t4503 := result (f := t4514) (a := t1) (u := t4514) (v := t4522) (refl t4514) (awb t4505 t1 t1 t1 (cI)) pv4522
theorem pv4550 : R t4550 t4549 := result (f := t1) (a := t4549) (u := t1) (v := t4549) (refl t1) (aw (ri t4549)) (refl t4549)
theorem pv4548 : R t4548 t4549 := result (f := t22) (a := t4527) (u := t24) (v := t4550) pv22 (aw (ra t1 t4527)) pv4550
theorem pv4546 : R t4546 t4549 := result (f := t4530) (a := t1) (u := t4530) (v := t4548) (refl t4530) (awb t0 t4527 t1 t1 (cI)) pv4548
theorem pv4577 : R t4577 t4576 := result (f := t1) (a := t4576) (u := t1) (v := t4576) (refl t1) (aw (ri t4576)) (refl t4576)
theorem pv4575 : R t4575 t4576 := result (f := t22) (a := t4554) (u := t24) (v := t4577) pv22 (aw (ra t1 t4554)) pv4577
theorem pv4573 : R t4573 t4576 := result (f := t4557) (a := t1) (u := t4557) (v := t4575) (refl t4557) (awb t0 t4554 t1 t1 (cI)) pv4575
theorem pv4582 : R t4582 t1 := result (f := t3967) (a := t1) (u := t149) (v := t231) pv3967 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv4583 : R t4583 t1 := result (f := t4582) (a := t1) (u := t1) (v := t1) pv4582 (aw (ri t1)) (refl t1)
theorem pv4500 : R t4500 t1 := result (f := t4498) (a := t1) (u := t4498) (v := t4583) (refl t4498) (awb t3967 t1 t1 t1 (cI)) pv4583
theorem pv4581 : R t4581 t1 := result (f := t3) (a := t4500) (u := t1) (v := t4500) pv3 (aw (ri t4500)) pv4500
theorem pv4579 : R t4579 t1 := result (f := t4516) (a := t1) (u := t4503) (v := t4581) pv4516 (awb t2 t4500 t1 t1 (cI)) pv4581
theorem pv4580 : R t4580 t1 := result (f := t4579) (a := t1) (u := t1) (v := t1) pv4579 (aw (ri t1)) (refl t1)
theorem pv4554 : R t4554 t1 := result (f := t4552) (a := t1) (u := t4552) (v := t4580) (refl t4552) (awb t4516 t1 t1 t1 (cI)) pv4580
theorem pv4578 : R t4578 t1 := result (f := t28) (a := t4554) (u := t1) (v := t4554) pv28 (aw (ri t4554)) pv4554
theorem pv4574 : R t4574 t1 := result (f := t4573) (a := t1) (u := t4576) (v := t4578) pv4573 (awb t1 t4554 t1 t1 (cI)) pv4578
theorem pv4568 : R t4568 t1 := result (f := t4566) (a := t1) (u := t4566) (v := t4574) (refl t4566) (awb t4557 t1 t1 t1 (cI)) pv4574
theorem pv4572 : R t4572 t4571 := result (f := t4568) (a := t4571) (u := t1) (v := t4571) pv4568 (aw (ri t4571)) (refl t4571)
theorem pv4569 : R t4569 t4571 := result (f := t0) (a := t4568) (u := t0) (v := t4572) (refl t0) (aw (rh t4568)) pv4572
theorem pv4585 : R t4585 t4584 := result (f := t4568) (a := t4584) (u := t1) (v := t4584) pv4568 (aw (ri t4584)) (refl t4584)
theorem pv4570 : R t4570 t4584 := result (f := t4569) (a := t4554) (u := t4571) (v := t4585) pv4569 (aw (ra t4568 t4554)) pv4585
theorem pv4567 : R t4567 t4584 := result (f := t4557) (a := t4566) (u := t4557) (v := t4570) (refl t4557) (awb t0 t4554 t4566 t4568 (refl _)) pv4570
theorem pv4561 : R t4561 t4584 := result (f := t4559) (a := t1) (u := t4559) (v := t4567) (refl t4559) (aw (ra t4557 t1)) pv4567
theorem pv4596 : R t4596 t1 := result (f := t4568) (a := t1) (u := t1) (v := t1) pv4568 (aw (ri t1)) (refl t1)
theorem pv4597 : R t4597 t1 := result (f := t4596) (a := t4554) (u := t1) (v := t4554) pv4596 (aw (ri t4554)) pv4554
theorem pv4594 : R t4594 t1 := result (f := t4561) (a := t1) (u := t4584) (v := t4597) pv4561 (awb t4568 t4554 t1 t1 (cI)) pv4597
theorem pv4595 : R t4595 t1 := result (f := t4594) (a := t1) (u := t1) (v := t1) pv4594 (aw (ri t1)) (refl t1)
theorem pv4591 : R t4591 t1 := result (f := t4589) (a := t1) (u := t4589) (v := t4595) (refl t4589) (awb t4561 t1 t1 t1 (cI)) pv4595
theorem pv4592 : R t4592 t1 := result (f := t4568) (a := t4591) (u := t1) (v := t4591) pv4568 (aw (ri t4591)) pv4591
theorem pv4593 : R t4593 t1 := result (f := t4592) (a := t4554) (u := t1) (v := t4554) pv4592 (aw (ri t4554)) pv4554
theorem pv4590 : R t4590 t1 := result (f := t4561) (a := t4589) (u := t4584) (v := t4593) pv4561 (awb t4568 t4554 t4589 t4591 (refl _)) pv4593
theorem pv4586 : R t4586 t1 := result (f := t4564) (a := t1) (u := t4564) (v := t4590) (refl t4564) (aw (ra t4561 t1)) pv4590
theorem pv4587 : R t4587 t1 := result (f := t4568) (a := t4586) (u := t1) (v := t4586) pv4568 (aw (ri t4586)) pv4586
theorem pv4588 : R t4588 t1 := result (f := t4587) (a := t4554) (u := t1) (v := t4554) pv4587 (aw (ri t4554)) pv4554
theorem pv4565 : R t4565 t1 := result (f := t4561) (a := t4564) (u := t4584) (v := t4588) pv4561 (awb t4568 t4554 t4564 t4586 (refl _)) pv4588
theorem pv4562 : R t4562 t1 := result (f := t0) (a := t4561) (u := t0) (v := t4565) (refl t0) (aw (rh t4561)) pv4565
theorem pv4563 : R t4563 t1 := result (f := t4562) (a := t4554) (u := t1) (v := t4554) pv4562 (aw (ri t4554)) pv4554
theorem pv4560 : R t4560 t1 := result (f := t4557) (a := t4559) (u := t4557) (v := t4563) (refl t4557) (awb t0 t4554 t4559 t4561 (refl _)) pv4563
theorem pv4558 : R t4558 t1 := result (f := t0) (a := t4557) (u := t0) (v := t4560) (refl t0) (aw (rh t4557)) pv4560
theorem pv4555 : R t4555 t1 := result (f := t2) (a := t4554) (u := t2) (v := t4558) (refl t2) (aw (ra t0 t4554)) pv4558
theorem pv4556 : R t4556 t1 := result (f := t4555) (a := t4500) (u := t1) (v := t4500) pv4555 (aw (ri t4500)) pv4500
theorem pv4553 : R t4553 t1 := result (f := t4516) (a := t4552) (u := t4503) (v := t4556) pv4516 (awb t2 t4500 t4552 t4554 (refl _)) pv4556
theorem pv4527 : R t4527 t1 := result (f := t4519) (a := t1) (u := t4519) (v := t4553) (refl t4519) (aw (ra t4516 t1)) pv4553
theorem pv4551 : R t4551 t1 := result (f := t28) (a := t4527) (u := t1) (v := t4527) pv28 (aw (ri t4527)) pv4527
theorem pv4547 : R t4547 t1 := result (f := t4546) (a := t1) (u := t4549) (v := t4551) pv4546 (awb t1 t4527 t1 t1 (cI)) pv4551
theorem pv4541 : R t4541 t1 := result (f := t4539) (a := t1) (u := t4539) (v := t4547) (refl t4539) (awb t4530 t1 t1 t1 (cI)) pv4547
theorem pv4545 : R t4545 t4544 := result (f := t4541) (a := t4544) (u := t1) (v := t4544) pv4541 (aw (ri t4544)) (refl t4544)
theorem pv4542 : R t4542 t4544 := result (f := t0) (a := t4541) (u := t0) (v := t4545) (refl t0) (aw (rh t4541)) pv4545
theorem pv4599 : R t4599 t4598 := result (f := t4541) (a := t4598) (u := t1) (v := t4598) pv4541 (aw (ri t4598)) (refl t4598)
theorem pv4543 : R t4543 t4598 := result (f := t4542) (a := t4527) (u := t4544) (v := t4599) pv4542 (aw (ra t4541 t4527)) pv4599
end Blc.H44.Pump
