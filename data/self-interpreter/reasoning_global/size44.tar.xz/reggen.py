from wireterms import *
from regular_terms import probeType,C,R
import portable
import hashlib
def details(kind):
    aa=[];m=I
    if kind=='rigid':c,r=C,R
    elif kind.startswith('extra'):c,r=KI,R;aa=[om]*int(kind[5:])
    elif kind=='apply':c,r=L(L(V(1))),om;aa=[om,I]
    elif kind=='poison':c,r=L(L(I)),om
    elif kind=='suffix':c,r=KI,R
    elif kind=='value':c,r=L(L(V(1))),om
    else:raise KeyError(kind)
    return c,m,r,aa
def terms(s,kind,ps):
    e=lc.decode(s)[0]
    q=probeType(e,kind) if isinstance(kind,str) else query(e,kind)
    t=q
    for p in ps:t=red(t,p)
    return e,t
def query(e,kind):
    c,m,r,aa=unpack(kind)
    return appall(A(A(e,c),lc.bitlist(lc.enc(m),r)),aa)
def unpack(kind):return (*[lc.decode(x)[0] for x in kind[:3]],[lc.decode(x)[0] for x in kind[3]])
def make_pattern(c):
    live={st[0] for st in c['states']}
    def cut(p):
        if p not in live:return ('?',)
        tag,*args=c['nodes'][p]
        return (tag,args[0]) if tag=='V' else (tag,*(cut(i) for i in args))
    return cut(0)
def match(pattern,t):
    if pattern==('?',):return True
    if pattern[0]!=t[0]:return False
    if t[0]=='V':return pattern==t
    return all(match(p,x) for p,x in zip(pattern[1:],t[1:]))
def dt(kind):
    c,m,r,aa=details(kind) if isinstance(kind,str) else unpack(kind)
    t=appall(A(A(c,L(m)),r),aa)
    for k in range(100):
        p=head_path(t)
        if p is None:return c,m,r,aa,k
        t=bounded(t,p)
        assert t is not None
    raise AssertionError()
def emit(s,row,classic=False):
    _,kind,_,_,_,ps,c=row
    e,t=terms(s,kind,ps);pat=make_pattern(c)
    name='R'+str(int(s,2))
    # Prune every node never inspected by the checked regular machine.
    live={st[0] for st in c['states']}
    # Compact the code itself, moving each retained source position and
    # closure address together. An unentered subtree becomes one opaque cell.
    ts0=[]
    def wr(x):
        ts0.append(x)
        for y in x[1:]:
            if isinstance(y,tuple):wr(y)
    wr(t)
    ids={};nodes=[];ts=[]
    def cut(i):
        j=len(nodes);ids[i]=j;nodes.append(None);ts.append(ts0[i])
        tag,*args=c['nodes'][i]
        if i not in live:nodes[j]=['C',0]
        elif tag=='V':nodes[j]=[tag,*args]
        else:nodes[j]=[tag,*[cut(a) for a in args]]
        return j
    cut(0)
    def clo(v):return [ids[v[0]],v[1]]
    cs=dict(c,nodes=nodes,values=[[clo(x) for x in row] for row in c['values']],konts=[[[clo(v),k] for v,k in row] for row in c['konts']],states=[[ids[p],e,k] for p,e,k in c['states']])
    if classic:
        ts=ts0
        cs=dict(c,nodes=[n if i in live else ['C',0] for i,n in enumerate(c['nodes'])])
    txt=portable.lean(cs,name)
    txt=txt[:txt.index('theorem no_stop')].replace('import Regular','import Reg')
    txt=txt.replace(':= by decide\n',':= by decide +kernel\n')
    decl=['open Blc Blc.Term Blc.Floor44 Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp',f'def e : Term := {expr(e)}',f'theorem wire_e : Closed e ∧ code e = {int("1"+s,2)} := by decide'.replace('code e','Blc.Floor44.code e')]
    # Include constituents of opaque fillings in the symbol pool.
    look={u:i for i,u in enumerate(ts0)}
    for u in sorted(look,key=wire):
        rhs=f'.var {u[1]}' if u[0]=='V' else (f'.lam t{look[u[1]]}' if u[0]=='L' else f'.app t{look[u[1]]} t{look[u[2]]}')
        decl.append(f'def t{look[u]} : Term := {rhs}')
    decl.append('def terms : Array Term := #['+','.join('t'+str(look[u]) for u in ts)+']')
    decl.extend(['theorem ordered_code : ordered code = true := by decide +kernel','def model : Model P := codeModel (rankedCode code ordered_code) (regAt terms)'])
    for j in reversed(range(len(ts))):
        tag,*args=cs['nodes'][j]
        if tag=='A':
            f,x=args;pf=f'by rw [model.app_eq {j} {f} {x} (by rfl), n{f}, n{x}]; rfl'
        elif tag=='L':
            b=args[0];pf=f'by rw [model.lam_eq {j} {b} (by rfl), n{b}]; rfl'
        elif tag=='V':pf=f'model.var_eq {j} {args[0]} (by rfl)'
        else:pf=f'(opaqueTerm (rankedCode code ordered_code) (regAt terms) (p := {j}) (by rfl)).trans (by rfl)'
        decl.append(f'theorem n{j} : model.term {j} = t{look[ts[j]]} := {pf}')
    if classic:
        decl=decl[:decl.index('theorem ordered_code : ordered code = true := by decide +kernel')]
        decl.append('def model : Model P := regModel (cs := code) (ts := terms) (by decide)')
    reach='(rawCount he)';start='e'
    if kind!='raw':
        cont,m,r,aa,k=dt(kind)
        start=f'(call e {expr(cont)} {expr(m)} {expr(r)} ['+','.join(map(expr,aa))+'])'
        reach=f'(inputCount (k := {k}) he (by decide) (by decide))'
    decl.extend(['theorem excluded : ¬ IsSelfInterpreter e := by','  intro he',f'  have hp : replay {paths(ps)} {start} = some (model.term 0) := by rw [n0]; decide',f'  obtain ⟨n,h⟩ := clocks_replay {reach} hp','  exact regular_no_clock model closed root n h','#print axioms excluded',f'end Certgen.{name}'])
    # Local code array shadows the theorem of the same name.
    (HERE/(name+'.lean')).write_text(txt+'\n'+'\n'.join(decl)+'\n')
    if classic:
        dest=HERE/(name+'.lean')
        dest.write_text(dest.read_text().replace('by rw [n0]; decide','by decide'))
    return cs
if __name__=='__main__':
    for f in sorted((HERE/'reg').glob('*.json')):
        emit(f.stem,json.loads(f.read_text()))
