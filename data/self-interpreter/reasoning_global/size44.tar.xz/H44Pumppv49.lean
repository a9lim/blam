import H44Pumppv48
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3540 : R t3540 t1 := result (f := t3538) (a := t1) (u := t3538) (v := t3544) (refl t3538) (awb t3472 t1 t1 t1 (cI)) pv3544
theorem pv3541 : R t3541 t1 := result (f := t3479) (a := t3540) (u := t1) (v := t3540) pv3479 (aw (ri t3540)) pv3540
theorem pv3542 : R t3542 t1 := result (f := t3541) (a := t3465) (u := t1) (v := t3465) pv3541 (aw (ri t3465)) pv3465
theorem pv3539 : R t3539 t1 := result (f := t3472) (a := t3538) (u := t3533) (v := t3542) pv3472 (awb t3479 t3465 t3538 t3540 (refl _)) pv3542
theorem pv3535 : R t3535 t1 := result (f := t3475) (a := t1) (u := t3475) (v := t3539) (refl t3475) (aw (ra t3472 t1)) pv3539
theorem pv3536 : R t3536 t1 := result (f := t3479) (a := t3535) (u := t1) (v := t3535) pv3479 (aw (ri t3535)) pv3535
theorem pv3537 : R t3537 t1 := result (f := t3536) (a := t3465) (u := t1) (v := t3465) pv3536 (aw (ri t3465)) pv3465
theorem pv3476 : R t3476 t1 := result (f := t3472) (a := t3475) (u := t3533) (v := t3537) pv3472 (awb t3479 t3465 t3475 t3535 (refl _)) pv3537
theorem pv3473 : R t3473 t1 := result (f := t0) (a := t3472) (u := t0) (v := t3476) (refl t0) (aw (rh t3472)) pv3476
theorem pv3474 : R t3474 t1 := result (f := t3473) (a := t3465) (u := t1) (v := t3465) pv3473 (aw (ri t3465)) pv3465
theorem pv3471 : R t3471 t1 := result (f := t3468) (a := t3470) (u := t3468) (v := t3474) (refl t3468) (awb t0 t3465 t3470 t3472 (refl _)) pv3474
theorem pv3469 : R t3469 t1 := result (f := t0) (a := t3468) (u := t0) (v := t3471) (refl t0) (aw (rh t3468)) pv3471
theorem pv3466 : R t3466 t1 := result (f := t2) (a := t3465) (u := t2) (v := t3469) (refl t2) (aw (ra t0 t3465)) pv3469
theorem pv3467 : R t3467 t1 := result (f := t3466) (a := t3159) (u := t1) (v := t3159) pv3466 (aw (ri t3159)) pv3159
theorem pv3172 : R t3172 t1 := result (f := t3168) (a := t3171) (u := t3162) (v := t3467) pv3168 (awb t2 t3159 t3171 t3465 (refl _)) pv3467
theorem pv3169 : R t3169 t1 := result (f := t0) (a := t3168) (u := t0) (v := t3172) (refl t0) (aw (rh t3168)) pv3172
theorem pv3170 : R t3170 t3162 := result (f := t3169) (a := t3162) (u := t1) (v := t3162) pv3169 (aw (ri t3162)) (refl t3162)
theorem pv3167 : R t3167 t3162 := result (f := t3164) (a := t3166) (u := t3164) (v := t3170) (refl t3164) (awb t0 t3162 t3166 t3168 (refl _)) pv3170
theorem pv3165 : R t3165 t3162 := result (f := t0) (a := t3164) (u := t0) (v := t3167) (refl t0) (aw (rh t3164)) pv3167
theorem pv3163 : R t3163 t3162 := result (f := t2) (a := t3162) (u := t2) (v := t3165) (refl t2) (aw (ra t0 t3162)) pv3165
theorem pv3160 : R t3160 t3162 := result (f := t59) (a := t3159) (u := t46) (v := t3163) pv59 (aw (ra t2 t3159)) pv3163
theorem pv3161 : R t3161 t1 := result (f := t3160) (a := t1) (u := t3162) (v := t3240) pv3160 (awb t2 t3159 t1 t1 (cI)) pv3240
theorem pv3109 : R t3109 t1 := result (f := t3105) (a := t3108) (u := t149) (v := t3161) pv3105 (awb t59 t1 t3108 t3159 (refl _)) pv3161
theorem pv3106 : R t3106 t1 := result (f := t0) (a := t3105) (u := t0) (v := t3109) (refl t0) (aw (rh t3105)) pv3109
theorem pv3107 : R t3107 t149 := result (f := t3106) (a := t3091) (u := t1) (v := t3091) pv3106 (aw (ri t3091)) pv3091
theorem pv3104 : R t3104 t149 := result (f := t3094) (a := t3103) (u := t3094) (v := t3107) (refl t3094) (awb t0 t3091 t3103 t3105 (refl _)) pv3107
theorem pv3098 : R t3098 t149 := result (f := t3096) (a := t1) (u := t3096) (v := t3104) (refl t3096) (aw (ra t3094 t1)) pv3104
theorem pv3572 : R t3572 t3571 := result (f := t1) (a := t3571) (u := t1) (v := t3571) (refl t1) (aw (ri t3571)) (refl t3571)
theorem pv3570 : R t3570 t3571 := result (f := t22) (a := t3550) (u := t24) (v := t3572) pv22 (aw (ra t1 t3550)) pv3572
theorem pv3568 : R t3568 t3571 := result (f := t3552) (a := t1) (u := t3552) (v := t3570) (refl t3552) (awb t0 t3550 t1 t1 (cI)) pv3570
theorem pv3573 : R t3573 t3550 := result (f := t28) (a := t3550) (u := t1) (v := t3550) pv28 (aw (ri t3550)) (refl t3550)
theorem pv3569 : R t3569 t3550 := result (f := t3568) (a := t1) (u := t3571) (v := t3573) pv3568 (awb t1 t3550 t1 t1 (cI)) pv3573
theorem pv3563 : R t3563 t3550 := result (f := t3561) (a := t1) (u := t3561) (v := t3569) (refl t3561) (awb t3552 t1 t1 t1 (cI)) pv3569
theorem pv3597 : R t3597 t3596 := result (f := t1) (a := t3596) (u := t1) (v := t3596) (refl t1) (aw (ri t3596)) (refl t3596)
theorem pv3595 : R t3595 t3596 := result (f := t22) (a := t3574) (u := t24) (v := t3597) pv22 (aw (ra t1 t3574)) pv3597
theorem pv3593 : R t3593 t3596 := result (f := t3577) (a := t1) (u := t3577) (v := t3595) (refl t3577) (awb t0 t3574 t1 t1 (cI)) pv3595
theorem pv3624 : R t3624 t3623 := result (f := t1) (a := t3623) (u := t1) (v := t3623) (refl t1) (aw (ri t3623)) (refl t3623)
theorem pv3622 : R t3622 t3623 := result (f := t22) (a := t3601) (u := t24) (v := t3624) pv22 (aw (ra t1 t3601)) pv3624
theorem pv3620 : R t3620 t3623 := result (f := t3604) (a := t1) (u := t3604) (v := t3622) (refl t3604) (awb t0 t3601 t1 t1 (cI)) pv3622
theorem pv3656 : R t3656 t3655 := result (f := t1) (a := t3655) (u := t1) (v := t3655) (refl t1) (aw (ri t3655)) (refl t3655)
theorem pv3654 : R t3654 t3655 := result (f := t22) (a := t3634) (u := t24) (v := t3656) pv22 (aw (ra t1 t3634)) pv3656
theorem pv3652 : R t3652 t3655 := result (f := t3636) (a := t1) (u := t3636) (v := t3654) (refl t3636) (awb t0 t3634 t1 t1 (cI)) pv3654
theorem pv3657 : R t3657 t3634 := result (f := t28) (a := t3634) (u := t1) (v := t3634) pv28 (aw (ri t3634)) (refl t3634)
theorem pv3653 : R t3653 t3634 := result (f := t3652) (a := t1) (u := t3655) (v := t3657) pv3652 (awb t1 t3634 t1 t1 (cI)) pv3657
theorem pv3647 : R t3647 t3634 := result (f := t3645) (a := t1) (u := t3645) (v := t3653) (refl t3645) (awb t3636 t1 t1 t1 (cI)) pv3653
theorem pv3681 : R t3681 t3680 := result (f := t1) (a := t3680) (u := t1) (v := t3680) (refl t1) (aw (ri t3680)) (refl t3680)
theorem pv3679 : R t3679 t3680 := result (f := t22) (a := t3658) (u := t24) (v := t3681) pv22 (aw (ra t1 t3658)) pv3681
theorem pv3677 : R t3677 t3680 := result (f := t3661) (a := t1) (u := t3661) (v := t3679) (refl t3661) (awb t0 t3658 t1 t1 (cI)) pv3679
theorem pv3708 : R t3708 t3707 := result (f := t1) (a := t3707) (u := t1) (v := t3707) (refl t1) (aw (ri t3707)) (refl t3707)
theorem pv3706 : R t3706 t3707 := result (f := t22) (a := t3685) (u := t24) (v := t3708) pv22 (aw (ra t1 t3685)) pv3708
theorem pv3704 : R t3704 t3707 := result (f := t3688) (a := t1) (u := t3688) (v := t3706) (refl t3688) (awb t0 t3685 t1 t1 (cI)) pv3706
theorem pv3713 : R t3713 t1 := result (f := t3098) (a := t1) (u := t149) (v := t231) pv3098 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv3714 : R t3714 t1 := result (f := t3713) (a := t1) (u := t1) (v := t1) pv3713 (aw (ri t1)) (refl t1)
theorem pv3631 : R t3631 t1 := result (f := t3629) (a := t1) (u := t3629) (v := t3714) (refl t3629) (awb t3098 t1 t1 t1 (cI)) pv3714
theorem pv3712 : R t3712 t1 := result (f := t3) (a := t3631) (u := t1) (v := t3631) pv3 (aw (ri t3631)) pv3631
end Blc.H44.Pump
