"""Recreate the slim archive's omitted files exclusively from its retained inputs."""
from inventory import BASE,generate
from render import render,small_modules
from rows import build
import subprocess,sys
if __name__=='__main__':
    generate(BASE)
    result=subprocess.check_output([sys.executable,'-B','audit_compare.py','audit-wires.txt','wires.txt'],cwd=BASE,timeout=550)
    (BASE/'audit-comparison.txt').write_bytes(result)
    render()
    small_modules()
    build()
