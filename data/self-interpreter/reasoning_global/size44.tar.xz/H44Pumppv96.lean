import H44Pumppv95
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6839 : R t6839 t1 := result (f := t6838) (a := t6570) (u := t1) (v := t6570) pv6838 (aw (ri t6570)) pv6570
theorem pv6581 : R t6581 t1 := result (f := t6577) (a := t6580) (u := t6835) (v := t6839) pv6577 (awb t6584 t6570 t6580 t6837 (refl _)) pv6839
theorem pv6578 : R t6578 t1 := result (f := t0) (a := t6577) (u := t0) (v := t6581) (refl t0) (aw (rh t6577)) pv6581
theorem pv6579 : R t6579 t1 := result (f := t6578) (a := t6570) (u := t1) (v := t6570) pv6578 (aw (ri t6570)) pv6570
theorem pv6576 : R t6576 t1 := result (f := t6573) (a := t6575) (u := t6573) (v := t6579) (refl t6573) (awb t0 t6570 t6575 t6577 (refl _)) pv6579
theorem pv6574 : R t6574 t1 := result (f := t0) (a := t6573) (u := t0) (v := t6576) (refl t0) (aw (rh t6573)) pv6576
theorem pv6571 : R t6571 t1 := result (f := t2) (a := t6570) (u := t2) (v := t6574) (refl t2) (aw (ra t0 t6570)) pv6574
theorem pv6572 : R t6572 t1 := result (f := t6571) (a := t6543) (u := t1) (v := t6543) pv6571 (aw (ri t6543)) pv6543
theorem pv6563 : R t6563 t1 := result (f := t6559) (a := t6562) (u := t6546) (v := t6572) pv6559 (awb t2 t6543 t6562 t6570 (refl _)) pv6572
theorem pv6560 : R t6560 t1 := result (f := t0) (a := t6559) (u := t0) (v := t6563) (refl t0) (aw (rh t6559)) pv6563
theorem pv6561 : R t6561 t6546 := result (f := t6560) (a := t6546) (u := t1) (v := t6546) pv6560 (aw (ri t6546)) (refl t6546)
theorem pv6558 : R t6558 t6546 := result (f := t6548) (a := t6557) (u := t6548) (v := t6561) (refl t6548) (awb t0 t6546 t6557 t6559 (refl _)) pv6561
theorem pv6552 : R t6552 t6546 := result (f := t6550) (a := t1) (u := t6550) (v := t6558) (refl t6550) (aw (ra t6548 t1)) pv6558
theorem pv6872 : R t6872 t6871 := result (f := t1) (a := t6871) (u := t1) (v := t6871) (refl t1) (aw (ri t6871)) (refl t6871)
theorem pv6870 : R t6870 t6871 := result (f := t22) (a := t6849) (u := t24) (v := t6872) pv22 (aw (ra t1 t6849)) pv6872
theorem pv6868 : R t6868 t6871 := result (f := t6852) (a := t1) (u := t6852) (v := t6870) (refl t6852) (awb t0 t6849 t1 t1 (cI)) pv6870
theorem pv6899 : R t6899 t6898 := result (f := t1) (a := t6898) (u := t1) (v := t6898) (refl t1) (aw (ri t6898)) (refl t6898)
theorem pv6897 : R t6897 t6898 := result (f := t22) (a := t6876) (u := t24) (v := t6899) pv22 (aw (ra t1 t6876)) pv6899
theorem pv6895 : R t6895 t6898 := result (f := t6879) (a := t1) (u := t6879) (v := t6897) (refl t6879) (awb t0 t6876 t1 t1 (cI)) pv6897
theorem pv6901 : R t6901 t1 := result (f := t6552) (a := t1) (u := t6546) (v := t6624) pv6552 (awb t2 t6543 t1 t1 (cI)) pv6624
theorem pv6902 : R t6902 t1 := result (f := t6901) (a := t1) (u := t1) (v := t1) pv6901 (aw (ri t1)) (refl t1)
theorem pv6876 : R t6876 t1 := result (f := t6874) (a := t1) (u := t6874) (v := t6902) (refl t6874) (awb t6552 t1 t1 t1 (cI)) pv6902
theorem pv6900 : R t6900 t1 := result (f := t28) (a := t6876) (u := t1) (v := t6876) pv28 (aw (ri t6876)) pv6876
theorem pv6896 : R t6896 t1 := result (f := t6895) (a := t1) (u := t6898) (v := t6900) pv6895 (awb t1 t6876 t1 t1 (cI)) pv6900
theorem pv6890 : R t6890 t1 := result (f := t6888) (a := t1) (u := t6888) (v := t6896) (refl t6888) (awb t6879 t1 t1 t1 (cI)) pv6896
theorem pv6894 : R t6894 t6893 := result (f := t6890) (a := t6893) (u := t1) (v := t6893) pv6890 (aw (ri t6893)) (refl t6893)
theorem pv6891 : R t6891 t6893 := result (f := t0) (a := t6890) (u := t0) (v := t6894) (refl t0) (aw (rh t6890)) pv6894
theorem pv6904 : R t6904 t6903 := result (f := t6890) (a := t6903) (u := t1) (v := t6903) pv6890 (aw (ri t6903)) (refl t6903)
theorem pv6892 : R t6892 t6903 := result (f := t6891) (a := t6876) (u := t6893) (v := t6904) pv6891 (aw (ra t6890 t6876)) pv6904
theorem pv6889 : R t6889 t6903 := result (f := t6879) (a := t6888) (u := t6879) (v := t6892) (refl t6879) (awb t0 t6876 t6888 t6890 (refl _)) pv6892
theorem pv6883 : R t6883 t6903 := result (f := t6881) (a := t1) (u := t6881) (v := t6889) (refl t6881) (aw (ra t6879 t1)) pv6889
theorem pv6915 : R t6915 t1 := result (f := t6890) (a := t1) (u := t1) (v := t1) pv6890 (aw (ri t1)) (refl t1)
theorem pv6916 : R t6916 t1 := result (f := t6915) (a := t6876) (u := t1) (v := t6876) pv6915 (aw (ri t6876)) pv6876
theorem pv6913 : R t6913 t1 := result (f := t6883) (a := t1) (u := t6903) (v := t6916) pv6883 (awb t6890 t6876 t1 t1 (cI)) pv6916
theorem pv6914 : R t6914 t1 := result (f := t6913) (a := t1) (u := t1) (v := t1) pv6913 (aw (ri t1)) (refl t1)
theorem pv6910 : R t6910 t1 := result (f := t6908) (a := t1) (u := t6908) (v := t6914) (refl t6908) (awb t6883 t1 t1 t1 (cI)) pv6914
theorem pv6911 : R t6911 t1 := result (f := t6890) (a := t6910) (u := t1) (v := t6910) pv6890 (aw (ri t6910)) pv6910
theorem pv6912 : R t6912 t1 := result (f := t6911) (a := t6876) (u := t1) (v := t6876) pv6911 (aw (ri t6876)) pv6876
theorem pv6909 : R t6909 t1 := result (f := t6883) (a := t6908) (u := t6903) (v := t6912) pv6883 (awb t6890 t6876 t6908 t6910 (refl _)) pv6912
theorem pv6905 : R t6905 t1 := result (f := t6886) (a := t1) (u := t6886) (v := t6909) (refl t6886) (aw (ra t6883 t1)) pv6909
theorem pv6906 : R t6906 t1 := result (f := t6890) (a := t6905) (u := t1) (v := t6905) pv6890 (aw (ri t6905)) pv6905
theorem pv6907 : R t6907 t1 := result (f := t6906) (a := t6876) (u := t1) (v := t6876) pv6906 (aw (ri t6876)) pv6876
theorem pv6887 : R t6887 t1 := result (f := t6883) (a := t6886) (u := t6903) (v := t6907) pv6883 (awb t6890 t6876 t6886 t6905 (refl _)) pv6907
theorem pv6884 : R t6884 t1 := result (f := t0) (a := t6883) (u := t0) (v := t6887) (refl t0) (aw (rh t6883)) pv6887
theorem pv6885 : R t6885 t1 := result (f := t6884) (a := t6876) (u := t1) (v := t6876) pv6884 (aw (ri t6876)) pv6876
theorem pv6882 : R t6882 t1 := result (f := t6879) (a := t6881) (u := t6879) (v := t6885) (refl t6879) (awb t0 t6876 t6881 t6883 (refl _)) pv6885
theorem pv6880 : R t6880 t1 := result (f := t0) (a := t6879) (u := t0) (v := t6882) (refl t0) (aw (rh t6879)) pv6882
theorem pv6877 : R t6877 t1 := result (f := t2) (a := t6876) (u := t2) (v := t6880) (refl t2) (aw (ra t0 t6876)) pv6880
theorem pv6878 : R t6878 t1 := result (f := t6877) (a := t6543) (u := t1) (v := t6543) pv6877 (aw (ri t6543)) pv6543
theorem pv6875 : R t6875 t1 := result (f := t6552) (a := t6874) (u := t6546) (v := t6878) pv6552 (awb t2 t6543 t6874 t6876 (refl _)) pv6878
theorem pv6849 : R t6849 t1 := result (f := t6555) (a := t1) (u := t6555) (v := t6875) (refl t6555) (aw (ra t6552 t1)) pv6875
theorem pv6873 : R t6873 t1 := result (f := t28) (a := t6849) (u := t1) (v := t6849) pv28 (aw (ri t6849)) pv6849
theorem pv6869 : R t6869 t1 := result (f := t6868) (a := t1) (u := t6871) (v := t6873) pv6868 (awb t1 t6849 t1 t1 (cI)) pv6873
theorem pv6863 : R t6863 t1 := result (f := t6861) (a := t1) (u := t6861) (v := t6869) (refl t6861) (awb t6852 t1 t1 t1 (cI)) pv6869
theorem pv6867 : R t6867 t6866 := result (f := t6863) (a := t6866) (u := t1) (v := t6866) pv6863 (aw (ri t6866)) (refl t6866)
end Blc.H44.Pump
