import H44Pumppv112
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv7875 : R t7875 t7874 := result (f := t7871) (a := t7874) (u := t1) (v := t7874) pv7871 (aw (ri t7874)) (refl t7874)
theorem pv7872 : R t7872 t7874 := result (f := t0) (a := t7871) (u := t0) (v := t7875) (refl t0) (aw (rh t7871)) pv7875
theorem pv8082 : R t8082 t8081 := result (f := t7871) (a := t8081) (u := t1) (v := t8081) pv7871 (aw (ri t8081)) (refl t8081)
theorem pv7873 : R t7873 t8081 := result (f := t7872) (a := t7857) (u := t7874) (v := t8082) pv7872 (aw (ra t7871 t7857)) pv8082
theorem pv7870 : R t7870 t8081 := result (f := t7860) (a := t7869) (u := t7860) (v := t7873) (refl t7860) (awb t0 t7857 t7869 t7871 (refl _)) pv7873
theorem pv7864 : R t7864 t8081 := result (f := t7862) (a := t1) (u := t7862) (v := t7870) (refl t7862) (aw (ra t7860 t1)) pv7870
theorem pv8093 : R t8093 t1 := result (f := t7871) (a := t1) (u := t1) (v := t1) pv7871 (aw (ri t1)) (refl t1)
theorem pv8094 : R t8094 t1 := result (f := t8093) (a := t7857) (u := t1) (v := t7857) pv8093 (aw (ri t7857)) pv7857
theorem pv8091 : R t8091 t1 := result (f := t7864) (a := t1) (u := t8081) (v := t8094) pv7864 (awb t7871 t7857 t1 t1 (cI)) pv8094
theorem pv8092 : R t8092 t1 := result (f := t8091) (a := t1) (u := t1) (v := t1) pv8091 (aw (ri t1)) (refl t1)
theorem pv8088 : R t8088 t1 := result (f := t8086) (a := t1) (u := t8086) (v := t8092) (refl t8086) (awb t7864 t1 t1 t1 (cI)) pv8092
theorem pv8089 : R t8089 t1 := result (f := t7871) (a := t8088) (u := t1) (v := t8088) pv7871 (aw (ri t8088)) pv8088
theorem pv8090 : R t8090 t1 := result (f := t8089) (a := t7857) (u := t1) (v := t7857) pv8089 (aw (ri t7857)) pv7857
theorem pv8087 : R t8087 t1 := result (f := t7864) (a := t8086) (u := t8081) (v := t8090) pv7864 (awb t7871 t7857 t8086 t8088 (refl _)) pv8090
theorem pv8083 : R t8083 t1 := result (f := t7867) (a := t1) (u := t7867) (v := t8087) (refl t7867) (aw (ra t7864 t1)) pv8087
theorem pv8084 : R t8084 t1 := result (f := t7871) (a := t8083) (u := t1) (v := t8083) pv7871 (aw (ri t8083)) pv8083
theorem pv8085 : R t8085 t1 := result (f := t8084) (a := t7857) (u := t1) (v := t7857) pv8084 (aw (ri t7857)) pv7857
theorem pv7868 : R t7868 t1 := result (f := t7864) (a := t7867) (u := t8081) (v := t8085) pv7864 (awb t7871 t7857 t7867 t8083 (refl _)) pv8085
theorem pv7865 : R t7865 t1 := result (f := t0) (a := t7864) (u := t0) (v := t7868) (refl t0) (aw (rh t7864)) pv7868
theorem pv7866 : R t7866 t1 := result (f := t7865) (a := t7857) (u := t1) (v := t7857) pv7865 (aw (ri t7857)) pv7857
theorem pv7863 : R t7863 t1 := result (f := t7860) (a := t7862) (u := t7860) (v := t7866) (refl t7860) (awb t0 t7857 t7862 t7864 (refl _)) pv7866
theorem pv7861 : R t7861 t1 := result (f := t0) (a := t7860) (u := t0) (v := t7863) (refl t0) (aw (rh t7860)) pv7863
theorem pv7858 : R t7858 t1 := result (f := t2) (a := t7857) (u := t2) (v := t7861) (refl t2) (aw (ra t0 t7857)) pv7861
theorem pv7859 : R t7859 t1 := result (f := t7858) (a := t7803) (u := t1) (v := t7803) pv7858 (aw (ri t7803)) pv7803
theorem pv7856 : R t7856 t1 := result (f := t7819) (a := t7855) (u := t7806) (v := t7859) pv7819 (awb t2 t7803 t7855 t7857 (refl _)) pv7859
theorem pv7830 : R t7830 t1 := result (f := t7822) (a := t1) (u := t7822) (v := t7856) (refl t7822) (aw (ra t7819 t1)) pv7856
theorem pv7854 : R t7854 t1 := result (f := t28) (a := t7830) (u := t1) (v := t7830) pv28 (aw (ri t7830)) pv7830
theorem pv7850 : R t7850 t1 := result (f := t7849) (a := t1) (u := t7852) (v := t7854) pv7849 (awb t1 t7830 t1 t1 (cI)) pv7854
theorem pv7844 : R t7844 t1 := result (f := t7842) (a := t1) (u := t7842) (v := t7850) (refl t7842) (awb t7833 t1 t1 t1 (cI)) pv7850
theorem pv7848 : R t7848 t7847 := result (f := t7844) (a := t7847) (u := t1) (v := t7847) pv7844 (aw (ri t7847)) (refl t7847)
theorem pv7845 : R t7845 t7847 := result (f := t0) (a := t7844) (u := t0) (v := t7848) (refl t0) (aw (rh t7844)) pv7848
theorem pv8096 : R t8096 t8095 := result (f := t7844) (a := t8095) (u := t1) (v := t8095) pv7844 (aw (ri t8095)) (refl t8095)
theorem pv7846 : R t7846 t8095 := result (f := t7845) (a := t7830) (u := t7847) (v := t8096) pv7845 (aw (ra t7844 t7830)) pv8096
theorem pv7843 : R t7843 t8095 := result (f := t7833) (a := t7842) (u := t7833) (v := t7846) (refl t7833) (awb t0 t7830 t7842 t7844 (refl _)) pv7846
theorem pv7837 : R t7837 t8095 := result (f := t7835) (a := t1) (u := t7835) (v := t7843) (refl t7835) (aw (ra t7833 t1)) pv7843
theorem pv8107 : R t8107 t1 := result (f := t7844) (a := t1) (u := t1) (v := t1) pv7844 (aw (ri t1)) (refl t1)
theorem pv8108 : R t8108 t1 := result (f := t8107) (a := t7830) (u := t1) (v := t7830) pv8107 (aw (ri t7830)) pv7830
theorem pv8105 : R t8105 t1 := result (f := t7837) (a := t1) (u := t8095) (v := t8108) pv7837 (awb t7844 t7830 t1 t1 (cI)) pv8108
theorem pv8106 : R t8106 t1 := result (f := t8105) (a := t1) (u := t1) (v := t1) pv8105 (aw (ri t1)) (refl t1)
theorem pv8102 : R t8102 t1 := result (f := t8100) (a := t1) (u := t8100) (v := t8106) (refl t8100) (awb t7837 t1 t1 t1 (cI)) pv8106
theorem pv8103 : R t8103 t1 := result (f := t7844) (a := t8102) (u := t1) (v := t8102) pv7844 (aw (ri t8102)) pv8102
theorem pv8104 : R t8104 t1 := result (f := t8103) (a := t7830) (u := t1) (v := t7830) pv8103 (aw (ri t7830)) pv7830
theorem pv8101 : R t8101 t1 := result (f := t7837) (a := t8100) (u := t8095) (v := t8104) pv7837 (awb t7844 t7830 t8100 t8102 (refl _)) pv8104
theorem pv8097 : R t8097 t1 := result (f := t7840) (a := t1) (u := t7840) (v := t8101) (refl t7840) (aw (ra t7837 t1)) pv8101
theorem pv8098 : R t8098 t1 := result (f := t7844) (a := t8097) (u := t1) (v := t8097) pv7844 (aw (ri t8097)) pv8097
theorem pv8099 : R t8099 t1 := result (f := t8098) (a := t7830) (u := t1) (v := t7830) pv8098 (aw (ri t7830)) pv7830
theorem pv7841 : R t7841 t1 := result (f := t7837) (a := t7840) (u := t8095) (v := t8099) pv7837 (awb t7844 t7830 t7840 t8097 (refl _)) pv8099
theorem pv7838 : R t7838 t1 := result (f := t0) (a := t7837) (u := t0) (v := t7841) (refl t0) (aw (rh t7837)) pv7841
theorem pv7839 : R t7839 t1 := result (f := t7838) (a := t7830) (u := t1) (v := t7830) pv7838 (aw (ri t7830)) pv7830
theorem pv7836 : R t7836 t1 := result (f := t7833) (a := t7835) (u := t7833) (v := t7839) (refl t7833) (awb t0 t7830 t7835 t7837 (refl _)) pv7839
theorem pv7834 : R t7834 t1 := result (f := t0) (a := t7833) (u := t0) (v := t7836) (refl t0) (aw (rh t7833)) pv7836
theorem pv7831 : R t7831 t1 := result (f := t2) (a := t7830) (u := t2) (v := t7834) (refl t2) (aw (ra t0 t7830)) pv7834
theorem pv7832 : R t7832 t1 := result (f := t7831) (a := t7803) (u := t1) (v := t7803) pv7831 (aw (ri t7803)) pv7803
theorem pv7823 : R t7823 t1 := result (f := t7819) (a := t7822) (u := t7806) (v := t7832) pv7819 (awb t2 t7803 t7822 t7830 (refl _)) pv7832
theorem pv7820 : R t7820 t1 := result (f := t0) (a := t7819) (u := t0) (v := t7823) (refl t0) (aw (rh t7819)) pv7823
end Blc.H44.Pump
