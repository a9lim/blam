import H44Pumppv31
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2421 : R t2421 t2402 := result (f := t2420) (a := t1) (u := t2423) (v := t2425) pv2420 (awb t1 t2402 t1 t1 (cI)) pv2425
theorem pv2415 : R t2415 t2402 := result (f := t2413) (a := t1) (u := t2413) (v := t2421) (refl t2413) (awb t2404 t1 t1 t1 (cI)) pv2421
theorem pv2449 : R t2449 t2448 := result (f := t1) (a := t2448) (u := t1) (v := t2448) (refl t1) (aw (ri t2448)) (refl t2448)
theorem pv2447 : R t2447 t2448 := result (f := t22) (a := t2426) (u := t24) (v := t2449) pv22 (aw (ra t1 t2426)) pv2449
theorem pv2445 : R t2445 t2448 := result (f := t2429) (a := t1) (u := t2429) (v := t2447) (refl t2429) (awb t0 t2426 t1 t1 (cI)) pv2447
theorem pv2476 : R t2476 t2475 := result (f := t1) (a := t2475) (u := t1) (v := t2475) (refl t1) (aw (ri t2475)) (refl t2475)
theorem pv2474 : R t2474 t2475 := result (f := t22) (a := t2453) (u := t24) (v := t2476) pv22 (aw (ra t1 t2453)) pv2476
theorem pv2472 : R t2472 t2475 := result (f := t2456) (a := t1) (u := t2456) (v := t2474) (refl t2456) (awb t0 t2453 t1 t1 (cI)) pv2474
theorem pv2481 : R t2481 t1 := result (f := t2261) (a := t1) (u := t149) (v := t231) pv2261 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv2482 : R t2482 t1 := result (f := t2481) (a := t1) (u := t1) (v := t1) pv2481 (aw (ri t1)) (refl t1)
theorem pv2399 : R t2399 t1 := result (f := t2397) (a := t1) (u := t2397) (v := t2482) (refl t2397) (awb t2261 t1 t1 t1 (cI)) pv2482
theorem pv2480 : R t2480 t1 := result (f := t3) (a := t2399) (u := t1) (v := t2399) pv3 (aw (ri t2399)) pv2399
theorem pv2478 : R t2478 t1 := result (f := t2415) (a := t1) (u := t2402) (v := t2480) pv2415 (awb t2 t2399 t1 t1 (cI)) pv2480
theorem pv2479 : R t2479 t1 := result (f := t2478) (a := t1) (u := t1) (v := t1) pv2478 (aw (ri t1)) (refl t1)
theorem pv2453 : R t2453 t1 := result (f := t2451) (a := t1) (u := t2451) (v := t2479) (refl t2451) (awb t2415 t1 t1 t1 (cI)) pv2479
theorem pv2477 : R t2477 t1 := result (f := t28) (a := t2453) (u := t1) (v := t2453) pv28 (aw (ri t2453)) pv2453
theorem pv2473 : R t2473 t1 := result (f := t2472) (a := t1) (u := t2475) (v := t2477) pv2472 (awb t1 t2453 t1 t1 (cI)) pv2477
theorem pv2467 : R t2467 t1 := result (f := t2465) (a := t1) (u := t2465) (v := t2473) (refl t2465) (awb t2456 t1 t1 t1 (cI)) pv2473
theorem pv2471 : R t2471 t2470 := result (f := t2467) (a := t2470) (u := t1) (v := t2470) pv2467 (aw (ri t2470)) (refl t2470)
theorem pv2468 : R t2468 t2470 := result (f := t0) (a := t2467) (u := t0) (v := t2471) (refl t0) (aw (rh t2467)) pv2471
theorem pv2484 : R t2484 t2483 := result (f := t2467) (a := t2483) (u := t1) (v := t2483) pv2467 (aw (ri t2483)) (refl t2483)
theorem pv2469 : R t2469 t2483 := result (f := t2468) (a := t2453) (u := t2470) (v := t2484) pv2468 (aw (ra t2467 t2453)) pv2484
theorem pv2466 : R t2466 t2483 := result (f := t2456) (a := t2465) (u := t2456) (v := t2469) (refl t2456) (awb t0 t2453 t2465 t2467 (refl _)) pv2469
theorem pv2460 : R t2460 t2483 := result (f := t2458) (a := t1) (u := t2458) (v := t2466) (refl t2458) (aw (ra t2456 t1)) pv2466
theorem pv2495 : R t2495 t1 := result (f := t2467) (a := t1) (u := t1) (v := t1) pv2467 (aw (ri t1)) (refl t1)
theorem pv2496 : R t2496 t1 := result (f := t2495) (a := t2453) (u := t1) (v := t2453) pv2495 (aw (ri t2453)) pv2453
theorem pv2493 : R t2493 t1 := result (f := t2460) (a := t1) (u := t2483) (v := t2496) pv2460 (awb t2467 t2453 t1 t1 (cI)) pv2496
theorem pv2494 : R t2494 t1 := result (f := t2493) (a := t1) (u := t1) (v := t1) pv2493 (aw (ri t1)) (refl t1)
theorem pv2490 : R t2490 t1 := result (f := t2488) (a := t1) (u := t2488) (v := t2494) (refl t2488) (awb t2460 t1 t1 t1 (cI)) pv2494
theorem pv2491 : R t2491 t1 := result (f := t2467) (a := t2490) (u := t1) (v := t2490) pv2467 (aw (ri t2490)) pv2490
theorem pv2492 : R t2492 t1 := result (f := t2491) (a := t2453) (u := t1) (v := t2453) pv2491 (aw (ri t2453)) pv2453
theorem pv2489 : R t2489 t1 := result (f := t2460) (a := t2488) (u := t2483) (v := t2492) pv2460 (awb t2467 t2453 t2488 t2490 (refl _)) pv2492
theorem pv2485 : R t2485 t1 := result (f := t2463) (a := t1) (u := t2463) (v := t2489) (refl t2463) (aw (ra t2460 t1)) pv2489
theorem pv2486 : R t2486 t1 := result (f := t2467) (a := t2485) (u := t1) (v := t2485) pv2467 (aw (ri t2485)) pv2485
theorem pv2487 : R t2487 t1 := result (f := t2486) (a := t2453) (u := t1) (v := t2453) pv2486 (aw (ri t2453)) pv2453
theorem pv2464 : R t2464 t1 := result (f := t2460) (a := t2463) (u := t2483) (v := t2487) pv2460 (awb t2467 t2453 t2463 t2485 (refl _)) pv2487
theorem pv2461 : R t2461 t1 := result (f := t0) (a := t2460) (u := t0) (v := t2464) (refl t0) (aw (rh t2460)) pv2464
theorem pv2462 : R t2462 t1 := result (f := t2461) (a := t2453) (u := t1) (v := t2453) pv2461 (aw (ri t2453)) pv2453
theorem pv2459 : R t2459 t1 := result (f := t2456) (a := t2458) (u := t2456) (v := t2462) (refl t2456) (awb t0 t2453 t2458 t2460 (refl _)) pv2462
theorem pv2457 : R t2457 t1 := result (f := t0) (a := t2456) (u := t0) (v := t2459) (refl t0) (aw (rh t2456)) pv2459
theorem pv2454 : R t2454 t1 := result (f := t2) (a := t2453) (u := t2) (v := t2457) (refl t2) (aw (ra t0 t2453)) pv2457
theorem pv2455 : R t2455 t1 := result (f := t2454) (a := t2399) (u := t1) (v := t2399) pv2454 (aw (ri t2399)) pv2399
theorem pv2452 : R t2452 t1 := result (f := t2415) (a := t2451) (u := t2402) (v := t2455) pv2415 (awb t2 t2399 t2451 t2453 (refl _)) pv2455
theorem pv2426 : R t2426 t1 := result (f := t2418) (a := t1) (u := t2418) (v := t2452) (refl t2418) (aw (ra t2415 t1)) pv2452
theorem pv2450 : R t2450 t1 := result (f := t28) (a := t2426) (u := t1) (v := t2426) pv28 (aw (ri t2426)) pv2426
theorem pv2446 : R t2446 t1 := result (f := t2445) (a := t1) (u := t2448) (v := t2450) pv2445 (awb t1 t2426 t1 t1 (cI)) pv2450
theorem pv2440 : R t2440 t1 := result (f := t2438) (a := t1) (u := t2438) (v := t2446) (refl t2438) (awb t2429 t1 t1 t1 (cI)) pv2446
theorem pv2444 : R t2444 t2443 := result (f := t2440) (a := t2443) (u := t1) (v := t2443) pv2440 (aw (ri t2443)) (refl t2443)
theorem pv2441 : R t2441 t2443 := result (f := t0) (a := t2440) (u := t0) (v := t2444) (refl t0) (aw (rh t2440)) pv2444
theorem pv2498 : R t2498 t2497 := result (f := t2440) (a := t2497) (u := t1) (v := t2497) pv2440 (aw (ri t2497)) (refl t2497)
theorem pv2442 : R t2442 t2497 := result (f := t2441) (a := t2426) (u := t2443) (v := t2498) pv2441 (aw (ra t2440 t2426)) pv2498
theorem pv2439 : R t2439 t2497 := result (f := t2429) (a := t2438) (u := t2429) (v := t2442) (refl t2429) (awb t0 t2426 t2438 t2440 (refl _)) pv2442
theorem pv2433 : R t2433 t2497 := result (f := t2431) (a := t1) (u := t2431) (v := t2439) (refl t2431) (aw (ra t2429 t1)) pv2439
theorem pv2509 : R t2509 t1 := result (f := t2440) (a := t1) (u := t1) (v := t1) pv2440 (aw (ri t1)) (refl t1)
theorem pv2510 : R t2510 t1 := result (f := t2509) (a := t2426) (u := t1) (v := t2426) pv2509 (aw (ri t2426)) pv2426
end Blc.H44.Pump
