"""Canonical wire partition. Each branch selects a certificate, never a search outcome."""
import csv,json
from functools import lru_cache
from pathlib import Path
from collections import Counter
from wireterms import HERE,lc,counts
def read(name):return json.loads((HERE/name).read_text())
def table(name):
    with (HERE/name).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def write_table(name,fields,rows):
    with (HERE/name).open('w') as f:
        out=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n')
        out.writeheader();out.writerows(rows)
def selected():
    first=read('certs.json');extra=read('extra.json')
    second={w:i//22 for i,w in enumerate(sorted(w for w,v in extra.items() if v!=['open']))}
    exact=read('exact.json');alt=read('alternatives.json')
    models=read('machine-layouts.json')
    with (HERE/'machine-index.tsv').open() as f:which=dict(l.split() for l in f)
    helper={r['wire']:r for r in table('helper-manifest.tsv')}
    assert {w for w,r in first.items() if r==['open']}==extra.keys() and len(helper)==75
    assert which.keys()==models.keys()
    for i,w in enumerate(sorted(first)):
        n='e'+str(int(w,2));batch=f'Batch{i//160:04}';k=first[w][0]
        m=batch;ns='Blc.Floor44.';literal=ns+n;th=ns+'cert_'+n;stage='first';args=first[w]
        if k!='open':direct=k.startswith('W')
        elif w in second:
            stage='extra';m=f'More{second[w]:03}';args=extra[w];k=args[0];ns+='Additional.'
            literal=ns+n;th=ns+'cert_'+n;direct=k.startswith(('W','rank','so'))
        elif w in exact:
            stage='exact';m='E'+n[1:];ns+=m+'.';literal=ns+'e';th=ns+'excluded';k='machineMismatch';direct=True
        elif w in alt:
            stage='alternative';m='Alternative';ns+='Alternative.';literal=ns+n;th=ns+'cert_'+n;k=alt[w][0];direct=True
        elif w in which:
            stage=which[w];m='R'+n[1:];ns='Certgen.'+m+'.';literal=ns+'e';th=ns+'excluded'
            k={'reg':'regular','safe':'regularRigid'}[stage];direct=True
        else:
            stage='helper';r=helper.pop(w);m='H44Bridge';literal=ns+n;th=r['theorem'];method=r['method']
            k='clock' if method=='macro_clock' else 'ordered' if method.startswith('ordered') else 'types'
            direct=True
        term,end=lc.decode(w);assert end==44
        rec=dict(wire=w,root='literal' if w.startswith('00') else 'app',triple=list(counts(term)),kind=k,
                 strength='complete' if direct else 'predicate',module=m,theorem=th)
        yield rec,stage,literal,args,batch
    assert not helper
def merge(gs):
    if len(gs)==1:return gs[0]
    k=len(gs)//2
    return '(merge '+merge(gs[:k])+' '+merge(gs[k:])+')'
def groups(final):
    imports=['Group44','H44Bridge']
    s=''.join('import '+m+'\n' for m in imports)+'namespace Blc.Floor44\n'
    groups=[]
    for i in range(0,len(final),12):
        name='finalGroup'+str(i//12);groups.append(name)
        s+='private def '+name+' : Group :=\n'+''.join('  add e'+str(int(r['wire'],2))+' '+r['theorem']+' (\n' for r in final[i:i+12])+'  emptyGroup'+')'*len(final[i:i+12])+'\n'
    s+='def residualGroup : Group := '+merge(groups)+'\ndef residuals := residualGroup.terms\ntheorem residuals_excluded (t : Term) (h : t ∈ residuals) : ¬ IsSelfInterpreter t := residualGroup.reject t h\n#print axioms residuals_excluded\nend Blc.Floor44\n'
    (HERE/'Residuals.lean').write_text(s)
def build():
    # Expected transitive axioms established in the original kernel compilation;
    # the clean check obtains them again for every individual complete statement.
    ax=read('axiom-classes.json')
    info=[];hard=[];initial=[];hist=Counter();expected=set();final=[]
    with (HERE/'ledger.json').open('w') as out:
        out.write('[\n')
        for i,(r,stage,literal,args,batch) in enumerate(selected()):
            if i:out.write(',\n')
            out.write(json.dumps(r,separators=(',',':')))
            w=r['wire'];k=r['kind'];hist[k,r['root']]+=1
            if r['strength']=='complete':
                expected.add(w)
                axs=['propext, Quot.sound','propext, Classical.choice, Quot.sound'][int(w in ax['choice'])]
                row=dict(wire=w,kind=k,file=r['module']+'.lean',theorem=r['theorem'],statement='¬ Blc.IsSelfInterpreter '+literal,axioms=axs)
                info.append(row)
                if stage=='helper':hard.append(row);final.append(r)
            if stage!='first':initial.append(dict(wire=w,stage=stage,kind=k,strength=r['strength'],module=r['module'],theorem=r['theorem']))
        out.write('\n]\n')
    assert len(expected)==9602 and set(ax['choice'])<=expected and len(initial)==3521 and len(hard)==75
    fields=['wire','kind','file','theorem','statement','axioms']
    write_table('complete.tsv',fields,info);write_table('residuals.tsv',fields,hard)
    write_table('initial-residuals.tsv',list(initial[0]),initial)
    write_table('by-family.tsv',['kind','app','literal','total'],[dict(kind=k,app=hist[k,'app'],literal=hist[k,'literal'],total=hist[k,'app']+hist[k,'literal']) for k in sorted({k for k,_ in hist})])
    groups(final)
if __name__=='__main__':build()
