import H44Pumppv26
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2110 : R t2110 t2109 := result (f := t2096) (a := t2109) (u := t1) (v := t2109) pv2096 (aw (ri t2109)) (refl t2109)
theorem pv2098 : R t2098 t2109 := result (f := t2097) (a := t2082) (u := t2099) (v := t2110) pv2097 (aw (ra t2096 t2082)) pv2110
theorem pv2095 : R t2095 t2109 := result (f := t2085) (a := t2094) (u := t2085) (v := t2098) (refl t2085) (awb t0 t2082 t2094 t2096 (refl _)) pv2098
theorem pv2089 : R t2089 t2109 := result (f := t2087) (a := t1) (u := t2087) (v := t2095) (refl t2087) (aw (ra t2085 t1)) pv2095
theorem pv2121 : R t2121 t1 := result (f := t2096) (a := t1) (u := t1) (v := t1) pv2096 (aw (ri t1)) (refl t1)
theorem pv2122 : R t2122 t1 := result (f := t2121) (a := t2082) (u := t1) (v := t2082) pv2121 (aw (ri t2082)) pv2082
theorem pv2119 : R t2119 t1 := result (f := t2089) (a := t1) (u := t2109) (v := t2122) pv2089 (awb t2096 t2082 t1 t1 (cI)) pv2122
theorem pv2120 : R t2120 t1 := result (f := t2119) (a := t1) (u := t1) (v := t1) pv2119 (aw (ri t1)) (refl t1)
theorem pv2116 : R t2116 t1 := result (f := t2114) (a := t1) (u := t2114) (v := t2120) (refl t2114) (awb t2089 t1 t1 t1 (cI)) pv2120
theorem pv2117 : R t2117 t1 := result (f := t2096) (a := t2116) (u := t1) (v := t2116) pv2096 (aw (ri t2116)) pv2116
theorem pv2118 : R t2118 t1 := result (f := t2117) (a := t2082) (u := t1) (v := t2082) pv2117 (aw (ri t2082)) pv2082
theorem pv2115 : R t2115 t1 := result (f := t2089) (a := t2114) (u := t2109) (v := t2118) pv2089 (awb t2096 t2082 t2114 t2116 (refl _)) pv2118
theorem pv2111 : R t2111 t1 := result (f := t2092) (a := t1) (u := t2092) (v := t2115) (refl t2092) (aw (ra t2089 t1)) pv2115
theorem pv2112 : R t2112 t1 := result (f := t2096) (a := t2111) (u := t1) (v := t2111) pv2096 (aw (ri t2111)) pv2111
theorem pv2113 : R t2113 t1 := result (f := t2112) (a := t2082) (u := t1) (v := t2082) pv2112 (aw (ri t2082)) pv2082
theorem pv2093 : R t2093 t1 := result (f := t2089) (a := t2092) (u := t2109) (v := t2113) pv2089 (awb t2096 t2082 t2092 t2111 (refl _)) pv2113
theorem pv2090 : R t2090 t1 := result (f := t0) (a := t2089) (u := t0) (v := t2093) (refl t0) (aw (rh t2089)) pv2093
theorem pv2091 : R t2091 t1 := result (f := t2090) (a := t2082) (u := t1) (v := t2082) pv2090 (aw (ri t2082)) pv2082
theorem pv2088 : R t2088 t1 := result (f := t2085) (a := t2087) (u := t2085) (v := t2091) (refl t2085) (awb t0 t2082 t2087 t2089 (refl _)) pv2091
theorem pv2086 : R t2086 t1 := result (f := t0) (a := t2085) (u := t0) (v := t2088) (refl t0) (aw (rh t2085)) pv2088
theorem pv2083 : R t2083 t1 := result (f := t2) (a := t2082) (u := t2) (v := t2086) (refl t2) (aw (ra t0 t2082)) pv2086
theorem pv2084 : R t2084 t1 := result (f := t2083) (a := t1943) (u := t1) (v := t1943) pv2083 (aw (ri t1943)) pv1943
theorem pv2081 : R t2081 t1 := result (f := t1952) (a := t2080) (u := t1946) (v := t2084) pv1952 (awb t2 t1943 t2080 t2082 (refl _)) pv2084
theorem pv2055 : R t2055 t1 := result (f := t1955) (a := t1) (u := t1955) (v := t2081) (refl t1955) (aw (ra t1952 t1)) pv2081
theorem pv2079 : R t2079 t1 := result (f := t28) (a := t2055) (u := t1) (v := t2055) pv28 (aw (ri t2055)) pv2055
theorem pv2075 : R t2075 t1 := result (f := t2074) (a := t1) (u := t2077) (v := t2079) pv2074 (awb t1 t2055 t1 t1 (cI)) pv2079
theorem pv2069 : R t2069 t1 := result (f := t2067) (a := t1) (u := t2067) (v := t2075) (refl t2067) (awb t2058 t1 t1 t1 (cI)) pv2075
theorem pv2073 : R t2073 t2072 := result (f := t2069) (a := t2072) (u := t1) (v := t2072) pv2069 (aw (ri t2072)) (refl t2072)
theorem pv2070 : R t2070 t2072 := result (f := t0) (a := t2069) (u := t0) (v := t2073) (refl t0) (aw (rh t2069)) pv2073
theorem pv2124 : R t2124 t2123 := result (f := t2069) (a := t2123) (u := t1) (v := t2123) pv2069 (aw (ri t2123)) (refl t2123)
theorem pv2071 : R t2071 t2123 := result (f := t2070) (a := t2055) (u := t2072) (v := t2124) pv2070 (aw (ra t2069 t2055)) pv2124
theorem pv2068 : R t2068 t2123 := result (f := t2058) (a := t2067) (u := t2058) (v := t2071) (refl t2058) (awb t0 t2055 t2067 t2069 (refl _)) pv2071
theorem pv2062 : R t2062 t2123 := result (f := t2060) (a := t1) (u := t2060) (v := t2068) (refl t2060) (aw (ra t2058 t1)) pv2068
theorem pv2135 : R t2135 t1 := result (f := t2069) (a := t1) (u := t1) (v := t1) pv2069 (aw (ri t1)) (refl t1)
theorem pv2136 : R t2136 t1 := result (f := t2135) (a := t2055) (u := t1) (v := t2055) pv2135 (aw (ri t2055)) pv2055
theorem pv2133 : R t2133 t1 := result (f := t2062) (a := t1) (u := t2123) (v := t2136) pv2062 (awb t2069 t2055 t1 t1 (cI)) pv2136
theorem pv2134 : R t2134 t1 := result (f := t2133) (a := t1) (u := t1) (v := t1) pv2133 (aw (ri t1)) (refl t1)
theorem pv2130 : R t2130 t1 := result (f := t2128) (a := t1) (u := t2128) (v := t2134) (refl t2128) (awb t2062 t1 t1 t1 (cI)) pv2134
theorem pv2131 : R t2131 t1 := result (f := t2069) (a := t2130) (u := t1) (v := t2130) pv2069 (aw (ri t2130)) pv2130
theorem pv2132 : R t2132 t1 := result (f := t2131) (a := t2055) (u := t1) (v := t2055) pv2131 (aw (ri t2055)) pv2055
theorem pv2129 : R t2129 t1 := result (f := t2062) (a := t2128) (u := t2123) (v := t2132) pv2062 (awb t2069 t2055 t2128 t2130 (refl _)) pv2132
theorem pv2125 : R t2125 t1 := result (f := t2065) (a := t1) (u := t2065) (v := t2129) (refl t2065) (aw (ra t2062 t1)) pv2129
theorem pv2126 : R t2126 t1 := result (f := t2069) (a := t2125) (u := t1) (v := t2125) pv2069 (aw (ri t2125)) pv2125
theorem pv2127 : R t2127 t1 := result (f := t2126) (a := t2055) (u := t1) (v := t2055) pv2126 (aw (ri t2055)) pv2055
theorem pv2066 : R t2066 t1 := result (f := t2062) (a := t2065) (u := t2123) (v := t2127) pv2062 (awb t2069 t2055 t2065 t2125 (refl _)) pv2127
theorem pv2063 : R t2063 t1 := result (f := t0) (a := t2062) (u := t0) (v := t2066) (refl t0) (aw (rh t2062)) pv2066
theorem pv2064 : R t2064 t1 := result (f := t2063) (a := t2055) (u := t1) (v := t2055) pv2063 (aw (ri t2055)) pv2055
theorem pv2061 : R t2061 t1 := result (f := t2058) (a := t2060) (u := t2058) (v := t2064) (refl t2058) (awb t0 t2055 t2060 t2062 (refl _)) pv2064
theorem pv2059 : R t2059 t1 := result (f := t0) (a := t2058) (u := t0) (v := t2061) (refl t0) (aw (rh t2058)) pv2061
theorem pv2056 : R t2056 t1 := result (f := t2) (a := t2055) (u := t2) (v := t2059) (refl t2) (aw (ra t0 t2055)) pv2059
theorem pv2057 : R t2057 t1 := result (f := t2056) (a := t1943) (u := t1) (v := t1943) pv2056 (aw (ri t1943)) pv1943
theorem pv1956 : R t1956 t1 := result (f := t1952) (a := t1955) (u := t1946) (v := t2057) pv1952 (awb t2 t1943 t1955 t2055 (refl _)) pv2057
theorem pv1953 : R t1953 t1 := result (f := t0) (a := t1952) (u := t0) (v := t1956) (refl t0) (aw (rh t1952)) pv1956
theorem pv1954 : R t1954 t1946 := result (f := t1953) (a := t1946) (u := t1) (v := t1946) pv1953 (aw (ri t1946)) (refl t1946)
theorem pv1951 : R t1951 t1946 := result (f := t1948) (a := t1950) (u := t1948) (v := t1954) (refl t1948) (awb t0 t1946 t1950 t1952 (refl _)) pv1954
end Blc.H44.Pump
