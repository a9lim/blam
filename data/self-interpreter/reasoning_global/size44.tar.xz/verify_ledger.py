"""Independently decode and scope-check the exact syntax, bijection, and evidence in every ledger row."""
import csv,json,re
from collections import Counter
from functools import lru_cache
from pathlib import Path
BASE=Path(__file__).resolve().parent
def rows(name):
    with (BASE/name).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def load(n):return json.loads((BASE/n).read_text())
def ledger():
    for l in (BASE/'ledger.json').open():
        if l.strip() not in ('[',']'):yield json.loads(l.strip().removesuffix(','))
def decode(s,i=0,d=0):
    if s[i]=='1':
        j=s.index('0',i);v=j-i-1;assert 0<=v<d
        return f'(.var {v})',j+1,(0,1,v)
    if s[i+1]=='0':
        u,j,(l,v,x)=decode(s,i+2,d+1);return f'(.lam {u})',j,(l+1,v,x)
    f,j,a=decode(s,i+2,d);u,k,b=decode(s,j,d)
    return f'(.app {f} {u})',k,tuple(x+y for x,y in zip(a,b))
def paths(ps):return '['+','.join('['+','.join('.'+d for d in p)+']' for p in ps)+']'
@lru_cache(32)
def source(mod):return (BASE/(mod+'.lean')).read_text()
def literal(body,n,ast,s,code='code'):
    assert f'def {n} : Term := {ast}\n' in body
    assert f'theorem wire_{n} : Closed {n} ∧ {code} {n} = {int("1"+s,2)} := by decide\n' in body
def indexed(name):
    rs=rows(name);ds={r['wire']:r for r in rs};assert len(rs)==len(ds);return ds
first=load('certs.json');extra=load('extra.json');exact=load('exact.json');alts=load('alternatives.json')
machines=dict(l.split() for l in (BASE/'machine-index.tsv').read_text().splitlines())
helpers=indexed('helper-manifest.tsv');final=indexed('residuals.tsv');direct=indexed('complete.tsv');initial=indexed('initial-residuals.tsv')
assert set(initial)==set(extra)=={w for w,z in first.items() if z==['open']} and len(initial)==3521
assert set(final)==set(helpers) and len(final)==75
charts=load('machine-certs.json')
assert all(charts[w][0]==k for w,k in machines.items()) and set(machines)==set(load('machine-layouts.json'))
del charts
wires=sorted((BASE/'wires.txt').read_text().split());assert len(wires)==len(set(wires))==len(first)==188768
assert first.keys()==set(wires)
tally=Counter();seen=set();seen_final=set()
for i,(s,r) in enumerate(zip(wires,ledger(),strict=True)):
    n='e'+str(int(s,2));b=f'Batch{i//160:04}';m=r['module'];k=r['kind'];th=r['theorem']
    ast,j,triple=decode(s);assert j==len(s)==44 and set(s)<=set('01') and tuple(r['triple'])==triple
    assert r['wire']==s and r['root']==('literal' if s.startswith('00') else 'app')
    assert set(r)=={'wire','root','triple','kind','strength','module','theorem'}
    literal(source(b),n,ast,s);body=source(m);z=None
    if s in helpers:
        h=helpers[s];ns='Blc.Floor44.Help44';term='Blc.Floor44.'+n
        assert m=='H44Bridge' and th==h['theorem']==ns+'.ex_'+n
        literal(source('H44Literals'),n,ast,s,'sentinel')
        assert f'theorem same_{n} : Blc.H44.{n} = {term} := rfl\n' in body
        assert f'theorem ex_{n} : ¬ IsSelfInterpreter {term} := Blc.H44.ex_{n}\n' in body
        assert h['statement']=='¬ Blc.IsSelfInterpreter '+term and final[s]==direct[s] and final[s]['axioms']==h['axioms']
        method=h['method'];want='clock' if method=='macro_clock' else 'ordered' if method.startswith('ordered') else 'types'
        assert k==want and f'  add {n} {th} (\n' in source('Residuals');seen_final.add(s)
    elif m==b or re.fullmatch('More[0-9]{3}',m) or m=='Alternative':
        ns='Blc.Floor44'+('' if m==b else '.Alternative' if m=='Alternative' else '.Additional')
        term=ns+'.'+n;assert th==ns+'.cert_'+n and 'namespace '+ns+'\n' in body
        literal(body,n,ast,s)
        z=first[s] if m==b else alts[s] if m=='Alternative' else extra[s]
        assert k==z[0]
        if k=='shortPublic':
            assert len(z[2])==37 and f'(p := {paths(z[1])}) (q := {paths(z[3])}) SelfintSingleObject.selfintSizeBound_38' in body
        if r['strength']=='complete':
            assert f'theorem cert_{n} : ¬ IsSelfInterpreter {n} :=' in body
            block=body.split('theorem cert_'+n+' :',1)[1].split('#print axioms',1)[0]
            assert f'(ps := {paths(z[1])})' in block or f'replay {paths(z[1])} ' in block or f'(p := {paths(z[1])})' in block
    else:
        isreg=m.startswith('R');assert m==('R' if isreg else 'E')+n[1:]
        ns=('Certgen.' if isreg else 'Blc.Floor44.')+m;term=ns+'.e'
        assert th==ns+'.excluded' and f'namespace {ns}\n' in body
        literal(body if 'def e : Term' in body else source(m+'Data'),'e',ast,s,'Blc.Floor44.code' if isreg else 'code')
        assert f'theorem excluded : ¬ IsSelfInterpreter e :=' in body
        assert (k=={'reg':'regular','safe':'regularRigid'}[machines[s]]) if isreg else (k=='machineMismatch' and s in exact)
    if r['strength']=='predicate':
        assert z and k in {'smaller','width','three','chain','identityHead','sourceHead','payload'}
        sig=f'checkPay {n} {paths(z[1])} {z[2]} {paths(z[3])}' if k=='payload' else f'check {n} {paths(z[1])} .{k}'
        assert f'theorem cert_{n} : {sig} = true := by decide\n' in body
    else:
        assert r['strength']=='complete';seen.add(s);d=direct[s]
        assert (d['kind'],d['theorem'],d['file'],d['statement'])==(k,th,m+'.lean','¬ Blc.IsSelfInterpreter '+term)
    if s in initial:assert all(initial[s][x]==r[x] for x in ('wire','module','kind','strength','theorem'))
    tally[k,r['root']]+=1
assert seen==set(direct) and len(seen)==9602 and seen_final==set(final)
assert [r['wire'] for r in rows('residuals.tsv')]==[format(int(x),'044b') for x in re.findall(r'^  add e(\d+) ',source('Residuals'),re.M)]
for r in rows('by-family.tsv'):
    a,l=tally[r['kind'],'app'],tally[r['kind'],'literal']
    assert [int(r[x]) for x in ('app','literal','total')]==[a,l,a+l]
print(f'{len(wires)} distinct scoped literals, resource triples, sentinel wire identities and ledger theorems matched.')
print('179166 exact finite predicates, 9602 complete negative statements, 75 collected final residuals.')
