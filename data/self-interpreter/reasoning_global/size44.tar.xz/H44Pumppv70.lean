import H44Pumppv69
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5087 : R t5087 t5090 := result (f := t5071) (a := t1) (u := t5071) (v := t5089) (refl t5071) (awb t0 t5068 t1 t1 (cI)) pv5089
theorem pv5118 : R t5118 t5117 := result (f := t1) (a := t5117) (u := t1) (v := t5117) (refl t1) (aw (ri t5117)) (refl t5117)
theorem pv5116 : R t5116 t5117 := result (f := t22) (a := t5095) (u := t24) (v := t5118) pv22 (aw (ra t1 t5095)) pv5118
theorem pv5114 : R t5114 t5117 := result (f := t5098) (a := t1) (u := t5098) (v := t5116) (refl t5098) (awb t0 t5095 t1 t1 (cI)) pv5116
theorem pv5120 : R t5120 t1 := result (f := t4965) (a := t1) (u := t4959) (v := t5037) pv4965 (awb t2 t4956 t1 t1 (cI)) pv5037
theorem pv5121 : R t5121 t1 := result (f := t5120) (a := t1) (u := t1) (v := t1) pv5120 (aw (ri t1)) (refl t1)
theorem pv5095 : R t5095 t1 := result (f := t5093) (a := t1) (u := t5093) (v := t5121) (refl t5093) (awb t4965 t1 t1 t1 (cI)) pv5121
theorem pv5119 : R t5119 t1 := result (f := t28) (a := t5095) (u := t1) (v := t5095) pv28 (aw (ri t5095)) pv5095
theorem pv5115 : R t5115 t1 := result (f := t5114) (a := t1) (u := t5117) (v := t5119) pv5114 (awb t1 t5095 t1 t1 (cI)) pv5119
theorem pv5109 : R t5109 t1 := result (f := t5107) (a := t1) (u := t5107) (v := t5115) (refl t5107) (awb t5098 t1 t1 t1 (cI)) pv5115
theorem pv5113 : R t5113 t5112 := result (f := t5109) (a := t5112) (u := t1) (v := t5112) pv5109 (aw (ri t5112)) (refl t5112)
theorem pv5110 : R t5110 t5112 := result (f := t0) (a := t5109) (u := t0) (v := t5113) (refl t0) (aw (rh t5109)) pv5113
theorem pv5123 : R t5123 t5122 := result (f := t5109) (a := t5122) (u := t1) (v := t5122) pv5109 (aw (ri t5122)) (refl t5122)
theorem pv5111 : R t5111 t5122 := result (f := t5110) (a := t5095) (u := t5112) (v := t5123) pv5110 (aw (ra t5109 t5095)) pv5123
theorem pv5108 : R t5108 t5122 := result (f := t5098) (a := t5107) (u := t5098) (v := t5111) (refl t5098) (awb t0 t5095 t5107 t5109 (refl _)) pv5111
theorem pv5102 : R t5102 t5122 := result (f := t5100) (a := t1) (u := t5100) (v := t5108) (refl t5100) (aw (ra t5098 t1)) pv5108
theorem pv5134 : R t5134 t1 := result (f := t5109) (a := t1) (u := t1) (v := t1) pv5109 (aw (ri t1)) (refl t1)
theorem pv5135 : R t5135 t1 := result (f := t5134) (a := t5095) (u := t1) (v := t5095) pv5134 (aw (ri t5095)) pv5095
theorem pv5132 : R t5132 t1 := result (f := t5102) (a := t1) (u := t5122) (v := t5135) pv5102 (awb t5109 t5095 t1 t1 (cI)) pv5135
theorem pv5133 : R t5133 t1 := result (f := t5132) (a := t1) (u := t1) (v := t1) pv5132 (aw (ri t1)) (refl t1)
theorem pv5129 : R t5129 t1 := result (f := t5127) (a := t1) (u := t5127) (v := t5133) (refl t5127) (awb t5102 t1 t1 t1 (cI)) pv5133
theorem pv5130 : R t5130 t1 := result (f := t5109) (a := t5129) (u := t1) (v := t5129) pv5109 (aw (ri t5129)) pv5129
theorem pv5131 : R t5131 t1 := result (f := t5130) (a := t5095) (u := t1) (v := t5095) pv5130 (aw (ri t5095)) pv5095
theorem pv5128 : R t5128 t1 := result (f := t5102) (a := t5127) (u := t5122) (v := t5131) pv5102 (awb t5109 t5095 t5127 t5129 (refl _)) pv5131
theorem pv5124 : R t5124 t1 := result (f := t5105) (a := t1) (u := t5105) (v := t5128) (refl t5105) (aw (ra t5102 t1)) pv5128
theorem pv5125 : R t5125 t1 := result (f := t5109) (a := t5124) (u := t1) (v := t5124) pv5109 (aw (ri t5124)) pv5124
theorem pv5126 : R t5126 t1 := result (f := t5125) (a := t5095) (u := t1) (v := t5095) pv5125 (aw (ri t5095)) pv5095
theorem pv5106 : R t5106 t1 := result (f := t5102) (a := t5105) (u := t5122) (v := t5126) pv5102 (awb t5109 t5095 t5105 t5124 (refl _)) pv5126
theorem pv5103 : R t5103 t1 := result (f := t0) (a := t5102) (u := t0) (v := t5106) (refl t0) (aw (rh t5102)) pv5106
theorem pv5104 : R t5104 t1 := result (f := t5103) (a := t5095) (u := t1) (v := t5095) pv5103 (aw (ri t5095)) pv5095
theorem pv5101 : R t5101 t1 := result (f := t5098) (a := t5100) (u := t5098) (v := t5104) (refl t5098) (awb t0 t5095 t5100 t5102 (refl _)) pv5104
theorem pv5099 : R t5099 t1 := result (f := t0) (a := t5098) (u := t0) (v := t5101) (refl t0) (aw (rh t5098)) pv5101
theorem pv5096 : R t5096 t1 := result (f := t2) (a := t5095) (u := t2) (v := t5099) (refl t2) (aw (ra t0 t5095)) pv5099
theorem pv5097 : R t5097 t1 := result (f := t5096) (a := t4956) (u := t1) (v := t4956) pv5096 (aw (ri t4956)) pv4956
theorem pv5094 : R t5094 t1 := result (f := t4965) (a := t5093) (u := t4959) (v := t5097) pv4965 (awb t2 t4956 t5093 t5095 (refl _)) pv5097
theorem pv5068 : R t5068 t1 := result (f := t4968) (a := t1) (u := t4968) (v := t5094) (refl t4968) (aw (ra t4965 t1)) pv5094
theorem pv5092 : R t5092 t1 := result (f := t28) (a := t5068) (u := t1) (v := t5068) pv28 (aw (ri t5068)) pv5068
theorem pv5088 : R t5088 t1 := result (f := t5087) (a := t1) (u := t5090) (v := t5092) pv5087 (awb t1 t5068 t1 t1 (cI)) pv5092
theorem pv5082 : R t5082 t1 := result (f := t5080) (a := t1) (u := t5080) (v := t5088) (refl t5080) (awb t5071 t1 t1 t1 (cI)) pv5088
theorem pv5086 : R t5086 t5085 := result (f := t5082) (a := t5085) (u := t1) (v := t5085) pv5082 (aw (ri t5085)) (refl t5085)
theorem pv5083 : R t5083 t5085 := result (f := t0) (a := t5082) (u := t0) (v := t5086) (refl t0) (aw (rh t5082)) pv5086
theorem pv5137 : R t5137 t5136 := result (f := t5082) (a := t5136) (u := t1) (v := t5136) pv5082 (aw (ri t5136)) (refl t5136)
theorem pv5084 : R t5084 t5136 := result (f := t5083) (a := t5068) (u := t5085) (v := t5137) pv5083 (aw (ra t5082 t5068)) pv5137
theorem pv5081 : R t5081 t5136 := result (f := t5071) (a := t5080) (u := t5071) (v := t5084) (refl t5071) (awb t0 t5068 t5080 t5082 (refl _)) pv5084
theorem pv5075 : R t5075 t5136 := result (f := t5073) (a := t1) (u := t5073) (v := t5081) (refl t5073) (aw (ra t5071 t1)) pv5081
theorem pv5148 : R t5148 t1 := result (f := t5082) (a := t1) (u := t1) (v := t1) pv5082 (aw (ri t1)) (refl t1)
theorem pv5149 : R t5149 t1 := result (f := t5148) (a := t5068) (u := t1) (v := t5068) pv5148 (aw (ri t5068)) pv5068
theorem pv5146 : R t5146 t1 := result (f := t5075) (a := t1) (u := t5136) (v := t5149) pv5075 (awb t5082 t5068 t1 t1 (cI)) pv5149
theorem pv5147 : R t5147 t1 := result (f := t5146) (a := t1) (u := t1) (v := t1) pv5146 (aw (ri t1)) (refl t1)
theorem pv5143 : R t5143 t1 := result (f := t5141) (a := t1) (u := t5141) (v := t5147) (refl t5141) (awb t5075 t1 t1 t1 (cI)) pv5147
theorem pv5144 : R t5144 t1 := result (f := t5082) (a := t5143) (u := t1) (v := t5143) pv5082 (aw (ri t5143)) pv5143
theorem pv5145 : R t5145 t1 := result (f := t5144) (a := t5068) (u := t1) (v := t5068) pv5144 (aw (ri t5068)) pv5068
theorem pv5142 : R t5142 t1 := result (f := t5075) (a := t5141) (u := t5136) (v := t5145) pv5075 (awb t5082 t5068 t5141 t5143 (refl _)) pv5145
theorem pv5138 : R t5138 t1 := result (f := t5078) (a := t1) (u := t5078) (v := t5142) (refl t5078) (aw (ra t5075 t1)) pv5142
theorem pv5139 : R t5139 t1 := result (f := t5082) (a := t5138) (u := t1) (v := t5138) pv5082 (aw (ri t5138)) pv5138
end Blc.H44.Pump
