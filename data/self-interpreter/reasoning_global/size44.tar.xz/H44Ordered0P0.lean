import H44Ordered0Defs
namespace Blc.H44Chain
open Term SelfintControl SelfintLowerBound ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
theorem oh0_0 (ρ : Env 3) (a0 : ρ 0 = 0) : eval gm0 ρ ob0_0 = 0 := by
  exact a0
theorem oh0_1 (ρ : Env 3) (a0 : ρ 0 = 0) : eval gm0 ρ ob0_1 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_0) (oh0_0 ρ a0) (oh0_0 ρ a0) (by decide : opm0 0 0 = 0)
theorem oh0_2 (ρ : Env 3) (a0 : ρ 0 = 1) : eval gm0 ρ ob0_0 = 1 := by
  exact a0
theorem oh0_3 (ρ : Env 3) (a0 : ρ 0 = 1) : eval gm0 ρ ob0_1 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_0) (oh0_2 ρ a0) (oh0_2 ρ a0) (by decide : opm0 1 1 = 2)
theorem oh0_4 (ρ : Env 3) (a0 : ρ 0 = 2) : eval gm0 ρ ob0_0 = 2 := by
  exact a0
theorem oh0_5 (ρ : Env 3) (a0 : ρ 0 = 2) : eval gm0 ρ ob0_1 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_0) (oh0_4 ρ a0) (oh0_4 ρ a0) (by decide : opm0 2 2 = 3)
theorem oh0_6 (ρ : Env 3) (a0 : ρ 0 = 3) : eval gm0 ρ ob0_0 = 3 := by
  exact a0
theorem oh0_7 (ρ : Env 3) (a0 : ρ 0 = 3) : eval gm0 ρ ob0_1 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_0) (oh0_6 ρ a0) (oh0_6 ρ a0) (by decide : opm0 3 3 = 3)
theorem oh0_8 (ρ : Env 3)  : eval gm0 ρ ob0_2 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_1) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_1) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 2 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_1 (push 0 ρ) rfl)
    · exact (oh0_3 (push 1 ρ) rfl)
    · exact (oh0_5 (push 2 ρ) rfl)
    · exact (oh0_7 (push 3 ρ) rfl)
  rw [h]
  decide
theorem oh0_9 (ρ : Env 3) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_3 = 0 := by
  exact a1
theorem oh0_10 (ρ : Env 3) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_4 = 0 := by
  exact a2
theorem oh0_11 (ρ : Env 3)  : eval gm0 ρ ob0_5 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_0) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_0) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 1 else if a = 2 then 2 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_0 (push 0 ρ) rfl)
    · exact (oh0_2 (push 1 ρ) rfl)
    · exact (oh0_4 (push 2 ρ) rfl)
    · exact (oh0_6 (push 3 ρ) rfl)
  rw [h]
  decide
theorem oh0_12 (ρ : Env 3) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_6 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_4) (a := ob0_5) (oh0_10 ρ a2) (oh0_11 ρ) (by decide : opm0 0 1 = 0)
theorem oh0_13 (ρ : Env 3) (a0 : ρ 0 = 0) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_7 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_12 ρ a2) (oh0_0 ρ a0) (by decide : opm0 0 0 = 0)
theorem oh0_14 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 0) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_13 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 0 0 = 0)
theorem oh0_15 (ρ : Env 3) (a0 : ρ 0 = 1) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_7 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_12 ρ a2) (oh0_2 ρ a0) (by decide : opm0 0 1 = 0)
theorem oh0_16 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 0) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_15 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 0 0 = 0)
theorem oh0_17 (ρ : Env 3) (a0 : ρ 0 = 2) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_7 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_12 ρ a2) (oh0_4 ρ a0) (by decide : opm0 0 2 = 0)
theorem oh0_18 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 0) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_17 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 0 0 = 0)
theorem oh0_19 (ρ : Env 3) (a0 : ρ 0 = 3) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_7 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_12 ρ a2) (oh0_6 ρ a0) (by decide : opm0 0 3 = 0)
theorem oh0_20 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 0) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_19 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 0 0 = 0)
theorem oh0_21 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_9 = 0 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 0
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 0 else if a = 2 then 0 else 0) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_14 (push 0 ρ) rfl a0 a1)
    · exact (oh0_16 (push 1 ρ) rfl a0 a1)
    · exact (oh0_18 (push 2 ρ) rfl a0 a1)
    · exact (oh0_20 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_22 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_10 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_9 ρ a1) (oh0_21 ρ a0 a1) (by decide : opm0 0 0 = 0)
theorem oh0_23 (ρ : Env 3) (a1 : ρ 1 = 1) : eval gm0 ρ ob0_3 = 1 := by
  exact a1
theorem oh0_24 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 1) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_13 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 0 1 = 0)
theorem oh0_25 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 1) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_15 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 0 1 = 0)
theorem oh0_26 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 1) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_17 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 0 1 = 0)
theorem oh0_27 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 1) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_19 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 0 1 = 0)
theorem oh0_28 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_9 = 0 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 0
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 0 else if a = 2 then 0 else 0) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_24 (push 0 ρ) rfl a0 a1)
    · exact (oh0_25 (push 1 ρ) rfl a0 a1)
    · exact (oh0_26 (push 2 ρ) rfl a0 a1)
    · exact (oh0_27 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_29 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 0) : eval gm0 ρ ob0_10 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_9 ρ a1) (oh0_28 ρ a0 a1) (by decide : opm0 0 0 = 0)
theorem oh0_30 (ρ : Env 3) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_3 = 2 := by
  exact a1
theorem oh0_31 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 2) (a2 : ρ 2 = 0) : eval gm0 ρ ob0_8 = 0 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_13 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 0 2 = 0)
end Blc.H44Chain
