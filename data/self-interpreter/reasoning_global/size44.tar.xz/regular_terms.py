from wireterms import *
om=A(L(A(V(0),V(0))),L(A(V(0),V(0))))
C=V(1);R=V(0)
def mask(t,d=0):
    if t[0]=='V':return t if t[1]<d else ('C',t[1])
    if t[0]=='L':return L(mask(t[1],d+1))
    return A(mask(t[1],d),mask(t[2],d))
def probeType(e,kind):
    # Each term has a normal form if e is an interpreter.
    if kind=='raw':return e # only weak-head clock
    if kind=='rigid':return A(A(e,C),lc.bitlist('0010',R))
    if kind=='generic':return A(A(e,C),R) # only when stuck placeholders? DO NOT USE
    if kind=='suffix':return A(A(e,KI),lc.bitlist('0010',R))
    if kind=='poison':return A(A(e,L(L(I))),lc.bitlist('0010',om))
    if kind=='ignore':return A(A(e,L(L(R))),lc.bitlist('0010',om)) # unused
    if kind=='value':return A(A(e,L(L(V(1)))),lc.bitlist('0010',om))
    if kind=='apply':return A(A(A(A(e,L(L(V(1)))),lc.bitlist('0010',om)),om),I)
    if kind.startswith('extra'):
        t=probeType(e,'suffix')
        for _ in range(int(kind[5:])):t=A(t,om)
        return t # target R applied to omegas has a clock; need direct weak-head solution
    raise AssertionError()
