import H44Pumppv53
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3893 : R t3893 t3907 := result (f := t3883) (a := t3892) (u := t3883) (v := t3896) (refl t3883) (awb t0 t3880 t3892 t3894 (refl _)) pv3896
theorem pv3887 : R t3887 t3907 := result (f := t3885) (a := t1) (u := t3885) (v := t3893) (refl t3885) (aw (ra t3883 t1)) pv3893
theorem pv3919 : R t3919 t1 := result (f := t3894) (a := t1) (u := t1) (v := t1) pv3894 (aw (ri t1)) (refl t1)
theorem pv3920 : R t3920 t1 := result (f := t3919) (a := t3880) (u := t1) (v := t3880) pv3919 (aw (ri t3880)) pv3880
theorem pv3917 : R t3917 t1 := result (f := t3887) (a := t1) (u := t3907) (v := t3920) pv3887 (awb t3894 t3880 t1 t1 (cI)) pv3920
theorem pv3918 : R t3918 t1 := result (f := t3917) (a := t1) (u := t1) (v := t1) pv3917 (aw (ri t1)) (refl t1)
theorem pv3914 : R t3914 t1 := result (f := t3912) (a := t1) (u := t3912) (v := t3918) (refl t3912) (awb t3887 t1 t1 t1 (cI)) pv3918
theorem pv3915 : R t3915 t1 := result (f := t3894) (a := t3914) (u := t1) (v := t3914) pv3894 (aw (ri t3914)) pv3914
theorem pv3916 : R t3916 t1 := result (f := t3915) (a := t3880) (u := t1) (v := t3880) pv3915 (aw (ri t3880)) pv3880
theorem pv3913 : R t3913 t1 := result (f := t3887) (a := t3912) (u := t3907) (v := t3916) pv3887 (awb t3894 t3880 t3912 t3914 (refl _)) pv3916
theorem pv3909 : R t3909 t1 := result (f := t3890) (a := t1) (u := t3890) (v := t3913) (refl t3890) (aw (ra t3887 t1)) pv3913
theorem pv3910 : R t3910 t1 := result (f := t3894) (a := t3909) (u := t1) (v := t3909) pv3894 (aw (ri t3909)) pv3909
theorem pv3911 : R t3911 t1 := result (f := t3910) (a := t3880) (u := t1) (v := t3880) pv3910 (aw (ri t3880)) pv3880
theorem pv3891 : R t3891 t1 := result (f := t3887) (a := t3890) (u := t3907) (v := t3911) pv3887 (awb t3894 t3880 t3890 t3909 (refl _)) pv3911
theorem pv3888 : R t3888 t1 := result (f := t0) (a := t3887) (u := t0) (v := t3891) (refl t0) (aw (rh t3887)) pv3891
theorem pv3889 : R t3889 t1 := result (f := t3888) (a := t3880) (u := t1) (v := t3880) pv3888 (aw (ri t3880)) pv3880
theorem pv3886 : R t3886 t1 := result (f := t3883) (a := t3885) (u := t3883) (v := t3889) (refl t3883) (awb t0 t3880 t3885 t3887 (refl _)) pv3889
theorem pv3884 : R t3884 t1 := result (f := t0) (a := t3883) (u := t0) (v := t3886) (refl t0) (aw (rh t3883)) pv3886
theorem pv3881 : R t3881 t1 := result (f := t2) (a := t3880) (u := t2) (v := t3884) (refl t2) (aw (ra t0 t3880)) pv3884
theorem pv3882 : R t3882 t1 := result (f := t3881) (a := t3547) (u := t1) (v := t3547) pv3881 (aw (ri t3547)) pv3547
theorem pv3879 : R t3879 t1 := result (f := t3556) (a := t3878) (u := t3550) (v := t3882) pv3556 (awb t2 t3547 t3878 t3880 (refl _)) pv3882
theorem pv3853 : R t3853 t1 := result (f := t3559) (a := t1) (u := t3559) (v := t3879) (refl t3559) (aw (ra t3556 t1)) pv3879
theorem pv3877 : R t3877 t1 := result (f := t28) (a := t3853) (u := t1) (v := t3853) pv28 (aw (ri t3853)) pv3853
theorem pv3873 : R t3873 t1 := result (f := t3872) (a := t1) (u := t3875) (v := t3877) pv3872 (awb t1 t3853 t1 t1 (cI)) pv3877
theorem pv3867 : R t3867 t1 := result (f := t3865) (a := t1) (u := t3865) (v := t3873) (refl t3865) (awb t3856 t1 t1 t1 (cI)) pv3873
theorem pv3871 : R t3871 t3870 := result (f := t3867) (a := t3870) (u := t1) (v := t3870) pv3867 (aw (ri t3870)) (refl t3870)
theorem pv3868 : R t3868 t3870 := result (f := t0) (a := t3867) (u := t0) (v := t3871) (refl t0) (aw (rh t3867)) pv3871
theorem pv3922 : R t3922 t3921 := result (f := t3867) (a := t3921) (u := t1) (v := t3921) pv3867 (aw (ri t3921)) (refl t3921)
theorem pv3869 : R t3869 t3921 := result (f := t3868) (a := t3853) (u := t3870) (v := t3922) pv3868 (aw (ra t3867 t3853)) pv3922
theorem pv3866 : R t3866 t3921 := result (f := t3856) (a := t3865) (u := t3856) (v := t3869) (refl t3856) (awb t0 t3853 t3865 t3867 (refl _)) pv3869
theorem pv3860 : R t3860 t3921 := result (f := t3858) (a := t1) (u := t3858) (v := t3866) (refl t3858) (aw (ra t3856 t1)) pv3866
theorem pv3933 : R t3933 t1 := result (f := t3867) (a := t1) (u := t1) (v := t1) pv3867 (aw (ri t1)) (refl t1)
theorem pv3934 : R t3934 t1 := result (f := t3933) (a := t3853) (u := t1) (v := t3853) pv3933 (aw (ri t3853)) pv3853
theorem pv3931 : R t3931 t1 := result (f := t3860) (a := t1) (u := t3921) (v := t3934) pv3860 (awb t3867 t3853 t1 t1 (cI)) pv3934
theorem pv3932 : R t3932 t1 := result (f := t3931) (a := t1) (u := t1) (v := t1) pv3931 (aw (ri t1)) (refl t1)
theorem pv3928 : R t3928 t1 := result (f := t3926) (a := t1) (u := t3926) (v := t3932) (refl t3926) (awb t3860 t1 t1 t1 (cI)) pv3932
theorem pv3929 : R t3929 t1 := result (f := t3867) (a := t3928) (u := t1) (v := t3928) pv3867 (aw (ri t3928)) pv3928
theorem pv3930 : R t3930 t1 := result (f := t3929) (a := t3853) (u := t1) (v := t3853) pv3929 (aw (ri t3853)) pv3853
theorem pv3927 : R t3927 t1 := result (f := t3860) (a := t3926) (u := t3921) (v := t3930) pv3860 (awb t3867 t3853 t3926 t3928 (refl _)) pv3930
theorem pv3923 : R t3923 t1 := result (f := t3863) (a := t1) (u := t3863) (v := t3927) (refl t3863) (aw (ra t3860 t1)) pv3927
theorem pv3924 : R t3924 t1 := result (f := t3867) (a := t3923) (u := t1) (v := t3923) pv3867 (aw (ri t3923)) pv3923
theorem pv3925 : R t3925 t1 := result (f := t3924) (a := t3853) (u := t1) (v := t3853) pv3924 (aw (ri t3853)) pv3853
theorem pv3864 : R t3864 t1 := result (f := t3860) (a := t3863) (u := t3921) (v := t3925) pv3860 (awb t3867 t3853 t3863 t3923 (refl _)) pv3925
theorem pv3861 : R t3861 t1 := result (f := t0) (a := t3860) (u := t0) (v := t3864) (refl t0) (aw (rh t3860)) pv3864
theorem pv3862 : R t3862 t1 := result (f := t3861) (a := t3853) (u := t1) (v := t3853) pv3861 (aw (ri t3853)) pv3853
theorem pv3859 : R t3859 t1 := result (f := t3856) (a := t3858) (u := t3856) (v := t3862) (refl t3856) (awb t0 t3853 t3858 t3860 (refl _)) pv3862
theorem pv3857 : R t3857 t1 := result (f := t0) (a := t3856) (u := t0) (v := t3859) (refl t0) (aw (rh t3856)) pv3859
theorem pv3854 : R t3854 t1 := result (f := t2) (a := t3853) (u := t2) (v := t3857) (refl t2) (aw (ra t0 t3853)) pv3857
theorem pv3855 : R t3855 t1 := result (f := t3854) (a := t3547) (u := t1) (v := t3547) pv3854 (aw (ri t3547)) pv3547
theorem pv3560 : R t3560 t1 := result (f := t3556) (a := t3559) (u := t3550) (v := t3855) pv3556 (awb t2 t3547 t3559 t3853 (refl _)) pv3855
theorem pv3557 : R t3557 t1 := result (f := t0) (a := t3556) (u := t0) (v := t3560) (refl t0) (aw (rh t3556)) pv3560
theorem pv3558 : R t3558 t3550 := result (f := t3557) (a := t3550) (u := t1) (v := t3550) pv3557 (aw (ri t3550)) (refl t3550)
theorem pv3555 : R t3555 t3550 := result (f := t3552) (a := t3554) (u := t3552) (v := t3558) (refl t3552) (awb t0 t3550 t3554 t3556 (refl _)) pv3558
theorem pv3553 : R t3553 t3550 := result (f := t0) (a := t3552) (u := t0) (v := t3555) (refl t0) (aw (rh t3552)) pv3555
theorem pv3551 : R t3551 t3550 := result (f := t2) (a := t3550) (u := t2) (v := t3553) (refl t2) (aw (ra t0 t3550)) pv3553
end Blc.H44.Pump
