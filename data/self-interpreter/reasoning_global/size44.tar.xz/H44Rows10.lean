import H44Literals
import H44F4846363331614
import H44F4846363332110
import H44Lib0
import H44Lib1
namespace Blc.H44
theorem ex_e4846363331466 : ¬ IsSelfInterpreter e4846363331466 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4846363331466 3 = true)
#print axioms ex_e4846363331466
theorem ex_e4846363331614 : ¬ IsSelfInterpreter e4846363331614 := H44F4846363331614.excluded
#print axioms ex_e4846363331614
theorem ex_e4846363331810 : ¬ IsSelfInterpreter e4846363331810 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846363331810 1 = true)
#print axioms ex_e4846363331810
theorem ex_e4846363332110 : ¬ IsSelfInterpreter e4846363332110 := H44F4846363332110.excluded
#print axioms ex_e4846363332110
theorem ex_e4846363332194 : ¬ IsSelfInterpreter e4846363332194 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846363332194 1 = true)
#print axioms ex_e4846363332194
theorem ex_e4846426121786 : ¬ IsSelfInterpreter e4846426121786 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846426121786 1 = true)
#print axioms ex_e4846426121786
end Blc.H44
