import H44Pumppv109
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv7880 : R t7880 t7879 := result (f := t1) (a := t7879) (u := t1) (v := t7879) (refl t1) (aw (ri t7879)) (refl t7879)
theorem pv7878 : R t7878 t7879 := result (f := t22) (a := t7857) (u := t24) (v := t7880) pv22 (aw (ra t1 t7857)) pv7880
theorem pv7876 : R t7876 t7879 := result (f := t7860) (a := t1) (u := t7860) (v := t7878) (refl t7860) (awb t0 t7857 t1 t1 (cI)) pv7878
theorem pv7912 : R t7912 t7911 := result (f := t1) (a := t7911) (u := t1) (v := t7911) (refl t1) (aw (ri t7911)) (refl t7911)
theorem pv7910 : R t7910 t7911 := result (f := t22) (a := t7890) (u := t24) (v := t7912) pv22 (aw (ra t1 t7890)) pv7912
theorem pv7908 : R t7908 t7911 := result (f := t7892) (a := t1) (u := t7892) (v := t7910) (refl t7892) (awb t0 t7890 t1 t1 (cI)) pv7910
theorem pv7913 : R t7913 t7890 := result (f := t28) (a := t7890) (u := t1) (v := t7890) pv28 (aw (ri t7890)) (refl t7890)
theorem pv7909 : R t7909 t7890 := result (f := t7908) (a := t1) (u := t7911) (v := t7913) pv7908 (awb t1 t7890 t1 t1 (cI)) pv7913
theorem pv7903 : R t7903 t7890 := result (f := t7901) (a := t1) (u := t7901) (v := t7909) (refl t7901) (awb t7892 t1 t1 t1 (cI)) pv7909
theorem pv7937 : R t7937 t7936 := result (f := t1) (a := t7936) (u := t1) (v := t7936) (refl t1) (aw (ri t7936)) (refl t7936)
theorem pv7935 : R t7935 t7936 := result (f := t22) (a := t7914) (u := t24) (v := t7937) pv22 (aw (ra t1 t7914)) pv7937
theorem pv7933 : R t7933 t7936 := result (f := t7917) (a := t1) (u := t7917) (v := t7935) (refl t7917) (awb t0 t7914 t1 t1 (cI)) pv7935
theorem pv7964 : R t7964 t7963 := result (f := t1) (a := t7963) (u := t1) (v := t7963) (refl t1) (aw (ri t7963)) (refl t7963)
theorem pv7962 : R t7962 t7963 := result (f := t22) (a := t7941) (u := t24) (v := t7964) pv22 (aw (ra t1 t7941)) pv7964
theorem pv7960 : R t7960 t7963 := result (f := t7944) (a := t1) (u := t7944) (v := t7962) (refl t7944) (awb t0 t7941 t1 t1 (cI)) pv7962
theorem pv7969 : R t7969 t1 := result (f := t7353) (a := t1) (u := t149) (v := t231) pv7353 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv7970 : R t7970 t1 := result (f := t7969) (a := t1) (u := t1) (v := t1) pv7969 (aw (ri t1)) (refl t1)
theorem pv7887 : R t7887 t1 := result (f := t7885) (a := t1) (u := t7885) (v := t7970) (refl t7885) (awb t7353 t1 t1 t1 (cI)) pv7970
theorem pv7968 : R t7968 t1 := result (f := t3) (a := t7887) (u := t1) (v := t7887) pv3 (aw (ri t7887)) pv7887
theorem pv7966 : R t7966 t1 := result (f := t7903) (a := t1) (u := t7890) (v := t7968) pv7903 (awb t2 t7887 t1 t1 (cI)) pv7968
theorem pv7967 : R t7967 t1 := result (f := t7966) (a := t1) (u := t1) (v := t1) pv7966 (aw (ri t1)) (refl t1)
theorem pv7941 : R t7941 t1 := result (f := t7939) (a := t1) (u := t7939) (v := t7967) (refl t7939) (awb t7903 t1 t1 t1 (cI)) pv7967
theorem pv7965 : R t7965 t1 := result (f := t28) (a := t7941) (u := t1) (v := t7941) pv28 (aw (ri t7941)) pv7941
theorem pv7961 : R t7961 t1 := result (f := t7960) (a := t1) (u := t7963) (v := t7965) pv7960 (awb t1 t7941 t1 t1 (cI)) pv7965
theorem pv7955 : R t7955 t1 := result (f := t7953) (a := t1) (u := t7953) (v := t7961) (refl t7953) (awb t7944 t1 t1 t1 (cI)) pv7961
theorem pv7959 : R t7959 t7958 := result (f := t7955) (a := t7958) (u := t1) (v := t7958) pv7955 (aw (ri t7958)) (refl t7958)
theorem pv7956 : R t7956 t7958 := result (f := t0) (a := t7955) (u := t0) (v := t7959) (refl t0) (aw (rh t7955)) pv7959
theorem pv7972 : R t7972 t7971 := result (f := t7955) (a := t7971) (u := t1) (v := t7971) pv7955 (aw (ri t7971)) (refl t7971)
theorem pv7957 : R t7957 t7971 := result (f := t7956) (a := t7941) (u := t7958) (v := t7972) pv7956 (aw (ra t7955 t7941)) pv7972
theorem pv7954 : R t7954 t7971 := result (f := t7944) (a := t7953) (u := t7944) (v := t7957) (refl t7944) (awb t0 t7941 t7953 t7955 (refl _)) pv7957
theorem pv7948 : R t7948 t7971 := result (f := t7946) (a := t1) (u := t7946) (v := t7954) (refl t7946) (aw (ra t7944 t1)) pv7954
theorem pv7983 : R t7983 t1 := result (f := t7955) (a := t1) (u := t1) (v := t1) pv7955 (aw (ri t1)) (refl t1)
theorem pv7984 : R t7984 t1 := result (f := t7983) (a := t7941) (u := t1) (v := t7941) pv7983 (aw (ri t7941)) pv7941
theorem pv7981 : R t7981 t1 := result (f := t7948) (a := t1) (u := t7971) (v := t7984) pv7948 (awb t7955 t7941 t1 t1 (cI)) pv7984
theorem pv7982 : R t7982 t1 := result (f := t7981) (a := t1) (u := t1) (v := t1) pv7981 (aw (ri t1)) (refl t1)
theorem pv7978 : R t7978 t1 := result (f := t7976) (a := t1) (u := t7976) (v := t7982) (refl t7976) (awb t7948 t1 t1 t1 (cI)) pv7982
theorem pv7979 : R t7979 t1 := result (f := t7955) (a := t7978) (u := t1) (v := t7978) pv7955 (aw (ri t7978)) pv7978
theorem pv7980 : R t7980 t1 := result (f := t7979) (a := t7941) (u := t1) (v := t7941) pv7979 (aw (ri t7941)) pv7941
theorem pv7977 : R t7977 t1 := result (f := t7948) (a := t7976) (u := t7971) (v := t7980) pv7948 (awb t7955 t7941 t7976 t7978 (refl _)) pv7980
theorem pv7973 : R t7973 t1 := result (f := t7951) (a := t1) (u := t7951) (v := t7977) (refl t7951) (aw (ra t7948 t1)) pv7977
theorem pv7974 : R t7974 t1 := result (f := t7955) (a := t7973) (u := t1) (v := t7973) pv7955 (aw (ri t7973)) pv7973
theorem pv7975 : R t7975 t1 := result (f := t7974) (a := t7941) (u := t1) (v := t7941) pv7974 (aw (ri t7941)) pv7941
theorem pv7952 : R t7952 t1 := result (f := t7948) (a := t7951) (u := t7971) (v := t7975) pv7948 (awb t7955 t7941 t7951 t7973 (refl _)) pv7975
theorem pv7949 : R t7949 t1 := result (f := t0) (a := t7948) (u := t0) (v := t7952) (refl t0) (aw (rh t7948)) pv7952
theorem pv7950 : R t7950 t1 := result (f := t7949) (a := t7941) (u := t1) (v := t7941) pv7949 (aw (ri t7941)) pv7941
theorem pv7947 : R t7947 t1 := result (f := t7944) (a := t7946) (u := t7944) (v := t7950) (refl t7944) (awb t0 t7941 t7946 t7948 (refl _)) pv7950
theorem pv7945 : R t7945 t1 := result (f := t0) (a := t7944) (u := t0) (v := t7947) (refl t0) (aw (rh t7944)) pv7947
theorem pv7942 : R t7942 t1 := result (f := t2) (a := t7941) (u := t2) (v := t7945) (refl t2) (aw (ra t0 t7941)) pv7945
theorem pv7943 : R t7943 t1 := result (f := t7942) (a := t7887) (u := t1) (v := t7887) pv7942 (aw (ri t7887)) pv7887
theorem pv7940 : R t7940 t1 := result (f := t7903) (a := t7939) (u := t7890) (v := t7943) pv7903 (awb t2 t7887 t7939 t7941 (refl _)) pv7943
theorem pv7914 : R t7914 t1 := result (f := t7906) (a := t1) (u := t7906) (v := t7940) (refl t7906) (aw (ra t7903 t1)) pv7940
theorem pv7938 : R t7938 t1 := result (f := t28) (a := t7914) (u := t1) (v := t7914) pv28 (aw (ri t7914)) pv7914
theorem pv7934 : R t7934 t1 := result (f := t7933) (a := t1) (u := t7936) (v := t7938) pv7933 (awb t1 t7914 t1 t1 (cI)) pv7938
theorem pv7928 : R t7928 t1 := result (f := t7926) (a := t1) (u := t7926) (v := t7934) (refl t7926) (awb t7917 t1 t1 t1 (cI)) pv7934
theorem pv7932 : R t7932 t7931 := result (f := t7928) (a := t7931) (u := t1) (v := t7931) pv7928 (aw (ri t7931)) (refl t7931)
end Blc.H44.Pump
