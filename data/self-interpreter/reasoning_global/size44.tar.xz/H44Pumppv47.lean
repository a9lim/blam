import H44Pumppv46
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3227 : R t3227 t1 := result (f := t3225) (a := t1) (u := t3225) (v := t3233) (refl t3225) (awb t3216 t1 t1 t1 (cI)) pv3233
theorem pv3231 : R t3231 t3230 := result (f := t3227) (a := t3230) (u := t1) (v := t3230) pv3227 (aw (ri t3230)) (refl t3230)
theorem pv3228 : R t3228 t3230 := result (f := t0) (a := t3227) (u := t0) (v := t3231) (refl t0) (aw (rh t3227)) pv3231
theorem pv3438 : R t3438 t3437 := result (f := t3227) (a := t3437) (u := t1) (v := t3437) pv3227 (aw (ri t3437)) (refl t3437)
theorem pv3229 : R t3229 t3437 := result (f := t3228) (a := t3213) (u := t3230) (v := t3438) pv3228 (aw (ra t3227 t3213)) pv3438
theorem pv3226 : R t3226 t3437 := result (f := t3216) (a := t3225) (u := t3216) (v := t3229) (refl t3216) (awb t0 t3213 t3225 t3227 (refl _)) pv3229
theorem pv3220 : R t3220 t3437 := result (f := t3218) (a := t1) (u := t3218) (v := t3226) (refl t3218) (aw (ra t3216 t1)) pv3226
theorem pv3449 : R t3449 t1 := result (f := t3227) (a := t1) (u := t1) (v := t1) pv3227 (aw (ri t1)) (refl t1)
theorem pv3450 : R t3450 t1 := result (f := t3449) (a := t3213) (u := t1) (v := t3213) pv3449 (aw (ri t3213)) pv3213
theorem pv3447 : R t3447 t1 := result (f := t3220) (a := t1) (u := t3437) (v := t3450) pv3220 (awb t3227 t3213 t1 t1 (cI)) pv3450
theorem pv3448 : R t3448 t1 := result (f := t3447) (a := t1) (u := t1) (v := t1) pv3447 (aw (ri t1)) (refl t1)
theorem pv3444 : R t3444 t1 := result (f := t3442) (a := t1) (u := t3442) (v := t3448) (refl t3442) (awb t3220 t1 t1 t1 (cI)) pv3448
theorem pv3445 : R t3445 t1 := result (f := t3227) (a := t3444) (u := t1) (v := t3444) pv3227 (aw (ri t3444)) pv3444
theorem pv3446 : R t3446 t1 := result (f := t3445) (a := t3213) (u := t1) (v := t3213) pv3445 (aw (ri t3213)) pv3213
theorem pv3443 : R t3443 t1 := result (f := t3220) (a := t3442) (u := t3437) (v := t3446) pv3220 (awb t3227 t3213 t3442 t3444 (refl _)) pv3446
theorem pv3439 : R t3439 t1 := result (f := t3223) (a := t1) (u := t3223) (v := t3443) (refl t3223) (aw (ra t3220 t1)) pv3443
theorem pv3440 : R t3440 t1 := result (f := t3227) (a := t3439) (u := t1) (v := t3439) pv3227 (aw (ri t3439)) pv3439
theorem pv3441 : R t3441 t1 := result (f := t3440) (a := t3213) (u := t1) (v := t3213) pv3440 (aw (ri t3213)) pv3213
theorem pv3224 : R t3224 t1 := result (f := t3220) (a := t3223) (u := t3437) (v := t3441) pv3220 (awb t3227 t3213 t3223 t3439 (refl _)) pv3441
theorem pv3221 : R t3221 t1 := result (f := t0) (a := t3220) (u := t0) (v := t3224) (refl t0) (aw (rh t3220)) pv3224
theorem pv3222 : R t3222 t1 := result (f := t3221) (a := t3213) (u := t1) (v := t3213) pv3221 (aw (ri t3213)) pv3213
theorem pv3219 : R t3219 t1 := result (f := t3216) (a := t3218) (u := t3216) (v := t3222) (refl t3216) (awb t0 t3213 t3218 t3220 (refl _)) pv3222
theorem pv3217 : R t3217 t1 := result (f := t0) (a := t3216) (u := t0) (v := t3219) (refl t0) (aw (rh t3216)) pv3219
theorem pv3214 : R t3214 t1 := result (f := t2) (a := t3213) (u := t2) (v := t3217) (refl t2) (aw (ra t0 t3213)) pv3217
theorem pv3215 : R t3215 t1 := result (f := t3214) (a := t3159) (u := t1) (v := t3159) pv3214 (aw (ri t3159)) pv3159
theorem pv3212 : R t3212 t1 := result (f := t3175) (a := t3211) (u := t3162) (v := t3215) pv3175 (awb t2 t3159 t3211 t3213 (refl _)) pv3215
theorem pv3186 : R t3186 t1 := result (f := t3178) (a := t1) (u := t3178) (v := t3212) (refl t3178) (aw (ra t3175 t1)) pv3212
theorem pv3210 : R t3210 t1 := result (f := t28) (a := t3186) (u := t1) (v := t3186) pv28 (aw (ri t3186)) pv3186
theorem pv3206 : R t3206 t1 := result (f := t3205) (a := t1) (u := t3208) (v := t3210) pv3205 (awb t1 t3186 t1 t1 (cI)) pv3210
theorem pv3200 : R t3200 t1 := result (f := t3198) (a := t1) (u := t3198) (v := t3206) (refl t3198) (awb t3189 t1 t1 t1 (cI)) pv3206
theorem pv3204 : R t3204 t3203 := result (f := t3200) (a := t3203) (u := t1) (v := t3203) pv3200 (aw (ri t3203)) (refl t3203)
theorem pv3201 : R t3201 t3203 := result (f := t0) (a := t3200) (u := t0) (v := t3204) (refl t0) (aw (rh t3200)) pv3204
theorem pv3452 : R t3452 t3451 := result (f := t3200) (a := t3451) (u := t1) (v := t3451) pv3200 (aw (ri t3451)) (refl t3451)
theorem pv3202 : R t3202 t3451 := result (f := t3201) (a := t3186) (u := t3203) (v := t3452) pv3201 (aw (ra t3200 t3186)) pv3452
theorem pv3199 : R t3199 t3451 := result (f := t3189) (a := t3198) (u := t3189) (v := t3202) (refl t3189) (awb t0 t3186 t3198 t3200 (refl _)) pv3202
theorem pv3193 : R t3193 t3451 := result (f := t3191) (a := t1) (u := t3191) (v := t3199) (refl t3191) (aw (ra t3189 t1)) pv3199
theorem pv3463 : R t3463 t1 := result (f := t3200) (a := t1) (u := t1) (v := t1) pv3200 (aw (ri t1)) (refl t1)
theorem pv3464 : R t3464 t1 := result (f := t3463) (a := t3186) (u := t1) (v := t3186) pv3463 (aw (ri t3186)) pv3186
theorem pv3461 : R t3461 t1 := result (f := t3193) (a := t1) (u := t3451) (v := t3464) pv3193 (awb t3200 t3186 t1 t1 (cI)) pv3464
theorem pv3462 : R t3462 t1 := result (f := t3461) (a := t1) (u := t1) (v := t1) pv3461 (aw (ri t1)) (refl t1)
theorem pv3458 : R t3458 t1 := result (f := t3456) (a := t1) (u := t3456) (v := t3462) (refl t3456) (awb t3193 t1 t1 t1 (cI)) pv3462
theorem pv3459 : R t3459 t1 := result (f := t3200) (a := t3458) (u := t1) (v := t3458) pv3200 (aw (ri t3458)) pv3458
theorem pv3460 : R t3460 t1 := result (f := t3459) (a := t3186) (u := t1) (v := t3186) pv3459 (aw (ri t3186)) pv3186
theorem pv3457 : R t3457 t1 := result (f := t3193) (a := t3456) (u := t3451) (v := t3460) pv3193 (awb t3200 t3186 t3456 t3458 (refl _)) pv3460
theorem pv3453 : R t3453 t1 := result (f := t3196) (a := t1) (u := t3196) (v := t3457) (refl t3196) (aw (ra t3193 t1)) pv3457
theorem pv3454 : R t3454 t1 := result (f := t3200) (a := t3453) (u := t1) (v := t3453) pv3200 (aw (ri t3453)) pv3453
theorem pv3455 : R t3455 t1 := result (f := t3454) (a := t3186) (u := t1) (v := t3186) pv3454 (aw (ri t3186)) pv3186
theorem pv3197 : R t3197 t1 := result (f := t3193) (a := t3196) (u := t3451) (v := t3455) pv3193 (awb t3200 t3186 t3196 t3453 (refl _)) pv3455
theorem pv3194 : R t3194 t1 := result (f := t0) (a := t3193) (u := t0) (v := t3197) (refl t0) (aw (rh t3193)) pv3197
theorem pv3195 : R t3195 t1 := result (f := t3194) (a := t3186) (u := t1) (v := t3186) pv3194 (aw (ri t3186)) pv3186
theorem pv3192 : R t3192 t1 := result (f := t3189) (a := t3191) (u := t3189) (v := t3195) (refl t3189) (awb t0 t3186 t3191 t3193 (refl _)) pv3195
theorem pv3190 : R t3190 t1 := result (f := t0) (a := t3189) (u := t0) (v := t3192) (refl t0) (aw (rh t3189)) pv3192
theorem pv3187 : R t3187 t1 := result (f := t2) (a := t3186) (u := t2) (v := t3190) (refl t2) (aw (ra t0 t3186)) pv3190
theorem pv3188 : R t3188 t1 := result (f := t3187) (a := t3159) (u := t1) (v := t3159) pv3187 (aw (ri t3159)) pv3159
theorem pv3179 : R t3179 t1 := result (f := t3175) (a := t3178) (u := t3162) (v := t3188) pv3175 (awb t2 t3159 t3178 t3186 (refl _)) pv3188
end Blc.H44.Pump
