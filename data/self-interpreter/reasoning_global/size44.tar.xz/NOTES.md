# Size 44

All 188,768 wires are covered. The 179,166 finite predicates, 9,602 literal negations and all 75 helper identities are indexed in the regenerated ledger and tables. The shorter public functions have 37-bit encodings and the three selected direct proofs invoke Lean's 38-bit floor.

The slim archive regenerates 8,449 files. Its replay compiles 8,852 local modules in fresh objects, with isolated retries for guarded modules. The unpacked check writes its actual timings, peak child RSS and transitive axiom audit outcome to check-metrics.json. REPORT-44.md gives the classification and evidence boundaries.
