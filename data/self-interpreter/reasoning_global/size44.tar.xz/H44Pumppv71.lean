import H44Pumppv70
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5140 : R t5140 t1 := result (f := t5139) (a := t5068) (u := t1) (v := t5068) pv5139 (aw (ri t5068)) pv5068
theorem pv5079 : R t5079 t1 := result (f := t5075) (a := t5078) (u := t5136) (v := t5140) pv5075 (awb t5082 t5068 t5078 t5138 (refl _)) pv5140
theorem pv5076 : R t5076 t1 := result (f := t0) (a := t5075) (u := t0) (v := t5079) (refl t0) (aw (rh t5075)) pv5079
theorem pv5077 : R t5077 t1 := result (f := t5076) (a := t5068) (u := t1) (v := t5068) pv5076 (aw (ri t5068)) pv5068
theorem pv5074 : R t5074 t1 := result (f := t5071) (a := t5073) (u := t5071) (v := t5077) (refl t5071) (awb t0 t5068 t5073 t5075 (refl _)) pv5077
theorem pv5072 : R t5072 t1 := result (f := t0) (a := t5071) (u := t0) (v := t5074) (refl t0) (aw (rh t5071)) pv5074
theorem pv5069 : R t5069 t1 := result (f := t2) (a := t5068) (u := t2) (v := t5072) (refl t2) (aw (ra t0 t5068)) pv5072
theorem pv5070 : R t5070 t1 := result (f := t5069) (a := t4956) (u := t1) (v := t4956) pv5069 (aw (ri t4956)) pv4956
theorem pv4969 : R t4969 t1 := result (f := t4965) (a := t4968) (u := t4959) (v := t5070) pv4965 (awb t2 t4956 t4968 t5068 (refl _)) pv5070
theorem pv4966 : R t4966 t1 := result (f := t0) (a := t4965) (u := t0) (v := t4969) (refl t0) (aw (rh t4965)) pv4969
theorem pv4967 : R t4967 t4959 := result (f := t4966) (a := t4959) (u := t1) (v := t4959) pv4966 (aw (ri t4959)) (refl t4959)
theorem pv4964 : R t4964 t4959 := result (f := t4961) (a := t4963) (u := t4961) (v := t4967) (refl t4961) (awb t0 t4959 t4963 t4965 (refl _)) pv4967
theorem pv4962 : R t4962 t4959 := result (f := t0) (a := t4961) (u := t0) (v := t4964) (refl t0) (aw (rh t4961)) pv4964
theorem pv4960 : R t4960 t4959 := result (f := t2) (a := t4959) (u := t2) (v := t4962) (refl t2) (aw (ra t0 t4959)) pv4962
theorem pv4957 : R t4957 t4959 := result (f := t59) (a := t4956) (u := t46) (v := t4960) pv59 (aw (ra t2 t4956)) pv4960
theorem pv4958 : R t4958 t1 := result (f := t4957) (a := t1) (u := t4959) (v := t5037) pv4957 (awb t2 t4956 t1 t1 (cI)) pv5037
theorem pv4955 : R t4955 t1 := result (f := t4818) (a := t4954) (u := t149) (v := t4958) pv4818 (awb t59 t1 t4954 t4956 (refl _)) pv4958
theorem pv4872 : R t4872 t1 := result (f := t4821) (a := t1) (u := t4821) (v := t4955) (refl t4821) (aw (ra t4818 t1)) pv4955
theorem pv4953 : R t4953 t1 := result (f := t3) (a := t4872) (u := t1) (v := t4872) pv3 (aw (ri t4872)) pv4872
theorem pv4951 : R t4951 t1 := result (f := t4888) (a := t1) (u := t4875) (v := t4953) pv4888 (awb t2 t4872 t1 t1 (cI)) pv4953
theorem pv4952 : R t4952 t1 := result (f := t4951) (a := t1) (u := t1) (v := t1) pv4951 (aw (ri t1)) (refl t1)
theorem pv4926 : R t4926 t1 := result (f := t4924) (a := t1) (u := t4924) (v := t4952) (refl t4924) (awb t4888 t1 t1 t1 (cI)) pv4952
theorem pv4950 : R t4950 t1 := result (f := t28) (a := t4926) (u := t1) (v := t4926) pv28 (aw (ri t4926)) pv4926
theorem pv4946 : R t4946 t1 := result (f := t4945) (a := t1) (u := t4948) (v := t4950) pv4945 (awb t1 t4926 t1 t1 (cI)) pv4950
theorem pv4940 : R t4940 t1 := result (f := t4938) (a := t1) (u := t4938) (v := t4946) (refl t4938) (awb t4929 t1 t1 t1 (cI)) pv4946
theorem pv4944 : R t4944 t4943 := result (f := t4940) (a := t4943) (u := t1) (v := t4943) pv4940 (aw (ri t4943)) (refl t4943)
theorem pv4941 : R t4941 t4943 := result (f := t0) (a := t4940) (u := t0) (v := t4944) (refl t0) (aw (rh t4940)) pv4944
theorem pv5151 : R t5151 t5150 := result (f := t4940) (a := t5150) (u := t1) (v := t5150) pv4940 (aw (ri t5150)) (refl t5150)
theorem pv4942 : R t4942 t5150 := result (f := t4941) (a := t4926) (u := t4943) (v := t5151) pv4941 (aw (ra t4940 t4926)) pv5151
theorem pv4939 : R t4939 t5150 := result (f := t4929) (a := t4938) (u := t4929) (v := t4942) (refl t4929) (awb t0 t4926 t4938 t4940 (refl _)) pv4942
theorem pv4933 : R t4933 t5150 := result (f := t4931) (a := t1) (u := t4931) (v := t4939) (refl t4931) (aw (ra t4929 t1)) pv4939
theorem pv5162 : R t5162 t1 := result (f := t4940) (a := t1) (u := t1) (v := t1) pv4940 (aw (ri t1)) (refl t1)
theorem pv5163 : R t5163 t1 := result (f := t5162) (a := t4926) (u := t1) (v := t4926) pv5162 (aw (ri t4926)) pv4926
theorem pv5160 : R t5160 t1 := result (f := t4933) (a := t1) (u := t5150) (v := t5163) pv4933 (awb t4940 t4926 t1 t1 (cI)) pv5163
theorem pv5161 : R t5161 t1 := result (f := t5160) (a := t1) (u := t1) (v := t1) pv5160 (aw (ri t1)) (refl t1)
theorem pv5157 : R t5157 t1 := result (f := t5155) (a := t1) (u := t5155) (v := t5161) (refl t5155) (awb t4933 t1 t1 t1 (cI)) pv5161
theorem pv5158 : R t5158 t1 := result (f := t4940) (a := t5157) (u := t1) (v := t5157) pv4940 (aw (ri t5157)) pv5157
theorem pv5159 : R t5159 t1 := result (f := t5158) (a := t4926) (u := t1) (v := t4926) pv5158 (aw (ri t4926)) pv4926
theorem pv5156 : R t5156 t1 := result (f := t4933) (a := t5155) (u := t5150) (v := t5159) pv4933 (awb t4940 t4926 t5155 t5157 (refl _)) pv5159
theorem pv5152 : R t5152 t1 := result (f := t4936) (a := t1) (u := t4936) (v := t5156) (refl t4936) (aw (ra t4933 t1)) pv5156
theorem pv5153 : R t5153 t1 := result (f := t4940) (a := t5152) (u := t1) (v := t5152) pv4940 (aw (ri t5152)) pv5152
theorem pv5154 : R t5154 t1 := result (f := t5153) (a := t4926) (u := t1) (v := t4926) pv5153 (aw (ri t4926)) pv4926
theorem pv4937 : R t4937 t1 := result (f := t4933) (a := t4936) (u := t5150) (v := t5154) pv4933 (awb t4940 t4926 t4936 t5152 (refl _)) pv5154
theorem pv4934 : R t4934 t1 := result (f := t0) (a := t4933) (u := t0) (v := t4937) (refl t0) (aw (rh t4933)) pv4937
theorem pv4935 : R t4935 t1 := result (f := t4934) (a := t4926) (u := t1) (v := t4926) pv4934 (aw (ri t4926)) pv4926
theorem pv4932 : R t4932 t1 := result (f := t4929) (a := t4931) (u := t4929) (v := t4935) (refl t4929) (awb t0 t4926 t4931 t4933 (refl _)) pv4935
theorem pv4930 : R t4930 t1 := result (f := t0) (a := t4929) (u := t0) (v := t4932) (refl t0) (aw (rh t4929)) pv4932
theorem pv4927 : R t4927 t1 := result (f := t2) (a := t4926) (u := t2) (v := t4930) (refl t2) (aw (ra t0 t4926)) pv4930
theorem pv4928 : R t4928 t1 := result (f := t4927) (a := t4872) (u := t1) (v := t4872) pv4927 (aw (ri t4872)) pv4872
theorem pv4925 : R t4925 t1 := result (f := t4888) (a := t4924) (u := t4875) (v := t4928) pv4888 (awb t2 t4872 t4924 t4926 (refl _)) pv4928
theorem pv4899 : R t4899 t1 := result (f := t4891) (a := t1) (u := t4891) (v := t4925) (refl t4891) (aw (ra t4888 t1)) pv4925
theorem pv4923 : R t4923 t1 := result (f := t28) (a := t4899) (u := t1) (v := t4899) pv28 (aw (ri t4899)) pv4899
theorem pv4919 : R t4919 t1 := result (f := t4918) (a := t1) (u := t4921) (v := t4923) pv4918 (awb t1 t4899 t1 t1 (cI)) pv4923
theorem pv4913 : R t4913 t1 := result (f := t4911) (a := t1) (u := t4911) (v := t4919) (refl t4911) (awb t4902 t1 t1 t1 (cI)) pv4919
theorem pv4917 : R t4917 t4916 := result (f := t4913) (a := t4916) (u := t1) (v := t4916) pv4913 (aw (ri t4916)) (refl t4916)
end Blc.H44.Pump
