import H44Pumppv133
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv9512 : R t9512 t1 := result (f := t9510) (a := t1) (u := t9510) (v := t9516) (refl t9510) (awb t9288 t1 t1 t1 (cI)) pv9516
theorem pv9513 : R t9513 t1 := result (f := t9295) (a := t9512) (u := t1) (v := t9512) pv9295 (aw (ri t9512)) pv9512
theorem pv9514 : R t9514 t1 := result (f := t9513) (a := t9281) (u := t1) (v := t9281) pv9513 (aw (ri t9281)) pv9281
theorem pv9511 : R t9511 t1 := result (f := t9288) (a := t9510) (u := t9505) (v := t9514) pv9288 (awb t9295 t9281 t9510 t9512 (refl _)) pv9514
theorem pv9507 : R t9507 t1 := result (f := t9291) (a := t1) (u := t9291) (v := t9511) (refl t9291) (aw (ra t9288 t1)) pv9511
theorem pv9508 : R t9508 t1 := result (f := t9295) (a := t9507) (u := t1) (v := t9507) pv9295 (aw (ri t9507)) pv9507
theorem pv9509 : R t9509 t1 := result (f := t9508) (a := t9281) (u := t1) (v := t9281) pv9508 (aw (ri t9281)) pv9281
theorem pv9292 : R t9292 t1 := result (f := t9288) (a := t9291) (u := t9505) (v := t9509) pv9288 (awb t9295 t9281 t9291 t9507 (refl _)) pv9509
theorem pv9289 : R t9289 t1 := result (f := t0) (a := t9288) (u := t0) (v := t9292) (refl t0) (aw (rh t9288)) pv9292
theorem pv9290 : R t9290 t1 := result (f := t9289) (a := t9281) (u := t1) (v := t9281) pv9289 (aw (ri t9281)) pv9281
theorem pv9287 : R t9287 t1 := result (f := t9284) (a := t9286) (u := t9284) (v := t9290) (refl t9284) (awb t0 t9281 t9286 t9288 (refl _)) pv9290
theorem pv9285 : R t9285 t1 := result (f := t0) (a := t9284) (u := t0) (v := t9287) (refl t0) (aw (rh t9284)) pv9287
theorem pv9282 : R t9282 t1 := result (f := t2) (a := t9281) (u := t2) (v := t9285) (refl t2) (aw (ra t0 t9281)) pv9285
theorem pv9283 : R t9283 t1 := result (f := t9282) (a := t9227) (u := t1) (v := t9227) pv9282 (aw (ri t9227)) pv9227
theorem pv9280 : R t9280 t1 := result (f := t9243) (a := t9279) (u := t9230) (v := t9283) pv9243 (awb t2 t9227 t9279 t9281 (refl _)) pv9283
theorem pv9254 : R t9254 t1 := result (f := t9246) (a := t1) (u := t9246) (v := t9280) (refl t9246) (aw (ra t9243 t1)) pv9280
theorem pv9278 : R t9278 t1 := result (f := t28) (a := t9254) (u := t1) (v := t9254) pv28 (aw (ri t9254)) pv9254
theorem pv9274 : R t9274 t1 := result (f := t9273) (a := t1) (u := t9276) (v := t9278) pv9273 (awb t1 t9254 t1 t1 (cI)) pv9278
theorem pv9268 : R t9268 t1 := result (f := t9266) (a := t1) (u := t9266) (v := t9274) (refl t9266) (awb t9257 t1 t1 t1 (cI)) pv9274
theorem pv9272 : R t9272 t9271 := result (f := t9268) (a := t9271) (u := t1) (v := t9271) pv9268 (aw (ri t9271)) (refl t9271)
theorem pv9269 : R t9269 t9271 := result (f := t0) (a := t9268) (u := t0) (v := t9272) (refl t0) (aw (rh t9268)) pv9272
theorem pv9520 : R t9520 t9519 := result (f := t9268) (a := t9519) (u := t1) (v := t9519) pv9268 (aw (ri t9519)) (refl t9519)
theorem pv9270 : R t9270 t9519 := result (f := t9269) (a := t9254) (u := t9271) (v := t9520) pv9269 (aw (ra t9268 t9254)) pv9520
theorem pv9267 : R t9267 t9519 := result (f := t9257) (a := t9266) (u := t9257) (v := t9270) (refl t9257) (awb t0 t9254 t9266 t9268 (refl _)) pv9270
theorem pv9261 : R t9261 t9519 := result (f := t9259) (a := t1) (u := t9259) (v := t9267) (refl t9259) (aw (ra t9257 t1)) pv9267
theorem pv9531 : R t9531 t1 := result (f := t9268) (a := t1) (u := t1) (v := t1) pv9268 (aw (ri t1)) (refl t1)
theorem pv9532 : R t9532 t1 := result (f := t9531) (a := t9254) (u := t1) (v := t9254) pv9531 (aw (ri t9254)) pv9254
theorem pv9529 : R t9529 t1 := result (f := t9261) (a := t1) (u := t9519) (v := t9532) pv9261 (awb t9268 t9254 t1 t1 (cI)) pv9532
theorem pv9530 : R t9530 t1 := result (f := t9529) (a := t1) (u := t1) (v := t1) pv9529 (aw (ri t1)) (refl t1)
theorem pv9526 : R t9526 t1 := result (f := t9524) (a := t1) (u := t9524) (v := t9530) (refl t9524) (awb t9261 t1 t1 t1 (cI)) pv9530
theorem pv9527 : R t9527 t1 := result (f := t9268) (a := t9526) (u := t1) (v := t9526) pv9268 (aw (ri t9526)) pv9526
theorem pv9528 : R t9528 t1 := result (f := t9527) (a := t9254) (u := t1) (v := t9254) pv9527 (aw (ri t9254)) pv9254
theorem pv9525 : R t9525 t1 := result (f := t9261) (a := t9524) (u := t9519) (v := t9528) pv9261 (awb t9268 t9254 t9524 t9526 (refl _)) pv9528
theorem pv9521 : R t9521 t1 := result (f := t9264) (a := t1) (u := t9264) (v := t9525) (refl t9264) (aw (ra t9261 t1)) pv9525
theorem pv9522 : R t9522 t1 := result (f := t9268) (a := t9521) (u := t1) (v := t9521) pv9268 (aw (ri t9521)) pv9521
theorem pv9523 : R t9523 t1 := result (f := t9522) (a := t9254) (u := t1) (v := t9254) pv9522 (aw (ri t9254)) pv9254
theorem pv9265 : R t9265 t1 := result (f := t9261) (a := t9264) (u := t9519) (v := t9523) pv9261 (awb t9268 t9254 t9264 t9521 (refl _)) pv9523
theorem pv9262 : R t9262 t1 := result (f := t0) (a := t9261) (u := t0) (v := t9265) (refl t0) (aw (rh t9261)) pv9265
theorem pv9263 : R t9263 t1 := result (f := t9262) (a := t9254) (u := t1) (v := t9254) pv9262 (aw (ri t9254)) pv9254
theorem pv9260 : R t9260 t1 := result (f := t9257) (a := t9259) (u := t9257) (v := t9263) (refl t9257) (awb t0 t9254 t9259 t9261 (refl _)) pv9263
theorem pv9258 : R t9258 t1 := result (f := t0) (a := t9257) (u := t0) (v := t9260) (refl t0) (aw (rh t9257)) pv9260
theorem pv9255 : R t9255 t1 := result (f := t2) (a := t9254) (u := t2) (v := t9258) (refl t2) (aw (ra t0 t9254)) pv9258
theorem pv9256 : R t9256 t1 := result (f := t9255) (a := t9227) (u := t1) (v := t9227) pv9255 (aw (ri t9227)) pv9227
theorem pv9247 : R t9247 t1 := result (f := t9243) (a := t9246) (u := t9230) (v := t9256) pv9243 (awb t2 t9227 t9246 t9254 (refl _)) pv9256
theorem pv9244 : R t9244 t1 := result (f := t0) (a := t9243) (u := t0) (v := t9247) (refl t0) (aw (rh t9243)) pv9247
theorem pv9245 : R t9245 t9230 := result (f := t9244) (a := t9230) (u := t1) (v := t9230) pv9244 (aw (ri t9230)) (refl t9230)
theorem pv9242 : R t9242 t9230 := result (f := t9232) (a := t9241) (u := t9232) (v := t9245) (refl t9232) (awb t0 t9230 t9241 t9243 (refl _)) pv9245
theorem pv9236 : R t9236 t9230 := result (f := t9234) (a := t1) (u := t9234) (v := t9242) (refl t9234) (aw (ra t9232 t1)) pv9242
theorem pv9556 : R t9556 t9555 := result (f := t1) (a := t9555) (u := t1) (v := t9555) (refl t1) (aw (ri t9555)) (refl t9555)
theorem pv9554 : R t9554 t9555 := result (f := t22) (a := t9533) (u := t24) (v := t9556) pv22 (aw (ra t1 t9533)) pv9556
theorem pv9552 : R t9552 t9555 := result (f := t9536) (a := t1) (u := t9536) (v := t9554) (refl t9536) (awb t0 t9533 t1 t1 (cI)) pv9554
theorem pv9583 : R t9583 t9582 := result (f := t1) (a := t9582) (u := t1) (v := t9582) (refl t1) (aw (ri t9582)) (refl t9582)
theorem pv9581 : R t9581 t9582 := result (f := t22) (a := t9560) (u := t24) (v := t9583) pv22 (aw (ra t1 t9560)) pv9583
theorem pv9579 : R t9579 t9582 := result (f := t9563) (a := t1) (u := t9563) (v := t9581) (refl t9563) (awb t0 t9560 t1 t1 (cI)) pv9581
theorem pv9585 : R t9585 t1 := result (f := t9236) (a := t1) (u := t9230) (v := t9308) pv9236 (awb t2 t9227 t1 t1 (cI)) pv9308
end Blc.H44.Pump
