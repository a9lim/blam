import H44Pumppv124
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv8949 : R t8949 t8926 := result (f := t28) (a := t8926) (u := t1) (v := t8926) pv28 (aw (ri t8926)) (refl t8926)
theorem pv8945 : R t8945 t8926 := result (f := t8944) (a := t1) (u := t8947) (v := t8949) pv8944 (awb t1 t8926 t1 t1 (cI)) pv8949
theorem pv8939 : R t8939 t8926 := result (f := t8937) (a := t1) (u := t8937) (v := t8945) (refl t8937) (awb t8928 t1 t1 t1 (cI)) pv8945
theorem pv8973 : R t8973 t8972 := result (f := t1) (a := t8972) (u := t1) (v := t8972) (refl t1) (aw (ri t8972)) (refl t8972)
theorem pv8971 : R t8971 t8972 := result (f := t22) (a := t8950) (u := t24) (v := t8973) pv22 (aw (ra t1 t8950)) pv8973
theorem pv8969 : R t8969 t8972 := result (f := t8953) (a := t1) (u := t8953) (v := t8971) (refl t8953) (awb t0 t8950 t1 t1 (cI)) pv8971
theorem pv9000 : R t9000 t8999 := result (f := t1) (a := t8999) (u := t1) (v := t8999) (refl t1) (aw (ri t8999)) (refl t8999)
theorem pv8998 : R t8998 t8999 := result (f := t22) (a := t8977) (u := t24) (v := t9000) pv22 (aw (ra t1 t8977)) pv9000
theorem pv8996 : R t8996 t8999 := result (f := t8980) (a := t1) (u := t8980) (v := t8998) (refl t8980) (awb t0 t8977 t1 t1 (cI)) pv8998
theorem pv9005 : R t9005 t1 := result (f := t8390) (a := t1) (u := t149) (v := t231) pv8390 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv9006 : R t9006 t1 := result (f := t9005) (a := t1) (u := t1) (v := t1) pv9005 (aw (ri t1)) (refl t1)
theorem pv8923 : R t8923 t1 := result (f := t8921) (a := t1) (u := t8921) (v := t9006) (refl t8921) (awb t8390 t1 t1 t1 (cI)) pv9006
theorem pv9004 : R t9004 t1 := result (f := t3) (a := t8923) (u := t1) (v := t8923) pv3 (aw (ri t8923)) pv8923
theorem pv9002 : R t9002 t1 := result (f := t8939) (a := t1) (u := t8926) (v := t9004) pv8939 (awb t2 t8923 t1 t1 (cI)) pv9004
theorem pv9003 : R t9003 t1 := result (f := t9002) (a := t1) (u := t1) (v := t1) pv9002 (aw (ri t1)) (refl t1)
theorem pv8977 : R t8977 t1 := result (f := t8975) (a := t1) (u := t8975) (v := t9003) (refl t8975) (awb t8939 t1 t1 t1 (cI)) pv9003
theorem pv9001 : R t9001 t1 := result (f := t28) (a := t8977) (u := t1) (v := t8977) pv28 (aw (ri t8977)) pv8977
theorem pv8997 : R t8997 t1 := result (f := t8996) (a := t1) (u := t8999) (v := t9001) pv8996 (awb t1 t8977 t1 t1 (cI)) pv9001
theorem pv8991 : R t8991 t1 := result (f := t8989) (a := t1) (u := t8989) (v := t8997) (refl t8989) (awb t8980 t1 t1 t1 (cI)) pv8997
theorem pv8995 : R t8995 t8994 := result (f := t8991) (a := t8994) (u := t1) (v := t8994) pv8991 (aw (ri t8994)) (refl t8994)
theorem pv8992 : R t8992 t8994 := result (f := t0) (a := t8991) (u := t0) (v := t8995) (refl t0) (aw (rh t8991)) pv8995
theorem pv9008 : R t9008 t9007 := result (f := t8991) (a := t9007) (u := t1) (v := t9007) pv8991 (aw (ri t9007)) (refl t9007)
theorem pv8993 : R t8993 t9007 := result (f := t8992) (a := t8977) (u := t8994) (v := t9008) pv8992 (aw (ra t8991 t8977)) pv9008
theorem pv8990 : R t8990 t9007 := result (f := t8980) (a := t8989) (u := t8980) (v := t8993) (refl t8980) (awb t0 t8977 t8989 t8991 (refl _)) pv8993
theorem pv8984 : R t8984 t9007 := result (f := t8982) (a := t1) (u := t8982) (v := t8990) (refl t8982) (aw (ra t8980 t1)) pv8990
theorem pv9019 : R t9019 t1 := result (f := t8991) (a := t1) (u := t1) (v := t1) pv8991 (aw (ri t1)) (refl t1)
theorem pv9020 : R t9020 t1 := result (f := t9019) (a := t8977) (u := t1) (v := t8977) pv9019 (aw (ri t8977)) pv8977
theorem pv9017 : R t9017 t1 := result (f := t8984) (a := t1) (u := t9007) (v := t9020) pv8984 (awb t8991 t8977 t1 t1 (cI)) pv9020
theorem pv9018 : R t9018 t1 := result (f := t9017) (a := t1) (u := t1) (v := t1) pv9017 (aw (ri t1)) (refl t1)
theorem pv9014 : R t9014 t1 := result (f := t9012) (a := t1) (u := t9012) (v := t9018) (refl t9012) (awb t8984 t1 t1 t1 (cI)) pv9018
theorem pv9015 : R t9015 t1 := result (f := t8991) (a := t9014) (u := t1) (v := t9014) pv8991 (aw (ri t9014)) pv9014
theorem pv9016 : R t9016 t1 := result (f := t9015) (a := t8977) (u := t1) (v := t8977) pv9015 (aw (ri t8977)) pv8977
theorem pv9013 : R t9013 t1 := result (f := t8984) (a := t9012) (u := t9007) (v := t9016) pv8984 (awb t8991 t8977 t9012 t9014 (refl _)) pv9016
theorem pv9009 : R t9009 t1 := result (f := t8987) (a := t1) (u := t8987) (v := t9013) (refl t8987) (aw (ra t8984 t1)) pv9013
theorem pv9010 : R t9010 t1 := result (f := t8991) (a := t9009) (u := t1) (v := t9009) pv8991 (aw (ri t9009)) pv9009
theorem pv9011 : R t9011 t1 := result (f := t9010) (a := t8977) (u := t1) (v := t8977) pv9010 (aw (ri t8977)) pv8977
theorem pv8988 : R t8988 t1 := result (f := t8984) (a := t8987) (u := t9007) (v := t9011) pv8984 (awb t8991 t8977 t8987 t9009 (refl _)) pv9011
theorem pv8985 : R t8985 t1 := result (f := t0) (a := t8984) (u := t0) (v := t8988) (refl t0) (aw (rh t8984)) pv8988
theorem pv8986 : R t8986 t1 := result (f := t8985) (a := t8977) (u := t1) (v := t8977) pv8985 (aw (ri t8977)) pv8977
theorem pv8983 : R t8983 t1 := result (f := t8980) (a := t8982) (u := t8980) (v := t8986) (refl t8980) (awb t0 t8977 t8982 t8984 (refl _)) pv8986
theorem pv8981 : R t8981 t1 := result (f := t0) (a := t8980) (u := t0) (v := t8983) (refl t0) (aw (rh t8980)) pv8983
theorem pv8978 : R t8978 t1 := result (f := t2) (a := t8977) (u := t2) (v := t8981) (refl t2) (aw (ra t0 t8977)) pv8981
theorem pv8979 : R t8979 t1 := result (f := t8978) (a := t8923) (u := t1) (v := t8923) pv8978 (aw (ri t8923)) pv8923
theorem pv8976 : R t8976 t1 := result (f := t8939) (a := t8975) (u := t8926) (v := t8979) pv8939 (awb t2 t8923 t8975 t8977 (refl _)) pv8979
theorem pv8950 : R t8950 t1 := result (f := t8942) (a := t1) (u := t8942) (v := t8976) (refl t8942) (aw (ra t8939 t1)) pv8976
theorem pv8974 : R t8974 t1 := result (f := t28) (a := t8950) (u := t1) (v := t8950) pv28 (aw (ri t8950)) pv8950
theorem pv8970 : R t8970 t1 := result (f := t8969) (a := t1) (u := t8972) (v := t8974) pv8969 (awb t1 t8950 t1 t1 (cI)) pv8974
theorem pv8964 : R t8964 t1 := result (f := t8962) (a := t1) (u := t8962) (v := t8970) (refl t8962) (awb t8953 t1 t1 t1 (cI)) pv8970
theorem pv8968 : R t8968 t8967 := result (f := t8964) (a := t8967) (u := t1) (v := t8967) pv8964 (aw (ri t8967)) (refl t8967)
theorem pv8965 : R t8965 t8967 := result (f := t0) (a := t8964) (u := t0) (v := t8968) (refl t0) (aw (rh t8964)) pv8968
theorem pv9022 : R t9022 t9021 := result (f := t8964) (a := t9021) (u := t1) (v := t9021) pv8964 (aw (ri t9021)) (refl t9021)
theorem pv8966 : R t8966 t9021 := result (f := t8965) (a := t8950) (u := t8967) (v := t9022) pv8965 (aw (ra t8964 t8950)) pv9022
theorem pv8963 : R t8963 t9021 := result (f := t8953) (a := t8962) (u := t8953) (v := t8966) (refl t8953) (awb t0 t8950 t8962 t8964 (refl _)) pv8966
theorem pv8957 : R t8957 t9021 := result (f := t8955) (a := t1) (u := t8955) (v := t8963) (refl t8955) (aw (ra t8953 t1)) pv8963
theorem pv9033 : R t9033 t1 := result (f := t8964) (a := t1) (u := t1) (v := t1) pv8964 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
