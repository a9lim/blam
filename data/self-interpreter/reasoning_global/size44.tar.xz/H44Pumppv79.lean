import H44Pumppv78
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5646 : R t5646 t1 := result (f := t5580) (a := t1) (u := t1) (v := t1) pv5580 (aw (ri t1)) (refl t1)
theorem pv5647 : R t5647 t1 := result (f := t5646) (a := t5566) (u := t1) (v := t5566) pv5646 (aw (ri t5566)) pv5566
theorem pv5644 : R t5644 t1 := result (f := t5573) (a := t1) (u := t5634) (v := t5647) pv5573 (awb t5580 t5566 t1 t1 (cI)) pv5647
theorem pv5645 : R t5645 t1 := result (f := t5644) (a := t1) (u := t1) (v := t1) pv5644 (aw (ri t1)) (refl t1)
theorem pv5641 : R t5641 t1 := result (f := t5639) (a := t1) (u := t5639) (v := t5645) (refl t5639) (awb t5573 t1 t1 t1 (cI)) pv5645
theorem pv5642 : R t5642 t1 := result (f := t5580) (a := t5641) (u := t1) (v := t5641) pv5580 (aw (ri t5641)) pv5641
theorem pv5643 : R t5643 t1 := result (f := t5642) (a := t5566) (u := t1) (v := t5566) pv5642 (aw (ri t5566)) pv5566
theorem pv5640 : R t5640 t1 := result (f := t5573) (a := t5639) (u := t5634) (v := t5643) pv5573 (awb t5580 t5566 t5639 t5641 (refl _)) pv5643
theorem pv5636 : R t5636 t1 := result (f := t5576) (a := t1) (u := t5576) (v := t5640) (refl t5576) (aw (ra t5573 t1)) pv5640
theorem pv5637 : R t5637 t1 := result (f := t5580) (a := t5636) (u := t1) (v := t5636) pv5580 (aw (ri t5636)) pv5636
theorem pv5638 : R t5638 t1 := result (f := t5637) (a := t5566) (u := t1) (v := t5566) pv5637 (aw (ri t5566)) pv5566
theorem pv5577 : R t5577 t1 := result (f := t5573) (a := t5576) (u := t5634) (v := t5638) pv5573 (awb t5580 t5566 t5576 t5636 (refl _)) pv5638
theorem pv5574 : R t5574 t1 := result (f := t0) (a := t5573) (u := t0) (v := t5577) (refl t0) (aw (rh t5573)) pv5577
theorem pv5575 : R t5575 t1 := result (f := t5574) (a := t5566) (u := t1) (v := t5566) pv5574 (aw (ri t5566)) pv5566
theorem pv5572 : R t5572 t1 := result (f := t5569) (a := t5571) (u := t5569) (v := t5575) (refl t5569) (awb t0 t5566 t5571 t5573 (refl _)) pv5575
theorem pv5570 : R t5570 t1 := result (f := t0) (a := t5569) (u := t0) (v := t5572) (refl t0) (aw (rh t5569)) pv5572
theorem pv5567 : R t5567 t1 := result (f := t2) (a := t5566) (u := t2) (v := t5570) (refl t2) (aw (ra t0 t5566)) pv5570
theorem pv5568 : R t5568 t1 := result (f := t5567) (a := t5260) (u := t1) (v := t5260) pv5567 (aw (ri t5260)) pv5260
theorem pv5273 : R t5273 t1 := result (f := t5269) (a := t5272) (u := t5263) (v := t5568) pv5269 (awb t2 t5260 t5272 t5566 (refl _)) pv5568
theorem pv5270 : R t5270 t1 := result (f := t0) (a := t5269) (u := t0) (v := t5273) (refl t0) (aw (rh t5269)) pv5273
theorem pv5271 : R t5271 t5263 := result (f := t5270) (a := t5263) (u := t1) (v := t5263) pv5270 (aw (ri t5263)) (refl t5263)
theorem pv5268 : R t5268 t5263 := result (f := t5265) (a := t5267) (u := t5265) (v := t5271) (refl t5265) (awb t0 t5263 t5267 t5269 (refl _)) pv5271
theorem pv5266 : R t5266 t5263 := result (f := t0) (a := t5265) (u := t0) (v := t5268) (refl t0) (aw (rh t5265)) pv5268
theorem pv5264 : R t5264 t5263 := result (f := t2) (a := t5263) (u := t2) (v := t5266) (refl t2) (aw (ra t0 t5263)) pv5266
theorem pv5261 : R t5261 t5263 := result (f := t59) (a := t5260) (u := t46) (v := t5264) pv59 (aw (ra t2 t5260)) pv5264
theorem pv5262 : R t5262 t1 := result (f := t5261) (a := t1) (u := t5263) (v := t5341) pv5261 (awb t2 t5260 t1 t1 (cI)) pv5341
theorem pv4815 : R t4815 t1 := result (f := t4811) (a := t4814) (u := t149) (v := t5262) pv4811 (awb t59 t1 t4814 t5260 (refl _)) pv5262
theorem pv4812 : R t4812 t1 := result (f := t0) (a := t4811) (u := t0) (v := t4815) (refl t0) (aw (rh t4811)) pv4815
theorem pv4813 : R t4813 t149 := result (f := t4812) (a := t4804) (u := t1) (v := t4804) pv4812 (aw (ri t4804)) pv4804
theorem pv4810 : R t4810 t149 := result (f := t4807) (a := t4809) (u := t4807) (v := t4813) (refl t4807) (awb t0 t4804 t4809 t4811 (refl _)) pv4813
theorem pv4808 : R t4808 t149 := result (f := t0) (a := t4807) (u := t0) (v := t4810) (refl t0) (aw (rh t4807)) pv4810
theorem pv4805 : R t4805 t149 := result (f := t2) (a := t4804) (u := t2) (v := t4808) (refl t2) (aw (ra t0 t4804)) pv4808
theorem pv4806 : R t4806 t1 := result (f := t4805) (a := t149) (u := t149) (v := t1213) pv4805 (awb t59 t1 t149 t1211 (refl _)) pv1213
theorem pv3946 : R t3946 t1 := result (f := t3942) (a := t3945) (u := t151) (v := t4806) pv3942 (awb t2 t149 t3945 t4804 (refl _)) pv4806
theorem pv3943 : R t3943 t1 := result (f := t0) (a := t3942) (u := t0) (v := t3946) (refl t0) (aw (rh t3942)) pv3946
theorem pv3944 : R t3944 t151 := result (f := t3943) (a := t3935) (u := t1) (v := t3935) pv3943 (aw (ri t3935)) pv3935
theorem pv3941 : R t3941 t151 := result (f := t3938) (a := t3940) (u := t3938) (v := t3944) (refl t3938) (awb t0 t3935 t3940 t3942 (refl _)) pv3944
theorem pv3939 : R t3939 t151 := result (f := t0) (a := t3938) (u := t0) (v := t3941) (refl t0) (aw (rh t3938)) pv3941
theorem pv3936 : R t3936 t151 := result (f := t2) (a := t3935) (u := t2) (v := t3939) (refl t2) (aw (ra t0 t3935)) pv3939
theorem pv5670 : R t5670 t5669 := result (f := t1) (a := t5669) (u := t1) (v := t5669) (refl t1) (aw (ri t5669)) (refl t5669)
theorem pv5668 : R t5668 t5669 := result (f := t22) (a := t1211) (u := t24) (v := t5670) pv22 (aw (ra t1 t1211)) pv5670
theorem pv5666 : R t5666 t5669 := result (f := t5650) (a := t1) (u := t5650) (v := t5668) (refl t5650) (awb t0 t1211 t1 t1 (cI)) pv5668
theorem pv5671 : R t5671 t1 := result (f := t28) (a := t1211) (u := t1) (v := t1211) pv28 (aw (ri t1211)) pv1211
theorem pv5667 : R t5667 t1 := result (f := t5666) (a := t1) (u := t5669) (v := t5671) pv5666 (awb t1 t1211 t1 t1 (cI)) pv5671
theorem pv5661 : R t5661 t1 := result (f := t5659) (a := t1) (u := t5659) (v := t5667) (refl t5659) (awb t5650 t1 t1 t1 (cI)) pv5667
theorem pv5665 : R t5665 t5664 := result (f := t5661) (a := t5664) (u := t1) (v := t5664) pv5661 (aw (ri t5664)) (refl t5664)
theorem pv5662 : R t5662 t5664 := result (f := t0) (a := t5661) (u := t0) (v := t5665) (refl t0) (aw (rh t5661)) pv5665
theorem pv5673 : R t5673 t5672 := result (f := t5661) (a := t5672) (u := t1) (v := t5672) pv5661 (aw (ri t5672)) (refl t5672)
theorem pv5663 : R t5663 t5672 := result (f := t5662) (a := t1211) (u := t5664) (v := t5673) pv5662 (aw (ra t5661 t1211)) pv5673
theorem pv5660 : R t5660 t5672 := result (f := t5650) (a := t5659) (u := t5650) (v := t5663) (refl t5650) (awb t0 t1211 t5659 t5661 (refl _)) pv5663
theorem pv5654 : R t5654 t5672 := result (f := t5652) (a := t1) (u := t5652) (v := t5660) (refl t5652) (aw (ra t5650 t1)) pv5660
theorem pv5684 : R t5684 t1 := result (f := t5661) (a := t1) (u := t1) (v := t1) pv5661 (aw (ri t1)) (refl t1)
theorem pv5685 : R t5685 t1 := result (f := t5684) (a := t1211) (u := t1) (v := t1211) pv5684 (aw (ri t1211)) pv1211
theorem pv5682 : R t5682 t1 := result (f := t5654) (a := t1) (u := t5672) (v := t5685) pv5654 (awb t5661 t1211 t1 t1 (cI)) pv5685
theorem pv5683 : R t5683 t1 := result (f := t5682) (a := t1) (u := t1) (v := t1) pv5682 (aw (ri t1)) (refl t1)
end Blc.H44.Pump
