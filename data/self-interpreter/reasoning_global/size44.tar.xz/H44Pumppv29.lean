import H44Pumppv28
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2157 : R t2157 t1 := result (f := t1893) (a := t2156) (u := t2151) (v := t2160) pv1893 (awb t1900 t1886 t2156 t2158 (refl _)) pv2160
theorem pv2153 : R t2153 t1 := result (f := t1896) (a := t1) (u := t1896) (v := t2157) (refl t1896) (aw (ra t1893 t1)) pv2157
theorem pv2154 : R t2154 t1 := result (f := t1900) (a := t2153) (u := t1) (v := t2153) pv1900 (aw (ri t2153)) pv2153
theorem pv2155 : R t2155 t1 := result (f := t2154) (a := t1886) (u := t1) (v := t1886) pv2154 (aw (ri t1886)) pv1886
theorem pv1897 : R t1897 t1 := result (f := t1893) (a := t1896) (u := t2151) (v := t2155) pv1893 (awb t1900 t1886 t1896 t2153 (refl _)) pv2155
theorem pv1894 : R t1894 t1 := result (f := t0) (a := t1893) (u := t0) (v := t1897) (refl t0) (aw (rh t1893)) pv1897
theorem pv1895 : R t1895 t1 := result (f := t1894) (a := t1886) (u := t1) (v := t1886) pv1894 (aw (ri t1886)) pv1886
theorem pv1892 : R t1892 t1 := result (f := t1889) (a := t1891) (u := t1889) (v := t1895) (refl t1889) (awb t0 t1886 t1891 t1893 (refl _)) pv1895
theorem pv1890 : R t1890 t1 := result (f := t0) (a := t1889) (u := t0) (v := t1892) (refl t0) (aw (rh t1889)) pv1892
theorem pv1887 : R t1887 t1 := result (f := t2) (a := t1886) (u := t2) (v := t1890) (refl t2) (aw (ra t0 t1886)) pv1890
theorem pv1888 : R t1888 t1 := result (f := t1887) (a := t1859) (u := t1) (v := t1859) pv1887 (aw (ri t1859)) pv1859
theorem pv1879 : R t1879 t1 := result (f := t1875) (a := t1878) (u := t1862) (v := t1888) pv1875 (awb t2 t1859 t1878 t1886 (refl _)) pv1888
theorem pv1876 : R t1876 t1 := result (f := t0) (a := t1875) (u := t0) (v := t1879) (refl t0) (aw (rh t1875)) pv1879
theorem pv1877 : R t1877 t1862 := result (f := t1876) (a := t1862) (u := t1) (v := t1862) pv1876 (aw (ri t1862)) (refl t1862)
theorem pv1874 : R t1874 t1862 := result (f := t1864) (a := t1873) (u := t1864) (v := t1877) (refl t1864) (awb t0 t1862 t1873 t1875 (refl _)) pv1877
theorem pv1868 : R t1868 t1862 := result (f := t1866) (a := t1) (u := t1866) (v := t1874) (refl t1866) (aw (ra t1864 t1)) pv1874
theorem pv2188 : R t2188 t2187 := result (f := t1) (a := t2187) (u := t1) (v := t2187) (refl t1) (aw (ri t2187)) (refl t2187)
theorem pv2186 : R t2186 t2187 := result (f := t22) (a := t2165) (u := t24) (v := t2188) pv22 (aw (ra t1 t2165)) pv2188
theorem pv2184 : R t2184 t2187 := result (f := t2168) (a := t1) (u := t2168) (v := t2186) (refl t2168) (awb t0 t2165 t1 t1 (cI)) pv2186
theorem pv2215 : R t2215 t2214 := result (f := t1) (a := t2214) (u := t1) (v := t2214) (refl t1) (aw (ri t2214)) (refl t2214)
theorem pv2213 : R t2213 t2214 := result (f := t22) (a := t2192) (u := t24) (v := t2215) pv22 (aw (ra t1 t2192)) pv2215
theorem pv2211 : R t2211 t2214 := result (f := t2195) (a := t1) (u := t2195) (v := t2213) (refl t2195) (awb t0 t2192 t1 t1 (cI)) pv2213
theorem pv2217 : R t2217 t1 := result (f := t1868) (a := t1) (u := t1862) (v := t1940) pv1868 (awb t2 t1859 t1 t1 (cI)) pv1940
theorem pv2218 : R t2218 t1 := result (f := t2217) (a := t1) (u := t1) (v := t1) pv2217 (aw (ri t1)) (refl t1)
theorem pv2192 : R t2192 t1 := result (f := t2190) (a := t1) (u := t2190) (v := t2218) (refl t2190) (awb t1868 t1 t1 t1 (cI)) pv2218
theorem pv2216 : R t2216 t1 := result (f := t28) (a := t2192) (u := t1) (v := t2192) pv28 (aw (ri t2192)) pv2192
theorem pv2212 : R t2212 t1 := result (f := t2211) (a := t1) (u := t2214) (v := t2216) pv2211 (awb t1 t2192 t1 t1 (cI)) pv2216
theorem pv2206 : R t2206 t1 := result (f := t2204) (a := t1) (u := t2204) (v := t2212) (refl t2204) (awb t2195 t1 t1 t1 (cI)) pv2212
theorem pv2210 : R t2210 t2209 := result (f := t2206) (a := t2209) (u := t1) (v := t2209) pv2206 (aw (ri t2209)) (refl t2209)
theorem pv2207 : R t2207 t2209 := result (f := t0) (a := t2206) (u := t0) (v := t2210) (refl t0) (aw (rh t2206)) pv2210
theorem pv2220 : R t2220 t2219 := result (f := t2206) (a := t2219) (u := t1) (v := t2219) pv2206 (aw (ri t2219)) (refl t2219)
theorem pv2208 : R t2208 t2219 := result (f := t2207) (a := t2192) (u := t2209) (v := t2220) pv2207 (aw (ra t2206 t2192)) pv2220
theorem pv2205 : R t2205 t2219 := result (f := t2195) (a := t2204) (u := t2195) (v := t2208) (refl t2195) (awb t0 t2192 t2204 t2206 (refl _)) pv2208
theorem pv2199 : R t2199 t2219 := result (f := t2197) (a := t1) (u := t2197) (v := t2205) (refl t2197) (aw (ra t2195 t1)) pv2205
theorem pv2231 : R t2231 t1 := result (f := t2206) (a := t1) (u := t1) (v := t1) pv2206 (aw (ri t1)) (refl t1)
theorem pv2232 : R t2232 t1 := result (f := t2231) (a := t2192) (u := t1) (v := t2192) pv2231 (aw (ri t2192)) pv2192
theorem pv2229 : R t2229 t1 := result (f := t2199) (a := t1) (u := t2219) (v := t2232) pv2199 (awb t2206 t2192 t1 t1 (cI)) pv2232
theorem pv2230 : R t2230 t1 := result (f := t2229) (a := t1) (u := t1) (v := t1) pv2229 (aw (ri t1)) (refl t1)
theorem pv2226 : R t2226 t1 := result (f := t2224) (a := t1) (u := t2224) (v := t2230) (refl t2224) (awb t2199 t1 t1 t1 (cI)) pv2230
theorem pv2227 : R t2227 t1 := result (f := t2206) (a := t2226) (u := t1) (v := t2226) pv2206 (aw (ri t2226)) pv2226
theorem pv2228 : R t2228 t1 := result (f := t2227) (a := t2192) (u := t1) (v := t2192) pv2227 (aw (ri t2192)) pv2192
theorem pv2225 : R t2225 t1 := result (f := t2199) (a := t2224) (u := t2219) (v := t2228) pv2199 (awb t2206 t2192 t2224 t2226 (refl _)) pv2228
theorem pv2221 : R t2221 t1 := result (f := t2202) (a := t1) (u := t2202) (v := t2225) (refl t2202) (aw (ra t2199 t1)) pv2225
theorem pv2222 : R t2222 t1 := result (f := t2206) (a := t2221) (u := t1) (v := t2221) pv2206 (aw (ri t2221)) pv2221
theorem pv2223 : R t2223 t1 := result (f := t2222) (a := t2192) (u := t1) (v := t2192) pv2222 (aw (ri t2192)) pv2192
theorem pv2203 : R t2203 t1 := result (f := t2199) (a := t2202) (u := t2219) (v := t2223) pv2199 (awb t2206 t2192 t2202 t2221 (refl _)) pv2223
theorem pv2200 : R t2200 t1 := result (f := t0) (a := t2199) (u := t0) (v := t2203) (refl t0) (aw (rh t2199)) pv2203
theorem pv2201 : R t2201 t1 := result (f := t2200) (a := t2192) (u := t1) (v := t2192) pv2200 (aw (ri t2192)) pv2192
theorem pv2198 : R t2198 t1 := result (f := t2195) (a := t2197) (u := t2195) (v := t2201) (refl t2195) (awb t0 t2192 t2197 t2199 (refl _)) pv2201
theorem pv2196 : R t2196 t1 := result (f := t0) (a := t2195) (u := t0) (v := t2198) (refl t0) (aw (rh t2195)) pv2198
theorem pv2193 : R t2193 t1 := result (f := t2) (a := t2192) (u := t2) (v := t2196) (refl t2) (aw (ra t0 t2192)) pv2196
theorem pv2194 : R t2194 t1 := result (f := t2193) (a := t1859) (u := t1) (v := t1859) pv2193 (aw (ri t1859)) pv1859
theorem pv2191 : R t2191 t1 := result (f := t1868) (a := t2190) (u := t1862) (v := t2194) pv1868 (awb t2 t1859 t2190 t2192 (refl _)) pv2194
theorem pv2165 : R t2165 t1 := result (f := t1871) (a := t1) (u := t1871) (v := t2191) (refl t1871) (aw (ra t1868 t1)) pv2191
theorem pv2189 : R t2189 t1 := result (f := t28) (a := t2165) (u := t1) (v := t2165) pv28 (aw (ri t2165)) pv2165
end Blc.H44.Pump
