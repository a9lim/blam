import H44Literals
import H44ChainRows
import H44Lib0
namespace Blc.H44
theorem ex_e4786842081518 : ¬ IsSelfInterpreter e4786842081518 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786842081518 1 = true)
#print axioms ex_e4786842081518
theorem ex_e4786842081526 : ¬ IsSelfInterpreter e4786842081526 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786842081526 1 = true)
#print axioms ex_e4786842081526
theorem ex_e4786842088222 : ¬ IsSelfInterpreter e4786842088222 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786842088222 1 = true)
#print axioms ex_e4786842088222
theorem ex_e4786842094702 : ¬ IsSelfInterpreter e4786842094702 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786842094702 1 = true)
#print axioms ex_e4786842094702
theorem ex_e4786842096414 : ¬ IsSelfInterpreter e4786842096414 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786842096414 1 = true)
#print axioms ex_e4786842096414
theorem ex_e4786842101574 : ¬ IsSelfInterpreter e4786842101574 := fun h => Blc.H44Chain.ex_e223894971174152376362648984469628621328607046 (transfer (SelfintSharp.replay_sound (by decide : SelfintSharp.replay [[],[.left],[.left],[.left,.right,.under,.under,.left]] e4786842101574 = some Blc.H44Chain.e223894971174152376362648984469628621328607046)) h)
#print axioms ex_e4786842101574
end Blc.H44
