import H44Pumppv42
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2249 : R t2249 t1 := result (f := t2248) (a := t149) (u := t149) (v := t1213) pv2248 (awb t59 t1 t149 t1211 (refl _)) pv1213
theorem pv139 : R t139 t1 := result (f := t135) (a := t138) (u := t151) (v := t2249) pv135 (awb t2 t149 t138 t2247 (refl _)) pv2249
theorem pv136 : R t136 t1 := result (f := t0) (a := t135) (u := t0) (v := t139) (refl t0) (aw (rh t135)) pv139
theorem pv137 : R t137 t151 := result (f := t136) (a := t121) (u := t1) (v := t121) pv136 (aw (ri t121)) pv121
theorem pv134 : R t134 t151 := result (f := t124) (a := t133) (u := t124) (v := t137) (refl t124) (awb t0 t121 t133 t135 (refl _)) pv137
theorem pv128 : R t128 t151 := result (f := t126) (a := t1) (u := t126) (v := t134) (refl t126) (aw (ra t124 t1)) pv134
theorem pv3114 : R t3114 t3113 := result (f := t1) (a := t3113) (u := t1) (v := t3113) (refl t1) (aw (ri t3113)) (refl t3113)
theorem pv3112 : R t3112 t3113 := result (f := t22) (a := t3091) (u := t24) (v := t3114) pv22 (aw (ra t1 t3091)) pv3114
theorem pv3110 : R t3110 t3113 := result (f := t3094) (a := t1) (u := t3094) (v := t3112) (refl t3094) (awb t0 t3091 t1 t1 (cI)) pv3112
theorem pv3141 : R t3141 t3140 := result (f := t1) (a := t3140) (u := t1) (v := t3140) (refl t1) (aw (ri t3140)) (refl t3140)
theorem pv3139 : R t3139 t3140 := result (f := t22) (a := t3118) (u := t24) (v := t3141) pv22 (aw (ra t1 t3118)) pv3141
theorem pv3137 : R t3137 t3140 := result (f := t3121) (a := t1) (u := t3121) (v := t3139) (refl t3121) (awb t0 t3118 t1 t1 (cI)) pv3139
theorem pv3143 : R t3143 t149 := result (f := t128) (a := t1) (u := t151) (v := t229) pv128 (awb t2 t149 t1 t1 (cI)) pv229
theorem pv3144 : R t3144 t1 := result (f := t3143) (a := t1) (u := t149) (v := t231) pv3143 (awb t59 t1 t1 t1 (cI)) pv231
theorem pv3118 : R t3118 t1 := result (f := t3116) (a := t1) (u := t3116) (v := t3144) (refl t3116) (awb t128 t1 t1 t1 (cI)) pv3144
theorem pv3142 : R t3142 t1 := result (f := t28) (a := t3118) (u := t1) (v := t3118) pv28 (aw (ri t3118)) pv3118
theorem pv3138 : R t3138 t1 := result (f := t3137) (a := t1) (u := t3140) (v := t3142) pv3137 (awb t1 t3118 t1 t1 (cI)) pv3142
theorem pv3132 : R t3132 t1 := result (f := t3130) (a := t1) (u := t3130) (v := t3138) (refl t3130) (awb t3121 t1 t1 t1 (cI)) pv3138
theorem pv3136 : R t3136 t3135 := result (f := t3132) (a := t3135) (u := t1) (v := t3135) pv3132 (aw (ri t3135)) (refl t3135)
theorem pv3133 : R t3133 t3135 := result (f := t0) (a := t3132) (u := t0) (v := t3136) (refl t0) (aw (rh t3132)) pv3136
theorem pv3146 : R t3146 t3145 := result (f := t3132) (a := t3145) (u := t1) (v := t3145) pv3132 (aw (ri t3145)) (refl t3145)
theorem pv3134 : R t3134 t3145 := result (f := t3133) (a := t3118) (u := t3135) (v := t3146) pv3133 (aw (ra t3132 t3118)) pv3146
theorem pv3131 : R t3131 t3145 := result (f := t3121) (a := t3130) (u := t3121) (v := t3134) (refl t3121) (awb t0 t3118 t3130 t3132 (refl _)) pv3134
theorem pv3125 : R t3125 t3145 := result (f := t3123) (a := t1) (u := t3123) (v := t3131) (refl t3123) (aw (ra t3121 t1)) pv3131
theorem pv3157 : R t3157 t1 := result (f := t3132) (a := t1) (u := t1) (v := t1) pv3132 (aw (ri t1)) (refl t1)
theorem pv3158 : R t3158 t1 := result (f := t3157) (a := t3118) (u := t1) (v := t3118) pv3157 (aw (ri t3118)) pv3118
theorem pv3155 : R t3155 t1 := result (f := t3125) (a := t1) (u := t3145) (v := t3158) pv3125 (awb t3132 t3118 t1 t1 (cI)) pv3158
theorem pv3156 : R t3156 t1 := result (f := t3155) (a := t1) (u := t1) (v := t1) pv3155 (aw (ri t1)) (refl t1)
theorem pv3152 : R t3152 t1 := result (f := t3150) (a := t1) (u := t3150) (v := t3156) (refl t3150) (awb t3125 t1 t1 t1 (cI)) pv3156
theorem pv3153 : R t3153 t1 := result (f := t3132) (a := t3152) (u := t1) (v := t3152) pv3132 (aw (ri t3152)) pv3152
theorem pv3154 : R t3154 t1 := result (f := t3153) (a := t3118) (u := t1) (v := t3118) pv3153 (aw (ri t3118)) pv3118
theorem pv3151 : R t3151 t1 := result (f := t3125) (a := t3150) (u := t3145) (v := t3154) pv3125 (awb t3132 t3118 t3150 t3152 (refl _)) pv3154
theorem pv3147 : R t3147 t1 := result (f := t3128) (a := t1) (u := t3128) (v := t3151) (refl t3128) (aw (ra t3125 t1)) pv3151
theorem pv3148 : R t3148 t1 := result (f := t3132) (a := t3147) (u := t1) (v := t3147) pv3132 (aw (ri t3147)) pv3147
theorem pv3149 : R t3149 t1 := result (f := t3148) (a := t3118) (u := t1) (v := t3118) pv3148 (aw (ri t3118)) pv3118
theorem pv3129 : R t3129 t1 := result (f := t3125) (a := t3128) (u := t3145) (v := t3149) pv3125 (awb t3132 t3118 t3128 t3147 (refl _)) pv3149
theorem pv3126 : R t3126 t1 := result (f := t0) (a := t3125) (u := t0) (v := t3129) (refl t0) (aw (rh t3125)) pv3129
theorem pv3127 : R t3127 t1 := result (f := t3126) (a := t3118) (u := t1) (v := t3118) pv3126 (aw (ri t3118)) pv3118
theorem pv3124 : R t3124 t1 := result (f := t3121) (a := t3123) (u := t3121) (v := t3127) (refl t3121) (awb t0 t3118 t3123 t3125 (refl _)) pv3127
theorem pv3122 : R t3122 t1 := result (f := t0) (a := t3121) (u := t0) (v := t3124) (refl t0) (aw (rh t3121)) pv3124
theorem pv3119 : R t3119 t1 := result (f := t2) (a := t3118) (u := t2) (v := t3122) (refl t2) (aw (ra t0 t3118)) pv3122
theorem pv3120 : R t3120 t149 := result (f := t3119) (a := t149) (u := t1) (v := t149) pv3119 (aw (ri t149)) (refl t149)
theorem pv3117 : R t3117 t149 := result (f := t128) (a := t3116) (u := t151) (v := t3120) pv128 (awb t2 t149 t3116 t3118 (refl _)) pv3120
theorem pv3091 : R t3091 t149 := result (f := t131) (a := t1) (u := t131) (v := t3117) (refl t131) (aw (ra t128 t1)) pv3117
theorem pv3115 : R t3115 t149 := result (f := t28) (a := t3091) (u := t1) (v := t3091) pv28 (aw (ri t3091)) pv3091
theorem pv3111 : R t3111 t149 := result (f := t3110) (a := t1) (u := t3113) (v := t3115) pv3110 (awb t1 t3091 t1 t1 (cI)) pv3115
theorem pv3105 : R t3105 t149 := result (f := t3103) (a := t1) (u := t3103) (v := t3111) (refl t3103) (awb t3094 t1 t1 t1 (cI)) pv3111
theorem pv3184 : R t3184 t3183 := result (f := t1) (a := t3183) (u := t1) (v := t3183) (refl t1) (aw (ri t3183)) (refl t3183)
theorem pv3182 : R t3182 t3183 := result (f := t22) (a := t3162) (u := t24) (v := t3184) pv22 (aw (ra t1 t3162)) pv3184
theorem pv3180 : R t3180 t3183 := result (f := t3164) (a := t1) (u := t3164) (v := t3182) (refl t3164) (awb t0 t3162 t1 t1 (cI)) pv3182
theorem pv3185 : R t3185 t3162 := result (f := t28) (a := t3162) (u := t1) (v := t3162) pv28 (aw (ri t3162)) (refl t3162)
theorem pv3181 : R t3181 t3162 := result (f := t3180) (a := t1) (u := t3183) (v := t3185) pv3180 (awb t1 t3162 t1 t1 (cI)) pv3185
theorem pv3175 : R t3175 t3162 := result (f := t3173) (a := t1) (u := t3173) (v := t3181) (refl t3173) (awb t3164 t1 t1 t1 (cI)) pv3181
theorem pv3209 : R t3209 t3208 := result (f := t1) (a := t3208) (u := t1) (v := t3208) (refl t1) (aw (ri t3208)) (refl t3208)
theorem pv3207 : R t3207 t3208 := result (f := t22) (a := t3186) (u := t24) (v := t3209) pv22 (aw (ra t1 t3186)) pv3209
end Blc.H44.Pump
