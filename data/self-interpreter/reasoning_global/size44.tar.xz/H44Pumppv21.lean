import H44Pumppv20
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv1584 : R t1584 t1 := result (f := t1583) (a := t1555) (u := t1) (v := t1555) pv1583 (aw (ri t1555)) pv1555
theorem pv1575 : R t1575 t1 := result (f := t1571) (a := t1574) (u := t1558) (v := t1584) pv1571 (awb t2 t1555 t1574 t1582 (refl _)) pv1584
theorem pv1572 : R t1572 t1 := result (f := t0) (a := t1571) (u := t0) (v := t1575) (refl t0) (aw (rh t1571)) pv1575
theorem pv1573 : R t1573 t1558 := result (f := t1572) (a := t1558) (u := t1) (v := t1558) pv1572 (aw (ri t1558)) (refl t1558)
theorem pv1570 : R t1570 t1558 := result (f := t1560) (a := t1569) (u := t1560) (v := t1573) (refl t1560) (awb t0 t1558 t1569 t1571 (refl _)) pv1573
theorem pv1564 : R t1564 t1558 := result (f := t1562) (a := t1) (u := t1562) (v := t1570) (refl t1562) (aw (ra t1560 t1)) pv1570
theorem pv1690 : R t1690 t1689 := result (f := t1) (a := t1689) (u := t1) (v := t1689) (refl t1) (aw (ri t1689)) (refl t1689)
theorem pv1688 : R t1688 t1689 := result (f := t22) (a := t1667) (u := t24) (v := t1690) pv22 (aw (ra t1 t1667)) pv1690
theorem pv1686 : R t1686 t1689 := result (f := t1670) (a := t1) (u := t1670) (v := t1688) (refl t1670) (awb t0 t1667 t1 t1 (cI)) pv1688
theorem pv1717 : R t1717 t1716 := result (f := t1) (a := t1716) (u := t1) (v := t1716) (refl t1) (aw (ri t1716)) (refl t1716)
theorem pv1715 : R t1715 t1716 := result (f := t22) (a := t1694) (u := t24) (v := t1717) pv22 (aw (ra t1 t1694)) pv1717
theorem pv1713 : R t1713 t1716 := result (f := t1697) (a := t1) (u := t1697) (v := t1715) (refl t1697) (awb t0 t1694 t1 t1 (cI)) pv1715
theorem pv1719 : R t1719 t1 := result (f := t1564) (a := t1) (u := t1558) (v := t1636) pv1564 (awb t2 t1555 t1 t1 (cI)) pv1636
theorem pv1720 : R t1720 t1 := result (f := t1719) (a := t1) (u := t1) (v := t1) pv1719 (aw (ri t1)) (refl t1)
theorem pv1694 : R t1694 t1 := result (f := t1692) (a := t1) (u := t1692) (v := t1720) (refl t1692) (awb t1564 t1 t1 t1 (cI)) pv1720
theorem pv1718 : R t1718 t1 := result (f := t28) (a := t1694) (u := t1) (v := t1694) pv28 (aw (ri t1694)) pv1694
theorem pv1714 : R t1714 t1 := result (f := t1713) (a := t1) (u := t1716) (v := t1718) pv1713 (awb t1 t1694 t1 t1 (cI)) pv1718
theorem pv1708 : R t1708 t1 := result (f := t1706) (a := t1) (u := t1706) (v := t1714) (refl t1706) (awb t1697 t1 t1 t1 (cI)) pv1714
theorem pv1712 : R t1712 t1711 := result (f := t1708) (a := t1711) (u := t1) (v := t1711) pv1708 (aw (ri t1711)) (refl t1711)
theorem pv1709 : R t1709 t1711 := result (f := t0) (a := t1708) (u := t0) (v := t1712) (refl t0) (aw (rh t1708)) pv1712
theorem pv1722 : R t1722 t1721 := result (f := t1708) (a := t1721) (u := t1) (v := t1721) pv1708 (aw (ri t1721)) (refl t1721)
theorem pv1710 : R t1710 t1721 := result (f := t1709) (a := t1694) (u := t1711) (v := t1722) pv1709 (aw (ra t1708 t1694)) pv1722
theorem pv1707 : R t1707 t1721 := result (f := t1697) (a := t1706) (u := t1697) (v := t1710) (refl t1697) (awb t0 t1694 t1706 t1708 (refl _)) pv1710
theorem pv1701 : R t1701 t1721 := result (f := t1699) (a := t1) (u := t1699) (v := t1707) (refl t1699) (aw (ra t1697 t1)) pv1707
theorem pv1733 : R t1733 t1 := result (f := t1708) (a := t1) (u := t1) (v := t1) pv1708 (aw (ri t1)) (refl t1)
theorem pv1734 : R t1734 t1 := result (f := t1733) (a := t1694) (u := t1) (v := t1694) pv1733 (aw (ri t1694)) pv1694
theorem pv1731 : R t1731 t1 := result (f := t1701) (a := t1) (u := t1721) (v := t1734) pv1701 (awb t1708 t1694 t1 t1 (cI)) pv1734
theorem pv1732 : R t1732 t1 := result (f := t1731) (a := t1) (u := t1) (v := t1) pv1731 (aw (ri t1)) (refl t1)
theorem pv1728 : R t1728 t1 := result (f := t1726) (a := t1) (u := t1726) (v := t1732) (refl t1726) (awb t1701 t1 t1 t1 (cI)) pv1732
theorem pv1729 : R t1729 t1 := result (f := t1708) (a := t1728) (u := t1) (v := t1728) pv1708 (aw (ri t1728)) pv1728
theorem pv1730 : R t1730 t1 := result (f := t1729) (a := t1694) (u := t1) (v := t1694) pv1729 (aw (ri t1694)) pv1694
theorem pv1727 : R t1727 t1 := result (f := t1701) (a := t1726) (u := t1721) (v := t1730) pv1701 (awb t1708 t1694 t1726 t1728 (refl _)) pv1730
theorem pv1723 : R t1723 t1 := result (f := t1704) (a := t1) (u := t1704) (v := t1727) (refl t1704) (aw (ra t1701 t1)) pv1727
theorem pv1724 : R t1724 t1 := result (f := t1708) (a := t1723) (u := t1) (v := t1723) pv1708 (aw (ri t1723)) pv1723
theorem pv1725 : R t1725 t1 := result (f := t1724) (a := t1694) (u := t1) (v := t1694) pv1724 (aw (ri t1694)) pv1694
theorem pv1705 : R t1705 t1 := result (f := t1701) (a := t1704) (u := t1721) (v := t1725) pv1701 (awb t1708 t1694 t1704 t1723 (refl _)) pv1725
theorem pv1702 : R t1702 t1 := result (f := t0) (a := t1701) (u := t0) (v := t1705) (refl t0) (aw (rh t1701)) pv1705
theorem pv1703 : R t1703 t1 := result (f := t1702) (a := t1694) (u := t1) (v := t1694) pv1702 (aw (ri t1694)) pv1694
theorem pv1700 : R t1700 t1 := result (f := t1697) (a := t1699) (u := t1697) (v := t1703) (refl t1697) (awb t0 t1694 t1699 t1701 (refl _)) pv1703
theorem pv1698 : R t1698 t1 := result (f := t0) (a := t1697) (u := t0) (v := t1700) (refl t0) (aw (rh t1697)) pv1700
theorem pv1695 : R t1695 t1 := result (f := t2) (a := t1694) (u := t2) (v := t1698) (refl t2) (aw (ra t0 t1694)) pv1698
theorem pv1696 : R t1696 t1 := result (f := t1695) (a := t1555) (u := t1) (v := t1555) pv1695 (aw (ri t1555)) pv1555
theorem pv1693 : R t1693 t1 := result (f := t1564) (a := t1692) (u := t1558) (v := t1696) pv1564 (awb t2 t1555 t1692 t1694 (refl _)) pv1696
theorem pv1667 : R t1667 t1 := result (f := t1567) (a := t1) (u := t1567) (v := t1693) (refl t1567) (aw (ra t1564 t1)) pv1693
theorem pv1691 : R t1691 t1 := result (f := t28) (a := t1667) (u := t1) (v := t1667) pv28 (aw (ri t1667)) pv1667
theorem pv1687 : R t1687 t1 := result (f := t1686) (a := t1) (u := t1689) (v := t1691) pv1686 (awb t1 t1667 t1 t1 (cI)) pv1691
theorem pv1681 : R t1681 t1 := result (f := t1679) (a := t1) (u := t1679) (v := t1687) (refl t1679) (awb t1670 t1 t1 t1 (cI)) pv1687
theorem pv1685 : R t1685 t1684 := result (f := t1681) (a := t1684) (u := t1) (v := t1684) pv1681 (aw (ri t1684)) (refl t1684)
theorem pv1682 : R t1682 t1684 := result (f := t0) (a := t1681) (u := t0) (v := t1685) (refl t0) (aw (rh t1681)) pv1685
theorem pv1736 : R t1736 t1735 := result (f := t1681) (a := t1735) (u := t1) (v := t1735) pv1681 (aw (ri t1735)) (refl t1735)
theorem pv1683 : R t1683 t1735 := result (f := t1682) (a := t1667) (u := t1684) (v := t1736) pv1682 (aw (ra t1681 t1667)) pv1736
theorem pv1680 : R t1680 t1735 := result (f := t1670) (a := t1679) (u := t1670) (v := t1683) (refl t1670) (awb t0 t1667 t1679 t1681 (refl _)) pv1683
theorem pv1674 : R t1674 t1735 := result (f := t1672) (a := t1) (u := t1672) (v := t1680) (refl t1672) (aw (ra t1670 t1)) pv1680
theorem pv1747 : R t1747 t1 := result (f := t1681) (a := t1) (u := t1) (v := t1) pv1681 (aw (ri t1)) (refl t1)
theorem pv1748 : R t1748 t1 := result (f := t1747) (a := t1667) (u := t1) (v := t1667) pv1747 (aw (ri t1667)) pv1667
end Blc.H44.Pump
