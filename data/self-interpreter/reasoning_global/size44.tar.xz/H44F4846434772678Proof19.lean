import H44F4846434772678Proof18
namespace Blc.H44.H44F4846434772678
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h684 (ρ : Env) (a0 : Fits s32 (ρ 0)) (a1 : Fits s83 (ρ 1)) : All tab ρ b9 s85 :=
  (consAll (lamAt d4 c4 (smaller (h625 (Types.cons s3 ρ) sub3 a0 a1) sub3)) (consAll (lamAt d235 c235 (smaller (h585 (Types.cons s32 ρ) sub141 a0 a1) sub175)) (consAll (lamAt d336 c336 (smaller (h626 (Types.cons s118 ρ) sub114 a0 a1) sub3)) (consAll (lamAt d340 c340 (smaller (h629 (Types.cons s52 ρ) sub170 a0 a1) sub3)) Positive.none))))
theorem h685 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s195 :=
  (consAll (lamAt d247 c247 (smaller (h591 (Types.cons s96 ρ) sub367 a0 a1) sub250)) Positive.none)
theorem h686 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s196 :=
  (consAll (lamAt d249 c249 (smaller (h592 (Types.cons s97 ρ) sub368 a0 a1) sub250)) Positive.none)
theorem h687 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s198 :=
  (consAll (lamAt d256 c256 (smaller (h594 (Types.cons s101 ρ) sub89 a0 a1) sub253)) Positive.none)
theorem h688 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s197 :=
  (consAll (lamAt d254 c254 (smaller (h595 (Types.cons s99 ρ) sub92 a0 a1) sub250)) Positive.none)
theorem h689 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s201 :=
  (consAll (lamAt d264 c264 (smaller (h597 (Types.cons s99 ρ) sub92 a0 a1) sub256)) Positive.none)
theorem h690 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s194 :=
  (consAll (lamAt d245 c245 (smaller (h598 (Types.cons s74 ρ) sub361 a0 a1) sub249)) Positive.none)
theorem h691 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s204 :=
  (consAll (lamAt d272 c272 (smaller (h600 (Types.cons s104 ρ) sub94 a0 a1) sub259)) Positive.none)
theorem h692 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s203 :=
  (consAll (lamAt d270 c270 (smaller (h601 (Types.cons s75 ρ) sub96 a0 a1) sub249)) Positive.none)
theorem h693 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s207 :=
  (consAll (lamAt d280 c280 (smaller (h603 (Types.cons s75 ρ) sub96 a0 a1) sub262)) Positive.none)
theorem h694 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s193 :=
  (consAll (lamAt d243 c243 (smaller (h604 (Types.cons s57 ρ) sub46 a0 a1) sub248)) Positive.none)
theorem h695 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s210 :=
  (consAll (lamAt d288 c288 (smaller (h606 (Types.cons s107 ρ) sub98 a0 a1) sub265)) Positive.none)
theorem h696 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s189 :=
  (consAll (lamAt d229 c229 (smaller (h607 (Types.cons s93 ρ) sub366 a0 a1) sub243)) Positive.none)
theorem h697 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s213 :=
  (consAll (lamAt d296 c296 (smaller (h609 (Types.cons s110 ρ) sub100 a0 a1) sub268)) Positive.none)
theorem h698 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s212 :=
  (consAll (lamAt d294 c294 (smaller (h610 (Types.cons s108 ρ) sub103 a0 a1) sub243)) Positive.none)
theorem h699 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s216 :=
  (consAll (lamAt d304 c304 (smaller (h612 (Types.cons s108 ρ) sub103 a0 a1) sub271)) Positive.none)
theorem h700 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s187 :=
  (consAll (lamAt d225 c225 (smaller (h613 (Types.cons s90 ρ) sub364 a0 a1) sub242)) Positive.none)
theorem h701 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s219 :=
  (consAll (lamAt d312 c312 (smaller (h615 (Types.cons s114 ρ) sub105 a0 a1) sub274)) Positive.none)
theorem h702 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s218 :=
  (consAll (lamAt d310 c310 (smaller (h616 (Types.cons s112 ρ) sub108 a0 a1) sub242)) Positive.none)
theorem h703 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s222 :=
  (consAll (lamAt d320 c320 (smaller (h618 (Types.cons s112 ρ) sub108 a0 a1) sub277)) Positive.none)
theorem h704 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s186 :=
  (consAll (lamAt d223 c223 (smaller (h619 (Types.cons s88 ρ) sub110 a0 a1) sub241)) Positive.none)
theorem h705 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s225 :=
  (consAll (lamAt d328 c328 (smaller (h621 (Types.cons s88 ρ) sub110 a0 a1) sub280)) Positive.none)
theorem h706 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s11 (ρ 1)) : All tab ρ b9 s185 :=
  (consAll (lamAt d221 c221 (smaller (h622 (Types.cons s86 ρ) sub112 a0 a1) sub3)) Positive.none)
theorem h707 (ρ : Env) (a0 : Fits s0 (ρ 0)) (a1 : Fits s1 (ρ 1)) : All tab ρ b9 s185 :=
  (consAll (lamAt d221 c221 (smaller (h624 (Types.cons s86 ρ) sub112 a0 a1) sub3)) Positive.none)
theorem h708 (ρ : Env) (a0 : Fits s32 (ρ 0)) (a1 : Fits s117 (ρ 1)) : All tab ρ b9 s119 :=
  (consAll (lamAt d338 c338 (smaller (h628 (Types.cons s32 ρ) sub141 a0 a1) sub3)) Positive.none)
theorem h709 (ρ : Env) (a0 : Fits s1 (ρ 0)) : All tab ρ b10 s4 :=
  (consAll (lamAt d6 c6 (smaller (h634 (Types.cons s5 ρ) sub8 a0) sub373)) (consAll (lamAt d14 c14 (smaller (h637 (Types.cons s10 ρ) sub10 a0) sub8)) (consAll (lamAt d20 c20 (smaller (h639 (Types.cons s0 ρ) sub374 a0) sub178)) (consAll (lamAt d24 c24 (smaller (h640 (Types.cons s0 ρ) sub374 a0) sub179)) (consAll (lamAt d32 c32 (smaller (h642 (Types.cons s0 ρ) sub374 a0) sub182)) (consAll (lamAt d40 c40 (smaller (h644 (Types.cons s0 ρ) sub374 a0) sub185)) (consAll (lamAt d46 c46 (smaller (h646 (Types.cons s0 ρ) sub374 a0) sub187)) (consAll (lamAt d51 c51 (smaller (h647 (Types.cons s0 ρ) sub374 a0) sub188)) (consAll (lamAt d58 c58 (smaller (h649 (Types.cons s0 ρ) sub374 a0) sub189)) (consAll (lamAt d69 c69 (smaller (h651 (Types.cons s0 ρ) sub374 a0) sub193)) (consAll (lamAt d80 c80 (smaller (h653 (Types.cons s0 ρ) sub374 a0) sub196)) (consAll (lamAt d88 c88 (smaller (h655 (Types.cons s0 ρ) sub374 a0) sub199)) (consAll (lamAt d96 c96 (smaller (h657 (Types.cons s0 ρ) sub374 a0) sub201)) (consAll (lamAt d104 c104 (smaller (h659 (Types.cons s0 ρ) sub374 a0) sub203)) (consAll (lamAt d118 c118 (smaller (h661 (Types.cons s0 ρ) sub374 a0) sub208)) (consAll (lamAt d129 c129 (smaller (h663 (Types.cons s0 ρ) sub374 a0) sub211)) (consAll (lamAt d138 c138 (smaller (h665 (Types.cons s0 ρ) sub374 a0) sub214)) (consAll (lamAt d143 c143 (smaller (h669 (Types.cons s0 ρ) sub374 a0) sub202)) (consAll (lamAt d146 c146 (smaller (h667 (Types.cons s0 ρ) sub374 a0) sub217)) (consAll (lamAt d160 c160 (smaller (h670 (Types.cons s0 ρ) sub374 a0) sub221)) (consAll (lamAt d177 c177 (smaller (h672 (Types.cons s0 ρ) sub374 a0) sub227)) (consAll (lamAt d186 c186 (smaller (h674 (Types.cons s0 ρ) sub374 a0) sub230)) (consAll (lamAt d195 c195 (smaller (h676 (Types.cons s0 ρ) sub374 a0) sub233)) (consAll (lamAt d203 c203 (smaller (h678 (Types.cons s0 ρ) sub374 a0) sub236)) (consAll (lamAt d209 c209 (smaller (h682 (Types.cons s0 ρ) sub374 a0) sub219)) (consAll (lamAt d212 c212 (smaller (h680 (Types.cons s0 ρ) sub374 a0) sub239)) (consAll (lamAt d228 c228 (smaller (h683 (Types.cons s0 ρ) sub374 a0) sub244)) (consAll (lamAt d248 c248 (smaller (h685 (Types.cons s0 ρ) sub374 a0) sub251)) (consAll (lamAt d257 c257 (smaller (h687 (Types.cons s0 ρ) sub374 a0) sub254)) (consAll (lamAt d265 c265 (smaller (h689 (Types.cons s0 ρ) sub374 a0) sub257)) (consAll (lamAt d273 c273 (smaller (h691 (Types.cons s0 ρ) sub374 a0) sub260)) (consAll (lamAt d281 c281 (smaller (h693 (Types.cons s0 ρ) sub374 a0) sub263)) (consAll (lamAt d289 c289 (smaller (h695 (Types.cons s0 ρ) sub374 a0) sub266)) (consAll (lamAt d297 c297 (smaller (h697 (Types.cons s0 ρ) sub374 a0) sub269)) (consAll (lamAt d305 c305 (smaller (h699 (Types.cons s0 ρ) sub374 a0) sub272)) (consAll (lamAt d313 c313 (smaller (h701 (Types.cons s0 ρ) sub374 a0) sub275)) (consAll (lamAt d321 c321 (smaller (h703 (Types.cons s0 ρ) sub374 a0) sub278)) (consAll (lamAt d326 c326 (smaller (h707 (Types.cons s0 ρ) sub374 a0) sub241)) (consAll (lamAt d329 c329 (smaller (h705 (Types.cons s0 ρ) sub374 a0) sub281)) Positive.none)))))))))))))))))))))))))))))))))))))))
theorem h710 (ρ : Env) (a0 : Fits s2 (ρ 0)) : All tab ρ b10 s6 :=
  (consAll (lamAt d9 c9 (smaller (h635 (Types.cons s5 ρ) sub8 a0) sub4)) Positive.none)
theorem h711 (ρ : Env) (a0 : Fits s7 (ρ 0)) : All tab ρ b10 s8 :=
  (consAll (lamAt d13 c13 (smaller (h636 (Types.cons s5 ρ) sub8 a0) sub6)) Positive.none)
theorem h712 (ρ : Env) (a0 : Fits s4 (ρ 0)) : All tab ρ b10 s10 :=
  (consAll (lamAt d18 c18 (smaller (h638 (Types.cons s10 ρ) sub10 a0) sub164)) Positive.none)
theorem h713 (ρ : Env) (a0 : Fits s11 (ρ 0)) : All tab ρ b10 s14 :=
  (consAll (lamAt d27 c27 (smaller (h641 (Types.cons s0 ρ) sub374 a0) sub180)) (consAll (lamAt d33 c33 (smaller (h643 (Types.cons s0 ρ) sub374 a0) sub181)) (consAll (lamAt d37 c37 (smaller (h645 (Types.cons s21 ρ) sub134 a0) sub128)) (consAll (lamAt d62 c62 (smaller (h656 (Types.cons s32 ρ) sub141 a0) sub133)) (consAll (lamAt d70 c70 (smaller (h652 (Types.cons s0 ρ) sub374 a0) sub192)) (consAll (lamAt d77 c77 (smaller (h654 (Types.cons s0 ρ) sub374 a0) sub191)) (consAll (lamAt d107 c107 (smaller (h664 (Types.cons s0 ρ) sub374 a0) sub204)) (consAll (lamAt d115 c115 (smaller (h662 (Types.cons s55 ρ) sub71 a0) sub206)) (consAll (lamAt d139 c139 (smaller (h666 (Types.cons s0 ρ) sub374 a0) sub213)) (consAll (lamAt d143 c143 (smaller (h668 (Types.cons s0 ρ) sub374 a0) sub202)) (consAll (lamAt d161 c161 (smaller (h679 (Types.cons s0 ρ) sub374 a0) sub220)) (consAll (lamAt d170 c170 (smaller (h677 (Types.cons s53 ρ) sub52 a0) sub375)) (consAll (lamAt d178 c178 (smaller (h673 (Types.cons s75 ρ) sub96 a0) sub226)) (consAll (lamAt d183 c183 (smaller (h675 (Types.cons s0 ρ) sub374 a0) sub376)) (consAll (lamAt d209 c209 (smaller (h681 (Types.cons s0 ρ) sub374 a0) sub219)) (consAll (lamAt d231 c231 (smaller (h696 (Types.cons s0 ρ) sub374 a0) sub245)) (consAll (lamAt d239 c239 (smaller (h677 (Types.cons s53 ρ) sub52 a0) sub377)) (consAll (lamAt d251 c251 (smaller (h686 (Types.cons s0 ρ) sub374 a0) sub252)) (consAll (lamAt d258 c258 (smaller (h688 (Types.cons s0 ρ) sub374 a0) sub253)) (consAll (lamAt d262 c262 (smaller (h690 (Types.cons s0 ρ) sub374 a0) sub250)) (consAll (lamAt d274 c274 (smaller (h692 (Types.cons s0 ρ) sub374 a0) sub259)) (consAll (lamAt d278 c278 (smaller (h694 (Types.cons s0 ρ) sub374 a0) sub249)) (consAll (lamAt d286 c286 (smaller (h675 (Types.cons s0 ρ) sub374 a0) sub378)) (consAll (lamAt d298 c298 (smaller (h698 (Types.cons s0 ρ) sub374 a0) sub268)) (consAll (lamAt d302 c302 (smaller (h700 (Types.cons s0 ρ) sub374 a0) sub243)) (consAll (lamAt d314 c314 (smaller (h702 (Types.cons s0 ρ) sub374 a0) sub274)) (consAll (lamAt d318 c318 (smaller (h704 (Types.cons s0 ρ) sub374 a0) sub242)) (consAll (lamAt d326 c326 (smaller (h706 (Types.cons s0 ρ) sub374 a0) sub241)) Positive.none))))))))))))))))))))))))))))
theorem h714 (ρ : Env) (a0 : Fits s12 (ρ 0)) : All tab ρ b10 s25 :=
  (consAll (lamAt d53 c53 (smaller (h648 (Types.cons s21 ρ) sub134 a0) sub132)) Positive.none)
theorem h715 (ρ : Env) (a0 : Fits s26 (ρ 0)) : All tab ρ b10 s28 :=
  (consAll (lamAt d61 c61 (smaller (h650 (Types.cons s21 ρ) sub134 a0) sub27)) Positive.none)
theorem h716 (ρ : Env) (a0 : Fits s30 (ρ 0)) : All tab ρ b10 s41 :=
  (consAll (lamAt d98 c98 (smaller (h658 (Types.cons s32 ρ) sub141 a0) sub138)) Positive.none)
theorem h717 (ρ : Env) (a0 : Fits s42 (ρ 0)) : All tab ρ b10 s44 :=
  (consAll (lamAt d110 c110 (smaller (h660 (Types.cons s32 ρ) sub141 a0) sub167)) Positive.none)
theorem h718 (ρ : Env) (a0 : Fits s65 (ρ 0)) : All tab ρ b10 s66 :=
  (consAll (lamAt d167 c167 (smaller (h671 (Types.cons s32 ρ) sub141 a0) sub172)) Positive.none)
theorem h719 (ρ : Env) (a0 : Fits s83 (ρ 0)) : All tab ρ b10 s84 :=
  (consAll (lamAt d236 c236 (smaller (h684 (Types.cons s32 ρ) sub141 a0) sub176)) Positive.none)
end Blc.H44.H44F4846434772678
