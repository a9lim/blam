import H44Pumppv0
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv174 : R t174 t151 := result (f := t28) (a := t151) (u := t1) (v := t151) pv28 (aw (ri t151)) (refl t151)
theorem pv170 : R t170 t151 := result (f := t169) (a := t1) (u := t172) (v := t174) pv169 (awb t1 t151 t1 t1 (cI)) pv174
theorem pv164 : R t164 t151 := result (f := t162) (a := t1) (u := t162) (v := t170) (refl t162) (awb t153 t1 t1 t1 (cI)) pv170
theorem pv198 : R t198 t197 := result (f := t1) (a := t197) (u := t1) (v := t197) (refl t1) (aw (ri t197)) (refl t197)
theorem pv196 : R t196 t197 := result (f := t22) (a := t175) (u := t24) (v := t198) pv22 (aw (ra t1 t175)) pv198
theorem pv194 : R t194 t197 := result (f := t178) (a := t1) (u := t178) (v := t196) (refl t178) (awb t0 t175 t1 t1 (cI)) pv196
theorem pv225 : R t225 t224 := result (f := t1) (a := t224) (u := t1) (v := t224) (refl t1) (aw (ri t224)) (refl t224)
theorem pv223 : R t223 t224 := result (f := t22) (a := t202) (u := t24) (v := t225) pv22 (aw (ra t1 t202)) pv225
theorem pv221 : R t221 t224 := result (f := t205) (a := t1) (u := t205) (v := t223) (refl t205) (awb t0 t202 t1 t1 (cI)) pv223
theorem pv229 : R t229 t149 := result (f := t3) (a := t149) (u := t1) (v := t149) pv3 (aw (ri t149)) (refl t149)
theorem pv227 : R t227 t149 := result (f := t164) (a := t1) (u := t151) (v := t229) pv164 (awb t2 t149 t1 t1 (cI)) pv229
theorem pv254 : R t254 t253 := result (f := t1) (a := t253) (u := t1) (v := t253) (refl t1) (aw (ri t253)) (refl t253)
theorem pv252 : R t252 t253 := result (f := t22) (a := t232) (u := t24) (v := t254) pv22 (aw (ra t1 t232)) pv254
theorem pv250 : R t250 t253 := result (f := t234) (a := t1) (u := t234) (v := t252) (refl t234) (awb t0 t232 t1 t1 (cI)) pv252
theorem pv255 : R t255 t232 := result (f := t28) (a := t232) (u := t1) (v := t232) pv28 (aw (ri t232)) (refl t232)
theorem pv251 : R t251 t232 := result (f := t250) (a := t1) (u := t253) (v := t255) pv250 (awb t1 t232 t1 t1 (cI)) pv255
theorem pv245 : R t245 t232 := result (f := t243) (a := t1) (u := t243) (v := t251) (refl t243) (awb t234 t1 t1 t1 (cI)) pv251
theorem pv279 : R t279 t278 := result (f := t1) (a := t278) (u := t1) (v := t278) (refl t1) (aw (ri t278)) (refl t278)
theorem pv277 : R t277 t278 := result (f := t22) (a := t256) (u := t24) (v := t279) pv22 (aw (ra t1 t256)) pv279
theorem pv275 : R t275 t278 := result (f := t259) (a := t1) (u := t259) (v := t277) (refl t259) (awb t0 t256 t1 t1 (cI)) pv277
theorem pv306 : R t306 t305 := result (f := t1) (a := t305) (u := t1) (v := t305) (refl t1) (aw (ri t305)) (refl t305)
theorem pv304 : R t304 t305 := result (f := t22) (a := t283) (u := t24) (v := t306) pv22 (aw (ra t1 t283)) pv306
theorem pv302 : R t302 t305 := result (f := t286) (a := t1) (u := t286) (v := t304) (refl t286) (awb t0 t283 t1 t1 (cI)) pv304
theorem pv310 : R t310 t1 := result (f := t3) (a := t1) (u := t1) (v := t1) pv3 (aw (ri t1)) (refl t1)
theorem pv308 : R t308 t1 := result (f := t245) (a := t1) (u := t232) (v := t310) pv245 (awb t2 t1 t1 t1 (cI)) pv310
theorem pv309 : R t309 t1 := result (f := t308) (a := t1) (u := t1) (v := t1) pv308 (aw (ri t1)) (refl t1)
theorem pv283 : R t283 t1 := result (f := t281) (a := t1) (u := t281) (v := t309) (refl t281) (awb t245 t1 t1 t1 (cI)) pv309
theorem pv307 : R t307 t1 := result (f := t28) (a := t283) (u := t1) (v := t283) pv28 (aw (ri t283)) pv283
theorem pv303 : R t303 t1 := result (f := t302) (a := t1) (u := t305) (v := t307) pv302 (awb t1 t283 t1 t1 (cI)) pv307
theorem pv297 : R t297 t1 := result (f := t295) (a := t1) (u := t295) (v := t303) (refl t295) (awb t286 t1 t1 t1 (cI)) pv303
theorem pv301 : R t301 t300 := result (f := t297) (a := t300) (u := t1) (v := t300) pv297 (aw (ri t300)) (refl t300)
theorem pv298 : R t298 t300 := result (f := t0) (a := t297) (u := t0) (v := t301) (refl t0) (aw (rh t297)) pv301
theorem pv312 : R t312 t311 := result (f := t297) (a := t311) (u := t1) (v := t311) pv297 (aw (ri t311)) (refl t311)
theorem pv299 : R t299 t311 := result (f := t298) (a := t283) (u := t300) (v := t312) pv298 (aw (ra t297 t283)) pv312
theorem pv296 : R t296 t311 := result (f := t286) (a := t295) (u := t286) (v := t299) (refl t286) (awb t0 t283 t295 t297 (refl _)) pv299
theorem pv290 : R t290 t311 := result (f := t288) (a := t1) (u := t288) (v := t296) (refl t288) (aw (ra t286 t1)) pv296
theorem pv323 : R t323 t1 := result (f := t297) (a := t1) (u := t1) (v := t1) pv297 (aw (ri t1)) (refl t1)
theorem pv324 : R t324 t1 := result (f := t323) (a := t283) (u := t1) (v := t283) pv323 (aw (ri t283)) pv283
theorem pv321 : R t321 t1 := result (f := t290) (a := t1) (u := t311) (v := t324) pv290 (awb t297 t283 t1 t1 (cI)) pv324
theorem pv322 : R t322 t1 := result (f := t321) (a := t1) (u := t1) (v := t1) pv321 (aw (ri t1)) (refl t1)
theorem pv318 : R t318 t1 := result (f := t316) (a := t1) (u := t316) (v := t322) (refl t316) (awb t290 t1 t1 t1 (cI)) pv322
theorem pv319 : R t319 t1 := result (f := t297) (a := t318) (u := t1) (v := t318) pv297 (aw (ri t318)) pv318
theorem pv320 : R t320 t1 := result (f := t319) (a := t283) (u := t1) (v := t283) pv319 (aw (ri t283)) pv283
theorem pv317 : R t317 t1 := result (f := t290) (a := t316) (u := t311) (v := t320) pv290 (awb t297 t283 t316 t318 (refl _)) pv320
theorem pv313 : R t313 t1 := result (f := t293) (a := t1) (u := t293) (v := t317) (refl t293) (aw (ra t290 t1)) pv317
theorem pv314 : R t314 t1 := result (f := t297) (a := t313) (u := t1) (v := t313) pv297 (aw (ri t313)) pv313
theorem pv315 : R t315 t1 := result (f := t314) (a := t283) (u := t1) (v := t283) pv314 (aw (ri t283)) pv283
theorem pv294 : R t294 t1 := result (f := t290) (a := t293) (u := t311) (v := t315) pv290 (awb t297 t283 t293 t313 (refl _)) pv315
theorem pv291 : R t291 t1 := result (f := t0) (a := t290) (u := t0) (v := t294) (refl t0) (aw (rh t290)) pv294
theorem pv292 : R t292 t1 := result (f := t291) (a := t283) (u := t1) (v := t283) pv291 (aw (ri t283)) pv283
theorem pv289 : R t289 t1 := result (f := t286) (a := t288) (u := t286) (v := t292) (refl t286) (awb t0 t283 t288 t290 (refl _)) pv292
theorem pv287 : R t287 t1 := result (f := t0) (a := t286) (u := t0) (v := t289) (refl t0) (aw (rh t286)) pv289
theorem pv284 : R t284 t1 := result (f := t2) (a := t283) (u := t2) (v := t287) (refl t2) (aw (ra t0 t283)) pv287
theorem pv285 : R t285 t1 := result (f := t284) (a := t1) (u := t1) (v := t1) pv284 (aw (ri t1)) (refl t1)
theorem pv282 : R t282 t1 := result (f := t245) (a := t281) (u := t232) (v := t285) pv245 (awb t2 t1 t281 t283 (refl _)) pv285
end Blc.H44.Pump
