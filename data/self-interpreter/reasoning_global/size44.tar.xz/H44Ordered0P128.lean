import H44Ordered0P96
namespace Blc.H44Chain
open Term SelfintControl SelfintLowerBound ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
theorem oh0_128 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 2) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_112 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_129 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 2) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_114 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_130 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 2) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_116 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_131 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 2) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_118 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_132 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_128 (push 0 ρ) rfl a0 a1)
    · exact (oh0_129 (push 1 ρ) rfl a0 a1)
    · exact (oh0_130 (push 2 ρ) rfl a0 a1)
    · exact (oh0_131 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_133 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_37 ρ a1) (oh0_132 ρ a0 a1) (by decide : opm0 3 3 = 3)
theorem oh0_134 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 3) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_112 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_135 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 3) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_114 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_136 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 3) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_116 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_137 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 3) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_118 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_138 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_134 (push 0 ρ) rfl a0 a1)
    · exact (oh0_135 (push 1 ρ) rfl a0 a1)
    · exact (oh0_136 (push 2 ρ) rfl a0 a1)
    · exact (oh0_137 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_139 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_37 ρ a1) (oh0_138 ρ a0 a1) (by decide : opm0 3 3 = 3)
theorem oh0_140 (ρ : Env 3) (a0 : ρ 0 = 3) : eval gm0 ρ ob0_11 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_10) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_10) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_121 (push 0 ρ) rfl a0)
    · exact (oh0_127 (push 1 ρ) rfl a0)
    · exact (oh0_133 (push 2 ρ) rfl a0)
    · exact (oh0_139 (push 3 ρ) rfl a0)
  rw [h]
  decide
theorem oh0_141 (ρ : Env 3) (a0 : ρ 0 = 3) : eval gm0 ρ ob0_12 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_11) (oh0_6 ρ a0) (oh0_140 ρ a0) (by decide : opm0 3 3 = 3)
theorem oh0_142 (ρ : Env 3)  : eval gm0 ρ ob0_13 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_12) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_12) = (fun a : Fin 4 => if a = 0 then 0 else if a = 1 then 2 else if a = 2 then 2 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_45 (push 0 ρ) rfl)
    · exact (oh0_77 (push 1 ρ) rfl)
    · exact (oh0_109 (push 2 ρ) rfl)
    · exact (oh0_141 (push 3 ρ) rfl)
  rw [h]
  decide
theorem oh0_143 (ρ : Env 3)  : eval gm0 ρ ob0_14 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_2) (a := ob0_13) (oh0_8 ρ) (oh0_142 ρ) (by decide : opm0 1 1 = 2)
end Blc.H44Chain
