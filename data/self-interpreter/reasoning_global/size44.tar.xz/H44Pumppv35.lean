import H44Pumppv34
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2606 : R t2606 t1 := result (f := t2605) (a := t2369) (u := t1) (v := t2369) pv2605 (aw (ri t2369)) pv2369
theorem pv2603 : R t2603 t1 := result (f := t2376) (a := t1) (u := t2593) (v := t2606) pv2376 (awb t2383 t2369 t1 t1 (cI)) pv2606
theorem pv2604 : R t2604 t1 := result (f := t2603) (a := t1) (u := t1) (v := t1) pv2603 (aw (ri t1)) (refl t1)
theorem pv2600 : R t2600 t1 := result (f := t2598) (a := t1) (u := t2598) (v := t2604) (refl t2598) (awb t2376 t1 t1 t1 (cI)) pv2604
theorem pv2601 : R t2601 t1 := result (f := t2383) (a := t2600) (u := t1) (v := t2600) pv2383 (aw (ri t2600)) pv2600
theorem pv2602 : R t2602 t1 := result (f := t2601) (a := t2369) (u := t1) (v := t2369) pv2601 (aw (ri t2369)) pv2369
theorem pv2599 : R t2599 t1 := result (f := t2376) (a := t2598) (u := t2593) (v := t2602) pv2376 (awb t2383 t2369 t2598 t2600 (refl _)) pv2602
theorem pv2595 : R t2595 t1 := result (f := t2379) (a := t1) (u := t2379) (v := t2599) (refl t2379) (aw (ra t2376 t1)) pv2599
theorem pv2596 : R t2596 t1 := result (f := t2383) (a := t2595) (u := t1) (v := t2595) pv2383 (aw (ri t2595)) pv2595
theorem pv2597 : R t2597 t1 := result (f := t2596) (a := t2369) (u := t1) (v := t2369) pv2596 (aw (ri t2369)) pv2369
theorem pv2380 : R t2380 t1 := result (f := t2376) (a := t2379) (u := t2593) (v := t2597) pv2376 (awb t2383 t2369 t2379 t2595 (refl _)) pv2597
theorem pv2377 : R t2377 t1 := result (f := t0) (a := t2376) (u := t0) (v := t2380) (refl t0) (aw (rh t2376)) pv2380
theorem pv2378 : R t2378 t1 := result (f := t2377) (a := t2369) (u := t1) (v := t2369) pv2377 (aw (ri t2369)) pv2369
theorem pv2375 : R t2375 t1 := result (f := t2372) (a := t2374) (u := t2372) (v := t2378) (refl t2372) (awb t0 t2369 t2374 t2376 (refl _)) pv2378
theorem pv2373 : R t2373 t1 := result (f := t0) (a := t2372) (u := t0) (v := t2375) (refl t0) (aw (rh t2372)) pv2375
theorem pv2370 : R t2370 t1 := result (f := t2) (a := t2369) (u := t2) (v := t2373) (refl t2) (aw (ra t0 t2369)) pv2373
theorem pv2371 : R t2371 t1 := result (f := t2370) (a := t2315) (u := t1) (v := t2315) pv2370 (aw (ri t2315)) pv2315
theorem pv2368 : R t2368 t1 := result (f := t2331) (a := t2367) (u := t2318) (v := t2371) pv2331 (awb t2 t2315 t2367 t2369 (refl _)) pv2371
theorem pv2342 : R t2342 t1 := result (f := t2334) (a := t1) (u := t2334) (v := t2368) (refl t2334) (aw (ra t2331 t1)) pv2368
theorem pv2366 : R t2366 t1 := result (f := t28) (a := t2342) (u := t1) (v := t2342) pv28 (aw (ri t2342)) pv2342
theorem pv2362 : R t2362 t1 := result (f := t2361) (a := t1) (u := t2364) (v := t2366) pv2361 (awb t1 t2342 t1 t1 (cI)) pv2366
theorem pv2356 : R t2356 t1 := result (f := t2354) (a := t1) (u := t2354) (v := t2362) (refl t2354) (awb t2345 t1 t1 t1 (cI)) pv2362
theorem pv2360 : R t2360 t2359 := result (f := t2356) (a := t2359) (u := t1) (v := t2359) pv2356 (aw (ri t2359)) (refl t2359)
theorem pv2357 : R t2357 t2359 := result (f := t0) (a := t2356) (u := t0) (v := t2360) (refl t0) (aw (rh t2356)) pv2360
theorem pv2608 : R t2608 t2607 := result (f := t2356) (a := t2607) (u := t1) (v := t2607) pv2356 (aw (ri t2607)) (refl t2607)
theorem pv2358 : R t2358 t2607 := result (f := t2357) (a := t2342) (u := t2359) (v := t2608) pv2357 (aw (ra t2356 t2342)) pv2608
theorem pv2355 : R t2355 t2607 := result (f := t2345) (a := t2354) (u := t2345) (v := t2358) (refl t2345) (awb t0 t2342 t2354 t2356 (refl _)) pv2358
theorem pv2349 : R t2349 t2607 := result (f := t2347) (a := t1) (u := t2347) (v := t2355) (refl t2347) (aw (ra t2345 t1)) pv2355
theorem pv2619 : R t2619 t1 := result (f := t2356) (a := t1) (u := t1) (v := t1) pv2356 (aw (ri t1)) (refl t1)
theorem pv2620 : R t2620 t1 := result (f := t2619) (a := t2342) (u := t1) (v := t2342) pv2619 (aw (ri t2342)) pv2342
theorem pv2617 : R t2617 t1 := result (f := t2349) (a := t1) (u := t2607) (v := t2620) pv2349 (awb t2356 t2342 t1 t1 (cI)) pv2620
theorem pv2618 : R t2618 t1 := result (f := t2617) (a := t1) (u := t1) (v := t1) pv2617 (aw (ri t1)) (refl t1)
theorem pv2614 : R t2614 t1 := result (f := t2612) (a := t1) (u := t2612) (v := t2618) (refl t2612) (awb t2349 t1 t1 t1 (cI)) pv2618
theorem pv2615 : R t2615 t1 := result (f := t2356) (a := t2614) (u := t1) (v := t2614) pv2356 (aw (ri t2614)) pv2614
theorem pv2616 : R t2616 t1 := result (f := t2615) (a := t2342) (u := t1) (v := t2342) pv2615 (aw (ri t2342)) pv2342
theorem pv2613 : R t2613 t1 := result (f := t2349) (a := t2612) (u := t2607) (v := t2616) pv2349 (awb t2356 t2342 t2612 t2614 (refl _)) pv2616
theorem pv2609 : R t2609 t1 := result (f := t2352) (a := t1) (u := t2352) (v := t2613) (refl t2352) (aw (ra t2349 t1)) pv2613
theorem pv2610 : R t2610 t1 := result (f := t2356) (a := t2609) (u := t1) (v := t2609) pv2356 (aw (ri t2609)) pv2609
theorem pv2611 : R t2611 t1 := result (f := t2610) (a := t2342) (u := t1) (v := t2342) pv2610 (aw (ri t2342)) pv2342
theorem pv2353 : R t2353 t1 := result (f := t2349) (a := t2352) (u := t2607) (v := t2611) pv2349 (awb t2356 t2342 t2352 t2609 (refl _)) pv2611
theorem pv2350 : R t2350 t1 := result (f := t0) (a := t2349) (u := t0) (v := t2353) (refl t0) (aw (rh t2349)) pv2353
theorem pv2351 : R t2351 t1 := result (f := t2350) (a := t2342) (u := t1) (v := t2342) pv2350 (aw (ri t2342)) pv2342
theorem pv2348 : R t2348 t1 := result (f := t2345) (a := t2347) (u := t2345) (v := t2351) (refl t2345) (awb t0 t2342 t2347 t2349 (refl _)) pv2351
theorem pv2346 : R t2346 t1 := result (f := t0) (a := t2345) (u := t0) (v := t2348) (refl t0) (aw (rh t2345)) pv2348
theorem pv2343 : R t2343 t1 := result (f := t2) (a := t2342) (u := t2) (v := t2346) (refl t2) (aw (ra t0 t2342)) pv2346
theorem pv2344 : R t2344 t1 := result (f := t2343) (a := t2315) (u := t1) (v := t2315) pv2343 (aw (ri t2315)) pv2315
theorem pv2335 : R t2335 t1 := result (f := t2331) (a := t2334) (u := t2318) (v := t2344) pv2331 (awb t2 t2315 t2334 t2342 (refl _)) pv2344
theorem pv2332 : R t2332 t1 := result (f := t0) (a := t2331) (u := t0) (v := t2335) (refl t0) (aw (rh t2331)) pv2335
theorem pv2333 : R t2333 t2318 := result (f := t2332) (a := t2318) (u := t1) (v := t2318) pv2332 (aw (ri t2318)) (refl t2318)
theorem pv2330 : R t2330 t2318 := result (f := t2320) (a := t2329) (u := t2320) (v := t2333) (refl t2320) (awb t0 t2318 t2329 t2331 (refl _)) pv2333
theorem pv2324 : R t2324 t2318 := result (f := t2322) (a := t1) (u := t2322) (v := t2330) (refl t2322) (aw (ra t2320 t1)) pv2330
theorem pv2644 : R t2644 t2643 := result (f := t1) (a := t2643) (u := t1) (v := t2643) (refl t1) (aw (ri t2643)) (refl t2643)
theorem pv2642 : R t2642 t2643 := result (f := t22) (a := t2621) (u := t24) (v := t2644) pv22 (aw (ra t1 t2621)) pv2644
theorem pv2640 : R t2640 t2643 := result (f := t2624) (a := t1) (u := t2624) (v := t2642) (refl t2624) (awb t0 t2621 t1 t1 (cI)) pv2642
theorem pv2671 : R t2671 t2670 := result (f := t1) (a := t2670) (u := t1) (v := t2670) (refl t1) (aw (ri t2670)) (refl t2670)
end Blc.H44.Pump
