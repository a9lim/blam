import H44F4846363332110Proof3
import H44Literals
import H44Clocks
namespace Blc.H44.H44F4846363332110
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
def env : Env := Types.cons s0 (Types.cons s0 Types.empty)
theorem excluded : ¬ IsSelfInterpreter e4846363332110 := by
  intro he
  have hp : replay [] e4846363332110 = some b14 := by decide
  obtain ⟨_,hc⟩ := clocks_replay (rawCount he) hp
  exact Types.noClock (m := tab) ((h117 Types.empty) 0 mem25) (by decide) hc
#print axioms excluded
end Blc.H44.H44F4846363332110
