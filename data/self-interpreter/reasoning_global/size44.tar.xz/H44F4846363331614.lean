import H44F4846363331614Proof2
import H44Literals
import H44Clocks
namespace Blc.H44.H44F4846363331614
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
def env : Env := Types.cons s0 (Types.cons s0 Types.empty)
theorem excluded : ¬ IsSelfInterpreter e4846363331614 := by
  intro he
  have hp : replay [] (.app e4846363331614 diag) = some b16 := by decide
  obtain ⟨_,hc⟩ := clocks_replay (diagCount he) hp
  exact Types.noClock (m := tab) ((h74 Types.empty) 0 mem22) (by decide) hc
#print axioms excluded
end Blc.H44.H44F4846363331614
