import H44PumpCycle
import H44Literals
namespace Blc.H44.Pump
open Term SelfintSharp SelfintControl SelfintLowerBound WeakHeadClock
theorem excluded : ¬ IsSelfInterpreter Blc.H44.e4846363276054 := by
  intro he
  obtain ⟨n,h⟩ := rawCount he
  have w : weakStep Blc.H44.e4846363276054 = some (den t44) := by decide
  obtain ⟨m,_,hm⟩ := head_decreases h w
  exact neverRoot m hm
#print axioms excluded
end Blc.H44.Pump
