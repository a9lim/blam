"""Rebuild three traversals independently of the recorded inventory and replay actual contractions."""
from inventory import *
with tempfile.TemporaryDirectory(dir=BASE) as tmp:
    d=Path(tmp)
    generate(d)
    for name,_,_,filename in JOBS:
        for file in (filename,name+'-counts.txt'):
            assert digest(d/file)==digest(BASE/file),file
    subprocess.run([sys.executable,'-B','independent.py'],cwd=BASE,check=True,timeout=550)
    audit=subprocess.check_output([sys.executable,'-B','audit_compare.py','audit-wires.txt','wires.txt'],cwd=BASE,timeout=550)
    assert audit==(BASE/'audit-comparison.txt').read_bytes()
    print(audit.decode().strip())
