import H44Pumppv96
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6864 : R t6864 t6866 := result (f := t0) (a := t6863) (u := t0) (v := t6867) (refl t0) (aw (rh t6863)) pv6867
theorem pv6918 : R t6918 t6917 := result (f := t6863) (a := t6917) (u := t1) (v := t6917) pv6863 (aw (ri t6917)) (refl t6917)
theorem pv6865 : R t6865 t6917 := result (f := t6864) (a := t6849) (u := t6866) (v := t6918) pv6864 (aw (ra t6863 t6849)) pv6918
theorem pv6862 : R t6862 t6917 := result (f := t6852) (a := t6861) (u := t6852) (v := t6865) (refl t6852) (awb t0 t6849 t6861 t6863 (refl _)) pv6865
theorem pv6856 : R t6856 t6917 := result (f := t6854) (a := t1) (u := t6854) (v := t6862) (refl t6854) (aw (ra t6852 t1)) pv6862
theorem pv6929 : R t6929 t1 := result (f := t6863) (a := t1) (u := t1) (v := t1) pv6863 (aw (ri t1)) (refl t1)
theorem pv6930 : R t6930 t1 := result (f := t6929) (a := t6849) (u := t1) (v := t6849) pv6929 (aw (ri t6849)) pv6849
theorem pv6927 : R t6927 t1 := result (f := t6856) (a := t1) (u := t6917) (v := t6930) pv6856 (awb t6863 t6849 t1 t1 (cI)) pv6930
theorem pv6928 : R t6928 t1 := result (f := t6927) (a := t1) (u := t1) (v := t1) pv6927 (aw (ri t1)) (refl t1)
theorem pv6924 : R t6924 t1 := result (f := t6922) (a := t1) (u := t6922) (v := t6928) (refl t6922) (awb t6856 t1 t1 t1 (cI)) pv6928
theorem pv6925 : R t6925 t1 := result (f := t6863) (a := t6924) (u := t1) (v := t6924) pv6863 (aw (ri t6924)) pv6924
theorem pv6926 : R t6926 t1 := result (f := t6925) (a := t6849) (u := t1) (v := t6849) pv6925 (aw (ri t6849)) pv6849
theorem pv6923 : R t6923 t1 := result (f := t6856) (a := t6922) (u := t6917) (v := t6926) pv6856 (awb t6863 t6849 t6922 t6924 (refl _)) pv6926
theorem pv6919 : R t6919 t1 := result (f := t6859) (a := t1) (u := t6859) (v := t6923) (refl t6859) (aw (ra t6856 t1)) pv6923
theorem pv6920 : R t6920 t1 := result (f := t6863) (a := t6919) (u := t1) (v := t6919) pv6863 (aw (ri t6919)) pv6919
theorem pv6921 : R t6921 t1 := result (f := t6920) (a := t6849) (u := t1) (v := t6849) pv6920 (aw (ri t6849)) pv6849
theorem pv6860 : R t6860 t1 := result (f := t6856) (a := t6859) (u := t6917) (v := t6921) pv6856 (awb t6863 t6849 t6859 t6919 (refl _)) pv6921
theorem pv6857 : R t6857 t1 := result (f := t0) (a := t6856) (u := t0) (v := t6860) (refl t0) (aw (rh t6856)) pv6860
theorem pv6858 : R t6858 t1 := result (f := t6857) (a := t6849) (u := t1) (v := t6849) pv6857 (aw (ri t6849)) pv6849
theorem pv6855 : R t6855 t1 := result (f := t6852) (a := t6854) (u := t6852) (v := t6858) (refl t6852) (awb t0 t6849 t6854 t6856 (refl _)) pv6858
theorem pv6853 : R t6853 t1 := result (f := t0) (a := t6852) (u := t0) (v := t6855) (refl t0) (aw (rh t6852)) pv6855
theorem pv6850 : R t6850 t1 := result (f := t2) (a := t6849) (u := t2) (v := t6853) (refl t2) (aw (ra t0 t6849)) pv6853
theorem pv6851 : R t6851 t1 := result (f := t6850) (a := t6543) (u := t1) (v := t6543) pv6850 (aw (ri t6543)) pv6543
theorem pv6556 : R t6556 t1 := result (f := t6552) (a := t6555) (u := t6546) (v := t6851) pv6552 (awb t2 t6543 t6555 t6849 (refl _)) pv6851
theorem pv6553 : R t6553 t1 := result (f := t0) (a := t6552) (u := t0) (v := t6556) (refl t0) (aw (rh t6552)) pv6556
theorem pv6554 : R t6554 t6546 := result (f := t6553) (a := t6546) (u := t1) (v := t6546) pv6553 (aw (ri t6546)) (refl t6546)
theorem pv6551 : R t6551 t6546 := result (f := t6548) (a := t6550) (u := t6548) (v := t6554) (refl t6548) (awb t0 t6546 t6550 t6552 (refl _)) pv6554
theorem pv6549 : R t6549 t6546 := result (f := t0) (a := t6548) (u := t0) (v := t6551) (refl t0) (aw (rh t6548)) pv6551
theorem pv6547 : R t6547 t6546 := result (f := t2) (a := t6546) (u := t2) (v := t6549) (refl t2) (aw (ra t0 t6546)) pv6549
theorem pv6544 : R t6544 t6546 := result (f := t59) (a := t6543) (u := t46) (v := t6547) pv59 (aw (ra t2 t6543)) pv6547
theorem pv6545 : R t6545 t1 := result (f := t6544) (a := t1) (u := t6546) (v := t6624) pv6544 (awb t2 t6543 t1 t1 (cI)) pv6624
theorem pv6533 : R t6533 t1 := result (f := t6529) (a := t6532) (u := t149) (v := t6545) pv6529 (awb t59 t1 t6532 t6543 (refl _)) pv6545
theorem pv6530 : R t6530 t1 := result (f := t0) (a := t6529) (u := t0) (v := t6533) (refl t0) (aw (rh t6529)) pv6533
theorem pv6531 : R t6531 t149 := result (f := t6530) (a := t6515) (u := t1) (v := t6515) pv6530 (aw (ri t6515)) pv6515
theorem pv6528 : R t6528 t149 := result (f := t6518) (a := t6527) (u := t6518) (v := t6531) (refl t6518) (awb t0 t6515 t6527 t6529 (refl _)) pv6531
theorem pv6522 : R t6522 t149 := result (f := t6520) (a := t1) (u := t6520) (v := t6528) (refl t6520) (aw (ra t6518 t1)) pv6528
theorem pv6956 : R t6956 t6955 := result (f := t1) (a := t6955) (u := t1) (v := t6955) (refl t1) (aw (ri t6955)) (refl t6955)
theorem pv6954 : R t6954 t6955 := result (f := t22) (a := t6934) (u := t24) (v := t6956) pv22 (aw (ra t1 t6934)) pv6956
theorem pv6952 : R t6952 t6955 := result (f := t6936) (a := t1) (u := t6936) (v := t6954) (refl t6936) (awb t0 t6934 t1 t1 (cI)) pv6954
theorem pv6957 : R t6957 t6934 := result (f := t28) (a := t6934) (u := t1) (v := t6934) pv28 (aw (ri t6934)) (refl t6934)
theorem pv6953 : R t6953 t6934 := result (f := t6952) (a := t1) (u := t6955) (v := t6957) pv6952 (awb t1 t6934 t1 t1 (cI)) pv6957
theorem pv6947 : R t6947 t6934 := result (f := t6945) (a := t1) (u := t6945) (v := t6953) (refl t6945) (awb t6936 t1 t1 t1 (cI)) pv6953
theorem pv6981 : R t6981 t6980 := result (f := t1) (a := t6980) (u := t1) (v := t6980) (refl t1) (aw (ri t6980)) (refl t6980)
theorem pv6979 : R t6979 t6980 := result (f := t22) (a := t6958) (u := t24) (v := t6981) pv22 (aw (ra t1 t6958)) pv6981
theorem pv6977 : R t6977 t6980 := result (f := t6961) (a := t1) (u := t6961) (v := t6979) (refl t6961) (awb t0 t6958 t1 t1 (cI)) pv6979
theorem pv7008 : R t7008 t7007 := result (f := t1) (a := t7007) (u := t1) (v := t7007) (refl t1) (aw (ri t7007)) (refl t7007)
theorem pv7006 : R t7006 t7007 := result (f := t22) (a := t6985) (u := t24) (v := t7008) pv22 (aw (ra t1 t6985)) pv7008
theorem pv7004 : R t7004 t7007 := result (f := t6988) (a := t1) (u := t6988) (v := t7006) (refl t6988) (awb t0 t6985 t1 t1 (cI)) pv7006
theorem pv7040 : R t7040 t7039 := result (f := t1) (a := t7039) (u := t1) (v := t7039) (refl t1) (aw (ri t7039)) (refl t7039)
theorem pv7038 : R t7038 t7039 := result (f := t22) (a := t7018) (u := t24) (v := t7040) pv22 (aw (ra t1 t7018)) pv7040
theorem pv7036 : R t7036 t7039 := result (f := t7020) (a := t1) (u := t7020) (v := t7038) (refl t7020) (awb t0 t7018 t1 t1 (cI)) pv7038
theorem pv7041 : R t7041 t7018 := result (f := t28) (a := t7018) (u := t1) (v := t7018) pv28 (aw (ri t7018)) (refl t7018)
theorem pv7037 : R t7037 t7018 := result (f := t7036) (a := t1) (u := t7039) (v := t7041) pv7036 (awb t1 t7018 t1 t1 (cI)) pv7041
theorem pv7031 : R t7031 t7018 := result (f := t7029) (a := t1) (u := t7029) (v := t7037) (refl t7029) (awb t7020 t1 t1 t1 (cI)) pv7037
theorem pv7065 : R t7065 t7064 := result (f := t1) (a := t7064) (u := t1) (v := t7064) (refl t1) (aw (ri t7064)) (refl t7064)
end Blc.H44.Pump
