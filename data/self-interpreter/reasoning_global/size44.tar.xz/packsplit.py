from pathlib import Path
import re
base=Path(__file__).resolve().parent
def split(mod,size=2):
    p=base/(mod+'.lean')
    t=p.read_text()
    chunks=t[t.index('theorem ok0'):t.index('theorem allok')].splitlines()
    head=t[:t.index('theorem ok0')]
    tail=t[t.index('theorem allok'):]
    ns='Certgen.'+mod;end='end '+ns+'\n'
    imports='open Blc Blc.Term Blc.Floor44 Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp\n'
    (base/(mod+'Data.lean')).write_text(head+end)
    names=[mod+'Data']
    for i in range(0,len(chunks),size):
        m=mod+'Block'+str(i)
        (base/(m+'.lean')).write_text(f'import {mod}Data\nnamespace {ns}\nset_option maxRecDepth 30000\nset_option maxHeartbeats 12000000\n'+imports+'\n'.join(chunks[i:i+size])+'\n'+end)
        names.append(m)
    p.write_text(''.join('import '+m+'\n' for m in names[1:])+f'namespace {ns}\nset_option maxRecDepth 30000\nset_option maxHeartbeats 12000000\n'+imports+tail)
    return names+[mod]
if __name__=='__main__':
    import sys
    print(' '.join(split(sys.argv[1],int(sys.argv[2]))))
