import H44Literals
import H44Lib0
import H44Lib2
namespace Blc.H44
theorem ex_e4846440683478 : ¬ IsSelfInterpreter e4846440683478 := Lib2.excluded (by decide : Types.has Lib2.tab Lib2.env e4846440683478 3 = true)
#print axioms ex_e4846440683478
theorem ex_e4846440700150 : ¬ IsSelfInterpreter e4846440700150 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846440700150 1 = true)
#print axioms ex_e4846440700150
theorem ex_e4846440708494 : ¬ IsSelfInterpreter e4846440708494 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846440708494 1 = true)
#print axioms ex_e4846440708494
end Blc.H44
