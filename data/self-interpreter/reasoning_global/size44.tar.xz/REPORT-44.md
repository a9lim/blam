# Every exact closed-source BLC self-interpreter has at least 45 bits

Sizes through 43 were excluded by the earlier archived classifications. At size 44 the complete static inventory contains 188,768 wires, of which 153,766 are application-rooted and 35,002 have a literal public lambda. Every row has positive evidence. The kernel proves 179,166 finite predicates and 9,602 complete propositions of the form `¬ Blc.IsSelfInterpreter <literal>`. The global conclusion combines the established floor of 44, the handwritten classification and the finite inventory with those kernel results.

The wire ledger is `ledger.json`. `complete.tsv` names all 9,602 direct proofs, their literal propositions and their transitive axioms. `initial-residuals.tsv` identifies all 3,521 wires left by the first certificate pass and `residuals.tsv` identifies the 75 left after the additional source, rank and machine checks. `Residuals.lean` collects precisely these final 75 into the theorem `Blc.Floor44.residuals_excluded (t : Term) (h : t ∈ Blc.Floor44.residuals) : ¬ Blc.IsSelfInterpreter t`. The independent `Blc.H44` literals are linked to the original batch definitions by 75 axiom-free definitional equalities.

## From an arbitrary 44-bit interpreter to a wire in the inventory

Use the established 44-bit floor and let E be a closed interpreter of size 44. Then E is globally minimum. Every beta reduct of E is closed and interprets. The contract is stable under reduction by confluence. Thus a beta reduct shorter than 44 bits is impossible, including one obtained under an abstraction or inside an operand.

Let L count lambdas, V count variable occurrences and X sum their zero-based de Bruijn indices. A unary/binary syntax tree with V leaves has V−1 applications. Counting the BLC tags and index bits gives 44 = 2L + 4V − 2 + X. The capture-width theorem supplies three distinct variables free relative to one source subterm. Their binders are on a single ancestor chain, and the three occurrence indices cost at least 2+1+0. Hence X≥3. The nonlinear-chain theorem supplies two incomparable binders, each used at least twice. At least one is outside the width chain. Consequently L≥4, V≥6, and E has at least four live binders. Six live binders would need L≥6, V≥8 and X≥3, giving at least 45 bits.

A variable cannot root a closed term. Two leading public lambdas require at least 46 bits by the literal-interface theorem. A single leading lambda λc.B must use c because the rigid continuation occurs in the required identity-source result. Both incomparable nonlinear binders are in B since the root is comparable with every binder. The single-public-binder width theorem requires a subterm of B with three distinct free variables *bound within B*. The pairing projection gives this strengthening when the continuation is specialized to closed Church true. It follows that a literal candidate has at least four live internal binders plus c, hence exactly five live binders at this size. The checker removes c from width masks and tests its occurrence separately.

At each eligible resource triple `enum.cpp` generates all preorder strings with the exact counts of unary nodes, binary nodes and variables. The pending-slot recurrence starts at one and ends at zero for the first time at the last token. This gives a bijection with ordered syntax trees. A lexical binder stack enumerates every variable assignment with indices in [0,depth) and total X. Counting uses by binding-node location detects nonlinearity. Incomparable binders have disjoint preorder intervals. A bottom-up free-binder mask gives the width at every subterm. No ordering of the nonlinear binders relative to the first redex and no normality restriction enter this construction.

For each redex (λx.B) A let k be the number of bound x occurrences, D the sum of their depths measured from B, f the number of free *occurrences* in A, and g the number of occurrences in B bound above x. Substitution removes the four bits of application and abstraction, removes k variables of cost 2 each plus their depths, introduces k copies of A in place of one, increases the free indices in those copies by their insertion depths, and lowers g outside references by one. The resulting wire-length change is (k−1)|A| + (f−1)D − 2k − 4 − g. Reject the source if any change is strictly negative.

## Complete inventory

Both roots are enumerated for every row. The structural column gives the pair, width and public conditions before the contraction filter. The last three columns give the survivors.

| L | V | X | Closed at these resources | Structural | App, 4 live | App, 5 live | Literal, 5 live |
|---:|---:|---:|---:|---:|---:|---:|---:|
|4|6|14|8,414|0|0|0|0|
|4|7|10|1,885,220|0|0|0|0|
|4|8|6|28,258,040|21,520|10,780|0|0|
|5|6|12|899,344|0|0|0|0|
|5|7|8|30,542,972|18,928|5,804|1,080|840|
|5|8|4|113,721,746|381,624|30,024|25,844|21,028|
|6|6|10|12,280,234|2,208|660|0|0|
|6|7|6|139,493,848|385,136|27,012|21,170|7,842|
|7|6|8|59,638,536|50,784|6,168|0|0|
|7|7|4|250,419,904|380,544|4,398|16,334|5,292|
|8|6|6|138,031,750|70,176|4,042|0|0|
|9|6|4|162,853,398|8,568|450|0|0|
|**Total**|||**938,033,406**|**1,319,488**|**89,338**|**64,428**|**35,002**|

The application total is 153,766. Compared with size 40, six new (L,V) cells enter the resource inequalities, namely (4,8), (5,8), (6,7), (7,7), (8,6) and (9,6). The old (4,7) and (5,6) cells have zero survivors at 44. Literal survivors now occur in four cells instead of one. The comparison holds (L,V) fixed because X changes with size.

For a more detailed root comparison, strip the possible public lambda and follow left children to the head of the source application spine. Application roots still have one or two arguments, but 120 now have two arguments and two lambdas on the head abstraction. Beneath a literal public lambda, 252 now have a three-lambda head applied to one argument, 144 have a two-lambda head applied to two, 72 have a one-lambda head applied to three, and 432 have the continuation itself applied to three. These five head profiles were absent at size 40. `root-shapes.tsv` contains every profile at both sizes.

An independent Rust traversal of the entire prefix grammar visited **1,573,331,752** closed 44-bit terms. It computes relative-index once/twice masks. At an application the twice mask includes the intersection of the child once masks. A binder shifts masks and tests bit zero for nonlinearity. A pair is inherited from either child or spans two children containing nonlinear binders. The width mask ignores external public variables. On the resulting 1,319,488 wires independent Python substitution actually contracts every redex needed to test the universal nonshrinking condition. Its survivor set matches the C++ set exactly, including multiplicities on kept rows. All 1,130,720 discarded structural candidates have a shortening contraction.

The independent C audit traverses the entire grammar without assuming the literal-interface filters or the triples. It obtained 70,647,750 wires with the incomparable pair, 3,964,680 also with width three, and **840,144** also with no shortening contraction. Of these, 425,664 start with two lambdas, 37,568 of the remainder have a dead continuation and 188,144 more fail the internal-width requirement. This explains all 651,376 differences. Every application-rooted C survivor matches. The three enumerators and the comparison code are unverified programs. The complete wire-set comparisons are recorded in `audit-comparison.txt` and can be repeated with `recheck_inventory.py`.

## Exact partition by certificate kind

| Ledger kind | Application | Literal | Total | Strength |
|---|---:|---:|---:|---|
| Widentity | 16 | 0 | 16 | complete |
| Wsource | 5,837 | 363 | 6,200 | complete |
| chain | 43,314 | 4,230 | 47,544 | predicate |
| clock | 1 | 0 | 1 | complete |
| identityHead | 5,383 | 431 | 5,814 | predicate |
| lostC | 4 | 0 | 4 | complete |
| machineMismatch | 88 | 2 | 90 | complete |
| ordered | 2 | 0 | 2 | complete |
| payload | 2,609 | 330 | 2,939 | predicate |
| rankdelta | 138 | 20 | 158 | complete |
| rankraw | 590 | 0 | 590 | complete |
| regular | 1,519 | 45 | 1,564 | complete |
| regularRigid | 83 | 1 | 84 | complete |
| shortPublic | 1 | 2 | 3 | complete |
| smaller | 36,144 | 1,542 | 37,686 | predicate |
| soK | 40 | 1 | 41 | complete |
| soraw | 759 | 18 | 777 | complete |
| sourceHead | 14,854 | 22,140 | 36,994 | predicate |
| three | 21,631 | 3,254 | 24,885 | predicate |
| types | 72 | 0 | 72 | complete |
| width | 20,681 | 2,623 | 23,304 | predicate |
| **Total** | **153,766** | **35,002** | **188,768** | |

The first pass found 179,096 finite predicates and 6,151 W/B exclusions. The 3,521 remaining wires yielded 70 more finite predicates, 65 more W/B exclusions, 818 single-object contradictions, 748 rank contradictions, 1,648 selected regular invariants, 90 exact machine observations, seven continuation arguments and 75 final helper proofs. Alternative discoveries can overlap. The ledger counts one proof per wire.

### Implications of the seven finite predicates

Each positive source record replays beta contractions under the exact contextual path. `SelfintSharp.replay_sound` proves the reduction. Every reduct of an interpreter interprets. Removing a chain of leading binders cannot remove an incomparable pair. The Boolean pair test on a remaining application is exact by testing its two subtrees and the cross-child pair. A smaller reduct contradicts the established floor. After three leading lambdas the identity call still has an outer lambda and cannot join its rigid target.

A closed head normal form with one lambda has head c. After applying the public continuation and the identity stream, c has one extra argument from the stream. To match the required arity it must originally have one argument, forcing the nonempty lambda-rooted stream to join its rigid suffix. With two lambdas a continuation-headed form must have exactly two arguments. Closedness rules out a zero-lambda HNF. This justifies the source signature filter.

After removing zero, one or two public binders, the relevant necessary width is three internally bound free variables at some remaining subterm. This uses the global, single-public or two-public form of the width proof respectively. Three or more binders were already impossible. At a variable index i at depth d the width procedure sets its bit only for i<d, combines masks by union at applications and shifts at a lambda. It retains the maximum population over every subterm.

For identity-source checks use independent rigid variables C and R. The required normal output is C (λz.I) R. A different head signature is invariant under reductions inside its arguments. At the correct head and arity, confluence and rigid spines require each argument to join the corresponding payload. A positively obtained unequal normal form of either argument is a contradiction. Limits on trace discovery are irrelevant to these implications.

### Complete exclusion families

The W/B substitution and head-progress grammar carries over unchanged from size 40. A source in its B class remains in B when the identity arguments are appended. A B identity reduct directly violates the required normal form. The original weighted-rank proof also carries over unchanged. A positive closed guarded term of rank zero has no finite weak-head clock. The source must have one by projection from its identity call. The Δ partial application must have one because the exact contract admits a solvable extension. The checking proofs replay their finite prefixes. The size-40 swap-parity theorem is not used here.

`Blc.Floor44.Plan.sound` in `More.lean` certifies the bottom-up single-object witness tree. Its leaves are variables, application checks both sons, closed and dead abstractions use their respective SO lemmas, and an explicit object slot checks its scoping and capture-avoiding reconstruction. A source reduct contradicts `selfInterpreter_not_so`; a reduct of E Church-true contradicts `specialized_not_so`. Both are repository theorems.

The ordinary regular invariants use the original sound Krivine progress checker. Each abstract value/continuation-store invariant covers an initial state and admits a covered step for every represented state. Administrative steps strictly reduce closure rank; a computational step strictly reduces any finite weak clock. This proves that the selected solvable probe cannot have such a clock. The probe's solvability follows from its actual target `want`, under the public contract and any appended arguments. Search can select the allocation policy, source, and beta prefix; the kernel checks the final allocation-independent finite invariant. Packed state tables use bounded-index lookup to keep the proof modules small. Opaque subterms have their actual syntax in the structural model.

The new `Safe.rejects` also admits a terminal abstraction on an empty stack. The probe is chosen to be beta-joinable to a rigid target. A state ending in a lambda cannot satisfy this obligation. At the other represented states the same verified successor and descending-clock argument applies, preserving the join. This allows finite lambda stops in a proof excluding a required rigid result. `SafePacked.excludes` connects its packed checker to this theorem. These results do not assert that every such machine diverges.

`Concrete.reject` checks finite head observations without materializing expanded substitution trees. Its deterministic closure machine has three operations: variable lookup, argument push, and lambda pop. The first two preserve the denoted term and the last is a weak beta step. At an observed lambda or rigid variable, its environment length and stack length give the exact head index and arity. Two beta-joinable terms cannot have contradictory observations. Each selected wire has an explicit source, continuation, remainder, argument list and finite runs on both sides of the contract.

`Alt.lost` uses a closed reduct of E applied to the generic continuation variable. Supplying a closed identity stream gives a closed term; its reducts cannot equal the required normal result with a free continuation. `Alt.shorter` checks that E and a smaller closed F have beta-joinable partial applications to the literal continuation variable of the contract. Congruence under application to the same encoded stream and transitivity of join transfer the whole interpreter contract to F. All three selected comparison functions have exactly 37 bits. Each proof invokes the kernel theorem `Blc.SelfintSingleObject.selfintSizeBound_38` and directly excludes the 44-bit literal.

### The final 75 application roots

For each successful wire `w`, let `N` be its unsigned binary value. The independently constructed de Bruijn term is `Blc.H44.eN`. In `H44Literals.lean`, `wire_eN` proves that it is closed and that folding its BLC bits from the initial numeral 1 gives the numeral represented by the bitstring `1w`. The initial 1 preserves leading zeros. The individual row module proves `Blc.H44.ex_eN : ¬ Blc.IsSelfInterpreter Blc.H44.eN`. In `H44Bridge.lean`, `Blc.Floor44.Help44.same_eN` proves by reflexivity that this term equals the originating batch’s `Blc.Floor44.eN`. The bridge then exports `Blc.Floor44.Help44.ex_eN : ¬ Blc.IsSelfInterpreter Blc.Floor44.eN`. The equality needs no axiom. No smaller-size premise occurs in any row.

| Proof source | Wires | What the kernel verified |
|---|---:|---|
| Existing recursive intersection-arrow rules | 59 | The source has the required type in a previously proved generic rule. Of the 25 rules, Lib0 covers 43, Lib1 covers eight, Lib4 covers four, and Lib2, Lib3, Lib7 and Lib15 each cover one. |
| New generic recursive intersection-arrow rules | 5 | Lib100, Lib101 and Lib102 cover one, three and one respectively. Each table gives a generic contract contradiction, and the source term satisfies its premise. |
| Individual six-arrow derivation | 1 | The closed source has bottom type, which precludes the weak-head clock required of an interpreter. |
| Intersection-arrow derivations extracted from call-by-name flow | 7 | Four ordinary finite analyses, two analyses tracking a color of each argument and one analysis keeping exact closures produced finite positive derivations. The proofs check each variable, abstraction, application and required type inclusion. |
| Closed macro reductions and a descending weak-head clock | 1 | The 11-edge cycle and the path from the literal rule out the clock required of an interpreter. |
| Finite ordered application algebra | 2 | A four-grade table violates the contract inequality. One proof acts directly on the literal and one first takes an explicit beta reduction. |

**Recursive typing.** A finite table gives each arrow its domain and codomain as sets of types. Mutual references are permitted. The `Types.preserved` and `Types.star` theorems preserve positive grading along ordinary beta reduction. For the generic rules, a positive grading of the checked contract source cannot survive in the normal target at that grade. The interpreter contract requires the two sides to join. The individual derivations either prevent joining the rigid target or give bottom grade on a closed term that the interpreter contract requires to have a weak-head clock. The exploratory flow evaluator, type synthesizer and its quotient of equivalent arrows only propose finite derivations. They do not enter any final proof.

**Ordered semantics.** The application table is monotone and the lambda grade is the least row that bounds the graded body for every possible argument. Subject reduction bounds the grade of a normal result by the source grade. Both certificates use the four-grade table with rows `0000`, `2233`, `2233`, `3333`. The kernel checks the required evaluations for the quotation, continuation, source and normal target. For the second wire it also checks the contraction path and preservation of self-interpretation under those contractions.

### The clock cycle

The last wire is `01000110100001100001110000101111001100010110`, decimal `4846363276054`, from `Batch1156.lean`. Its literal is `(λa.a a) H`, with `H = λa.a (λb.a (λc.a (c I) b))` and `I = λx.x`. Its first weak-head contraction gives `H H`.

Put `A(x) = λy.x (λz.x (z I) y)` and `B(x,y) = λz.x (z I) y` for closed operands. The checked head rules send `H u` to `u A(u)`, `A(x) u` to `x B(x,u)`, `B(x,y) u` to `x (u I) y`, and `I u` to `u`. The 32 positive beta summaries used by `H44PumpAnchor.lean` prove `A(H) I →* I`. Consequently `B(A(H),y) I →* y` for every closed macro operand y, by reducing first to `A(H) (I I) y`, then to `I y`. This simplification exposes the recurrent demanded application.

The certificate contains 10,003 shared syntax nodes and 7,810 further positive beta summaries. Each summary composes reductions of the function, a concrete weak-head contraction, and reductions of the result. The 36 demand edges start at `H H`. Edge 25 starts an 11-edge cycle with eight strict decreases. Demanding the function of an application cannot increase its weak-head clock. Contracting the exposed head redex strictly decreases that clock, and subsequent beta reductions cannot increase it. Strong induction on the natural-valued clock rules out the cycle. The 25 preceding edges transfer this contradiction back to `H H`. The interpreter contract requires a weak-head clock at the original literal, so `Blc.H44.Pump.excluded` follows. `H44PumpBase.lean` proves the rule semantics and clock comparisons, and `H44PumpCycle.lean` checks the cycle inequalities. The finite call-by-need search found the demanded calls. Every positive reduction and every demand edge used in the proof is checked in Lean.


## Reproduction and trust

From the repository root, run `python3 data/self-interpreter/reasoning_global/pack.py pack 44 tmp/global/floor45`, then `python3 data/self-interpreter/reasoning_global/pack.py check 44` with a fresh `tmp/recheck/size44` destination. The archive contains the chart, replay and type witnesses. The slim manifest records SHA-256 hashes for every omitted generated file. Regeneration compiles the three vendored enumerators, renders the certificate sources and derives the ledger and tables. The helper's substantive Lean derivations are retained as proof inputs. Its independently encoded literals and definitional bridge regenerate from the helper manifest and inventory. Regeneration uses only the unpacked files and ordinary system compilers.

1. `recheck_inventory.py` recompiles the C++, Rust and C enumerators in a fresh temporary directory, compares all wire streams and count reports byte-for-byte, checks the C omissions by syntactic reason and explicitly contracts redexes on the Rust structural inventory.
2. `verify_ledger.py` independently decodes each wire, checks scope, resource triple, root, sentinel code, exact term and theorem, and matches the finite proof statement to its replay paths. It also checks the complete, initial-residual and final-residual tables, the independent literals and the collection’s membership list. Regeneration hashes bind the machine chart and path records to their Lean sources.
3. `recheck.py` visits the import closure rooted at every ledger module and `Residuals`, builds each local source into a new empty object directory and audits every complete theorem's transitive axioms. Each invocation uses the pinned Lean toolchain and repository library, `-j2 -M 900`, four concurrent processes at most, a 985,000,000-byte RSS cutoff and a 180-second first-attempt limit. On failure, the scheduler drains the concurrent queue and retries the module alone with the same memory limit and 450 seconds. The check audits all 75 helper literal theorems and their axiom-free bridges as well. `check-metrics.json` in the unpacked directory records wall time, per-process peak RSS, retries and the axioms of the collected theorem.

The unrestricted grammar traversal, contraction comparison, ledger bookkeeping and the implication from each of the seven finite predicates to the semantic obstruction are the non-kernel parts of the global size argument. Every enumerated candidate has a checked closed literal with an exact sentinel-prefixed encoding. Every finite proof uses a positive contextual contraction sequence and every complete proof concludes the literal negation. Search bounds contribute zero exclusions. The permitted axioms are `propext`, `Classical.choice` and `Quot.sound`. The coordinator separately reported agreement from an independent enumeration of all 188,768 wires and a separate reducer for the 179,096 first-pass finite certificates.
