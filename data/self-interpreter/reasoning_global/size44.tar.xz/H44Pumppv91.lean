import H44Pumppv90
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6395 : R t6395 t6397 := result (f := t0) (a := t6394) (u := t0) (v := t6398) (refl t0) (aw (rh t6394)) pv6398
theorem pv6449 : R t6449 t6448 := result (f := t6394) (a := t6448) (u := t1) (v := t6448) pv6394 (aw (ri t6448)) (refl t6448)
theorem pv6396 : R t6396 t6448 := result (f := t6395) (a := t6380) (u := t6397) (v := t6449) pv6395 (aw (ra t6394 t6380)) pv6449
theorem pv6393 : R t6393 t6448 := result (f := t6383) (a := t6392) (u := t6383) (v := t6396) (refl t6383) (awb t0 t6380 t6392 t6394 (refl _)) pv6396
theorem pv6387 : R t6387 t6448 := result (f := t6385) (a := t1) (u := t6385) (v := t6393) (refl t6385) (aw (ra t6383 t1)) pv6393
theorem pv6460 : R t6460 t1 := result (f := t6394) (a := t1) (u := t1) (v := t1) pv6394 (aw (ri t1)) (refl t1)
theorem pv6461 : R t6461 t1 := result (f := t6460) (a := t6380) (u := t1) (v := t6380) pv6460 (aw (ri t6380)) pv6380
theorem pv6458 : R t6458 t1 := result (f := t6387) (a := t1) (u := t6448) (v := t6461) pv6387 (awb t6394 t6380 t1 t1 (cI)) pv6461
theorem pv6459 : R t6459 t1 := result (f := t6458) (a := t1) (u := t1) (v := t1) pv6458 (aw (ri t1)) (refl t1)
theorem pv6455 : R t6455 t1 := result (f := t6453) (a := t1) (u := t6453) (v := t6459) (refl t6453) (awb t6387 t1 t1 t1 (cI)) pv6459
theorem pv6456 : R t6456 t1 := result (f := t6394) (a := t6455) (u := t1) (v := t6455) pv6394 (aw (ri t6455)) pv6455
theorem pv6457 : R t6457 t1 := result (f := t6456) (a := t6380) (u := t1) (v := t6380) pv6456 (aw (ri t6380)) pv6380
theorem pv6454 : R t6454 t1 := result (f := t6387) (a := t6453) (u := t6448) (v := t6457) pv6387 (awb t6394 t6380 t6453 t6455 (refl _)) pv6457
theorem pv6450 : R t6450 t1 := result (f := t6390) (a := t1) (u := t6390) (v := t6454) (refl t6390) (aw (ra t6387 t1)) pv6454
theorem pv6451 : R t6451 t1 := result (f := t6394) (a := t6450) (u := t1) (v := t6450) pv6394 (aw (ri t6450)) pv6450
theorem pv6452 : R t6452 t1 := result (f := t6451) (a := t6380) (u := t1) (v := t6380) pv6451 (aw (ri t6380)) pv6380
theorem pv6391 : R t6391 t1 := result (f := t6387) (a := t6390) (u := t6448) (v := t6452) pv6387 (awb t6394 t6380 t6390 t6450 (refl _)) pv6452
theorem pv6388 : R t6388 t1 := result (f := t0) (a := t6387) (u := t0) (v := t6391) (refl t0) (aw (rh t6387)) pv6391
theorem pv6389 : R t6389 t1 := result (f := t6388) (a := t6380) (u := t1) (v := t6380) pv6388 (aw (ri t6380)) pv6380
theorem pv6386 : R t6386 t1 := result (f := t6383) (a := t6385) (u := t6383) (v := t6389) (refl t6383) (awb t0 t6380 t6385 t6387 (refl _)) pv6389
theorem pv6384 : R t6384 t1 := result (f := t0) (a := t6383) (u := t0) (v := t6386) (refl t0) (aw (rh t6383)) pv6386
theorem pv6381 : R t6381 t1 := result (f := t2) (a := t6380) (u := t2) (v := t6384) (refl t2) (aw (ra t0 t6380)) pv6384
theorem pv6382 : R t6382 t1 := result (f := t6381) (a := t6074) (u := t1) (v := t6074) pv6381 (aw (ri t6074)) pv6074
theorem pv6087 : R t6087 t1 := result (f := t6083) (a := t6086) (u := t6077) (v := t6382) pv6083 (awb t2 t6074 t6086 t6380 (refl _)) pv6382
theorem pv6084 : R t6084 t1 := result (f := t0) (a := t6083) (u := t0) (v := t6087) (refl t0) (aw (rh t6083)) pv6087
theorem pv6085 : R t6085 t6077 := result (f := t6084) (a := t6077) (u := t1) (v := t6077) pv6084 (aw (ri t6077)) (refl t6077)
theorem pv6082 : R t6082 t6077 := result (f := t6079) (a := t6081) (u := t6079) (v := t6085) (refl t6079) (awb t0 t6077 t6081 t6083 (refl _)) pv6085
theorem pv6080 : R t6080 t6077 := result (f := t0) (a := t6079) (u := t0) (v := t6082) (refl t0) (aw (rh t6079)) pv6082
theorem pv6078 : R t6078 t6077 := result (f := t2) (a := t6077) (u := t2) (v := t6080) (refl t2) (aw (ra t0 t6077)) pv6080
theorem pv6075 : R t6075 t6077 := result (f := t59) (a := t6074) (u := t46) (v := t6078) pv59 (aw (ra t2 t6074)) pv6078
theorem pv6076 : R t6076 t1 := result (f := t6075) (a := t1) (u := t6077) (v := t6155) pv6075 (awb t2 t6074 t1 t1 (cI)) pv6155
theorem pv105 : R t105 t1 := result (f := t101) (a := t104) (u := t149) (v := t6076) pv101 (awb t59 t1 t104 t6074 (refl _)) pv6076
theorem pv102 : R t102 t1 := result (f := t0) (a := t101) (u := t0) (v := t105) (refl t0) (aw (rh t101)) pv105
theorem pv103 : R t103 t149 := result (f := t102) (a := t94) (u := t1) (v := t94) pv102 (aw (ri t94)) pv94
theorem pv100 : R t100 t149 := result (f := t97) (a := t99) (u := t97) (v := t103) (refl t97) (awb t0 t94 t99 t101 (refl _)) pv103
theorem pv98 : R t98 t149 := result (f := t0) (a := t97) (u := t0) (v := t100) (refl t0) (aw (rh t97)) pv100
theorem pv95 : R t95 t149 := result (f := t2) (a := t94) (u := t2) (v := t98) (refl t2) (aw (ra t0 t94)) pv98
theorem pv6486 : R t6486 t6485 := result (f := t1) (a := t6485) (u := t1) (v := t6485) (refl t1) (aw (ri t6485)) (refl t6485)
theorem pv6484 : R t6484 t6485 := result (f := t22) (a := t6464) (u := t24) (v := t6486) pv22 (aw (ra t1 t6464)) pv6486
theorem pv6482 : R t6482 t6485 := result (f := t6466) (a := t1) (u := t6466) (v := t6484) (refl t6466) (awb t0 t6464 t1 t1 (cI)) pv6484
theorem pv6487 : R t6487 t6464 := result (f := t28) (a := t6464) (u := t1) (v := t6464) pv28 (aw (ri t6464)) (refl t6464)
theorem pv6483 : R t6483 t6464 := result (f := t6482) (a := t1) (u := t6485) (v := t6487) pv6482 (awb t1 t6464 t1 t1 (cI)) pv6487
theorem pv6477 : R t6477 t6464 := result (f := t6475) (a := t1) (u := t6475) (v := t6483) (refl t6475) (awb t6466 t1 t1 t1 (cI)) pv6483
theorem pv6511 : R t6511 t6510 := result (f := t1) (a := t6510) (u := t1) (v := t6510) (refl t1) (aw (ri t6510)) (refl t6510)
theorem pv6509 : R t6509 t6510 := result (f := t22) (a := t6488) (u := t24) (v := t6511) pv22 (aw (ra t1 t6488)) pv6511
theorem pv6507 : R t6507 t6510 := result (f := t6491) (a := t1) (u := t6491) (v := t6509) (refl t6491) (awb t0 t6488 t1 t1 (cI)) pv6509
theorem pv6538 : R t6538 t6537 := result (f := t1) (a := t6537) (u := t1) (v := t6537) (refl t1) (aw (ri t6537)) (refl t6537)
theorem pv6536 : R t6536 t6537 := result (f := t22) (a := t6515) (u := t24) (v := t6538) pv22 (aw (ra t1 t6515)) pv6538
theorem pv6534 : R t6534 t6537 := result (f := t6518) (a := t1) (u := t6518) (v := t6536) (refl t6518) (awb t0 t6515 t1 t1 (cI)) pv6536
theorem pv6542 : R t6542 t151 := result (f := t3) (a := t3935) (u := t1) (v := t3935) pv3 (aw (ri t3935)) pv3935
theorem pv6540 : R t6540 t151 := result (f := t6477) (a := t1) (u := t6464) (v := t6542) pv6477 (awb t2 t3935 t1 t1 (cI)) pv6542
theorem pv6541 : R t6541 t149 := result (f := t6540) (a := t1) (u := t151) (v := t229) pv6540 (awb t2 t149 t1 t1 (cI)) pv229
theorem pv6515 : R t6515 t149 := result (f := t6513) (a := t1) (u := t6513) (v := t6541) (refl t6513) (awb t6477 t1 t1 t1 (cI)) pv6541
theorem pv6539 : R t6539 t149 := result (f := t28) (a := t6515) (u := t1) (v := t6515) pv28 (aw (ri t6515)) pv6515
theorem pv6535 : R t6535 t149 := result (f := t6534) (a := t1) (u := t6537) (v := t6539) pv6534 (awb t1 t6515 t1 t1 (cI)) pv6539
end Blc.H44.Pump
