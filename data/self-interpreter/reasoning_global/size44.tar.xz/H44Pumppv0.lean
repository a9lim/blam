import H44PumpAnchor
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv25 : R t25 t24 := result (f := t1) (a := t24) (u := t1) (v := t24) (refl t1) (aw (ri t24)) (refl t24)
theorem pv22 : R t22 t24 := result (f := t0) (a := t1) (u := t0) (v := t25) (refl t0) (aw (rh t1)) pv25
theorem pv68 : R t68 t67 := result (f := t1) (a := t67) (u := t1) (v := t67) (refl t1) (aw (ri t67)) (refl t67)
theorem pv66 : R t66 t67 := result (f := t22) (a := t46) (u := t24) (v := t68) pv22 (aw (ra t1 t46)) pv68
theorem pv64 : R t64 t67 := result (f := t48) (a := t1) (u := t48) (v := t66) (refl t48) (awb t0 t46 t1 t1 (cI)) pv66
theorem pv28 : R t28 t1 := result (f := t1) (a := t1) (u := t1) (v := t1) (refl t1) (aw (ri t1)) (refl t1)
theorem pv69 : R t69 t46 := result (f := t28) (a := t46) (u := t1) (v := t46) pv28 (aw (ri t46)) (refl t46)
theorem pv65 : R t65 t46 := result (f := t64) (a := t1) (u := t67) (v := t69) pv64 (awb t1 t46 t1 t1 (cI)) pv69
theorem pv59 : R t59 t46 := result (f := t57) (a := t1) (u := t57) (v := t65) (refl t57) (awb t48 t1 t1 t1 (cI)) pv65
theorem pv92 : R t92 t91 := result (f := t1) (a := t91) (u := t1) (v := t91) (refl t1) (aw (ri t91)) (refl t91)
theorem pv90 : R t90 t91 := result (f := t22) (a := t70) (u := t24) (v := t92) pv22 (aw (ra t1 t70)) pv92
theorem pv88 : R t88 t91 := result (f := t72) (a := t1) (u := t72) (v := t90) (refl t72) (awb t0 t70 t1 t1 (cI)) pv90
theorem pv93 : R t93 t70 := result (f := t28) (a := t70) (u := t1) (v := t70) pv28 (aw (ri t70)) (refl t70)
theorem pv89 : R t89 t70 := result (f := t88) (a := t1) (u := t91) (v := t93) pv88 (awb t1 t70 t1 t1 (cI)) pv93
theorem pv83 : R t83 t70 := result (f := t81) (a := t1) (u := t81) (v := t89) (refl t81) (awb t72 t1 t1 t1 (cI)) pv89
theorem pv117 : R t117 t116 := result (f := t1) (a := t116) (u := t1) (v := t116) (refl t1) (aw (ri t116)) (refl t116)
theorem pv115 : R t115 t116 := result (f := t22) (a := t94) (u := t24) (v := t117) pv22 (aw (ra t1 t94)) pv117
theorem pv113 : R t113 t116 := result (f := t97) (a := t1) (u := t97) (v := t115) (refl t97) (awb t0 t94 t1 t1 (cI)) pv115
theorem pv144 : R t144 t143 := result (f := t1) (a := t143) (u := t1) (v := t143) (refl t1) (aw (ri t143)) (refl t143)
theorem pv142 : R t142 t143 := result (f := t22) (a := t121) (u := t24) (v := t144) pv22 (aw (ra t1 t121)) pv144
theorem pv140 : R t140 t143 := result (f := t124) (a := t1) (u := t124) (v := t142) (refl t124) (awb t0 t121 t1 t1 (cI)) pv142
theorem pv27 : R t27 t26 := result (f := t1) (a := t26) (u := t1) (v := t26) (refl t1) (aw (ri t26)) (refl t26)
theorem pv23 : R t23 t26 := result (f := t22) (a := t1) (u := t24) (v := t27) pv22 (aw (ra t1 t1)) pv27
theorem pv20 : R t20 t26 := result (f := t4) (a := t1) (u := t4) (v := t23) (refl t4) (awb t0 t1 t1 t1 (cI)) pv23
theorem pv29 : R t29 t1 := result (f := t28) (a := t1) (u := t1) (v := t1) pv28 (aw (ri t1)) (refl t1)
theorem pv21 : R t21 t1 := result (f := t20) (a := t1) (u := t26) (v := t29) pv20 (awb t1 t1 t1 t1 (cI)) pv29
theorem pv15 : R t15 t1 := result (f := t13) (a := t1) (u := t13) (v := t21) (refl t13) (awb t4 t1 t1 t1 (cI)) pv21
theorem pv19 : R t19 t18 := result (f := t15) (a := t18) (u := t1) (v := t18) pv15 (aw (ri t18)) (refl t18)
theorem pv16 : R t16 t18 := result (f := t0) (a := t15) (u := t0) (v := t19) (refl t0) (aw (rh t15)) pv19
theorem pv31 : R t31 t30 := result (f := t15) (a := t30) (u := t1) (v := t30) pv15 (aw (ri t30)) (refl t30)
theorem pv17 : R t17 t30 := result (f := t16) (a := t1) (u := t18) (v := t31) pv16 (aw (ra t15 t1)) pv31
theorem pv14 : R t14 t30 := result (f := t4) (a := t13) (u := t4) (v := t17) (refl t4) (awb t0 t1 t13 t15 (refl _)) pv17
theorem pv8 : R t8 t30 := result (f := t6) (a := t1) (u := t6) (v := t14) (refl t6) (aw (ra t4 t1)) pv14
theorem pv42 : R t42 t1 := result (f := t15) (a := t1) (u := t1) (v := t1) pv15 (aw (ri t1)) (refl t1)
theorem pv43 : R t43 t1 := result (f := t42) (a := t1) (u := t1) (v := t1) pv42 (aw (ri t1)) (refl t1)
theorem pv40 : R t40 t1 := result (f := t8) (a := t1) (u := t30) (v := t43) pv8 (awb t15 t1 t1 t1 (cI)) pv43
theorem pv41 : R t41 t1 := result (f := t40) (a := t1) (u := t1) (v := t1) pv40 (aw (ri t1)) (refl t1)
theorem pv37 : R t37 t1 := result (f := t35) (a := t1) (u := t35) (v := t41) (refl t35) (awb t8 t1 t1 t1 (cI)) pv41
theorem pv38 : R t38 t1 := result (f := t15) (a := t37) (u := t1) (v := t37) pv15 (aw (ri t37)) pv37
theorem pv39 : R t39 t1 := result (f := t38) (a := t1) (u := t1) (v := t1) pv38 (aw (ri t1)) (refl t1)
theorem pv36 : R t36 t1 := result (f := t8) (a := t35) (u := t30) (v := t39) pv8 (awb t15 t1 t35 t37 (refl _)) pv39
theorem pv32 : R t32 t1 := result (f := t11) (a := t1) (u := t11) (v := t36) (refl t11) (aw (ra t8 t1)) pv36
theorem pv33 : R t33 t1 := result (f := t15) (a := t32) (u := t1) (v := t32) pv15 (aw (ri t32)) pv32
theorem pv34 : R t34 t1 := result (f := t33) (a := t1) (u := t1) (v := t1) pv33 (aw (ri t1)) (refl t1)
theorem pv12 : R t12 t1 := result (f := t8) (a := t11) (u := t30) (v := t34) pv8 (awb t15 t1 t11 t32 (refl _)) pv34
theorem pv9 : R t9 t1 := result (f := t0) (a := t8) (u := t0) (v := t12) (refl t0) (aw (rh t8)) pv12
theorem pv10 : R t10 t1 := result (f := t9) (a := t1) (u := t1) (v := t1) pv9 (aw (ri t1)) (refl t1)
theorem pv7 : R t7 t1 := result (f := t4) (a := t6) (u := t4) (v := t10) (refl t4) (awb t0 t1 t6 t8 (refl _)) pv10
theorem pv5 : R t5 t1 := result (f := t0) (a := t4) (u := t0) (v := t7) (refl t0) (aw (rh t4)) pv7
theorem pv3 : R t3 t1 := result (f := t2) (a := t1) (u := t2) (v := t5) (refl t2) (aw (ra t0 t1)) pv5
theorem pv148 : R t148 t62 := result (f := t3) (a := t62) (u := t1) (v := t62) pv3 (aw (ri t62)) (refl t62)
theorem pv146 : R t146 t62 := result (f := t83) (a := t1) (u := t70) (v := t148) pv83 (awb t2 t62 t1 t1 (cI)) pv148
theorem pv173 : R t173 t172 := result (f := t1) (a := t172) (u := t1) (v := t172) (refl t1) (aw (ri t172)) (refl t172)
theorem pv171 : R t171 t172 := result (f := t22) (a := t151) (u := t24) (v := t173) pv22 (aw (ra t1 t151)) pv173
theorem pv169 : R t169 t172 := result (f := t153) (a := t1) (u := t153) (v := t171) (refl t153) (awb t0 t151 t1 t1 (cI)) pv171
end Blc.H44.Pump
