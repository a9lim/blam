import H44F4846201355482Proof7
namespace Blc.H44.H44F4846201355482
open Term SelfintSharp SelfintControl SelfintLowerBound SelfintProbe WeakHeadClock Types Positive
set_option maxRecDepth 20000
theorem h288 (ρ : Env) (a0 : Fits s34 (ρ 0)) : All tab ρ b7 s34 :=
  (consAll (lamAt d2 c2 (smaller (h243 (Types.cons s0 ρ) sub124 a0) sub14)) (consAll (lamAt d36 c36 (smaller (h257 (Types.cons s0 ρ) sub124 a0) sub15)) Positive.none))
theorem h289 (ρ : Env) (a0 : Fits s35 (ρ 0)) : All tab ρ b7 s34 :=
  (consAll (lamAt d2 c2 (smaller (h244 (Types.cons s0 ρ) sub124 a0) sub125)) (consAll (lamAt d36 c36 (smaller (h244 (Types.cons s0 ρ) sub124 a0) sub126)) Positive.none))
theorem h290 (ρ : Env) (a0 : Fits s40 (ρ 0)) : All tab ρ b7 s31 :=
  (consAll (lamAt d36 c36 (smaller (h246 (Types.cons s0 ρ) sub124 a0) sub15)) Positive.none)
theorem h291 (ρ : Env) (a0 : Fits s35 (ρ 0)) : All tab ρ b7 s7 :=
  (consAll (lamAt d2 c2 (smaller (h247 (Types.cons s0 ρ) sub124 a0) sub14)) Positive.none)
theorem h292 (ρ : Env) (a0 : Fits s21 (ρ 0)) : All tab ρ b7 s37 :=
  (consAll (lamAt d52 c52 (smaller (h248 (Types.cons s42 ρ) sub30 a0) sub15)) Positive.none)
theorem h293 (ρ : Env) (a0 : Fits s31 (ρ 0)) : All tab ρ b7 s31 :=
  (consAll (lamAt d36 c36 (smaller (h254 (Types.cons s0 ρ) sub124 a0) sub15)) Positive.none)
theorem h294 (ρ : Env) (a0 : Fits s52 (ρ 0)) : All tab ρ b7 s49 :=
  (consAll (lamAt d38 c38 (smaller (h269 (Types.cons s7 ρ) sub15 a0) sub11)) (consAll (lamAt d62 c62 (smaller (h272 (Types.cons s7 ρ) sub15 a0) sub23)) (consAll (lamAt d75 c75 (smaller (h258 (Types.cons s51 ρ) sub62 a0) sub120)) (consAll (lamAt d86 c86 (smaller (h263 (Types.cons s59 ρ) sub66 a0) sub105)) (consAll (lamAt d93 c93 (smaller (h265 (Types.cons s7 ρ) sub15 a0) sub35)) Positive.none)))))
theorem h295 (ρ : Env) (a0 : Fits s53 (ρ 0)) : All tab ρ b7 s69 :=
  (consAll (lamAt d74 c74 (smaller (h259 (Types.cons s50 ρ) sub64 a0) sub27)) Positive.none)
theorem h296 (ρ : Env) (a0 : Fits s55 (ρ 0)) : All tab ρ b7 s43 :=
  (consAll (lamAt d67 c67 (smaller (h260 (Types.cons s12 ρ) sub28 a0) sub11)) Positive.none)
theorem h297 (ρ : Env) (a0 : Fits s58 (ρ 0)) : All tab ρ b7 s55 :=
  (consAll (lamAt d35 c35 (smaller (h270 (Types.cons s31 ρ) sub11 a0) sub15)) (consAll (lamAt d66 c66 (smaller (h275 (Types.cons s31 ρ) sub11 a0) sub11)) (consAll (lamAt d80 c80 (smaller (h261 (Types.cons s21 ρ) sub57 a0) sub11)) Positive.none)))
theorem h298 (ρ : Env) (a0 : Fits s50 (ρ 0)) : All tab ρ b7 s57 :=
  (consAll (lamAt d84 c84 (smaller (h262 (Types.cons s26 ρ) sub55 a0) sub105)) Positive.none)
theorem h299 (ρ : Env) (a0 : Fits s60 (ρ 0)) : All tab ρ b7 s58 :=
  (consAll (lamAt d35 c35 (smaller (h274 (Types.cons s31 ρ) sub11 a0) sub15)) (consAll (lamAt d37 c37 (smaller (h264 (Types.cons s25 ρ) sub16 a0) sub11)) (consAll (lamAt d45 c45 (smaller (h268 (Types.cons s37 ρ) sub20 a0) sub15)) (consAll (lamAt d55 c55 (smaller (h271 (Types.cons s44 ρ) sub25 a0) sub15)) (consAll (lamAt d69 c69 (smaller (h276 (Types.cons s44 ρ) sub25 a0) sub11)) Positive.none)))))
theorem h300 (ρ : Env) (a0 : Fits s64 (ρ 0)) : All tab ρ b7 s106 :=
  (consAll (lamAt d60 c60 (smaller (h273 (Types.cons s0 ρ) sub124 a0) sub53)) (consAll (lamAt d91 c91 (smaller (h266 (Types.cons s0 ρ) sub124 a0) sub11)) Positive.none))
theorem h301 (ρ : Env)  : All tab ρ b8 s107 :=
  (consAll (lamAt d6 c6 (smaller (h277 (Types.cons s4 ρ) sub127) sub128)) (consAll (lamAt d7 c7 (smaller (h278 (Types.cons s5 ρ) sub113) sub114)) (consAll (lamAt d9 c9 (smaller (h279 (Types.cons s7 ρ) sub15) sub15)) (consAll (lamAt d13 c13 (smaller (h280 (Types.cons s1 ρ) sub41) sub2)) (consAll (lamAt d20 c20 (smaller (h281 (Types.cons s17 ρ) sub129) sub5)) (consAll (lamAt d21 c21 (smaller (h282 (Types.cons s18 ρ) sub115) sub116)) (consAll (lamAt d23 c23 (smaller (h283 (Types.cons s20 ρ) sub91) sub110)) (consAll (lamAt d27 c27 (smaller (h284 (Types.cons s24 ρ) sub93) sub91)) (consAll (lamAt d30 c30 (smaller (h285 (Types.cons s15 ρ) sub49) sub8)) (consAll (lamAt d32 c32 (smaller (h286 (Types.cons s28 ρ) sub117) sub93)) (consAll (lamAt d39 c39 (smaller (h287 (Types.cons s32 ρ) sub118) sub130)) (consAll (lamAt d41 c41 (smaller (h288 (Types.cons s34 ρ) sub53) sub53)) (consAll (lamAt d43 c43 (smaller (h289 (Types.cons s35 ρ) sub14) sub53)) (consAll (lamAt d49 c49 (smaller (h290 (Types.cons s40 ρ) sub123) sub11)) (consAll (lamAt d51 c51 (smaller (h291 (Types.cons s35 ρ) sub14) sub15)) (consAll (lamAt d53 c53 (smaller (h292 (Types.cons s21 ρ) sub57) sub20)) (consAll (lamAt d57 c57 (smaller (h288 (Types.cons s34 ρ) sub53) sub111)) (consAll (lamAt d63 c63 (smaller (h287 (Types.cons s32 ρ) sub118) sub131)) (consAll (lamAt d66 c66 (smaller (h293 (Types.cons s31 ρ) sub11) sub11)) (consAll (lamAt d71 c71 (smaller (h288 (Types.cons s34 ρ) sub53) sub112)) (consAll (lamAt d76 c76 (smaller (h294 (Types.cons s52 ρ) sub132) sub29)) (consAll (lamAt d77 c77 (smaller (h295 (Types.cons s53 ρ) sub119) sub120)) (consAll (lamAt d79 c79 (smaller (h296 (Types.cons s55 ρ) sub103) sub27)) (consAll (lamAt d83 c83 (smaller (h297 (Types.cons s58 ρ) sub105) sub103)) (consAll (lamAt d85 c85 (smaller (h298 (Types.cons s50 ρ) sub64) sub32)) (consAll (lamAt d87 c87 (smaller (h299 (Types.cons s60 ρ) sub121) sub105)) (consAll (lamAt d94 c94 (smaller (h300 (Types.cons s64 ρ) sub122) sub133)) (consAll (lamAt d96 c96 (smaller (h300 (Types.cons s64 ρ) sub122) sub134)) Positive.none))))))))))))))))))))))))))))
theorem h302 (ρ : Env) (a0 : Fits s2 (ρ 0)) : All tab ρ b9 s66 :=
  appAll len6 d6 c6 sub128 ((h0 ρ a0) 6 mem114) (smaller (h301 ρ) sub135)
theorem h303 (ρ : Env) (a0 : Fits s11 (ρ 0)) : All tab ρ b9 s67 :=
  appAll len16 d16 c16 sub110 ((h4 ρ a0) 16 mem115) (smaller (h301 ρ) sub136)
theorem h304 (ρ : Env) (a0 : Fits s14 (ρ 0)) : All tab ρ b9 s68 :=
  appAll len19 d19 c19 sub116 ((h5 ρ a0) 19 mem116) (smaller (h301 ρ) sub137)
theorem h305 (ρ : Env) (a0 : Fits s49 (ρ 0)) : All tab ρ b9 s69 :=
  appAll len75 d75 c75 sub120 ((h29 ρ a0) 75 mem117) (smaller (h301 ρ) sub138)
theorem h306 (ρ : Env) (a0 : Fits s2 (ρ 0)) : All tab ρ b10 s65 :=
  appAll len5 d5 c5 sub114 ((h302 ρ a0) 5 mem118) (smaller (h0 ρ a0) sub139)
theorem h307 (ρ : Env) (a0 : Fits s11 (ρ 0)) : All tab ρ b10 s7 :=
  appAll len15 d15 c15 sub15 ((h303 ρ a0) 15 mem119) (smaller (h4 ρ a0) sub140)
theorem h308 (ρ : Env) (a0 : Fits s14 (ρ 0)) : All tab ρ b10 s67 :=
  appAll len18 d18 c18 sub110 ((h304 ρ a0) 18 mem120) (smaller (h5 ρ a0) sub141)
theorem h309 (ρ : Env) (a0 : Fits s49 (ρ 0)) : All tab ρ b10 s43 :=
  appAll len74 d74 c74 sub27 ((h305 ρ a0) 74 mem121) (smaller (h29 ρ a0) sub142)
theorem h310 (ρ : Env)  : All tab ρ b11 s108 :=
  (consAll (lamAt d4 c4 (smaller (h306 (Types.cons s2 ρ) sub0) sub114)) (consAll (lamAt d14 c14 (smaller (h307 (Types.cons s11 ρ) sub4) sub15)) (consAll (lamAt d17 c17 (smaller (h308 (Types.cons s14 ρ) sub5) sub110)) (consAll (lamAt d73 c73 (smaller (h309 (Types.cons s49 ρ) sub29) sub27)) Positive.none))))
theorem h311 (ρ : Env)  : All tab ρ b12 s65 :=
  appAll len4 d4 c4 sub114 ((h310 ρ) 4 mem122) (smaller (h301 ρ) sub143)
theorem h312 (ρ : Env)  : All tab ρ b13 s7 :=
  appAll len3 d3 c3 sub15 ((h311 ρ) 3 mem123) (smaller (h310 ρ) sub144)
theorem h313 (ρ : Env)  : All tab ρ b16 s35 :=
  appAll len2 d2 c2 sub14 ((h312 ρ) 2 mem12) Positive.none
theorem h314 (ρ : Env) (a0 : Fits s0 (ρ 0)) : All tab ρ b38 s109 :=
  botAll ((h313 ρ) 0 mem11)
end Blc.H44.H44F4846201355482
