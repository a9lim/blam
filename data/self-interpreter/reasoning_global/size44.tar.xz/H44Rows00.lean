import H44Literals
import H44F4786765230946
import H44Lib0
import H44Lib101
namespace Blc.H44
theorem ex_e4770149175098 : ¬ IsSelfInterpreter e4770149175098 := Lib101.excluded (by decide : Types.has Lib101.tab Lib101.env e4770149175098 5 = true)
#print axioms ex_e4770149175098
theorem ex_e4783034076782 : ¬ IsSelfInterpreter e4783034076782 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4783034076782 1 = true)
#print axioms ex_e4783034076782
theorem ex_e4783034076982 : ¬ IsSelfInterpreter e4783034076982 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4783034076982 1 = true)
#print axioms ex_e4783034076982
theorem ex_e4783034076986 : ¬ IsSelfInterpreter e4783034076986 := Lib101.excluded (by decide : Types.has Lib101.tab Lib101.env e4783034076986 5 = true)
#print axioms ex_e4783034076986
theorem ex_e4786765230946 : ¬ IsSelfInterpreter e4786765230946 := H44F4786765230946.excluded
#print axioms ex_e4786765230946
theorem ex_e4786842079030 : ¬ IsSelfInterpreter e4786842079030 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4786842079030 1 = true)
#print axioms ex_e4786842079030
end Blc.H44
