import H44Pumppv82
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5958 : R t5958 t1 := result (f := t5896) (a := t5957) (u := t1) (v := t5957) pv5896 (aw (ri t5957)) pv5957
theorem pv5959 : R t5959 t1 := result (f := t5958) (a := t5882) (u := t1) (v := t5882) pv5958 (aw (ri t5882)) pv5882
theorem pv5956 : R t5956 t1 := result (f := t5889) (a := t5955) (u := t5950) (v := t5959) pv5889 (awb t5896 t5882 t5955 t5957 (refl _)) pv5959
theorem pv5952 : R t5952 t1 := result (f := t5892) (a := t1) (u := t5892) (v := t5956) (refl t5892) (aw (ra t5889 t1)) pv5956
theorem pv5953 : R t5953 t1 := result (f := t5896) (a := t5952) (u := t1) (v := t5952) pv5896 (aw (ri t5952)) pv5952
theorem pv5954 : R t5954 t1 := result (f := t5953) (a := t5882) (u := t1) (v := t5882) pv5953 (aw (ri t5882)) pv5882
theorem pv5893 : R t5893 t1 := result (f := t5889) (a := t5892) (u := t5950) (v := t5954) pv5889 (awb t5896 t5882 t5892 t5952 (refl _)) pv5954
theorem pv5890 : R t5890 t1 := result (f := t0) (a := t5889) (u := t0) (v := t5893) (refl t0) (aw (rh t5889)) pv5893
theorem pv5891 : R t5891 t1 := result (f := t5890) (a := t5882) (u := t1) (v := t5882) pv5890 (aw (ri t5882)) pv5882
theorem pv5888 : R t5888 t1 := result (f := t5885) (a := t5887) (u := t5885) (v := t5891) (refl t5885) (awb t0 t5882 t5887 t5889 (refl _)) pv5891
theorem pv5886 : R t5886 t1 := result (f := t0) (a := t5885) (u := t0) (v := t5888) (refl t0) (aw (rh t5885)) pv5888
theorem pv5883 : R t5883 t1 := result (f := t2) (a := t5882) (u := t2) (v := t5886) (refl t2) (aw (ra t0 t5882)) pv5886
theorem pv5884 : R t5884 t1 := result (f := t5883) (a := t5770) (u := t1) (v := t5770) pv5883 (aw (ri t5770)) pv5770
theorem pv5783 : R t5783 t1 := result (f := t5779) (a := t5782) (u := t5773) (v := t5884) pv5779 (awb t2 t5770 t5782 t5882 (refl _)) pv5884
theorem pv5780 : R t5780 t1 := result (f := t0) (a := t5779) (u := t0) (v := t5783) (refl t0) (aw (rh t5779)) pv5783
theorem pv5781 : R t5781 t5773 := result (f := t5780) (a := t5773) (u := t1) (v := t5773) pv5780 (aw (ri t5773)) (refl t5773)
theorem pv5778 : R t5778 t5773 := result (f := t5775) (a := t5777) (u := t5775) (v := t5781) (refl t5775) (awb t0 t5773 t5777 t5779 (refl _)) pv5781
theorem pv5776 : R t5776 t5773 := result (f := t0) (a := t5775) (u := t0) (v := t5778) (refl t0) (aw (rh t5775)) pv5778
theorem pv5774 : R t5774 t5773 := result (f := t2) (a := t5773) (u := t2) (v := t5776) (refl t2) (aw (ra t0 t5773)) pv5776
theorem pv5771 : R t5771 t5773 := result (f := t59) (a := t5770) (u := t46) (v := t5774) pv59 (aw (ra t2 t5770)) pv5774
theorem pv5772 : R t5772 t1 := result (f := t5771) (a := t1) (u := t5773) (v := t5851) pv5771 (awb t2 t5770 t1 t1 (cI)) pv5851
theorem pv5769 : R t5769 t1 := result (f := t108) (a := t5768) (u := t149) (v := t5772) pv108 (awb t59 t1 t5768 t5770 (refl _)) pv5772
theorem pv5686 : R t5686 t1 := result (f := t111) (a := t1) (u := t111) (v := t5769) (refl t111) (aw (ra t108 t1)) pv5769
theorem pv5767 : R t5767 t1 := result (f := t3) (a := t5686) (u := t1) (v := t5686) pv3 (aw (ri t5686)) pv5686
theorem pv5765 : R t5765 t1 := result (f := t5702) (a := t1) (u := t5689) (v := t5767) pv5702 (awb t2 t5686 t1 t1 (cI)) pv5767
theorem pv5766 : R t5766 t1 := result (f := t5765) (a := t1) (u := t1) (v := t1) pv5765 (aw (ri t1)) (refl t1)
theorem pv5740 : R t5740 t1 := result (f := t5738) (a := t1) (u := t5738) (v := t5766) (refl t5738) (awb t5702 t1 t1 t1 (cI)) pv5766
theorem pv5764 : R t5764 t1 := result (f := t28) (a := t5740) (u := t1) (v := t5740) pv28 (aw (ri t5740)) pv5740
theorem pv5760 : R t5760 t1 := result (f := t5759) (a := t1) (u := t5762) (v := t5764) pv5759 (awb t1 t5740 t1 t1 (cI)) pv5764
theorem pv5754 : R t5754 t1 := result (f := t5752) (a := t1) (u := t5752) (v := t5760) (refl t5752) (awb t5743 t1 t1 t1 (cI)) pv5760
theorem pv5758 : R t5758 t5757 := result (f := t5754) (a := t5757) (u := t1) (v := t5757) pv5754 (aw (ri t5757)) (refl t5757)
theorem pv5755 : R t5755 t5757 := result (f := t0) (a := t5754) (u := t0) (v := t5758) (refl t0) (aw (rh t5754)) pv5758
theorem pv5965 : R t5965 t5964 := result (f := t5754) (a := t5964) (u := t1) (v := t5964) pv5754 (aw (ri t5964)) (refl t5964)
theorem pv5756 : R t5756 t5964 := result (f := t5755) (a := t5740) (u := t5757) (v := t5965) pv5755 (aw (ra t5754 t5740)) pv5965
theorem pv5753 : R t5753 t5964 := result (f := t5743) (a := t5752) (u := t5743) (v := t5756) (refl t5743) (awb t0 t5740 t5752 t5754 (refl _)) pv5756
theorem pv5747 : R t5747 t5964 := result (f := t5745) (a := t1) (u := t5745) (v := t5753) (refl t5745) (aw (ra t5743 t1)) pv5753
theorem pv5976 : R t5976 t1 := result (f := t5754) (a := t1) (u := t1) (v := t1) pv5754 (aw (ri t1)) (refl t1)
theorem pv5977 : R t5977 t1 := result (f := t5976) (a := t5740) (u := t1) (v := t5740) pv5976 (aw (ri t5740)) pv5740
theorem pv5974 : R t5974 t1 := result (f := t5747) (a := t1) (u := t5964) (v := t5977) pv5747 (awb t5754 t5740 t1 t1 (cI)) pv5977
theorem pv5975 : R t5975 t1 := result (f := t5974) (a := t1) (u := t1) (v := t1) pv5974 (aw (ri t1)) (refl t1)
theorem pv5971 : R t5971 t1 := result (f := t5969) (a := t1) (u := t5969) (v := t5975) (refl t5969) (awb t5747 t1 t1 t1 (cI)) pv5975
theorem pv5972 : R t5972 t1 := result (f := t5754) (a := t5971) (u := t1) (v := t5971) pv5754 (aw (ri t5971)) pv5971
theorem pv5973 : R t5973 t1 := result (f := t5972) (a := t5740) (u := t1) (v := t5740) pv5972 (aw (ri t5740)) pv5740
theorem pv5970 : R t5970 t1 := result (f := t5747) (a := t5969) (u := t5964) (v := t5973) pv5747 (awb t5754 t5740 t5969 t5971 (refl _)) pv5973
theorem pv5966 : R t5966 t1 := result (f := t5750) (a := t1) (u := t5750) (v := t5970) (refl t5750) (aw (ra t5747 t1)) pv5970
theorem pv5967 : R t5967 t1 := result (f := t5754) (a := t5966) (u := t1) (v := t5966) pv5754 (aw (ri t5966)) pv5966
theorem pv5968 : R t5968 t1 := result (f := t5967) (a := t5740) (u := t1) (v := t5740) pv5967 (aw (ri t5740)) pv5740
theorem pv5751 : R t5751 t1 := result (f := t5747) (a := t5750) (u := t5964) (v := t5968) pv5747 (awb t5754 t5740 t5750 t5966 (refl _)) pv5968
theorem pv5748 : R t5748 t1 := result (f := t0) (a := t5747) (u := t0) (v := t5751) (refl t0) (aw (rh t5747)) pv5751
theorem pv5749 : R t5749 t1 := result (f := t5748) (a := t5740) (u := t1) (v := t5740) pv5748 (aw (ri t5740)) pv5740
theorem pv5746 : R t5746 t1 := result (f := t5743) (a := t5745) (u := t5743) (v := t5749) (refl t5743) (awb t0 t5740 t5745 t5747 (refl _)) pv5749
theorem pv5744 : R t5744 t1 := result (f := t0) (a := t5743) (u := t0) (v := t5746) (refl t0) (aw (rh t5743)) pv5746
theorem pv5741 : R t5741 t1 := result (f := t2) (a := t5740) (u := t2) (v := t5744) (refl t2) (aw (ra t0 t5740)) pv5744
theorem pv5742 : R t5742 t1 := result (f := t5741) (a := t5686) (u := t1) (v := t5686) pv5741 (aw (ri t5686)) pv5686
theorem pv5739 : R t5739 t1 := result (f := t5702) (a := t5738) (u := t5689) (v := t5742) pv5702 (awb t2 t5686 t5738 t5740 (refl _)) pv5742
end Blc.H44.Pump
