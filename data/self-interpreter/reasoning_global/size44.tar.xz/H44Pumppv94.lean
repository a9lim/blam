import H44Pumppv93
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv6773 : R t6773 t6793 := result (f := t6771) (a := t1) (u := t6771) (v := t6779) (refl t6771) (aw (ra t6769 t1)) pv6779
theorem pv6805 : R t6805 t1 := result (f := t6780) (a := t1) (u := t1) (v := t1) pv6780 (aw (ri t1)) (refl t1)
theorem pv6806 : R t6806 t1 := result (f := t6805) (a := t6766) (u := t1) (v := t6766) pv6805 (aw (ri t6766)) pv6766
theorem pv6803 : R t6803 t1 := result (f := t6773) (a := t1) (u := t6793) (v := t6806) pv6773 (awb t6780 t6766 t1 t1 (cI)) pv6806
theorem pv6804 : R t6804 t1 := result (f := t6803) (a := t1) (u := t1) (v := t1) pv6803 (aw (ri t1)) (refl t1)
theorem pv6800 : R t6800 t1 := result (f := t6798) (a := t1) (u := t6798) (v := t6804) (refl t6798) (awb t6773 t1 t1 t1 (cI)) pv6804
theorem pv6801 : R t6801 t1 := result (f := t6780) (a := t6800) (u := t1) (v := t6800) pv6780 (aw (ri t6800)) pv6800
theorem pv6802 : R t6802 t1 := result (f := t6801) (a := t6766) (u := t1) (v := t6766) pv6801 (aw (ri t6766)) pv6766
theorem pv6799 : R t6799 t1 := result (f := t6773) (a := t6798) (u := t6793) (v := t6802) pv6773 (awb t6780 t6766 t6798 t6800 (refl _)) pv6802
theorem pv6795 : R t6795 t1 := result (f := t6776) (a := t1) (u := t6776) (v := t6799) (refl t6776) (aw (ra t6773 t1)) pv6799
theorem pv6796 : R t6796 t1 := result (f := t6780) (a := t6795) (u := t1) (v := t6795) pv6780 (aw (ri t6795)) pv6795
theorem pv6797 : R t6797 t1 := result (f := t6796) (a := t6766) (u := t1) (v := t6766) pv6796 (aw (ri t6766)) pv6766
theorem pv6777 : R t6777 t1 := result (f := t6773) (a := t6776) (u := t6793) (v := t6797) pv6773 (awb t6780 t6766 t6776 t6795 (refl _)) pv6797
theorem pv6774 : R t6774 t1 := result (f := t0) (a := t6773) (u := t0) (v := t6777) (refl t0) (aw (rh t6773)) pv6777
theorem pv6775 : R t6775 t1 := result (f := t6774) (a := t6766) (u := t1) (v := t6766) pv6774 (aw (ri t6766)) pv6766
theorem pv6772 : R t6772 t1 := result (f := t6769) (a := t6771) (u := t6769) (v := t6775) (refl t6769) (awb t0 t6766 t6771 t6773 (refl _)) pv6775
theorem pv6770 : R t6770 t1 := result (f := t0) (a := t6769) (u := t0) (v := t6772) (refl t0) (aw (rh t6769)) pv6772
theorem pv6767 : R t6767 t1 := result (f := t2) (a := t6766) (u := t2) (v := t6770) (refl t2) (aw (ra t0 t6766)) pv6770
theorem pv6768 : R t6768 t1 := result (f := t6767) (a := t6627) (u := t1) (v := t6627) pv6767 (aw (ri t6627)) pv6627
theorem pv6765 : R t6765 t1 := result (f := t6636) (a := t6764) (u := t6630) (v := t6768) pv6636 (awb t2 t6627 t6764 t6766 (refl _)) pv6768
theorem pv6739 : R t6739 t1 := result (f := t6639) (a := t1) (u := t6639) (v := t6765) (refl t6639) (aw (ra t6636 t1)) pv6765
theorem pv6763 : R t6763 t1 := result (f := t28) (a := t6739) (u := t1) (v := t6739) pv28 (aw (ri t6739)) pv6739
theorem pv6759 : R t6759 t1 := result (f := t6758) (a := t1) (u := t6761) (v := t6763) pv6758 (awb t1 t6739 t1 t1 (cI)) pv6763
theorem pv6753 : R t6753 t1 := result (f := t6751) (a := t1) (u := t6751) (v := t6759) (refl t6751) (awb t6742 t1 t1 t1 (cI)) pv6759
theorem pv6757 : R t6757 t6756 := result (f := t6753) (a := t6756) (u := t1) (v := t6756) pv6753 (aw (ri t6756)) (refl t6756)
theorem pv6754 : R t6754 t6756 := result (f := t0) (a := t6753) (u := t0) (v := t6757) (refl t0) (aw (rh t6753)) pv6757
theorem pv6808 : R t6808 t6807 := result (f := t6753) (a := t6807) (u := t1) (v := t6807) pv6753 (aw (ri t6807)) (refl t6807)
theorem pv6755 : R t6755 t6807 := result (f := t6754) (a := t6739) (u := t6756) (v := t6808) pv6754 (aw (ra t6753 t6739)) pv6808
theorem pv6752 : R t6752 t6807 := result (f := t6742) (a := t6751) (u := t6742) (v := t6755) (refl t6742) (awb t0 t6739 t6751 t6753 (refl _)) pv6755
theorem pv6746 : R t6746 t6807 := result (f := t6744) (a := t1) (u := t6744) (v := t6752) (refl t6744) (aw (ra t6742 t1)) pv6752
theorem pv6819 : R t6819 t1 := result (f := t6753) (a := t1) (u := t1) (v := t1) pv6753 (aw (ri t1)) (refl t1)
theorem pv6820 : R t6820 t1 := result (f := t6819) (a := t6739) (u := t1) (v := t6739) pv6819 (aw (ri t6739)) pv6739
theorem pv6817 : R t6817 t1 := result (f := t6746) (a := t1) (u := t6807) (v := t6820) pv6746 (awb t6753 t6739 t1 t1 (cI)) pv6820
theorem pv6818 : R t6818 t1 := result (f := t6817) (a := t1) (u := t1) (v := t1) pv6817 (aw (ri t1)) (refl t1)
theorem pv6814 : R t6814 t1 := result (f := t6812) (a := t1) (u := t6812) (v := t6818) (refl t6812) (awb t6746 t1 t1 t1 (cI)) pv6818
theorem pv6815 : R t6815 t1 := result (f := t6753) (a := t6814) (u := t1) (v := t6814) pv6753 (aw (ri t6814)) pv6814
theorem pv6816 : R t6816 t1 := result (f := t6815) (a := t6739) (u := t1) (v := t6739) pv6815 (aw (ri t6739)) pv6739
theorem pv6813 : R t6813 t1 := result (f := t6746) (a := t6812) (u := t6807) (v := t6816) pv6746 (awb t6753 t6739 t6812 t6814 (refl _)) pv6816
theorem pv6809 : R t6809 t1 := result (f := t6749) (a := t1) (u := t6749) (v := t6813) (refl t6749) (aw (ra t6746 t1)) pv6813
theorem pv6810 : R t6810 t1 := result (f := t6753) (a := t6809) (u := t1) (v := t6809) pv6753 (aw (ri t6809)) pv6809
theorem pv6811 : R t6811 t1 := result (f := t6810) (a := t6739) (u := t1) (v := t6739) pv6810 (aw (ri t6739)) pv6739
theorem pv6750 : R t6750 t1 := result (f := t6746) (a := t6749) (u := t6807) (v := t6811) pv6746 (awb t6753 t6739 t6749 t6809 (refl _)) pv6811
theorem pv6747 : R t6747 t1 := result (f := t0) (a := t6746) (u := t0) (v := t6750) (refl t0) (aw (rh t6746)) pv6750
theorem pv6748 : R t6748 t1 := result (f := t6747) (a := t6739) (u := t1) (v := t6739) pv6747 (aw (ri t6739)) pv6739
theorem pv6745 : R t6745 t1 := result (f := t6742) (a := t6744) (u := t6742) (v := t6748) (refl t6742) (awb t0 t6739 t6744 t6746 (refl _)) pv6748
theorem pv6743 : R t6743 t1 := result (f := t0) (a := t6742) (u := t0) (v := t6745) (refl t0) (aw (rh t6742)) pv6745
theorem pv6740 : R t6740 t1 := result (f := t2) (a := t6739) (u := t2) (v := t6743) (refl t2) (aw (ra t0 t6739)) pv6743
theorem pv6741 : R t6741 t1 := result (f := t6740) (a := t6627) (u := t1) (v := t6627) pv6740 (aw (ri t6627)) pv6627
theorem pv6640 : R t6640 t1 := result (f := t6636) (a := t6639) (u := t6630) (v := t6741) pv6636 (awb t2 t6627 t6639 t6739 (refl _)) pv6741
theorem pv6637 : R t6637 t1 := result (f := t0) (a := t6636) (u := t0) (v := t6640) (refl t0) (aw (rh t6636)) pv6640
theorem pv6638 : R t6638 t6630 := result (f := t6637) (a := t6630) (u := t1) (v := t6630) pv6637 (aw (ri t6630)) (refl t6630)
theorem pv6635 : R t6635 t6630 := result (f := t6632) (a := t6634) (u := t6632) (v := t6638) (refl t6632) (awb t0 t6630 t6634 t6636 (refl _)) pv6638
theorem pv6633 : R t6633 t6630 := result (f := t0) (a := t6632) (u := t0) (v := t6635) (refl t0) (aw (rh t6632)) pv6635
theorem pv6631 : R t6631 t6630 := result (f := t2) (a := t6630) (u := t2) (v := t6633) (refl t2) (aw (ra t0 t6630)) pv6633
theorem pv6628 : R t6628 t6630 := result (f := t59) (a := t6627) (u := t46) (v := t6631) pv59 (aw (ra t2 t6627)) pv6631
end Blc.H44.Pump
