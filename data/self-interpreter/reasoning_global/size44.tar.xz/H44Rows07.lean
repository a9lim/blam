import H44Literals
import H44F4846201355482
import H44Lib0
import H44Lib1
import H44Lib3
namespace Blc.H44
theorem ex_e4846200015994 : ¬ IsSelfInterpreter e4846200015994 := Lib3.excluded (by decide : Types.has Lib3.tab Lib3.env e4846200015994 4 = true)
#print axioms ex_e4846200015994
theorem ex_e4846200016090 : ¬ IsSelfInterpreter e4846200016090 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846200016090 1 = true)
#print axioms ex_e4846200016090
theorem ex_e4846200016106 : ¬ IsSelfInterpreter e4846200016106 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846200016106 1 = true)
#print axioms ex_e4846200016106
theorem ex_e4846201032546 : ¬ IsSelfInterpreter e4846201032546 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4846201032546 3 = true)
#print axioms ex_e4846201032546
theorem ex_e4846201355482 : ¬ IsSelfInterpreter e4846201355482 := H44F4846201355482.excluded
#print axioms ex_e4846201355482
theorem ex_e4846201392994 : ¬ IsSelfInterpreter e4846201392994 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846201392994 1 = true)
#print axioms ex_e4846201392994
end Blc.H44
