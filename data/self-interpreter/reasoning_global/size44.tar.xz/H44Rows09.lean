import H44Literals
import H44Lib0
import H44Lib4
import H44PumpFinal
import H44T4846363331350
namespace Blc.H44
theorem ex_e4846363276054 : ¬ IsSelfInterpreter e4846363276054 := Pump.excluded
#print axioms ex_e4846363276054
theorem ex_e4846363317806 : ¬ IsSelfInterpreter e4846363317806 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846363317806 1 = true)
#print axioms ex_e4846363317806
theorem ex_e4846363318154 : ¬ IsSelfInterpreter e4846363318154 := Lib4.excluded (by decide : Types.has Lib4.tab Lib4.env e4846363318154 4 = true)
#print axioms ex_e4846363318154
theorem ex_e4846363318754 : ¬ IsSelfInterpreter e4846363318754 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846363318754 1 = true)
#print axioms ex_e4846363318754
theorem ex_e4846363319906 : ¬ IsSelfInterpreter e4846363319906 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4846363319906 1 = true)
#print axioms ex_e4846363319906
theorem ex_e4846363331350 : ¬ IsSelfInterpreter e4846363331350 := T4846363331350.excluded
#print axioms ex_e4846363331350
end Blc.H44
