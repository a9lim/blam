import H44Pumppv40
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv2750 : R t2750 t1 := result (f := t2749) (a := t1) (u := t2752) (v := t2754) pv2749 (awb t1 t2730 t1 t1 (cI)) pv2754
theorem pv2744 : R t2744 t1 := result (f := t2742) (a := t1) (u := t2742) (v := t2750) (refl t2742) (awb t2733 t1 t1 t1 (cI)) pv2750
theorem pv2748 : R t2748 t2747 := result (f := t2744) (a := t2747) (u := t1) (v := t2747) pv2744 (aw (ri t2747)) (refl t2747)
theorem pv2745 : R t2745 t2747 := result (f := t0) (a := t2744) (u := t0) (v := t2748) (refl t0) (aw (rh t2744)) pv2748
theorem pv2996 : R t2996 t2995 := result (f := t2744) (a := t2995) (u := t1) (v := t2995) pv2744 (aw (ri t2995)) (refl t2995)
theorem pv2746 : R t2746 t2995 := result (f := t2745) (a := t2730) (u := t2747) (v := t2996) pv2745 (aw (ra t2744 t2730)) pv2996
theorem pv2743 : R t2743 t2995 := result (f := t2733) (a := t2742) (u := t2733) (v := t2746) (refl t2733) (awb t0 t2730 t2742 t2744 (refl _)) pv2746
theorem pv2737 : R t2737 t2995 := result (f := t2735) (a := t1) (u := t2735) (v := t2743) (refl t2735) (aw (ra t2733 t1)) pv2743
theorem pv3007 : R t3007 t1 := result (f := t2744) (a := t1) (u := t1) (v := t1) pv2744 (aw (ri t1)) (refl t1)
theorem pv3008 : R t3008 t1 := result (f := t3007) (a := t2730) (u := t1) (v := t2730) pv3007 (aw (ri t2730)) pv2730
theorem pv3005 : R t3005 t1 := result (f := t2737) (a := t1) (u := t2995) (v := t3008) pv2737 (awb t2744 t2730 t1 t1 (cI)) pv3008
theorem pv3006 : R t3006 t1 := result (f := t3005) (a := t1) (u := t1) (v := t1) pv3005 (aw (ri t1)) (refl t1)
theorem pv3002 : R t3002 t1 := result (f := t3000) (a := t1) (u := t3000) (v := t3006) (refl t3000) (awb t2737 t1 t1 t1 (cI)) pv3006
theorem pv3003 : R t3003 t1 := result (f := t2744) (a := t3002) (u := t1) (v := t3002) pv2744 (aw (ri t3002)) pv3002
theorem pv3004 : R t3004 t1 := result (f := t3003) (a := t2730) (u := t1) (v := t2730) pv3003 (aw (ri t2730)) pv2730
theorem pv3001 : R t3001 t1 := result (f := t2737) (a := t3000) (u := t2995) (v := t3004) pv2737 (awb t2744 t2730 t3000 t3002 (refl _)) pv3004
theorem pv2997 : R t2997 t1 := result (f := t2740) (a := t1) (u := t2740) (v := t3001) (refl t2740) (aw (ra t2737 t1)) pv3001
theorem pv2998 : R t2998 t1 := result (f := t2744) (a := t2997) (u := t1) (v := t2997) pv2744 (aw (ri t2997)) pv2997
theorem pv2999 : R t2999 t1 := result (f := t2998) (a := t2730) (u := t1) (v := t2730) pv2998 (aw (ri t2730)) pv2730
theorem pv2741 : R t2741 t1 := result (f := t2737) (a := t2740) (u := t2995) (v := t2999) pv2737 (awb t2744 t2730 t2740 t2997 (refl _)) pv2999
theorem pv2738 : R t2738 t1 := result (f := t0) (a := t2737) (u := t0) (v := t2741) (refl t0) (aw (rh t2737)) pv2741
theorem pv2739 : R t2739 t1 := result (f := t2738) (a := t2730) (u := t1) (v := t2730) pv2738 (aw (ri t2730)) pv2730
theorem pv2736 : R t2736 t1 := result (f := t2733) (a := t2735) (u := t2733) (v := t2739) (refl t2733) (awb t0 t2730 t2735 t2737 (refl _)) pv2739
theorem pv2734 : R t2734 t1 := result (f := t0) (a := t2733) (u := t0) (v := t2736) (refl t0) (aw (rh t2733)) pv2736
theorem pv2731 : R t2731 t1 := result (f := t2) (a := t2730) (u := t2) (v := t2734) (refl t2) (aw (ra t0 t2730)) pv2734
theorem pv2732 : R t2732 t1 := result (f := t2731) (a := t2703) (u := t1) (v := t2703) pv2731 (aw (ri t2703)) pv2703
theorem pv2723 : R t2723 t1 := result (f := t2719) (a := t2722) (u := t2706) (v := t2732) pv2719 (awb t2 t2703 t2722 t2730 (refl _)) pv2732
theorem pv2720 : R t2720 t1 := result (f := t0) (a := t2719) (u := t0) (v := t2723) (refl t0) (aw (rh t2719)) pv2723
theorem pv2721 : R t2721 t2706 := result (f := t2720) (a := t2706) (u := t1) (v := t2706) pv2720 (aw (ri t2706)) (refl t2706)
theorem pv2718 : R t2718 t2706 := result (f := t2708) (a := t2717) (u := t2708) (v := t2721) (refl t2708) (awb t0 t2706 t2717 t2719 (refl _)) pv2721
theorem pv2712 : R t2712 t2706 := result (f := t2710) (a := t1) (u := t2710) (v := t2718) (refl t2710) (aw (ra t2708 t1)) pv2718
theorem pv3032 : R t3032 t3031 := result (f := t1) (a := t3031) (u := t1) (v := t3031) (refl t1) (aw (ri t3031)) (refl t3031)
theorem pv3030 : R t3030 t3031 := result (f := t22) (a := t3009) (u := t24) (v := t3032) pv22 (aw (ra t1 t3009)) pv3032
theorem pv3028 : R t3028 t3031 := result (f := t3012) (a := t1) (u := t3012) (v := t3030) (refl t3012) (awb t0 t3009 t1 t1 (cI)) pv3030
theorem pv3059 : R t3059 t3058 := result (f := t1) (a := t3058) (u := t1) (v := t3058) (refl t1) (aw (ri t3058)) (refl t3058)
theorem pv3057 : R t3057 t3058 := result (f := t22) (a := t3036) (u := t24) (v := t3059) pv22 (aw (ra t1 t3036)) pv3059
theorem pv3055 : R t3055 t3058 := result (f := t3039) (a := t1) (u := t3039) (v := t3057) (refl t3039) (awb t0 t3036 t1 t1 (cI)) pv3057
theorem pv3061 : R t3061 t1 := result (f := t2712) (a := t1) (u := t2706) (v := t2784) pv2712 (awb t2 t2703 t1 t1 (cI)) pv2784
theorem pv3062 : R t3062 t1 := result (f := t3061) (a := t1) (u := t1) (v := t1) pv3061 (aw (ri t1)) (refl t1)
theorem pv3036 : R t3036 t1 := result (f := t3034) (a := t1) (u := t3034) (v := t3062) (refl t3034) (awb t2712 t1 t1 t1 (cI)) pv3062
theorem pv3060 : R t3060 t1 := result (f := t28) (a := t3036) (u := t1) (v := t3036) pv28 (aw (ri t3036)) pv3036
theorem pv3056 : R t3056 t1 := result (f := t3055) (a := t1) (u := t3058) (v := t3060) pv3055 (awb t1 t3036 t1 t1 (cI)) pv3060
theorem pv3050 : R t3050 t1 := result (f := t3048) (a := t1) (u := t3048) (v := t3056) (refl t3048) (awb t3039 t1 t1 t1 (cI)) pv3056
theorem pv3054 : R t3054 t3053 := result (f := t3050) (a := t3053) (u := t1) (v := t3053) pv3050 (aw (ri t3053)) (refl t3053)
theorem pv3051 : R t3051 t3053 := result (f := t0) (a := t3050) (u := t0) (v := t3054) (refl t0) (aw (rh t3050)) pv3054
theorem pv3064 : R t3064 t3063 := result (f := t3050) (a := t3063) (u := t1) (v := t3063) pv3050 (aw (ri t3063)) (refl t3063)
theorem pv3052 : R t3052 t3063 := result (f := t3051) (a := t3036) (u := t3053) (v := t3064) pv3051 (aw (ra t3050 t3036)) pv3064
theorem pv3049 : R t3049 t3063 := result (f := t3039) (a := t3048) (u := t3039) (v := t3052) (refl t3039) (awb t0 t3036 t3048 t3050 (refl _)) pv3052
theorem pv3043 : R t3043 t3063 := result (f := t3041) (a := t1) (u := t3041) (v := t3049) (refl t3041) (aw (ra t3039 t1)) pv3049
theorem pv3075 : R t3075 t1 := result (f := t3050) (a := t1) (u := t1) (v := t1) pv3050 (aw (ri t1)) (refl t1)
theorem pv3076 : R t3076 t1 := result (f := t3075) (a := t3036) (u := t1) (v := t3036) pv3075 (aw (ri t3036)) pv3036
theorem pv3073 : R t3073 t1 := result (f := t3043) (a := t1) (u := t3063) (v := t3076) pv3043 (awb t3050 t3036 t1 t1 (cI)) pv3076
theorem pv3074 : R t3074 t1 := result (f := t3073) (a := t1) (u := t1) (v := t1) pv3073 (aw (ri t1)) (refl t1)
theorem pv3070 : R t3070 t1 := result (f := t3068) (a := t1) (u := t3068) (v := t3074) (refl t3068) (awb t3043 t1 t1 t1 (cI)) pv3074
theorem pv3071 : R t3071 t1 := result (f := t3050) (a := t3070) (u := t1) (v := t3070) pv3050 (aw (ri t3070)) pv3070
end Blc.H44.Pump
