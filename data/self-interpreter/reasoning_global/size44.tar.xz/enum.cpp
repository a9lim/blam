// Unary/binary skeleton, followed by legal binder choices with exact index sum.
#include <cstdio>
#include <cstdint>
#include <cassert>
#include <algorithm>
#include <bit>
using namespace std;
int tag[40],endp[40],dep[40],binds[40][22],leaves[22],idx[40],cnt[40];
int lv[40],sub[40],lam[40],varn[40],nlam,nvar,ex,N,rootLam;
long long raw,structural,kept;
void visit(){
 ++raw;
 int internal=rootLam;
 if(internal && (!cnt[0] || tag[1]==1))return;
 int non[22],nk=0;
 for(int p=internal;p<N;p++)if(tag[p]==1 && cnt[p]>=2)non[nk++]=p;
 bool pair=false;
 for(int i=0;i<nk;i++)for(int j=i+1;j<nk;j++)if(endp[non[i]]<=non[j])pair=true;
 if(!pair)return;
 bool wide=false;
 for(int p=N-1;p>=internal;p--){
   if(tag[p]==0){int b=binds[p][dep[p]-1-idx[p]];sub[p]=(1u<<b);}
   else if(tag[p]==1)sub[p]=sub[p+1]&~(1u<<p);
   else sub[p]=sub[p+1]|sub[endp[p+1]];
   if(popcount((unsigned)sub[p] & ~(unsigned)internal)>=3)wide=true;
 }
 if(!wide)return;
 ++structural;
 // Exact length change of a single contraction in fixed context.
 for(int p=0;p<N;p++)if(tag[p]==2 && tag[p+1]==1){
   int b=p+1,a=endp[b],k=cnt[b],D=0,g=0,f=0,sa=0;
   for(int j=b+1;j<a;j++)if(tag[j]==0){
     int d=dep[j]-dep[b]-1;
     if(idx[j]==d)D+=d;
     if(idx[j]>d)g++;
   }
   for(int j=a;j<endp[a];j++){
     sa+=2;
     if(tag[j]==0){sa+=idx[j];f+=(idx[j]>=dep[j]-dep[a]);}
   }
   if((k-1)*sa+(f-1)*D-2*k-4-g<0)return;
 }
 ++kept;
 for(int j=0;j<N;j++){
  if(tag[j]==1)printf("00");else if(tag[j]==2)printf("01");
  else {for(int i=0;i<=idx[j];i++)putchar('1');putchar('0');}
 }
 putchar('\n');
}
void assign(int i,int rem){
 if(i==nvar){if(!rem)visit();return;}
 int p=leaves[i];
 for(int v=0;v<dep[p] && v<=rem;v++){
  int b=binds[p][dep[p]-1-v];idx[p]=v;cnt[b]++;
  assign(i+1,rem-v);cnt[b]--;
 }
}
int walk(int p,int d,int *stack,int &j){
 dep[p]=d;
 if(tag[p]==0){copy(stack,stack+d,binds[p]);leaves[j++]=p;return endp[p]=p+1;}
 if(tag[p]==1){stack[d]=p;return endp[p]=walk(p+1,d+1,stack,j);}
 int a=walk(p+1,d,stack,j);return endp[p]=walk(a,d,stack,j);
}
void shape(int i,int l,int v,int a,int pending){
 if(!pending){
   if(l||v||a)return;
   rootLam=tag[0]==1;
   int stack[22],j=0;walk(0,0,stack,j);
   assign(0,ex);return;
 }
 if(v){tag[i]=0;shape(i+1,l,v-1,a,pending-1);}
 if(l){tag[i]=1;shape(i+1,l-1,v,a,pending);}
 if(a){tag[i]=2;shape(i+1,l,v,a-1,pending+1);}
}
int main(){
 for(nlam=4;nlam<=12;nlam++)for(nvar=6;nvar<=11;nvar++){
  ex=46-2*nlam-4*nvar;if(ex<3)continue;
  assert(nlam+2*nvar-1<31);N=nlam+2*nvar-1;raw=structural=kept=0;
  shape(0,nlam,nvar,nvar-1,1);
  fprintf(stderr,"%d %d %d %lld %lld %lld\n",nlam,nvar,ex,raw,structural,kept);
 }
}
