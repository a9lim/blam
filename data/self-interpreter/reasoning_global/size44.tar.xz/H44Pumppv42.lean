import H44Pumppv41
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3072 : R t3072 t1 := result (f := t3071) (a := t3036) (u := t1) (v := t3036) pv3071 (aw (ri t3036)) pv3036
theorem pv3069 : R t3069 t1 := result (f := t3043) (a := t3068) (u := t3063) (v := t3072) pv3043 (awb t3050 t3036 t3068 t3070 (refl _)) pv3072
theorem pv3065 : R t3065 t1 := result (f := t3046) (a := t1) (u := t3046) (v := t3069) (refl t3046) (aw (ra t3043 t1)) pv3069
theorem pv3066 : R t3066 t1 := result (f := t3050) (a := t3065) (u := t1) (v := t3065) pv3050 (aw (ri t3065)) pv3065
theorem pv3067 : R t3067 t1 := result (f := t3066) (a := t3036) (u := t1) (v := t3036) pv3066 (aw (ri t3036)) pv3036
theorem pv3047 : R t3047 t1 := result (f := t3043) (a := t3046) (u := t3063) (v := t3067) pv3043 (awb t3050 t3036 t3046 t3065 (refl _)) pv3067
theorem pv3044 : R t3044 t1 := result (f := t0) (a := t3043) (u := t0) (v := t3047) (refl t0) (aw (rh t3043)) pv3047
theorem pv3045 : R t3045 t1 := result (f := t3044) (a := t3036) (u := t1) (v := t3036) pv3044 (aw (ri t3036)) pv3036
theorem pv3042 : R t3042 t1 := result (f := t3039) (a := t3041) (u := t3039) (v := t3045) (refl t3039) (awb t0 t3036 t3041 t3043 (refl _)) pv3045
theorem pv3040 : R t3040 t1 := result (f := t0) (a := t3039) (u := t0) (v := t3042) (refl t0) (aw (rh t3039)) pv3042
theorem pv3037 : R t3037 t1 := result (f := t2) (a := t3036) (u := t2) (v := t3040) (refl t2) (aw (ra t0 t3036)) pv3040
theorem pv3038 : R t3038 t1 := result (f := t3037) (a := t2703) (u := t1) (v := t2703) pv3037 (aw (ri t2703)) pv2703
theorem pv3035 : R t3035 t1 := result (f := t2712) (a := t3034) (u := t2706) (v := t3038) pv2712 (awb t2 t2703 t3034 t3036 (refl _)) pv3038
theorem pv3009 : R t3009 t1 := result (f := t2715) (a := t1) (u := t2715) (v := t3035) (refl t2715) (aw (ra t2712 t1)) pv3035
theorem pv3033 : R t3033 t1 := result (f := t28) (a := t3009) (u := t1) (v := t3009) pv28 (aw (ri t3009)) pv3009
theorem pv3029 : R t3029 t1 := result (f := t3028) (a := t1) (u := t3031) (v := t3033) pv3028 (awb t1 t3009 t1 t1 (cI)) pv3033
theorem pv3023 : R t3023 t1 := result (f := t3021) (a := t1) (u := t3021) (v := t3029) (refl t3021) (awb t3012 t1 t1 t1 (cI)) pv3029
theorem pv3027 : R t3027 t3026 := result (f := t3023) (a := t3026) (u := t1) (v := t3026) pv3023 (aw (ri t3026)) (refl t3026)
theorem pv3024 : R t3024 t3026 := result (f := t0) (a := t3023) (u := t0) (v := t3027) (refl t0) (aw (rh t3023)) pv3027
theorem pv3078 : R t3078 t3077 := result (f := t3023) (a := t3077) (u := t1) (v := t3077) pv3023 (aw (ri t3077)) (refl t3077)
theorem pv3025 : R t3025 t3077 := result (f := t3024) (a := t3009) (u := t3026) (v := t3078) pv3024 (aw (ra t3023 t3009)) pv3078
theorem pv3022 : R t3022 t3077 := result (f := t3012) (a := t3021) (u := t3012) (v := t3025) (refl t3012) (awb t0 t3009 t3021 t3023 (refl _)) pv3025
theorem pv3016 : R t3016 t3077 := result (f := t3014) (a := t1) (u := t3014) (v := t3022) (refl t3014) (aw (ra t3012 t1)) pv3022
theorem pv3089 : R t3089 t1 := result (f := t3023) (a := t1) (u := t1) (v := t1) pv3023 (aw (ri t1)) (refl t1)
theorem pv3090 : R t3090 t1 := result (f := t3089) (a := t3009) (u := t1) (v := t3009) pv3089 (aw (ri t3009)) pv3009
theorem pv3087 : R t3087 t1 := result (f := t3016) (a := t1) (u := t3077) (v := t3090) pv3016 (awb t3023 t3009 t1 t1 (cI)) pv3090
theorem pv3088 : R t3088 t1 := result (f := t3087) (a := t1) (u := t1) (v := t1) pv3087 (aw (ri t1)) (refl t1)
theorem pv3084 : R t3084 t1 := result (f := t3082) (a := t1) (u := t3082) (v := t3088) (refl t3082) (awb t3016 t1 t1 t1 (cI)) pv3088
theorem pv3085 : R t3085 t1 := result (f := t3023) (a := t3084) (u := t1) (v := t3084) pv3023 (aw (ri t3084)) pv3084
theorem pv3086 : R t3086 t1 := result (f := t3085) (a := t3009) (u := t1) (v := t3009) pv3085 (aw (ri t3009)) pv3009
theorem pv3083 : R t3083 t1 := result (f := t3016) (a := t3082) (u := t3077) (v := t3086) pv3016 (awb t3023 t3009 t3082 t3084 (refl _)) pv3086
theorem pv3079 : R t3079 t1 := result (f := t3019) (a := t1) (u := t3019) (v := t3083) (refl t3019) (aw (ra t3016 t1)) pv3083
theorem pv3080 : R t3080 t1 := result (f := t3023) (a := t3079) (u := t1) (v := t3079) pv3023 (aw (ri t3079)) pv3079
theorem pv3081 : R t3081 t1 := result (f := t3080) (a := t3009) (u := t1) (v := t3009) pv3080 (aw (ri t3009)) pv3009
theorem pv3020 : R t3020 t1 := result (f := t3016) (a := t3019) (u := t3077) (v := t3081) pv3016 (awb t3023 t3009 t3019 t3079 (refl _)) pv3081
theorem pv3017 : R t3017 t1 := result (f := t0) (a := t3016) (u := t0) (v := t3020) (refl t0) (aw (rh t3016)) pv3020
theorem pv3018 : R t3018 t1 := result (f := t3017) (a := t3009) (u := t1) (v := t3009) pv3017 (aw (ri t3009)) pv3009
theorem pv3015 : R t3015 t1 := result (f := t3012) (a := t3014) (u := t3012) (v := t3018) (refl t3012) (awb t0 t3009 t3014 t3016 (refl _)) pv3018
theorem pv3013 : R t3013 t1 := result (f := t0) (a := t3012) (u := t0) (v := t3015) (refl t0) (aw (rh t3012)) pv3015
theorem pv3010 : R t3010 t1 := result (f := t2) (a := t3009) (u := t2) (v := t3013) (refl t2) (aw (ra t0 t3009)) pv3013
theorem pv3011 : R t3011 t1 := result (f := t3010) (a := t2703) (u := t1) (v := t2703) pv3010 (aw (ri t2703)) pv2703
theorem pv2716 : R t2716 t1 := result (f := t2712) (a := t2715) (u := t2706) (v := t3011) pv2712 (awb t2 t2703 t2715 t3009 (refl _)) pv3011
theorem pv2713 : R t2713 t1 := result (f := t0) (a := t2712) (u := t0) (v := t2716) (refl t0) (aw (rh t2712)) pv2716
theorem pv2714 : R t2714 t2706 := result (f := t2713) (a := t2706) (u := t1) (v := t2706) pv2713 (aw (ri t2706)) (refl t2706)
theorem pv2711 : R t2711 t2706 := result (f := t2708) (a := t2710) (u := t2708) (v := t2714) (refl t2708) (awb t0 t2706 t2710 t2712 (refl _)) pv2714
theorem pv2709 : R t2709 t2706 := result (f := t0) (a := t2708) (u := t0) (v := t2711) (refl t0) (aw (rh t2708)) pv2711
theorem pv2707 : R t2707 t2706 := result (f := t2) (a := t2706) (u := t2) (v := t2709) (refl t2) (aw (ra t0 t2706)) pv2709
theorem pv2704 : R t2704 t2706 := result (f := t59) (a := t2703) (u := t46) (v := t2707) pv59 (aw (ra t2 t2703)) pv2707
theorem pv2705 : R t2705 t1 := result (f := t2704) (a := t1) (u := t2706) (v := t2784) pv2704 (awb t2 t2703 t1 t1 (cI)) pv2784
theorem pv2258 : R t2258 t1 := result (f := t2254) (a := t2257) (u := t149) (v := t2705) pv2254 (awb t59 t1 t2257 t2703 (refl _)) pv2705
theorem pv2255 : R t2255 t1 := result (f := t0) (a := t2254) (u := t0) (v := t2258) (refl t0) (aw (rh t2254)) pv2258
theorem pv2256 : R t2256 t149 := result (f := t2255) (a := t2247) (u := t1) (v := t2247) pv2255 (aw (ri t2247)) pv2247
theorem pv2253 : R t2253 t149 := result (f := t2250) (a := t2252) (u := t2250) (v := t2256) (refl t2250) (awb t0 t2247 t2252 t2254 (refl _)) pv2256
theorem pv2251 : R t2251 t149 := result (f := t0) (a := t2250) (u := t0) (v := t2253) (refl t0) (aw (rh t2250)) pv2253
theorem pv2248 : R t2248 t149 := result (f := t2) (a := t2247) (u := t2) (v := t2251) (refl t2) (aw (ra t0 t2247)) pv2251
end Blc.H44.Pump
