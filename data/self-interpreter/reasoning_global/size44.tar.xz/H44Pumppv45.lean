import H44Pumppv44
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv3288 : R t3288 t3287 := result (f := t3284) (a := t3287) (u := t1) (v := t3287) pv3284 (aw (ri t3287)) (refl t3287)
theorem pv3285 : R t3285 t3287 := result (f := t0) (a := t3284) (u := t0) (v := t3288) (refl t0) (aw (rh t3284)) pv3288
theorem pv3342 : R t3342 t3341 := result (f := t3284) (a := t3341) (u := t1) (v := t3341) pv3284 (aw (ri t3341)) (refl t3341)
theorem pv3286 : R t3286 t3341 := result (f := t3285) (a := t3270) (u := t3287) (v := t3342) pv3285 (aw (ra t3284 t3270)) pv3342
theorem pv3283 : R t3283 t3341 := result (f := t3273) (a := t3282) (u := t3273) (v := t3286) (refl t3273) (awb t0 t3270 t3282 t3284 (refl _)) pv3286
theorem pv3277 : R t3277 t3341 := result (f := t3275) (a := t1) (u := t3275) (v := t3283) (refl t3275) (aw (ra t3273 t1)) pv3283
theorem pv3353 : R t3353 t1 := result (f := t3284) (a := t1) (u := t1) (v := t1) pv3284 (aw (ri t1)) (refl t1)
theorem pv3354 : R t3354 t1 := result (f := t3353) (a := t3270) (u := t1) (v := t3270) pv3353 (aw (ri t3270)) pv3270
theorem pv3351 : R t3351 t1 := result (f := t3277) (a := t1) (u := t3341) (v := t3354) pv3277 (awb t3284 t3270 t1 t1 (cI)) pv3354
theorem pv3352 : R t3352 t1 := result (f := t3351) (a := t1) (u := t1) (v := t1) pv3351 (aw (ri t1)) (refl t1)
theorem pv3348 : R t3348 t1 := result (f := t3346) (a := t1) (u := t3346) (v := t3352) (refl t3346) (awb t3277 t1 t1 t1 (cI)) pv3352
theorem pv3349 : R t3349 t1 := result (f := t3284) (a := t3348) (u := t1) (v := t3348) pv3284 (aw (ri t3348)) pv3348
theorem pv3350 : R t3350 t1 := result (f := t3349) (a := t3270) (u := t1) (v := t3270) pv3349 (aw (ri t3270)) pv3270
theorem pv3347 : R t3347 t1 := result (f := t3277) (a := t3346) (u := t3341) (v := t3350) pv3277 (awb t3284 t3270 t3346 t3348 (refl _)) pv3350
theorem pv3343 : R t3343 t1 := result (f := t3280) (a := t1) (u := t3280) (v := t3347) (refl t3280) (aw (ra t3277 t1)) pv3347
theorem pv3344 : R t3344 t1 := result (f := t3284) (a := t3343) (u := t1) (v := t3343) pv3284 (aw (ri t3343)) pv3343
theorem pv3345 : R t3345 t1 := result (f := t3344) (a := t3270) (u := t1) (v := t3270) pv3344 (aw (ri t3270)) pv3270
theorem pv3281 : R t3281 t1 := result (f := t3277) (a := t3280) (u := t3341) (v := t3345) pv3277 (awb t3284 t3270 t3280 t3343 (refl _)) pv3345
theorem pv3278 : R t3278 t1 := result (f := t0) (a := t3277) (u := t0) (v := t3281) (refl t0) (aw (rh t3277)) pv3281
theorem pv3279 : R t3279 t1 := result (f := t3278) (a := t3270) (u := t1) (v := t3270) pv3278 (aw (ri t3270)) pv3270
theorem pv3276 : R t3276 t1 := result (f := t3273) (a := t3275) (u := t3273) (v := t3279) (refl t3273) (awb t0 t3270 t3275 t3277 (refl _)) pv3279
theorem pv3274 : R t3274 t1 := result (f := t0) (a := t3273) (u := t0) (v := t3276) (refl t0) (aw (rh t3273)) pv3276
theorem pv3271 : R t3271 t1 := result (f := t2) (a := t3270) (u := t2) (v := t3274) (refl t2) (aw (ra t0 t3270)) pv3274
theorem pv3272 : R t3272 t1 := result (f := t3271) (a := t3243) (u := t1) (v := t3243) pv3271 (aw (ri t3243)) pv3243
theorem pv3263 : R t3263 t1 := result (f := t3259) (a := t3262) (u := t3246) (v := t3272) pv3259 (awb t2 t3243 t3262 t3270 (refl _)) pv3272
theorem pv3260 : R t3260 t1 := result (f := t0) (a := t3259) (u := t0) (v := t3263) (refl t0) (aw (rh t3259)) pv3263
theorem pv3261 : R t3261 t3246 := result (f := t3260) (a := t3246) (u := t1) (v := t3246) pv3260 (aw (ri t3246)) (refl t3246)
theorem pv3258 : R t3258 t3246 := result (f := t3248) (a := t3257) (u := t3248) (v := t3261) (refl t3248) (awb t0 t3246 t3257 t3259 (refl _)) pv3261
theorem pv3252 : R t3252 t3246 := result (f := t3250) (a := t1) (u := t3250) (v := t3258) (refl t3250) (aw (ra t3248 t1)) pv3258
theorem pv3378 : R t3378 t3377 := result (f := t1) (a := t3377) (u := t1) (v := t3377) (refl t1) (aw (ri t3377)) (refl t3377)
theorem pv3376 : R t3376 t3377 := result (f := t22) (a := t3355) (u := t24) (v := t3378) pv22 (aw (ra t1 t3355)) pv3378
theorem pv3374 : R t3374 t3377 := result (f := t3358) (a := t1) (u := t3358) (v := t3376) (refl t3358) (awb t0 t3355 t1 t1 (cI)) pv3376
theorem pv3405 : R t3405 t3404 := result (f := t1) (a := t3404) (u := t1) (v := t3404) (refl t1) (aw (ri t3404)) (refl t3404)
theorem pv3403 : R t3403 t3404 := result (f := t22) (a := t3382) (u := t24) (v := t3405) pv22 (aw (ra t1 t3382)) pv3405
theorem pv3401 : R t3401 t3404 := result (f := t3385) (a := t1) (u := t3385) (v := t3403) (refl t3385) (awb t0 t3382 t1 t1 (cI)) pv3403
theorem pv3407 : R t3407 t1 := result (f := t3252) (a := t1) (u := t3246) (v := t3324) pv3252 (awb t2 t3243 t1 t1 (cI)) pv3324
theorem pv3408 : R t3408 t1 := result (f := t3407) (a := t1) (u := t1) (v := t1) pv3407 (aw (ri t1)) (refl t1)
theorem pv3382 : R t3382 t1 := result (f := t3380) (a := t1) (u := t3380) (v := t3408) (refl t3380) (awb t3252 t1 t1 t1 (cI)) pv3408
theorem pv3406 : R t3406 t1 := result (f := t28) (a := t3382) (u := t1) (v := t3382) pv28 (aw (ri t3382)) pv3382
theorem pv3402 : R t3402 t1 := result (f := t3401) (a := t1) (u := t3404) (v := t3406) pv3401 (awb t1 t3382 t1 t1 (cI)) pv3406
theorem pv3396 : R t3396 t1 := result (f := t3394) (a := t1) (u := t3394) (v := t3402) (refl t3394) (awb t3385 t1 t1 t1 (cI)) pv3402
theorem pv3400 : R t3400 t3399 := result (f := t3396) (a := t3399) (u := t1) (v := t3399) pv3396 (aw (ri t3399)) (refl t3399)
theorem pv3397 : R t3397 t3399 := result (f := t0) (a := t3396) (u := t0) (v := t3400) (refl t0) (aw (rh t3396)) pv3400
theorem pv3410 : R t3410 t3409 := result (f := t3396) (a := t3409) (u := t1) (v := t3409) pv3396 (aw (ri t3409)) (refl t3409)
theorem pv3398 : R t3398 t3409 := result (f := t3397) (a := t3382) (u := t3399) (v := t3410) pv3397 (aw (ra t3396 t3382)) pv3410
theorem pv3395 : R t3395 t3409 := result (f := t3385) (a := t3394) (u := t3385) (v := t3398) (refl t3385) (awb t0 t3382 t3394 t3396 (refl _)) pv3398
theorem pv3389 : R t3389 t3409 := result (f := t3387) (a := t1) (u := t3387) (v := t3395) (refl t3387) (aw (ra t3385 t1)) pv3395
theorem pv3421 : R t3421 t1 := result (f := t3396) (a := t1) (u := t1) (v := t1) pv3396 (aw (ri t1)) (refl t1)
theorem pv3422 : R t3422 t1 := result (f := t3421) (a := t3382) (u := t1) (v := t3382) pv3421 (aw (ri t3382)) pv3382
theorem pv3419 : R t3419 t1 := result (f := t3389) (a := t1) (u := t3409) (v := t3422) pv3389 (awb t3396 t3382 t1 t1 (cI)) pv3422
theorem pv3420 : R t3420 t1 := result (f := t3419) (a := t1) (u := t1) (v := t1) pv3419 (aw (ri t1)) (refl t1)
theorem pv3416 : R t3416 t1 := result (f := t3414) (a := t1) (u := t3414) (v := t3420) (refl t3414) (awb t3389 t1 t1 t1 (cI)) pv3420
theorem pv3417 : R t3417 t1 := result (f := t3396) (a := t3416) (u := t1) (v := t3416) pv3396 (aw (ri t3416)) pv3416
theorem pv3418 : R t3418 t1 := result (f := t3417) (a := t3382) (u := t1) (v := t3382) pv3417 (aw (ri t3382)) pv3382
theorem pv3415 : R t3415 t1 := result (f := t3389) (a := t3414) (u := t3409) (v := t3418) pv3389 (awb t3396 t3382 t3414 t3416 (refl _)) pv3418
end Blc.H44.Pump
