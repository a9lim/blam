import H44Pumppv72
namespace Blc.H44.Pump
set_option maxRecDepth 20000
theorem pv5235 : R t5235 t1 := result (f := t5219) (a := t5234) (u := t1) (v := t5234) pv5219 (aw (ri t5234)) pv5234
theorem pv5236 : R t5236 t1 := result (f := t5235) (a := t5205) (u := t1) (v := t5205) pv5235 (aw (ri t5205)) pv5205
theorem pv5216 : R t5216 t1 := result (f := t5212) (a := t5215) (u := t5232) (v := t5236) pv5212 (awb t5219 t5205 t5215 t5234 (refl _)) pv5236
theorem pv5213 : R t5213 t1 := result (f := t0) (a := t5212) (u := t0) (v := t5216) (refl t0) (aw (rh t5212)) pv5216
theorem pv5214 : R t5214 t1 := result (f := t5213) (a := t5205) (u := t1) (v := t5205) pv5213 (aw (ri t5205)) pv5205
theorem pv5211 : R t5211 t1 := result (f := t5208) (a := t5210) (u := t5208) (v := t5214) (refl t5208) (awb t0 t5205 t5210 t5212 (refl _)) pv5214
theorem pv5209 : R t5209 t1 := result (f := t0) (a := t5208) (u := t0) (v := t5211) (refl t0) (aw (rh t5208)) pv5211
theorem pv5206 : R t5206 t1 := result (f := t2) (a := t5205) (u := t2) (v := t5209) (refl t2) (aw (ra t0 t5205)) pv5209
theorem pv5207 : R t5207 t1 := result (f := t5206) (a := t4872) (u := t1) (v := t4872) pv5206 (aw (ri t4872)) pv4872
theorem pv5204 : R t5204 t1 := result (f := t4881) (a := t5203) (u := t4875) (v := t5207) pv4881 (awb t2 t4872 t5203 t5205 (refl _)) pv5207
theorem pv5178 : R t5178 t1 := result (f := t4884) (a := t1) (u := t4884) (v := t5204) (refl t4884) (aw (ra t4881 t1)) pv5204
theorem pv5202 : R t5202 t1 := result (f := t28) (a := t5178) (u := t1) (v := t5178) pv28 (aw (ri t5178)) pv5178
theorem pv5198 : R t5198 t1 := result (f := t5197) (a := t1) (u := t5200) (v := t5202) pv5197 (awb t1 t5178 t1 t1 (cI)) pv5202
theorem pv5192 : R t5192 t1 := result (f := t5190) (a := t1) (u := t5190) (v := t5198) (refl t5190) (awb t5181 t1 t1 t1 (cI)) pv5198
theorem pv5196 : R t5196 t5195 := result (f := t5192) (a := t5195) (u := t1) (v := t5195) pv5192 (aw (ri t5195)) (refl t5195)
theorem pv5193 : R t5193 t5195 := result (f := t0) (a := t5192) (u := t0) (v := t5196) (refl t0) (aw (rh t5192)) pv5196
theorem pv5247 : R t5247 t5246 := result (f := t5192) (a := t5246) (u := t1) (v := t5246) pv5192 (aw (ri t5246)) (refl t5246)
theorem pv5194 : R t5194 t5246 := result (f := t5193) (a := t5178) (u := t5195) (v := t5247) pv5193 (aw (ra t5192 t5178)) pv5247
theorem pv5191 : R t5191 t5246 := result (f := t5181) (a := t5190) (u := t5181) (v := t5194) (refl t5181) (awb t0 t5178 t5190 t5192 (refl _)) pv5194
theorem pv5185 : R t5185 t5246 := result (f := t5183) (a := t1) (u := t5183) (v := t5191) (refl t5183) (aw (ra t5181 t1)) pv5191
theorem pv5258 : R t5258 t1 := result (f := t5192) (a := t1) (u := t1) (v := t1) pv5192 (aw (ri t1)) (refl t1)
theorem pv5259 : R t5259 t1 := result (f := t5258) (a := t5178) (u := t1) (v := t5178) pv5258 (aw (ri t5178)) pv5178
theorem pv5256 : R t5256 t1 := result (f := t5185) (a := t1) (u := t5246) (v := t5259) pv5185 (awb t5192 t5178 t1 t1 (cI)) pv5259
theorem pv5257 : R t5257 t1 := result (f := t5256) (a := t1) (u := t1) (v := t1) pv5256 (aw (ri t1)) (refl t1)
theorem pv5253 : R t5253 t1 := result (f := t5251) (a := t1) (u := t5251) (v := t5257) (refl t5251) (awb t5185 t1 t1 t1 (cI)) pv5257
theorem pv5254 : R t5254 t1 := result (f := t5192) (a := t5253) (u := t1) (v := t5253) pv5192 (aw (ri t5253)) pv5253
theorem pv5255 : R t5255 t1 := result (f := t5254) (a := t5178) (u := t1) (v := t5178) pv5254 (aw (ri t5178)) pv5178
theorem pv5252 : R t5252 t1 := result (f := t5185) (a := t5251) (u := t5246) (v := t5255) pv5185 (awb t5192 t5178 t5251 t5253 (refl _)) pv5255
theorem pv5248 : R t5248 t1 := result (f := t5188) (a := t1) (u := t5188) (v := t5252) (refl t5188) (aw (ra t5185 t1)) pv5252
theorem pv5249 : R t5249 t1 := result (f := t5192) (a := t5248) (u := t1) (v := t5248) pv5192 (aw (ri t5248)) pv5248
theorem pv5250 : R t5250 t1 := result (f := t5249) (a := t5178) (u := t1) (v := t5178) pv5249 (aw (ri t5178)) pv5178
theorem pv5189 : R t5189 t1 := result (f := t5185) (a := t5188) (u := t5246) (v := t5250) pv5185 (awb t5192 t5178 t5188 t5248 (refl _)) pv5250
theorem pv5186 : R t5186 t1 := result (f := t0) (a := t5185) (u := t0) (v := t5189) (refl t0) (aw (rh t5185)) pv5189
theorem pv5187 : R t5187 t1 := result (f := t5186) (a := t5178) (u := t1) (v := t5178) pv5186 (aw (ri t5178)) pv5178
theorem pv5184 : R t5184 t1 := result (f := t5181) (a := t5183) (u := t5181) (v := t5187) (refl t5181) (awb t0 t5178 t5183 t5185 (refl _)) pv5187
theorem pv5182 : R t5182 t1 := result (f := t0) (a := t5181) (u := t0) (v := t5184) (refl t0) (aw (rh t5181)) pv5184
theorem pv5179 : R t5179 t1 := result (f := t2) (a := t5178) (u := t2) (v := t5182) (refl t2) (aw (ra t0 t5178)) pv5182
theorem pv5180 : R t5180 t1 := result (f := t5179) (a := t4872) (u := t1) (v := t4872) pv5179 (aw (ri t4872)) pv4872
theorem pv4885 : R t4885 t1 := result (f := t4881) (a := t4884) (u := t4875) (v := t5180) pv4881 (awb t2 t4872 t4884 t5178 (refl _)) pv5180
theorem pv4882 : R t4882 t1 := result (f := t0) (a := t4881) (u := t0) (v := t4885) (refl t0) (aw (rh t4881)) pv4885
theorem pv4883 : R t4883 t4875 := result (f := t4882) (a := t4875) (u := t1) (v := t4875) pv4882 (aw (ri t4875)) (refl t4875)
theorem pv4880 : R t4880 t4875 := result (f := t4877) (a := t4879) (u := t4877) (v := t4883) (refl t4877) (awb t0 t4875 t4879 t4881 (refl _)) pv4883
theorem pv4878 : R t4878 t4875 := result (f := t0) (a := t4877) (u := t0) (v := t4880) (refl t0) (aw (rh t4877)) pv4880
theorem pv4876 : R t4876 t4875 := result (f := t2) (a := t4875) (u := t2) (v := t4878) (refl t2) (aw (ra t0 t4875)) pv4878
theorem pv4873 : R t4873 t4875 := result (f := t59) (a := t4872) (u := t46) (v := t4876) pv59 (aw (ra t2 t4872)) pv4876
theorem pv4874 : R t4874 t1 := result (f := t4873) (a := t1) (u := t4875) (v := t4953) pv4873 (awb t2 t4872 t1 t1 (cI)) pv4953
theorem pv4822 : R t4822 t1 := result (f := t4818) (a := t4821) (u := t149) (v := t4874) pv4818 (awb t59 t1 t4821 t4872 (refl _)) pv4874
theorem pv4819 : R t4819 t1 := result (f := t0) (a := t4818) (u := t0) (v := t4822) (refl t0) (aw (rh t4818)) pv4822
theorem pv4820 : R t4820 t149 := result (f := t4819) (a := t4804) (u := t1) (v := t4804) pv4819 (aw (ri t4804)) pv4804
theorem pv4817 : R t4817 t149 := result (f := t4807) (a := t4816) (u := t4807) (v := t4820) (refl t4807) (awb t0 t4804 t4816 t4818 (refl _)) pv4820
theorem pv4811 : R t4811 t149 := result (f := t4809) (a := t1) (u := t4809) (v := t4817) (refl t4809) (aw (ra t4807 t1)) pv4817
theorem pv5285 : R t5285 t5284 := result (f := t1) (a := t5284) (u := t1) (v := t5284) (refl t1) (aw (ri t5284)) (refl t5284)
theorem pv5283 : R t5283 t5284 := result (f := t22) (a := t5263) (u := t24) (v := t5285) pv22 (aw (ra t1 t5263)) pv5285
theorem pv5281 : R t5281 t5284 := result (f := t5265) (a := t1) (u := t5265) (v := t5283) (refl t5265) (awb t0 t5263 t1 t1 (cI)) pv5283
theorem pv5286 : R t5286 t5263 := result (f := t28) (a := t5263) (u := t1) (v := t5263) pv28 (aw (ri t5263)) (refl t5263)
end Blc.H44.Pump
