"""Produce the raw C++, Rust and C inventories using the archived sources."""
import hashlib, os, subprocess, sys, tempfile, time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
BASE = Path(__file__).resolve().parent
JOBS = [
    ('enum', ['clang++','-std=c++20','-O3','enum.cpp'], [], 'wires.txt'),
    ('cross', ['rustc','--edition=2021','-O','cross.rs'], [], 'cross.txt'),
    ('audit', ['clang','-O3','-x','c','audit-source.txt'], ['44'], 'audit-wires.txt'),
]
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def generate(dest):
    def run(job):
        name,cc,args,filename=job
        with tempfile.TemporaryDirectory(dir=dest) as tmp:
            exe=Path(tmp)/name
            subprocess.run([*cc,'-o',exe],cwd=BASE,check=True,timeout=90)
            with (dest/filename).open('wb') as out,(dest/(name+'-counts.txt')).open('wb') as log:
                subprocess.run([exe,*args],cwd=BASE,stdout=out,stderr=log,check=True,timeout=540)
        return name
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,JOBS))
