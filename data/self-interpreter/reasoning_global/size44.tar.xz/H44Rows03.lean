import H44Literals
import H44Lib0
import H44Lib1
import H44Lib101
import H44Lib4
namespace Blc.H44
theorem ex_e4817624501882 : ¬ IsSelfInterpreter e4817624501882 := Lib4.excluded (by decide : Types.has Lib4.tab Lib4.env e4817624501882 4 = true)
#print axioms ex_e4817624501882
theorem ex_e4834204585782 : ¬ IsSelfInterpreter e4834204585782 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4834204585782 1 = true)
#print axioms ex_e4834204585782
theorem ex_e4834573684534 : ¬ IsSelfInterpreter e4834573684534 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4834573684534 1 = true)
#print axioms ex_e4834573684534
theorem ex_e4834573684538 : ¬ IsSelfInterpreter e4834573684538 := Lib101.excluded (by decide : Types.has Lib101.tab Lib101.env e4834573684538 5 = true)
#print axioms ex_e4834573684538
theorem ex_e4836586950454 : ¬ IsSelfInterpreter e4836586950454 := Lib0.excluded (by decide : Types.has Lib0.tab Lib0.env e4836586950454 1 = true)
#print axioms ex_e4836586950454
theorem ex_e4836586950458 : ¬ IsSelfInterpreter e4836586950458 := Lib1.excluded (by decide : Types.has Lib1.tab Lib1.env e4836586950458 3 = true)
#print axioms ex_e4836586950458
end Blc.H44
