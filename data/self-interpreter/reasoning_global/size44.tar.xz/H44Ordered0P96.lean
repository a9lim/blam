import H44Ordered0P64
namespace Blc.H44Chain
open Term SelfintControl SelfintLowerBound ChainModel
set_option maxRecDepth 30000
set_option maxHeartbeats 3000000
theorem oh0_96 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 2) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_80 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 2 2 = 3)
theorem oh0_97 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 2) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_82 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 2 2 = 3)
theorem oh0_98 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 2) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_84 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_99 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 2) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_86 ρ a0 a2) (oh0_30 ρ a1) (by decide : opm0 3 2 = 3)
theorem oh0_100 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_96 (push 0 ρ) rfl a0 a1)
    · exact (oh0_97 (push 1 ρ) rfl a0 a1)
    · exact (oh0_98 (push 2 ρ) rfl a0 a1)
    · exact (oh0_99 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_101 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_30 ρ a1) (oh0_100 ρ a0 a1) (by decide : opm0 2 3 = 3)
theorem oh0_102 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 3) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_80 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 2 3 = 3)
theorem oh0_103 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 3) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_82 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 2 3 = 3)
theorem oh0_104 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 3) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_84 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_105 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 3) (a2 : ρ 2 = 2) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_86 ρ a0 a2) (oh0_37 ρ a1) (by decide : opm0 3 3 = 3)
theorem oh0_106 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_102 (push 0 ρ) rfl a0 a1)
    · exact (oh0_103 (push 1 ρ) rfl a0 a1)
    · exact (oh0_104 (push 2 ρ) rfl a0 a1)
    · exact (oh0_105 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_107 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 2) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_30 ρ a1) (oh0_106 ρ a0 a1) (by decide : opm0 2 3 = 3)
theorem oh0_108 (ρ : Env 3) (a0 : ρ 0 = 2) : eval gm0 ρ ob0_11 = 1 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_10) = 1
  have h : (fun a => eval gm0 (push a ρ) ob0_10) = (fun a : Fin 4 => if a = 0 then 2 else if a = 1 then 2 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_89 (push 0 ρ) rfl a0)
    · exact (oh0_95 (push 1 ρ) rfl a0)
    · exact (oh0_101 (push 2 ρ) rfl a0)
    · exact (oh0_107 (push 3 ρ) rfl a0)
  rw [h]
  decide
theorem oh0_109 (ρ : Env 3) (a0 : ρ 0 = 2) : eval gm0 ρ ob0_12 = 2 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_0) (a := ob0_11) (oh0_4 ρ a0) (oh0_108 ρ a0) (by decide : opm0 2 1 = 2)
theorem oh0_110 (ρ : Env 3) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_4 = 3 := by
  exact a2
theorem oh0_111 (ρ : Env 3) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_6 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_4) (a := ob0_5) (oh0_110 ρ a2) (oh0_11 ρ) (by decide : opm0 3 1 = 3)
theorem oh0_112 (ρ : Env 3) (a0 : ρ 0 = 0) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_111 ρ a2) (oh0_0 ρ a0) (by decide : opm0 3 0 = 3)
theorem oh0_113 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 0) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_112 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_114 (ρ : Env 3) (a0 : ρ 0 = 1) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_111 ρ a2) (oh0_2 ρ a0) (by decide : opm0 3 1 = 3)
theorem oh0_115 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 0) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_114 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_116 (ρ : Env 3) (a0 : ρ 0 = 2) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_111 ρ a2) (oh0_4 ρ a0) (by decide : opm0 3 2 = 3)
theorem oh0_117 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 0) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_116 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_118 (ρ : Env 3) (a0 : ρ 0 = 3) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_7 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_6) (a := ob0_0) (oh0_111 ρ a2) (oh0_6 ρ a0) (by decide : opm0 3 3 = 3)
theorem oh0_119 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 0) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_118 ρ a0 a2) (oh0_9 ρ a1) (by decide : opm0 3 0 = 3)
theorem oh0_120 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_113 (push 0 ρ) rfl a0 a1)
    · exact (oh0_115 (push 1 ρ) rfl a0 a1)
    · exact (oh0_117 (push 2 ρ) rfl a0 a1)
    · exact (oh0_119 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_121 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_37 ρ a1) (oh0_120 ρ a0 a1) (by decide : opm0 3 3 = 3)
theorem oh0_122 (ρ : Env 3) (a0 : ρ 0 = 0) (a1 : ρ 1 = 1) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_112 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_123 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 1) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_114 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_124 (ρ : Env 3) (a0 : ρ 0 = 2) (a1 : ρ 1 = 1) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_116 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_125 (ρ : Env 3) (a0 : ρ 0 = 3) (a1 : ρ 1 = 1) (a2 : ρ 2 = 3) : eval gm0 ρ ob0_8 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_7) (a := ob0_3) (oh0_118 ρ a0 a2) (oh0_23 ρ a1) (by decide : opm0 3 1 = 3)
theorem oh0_126 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_9 = 3 := by
  change pick gm0 (fun a => eval gm0 (push a ρ) ob0_8) = 3
  have h : (fun a => eval gm0 (push a ρ) ob0_8) = (fun a : Fin 4 => if a = 0 then 3 else if a = 1 then 3 else if a = 2 then 3 else 3) := by
    funext a
    have hall : ∀ a : Fin 4, a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 := by decide
    rcases hall a with rfl | rfl | rfl | rfl
    · exact (oh0_122 (push 0 ρ) rfl a0 a1)
    · exact (oh0_123 (push 1 ρ) rfl a0 a1)
    · exact (oh0_124 (push 2 ρ) rfl a0 a1)
    · exact (oh0_125 (push 3 ρ) rfl a0 a1)
  rw [h]
  decide
theorem oh0_127 (ρ : Env 3) (a0 : ρ 0 = 1) (a1 : ρ 1 = 3) : eval gm0 ρ ob0_10 = 3 := by
  exact appEq (G := gm0) (ρ := ρ) (f := ob0_3) (a := ob0_9) (oh0_37 ρ a1) (oh0_126 ρ a0 a1) (by decide : opm0 3 3 = 3)
end Blc.H44Chain
