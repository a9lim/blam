import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419143195254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143195254 : Closed e2419143195254 ∧ code e2419143195254 = 11215236217462 := by decide
theorem cert_e2419143195254 : check e2419143195254 [[],[]] .sourceHead = true := by decide
def e2419143195258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143195258 : Closed e2419143195258 ∧ code e2419143195258 = 11215236217466 := by decide
theorem cert_e2419143195258 : check e2419143195258 [[],[]] .sourceHead = true := by decide
def e2419143195446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143195446 : Closed e2419143195446 ∧ code e2419143195446 = 11215236217654 := by decide
theorem cert_e2419143195446 : check e2419143195446 [[],[]] .sourceHead = true := by decide
def e2419143195450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143195450 : Closed e2419143195450 ∧ code e2419143195450 = 11215236217658 := by decide
theorem cert_e2419143195450 : check e2419143195450 [[],[]] .sourceHead = true := by decide
def e2419143195546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143195546 : Closed e2419143195546 ∧ code e2419143195546 = 11215236217754 := by decide
theorem cert_e2419143195546 : check e2419143195546 [[],[]] .sourceHead = true := by decide
def e2419143197142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2419143197142 : Closed e2419143197142 ∧ code e2419143197142 = 11215236219350 := by decide
theorem cert_e2419143197142 : check e2419143197142 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143197146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2419143197146 : Closed e2419143197146 ∧ code e2419143197146 = 11215236219354 := by decide
theorem cert_e2419143197146 : check e2419143197146 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143197162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2419143197162 : Closed e2419143197162 ∧ code e2419143197162 = 11215236219370 := by decide
theorem cert_e2419143197162 : check e2419143197162 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143197526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2419143197526 : Closed e2419143197526 ∧ code e2419143197526 = 11215236219734 := by decide
private def t_e2419143197526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem cert_e2419143197526 : ¬ IsSelfInterpreter e2419143197526 :=
  wSource (t := t_e2419143197526) (replay_sound (ps := []) (t := e2419143197526) (by decide)) (by decide)
def e2419143197530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2419143197530 : Closed e2419143197530 ∧ code e2419143197530 = 11215236219738 := by decide
private def t_e2419143197530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem cert_e2419143197530 : ¬ IsSelfInterpreter e2419143197530 :=
  wSource (t := t_e2419143197530) (replay_sound (ps := []) (t := e2419143197530) (by decide)) (by decide)
def e2419143197910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2419143197910 : Closed e2419143197910 ∧ code e2419143197910 = 11215236220118 := by decide
theorem cert_e2419143197910 : check e2419143197910 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143197914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2419143197914 : Closed e2419143197914 ∧ code e2419143197914 = 11215236220122 := by decide
theorem cert_e2419143197914 : check e2419143197914 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143197930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2419143197930 : Closed e2419143197930 ∧ code e2419143197930 = 11215236220138 := by decide
theorem cert_e2419143197930 : check e2419143197930 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143198006 : Closed e2419143198006 ∧ code e2419143198006 = 11215236220214 := by decide
theorem cert_e2419143198006 : check e2419143198006 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143198010 : Closed e2419143198010 ∧ code e2419143198010 = 11215236220218 := by decide
theorem cert_e2419143198010 : check e2419143198010 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143198106 : Closed e2419143198106 ∧ code e2419143198106 = 11215236220314 := by decide
theorem cert_e2419143198106 : check e2419143198106 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2419143198262 : Closed e2419143198262 ∧ code e2419143198262 = 11215236220470 := by decide
theorem cert_e2419143198262 : check e2419143198262 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2419143198266 : Closed e2419143198266 ∧ code e2419143198266 = 11215236220474 := by decide
theorem cert_e2419143198266 : check e2419143198266 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2419143198350 : Closed e2419143198350 ∧ code e2419143198350 = 11215236220558 := by decide
theorem cert_e2419143198350 : check e2419143198350 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2419143198406 : Closed e2419143198406 ∧ code e2419143198406 = 11215236220614 := by decide
theorem cert_e2419143198406 : check e2419143198406 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2419143198490 : Closed e2419143198490 ∧ code e2419143198490 = 11215236220698 := by decide
theorem cert_e2419143198490 : check e2419143198490 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143198534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2419143198534 : Closed e2419143198534 ∧ code e2419143198534 = 11215236220742 := by decide
theorem cert_e2419143198534 : check e2419143198534 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143199830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2419143199830 : Closed e2419143199830 ∧ code e2419143199830 = 11215236222038 := by decide
theorem cert_e2419143199830 : check e2419143199830 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143199834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2419143199834 : Closed e2419143199834 ∧ code e2419143199834 = 11215236222042 := by decide
theorem cert_e2419143199834 : check e2419143199834 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2419143200022 : Closed e2419143200022 ∧ code e2419143200022 = 11215236222230 := by decide
theorem cert_e2419143200022 : check e2419143200022 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2419143200098 : Closed e2419143200098 ∧ code e2419143200098 = 11215236222306 := by decide
theorem cert_e2419143200098 : check e2419143200098 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2419143200110 : Closed e2419143200110 ∧ code e2419143200110 = 11215236222318 := by decide
theorem cert_e2419143200110 : check e2419143200110 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143200118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2419143200118 : Closed e2419143200118 ∧ code e2419143200118 = 11215236222326 := by decide
def e2419143200138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2419143200138 : Closed e2419143200138 ∧ code e2419143200138 = 11215236222346 := by decide
theorem cert_e2419143200138 : check e2419143200138 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2419143200162 : Closed e2419143200162 ∧ code e2419143200162 = 11215236222370 := by decide
theorem cert_e2419143200162 : check e2419143200162 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2419143200174 : Closed e2419143200174 ∧ code e2419143200174 = 11215236222382 := by decide
theorem cert_e2419143200174 : check e2419143200174 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143200182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2419143200182 : Closed e2419143200182 ∧ code e2419143200182 = 11215236222390 := by decide
theorem cert_e2419143200182 : check e2419143200182 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2419143200186 : Closed e2419143200186 ∧ code e2419143200186 = 11215236222394 := by decide
def e2419143200214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2419143200214 : Closed e2419143200214 ∧ code e2419143200214 = 11215236222422 := by decide
def e2419143200218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2419143200218 : Closed e2419143200218 ∧ code e2419143200218 = 11215236222426 := by decide
theorem cert_e2419143200218 : check e2419143200218 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143200298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2419143200298 : Closed e2419143200298 ∧ code e2419143200298 = 11215236222506 := by decide
theorem cert_e2419143200298 : check e2419143200298 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2419143200394 : Closed e2419143200394 ∧ code e2419143200394 = 11215236222602 := by decide
theorem cert_e2419143200394 : check e2419143200394 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2419143200418 : Closed e2419143200418 ∧ code e2419143200418 = 11215236222626 := by decide
theorem cert_e2419143200418 : check e2419143200418 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2419143200430 : Closed e2419143200430 ∧ code e2419143200430 = 11215236222638 := by decide
theorem cert_e2419143200430 : check e2419143200430 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143200438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2419143200438 : Closed e2419143200438 ∧ code e2419143200438 = 11215236222646 := by decide
theorem cert_e2419143200438 : check e2419143200438 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2419143200442 : Closed e2419143200442 ∧ code e2419143200442 = 11215236222650 := by decide
theorem cert_e2419143200442 : check e2419143200442 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143200470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2419143200470 : Closed e2419143200470 ∧ code e2419143200470 = 11215236222678 := by decide
theorem cert_e2419143200470 : check e2419143200470 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2419143200474 : Closed e2419143200474 ∧ code e2419143200474 = 11215236222682 := by decide
theorem cert_e2419143200474 : check e2419143200474 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2419143200490 : Closed e2419143200490 ∧ code e2419143200490 = 11215236222698 := by decide
theorem cert_e2419143200490 : check e2419143200490 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143200598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2419143200598 : Closed e2419143200598 ∧ code e2419143200598 = 11215236222806 := by decide
def e2419143200602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2419143200602 : Closed e2419143200602 ∧ code e2419143200602 = 11215236222810 := by decide
theorem cert_e2419143200602 : check e2419143200602 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419143200618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2419143200618 : Closed e2419143200618 ∧ code e2419143200618 = 11215236222826 := by decide
def e2419143200886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2419143200886 : Closed e2419143200886 ∧ code e2419143200886 = 11215236223094 := by decide
theorem cert_e2419143200886 : check e2419143200886 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2419143200890 : Closed e2419143200890 ∧ code e2419143200890 = 11215236223098 := by decide
theorem cert_e2419143200890 : check e2419143200890 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143200982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2419143200982 : Closed e2419143200982 ∧ code e2419143200982 = 11215236223190 := by decide
theorem cert_e2419143200982 : check e2419143200982 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2419143201078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143201078 : Closed e2419143201078 ∧ code e2419143201078 = 11215236223286 := by decide
theorem cert_e2419143201078 : check e2419143201078 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143201082 : Closed e2419143201082 ∧ code e2419143201082 = 11215236223290 := by decide
theorem cert_e2419143201082 : check e2419143201082 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2419143201166 : Closed e2419143201166 ∧ code e2419143201166 = 11215236223374 := by decide
theorem cert_e2419143201166 : check e2419143201166 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2419143201222 : Closed e2419143201222 ∧ code e2419143201222 = 11215236223430 := by decide
theorem cert_e2419143201222 : check e2419143201222 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2419143201558 : Closed e2419143201558 ∧ code e2419143201558 = 11215236223766 := by decide
theorem cert_e2419143201558 : check e2419143201558 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2419143201634 : Closed e2419143201634 ∧ code e2419143201634 = 11215236223842 := by decide
theorem cert_e2419143201634 : check e2419143201634 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2419143201646 : Closed e2419143201646 ∧ code e2419143201646 = 11215236223854 := by decide
theorem cert_e2419143201646 : check e2419143201646 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143201654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2419143201654 : Closed e2419143201654 ∧ code e2419143201654 = 11215236223862 := by decide
def e2419143201674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143201674 : Closed e2419143201674 ∧ code e2419143201674 = 11215236223882 := by decide
theorem cert_e2419143201674 : check e2419143201674 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143201698 : Closed e2419143201698 ∧ code e2419143201698 = 11215236223906 := by decide
theorem cert_e2419143201698 : check e2419143201698 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2419143201710 : Closed e2419143201710 ∧ code e2419143201710 = 11215236223918 := by decide
theorem cert_e2419143201710 : check e2419143201710 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143201718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2419143201718 : Closed e2419143201718 ∧ code e2419143201718 = 11215236223926 := by decide
theorem cert_e2419143201718 : check e2419143201718 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143201722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2419143201722 : Closed e2419143201722 ∧ code e2419143201722 = 11215236223930 := by decide
theorem cert_e2419143201722 : check e2419143201722 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143201750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2419143201750 : Closed e2419143201750 ∧ code e2419143201750 = 11215236223958 := by decide
def e2419143201754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2419143201754 : Closed e2419143201754 ∧ code e2419143201754 = 11215236223962 := by decide
def e2419143201822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2419143201822 : Closed e2419143201822 ∧ code e2419143201822 = 11215236224030 := by decide
theorem cert_e2419143201822 : check e2419143201822 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143202018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2419143202018 : Closed e2419143202018 ∧ code e2419143202018 = 11215236224226 := by decide
theorem cert_e2419143202018 : check e2419143202018 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143202030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143202030 : Closed e2419143202030 ∧ code e2419143202030 = 11215236224238 := by decide
theorem cert_e2419143202030 : checkPay e2419143202030 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left]] 0 [[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] = true := by decide
def e2419143202038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143202038 : Closed e2419143202038 ∧ code e2419143202038 = 11215236224246 := by decide
theorem cert_e2419143202038 : check e2419143202038 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left,.left]] .identityHead = true := by decide
def e2419143202318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2419143202318 : Closed e2419143202318 ∧ code e2419143202318 = 11215236224526 := by decide
theorem cert_e2419143202318 : check e2419143202318 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143202330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143202330 : Closed e2419143202330 ∧ code e2419143202330 = 11215236224538 := by decide
theorem cert_e2419143202330 : check e2419143202330 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2419143202402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143202402 : Closed e2419143202402 ∧ code e2419143202402 = 11215236224610 := by decide
theorem cert_e2419143202402 : check e2419143202402 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143202414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143202414 : Closed e2419143202414 ∧ code e2419143202414 = 11215236224622 := by decide
theorem cert_e2419143202414 : check e2419143202414 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143202422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143202422 : Closed e2419143202422 ∧ code e2419143202422 = 11215236224630 := by decide
theorem cert_e2419143202422 : check e2419143202422 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143202426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143202426 : Closed e2419143202426 ∧ code e2419143202426 = 11215236224634 := by decide
theorem cert_e2419143202426 : check e2419143202426 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143202614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143202614 : Closed e2419143202614 ∧ code e2419143202614 = 11215236224822 := by decide
def e2419143202618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143202618 : Closed e2419143202618 ∧ code e2419143202618 = 11215236224826 := by decide
def e2419143202874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2419143202874 : Closed e2419143202874 ∧ code e2419143202874 = 11215236225082 := by decide
theorem cert_e2419143202874 : check e2419143202874 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143202922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2419143202922 : Closed e2419143202922 ∧ code e2419143202922 = 11215236225130 := by decide
theorem cert_e2419143202922 : check e2419143202922 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2419143202970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143202970 : Closed e2419143202970 ∧ code e2419143202970 = 11215236225178 := by decide
theorem cert_e2419143202970 : check e2419143202970 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2419143203014 : Closed e2419143203014 ∧ code e2419143203014 = 11215236225222 := by decide
theorem cert_e2419143203014 : check e2419143203014 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143203210 : Closed e2419143203210 ∧ code e2419143203210 = 11215236225418 := by decide
theorem cert_e2419143203210 : check e2419143203210 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143203234 : Closed e2419143203234 ∧ code e2419143203234 = 11215236225442 := by decide
theorem cert_e2419143203234 : check e2419143203234 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2419143203246 : Closed e2419143203246 ∧ code e2419143203246 = 11215236225454 := by decide
theorem cert_e2419143203246 : check e2419143203246 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143203254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2419143203254 : Closed e2419143203254 ∧ code e2419143203254 = 11215236225462 := by decide
theorem cert_e2419143203254 : check e2419143203254 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2419143203258 : Closed e2419143203258 ∧ code e2419143203258 = 11215236225466 := by decide
theorem cert_e2419143203258 : check e2419143203258 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143203286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2419143203286 : Closed e2419143203286 ∧ code e2419143203286 = 11215236225494 := by decide
theorem cert_e2419143203286 : check e2419143203286 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2419143203290 : Closed e2419143203290 ∧ code e2419143203290 = 11215236225498 := by decide
theorem cert_e2419143203290 : check e2419143203290 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2419143203306 : Closed e2419143203306 ∧ code e2419143203306 = 11215236225514 := by decide
theorem cert_e2419143203306 : check e2419143203306 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143203342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2419143203342 : Closed e2419143203342 ∧ code e2419143203342 = 11215236225550 := by decide
theorem cert_e2419143203342 : check e2419143203342 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143203354 : Closed e2419143203354 ∧ code e2419143203354 = 11215236225562 := by decide
theorem cert_e2419143203354 : check e2419143203354 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2419143203426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143203426 : Closed e2419143203426 ∧ code e2419143203426 = 11215236225634 := by decide
theorem cert_e2419143203426 : check e2419143203426 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143203438 : Closed e2419143203438 ∧ code e2419143203438 = 11215236225646 := by decide
theorem cert_e2419143203438 : check e2419143203438 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143203446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143203446 : Closed e2419143203446 ∧ code e2419143203446 = 11215236225654 := by decide
theorem cert_e2419143203446 : check e2419143203446 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143203450 : Closed e2419143203450 ∧ code e2419143203450 = 11215236225658 := by decide
theorem cert_e2419143203450 : check e2419143203450 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143203638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143203638 : Closed e2419143203638 ∧ code e2419143203638 = 11215236225846 := by decide
theorem cert_e2419143203638 : check e2419143203638 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143203642 : Closed e2419143203642 ∧ code e2419143203642 = 11215236225850 := by decide
theorem cert_e2419143203642 : check e2419143203642 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419143203738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143203738 : Closed e2419143203738 ∧ code e2419143203738 = 11215236225946 := by decide
theorem cert_e2419143203738 : check e2419143203738 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143204054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2419143204054 : Closed e2419143204054 ∧ code e2419143204054 = 11215236226262 := by decide
private def t_e2419143204054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem cert_e2419143204054 : ¬ IsSelfInterpreter e2419143204054 :=
  wSource (t := t_e2419143204054) (replay_sound (ps := []) (t := e2419143204054) (by decide)) (by decide)
def e2419143204058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2419143204058 : Closed e2419143204058 ∧ code e2419143204058 = 11215236226266 := by decide
private def t_e2419143204058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem cert_e2419143204058 : ¬ IsSelfInterpreter e2419143204058 :=
  wSource (t := t_e2419143204058) (replay_sound (ps := []) (t := e2419143204058) (by decide)) (by decide)
def e2419143204074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2419143204074 : Closed e2419143204074 ∧ code e2419143204074 = 11215236226282 := by decide
private def t_e2419143204074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem cert_e2419143204074 : ¬ IsSelfInterpreter e2419143204074 :=
  wSource (t := t_e2419143204074) (replay_sound (ps := []) (t := e2419143204074) (by decide)) (by decide)
def e2419143204150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143204150 : Closed e2419143204150 ∧ code e2419143204150 = 11215236226358 := by decide
private def t_e2419143204150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem cert_e2419143204150 : ¬ IsSelfInterpreter e2419143204150 :=
  wSource (t := t_e2419143204150) (replay_sound (ps := []) (t := e2419143204150) (by decide)) (by decide)
def e2419143204154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143204154 : Closed e2419143204154 ∧ code e2419143204154 = 11215236226362 := by decide
private def t_e2419143204154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem cert_e2419143204154 : ¬ IsSelfInterpreter e2419143204154 :=
  wSource (t := t_e2419143204154) (replay_sound (ps := []) (t := e2419143204154) (by decide)) (by decide)
def e2419143204250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143204250 : Closed e2419143204250 ∧ code e2419143204250 = 11215236226458 := by decide
private def t_e2419143204250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem cert_e2419143204250 : ¬ IsSelfInterpreter e2419143204250 :=
  wSource (t := t_e2419143204250) (replay_sound (ps := []) (t := e2419143204250) (by decide)) (by decide)
def e2419143220462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143220462 : Closed e2419143220462 ∧ code e2419143220462 = 11215236242670 := by decide
theorem cert_e2419143220462 : check e2419143220462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143220470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143220470 : Closed e2419143220470 ∧ code e2419143220470 = 11215236242678 := by decide
theorem cert_e2419143220470 : check e2419143220470 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143220846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143220846 : Closed e2419143220846 ∧ code e2419143220846 = 11215236243054 := by decide
theorem cert_e2419143220846 : check e2419143220846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143220858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143220858 : Closed e2419143220858 ∧ code e2419143220858 = 11215236243066 := by decide
theorem cert_e2419143220858 : check e2419143220858 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143221046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143221046 : Closed e2419143221046 ∧ code e2419143221046 = 11215236243254 := by decide
theorem cert_e2419143221046 : check e2419143221046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143221050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143221050 : Closed e2419143221050 ∧ code e2419143221050 = 11215236243258 := by decide
theorem cert_e2419143221050 : check e2419143221050 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143224762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2419143224762 : Closed e2419143224762 ∧ code e2419143224762 = 11215236246970 := by decide
theorem cert_e2419143224762 : check e2419143224762 [[],[]] .smaller = true := by decide
def e2419143224794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2419143224794 : Closed e2419143224794 ∧ code e2419143224794 = 11215236247002 := by decide
theorem cert_e2419143224794 : check e2419143224794 [[],[]] .smaller = true := by decide
def e2419143225018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2419143225018 : Closed e2419143225018 ∧ code e2419143225018 = 11215236247226 := by decide
theorem cert_e2419143225018 : check e2419143225018 [[],[]] .smaller = true := by decide
def e2419143225066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2419143225066 : Closed e2419143225066 ∧ code e2419143225066 = 11215236247274 := by decide
theorem cert_e2419143225066 : check e2419143225066 [[],[]] .smaller = true := by decide
def e2419143225178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2419143225178 : Closed e2419143225178 ∧ code e2419143225178 = 11215236247386 := by decide
theorem cert_e2419143225178 : check e2419143225178 [[],[]] .smaller = true := by decide
def e2419143225194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2419143225194 : Closed e2419143225194 ∧ code e2419143225194 = 11215236247402 := by decide
theorem cert_e2419143225194 : check e2419143225194 [[],[]] .smaller = true := by decide
def e2419143226298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2419143226298 : Closed e2419143226298 ∧ code e2419143226298 = 11215236248506 := by decide
theorem cert_e2419143226298 : check e2419143226298 [[],[]] .smaller = true := by decide
def e2419143226330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2419143226330 : Closed e2419143226330 ∧ code e2419143226330 = 11215236248538 := by decide
theorem cert_e2419143226330 : check e2419143226330 [[],[]] .smaller = true := by decide
def e2419143226606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143226606 : Closed e2419143226606 ∧ code e2419143226606 = 11215236248814 := by decide
theorem cert_e2419143226606 : check e2419143226606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143226614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143226614 : Closed e2419143226614 ∧ code e2419143226614 = 11215236248822 := by decide
theorem cert_e2419143226614 : check e2419143226614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2419143227834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2419143227834 : Closed e2419143227834 ∧ code e2419143227834 = 11215236250042 := by decide
theorem cert_e2419143227834 : check e2419143227834 [[],[]] .smaller = true := by decide
def e2419143227882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2419143227882 : Closed e2419143227882 ∧ code e2419143227882 = 11215236250090 := by decide
theorem cert_e2419143227882 : check e2419143227882 [[],[]] .smaller = true := by decide
def e2419143228634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2419143228634 : Closed e2419143228634 ∧ code e2419143228634 = 11215236250842 := by decide
theorem cert_e2419143228634 : check e2419143228634 [[],[]] .smaller = true := by decide
def e2419143228650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2419143228650 : Closed e2419143228650 ∧ code e2419143228650 = 11215236250858 := by decide
theorem cert_e2419143228650 : check e2419143228650 [[],[]] .smaller = true := by decide
def e2419143228910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2))))))
theorem wire_e2419143228910 : Closed e2419143228910 ∧ code e2419143228910 = 11215236251118 := by decide
theorem cert_e2419143228910 : check e2419143228910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2419143229166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2))))))
theorem wire_e2419143229166 : Closed e2419143229166 ∧ code e2419143229166 = 11215236251374 := by decide
theorem cert_e2419143229166 : checkPay e2419143229166 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e2419143229174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1))))))
theorem wire_e2419143229174 : Closed e2419143229174 ∧ code e2419143229174 = 11215236251382 := by decide
theorem cert_e2419143229174 : checkPay e2419143229174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2419143232366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419143232366 : Closed e2419143232366 ∧ code e2419143232366 = 11215236254574 := by decide
theorem cert_e2419143232366 : check e2419143232366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143232374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419143232374 : Closed e2419143232374 ∧ code e2419143232374 = 11215236254582 := by decide
theorem cert_e2419143232374 : check e2419143232374 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143232430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419143232430 : Closed e2419143232430 ∧ code e2419143232430 = 11215236254638 := by decide
theorem cert_e2419143232430 : check e2419143232430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143232442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419143232442 : Closed e2419143232442 ∧ code e2419143232442 = 11215236254650 := by decide
theorem cert_e2419143232442 : check e2419143232442 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143232470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419143232470 : Closed e2419143232470 ∧ code e2419143232470 = 11215236254678 := by decide
theorem cert_e2419143232470 : check e2419143232470 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143232474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419143232474 : Closed e2419143232474 ∧ code e2419143232474 = 11215236254682 := by decide
theorem cert_e2419143232474 : check e2419143232474 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143232750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143232750 : Closed e2419143232750 ∧ code e2419143232750 = 11215236254958 := by decide
theorem cert_e2419143232750 : check e2419143232750 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143232758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143232758 : Closed e2419143232758 ∧ code e2419143232758 = 11215236254966 := by decide
theorem cert_e2419143232758 : check e2419143232758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143233134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143233134 : Closed e2419143233134 ∧ code e2419143233134 = 11215236255342 := by decide
theorem cert_e2419143233134 : check e2419143233134 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143233146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143233146 : Closed e2419143233146 ∧ code e2419143233146 = 11215236255354 := by decide
theorem cert_e2419143233146 : check e2419143233146 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143233334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143233334 : Closed e2419143233334 ∧ code e2419143233334 = 11215236255542 := by decide
theorem cert_e2419143233334 : check e2419143233334 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143233338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143233338 : Closed e2419143233338 ∧ code e2419143233338 = 11215236255546 := by decide
theorem cert_e2419143233338 : check e2419143233338 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143239454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2419143239454 : Closed e2419143239454 ∧ code e2419143239454 = 11215236261662 := by decide
theorem cert_e2419143239454 : check e2419143239454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143239566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2419143239566 : Closed e2419143239566 ∧ code e2419143239566 = 11215236261774 := by decide
theorem cert_e2419143239566 : check e2419143239566 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143242526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2419143242526 : Closed e2419143242526 ∧ code e2419143242526 = 11215236264734 := by decide
theorem cert_e2419143242526 : checkPay e2419143242526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2419143242694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2419143242694 : Closed e2419143242694 ∧ code e2419143242694 = 11215236264902 := by decide
theorem cert_e2419143242694 : checkPay e2419143242694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2419143244174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2419143244174 : Closed e2419143244174 ∧ code e2419143244174 = 11215236266382 := by decide
theorem cert_e2419143244174 : check e2419143244174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143244230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2419143244230 : Closed e2419143244230 ∧ code e2419143244230 = 11215236266438 := by decide
theorem cert_e2419143244230 : check e2419143244230 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143258478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2419143258478 : Closed e2419143258478 ∧ code e2419143258478 = 11215236280686 := by decide
theorem cert_e2419143258478 : check e2419143258478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143258486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2419143258486 : Closed e2419143258486 ∧ code e2419143258486 = 11215236280694 := by decide
theorem cert_e2419143258486 : check e2419143258486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143259694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2419143259694 : Closed e2419143259694 ∧ code e2419143259694 = 11215236281902 := by decide
theorem cert_e2419143259694 : check e2419143259694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143259874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2419143259874 : Closed e2419143259874 ∧ code e2419143259874 = 11215236282082 := by decide
theorem cert_e2419143259874 : check e2419143259874 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143259886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e2419143259886 : Closed e2419143259886 ∧ code e2419143259886 = 11215236282094 := by decide
theorem cert_e2419143259886 : check e2419143259886 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143259926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2419143259926 : Closed e2419143259926 ∧ code e2419143259926 = 11215236282134 := by decide
theorem cert_e2419143259926 : check e2419143259926 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143260002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2419143260002 : Closed e2419143260002 ∧ code e2419143260002 = 11215236282210 := by decide
theorem cert_e2419143260002 : check e2419143260002 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143260014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e2419143260014 : Closed e2419143260014 ∧ code e2419143260014 = 11215236282222 := by decide
theorem cert_e2419143260014 : check e2419143260014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143260022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e2419143260022 : Closed e2419143260022 ∧ code e2419143260022 = 11215236282230 := by decide
theorem cert_e2419143260022 : check e2419143260022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143260334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2419143260334 : Closed e2419143260334 ∧ code e2419143260334 = 11215236282542 := by decide
theorem cert_e2419143260334 : check e2419143260334 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143260346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2419143260346 : Closed e2419143260346 ∧ code e2419143260346 = 11215236282554 := by decide
theorem cert_e2419143260346 : check e2419143260346 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143260718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2419143260718 : Closed e2419143260718 ∧ code e2419143260718 = 11215236282926 := by decide
theorem cert_e2419143260718 : check e2419143260718 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143260898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2419143260898 : Closed e2419143260898 ∧ code e2419143260898 = 11215236283106 := by decide
theorem cert_e2419143260898 : check e2419143260898 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143260910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2419143260910 : Closed e2419143260910 ∧ code e2419143260910 = 11215236283118 := by decide
theorem cert_e2419143260910 : check e2419143260910 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143261038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2419143261038 : Closed e2419143261038 ∧ code e2419143261038 = 11215236283246 := by decide
theorem cert_e2419143261038 : check e2419143261038 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419143197526
#print axioms Blc.Floor43.cert_e2419143197530
#print axioms Blc.Floor43.cert_e2419143204054
#print axioms Blc.Floor43.cert_e2419143204058
#print axioms Blc.Floor43.cert_e2419143204074
#print axioms Blc.Floor43.cert_e2419143204150
#print axioms Blc.Floor43.cert_e2419143204154
#print axioms Blc.Floor43.cert_e2419143204250
