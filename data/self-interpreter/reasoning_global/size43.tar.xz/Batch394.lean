import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372810170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372810170 : Closed e2422372810170 ∧ code e2422372810170 = 11218465832378 := by decide
theorem cert_e2422372810170 : check e2422372810170 [[],[]] .three = true := by decide
def e2422372810198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372810198 : Closed e2422372810198 ∧ code e2422372810198 = 11218465832406 := by decide
theorem cert_e2422372810198 : check e2422372810198 [[],[]] .three = true := by decide
def e2422372810202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372810202 : Closed e2422372810202 ∧ code e2422372810202 = 11218465832410 := by decide
theorem cert_e2422372810202 : check e2422372810202 [[],[]] .three = true := by decide
def e2422372810218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2422372810218 : Closed e2422372810218 ∧ code e2422372810218 = 11218465832426 := by decide
theorem cert_e2422372810218 : check e2422372810218 [[],[]] .three = true := by decide
def e2422372811094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372811094 : Closed e2422372811094 ∧ code e2422372811094 = 11218465833302 := by decide
theorem cert_e2422372811094 : check e2422372811094 [[],[]] .smaller = true := by decide
def e2422372811098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372811098 : Closed e2422372811098 ∧ code e2422372811098 = 11218465833306 := by decide
theorem cert_e2422372811098 : check e2422372811098 [[],[]] .smaller = true := by decide
def e2422372811114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372811114 : Closed e2422372811114 ∧ code e2422372811114 = 11218465833322 := by decide
theorem cert_e2422372811114 : check e2422372811114 [[],[]] .smaller = true := by decide
def e2422372812126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2422372812126 : Closed e2422372812126 ∧ code e2422372812126 = 11218465834334 := by decide
theorem cert_e2422372812126 : check e2422372812126 [[],[]] .three = true := by decide
def e2422372812142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372812142 : Closed e2422372812142 ∧ code e2422372812142 = 11218465834350 := by decide
theorem cert_e2422372812142 : check e2422372812142 [[],[]] .smaller = true := by decide
def e2422372812150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372812150 : Closed e2422372812150 ∧ code e2422372812150 = 11218465834358 := by decide
theorem cert_e2422372812150 : check e2422372812150 [[],[]] .smaller = true := by decide
def e2422372812154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2422372812154 : Closed e2422372812154 ∧ code e2422372812154 = 11218465834362 := by decide
theorem cert_e2422372812154 : check e2422372812154 [[],[]] .three = true := by decide
def e2422372812206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372812206 : Closed e2422372812206 ∧ code e2422372812206 = 11218465834414 := by decide
theorem cert_e2422372812206 : check e2422372812206 [[],[]] .smaller = true := by decide
def e2422372812218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372812218 : Closed e2422372812218 ∧ code e2422372812218 = 11218465834426 := by decide
theorem cert_e2422372812218 : check e2422372812218 [[],[]] .smaller = true := by decide
def e2422372812246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372812246 : Closed e2422372812246 ∧ code e2422372812246 = 11218465834454 := by decide
theorem cert_e2422372812246 : check e2422372812246 [[],[]] .smaller = true := by decide
def e2422372812250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372812250 : Closed e2422372812250 ∧ code e2422372812250 = 11218465834458 := by decide
theorem cert_e2422372812250 : check e2422372812250 [[],[]] .smaller = true := by decide
def e2422372812266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2422372812266 : Closed e2422372812266 ∧ code e2422372812266 = 11218465834474 := by decide
theorem cert_e2422372812266 : check e2422372812266 [[],[]] .three = true := by decide
def e2422372812470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2422372812470 : Closed e2422372812470 ∧ code e2422372812470 = 11218465834678 := by decide
theorem cert_e2422372812470 : check e2422372812470 [[],[]] .smaller = true := by decide
def e2422372812502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2422372812502 : Closed e2422372812502 ∧ code e2422372812502 = 11218465834710 := by decide
theorem cert_e2422372812502 : check e2422372812502 [[],[]] .smaller = true := by decide
def e2422372812506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2422372812506 : Closed e2422372812506 ∧ code e2422372812506 = 11218465834714 := by decide
theorem cert_e2422372812506 : check e2422372812506 [[],[]] .smaller = true := by decide
def e2422372812630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372812630 : Closed e2422372812630 ∧ code e2422372812630 = 11218465834838 := by decide
theorem cert_e2422372812630 : check e2422372812630 [[],[]] .smaller = true := by decide
def e2422372812634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372812634 : Closed e2422372812634 ∧ code e2422372812634 = 11218465834842 := by decide
theorem cert_e2422372812634 : check e2422372812634 [[],[]] .smaller = true := by decide
def e2422372812650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372812650 : Closed e2422372812650 ∧ code e2422372812650 = 11218465834858 := by decide
theorem cert_e2422372812650 : check e2422372812650 [[],[]] .smaller = true := by decide
def e2422372814166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372814166 : Closed e2422372814166 ∧ code e2422372814166 = 11218465836374 := by decide
theorem cert_e2422372814166 : check e2422372814166 [[],[]] .smaller = true := by decide
def e2422372814170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372814170 : Closed e2422372814170 ∧ code e2422372814170 = 11218465836378 := by decide
theorem cert_e2422372814170 : check e2422372814170 [[],[]] .smaller = true := by decide
def e2422372814186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372814186 : Closed e2422372814186 ∧ code e2422372814186 = 11218465836394 := by decide
theorem cert_e2422372814186 : check e2422372814186 [[],[]] .smaller = true := by decide
def e2422372814250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372814250 : Closed e2422372814250 ∧ code e2422372814250 = 11218465836458 := by decide
theorem cert_e2422372814250 : check e2422372814250 [[],[]] .smaller = true := by decide
def e2422372814506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372814506 : Closed e2422372814506 ∧ code e2422372814506 = 11218465836714 := by decide
theorem cert_e2422372814506 : check e2422372814506 [[],[]] .smaller = true := by decide
def e2422372814934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372814934 : Closed e2422372814934 ∧ code e2422372814934 = 11218465837142 := by decide
theorem cert_e2422372814934 : check e2422372814934 [[],[]] .smaller = true := by decide
def e2422372814938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372814938 : Closed e2422372814938 ∧ code e2422372814938 = 11218465837146 := by decide
theorem cert_e2422372814938 : check e2422372814938 [[],[]] .smaller = true := by decide
def e2422372815198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2422372815198 : Closed e2422372815198 ∧ code e2422372815198 = 11218465837406 := by decide
theorem cert_e2422372815198 : check e2422372815198 [[],[]] .three = true := by decide
def e2422372815214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2422372815214 : Closed e2422372815214 ∧ code e2422372815214 = 11218465837422 := by decide
theorem cert_e2422372815214 : check e2422372815214 [[],[]] .smaller = true := by decide
def e2422372815222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2422372815222 : Closed e2422372815222 ∧ code e2422372815222 = 11218465837430 := by decide
theorem cert_e2422372815222 : check e2422372815222 [[],[]] .smaller = true := by decide
def e2422372815226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2422372815226 : Closed e2422372815226 ∧ code e2422372815226 = 11218465837434 := by decide
theorem cert_e2422372815226 : check e2422372815226 [[],[]] .three = true := by decide
def e2422372815286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e2422372815286 : Closed e2422372815286 ∧ code e2422372815286 = 11218465837494 := by decide
theorem cert_e2422372815286 : check e2422372815286 [[],[]] .smaller = true := by decide
def e2422372815318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2422372815318 : Closed e2422372815318 ∧ code e2422372815318 = 11218465837526 := by decide
theorem cert_e2422372815318 : check e2422372815318 [[],[]] .smaller = true := by decide
def e2422372815322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2422372815322 : Closed e2422372815322 ∧ code e2422372815322 = 11218465837530 := by decide
theorem cert_e2422372815322 : check e2422372815322 [[],[]] .smaller = true := by decide
def e2422372815702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372815702 : Closed e2422372815702 ∧ code e2422372815702 = 11218465837910 := by decide
theorem cert_e2422372815702 : check e2422372815702 [[],[]] .smaller = true := by decide
def e2422372815706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372815706 : Closed e2422372815706 ∧ code e2422372815706 = 11218465837914 := by decide
theorem cert_e2422372815706 : check e2422372815706 [[],[]] .smaller = true := by decide
def e2422372815722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422372815722 : Closed e2422372815722 ∧ code e2422372815722 = 11218465837930 := by decide
theorem cert_e2422372815722 : check e2422372815722 [[],[]] .smaller = true := by decide
def e2422372815786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372815786 : Closed e2422372815786 ∧ code e2422372815786 = 11218465837994 := by decide
theorem cert_e2422372815786 : check e2422372815786 [[],[]] .smaller = true := by decide
def e2422372815894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372815894 : Closed e2422372815894 ∧ code e2422372815894 = 11218465838102 := by decide
theorem cert_e2422372815894 : check e2422372815894 [[],[]] .smaller = true := by decide
def e2422372815966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372815966 : Closed e2422372815966 ∧ code e2422372815966 = 11218465838174 := by decide
theorem cert_e2422372815966 : check e2422372815966 [[],[]] .three = true := by decide
def e2422372815990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422372815990 : Closed e2422372815990 ∧ code e2422372815990 = 11218465838198 := by decide
theorem cert_e2422372815990 : check e2422372815990 [[],[]] .smaller = true := by decide
def e2422372816086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422372816086 : Closed e2422372816086 ∧ code e2422372816086 = 11218465838294 := by decide
theorem cert_e2422372816086 : check e2422372816086 [[],[]] .smaller = true := by decide
def e2422372816090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422372816090 : Closed e2422372816090 ∧ code e2422372816090 = 11218465838298 := by decide
theorem cert_e2422372816090 : check e2422372816090 [[],[]] .smaller = true := by decide
def e2422372816106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422372816106 : Closed e2422372816106 ∧ code e2422372816106 = 11218465838314 := by decide
theorem cert_e2422372816106 : check e2422372816106 [[],[]] .smaller = true := by decide
def e2422372816182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372816182 : Closed e2422372816182 ∧ code e2422372816182 = 11218465838390 := by decide
theorem cert_e2422372816182 : check e2422372816182 [[],[]] .smaller = true := by decide
def e2422372816186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372816186 : Closed e2422372816186 ∧ code e2422372816186 = 11218465838394 := by decide
theorem cert_e2422372816186 : check e2422372816186 [[],[]] .smaller = true := by decide
def e2422372816258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372816258 : Closed e2422372816258 ∧ code e2422372816258 = 11218465838466 := by decide
theorem cert_e2422372816258 : check e2422372816258 [[],[]] .smaller = true := by decide
def e2422372816270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422372816270 : Closed e2422372816270 ∧ code e2422372816270 = 11218465838478 := by decide
theorem cert_e2422372816270 : check e2422372816270 [[],[]] .smaller = true := by decide
def e2422372816282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372816282 : Closed e2422372816282 ∧ code e2422372816282 = 11218465838490 := by decide
theorem cert_e2422372816282 : check e2422372816282 [[],[]] .smaller = true := by decide
def e2422372816350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2422372816350 : Closed e2422372816350 ∧ code e2422372816350 = 11218465838558 := by decide
theorem cert_e2422372816350 : check e2422372816350 [[],[]] .three = true := by decide
def e2422372816354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372816354 : Closed e2422372816354 ∧ code e2422372816354 = 11218465838562 := by decide
theorem cert_e2422372816354 : check e2422372816354 [[],[]] .three = true := by decide
def e2422372816366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2422372816366 : Closed e2422372816366 ∧ code e2422372816366 = 11218465838574 := by decide
theorem cert_e2422372816366 : check e2422372816366 [[],[]] .three = true := by decide
def e2422372816394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372816394 : Closed e2422372816394 ∧ code e2422372816394 = 11218465838602 := by decide
theorem cert_e2422372816394 : check e2422372816394 [[],[]] .smaller = true := by decide
def e2422372816430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372816430 : Closed e2422372816430 ∧ code e2422372816430 = 11218465838638 := by decide
theorem cert_e2422372816430 : check e2422372816430 [[],[]] .smaller = true := by decide
def e2422372816438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372816438 : Closed e2422372816438 ∧ code e2422372816438 = 11218465838646 := by decide
theorem cert_e2422372816438 : check e2422372816438 [[],[]] .smaller = true := by decide
def e2422372816442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372816442 : Closed e2422372816442 ∧ code e2422372816442 = 11218465838650 := by decide
theorem cert_e2422372816442 : check e2422372816442 [[],[]] .smaller = true := by decide
def e2422372816490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372816490 : Closed e2422372816490 ∧ code e2422372816490 = 11218465838698 := by decide
theorem cert_e2422372816490 : check e2422372816490 [[],[]] .smaller = true := by decide
def e2422372816514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372816514 : Closed e2422372816514 ∧ code e2422372816514 = 11218465838722 := by decide
theorem cert_e2422372816514 : check e2422372816514 [[],[]] .smaller = true := by decide
def e2422372816526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372816526 : Closed e2422372816526 ∧ code e2422372816526 = 11218465838734 := by decide
theorem cert_e2422372816526 : check e2422372816526 [[],[]] .smaller = true := by decide
def e2422372816538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372816538 : Closed e2422372816538 ∧ code e2422372816538 = 11218465838746 := by decide
theorem cert_e2422372816538 : check e2422372816538 [[],[]] .smaller = true := by decide
def e2422372816582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372816582 : Closed e2422372816582 ∧ code e2422372816582 = 11218465838790 := by decide
theorem cert_e2422372816582 : check e2422372816582 [[],[]] .smaller = true := by decide
def e2422372816606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2422372816606 : Closed e2422372816606 ∧ code e2422372816606 = 11218465838814 := by decide
theorem cert_e2422372816606 : check e2422372816606 [[],[]] .three = true := by decide
def e2422372816610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372816610 : Closed e2422372816610 ∧ code e2422372816610 = 11218465838818 := by decide
theorem cert_e2422372816610 : check e2422372816610 [[],[]] .smaller = true := by decide
def e2422372816622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2422372816622 : Closed e2422372816622 ∧ code e2422372816622 = 11218465838830 := by decide
theorem cert_e2422372816622 : check e2422372816622 [[],[]] .smaller = true := by decide
def e2422372816630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2422372816630 : Closed e2422372816630 ∧ code e2422372816630 = 11218465838838 := by decide
theorem cert_e2422372816630 : check e2422372816630 [[],[]] .three = true := by decide
def e2422372816662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372816662 : Closed e2422372816662 ∧ code e2422372816662 = 11218465838870 := by decide
theorem cert_e2422372816662 : check e2422372816662 [[],[]] .smaller = true := by decide
def e2422372816734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2422372816734 : Closed e2422372816734 ∧ code e2422372816734 = 11218465838942 := by decide
theorem cert_e2422372816734 : check e2422372816734 [[],[]] .three = true := by decide
def e2422372816738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372816738 : Closed e2422372816738 ∧ code e2422372816738 = 11218465838946 := by decide
theorem cert_e2422372816738 : check e2422372816738 [[],[]] .smaller = true := by decide
def e2422372816750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2422372816750 : Closed e2422372816750 ∧ code e2422372816750 = 11218465838958 := by decide
theorem cert_e2422372816750 : check e2422372816750 [[],[]] .smaller = true := by decide
def e2422372816758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2422372816758 : Closed e2422372816758 ∧ code e2422372816758 = 11218465838966 := by decide
theorem cert_e2422372816758 : check e2422372816758 [[],[]] .smaller = true := by decide
def e2422372816762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2422372816762 : Closed e2422372816762 ∧ code e2422372816762 = 11218465838970 := by decide
theorem cert_e2422372816762 : check e2422372816762 [[],[]] .three = true := by decide
def e2422372816778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372816778 : Closed e2422372816778 ∧ code e2422372816778 = 11218465838986 := by decide
theorem cert_e2422372816778 : check e2422372816778 [[],[]] .three = true := by decide
def e2422372816802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372816802 : Closed e2422372816802 ∧ code e2422372816802 = 11218465839010 := by decide
theorem cert_e2422372816802 : check e2422372816802 [[],[]] .three = true := by decide
def e2422372816814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2422372816814 : Closed e2422372816814 ∧ code e2422372816814 = 11218465839022 := by decide
theorem cert_e2422372816814 : check e2422372816814 [[],[]] .three = true := by decide
def e2422372816822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2422372816822 : Closed e2422372816822 ∧ code e2422372816822 = 11218465839030 := by decide
theorem cert_e2422372816822 : check e2422372816822 [[],[]] .three = true := by decide
def e2422372816826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2422372816826 : Closed e2422372816826 ∧ code e2422372816826 = 11218465839034 := by decide
theorem cert_e2422372816826 : check e2422372816826 [[],[]] .three = true := by decide
def e2422372816938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372816938 : Closed e2422372816938 ∧ code e2422372816938 = 11218465839146 := by decide
theorem cert_e2422372816938 : check e2422372816938 [[],[]] .smaller = true := by decide
def e2422372817070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372817070 : Closed e2422372817070 ∧ code e2422372817070 = 11218465839278 := by decide
theorem cert_e2422372817070 : check e2422372817070 [[],[]] .smaller = true := by decide
def e2422372817082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372817082 : Closed e2422372817082 ∧ code e2422372817082 = 11218465839290 := by decide
theorem cert_e2422372817082 : check e2422372817082 [[],[]] .smaller = true := by decide
def e2422372817110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2422372817110 : Closed e2422372817110 ∧ code e2422372817110 = 11218465839318 := by decide
theorem cert_e2422372817110 : check e2422372817110 [[],[]] .smaller = true := by decide
def e2422372817114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2422372817114 : Closed e2422372817114 ∧ code e2422372817114 = 11218465839322 := by decide
theorem cert_e2422372817114 : check e2422372817114 [[],[]] .smaller = true := by decide
def e2422372817130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372817130 : Closed e2422372817130 ∧ code e2422372817130 = 11218465839338 := by decide
theorem cert_e2422372817130 : check e2422372817130 [[],[]] .smaller = true := by decide
def e2422372817322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372817322 : Closed e2422372817322 ∧ code e2422372817322 = 11218465839530 := by decide
theorem cert_e2422372817322 : check e2422372817322 [[],[]] .smaller = true := by decide
def e2422372817418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372817418 : Closed e2422372817418 ∧ code e2422372817418 = 11218465839626 := by decide
theorem cert_e2422372817418 : check e2422372817418 [[],[]] .smaller = true := by decide
def e2422372817454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372817454 : Closed e2422372817454 ∧ code e2422372817454 = 11218465839662 := by decide
theorem cert_e2422372817454 : check e2422372817454 [[],[]] .smaller = true := by decide
def e2422372817462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372817462 : Closed e2422372817462 ∧ code e2422372817462 = 11218465839670 := by decide
theorem cert_e2422372817462 : check e2422372817462 [[],[]] .smaller = true := by decide
def e2422372817466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372817466 : Closed e2422372817466 ∧ code e2422372817466 = 11218465839674 := by decide
theorem cert_e2422372817466 : check e2422372817466 [[],[]] .smaller = true := by decide
def e2422372817514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372817514 : Closed e2422372817514 ∧ code e2422372817514 = 11218465839722 := by decide
theorem cert_e2422372817514 : check e2422372817514 [[],[]] .smaller = true := by decide
def e2422372817538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372817538 : Closed e2422372817538 ∧ code e2422372817538 = 11218465839746 := by decide
theorem cert_e2422372817538 : check e2422372817538 [[],[]] .smaller = true := by decide
def e2422372817550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372817550 : Closed e2422372817550 ∧ code e2422372817550 = 11218465839758 := by decide
theorem cert_e2422372817550 : check e2422372817550 [[],[]] .smaller = true := by decide
def e2422372817562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372817562 : Closed e2422372817562 ∧ code e2422372817562 = 11218465839770 := by decide
theorem cert_e2422372817562 : check e2422372817562 [[],[]] .smaller = true := by decide
def e2422372817606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372817606 : Closed e2422372817606 ∧ code e2422372817606 = 11218465839814 := by decide
theorem cert_e2422372817606 : check e2422372817606 [[],[]] .smaller = true := by decide
def e2422372817630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2422372817630 : Closed e2422372817630 ∧ code e2422372817630 = 11218465839838 := by decide
theorem cert_e2422372817630 : check e2422372817630 [[],[]] .three = true := by decide
def e2422372817634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372817634 : Closed e2422372817634 ∧ code e2422372817634 = 11218465839842 := by decide
theorem cert_e2422372817634 : check e2422372817634 [[],[]] .smaller = true := by decide
def e2422372817646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2422372817646 : Closed e2422372817646 ∧ code e2422372817646 = 11218465839854 := by decide
theorem cert_e2422372817646 : check e2422372817646 [[],[]] .smaller = true := by decide
def e2422372817654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2422372817654 : Closed e2422372817654 ∧ code e2422372817654 = 11218465839862 := by decide
theorem cert_e2422372817654 : check e2422372817654 [[],[]] .three = true := by decide
def e2422372817690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372817690 : Closed e2422372817690 ∧ code e2422372817690 = 11218465839898 := by decide
theorem cert_e2422372817690 : check e2422372817690 [[],[]] .smaller = true := by decide
def e2422372817734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372817734 : Closed e2422372817734 ∧ code e2422372817734 = 11218465839942 := by decide
theorem cert_e2422372817734 : check e2422372817734 [[],[]] .smaller = true := by decide
def e2422372817758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2422372817758 : Closed e2422372817758 ∧ code e2422372817758 = 11218465839966 := by decide
theorem cert_e2422372817758 : check e2422372817758 [[],[]] .three = true := by decide
def e2422372817786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2422372817786 : Closed e2422372817786 ∧ code e2422372817786 = 11218465839994 := by decide
theorem cert_e2422372817786 : check e2422372817786 [[],[]] .three = true := by decide
def e2422372817802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372817802 : Closed e2422372817802 ∧ code e2422372817802 = 11218465840010 := by decide
theorem cert_e2422372817802 : check e2422372817802 [[],[]] .smaller = true := by decide
def e2422372817826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372817826 : Closed e2422372817826 ∧ code e2422372817826 = 11218465840034 := by decide
theorem cert_e2422372817826 : check e2422372817826 [[],[]] .smaller = true := by decide
def e2422372817838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2422372817838 : Closed e2422372817838 ∧ code e2422372817838 = 11218465840046 := by decide
theorem cert_e2422372817838 : check e2422372817838 [[],[]] .smaller = true := by decide
def e2422372817850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2422372817850 : Closed e2422372817850 ∧ code e2422372817850 = 11218465840058 := by decide
theorem cert_e2422372817850 : check e2422372817850 [[],[]] .smaller = true := by decide
def e2422372817878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2422372817878 : Closed e2422372817878 ∧ code e2422372817878 = 11218465840086 := by decide
theorem cert_e2422372817878 : check e2422372817878 [[],[]] .three = true := by decide
def e2422372817882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2422372817882 : Closed e2422372817882 ∧ code e2422372817882 = 11218465840090 := by decide
theorem cert_e2422372817882 : check e2422372817882 [[],[]] .three = true := by decide
def e2422372818006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372818006 : Closed e2422372818006 ∧ code e2422372818006 = 11218465840214 := by decide
theorem cert_e2422372818006 : check e2422372818006 [[],[]] .smaller = true := by decide
def e2422372818010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372818010 : Closed e2422372818010 ∧ code e2422372818010 = 11218465840218 := by decide
theorem cert_e2422372818010 : check e2422372818010 [[],[]] .smaller = true := by decide
def e2422372818198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372818198 : Closed e2422372818198 ∧ code e2422372818198 = 11218465840406 := by decide
theorem cert_e2422372818198 : check e2422372818198 [[],[]] .smaller = true := by decide
def e2422372818270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2422372818270 : Closed e2422372818270 ∧ code e2422372818270 = 11218465840478 := by decide
theorem cert_e2422372818270 : check e2422372818270 [[],[]] .three = true := by decide
def e2422372818274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372818274 : Closed e2422372818274 ∧ code e2422372818274 = 11218465840482 := by decide
theorem cert_e2422372818274 : check e2422372818274 [[],[]] .smaller = true := by decide
def e2422372818286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372818286 : Closed e2422372818286 ∧ code e2422372818286 = 11218465840494 := by decide
theorem cert_e2422372818286 : check e2422372818286 [[],[]] .smaller = true := by decide
def e2422372818294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372818294 : Closed e2422372818294 ∧ code e2422372818294 = 11218465840502 := by decide
theorem cert_e2422372818294 : check e2422372818294 [[],[]] .smaller = true := by decide
def e2422372818298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2422372818298 : Closed e2422372818298 ∧ code e2422372818298 = 11218465840506 := by decide
theorem cert_e2422372818298 : check e2422372818298 [[],[]] .three = true := by decide
def e2422372818314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372818314 : Closed e2422372818314 ∧ code e2422372818314 = 11218465840522 := by decide
theorem cert_e2422372818314 : check e2422372818314 [[],[]] .smaller = true := by decide
def e2422372818338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372818338 : Closed e2422372818338 ∧ code e2422372818338 = 11218465840546 := by decide
theorem cert_e2422372818338 : check e2422372818338 [[],[]] .smaller = true := by decide
def e2422372818350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372818350 : Closed e2422372818350 ∧ code e2422372818350 = 11218465840558 := by decide
theorem cert_e2422372818350 : check e2422372818350 [[],[]] .smaller = true := by decide
def e2422372818362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372818362 : Closed e2422372818362 ∧ code e2422372818362 = 11218465840570 := by decide
theorem cert_e2422372818362 : check e2422372818362 [[],[]] .smaller = true := by decide
def e2422372818390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372818390 : Closed e2422372818390 ∧ code e2422372818390 = 11218465840598 := by decide
theorem cert_e2422372818390 : check e2422372818390 [[],[]] .smaller = true := by decide
def e2422372818394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372818394 : Closed e2422372818394 ∧ code e2422372818394 = 11218465840602 := by decide
theorem cert_e2422372818394 : check e2422372818394 [[],[]] .smaller = true := by decide
def e2422372818410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2422372818410 : Closed e2422372818410 ∧ code e2422372818410 = 11218465840618 := by decide
theorem cert_e2422372818410 : check e2422372818410 [[],[]] .three = true := by decide
def e2422372818474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372818474 : Closed e2422372818474 ∧ code e2422372818474 = 11218465840682 := by decide
theorem cert_e2422372818474 : check e2422372818474 [[],[]] .three = true := by decide
def e2422372818570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372818570 : Closed e2422372818570 ∧ code e2422372818570 = 11218465840778 := by decide
theorem cert_e2422372818570 : check e2422372818570 [[],[]] .three = true := by decide
def e2422372818594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372818594 : Closed e2422372818594 ∧ code e2422372818594 = 11218465840802 := by decide
theorem cert_e2422372818594 : check e2422372818594 [[],[]] .three = true := by decide
def e2422372818606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372818606 : Closed e2422372818606 ∧ code e2422372818606 = 11218465840814 := by decide
theorem cert_e2422372818606 : check e2422372818606 [[],[]] .three = true := by decide
def e2422372818614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2422372818614 : Closed e2422372818614 ∧ code e2422372818614 = 11218465840822 := by decide
theorem cert_e2422372818614 : check e2422372818614 [[],[]] .three = true := by decide
def e2422372818618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372818618 : Closed e2422372818618 ∧ code e2422372818618 = 11218465840826 := by decide
theorem cert_e2422372818618 : check e2422372818618 [[],[]] .three = true := by decide
def e2422372818646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2422372818646 : Closed e2422372818646 ∧ code e2422372818646 = 11218465840854 := by decide
theorem cert_e2422372818646 : check e2422372818646 [[],[]] .three = true := by decide
def e2422372818650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2422372818650 : Closed e2422372818650 ∧ code e2422372818650 = 11218465840858 := by decide
theorem cert_e2422372818650 : check e2422372818650 [[],[]] .three = true := by decide
def e2422372818666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372818666 : Closed e2422372818666 ∧ code e2422372818666 = 11218465840874 := by decide
theorem cert_e2422372818666 : check e2422372818666 [[],[]] .three = true := by decide
def e2422372819630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372819630 : Closed e2422372819630 ∧ code e2422372819630 = 11218465841838 := by decide
theorem cert_e2422372819630 : check e2422372819630 [[],[]] .three = true := by decide
def e2422372819638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2422372819638 : Closed e2422372819638 ∧ code e2422372819638 = 11218465841846 := by decide
theorem cert_e2422372819638 : check e2422372819638 [[],[]] .three = true := by decide
def e2422372819642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372819642 : Closed e2422372819642 ∧ code e2422372819642 = 11218465841850 := by decide
theorem cert_e2422372819642 : check e2422372819642 [[],[]] .three = true := by decide
def e2422372819670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2422372819670 : Closed e2422372819670 ∧ code e2422372819670 = 11218465841878 := by decide
theorem cert_e2422372819670 : check e2422372819670 [[],[]] .three = true := by decide
def e2422372819674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2422372819674 : Closed e2422372819674 ∧ code e2422372819674 = 11218465841882 := by decide
theorem cert_e2422372819674 : check e2422372819674 [[],[]] .three = true := by decide
def e2422372819690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372819690 : Closed e2422372819690 ∧ code e2422372819690 = 11218465841898 := by decide
theorem cert_e2422372819690 : check e2422372819690 [[],[]] .three = true := by decide
def e2422372819798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372819798 : Closed e2422372819798 ∧ code e2422372819798 = 11218465842006 := by decide
theorem cert_e2422372819798 : check e2422372819798 [[],[]] .three = true := by decide
def e2422372819802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372819802 : Closed e2422372819802 ∧ code e2422372819802 = 11218465842010 := by decide
theorem cert_e2422372819802 : check e2422372819802 [[],[]] .three = true := by decide
def e2422372819818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372819818 : Closed e2422372819818 ∧ code e2422372819818 = 11218465842026 := by decide
theorem cert_e2422372819818 : check e2422372819818 [[],[]] .three = true := by decide
def e2422372819882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372819882 : Closed e2422372819882 ∧ code e2422372819882 = 11218465842090 := by decide
theorem cert_e2422372819882 : check e2422372819882 [[],[]] .three = true := by decide
def e2422372821166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372821166 : Closed e2422372821166 ∧ code e2422372821166 = 11218465843374 := by decide
theorem cert_e2422372821166 : check e2422372821166 [[],[]] .three = true := by decide
def e2422372821174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2422372821174 : Closed e2422372821174 ∧ code e2422372821174 = 11218465843382 := by decide
theorem cert_e2422372821174 : check e2422372821174 [[],[]] .three = true := by decide
def e2422372821178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372821178 : Closed e2422372821178 ∧ code e2422372821178 = 11218465843386 := by decide
theorem cert_e2422372821178 : check e2422372821178 [[],[]] .three = true := by decide
def e2422372821206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2422372821206 : Closed e2422372821206 ∧ code e2422372821206 = 11218465843414 := by decide
theorem cert_e2422372821206 : check e2422372821206 [[],[]] .three = true := by decide
def e2422372821210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2422372821210 : Closed e2422372821210 ∧ code e2422372821210 = 11218465843418 := by decide
theorem cert_e2422372821210 : check e2422372821210 [[],[]] .three = true := by decide
def e2422372821226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372821226 : Closed e2422372821226 ∧ code e2422372821226 = 11218465843434 := by decide
theorem cert_e2422372821226 : check e2422372821226 [[],[]] .three = true := by decide
def e2422372821550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372821550 : Closed e2422372821550 ∧ code e2422372821550 = 11218465843758 := by decide
theorem cert_e2422372821550 : check e2422372821550 [[],[]] .three = true := by decide
def e2422372821558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372821558 : Closed e2422372821558 ∧ code e2422372821558 = 11218465843766 := by decide
theorem cert_e2422372821558 : check e2422372821558 [[],[]] .three = true := by decide
def e2422372821562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372821562 : Closed e2422372821562 ∧ code e2422372821562 = 11218465843770 := by decide
theorem cert_e2422372821562 : check e2422372821562 [[],[]] .three = true := by decide
def e2422372821646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372821646 : Closed e2422372821646 ∧ code e2422372821646 = 11218465843854 := by decide
theorem cert_e2422372821646 : check e2422372821646 [[],[]] .three = true := by decide
def e2422372821702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372821702 : Closed e2422372821702 ∧ code e2422372821702 = 11218465843910 := by decide
theorem cert_e2422372821702 : check e2422372821702 [[],[]] .three = true := by decide
def e2422372821726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2422372821726 : Closed e2422372821726 ∧ code e2422372821726 = 11218465843934 := by decide
theorem cert_e2422372821726 : check e2422372821726 [[],[]] .three = true := by decide
def e2422372821730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372821730 : Closed e2422372821730 ∧ code e2422372821730 = 11218465843938 := by decide
theorem cert_e2422372821730 : check e2422372821730 [[],[]] .three = true := by decide
def e2422372821742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2422372821742 : Closed e2422372821742 ∧ code e2422372821742 = 11218465843950 := by decide
theorem cert_e2422372821742 : check e2422372821742 [[],[]] .three = true := by decide
def e2422372821750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2422372821750 : Closed e2422372821750 ∧ code e2422372821750 = 11218465843958 := by decide
theorem cert_e2422372821750 : check e2422372821750 [[],[]] .three = true := by decide
def e2422372821782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372821782 : Closed e2422372821782 ∧ code e2422372821782 = 11218465843990 := by decide
theorem cert_e2422372821782 : check e2422372821782 [[],[]] .three = true := by decide
def e2422372821786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372821786 : Closed e2422372821786 ∧ code e2422372821786 = 11218465843994 := by decide
theorem cert_e2422372821786 : check e2422372821786 [[],[]] .three = true := by decide
def e2422372821830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372821830 : Closed e2422372821830 ∧ code e2422372821830 = 11218465844038 := by decide
theorem cert_e2422372821830 : check e2422372821830 [[],[]] .three = true := by decide
end Blc.Floor43
