import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422362265850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e2422362265850 : Closed e2422362265850 ∧ code e2422362265850 = 11218455288058 := by decide
theorem cert_e2422362265850 : check e2422362265850 [[],[]] .smaller = true := by decide
def e2422362266030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422362266030 : Closed e2422362266030 ∧ code e2422362266030 = 11218455288238 := by decide
theorem cert_e2422362266030 : check e2422362266030 [[],[]] .smaller = true := by decide
def e2422362266042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422362266042 : Closed e2422362266042 ∧ code e2422362266042 = 11218455288250 := by decide
theorem cert_e2422362266042 : check e2422362266042 [[],[]] .smaller = true := by decide
def e2422362266090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422362266090 : Closed e2422362266090 ∧ code e2422362266090 = 11218455288298 := by decide
theorem cert_e2422362266090 : check e2422362266090 [[],[]] .smaller = true := by decide
def e2422362266174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e2422362266174 : Closed e2422362266174 ∧ code e2422362266174 = 11218455288382 := by decide
theorem cert_e2422362266174 : check e2422362266174 [[],[]] .smaller = true := by decide
def e2422362266222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362266222 : Closed e2422362266222 ∧ code e2422362266222 = 11218455288430 := by decide
theorem cert_e2422362266222 : check e2422362266222 [[],[]] .smaller = true := by decide
def e2422362266234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362266234 : Closed e2422362266234 ∧ code e2422362266234 = 11218455288442 := by decide
theorem cert_e2422362266234 : check e2422362266234 [[],[]] .smaller = true := by decide
def e2422362266398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2422362266398 : Closed e2422362266398 ∧ code e2422362266398 = 11218455288606 := by decide
theorem cert_e2422362266398 : check e2422362266398 [[],[]] .smaller = true := by decide
def e2422362266494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 5)))))))))
theorem wire_e2422362266494 : Closed e2422362266494 ∧ code e2422362266494 = 11218455288702 := by decide
theorem cert_e2422362266494 : check e2422362266494 [[],[]] .three = true := by decide
def e2422362266510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2422362266510 : Closed e2422362266510 ∧ code e2422362266510 = 11218455288718 := by decide
theorem cert_e2422362266510 : check e2422362266510 [[],[]] .smaller = true := by decide
def e2422362266522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362266522 : Closed e2422362266522 ∧ code e2422362266522 = 11218455288730 := by decide
theorem cert_e2422362266522 : check e2422362266522 [[],[]] .smaller = true := by decide
def e2422362266566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e2422362266566 : Closed e2422362266566 ∧ code e2422362266566 = 11218455288774 := by decide
theorem cert_e2422362266566 : check e2422362266566 [[],[]] .smaller = true := by decide
def e2422362266590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3)))))))))
theorem wire_e2422362266590 : Closed e2422362266590 ∧ code e2422362266590 = 11218455288798 := by decide
theorem cert_e2422362266590 : check e2422362266590 [[],[]] .smaller = true := by decide
def e2422362266614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 5)) (.var 1)))))))))
theorem wire_e2422362266614 : Closed e2422362266614 ∧ code e2422362266614 = 11218455288822 := by decide
theorem cert_e2422362266614 : check e2422362266614 [[],[]] .three = true := by decide
def e2422362266742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422362266742 : Closed e2422362266742 ∧ code e2422362266742 = 11218455288950 := by decide
theorem cert_e2422362266742 : check e2422362266742 [[],[]] .smaller = true := by decide
def e2422362266838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422362266838 : Closed e2422362266838 ∧ code e2422362266838 = 11218455289046 := by decide
theorem cert_e2422362266838 : check e2422362266838 [[],[]] .smaller = true := by decide
def e2422362266842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422362266842 : Closed e2422362266842 ∧ code e2422362266842 = 11218455289050 := by decide
theorem cert_e2422362266842 : check e2422362266842 [[],[]] .smaller = true := by decide
def e2422362266858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422362266858 : Closed e2422362266858 ∧ code e2422362266858 = 11218455289066 := by decide
theorem cert_e2422362266858 : check e2422362266858 [[],[]] .smaller = true := by decide
def e2422362266934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362266934 : Closed e2422362266934 ∧ code e2422362266934 = 11218455289142 := by decide
theorem cert_e2422362266934 : check e2422362266934 [[],[]] .smaller = true := by decide
def e2422362266938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362266938 : Closed e2422362266938 ∧ code e2422362266938 = 11218455289146 := by decide
theorem cert_e2422362266938 : check e2422362266938 [[],[]] .smaller = true := by decide
def e2422362267006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 5)))))))))
theorem wire_e2422362267006 : Closed e2422362267006 ∧ code e2422362267006 = 11218455289214 := by decide
theorem cert_e2422362267006 : check e2422362267006 [[],[]] .three = true := by decide
def e2422362267022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422362267022 : Closed e2422362267022 ∧ code e2422362267022 = 11218455289230 := by decide
theorem cert_e2422362267022 : check e2422362267022 [[],[]] .smaller = true := by decide
def e2422362267034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362267034 : Closed e2422362267034 ∧ code e2422362267034 = 11218455289242 := by decide
theorem cert_e2422362267034 : check e2422362267034 [[],[]] .smaller = true := by decide
def e2422362267102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3)))))))))
theorem wire_e2422362267102 : Closed e2422362267102 ∧ code e2422362267102 = 11218455289310 := by decide
theorem cert_e2422362267102 : check e2422362267102 [[],[]] .smaller = true := by decide
def e2422362267118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2)))))))))
theorem wire_e2422362267118 : Closed e2422362267118 ∧ code e2422362267118 = 11218455289326 := by decide
theorem cert_e2422362267118 : check e2422362267118 [[],[]] .smaller = true := by decide
def e2422362267130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 5)) (.var 0)))))))))
theorem wire_e2422362267130 : Closed e2422362267130 ∧ code e2422362267130 = 11218455289338 := by decide
theorem cert_e2422362267130 : check e2422362267130 [[],[]] .three = true := by decide
def e2422362267190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422362267190 : Closed e2422362267190 ∧ code e2422362267190 = 11218455289398 := by decide
theorem cert_e2422362267190 : check e2422362267190 [[],[]] .smaller = true := by decide
def e2422362267194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422362267194 : Closed e2422362267194 ∧ code e2422362267194 = 11218455289402 := by decide
theorem cert_e2422362267194 : check e2422362267194 [[],[]] .smaller = true := by decide
def e2422362267278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422362267278 : Closed e2422362267278 ∧ code e2422362267278 = 11218455289486 := by decide
theorem cert_e2422362267278 : check e2422362267278 [[],[]] .smaller = true := by decide
def e2422362267326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 4)))))))))
theorem wire_e2422362267326 : Closed e2422362267326 ∧ code e2422362267326 = 11218455289534 := by decide
theorem cert_e2422362267326 : check e2422362267326 [[],[]] .smaller = true := by decide
def e2422362267334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422362267334 : Closed e2422362267334 ∧ code e2422362267334 = 11218455289542 := by decide
theorem cert_e2422362267334 : check e2422362267334 [[],[]] .smaller = true := by decide
def e2422362267358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3)))))))))
theorem wire_e2422362267358 : Closed e2422362267358 ∧ code e2422362267358 = 11218455289566 := by decide
theorem cert_e2422362267358 : check e2422362267358 [[],[]] .smaller = true := by decide
def e2422362267374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2)))))))))
theorem wire_e2422362267374 : Closed e2422362267374 ∧ code e2422362267374 = 11218455289582 := by decide
theorem cert_e2422362267374 : check e2422362267374 [[],[]] .smaller = true := by decide
def e2422362267382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1)))))))))
theorem wire_e2422362267382 : Closed e2422362267382 ∧ code e2422362267382 = 11218455289590 := by decide
theorem cert_e2422362267382 : check e2422362267382 [[],[]] .smaller = true := by decide
def e2422362267386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 4)) (.var 0)))))))))
theorem wire_e2422362267386 : Closed e2422362267386 ∧ code e2422362267386 = 11218455289594 := by decide
theorem cert_e2422362267386 : check e2422362267386 [[],[]] .smaller = true := by decide
def e2422362267486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 3)))))))))
theorem wire_e2422362267486 : Closed e2422362267486 ∧ code e2422362267486 = 11218455289694 := by decide
theorem cert_e2422362267486 : check e2422362267486 [[],[]] .smaller = true := by decide
def e2422362267514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 3)) (.var 0)))))))))
theorem wire_e2422362267514 : Closed e2422362267514 ∧ code e2422362267514 = 11218455289722 := by decide
theorem cert_e2422362267514 : check e2422362267514 [[],[]] .smaller = true := by decide
def e2422362267566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 5)) (.var 0)) (.var 2)))))))))
theorem wire_e2422362267566 : Closed e2422362267566 ∧ code e2422362267566 = 11218455289774 := by decide
theorem cert_e2422362267566 : check e2422362267566 [[],[]] .three = true := by decide
def e2422362267574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 5)) (.var 1)) (.var 1)))))))))
theorem wire_e2422362267574 : Closed e2422362267574 ∧ code e2422362267574 = 11218455289782 := by decide
theorem cert_e2422362267574 : check e2422362267574 [[],[]] .three = true := by decide
def e2422362267578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 5)) (.var 2)) (.var 0)))))))))
theorem wire_e2422362267578 : Closed e2422362267578 ∧ code e2422362267578 = 11218455289786 := by decide
theorem cert_e2422362267578 : check e2422362267578 [[],[]] .three = true := by decide
def e2422362268510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3)))))))))
theorem wire_e2422362268510 : Closed e2422362268510 ∧ code e2422362268510 = 11218455290718 := by decide
theorem cert_e2422362268510 : check e2422362268510 [[],[]] .smaller = true := by decide
def e2422362268526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))))
theorem wire_e2422362268526 : Closed e2422362268526 ∧ code e2422362268526 = 11218455290734 := by decide
theorem cert_e2422362268526 : check e2422362268526 [[],[]] .smaller = true := by decide
def e2422362268534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))))
theorem wire_e2422362268534 : Closed e2422362268534 ∧ code e2422362268534 = 11218455290742 := by decide
theorem cert_e2422362268534 : check e2422362268534 [[],[]] .smaller = true := by decide
def e2422362268538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0)))))))))
theorem wire_e2422362268538 : Closed e2422362268538 ∧ code e2422362268538 = 11218455290746 := by decide
theorem cert_e2422362268538 : check e2422362268538 [[],[]] .smaller = true := by decide
def e2422362268590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))))
theorem wire_e2422362268590 : Closed e2422362268590 ∧ code e2422362268590 = 11218455290798 := by decide
theorem cert_e2422362268590 : check e2422362268590 [[],[]] .smaller = true := by decide
def e2422362268602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))))
theorem wire_e2422362268602 : Closed e2422362268602 ∧ code e2422362268602 = 11218455290810 := by decide
theorem cert_e2422362268602 : check e2422362268602 [[],[]] .smaller = true := by decide
def e2422362268630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))))
theorem wire_e2422362268630 : Closed e2422362268630 ∧ code e2422362268630 = 11218455290838 := by decide
theorem cert_e2422362268630 : check e2422362268630 [[],[]] .smaller = true := by decide
def e2422362268634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))))
theorem wire_e2422362268634 : Closed e2422362268634 ∧ code e2422362268634 = 11218455290842 := by decide
theorem cert_e2422362268634 : check e2422362268634 [[],[]] .smaller = true := by decide
def e2422362268650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362268650 : Closed e2422362268650 ∧ code e2422362268650 = 11218455290858 := by decide
theorem cert_e2422362268650 : check e2422362268650 [[],[]] .smaller = true := by decide
def e2422362269358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))))
theorem wire_e2422362269358 : Closed e2422362269358 ∧ code e2422362269358 = 11218455291566 := by decide
theorem cert_e2422362269358 : check e2422362269358 [[],[]] .smaller = true := by decide
def e2422362269370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))))
theorem wire_e2422362269370 : Closed e2422362269370 ∧ code e2422362269370 = 11218455291578 := by decide
theorem cert_e2422362269370 : check e2422362269370 [[],[]] .smaller = true := by decide
def e2422362269418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362269418 : Closed e2422362269418 ∧ code e2422362269418 = 11218455291626 := by decide
theorem cert_e2422362269418 : check e2422362269418 [[],[]] .smaller = true := by decide
def e2422362269610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362269610 : Closed e2422362269610 ∧ code e2422362269610 = 11218455291818 := by decide
theorem cert_e2422362269610 : check e2422362269610 [[],[]] .smaller = true := by decide
def e2422362269918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e2422362269918 : Closed e2422362269918 ∧ code e2422362269918 = 11218455292126 := by decide
theorem cert_e2422362269918 : check e2422362269918 [[],[]] .smaller = true := by decide
def e2422362269934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2422362269934 : Closed e2422362269934 ∧ code e2422362269934 = 11218455292142 := by decide
theorem cert_e2422362269934 : check e2422362269934 [[],[]] .smaller = true := by decide
def e2422362269942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2422362269942 : Closed e2422362269942 ∧ code e2422362269942 = 11218455292150 := by decide
theorem cert_e2422362269942 : check e2422362269942 [[],[]] .smaller = true := by decide
def e2422362269946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e2422362269946 : Closed e2422362269946 ∧ code e2422362269946 = 11218455292154 := by decide
theorem cert_e2422362269946 : check e2422362269946 [[],[]] .smaller = true := by decide
def e2422362270126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422362270126 : Closed e2422362270126 ∧ code e2422362270126 = 11218455292334 := by decide
theorem cert_e2422362270126 : check e2422362270126 [[],[]] .smaller = true := by decide
def e2422362270138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422362270138 : Closed e2422362270138 ∧ code e2422362270138 = 11218455292346 := by decide
theorem cert_e2422362270138 : check e2422362270138 [[],[]] .smaller = true := by decide
def e2422362270186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422362270186 : Closed e2422362270186 ∧ code e2422362270186 = 11218455292394 := by decide
theorem cert_e2422362270186 : check e2422362270186 [[],[]] .smaller = true := by decide
def e2422362270270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e2422362270270 : Closed e2422362270270 ∧ code e2422362270270 = 11218455292478 := by decide
theorem cert_e2422362270270 : check e2422362270270 [[],[]] .smaller = true := by decide
def e2422362270318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362270318 : Closed e2422362270318 ∧ code e2422362270318 = 11218455292526 := by decide
theorem cert_e2422362270318 : check e2422362270318 [[],[]] .smaller = true := by decide
def e2422362270330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362270330 : Closed e2422362270330 ∧ code e2422362270330 = 11218455292538 := by decide
theorem cert_e2422362270330 : check e2422362270330 [[],[]] .smaller = true := by decide
def e2422362270494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2422362270494 : Closed e2422362270494 ∧ code e2422362270494 = 11218455292702 := by decide
theorem cert_e2422362270494 : check e2422362270494 [[],[]] .smaller = true := by decide
def e2422362270590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 5)))))))))
theorem wire_e2422362270590 : Closed e2422362270590 ∧ code e2422362270590 = 11218455292798 := by decide
theorem cert_e2422362270590 : check e2422362270590 [[],[]] .three = true := by decide
def e2422362270606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2422362270606 : Closed e2422362270606 ∧ code e2422362270606 = 11218455292814 := by decide
theorem cert_e2422362270606 : check e2422362270606 [[],[]] .smaller = true := by decide
def e2422362270618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362270618 : Closed e2422362270618 ∧ code e2422362270618 = 11218455292826 := by decide
theorem cert_e2422362270618 : check e2422362270618 [[],[]] .smaller = true := by decide
def e2422362270662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e2422362270662 : Closed e2422362270662 ∧ code e2422362270662 = 11218455292870 := by decide
theorem cert_e2422362270662 : check e2422362270662 [[],[]] .smaller = true := by decide
def e2422362270686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3)))))))))
theorem wire_e2422362270686 : Closed e2422362270686 ∧ code e2422362270686 = 11218455292894 := by decide
theorem cert_e2422362270686 : check e2422362270686 [[],[]] .smaller = true := by decide
def e2422362270710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 5)) (.var 1)))))))))
theorem wire_e2422362270710 : Closed e2422362270710 ∧ code e2422362270710 = 11218455292918 := by decide
theorem cert_e2422362270710 : check e2422362270710 [[],[]] .three = true := by decide
def e2422362270830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2422362270830 : Closed e2422362270830 ∧ code e2422362270830 = 11218455293038 := by decide
theorem cert_e2422362270830 : check e2422362270830 [[],[]] .smaller = true := by decide
def e2422362270842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2422362270842 : Closed e2422362270842 ∧ code e2422362270842 = 11218455293050 := by decide
theorem cert_e2422362270842 : check e2422362270842 [[],[]] .smaller = true := by decide
def e2422362271006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2422362271006 : Closed e2422362271006 ∧ code e2422362271006 = 11218455293214 := by decide
theorem cert_e2422362271006 : check e2422362271006 [[],[]] .smaller = true := by decide
def e2422362271102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 5)))))))))
theorem wire_e2422362271102 : Closed e2422362271102 ∧ code e2422362271102 = 11218455293310 := by decide
theorem cert_e2422362271102 : check e2422362271102 [[],[]] .three = true := by decide
def e2422362271174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2422362271174 : Closed e2422362271174 ∧ code e2422362271174 = 11218455293382 := by decide
theorem cert_e2422362271174 : check e2422362271174 [[],[]] .smaller = true := by decide
def e2422362271198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3)))))))))
theorem wire_e2422362271198 : Closed e2422362271198 ∧ code e2422362271198 = 11218455293406 := by decide
theorem cert_e2422362271198 : check e2422362271198 [[],[]] .smaller = true := by decide
def e2422362271214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2)))))))))
theorem wire_e2422362271214 : Closed e2422362271214 ∧ code e2422362271214 = 11218455293422 := by decide
theorem cert_e2422362271214 : check e2422362271214 [[],[]] .smaller = true := by decide
def e2422362271226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 5)) (.var 0)))))))))
theorem wire_e2422362271226 : Closed e2422362271226 ∧ code e2422362271226 = 11218455293434 := by decide
theorem cert_e2422362271226 : check e2422362271226 [[],[]] .three = true := by decide
def e2422362271286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422362271286 : Closed e2422362271286 ∧ code e2422362271286 = 11218455293494 := by decide
theorem cert_e2422362271286 : check e2422362271286 [[],[]] .smaller = true := by decide
def e2422362271290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422362271290 : Closed e2422362271290 ∧ code e2422362271290 = 11218455293498 := by decide
theorem cert_e2422362271290 : check e2422362271290 [[],[]] .smaller = true := by decide
def e2422362271338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422362271338 : Closed e2422362271338 ∧ code e2422362271338 = 11218455293546 := by decide
theorem cert_e2422362271338 : check e2422362271338 [[],[]] .smaller = true := by decide
def e2422362271374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422362271374 : Closed e2422362271374 ∧ code e2422362271374 = 11218455293582 := by decide
theorem cert_e2422362271374 : check e2422362271374 [[],[]] .smaller = true := by decide
def e2422362271386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362271386 : Closed e2422362271386 ∧ code e2422362271386 = 11218455293594 := by decide
theorem cert_e2422362271386 : check e2422362271386 [[],[]] .smaller = true := by decide
def e2422362271430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422362271430 : Closed e2422362271430 ∧ code e2422362271430 = 11218455293638 := by decide
theorem cert_e2422362271430 : check e2422362271430 [[],[]] .smaller = true := by decide
def e2422362271454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3)))))))))
theorem wire_e2422362271454 : Closed e2422362271454 ∧ code e2422362271454 = 11218455293662 := by decide
theorem cert_e2422362271454 : check e2422362271454 [[],[]] .smaller = true := by decide
def e2422362271478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1)))))))))
theorem wire_e2422362271478 : Closed e2422362271478 ∧ code e2422362271478 = 11218455293686 := by decide
theorem cert_e2422362271478 : check e2422362271478 [[],[]] .smaller = true := by decide
def e2422362271514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422362271514 : Closed e2422362271514 ∧ code e2422362271514 = 11218455293722 := by decide
theorem cert_e2422362271514 : check e2422362271514 [[],[]] .smaller = true := by decide
def e2422362271558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422362271558 : Closed e2422362271558 ∧ code e2422362271558 = 11218455293766 := by decide
theorem cert_e2422362271558 : check e2422362271558 [[],[]] .smaller = true := by decide
def e2422362271582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3)))))))))
theorem wire_e2422362271582 : Closed e2422362271582 ∧ code e2422362271582 = 11218455293790 := by decide
theorem cert_e2422362271582 : check e2422362271582 [[],[]] .smaller = true := by decide
def e2422362271598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2)))))))))
theorem wire_e2422362271598 : Closed e2422362271598 ∧ code e2422362271598 = 11218455293806 := by decide
theorem cert_e2422362271598 : check e2422362271598 [[],[]] .smaller = true := by decide
def e2422362271606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1)))))))))
theorem wire_e2422362271606 : Closed e2422362271606 ∧ code e2422362271606 = 11218455293814 := by decide
theorem cert_e2422362271606 : check e2422362271606 [[],[]] .smaller = true := by decide
def e2422362271610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0)))))))))
theorem wire_e2422362271610 : Closed e2422362271610 ∧ code e2422362271610 = 11218455293818 := by decide
theorem cert_e2422362271610 : check e2422362271610 [[],[]] .smaller = true := by decide
def e2422362271702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 5)) (.var 0)) (.var 1)))))))))
theorem wire_e2422362271702 : Closed e2422362271702 ∧ code e2422362271702 = 11218455293910 := by decide
theorem cert_e2422362271702 : check e2422362271702 [[],[]] .three = true := by decide
def e2422362271706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 5)) (.var 1)) (.var 0)))))))))
theorem wire_e2422362271706 : Closed e2422362271706 ∧ code e2422362271706 = 11218455293914 := by decide
theorem cert_e2422362271706 : check e2422362271706 [[],[]] .three = true := by decide
def e2422362272182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))))
theorem wire_e2422362272182 : Closed e2422362272182 ∧ code e2422362272182 = 11218455294390 := by decide
theorem cert_e2422362272182 : check e2422362272182 [[],[]] .smaller = true := by decide
def e2422362272214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))))
theorem wire_e2422362272214 : Closed e2422362272214 ∧ code e2422362272214 = 11218455294422 := by decide
theorem cert_e2422362272214 : check e2422362272214 [[],[]] .smaller = true := by decide
def e2422362272218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))))
theorem wire_e2422362272218 : Closed e2422362272218 ∧ code e2422362272218 = 11218455294426 := by decide
theorem cert_e2422362272218 : check e2422362272218 [[],[]] .smaller = true := by decide
def e2422362272598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))))
theorem wire_e2422362272598 : Closed e2422362272598 ∧ code e2422362272598 = 11218455294806 := by decide
theorem cert_e2422362272598 : check e2422362272598 [[],[]] .smaller = true := by decide
def e2422362272602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))))
theorem wire_e2422362272602 : Closed e2422362272602 ∧ code e2422362272602 = 11218455294810 := by decide
theorem cert_e2422362272602 : check e2422362272602 [[],[]] .smaller = true := by decide
def e2422362272618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362272618 : Closed e2422362272618 ∧ code e2422362272618 = 11218455294826 := by decide
theorem cert_e2422362272618 : check e2422362272618 [[],[]] .smaller = true := by decide
def e2422362272682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362272682 : Closed e2422362272682 ∧ code e2422362272682 = 11218455294890 := by decide
theorem cert_e2422362272682 : check e2422362272682 [[],[]] .smaller = true := by decide
def e2422362272886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422362272886 : Closed e2422362272886 ∧ code e2422362272886 = 11218455295094 := by decide
theorem cert_e2422362272886 : check e2422362272886 [[],[]] .smaller = true := by decide
def e2422362272982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422362272982 : Closed e2422362272982 ∧ code e2422362272982 = 11218455295190 := by decide
theorem cert_e2422362272982 : check e2422362272982 [[],[]] .smaller = true := by decide
def e2422362272986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422362272986 : Closed e2422362272986 ∧ code e2422362272986 = 11218455295194 := by decide
theorem cert_e2422362272986 : check e2422362272986 [[],[]] .smaller = true := by decide
def e2422362273002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422362273002 : Closed e2422362273002 ∧ code e2422362273002 = 11218455295210 := by decide
theorem cert_e2422362273002 : check e2422362273002 [[],[]] .smaller = true := by decide
def e2422362273078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362273078 : Closed e2422362273078 ∧ code e2422362273078 = 11218455295286 := by decide
theorem cert_e2422362273078 : check e2422362273078 [[],[]] .smaller = true := by decide
def e2422362273082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362273082 : Closed e2422362273082 ∧ code e2422362273082 = 11218455295290 := by decide
theorem cert_e2422362273082 : check e2422362273082 [[],[]] .smaller = true := by decide
def e2422362273150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 5)))))))))
theorem wire_e2422362273150 : Closed e2422362273150 ∧ code e2422362273150 = 11218455295358 := by decide
theorem cert_e2422362273150 : check e2422362273150 [[],[]] .three = true := by decide
def e2422362273166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422362273166 : Closed e2422362273166 ∧ code e2422362273166 = 11218455295374 := by decide
theorem cert_e2422362273166 : check e2422362273166 [[],[]] .smaller = true := by decide
def e2422362273178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362273178 : Closed e2422362273178 ∧ code e2422362273178 = 11218455295386 := by decide
theorem cert_e2422362273178 : check e2422362273178 [[],[]] .smaller = true := by decide
def e2422362273246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e2422362273246 : Closed e2422362273246 ∧ code e2422362273246 = 11218455295454 := by decide
theorem cert_e2422362273246 : check e2422362273246 [[],[]] .smaller = true := by decide
def e2422362273262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e2422362273262 : Closed e2422362273262 ∧ code e2422362273262 = 11218455295470 := by decide
theorem cert_e2422362273262 : check e2422362273262 [[],[]] .smaller = true := by decide
def e2422362273274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 5)) (.var 0)))))))))
theorem wire_e2422362273274 : Closed e2422362273274 ∧ code e2422362273274 = 11218455295482 := by decide
theorem cert_e2422362273274 : check e2422362273274 [[],[]] .three = true := by decide
def e2422362273334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422362273334 : Closed e2422362273334 ∧ code e2422362273334 = 11218455295542 := by decide
theorem cert_e2422362273334 : check e2422362273334 [[],[]] .smaller = true := by decide
def e2422362273338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422362273338 : Closed e2422362273338 ∧ code e2422362273338 = 11218455295546 := by decide
theorem cert_e2422362273338 : check e2422362273338 [[],[]] .smaller = true := by decide
def e2422362273386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422362273386 : Closed e2422362273386 ∧ code e2422362273386 = 11218455295594 := by decide
theorem cert_e2422362273386 : check e2422362273386 [[],[]] .smaller = true := by decide
def e2422362273422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422362273422 : Closed e2422362273422 ∧ code e2422362273422 = 11218455295630 := by decide
theorem cert_e2422362273422 : check e2422362273422 [[],[]] .smaller = true := by decide
def e2422362273434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362273434 : Closed e2422362273434 ∧ code e2422362273434 = 11218455295642 := by decide
theorem cert_e2422362273434 : check e2422362273434 [[],[]] .smaller = true := by decide
def e2422362273478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422362273478 : Closed e2422362273478 ∧ code e2422362273478 = 11218455295686 := by decide
theorem cert_e2422362273478 : check e2422362273478 [[],[]] .smaller = true := by decide
def e2422362273502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e2422362273502 : Closed e2422362273502 ∧ code e2422362273502 = 11218455295710 := by decide
theorem cert_e2422362273502 : check e2422362273502 [[],[]] .smaller = true := by decide
def e2422362273526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e2422362273526 : Closed e2422362273526 ∧ code e2422362273526 = 11218455295734 := by decide
theorem cert_e2422362273526 : check e2422362273526 [[],[]] .smaller = true := by decide
def e2422362273630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e2422362273630 : Closed e2422362273630 ∧ code e2422362273630 = 11218455295838 := by decide
theorem cert_e2422362273630 : check e2422362273630 [[],[]] .smaller = true := by decide
def e2422362273658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e2422362273658 : Closed e2422362273658 ∧ code e2422362273658 = 11218455295866 := by decide
theorem cert_e2422362273658 : check e2422362273658 [[],[]] .smaller = true := by decide
def e2422362273710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e2422362273710 : Closed e2422362273710 ∧ code e2422362273710 = 11218455295918 := by decide
theorem cert_e2422362273710 : check e2422362273710 [[],[]] .smaller = true := by decide
def e2422362273718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e2422362273718 : Closed e2422362273718 ∧ code e2422362273718 = 11218455295926 := by decide
theorem cert_e2422362273718 : check e2422362273718 [[],[]] .smaller = true := by decide
def e2422362273722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e2422362273722 : Closed e2422362273722 ∧ code e2422362273722 = 11218455295930 := by decide
theorem cert_e2422362273722 : check e2422362273722 [[],[]] .smaller = true := by decide
def e2422362273770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 5)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362273770 : Closed e2422362273770 ∧ code e2422362273770 = 11218455295978 := by decide
theorem cert_e2422362273770 : check e2422362273770 [[],[]] .three = true := by decide
def e2422362274006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1)))))))))
theorem wire_e2422362274006 : Closed e2422362274006 ∧ code e2422362274006 = 11218455296214 := by decide
theorem cert_e2422362274006 : check e2422362274006 [[],[]] .smaller = true := by decide
def e2422362274010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0)))))))))
theorem wire_e2422362274010 : Closed e2422362274010 ∧ code e2422362274010 = 11218455296218 := by decide
theorem cert_e2422362274010 : check e2422362274010 [[],[]] .smaller = true := by decide
def e2422362274026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362274026 : Closed e2422362274026 ∧ code e2422362274026 = 11218455296234 := by decide
theorem cert_e2422362274026 : check e2422362274026 [[],[]] .smaller = true := by decide
def e2422362274358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422362274358 : Closed e2422362274358 ∧ code e2422362274358 = 11218455296566 := by decide
theorem cert_e2422362274358 : check e2422362274358 [[],[]] .smaller = true := by decide
def e2422362274362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422362274362 : Closed e2422362274362 ∧ code e2422362274362 = 11218455296570 := by decide
theorem cert_e2422362274362 : check e2422362274362 [[],[]] .smaller = true := by decide
def e2422362274446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422362274446 : Closed e2422362274446 ∧ code e2422362274446 = 11218455296654 := by decide
theorem cert_e2422362274446 : check e2422362274446 [[],[]] .smaller = true := by decide
def e2422362274494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 4)))))))))
theorem wire_e2422362274494 : Closed e2422362274494 ∧ code e2422362274494 = 11218455296702 := by decide
theorem cert_e2422362274494 : check e2422362274494 [[],[]] .smaller = true := by decide
def e2422362274502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422362274502 : Closed e2422362274502 ∧ code e2422362274502 = 11218455296710 := by decide
theorem cert_e2422362274502 : check e2422362274502 [[],[]] .smaller = true := by decide
def e2422362274526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e2422362274526 : Closed e2422362274526 ∧ code e2422362274526 = 11218455296734 := by decide
theorem cert_e2422362274526 : check e2422362274526 [[],[]] .smaller = true := by decide
def e2422362274542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e2422362274542 : Closed e2422362274542 ∧ code e2422362274542 = 11218455296750 := by decide
theorem cert_e2422362274542 : check e2422362274542 [[],[]] .smaller = true := by decide
def e2422362274550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e2422362274550 : Closed e2422362274550 ∧ code e2422362274550 = 11218455296758 := by decide
theorem cert_e2422362274550 : check e2422362274550 [[],[]] .smaller = true := by decide
def e2422362274554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 4)) (.var 0)))))))))
theorem wire_e2422362274554 : Closed e2422362274554 ∧ code e2422362274554 = 11218455296762 := by decide
theorem cert_e2422362274554 : check e2422362274554 [[],[]] .smaller = true := by decide
def e2422362274586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422362274586 : Closed e2422362274586 ∧ code e2422362274586 = 11218455296794 := by decide
theorem cert_e2422362274586 : check e2422362274586 [[],[]] .smaller = true := by decide
def e2422362274630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422362274630 : Closed e2422362274630 ∧ code e2422362274630 = 11218455296838 := by decide
theorem cert_e2422362274630 : check e2422362274630 [[],[]] .smaller = true := by decide
def e2422362274654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e2422362274654 : Closed e2422362274654 ∧ code e2422362274654 = 11218455296862 := by decide
theorem cert_e2422362274654 : check e2422362274654 [[],[]] .smaller = true := by decide
def e2422362274670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e2422362274670 : Closed e2422362274670 ∧ code e2422362274670 = 11218455296878 := by decide
theorem cert_e2422362274670 : check e2422362274670 [[],[]] .smaller = true := by decide
def e2422362274678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e2422362274678 : Closed e2422362274678 ∧ code e2422362274678 = 11218455296886 := by decide
theorem cert_e2422362274678 : check e2422362274678 [[],[]] .smaller = true := by decide
def e2422362274682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e2422362274682 : Closed e2422362274682 ∧ code e2422362274682 = 11218455296890 := by decide
theorem cert_e2422362274682 : check e2422362274682 [[],[]] .smaller = true := by decide
def e2422362274734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e2422362274734 : Closed e2422362274734 ∧ code e2422362274734 = 11218455296942 := by decide
theorem cert_e2422362274734 : check e2422362274734 [[],[]] .smaller = true := by decide
def e2422362274742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e2422362274742 : Closed e2422362274742 ∧ code e2422362274742 = 11218455296950 := by decide
theorem cert_e2422362274742 : check e2422362274742 [[],[]] .smaller = true := by decide
def e2422362274746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e2422362274746 : Closed e2422362274746 ∧ code e2422362274746 = 11218455296954 := by decide
theorem cert_e2422362274746 : check e2422362274746 [[],[]] .smaller = true := by decide
def e2422362274774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e2422362274774 : Closed e2422362274774 ∧ code e2422362274774 = 11218455296982 := by decide
theorem cert_e2422362274774 : check e2422362274774 [[],[]] .smaller = true := by decide
def e2422362274778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e2422362274778 : Closed e2422362274778 ∧ code e2422362274778 = 11218455296986 := by decide
theorem cert_e2422362274778 : check e2422362274778 [[],[]] .smaller = true := by decide
def e2422362274794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 4)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362274794 : Closed e2422362274794 ∧ code e2422362274794 = 11218455297002 := by decide
theorem cert_e2422362274794 : check e2422362274794 [[],[]] .smaller = true := by decide
def e2422362275166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e2422362275166 : Closed e2422362275166 ∧ code e2422362275166 = 11218455297374 := by decide
theorem cert_e2422362275166 : check e2422362275166 [[],[]] .smaller = true := by decide
def e2422362275194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e2422362275194 : Closed e2422362275194 ∧ code e2422362275194 = 11218455297402 := by decide
theorem cert_e2422362275194 : check e2422362275194 [[],[]] .smaller = true := by decide
def e2422362275306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362275306 : Closed e2422362275306 ∧ code e2422362275306 = 11218455297514 := by decide
theorem cert_e2422362275306 : check e2422362275306 [[],[]] .smaller = true := by decide
def e2422362275502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422362275502 : Closed e2422362275502 ∧ code e2422362275502 = 11218455297710 := by decide
theorem cert_e2422362275502 : check e2422362275502 [[],[]] .three = true := by decide
def e2422362275510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2422362275510 : Closed e2422362275510 ∧ code e2422362275510 = 11218455297718 := by decide
theorem cert_e2422362275510 : check e2422362275510 [[],[]] .three = true := by decide
def e2422362275514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422362275514 : Closed e2422362275514 ∧ code e2422362275514 = 11218455297722 := by decide
theorem cert_e2422362275514 : check e2422362275514 [[],[]] .three = true := by decide
def e2422362275542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2422362275542 : Closed e2422362275542 ∧ code e2422362275542 = 11218455297750 := by decide
theorem cert_e2422362275542 : check e2422362275542 [[],[]] .three = true := by decide
def e2422362275546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2422362275546 : Closed e2422362275546 ∧ code e2422362275546 = 11218455297754 := by decide
theorem cert_e2422362275546 : check e2422362275546 [[],[]] .three = true := by decide
def e2422362275562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 5) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362275562 : Closed e2422362275562 ∧ code e2422362275562 = 11218455297770 := by decide
theorem cert_e2422362275562 : check e2422362275562 [[],[]] .three = true := by decide
end Blc.Floor43
