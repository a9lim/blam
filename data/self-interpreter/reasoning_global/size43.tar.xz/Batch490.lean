import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407941786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407941786 : Closed e2422407941786 ∧ code e2422407941786 = 11218500963994 := by decide
theorem cert_e2422407941786 : check e2422407941786 [[],[]] .smaller = true := by decide
def e2422407941870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e2422407941870 : Closed e2422407941870 ∧ code e2422407941870 = 11218500964078 := by decide
theorem cert_e2422407941870 : check e2422407941870 [[],[]] .chain = true := by decide
def e2422407941878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e2422407941878 : Closed e2422407941878 ∧ code e2422407941878 = 11218500964086 := by decide
theorem cert_e2422407941878 : check e2422407941878 [[],[]] .chain = true := by decide
def e2422407941998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e2422407941998 : Closed e2422407941998 ∧ code e2422407941998 = 11218500964206 := by decide
theorem cert_e2422407941998 : check e2422407941998 [[],[]] .chain = true := by decide
def e2422407942010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e2422407942010 : Closed e2422407942010 ∧ code e2422407942010 = 11218500964218 := by decide
theorem cert_e2422407942010 : check e2422407942010 [[],[]] .chain = true := by decide
def e2422407942026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407942026 : Closed e2422407942026 ∧ code e2422407942026 = 11218500964234 := by decide
theorem cert_e2422407942026 : check e2422407942026 [[],[]] .chain = true := by decide
def e2422407942062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))) (.var 2))))))
theorem wire_e2422407942062 : Closed e2422407942062 ∧ code e2422407942062 = 11218500964270 := by decide
theorem cert_e2422407942062 : check e2422407942062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407942070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e2422407942070 : Closed e2422407942070 ∧ code e2422407942070 = 11218500964278 := by decide
theorem cert_e2422407942070 : check e2422407942070 [[],[]] .chain = true := by decide
def e2422407942074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e2422407942074 : Closed e2422407942074 ∧ code e2422407942074 = 11218500964282 := by decide
theorem cert_e2422407942074 : check e2422407942074 [[],[]] .chain = true := by decide
def e2422407942942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407942942 : Closed e2422407942942 ∧ code e2422407942942 = 11218500965150 := by decide
theorem cert_e2422407942942 : check e2422407942942 [[],[]] .chain = true := by decide
def e2422407943110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407943110 : Closed e2422407943110 ∧ code e2422407943110 = 11218500965318 := by decide
theorem cert_e2422407943110 : check e2422407943110 [[],[]] .chain = true := by decide
def e2422407944254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.lam (.var 4))))))))
theorem wire_e2422407944254 : Closed e2422407944254 ∧ code e2422407944254 = 11218500966462 := by decide
theorem cert_e2422407944254 : check e2422407944254 [[],[]] .chain = true := by decide
def e2422407944674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407944674 : Closed e2422407944674 ∧ code e2422407944674 = 11218500966882 := by decide
theorem cert_e2422407944674 : check e2422407944674 [[],[]] .chain = true := by decide
def e2422407944686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407944686 : Closed e2422407944686 ∧ code e2422407944686 = 11218500966894 := by decide
theorem cert_e2422407944686 : check e2422407944686 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407945454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407945454 : Closed e2422407945454 ∧ code e2422407945454 = 11218500967662 := by decide
theorem cert_e2422407945454 : check e2422407945454 [[],[]] .chain = true := by decide
def e2422407945462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407945462 : Closed e2422407945462 ∧ code e2422407945462 = 11218500967670 := by decide
theorem cert_e2422407945462 : check e2422407945462 [[],[]] .chain = true := by decide
def e2422407945742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407945742 : Closed e2422407945742 ∧ code e2422407945742 = 11218500967950 := by decide
theorem cert_e2422407945742 : check e2422407945742 [[],[]] .chain = true := by decide
def e2422407945754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407945754 : Closed e2422407945754 ∧ code e2422407945754 = 11218500967962 := by decide
theorem cert_e2422407945754 : check e2422407945754 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407945826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407945826 : Closed e2422407945826 ∧ code e2422407945826 = 11218500968034 := by decide
theorem cert_e2422407945826 : check e2422407945826 [[],[]] .chain = true := by decide
def e2422407945838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407945838 : Closed e2422407945838 ∧ code e2422407945838 = 11218500968046 := by decide
theorem cert_e2422407945838 : check e2422407945838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407945846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407945846 : Closed e2422407945846 ∧ code e2422407945846 = 11218500968054 := by decide
theorem cert_e2422407945846 : check e2422407945846 [[],[]] .chain = true := by decide
def e2422407945850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407945850 : Closed e2422407945850 ∧ code e2422407945850 = 11218500968058 := by decide
theorem cert_e2422407945850 : check e2422407945850 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407946486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.lam (.var 3)))))) (.var 1))))))
theorem wire_e2422407946486 : Closed e2422407946486 ∧ code e2422407946486 = 11218500968694 := by decide
theorem cert_e2422407946486 : check e2422407946486 [[],[]] .chain = true := by decide
def e2422407946490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.lam (.var 4)))))) (.var 0))))))
theorem wire_e2422407946490 : Closed e2422407946490 ∧ code e2422407946490 = 11218500968698 := by decide
theorem cert_e2422407946490 : check e2422407946490 [[],[]] .chain = true := by decide
def e2422407946870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407946870 : Closed e2422407946870 ∧ code e2422407946870 = 11218500969078 := by decide
theorem cert_e2422407946870 : check e2422407946870 [[],[]] .chain = true := by decide
def e2422407947062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 1))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407947062 : Closed e2422407947062 ∧ code e2422407947062 = 11218500969270 := by decide
theorem cert_e2422407947062 : check e2422407947062 [[],[]] .chain = true := by decide
def e2422407947066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 1))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407947066 : Closed e2422407947066 ∧ code e2422407947066 = 11218500969274 := by decide
theorem cert_e2422407947066 : check e2422407947066 [[],[]] .chain = true := by decide
def e2422407947150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 2))))) (.lam (.var 2)))))))
theorem wire_e2422407947150 : Closed e2422407947150 ∧ code e2422407947150 = 11218500969358 := by decide
theorem cert_e2422407947150 : check e2422407947150 [[],[]] .chain = true := by decide
def e2422407947206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))) (.lam (.var 1)))))))
theorem wire_e2422407947206 : Closed e2422407947206 ∧ code e2422407947206 = 11218500969414 := by decide
theorem cert_e2422407947206 : check e2422407947206 [[],[]] .chain = true := by decide
def e2422407947830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422407947830 : Closed e2422407947830 ∧ code e2422407947830 = 11218500970038 := by decide
theorem cert_e2422407947830 : check e2422407947830 [[],[]] .chain = true := by decide
def e2422407947834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))) (.var 0))))))
theorem wire_e2422407947834 : Closed e2422407947834 ∧ code e2422407947834 = 11218500970042 := by decide
theorem cert_e2422407947834 : check e2422407947834 [[],[]] .chain = true := by decide
def e2422407947918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422407947918 : Closed e2422407947918 ∧ code e2422407947918 = 11218500970126 := by decide
theorem cert_e2422407947918 : check e2422407947918 [[],[]] .chain = true := by decide
def e2422407947974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.lam (.var 1)))))))
theorem wire_e2422407947974 : Closed e2422407947974 ∧ code e2422407947974 = 11218500970182 := by decide
theorem cert_e2422407947974 : check e2422407947974 [[],[]] .chain = true := by decide
def e2422407948014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e2422407948014 : Closed e2422407948014 ∧ code e2422407948014 = 11218500970222 := by decide
theorem cert_e2422407948014 : check e2422407948014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422407948022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e2422407948022 : Closed e2422407948022 ∧ code e2422407948022 = 11218500970230 := by decide
theorem cert_e2422407948022 : checkPay e2422407948022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left],[.under]] = true := by decide
def e2422407948054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422407948054 : Closed e2422407948054 ∧ code e2422407948054 = 11218500970262 := by decide
theorem cert_e2422407948054 : check e2422407948054 [[],[]] .chain = true := by decide
def e2422407948058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e2422407948058 : Closed e2422407948058 ∧ code e2422407948058 = 11218500970266 := by decide
theorem cert_e2422407948058 : check e2422407948058 [[],[]] .chain = true := by decide
def e2422407948102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e2422407948102 : Closed e2422407948102 ∧ code e2422407948102 = 11218500970310 := by decide
theorem cert_e2422407948102 : check e2422407948102 [[],[]] .chain = true := by decide
def e2422407948150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e2422407948150 : Closed e2422407948150 ∧ code e2422407948150 = 11218500970358 := by decide
theorem cert_e2422407948150 : check e2422407948150 [[],[]] .chain = true := by decide
def e2422407948170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407948170 : Closed e2422407948170 ∧ code e2422407948170 = 11218500970378 := by decide
theorem cert_e2422407948170 : check e2422407948170 [[],[]] .chain = true := by decide
def e2422407948206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e2422407948206 : Closed e2422407948206 ∧ code e2422407948206 = 11218500970414 := by decide
theorem cert_e2422407948206 : check e2422407948206 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422407948214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e2422407948214 : Closed e2422407948214 ∧ code e2422407948214 = 11218500970422 := by decide
theorem cert_e2422407948214 : check e2422407948214 [[],[]] .chain = true := by decide
def e2422407948218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 2))))) (.var 0))))))
theorem wire_e2422407948218 : Closed e2422407948218 ∧ code e2422407948218 = 11218500970426 := by decide
theorem cert_e2422407948218 : check e2422407948218 [[],[]] .chain = true := by decide
def e2422407948246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e2422407948246 : Closed e2422407948246 ∧ code e2422407948246 = 11218500970454 := by decide
theorem cert_e2422407948246 : checkPay e2422407948246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.under,.left,.right,.under],[.under,.under,.left,.right,.under,.under],[.under,.under,.right,.left],[.under,.under,.right],[.under,.under,.right,.under,.left,.right,.under],[.under,.under,.right,.under,.left,.right,.under,.under]] = true := by decide
def e2422407948686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407948686 : Closed e2422407948686 ∧ code e2422407948686 = 11218500970894 := by decide
theorem cert_e2422407948686 : check e2422407948686 [[],[]] .chain = true := by decide
def e2422407948742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407948742 : Closed e2422407948742 ∧ code e2422407948742 = 11218500970950 := by decide
theorem cert_e2422407948742 : check e2422407948742 [[],[]] .chain = true := by decide
def e2422407949342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407949342 : Closed e2422407949342 ∧ code e2422407949342 = 11218500971550 := by decide
theorem cert_e2422407949342 : check e2422407949342 [[],[]] .chain = true := by decide
def e2422407949538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407949538 : Closed e2422407949538 ∧ code e2422407949538 = 11218500971746 := by decide
theorem cert_e2422407949538 : check e2422407949538 [[],[]] .chain = true := by decide
def e2422407949550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407949550 : Closed e2422407949550 ∧ code e2422407949550 = 11218500971758 := by decide
theorem cert_e2422407949550 : check e2422407949550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407949558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407949558 : Closed e2422407949558 ∧ code e2422407949558 = 11218500971766 := by decide
theorem cert_e2422407949558 : check e2422407949558 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407949838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407949838 : Closed e2422407949838 ∧ code e2422407949838 = 11218500972046 := by decide
theorem cert_e2422407949838 : check e2422407949838 [[],[]] .chain = true := by decide
def e2422407949850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407949850 : Closed e2422407949850 ∧ code e2422407949850 = 11218500972058 := by decide
theorem cert_e2422407949850 : checkPay e2422407949850 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left]] 0 [] = true := by decide
def e2422407949922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407949922 : Closed e2422407949922 ∧ code e2422407949922 = 11218500972130 := by decide
theorem cert_e2422407949922 : check e2422407949922 [[],[]] .chain = true := by decide
def e2422407949934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407949934 : Closed e2422407949934 ∧ code e2422407949934 = 11218500972142 := by decide
theorem cert_e2422407949934 : check e2422407949934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407949942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407949942 : Closed e2422407949942 ∧ code e2422407949942 = 11218500972150 := by decide
theorem cert_e2422407949942 : check e2422407949942 [[],[]] .chain = true := by decide
def e2422407949946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407949946 : Closed e2422407949946 ∧ code e2422407949946 = 11218500972154 := by decide
theorem cert_e2422407949946 : check e2422407949946 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407950134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407950134 : Closed e2422407950134 ∧ code e2422407950134 = 11218500972342 := by decide
theorem cert_e2422407950134 : check e2422407950134 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407950138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407950138 : Closed e2422407950138 ∧ code e2422407950138 = 11218500972346 := by decide
theorem cert_e2422407950138 : check e2422407950138 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407957358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422407957358 : Closed e2422407957358 ∧ code e2422407957358 = 11218500979566 := by decide
theorem cert_e2422407957358 : check e2422407957358 [[],[]] .smaller = true := by decide
def e2422407957366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422407957366 : Closed e2422407957366 ∧ code e2422407957366 = 11218500979574 := by decide
theorem cert_e2422407957366 : check e2422407957366 [[],[]] .smaller = true := by decide
def e2422407957422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422407957422 : Closed e2422407957422 ∧ code e2422407957422 = 11218500979630 := by decide
theorem cert_e2422407957422 : check e2422407957422 [[],[]] .smaller = true := by decide
def e2422407957434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422407957434 : Closed e2422407957434 ∧ code e2422407957434 = 11218500979642 := by decide
theorem cert_e2422407957434 : check e2422407957434 [[],[]] .smaller = true := by decide
def e2422407957462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422407957462 : Closed e2422407957462 ∧ code e2422407957462 = 11218500979670 := by decide
theorem cert_e2422407957462 : check e2422407957462 [[],[]] .smaller = true := by decide
def e2422407957466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422407957466 : Closed e2422407957466 ∧ code e2422407957466 = 11218500979674 := by decide
theorem cert_e2422407957466 : check e2422407957466 [[],[]] .smaller = true := by decide
def e2422407957742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422407957742 : Closed e2422407957742 ∧ code e2422407957742 = 11218500979950 := by decide
theorem cert_e2422407957742 : check e2422407957742 [[],[]] .smaller = true := by decide
def e2422407957750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422407957750 : Closed e2422407957750 ∧ code e2422407957750 = 11218500979958 := by decide
theorem cert_e2422407957750 : check e2422407957750 [[],[]] .smaller = true := by decide
def e2422407958126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422407958126 : Closed e2422407958126 ∧ code e2422407958126 = 11218500980334 := by decide
theorem cert_e2422407958126 : check e2422407958126 [[],[]] .smaller = true := by decide
def e2422407958138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422407958138 : Closed e2422407958138 ∧ code e2422407958138 = 11218500980346 := by decide
theorem cert_e2422407958138 : check e2422407958138 [[],[]] .smaller = true := by decide
def e2422407958326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422407958326 : Closed e2422407958326 ∧ code e2422407958326 = 11218500980534 := by decide
theorem cert_e2422407958326 : check e2422407958326 [[],[]] .smaller = true := by decide
def e2422407958330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422407958330 : Closed e2422407958330 ∧ code e2422407958330 = 11218500980538 := by decide
theorem cert_e2422407958330 : check e2422407958330 [[],[]] .smaller = true := by decide
def e2422407998830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422407998830 : Closed e2422407998830 ∧ code e2422407998830 = 11218501021038 := by decide
theorem cert_e2422407998830 : check e2422407998830 [[],[]] .chain = true := by decide
def e2422407998838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422407998838 : Closed e2422407998838 ∧ code e2422407998838 = 11218501021046 := by decide
theorem cert_e2422407998838 : check e2422407998838 [[],[]] .chain = true := by decide
def e2422407998894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422407998894 : Closed e2422407998894 ∧ code e2422407998894 = 11218501021102 := by decide
theorem cert_e2422407998894 : check e2422407998894 [[],[]] .chain = true := by decide
def e2422407998906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422407998906 : Closed e2422407998906 ∧ code e2422407998906 = 11218501021114 := by decide
theorem cert_e2422407998906 : check e2422407998906 [[],[]] .chain = true := by decide
def e2422407998934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422407998934 : Closed e2422407998934 ∧ code e2422407998934 = 11218501021142 := by decide
theorem cert_e2422407998934 : check e2422407998934 [[],[]] .chain = true := by decide
def e2422407998938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422407998938 : Closed e2422407998938 ∧ code e2422407998938 = 11218501021146 := by decide
theorem cert_e2422407998938 : check e2422407998938 [[],[]] .chain = true := by decide
def e2422407999150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422407999150 : Closed e2422407999150 ∧ code e2422407999150 = 11218501021358 := by decide
theorem cert_e2422407999150 : check e2422407999150 [[],[]] .chain = true := by decide
def e2422407999162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422407999162 : Closed e2422407999162 ∧ code e2422407999162 = 11218501021370 := by decide
theorem cert_e2422407999162 : check e2422407999162 [[],[]] .chain = true := by decide
def e2422407999210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422407999210 : Closed e2422407999210 ∧ code e2422407999210 = 11218501021418 := by decide
theorem cert_e2422407999210 : check e2422407999210 [[],[]] .chain = true := by decide
def e2422407999318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422407999318 : Closed e2422407999318 ∧ code e2422407999318 = 11218501021526 := by decide
theorem cert_e2422407999318 : check e2422407999318 [[],[]] .chain = true := by decide
def e2422407999322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422407999322 : Closed e2422407999322 ∧ code e2422407999322 = 11218501021530 := by decide
theorem cert_e2422407999322 : check e2422407999322 [[],[]] .chain = true := by decide
def e2422407999338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422407999338 : Closed e2422407999338 ∧ code e2422407999338 = 11218501021546 := by decide
theorem cert_e2422407999338 : check e2422407999338 [[],[]] .chain = true := by decide
def e2422408000366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422408000366 : Closed e2422408000366 ∧ code e2422408000366 = 11218501022574 := by decide
theorem cert_e2422408000366 : check e2422408000366 [[],[]] .chain = true := by decide
def e2422408000374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422408000374 : Closed e2422408000374 ∧ code e2422408000374 = 11218501022582 := by decide
theorem cert_e2422408000374 : check e2422408000374 [[],[]] .chain = true := by decide
def e2422408000430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422408000430 : Closed e2422408000430 ∧ code e2422408000430 = 11218501022638 := by decide
theorem cert_e2422408000430 : check e2422408000430 [[],[]] .chain = true := by decide
def e2422408000442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422408000442 : Closed e2422408000442 ∧ code e2422408000442 = 11218501022650 := by decide
theorem cert_e2422408000442 : check e2422408000442 [[],[]] .chain = true := by decide
def e2422408000470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422408000470 : Closed e2422408000470 ∧ code e2422408000470 = 11218501022678 := by decide
theorem cert_e2422408000470 : check e2422408000470 [[],[]] .chain = true := by decide
def e2422408000474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422408000474 : Closed e2422408000474 ∧ code e2422408000474 = 11218501022682 := by decide
theorem cert_e2422408000474 : check e2422408000474 [[],[]] .chain = true := by decide
def e2422408000750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408000750 : Closed e2422408000750 ∧ code e2422408000750 = 11218501022958 := by decide
theorem cert_e2422408000750 : check e2422408000750 [[],[]] .chain = true := by decide
def e2422408000758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408000758 : Closed e2422408000758 ∧ code e2422408000758 = 11218501022966 := by decide
theorem cert_e2422408000758 : check e2422408000758 [[],[]] .chain = true := by decide
def e2422408001134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408001134 : Closed e2422408001134 ∧ code e2422408001134 = 11218501023342 := by decide
theorem cert_e2422408001134 : check e2422408001134 [[],[]] .chain = true := by decide
def e2422408001146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408001146 : Closed e2422408001146 ∧ code e2422408001146 = 11218501023354 := by decide
theorem cert_e2422408001146 : check e2422408001146 [[],[]] .chain = true := by decide
def e2422408001334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408001334 : Closed e2422408001334 ∧ code e2422408001334 = 11218501023542 := by decide
theorem cert_e2422408001334 : check e2422408001334 [[],[]] .chain = true := by decide
def e2422408001338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408001338 : Closed e2422408001338 ∧ code e2422408001338 = 11218501023546 := by decide
theorem cert_e2422408001338 : check e2422408001338 [[],[]] .chain = true := by decide
def e2422408001774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422408001774 : Closed e2422408001774 ∧ code e2422408001774 = 11218501023982 := by decide
theorem cert_e2422408001774 : check e2422408001774 [[],[]] .chain = true := by decide
def e2422408001782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422408001782 : Closed e2422408001782 ∧ code e2422408001782 = 11218501023990 := by decide
theorem cert_e2422408001782 : check e2422408001782 [[],[]] .chain = true := by decide
def e2422408001966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422408001966 : Closed e2422408001966 ∧ code e2422408001966 = 11218501024174 := by decide
theorem cert_e2422408001966 : check e2422408001966 [[],[]] .chain = true := by decide
def e2422408001978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422408001978 : Closed e2422408001978 ∧ code e2422408001978 = 11218501024186 := by decide
theorem cert_e2422408001978 : check e2422408001978 [[],[]] .chain = true := by decide
def e2422408002026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422408002026 : Closed e2422408002026 ∧ code e2422408002026 = 11218501024234 := by decide
theorem cert_e2422408002026 : check e2422408002026 [[],[]] .chain = true := by decide
def e2422408002158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408002158 : Closed e2422408002158 ∧ code e2422408002158 = 11218501024366 := by decide
theorem cert_e2422408002158 : check e2422408002158 [[],[]] .chain = true := by decide
def e2422408002170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408002170 : Closed e2422408002170 ∧ code e2422408002170 = 11218501024378 := by decide
theorem cert_e2422408002170 : check e2422408002170 [[],[]] .chain = true := by decide
def e2422408002334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422408002334 : Closed e2422408002334 ∧ code e2422408002334 = 11218501024542 := by decide
theorem cert_e2422408002334 : check e2422408002334 [[],[]] .chain = true := by decide
def e2422408002446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422408002446 : Closed e2422408002446 ∧ code e2422408002446 = 11218501024654 := by decide
theorem cert_e2422408002446 : check e2422408002446 [[],[]] .chain = true := by decide
def e2422408002458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422408002458 : Closed e2422408002458 ∧ code e2422408002458 = 11218501024666 := by decide
theorem cert_e2422408002458 : check e2422408002458 [[],[]] .chain = true := by decide
def e2422408002678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422408002678 : Closed e2422408002678 ∧ code e2422408002678 = 11218501024886 := by decide
theorem cert_e2422408002678 : check e2422408002678 [[],[]] .chain = true := by decide
def e2422408002774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422408002774 : Closed e2422408002774 ∧ code e2422408002774 = 11218501024982 := by decide
theorem cert_e2422408002774 : check e2422408002774 [[],[]] .chain = true := by decide
def e2422408002778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422408002778 : Closed e2422408002778 ∧ code e2422408002778 = 11218501024986 := by decide
theorem cert_e2422408002778 : check e2422408002778 [[],[]] .chain = true := by decide
def e2422408002794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422408002794 : Closed e2422408002794 ∧ code e2422408002794 = 11218501025002 := by decide
theorem cert_e2422408002794 : check e2422408002794 [[],[]] .chain = true := by decide
def e2422408002870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408002870 : Closed e2422408002870 ∧ code e2422408002870 = 11218501025078 := by decide
theorem cert_e2422408002870 : check e2422408002870 [[],[]] .chain = true := by decide
def e2422408002874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408002874 : Closed e2422408002874 ∧ code e2422408002874 = 11218501025082 := by decide
theorem cert_e2422408002874 : check e2422408002874 [[],[]] .chain = true := by decide
def e2422408002958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422408002958 : Closed e2422408002958 ∧ code e2422408002958 = 11218501025166 := by decide
theorem cert_e2422408002958 : check e2422408002958 [[],[]] .chain = true := by decide
def e2422408002970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422408002970 : Closed e2422408002970 ∧ code e2422408002970 = 11218501025178 := by decide
theorem cert_e2422408002970 : check e2422408002970 [[],[]] .chain = true := by decide
def e2422408004574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422408004574 : Closed e2422408004574 ∧ code e2422408004574 = 11218501026782 := by decide
theorem cert_e2422408004574 : check e2422408004574 [[],[]] .chain = true := by decide
def e2422408004590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422408004590 : Closed e2422408004590 ∧ code e2422408004590 = 11218501026798 := by decide
theorem cert_e2422408004590 : check e2422408004590 [[],[]] .chain = true := by decide
def e2422408006510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422408006510 : Closed e2422408006510 ∧ code e2422408006510 = 11218501028718 := by decide
theorem cert_e2422408006510 : check e2422408006510 [[],[]] .chain = true := by decide
def e2422408006518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422408006518 : Closed e2422408006518 ∧ code e2422408006518 = 11218501028726 := by decide
theorem cert_e2422408006518 : check e2422408006518 [[],[]] .chain = true := by decide
def e2422408006574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422408006574 : Closed e2422408006574 ∧ code e2422408006574 = 11218501028782 := by decide
theorem cert_e2422408006574 : check e2422408006574 [[],[]] .chain = true := by decide
def e2422408006586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422408006586 : Closed e2422408006586 ∧ code e2422408006586 = 11218501028794 := by decide
theorem cert_e2422408006586 : check e2422408006586 [[],[]] .chain = true := by decide
def e2422408006614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422408006614 : Closed e2422408006614 ∧ code e2422408006614 = 11218501028822 := by decide
theorem cert_e2422408006614 : check e2422408006614 [[],[]] .chain = true := by decide
def e2422408006618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422408006618 : Closed e2422408006618 ∧ code e2422408006618 = 11218501028826 := by decide
theorem cert_e2422408006618 : check e2422408006618 [[],[]] .chain = true := by decide
def e2422408006894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422408006894 : Closed e2422408006894 ∧ code e2422408006894 = 11218501029102 := by decide
theorem cert_e2422408006894 : check e2422408006894 [[],[]] .chain = true := by decide
def e2422408006902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422408006902 : Closed e2422408006902 ∧ code e2422408006902 = 11218501029110 := by decide
theorem cert_e2422408006902 : check e2422408006902 [[],[]] .chain = true := by decide
def e2422408007278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408007278 : Closed e2422408007278 ∧ code e2422408007278 = 11218501029486 := by decide
theorem cert_e2422408007278 : check e2422408007278 [[],[]] .chain = true := by decide
def e2422408007290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408007290 : Closed e2422408007290 ∧ code e2422408007290 = 11218501029498 := by decide
theorem cert_e2422408007290 : check e2422408007290 [[],[]] .chain = true := by decide
def e2422408007478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408007478 : Closed e2422408007478 ∧ code e2422408007478 = 11218501029686 := by decide
theorem cert_e2422408007478 : check e2422408007478 [[],[]] .chain = true := by decide
def e2422408007482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408007482 : Closed e2422408007482 ∧ code e2422408007482 = 11218501029690 := by decide
theorem cert_e2422408007482 : check e2422408007482 [[],[]] .chain = true := by decide
def e2422408012254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422408012254 : Closed e2422408012254 ∧ code e2422408012254 = 11218501034462 := by decide
theorem cert_e2422408012254 : check e2422408012254 [[],[]] .chain = true := by decide
def e2422408012278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422408012278 : Closed e2422408012278 ∧ code e2422408012278 = 11218501034486 := by decide
theorem cert_e2422408012278 : check e2422408012278 [[],[]] .chain = true := by decide
def e2422408013230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422408013230 : Closed e2422408013230 ∧ code e2422408013230 = 11218501035438 := by decide
theorem cert_e2422408013230 : check e2422408013230 [[],[]] .chain = true := by decide
def e2422408013242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422408013242 : Closed e2422408013242 ∧ code e2422408013242 = 11218501035450 := by decide
theorem cert_e2422408013242 : check e2422408013242 [[],[]] .chain = true := by decide
def e2422408013290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422408013290 : Closed e2422408013290 ∧ code e2422408013290 = 11218501035498 := by decide
theorem cert_e2422408013290 : check e2422408013290 [[],[]] .chain = true := by decide
def e2422408013422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408013422 : Closed e2422408013422 ∧ code e2422408013422 = 11218501035630 := by decide
theorem cert_e2422408013422 : check e2422408013422 [[],[]] .chain = true := by decide
def e2422408013434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408013434 : Closed e2422408013434 ∧ code e2422408013434 = 11218501035642 := by decide
theorem cert_e2422408013434 : check e2422408013434 [[],[]] .chain = true := by decide
def e2422408013598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422408013598 : Closed e2422408013598 ∧ code e2422408013598 = 11218501035806 := by decide
theorem cert_e2422408013598 : check e2422408013598 [[],[]] .chain = true := by decide
def e2422408013710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422408013710 : Closed e2422408013710 ∧ code e2422408013710 = 11218501035918 := by decide
theorem cert_e2422408013710 : check e2422408013710 [[],[]] .chain = true := by decide
def e2422408013722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408013722 : Closed e2422408013722 ∧ code e2422408013722 = 11218501035930 := by decide
theorem cert_e2422408013722 : check e2422408013722 [[],[]] .chain = true := by decide
def e2422408016110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422408016110 : Closed e2422408016110 ∧ code e2422408016110 = 11218501038318 := by decide
theorem cert_e2422408016110 : check e2422408016110 [[],[]] .chain = true := by decide
def e2422408016118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422408016118 : Closed e2422408016118 ∧ code e2422408016118 = 11218501038326 := by decide
theorem cert_e2422408016118 : check e2422408016118 [[],[]] .chain = true := by decide
def e2422408016598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422408016598 : Closed e2422408016598 ∧ code e2422408016598 = 11218501038806 := by decide
theorem cert_e2422408016598 : check e2422408016598 [[],[]] .chain = true := by decide
def e2422408016602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422408016602 : Closed e2422408016602 ∧ code e2422408016602 = 11218501038810 := by decide
theorem cert_e2422408016602 : check e2422408016602 [[],[]] .chain = true := by decide
def e2422408016618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422408016618 : Closed e2422408016618 ∧ code e2422408016618 = 11218501038826 := by decide
theorem cert_e2422408016618 : check e2422408016618 [[],[]] .chain = true := by decide
def e2422408016694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408016694 : Closed e2422408016694 ∧ code e2422408016694 = 11218501038902 := by decide
theorem cert_e2422408016694 : check e2422408016694 [[],[]] .chain = true := by decide
def e2422408016698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408016698 : Closed e2422408016698 ∧ code e2422408016698 = 11218501038906 := by decide
theorem cert_e2422408016698 : check e2422408016698 [[],[]] .chain = true := by decide
def e2422408016782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422408016782 : Closed e2422408016782 ∧ code e2422408016782 = 11218501038990 := by decide
theorem cert_e2422408016782 : check e2422408016782 [[],[]] .chain = true := by decide
def e2422408016794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408016794 : Closed e2422408016794 ∧ code e2422408016794 = 11218501039002 := by decide
theorem cert_e2422408016794 : check e2422408016794 [[],[]] .chain = true := by decide
def e2422408091358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2422408091358 : Closed e2422408091358 ∧ code e2422408091358 = 11218501113566 := by decide
theorem cert_e2422408091358 : check e2422408091358 [[],[]] .chain = true := by decide
def e2422408091382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2422408091382 : Closed e2422408091382 ∧ code e2422408091382 = 11218501113590 := by decide
theorem cert_e2422408091382 : check e2422408091382 [[],[]] .chain = true := by decide
def e2422408091486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2422408091486 : Closed e2422408091486 ∧ code e2422408091486 = 11218501113694 := by decide
theorem cert_e2422408091486 : check e2422408091486 [[],[]] .chain = true := by decide
def e2422408091514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2422408091514 : Closed e2422408091514 ∧ code e2422408091514 = 11218501113722 := by decide
theorem cert_e2422408091514 : check e2422408091514 [[],[]] .chain = true := by decide
def e2422408091606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2422408091606 : Closed e2422408091606 ∧ code e2422408091606 = 11218501113814 := by decide
theorem cert_e2422408091606 : check e2422408091606 [[],[]] .chain = true := by decide
def e2422408091610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2422408091610 : Closed e2422408091610 ∧ code e2422408091610 = 11218501113818 := by decide
theorem cert_e2422408091610 : check e2422408091610 [[],[]] .chain = true := by decide
def e2422408092126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422408092126 : Closed e2422408092126 ∧ code e2422408092126 = 11218501114334 := by decide
theorem cert_e2422408092126 : check e2422408092126 [[],[]] .chain = true := by decide
def e2422408092150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422408092150 : Closed e2422408092150 ∧ code e2422408092150 = 11218501114358 := by decide
theorem cert_e2422408092150 : check e2422408092150 [[],[]] .chain = true := by decide
def e2422408092894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422408092894 : Closed e2422408092894 ∧ code e2422408092894 = 11218501115102 := by decide
theorem cert_e2422408092894 : check e2422408092894 [[],[]] .chain = true := by decide
def e2422408092922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422408092922 : Closed e2422408092922 ∧ code e2422408092922 = 11218501115130 := by decide
theorem cert_e2422408092922 : check e2422408092922 [[],[]] .chain = true := by decide
def e2422408093246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2422408093246 : Closed e2422408093246 ∧ code e2422408093246 = 11218501115454 := by decide
theorem cert_e2422408093246 : check e2422408093246 [[],[]] .chain = true := by decide
def e2422408093470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2422408093470 : Closed e2422408093470 ∧ code e2422408093470 = 11218501115678 := by decide
theorem cert_e2422408093470 : check e2422408093470 [[],[]] .chain = true := by decide
def e2422408093494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408093494 : Closed e2422408093494 ∧ code e2422408093494 = 11218501115702 := by decide
theorem cert_e2422408093494 : check e2422408093494 [[],[]] .chain = true := by decide
def e2422408093498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408093498 : Closed e2422408093498 ∧ code e2422408093498 = 11218501115706 := by decide
theorem cert_e2422408093498 : check e2422408093498 [[],[]] .chain = true := by decide
def e2422408108270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422408108270 : Closed e2422408108270 ∧ code e2422408108270 = 11218501130478 := by decide
theorem cert_e2422408108270 : check e2422408108270 [[],[]] .chain = true := by decide
end Blc.Floor43
