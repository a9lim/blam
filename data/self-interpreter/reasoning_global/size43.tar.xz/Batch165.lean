import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262374729566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2262374729566 : Closed e2262374729566 ∧ code e2262374729566 = 11058467751774 := by decide
theorem cert_e2262374729566 : check e2262374729566 [[],[.under]] .three = true := by decide
def e2262374729582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e2262374729582 : Closed e2262374729582 ∧ code e2262374729582 = 11058467751790 := by decide
theorem cert_e2262374729582 : check e2262374729582 [[],[.under]] .smaller = true := by decide
def e2262374729590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e2262374729590 : Closed e2262374729590 ∧ code e2262374729590 = 11058467751798 := by decide
theorem cert_e2262374729590 : check e2262374729590 [[],[.under]] .smaller = true := by decide
def e2262374729594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2262374729594 : Closed e2262374729594 ∧ code e2262374729594 = 11058467751802 := by decide
theorem cert_e2262374729594 : check e2262374729594 [[],[.under]] .three = true := by decide
def e2262374729654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e2262374729654 : Closed e2262374729654 ∧ code e2262374729654 = 11058467751862 := by decide
theorem cert_e2262374729654 : check e2262374729654 [[],[.under]] .smaller = true := by decide
def e2262374729686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e2262374729686 : Closed e2262374729686 ∧ code e2262374729686 = 11058467751894 := by decide
theorem cert_e2262374729686 : check e2262374729686 [[],[.under]] .three = true := by decide
def e2262374729690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e2262374729690 : Closed e2262374729690 ∧ code e2262374729690 = 11058467751898 := by decide
theorem cert_e2262374729690 : check e2262374729690 [[],[.under]] .three = true := by decide
def e2262374731118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2262374731118 : Closed e2262374731118 ∧ code e2262374731118 = 11058467753326 := by decide
theorem cert_e2262374731118 : check e2262374731118 [[],[.under]] .smaller = true := by decide
def e2262374731126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2262374731126 : Closed e2262374731126 ∧ code e2262374731126 = 11058467753334 := by decide
theorem cert_e2262374731126 : check e2262374731126 [[],[.under]] .smaller = true := by decide
def e2262374731182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2262374731182 : Closed e2262374731182 ∧ code e2262374731182 = 11058467753390 := by decide
theorem cert_e2262374731182 : check e2262374731182 [[],[.under]] .smaller = true := by decide
def e2262374731194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2262374731194 : Closed e2262374731194 ∧ code e2262374731194 = 11058467753402 := by decide
theorem cert_e2262374731194 : check e2262374731194 [[],[.under]] .smaller = true := by decide
def e2262374731222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2262374731222 : Closed e2262374731222 ∧ code e2262374731222 = 11058467753430 := by decide
theorem cert_e2262374731222 : check e2262374731222 [[],[.under]] .smaller = true := by decide
def e2262374731226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2262374731226 : Closed e2262374731226 ∧ code e2262374731226 = 11058467753434 := by decide
theorem cert_e2262374731226 : check e2262374731226 [[],[.under]] .smaller = true := by decide
def e2262374731438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2262374731438 : Closed e2262374731438 ∧ code e2262374731438 = 11058467753646 := by decide
theorem cert_e2262374731438 : check e2262374731438 [[],[.under]] .smaller = true := by decide
def e2262374731450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2262374731450 : Closed e2262374731450 ∧ code e2262374731450 = 11058467753658 := by decide
theorem cert_e2262374731450 : check e2262374731450 [[],[.under]] .smaller = true := by decide
def e2262374731498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2262374731498 : Closed e2262374731498 ∧ code e2262374731498 = 11058467753706 := by decide
theorem cert_e2262374731498 : check e2262374731498 [[],[.under]] .smaller = true := by decide
def e2262374731606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2262374731606 : Closed e2262374731606 ∧ code e2262374731606 = 11058467753814 := by decide
theorem cert_e2262374731606 : check e2262374731606 [[],[.under]] .smaller = true := by decide
def e2262374731610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2262374731610 : Closed e2262374731610 ∧ code e2262374731610 = 11058467753818 := by decide
theorem cert_e2262374731610 : check e2262374731610 [[],[.under]] .smaller = true := by decide
def e2262374731626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2262374731626 : Closed e2262374731626 ∧ code e2262374731626 = 11058467753834 := by decide
theorem cert_e2262374731626 : check e2262374731626 [[],[.under]] .smaller = true := by decide
def e2262374732254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2262374732254 : Closed e2262374732254 ∧ code e2262374732254 = 11058467754462 := by decide
theorem cert_e2262374732254 : check e2262374732254 [[],[.under]] .three = true := by decide
def e2262374732278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2262374732278 : Closed e2262374732278 ∧ code e2262374732278 = 11058467754486 := by decide
theorem cert_e2262374732278 : check e2262374732278 [[],[.under]] .three = true := by decide
def e2262374732654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2262374732654 : Closed e2262374732654 ∧ code e2262374732654 = 11058467754862 := by decide
theorem cert_e2262374732654 : check e2262374732654 [[],[.under]] .smaller = true := by decide
def e2262374732662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2262374732662 : Closed e2262374732662 ∧ code e2262374732662 = 11058467754870 := by decide
theorem cert_e2262374732662 : check e2262374732662 [[],[.under]] .smaller = true := by decide
def e2262374732718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2262374732718 : Closed e2262374732718 ∧ code e2262374732718 = 11058467754926 := by decide
theorem cert_e2262374732718 : check e2262374732718 [[],[.under]] .smaller = true := by decide
def e2262374732730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2262374732730 : Closed e2262374732730 ∧ code e2262374732730 = 11058467754938 := by decide
theorem cert_e2262374732730 : check e2262374732730 [[],[.under]] .smaller = true := by decide
def e2262374732758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2262374732758 : Closed e2262374732758 ∧ code e2262374732758 = 11058467754966 := by decide
theorem cert_e2262374732758 : check e2262374732758 [[],[.under]] .smaller = true := by decide
def e2262374732762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2262374732762 : Closed e2262374732762 ∧ code e2262374732762 = 11058467754970 := by decide
theorem cert_e2262374732762 : check e2262374732762 [[],[.under]] .smaller = true := by decide
def e2262374733038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262374733038 : Closed e2262374733038 ∧ code e2262374733038 = 11058467755246 := by decide
theorem cert_e2262374733038 : check e2262374733038 [[],[.under]] .smaller = true := by decide
def e2262374733046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262374733046 : Closed e2262374733046 ∧ code e2262374733046 = 11058467755254 := by decide
theorem cert_e2262374733046 : check e2262374733046 [[],[.under]] .smaller = true := by decide
def e2262374733374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2262374733374 : Closed e2262374733374 ∧ code e2262374733374 = 11058467755582 := by decide
theorem cert_e2262374733374 : check e2262374733374 [[],[.under]] .three = true := by decide
def e2262374733422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374733422 : Closed e2262374733422 ∧ code e2262374733422 = 11058467755630 := by decide
theorem cert_e2262374733422 : check e2262374733422 [[],[.under]] .smaller = true := by decide
def e2262374733434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374733434 : Closed e2262374733434 ∧ code e2262374733434 = 11058467755642 := by decide
theorem cert_e2262374733434 : check e2262374733434 [[],[.under]] .smaller = true := by decide
def e2262374733622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374733622 : Closed e2262374733622 ∧ code e2262374733622 = 11058467755830 := by decide
theorem cert_e2262374733622 : check e2262374733622 [[],[.under]] .smaller = true := by decide
def e2262374733626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374733626 : Closed e2262374733626 ∧ code e2262374733626 = 11058467755834 := by decide
theorem cert_e2262374733626 : check e2262374733626 [[],[.under]] .smaller = true := by decide
def e2262374733710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2262374733710 : Closed e2262374733710 ∧ code e2262374733710 = 11058467755918 := by decide
theorem cert_e2262374733710 : check e2262374733710 [[],[.under]] .three = true := by decide
def e2262374734046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2262374734046 : Closed e2262374734046 ∧ code e2262374734046 = 11058467756254 := by decide
theorem cert_e2262374734046 : check e2262374734046 [[],[.under]] .three = true := by decide
def e2262374734062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2262374734062 : Closed e2262374734062 ∧ code e2262374734062 = 11058467756270 := by decide
theorem cert_e2262374734062 : check e2262374734062 [[],[.under]] .smaller = true := by decide
def e2262374734070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2262374734070 : Closed e2262374734070 ∧ code e2262374734070 = 11058467756278 := by decide
theorem cert_e2262374734070 : check e2262374734070 [[],[.under]] .smaller = true := by decide
def e2262374734074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2262374734074 : Closed e2262374734074 ∧ code e2262374734074 = 11058467756282 := by decide
theorem cert_e2262374734074 : check e2262374734074 [[],[.under]] .three = true := by decide
def e2262374734254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2262374734254 : Closed e2262374734254 ∧ code e2262374734254 = 11058467756462 := by decide
theorem cert_e2262374734254 : check e2262374734254 [[],[.under]] .smaller = true := by decide
def e2262374734266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2262374734266 : Closed e2262374734266 ∧ code e2262374734266 = 11058467756474 := by decide
theorem cert_e2262374734266 : check e2262374734266 [[],[.under]] .smaller = true := by decide
def e2262374734314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2262374734314 : Closed e2262374734314 ∧ code e2262374734314 = 11058467756522 := by decide
theorem cert_e2262374734314 : check e2262374734314 [[],[.under]] .smaller = true := by decide
def e2262374734398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2262374734398 : Closed e2262374734398 ∧ code e2262374734398 = 11058467756606 := by decide
theorem cert_e2262374734398 : check e2262374734398 [[],[.under]] .three = true := by decide
def e2262374734446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374734446 : Closed e2262374734446 ∧ code e2262374734446 = 11058467756654 := by decide
theorem cert_e2262374734446 : check e2262374734446 [[],[.under]] .smaller = true := by decide
def e2262374734458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374734458 : Closed e2262374734458 ∧ code e2262374734458 = 11058467756666 := by decide
theorem cert_e2262374734458 : check e2262374734458 [[],[.under]] .smaller = true := by decide
def e2262374734622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2262374734622 : Closed e2262374734622 ∧ code e2262374734622 = 11058467756830 := by decide
theorem cert_e2262374734622 : check e2262374734622 [[],[.under]] .smaller = true := by decide
def e2262374734734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2262374734734 : Closed e2262374734734 ∧ code e2262374734734 = 11058467756942 := by decide
theorem cert_e2262374734734 : check e2262374734734 [[],[.under]] .smaller = true := by decide
def e2262374734746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374734746 : Closed e2262374734746 ∧ code e2262374734746 = 11058467756954 := by decide
theorem cert_e2262374734746 : check e2262374734746 [[],[.under]] .smaller = true := by decide
def e2262374734790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2262374734790 : Closed e2262374734790 ∧ code e2262374734790 = 11058467756998 := by decide
theorem cert_e2262374734790 : check e2262374734790 [[],[.under]] .three = true := by decide
def e2262374734814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3)))))))
theorem wire_e2262374734814 : Closed e2262374734814 ∧ code e2262374734814 = 11058467757022 := by decide
theorem cert_e2262374734814 : check e2262374734814 [[],[.under]] .three = true := by decide
def e2262374734966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2262374734966 : Closed e2262374734966 ∧ code e2262374734966 = 11058467757174 := by decide
theorem cert_e2262374734966 : check e2262374734966 [[],[.under]] .smaller = true := by decide
def e2262374735062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2262374735062 : Closed e2262374735062 ∧ code e2262374735062 = 11058467757270 := by decide
theorem cert_e2262374735062 : check e2262374735062 [[],[.under]] .smaller = true := by decide
def e2262374735066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2262374735066 : Closed e2262374735066 ∧ code e2262374735066 = 11058467757274 := by decide
theorem cert_e2262374735066 : check e2262374735066 [[],[.under]] .smaller = true := by decide
def e2262374735082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2262374735082 : Closed e2262374735082 ∧ code e2262374735082 = 11058467757290 := by decide
theorem cert_e2262374735082 : check e2262374735082 [[],[.under]] .smaller = true := by decide
def e2262374735158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374735158 : Closed e2262374735158 ∧ code e2262374735158 = 11058467757366 := by decide
theorem cert_e2262374735158 : check e2262374735158 [[],[.under]] .smaller = true := by decide
def e2262374735162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374735162 : Closed e2262374735162 ∧ code e2262374735162 = 11058467757370 := by decide
theorem cert_e2262374735162 : check e2262374735162 [[],[.under]] .smaller = true := by decide
def e2262374735246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2262374735246 : Closed e2262374735246 ∧ code e2262374735246 = 11058467757454 := by decide
theorem cert_e2262374735246 : check e2262374735246 [[],[.under]] .smaller = true := by decide
def e2262374735258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374735258 : Closed e2262374735258 ∧ code e2262374735258 = 11058467757466 := by decide
theorem cert_e2262374735258 : check e2262374735258 [[],[.under]] .smaller = true := by decide
def e2262374735326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3)))))))
theorem wire_e2262374735326 : Closed e2262374735326 ∧ code e2262374735326 = 11058467757534 := by decide
theorem cert_e2262374735326 : check e2262374735326 [[],[.under]] .three = true := by decide
def e2262374735342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2)))))))
theorem wire_e2262374735342 : Closed e2262374735342 ∧ code e2262374735342 = 11058467757550 := by decide
theorem cert_e2262374735342 : check e2262374735342 [[],[.under]] .three = true := by decide
def e2262374735414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2262374735414 : Closed e2262374735414 ∧ code e2262374735414 = 11058467757622 := by decide
theorem cert_e2262374735414 : check e2262374735414 [[],[.under]] .three = true := by decide
def e2262374735418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2262374735418 : Closed e2262374735418 ∧ code e2262374735418 = 11058467757626 := by decide
theorem cert_e2262374735418 : check e2262374735418 [[],[.under]] .three = true := by decide
def e2262374735502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2262374735502 : Closed e2262374735502 ∧ code e2262374735502 = 11058467757710 := by decide
theorem cert_e2262374735502 : check e2262374735502 [[],[.under]] .three = true := by decide
def e2262374735558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2262374735558 : Closed e2262374735558 ∧ code e2262374735558 = 11058467757766 := by decide
theorem cert_e2262374735558 : check e2262374735558 [[],[.under]] .three = true := by decide
def e2262374735582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3)))))))
theorem wire_e2262374735582 : Closed e2262374735582 ∧ code e2262374735582 = 11058467757790 := by decide
theorem cert_e2262374735582 : check e2262374735582 [[],[.under]] .three = true := by decide
def e2262374735598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2)))))))
theorem wire_e2262374735598 : Closed e2262374735598 ∧ code e2262374735598 = 11058467757806 := by decide
theorem cert_e2262374735598 : check e2262374735598 [[],[.under]] .three = true := by decide
def e2262374735606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1)))))))
theorem wire_e2262374735606 : Closed e2262374735606 ∧ code e2262374735606 = 11058467757814 := by decide
theorem cert_e2262374735606 : check e2262374735606 [[],[.under]] .three = true := by decide
def e2262374736734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2262374736734 : Closed e2262374736734 ∧ code e2262374736734 = 11058467758942 := by decide
theorem cert_e2262374736734 : check e2262374736734 [[],[.under]] .three = true := by decide
def e2262374736750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2262374736750 : Closed e2262374736750 ∧ code e2262374736750 = 11058467758958 := by decide
theorem cert_e2262374736750 : check e2262374736750 [[],[.under]] .smaller = true := by decide
def e2262374736758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2262374736758 : Closed e2262374736758 ∧ code e2262374736758 = 11058467758966 := by decide
theorem cert_e2262374736758 : check e2262374736758 [[],[.under]] .smaller = true := by decide
def e2262374736762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2262374736762 : Closed e2262374736762 ∧ code e2262374736762 = 11058467758970 := by decide
theorem cert_e2262374736762 : check e2262374736762 [[],[.under]] .three = true := by decide
def e2262374736814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2262374736814 : Closed e2262374736814 ∧ code e2262374736814 = 11058467759022 := by decide
theorem cert_e2262374736814 : check e2262374736814 [[],[.under]] .smaller = true := by decide
def e2262374736826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2262374736826 : Closed e2262374736826 ∧ code e2262374736826 = 11058467759034 := by decide
theorem cert_e2262374736826 : check e2262374736826 [[],[.under]] .smaller = true := by decide
def e2262374736854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2262374736854 : Closed e2262374736854 ∧ code e2262374736854 = 11058467759062 := by decide
theorem cert_e2262374736854 : check e2262374736854 [[],[.under]] .smaller = true := by decide
def e2262374736858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2262374736858 : Closed e2262374736858 ∧ code e2262374736858 = 11058467759066 := by decide
theorem cert_e2262374736858 : check e2262374736858 [[],[.under]] .smaller = true := by decide
def e2262374736874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e2262374736874 : Closed e2262374736874 ∧ code e2262374736874 = 11058467759082 := by decide
theorem cert_e2262374736874 : check e2262374736874 [[],[.under]] .three = true := by decide
def e2262374737582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2262374737582 : Closed e2262374737582 ∧ code e2262374737582 = 11058467759790 := by decide
theorem cert_e2262374737582 : check e2262374737582 [[],[.under]] .smaller = true := by decide
def e2262374737594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2262374737594 : Closed e2262374737594 ∧ code e2262374737594 = 11058467759802 := by decide
theorem cert_e2262374737594 : check e2262374737594 [[],[.under]] .smaller = true := by decide
def e2262374737642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2262374737642 : Closed e2262374737642 ∧ code e2262374737642 = 11058467759850 := by decide
theorem cert_e2262374737642 : check e2262374737642 [[],[.under]] .smaller = true := by decide
def e2262374737834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2262374737834 : Closed e2262374737834 ∧ code e2262374737834 = 11058467760042 := by decide
theorem cert_e2262374737834 : check e2262374737834 [[],[.under]] .smaller = true := by decide
def e2262374738142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2262374738142 : Closed e2262374738142 ∧ code e2262374738142 = 11058467760350 := by decide
theorem cert_e2262374738142 : check e2262374738142 [[],[.under]] .three = true := by decide
def e2262374738158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2262374738158 : Closed e2262374738158 ∧ code e2262374738158 = 11058467760366 := by decide
theorem cert_e2262374738158 : check e2262374738158 [[],[.under]] .smaller = true := by decide
def e2262374738166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2262374738166 : Closed e2262374738166 ∧ code e2262374738166 = 11058467760374 := by decide
theorem cert_e2262374738166 : check e2262374738166 [[],[.under]] .smaller = true := by decide
def e2262374738170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2262374738170 : Closed e2262374738170 ∧ code e2262374738170 = 11058467760378 := by decide
theorem cert_e2262374738170 : check e2262374738170 [[],[.under]] .three = true := by decide
def e2262374738350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2262374738350 : Closed e2262374738350 ∧ code e2262374738350 = 11058467760558 := by decide
theorem cert_e2262374738350 : check e2262374738350 [[],[.under]] .smaller = true := by decide
def e2262374738362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2262374738362 : Closed e2262374738362 ∧ code e2262374738362 = 11058467760570 := by decide
theorem cert_e2262374738362 : check e2262374738362 [[],[.under]] .smaller = true := by decide
def e2262374738410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2262374738410 : Closed e2262374738410 ∧ code e2262374738410 = 11058467760618 := by decide
theorem cert_e2262374738410 : check e2262374738410 [[],[.under]] .smaller = true := by decide
def e2262374738494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2262374738494 : Closed e2262374738494 ∧ code e2262374738494 = 11058467760702 := by decide
theorem cert_e2262374738494 : check e2262374738494 [[],[.under]] .three = true := by decide
def e2262374738542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374738542 : Closed e2262374738542 ∧ code e2262374738542 = 11058467760750 := by decide
theorem cert_e2262374738542 : check e2262374738542 [[],[.under]] .smaller = true := by decide
def e2262374738554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374738554 : Closed e2262374738554 ∧ code e2262374738554 = 11058467760762 := by decide
theorem cert_e2262374738554 : check e2262374738554 [[],[.under]] .smaller = true := by decide
def e2262374738718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2262374738718 : Closed e2262374738718 ∧ code e2262374738718 = 11058467760926 := by decide
theorem cert_e2262374738718 : check e2262374738718 [[],[.under]] .smaller = true := by decide
def e2262374738830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2262374738830 : Closed e2262374738830 ∧ code e2262374738830 = 11058467761038 := by decide
theorem cert_e2262374738830 : check e2262374738830 [[],[.under]] .smaller = true := by decide
def e2262374738842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374738842 : Closed e2262374738842 ∧ code e2262374738842 = 11058467761050 := by decide
theorem cert_e2262374738842 : check e2262374738842 [[],[.under]] .smaller = true := by decide
def e2262374738886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2262374738886 : Closed e2262374738886 ∧ code e2262374738886 = 11058467761094 := by decide
theorem cert_e2262374738886 : check e2262374738886 [[],[.under]] .three = true := by decide
def e2262374738910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e2262374738910 : Closed e2262374738910 ∧ code e2262374738910 = 11058467761118 := by decide
theorem cert_e2262374738910 : check e2262374738910 [[],[.under]] .three = true := by decide
def e2262374739054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2262374739054 : Closed e2262374739054 ∧ code e2262374739054 = 11058467761262 := by decide
theorem cert_e2262374739054 : check e2262374739054 [[],[.under]] .smaller = true := by decide
def e2262374739066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2262374739066 : Closed e2262374739066 ∧ code e2262374739066 = 11058467761274 := by decide
theorem cert_e2262374739066 : check e2262374739066 [[],[.under]] .smaller = true := by decide
def e2262374739230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2262374739230 : Closed e2262374739230 ∧ code e2262374739230 = 11058467761438 := by decide
theorem cert_e2262374739230 : check e2262374739230 [[],[.under]] .smaller = true := by decide
def e2262374739398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2262374739398 : Closed e2262374739398 ∧ code e2262374739398 = 11058467761606 := by decide
theorem cert_e2262374739398 : check e2262374739398 [[],[.under]] .smaller = true := by decide
def e2262374739422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e2262374739422 : Closed e2262374739422 ∧ code e2262374739422 = 11058467761630 := by decide
theorem cert_e2262374739422 : check e2262374739422 [[],[.under]] .three = true := by decide
def e2262374739438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e2262374739438 : Closed e2262374739438 ∧ code e2262374739438 = 11058467761646 := by decide
theorem cert_e2262374739438 : check e2262374739438 [[],[.under]] .three = true := by decide
def e2262374739510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2262374739510 : Closed e2262374739510 ∧ code e2262374739510 = 11058467761718 := by decide
theorem cert_e2262374739510 : check e2262374739510 [[],[.under]] .smaller = true := by decide
def e2262374739514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2262374739514 : Closed e2262374739514 ∧ code e2262374739514 = 11058467761722 := by decide
theorem cert_e2262374739514 : check e2262374739514 [[],[.under]] .smaller = true := by decide
def e2262374739562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2262374739562 : Closed e2262374739562 ∧ code e2262374739562 = 11058467761770 := by decide
theorem cert_e2262374739562 : check e2262374739562 [[],[.under]] .smaller = true := by decide
def e2262374739598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2262374739598 : Closed e2262374739598 ∧ code e2262374739598 = 11058467761806 := by decide
theorem cert_e2262374739598 : check e2262374739598 [[],[.under]] .smaller = true := by decide
def e2262374739610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374739610 : Closed e2262374739610 ∧ code e2262374739610 = 11058467761818 := by decide
theorem cert_e2262374739610 : check e2262374739610 [[],[.under]] .smaller = true := by decide
def e2262374739654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2262374739654 : Closed e2262374739654 ∧ code e2262374739654 = 11058467761862 := by decide
theorem cert_e2262374739654 : check e2262374739654 [[],[.under]] .smaller = true := by decide
def e2262374739678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e2262374739678 : Closed e2262374739678 ∧ code e2262374739678 = 11058467761886 := by decide
theorem cert_e2262374739678 : check e2262374739678 [[],[.under]] .three = true := by decide
def e2262374739702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e2262374739702 : Closed e2262374739702 ∧ code e2262374739702 = 11058467761910 := by decide
theorem cert_e2262374739702 : check e2262374739702 [[],[.under]] .three = true := by decide
def e2262374739738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2262374739738 : Closed e2262374739738 ∧ code e2262374739738 = 11058467761946 := by decide
theorem cert_e2262374739738 : check e2262374739738 [[],[.under]] .three = true := by decide
def e2262374739782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2262374739782 : Closed e2262374739782 ∧ code e2262374739782 = 11058467761990 := by decide
theorem cert_e2262374739782 : check e2262374739782 [[],[.under]] .three = true := by decide
def e2262374739806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e2262374739806 : Closed e2262374739806 ∧ code e2262374739806 = 11058467762014 := by decide
theorem cert_e2262374739806 : check e2262374739806 [[],[.under]] .three = true := by decide
def e2262374739822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e2262374739822 : Closed e2262374739822 ∧ code e2262374739822 = 11058467762030 := by decide
theorem cert_e2262374739822 : check e2262374739822 [[],[.under]] .three = true := by decide
def e2262374739830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e2262374739830 : Closed e2262374739830 ∧ code e2262374739830 = 11058467762038 := by decide
theorem cert_e2262374739830 : check e2262374739830 [[],[.under]] .three = true := by decide
def e2262374739834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e2262374739834 : Closed e2262374739834 ∧ code e2262374739834 = 11058467762042 := by decide
theorem cert_e2262374739834 : check e2262374739834 [[],[.under]] .three = true := by decide
def e2262374740406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e2262374740406 : Closed e2262374740406 ∧ code e2262374740406 = 11058467762614 := by decide
theorem cert_e2262374740406 : check e2262374740406 [[],[.under]] .smaller = true := by decide
def e2262374740438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2262374740438 : Closed e2262374740438 ∧ code e2262374740438 = 11058467762646 := by decide
theorem cert_e2262374740438 : check e2262374740438 [[],[.under]] .smaller = true := by decide
def e2262374740442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2262374740442 : Closed e2262374740442 ∧ code e2262374740442 = 11058467762650 := by decide
theorem cert_e2262374740442 : check e2262374740442 [[],[.under]] .smaller = true := by decide
def e2262374740822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2262374740822 : Closed e2262374740822 ∧ code e2262374740822 = 11058467763030 := by decide
theorem cert_e2262374740822 : check e2262374740822 [[],[.under]] .smaller = true := by decide
def e2262374740826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2262374740826 : Closed e2262374740826 ∧ code e2262374740826 = 11058467763034 := by decide
theorem cert_e2262374740826 : check e2262374740826 [[],[.under]] .smaller = true := by decide
def e2262374740842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2262374740842 : Closed e2262374740842 ∧ code e2262374740842 = 11058467763050 := by decide
theorem cert_e2262374740842 : check e2262374740842 [[],[.under]] .smaller = true := by decide
def e2262374740906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2262374740906 : Closed e2262374740906 ∧ code e2262374740906 = 11058467763114 := by decide
theorem cert_e2262374740906 : check e2262374740906 [[],[.under]] .smaller = true := by decide
def e2262374741110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2262374741110 : Closed e2262374741110 ∧ code e2262374741110 = 11058467763318 := by decide
theorem cert_e2262374741110 : check e2262374741110 [[],[.under]] .smaller = true := by decide
def e2262374741206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2262374741206 : Closed e2262374741206 ∧ code e2262374741206 = 11058467763414 := by decide
theorem cert_e2262374741206 : check e2262374741206 [[],[.under]] .smaller = true := by decide
def e2262374741210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2262374741210 : Closed e2262374741210 ∧ code e2262374741210 = 11058467763418 := by decide
theorem cert_e2262374741210 : check e2262374741210 [[],[.under]] .smaller = true := by decide
def e2262374741226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2262374741226 : Closed e2262374741226 ∧ code e2262374741226 = 11058467763434 := by decide
theorem cert_e2262374741226 : check e2262374741226 [[],[.under]] .smaller = true := by decide
def e2262374741302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374741302 : Closed e2262374741302 ∧ code e2262374741302 = 11058467763510 := by decide
theorem cert_e2262374741302 : check e2262374741302 [[],[.under]] .smaller = true := by decide
def e2262374741306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374741306 : Closed e2262374741306 ∧ code e2262374741306 = 11058467763514 := by decide
theorem cert_e2262374741306 : check e2262374741306 [[],[.under]] .smaller = true := by decide
def e2262374741390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2262374741390 : Closed e2262374741390 ∧ code e2262374741390 = 11058467763598 := by decide
theorem cert_e2262374741390 : check e2262374741390 [[],[.under]] .smaller = true := by decide
def e2262374741402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374741402 : Closed e2262374741402 ∧ code e2262374741402 = 11058467763610 := by decide
theorem cert_e2262374741402 : check e2262374741402 [[],[.under]] .smaller = true := by decide
def e2262374741470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2262374741470 : Closed e2262374741470 ∧ code e2262374741470 = 11058467763678 := by decide
theorem cert_e2262374741470 : check e2262374741470 [[],[.under]] .three = true := by decide
def e2262374741486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2262374741486 : Closed e2262374741486 ∧ code e2262374741486 = 11058467763694 := by decide
theorem cert_e2262374741486 : check e2262374741486 [[],[.under]] .three = true := by decide
def e2262374741558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2262374741558 : Closed e2262374741558 ∧ code e2262374741558 = 11058467763766 := by decide
theorem cert_e2262374741558 : check e2262374741558 [[],[.under]] .smaller = true := by decide
def e2262374741562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2262374741562 : Closed e2262374741562 ∧ code e2262374741562 = 11058467763770 := by decide
theorem cert_e2262374741562 : check e2262374741562 [[],[.under]] .smaller = true := by decide
def e2262374741610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2262374741610 : Closed e2262374741610 ∧ code e2262374741610 = 11058467763818 := by decide
theorem cert_e2262374741610 : check e2262374741610 [[],[.under]] .smaller = true := by decide
def e2262374741646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2262374741646 : Closed e2262374741646 ∧ code e2262374741646 = 11058467763854 := by decide
theorem cert_e2262374741646 : check e2262374741646 [[],[.under]] .smaller = true := by decide
def e2262374741658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374741658 : Closed e2262374741658 ∧ code e2262374741658 = 11058467763866 := by decide
theorem cert_e2262374741658 : check e2262374741658 [[],[.under]] .smaller = true := by decide
def e2262374741702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2262374741702 : Closed e2262374741702 ∧ code e2262374741702 = 11058467763910 := by decide
theorem cert_e2262374741702 : check e2262374741702 [[],[.under]] .smaller = true := by decide
def e2262374741726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2262374741726 : Closed e2262374741726 ∧ code e2262374741726 = 11058467763934 := by decide
theorem cert_e2262374741726 : check e2262374741726 [[],[.under]] .three = true := by decide
def e2262374741750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2262374741750 : Closed e2262374741750 ∧ code e2262374741750 = 11058467763958 := by decide
theorem cert_e2262374741750 : check e2262374741750 [[],[.under]] .three = true := by decide
def e2262374741854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2262374741854 : Closed e2262374741854 ∧ code e2262374741854 = 11058467764062 := by decide
theorem cert_e2262374741854 : check e2262374741854 [[],[.under]] .three = true := by decide
def e2262374741882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2262374741882 : Closed e2262374741882 ∧ code e2262374741882 = 11058467764090 := by decide
theorem cert_e2262374741882 : check e2262374741882 [[],[.under]] .three = true := by decide
def e2262374741934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2262374741934 : Closed e2262374741934 ∧ code e2262374741934 = 11058467764142 := by decide
theorem cert_e2262374741934 : check e2262374741934 [[],[.under]] .three = true := by decide
def e2262374741942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2262374741942 : Closed e2262374741942 ∧ code e2262374741942 = 11058467764150 := by decide
theorem cert_e2262374741942 : check e2262374741942 [[],[.under]] .three = true := by decide
def e2262374741946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2262374741946 : Closed e2262374741946 ∧ code e2262374741946 = 11058467764154 := by decide
theorem cert_e2262374741946 : check e2262374741946 [[],[.under]] .three = true := by decide
def e2262374742230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2262374742230 : Closed e2262374742230 ∧ code e2262374742230 = 11058467764438 := by decide
theorem cert_e2262374742230 : check e2262374742230 [[],[.under]] .three = true := by decide
def e2262374742234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2262374742234 : Closed e2262374742234 ∧ code e2262374742234 = 11058467764442 := by decide
theorem cert_e2262374742234 : check e2262374742234 [[],[.under]] .three = true := by decide
def e2262374742250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2262374742250 : Closed e2262374742250 ∧ code e2262374742250 = 11058467764458 := by decide
theorem cert_e2262374742250 : check e2262374742250 [[],[.under]] .three = true := by decide
def e2262374742582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2262374742582 : Closed e2262374742582 ∧ code e2262374742582 = 11058467764790 := by decide
theorem cert_e2262374742582 : check e2262374742582 [[],[.under]] .three = true := by decide
def e2262374742586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2262374742586 : Closed e2262374742586 ∧ code e2262374742586 = 11058467764794 := by decide
theorem cert_e2262374742586 : check e2262374742586 [[],[.under]] .three = true := by decide
def e2262374742670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2262374742670 : Closed e2262374742670 ∧ code e2262374742670 = 11058467764878 := by decide
theorem cert_e2262374742670 : check e2262374742670 [[],[.under]] .three = true := by decide
def e2262374742726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2262374742726 : Closed e2262374742726 ∧ code e2262374742726 = 11058467764934 := by decide
theorem cert_e2262374742726 : check e2262374742726 [[],[.under]] .three = true := by decide
def e2262374742750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2262374742750 : Closed e2262374742750 ∧ code e2262374742750 = 11058467764958 := by decide
theorem cert_e2262374742750 : check e2262374742750 [[],[.under]] .three = true := by decide
def e2262374742766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2262374742766 : Closed e2262374742766 ∧ code e2262374742766 = 11058467764974 := by decide
theorem cert_e2262374742766 : check e2262374742766 [[],[.under]] .three = true := by decide
def e2262374742774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2262374742774 : Closed e2262374742774 ∧ code e2262374742774 = 11058467764982 := by decide
theorem cert_e2262374742774 : check e2262374742774 [[],[.under]] .three = true := by decide
def e2262374742810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2262374742810 : Closed e2262374742810 ∧ code e2262374742810 = 11058467765018 := by decide
theorem cert_e2262374742810 : check e2262374742810 [[],[.under]] .three = true := by decide
def e2262374742854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2262374742854 : Closed e2262374742854 ∧ code e2262374742854 = 11058467765062 := by decide
theorem cert_e2262374742854 : check e2262374742854 [[],[.under]] .three = true := by decide
def e2262374742878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2262374742878 : Closed e2262374742878 ∧ code e2262374742878 = 11058467765086 := by decide
theorem cert_e2262374742878 : check e2262374742878 [[],[.under]] .three = true := by decide
def e2262374742894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2262374742894 : Closed e2262374742894 ∧ code e2262374742894 = 11058467765102 := by decide
theorem cert_e2262374742894 : check e2262374742894 [[],[.under]] .three = true := by decide
def e2262374742902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2262374742902 : Closed e2262374742902 ∧ code e2262374742902 = 11058467765110 := by decide
theorem cert_e2262374742902 : check e2262374742902 [[],[.under]] .three = true := by decide
end Blc.Floor43
