import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e834099260846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e834099260846 : Closed e834099260846 ∧ code e834099260846 = 9630192283054 := by decide
theorem cert_e834099260846 : check e834099260846 [] .sourceHead = true := by decide
def e834099260858 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e834099260858 : Closed e834099260858 ∧ code e834099260858 = 9630192283066 := by decide
theorem cert_e834099260858 : check e834099260858 [] .sourceHead = true := by decide
def e834099260886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e834099260886 : Closed e834099260886 ∧ code e834099260886 = 9630192283094 := by decide
theorem cert_e834099260886 : check e834099260886 [] .sourceHead = true := by decide
def e834099260890 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e834099260890 : Closed e834099260890 ∧ code e834099260890 = 9630192283098 := by decide
theorem cert_e834099260890 : check e834099260890 [] .sourceHead = true := by decide
def e834099261102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e834099261102 : Closed e834099261102 ∧ code e834099261102 = 9630192283310 := by decide
theorem cert_e834099261102 : check e834099261102 [] .sourceHead = true := by decide
def e834099261114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e834099261114 : Closed e834099261114 ∧ code e834099261114 = 9630192283322 := by decide
theorem cert_e834099261114 : check e834099261114 [] .sourceHead = true := by decide
def e834099261162 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e834099261162 : Closed e834099261162 ∧ code e834099261162 = 9630192283370 := by decide
theorem cert_e834099261162 : check e834099261162 [] .sourceHead = true := by decide
def e834099261270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e834099261270 : Closed e834099261270 ∧ code e834099261270 = 9630192283478 := by decide
theorem cert_e834099261270 : check e834099261270 [] .sourceHead = true := by decide
def e834099261274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e834099261274 : Closed e834099261274 ∧ code e834099261274 = 9630192283482 := by decide
theorem cert_e834099261274 : check e834099261274 [] .sourceHead = true := by decide
def e834099261290 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e834099261290 : Closed e834099261290 ∧ code e834099261290 = 9630192283498 := by decide
theorem cert_e834099261290 : check e834099261290 [] .sourceHead = true := by decide
def e834099262318 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e834099262318 : Closed e834099262318 ∧ code e834099262318 = 9630192284526 := by decide
theorem cert_e834099262318 : check e834099262318 [] .sourceHead = true := by decide
def e834099262326 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e834099262326 : Closed e834099262326 ∧ code e834099262326 = 9630192284534 := by decide
theorem cert_e834099262326 : check e834099262326 [] .sourceHead = true := by decide
def e834099262382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e834099262382 : Closed e834099262382 ∧ code e834099262382 = 9630192284590 := by decide
theorem cert_e834099262382 : check e834099262382 [] .sourceHead = true := by decide
def e834099262394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e834099262394 : Closed e834099262394 ∧ code e834099262394 = 9630192284602 := by decide
theorem cert_e834099262394 : check e834099262394 [] .sourceHead = true := by decide
def e834099262422 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e834099262422 : Closed e834099262422 ∧ code e834099262422 = 9630192284630 := by decide
theorem cert_e834099262422 : check e834099262422 [] .sourceHead = true := by decide
def e834099262426 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e834099262426 : Closed e834099262426 ∧ code e834099262426 = 9630192284634 := by decide
theorem cert_e834099262426 : check e834099262426 [] .sourceHead = true := by decide
def e834099262702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e834099262702 : Closed e834099262702 ∧ code e834099262702 = 9630192284910 := by decide
theorem cert_e834099262702 : check e834099262702 [] .sourceHead = true := by decide
def e834099262710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e834099262710 : Closed e834099262710 ∧ code e834099262710 = 9630192284918 := by decide
theorem cert_e834099262710 : check e834099262710 [] .sourceHead = true := by decide
def e834099263086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834099263086 : Closed e834099263086 ∧ code e834099263086 = 9630192285294 := by decide
theorem cert_e834099263086 : check e834099263086 [] .sourceHead = true := by decide
def e834099263098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834099263098 : Closed e834099263098 ∧ code e834099263098 = 9630192285306 := by decide
theorem cert_e834099263098 : check e834099263098 [] .sourceHead = true := by decide
def e834099263286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834099263286 : Closed e834099263286 ∧ code e834099263286 = 9630192285494 := by decide
theorem cert_e834099263286 : check e834099263286 [] .sourceHead = true := by decide
def e834099263290 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834099263290 : Closed e834099263290 ∧ code e834099263290 = 9630192285498 := by decide
theorem cert_e834099263290 : check e834099263290 [] .sourceHead = true := by decide
def e834099263918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e834099263918 : Closed e834099263918 ∧ code e834099263918 = 9630192286126 := by decide
theorem cert_e834099263918 : check e834099263918 [] .sourceHead = true := by decide
def e834099263930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e834099263930 : Closed e834099263930 ∧ code e834099263930 = 9630192286138 := by decide
theorem cert_e834099263930 : check e834099263930 [] .sourceHead = true := by decide
def e834099263978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e834099263978 : Closed e834099263978 ∧ code e834099263978 = 9630192286186 := by decide
theorem cert_e834099263978 : check e834099263978 [] .sourceHead = true := by decide
def e834099264110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834099264110 : Closed e834099264110 ∧ code e834099264110 = 9630192286318 := by decide
theorem cert_e834099264110 : check e834099264110 [] .sourceHead = true := by decide
def e834099264122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834099264122 : Closed e834099264122 ∧ code e834099264122 = 9630192286330 := by decide
theorem cert_e834099264122 : check e834099264122 [] .sourceHead = true := by decide
def e834099264410 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834099264410 : Closed e834099264410 ∧ code e834099264410 = 9630192286618 := by decide
theorem cert_e834099264410 : check e834099264410 [] .sourceHead = true := by decide
def e834099264726 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e834099264726 : Closed e834099264726 ∧ code e834099264726 = 9630192286934 := by decide
theorem cert_e834099264726 : check e834099264726 [] .sourceHead = true := by decide
def e834099264730 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e834099264730 : Closed e834099264730 ∧ code e834099264730 = 9630192286938 := by decide
theorem cert_e834099264730 : check e834099264730 [] .sourceHead = true := by decide
def e834099264746 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e834099264746 : Closed e834099264746 ∧ code e834099264746 = 9630192286954 := by decide
theorem cert_e834099264746 : check e834099264746 [] .sourceHead = true := by decide
def e834099264822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834099264822 : Closed e834099264822 ∧ code e834099264822 = 9630192287030 := by decide
theorem cert_e834099264822 : check e834099264822 [] .sourceHead = true := by decide
def e834099264826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834099264826 : Closed e834099264826 ∧ code e834099264826 = 9630192287034 := by decide
theorem cert_e834099264826 : check e834099264826 [] .sourceHead = true := by decide
def e834099264922 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834099264922 : Closed e834099264922 ∧ code e834099264922 = 9630192287130 := by decide
theorem cert_e834099264922 : check e834099264922 [] .sourceHead = true := by decide
def e834099266526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e834099266526 : Closed e834099266526 ∧ code e834099266526 = 9630192288734 := by decide
theorem cert_e834099266526 : check e834099266526 [] .sourceHead = true := by decide
def e834099266542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e834099266542 : Closed e834099266542 ∧ code e834099266542 = 9630192288750 := by decide
theorem cert_e834099266542 : check e834099266542 [] .sourceHead = true := by decide
def e834099268462 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e834099268462 : Closed e834099268462 ∧ code e834099268462 = 9630192290670 := by decide
theorem cert_e834099268462 : check e834099268462 [] .sourceHead = true := by decide
def e834099268470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e834099268470 : Closed e834099268470 ∧ code e834099268470 = 9630192290678 := by decide
theorem cert_e834099268470 : check e834099268470 [] .sourceHead = true := by decide
def e834099268526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e834099268526 : Closed e834099268526 ∧ code e834099268526 = 9630192290734 := by decide
theorem cert_e834099268526 : check e834099268526 [] .sourceHead = true := by decide
def e834099268538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e834099268538 : Closed e834099268538 ∧ code e834099268538 = 9630192290746 := by decide
theorem cert_e834099268538 : check e834099268538 [] .sourceHead = true := by decide
def e834099268566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e834099268566 : Closed e834099268566 ∧ code e834099268566 = 9630192290774 := by decide
theorem cert_e834099268566 : check e834099268566 [] .sourceHead = true := by decide
def e834099268570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e834099268570 : Closed e834099268570 ∧ code e834099268570 = 9630192290778 := by decide
theorem cert_e834099268570 : check e834099268570 [] .sourceHead = true := by decide
def e834099268846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834099268846 : Closed e834099268846 ∧ code e834099268846 = 9630192291054 := by decide
theorem cert_e834099268846 : check e834099268846 [] .sourceHead = true := by decide
def e834099268854 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834099268854 : Closed e834099268854 ∧ code e834099268854 = 9630192291062 := by decide
theorem cert_e834099268854 : check e834099268854 [] .sourceHead = true := by decide
def e834099269230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834099269230 : Closed e834099269230 ∧ code e834099269230 = 9630192291438 := by decide
theorem cert_e834099269230 : check e834099269230 [] .sourceHead = true := by decide
def e834099269242 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834099269242 : Closed e834099269242 ∧ code e834099269242 = 9630192291450 := by decide
theorem cert_e834099269242 : check e834099269242 [] .sourceHead = true := by decide
def e834099269430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834099269430 : Closed e834099269430 ∧ code e834099269430 = 9630192291638 := by decide
theorem cert_e834099269430 : check e834099269430 [] .sourceHead = true := by decide
def e834099269434 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834099269434 : Closed e834099269434 ∧ code e834099269434 = 9630192291642 := by decide
theorem cert_e834099269434 : check e834099269434 [] .sourceHead = true := by decide
def e834099274206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e834099274206 : Closed e834099274206 ∧ code e834099274206 = 9630192296414 := by decide
theorem cert_e834099274206 : check e834099274206 [] .sourceHead = true := by decide
def e834099274230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e834099274230 : Closed e834099274230 ∧ code e834099274230 = 9630192296438 := by decide
theorem cert_e834099274230 : check e834099274230 [] .sourceHead = true := by decide
def e834099275182 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e834099275182 : Closed e834099275182 ∧ code e834099275182 = 9630192297390 := by decide
theorem cert_e834099275182 : check e834099275182 [] .sourceHead = true := by decide
def e834099275194 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e834099275194 : Closed e834099275194 ∧ code e834099275194 = 9630192297402 := by decide
theorem cert_e834099275194 : check e834099275194 [] .sourceHead = true := by decide
def e834099275242 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e834099275242 : Closed e834099275242 ∧ code e834099275242 = 9630192297450 := by decide
theorem cert_e834099275242 : check e834099275242 [] .sourceHead = true := by decide
def e834099275374 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834099275374 : Closed e834099275374 ∧ code e834099275374 = 9630192297582 := by decide
theorem cert_e834099275374 : check e834099275374 [] .sourceHead = true := by decide
def e834099275386 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834099275386 : Closed e834099275386 ∧ code e834099275386 = 9630192297594 := by decide
theorem cert_e834099275386 : check e834099275386 [] .sourceHead = true := by decide
def e834099275674 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834099275674 : Closed e834099275674 ∧ code e834099275674 = 9630192297882 := by decide
theorem cert_e834099275674 : check e834099275674 [] .sourceHead = true := by decide
def e834099278062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e834099278062 : Closed e834099278062 ∧ code e834099278062 = 9630192300270 := by decide
theorem cert_e834099278062 : check e834099278062 [] .sourceHead = true := by decide
def e834099278070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e834099278070 : Closed e834099278070 ∧ code e834099278070 = 9630192300278 := by decide
theorem cert_e834099278070 : check e834099278070 [] .sourceHead = true := by decide
def e834099278550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e834099278550 : Closed e834099278550 ∧ code e834099278550 = 9630192300758 := by decide
theorem cert_e834099278550 : check e834099278550 [] .sourceHead = true := by decide
def e834099278554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e834099278554 : Closed e834099278554 ∧ code e834099278554 = 9630192300762 := by decide
theorem cert_e834099278554 : check e834099278554 [] .sourceHead = true := by decide
def e834099278570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e834099278570 : Closed e834099278570 ∧ code e834099278570 = 9630192300778 := by decide
theorem cert_e834099278570 : check e834099278570 [] .sourceHead = true := by decide
def e834099278646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834099278646 : Closed e834099278646 ∧ code e834099278646 = 9630192300854 := by decide
theorem cert_e834099278646 : check e834099278646 [] .sourceHead = true := by decide
def e834099278650 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834099278650 : Closed e834099278650 ∧ code e834099278650 = 9630192300858 := by decide
theorem cert_e834099278650 : check e834099278650 [] .sourceHead = true := by decide
def e834099278746 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834099278746 : Closed e834099278746 ∧ code e834099278746 = 9630192300954 := by decide
theorem cert_e834099278746 : check e834099278746 [] .sourceHead = true := by decide
def e834099415918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e834099415918 : Closed e834099415918 ∧ code e834099415918 = 9630192438126 := by decide
theorem cert_e834099415918 : check e834099415918 [] .sourceHead = true := by decide
def e834099415926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e834099415926 : Closed e834099415926 ∧ code e834099415926 = 9630192438134 := by decide
theorem cert_e834099415926 : check e834099415926 [] .sourceHead = true := by decide
def e834099415982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e834099415982 : Closed e834099415982 ∧ code e834099415982 = 9630192438190 := by decide
theorem cert_e834099415982 : check e834099415982 [] .sourceHead = true := by decide
def e834099415994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e834099415994 : Closed e834099415994 ∧ code e834099415994 = 9630192438202 := by decide
theorem cert_e834099415994 : check e834099415994 [] .sourceHead = true := by decide
def e834099416022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e834099416022 : Closed e834099416022 ∧ code e834099416022 = 9630192438230 := by decide
theorem cert_e834099416022 : check e834099416022 [] .sourceHead = true := by decide
def e834099416026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e834099416026 : Closed e834099416026 ∧ code e834099416026 = 9630192438234 := by decide
theorem cert_e834099416026 : check e834099416026 [] .sourceHead = true := by decide
def e834099416302 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834099416302 : Closed e834099416302 ∧ code e834099416302 = 9630192438510 := by decide
theorem cert_e834099416302 : check e834099416302 [] .sourceHead = true := by decide
def e834099416310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834099416310 : Closed e834099416310 ∧ code e834099416310 = 9630192438518 := by decide
theorem cert_e834099416310 : check e834099416310 [] .sourceHead = true := by decide
def e834099416686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834099416686 : Closed e834099416686 ∧ code e834099416686 = 9630192438894 := by decide
theorem cert_e834099416686 : check e834099416686 [] .sourceHead = true := by decide
def e834099416698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834099416698 : Closed e834099416698 ∧ code e834099416698 = 9630192438906 := by decide
theorem cert_e834099416698 : check e834099416698 [] .sourceHead = true := by decide
def e834099416886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834099416886 : Closed e834099416886 ∧ code e834099416886 = 9630192439094 := by decide
theorem cert_e834099416886 : check e834099416886 [] .sourceHead = true := by decide
def e834099416890 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834099416890 : Closed e834099416890 ∧ code e834099416890 = 9630192439098 := by decide
theorem cert_e834099416890 : check e834099416890 [] .sourceHead = true := by decide
def e834108697966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e834108697966 : Closed e834108697966 ∧ code e834108697966 = 9630201720174 := by decide
theorem cert_e834108697966 : check e834108697966 [] .sourceHead = true := by decide
def e834108697974 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e834108697974 : Closed e834108697974 ∧ code e834108697974 = 9630201720182 := by decide
theorem cert_e834108697974 : check e834108697974 [] .sourceHead = true := by decide
def e834108698030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e834108698030 : Closed e834108698030 ∧ code e834108698030 = 9630201720238 := by decide
theorem cert_e834108698030 : check e834108698030 [] .sourceHead = true := by decide
def e834108698042 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e834108698042 : Closed e834108698042 ∧ code e834108698042 = 9630201720250 := by decide
theorem cert_e834108698042 : check e834108698042 [] .sourceHead = true := by decide
def e834108698070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e834108698070 : Closed e834108698070 ∧ code e834108698070 = 9630201720278 := by decide
theorem cert_e834108698070 : check e834108698070 [] .sourceHead = true := by decide
def e834108698074 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e834108698074 : Closed e834108698074 ∧ code e834108698074 = 9630201720282 := by decide
theorem cert_e834108698074 : check e834108698074 [] .sourceHead = true := by decide
def e834108698286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e834108698286 : Closed e834108698286 ∧ code e834108698286 = 9630201720494 := by decide
theorem cert_e834108698286 : check e834108698286 [] .sourceHead = true := by decide
def e834108698298 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e834108698298 : Closed e834108698298 ∧ code e834108698298 = 9630201720506 := by decide
theorem cert_e834108698298 : check e834108698298 [] .sourceHead = true := by decide
def e834108698346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e834108698346 : Closed e834108698346 ∧ code e834108698346 = 9630201720554 := by decide
theorem cert_e834108698346 : check e834108698346 [] .sourceHead = true := by decide
def e834108698454 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e834108698454 : Closed e834108698454 ∧ code e834108698454 = 9630201720662 := by decide
theorem cert_e834108698454 : check e834108698454 [] .sourceHead = true := by decide
def e834108698458 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e834108698458 : Closed e834108698458 ∧ code e834108698458 = 9630201720666 := by decide
theorem cert_e834108698458 : check e834108698458 [] .sourceHead = true := by decide
def e834108698474 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e834108698474 : Closed e834108698474 ∧ code e834108698474 = 9630201720682 := by decide
theorem cert_e834108698474 : check e834108698474 [] .sourceHead = true := by decide
def e834108699502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e834108699502 : Closed e834108699502 ∧ code e834108699502 = 9630201721710 := by decide
theorem cert_e834108699502 : check e834108699502 [] .sourceHead = true := by decide
def e834108699510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e834108699510 : Closed e834108699510 ∧ code e834108699510 = 9630201721718 := by decide
theorem cert_e834108699510 : check e834108699510 [] .sourceHead = true := by decide
def e834108699566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e834108699566 : Closed e834108699566 ∧ code e834108699566 = 9630201721774 := by decide
theorem cert_e834108699566 : check e834108699566 [] .sourceHead = true := by decide
def e834108699578 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e834108699578 : Closed e834108699578 ∧ code e834108699578 = 9630201721786 := by decide
theorem cert_e834108699578 : check e834108699578 [] .sourceHead = true := by decide
def e834108699606 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e834108699606 : Closed e834108699606 ∧ code e834108699606 = 9630201721814 := by decide
theorem cert_e834108699606 : check e834108699606 [] .sourceHead = true := by decide
def e834108699610 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e834108699610 : Closed e834108699610 ∧ code e834108699610 = 9630201721818 := by decide
theorem cert_e834108699610 : check e834108699610 [] .sourceHead = true := by decide
def e834108699886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e834108699886 : Closed e834108699886 ∧ code e834108699886 = 9630201722094 := by decide
theorem cert_e834108699886 : check e834108699886 [] .sourceHead = true := by decide
def e834108699894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e834108699894 : Closed e834108699894 ∧ code e834108699894 = 9630201722102 := by decide
theorem cert_e834108699894 : check e834108699894 [] .sourceHead = true := by decide
def e834108700270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834108700270 : Closed e834108700270 ∧ code e834108700270 = 9630201722478 := by decide
theorem cert_e834108700270 : check e834108700270 [] .sourceHead = true := by decide
def e834108700282 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834108700282 : Closed e834108700282 ∧ code e834108700282 = 9630201722490 := by decide
theorem cert_e834108700282 : check e834108700282 [] .sourceHead = true := by decide
def e834108700470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834108700470 : Closed e834108700470 ∧ code e834108700470 = 9630201722678 := by decide
theorem cert_e834108700470 : check e834108700470 [] .sourceHead = true := by decide
def e834108700474 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834108700474 : Closed e834108700474 ∧ code e834108700474 = 9630201722682 := by decide
theorem cert_e834108700474 : check e834108700474 [] .sourceHead = true := by decide
def e834108701102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e834108701102 : Closed e834108701102 ∧ code e834108701102 = 9630201723310 := by decide
theorem cert_e834108701102 : check e834108701102 [] .sourceHead = true := by decide
def e834108701114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e834108701114 : Closed e834108701114 ∧ code e834108701114 = 9630201723322 := by decide
theorem cert_e834108701114 : check e834108701114 [] .sourceHead = true := by decide
def e834108701162 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e834108701162 : Closed e834108701162 ∧ code e834108701162 = 9630201723370 := by decide
theorem cert_e834108701162 : check e834108701162 [] .sourceHead = true := by decide
def e834108701294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834108701294 : Closed e834108701294 ∧ code e834108701294 = 9630201723502 := by decide
theorem cert_e834108701294 : check e834108701294 [] .sourceHead = true := by decide
def e834108701306 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834108701306 : Closed e834108701306 ∧ code e834108701306 = 9630201723514 := by decide
theorem cert_e834108701306 : check e834108701306 [] .sourceHead = true := by decide
def e834108701594 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834108701594 : Closed e834108701594 ∧ code e834108701594 = 9630201723802 := by decide
theorem cert_e834108701594 : check e834108701594 [] .sourceHead = true := by decide
def e834108701910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e834108701910 : Closed e834108701910 ∧ code e834108701910 = 9630201724118 := by decide
theorem cert_e834108701910 : check e834108701910 [] .sourceHead = true := by decide
def e834108701914 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e834108701914 : Closed e834108701914 ∧ code e834108701914 = 9630201724122 := by decide
theorem cert_e834108701914 : check e834108701914 [] .sourceHead = true := by decide
def e834108701930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e834108701930 : Closed e834108701930 ∧ code e834108701930 = 9630201724138 := by decide
theorem cert_e834108701930 : check e834108701930 [] .sourceHead = true := by decide
def e834108702006 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834108702006 : Closed e834108702006 ∧ code e834108702006 = 9630201724214 := by decide
theorem cert_e834108702006 : check e834108702006 [] .sourceHead = true := by decide
def e834108702010 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834108702010 : Closed e834108702010 ∧ code e834108702010 = 9630201724218 := by decide
theorem cert_e834108702010 : check e834108702010 [] .sourceHead = true := by decide
def e834108702106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834108702106 : Closed e834108702106 ∧ code e834108702106 = 9630201724314 := by decide
theorem cert_e834108702106 : check e834108702106 [] .sourceHead = true := by decide
def e834108705646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e834108705646 : Closed e834108705646 ∧ code e834108705646 = 9630201727854 := by decide
theorem cert_e834108705646 : check e834108705646 [] .sourceHead = true := by decide
def e834108705654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e834108705654 : Closed e834108705654 ∧ code e834108705654 = 9630201727862 := by decide
theorem cert_e834108705654 : check e834108705654 [] .sourceHead = true := by decide
def e834108705710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e834108705710 : Closed e834108705710 ∧ code e834108705710 = 9630201727918 := by decide
theorem cert_e834108705710 : check e834108705710 [] .sourceHead = true := by decide
def e834108705722 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e834108705722 : Closed e834108705722 ∧ code e834108705722 = 9630201727930 := by decide
theorem cert_e834108705722 : check e834108705722 [] .sourceHead = true := by decide
def e834108705750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e834108705750 : Closed e834108705750 ∧ code e834108705750 = 9630201727958 := by decide
theorem cert_e834108705750 : check e834108705750 [] .sourceHead = true := by decide
def e834108705754 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e834108705754 : Closed e834108705754 ∧ code e834108705754 = 9630201727962 := by decide
theorem cert_e834108705754 : check e834108705754 [] .sourceHead = true := by decide
def e834108706030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834108706030 : Closed e834108706030 ∧ code e834108706030 = 9630201728238 := by decide
theorem cert_e834108706030 : check e834108706030 [] .sourceHead = true := by decide
def e834108706038 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834108706038 : Closed e834108706038 ∧ code e834108706038 = 9630201728246 := by decide
theorem cert_e834108706038 : check e834108706038 [] .sourceHead = true := by decide
def e834108706414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834108706414 : Closed e834108706414 ∧ code e834108706414 = 9630201728622 := by decide
theorem cert_e834108706414 : check e834108706414 [] .sourceHead = true := by decide
def e834108706426 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834108706426 : Closed e834108706426 ∧ code e834108706426 = 9630201728634 := by decide
theorem cert_e834108706426 : check e834108706426 [] .sourceHead = true := by decide
def e834108706614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834108706614 : Closed e834108706614 ∧ code e834108706614 = 9630201728822 := by decide
theorem cert_e834108706614 : check e834108706614 [] .sourceHead = true := by decide
def e834108706618 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834108706618 : Closed e834108706618 ∧ code e834108706618 = 9630201728826 := by decide
theorem cert_e834108706618 : check e834108706618 [] .sourceHead = true := by decide
def e834108712366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e834108712366 : Closed e834108712366 ∧ code e834108712366 = 9630201734574 := by decide
theorem cert_e834108712366 : check e834108712366 [] .sourceHead = true := by decide
def e834108712378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e834108712378 : Closed e834108712378 ∧ code e834108712378 = 9630201734586 := by decide
theorem cert_e834108712378 : check e834108712378 [] .sourceHead = true := by decide
def e834108712426 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e834108712426 : Closed e834108712426 ∧ code e834108712426 = 9630201734634 := by decide
theorem cert_e834108712426 : check e834108712426 [] .sourceHead = true := by decide
def e834108712558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834108712558 : Closed e834108712558 ∧ code e834108712558 = 9630201734766 := by decide
theorem cert_e834108712558 : check e834108712558 [] .sourceHead = true := by decide
def e834108712570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834108712570 : Closed e834108712570 ∧ code e834108712570 = 9630201734778 := by decide
theorem cert_e834108712570 : check e834108712570 [] .sourceHead = true := by decide
def e834108712858 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834108712858 : Closed e834108712858 ∧ code e834108712858 = 9630201735066 := by decide
theorem cert_e834108712858 : check e834108712858 [] .sourceHead = true := by decide
def e834108715734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e834108715734 : Closed e834108715734 ∧ code e834108715734 = 9630201737942 := by decide
theorem cert_e834108715734 : check e834108715734 [] .sourceHead = true := by decide
def e834108715738 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e834108715738 : Closed e834108715738 ∧ code e834108715738 = 9630201737946 := by decide
theorem cert_e834108715738 : check e834108715738 [] .sourceHead = true := by decide
def e834108715754 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e834108715754 : Closed e834108715754 ∧ code e834108715754 = 9630201737962 := by decide
theorem cert_e834108715754 : check e834108715754 [] .sourceHead = true := by decide
def e834108715830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834108715830 : Closed e834108715830 ∧ code e834108715830 = 9630201738038 := by decide
theorem cert_e834108715830 : check e834108715830 [] .sourceHead = true := by decide
def e834108715834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834108715834 : Closed e834108715834 ∧ code e834108715834 = 9630201738042 := by decide
theorem cert_e834108715834 : check e834108715834 [] .sourceHead = true := by decide
def e834108715930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834108715930 : Closed e834108715930 ∧ code e834108715930 = 9630201738138 := by decide
theorem cert_e834108715930 : check e834108715930 [] .sourceHead = true := by decide
def e834108853102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e834108853102 : Closed e834108853102 ∧ code e834108853102 = 9630201875310 := by decide
theorem cert_e834108853102 : check e834108853102 [] .sourceHead = true := by decide
def e834108853110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e834108853110 : Closed e834108853110 ∧ code e834108853110 = 9630201875318 := by decide
theorem cert_e834108853110 : check e834108853110 [] .sourceHead = true := by decide
def e834108853166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e834108853166 : Closed e834108853166 ∧ code e834108853166 = 9630201875374 := by decide
theorem cert_e834108853166 : check e834108853166 [] .sourceHead = true := by decide
def e834108853178 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e834108853178 : Closed e834108853178 ∧ code e834108853178 = 9630201875386 := by decide
theorem cert_e834108853178 : check e834108853178 [] .sourceHead = true := by decide
def e834108853206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e834108853206 : Closed e834108853206 ∧ code e834108853206 = 9630201875414 := by decide
theorem cert_e834108853206 : check e834108853206 [] .sourceHead = true := by decide
def e834108853210 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e834108853210 : Closed e834108853210 ∧ code e834108853210 = 9630201875418 := by decide
theorem cert_e834108853210 : check e834108853210 [] .sourceHead = true := by decide
def e834108853486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834108853486 : Closed e834108853486 ∧ code e834108853486 = 9630201875694 := by decide
theorem cert_e834108853486 : check e834108853486 [] .sourceHead = true := by decide
def e834108853494 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834108853494 : Closed e834108853494 ∧ code e834108853494 = 9630201875702 := by decide
theorem cert_e834108853494 : check e834108853494 [] .sourceHead = true := by decide
def e834108853870 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834108853870 : Closed e834108853870 ∧ code e834108853870 = 9630201876078 := by decide
theorem cert_e834108853870 : check e834108853870 [] .sourceHead = true := by decide
def e834108853882 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834108853882 : Closed e834108853882 ∧ code e834108853882 = 9630201876090 := by decide
theorem cert_e834108853882 : check e834108853882 [] .sourceHead = true := by decide
def e834108854070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834108854070 : Closed e834108854070 ∧ code e834108854070 = 9630201876278 := by decide
theorem cert_e834108854070 : check e834108854070 [] .sourceHead = true := by decide
def e834108854074 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834108854074 : Closed e834108854074 ∧ code e834108854074 = 9630201876282 := by decide
theorem cert_e834108854074 : check e834108854074 [] .sourceHead = true := by decide
def e835589420474 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e835589420474 : Closed e835589420474 ∧ code e835589420474 = 9631682442682 := by decide
theorem cert_e835589420474 : check e835589420474 [] .sourceHead = true := by decide
def e835589420506 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e835589420506 : Closed e835589420506 ∧ code e835589420506 = 9631682442714 := by decide
theorem cert_e835589420506 : check e835589420506 [] .sourceHead = true := by decide
def e835589420730 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e835589420730 : Closed e835589420730 ∧ code e835589420730 = 9631682442938 := by decide
theorem cert_e835589420730 : check e835589420730 [] .sourceHead = true := by decide
def e835589420778 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e835589420778 : Closed e835589420778 ∧ code e835589420778 = 9631682442986 := by decide
theorem cert_e835589420778 : check e835589420778 [] .sourceHead = true := by decide
def e835589420890 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e835589420890 : Closed e835589420890 ∧ code e835589420890 = 9631682443098 := by decide
theorem cert_e835589420890 : check e835589420890 [] .sourceHead = true := by decide
def e835589420906 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e835589420906 : Closed e835589420906 ∧ code e835589420906 = 9631682443114 := by decide
theorem cert_e835589420906 : check e835589420906 [] .sourceHead = true := by decide
def e835589421754 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e835589421754 : Closed e835589421754 ∧ code e835589421754 = 9631682443962 := by decide
theorem cert_e835589421754 : check e835589421754 [] .sourceHead = true := by decide
def e835589421802 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e835589421802 : Closed e835589421802 ∧ code e835589421802 = 9631682444010 := by decide
theorem cert_e835589421802 : check e835589421802 [] .sourceHead = true := by decide
def e835589421994 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))) (.var 0)))))
theorem wire_e835589421994 : Closed e835589421994 ∧ code e835589421994 = 9631682444202 := by decide
theorem cert_e835589421994 : check e835589421994 [] .sourceHead = true := by decide
def e835589422426 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e835589422426 : Closed e835589422426 ∧ code e835589422426 = 9631682444634 := by decide
theorem cert_e835589422426 : check e835589422426 [] .sourceHead = true := by decide
def e835589422442 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e835589422442 : Closed e835589422442 ∧ code e835589422442 = 9631682444650 := by decide
theorem cert_e835589422442 : check e835589422442 [] .sourceHead = true := by decide
def e835589422506 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (.var 0)))))
theorem wire_e835589422506 : Closed e835589422506 ∧ code e835589422506 = 9631682444714 := by decide
theorem cert_e835589422506 : check e835589422506 [] .sourceHead = true := by decide
end Blc.Floor43
