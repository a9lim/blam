import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411647753326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411647753326 : Closed e2411647753326 ∧ code e2411647753326 = 11207740775534 := by decide
theorem cert_e2411647753326 : check e2411647753326 [[],[]] .chain = true := by decide
def e2411647753338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411647753338 : Closed e2411647753338 ∧ code e2411647753338 = 11207740775546 := by decide
theorem cert_e2411647753338 : check e2411647753338 [[],[]] .chain = true := by decide
def e2411647753502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411647753502 : Closed e2411647753502 ∧ code e2411647753502 = 11207740775710 := by decide
theorem cert_e2411647753502 : check e2411647753502 [[],[]] .chain = true := by decide
def e2411647753670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411647753670 : Closed e2411647753670 ∧ code e2411647753670 = 11207740775878 := by decide
theorem cert_e2411647753670 : check e2411647753670 [[],[]] .chain = true := by decide
def e2411647753782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411647753782 : Closed e2411647753782 ∧ code e2411647753782 = 11207740775990 := by decide
theorem cert_e2411647753782 : check e2411647753782 [[],[]] .chain = true := by decide
def e2411647753786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411647753786 : Closed e2411647753786 ∧ code e2411647753786 = 11207740775994 := by decide
theorem cert_e2411647753786 : check e2411647753786 [[],[]] .chain = true := by decide
def e2411647753870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411647753870 : Closed e2411647753870 ∧ code e2411647753870 = 11207740776078 := by decide
theorem cert_e2411647753870 : check e2411647753870 [[],[]] .chain = true := by decide
def e2411647753926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411647753926 : Closed e2411647753926 ∧ code e2411647753926 = 11207740776134 := by decide
theorem cert_e2411647753926 : check e2411647753926 [[],[]] .chain = true := by decide
def e2411647756062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411647756062 : Closed e2411647756062 ∧ code e2411647756062 = 11207740778270 := by decide
theorem cert_e2411647756062 : check e2411647756062 [[],[]] .chain = true := by decide
def e2411647756174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411647756174 : Closed e2411647756174 ∧ code e2411647756174 = 11207740778382 := by decide
theorem cert_e2411647756174 : check e2411647756174 [[],[]] .chain = true := by decide
def e2411647759134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411647759134 : Closed e2411647759134 ∧ code e2411647759134 = 11207740781342 := by decide
theorem cert_e2411647759134 : check e2411647759134 [[],[]] .chain = true := by decide
def e2411647759302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411647759302 : Closed e2411647759302 ∧ code e2411647759302 = 11207740781510 := by decide
theorem cert_e2411647759302 : check e2411647759302 [[],[]] .chain = true := by decide
def e2411647760782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411647760782 : Closed e2411647760782 ∧ code e2411647760782 = 11207740782990 := by decide
theorem cert_e2411647760782 : check e2411647760782 [[],[]] .chain = true := by decide
def e2411647760838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411647760838 : Closed e2411647760838 ∧ code e2411647760838 = 11207740783046 := by decide
theorem cert_e2411647760838 : check e2411647760838 [[],[]] .chain = true := by decide
def e2411647994734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411647994734 : Closed e2411647994734 ∧ code e2411647994734 = 11207741016942 := by decide
theorem cert_e2411647994734 : check e2411647994734 [[],[]] .chain = true := by decide
def e2411647994742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411647994742 : Closed e2411647994742 ∧ code e2411647994742 = 11207741016950 := by decide
theorem cert_e2411647994742 : check e2411647994742 [[],[]] .chain = true := by decide
def e2411647994798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411647994798 : Closed e2411647994798 ∧ code e2411647994798 = 11207741017006 := by decide
theorem cert_e2411647994798 : check e2411647994798 [[],[]] .chain = true := by decide
def e2411647994810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411647994810 : Closed e2411647994810 ∧ code e2411647994810 = 11207741017018 := by decide
theorem cert_e2411647994810 : check e2411647994810 [[],[]] .chain = true := by decide
def e2411647994838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411647994838 : Closed e2411647994838 ∧ code e2411647994838 = 11207741017046 := by decide
theorem cert_e2411647994838 : check e2411647994838 [[],[]] .chain = true := by decide
def e2411647994842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411647994842 : Closed e2411647994842 ∧ code e2411647994842 = 11207741017050 := by decide
theorem cert_e2411647994842 : check e2411647994842 [[],[]] .chain = true := by decide
def e2411647995118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411647995118 : Closed e2411647995118 ∧ code e2411647995118 = 11207741017326 := by decide
theorem cert_e2411647995118 : check e2411647995118 [[],[]] .chain = true := by decide
def e2411647995126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411647995126 : Closed e2411647995126 ∧ code e2411647995126 = 11207741017334 := by decide
theorem cert_e2411647995126 : check e2411647995126 [[],[]] .chain = true := by decide
def e2411647995502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411647995502 : Closed e2411647995502 ∧ code e2411647995502 = 11207741017710 := by decide
theorem cert_e2411647995502 : check e2411647995502 [[],[]] .chain = true := by decide
def e2411647995514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411647995514 : Closed e2411647995514 ∧ code e2411647995514 = 11207741017722 := by decide
theorem cert_e2411647995514 : check e2411647995514 [[],[]] .chain = true := by decide
def e2411647995702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411647995702 : Closed e2411647995702 ∧ code e2411647995702 = 11207741017910 := by decide
theorem cert_e2411647995702 : check e2411647995702 [[],[]] .chain = true := by decide
def e2411647995706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411647995706 : Closed e2411647995706 ∧ code e2411647995706 = 11207741017914 := by decide
theorem cert_e2411647995706 : check e2411647995706 [[],[]] .chain = true := by decide
def e2411648265658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e2411648265658 : Closed e2411648265658 ∧ code e2411648265658 = 11207741287866 := by decide
theorem cert_e2411648265658 : check e2411648265658 [[],[]] .chain = true := by decide
def e2411648265690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e2411648265690 : Closed e2411648265690 ∧ code e2411648265690 = 11207741287898 := by decide
theorem cert_e2411648265690 : check e2411648265690 [[],[]] .chain = true := by decide
def e2411648265914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e2411648265914 : Closed e2411648265914 ∧ code e2411648265914 = 11207741288122 := by decide
theorem cert_e2411648265914 : check e2411648265914 [[],[]] .chain = true := by decide
def e2411648265962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e2411648265962 : Closed e2411648265962 ∧ code e2411648265962 = 11207741288170 := by decide
theorem cert_e2411648265962 : check e2411648265962 [[],[]] .chain = true := by decide
def e2411648266074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e2411648266074 : Closed e2411648266074 ∧ code e2411648266074 = 11207741288282 := by decide
theorem cert_e2411648266074 : check e2411648266074 [[],[]] .chain = true := by decide
def e2411648266090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e2411648266090 : Closed e2411648266090 ∧ code e2411648266090 = 11207741288298 := by decide
theorem cert_e2411648266090 : check e2411648266090 [[],[]] .chain = true := by decide
def e2411648267194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e2411648267194 : Closed e2411648267194 ∧ code e2411648267194 = 11207741289402 := by decide
theorem cert_e2411648267194 : check e2411648267194 [[],[]] .chain = true := by decide
def e2411648267226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e2411648267226 : Closed e2411648267226 ∧ code e2411648267226 = 11207741289434 := by decide
theorem cert_e2411648267226 : check e2411648267226 [[],[]] .chain = true := by decide
def e2411648268730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e2411648268730 : Closed e2411648268730 ∧ code e2411648268730 = 11207741290938 := by decide
theorem cert_e2411648268730 : check e2411648268730 [[],[]] .chain = true := by decide
def e2411648268778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e2411648268778 : Closed e2411648268778 ∧ code e2411648268778 = 11207741290986 := by decide
theorem cert_e2411648268778 : check e2411648268778 [[],[]] .chain = true := by decide
def e2411648269530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e2411648269530 : Closed e2411648269530 ∧ code e2411648269530 = 11207741291738 := by decide
theorem cert_e2411648269530 : check e2411648269530 [[],[]] .chain = true := by decide
def e2411648269546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e2411648269546 : Closed e2411648269546 ∧ code e2411648269546 = 11207741291754 := by decide
theorem cert_e2411648269546 : check e2411648269546 [[],[]] .chain = true := by decide
def e2411648300770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2411648300770 : Closed e2411648300770 ∧ code e2411648300770 = 11207741322978 := by decide
theorem cert_e2411648300770 : check e2411648300770 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648300898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2411648300898 : Closed e2411648300898 ∧ code e2411648300898 = 11207741323106 := by decide
theorem cert_e2411648300898 : check e2411648300898 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648301794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2411648301794 : Closed e2411648301794 ∧ code e2411648301794 = 11207741324002 := by decide
theorem cert_e2411648301794 : check e2411648301794 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648301986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2411648301986 : Closed e2411648301986 ∧ code e2411648301986 = 11207741324194 := by decide
theorem cert_e2411648301986 : check e2411648301986 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648302434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2411648302434 : Closed e2411648302434 ∧ code e2411648302434 = 11207741324642 := by decide
theorem cert_e2411648302434 : check e2411648302434 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648302498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2411648302498 : Closed e2411648302498 ∧ code e2411648302498 = 11207741324706 := by decide
theorem cert_e2411648302498 : check e2411648302498 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648306914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2411648306914 : Closed e2411648306914 ∧ code e2411648306914 = 11207741329122 := by decide
theorem cert_e2411648306914 : check e2411648306914 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648307042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2411648307042 : Closed e2411648307042 ∧ code e2411648307042 = 11207741329250 := by decide
theorem cert_e2411648307042 : check e2411648307042 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648313058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2411648313058 : Closed e2411648313058 ∧ code e2411648313058 = 11207741335266 := by decide
theorem cert_e2411648313058 : check e2411648313058 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648313250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2411648313250 : Closed e2411648313250 ∧ code e2411648313250 = 11207741335458 := by decide
theorem cert_e2411648313250 : check e2411648313250 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648316258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2411648316258 : Closed e2411648316258 ∧ code e2411648316258 = 11207741338466 := by decide
theorem cert_e2411648316258 : check e2411648316258 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648316322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2411648316322 : Closed e2411648316322 ∧ code e2411648316322 = 11207741338530 := by decide
theorem cert_e2411648316322 : check e2411648316322 [[],[],[.under,.left]] .smaller = true := by decide
def e2411648322414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2411648322414 : Closed e2411648322414 ∧ code e2411648322414 = 11207741344622 := by decide
theorem cert_e2411648322414 : checkPay e2411648322414 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2411648322422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2411648322422 : Closed e2411648322422 ∧ code e2411648322422 = 11207741344630 := by decide
theorem cert_e2411648322422 : check e2411648322422 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411648322478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2411648322478 : Closed e2411648322478 ∧ code e2411648322478 = 11207741344686 := by decide
theorem cert_e2411648322478 : check e2411648322478 [[],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2411648322490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2411648322490 : Closed e2411648322490 ∧ code e2411648322490 = 11207741344698 := by decide
theorem cert_e2411648322490 : check e2411648322490 [[],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2411648322518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2411648322518 : Closed e2411648322518 ∧ code e2411648322518 = 11207741344726 := by decide
theorem cert_e2411648322518 : check e2411648322518 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2411648322522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2411648322522 : Closed e2411648322522 ∧ code e2411648322522 = 11207741344730 := by decide
theorem cert_e2411648322522 : check e2411648322522 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2411648322798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2411648322798 : Closed e2411648322798 ∧ code e2411648322798 = 11207741345006 := by decide
theorem cert_e2411648322798 : checkPay e2411648322798 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left]] 0 [] = true := by decide
def e2411648322806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2411648322806 : Closed e2411648322806 ∧ code e2411648322806 = 11207741345014 := by decide
theorem cert_e2411648322806 : check e2411648322806 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411648323182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2411648323182 : Closed e2411648323182 ∧ code e2411648323182 = 11207741345390 := by decide
theorem cert_e2411648323182 : checkPay e2411648323182 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [[]] = true := by decide
def e2411648323194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2411648323194 : Closed e2411648323194 ∧ code e2411648323194 = 11207741345402 := by decide
theorem cert_e2411648323194 : checkPay e2411648323194 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [[]] = true := by decide
def e2411648323382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2411648323382 : Closed e2411648323382 ∧ code e2411648323382 = 11207741345590 := by decide
theorem cert_e2411648323382 : check e2411648323382 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411648323386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2411648323386 : Closed e2411648323386 ∧ code e2411648323386 = 11207741345594 := by decide
theorem cert_e2411648323386 : check e2411648323386 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411648519022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411648519022 : Closed e2411648519022 ∧ code e2411648519022 = 11207741541230 := by decide
theorem cert_e2411648519022 : check e2411648519022 [[],[]] .chain = true := by decide
def e2411648519030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411648519030 : Closed e2411648519030 ∧ code e2411648519030 = 11207741541238 := by decide
theorem cert_e2411648519030 : check e2411648519030 [[],[]] .chain = true := by decide
def e2411648519086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411648519086 : Closed e2411648519086 ∧ code e2411648519086 = 11207741541294 := by decide
theorem cert_e2411648519086 : check e2411648519086 [[],[]] .chain = true := by decide
def e2411648519098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411648519098 : Closed e2411648519098 ∧ code e2411648519098 = 11207741541306 := by decide
theorem cert_e2411648519098 : check e2411648519098 [[],[]] .chain = true := by decide
def e2411648519126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411648519126 : Closed e2411648519126 ∧ code e2411648519126 = 11207741541334 := by decide
theorem cert_e2411648519126 : check e2411648519126 [[],[]] .chain = true := by decide
def e2411648519130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411648519130 : Closed e2411648519130 ∧ code e2411648519130 = 11207741541338 := by decide
theorem cert_e2411648519130 : check e2411648519130 [[],[]] .chain = true := by decide
def e2411648519406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411648519406 : Closed e2411648519406 ∧ code e2411648519406 = 11207741541614 := by decide
theorem cert_e2411648519406 : check e2411648519406 [[],[]] .chain = true := by decide
def e2411648519414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411648519414 : Closed e2411648519414 ∧ code e2411648519414 = 11207741541622 := by decide
theorem cert_e2411648519414 : check e2411648519414 [[],[]] .chain = true := by decide
def e2411648519790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411648519790 : Closed e2411648519790 ∧ code e2411648519790 = 11207741541998 := by decide
theorem cert_e2411648519790 : check e2411648519790 [[],[]] .chain = true := by decide
def e2411648519802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411648519802 : Closed e2411648519802 ∧ code e2411648519802 = 11207741542010 := by decide
theorem cert_e2411648519802 : check e2411648519802 [[],[]] .chain = true := by decide
def e2411648519990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411648519990 : Closed e2411648519990 ∧ code e2411648519990 = 11207741542198 := by decide
theorem cert_e2411648519990 : check e2411648519990 [[],[]] .chain = true := by decide
def e2411648519994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411648519994 : Closed e2411648519994 ∧ code e2411648519994 = 11207741542202 := by decide
theorem cert_e2411648519994 : check e2411648519994 [[],[]] .chain = true := by decide
def e2411649326558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e2411649326558 : Closed e2411649326558 ∧ code e2411649326558 = 11207742348766 := by decide
theorem cert_e2411649326558 : check e2411649326558 [[],[]] .smaller = true := by decide
def e2411649326574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e2411649326574 : Closed e2411649326574 ∧ code e2411649326574 = 11207742348782 := by decide
theorem cert_e2411649326574 : check e2411649326574 [[],[]] .smaller = true := by decide
def e2411649326814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e2411649326814 : Closed e2411649326814 ∧ code e2411649326814 = 11207742349022 := by decide
theorem cert_e2411649326814 : check e2411649326814 [[],[]] .smaller = true := by decide
def e2411649326838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e2411649326838 : Closed e2411649326838 ∧ code e2411649326838 = 11207742349046 := by decide
theorem cert_e2411649326838 : check e2411649326838 [[],[]] .smaller = true := by decide
def e2411649326958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e2411649326958 : Closed e2411649326958 ∧ code e2411649326958 = 11207742349166 := by decide
theorem cert_e2411649326958 : check e2411649326958 [[],[]] .smaller = true := by decide
def e2411649326966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e2411649326966 : Closed e2411649326966 ∧ code e2411649326966 = 11207742349174 := by decide
theorem cert_e2411649326966 : check e2411649326966 [[],[]] .smaller = true := by decide
def e2411649332190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e2411649332190 : Closed e2411649332190 ∧ code e2411649332190 = 11207742354398 := by decide
theorem cert_e2411649332190 : check e2411649332190 [[],[]] .smaller = true := by decide
def e2411649332206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e2411649332206 : Closed e2411649332206 ∧ code e2411649332206 = 11207742354414 := by decide
theorem cert_e2411649332206 : check e2411649332206 [[],[]] .smaller = true := by decide
def e2411649333726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411649333726 : Closed e2411649333726 ∧ code e2411649333726 = 11207742355934 := by decide
theorem cert_e2411649333726 : check e2411649333726 [[],[]] .smaller = true := by decide
def e2411649333750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411649333750 : Closed e2411649333750 ∧ code e2411649333750 = 11207742355958 := by decide
theorem cert_e2411649333750 : check e2411649333750 [[],[]] .smaller = true := by decide
def e2411649334510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411649334510 : Closed e2411649334510 ∧ code e2411649334510 = 11207742356718 := by decide
theorem cert_e2411649334510 : check e2411649334510 [[],[]] .smaller = true := by decide
def e2411649334518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411649334518 : Closed e2411649334518 ∧ code e2411649334518 = 11207742356726 := by decide
theorem cert_e2411649334518 : check e2411649334518 [[],[]] .smaller = true := by decide
def e2411649391326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2411649391326 : Closed e2411649391326 ∧ code e2411649391326 = 11207742413534 := by decide
theorem cert_e2411649391326 : check e2411649391326 [[],[]] .chain = true := by decide
def e2411649391350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2411649391350 : Closed e2411649391350 ∧ code e2411649391350 = 11207742413558 := by decide
theorem cert_e2411649391350 : check e2411649391350 [[],[]] .chain = true := by decide
def e2411649391454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2411649391454 : Closed e2411649391454 ∧ code e2411649391454 = 11207742413662 := by decide
theorem cert_e2411649391454 : check e2411649391454 [[],[]] .chain = true := by decide
def e2411649391470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2411649391470 : Closed e2411649391470 ∧ code e2411649391470 = 11207742413678 := by decide
theorem cert_e2411649391470 : check e2411649391470 [[],[]] .smaller = true := by decide
def e2411649391478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2411649391478 : Closed e2411649391478 ∧ code e2411649391478 = 11207742413686 := by decide
theorem cert_e2411649391478 : check e2411649391478 [[],[]] .smaller = true := by decide
def e2411649391482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2411649391482 : Closed e2411649391482 ∧ code e2411649391482 = 11207742413690 := by decide
theorem cert_e2411649391482 : check e2411649391482 [[],[]] .chain = true := by decide
def e2411649391542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2411649391542 : Closed e2411649391542 ∧ code e2411649391542 = 11207742413750 := by decide
theorem cert_e2411649391542 : check e2411649391542 [[],[]] .smaller = true := by decide
def e2411649391574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2411649391574 : Closed e2411649391574 ∧ code e2411649391574 = 11207742413782 := by decide
theorem cert_e2411649391574 : check e2411649391574 [[],[]] .chain = true := by decide
def e2411649391578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2411649391578 : Closed e2411649391578 ∧ code e2411649391578 = 11207742413786 := by decide
theorem cert_e2411649391578 : check e2411649391578 [[],[]] .chain = true := by decide
def e2411649391966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2411649391966 : Closed e2411649391966 ∧ code e2411649391966 = 11207742414174 := by decide
theorem cert_e2411649391966 : check e2411649391966 [[],[]] .chain = true := by decide
def e2411649391982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2411649391982 : Closed e2411649391982 ∧ code e2411649391982 = 11207742414190 := by decide
theorem cert_e2411649391982 : check e2411649391982 [[],[]] .smaller = true := by decide
def e2411649391990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2411649391990 : Closed e2411649391990 ∧ code e2411649391990 = 11207742414198 := by decide
theorem cert_e2411649391990 : check e2411649391990 [[],[]] .smaller = true := by decide
def e2411649391994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2411649391994 : Closed e2411649391994 ∧ code e2411649391994 = 11207742414202 := by decide
theorem cert_e2411649391994 : check e2411649391994 [[],[]] .chain = true := by decide
def e2411649392046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2411649392046 : Closed e2411649392046 ∧ code e2411649392046 = 11207742414254 := by decide
theorem cert_e2411649392046 : check e2411649392046 [[],[]] .smaller = true := by decide
def e2411649392058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2411649392058 : Closed e2411649392058 ∧ code e2411649392058 = 11207742414266 := by decide
theorem cert_e2411649392058 : check e2411649392058 [[],[]] .smaller = true := by decide
def e2411649392086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2411649392086 : Closed e2411649392086 ∧ code e2411649392086 = 11207742414294 := by decide
theorem cert_e2411649392086 : check e2411649392086 [[],[]] .smaller = true := by decide
def e2411649392090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2411649392090 : Closed e2411649392090 ∧ code e2411649392090 = 11207742414298 := by decide
theorem cert_e2411649392090 : check e2411649392090 [[],[]] .smaller = true := by decide
def e2411649392106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2411649392106 : Closed e2411649392106 ∧ code e2411649392106 = 11207742414314 := by decide
theorem cert_e2411649392106 : check e2411649392106 [[],[]] .chain = true := by decide
def e2411649392310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2411649392310 : Closed e2411649392310 ∧ code e2411649392310 = 11207742414518 := by decide
theorem cert_e2411649392310 : check e2411649392310 [[],[]] .smaller = true := by decide
def e2411649392342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2411649392342 : Closed e2411649392342 ∧ code e2411649392342 = 11207742414550 := by decide
theorem cert_e2411649392342 : check e2411649392342 [[],[]] .smaller = true := by decide
def e2411649392346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2411649392346 : Closed e2411649392346 ∧ code e2411649392346 = 11207742414554 := by decide
theorem cert_e2411649392346 : check e2411649392346 [[],[]] .smaller = true := by decide
def e2411649392470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411649392470 : Closed e2411649392470 ∧ code e2411649392470 = 11207742414678 := by decide
theorem cert_e2411649392470 : check e2411649392470 [[],[]] .chain = true := by decide
def e2411649392474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411649392474 : Closed e2411649392474 ∧ code e2411649392474 = 11207742414682 := by decide
theorem cert_e2411649392474 : check e2411649392474 [[],[]] .chain = true := by decide
def e2411649392490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411649392490 : Closed e2411649392490 ∧ code e2411649392490 = 11207742414698 := by decide
theorem cert_e2411649392490 : check e2411649392490 [[],[]] .chain = true := by decide
def e2411649393630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e2411649393630 : Closed e2411649393630 ∧ code e2411649393630 = 11207742415838 := by decide
theorem cert_e2411649393630 : check e2411649393630 [[],[]] .chain = true := by decide
def e2411649393646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e2411649393646 : Closed e2411649393646 ∧ code e2411649393646 = 11207742415854 := by decide
theorem cert_e2411649393646 : check e2411649393646 [[],[]] .chain = true := by decide
def e2411649394398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2411649394398 : Closed e2411649394398 ∧ code e2411649394398 = 11207742416606 := by decide
theorem cert_e2411649394398 : check e2411649394398 [[],[]] .chain = true := by decide
def e2411649394422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2411649394422 : Closed e2411649394422 ∧ code e2411649394422 = 11207742416630 := by decide
theorem cert_e2411649394422 : check e2411649394422 [[],[]] .chain = true := by decide
def e2411649394526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2411649394526 : Closed e2411649394526 ∧ code e2411649394526 = 11207742416734 := by decide
theorem cert_e2411649394526 : check e2411649394526 [[],[]] .chain = true := by decide
def e2411649394542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2411649394542 : Closed e2411649394542 ∧ code e2411649394542 = 11207742416750 := by decide
theorem cert_e2411649394542 : check e2411649394542 [[],[]] .smaller = true := by decide
def e2411649394550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2411649394550 : Closed e2411649394550 ∧ code e2411649394550 = 11207742416758 := by decide
theorem cert_e2411649394550 : check e2411649394550 [[],[]] .smaller = true := by decide
def e2411649394554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2411649394554 : Closed e2411649394554 ∧ code e2411649394554 = 11207742416762 := by decide
theorem cert_e2411649394554 : check e2411649394554 [[],[]] .chain = true := by decide
def e2411649394614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2411649394614 : Closed e2411649394614 ∧ code e2411649394614 = 11207742416822 := by decide
theorem cert_e2411649394614 : check e2411649394614 [[],[]] .smaller = true := by decide
def e2411649394646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2411649394646 : Closed e2411649394646 ∧ code e2411649394646 = 11207742416854 := by decide
theorem cert_e2411649394646 : check e2411649394646 [[],[]] .chain = true := by decide
def e2411649394650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2411649394650 : Closed e2411649394650 ∧ code e2411649394650 = 11207742416858 := by decide
theorem cert_e2411649394650 : check e2411649394650 [[],[]] .chain = true := by decide
def e2411649395166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411649395166 : Closed e2411649395166 ∧ code e2411649395166 = 11207742417374 := by decide
theorem cert_e2411649395166 : check e2411649395166 [[],[]] .chain = true := by decide
def e2411649395190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411649395190 : Closed e2411649395190 ∧ code e2411649395190 = 11207742417398 := by decide
theorem cert_e2411649395190 : check e2411649395190 [[],[]] .chain = true := by decide
def e2411649395934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411649395934 : Closed e2411649395934 ∧ code e2411649395934 = 11207742418142 := by decide
theorem cert_e2411649395934 : check e2411649395934 [[],[]] .chain = true := by decide
def e2411649395950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411649395950 : Closed e2411649395950 ∧ code e2411649395950 = 11207742418158 := by decide
theorem cert_e2411649395950 : check e2411649395950 [[],[]] .smaller = true := by decide
def e2411649395958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411649395958 : Closed e2411649395958 ∧ code e2411649395958 = 11207742418166 := by decide
theorem cert_e2411649395958 : check e2411649395958 [[],[]] .smaller = true := by decide
def e2411649395962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411649395962 : Closed e2411649395962 ∧ code e2411649395962 = 11207742418170 := by decide
theorem cert_e2411649395962 : check e2411649395962 [[],[]] .chain = true := by decide
def e2411649396286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e2411649396286 : Closed e2411649396286 ∧ code e2411649396286 = 11207742418494 := by decide
theorem cert_e2411649396286 : check e2411649396286 [[],[]] .chain = true := by decide
def e2411649396342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411649396342 : Closed e2411649396342 ∧ code e2411649396342 = 11207742418550 := by decide
theorem cert_e2411649396342 : check e2411649396342 [[],[]] .smaller = true := by decide
def e2411649396510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e2411649396510 : Closed e2411649396510 ∧ code e2411649396510 = 11207742418718 := by decide
theorem cert_e2411649396510 : check e2411649396510 [[],[]] .chain = true := by decide
def e2411649396534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411649396534 : Closed e2411649396534 ∧ code e2411649396534 = 11207742418742 := by decide
theorem cert_e2411649396534 : check e2411649396534 [[],[]] .chain = true := by decide
def e2411649396538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411649396538 : Closed e2411649396538 ∧ code e2411649396538 = 11207742418746 := by decide
theorem cert_e2411649396538 : check e2411649396538 [[],[]] .chain = true := by decide
def e2411649397598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2411649397598 : Closed e2411649397598 ∧ code e2411649397598 = 11207742419806 := by decide
theorem cert_e2411649397598 : check e2411649397598 [[],[]] .chain = true := by decide
def e2411649397614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2411649397614 : Closed e2411649397614 ∧ code e2411649397614 = 11207742419822 := by decide
theorem cert_e2411649397614 : check e2411649397614 [[],[]] .smaller = true := by decide
def e2411649397622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2411649397622 : Closed e2411649397622 ∧ code e2411649397622 = 11207742419830 := by decide
theorem cert_e2411649397622 : check e2411649397622 [[],[]] .smaller = true := by decide
def e2411649397626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2411649397626 : Closed e2411649397626 ∧ code e2411649397626 = 11207742419834 := by decide
theorem cert_e2411649397626 : check e2411649397626 [[],[]] .chain = true := by decide
def e2411649397678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2411649397678 : Closed e2411649397678 ∧ code e2411649397678 = 11207742419886 := by decide
theorem cert_e2411649397678 : check e2411649397678 [[],[]] .smaller = true := by decide
def e2411649397690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2411649397690 : Closed e2411649397690 ∧ code e2411649397690 = 11207742419898 := by decide
theorem cert_e2411649397690 : check e2411649397690 [[],[]] .smaller = true := by decide
def e2411649397718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2411649397718 : Closed e2411649397718 ∧ code e2411649397718 = 11207742419926 := by decide
theorem cert_e2411649397718 : check e2411649397718 [[],[]] .smaller = true := by decide
def e2411649397722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2411649397722 : Closed e2411649397722 ∧ code e2411649397722 = 11207742419930 := by decide
theorem cert_e2411649397722 : check e2411649397722 [[],[]] .smaller = true := by decide
def e2411649397738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2411649397738 : Closed e2411649397738 ∧ code e2411649397738 = 11207742419946 := by decide
theorem cert_e2411649397738 : check e2411649397738 [[],[]] .chain = true := by decide
def e2411649397982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411649397982 : Closed e2411649397982 ∧ code e2411649397982 = 11207742420190 := by decide
theorem cert_e2411649397982 : check e2411649397982 [[],[]] .chain = true := by decide
def e2411649397998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411649397998 : Closed e2411649397998 ∧ code e2411649397998 = 11207742420206 := by decide
theorem cert_e2411649397998 : check e2411649397998 [[],[]] .smaller = true := by decide
def e2411649398006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411649398006 : Closed e2411649398006 ∧ code e2411649398006 = 11207742420214 := by decide
theorem cert_e2411649398006 : check e2411649398006 [[],[]] .smaller = true := by decide
def e2411649398010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411649398010 : Closed e2411649398010 ∧ code e2411649398010 = 11207742420218 := by decide
theorem cert_e2411649398010 : check e2411649398010 [[],[]] .chain = true := by decide
def e2411649398382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411649398382 : Closed e2411649398382 ∧ code e2411649398382 = 11207742420590 := by decide
theorem cert_e2411649398382 : check e2411649398382 [[],[]] .smaller = true := by decide
def e2411649398394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411649398394 : Closed e2411649398394 ∧ code e2411649398394 = 11207742420602 := by decide
theorem cert_e2411649398394 : check e2411649398394 [[],[]] .smaller = true := by decide
def e2411649398582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411649398582 : Closed e2411649398582 ∧ code e2411649398582 = 11207742420790 := by decide
theorem cert_e2411649398582 : check e2411649398582 [[],[]] .smaller = true := by decide
def e2411649398586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411649398586 : Closed e2411649398586 ∧ code e2411649398586 = 11207742420794 := by decide
theorem cert_e2411649398586 : check e2411649398586 [[],[]] .smaller = true := by decide
def e2411649398682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411649398682 : Closed e2411649398682 ∧ code e2411649398682 = 11207742420890 := by decide
theorem cert_e2411649398682 : check e2411649398682 [[],[]] .chain = true := by decide
def e2411649399006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2411649399006 : Closed e2411649399006 ∧ code e2411649399006 = 11207742421214 := by decide
theorem cert_e2411649399006 : check e2411649399006 [[],[]] .chain = true := by decide
def e2411649399034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2411649399034 : Closed e2411649399034 ∧ code e2411649399034 = 11207742421242 := by decide
theorem cert_e2411649399034 : check e2411649399034 [[],[]] .chain = true := by decide
def e2411649399222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2411649399222 : Closed e2411649399222 ∧ code e2411649399222 = 11207742421430 := by decide
theorem cert_e2411649399222 : check e2411649399222 [[],[]] .smaller = true := by decide
def e2411649399254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2411649399254 : Closed e2411649399254 ∧ code e2411649399254 = 11207742421462 := by decide
theorem cert_e2411649399254 : check e2411649399254 [[],[]] .smaller = true := by decide
def e2411649399258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2411649399258 : Closed e2411649399258 ∧ code e2411649399258 = 11207742421466 := by decide
theorem cert_e2411649399258 : check e2411649399258 [[],[]] .smaller = true := by decide
def e2411649399358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2411649399358 : Closed e2411649399358 ∧ code e2411649399358 = 11207742421566 := by decide
theorem cert_e2411649399358 : check e2411649399358 [[],[]] .chain = true := by decide
def e2411649399414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411649399414 : Closed e2411649399414 ∧ code e2411649399414 = 11207742421622 := by decide
theorem cert_e2411649399414 : check e2411649399414 [[],[]] .smaller = true := by decide
def e2411649399606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411649399606 : Closed e2411649399606 ∧ code e2411649399606 = 11207742421814 := by decide
theorem cert_e2411649399606 : check e2411649399606 [[],[]] .smaller = true := by decide
def e2411649399610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411649399610 : Closed e2411649399610 ∧ code e2411649399610 = 11207742421818 := by decide
theorem cert_e2411649399610 : check e2411649399610 [[],[]] .smaller = true := by decide
def e2411649399750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2411649399750 : Closed e2411649399750 ∧ code e2411649399750 = 11207742421958 := by decide
theorem cert_e2411649399750 : check e2411649399750 [[],[]] .chain = true := by decide
end Blc.Floor43
