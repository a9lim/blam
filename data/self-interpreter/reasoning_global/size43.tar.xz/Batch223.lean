import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392705751838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2392705751838 : Closed e2392705751838 ∧ code e2392705751838 = 11188798774046 := by decide
theorem cert_e2392705751838 : check e2392705751838 [[],[.left],[.left],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2392705751950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2392705751950 : Closed e2392705751950 ∧ code e2392705751950 = 11188798774158 := by decide
theorem cert_e2392705751950 : check e2392705751950 [[],[.left],[.left],[.left],[],[.left],[],[]] .chain = true := by decide
def e2392705752174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2392705752174 : Closed e2392705752174 ∧ code e2392705752174 = 11188798774382 := by decide
theorem cert_e2392705752174 : check e2392705752174 [[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2392705752186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2392705752186 : Closed e2392705752186 ∧ code e2392705752186 = 11188798774394 := by decide
theorem cert_e2392705752186 : check e2392705752186 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2392705752350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2392705752350 : Closed e2392705752350 ∧ code e2392705752350 = 11188798774558 := by decide
theorem cert_e2392705752350 : check e2392705752350 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2392705752518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2392705752518 : Closed e2392705752518 ∧ code e2392705752518 = 11188798774726 := by decide
private def t_e2392705752518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e2392705752518 : ¬ IsSelfInterpreter e2392705752518 :=
  wSource (t := t_e2392705752518) (replay_sound (ps := []) (t := e2392705752518) (by decide)) (by decide)
def e2392705752630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2392705752630 : Closed e2392705752630 ∧ code e2392705752630 = 11188798774838 := by decide
theorem cert_e2392705752630 : check e2392705752630 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2392705752634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2392705752634 : Closed e2392705752634 ∧ code e2392705752634 = 11188798774842 := by decide
theorem cert_e2392705752634 : check e2392705752634 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2392705752718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2392705752718 : Closed e2392705752718 ∧ code e2392705752718 = 11188798774926 := by decide
theorem cert_e2392705752718 : check e2392705752718 [[],[.left],[.left],[.left],[],[.left],[.left],[],[]] .chain = true := by decide
def e2392705752774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2392705752774 : Closed e2392705752774 ∧ code e2392705752774 = 11188798774982 := by decide
private def t_e2392705752774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e2392705752774 : ¬ IsSelfInterpreter e2392705752774 :=
  wSource (t := t_e2392705752774) (replay_sound (ps := []) (t := e2392705752774) (by decide)) (by decide)
def e2392705754910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2392705754910 : Closed e2392705754910 ∧ code e2392705754910 = 11188798777118 := by decide
theorem cert_e2392705754910 : check e2392705754910 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2392705755022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2392705755022 : Closed e2392705755022 ∧ code e2392705755022 = 11188798777230 := by decide
theorem cert_e2392705755022 : check e2392705755022 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2392705757982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2392705757982 : Closed e2392705757982 ∧ code e2392705757982 = 11188798780190 := by decide
theorem cert_e2392705757982 : check e2392705757982 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392705758150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2392705758150 : Closed e2392705758150 ∧ code e2392705758150 = 11188798780358 := by decide
theorem cert_e2392705758150 : check e2392705758150 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2392705759630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2392705759630 : Closed e2392705759630 ∧ code e2392705759630 = 11188798781838 := by decide
theorem cert_e2392705759630 : check e2392705759630 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392705759686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2392705759686 : Closed e2392705759686 ∧ code e2392705759686 = 11188798781894 := by decide
theorem cert_e2392705759686 : check e2392705759686 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2393102839322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102839322 : Closed e2393102839322 ∧ code e2393102839322 = 11189195861530 := by decide
private def t_e2393102839322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102839322 : ¬ IsSelfInterpreter e2393102839322 :=
  wSource (t := t_e2393102839322) (replay_sound (ps := []) (t := e2393102839322) (by decide)) (by decide)
def e2393102841370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102841370 : Closed e2393102841370 ∧ code e2393102841370 = 11189195863578 := by decide
private def t_e2393102841370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102841370 : ¬ IsSelfInterpreter e2393102841370 :=
  wSource (t := t_e2393102841370) (replay_sound (ps := []) (t := e2393102841370) (by decide)) (by decide)
def e2393102855706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102855706 : Closed e2393102855706 ∧ code e2393102855706 = 11189195877914 := by decide
private def t_e2393102855706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102855706 : ¬ IsSelfInterpreter e2393102855706 :=
  wSource (t := t_e2393102855706) (replay_sound (ps := []) (t := e2393102855706) (by decide)) (by decide)
def e2393102858778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102858778 : Closed e2393102858778 ∧ code e2393102858778 = 11189195880986 := by decide
private def t_e2393102858778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102858778 : ¬ IsSelfInterpreter e2393102858778 :=
  wSource (t := t_e2393102858778) (replay_sound (ps := []) (t := e2393102858778) (by decide)) (by decide)
def e2393102865946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102865946 : Closed e2393102865946 ∧ code e2393102865946 = 11189195888154 := by decide
private def t_e2393102865946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102865946 : ¬ IsSelfInterpreter e2393102865946 :=
  wSource (t := t_e2393102865946) (replay_sound (ps := []) (t := e2393102865946) (by decide)) (by decide)
def e2393102866970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102866970 : Closed e2393102866970 ∧ code e2393102866970 = 11189195889178 := by decide
private def t_e2393102866970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102866970 : ¬ IsSelfInterpreter e2393102866970 :=
  wSource (t := t_e2393102866970) (replay_sound (ps := []) (t := e2393102866970) (by decide)) (by decide)
def e2393102937626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102937626 : Closed e2393102937626 ∧ code e2393102937626 = 11189195959834 := by decide
private def t_e2393102937626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102937626 : ¬ IsSelfInterpreter e2393102937626 :=
  wSource (t := t_e2393102937626) (replay_sound (ps := []) (t := e2393102937626) (by decide)) (by decide)
def e2393102939674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393102939674 : Closed e2393102939674 ∧ code e2393102939674 = 11189195961882 := by decide
private def t_e2393102939674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393102939674 : ¬ IsSelfInterpreter e2393102939674 :=
  wSource (t := t_e2393102939674) (replay_sound (ps := []) (t := e2393102939674) (by decide)) (by decide)
def e2393103035930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393103035930 : Closed e2393103035930 ∧ code e2393103035930 = 11189196058138 := by decide
private def t_e2393103035930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393103035930 : ¬ IsSelfInterpreter e2393103035930 :=
  wSource (t := t_e2393103035930) (replay_sound (ps := []) (t := e2393103035930) (by decide)) (by decide)
def e2393103039002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393103039002 : Closed e2393103039002 ∧ code e2393103039002 = 11189196061210 := by decide
private def t_e2393103039002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393103039002 : ¬ IsSelfInterpreter e2393103039002 :=
  wSource (t := t_e2393103039002) (replay_sound (ps := []) (t := e2393103039002) (by decide)) (by decide)
def e2393103087130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393103087130 : Closed e2393103087130 ∧ code e2393103087130 = 11189196109338 := by decide
private def t_e2393103087130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393103087130 : ¬ IsSelfInterpreter e2393103087130 :=
  wSource (t := t_e2393103087130) (replay_sound (ps := []) (t := e2393103087130) (by decide)) (by decide)
def e2393103088154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2393103088154 : Closed e2393103088154 ∧ code e2393103088154 = 11189196110362 := by decide
private def t_e2393103088154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2393103088154 : ¬ IsSelfInterpreter e2393103088154 :=
  wSource (t := t_e2393103088154) (replay_sound (ps := []) (t := e2393103088154) (by decide)) (by decide)
def e2393105086490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105086490 : Closed e2393105086490 ∧ code e2393105086490 = 11189198108698 := by decide
theorem cert_e2393105086490 : check e2393105086490 [[]] .width = true := by decide
def e2393105094682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105094682 : Closed e2393105094682 ∧ code e2393105094682 = 11189198116890 := by decide
theorem cert_e2393105094682 : check e2393105094682 [[]] .width = true := by decide
def e2393105152026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105152026 : Closed e2393105152026 ∧ code e2393105152026 = 11189198174234 := by decide
theorem cert_e2393105152026 : check e2393105152026 [[]] .width = true := by decide
def e2393105164314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105164314 : Closed e2393105164314 ∧ code e2393105164314 = 11189198186522 := by decide
theorem cert_e2393105164314 : check e2393105164314 [[]] .width = true := by decide
def e2393105192986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105192986 : Closed e2393105192986 ∧ code e2393105192986 = 11189198215194 := by decide
theorem cert_e2393105192986 : check e2393105192986 [[]] .width = true := by decide
def e2393105197082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105197082 : Closed e2393105197082 ∧ code e2393105197082 = 11189198219290 := by decide
theorem cert_e2393105197082 : check e2393105197082 [[]] .width = true := by decide
def e2393105479706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105479706 : Closed e2393105479706 ∧ code e2393105479706 = 11189198501914 := by decide
theorem cert_e2393105479706 : check e2393105479706 [[]] .width = true := by decide
def e2393105487898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105487898 : Closed e2393105487898 ∧ code e2393105487898 = 11189198510106 := by decide
theorem cert_e2393105487898 : check e2393105487898 [[]] .width = true := by decide
def e2393105872922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105872922 : Closed e2393105872922 ∧ code e2393105872922 = 11189198895130 := by decide
theorem cert_e2393105872922 : check e2393105872922 [[]] .width = true := by decide
def e2393105885210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393105885210 : Closed e2393105885210 ∧ code e2393105885210 = 11189198907418 := by decide
theorem cert_e2393105885210 : check e2393105885210 [[]] .width = true := by decide
def e2393106077722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393106077722 : Closed e2393106077722 ∧ code e2393106077722 = 11189199099930 := by decide
theorem cert_e2393106077722 : check e2393106077722 [[]] .width = true := by decide
def e2393106081818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2393106081818 : Closed e2393106081818 ∧ code e2393106081818 = 11189199104026 := by decide
theorem cert_e2393106081818 : check e2393106081818 [[]] .width = true := by decide
def e2393118911854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2393118911854 : Closed e2393118911854 ∧ code e2393118911854 = 11189211934062 := by decide
theorem cert_e2393118911854 : check e2393118911854 [[],[.left],[]] .sourceHead = true := by decide
def e2393118911862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2393118911862 : Closed e2393118911862 ∧ code e2393118911862 = 11189211934070 := by decide
theorem cert_e2393118911862 : check e2393118911862 [[],[.left],[]] .sourceHead = true := by decide
def e2393118911918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2393118911918 : Closed e2393118911918 ∧ code e2393118911918 = 11189211934126 := by decide
theorem cert_e2393118911918 : check e2393118911918 [[],[.left],[]] .sourceHead = true := by decide
def e2393118911930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2393118911930 : Closed e2393118911930 ∧ code e2393118911930 = 11189211934138 := by decide
theorem cert_e2393118911930 : check e2393118911930 [[],[.left],[]] .sourceHead = true := by decide
def e2393118911958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2393118911958 : Closed e2393118911958 ∧ code e2393118911958 = 11189211934166 := by decide
theorem cert_e2393118911958 : check e2393118911958 [[],[.left],[]] .sourceHead = true := by decide
def e2393118911962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2393118911962 : Closed e2393118911962 ∧ code e2393118911962 = 11189211934170 := by decide
theorem cert_e2393118911962 : check e2393118911962 [[],[.left],[]] .sourceHead = true := by decide
def e2393118912174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2393118912174 : Closed e2393118912174 ∧ code e2393118912174 = 11189211934382 := by decide
theorem cert_e2393118912174 : check e2393118912174 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393118912186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2393118912186 : Closed e2393118912186 ∧ code e2393118912186 = 11189211934394 := by decide
theorem cert_e2393118912186 : check e2393118912186 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393118912234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2393118912234 : Closed e2393118912234 ∧ code e2393118912234 = 11189211934442 := by decide
theorem cert_e2393118912234 : check e2393118912234 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393118912342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2393118912342 : Closed e2393118912342 ∧ code e2393118912342 = 11189211934550 := by decide
theorem cert_e2393118912342 : check e2393118912342 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393118912346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2393118912346 : Closed e2393118912346 ∧ code e2393118912346 = 11189211934554 := by decide
theorem cert_e2393118912346 : check e2393118912346 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393118912362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2393118912362 : Closed e2393118912362 ∧ code e2393118912362 = 11189211934570 := by decide
theorem cert_e2393118912362 : check e2393118912362 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393118913390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2393118913390 : Closed e2393118913390 ∧ code e2393118913390 = 11189211935598 := by decide
theorem cert_e2393118913390 : check e2393118913390 [[],[.left],[]] .sourceHead = true := by decide
def e2393118913398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2393118913398 : Closed e2393118913398 ∧ code e2393118913398 = 11189211935606 := by decide
theorem cert_e2393118913398 : check e2393118913398 [[],[.left],[]] .sourceHead = true := by decide
def e2393118913454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2393118913454 : Closed e2393118913454 ∧ code e2393118913454 = 11189211935662 := by decide
theorem cert_e2393118913454 : check e2393118913454 [[],[.left],[]] .sourceHead = true := by decide
def e2393118913466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2393118913466 : Closed e2393118913466 ∧ code e2393118913466 = 11189211935674 := by decide
theorem cert_e2393118913466 : check e2393118913466 [[],[.left],[]] .sourceHead = true := by decide
def e2393118913494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2393118913494 : Closed e2393118913494 ∧ code e2393118913494 = 11189211935702 := by decide
theorem cert_e2393118913494 : check e2393118913494 [[],[.left],[]] .sourceHead = true := by decide
def e2393118913498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2393118913498 : Closed e2393118913498 ∧ code e2393118913498 = 11189211935706 := by decide
theorem cert_e2393118913498 : check e2393118913498 [[],[.left],[]] .sourceHead = true := by decide
def e2393118913774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393118913774 : Closed e2393118913774 ∧ code e2393118913774 = 11189211935982 := by decide
theorem cert_e2393118913774 : check e2393118913774 [[],[.left],[]] .sourceHead = true := by decide
def e2393118913782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393118913782 : Closed e2393118913782 ∧ code e2393118913782 = 11189211935990 := by decide
theorem cert_e2393118913782 : check e2393118913782 [[],[.left],[]] .sourceHead = true := by decide
def e2393118914158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393118914158 : Closed e2393118914158 ∧ code e2393118914158 = 11189211936366 := by decide
theorem cert_e2393118914158 : check e2393118914158 [[],[.left],[]] .sourceHead = true := by decide
def e2393118914170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393118914170 : Closed e2393118914170 ∧ code e2393118914170 = 11189211936378 := by decide
theorem cert_e2393118914170 : check e2393118914170 [[],[.left],[]] .sourceHead = true := by decide
def e2393118914358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393118914358 : Closed e2393118914358 ∧ code e2393118914358 = 11189211936566 := by decide
theorem cert_e2393118914358 : check e2393118914358 [[],[.left],[]] .sourceHead = true := by decide
def e2393118914362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393118914362 : Closed e2393118914362 ∧ code e2393118914362 = 11189211936570 := by decide
theorem cert_e2393118914362 : check e2393118914362 [[],[.left],[]] .sourceHead = true := by decide
def e2393118914990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2393118914990 : Closed e2393118914990 ∧ code e2393118914990 = 11189211937198 := by decide
theorem cert_e2393118914990 : check e2393118914990 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393118915002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2393118915002 : Closed e2393118915002 ∧ code e2393118915002 = 11189211937210 := by decide
theorem cert_e2393118915002 : check e2393118915002 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393118915050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2393118915050 : Closed e2393118915050 ∧ code e2393118915050 = 11189211937258 := by decide
theorem cert_e2393118915050 : check e2393118915050 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393118915182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393118915182 : Closed e2393118915182 ∧ code e2393118915182 = 11189211937390 := by decide
theorem cert_e2393118915182 : check e2393118915182 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393118915194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393118915194 : Closed e2393118915194 ∧ code e2393118915194 = 11189211937402 := by decide
theorem cert_e2393118915194 : check e2393118915194 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393118915482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2393118915482 : Closed e2393118915482 ∧ code e2393118915482 = 11189211937690 := by decide
theorem cert_e2393118915482 : check e2393118915482 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393118915798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2393118915798 : Closed e2393118915798 ∧ code e2393118915798 = 11189211938006 := by decide
theorem cert_e2393118915798 : check e2393118915798 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118915802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2393118915802 : Closed e2393118915802 ∧ code e2393118915802 = 11189211938010 := by decide
theorem cert_e2393118915802 : check e2393118915802 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393118915818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2393118915818 : Closed e2393118915818 ∧ code e2393118915818 = 11189211938026 := by decide
theorem cert_e2393118915818 : check e2393118915818 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393118915894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393118915894 : Closed e2393118915894 ∧ code e2393118915894 = 11189211938102 := by decide
theorem cert_e2393118915894 : check e2393118915894 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118915898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393118915898 : Closed e2393118915898 ∧ code e2393118915898 = 11189211938106 := by decide
theorem cert_e2393118915898 : check e2393118915898 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118915994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2393118915994 : Closed e2393118915994 ∧ code e2393118915994 = 11189211938202 := by decide
theorem cert_e2393118915994 : check e2393118915994 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393118919534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393118919534 : Closed e2393118919534 ∧ code e2393118919534 = 11189211941742 := by decide
theorem cert_e2393118919534 : check e2393118919534 [[],[.left],[]] .sourceHead = true := by decide
def e2393118919542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393118919542 : Closed e2393118919542 ∧ code e2393118919542 = 11189211941750 := by decide
theorem cert_e2393118919542 : check e2393118919542 [[],[.left],[]] .sourceHead = true := by decide
def e2393118919598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393118919598 : Closed e2393118919598 ∧ code e2393118919598 = 11189211941806 := by decide
theorem cert_e2393118919598 : check e2393118919598 [[],[.left],[]] .sourceHead = true := by decide
def e2393118919610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393118919610 : Closed e2393118919610 ∧ code e2393118919610 = 11189211941818 := by decide
theorem cert_e2393118919610 : check e2393118919610 [[],[.left],[]] .sourceHead = true := by decide
def e2393118919638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393118919638 : Closed e2393118919638 ∧ code e2393118919638 = 11189211941846 := by decide
theorem cert_e2393118919638 : check e2393118919638 [[],[.left],[]] .sourceHead = true := by decide
def e2393118919642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393118919642 : Closed e2393118919642 ∧ code e2393118919642 = 11189211941850 := by decide
theorem cert_e2393118919642 : check e2393118919642 [[],[.left],[]] .sourceHead = true := by decide
def e2393118919918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393118919918 : Closed e2393118919918 ∧ code e2393118919918 = 11189211942126 := by decide
theorem cert_e2393118919918 : check e2393118919918 [[],[.left],[]] .sourceHead = true := by decide
def e2393118919926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393118919926 : Closed e2393118919926 ∧ code e2393118919926 = 11189211942134 := by decide
theorem cert_e2393118919926 : check e2393118919926 [[],[.left],[]] .sourceHead = true := by decide
def e2393118920302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393118920302 : Closed e2393118920302 ∧ code e2393118920302 = 11189211942510 := by decide
theorem cert_e2393118920302 : check e2393118920302 [[],[.left],[]] .sourceHead = true := by decide
def e2393118920314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393118920314 : Closed e2393118920314 ∧ code e2393118920314 = 11189211942522 := by decide
theorem cert_e2393118920314 : check e2393118920314 [[],[.left],[]] .sourceHead = true := by decide
def e2393118920502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393118920502 : Closed e2393118920502 ∧ code e2393118920502 = 11189211942710 := by decide
theorem cert_e2393118920502 : check e2393118920502 [[],[.left],[]] .sourceHead = true := by decide
def e2393118920506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393118920506 : Closed e2393118920506 ∧ code e2393118920506 = 11189211942714 := by decide
theorem cert_e2393118920506 : check e2393118920506 [[],[.left],[]] .sourceHead = true := by decide
def e2393118926254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2393118926254 : Closed e2393118926254 ∧ code e2393118926254 = 11189211948462 := by decide
theorem cert_e2393118926254 : check e2393118926254 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118926266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2393118926266 : Closed e2393118926266 ∧ code e2393118926266 = 11189211948474 := by decide
theorem cert_e2393118926266 : check e2393118926266 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118926314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2393118926314 : Closed e2393118926314 ∧ code e2393118926314 = 11189211948522 := by decide
theorem cert_e2393118926314 : check e2393118926314 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118926446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2393118926446 : Closed e2393118926446 ∧ code e2393118926446 = 11189211948654 := by decide
theorem cert_e2393118926446 : check e2393118926446 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118926458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2393118926458 : Closed e2393118926458 ∧ code e2393118926458 = 11189211948666 := by decide
theorem cert_e2393118926458 : check e2393118926458 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118926746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2393118926746 : Closed e2393118926746 ∧ code e2393118926746 = 11189211948954 := by decide
theorem cert_e2393118926746 : check e2393118926746 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393118929622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2393118929622 : Closed e2393118929622 ∧ code e2393118929622 = 11189211951830 := by decide
theorem cert_e2393118929622 : check e2393118929622 [[],[.left],[],[.under]] .three = true := by decide
def e2393118929626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2393118929626 : Closed e2393118929626 ∧ code e2393118929626 = 11189211951834 := by decide
theorem cert_e2393118929626 : check e2393118929626 [[],[.left],[],[.under]] .three = true := by decide
def e2393118929642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2393118929642 : Closed e2393118929642 ∧ code e2393118929642 = 11189211951850 := by decide
theorem cert_e2393118929642 : check e2393118929642 [[],[.left],[],[.under]] .three = true := by decide
def e2393118929718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2393118929718 : Closed e2393118929718 ∧ code e2393118929718 = 11189211951926 := by decide
theorem cert_e2393118929718 : check e2393118929718 [[],[.left],[],[.under]] .three = true := by decide
def e2393118929722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2393118929722 : Closed e2393118929722 ∧ code e2393118929722 = 11189211951930 := by decide
theorem cert_e2393118929722 : check e2393118929722 [[],[.left],[],[.under]] .three = true := by decide
def e2393118929818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2393118929818 : Closed e2393118929818 ∧ code e2393118929818 = 11189211952026 := by decide
theorem cert_e2393118929818 : check e2393118929818 [[],[.left],[],[.under]] .three = true := by decide
def e2393119066990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393119066990 : Closed e2393119066990 ∧ code e2393119066990 = 11189212089198 := by decide
def e2393119066998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393119066998 : Closed e2393119066998 ∧ code e2393119066998 = 11189212089206 := by decide
def e2393119067054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393119067054 : Closed e2393119067054 ∧ code e2393119067054 = 11189212089262 := by decide
def e2393119067066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393119067066 : Closed e2393119067066 ∧ code e2393119067066 = 11189212089274 := by decide
def e2393119067094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393119067094 : Closed e2393119067094 ∧ code e2393119067094 = 11189212089302 := by decide
def e2393119067098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393119067098 : Closed e2393119067098 ∧ code e2393119067098 = 11189212089306 := by decide
def e2393119067374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393119067374 : Closed e2393119067374 ∧ code e2393119067374 = 11189212089582 := by decide
def e2393119067382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393119067382 : Closed e2393119067382 ∧ code e2393119067382 = 11189212089590 := by decide
def e2393119067758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393119067758 : Closed e2393119067758 ∧ code e2393119067758 = 11189212089966 := by decide
def e2393119067770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393119067770 : Closed e2393119067770 ∧ code e2393119067770 = 11189212089978 := by decide
def e2393119067958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393119067958 : Closed e2393119067958 ∧ code e2393119067958 = 11189212090166 := by decide
theorem cert_e2393119067958 : check e2393119067958 [[],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e2393119067962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393119067962 : Closed e2393119067962 ∧ code e2393119067962 = 11189212090170 := by decide
theorem cert_e2393119067962 : check e2393119067962 [[],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e2393119656814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393119656814 : Closed e2393119656814 ∧ code e2393119656814 = 11189212679022 := by decide
theorem cert_e2393119656814 : check e2393119656814 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2393119656822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393119656822 : Closed e2393119656822 ∧ code e2393119656822 = 11189212679030 := by decide
theorem cert_e2393119656822 : check e2393119656822 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393119656878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393119656878 : Closed e2393119656878 ∧ code e2393119656878 = 11189212679086 := by decide
theorem cert_e2393119656878 : check e2393119656878 [[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393119656890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393119656890 : Closed e2393119656890 ∧ code e2393119656890 = 11189212679098 := by decide
private def t_e2393119656890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2393119656890 : ¬ IsSelfInterpreter e2393119656890 :=
  wSource (t := t_e2393119656890) (replay_sound (ps := []) (t := e2393119656890) (by decide)) (by decide)
def e2393119656918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393119656918 : Closed e2393119656918 ∧ code e2393119656918 = 11189212679126 := by decide
theorem cert_e2393119656918 : check e2393119656918 [[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393119656922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393119656922 : Closed e2393119656922 ∧ code e2393119656922 = 11189212679130 := by decide
private def t_e2393119656922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2393119656922 : ¬ IsSelfInterpreter e2393119656922 :=
  wSource (t := t_e2393119656922) (replay_sound (ps := []) (t := e2393119656922) (by decide)) (by decide)
def e2393119657198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393119657198 : Closed e2393119657198 ∧ code e2393119657198 = 11189212679406 := by decide
theorem cert_e2393119657198 : check e2393119657198 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2393119657206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393119657206 : Closed e2393119657206 ∧ code e2393119657206 = 11189212679414 := by decide
theorem cert_e2393119657206 : check e2393119657206 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2393119657582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393119657582 : Closed e2393119657582 ∧ code e2393119657582 = 11189212679790 := by decide
theorem cert_e2393119657582 : check e2393119657582 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393119657594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393119657594 : Closed e2393119657594 ∧ code e2393119657594 = 11189212679802 := by decide
theorem cert_e2393119657594 : check e2393119657594 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393119657782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393119657782 : Closed e2393119657782 ∧ code e2393119657782 = 11189212679990 := by decide
theorem cert_e2393119657782 : check e2393119657782 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393119657786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393119657786 : Closed e2393119657786 ∧ code e2393119657786 = 11189212679994 := by decide
theorem cert_e2393119657786 : check e2393119657786 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393169243502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393169243502 : Closed e2393169243502 ∧ code e2393169243502 = 11189262265710 := by decide
theorem cert_e2393169243502 : check e2393169243502 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393169243510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393169243510 : Closed e2393169243510 ∧ code e2393169243510 = 11189262265718 := by decide
theorem cert_e2393169243510 : checkPay e2393169243510 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393169243566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393169243566 : Closed e2393169243566 ∧ code e2393169243566 = 11189262265774 := by decide
theorem cert_e2393169243566 : check e2393169243566 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2393169243578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393169243578 : Closed e2393169243578 ∧ code e2393169243578 = 11189262265786 := by decide
theorem cert_e2393169243578 : check e2393169243578 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2393169243606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393169243606 : Closed e2393169243606 ∧ code e2393169243606 = 11189262265814 := by decide
theorem cert_e2393169243606 : checkPay e2393169243606 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393169243610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393169243610 : Closed e2393169243610 ∧ code e2393169243610 = 11189262265818 := by decide
theorem cert_e2393169243610 : check e2393169243610 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2393169243822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2393169243822 : Closed e2393169243822 ∧ code e2393169243822 = 11189262266030 := by decide
theorem cert_e2393169243822 : check e2393169243822 [[],[.left],[]] .sourceHead = true := by decide
def e2393169243834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2393169243834 : Closed e2393169243834 ∧ code e2393169243834 = 11189262266042 := by decide
theorem cert_e2393169243834 : check e2393169243834 [[],[.left],[]] .sourceHead = true := by decide
def e2393169243882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2393169243882 : Closed e2393169243882 ∧ code e2393169243882 = 11189262266090 := by decide
theorem cert_e2393169243882 : check e2393169243882 [[],[.left],[]] .sourceHead = true := by decide
def e2393169243990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2393169243990 : Closed e2393169243990 ∧ code e2393169243990 = 11189262266198 := by decide
theorem cert_e2393169243990 : check e2393169243990 [[],[.left],[],[.under,.under,.left,.left,.left]] .smaller = true := by decide
def e2393169243994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2393169243994 : Closed e2393169243994 ∧ code e2393169243994 = 11189262266202 := by decide
theorem cert_e2393169243994 : check e2393169243994 [[],[.left],[],[.under,.under,.left,.left,.left]] .smaller = true := by decide
def e2393169244010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2393169244010 : Closed e2393169244010 ∧ code e2393169244010 = 11189262266218 := by decide
theorem cert_e2393169244010 : check e2393169244010 [[],[.left],[],[.under,.under,.left,.left,.left]] .smaller = true := by decide
def e2393169245038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393169245038 : Closed e2393169245038 ∧ code e2393169245038 = 11189262267246 := by decide
theorem cert_e2393169245038 : check e2393169245038 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2393169245046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393169245046 : Closed e2393169245046 ∧ code e2393169245046 = 11189262267254 := by decide
theorem cert_e2393169245046 : check e2393169245046 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393169245102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393169245102 : Closed e2393169245102 ∧ code e2393169245102 = 11189262267310 := by decide
theorem cert_e2393169245102 : check e2393169245102 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393169245114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393169245114 : Closed e2393169245114 ∧ code e2393169245114 = 11189262267322 := by decide
theorem cert_e2393169245114 : check e2393169245114 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393169245142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393169245142 : Closed e2393169245142 ∧ code e2393169245142 = 11189262267350 := by decide
theorem cert_e2393169245142 : check e2393169245142 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393169245146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393169245146 : Closed e2393169245146 ∧ code e2393169245146 = 11189262267354 := by decide
theorem cert_e2393169245146 : check e2393169245146 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2393169245422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393169245422 : Closed e2393169245422 ∧ code e2393169245422 = 11189262267630 := by decide
theorem cert_e2393169245422 : check e2393169245422 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393169245430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393169245430 : Closed e2393169245430 ∧ code e2393169245430 = 11189262267638 := by decide
theorem cert_e2393169245430 : check e2393169245430 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393169245806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393169245806 : Closed e2393169245806 ∧ code e2393169245806 = 11189262268014 := by decide
theorem cert_e2393169245806 : check e2393169245806 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393169245818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393169245818 : Closed e2393169245818 ∧ code e2393169245818 = 11189262268026 := by decide
theorem cert_e2393169245818 : check e2393169245818 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393169246006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393169246006 : Closed e2393169246006 ∧ code e2393169246006 = 11189262268214 := by decide
theorem cert_e2393169246006 : check e2393169246006 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2393169246010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393169246010 : Closed e2393169246010 ∧ code e2393169246010 = 11189262268218 := by decide
theorem cert_e2393169246010 : check e2393169246010 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393169246638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2393169246638 : Closed e2393169246638 ∧ code e2393169246638 = 11189262268846 := by decide
theorem cert_e2393169246638 : checkPay e2393169246638 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2393169246650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2393169246650 : Closed e2393169246650 ∧ code e2393169246650 = 11189262268858 := by decide
theorem cert_e2393169246650 : checkPay e2393169246650 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.under,.left]] = true := by decide
def e2393169246698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2393169246698 : Closed e2393169246698 ∧ code e2393169246698 = 11189262268906 := by decide
theorem cert_e2393169246698 : checkPay e2393169246698 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.under,.left,.right]] = true := by decide
def e2393169246830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393169246830 : Closed e2393169246830 ∧ code e2393169246830 = 11189262269038 := by decide
theorem cert_e2393169246830 : checkPay e2393169246830 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393169246842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393169246842 : Closed e2393169246842 ∧ code e2393169246842 = 11189262269050 := by decide
theorem cert_e2393169246842 : checkPay e2393169246842 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393169247130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393169247130 : Closed e2393169247130 ∧ code e2393169247130 = 11189262269338 := by decide
theorem cert_e2393169247130 : checkPay e2393169247130 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2393169247446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2393169247446 : Closed e2393169247446 ∧ code e2393169247446 = 11189262269654 := by decide
theorem cert_e2393169247446 : check e2393169247446 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2393169247450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2393169247450 : Closed e2393169247450 ∧ code e2393169247450 = 11189262269658 := by decide
theorem cert_e2393169247450 : check e2393169247450 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2393169247466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2393169247466 : Closed e2393169247466 ∧ code e2393169247466 = 11189262269674 := by decide
theorem cert_e2393169247466 : check e2393169247466 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2393169247542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393169247542 : Closed e2393169247542 ∧ code e2393169247542 = 11189262269750 := by decide
theorem cert_e2393169247542 : check e2393169247542 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2393169247546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393169247546 : Closed e2393169247546 ∧ code e2393169247546 = 11189262269754 := by decide
theorem cert_e2393169247546 : check e2393169247546 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2393169247642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393169247642 : Closed e2393169247642 ∧ code e2393169247642 = 11189262269850 := by decide
theorem cert_e2393169247642 : check e2393169247642 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392705752518
#print axioms Blc.Floor43.cert_e2392705752774
#print axioms Blc.Floor43.cert_e2393102839322
#print axioms Blc.Floor43.cert_e2393102841370
#print axioms Blc.Floor43.cert_e2393102855706
#print axioms Blc.Floor43.cert_e2393102858778
#print axioms Blc.Floor43.cert_e2393102865946
#print axioms Blc.Floor43.cert_e2393102866970
#print axioms Blc.Floor43.cert_e2393102937626
#print axioms Blc.Floor43.cert_e2393102939674
#print axioms Blc.Floor43.cert_e2393103035930
#print axioms Blc.Floor43.cert_e2393103039002
#print axioms Blc.Floor43.cert_e2393103087130
#print axioms Blc.Floor43.cert_e2393103088154
#print axioms Blc.Floor43.cert_e2393119656890
#print axioms Blc.Floor43.cert_e2393119656922
