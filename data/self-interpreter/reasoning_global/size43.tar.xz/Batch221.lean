import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392578001774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392578001774 : Closed e2392578001774 ∧ code e2392578001774 = 11188671023982 := by decide
private def t_e2392578001774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e2392578001774 : ¬ IsSelfInterpreter e2392578001774 :=
  wSource (t := t_e2392578001774) (replay_sound (ps := []) (t := e2392578001774) (by decide)) (by decide)
def e2392578001782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392578001782 : Closed e2392578001782 ∧ code e2392578001782 = 11188671023990 := by decide
private def t_e2392578001782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e2392578001782 : ¬ IsSelfInterpreter e2392578001782 :=
  wSource (t := t_e2392578001782) (replay_sound (ps := []) (t := e2392578001782) (by decide)) (by decide)
def e2392578001838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392578001838 : Closed e2392578001838 ∧ code e2392578001838 = 11188671024046 := by decide
private def t_e2392578001838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e2392578001838 : ¬ IsSelfInterpreter e2392578001838 :=
  wSource (t := t_e2392578001838) (replay_sound (ps := []) (t := e2392578001838) (by decide)) (by decide)
def e2392578001850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392578001850 : Closed e2392578001850 ∧ code e2392578001850 = 11188671024058 := by decide
private def t_e2392578001850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2392578001850 : ¬ IsSelfInterpreter e2392578001850 :=
  wSource (t := t_e2392578001850) (replay_sound (ps := []) (t := e2392578001850) (by decide)) (by decide)
def e2392578001878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392578001878 : Closed e2392578001878 ∧ code e2392578001878 = 11188671024086 := by decide
private def t_e2392578001878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e2392578001878 : ¬ IsSelfInterpreter e2392578001878 :=
  wSource (t := t_e2392578001878) (replay_sound (ps := []) (t := e2392578001878) (by decide)) (by decide)
def e2392578001882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392578001882 : Closed e2392578001882 ∧ code e2392578001882 = 11188671024090 := by decide
private def t_e2392578001882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2392578001882 : ¬ IsSelfInterpreter e2392578001882 :=
  wSource (t := t_e2392578001882) (replay_sound (ps := []) (t := e2392578001882) (by decide)) (by decide)
def e2392578002158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392578002158 : Closed e2392578002158 ∧ code e2392578002158 = 11188671024366 := by decide
private def t_e2392578002158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e2392578002158 : ¬ IsSelfInterpreter e2392578002158 :=
  wSource (t := t_e2392578002158) (replay_sound (ps := []) (t := e2392578002158) (by decide)) (by decide)
def e2392578002166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392578002166 : Closed e2392578002166 ∧ code e2392578002166 = 11188671024374 := by decide
private def t_e2392578002166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e2392578002166 : ¬ IsSelfInterpreter e2392578002166 :=
  wSource (t := t_e2392578002166) (replay_sound (ps := []) (t := e2392578002166) (by decide)) (by decide)
def e2392578002542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392578002542 : Closed e2392578002542 ∧ code e2392578002542 = 11188671024750 := by decide
private def t_e2392578002542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e2392578002542 : ¬ IsSelfInterpreter e2392578002542 :=
  wSource (t := t_e2392578002542) (replay_sound (ps := []) (t := e2392578002542) (by decide)) (by decide)
def e2392578002554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392578002554 : Closed e2392578002554 ∧ code e2392578002554 = 11188671024762 := by decide
private def t_e2392578002554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e2392578002554 : ¬ IsSelfInterpreter e2392578002554 :=
  wSource (t := t_e2392578002554) (replay_sound (ps := []) (t := e2392578002554) (by decide)) (by decide)
def e2392578002742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392578002742 : Closed e2392578002742 ∧ code e2392578002742 = 11188671024950 := by decide
private def t_e2392578002742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e2392578002742 : ¬ IsSelfInterpreter e2392578002742 :=
  wSource (t := t_e2392578002742) (replay_sound (ps := []) (t := e2392578002742) (by decide)) (by decide)
def e2392578002746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392578002746 : Closed e2392578002746 ∧ code e2392578002746 = 11188671024954 := by decide
private def t_e2392578002746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e2392578002746 : ¬ IsSelfInterpreter e2392578002746 :=
  wSource (t := t_e2392578002746) (replay_sound (ps := []) (t := e2392578002746) (by decide)) (by decide)
def e2392578591598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392578591598 : Closed e2392578591598 ∧ code e2392578591598 = 11188671613806 := by decide
def e2392578591606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392578591606 : Closed e2392578591606 ∧ code e2392578591606 = 11188671613814 := by decide
def e2392578591662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392578591662 : Closed e2392578591662 ∧ code e2392578591662 = 11188671613870 := by decide
def e2392578591674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392578591674 : Closed e2392578591674 ∧ code e2392578591674 = 11188671613882 := by decide
private def t_e2392578591674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2392578591674 : ¬ IsSelfInterpreter e2392578591674 :=
  wSource (t := t_e2392578591674) (replay_sound (ps := []) (t := e2392578591674) (by decide)) (by decide)
def e2392578591702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392578591702 : Closed e2392578591702 ∧ code e2392578591702 = 11188671613910 := by decide
def e2392578591706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392578591706 : Closed e2392578591706 ∧ code e2392578591706 = 11188671613914 := by decide
private def t_e2392578591706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2392578591706 : ¬ IsSelfInterpreter e2392578591706 :=
  wSource (t := t_e2392578591706) (replay_sound (ps := []) (t := e2392578591706) (by decide)) (by decide)
def e2392578591982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392578591982 : Closed e2392578591982 ∧ code e2392578591982 = 11188671614190 := by decide
def e2392578591990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392578591990 : Closed e2392578591990 ∧ code e2392578591990 = 11188671614198 := by decide
def e2392578592366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392578592366 : Closed e2392578592366 ∧ code e2392578592366 = 11188671614574 := by decide
def e2392578592378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392578592378 : Closed e2392578592378 ∧ code e2392578592378 = 11188671614586 := by decide
def e2392578592566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392578592566 : Closed e2392578592566 ∧ code e2392578592566 = 11188671614774 := by decide
def e2392578592570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392578592570 : Closed e2392578592570 ∧ code e2392578592570 = 11188671614778 := by decide
def e2392699525854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2392699525854 : Closed e2392699525854 ∧ code e2392699525854 = 11188792548062 := by decide
theorem cert_e2392699525854 : check e2392699525854 [[],[.left],[]] .chain = true := by decide
def e2392699525878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2392699525878 : Closed e2392699525878 ∧ code e2392699525878 = 11188792548086 := by decide
theorem cert_e2392699525878 : check e2392699525878 [[],[.left],[]] .chain = true := by decide
def e2392699525982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2392699525982 : Closed e2392699525982 ∧ code e2392699525982 = 11188792548190 := by decide
theorem cert_e2392699525982 : check e2392699525982 [[],[.left],[]] .chain = true := by decide
def e2392699525998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2392699525998 : Closed e2392699525998 ∧ code e2392699525998 = 11188792548206 := by decide
theorem cert_e2392699525998 : check e2392699525998 [[],[.left],[]] .chain = true := by decide
def e2392699526006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2392699526006 : Closed e2392699526006 ∧ code e2392699526006 = 11188792548214 := by decide
theorem cert_e2392699526006 : check e2392699526006 [[],[.left],[]] .chain = true := by decide
def e2392699526010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2392699526010 : Closed e2392699526010 ∧ code e2392699526010 = 11188792548218 := by decide
theorem cert_e2392699526010 : check e2392699526010 [[],[.left],[]] .chain = true := by decide
def e2392699526070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2392699526070 : Closed e2392699526070 ∧ code e2392699526070 = 11188792548278 := by decide
theorem cert_e2392699526070 : check e2392699526070 [[],[.left],[]] .chain = true := by decide
def e2392699526102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2392699526102 : Closed e2392699526102 ∧ code e2392699526102 = 11188792548310 := by decide
theorem cert_e2392699526102 : check e2392699526102 [[],[.left],[]] .chain = true := by decide
def e2392699526106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2392699526106 : Closed e2392699526106 ∧ code e2392699526106 = 11188792548314 := by decide
theorem cert_e2392699526106 : check e2392699526106 [[],[.left],[]] .chain = true := by decide
def e2392699526494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2392699526494 : Closed e2392699526494 ∧ code e2392699526494 = 11188792548702 := by decide
theorem cert_e2392699526494 : check e2392699526494 [[],[.left],[]] .chain = true := by decide
def e2392699526510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2392699526510 : Closed e2392699526510 ∧ code e2392699526510 = 11188792548718 := by decide
theorem cert_e2392699526510 : check e2392699526510 [[],[.left],[]] .chain = true := by decide
def e2392699526518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2392699526518 : Closed e2392699526518 ∧ code e2392699526518 = 11188792548726 := by decide
theorem cert_e2392699526518 : check e2392699526518 [[],[.left],[]] .chain = true := by decide
def e2392699526522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2392699526522 : Closed e2392699526522 ∧ code e2392699526522 = 11188792548730 := by decide
theorem cert_e2392699526522 : check e2392699526522 [[],[.left],[]] .chain = true := by decide
def e2392699526574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2392699526574 : Closed e2392699526574 ∧ code e2392699526574 = 11188792548782 := by decide
theorem cert_e2392699526574 : check e2392699526574 [[],[.left],[]] .chain = true := by decide
def e2392699526586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2392699526586 : Closed e2392699526586 ∧ code e2392699526586 = 11188792548794 := by decide
theorem cert_e2392699526586 : check e2392699526586 [[],[.left],[]] .chain = true := by decide
def e2392699526614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2392699526614 : Closed e2392699526614 ∧ code e2392699526614 = 11188792548822 := by decide
theorem cert_e2392699526614 : check e2392699526614 [[],[.left],[]] .chain = true := by decide
def e2392699526618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2392699526618 : Closed e2392699526618 ∧ code e2392699526618 = 11188792548826 := by decide
theorem cert_e2392699526618 : check e2392699526618 [[],[.left],[]] .chain = true := by decide
def e2392699526634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2392699526634 : Closed e2392699526634 ∧ code e2392699526634 = 11188792548842 := by decide
theorem cert_e2392699526634 : check e2392699526634 [[],[.left],[]] .chain = true := by decide
def e2392699526838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2392699526838 : Closed e2392699526838 ∧ code e2392699526838 = 11188792549046 := by decide
theorem cert_e2392699526838 : check e2392699526838 [[],[.left],[]] .chain = true := by decide
def e2392699526870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2392699526870 : Closed e2392699526870 ∧ code e2392699526870 = 11188792549078 := by decide
theorem cert_e2392699526870 : check e2392699526870 [[],[.left],[]] .chain = true := by decide
def e2392699526874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2392699526874 : Closed e2392699526874 ∧ code e2392699526874 = 11188792549082 := by decide
theorem cert_e2392699526874 : check e2392699526874 [[],[.left],[]] .chain = true := by decide
def e2392699526998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2392699526998 : Closed e2392699526998 ∧ code e2392699526998 = 11188792549206 := by decide
theorem cert_e2392699526998 : check e2392699526998 [[],[.left],[]] .chain = true := by decide
def e2392699527002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2392699527002 : Closed e2392699527002 ∧ code e2392699527002 = 11188792549210 := by decide
theorem cert_e2392699527002 : check e2392699527002 [[],[.left],[]] .chain = true := by decide
def e2392699527018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2392699527018 : Closed e2392699527018 ∧ code e2392699527018 = 11188792549226 := by decide
theorem cert_e2392699527018 : check e2392699527018 [[],[.left],[]] .chain = true := by decide
def e2392699528926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2392699528926 : Closed e2392699528926 ∧ code e2392699528926 = 11188792551134 := by decide
theorem cert_e2392699528926 : check e2392699528926 [[],[.left],[]] .chain = true := by decide
def e2392699528950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2392699528950 : Closed e2392699528950 ∧ code e2392699528950 = 11188792551158 := by decide
theorem cert_e2392699528950 : check e2392699528950 [[],[.left],[]] .chain = true := by decide
def e2392699529054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2392699529054 : Closed e2392699529054 ∧ code e2392699529054 = 11188792551262 := by decide
theorem cert_e2392699529054 : check e2392699529054 [[],[.left],[]] .chain = true := by decide
def e2392699529070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2392699529070 : Closed e2392699529070 ∧ code e2392699529070 = 11188792551278 := by decide
theorem cert_e2392699529070 : check e2392699529070 [[],[.left],[]] .chain = true := by decide
def e2392699529078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2392699529078 : Closed e2392699529078 ∧ code e2392699529078 = 11188792551286 := by decide
theorem cert_e2392699529078 : check e2392699529078 [[],[.left],[]] .chain = true := by decide
def e2392699529082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2392699529082 : Closed e2392699529082 ∧ code e2392699529082 = 11188792551290 := by decide
theorem cert_e2392699529082 : check e2392699529082 [[],[.left],[]] .chain = true := by decide
def e2392699529142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2392699529142 : Closed e2392699529142 ∧ code e2392699529142 = 11188792551350 := by decide
theorem cert_e2392699529142 : check e2392699529142 [[],[.left],[]] .chain = true := by decide
def e2392699529174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2392699529174 : Closed e2392699529174 ∧ code e2392699529174 = 11188792551382 := by decide
theorem cert_e2392699529174 : check e2392699529174 [[],[.left],[]] .chain = true := by decide
def e2392699529178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2392699529178 : Closed e2392699529178 ∧ code e2392699529178 = 11188792551386 := by decide
theorem cert_e2392699529178 : check e2392699529178 [[],[.left],[]] .chain = true := by decide
def e2392699529694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2392699529694 : Closed e2392699529694 ∧ code e2392699529694 = 11188792551902 := by decide
theorem cert_e2392699529694 : check e2392699529694 [[],[.left],[]] .chain = true := by decide
def e2392699529718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2392699529718 : Closed e2392699529718 ∧ code e2392699529718 = 11188792551926 := by decide
theorem cert_e2392699529718 : check e2392699529718 [[],[.left],[]] .chain = true := by decide
def e2392699530462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2392699530462 : Closed e2392699530462 ∧ code e2392699530462 = 11188792552670 := by decide
theorem cert_e2392699530462 : check e2392699530462 [[],[.left],[]] .chain = true := by decide
def e2392699530478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392699530478 : Closed e2392699530478 ∧ code e2392699530478 = 11188792552686 := by decide
theorem cert_e2392699530478 : check e2392699530478 [[],[.left],[]] .chain = true := by decide
def e2392699530486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392699530486 : Closed e2392699530486 ∧ code e2392699530486 = 11188792552694 := by decide
theorem cert_e2392699530486 : check e2392699530486 [[],[.left],[]] .chain = true := by decide
def e2392699530490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2392699530490 : Closed e2392699530490 ∧ code e2392699530490 = 11188792552698 := by decide
theorem cert_e2392699530490 : check e2392699530490 [[],[.left],[]] .chain = true := by decide
def e2392699530870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2392699530870 : Closed e2392699530870 ∧ code e2392699530870 = 11188792553078 := by decide
theorem cert_e2392699530870 : check e2392699530870 [[],[.left],[]] .chain = true := by decide
def e2392699531062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392699531062 : Closed e2392699531062 ∧ code e2392699531062 = 11188792553270 := by decide
theorem cert_e2392699531062 : check e2392699531062 [[],[.left],[]] .chain = true := by decide
def e2392699531066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392699531066 : Closed e2392699531066 ∧ code e2392699531066 = 11188792553274 := by decide
theorem cert_e2392699531066 : check e2392699531066 [[],[.left],[]] .chain = true := by decide
def e2392699532126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2392699532126 : Closed e2392699532126 ∧ code e2392699532126 = 11188792554334 := by decide
theorem cert_e2392699532126 : check e2392699532126 [[],[.left],[]] .chain = true := by decide
def e2392699532142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2392699532142 : Closed e2392699532142 ∧ code e2392699532142 = 11188792554350 := by decide
theorem cert_e2392699532142 : check e2392699532142 [[],[.left],[]] .chain = true := by decide
def e2392699532150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2392699532150 : Closed e2392699532150 ∧ code e2392699532150 = 11188792554358 := by decide
theorem cert_e2392699532150 : check e2392699532150 [[],[.left],[]] .chain = true := by decide
def e2392699532154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2392699532154 : Closed e2392699532154 ∧ code e2392699532154 = 11188792554362 := by decide
theorem cert_e2392699532154 : check e2392699532154 [[],[.left],[]] .chain = true := by decide
def e2392699532206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2392699532206 : Closed e2392699532206 ∧ code e2392699532206 = 11188792554414 := by decide
theorem cert_e2392699532206 : check e2392699532206 [[],[.left],[]] .chain = true := by decide
def e2392699532218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2392699532218 : Closed e2392699532218 ∧ code e2392699532218 = 11188792554426 := by decide
theorem cert_e2392699532218 : check e2392699532218 [[],[.left],[]] .chain = true := by decide
def e2392699532246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2392699532246 : Closed e2392699532246 ∧ code e2392699532246 = 11188792554454 := by decide
theorem cert_e2392699532246 : check e2392699532246 [[],[.left],[]] .chain = true := by decide
def e2392699532250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2392699532250 : Closed e2392699532250 ∧ code e2392699532250 = 11188792554458 := by decide
theorem cert_e2392699532250 : check e2392699532250 [[],[.left],[]] .chain = true := by decide
def e2392699532266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2392699532266 : Closed e2392699532266 ∧ code e2392699532266 = 11188792554474 := by decide
theorem cert_e2392699532266 : check e2392699532266 [[],[.left],[]] .chain = true := by decide
def e2392699532510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2392699532510 : Closed e2392699532510 ∧ code e2392699532510 = 11188792554718 := by decide
theorem cert_e2392699532510 : check e2392699532510 [[],[.left],[]] .chain = true := by decide
def e2392699532526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392699532526 : Closed e2392699532526 ∧ code e2392699532526 = 11188792554734 := by decide
theorem cert_e2392699532526 : check e2392699532526 [[],[.left],[]] .chain = true := by decide
def e2392699532534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392699532534 : Closed e2392699532534 ∧ code e2392699532534 = 11188792554742 := by decide
theorem cert_e2392699532534 : check e2392699532534 [[],[.left],[]] .chain = true := by decide
def e2392699532538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2392699532538 : Closed e2392699532538 ∧ code e2392699532538 = 11188792554746 := by decide
theorem cert_e2392699532538 : check e2392699532538 [[],[.left],[]] .chain = true := by decide
def e2392699532910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392699532910 : Closed e2392699532910 ∧ code e2392699532910 = 11188792555118 := by decide
theorem cert_e2392699532910 : check e2392699532910 [[],[.left],[]] .chain = true := by decide
def e2392699532922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392699532922 : Closed e2392699532922 ∧ code e2392699532922 = 11188792555130 := by decide
theorem cert_e2392699532922 : check e2392699532922 [[],[.left],[]] .chain = true := by decide
def e2392699533110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392699533110 : Closed e2392699533110 ∧ code e2392699533110 = 11188792555318 := by decide
theorem cert_e2392699533110 : check e2392699533110 [[],[.left],[]] .chain = true := by decide
def e2392699533114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392699533114 : Closed e2392699533114 ∧ code e2392699533114 = 11188792555322 := by decide
theorem cert_e2392699533114 : check e2392699533114 [[],[.left],[]] .chain = true := by decide
def e2392699533210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392699533210 : Closed e2392699533210 ∧ code e2392699533210 = 11188792555418 := by decide
theorem cert_e2392699533210 : check e2392699533210 [[],[.left],[]] .chain = true := by decide
def e2392699533750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2392699533750 : Closed e2392699533750 ∧ code e2392699533750 = 11188792555958 := by decide
theorem cert_e2392699533750 : check e2392699533750 [[],[.left],[]] .chain = true := by decide
def e2392699533782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2392699533782 : Closed e2392699533782 ∧ code e2392699533782 = 11188792555990 := by decide
theorem cert_e2392699533782 : check e2392699533782 [[],[.left],[]] .chain = true := by decide
def e2392699533786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2392699533786 : Closed e2392699533786 ∧ code e2392699533786 = 11188792555994 := by decide
theorem cert_e2392699533786 : check e2392699533786 [[],[.left],[]] .chain = true := by decide
def e2392699533942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2392699533942 : Closed e2392699533942 ∧ code e2392699533942 = 11188792556150 := by decide
theorem cert_e2392699533942 : check e2392699533942 [[],[.left],[]] .chain = true := by decide
def e2392699534134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392699534134 : Closed e2392699534134 ∧ code e2392699534134 = 11188792556342 := by decide
theorem cert_e2392699534134 : check e2392699534134 [[],[.left],[]] .chain = true := by decide
def e2392699534138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392699534138 : Closed e2392699534138 ∧ code e2392699534138 = 11188792556346 := by decide
theorem cert_e2392699534138 : check e2392699534138 [[],[.left],[]] .chain = true := by decide
def e2392699534550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2392699534550 : Closed e2392699534550 ∧ code e2392699534550 = 11188792556758 := by decide
theorem cert_e2392699534550 : check e2392699534550 [[],[.left],[]] .chain = true := by decide
def e2392699534554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2392699534554 : Closed e2392699534554 ∧ code e2392699534554 = 11188792556762 := by decide
theorem cert_e2392699534554 : check e2392699534554 [[],[.left],[]] .chain = true := by decide
def e2392699534570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2392699534570 : Closed e2392699534570 ∧ code e2392699534570 = 11188792556778 := by decide
theorem cert_e2392699534570 : check e2392699534570 [[],[.left],[]] .chain = true := by decide
def e2392699534646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392699534646 : Closed e2392699534646 ∧ code e2392699534646 = 11188792556854 := by decide
theorem cert_e2392699534646 : check e2392699534646 [[],[.left],[]] .chain = true := by decide
def e2392699534650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392699534650 : Closed e2392699534650 ∧ code e2392699534650 = 11188792556858 := by decide
theorem cert_e2392699534650 : check e2392699534650 [[],[.left],[]] .chain = true := by decide
def e2392699534746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392699534746 : Closed e2392699534746 ∧ code e2392699534746 = 11188792556954 := by decide
theorem cert_e2392699534746 : check e2392699534746 [[],[.left],[]] .chain = true := by decide
def e2392699541214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2392699541214 : Closed e2392699541214 ∧ code e2392699541214 = 11188792563422 := by decide
theorem cert_e2392699541214 : check e2392699541214 [[],[.left],[]] .chain = true := by decide
def e2392699541238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2392699541238 : Closed e2392699541238 ∧ code e2392699541238 = 11188792563446 := by decide
theorem cert_e2392699541238 : check e2392699541238 [[],[.left],[]] .chain = true := by decide
def e2392699541342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2392699541342 : Closed e2392699541342 ∧ code e2392699541342 = 11188792563550 := by decide
theorem cert_e2392699541342 : check e2392699541342 [[],[.left],[]] .chain = true := by decide
def e2392699541358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2392699541358 : Closed e2392699541358 ∧ code e2392699541358 = 11188792563566 := by decide
theorem cert_e2392699541358 : check e2392699541358 [[],[.left],[]] .chain = true := by decide
def e2392699541366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2392699541366 : Closed e2392699541366 ∧ code e2392699541366 = 11188792563574 := by decide
theorem cert_e2392699541366 : check e2392699541366 [[],[.left],[]] .chain = true := by decide
def e2392699541370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2392699541370 : Closed e2392699541370 ∧ code e2392699541370 = 11188792563578 := by decide
theorem cert_e2392699541370 : check e2392699541370 [[],[.left],[]] .chain = true := by decide
def e2392699541430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2392699541430 : Closed e2392699541430 ∧ code e2392699541430 = 11188792563638 := by decide
theorem cert_e2392699541430 : check e2392699541430 [[],[.left],[]] .chain = true := by decide
def e2392699541462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2392699541462 : Closed e2392699541462 ∧ code e2392699541462 = 11188792563670 := by decide
theorem cert_e2392699541462 : check e2392699541462 [[],[.left],[]] .chain = true := by decide
def e2392699541466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2392699541466 : Closed e2392699541466 ∧ code e2392699541466 = 11188792563674 := by decide
theorem cert_e2392699541466 : check e2392699541466 [[],[.left],[]] .chain = true := by decide
def e2392699541982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2392699541982 : Closed e2392699541982 ∧ code e2392699541982 = 11188792564190 := by decide
theorem cert_e2392699541982 : check e2392699541982 [[],[.left],[]] .chain = true := by decide
def e2392699542006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2392699542006 : Closed e2392699542006 ∧ code e2392699542006 = 11188792564214 := by decide
theorem cert_e2392699542006 : check e2392699542006 [[],[.left],[]] .chain = true := by decide
def e2392699542750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392699542750 : Closed e2392699542750 ∧ code e2392699542750 = 11188792564958 := by decide
theorem cert_e2392699542750 : check e2392699542750 [[],[.left],[]] .chain = true := by decide
def e2392699542766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392699542766 : Closed e2392699542766 ∧ code e2392699542766 = 11188792564974 := by decide
theorem cert_e2392699542766 : check e2392699542766 [[],[.left],[]] .chain = true := by decide
def e2392699542774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392699542774 : Closed e2392699542774 ∧ code e2392699542774 = 11188792564982 := by decide
theorem cert_e2392699542774 : check e2392699542774 [[],[.left],[]] .chain = true := by decide
def e2392699542778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392699542778 : Closed e2392699542778 ∧ code e2392699542778 = 11188792564986 := by decide
theorem cert_e2392699542778 : check e2392699542778 [[],[.left],[]] .chain = true := by decide
def e2392699543158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2392699543158 : Closed e2392699543158 ∧ code e2392699543158 = 11188792565366 := by decide
theorem cert_e2392699543158 : check e2392699543158 [[],[.left],[]] .chain = true := by decide
def e2392699543350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392699543350 : Closed e2392699543350 ∧ code e2392699543350 = 11188792565558 := by decide
theorem cert_e2392699543350 : check e2392699543350 [[],[.left],[]] .chain = true := by decide
def e2392699543354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392699543354 : Closed e2392699543354 ∧ code e2392699543354 = 11188792565562 := by decide
theorem cert_e2392699543354 : check e2392699543354 [[],[.left],[]] .chain = true := by decide
def e2392699554654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2392699554654 : Closed e2392699554654 ∧ code e2392699554654 = 11188792576862 := by decide
theorem cert_e2392699554654 : check e2392699554654 [[],[.left],[]] .chain = true := by decide
def e2392699554670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392699554670 : Closed e2392699554670 ∧ code e2392699554670 = 11188792576878 := by decide
theorem cert_e2392699554670 : check e2392699554670 [[],[.left],[]] .chain = true := by decide
def e2392699554678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392699554678 : Closed e2392699554678 ∧ code e2392699554678 = 11188792576886 := by decide
theorem cert_e2392699554678 : check e2392699554678 [[],[.left],[]] .chain = true := by decide
def e2392699554682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2392699554682 : Closed e2392699554682 ∧ code e2392699554682 = 11188792576890 := by decide
theorem cert_e2392699554682 : check e2392699554682 [[],[.left],[]] .chain = true := by decide
def e2392699554734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392699554734 : Closed e2392699554734 ∧ code e2392699554734 = 11188792576942 := by decide
theorem cert_e2392699554734 : check e2392699554734 [[],[.left],[]] .chain = true := by decide
def e2392699554746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392699554746 : Closed e2392699554746 ∧ code e2392699554746 = 11188792576954 := by decide
theorem cert_e2392699554746 : check e2392699554746 [[],[.left],[]] .chain = true := by decide
def e2392699554774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392699554774 : Closed e2392699554774 ∧ code e2392699554774 = 11188792576982 := by decide
theorem cert_e2392699554774 : check e2392699554774 [[],[.left],[]] .chain = true := by decide
def e2392699554778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392699554778 : Closed e2392699554778 ∧ code e2392699554778 = 11188792576986 := by decide
theorem cert_e2392699554778 : check e2392699554778 [[],[.left],[]] .chain = true := by decide
def e2392699554794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2392699554794 : Closed e2392699554794 ∧ code e2392699554794 = 11188792577002 := by decide
theorem cert_e2392699554794 : check e2392699554794 [[],[.left],[]] .chain = true := by decide
def e2392699555038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392699555038 : Closed e2392699555038 ∧ code e2392699555038 = 11188792577246 := by decide
theorem cert_e2392699555038 : check e2392699555038 [[],[.left],[]] .chain = true := by decide
def e2392699555054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392699555054 : Closed e2392699555054 ∧ code e2392699555054 = 11188792577262 := by decide
theorem cert_e2392699555054 : check e2392699555054 [[],[.left],[]] .chain = true := by decide
def e2392699555062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392699555062 : Closed e2392699555062 ∧ code e2392699555062 = 11188792577270 := by decide
theorem cert_e2392699555062 : check e2392699555062 [[],[.left],[]] .chain = true := by decide
def e2392699555066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392699555066 : Closed e2392699555066 ∧ code e2392699555066 = 11188792577274 := by decide
theorem cert_e2392699555066 : check e2392699555066 [[],[.left],[]] .chain = true := by decide
def e2392699555438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392699555438 : Closed e2392699555438 ∧ code e2392699555438 = 11188792577646 := by decide
theorem cert_e2392699555438 : check e2392699555438 [[],[.left],[]] .chain = true := by decide
def e2392699555450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392699555450 : Closed e2392699555450 ∧ code e2392699555450 = 11188792577658 := by decide
theorem cert_e2392699555450 : check e2392699555450 [[],[.left],[]] .chain = true := by decide
def e2392699555638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392699555638 : Closed e2392699555638 ∧ code e2392699555638 = 11188792577846 := by decide
theorem cert_e2392699555638 : check e2392699555638 [[],[.left],[]] .chain = true := by decide
def e2392699555642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392699555642 : Closed e2392699555642 ∧ code e2392699555642 = 11188792577850 := by decide
theorem cert_e2392699555642 : check e2392699555642 [[],[.left],[]] .chain = true := by decide
def e2392699555738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392699555738 : Closed e2392699555738 ∧ code e2392699555738 = 11188792577946 := by decide
theorem cert_e2392699555738 : check e2392699555738 [[],[.left],[]] .chain = true := by decide
def e2392699561398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2392699561398 : Closed e2392699561398 ∧ code e2392699561398 = 11188792583606 := by decide
theorem cert_e2392699561398 : check e2392699561398 [[],[.left],[]] .chain = true := by decide
def e2392699561430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2392699561430 : Closed e2392699561430 ∧ code e2392699561430 = 11188792583638 := by decide
theorem cert_e2392699561430 : check e2392699561430 [[],[.left],[]] .chain = true := by decide
def e2392699561434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2392699561434 : Closed e2392699561434 ∧ code e2392699561434 = 11188792583642 := by decide
theorem cert_e2392699561434 : check e2392699561434 [[],[.left],[]] .chain = true := by decide
def e2392699561590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2392699561590 : Closed e2392699561590 ∧ code e2392699561590 = 11188792583798 := by decide
theorem cert_e2392699561590 : check e2392699561590 [[],[.left],[]] .chain = true := by decide
def e2392699561782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392699561782 : Closed e2392699561782 ∧ code e2392699561782 = 11188792583990 := by decide
theorem cert_e2392699561782 : check e2392699561782 [[],[.left],[]] .chain = true := by decide
def e2392699561786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392699561786 : Closed e2392699561786 ∧ code e2392699561786 = 11188792583994 := by decide
theorem cert_e2392699561786 : check e2392699561786 [[],[.left],[]] .chain = true := by decide
def e2392699564758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2392699564758 : Closed e2392699564758 ∧ code e2392699564758 = 11188792586966 := by decide
theorem cert_e2392699564758 : check e2392699564758 [[],[.left],[]] .chain = true := by decide
def e2392699564762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2392699564762 : Closed e2392699564762 ∧ code e2392699564762 = 11188792586970 := by decide
theorem cert_e2392699564762 : check e2392699564762 [[],[.left],[]] .chain = true := by decide
def e2392699564778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2392699564778 : Closed e2392699564778 ∧ code e2392699564778 = 11188792586986 := by decide
theorem cert_e2392699564778 : check e2392699564778 [[],[.left],[]] .chain = true := by decide
def e2392699564854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392699564854 : Closed e2392699564854 ∧ code e2392699564854 = 11188792587062 := by decide
theorem cert_e2392699564854 : check e2392699564854 [[],[.left],[]] .chain = true := by decide
def e2392699564858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392699564858 : Closed e2392699564858 ∧ code e2392699564858 = 11188792587066 := by decide
theorem cert_e2392699564858 : check e2392699564858 [[],[.left],[]] .chain = true := by decide
def e2392699564954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392699564954 : Closed e2392699564954 ∧ code e2392699564954 = 11188792587162 := by decide
theorem cert_e2392699564954 : check e2392699564954 [[],[.left],[]] .chain = true := by decide
def e2392699790190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2392699790190 : Closed e2392699790190 ∧ code e2392699790190 = 11188792812398 := by decide
theorem cert_e2392699790190 : check e2392699790190 [[],[.left],[]] .sourceHead = true := by decide
def e2392699790198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2392699790198 : Closed e2392699790198 ∧ code e2392699790198 = 11188792812406 := by decide
theorem cert_e2392699790198 : check e2392699790198 [[],[.left],[]] .sourceHead = true := by decide
def e2392699790254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2392699790254 : Closed e2392699790254 ∧ code e2392699790254 = 11188792812462 := by decide
theorem cert_e2392699790254 : check e2392699790254 [[],[.left],[]] .sourceHead = true := by decide
def e2392699790266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2392699790266 : Closed e2392699790266 ∧ code e2392699790266 = 11188792812474 := by decide
theorem cert_e2392699790266 : check e2392699790266 [[],[.left],[]] .sourceHead = true := by decide
def e2392699790294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2392699790294 : Closed e2392699790294 ∧ code e2392699790294 = 11188792812502 := by decide
theorem cert_e2392699790294 : check e2392699790294 [[],[.left],[]] .sourceHead = true := by decide
def e2392699790298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2392699790298 : Closed e2392699790298 ∧ code e2392699790298 = 11188792812506 := by decide
theorem cert_e2392699790298 : check e2392699790298 [[],[.left],[]] .sourceHead = true := by decide
def e2392699791598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2392699791598 : Closed e2392699791598 ∧ code e2392699791598 = 11188792813806 := by decide
theorem cert_e2392699791598 : check e2392699791598 [[],[.left],[]] .sourceHead = true := by decide
def e2392699791606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2392699791606 : Closed e2392699791606 ∧ code e2392699791606 = 11188792813814 := by decide
theorem cert_e2392699791606 : check e2392699791606 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2392699792158 : Closed e2392699792158 ∧ code e2392699792158 = 11188792814366 := by decide
theorem cert_e2392699792158 : check e2392699792158 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2392699792270 : Closed e2392699792270 ∧ code e2392699792270 = 11188792814478 := by decide
theorem cert_e2392699792270 : check e2392699792270 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2392699792494 : Closed e2392699792494 ∧ code e2392699792494 = 11188792814702 := by decide
theorem cert_e2392699792494 : check e2392699792494 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2392699792506 : Closed e2392699792506 ∧ code e2392699792506 = 11188792814714 := by decide
theorem cert_e2392699792506 : check e2392699792506 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2392699792670 : Closed e2392699792670 ∧ code e2392699792670 = 11188792814878 := by decide
theorem cert_e2392699792670 : check e2392699792670 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2392699792838 : Closed e2392699792838 ∧ code e2392699792838 = 11188792815046 := by decide
theorem cert_e2392699792838 : check e2392699792838 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2392699792950 : Closed e2392699792950 ∧ code e2392699792950 = 11188792815158 := by decide
theorem cert_e2392699792950 : check e2392699792950 [[],[.left],[]] .sourceHead = true := by decide
def e2392699792954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2392699792954 : Closed e2392699792954 ∧ code e2392699792954 = 11188792815162 := by decide
theorem cert_e2392699792954 : check e2392699792954 [[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392578001774
#print axioms Blc.Floor43.cert_e2392578001782
#print axioms Blc.Floor43.cert_e2392578001838
#print axioms Blc.Floor43.cert_e2392578001850
#print axioms Blc.Floor43.cert_e2392578001878
#print axioms Blc.Floor43.cert_e2392578001882
#print axioms Blc.Floor43.cert_e2392578002158
#print axioms Blc.Floor43.cert_e2392578002166
#print axioms Blc.Floor43.cert_e2392578002542
#print axioms Blc.Floor43.cert_e2392578002554
#print axioms Blc.Floor43.cert_e2392578002742
#print axioms Blc.Floor43.cert_e2392578002746
#print axioms Blc.Floor43.cert_e2392578591674
#print axioms Blc.Floor43.cert_e2392578591706
