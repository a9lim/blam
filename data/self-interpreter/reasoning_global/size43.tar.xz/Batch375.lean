import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364427294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422364427294 : Closed e2422364427294 ∧ code e2422364427294 = 11218457449502 := by decide
theorem cert_e2422364427294 : check e2422364427294 [[],[]] .smaller = true := by decide
def e2422364427390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 5)))))))))
theorem wire_e2422364427390 : Closed e2422364427390 ∧ code e2422364427390 = 11218457449598 := by decide
theorem cert_e2422364427390 : check e2422364427390 [[],[]] .three = true := by decide
def e2422364427486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364427486 : Closed e2422364427486 ∧ code e2422364427486 = 11218457449694 := by decide
theorem cert_e2422364427486 : check e2422364427486 [[],[]] .smaller = true := by decide
def e2422364427490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422364427490 : Closed e2422364427490 ∧ code e2422364427490 = 11218457449698 := by decide
theorem cert_e2422364427490 : check e2422364427490 [[],[]] .smaller = true := by decide
def e2422364427502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364427502 : Closed e2422364427502 ∧ code e2422364427502 = 11218457449710 := by decide
theorem cert_e2422364427502 : check e2422364427502 [[],[]] .smaller = true := by decide
def e2422364427510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364427510 : Closed e2422364427510 ∧ code e2422364427510 = 11218457449718 := by decide
theorem cert_e2422364427510 : check e2422364427510 [[],[]] .smaller = true := by decide
def e2422364427514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364427514 : Closed e2422364427514 ∧ code e2422364427514 = 11218457449722 := by decide
theorem cert_e2422364427514 : check e2422364427514 [[],[]] .smaller = true := by decide
def e2422364427790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364427790 : Closed e2422364427790 ∧ code e2422364427790 = 11218457449998 := by decide
theorem cert_e2422364427790 : check e2422364427790 [[],[]] .smaller = true := by decide
def e2422364427802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364427802 : Closed e2422364427802 ∧ code e2422364427802 = 11218457450010 := by decide
theorem cert_e2422364427802 : check e2422364427802 [[],[]] .smaller = true := by decide
def e2422364427874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364427874 : Closed e2422364427874 ∧ code e2422364427874 = 11218457450082 := by decide
theorem cert_e2422364427874 : check e2422364427874 [[],[]] .smaller = true := by decide
def e2422364427886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364427886 : Closed e2422364427886 ∧ code e2422364427886 = 11218457450094 := by decide
theorem cert_e2422364427886 : check e2422364427886 [[],[]] .smaller = true := by decide
def e2422364427894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364427894 : Closed e2422364427894 ∧ code e2422364427894 = 11218457450102 := by decide
theorem cert_e2422364427894 : check e2422364427894 [[],[]] .smaller = true := by decide
def e2422364427898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364427898 : Closed e2422364427898 ∧ code e2422364427898 = 11218457450106 := by decide
theorem cert_e2422364427898 : check e2422364427898 [[],[]] .smaller = true := by decide
def e2422364428086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364428086 : Closed e2422364428086 ∧ code e2422364428086 = 11218457450294 := by decide
theorem cert_e2422364428086 : check e2422364428086 [[],[]] .smaller = true := by decide
def e2422364428090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364428090 : Closed e2422364428090 ∧ code e2422364428090 = 11218457450298 := by decide
theorem cert_e2422364428090 : check e2422364428090 [[],[]] .smaller = true := by decide
def e2422364428186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364428186 : Closed e2422364428186 ∧ code e2422364428186 = 11218457450394 := by decide
theorem cert_e2422364428186 : check e2422364428186 [[],[]] .smaller = true := by decide
def e2422364428230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 4)) (.lam (.var 1)))))))))
theorem wire_e2422364428230 : Closed e2422364428230 ∧ code e2422364428230 = 11218457450438 := by decide
theorem cert_e2422364428230 : check e2422364428230 [[],[]] .three = true := by decide
def e2422364428346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422364428346 : Closed e2422364428346 ∧ code e2422364428346 = 11218457450554 := by decide
theorem cert_e2422364428346 : check e2422364428346 [[],[]] .smaller = true := by decide
def e2422364428394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422364428394 : Closed e2422364428394 ∧ code e2422364428394 = 11218457450602 := by decide
theorem cert_e2422364428394 : check e2422364428394 [[],[]] .smaller = true := by decide
def e2422364428442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364428442 : Closed e2422364428442 ∧ code e2422364428442 = 11218457450650 := by decide
theorem cert_e2422364428442 : check e2422364428442 [[],[]] .smaller = true := by decide
def e2422364428486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422364428486 : Closed e2422364428486 ∧ code e2422364428486 = 11218457450694 := by decide
theorem cert_e2422364428486 : check e2422364428486 [[],[]] .smaller = true := by decide
def e2422364428682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364428682 : Closed e2422364428682 ∧ code e2422364428682 = 11218457450890 := by decide
theorem cert_e2422364428682 : check e2422364428682 [[],[]] .smaller = true := by decide
def e2422364428706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364428706 : Closed e2422364428706 ∧ code e2422364428706 = 11218457450914 := by decide
theorem cert_e2422364428706 : check e2422364428706 [[],[]] .smaller = true := by decide
def e2422364428718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422364428718 : Closed e2422364428718 ∧ code e2422364428718 = 11218457450926 := by decide
theorem cert_e2422364428718 : check e2422364428718 [[],[]] .smaller = true := by decide
def e2422364428726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2422364428726 : Closed e2422364428726 ∧ code e2422364428726 = 11218457450934 := by decide
theorem cert_e2422364428726 : check e2422364428726 [[],[]] .smaller = true := by decide
def e2422364428730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422364428730 : Closed e2422364428730 ∧ code e2422364428730 = 11218457450938 := by decide
theorem cert_e2422364428730 : check e2422364428730 [[],[]] .smaller = true := by decide
def e2422364428758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2422364428758 : Closed e2422364428758 ∧ code e2422364428758 = 11218457450966 := by decide
theorem cert_e2422364428758 : check e2422364428758 [[],[]] .smaller = true := by decide
def e2422364428762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2422364428762 : Closed e2422364428762 ∧ code e2422364428762 = 11218457450970 := by decide
theorem cert_e2422364428762 : check e2422364428762 [[],[]] .smaller = true := by decide
def e2422364428778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422364428778 : Closed e2422364428778 ∧ code e2422364428778 = 11218457450986 := by decide
theorem cert_e2422364428778 : check e2422364428778 [[],[]] .smaller = true := by decide
def e2422364428814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364428814 : Closed e2422364428814 ∧ code e2422364428814 = 11218457451022 := by decide
theorem cert_e2422364428814 : check e2422364428814 [[],[]] .smaller = true := by decide
def e2422364428826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364428826 : Closed e2422364428826 ∧ code e2422364428826 = 11218457451034 := by decide
theorem cert_e2422364428826 : check e2422364428826 [[],[]] .smaller = true := by decide
def e2422364428898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364428898 : Closed e2422364428898 ∧ code e2422364428898 = 11218457451106 := by decide
theorem cert_e2422364428898 : check e2422364428898 [[],[]] .smaller = true := by decide
def e2422364428910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364428910 : Closed e2422364428910 ∧ code e2422364428910 = 11218457451118 := by decide
theorem cert_e2422364428910 : check e2422364428910 [[],[]] .smaller = true := by decide
def e2422364428918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364428918 : Closed e2422364428918 ∧ code e2422364428918 = 11218457451126 := by decide
theorem cert_e2422364428918 : check e2422364428918 [[],[]] .smaller = true := by decide
def e2422364428922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364428922 : Closed e2422364428922 ∧ code e2422364428922 = 11218457451130 := by decide
theorem cert_e2422364428922 : check e2422364428922 [[],[]] .smaller = true := by decide
def e2422364429110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364429110 : Closed e2422364429110 ∧ code e2422364429110 = 11218457451318 := by decide
theorem cert_e2422364429110 : check e2422364429110 [[],[]] .smaller = true := by decide
def e2422364429114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364429114 : Closed e2422364429114 ∧ code e2422364429114 = 11218457451322 := by decide
theorem cert_e2422364429114 : check e2422364429114 [[],[]] .smaller = true := by decide
def e2422364429210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364429210 : Closed e2422364429210 ∧ code e2422364429210 = 11218457451418 := by decide
theorem cert_e2422364429210 : check e2422364429210 [[],[]] .smaller = true := by decide
def e2422364429246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 4))))))))
theorem wire_e2422364429246 : Closed e2422364429246 ∧ code e2422364429246 = 11218457451454 := by decide
theorem cert_e2422364429246 : check e2422364429246 [[],[]] .three = true := by decide
def e2422364429278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 3))))))))
theorem wire_e2422364429278 : Closed e2422364429278 ∧ code e2422364429278 = 11218457451486 := by decide
theorem cert_e2422364429278 : check e2422364429278 [[],[]] .smaller = true := by decide
def e2422364429294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 4)) (.var 2))))))))
theorem wire_e2422364429294 : Closed e2422364429294 ∧ code e2422364429294 = 11218457451502 := by decide
theorem cert_e2422364429294 : check e2422364429294 [[],[]] .three = true := by decide
def e2422364429526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422364429526 : Closed e2422364429526 ∧ code e2422364429526 = 11218457451734 := by decide
theorem cert_e2422364429526 : check e2422364429526 [[],[]] .smaller = true := by decide
def e2422364429530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422364429530 : Closed e2422364429530 ∧ code e2422364429530 = 11218457451738 := by decide
theorem cert_e2422364429530 : check e2422364429530 [[],[]] .smaller = true := by decide
def e2422364429546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422364429546 : Closed e2422364429546 ∧ code e2422364429546 = 11218457451754 := by decide
theorem cert_e2422364429546 : check e2422364429546 [[],[]] .smaller = true := by decide
def e2422364429622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364429622 : Closed e2422364429622 ∧ code e2422364429622 = 11218457451830 := by decide
theorem cert_e2422364429622 : check e2422364429622 [[],[]] .smaller = true := by decide
def e2422364429626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364429626 : Closed e2422364429626 ∧ code e2422364429626 = 11218457451834 := by decide
theorem cert_e2422364429626 : check e2422364429626 [[],[]] .smaller = true := by decide
def e2422364429722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364429722 : Closed e2422364429722 ∧ code e2422364429722 = 11218457451930 := by decide
theorem cert_e2422364429722 : check e2422364429722 [[],[]] .smaller = true := by decide
def e2422364429758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 4))))))))
theorem wire_e2422364429758 : Closed e2422364429758 ∧ code e2422364429758 = 11218457451966 := by decide
theorem cert_e2422364429758 : check e2422364429758 [[],[]] .three = true := by decide
def e2422364429814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 4)) (.var 1))))))))
theorem wire_e2422364429814 : Closed e2422364429814 ∧ code e2422364429814 = 11218457452022 := by decide
theorem cert_e2422364429814 : check e2422364429814 [[],[]] .three = true := by decide
def e2422364429930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422364429930 : Closed e2422364429930 ∧ code e2422364429930 = 11218457452138 := by decide
theorem cert_e2422364429930 : check e2422364429930 [[],[]] .smaller = true := by decide
def e2422364429978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364429978 : Closed e2422364429978 ∧ code e2422364429978 = 11218457452186 := by decide
theorem cert_e2422364429978 : check e2422364429978 [[],[]] .smaller = true := by decide
def e2422364430046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 3))))))))
theorem wire_e2422364430046 : Closed e2422364430046 ∧ code e2422364430046 = 11218457452254 := by decide
theorem cert_e2422364430046 : check e2422364430046 [[],[]] .smaller = true := by decide
def e2422364430070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 3)) (.var 1))))))))
theorem wire_e2422364430070 : Closed e2422364430070 ∧ code e2422364430070 = 11218457452278 := by decide
theorem cert_e2422364430070 : check e2422364430070 [[],[]] .smaller = true := by decide
def e2422364430106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422364430106 : Closed e2422364430106 ∧ code e2422364430106 = 11218457452314 := by decide
theorem cert_e2422364430106 : check e2422364430106 [[],[]] .three = true := by decide
def e2422364430150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422364430150 : Closed e2422364430150 ∧ code e2422364430150 = 11218457452358 := by decide
theorem cert_e2422364430150 : check e2422364430150 [[],[]] .three = true := by decide
def e2422364430190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 1)) (.var 2))))))))
theorem wire_e2422364430190 : Closed e2422364430190 ∧ code e2422364430190 = 11218457452398 := by decide
theorem cert_e2422364430190 : check e2422364430190 [[],[]] .three = true := by decide
def e2422364430198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 2)) (.var 1))))))))
theorem wire_e2422364430198 : Closed e2422364430198 ∧ code e2422364430198 = 11218457452406 := by decide
theorem cert_e2422364430198 : check e2422364430198 [[],[]] .three = true := by decide
def e2422364432046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422364432046 : Closed e2422364432046 ∧ code e2422364432046 = 11218457454254 := by decide
theorem cert_e2422364432046 : check e2422364432046 [[],[]] .smaller = true := by decide
def e2422364432054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e2422364432054 : Closed e2422364432054 ∧ code e2422364432054 = 11218457454262 := by decide
theorem cert_e2422364432054 : check e2422364432054 [[],[]] .smaller = true := by decide
def e2422364432058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422364432058 : Closed e2422364432058 ∧ code e2422364432058 = 11218457454266 := by decide
theorem cert_e2422364432058 : check e2422364432058 [[],[]] .smaller = true := by decide
def e2422364432086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422364432086 : Closed e2422364432086 ∧ code e2422364432086 = 11218457454294 := by decide
theorem cert_e2422364432086 : check e2422364432086 [[],[]] .smaller = true := by decide
def e2422364432090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422364432090 : Closed e2422364432090 ∧ code e2422364432090 = 11218457454298 := by decide
theorem cert_e2422364432090 : check e2422364432090 [[],[]] .smaller = true := by decide
def e2422364432106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422364432106 : Closed e2422364432106 ∧ code e2422364432106 = 11218457454314 := by decide
theorem cert_e2422364432106 : check e2422364432106 [[],[]] .smaller = true := by decide
def e2422364432214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422364432214 : Closed e2422364432214 ∧ code e2422364432214 = 11218457454422 := by decide
theorem cert_e2422364432214 : check e2422364432214 [[],[]] .smaller = true := by decide
def e2422364432218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422364432218 : Closed e2422364432218 ∧ code e2422364432218 = 11218457454426 := by decide
theorem cert_e2422364432218 : check e2422364432218 [[],[]] .smaller = true := by decide
def e2422364432234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422364432234 : Closed e2422364432234 ∧ code e2422364432234 = 11218457454442 := by decide
theorem cert_e2422364432234 : check e2422364432234 [[],[]] .smaller = true := by decide
def e2422364432298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422364432298 : Closed e2422364432298 ∧ code e2422364432298 = 11218457454506 := by decide
theorem cert_e2422364432298 : check e2422364432298 [[],[]] .smaller = true := by decide
def e2422364432814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422364432814 : Closed e2422364432814 ∧ code e2422364432814 = 11218457455022 := by decide
theorem cert_e2422364432814 : check e2422364432814 [[],[]] .smaller = true := by decide
def e2422364432822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2422364432822 : Closed e2422364432822 ∧ code e2422364432822 = 11218457455030 := by decide
theorem cert_e2422364432822 : check e2422364432822 [[],[]] .smaller = true := by decide
def e2422364432826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422364432826 : Closed e2422364432826 ∧ code e2422364432826 = 11218457455034 := by decide
theorem cert_e2422364432826 : check e2422364432826 [[],[]] .smaller = true := by decide
def e2422364432854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2422364432854 : Closed e2422364432854 ∧ code e2422364432854 = 11218457455062 := by decide
theorem cert_e2422364432854 : check e2422364432854 [[],[]] .smaller = true := by decide
def e2422364432858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2422364432858 : Closed e2422364432858 ∧ code e2422364432858 = 11218457455066 := by decide
theorem cert_e2422364432858 : check e2422364432858 [[],[]] .smaller = true := by decide
def e2422364432874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422364432874 : Closed e2422364432874 ∧ code e2422364432874 = 11218457455082 := by decide
theorem cert_e2422364432874 : check e2422364432874 [[],[]] .smaller = true := by decide
def e2422364433006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364433006 : Closed e2422364433006 ∧ code e2422364433006 = 11218457455214 := by decide
theorem cert_e2422364433006 : check e2422364433006 [[],[]] .smaller = true := by decide
def e2422364433014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364433014 : Closed e2422364433014 ∧ code e2422364433014 = 11218457455222 := by decide
theorem cert_e2422364433014 : check e2422364433014 [[],[]] .smaller = true := by decide
def e2422364433018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364433018 : Closed e2422364433018 ∧ code e2422364433018 = 11218457455226 := by decide
theorem cert_e2422364433018 : check e2422364433018 [[],[]] .smaller = true := by decide
def e2422364433206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364433206 : Closed e2422364433206 ∧ code e2422364433206 = 11218457455414 := by decide
theorem cert_e2422364433206 : check e2422364433206 [[],[]] .smaller = true := by decide
def e2422364433210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364433210 : Closed e2422364433210 ∧ code e2422364433210 = 11218457455418 := by decide
theorem cert_e2422364433210 : check e2422364433210 [[],[]] .smaller = true := by decide
def e2422364433306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364433306 : Closed e2422364433306 ∧ code e2422364433306 = 11218457455514 := by decide
theorem cert_e2422364433306 : check e2422364433306 [[],[]] .smaller = true := by decide
def e2422364433622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422364433622 : Closed e2422364433622 ∧ code e2422364433622 = 11218457455830 := by decide
theorem cert_e2422364433622 : check e2422364433622 [[],[]] .smaller = true := by decide
def e2422364433626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422364433626 : Closed e2422364433626 ∧ code e2422364433626 = 11218457455834 := by decide
theorem cert_e2422364433626 : check e2422364433626 [[],[]] .smaller = true := by decide
def e2422364433642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422364433642 : Closed e2422364433642 ∧ code e2422364433642 = 11218457455850 := by decide
theorem cert_e2422364433642 : check e2422364433642 [[],[]] .smaller = true := by decide
def e2422364433718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364433718 : Closed e2422364433718 ∧ code e2422364433718 = 11218457455926 := by decide
theorem cert_e2422364433718 : check e2422364433718 [[],[]] .smaller = true := by decide
def e2422364433722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364433722 : Closed e2422364433722 ∧ code e2422364433722 = 11218457455930 := by decide
theorem cert_e2422364433722 : check e2422364433722 [[],[]] .smaller = true := by decide
def e2422364433818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364433818 : Closed e2422364433818 ∧ code e2422364433818 = 11218457456026 := by decide
theorem cert_e2422364433818 : check e2422364433818 [[],[]] .smaller = true := by decide
def e2422364433854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 4))))))))
theorem wire_e2422364433854 : Closed e2422364433854 ∧ code e2422364433854 = 11218457456062 := by decide
theorem cert_e2422364433854 : check e2422364433854 [[],[]] .three = true := by decide
def e2422364433886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e2422364433886 : Closed e2422364433886 ∧ code e2422364433886 = 11218457456094 := by decide
theorem cert_e2422364433886 : check e2422364433886 [[],[]] .smaller = true := by decide
def e2422364433902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e2422364433902 : Closed e2422364433902 ∧ code e2422364433902 = 11218457456110 := by decide
theorem cert_e2422364433902 : check e2422364433902 [[],[]] .smaller = true := by decide
def e2422364433910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 4)) (.var 1))))))))
theorem wire_e2422364433910 : Closed e2422364433910 ∧ code e2422364433910 = 11218457456118 := by decide
theorem cert_e2422364433910 : check e2422364433910 [[],[]] .three = true := by decide
def e2422364434026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422364434026 : Closed e2422364434026 ∧ code e2422364434026 = 11218457456234 := by decide
theorem cert_e2422364434026 : check e2422364434026 [[],[]] .smaller = true := by decide
def e2422364434074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364434074 : Closed e2422364434074 ∧ code e2422364434074 = 11218457456282 := by decide
theorem cert_e2422364434074 : check e2422364434074 [[],[]] .smaller = true := by decide
def e2422364434142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e2422364434142 : Closed e2422364434142 ∧ code e2422364434142 = 11218457456350 := by decide
theorem cert_e2422364434142 : check e2422364434142 [[],[]] .smaller = true := by decide
def e2422364434166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e2422364434166 : Closed e2422364434166 ∧ code e2422364434166 = 11218457456374 := by decide
theorem cert_e2422364434166 : check e2422364434166 [[],[]] .smaller = true := by decide
def e2422364434286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e2422364434286 : Closed e2422364434286 ∧ code e2422364434286 = 11218457456494 := by decide
theorem cert_e2422364434286 : check e2422364434286 [[],[]] .smaller = true := by decide
def e2422364434294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e2422364434294 : Closed e2422364434294 ∧ code e2422364434294 = 11218457456502 := by decide
theorem cert_e2422364434294 : check e2422364434294 [[],[]] .smaller = true := by decide
def e2422364434358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 4)) (.var 1)) (.var 1))))))))
theorem wire_e2422364434358 : Closed e2422364434358 ∧ code e2422364434358 = 11218457456566 := by decide
theorem cert_e2422364434358 : check e2422364434358 [[],[]] .three = true := by decide
def e2422364434862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e2422364434862 : Closed e2422364434862 ∧ code e2422364434862 = 11218457457070 := by decide
theorem cert_e2422364434862 : check e2422364434862 [[],[]] .three = true := by decide
def e2422364434870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e2422364434870 : Closed e2422364434870 ∧ code e2422364434870 = 11218457457078 := by decide
theorem cert_e2422364434870 : check e2422364434870 [[],[]] .three = true := by decide
def e2422364434874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e2422364434874 : Closed e2422364434874 ∧ code e2422364434874 = 11218457457082 := by decide
theorem cert_e2422364434874 : check e2422364434874 [[],[]] .three = true := by decide
def e2422364434902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e2422364434902 : Closed e2422364434902 ∧ code e2422364434902 = 11218457457110 := by decide
theorem cert_e2422364434902 : check e2422364434902 [[],[]] .three = true := by decide
def e2422364434906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e2422364434906 : Closed e2422364434906 ∧ code e2422364434906 = 11218457457114 := by decide
theorem cert_e2422364434906 : check e2422364434906 [[],[]] .three = true := by decide
def e2422364434922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e2422364434922 : Closed e2422364434922 ∧ code e2422364434922 = 11218457457130 := by decide
theorem cert_e2422364434922 : check e2422364434922 [[],[]] .three = true := by decide
def e2422364435286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422364435286 : Closed e2422364435286 ∧ code e2422364435286 = 11218457457494 := by decide
theorem cert_e2422364435286 : check e2422364435286 [[],[]] .three = true := by decide
def e2422364435290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422364435290 : Closed e2422364435290 ∧ code e2422364435290 = 11218457457498 := by decide
theorem cert_e2422364435290 : check e2422364435290 [[],[]] .three = true := by decide
def e2422364435306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422364435306 : Closed e2422364435306 ∧ code e2422364435306 = 11218457457514 := by decide
theorem cert_e2422364435306 : check e2422364435306 [[],[]] .three = true := by decide
def e2422364435370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422364435370 : Closed e2422364435370 ∧ code e2422364435370 = 11218457457578 := by decide
theorem cert_e2422364435370 : check e2422364435370 [[],[]] .three = true := by decide
def e2422364435566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422364435566 : Closed e2422364435566 ∧ code e2422364435566 = 11218457457774 := by decide
theorem cert_e2422364435566 : check e2422364435566 [[],[]] .three = true := by decide
def e2422364435574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422364435574 : Closed e2422364435574 ∧ code e2422364435574 = 11218457457782 := by decide
theorem cert_e2422364435574 : check e2422364435574 [[],[]] .three = true := by decide
def e2422364435578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422364435578 : Closed e2422364435578 ∧ code e2422364435578 = 11218457457786 := by decide
theorem cert_e2422364435578 : check e2422364435578 [[],[]] .three = true := by decide
def e2422364435670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422364435670 : Closed e2422364435670 ∧ code e2422364435670 = 11218457457878 := by decide
theorem cert_e2422364435670 : check e2422364435670 [[],[]] .three = true := by decide
def e2422364435674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422364435674 : Closed e2422364435674 ∧ code e2422364435674 = 11218457457882 := by decide
theorem cert_e2422364435674 : check e2422364435674 [[],[]] .three = true := by decide
def e2422364435690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422364435690 : Closed e2422364435690 ∧ code e2422364435690 = 11218457457898 := by decide
theorem cert_e2422364435690 : check e2422364435690 [[],[]] .three = true := by decide
def e2422364435742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422364435742 : Closed e2422364435742 ∧ code e2422364435742 = 11218457457950 := by decide
theorem cert_e2422364435742 : check e2422364435742 [[],[]] .three = true := by decide
def e2422364435766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364435766 : Closed e2422364435766 ∧ code e2422364435766 = 11218457457974 := by decide
theorem cert_e2422364435766 : check e2422364435766 [[],[]] .three = true := by decide
def e2422364435770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364435770 : Closed e2422364435770 ∧ code e2422364435770 = 11218457457978 := by decide
theorem cert_e2422364435770 : check e2422364435770 [[],[]] .three = true := by decide
def e2422364435854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422364435854 : Closed e2422364435854 ∧ code e2422364435854 = 11218457458062 := by decide
theorem cert_e2422364435854 : check e2422364435854 [[],[]] .three = true := by decide
def e2422364435866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364435866 : Closed e2422364435866 ∧ code e2422364435866 = 11218457458074 := by decide
theorem cert_e2422364435866 : check e2422364435866 [[],[]] .three = true := by decide
def e2422364435902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e2422364435902 : Closed e2422364435902 ∧ code e2422364435902 = 11218457458110 := by decide
theorem cert_e2422364435902 : check e2422364435902 [[],[]] .three = true := by decide
def e2422364435910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422364435910 : Closed e2422364435910 ∧ code e2422364435910 = 11218457458118 := by decide
theorem cert_e2422364435910 : check e2422364435910 [[],[]] .three = true := by decide
def e2422364435958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e2422364435958 : Closed e2422364435958 ∧ code e2422364435958 = 11218457458166 := by decide
theorem cert_e2422364435958 : check e2422364435958 [[],[]] .three = true := by decide
def e2422364436022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422364436022 : Closed e2422364436022 ∧ code e2422364436022 = 11218457458230 := by decide
theorem cert_e2422364436022 : check e2422364436022 [[],[]] .three = true := by decide
def e2422364436026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422364436026 : Closed e2422364436026 ∧ code e2422364436026 = 11218457458234 := by decide
theorem cert_e2422364436026 : check e2422364436026 [[],[]] .three = true := by decide
def e2422364436074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422364436074 : Closed e2422364436074 ∧ code e2422364436074 = 11218457458282 := by decide
theorem cert_e2422364436074 : check e2422364436074 [[],[]] .three = true := by decide
def e2422364436110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422364436110 : Closed e2422364436110 ∧ code e2422364436110 = 11218457458318 := by decide
theorem cert_e2422364436110 : check e2422364436110 [[],[]] .three = true := by decide
def e2422364436122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364436122 : Closed e2422364436122 ∧ code e2422364436122 = 11218457458330 := by decide
theorem cert_e2422364436122 : check e2422364436122 [[],[]] .three = true := by decide
def e2422364436158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e2422364436158 : Closed e2422364436158 ∧ code e2422364436158 = 11218457458366 := by decide
theorem cert_e2422364436158 : check e2422364436158 [[],[]] .three = true := by decide
def e2422364436166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422364436166 : Closed e2422364436166 ∧ code e2422364436166 = 11218457458374 := by decide
theorem cert_e2422364436166 : check e2422364436166 [[],[]] .three = true := by decide
def e2422364436190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e2422364436190 : Closed e2422364436190 ∧ code e2422364436190 = 11218457458398 := by decide
theorem cert_e2422364436190 : check e2422364436190 [[],[]] .three = true := by decide
def e2422364436206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e2422364436206 : Closed e2422364436206 ∧ code e2422364436206 = 11218457458414 := by decide
theorem cert_e2422364436206 : check e2422364436206 [[],[]] .three = true := by decide
def e2422364436214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e2422364436214 : Closed e2422364436214 ∧ code e2422364436214 = 11218457458422 := by decide
theorem cert_e2422364436214 : check e2422364436214 [[],[]] .three = true := by decide
def e2422364436218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e2422364436218 : Closed e2422364436218 ∧ code e2422364436218 = 11218457458426 := by decide
theorem cert_e2422364436218 : check e2422364436218 [[],[]] .three = true := by decide
def e2422364436250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422364436250 : Closed e2422364436250 ∧ code e2422364436250 = 11218457458458 := by decide
theorem cert_e2422364436250 : check e2422364436250 [[],[]] .three = true := by decide
def e2422364436294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422364436294 : Closed e2422364436294 ∧ code e2422364436294 = 11218457458502 := by decide
theorem cert_e2422364436294 : check e2422364436294 [[],[]] .three = true := by decide
def e2422364436334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e2422364436334 : Closed e2422364436334 ∧ code e2422364436334 = 11218457458542 := by decide
theorem cert_e2422364436334 : check e2422364436334 [[],[]] .three = true := by decide
def e2422364436342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e2422364436342 : Closed e2422364436342 ∧ code e2422364436342 = 11218457458550 := by decide
theorem cert_e2422364436342 : check e2422364436342 [[],[]] .three = true := by decide
def e2422364436406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e2422364436406 : Closed e2422364436406 ∧ code e2422364436406 = 11218457458614 := by decide
theorem cert_e2422364436406 : check e2422364436406 [[],[]] .three = true := by decide
def e2422364436438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e2422364436438 : Closed e2422364436438 ∧ code e2422364436438 = 11218457458646 := by decide
private def t_e2422364436438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 4)) (.var 0)) (.var 1))))))))
theorem cert_e2422364436438 : ¬ IsSelfInterpreter e2422364436438 :=
  wSource (t := t_e2422364436438) (replay_sound (ps := []) (t := e2422364436438) (by decide)) (by decide)
def e2422364436442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e2422364436442 : Closed e2422364436442 ∧ code e2422364436442 = 11218457458650 := by decide
private def t_e2422364436442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 4)) (.var 1)) (.var 0))))))))
theorem cert_e2422364436442 : ¬ IsSelfInterpreter e2422364436442 :=
  wSource (t := t_e2422364436442) (replay_sound (ps := []) (t := e2422364436442) (by decide)) (by decide)
def e2422364445934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364445934 : Closed e2422364445934 ∧ code e2422364445934 = 11218457468142 := by decide
theorem cert_e2422364445934 : check e2422364445934 [[],[]] .smaller = true := by decide
def e2422364445942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364445942 : Closed e2422364445942 ∧ code e2422364445942 = 11218457468150 := by decide
theorem cert_e2422364445942 : check e2422364445942 [[],[]] .smaller = true := by decide
def e2422364446318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364446318 : Closed e2422364446318 ∧ code e2422364446318 = 11218457468526 := by decide
theorem cert_e2422364446318 : check e2422364446318 [[],[]] .smaller = true := by decide
def e2422364446330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364446330 : Closed e2422364446330 ∧ code e2422364446330 = 11218457468538 := by decide
theorem cert_e2422364446330 : check e2422364446330 [[],[]] .smaller = true := by decide
def e2422364446518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364446518 : Closed e2422364446518 ∧ code e2422364446518 = 11218457468726 := by decide
theorem cert_e2422364446518 : check e2422364446518 [[],[]] .smaller = true := by decide
def e2422364446522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364446522 : Closed e2422364446522 ∧ code e2422364446522 = 11218457468730 := by decide
theorem cert_e2422364446522 : check e2422364446522 [[],[]] .smaller = true := by decide
def e2422364450234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))))
theorem wire_e2422364450234 : Closed e2422364450234 ∧ code e2422364450234 = 11218457472442 := by decide
theorem cert_e2422364450234 : check e2422364450234 [[],[]] .smaller = true := by decide
def e2422364450266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))))
theorem wire_e2422364450266 : Closed e2422364450266 ∧ code e2422364450266 = 11218457472474 := by decide
theorem cert_e2422364450266 : check e2422364450266 [[],[]] .smaller = true := by decide
def e2422364450490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))))
theorem wire_e2422364450490 : Closed e2422364450490 ∧ code e2422364450490 = 11218457472698 := by decide
theorem cert_e2422364450490 : check e2422364450490 [[],[]] .smaller = true := by decide
def e2422364450538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))))
theorem wire_e2422364450538 : Closed e2422364450538 ∧ code e2422364450538 = 11218457472746 := by decide
theorem cert_e2422364450538 : check e2422364450538 [[],[]] .smaller = true := by decide
def e2422364450650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))))
theorem wire_e2422364450650 : Closed e2422364450650 ∧ code e2422364450650 = 11218457472858 := by decide
theorem cert_e2422364450650 : check e2422364450650 [[],[]] .smaller = true := by decide
def e2422364450666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))))
theorem wire_e2422364450666 : Closed e2422364450666 ∧ code e2422364450666 = 11218457472874 := by decide
theorem cert_e2422364450666 : check e2422364450666 [[],[]] .smaller = true := by decide
def e2422364451770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))))
theorem wire_e2422364451770 : Closed e2422364451770 ∧ code e2422364451770 = 11218457473978 := by decide
theorem cert_e2422364451770 : check e2422364451770 [[],[]] .smaller = true := by decide
def e2422364451802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))))
theorem wire_e2422364451802 : Closed e2422364451802 ∧ code e2422364451802 = 11218457474010 := by decide
theorem cert_e2422364451802 : check e2422364451802 [[],[]] .smaller = true := by decide
def e2422364452078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364452078 : Closed e2422364452078 ∧ code e2422364452078 = 11218457474286 := by decide
theorem cert_e2422364452078 : check e2422364452078 [[],[]] .smaller = true := by decide
def e2422364452086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364452086 : Closed e2422364452086 ∧ code e2422364452086 = 11218457474294 := by decide
theorem cert_e2422364452086 : check e2422364452086 [[],[]] .smaller = true := by decide
def e2422364453306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))))
theorem wire_e2422364453306 : Closed e2422364453306 ∧ code e2422364453306 = 11218457475514 := by decide
theorem cert_e2422364453306 : check e2422364453306 [[],[]] .smaller = true := by decide
def e2422364453354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))))
theorem wire_e2422364453354 : Closed e2422364453354 ∧ code e2422364453354 = 11218457475562 := by decide
theorem cert_e2422364453354 : check e2422364453354 [[],[]] .smaller = true := by decide
def e2422364453822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 4))))))))
theorem wire_e2422364453822 : Closed e2422364453822 ∧ code e2422364453822 = 11218457476030 := by decide
theorem cert_e2422364453822 : check e2422364453822 [[],[]] .three = true := by decide
def e2422364453854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 3))))))))
theorem wire_e2422364453854 : Closed e2422364453854 ∧ code e2422364453854 = 11218457476062 := by decide
theorem cert_e2422364453854 : check e2422364453854 [[],[]] .smaller = true := by decide
def e2422364453870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 4)))) (.var 2))))))))
theorem wire_e2422364453870 : Closed e2422364453870 ∧ code e2422364453870 = 11218457476078 := by decide
theorem cert_e2422364453870 : check e2422364453870 [[],[]] .smaller = true := by decide
def e2422364453878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 5)))) (.var 1))))))))
theorem wire_e2422364453878 : Closed e2422364453878 ∧ code e2422364453878 = 11218457476086 := by decide
theorem cert_e2422364453878 : check e2422364453878 [[],[]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422364436438
#print axioms Blc.Floor43.cert_e2422364436442
