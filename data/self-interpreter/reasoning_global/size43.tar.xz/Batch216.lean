import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392565412842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2392565412842 : Closed e2392565412842 ∧ code e2392565412842 = 11188658435050 := by decide
theorem cert_e2392565412842 : check e2392565412842 [[],[.left]] .chain = true := by decide
def e2392565413086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2392565413086 : Closed e2392565413086 ∧ code e2392565413086 = 11188658435294 := by decide
theorem cert_e2392565413086 : check e2392565413086 [[],[.left]] .chain = true := by decide
def e2392565413102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392565413102 : Closed e2392565413102 ∧ code e2392565413102 = 11188658435310 := by decide
theorem cert_e2392565413102 : check e2392565413102 [[],[.left]] .smaller = true := by decide
def e2392565413110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392565413110 : Closed e2392565413110 ∧ code e2392565413110 = 11188658435318 := by decide
theorem cert_e2392565413110 : check e2392565413110 [[],[.left]] .smaller = true := by decide
def e2392565413114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2392565413114 : Closed e2392565413114 ∧ code e2392565413114 = 11188658435322 := by decide
theorem cert_e2392565413114 : check e2392565413114 [[],[.left]] .chain = true := by decide
def e2392565413486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392565413486 : Closed e2392565413486 ∧ code e2392565413486 = 11188658435694 := by decide
theorem cert_e2392565413486 : check e2392565413486 [[],[.left]] .smaller = true := by decide
def e2392565413498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392565413498 : Closed e2392565413498 ∧ code e2392565413498 = 11188658435706 := by decide
theorem cert_e2392565413498 : check e2392565413498 [[],[.left]] .smaller = true := by decide
def e2392565413686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392565413686 : Closed e2392565413686 ∧ code e2392565413686 = 11188658435894 := by decide
theorem cert_e2392565413686 : check e2392565413686 [[],[.left]] .smaller = true := by decide
def e2392565413690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392565413690 : Closed e2392565413690 ∧ code e2392565413690 = 11188658435898 := by decide
theorem cert_e2392565413690 : check e2392565413690 [[],[.left]] .smaller = true := by decide
def e2392565413786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565413786 : Closed e2392565413786 ∧ code e2392565413786 = 11188658435994 := by decide
theorem cert_e2392565413786 : check e2392565413786 [[],[.left]] .chain = true := by decide
def e2392565414318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2392565414318 : Closed e2392565414318 ∧ code e2392565414318 = 11188658436526 := by decide
theorem cert_e2392565414318 : check e2392565414318 [[],[.left]] .chain = true := by decide
def e2392565414326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2392565414326 : Closed e2392565414326 ∧ code e2392565414326 = 11188658436534 := by decide
theorem cert_e2392565414326 : check e2392565414326 [[],[.left]] .chain = true := by decide
def e2392565414330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2392565414330 : Closed e2392565414330 ∧ code e2392565414330 = 11188658436538 := by decide
theorem cert_e2392565414330 : check e2392565414330 [[],[.left]] .chain = true := by decide
def e2392565414358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2392565414358 : Closed e2392565414358 ∧ code e2392565414358 = 11188658436566 := by decide
theorem cert_e2392565414358 : check e2392565414358 [[],[.left]] .chain = true := by decide
def e2392565414362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2392565414362 : Closed e2392565414362 ∧ code e2392565414362 = 11188658436570 := by decide
theorem cert_e2392565414362 : check e2392565414362 [[],[.left]] .chain = true := by decide
def e2392565414378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2392565414378 : Closed e2392565414378 ∧ code e2392565414378 = 11188658436586 := by decide
theorem cert_e2392565414378 : check e2392565414378 [[],[.left]] .chain = true := by decide
def e2392565414510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392565414510 : Closed e2392565414510 ∧ code e2392565414510 = 11188658436718 := by decide
theorem cert_e2392565414510 : check e2392565414510 [[],[.left]] .chain = true := by decide
def e2392565414518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2392565414518 : Closed e2392565414518 ∧ code e2392565414518 = 11188658436726 := by decide
theorem cert_e2392565414518 : check e2392565414518 [[],[.left]] .chain = true := by decide
def e2392565414522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392565414522 : Closed e2392565414522 ∧ code e2392565414522 = 11188658436730 := by decide
theorem cert_e2392565414522 : check e2392565414522 [[],[.left]] .chain = true := by decide
def e2392565414710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392565414710 : Closed e2392565414710 ∧ code e2392565414710 = 11188658436918 := by decide
theorem cert_e2392565414710 : check e2392565414710 [[],[.left]] .chain = true := by decide
def e2392565414714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392565414714 : Closed e2392565414714 ∧ code e2392565414714 = 11188658436922 := by decide
theorem cert_e2392565414714 : check e2392565414714 [[],[.left]] .chain = true := by decide
def e2392565414810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565414810 : Closed e2392565414810 ∧ code e2392565414810 = 11188658437018 := by decide
theorem cert_e2392565414810 : check e2392565414810 [[],[.left]] .chain = true := by decide
def e2392565418862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2392565418862 : Closed e2392565418862 ∧ code e2392565418862 = 11188658441070 := by decide
theorem cert_e2392565418862 : check e2392565418862 [[],[.left]] .smaller = true := by decide
def e2392565418870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2392565418870 : Closed e2392565418870 ∧ code e2392565418870 = 11188658441078 := by decide
theorem cert_e2392565418870 : check e2392565418870 [[],[.left]] .smaller = true := by decide
def e2392565418926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2392565418926 : Closed e2392565418926 ∧ code e2392565418926 = 11188658441134 := by decide
theorem cert_e2392565418926 : check e2392565418926 [[],[.left]] .smaller = true := by decide
def e2392565418938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2392565418938 : Closed e2392565418938 ∧ code e2392565418938 = 11188658441146 := by decide
theorem cert_e2392565418938 : check e2392565418938 [[],[.left]] .smaller = true := by decide
def e2392565418966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2392565418966 : Closed e2392565418966 ∧ code e2392565418966 = 11188658441174 := by decide
theorem cert_e2392565418966 : check e2392565418966 [[],[.left]] .smaller = true := by decide
def e2392565418970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2392565418970 : Closed e2392565418970 ∧ code e2392565418970 = 11188658441178 := by decide
theorem cert_e2392565418970 : check e2392565418970 [[],[.left]] .smaller = true := by decide
def e2392565419246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2392565419246 : Closed e2392565419246 ∧ code e2392565419246 = 11188658441454 := by decide
theorem cert_e2392565419246 : check e2392565419246 [[],[.left]] .smaller = true := by decide
def e2392565419254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2392565419254 : Closed e2392565419254 ∧ code e2392565419254 = 11188658441462 := by decide
theorem cert_e2392565419254 : check e2392565419254 [[],[.left]] .smaller = true := by decide
def e2392565419630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2392565419630 : Closed e2392565419630 ∧ code e2392565419630 = 11188658441838 := by decide
theorem cert_e2392565419630 : check e2392565419630 [[],[.left]] .smaller = true := by decide
def e2392565419642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2392565419642 : Closed e2392565419642 ∧ code e2392565419642 = 11188658441850 := by decide
theorem cert_e2392565419642 : check e2392565419642 [[],[.left]] .smaller = true := by decide
def e2392565419830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2392565419830 : Closed e2392565419830 ∧ code e2392565419830 = 11188658442038 := by decide
theorem cert_e2392565419830 : check e2392565419830 [[],[.left]] .smaller = true := by decide
def e2392565419834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2392565419834 : Closed e2392565419834 ∧ code e2392565419834 = 11188658442042 := by decide
theorem cert_e2392565419834 : check e2392565419834 [[],[.left]] .smaller = true := by decide
def e2392565427678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2392565427678 : Closed e2392565427678 ∧ code e2392565427678 = 11188658449886 := by decide
theorem cert_e2392565427678 : check e2392565427678 [[],[.left]] .chain = true := by decide
def e2392565427694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2392565427694 : Closed e2392565427694 ∧ code e2392565427694 = 11188658449902 := by decide
theorem cert_e2392565427694 : check e2392565427694 [[],[.left]] .chain = true := by decide
def e2392565427934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2392565427934 : Closed e2392565427934 ∧ code e2392565427934 = 11188658450142 := by decide
theorem cert_e2392565427934 : check e2392565427934 [[],[.left]] .chain = true := by decide
def e2392565427950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2392565427950 : Closed e2392565427950 ∧ code e2392565427950 = 11188658450158 := by decide
theorem cert_e2392565427950 : check e2392565427950 [[],[.left]] .smaller = true := by decide
def e2392565427958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2392565427958 : Closed e2392565427958 ∧ code e2392565427958 = 11188658450166 := by decide
theorem cert_e2392565427958 : check e2392565427958 [[],[.left]] .chain = true := by decide
def e2392565428062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2392565428062 : Closed e2392565428062 ∧ code e2392565428062 = 11188658450270 := by decide
theorem cert_e2392565428062 : check e2392565428062 [[],[.left]] .chain = true := by decide
def e2392565428078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2392565428078 : Closed e2392565428078 ∧ code e2392565428078 = 11188658450286 := by decide
theorem cert_e2392565428078 : check e2392565428078 [[],[.left]] .smaller = true := by decide
def e2392565428086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2392565428086 : Closed e2392565428086 ∧ code e2392565428086 = 11188658450294 := by decide
theorem cert_e2392565428086 : check e2392565428086 [[],[.left]] .smaller = true := by decide
def e2392565428090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2392565428090 : Closed e2392565428090 ∧ code e2392565428090 = 11188658450298 := by decide
theorem cert_e2392565428090 : check e2392565428090 [[],[.left]] .chain = true := by decide
def e2392565428142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2392565428142 : Closed e2392565428142 ∧ code e2392565428142 = 11188658450350 := by decide
theorem cert_e2392565428142 : check e2392565428142 [[],[.left]] .chain = true := by decide
def e2392565428150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2392565428150 : Closed e2392565428150 ∧ code e2392565428150 = 11188658450358 := by decide
theorem cert_e2392565428150 : check e2392565428150 [[],[.left]] .chain = true := by decide
def e2392565428154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2392565428154 : Closed e2392565428154 ∧ code e2392565428154 = 11188658450362 := by decide
theorem cert_e2392565428154 : check e2392565428154 [[],[.left]] .chain = true := by decide
def e2392565429214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2392565429214 : Closed e2392565429214 ∧ code e2392565429214 = 11188658451422 := by decide
theorem cert_e2392565429214 : check e2392565429214 [[],[.left]] .chain = true := by decide
def e2392565429230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2392565429230 : Closed e2392565429230 ∧ code e2392565429230 = 11188658451438 := by decide
theorem cert_e2392565429230 : check e2392565429230 [[],[.left]] .chain = true := by decide
def e2392565430750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2392565430750 : Closed e2392565430750 ∧ code e2392565430750 = 11188658452958 := by decide
theorem cert_e2392565430750 : check e2392565430750 [[],[.left]] .chain = true := by decide
def e2392565430766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2392565430766 : Closed e2392565430766 ∧ code e2392565430766 = 11188658452974 := by decide
theorem cert_e2392565430766 : check e2392565430766 [[],[.left]] .smaller = true := by decide
def e2392565430774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2392565430774 : Closed e2392565430774 ∧ code e2392565430774 = 11188658452982 := by decide
theorem cert_e2392565430774 : check e2392565430774 [[],[.left]] .chain = true := by decide
def e2392565431518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392565431518 : Closed e2392565431518 ∧ code e2392565431518 = 11188658453726 := by decide
theorem cert_e2392565431518 : check e2392565431518 [[],[.left]] .chain = true := by decide
def e2392565431534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392565431534 : Closed e2392565431534 ∧ code e2392565431534 = 11188658453742 := by decide
theorem cert_e2392565431534 : check e2392565431534 [[],[.left]] .smaller = true := by decide
def e2392565431542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392565431542 : Closed e2392565431542 ∧ code e2392565431542 = 11188658453750 := by decide
theorem cert_e2392565431542 : check e2392565431542 [[],[.left]] .smaller = true := by decide
def e2392565431546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392565431546 : Closed e2392565431546 ∧ code e2392565431546 = 11188658453754 := by decide
theorem cert_e2392565431546 : check e2392565431546 [[],[.left]] .chain = true := by decide
def e2392565431918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392565431918 : Closed e2392565431918 ∧ code e2392565431918 = 11188658454126 := by decide
theorem cert_e2392565431918 : check e2392565431918 [[],[.left]] .chain = true := by decide
def e2392565431926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2392565431926 : Closed e2392565431926 ∧ code e2392565431926 = 11188658454134 := by decide
theorem cert_e2392565431926 : check e2392565431926 [[],[.left]] .chain = true := by decide
def e2392565431930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392565431930 : Closed e2392565431930 ∧ code e2392565431930 = 11188658454138 := by decide
theorem cert_e2392565431930 : check e2392565431930 [[],[.left]] .chain = true := by decide
def e2392565454558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2392565454558 : Closed e2392565454558 ∧ code e2392565454558 = 11188658476766 := by decide
theorem cert_e2392565454558 : check e2392565454558 [[],[.left]] .chain = true := by decide
def e2392565454574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2392565454574 : Closed e2392565454574 ∧ code e2392565454574 = 11188658476782 := by decide
theorem cert_e2392565454574 : check e2392565454574 [[],[.left]] .smaller = true := by decide
def e2392565454582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2392565454582 : Closed e2392565454582 ∧ code e2392565454582 = 11188658476790 := by decide
theorem cert_e2392565454582 : check e2392565454582 [[],[.left]] .chain = true := by decide
def e2392565454686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2392565454686 : Closed e2392565454686 ∧ code e2392565454686 = 11188658476894 := by decide
theorem cert_e2392565454686 : check e2392565454686 [[],[.left]] .chain = true := by decide
def e2392565454714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2392565454714 : Closed e2392565454714 ∧ code e2392565454714 = 11188658476922 := by decide
theorem cert_e2392565454714 : check e2392565454714 [[],[.left]] .chain = true := by decide
def e2392565454766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2392565454766 : Closed e2392565454766 ∧ code e2392565454766 = 11188658476974 := by decide
theorem cert_e2392565454766 : check e2392565454766 [[],[.left]] .smaller = true := by decide
def e2392565454778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2392565454778 : Closed e2392565454778 ∧ code e2392565454778 = 11188658476986 := by decide
theorem cert_e2392565454778 : check e2392565454778 [[],[.left]] .smaller = true := by decide
def e2392565454806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2392565454806 : Closed e2392565454806 ∧ code e2392565454806 = 11188658477014 := by decide
theorem cert_e2392565454806 : check e2392565454806 [[],[.left]] .chain = true := by decide
def e2392565454810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2392565454810 : Closed e2392565454810 ∧ code e2392565454810 = 11188658477018 := by decide
theorem cert_e2392565454810 : check e2392565454810 [[],[.left]] .chain = true := by decide
def e2392565455326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2392565455326 : Closed e2392565455326 ∧ code e2392565455326 = 11188658477534 := by decide
theorem cert_e2392565455326 : check e2392565455326 [[],[.left]] .chain = true := by decide
def e2392565455342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2392565455342 : Closed e2392565455342 ∧ code e2392565455342 = 11188658477550 := by decide
theorem cert_e2392565455342 : check e2392565455342 [[],[.left]] .smaller = true := by decide
def e2392565455350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2392565455350 : Closed e2392565455350 ∧ code e2392565455350 = 11188658477558 := by decide
theorem cert_e2392565455350 : check e2392565455350 [[],[.left]] .chain = true := by decide
def e2392565456094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392565456094 : Closed e2392565456094 ∧ code e2392565456094 = 11188658478302 := by decide
theorem cert_e2392565456094 : check e2392565456094 [[],[.left]] .chain = true := by decide
def e2392565456122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392565456122 : Closed e2392565456122 ∧ code e2392565456122 = 11188658478330 := by decide
theorem cert_e2392565456122 : check e2392565456122 [[],[.left]] .chain = true := by decide
def e2392565456494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392565456494 : Closed e2392565456494 ∧ code e2392565456494 = 11188658478702 := by decide
theorem cert_e2392565456494 : check e2392565456494 [[],[.left]] .smaller = true := by decide
def e2392565456506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392565456506 : Closed e2392565456506 ∧ code e2392565456506 = 11188658478714 := by decide
theorem cert_e2392565456506 : check e2392565456506 [[],[.left]] .smaller = true := by decide
def e2392565456694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392565456694 : Closed e2392565456694 ∧ code e2392565456694 = 11188658478902 := by decide
theorem cert_e2392565456694 : check e2392565456694 [[],[.left]] .chain = true := by decide
def e2392565456698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392565456698 : Closed e2392565456698 ∧ code e2392565456698 = 11188658478906 := by decide
theorem cert_e2392565456698 : check e2392565456698 [[],[.left]] .chain = true := by decide
def e2392565467998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2392565467998 : Closed e2392565467998 ∧ code e2392565467998 = 11188658490206 := by decide
theorem cert_e2392565467998 : check e2392565467998 [[],[.left]] .chain = true := by decide
def e2392565468014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392565468014 : Closed e2392565468014 ∧ code e2392565468014 = 11188658490222 := by decide
theorem cert_e2392565468014 : check e2392565468014 [[],[.left]] .smaller = true := by decide
def e2392565468022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392565468022 : Closed e2392565468022 ∧ code e2392565468022 = 11188658490230 := by decide
theorem cert_e2392565468022 : check e2392565468022 [[],[.left]] .smaller = true := by decide
def e2392565468026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2392565468026 : Closed e2392565468026 ∧ code e2392565468026 = 11188658490234 := by decide
theorem cert_e2392565468026 : check e2392565468026 [[],[.left]] .chain = true := by decide
def e2392565468078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392565468078 : Closed e2392565468078 ∧ code e2392565468078 = 11188658490286 := by decide
theorem cert_e2392565468078 : check e2392565468078 [[],[.left]] .smaller = true := by decide
def e2392565468090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392565468090 : Closed e2392565468090 ∧ code e2392565468090 = 11188658490298 := by decide
theorem cert_e2392565468090 : check e2392565468090 [[],[.left]] .smaller = true := by decide
def e2392565468118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392565468118 : Closed e2392565468118 ∧ code e2392565468118 = 11188658490326 := by decide
theorem cert_e2392565468118 : check e2392565468118 [[],[.left]] .smaller = true := by decide
def e2392565468122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392565468122 : Closed e2392565468122 ∧ code e2392565468122 = 11188658490330 := by decide
theorem cert_e2392565468122 : check e2392565468122 [[],[.left]] .smaller = true := by decide
def e2392565468138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2392565468138 : Closed e2392565468138 ∧ code e2392565468138 = 11188658490346 := by decide
theorem cert_e2392565468138 : check e2392565468138 [[],[.left]] .chain = true := by decide
def e2392565468382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392565468382 : Closed e2392565468382 ∧ code e2392565468382 = 11188658490590 := by decide
theorem cert_e2392565468382 : check e2392565468382 [[],[.left]] .chain = true := by decide
def e2392565468398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392565468398 : Closed e2392565468398 ∧ code e2392565468398 = 11188658490606 := by decide
theorem cert_e2392565468398 : check e2392565468398 [[],[.left]] .smaller = true := by decide
def e2392565468406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392565468406 : Closed e2392565468406 ∧ code e2392565468406 = 11188658490614 := by decide
theorem cert_e2392565468406 : check e2392565468406 [[],[.left]] .smaller = true := by decide
def e2392565468410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392565468410 : Closed e2392565468410 ∧ code e2392565468410 = 11188658490618 := by decide
theorem cert_e2392565468410 : check e2392565468410 [[],[.left]] .chain = true := by decide
def e2392565468782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392565468782 : Closed e2392565468782 ∧ code e2392565468782 = 11188658490990 := by decide
theorem cert_e2392565468782 : check e2392565468782 [[],[.left]] .smaller = true := by decide
def e2392565468794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392565468794 : Closed e2392565468794 ∧ code e2392565468794 = 11188658491002 := by decide
theorem cert_e2392565468794 : check e2392565468794 [[],[.left]] .smaller = true := by decide
def e2392565468982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392565468982 : Closed e2392565468982 ∧ code e2392565468982 = 11188658491190 := by decide
theorem cert_e2392565468982 : check e2392565468982 [[],[.left]] .smaller = true := by decide
def e2392565468986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392565468986 : Closed e2392565468986 ∧ code e2392565468986 = 11188658491194 := by decide
theorem cert_e2392565468986 : check e2392565468986 [[],[.left]] .smaller = true := by decide
def e2392565469082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392565469082 : Closed e2392565469082 ∧ code e2392565469082 = 11188658491290 := by decide
theorem cert_e2392565469082 : check e2392565469082 [[],[.left]] .chain = true := by decide
def e2392565474734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2392565474734 : Closed e2392565474734 ∧ code e2392565474734 = 11188658496942 := by decide
theorem cert_e2392565474734 : check e2392565474734 [[],[.left]] .chain = true := by decide
def e2392565474742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2392565474742 : Closed e2392565474742 ∧ code e2392565474742 = 11188658496950 := by decide
theorem cert_e2392565474742 : check e2392565474742 [[],[.left]] .chain = true := by decide
def e2392565474746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2392565474746 : Closed e2392565474746 ∧ code e2392565474746 = 11188658496954 := by decide
theorem cert_e2392565474746 : check e2392565474746 [[],[.left]] .chain = true := by decide
def e2392565474774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2392565474774 : Closed e2392565474774 ∧ code e2392565474774 = 11188658496982 := by decide
theorem cert_e2392565474774 : check e2392565474774 [[],[.left]] .chain = true := by decide
def e2392565474778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2392565474778 : Closed e2392565474778 ∧ code e2392565474778 = 11188658496986 := by decide
theorem cert_e2392565474778 : check e2392565474778 [[],[.left]] .chain = true := by decide
def e2392565474794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2392565474794 : Closed e2392565474794 ∧ code e2392565474794 = 11188658497002 := by decide
theorem cert_e2392565474794 : check e2392565474794 [[],[.left]] .chain = true := by decide
def e2392565474926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392565474926 : Closed e2392565474926 ∧ code e2392565474926 = 11188658497134 := by decide
theorem cert_e2392565474926 : check e2392565474926 [[],[.left]] .chain = true := by decide
def e2392565474934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2392565474934 : Closed e2392565474934 ∧ code e2392565474934 = 11188658497142 := by decide
theorem cert_e2392565474934 : check e2392565474934 [[],[.left]] .chain = true := by decide
def e2392565474938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392565474938 : Closed e2392565474938 ∧ code e2392565474938 = 11188658497146 := by decide
theorem cert_e2392565474938 : check e2392565474938 [[],[.left]] .chain = true := by decide
def e2392565475126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392565475126 : Closed e2392565475126 ∧ code e2392565475126 = 11188658497334 := by decide
theorem cert_e2392565475126 : check e2392565475126 [[],[.left]] .chain = true := by decide
def e2392565475130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392565475130 : Closed e2392565475130 ∧ code e2392565475130 = 11188658497338 := by decide
theorem cert_e2392565475130 : check e2392565475130 [[],[.left]] .chain = true := by decide
def e2392565475226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392565475226 : Closed e2392565475226 ∧ code e2392565475226 = 11188658497434 := by decide
theorem cert_e2392565475226 : check e2392565475226 [[],[.left]] .chain = true := by decide
def e2392565921134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2392565921134 : Closed e2392565921134 ∧ code e2392565921134 = 11188658943342 := by decide
theorem cert_e2392565921134 : check e2392565921134 [[],[.left]] .chain = true := by decide
def e2392565921142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2392565921142 : Closed e2392565921142 ∧ code e2392565921142 = 11188658943350 := by decide
theorem cert_e2392565921142 : check e2392565921142 [[],[.left]] .chain = true := by decide
def e2392565921198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2392565921198 : Closed e2392565921198 ∧ code e2392565921198 = 11188658943406 := by decide
theorem cert_e2392565921198 : check e2392565921198 [[],[.left]] .chain = true := by decide
def e2392565921210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2392565921210 : Closed e2392565921210 ∧ code e2392565921210 = 11188658943418 := by decide
theorem cert_e2392565921210 : check e2392565921210 [[],[.left]] .chain = true := by decide
def e2392565921238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2392565921238 : Closed e2392565921238 ∧ code e2392565921238 = 11188658943446 := by decide
theorem cert_e2392565921238 : check e2392565921238 [[],[.left]] .chain = true := by decide
def e2392565921242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2392565921242 : Closed e2392565921242 ∧ code e2392565921242 = 11188658943450 := by decide
theorem cert_e2392565921242 : check e2392565921242 [[],[.left]] .chain = true := by decide
def e2392565921454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2392565921454 : Closed e2392565921454 ∧ code e2392565921454 = 11188658943662 := by decide
theorem cert_e2392565921454 : check e2392565921454 [[],[.left]] .chain = true := by decide
def e2392565921466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2392565921466 : Closed e2392565921466 ∧ code e2392565921466 = 11188658943674 := by decide
theorem cert_e2392565921466 : check e2392565921466 [[],[.left]] .chain = true := by decide
def e2392565921514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2392565921514 : Closed e2392565921514 ∧ code e2392565921514 = 11188658943722 := by decide
theorem cert_e2392565921514 : check e2392565921514 [[],[.left]] .chain = true := by decide
def e2392565921622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2392565921622 : Closed e2392565921622 ∧ code e2392565921622 = 11188658943830 := by decide
theorem cert_e2392565921622 : check e2392565921622 [[],[.left]] .chain = true := by decide
def e2392565921626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2392565921626 : Closed e2392565921626 ∧ code e2392565921626 = 11188658943834 := by decide
theorem cert_e2392565921626 : check e2392565921626 [[],[.left]] .chain = true := by decide
def e2392565921642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2392565921642 : Closed e2392565921642 ∧ code e2392565921642 = 11188658943850 := by decide
theorem cert_e2392565921642 : check e2392565921642 [[],[.left]] .chain = true := by decide
def e2392565922478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2392565922478 : Closed e2392565922478 ∧ code e2392565922478 = 11188658944686 := by decide
theorem cert_e2392565922478 : check e2392565922478 [[],[.left]] .chain = true := by decide
def e2392565922490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2392565922490 : Closed e2392565922490 ∧ code e2392565922490 = 11188658944698 := by decide
theorem cert_e2392565922490 : check e2392565922490 [[],[.left]] .chain = true := by decide
def e2392565922538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2392565922538 : Closed e2392565922538 ∧ code e2392565922538 = 11188658944746 := by decide
theorem cert_e2392565922538 : check e2392565922538 [[],[.left]] .chain = true := by decide
def e2392565922730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2392565922730 : Closed e2392565922730 ∧ code e2392565922730 = 11188658944938 := by decide
theorem cert_e2392565922730 : check e2392565922730 [[],[.left]] .chain = true := by decide
def e2392565923158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2392565923158 : Closed e2392565923158 ∧ code e2392565923158 = 11188658945366 := by decide
theorem cert_e2392565923158 : check e2392565923158 [[],[.left]] .chain = true := by decide
def e2392565923162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2392565923162 : Closed e2392565923162 ∧ code e2392565923162 = 11188658945370 := by decide
theorem cert_e2392565923162 : check e2392565923162 [[],[.left]] .chain = true := by decide
def e2392565923178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2392565923178 : Closed e2392565923178 ∧ code e2392565923178 = 11188658945386 := by decide
theorem cert_e2392565923178 : check e2392565923178 [[],[.left]] .chain = true := by decide
def e2392565923242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2392565923242 : Closed e2392565923242 ∧ code e2392565923242 = 11188658945450 := by decide
theorem cert_e2392565923242 : check e2392565923242 [[],[.left]] .chain = true := by decide
def e2392565925742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2392565925742 : Closed e2392565925742 ∧ code e2392565925742 = 11188658947950 := by decide
theorem cert_e2392565925742 : check e2392565925742 [[],[.left]] .chain = true := by decide
def e2392565925750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2392565925750 : Closed e2392565925750 ∧ code e2392565925750 = 11188658947958 := by decide
theorem cert_e2392565925750 : check e2392565925750 [[],[.left]] .chain = true := by decide
def e2392565925814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e2392565925814 : Closed e2392565925814 ∧ code e2392565925814 = 11188658948022 := by decide
theorem cert_e2392565925814 : check e2392565925814 [[],[.left]] .chain = true := by decide
def e2392565927278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2392565927278 : Closed e2392565927278 ∧ code e2392565927278 = 11188658949486 := by decide
theorem cert_e2392565927278 : check e2392565927278 [[],[.left]] .chain = true := by decide
def e2392565927286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2392565927286 : Closed e2392565927286 ∧ code e2392565927286 = 11188658949494 := by decide
theorem cert_e2392565927286 : check e2392565927286 [[],[.left]] .chain = true := by decide
def e2392565927342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2392565927342 : Closed e2392565927342 ∧ code e2392565927342 = 11188658949550 := by decide
theorem cert_e2392565927342 : check e2392565927342 [[],[.left]] .chain = true := by decide
def e2392565927354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2392565927354 : Closed e2392565927354 ∧ code e2392565927354 = 11188658949562 := by decide
theorem cert_e2392565927354 : check e2392565927354 [[],[.left]] .chain = true := by decide
def e2392565927382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2392565927382 : Closed e2392565927382 ∧ code e2392565927382 = 11188658949590 := by decide
theorem cert_e2392565927382 : check e2392565927382 [[],[.left]] .chain = true := by decide
def e2392565927386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2392565927386 : Closed e2392565927386 ∧ code e2392565927386 = 11188658949594 := by decide
theorem cert_e2392565927386 : check e2392565927386 [[],[.left]] .chain = true := by decide
def e2392565927598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2392565927598 : Closed e2392565927598 ∧ code e2392565927598 = 11188658949806 := by decide
theorem cert_e2392565927598 : check e2392565927598 [[],[.left]] .chain = true := by decide
def e2392565927610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2392565927610 : Closed e2392565927610 ∧ code e2392565927610 = 11188658949818 := by decide
theorem cert_e2392565927610 : check e2392565927610 [[],[.left]] .chain = true := by decide
def e2392565927658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2392565927658 : Closed e2392565927658 ∧ code e2392565927658 = 11188658949866 := by decide
theorem cert_e2392565927658 : check e2392565927658 [[],[.left]] .chain = true := by decide
def e2392565927766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2392565927766 : Closed e2392565927766 ∧ code e2392565927766 = 11188658949974 := by decide
theorem cert_e2392565927766 : check e2392565927766 [[],[.left]] .chain = true := by decide
def e2392565927770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2392565927770 : Closed e2392565927770 ∧ code e2392565927770 = 11188658949978 := by decide
theorem cert_e2392565927770 : check e2392565927770 [[],[.left]] .chain = true := by decide
def e2392565927786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2392565927786 : Closed e2392565927786 ∧ code e2392565927786 = 11188658949994 := by decide
theorem cert_e2392565927786 : check e2392565927786 [[],[.left]] .chain = true := by decide
def e2392565928814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2392565928814 : Closed e2392565928814 ∧ code e2392565928814 = 11188658951022 := by decide
theorem cert_e2392565928814 : check e2392565928814 [[],[.left]] .chain = true := by decide
def e2392565928822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2392565928822 : Closed e2392565928822 ∧ code e2392565928822 = 11188658951030 := by decide
theorem cert_e2392565928822 : check e2392565928822 [[],[.left]] .chain = true := by decide
def e2392565928878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2392565928878 : Closed e2392565928878 ∧ code e2392565928878 = 11188658951086 := by decide
theorem cert_e2392565928878 : check e2392565928878 [[],[.left]] .chain = true := by decide
def e2392565928890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2392565928890 : Closed e2392565928890 ∧ code e2392565928890 = 11188658951098 := by decide
theorem cert_e2392565928890 : check e2392565928890 [[],[.left]] .chain = true := by decide
def e2392565928918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2392565928918 : Closed e2392565928918 ∧ code e2392565928918 = 11188658951126 := by decide
theorem cert_e2392565928918 : check e2392565928918 [[],[.left]] .chain = true := by decide
def e2392565928922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2392565928922 : Closed e2392565928922 ∧ code e2392565928922 = 11188658951130 := by decide
theorem cert_e2392565928922 : check e2392565928922 [[],[.left]] .chain = true := by decide
def e2392565929198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392565929198 : Closed e2392565929198 ∧ code e2392565929198 = 11188658951406 := by decide
theorem cert_e2392565929198 : check e2392565929198 [[],[.left]] .chain = true := by decide
def e2392565929206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392565929206 : Closed e2392565929206 ∧ code e2392565929206 = 11188658951414 := by decide
theorem cert_e2392565929206 : check e2392565929206 [[],[.left]] .chain = true := by decide
def e2392565929582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392565929582 : Closed e2392565929582 ∧ code e2392565929582 = 11188658951790 := by decide
theorem cert_e2392565929582 : check e2392565929582 [[],[.left]] .chain = true := by decide
def e2392565929594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392565929594 : Closed e2392565929594 ∧ code e2392565929594 = 11188658951802 := by decide
theorem cert_e2392565929594 : check e2392565929594 [[],[.left]] .chain = true := by decide
def e2392565929782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565929782 : Closed e2392565929782 ∧ code e2392565929782 = 11188658951990 := by decide
theorem cert_e2392565929782 : check e2392565929782 [[],[.left]] .chain = true := by decide
def e2392565929786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565929786 : Closed e2392565929786 ∧ code e2392565929786 = 11188658951994 := by decide
theorem cert_e2392565929786 : check e2392565929786 [[],[.left]] .chain = true := by decide
def e2392565930222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2392565930222 : Closed e2392565930222 ∧ code e2392565930222 = 11188658952430 := by decide
theorem cert_e2392565930222 : check e2392565930222 [[],[.left]] .chain = true := by decide
def e2392565930230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2392565930230 : Closed e2392565930230 ∧ code e2392565930230 = 11188658952438 := by decide
theorem cert_e2392565930230 : check e2392565930230 [[],[.left]] .chain = true := by decide
def e2392565930414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2392565930414 : Closed e2392565930414 ∧ code e2392565930414 = 11188658952622 := by decide
theorem cert_e2392565930414 : check e2392565930414 [[],[.left]] .chain = true := by decide
def e2392565930426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2392565930426 : Closed e2392565930426 ∧ code e2392565930426 = 11188658952634 := by decide
theorem cert_e2392565930426 : check e2392565930426 [[],[.left]] .chain = true := by decide
def e2392565930474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2392565930474 : Closed e2392565930474 ∧ code e2392565930474 = 11188658952682 := by decide
theorem cert_e2392565930474 : check e2392565930474 [[],[.left]] .chain = true := by decide
def e2392565930606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392565930606 : Closed e2392565930606 ∧ code e2392565930606 = 11188658952814 := by decide
theorem cert_e2392565930606 : check e2392565930606 [[],[.left]] .chain = true := by decide
def e2392565930618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392565930618 : Closed e2392565930618 ∧ code e2392565930618 = 11188658952826 := by decide
theorem cert_e2392565930618 : check e2392565930618 [[],[.left]] .chain = true := by decide
end Blc.Floor43
