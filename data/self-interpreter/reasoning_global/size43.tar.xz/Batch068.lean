import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e758934908442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934908442 : Closed e758934908442 ∧ code e758934908442 = 9555027930650 := by decide
theorem cert_e758934908442 : check e758934908442 [] .sourceHead = true := by decide
def e758934911514 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934911514 : Closed e758934911514 ∧ code e758934911514 = 9555027933722 := by decide
theorem cert_e758934911514 : check e758934911514 [] .sourceHead = true := by decide
def e758934918682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934918682 : Closed e758934918682 ∧ code e758934918682 = 9555027940890 := by decide
theorem cert_e758934918682 : check e758934918682 [] .sourceHead = true := by decide
def e758934919706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934919706 : Closed e758934919706 ∧ code e758934919706 = 9555027941914 := by decide
theorem cert_e758934919706 : check e758934919706 [] .sourceHead = true := by decide
def e758934990362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934990362 : Closed e758934990362 ∧ code e758934990362 = 9555028012570 := by decide
theorem cert_e758934990362 : check e758934990362 [] .sourceHead = true := by decide
def e758934992410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934992410 : Closed e758934992410 ∧ code e758934992410 = 9555028014618 := by decide
theorem cert_e758934992410 : check e758934992410 [] .sourceHead = true := by decide
def e758935088666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758935088666 : Closed e758935088666 ∧ code e758935088666 = 9555028110874 := by decide
theorem cert_e758935088666 : check e758935088666 [] .sourceHead = true := by decide
def e758935091738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758935091738 : Closed e758935091738 ∧ code e758935091738 = 9555028113946 := by decide
theorem cert_e758935091738 : check e758935091738 [] .sourceHead = true := by decide
def e758935139866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758935139866 : Closed e758935139866 ∧ code e758935139866 = 9555028162074 := by decide
theorem cert_e758935139866 : check e758935139866 [] .sourceHead = true := by decide
def e758935140890 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758935140890 : Closed e758935140890 ∧ code e758935140890 = 9555028163098 := by decide
theorem cert_e758935140890 : check e758935140890 [] .sourceHead = true := by decide
def e758950964590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e758950964590 : Closed e758950964590 ∧ code e758950964590 = 9555043986798 := by decide
theorem cert_e758950964590 : check e758950964590 [] .sourceHead = true := by decide
def e758950964598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e758950964598 : Closed e758950964598 ∧ code e758950964598 = 9555043986806 := by decide
theorem cert_e758950964598 : check e758950964598 [] .sourceHead = true := by decide
def e758950964654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e758950964654 : Closed e758950964654 ∧ code e758950964654 = 9555043986862 := by decide
theorem cert_e758950964654 : check e758950964654 [] .sourceHead = true := by decide
def e758950964666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e758950964666 : Closed e758950964666 ∧ code e758950964666 = 9555043986874 := by decide
theorem cert_e758950964666 : check e758950964666 [] .sourceHead = true := by decide
def e758950964694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e758950964694 : Closed e758950964694 ∧ code e758950964694 = 9555043986902 := by decide
theorem cert_e758950964694 : check e758950964694 [] .sourceHead = true := by decide
def e758950964698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e758950964698 : Closed e758950964698 ∧ code e758950964698 = 9555043986906 := by decide
theorem cert_e758950964698 : check e758950964698 [] .sourceHead = true := by decide
def e758950964910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e758950964910 : Closed e758950964910 ∧ code e758950964910 = 9555043987118 := by decide
theorem cert_e758950964910 : check e758950964910 [] .sourceHead = true := by decide
def e758950964922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e758950964922 : Closed e758950964922 ∧ code e758950964922 = 9555043987130 := by decide
theorem cert_e758950964922 : check e758950964922 [] .sourceHead = true := by decide
def e758950964970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e758950964970 : Closed e758950964970 ∧ code e758950964970 = 9555043987178 := by decide
theorem cert_e758950964970 : check e758950964970 [] .sourceHead = true := by decide
def e758950965078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e758950965078 : Closed e758950965078 ∧ code e758950965078 = 9555043987286 := by decide
theorem cert_e758950965078 : check e758950965078 [] .sourceHead = true := by decide
def e758950965082 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e758950965082 : Closed e758950965082 ∧ code e758950965082 = 9555043987290 := by decide
theorem cert_e758950965082 : check e758950965082 [] .sourceHead = true := by decide
def e758950965098 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e758950965098 : Closed e758950965098 ∧ code e758950965098 = 9555043987306 := by decide
theorem cert_e758950965098 : check e758950965098 [] .sourceHead = true := by decide
def e758950966126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e758950966126 : Closed e758950966126 ∧ code e758950966126 = 9555043988334 := by decide
theorem cert_e758950966126 : check e758950966126 [] .sourceHead = true := by decide
def e758950966134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e758950966134 : Closed e758950966134 ∧ code e758950966134 = 9555043988342 := by decide
theorem cert_e758950966134 : check e758950966134 [] .sourceHead = true := by decide
def e758950966190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e758950966190 : Closed e758950966190 ∧ code e758950966190 = 9555043988398 := by decide
theorem cert_e758950966190 : check e758950966190 [] .sourceHead = true := by decide
def e758950966202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e758950966202 : Closed e758950966202 ∧ code e758950966202 = 9555043988410 := by decide
theorem cert_e758950966202 : check e758950966202 [] .sourceHead = true := by decide
def e758950966230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e758950966230 : Closed e758950966230 ∧ code e758950966230 = 9555043988438 := by decide
theorem cert_e758950966230 : check e758950966230 [] .sourceHead = true := by decide
def e758950966234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e758950966234 : Closed e758950966234 ∧ code e758950966234 = 9555043988442 := by decide
theorem cert_e758950966234 : check e758950966234 [] .sourceHead = true := by decide
def e758950966510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e758950966510 : Closed e758950966510 ∧ code e758950966510 = 9555043988718 := by decide
theorem cert_e758950966510 : check e758950966510 [] .sourceHead = true := by decide
def e758950966518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e758950966518 : Closed e758950966518 ∧ code e758950966518 = 9555043988726 := by decide
theorem cert_e758950966518 : check e758950966518 [] .sourceHead = true := by decide
def e758950966894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e758950966894 : Closed e758950966894 ∧ code e758950966894 = 9555043989102 := by decide
theorem cert_e758950966894 : check e758950966894 [] .sourceHead = true := by decide
def e758950966906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e758950966906 : Closed e758950966906 ∧ code e758950966906 = 9555043989114 := by decide
theorem cert_e758950966906 : check e758950966906 [] .sourceHead = true := by decide
def e758950967094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e758950967094 : Closed e758950967094 ∧ code e758950967094 = 9555043989302 := by decide
theorem cert_e758950967094 : check e758950967094 [] .sourceHead = true := by decide
def e758950967098 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e758950967098 : Closed e758950967098 ∧ code e758950967098 = 9555043989306 := by decide
theorem cert_e758950967098 : check e758950967098 [] .sourceHead = true := by decide
def e758950967726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e758950967726 : Closed e758950967726 ∧ code e758950967726 = 9555043989934 := by decide
theorem cert_e758950967726 : check e758950967726 [] .sourceHead = true := by decide
def e758950967738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e758950967738 : Closed e758950967738 ∧ code e758950967738 = 9555043989946 := by decide
theorem cert_e758950967738 : check e758950967738 [] .sourceHead = true := by decide
def e758950967786 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e758950967786 : Closed e758950967786 ∧ code e758950967786 = 9555043989994 := by decide
theorem cert_e758950967786 : check e758950967786 [] .sourceHead = true := by decide
def e758950967918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e758950967918 : Closed e758950967918 ∧ code e758950967918 = 9555043990126 := by decide
theorem cert_e758950967918 : check e758950967918 [] .sourceHead = true := by decide
def e758950967930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e758950967930 : Closed e758950967930 ∧ code e758950967930 = 9555043990138 := by decide
theorem cert_e758950967930 : check e758950967930 [] .sourceHead = true := by decide
def e758950968218 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e758950968218 : Closed e758950968218 ∧ code e758950968218 = 9555043990426 := by decide
theorem cert_e758950968218 : check e758950968218 [] .sourceHead = true := by decide
def e758950968534 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e758950968534 : Closed e758950968534 ∧ code e758950968534 = 9555043990742 := by decide
theorem cert_e758950968534 : check e758950968534 [] .sourceHead = true := by decide
def e758950968538 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e758950968538 : Closed e758950968538 ∧ code e758950968538 = 9555043990746 := by decide
theorem cert_e758950968538 : check e758950968538 [] .sourceHead = true := by decide
def e758950968554 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e758950968554 : Closed e758950968554 ∧ code e758950968554 = 9555043990762 := by decide
theorem cert_e758950968554 : check e758950968554 [] .sourceHead = true := by decide
def e758950968630 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e758950968630 : Closed e758950968630 ∧ code e758950968630 = 9555043990838 := by decide
theorem cert_e758950968630 : check e758950968630 [] .sourceHead = true := by decide
def e758950968634 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e758950968634 : Closed e758950968634 ∧ code e758950968634 = 9555043990842 := by decide
theorem cert_e758950968634 : check e758950968634 [] .sourceHead = true := by decide
def e758950968730 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e758950968730 : Closed e758950968730 ∧ code e758950968730 = 9555043990938 := by decide
theorem cert_e758950968730 : check e758950968730 [] .sourceHead = true := by decide
def e758950972270 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e758950972270 : Closed e758950972270 ∧ code e758950972270 = 9555043994478 := by decide
theorem cert_e758950972270 : check e758950972270 [] .sourceHead = true := by decide
def e758950972278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e758950972278 : Closed e758950972278 ∧ code e758950972278 = 9555043994486 := by decide
theorem cert_e758950972278 : check e758950972278 [] .sourceHead = true := by decide
def e758950972334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e758950972334 : Closed e758950972334 ∧ code e758950972334 = 9555043994542 := by decide
theorem cert_e758950972334 : check e758950972334 [] .sourceHead = true := by decide
def e758950972346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e758950972346 : Closed e758950972346 ∧ code e758950972346 = 9555043994554 := by decide
theorem cert_e758950972346 : check e758950972346 [] .sourceHead = true := by decide
def e758950972374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e758950972374 : Closed e758950972374 ∧ code e758950972374 = 9555043994582 := by decide
theorem cert_e758950972374 : check e758950972374 [] .sourceHead = true := by decide
def e758950972378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e758950972378 : Closed e758950972378 ∧ code e758950972378 = 9555043994586 := by decide
theorem cert_e758950972378 : check e758950972378 [] .sourceHead = true := by decide
def e758950972654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e758950972654 : Closed e758950972654 ∧ code e758950972654 = 9555043994862 := by decide
theorem cert_e758950972654 : check e758950972654 [] .sourceHead = true := by decide
def e758950972662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e758950972662 : Closed e758950972662 ∧ code e758950972662 = 9555043994870 := by decide
theorem cert_e758950972662 : check e758950972662 [] .sourceHead = true := by decide
def e758950973038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e758950973038 : Closed e758950973038 ∧ code e758950973038 = 9555043995246 := by decide
theorem cert_e758950973038 : check e758950973038 [] .sourceHead = true := by decide
def e758950973050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e758950973050 : Closed e758950973050 ∧ code e758950973050 = 9555043995258 := by decide
theorem cert_e758950973050 : check e758950973050 [] .sourceHead = true := by decide
def e758950973238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e758950973238 : Closed e758950973238 ∧ code e758950973238 = 9555043995446 := by decide
theorem cert_e758950973238 : check e758950973238 [] .sourceHead = true := by decide
def e758950973242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e758950973242 : Closed e758950973242 ∧ code e758950973242 = 9555043995450 := by decide
theorem cert_e758950973242 : check e758950973242 [] .sourceHead = true := by decide
def e758950978990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e758950978990 : Closed e758950978990 ∧ code e758950978990 = 9555044001198 := by decide
theorem cert_e758950978990 : check e758950978990 [] .sourceHead = true := by decide
def e758950979002 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e758950979002 : Closed e758950979002 ∧ code e758950979002 = 9555044001210 := by decide
theorem cert_e758950979002 : check e758950979002 [] .sourceHead = true := by decide
def e758950979050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e758950979050 : Closed e758950979050 ∧ code e758950979050 = 9555044001258 := by decide
theorem cert_e758950979050 : check e758950979050 [] .sourceHead = true := by decide
def e758950979182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e758950979182 : Closed e758950979182 ∧ code e758950979182 = 9555044001390 := by decide
theorem cert_e758950979182 : check e758950979182 [] .sourceHead = true := by decide
def e758950979194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e758950979194 : Closed e758950979194 ∧ code e758950979194 = 9555044001402 := by decide
theorem cert_e758950979194 : check e758950979194 [] .sourceHead = true := by decide
def e758950979482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e758950979482 : Closed e758950979482 ∧ code e758950979482 = 9555044001690 := by decide
theorem cert_e758950979482 : check e758950979482 [] .sourceHead = true := by decide
def e758950982358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e758950982358 : Closed e758950982358 ∧ code e758950982358 = 9555044004566 := by decide
theorem cert_e758950982358 : check e758950982358 [] .sourceHead = true := by decide
def e758950982362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e758950982362 : Closed e758950982362 ∧ code e758950982362 = 9555044004570 := by decide
theorem cert_e758950982362 : check e758950982362 [] .sourceHead = true := by decide
def e758950982378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e758950982378 : Closed e758950982378 ∧ code e758950982378 = 9555044004586 := by decide
theorem cert_e758950982378 : check e758950982378 [] .sourceHead = true := by decide
def e758950982454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e758950982454 : Closed e758950982454 ∧ code e758950982454 = 9555044004662 := by decide
theorem cert_e758950982454 : check e758950982454 [] .sourceHead = true := by decide
def e758950982458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e758950982458 : Closed e758950982458 ∧ code e758950982458 = 9555044004666 := by decide
theorem cert_e758950982458 : check e758950982458 [] .sourceHead = true := by decide
def e758950982554 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e758950982554 : Closed e758950982554 ∧ code e758950982554 = 9555044004762 := by decide
theorem cert_e758950982554 : check e758950982554 [] .sourceHead = true := by decide
def e758951119726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e758951119726 : Closed e758951119726 ∧ code e758951119726 = 9555044141934 := by decide
theorem cert_e758951119726 : check e758951119726 [] .sourceHead = true := by decide
def e758951119734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e758951119734 : Closed e758951119734 ∧ code e758951119734 = 9555044141942 := by decide
theorem cert_e758951119734 : check e758951119734 [] .sourceHead = true := by decide
def e758951119790 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e758951119790 : Closed e758951119790 ∧ code e758951119790 = 9555044141998 := by decide
theorem cert_e758951119790 : check e758951119790 [] .sourceHead = true := by decide
def e758951119802 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e758951119802 : Closed e758951119802 ∧ code e758951119802 = 9555044142010 := by decide
theorem cert_e758951119802 : check e758951119802 [] .sourceHead = true := by decide
def e758951119830 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e758951119830 : Closed e758951119830 ∧ code e758951119830 = 9555044142038 := by decide
theorem cert_e758951119830 : check e758951119830 [] .sourceHead = true := by decide
def e758951119834 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e758951119834 : Closed e758951119834 ∧ code e758951119834 = 9555044142042 := by decide
theorem cert_e758951119834 : check e758951119834 [] .sourceHead = true := by decide
def e758951120110 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e758951120110 : Closed e758951120110 ∧ code e758951120110 = 9555044142318 := by decide
theorem cert_e758951120110 : check e758951120110 [] .sourceHead = true := by decide
def e758951120118 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e758951120118 : Closed e758951120118 ∧ code e758951120118 = 9555044142326 := by decide
theorem cert_e758951120118 : check e758951120118 [] .sourceHead = true := by decide
def e758951120494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e758951120494 : Closed e758951120494 ∧ code e758951120494 = 9555044142702 := by decide
theorem cert_e758951120494 : check e758951120494 [] .sourceHead = true := by decide
def e758951120506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e758951120506 : Closed e758951120506 ∧ code e758951120506 = 9555044142714 := by decide
theorem cert_e758951120506 : check e758951120506 [] .sourceHead = true := by decide
def e758951120694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e758951120694 : Closed e758951120694 ∧ code e758951120694 = 9555044142902 := by decide
theorem cert_e758951120694 : check e758951120694 [] .sourceHead = true := by decide
def e758951120698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e758951120698 : Closed e758951120698 ∧ code e758951120698 = 9555044142906 := by decide
theorem cert_e758951120698 : check e758951120698 [] .sourceHead = true := by decide
def e758951709550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e758951709550 : Closed e758951709550 ∧ code e758951709550 = 9555044731758 := by decide
theorem cert_e758951709550 : check e758951709550 [] .sourceHead = true := by decide
def e758951709558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e758951709558 : Closed e758951709558 ∧ code e758951709558 = 9555044731766 := by decide
theorem cert_e758951709558 : check e758951709558 [] .sourceHead = true := by decide
def e758951709614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e758951709614 : Closed e758951709614 ∧ code e758951709614 = 9555044731822 := by decide
theorem cert_e758951709614 : check e758951709614 [] .sourceHead = true := by decide
def e758951709626 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e758951709626 : Closed e758951709626 ∧ code e758951709626 = 9555044731834 := by decide
theorem cert_e758951709626 : check e758951709626 [] .sourceHead = true := by decide
def e758951709654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e758951709654 : Closed e758951709654 ∧ code e758951709654 = 9555044731862 := by decide
theorem cert_e758951709654 : check e758951709654 [] .sourceHead = true := by decide
def e758951709658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e758951709658 : Closed e758951709658 ∧ code e758951709658 = 9555044731866 := by decide
theorem cert_e758951709658 : check e758951709658 [] .sourceHead = true := by decide
def e758951709934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e758951709934 : Closed e758951709934 ∧ code e758951709934 = 9555044732142 := by decide
theorem cert_e758951709934 : check e758951709934 [] .sourceHead = true := by decide
def e758951709942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e758951709942 : Closed e758951709942 ∧ code e758951709942 = 9555044732150 := by decide
theorem cert_e758951709942 : check e758951709942 [] .sourceHead = true := by decide
def e758951710318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e758951710318 : Closed e758951710318 ∧ code e758951710318 = 9555044732526 := by decide
theorem cert_e758951710318 : check e758951710318 [] .sourceHead = true := by decide
def e758951710330 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e758951710330 : Closed e758951710330 ∧ code e758951710330 = 9555044732538 := by decide
theorem cert_e758951710330 : check e758951710330 [] .sourceHead = true := by decide
def e758951710518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e758951710518 : Closed e758951710518 ∧ code e758951710518 = 9555044732726 := by decide
theorem cert_e758951710518 : check e758951710518 [] .sourceHead = true := by decide
def e758951710522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e758951710522 : Closed e758951710522 ∧ code e758951710522 = 9555044732730 := by decide
theorem cert_e758951710522 : check e758951710522 [] .sourceHead = true := by decide
def e759138475546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138475546 : Closed e759138475546 ∧ code e759138475546 = 9555231497754 := by decide
theorem cert_e759138475546 : check e759138475546 [] .sourceHead = true := by decide
def e759138479642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138479642 : Closed e759138479642 ∧ code e759138479642 = 9555231501850 := by decide
theorem cert_e759138479642 : check e759138479642 [] .sourceHead = true := by decide
def e759138573850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138573850 : Closed e759138573850 ∧ code e759138573850 = 9555231596058 := by decide
theorem cert_e759138573850 : check e759138573850 [] .sourceHead = true := by decide
def e759138581018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138581018 : Closed e759138581018 ∧ code e759138581018 = 9555231603226 := by decide
theorem cert_e759138581018 : check e759138581018 [] .sourceHead = true := by decide
def e759138594330 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138594330 : Closed e759138594330 ∧ code e759138594330 = 9555231616538 := by decide
theorem cert_e759138594330 : check e759138594330 [] .sourceHead = true := by decide
def e759138597402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138597402 : Closed e759138597402 ∧ code e759138597402 = 9555231619610 := by decide
theorem cert_e759138597402 : check e759138597402 [] .sourceHead = true := by decide
def e759138868762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138868762 : Closed e759138868762 ∧ code e759138868762 = 9555231890970 := by decide
theorem cert_e759138868762 : check e759138868762 [] .sourceHead = true := by decide
def e759138872858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759138872858 : Closed e759138872858 ∧ code e759138872858 = 9555231895066 := by decide
theorem cert_e759138872858 : check e759138872858 [] .sourceHead = true := by decide
def e759139458586 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759139458586 : Closed e759139458586 ∧ code e759139458586 = 9555232480794 := by decide
theorem cert_e759139458586 : check e759139458586 [] .sourceHead = true := by decide
def e759139465754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759139465754 : Closed e759139465754 ∧ code e759139465754 = 9555232487962 := by decide
theorem cert_e759139465754 : check e759139465754 [] .sourceHead = true := by decide
def e759139560986 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759139560986 : Closed e759139560986 ∧ code e759139560986 = 9555232583194 := by decide
theorem cert_e759139560986 : check e759139560986 [] .sourceHead = true := by decide
def e759139564058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759139564058 : Closed e759139564058 ∧ code e759139564058 = 9555232586266 := by decide
theorem cert_e759139564058 : check e759139564058 [] .sourceHead = true := by decide
def e759146835482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146835482 : Closed e759146835482 ∧ code e759146835482 = 9555239857690 := by decide
theorem cert_e759146835482 : check e759146835482 [] .sourceHead = true := by decide
def e759146837530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146837530 : Closed e759146837530 ∧ code e759146837530 = 9555239859738 := by decide
theorem cert_e759146837530 : check e759146837530 [] .sourceHead = true := by decide
def e759146851866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146851866 : Closed e759146851866 ∧ code e759146851866 = 9555239874074 := by decide
theorem cert_e759146851866 : check e759146851866 [] .sourceHead = true := by decide
def e759146854938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146854938 : Closed e759146854938 ∧ code e759146854938 = 9555239877146 := by decide
theorem cert_e759146854938 : check e759146854938 [] .sourceHead = true := by decide
def e759146862106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146862106 : Closed e759146862106 ∧ code e759146862106 = 9555239884314 := by decide
theorem cert_e759146862106 : check e759146862106 [] .sourceHead = true := by decide
def e759146863130 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146863130 : Closed e759146863130 ∧ code e759146863130 = 9555239885338 := by decide
theorem cert_e759146863130 : check e759146863130 [] .sourceHead = true := by decide
def e759146917402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146917402 : Closed e759146917402 ∧ code e759146917402 = 9555239939610 := by decide
theorem cert_e759146917402 : check e759146917402 [] .sourceHead = true := by decide
def e759146920474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146920474 : Closed e759146920474 ∧ code e759146920474 = 9555239942682 := by decide
theorem cert_e759146920474 : check e759146920474 [] .sourceHead = true := by decide
def e759146932762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146932762 : Closed e759146932762 ∧ code e759146932762 = 9555239954970 := by decide
theorem cert_e759146932762 : check e759146932762 [] .sourceHead = true := by decide
def e759146960410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146960410 : Closed e759146960410 ∧ code e759146960410 = 9555239982618 := by decide
theorem cert_e759146960410 : check e759146960410 [] .sourceHead = true := by decide
def e759146961434 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146961434 : Closed e759146961434 ∧ code e759146961434 = 9555239983642 := by decide
theorem cert_e759146961434 : check e759146961434 [] .sourceHead = true := by decide
def e759146965530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759146965530 : Closed e759146965530 ∧ code e759146965530 = 9555239987738 := by decide
theorem cert_e759146965530 : check e759146965530 [] .sourceHead = true := by decide
def e759147228698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147228698 : Closed e759147228698 ∧ code e759147228698 = 9555240250906 := by decide
theorem cert_e759147228698 : check e759147228698 [] .sourceHead = true := by decide
def e759147230746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147230746 : Closed e759147230746 ∧ code e759147230746 = 9555240252954 := by decide
theorem cert_e759147230746 : check e759147230746 [] .sourceHead = true := by decide
def e759147245082 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147245082 : Closed e759147245082 ∧ code e759147245082 = 9555240267290 := by decide
theorem cert_e759147245082 : check e759147245082 [] .sourceHead = true := by decide
def e759147248154 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147248154 : Closed e759147248154 ∧ code e759147248154 = 9555240270362 := by decide
theorem cert_e759147248154 : check e759147248154 [] .sourceHead = true := by decide
def e759147255322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147255322 : Closed e759147255322 ∧ code e759147255322 = 9555240277530 := by decide
theorem cert_e759147255322 : check e759147255322 [] .sourceHead = true := by decide
def e759147256346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147256346 : Closed e759147256346 ∧ code e759147256346 = 9555240278554 := by decide
theorem cert_e759147256346 : check e759147256346 [] .sourceHead = true := by decide
def e759147327002 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147327002 : Closed e759147327002 ∧ code e759147327002 = 9555240349210 := by decide
theorem cert_e759147327002 : check e759147327002 [] .sourceHead = true := by decide
def e759147329050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147329050 : Closed e759147329050 ∧ code e759147329050 = 9555240351258 := by decide
theorem cert_e759147329050 : check e759147329050 [] .sourceHead = true := by decide
def e759147425306 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147425306 : Closed e759147425306 ∧ code e759147425306 = 9555240447514 := by decide
theorem cert_e759147425306 : check e759147425306 [] .sourceHead = true := by decide
def e759147428378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147428378 : Closed e759147428378 ∧ code e759147428378 = 9555240450586 := by decide
theorem cert_e759147428378 : check e759147428378 [] .sourceHead = true := by decide
def e759147454490 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759147454490 : Closed e759147454490 ∧ code e759147454490 = 9555240476698 := by decide
theorem cert_e759147454490 : check e759147454490 [] .sourceHead = true := by decide
def e759147454582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759147454582 : Closed e759147454582 ∧ code e759147454582 = 9555240476790 := by decide
theorem cert_e759147454582 : check e759147454582 [] .sourceHead = true := by decide
def e759147454826 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759147454826 : Closed e759147454826 ∧ code e759147454826 = 9555240477034 := by decide
theorem cert_e759147454826 : check e759147454826 [] .sourceHead = true := by decide
def e759147454874 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759147454874 : Closed e759147454874 ∧ code e759147454874 = 9555240477082 := by decide
theorem cert_e759147454874 : check e759147454874 [] .sourceHead = true := by decide
def e759147456026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759147456026 : Closed e759147456026 ∧ code e759147456026 = 9555240478234 := by decide
theorem cert_e759147456026 : check e759147456026 [] .sourceHead = true := by decide
def e759147476506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147476506 : Closed e759147476506 ∧ code e759147476506 = 9555240498714 := by decide
theorem cert_e759147476506 : check e759147476506 [] .sourceHead = true := by decide
def e759147477530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147477530 : Closed e759147477530 ∧ code e759147477530 = 9555240499738 := by decide
theorem cert_e759147477530 : check e759147477530 [] .sourceHead = true := by decide
def e759147487258 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759147487258 : Closed e759147487258 ∧ code e759147487258 = 9555240509466 := by decide
theorem cert_e759147487258 : check e759147487258 [] .sourceHead = true := by decide
def e759147487350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759147487350 : Closed e759147487350 ∧ code e759147487350 = 9555240509558 := by decide
theorem cert_e759147487350 : check e759147487350 [] .sourceHead = true := by decide
def e759147487594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759147487594 : Closed e759147487594 ∧ code e759147487594 = 9555240509802 := by decide
theorem cert_e759147487594 : check e759147487594 [] .sourceHead = true := by decide
def e759147487642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759147487642 : Closed e759147487642 ∧ code e759147487642 = 9555240509850 := by decide
theorem cert_e759147487642 : check e759147487642 [] .sourceHead = true := by decide
def e759147488794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759147488794 : Closed e759147488794 ∧ code e759147488794 = 9555240511002 := by decide
theorem cert_e759147488794 : check e759147488794 [] .sourceHead = true := by decide
def e759147638298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147638298 : Closed e759147638298 ∧ code e759147638298 = 9555240660506 := by decide
theorem cert_e759147638298 : check e759147638298 [] .sourceHead = true := by decide
def e759147641370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147641370 : Closed e759147641370 ∧ code e759147641370 = 9555240663578 := by decide
theorem cert_e759147641370 : check e759147641370 [] .sourceHead = true := by decide
def e759147653658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147653658 : Closed e759147653658 ∧ code e759147653658 = 9555240675866 := by decide
theorem cert_e759147653658 : check e759147653658 [] .sourceHead = true := by decide
def e759147687450 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147687450 : Closed e759147687450 ∧ code e759147687450 = 9555240709658 := by decide
theorem cert_e759147687450 : check e759147687450 [] .sourceHead = true := by decide
def e759147690522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147690522 : Closed e759147690522 ∧ code e759147690522 = 9555240712730 := by decide
theorem cert_e759147690522 : check e759147690522 [] .sourceHead = true := by decide
def e759147716634 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759147716634 : Closed e759147716634 ∧ code e759147716634 = 9555240738842 := by decide
theorem cert_e759147716634 : check e759147716634 [] .sourceHead = true := by decide
def e759147716726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759147716726 : Closed e759147716726 ∧ code e759147716726 = 9555240738934 := by decide
theorem cert_e759147716726 : check e759147716726 [] .sourceHead = true := by decide
def e759147716970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759147716970 : Closed e759147716970 ∧ code e759147716970 = 9555240739178 := by decide
theorem cert_e759147716970 : check e759147716970 [] .sourceHead = true := by decide
def e759147717018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759147717018 : Closed e759147717018 ∧ code e759147717018 = 9555240739226 := by decide
theorem cert_e759147717018 : check e759147717018 [] .sourceHead = true := by decide
def e759147718170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759147718170 : Closed e759147718170 ∧ code e759147718170 = 9555240740378 := by decide
theorem cert_e759147718170 : check e759147718170 [] .sourceHead = true := by decide
def e759147764250 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147764250 : Closed e759147764250 ∧ code e759147764250 = 9555240786458 := by decide
theorem cert_e759147764250 : check e759147764250 [] .sourceHead = true := by decide
def e759147765786 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759147765786 : Closed e759147765786 ∧ code e759147765786 = 9555240787994 := by decide
theorem cert_e759147765786 : check e759147765786 [] .sourceHead = true := by decide
def e759147765878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759147765878 : Closed e759147765878 ∧ code e759147765878 = 9555240788086 := by decide
theorem cert_e759147765878 : check e759147765878 [] .sourceHead = true := by decide
def e759147766122 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759147766122 : Closed e759147766122 ∧ code e759147766122 = 9555240788330 := by decide
theorem cert_e759147766122 : check e759147766122 [] .sourceHead = true := by decide
def e759147766170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759147766170 : Closed e759147766170 ∧ code e759147766170 = 9555240788378 := by decide
theorem cert_e759147766170 : check e759147766170 [] .sourceHead = true := by decide
def e759147767322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759147767322 : Closed e759147767322 ∧ code e759147767322 = 9555240789530 := by decide
theorem cert_e759147767322 : check e759147767322 [] .sourceHead = true := by decide
def e759147845146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147845146 : Closed e759147845146 ∧ code e759147845146 = 9555240867354 := by decide
theorem cert_e759147845146 : check e759147845146 [] .sourceHead = true := by decide
def e759147846170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147846170 : Closed e759147846170 ∧ code e759147846170 = 9555240868378 := by decide
theorem cert_e759147846170 : check e759147846170 [] .sourceHead = true := by decide
def e759147850266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147850266 : Closed e759147850266 ∧ code e759147850266 = 9555240872474 := by decide
theorem cert_e759147850266 : check e759147850266 [] .sourceHead = true := by decide
def e759147869722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147869722 : Closed e759147869722 ∧ code e759147869722 = 9555240891930 := by decide
theorem cert_e759147869722 : check e759147869722 [] .sourceHead = true := by decide
end Blc.Floor43
