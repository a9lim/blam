import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e825225169838 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e825225169838 : Closed e825225169838 ∧ code e825225169838 = 9621318192046 := by decide
theorem cert_e825225169838 : check e825225169838 [] .sourceHead = true := by decide
def e825225169850 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e825225169850 : Closed e825225169850 ∧ code e825225169850 = 9621318192058 := by decide
theorem cert_e825225169850 : check e825225169850 [] .sourceHead = true := by decide
def e825225169878 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e825225169878 : Closed e825225169878 ∧ code e825225169878 = 9621318192086 := by decide
theorem cert_e825225169878 : check e825225169878 [] .sourceHead = true := by decide
def e825225169882 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e825225169882 : Closed e825225169882 ∧ code e825225169882 = 9621318192090 := by decide
theorem cert_e825225169882 : check e825225169882 [] .sourceHead = true := by decide
def e825225170158 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e825225170158 : Closed e825225170158 ∧ code e825225170158 = 9621318192366 := by decide
theorem cert_e825225170158 : check e825225170158 [] .sourceHead = true := by decide
def e825225170166 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e825225170166 : Closed e825225170166 ∧ code e825225170166 = 9621318192374 := by decide
theorem cert_e825225170166 : check e825225170166 [] .sourceHead = true := by decide
def e825225170542 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e825225170542 : Closed e825225170542 ∧ code e825225170542 = 9621318192750 := by decide
theorem cert_e825225170542 : check e825225170542 [] .sourceHead = true := by decide
def e825225170554 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e825225170554 : Closed e825225170554 ∧ code e825225170554 = 9621318192762 := by decide
theorem cert_e825225170554 : check e825225170554 [] .sourceHead = true := by decide
def e825225170742 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e825225170742 : Closed e825225170742 ∧ code e825225170742 = 9621318192950 := by decide
theorem cert_e825225170742 : check e825225170742 [] .sourceHead = true := by decide
def e825225170746 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e825225170746 : Closed e825225170746 ∧ code e825225170746 = 9621318192954 := by decide
theorem cert_e825225170746 : check e825225170746 [] .sourceHead = true := by decide
def e825225176494 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e825225176494 : Closed e825225176494 ∧ code e825225176494 = 9621318198702 := by decide
theorem cert_e825225176494 : check e825225176494 [] .sourceHead = true := by decide
def e825225176506 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e825225176506 : Closed e825225176506 ∧ code e825225176506 = 9621318198714 := by decide
theorem cert_e825225176506 : check e825225176506 [] .sourceHead = true := by decide
def e825225176554 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e825225176554 : Closed e825225176554 ∧ code e825225176554 = 9621318198762 := by decide
theorem cert_e825225176554 : check e825225176554 [] .sourceHead = true := by decide
def e825225176686 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e825225176686 : Closed e825225176686 ∧ code e825225176686 = 9621318198894 := by decide
theorem cert_e825225176686 : check e825225176686 [] .sourceHead = true := by decide
def e825225176698 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e825225176698 : Closed e825225176698 ∧ code e825225176698 = 9621318198906 := by decide
theorem cert_e825225176698 : check e825225176698 [] .sourceHead = true := by decide
def e825225176986 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e825225176986 : Closed e825225176986 ∧ code e825225176986 = 9621318199194 := by decide
theorem cert_e825225176986 : check e825225176986 [] .sourceHead = true := by decide
def e825225179862 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e825225179862 : Closed e825225179862 ∧ code e825225179862 = 9621318202070 := by decide
theorem cert_e825225179862 : check e825225179862 [] .sourceHead = true := by decide
def e825225179866 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e825225179866 : Closed e825225179866 ∧ code e825225179866 = 9621318202074 := by decide
theorem cert_e825225179866 : check e825225179866 [] .sourceHead = true := by decide
def e825225179882 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e825225179882 : Closed e825225179882 ∧ code e825225179882 = 9621318202090 := by decide
theorem cert_e825225179882 : check e825225179882 [] .sourceHead = true := by decide
def e825225179958 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e825225179958 : Closed e825225179958 ∧ code e825225179958 = 9621318202166 := by decide
theorem cert_e825225179958 : check e825225179958 [] .sourceHead = true := by decide
def e825225179962 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e825225179962 : Closed e825225179962 ∧ code e825225179962 = 9621318202170 := by decide
theorem cert_e825225179962 : check e825225179962 [] .sourceHead = true := by decide
def e825225180058 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e825225180058 : Closed e825225180058 ∧ code e825225180058 = 9621318202266 := by decide
theorem cert_e825225180058 : check e825225180058 [] .sourceHead = true := by decide
def e825225295326 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e825225295326 : Closed e825225295326 ∧ code e825225295326 = 9621318317534 := by decide
theorem cert_e825225295326 : check e825225295326 [] .sourceHead = true := by decide
def e825225295342 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e825225295342 : Closed e825225295342 ∧ code e825225295342 = 9621318317550 := by decide
theorem cert_e825225295342 : check e825225295342 [] .sourceHead = true := by decide
def e825225295710 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e825225295710 : Closed e825225295710 ∧ code e825225295710 = 9621318317918 := by decide
theorem cert_e825225295710 : check e825225295710 [] .sourceHead = true := by decide
def e825225295738 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e825225295738 : Closed e825225295738 ∧ code e825225295738 = 9621318317946 := by decide
theorem cert_e825225295738 : check e825225295738 [] .sourceHead = true := by decide
def e825225295790 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e825225295790 : Closed e825225295790 ∧ code e825225295790 = 9621318317998 := by decide
theorem cert_e825225295790 : check e825225295790 [] .sourceHead = true := by decide
def e825225295802 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e825225295802 : Closed e825225295802 ∧ code e825225295802 = 9621318318010 := by decide
theorem cert_e825225295802 : check e825225295802 [] .sourceHead = true := by decide
def e825225297246 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e825225297246 : Closed e825225297246 ∧ code e825225297246 = 9621318319454 := by decide
theorem cert_e825225297246 : check e825225297246 [] .sourceHead = true := by decide
def e825225297274 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e825225297274 : Closed e825225297274 ∧ code e825225297274 = 9621318319482 := by decide
theorem cert_e825225297274 : check e825225297274 [] .sourceHead = true := by decide
def e825225297386 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e825225297386 : Closed e825225297386 ∧ code e825225297386 = 9621318319594 := by decide
theorem cert_e825225297386 : check e825225297386 [] .sourceHead = true := by decide
def e825225297582 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e825225297582 : Closed e825225297582 ∧ code e825225297582 = 9621318319790 := by decide
theorem cert_e825225297582 : check e825225297582 [] .sourceHead = true := by decide
def e825225297594 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e825225297594 : Closed e825225297594 ∧ code e825225297594 = 9621318319802 := by decide
theorem cert_e825225297594 : check e825225297594 [] .sourceHead = true := by decide
def e825225297642 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e825225297642 : Closed e825225297642 ∧ code e825225297642 = 9621318319850 := by decide
theorem cert_e825225297642 : check e825225297642 [] .sourceHead = true := by decide
def e825225301470 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e825225301470 : Closed e825225301470 ∧ code e825225301470 = 9621318323678 := by decide
theorem cert_e825225301470 : check e825225301470 [] .sourceHead = true := by decide
def e825225301486 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e825225301486 : Closed e825225301486 ∧ code e825225301486 = 9621318323694 := by decide
theorem cert_e825225301486 : check e825225301486 [] .sourceHead = true := by decide
def e825225301854 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e825225301854 : Closed e825225301854 ∧ code e825225301854 = 9621318324062 := by decide
theorem cert_e825225301854 : check e825225301854 [] .sourceHead = true := by decide
def e825225301882 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e825225301882 : Closed e825225301882 ∧ code e825225301882 = 9621318324090 := by decide
theorem cert_e825225301882 : check e825225301882 [] .sourceHead = true := by decide
def e825225301934 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e825225301934 : Closed e825225301934 ∧ code e825225301934 = 9621318324142 := by decide
theorem cert_e825225301934 : check e825225301934 [] .sourceHead = true := by decide
def e825225301946 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e825225301946 : Closed e825225301946 ∧ code e825225301946 = 9621318324154 := by decide
theorem cert_e825225301946 : check e825225301946 [] .sourceHead = true := by decide
def e825225303006 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e825225303006 : Closed e825225303006 ∧ code e825225303006 = 9621318325214 := by decide
theorem cert_e825225303006 : check e825225303006 [] .sourceHead = true := by decide
def e825225303022 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e825225303022 : Closed e825225303022 ∧ code e825225303022 = 9621318325230 := by decide
theorem cert_e825225303022 : check e825225303022 [] .sourceHead = true := by decide
def e825225305310 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e825225305310 : Closed e825225305310 ∧ code e825225305310 = 9621318327518 := by decide
theorem cert_e825225305310 : check e825225305310 [] .sourceHead = true := by decide
def e825225305338 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e825225305338 : Closed e825225305338 ∧ code e825225305338 = 9621318327546 := by decide
theorem cert_e825225305338 : check e825225305338 [] .sourceHead = true := by decide
def e825225305710 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e825225305710 : Closed e825225305710 ∧ code e825225305710 = 9621318327918 := by decide
theorem cert_e825225305710 : check e825225305710 [] .sourceHead = true := by decide
def e825225305722 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e825225305722 : Closed e825225305722 ∧ code e825225305722 = 9621318327930 := by decide
theorem cert_e825225305722 : check e825225305722 [] .sourceHead = true := by decide
def e825225311070 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e825225311070 : Closed e825225311070 ∧ code e825225311070 = 9621318333278 := by decide
theorem cert_e825225311070 : check e825225311070 [] .sourceHead = true := by decide
def e825225311098 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e825225311098 : Closed e825225311098 ∧ code e825225311098 = 9621318333306 := by decide
theorem cert_e825225311098 : check e825225311098 [] .sourceHead = true := by decide
def e825225311210 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e825225311210 : Closed e825225311210 ∧ code e825225311210 = 9621318333418 := by decide
theorem cert_e825225311210 : check e825225311210 [] .sourceHead = true := by decide
def e825225311454 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e825225311454 : Closed e825225311454 ∧ code e825225311454 = 9621318333662 := by decide
theorem cert_e825225311454 : check e825225311454 [] .sourceHead = true := by decide
def e825225311482 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e825225311482 : Closed e825225311482 ∧ code e825225311482 = 9621318333690 := by decide
theorem cert_e825225311482 : check e825225311482 [] .sourceHead = true := by decide
def e825225312154 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e825225312154 : Closed e825225312154 ∧ code e825225312154 = 9621318334362 := by decide
theorem cert_e825225312154 : check e825225312154 [] .sourceHead = true := by decide
def e825225312686 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e825225312686 : Closed e825225312686 ∧ code e825225312686 = 9621318334894 := by decide
theorem cert_e825225312686 : check e825225312686 [] .sourceHead = true := by decide
def e825225312698 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e825225312698 : Closed e825225312698 ∧ code e825225312698 = 9621318334906 := by decide
theorem cert_e825225312698 : check e825225312698 [] .sourceHead = true := by decide
def e825225312746 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e825225312746 : Closed e825225312746 ∧ code e825225312746 = 9621318334954 := by decide
theorem cert_e825225312746 : check e825225312746 [] .sourceHead = true := by decide
def e825225312878 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e825225312878 : Closed e825225312878 ∧ code e825225312878 = 9621318335086 := by decide
theorem cert_e825225312878 : check e825225312878 [] .sourceHead = true := by decide
def e825225312890 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e825225312890 : Closed e825225312890 ∧ code e825225312890 = 9621318335098 := by decide
theorem cert_e825225312890 : check e825225312890 [] .sourceHead = true := by decide
def e825225313178 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e825225313178 : Closed e825225313178 ∧ code e825225313178 = 9621318335386 := by decide
theorem cert_e825225313178 : check e825225313178 [] .sourceHead = true := by decide
def e825225317230 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e825225317230 : Closed e825225317230 ∧ code e825225317230 = 9621318339438 := by decide
theorem cert_e825225317230 : check e825225317230 [] .sourceHead = true := by decide
def e825225317238 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e825225317238 : Closed e825225317238 ∧ code e825225317238 = 9621318339446 := by decide
theorem cert_e825225317238 : check e825225317238 [] .sourceHead = true := by decide
def e825225317294 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e825225317294 : Closed e825225317294 ∧ code e825225317294 = 9621318339502 := by decide
theorem cert_e825225317294 : check e825225317294 [] .sourceHead = true := by decide
def e825225317306 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e825225317306 : Closed e825225317306 ∧ code e825225317306 = 9621318339514 := by decide
theorem cert_e825225317306 : check e825225317306 [] .sourceHead = true := by decide
def e825225317334 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e825225317334 : Closed e825225317334 ∧ code e825225317334 = 9621318339542 := by decide
theorem cert_e825225317334 : check e825225317334 [] .sourceHead = true := by decide
def e825225317338 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e825225317338 : Closed e825225317338 ∧ code e825225317338 = 9621318339546 := by decide
theorem cert_e825225317338 : check e825225317338 [] .sourceHead = true := by decide
def e825225317614 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e825225317614 : Closed e825225317614 ∧ code e825225317614 = 9621318339822 := by decide
theorem cert_e825225317614 : check e825225317614 [] .sourceHead = true := by decide
def e825225317622 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e825225317622 : Closed e825225317622 ∧ code e825225317622 = 9621318339830 := by decide
theorem cert_e825225317622 : check e825225317622 [] .sourceHead = true := by decide
def e825225317998 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e825225317998 : Closed e825225317998 ∧ code e825225317998 = 9621318340206 := by decide
theorem cert_e825225317998 : check e825225317998 [] .sourceHead = true := by decide
def e825225318010 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e825225318010 : Closed e825225318010 ∧ code e825225318010 = 9621318340218 := by decide
theorem cert_e825225318010 : check e825225318010 [] .sourceHead = true := by decide
def e825225318198 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e825225318198 : Closed e825225318198 ∧ code e825225318198 = 9621318340406 := by decide
theorem cert_e825225318198 : check e825225318198 [] .sourceHead = true := by decide
def e825225318202 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e825225318202 : Closed e825225318202 ∧ code e825225318202 = 9621318340410 := by decide
theorem cert_e825225318202 : check e825225318202 [] .sourceHead = true := by decide
def e825225326046 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e825225326046 : Closed e825225326046 ∧ code e825225326046 = 9621318348254 := by decide
theorem cert_e825225326046 : check e825225326046 [] .sourceHead = true := by decide
def e825225326062 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e825225326062 : Closed e825225326062 ∧ code e825225326062 = 9621318348270 := by decide
theorem cert_e825225326062 : check e825225326062 [] .sourceHead = true := by decide
def e825225326430 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e825225326430 : Closed e825225326430 ∧ code e825225326430 = 9621318348638 := by decide
theorem cert_e825225326430 : check e825225326430 [] .sourceHead = true := by decide
def e825225326458 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e825225326458 : Closed e825225326458 ∧ code e825225326458 = 9621318348666 := by decide
theorem cert_e825225326458 : check e825225326458 [] .sourceHead = true := by decide
def e825225326510 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e825225326510 : Closed e825225326510 ∧ code e825225326510 = 9621318348718 := by decide
theorem cert_e825225326510 : check e825225326510 [] .sourceHead = true := by decide
def e825225326522 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e825225326522 : Closed e825225326522 ∧ code e825225326522 = 9621318348730 := by decide
theorem cert_e825225326522 : check e825225326522 [] .sourceHead = true := by decide
def e825225327582 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e825225327582 : Closed e825225327582 ∧ code e825225327582 = 9621318349790 := by decide
theorem cert_e825225327582 : check e825225327582 [] .sourceHead = true := by decide
def e825225327598 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e825225327598 : Closed e825225327598 ∧ code e825225327598 = 9621318349806 := by decide
theorem cert_e825225327598 : check e825225327598 [] .sourceHead = true := by decide
def e825225329886 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e825225329886 : Closed e825225329886 ∧ code e825225329886 = 9621318352094 := by decide
theorem cert_e825225329886 : check e825225329886 [] .sourceHead = true := by decide
def e825225329914 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e825225329914 : Closed e825225329914 ∧ code e825225329914 = 9621318352122 := by decide
theorem cert_e825225329914 : check e825225329914 [] .sourceHead = true := by decide
def e825225330286 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e825225330286 : Closed e825225330286 ∧ code e825225330286 = 9621318352494 := by decide
theorem cert_e825225330286 : check e825225330286 [] .sourceHead = true := by decide
def e825225330298 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e825225330298 : Closed e825225330298 ∧ code e825225330298 = 9621318352506 := by decide
theorem cert_e825225330298 : check e825225330298 [] .sourceHead = true := by decide
def e825225366366 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e825225366366 : Closed e825225366366 ∧ code e825225366366 = 9621318388574 := by decide
theorem cert_e825225366366 : check e825225366366 [] .sourceHead = true := by decide
def e825225366394 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e825225366394 : Closed e825225366394 ∧ code e825225366394 = 9621318388602 := by decide
theorem cert_e825225366394 : check e825225366394 [] .sourceHead = true := by decide
def e825225366506 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e825225366506 : Closed e825225366506 ∧ code e825225366506 = 9621318388714 := by decide
theorem cert_e825225366506 : check e825225366506 [] .sourceHead = true := by decide
def e825225366750 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e825225366750 : Closed e825225366750 ∧ code e825225366750 = 9621318388958 := by decide
theorem cert_e825225366750 : check e825225366750 [] .sourceHead = true := by decide
def e825225366778 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e825225366778 : Closed e825225366778 ∧ code e825225366778 = 9621318388986 := by decide
theorem cert_e825225366778 : check e825225366778 [] .sourceHead = true := by decide
def e825225367450 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e825225367450 : Closed e825225367450 ∧ code e825225367450 = 9621318389658 := by decide
theorem cert_e825225367450 : check e825225367450 [] .sourceHead = true := by decide
def e825225373102 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e825225373102 : Closed e825225373102 ∧ code e825225373102 = 9621318395310 := by decide
theorem cert_e825225373102 : check e825225373102 [] .sourceHead = true := by decide
def e825225373114 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e825225373114 : Closed e825225373114 ∧ code e825225373114 = 9621318395322 := by decide
theorem cert_e825225373114 : check e825225373114 [] .sourceHead = true := by decide
def e825225373162 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e825225373162 : Closed e825225373162 ∧ code e825225373162 = 9621318395370 := by decide
theorem cert_e825225373162 : check e825225373162 [] .sourceHead = true := by decide
def e825225373294 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e825225373294 : Closed e825225373294 ∧ code e825225373294 = 9621318395502 := by decide
theorem cert_e825225373294 : check e825225373294 [] .sourceHead = true := by decide
def e825225373306 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e825225373306 : Closed e825225373306 ∧ code e825225373306 = 9621318395514 := by decide
theorem cert_e825225373306 : check e825225373306 [] .sourceHead = true := by decide
def e825225373594 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e825225373594 : Closed e825225373594 ∧ code e825225373594 = 9621318395802 := by decide
theorem cert_e825225373594 : check e825225373594 [] .sourceHead = true := by decide
def e825230800922 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825230800922 : Closed e825230800922 ∧ code e825230800922 = 9621323823130 := by decide
theorem cert_e825230800922 : check e825230800922 [] .sourceHead = true := by decide
def e825230813210 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825230813210 : Closed e825230813210 ∧ code e825230813210 = 9621323835418 := by decide
theorem cert_e825230813210 : check e825230813210 [] .sourceHead = true := by decide
def e825230862362 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825230862362 : Closed e825230862362 ∧ code e825230862362 = 9621323884570 := by decide
theorem cert_e825230862362 : check e825230862362 [] .sourceHead = true := by decide
def e825230997530 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825230997530 : Closed e825230997530 ∧ code e825230997530 = 9621324019738 := by decide
theorem cert_e825230997530 : check e825230997530 [] .sourceHead = true := by decide
def e825231009818 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825231009818 : Closed e825231009818 ∧ code e825231009818 = 9621324032026 := by decide
theorem cert_e825231009818 : check e825231009818 [] .sourceHead = true := by decide
def e825231304730 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825231304730 : Closed e825231304730 ∧ code e825231304730 = 9621324326938 := by decide
theorem cert_e825231304730 : check e825231304730 [] .sourceHead = true := by decide
def e825234249754 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825234249754 : Closed e825234249754 ∧ code e825234249754 = 9621327271962 := by decide
theorem cert_e825234249754 : check e825234249754 [] .sourceHead = true := by decide
def e825234253850 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825234253850 : Closed e825234253850 ∧ code e825234253850 = 9621327276058 := by decide
theorem cert_e825234253850 : check e825234253850 [] .sourceHead = true := by decide
def e825234270234 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825234270234 : Closed e825234270234 ∧ code e825234270234 = 9621327292442 := by decide
theorem cert_e825234270234 : check e825234270234 [] .sourceHead = true := by decide
def e825234348058 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825234348058 : Closed e825234348058 ∧ code e825234348058 = 9621327370266 := by decide
theorem cert_e825234348058 : check e825234348058 [] .sourceHead = true := by decide
def e825234352154 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825234352154 : Closed e825234352154 ∧ code e825234352154 = 9621327374362 := by decide
theorem cert_e825234352154 : check e825234352154 [] .sourceHead = true := by decide
def e825234450458 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825234450458 : Closed e825234450458 ∧ code e825234450458 = 9621327472666 := by decide
theorem cert_e825234450458 : check e825234450458 [] .sourceHead = true := by decide
def e826843114862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e826843114862 : Closed e826843114862 ∧ code e826843114862 = 9622936137070 := by decide
theorem cert_e826843114862 : check e826843114862 [] .sourceHead = true := by decide
def e826843114870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e826843114870 : Closed e826843114870 ∧ code e826843114870 = 9622936137078 := by decide
theorem cert_e826843114870 : check e826843114870 [] .sourceHead = true := by decide
def e826843114926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e826843114926 : Closed e826843114926 ∧ code e826843114926 = 9622936137134 := by decide
theorem cert_e826843114926 : check e826843114926 [] .sourceHead = true := by decide
def e826843114938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e826843114938 : Closed e826843114938 ∧ code e826843114938 = 9622936137146 := by decide
theorem cert_e826843114938 : check e826843114938 [] .sourceHead = true := by decide
def e826843114966 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e826843114966 : Closed e826843114966 ∧ code e826843114966 = 9622936137174 := by decide
theorem cert_e826843114966 : check e826843114966 [] .sourceHead = true := by decide
def e826843114970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e826843114970 : Closed e826843114970 ∧ code e826843114970 = 9622936137178 := by decide
theorem cert_e826843114970 : check e826843114970 [] .sourceHead = true := by decide
def e826843115182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e826843115182 : Closed e826843115182 ∧ code e826843115182 = 9622936137390 := by decide
theorem cert_e826843115182 : check e826843115182 [] .sourceHead = true := by decide
def e826843115194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e826843115194 : Closed e826843115194 ∧ code e826843115194 = 9622936137402 := by decide
theorem cert_e826843115194 : check e826843115194 [] .sourceHead = true := by decide
def e826843115242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e826843115242 : Closed e826843115242 ∧ code e826843115242 = 9622936137450 := by decide
theorem cert_e826843115242 : check e826843115242 [] .sourceHead = true := by decide
def e826843115350 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e826843115350 : Closed e826843115350 ∧ code e826843115350 = 9622936137558 := by decide
theorem cert_e826843115350 : check e826843115350 [] .sourceHead = true := by decide
def e826843115354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e826843115354 : Closed e826843115354 ∧ code e826843115354 = 9622936137562 := by decide
theorem cert_e826843115354 : check e826843115354 [] .sourceHead = true := by decide
def e826843115370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e826843115370 : Closed e826843115370 ∧ code e826843115370 = 9622936137578 := by decide
theorem cert_e826843115370 : check e826843115370 [] .sourceHead = true := by decide
def e826843116398 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e826843116398 : Closed e826843116398 ∧ code e826843116398 = 9622936138606 := by decide
theorem cert_e826843116398 : check e826843116398 [] .sourceHead = true := by decide
def e826843116406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e826843116406 : Closed e826843116406 ∧ code e826843116406 = 9622936138614 := by decide
theorem cert_e826843116406 : check e826843116406 [] .sourceHead = true := by decide
def e826843116462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e826843116462 : Closed e826843116462 ∧ code e826843116462 = 9622936138670 := by decide
theorem cert_e826843116462 : check e826843116462 [] .sourceHead = true := by decide
def e826843116474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e826843116474 : Closed e826843116474 ∧ code e826843116474 = 9622936138682 := by decide
theorem cert_e826843116474 : check e826843116474 [] .sourceHead = true := by decide
def e826843116502 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e826843116502 : Closed e826843116502 ∧ code e826843116502 = 9622936138710 := by decide
theorem cert_e826843116502 : check e826843116502 [] .sourceHead = true := by decide
def e826843116506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e826843116506 : Closed e826843116506 ∧ code e826843116506 = 9622936138714 := by decide
theorem cert_e826843116506 : check e826843116506 [] .sourceHead = true := by decide
def e826843116782 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e826843116782 : Closed e826843116782 ∧ code e826843116782 = 9622936138990 := by decide
theorem cert_e826843116782 : check e826843116782 [] .sourceHead = true := by decide
def e826843116790 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e826843116790 : Closed e826843116790 ∧ code e826843116790 = 9622936138998 := by decide
theorem cert_e826843116790 : check e826843116790 [] .sourceHead = true := by decide
def e826843117166 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e826843117166 : Closed e826843117166 ∧ code e826843117166 = 9622936139374 := by decide
theorem cert_e826843117166 : check e826843117166 [] .sourceHead = true := by decide
def e826843117178 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e826843117178 : Closed e826843117178 ∧ code e826843117178 = 9622936139386 := by decide
theorem cert_e826843117178 : check e826843117178 [] .sourceHead = true := by decide
def e826843117366 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e826843117366 : Closed e826843117366 ∧ code e826843117366 = 9622936139574 := by decide
theorem cert_e826843117366 : check e826843117366 [] .sourceHead = true := by decide
def e826843117370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e826843117370 : Closed e826843117370 ∧ code e826843117370 = 9622936139578 := by decide
theorem cert_e826843117370 : check e826843117370 [] .sourceHead = true := by decide
def e826843117998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e826843117998 : Closed e826843117998 ∧ code e826843117998 = 9622936140206 := by decide
theorem cert_e826843117998 : check e826843117998 [] .sourceHead = true := by decide
def e826843118010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e826843118010 : Closed e826843118010 ∧ code e826843118010 = 9622936140218 := by decide
theorem cert_e826843118010 : check e826843118010 [] .sourceHead = true := by decide
def e826843118058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e826843118058 : Closed e826843118058 ∧ code e826843118058 = 9622936140266 := by decide
theorem cert_e826843118058 : check e826843118058 [] .sourceHead = true := by decide
def e826843118190 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e826843118190 : Closed e826843118190 ∧ code e826843118190 = 9622936140398 := by decide
theorem cert_e826843118190 : check e826843118190 [] .sourceHead = true := by decide
def e826843118202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e826843118202 : Closed e826843118202 ∧ code e826843118202 = 9622936140410 := by decide
theorem cert_e826843118202 : check e826843118202 [] .sourceHead = true := by decide
def e826843118490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e826843118490 : Closed e826843118490 ∧ code e826843118490 = 9622936140698 := by decide
theorem cert_e826843118490 : check e826843118490 [] .sourceHead = true := by decide
def e826843118806 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e826843118806 : Closed e826843118806 ∧ code e826843118806 = 9622936141014 := by decide
theorem cert_e826843118806 : check e826843118806 [] .sourceHead = true := by decide
def e826843118810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e826843118810 : Closed e826843118810 ∧ code e826843118810 = 9622936141018 := by decide
theorem cert_e826843118810 : check e826843118810 [] .sourceHead = true := by decide
def e826843118826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e826843118826 : Closed e826843118826 ∧ code e826843118826 = 9622936141034 := by decide
theorem cert_e826843118826 : check e826843118826 [] .sourceHead = true := by decide
def e826843118902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e826843118902 : Closed e826843118902 ∧ code e826843118902 = 9622936141110 := by decide
theorem cert_e826843118902 : check e826843118902 [] .sourceHead = true := by decide
def e826843118906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e826843118906 : Closed e826843118906 ∧ code e826843118906 = 9622936141114 := by decide
theorem cert_e826843118906 : check e826843118906 [] .sourceHead = true := by decide
def e826843119002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e826843119002 : Closed e826843119002 ∧ code e826843119002 = 9622936141210 := by decide
theorem cert_e826843119002 : check e826843119002 [] .sourceHead = true := by decide
def e826843122542 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e826843122542 : Closed e826843122542 ∧ code e826843122542 = 9622936144750 := by decide
theorem cert_e826843122542 : check e826843122542 [] .sourceHead = true := by decide
def e826843122550 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e826843122550 : Closed e826843122550 ∧ code e826843122550 = 9622936144758 := by decide
theorem cert_e826843122550 : check e826843122550 [] .sourceHead = true := by decide
def e826843122606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e826843122606 : Closed e826843122606 ∧ code e826843122606 = 9622936144814 := by decide
theorem cert_e826843122606 : check e826843122606 [] .sourceHead = true := by decide
def e826843122618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e826843122618 : Closed e826843122618 ∧ code e826843122618 = 9622936144826 := by decide
theorem cert_e826843122618 : check e826843122618 [] .sourceHead = true := by decide
def e826843122646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e826843122646 : Closed e826843122646 ∧ code e826843122646 = 9622936144854 := by decide
theorem cert_e826843122646 : check e826843122646 [] .sourceHead = true := by decide
def e826843122650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e826843122650 : Closed e826843122650 ∧ code e826843122650 = 9622936144858 := by decide
theorem cert_e826843122650 : check e826843122650 [] .sourceHead = true := by decide
def e826843122926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e826843122926 : Closed e826843122926 ∧ code e826843122926 = 9622936145134 := by decide
theorem cert_e826843122926 : check e826843122926 [] .sourceHead = true := by decide
def e826843122934 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e826843122934 : Closed e826843122934 ∧ code e826843122934 = 9622936145142 := by decide
theorem cert_e826843122934 : check e826843122934 [] .sourceHead = true := by decide
def e826843123310 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e826843123310 : Closed e826843123310 ∧ code e826843123310 = 9622936145518 := by decide
theorem cert_e826843123310 : check e826843123310 [] .sourceHead = true := by decide
def e826843123322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e826843123322 : Closed e826843123322 ∧ code e826843123322 = 9622936145530 := by decide
theorem cert_e826843123322 : check e826843123322 [] .sourceHead = true := by decide
def e826843123510 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e826843123510 : Closed e826843123510 ∧ code e826843123510 = 9622936145718 := by decide
theorem cert_e826843123510 : check e826843123510 [] .sourceHead = true := by decide
def e826843123514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e826843123514 : Closed e826843123514 ∧ code e826843123514 = 9622936145722 := by decide
theorem cert_e826843123514 : check e826843123514 [] .sourceHead = true := by decide
def e826843129262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e826843129262 : Closed e826843129262 ∧ code e826843129262 = 9622936151470 := by decide
theorem cert_e826843129262 : check e826843129262 [] .sourceHead = true := by decide
def e826843129274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e826843129274 : Closed e826843129274 ∧ code e826843129274 = 9622936151482 := by decide
theorem cert_e826843129274 : check e826843129274 [] .sourceHead = true := by decide
def e826843129322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e826843129322 : Closed e826843129322 ∧ code e826843129322 = 9622936151530 := by decide
theorem cert_e826843129322 : check e826843129322 [] .sourceHead = true := by decide
def e826843129454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e826843129454 : Closed e826843129454 ∧ code e826843129454 = 9622936151662 := by decide
theorem cert_e826843129454 : check e826843129454 [] .sourceHead = true := by decide
def e826843129466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e826843129466 : Closed e826843129466 ∧ code e826843129466 = 9622936151674 := by decide
theorem cert_e826843129466 : check e826843129466 [] .sourceHead = true := by decide
def e826843129754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e826843129754 : Closed e826843129754 ∧ code e826843129754 = 9622936151962 := by decide
theorem cert_e826843129754 : check e826843129754 [] .sourceHead = true := by decide
end Blc.Floor43
