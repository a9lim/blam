import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407886574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 2)))) (.var 2))))))
theorem wire_e2422407886574 : Closed e2422407886574 ∧ code e2422407886574 = 11218500908782 := by decide
theorem cert_e2422407886574 : check e2422407886574 [[],[]] .chain = true := by decide
def e2422407886582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))) (.var 1))))))
theorem wire_e2422407886582 : Closed e2422407886582 ∧ code e2422407886582 = 11218500908790 := by decide
theorem cert_e2422407886582 : check e2422407886582 [[],[]] .chain = true := by decide
def e2422407886702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 1)))) (.var 2))))))
theorem wire_e2422407886702 : Closed e2422407886702 ∧ code e2422407886702 = 11218500908910 := by decide
theorem cert_e2422407886702 : check e2422407886702 [[],[]] .chain = true := by decide
def e2422407886714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3)))) (.var 0))))))
theorem wire_e2422407886714 : Closed e2422407886714 ∧ code e2422407886714 = 11218500908922 := by decide
theorem cert_e2422407886714 : check e2422407886714 [[],[]] .chain = true := by decide
def e2422407886730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407886730 : Closed e2422407886730 ∧ code e2422407886730 = 11218500908938 := by decide
theorem cert_e2422407886730 : check e2422407886730 [[],[]] .chain = true := by decide
def e2422407886766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))) (.var 2))))))
theorem wire_e2422407886766 : Closed e2422407886766 ∧ code e2422407886766 = 11218500908974 := by decide
theorem cert_e2422407886766 : check e2422407886766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407886774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))) (.var 1))))))
theorem wire_e2422407886774 : Closed e2422407886774 ∧ code e2422407886774 = 11218500908982 := by decide
theorem cert_e2422407886774 : check e2422407886774 [[],[]] .chain = true := by decide
def e2422407886778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 2)))) (.var 0))))))
theorem wire_e2422407886778 : Closed e2422407886778 ∧ code e2422407886778 = 11218500908986 := by decide
theorem cert_e2422407886778 : check e2422407886778 [[],[]] .chain = true := by decide
def e2422407887030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 0))) (.var 1)))) (.var 1))))))
theorem wire_e2422407887030 : Closed e2422407887030 ∧ code e2422407887030 = 11218500909238 := by decide
theorem cert_e2422407887030 : check e2422407887030 [[],[]] .chain = true := by decide
def e2422407887034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 0))) (.var 2)))) (.var 0))))))
theorem wire_e2422407887034 : Closed e2422407887034 ∧ code e2422407887034 = 11218500909242 := by decide
theorem cert_e2422407887034 : check e2422407887034 [[],[]] .chain = true := by decide
def e2422407887062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 0)))) (.var 1))))))
theorem wire_e2422407887062 : Closed e2422407887062 ∧ code e2422407887062 = 11218500909270 := by decide
theorem cert_e2422407887062 : check e2422407887062 [[],[]] .chain = true := by decide
def e2422407887066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))) (.var 0))))))
theorem wire_e2422407887066 : Closed e2422407887066 ∧ code e2422407887066 = 11218500909274 := by decide
theorem cert_e2422407887066 : check e2422407887066 [[],[]] .chain = true := by decide
def e2422407887082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))) (.var 0))))))
theorem wire_e2422407887082 : Closed e2422407887082 ∧ code e2422407887082 = 11218500909290 := by decide
theorem cert_e2422407887082 : check e2422407887082 [[],[]] .chain = true := by decide
def e2422407887414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407887414 : Closed e2422407887414 ∧ code e2422407887414 = 11218500909622 := by decide
theorem cert_e2422407887414 : check e2422407887414 [[],[]] .chain = true := by decide
def e2422407887418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407887418 : Closed e2422407887418 ∧ code e2422407887418 = 11218500909626 := by decide
theorem cert_e2422407887418 : check e2422407887418 [[],[]] .chain = true := by decide
def e2422407887502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407887502 : Closed e2422407887502 ∧ code e2422407887502 = 11218500909710 := by decide
theorem cert_e2422407887502 : check e2422407887502 [[],[]] .chain = true := by decide
def e2422407887558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407887558 : Closed e2422407887558 ∧ code e2422407887558 = 11218500909766 := by decide
theorem cert_e2422407887558 : check e2422407887558 [[],[]] .chain = true := by decide
def e2422407887598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e2422407887598 : Closed e2422407887598 ∧ code e2422407887598 = 11218500909806 := by decide
theorem cert_e2422407887598 : check e2422407887598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422407887606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 3)))) (.var 1))))))
theorem wire_e2422407887606 : Closed e2422407887606 ∧ code e2422407887606 = 11218500909814 := by decide
theorem cert_e2422407887606 : checkPay e2422407887606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422407887638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407887638 : Closed e2422407887638 ∧ code e2422407887638 = 11218500909846 := by decide
theorem cert_e2422407887638 : check e2422407887638 [[],[]] .chain = true := by decide
def e2422407887642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407887642 : Closed e2422407887642 ∧ code e2422407887642 = 11218500909850 := by decide
theorem cert_e2422407887642 : check e2422407887642 [[],[]] .chain = true := by decide
def e2422407887686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407887686 : Closed e2422407887686 ∧ code e2422407887686 = 11218500909894 := by decide
theorem cert_e2422407887686 : check e2422407887686 [[],[]] .chain = true := by decide
def e2422407887734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e2422407887734 : Closed e2422407887734 ∧ code e2422407887734 = 11218500909942 := by decide
theorem cert_e2422407887734 : check e2422407887734 [[],[]] .chain = true := by decide
def e2422407887754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407887754 : Closed e2422407887754 ∧ code e2422407887754 = 11218500909962 := by decide
theorem cert_e2422407887754 : check e2422407887754 [[],[]] .chain = true := by decide
def e2422407887790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e2422407887790 : Closed e2422407887790 ∧ code e2422407887790 = 11218500909998 := by decide
theorem cert_e2422407887790 : check e2422407887790 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407887798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e2422407887798 : Closed e2422407887798 ∧ code e2422407887798 = 11218500910006 := by decide
theorem cert_e2422407887798 : check e2422407887798 [[],[]] .chain = true := by decide
def e2422407887802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 2)))) (.var 0))))))
theorem wire_e2422407887802 : Closed e2422407887802 ∧ code e2422407887802 = 11218500910010 := by decide
theorem cert_e2422407887802 : check e2422407887802 [[],[]] .chain = true := by decide
def e2422407887830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 3)) (.var 0)))) (.var 1))))))
theorem wire_e2422407887830 : Closed e2422407887830 ∧ code e2422407887830 = 11218500910038 := by decide
theorem cert_e2422407887830 : check e2422407887830 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407892858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))) (.var 0))))))
theorem wire_e2422407892858 : Closed e2422407892858 ∧ code e2422407892858 = 11218500915066 := by decide
theorem cert_e2422407892858 : check e2422407892858 [[],[]] .smaller = true := by decide
def e2422407892922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))) (.var 0))))))
theorem wire_e2422407892922 : Closed e2422407892922 ∧ code e2422407892922 = 11218500915130 := by decide
theorem cert_e2422407892922 : check e2422407892922 [[],[]] .smaller = true := by decide
def e2422407896302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407896302 : Closed e2422407896302 ∧ code e2422407896302 = 11218500918510 := by decide
theorem cert_e2422407896302 : check e2422407896302 [[],[]] .chain = true := by decide
def e2422407896310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407896310 : Closed e2422407896310 ∧ code e2422407896310 = 11218500918518 := by decide
theorem cert_e2422407896310 : check e2422407896310 [[],[]] .chain = true := by decide
def e2422407896686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 3))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407896686 : Closed e2422407896686 ∧ code e2422407896686 = 11218500918894 := by decide
theorem cert_e2422407896686 : check e2422407896686 [[],[]] .chain = true := by decide
def e2422407896698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 3))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407896698 : Closed e2422407896698 ∧ code e2422407896698 = 11218500918906 := by decide
theorem cert_e2422407896698 : check e2422407896698 [[],[]] .chain = true := by decide
def e2422407896886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 4))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407896886 : Closed e2422407896886 ∧ code e2422407896886 = 11218500919094 := by decide
theorem cert_e2422407896886 : check e2422407896886 [[],[]] .chain = true := by decide
def e2422407896890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 4))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407896890 : Closed e2422407896890 ∧ code e2422407896890 = 11218500919098 := by decide
theorem cert_e2422407896890 : check e2422407896890 [[],[]] .chain = true := by decide
def e2422407900602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e2422407900602 : Closed e2422407900602 ∧ code e2422407900602 = 11218500922810 := by decide
theorem cert_e2422407900602 : check e2422407900602 [[],[]] .smaller = true := by decide
def e2422407900634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e2422407900634 : Closed e2422407900634 ∧ code e2422407900634 = 11218500922842 := by decide
theorem cert_e2422407900634 : check e2422407900634 [[],[]] .smaller = true := by decide
def e2422407900858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e2422407900858 : Closed e2422407900858 ∧ code e2422407900858 = 11218500923066 := by decide
theorem cert_e2422407900858 : check e2422407900858 [[],[]] .smaller = true := by decide
def e2422407900906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e2422407900906 : Closed e2422407900906 ∧ code e2422407900906 = 11218500923114 := by decide
theorem cert_e2422407900906 : check e2422407900906 [[],[]] .smaller = true := by decide
def e2422407901018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e2422407901018 : Closed e2422407901018 ∧ code e2422407901018 = 11218500923226 := by decide
theorem cert_e2422407901018 : check e2422407901018 [[],[]] .smaller = true := by decide
def e2422407901034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e2422407901034 : Closed e2422407901034 ∧ code e2422407901034 = 11218500923242 := by decide
theorem cert_e2422407901034 : check e2422407901034 [[],[]] .smaller = true := by decide
def e2422407901678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))) (.var 2))))))
theorem wire_e2422407901678 : Closed e2422407901678 ∧ code e2422407901678 = 11218500923886 := by decide
theorem cert_e2422407901678 : check e2422407901678 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407901686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 4)))))) (.var 1))))))
theorem wire_e2422407901686 : Closed e2422407901686 ∧ code e2422407901686 = 11218500923894 := by decide
theorem cert_e2422407901686 : check e2422407901686 [[],[]] .chain = true := by decide
def e2422407902138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e2422407902138 : Closed e2422407902138 ∧ code e2422407902138 = 11218500924346 := by decide
theorem cert_e2422407902138 : check e2422407902138 [[],[]] .smaller = true := by decide
def e2422407902170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e2422407902170 : Closed e2422407902170 ∧ code e2422407902170 = 11218500924378 := by decide
theorem cert_e2422407902170 : check e2422407902170 [[],[]] .smaller = true := by decide
def e2422407902446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407902446 : Closed e2422407902446 ∧ code e2422407902446 = 11218500924654 := by decide
theorem cert_e2422407902446 : check e2422407902446 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407902454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407902454 : Closed e2422407902454 ∧ code e2422407902454 = 11218500924662 := by decide
theorem cert_e2422407902454 : check e2422407902454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407903006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.var 3)))))))
theorem wire_e2422407903006 : Closed e2422407903006 ∧ code e2422407903006 = 11218500925214 := by decide
theorem cert_e2422407903006 : check e2422407903006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407903118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))) (.lam (.var 2)))))))
theorem wire_e2422407903118 : Closed e2422407903118 ∧ code e2422407903118 = 11218500925326 := by decide
theorem cert_e2422407903118 : check e2422407903118 [[],[]] .chain = true := by decide
def e2422407903478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 1))))))
theorem wire_e2422407903478 : Closed e2422407903478 ∧ code e2422407903478 = 11218500925686 := by decide
theorem cert_e2422407903478 : check e2422407903478 [[],[]] .smaller = true := by decide
def e2422407903482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))) (.var 0))))))
theorem wire_e2422407903482 : Closed e2422407903482 ∧ code e2422407903482 = 11218500925690 := by decide
theorem cert_e2422407903482 : check e2422407903482 [[],[]] .chain = true := by decide
def e2422407903674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e2422407903674 : Closed e2422407903674 ∧ code e2422407903674 = 11218500925882 := by decide
theorem cert_e2422407903674 : check e2422407903674 [[],[]] .smaller = true := by decide
def e2422407903722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e2422407903722 : Closed e2422407903722 ∧ code e2422407903722 = 11218500925930 := by decide
theorem cert_e2422407903722 : check e2422407903722 [[],[]] .smaller = true := by decide
def e2422407904130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407904130 : Closed e2422407904130 ∧ code e2422407904130 = 11218500926338 := by decide
theorem cert_e2422407904130 : check e2422407904130 [[],[]] .smaller = true := by decide
def e2422407904142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 2)))))))
theorem wire_e2422407904142 : Closed e2422407904142 ∧ code e2422407904142 = 11218500926350 := by decide
theorem cert_e2422407904142 : check e2422407904142 [[],[]] .smaller = true := by decide
def e2422407904154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407904154 : Closed e2422407904154 ∧ code e2422407904154 = 11218500926362 := by decide
theorem cert_e2422407904154 : check e2422407904154 [[],[]] .smaller = true := by decide
def e2422407904198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.lam (.var 1)))))))
theorem wire_e2422407904198 : Closed e2422407904198 ∧ code e2422407904198 = 11218500926406 := by decide
theorem cert_e2422407904198 : check e2422407904198 [[],[]] .chain = true := by decide
def e2422407904366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))) (.var 2))))))
theorem wire_e2422407904366 : Closed e2422407904366 ∧ code e2422407904366 = 11218500926574 := by decide
theorem cert_e2422407904366 : checkPay e2422407904366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2422407904374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 1))))))
theorem wire_e2422407904374 : Closed e2422407904374 ∧ code e2422407904374 = 11218500926582 := by decide
theorem cert_e2422407904374 : check e2422407904374 [[],[]] .smaller = true := by decide
def e2422407904474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e2422407904474 : Closed e2422407904474 ∧ code e2422407904474 = 11218500926682 := by decide
theorem cert_e2422407904474 : check e2422407904474 [[],[]] .smaller = true := by decide
def e2422407904490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e2422407904490 : Closed e2422407904490 ∧ code e2422407904490 = 11218500926698 := by decide
theorem cert_e2422407904490 : check e2422407904490 [[],[]] .smaller = true := by decide
def e2422407904542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.var 3)))))))
theorem wire_e2422407904542 : Closed e2422407904542 ∧ code e2422407904542 = 11218500926750 := by decide
theorem cert_e2422407904542 : checkPay e2422407904542 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2422407904642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407904642 : Closed e2422407904642 ∧ code e2422407904642 = 11218500926850 := by decide
theorem cert_e2422407904642 : check e2422407904642 [[],[]] .smaller = true := by decide
def e2422407904654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 2)))))))
theorem wire_e2422407904654 : Closed e2422407904654 ∧ code e2422407904654 = 11218500926862 := by decide
theorem cert_e2422407904654 : check e2422407904654 [[],[]] .smaller = true := by decide
def e2422407904666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407904666 : Closed e2422407904666 ∧ code e2422407904666 = 11218500926874 := by decide
theorem cert_e2422407904666 : check e2422407904666 [[],[]] .smaller = true := by decide
def e2422407904750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))) (.var 2))))))
theorem wire_e2422407904750 : Closed e2422407904750 ∧ code e2422407904750 = 11218500926958 := by decide
theorem cert_e2422407904750 : checkPay e2422407904750 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2422407904822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422407904822 : Closed e2422407904822 ∧ code e2422407904822 = 11218500927030 := by decide
theorem cert_e2422407904822 : check e2422407904822 [[],[]] .chain = true := by decide
def e2422407904826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))) (.var 0))))))
theorem wire_e2422407904826 : Closed e2422407904826 ∧ code e2422407904826 = 11218500927034 := by decide
theorem cert_e2422407904826 : check e2422407904826 [[],[]] .chain = true := by decide
def e2422407904910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422407904910 : Closed e2422407904910 ∧ code e2422407904910 = 11218500927118 := by decide
theorem cert_e2422407904910 : check e2422407904910 [[],[]] .chain = true := by decide
def e2422407904966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.lam (.var 1)))))))
theorem wire_e2422407904966 : Closed e2422407904966 ∧ code e2422407904966 = 11218500927174 := by decide
theorem cert_e2422407904966 : check e2422407904966 [[],[]] .chain = true := by decide
def e2422407905006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))) (.var 2))))))
theorem wire_e2422407905006 : Closed e2422407905006 ∧ code e2422407905006 = 11218500927214 := by decide
theorem cert_e2422407905006 : check e2422407905006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407905014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 3))))) (.var 1))))))
theorem wire_e2422407905014 : Closed e2422407905014 ∧ code e2422407905014 = 11218500927222 := by decide
theorem cert_e2422407905014 : check e2422407905014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407906270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407906270 : Closed e2422407906270 ∧ code e2422407906270 = 11218500928478 := by decide
theorem cert_e2422407906270 : check e2422407906270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407906286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407906286 : Closed e2422407906286 ∧ code e2422407906286 = 11218500928494 := by decide
theorem cert_e2422407906286 : check e2422407906286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.under]] .identityHead = true := by decide
def e2422407908206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407908206 : Closed e2422407908206 ∧ code e2422407908206 = 11218500930414 := by decide
theorem cert_e2422407908206 : check e2422407908206 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left]] .identityHead = true := by decide
def e2422407908214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407908214 : Closed e2422407908214 ∧ code e2422407908214 = 11218500930422 := by decide
theorem cert_e2422407908214 : check e2422407908214 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2422407908270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407908270 : Closed e2422407908270 ∧ code e2422407908270 = 11218500930478 := by decide
theorem cert_e2422407908270 : check e2422407908270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407908282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407908282 : Closed e2422407908282 ∧ code e2422407908282 = 11218500930490 := by decide
theorem cert_e2422407908282 : check e2422407908282 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407908310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407908310 : Closed e2422407908310 ∧ code e2422407908310 = 11218500930518 := by decide
theorem cert_e2422407908310 : check e2422407908310 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2422407908314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407908314 : Closed e2422407908314 ∧ code e2422407908314 = 11218500930522 := by decide
theorem cert_e2422407908314 : check e2422407908314 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2422407908590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407908590 : Closed e2422407908590 ∧ code e2422407908590 = 11218500930798 := by decide
theorem cert_e2422407908590 : check e2422407908590 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422407908598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407908598 : Closed e2422407908598 ∧ code e2422407908598 = 11218500930806 := by decide
theorem cert_e2422407908598 : check e2422407908598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.under]] .identityHead = true := by decide
def e2422407908974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407908974 : Closed e2422407908974 ∧ code e2422407908974 = 11218500931182 := by decide
theorem cert_e2422407908974 : check e2422407908974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407908986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407908986 : Closed e2422407908986 ∧ code e2422407908986 = 11218500931194 := by decide
theorem cert_e2422407908986 : check e2422407908986 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407909174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407909174 : Closed e2422407909174 ∧ code e2422407909174 = 11218500931382 := by decide
theorem cert_e2422407909174 : check e2422407909174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422407909178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407909178 : Closed e2422407909178 ∧ code e2422407909178 = 11218500931386 := by decide
theorem cert_e2422407909178 : check e2422407909178 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422407915294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407915294 : Closed e2422407915294 ∧ code e2422407915294 = 11218500937502 := by decide
theorem cert_e2422407915294 : check e2422407915294 [[],[]] .chain = true := by decide
def e2422407915406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407915406 : Closed e2422407915406 ∧ code e2422407915406 = 11218500937614 := by decide
theorem cert_e2422407915406 : check e2422407915406 [[],[]] .chain = true := by decide
def e2422407918366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407918366 : Closed e2422407918366 ∧ code e2422407918366 = 11218500940574 := by decide
theorem cert_e2422407918366 : check e2422407918366 [[],[]] .chain = true := by decide
def e2422407918534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407918534 : Closed e2422407918534 ∧ code e2422407918534 = 11218500940742 := by decide
theorem cert_e2422407918534 : check e2422407918534 [[],[]] .chain = true := by decide
def e2422407920014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407920014 : Closed e2422407920014 ∧ code e2422407920014 = 11218500942222 := by decide
theorem cert_e2422407920014 : check e2422407920014 [[],[]] .chain = true := by decide
def e2422407920070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407920070 : Closed e2422407920070 ∧ code e2422407920070 = 11218500942278 := by decide
theorem cert_e2422407920070 : check e2422407920070 [[],[]] .chain = true := by decide
def e2422407922670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.var 4)))))) (.var 2))))))
theorem wire_e2422407922670 : Closed e2422407922670 ∧ code e2422407922670 = 11218500944878 := by decide
theorem cert_e2422407922670 : check e2422407922670 [[],[]] .chain = true := by decide
def e2422407922678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.var 5)))))) (.var 1))))))
theorem wire_e2422407922678 : Closed e2422407922678 ∧ code e2422407922678 = 11218500944886 := by decide
theorem cert_e2422407922678 : check e2422407922678 [[],[]] .chain = true := by decide
def e2422407923578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))) (.var 0))))))
theorem wire_e2422407923578 : Closed e2422407923578 ∧ code e2422407923578 = 11218500945786 := by decide
theorem cert_e2422407923578 : check e2422407923578 [[],[]] .smaller = true := by decide
def e2422407923674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))) (.var 0))))))
theorem wire_e2422407923674 : Closed e2422407923674 ∧ code e2422407923674 = 11218500945882 := by decide
theorem cert_e2422407923674 : check e2422407923674 [[],[]] .smaller = true := by decide
def e2422407924974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407924974 : Closed e2422407924974 ∧ code e2422407924974 = 11218500947182 := by decide
theorem cert_e2422407924974 : check e2422407924974 [[],[]] .chain = true := by decide
def e2422407924982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407924982 : Closed e2422407924982 ∧ code e2422407924982 = 11218500947190 := by decide
theorem cert_e2422407924982 : check e2422407924982 [[],[]] .chain = true := by decide
def e2422407925534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3))))) (.lam (.var 3)))))))
theorem wire_e2422407925534 : Closed e2422407925534 ∧ code e2422407925534 = 11218500947742 := by decide
theorem cert_e2422407925534 : check e2422407925534 [[],[]] .chain = true := by decide
def e2422407925646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 4))))) (.lam (.var 2)))))))
theorem wire_e2422407925646 : Closed e2422407925646 ∧ code e2422407925646 = 11218500947854 := by decide
theorem cert_e2422407925646 : check e2422407925646 [[],[]] .chain = true := by decide
def e2422407927482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e2422407927482 : Closed e2422407927482 ∧ code e2422407927482 = 11218500949690 := by decide
theorem cert_e2422407927482 : check e2422407927482 [[],[]] .smaller = true := by decide
def e2422407927530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e2422407927530 : Closed e2422407927530 ∧ code e2422407927530 = 11218500949738 := by decide
theorem cert_e2422407927530 : check e2422407927530 [[],[]] .smaller = true := by decide
def e2422407927722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.var 0))))))
theorem wire_e2422407927722 : Closed e2422407927722 ∧ code e2422407927722 = 11218500949930 := by decide
theorem cert_e2422407927722 : check e2422407927722 [[],[]] .smaller = true := by decide
def e2422407928054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 1))))))
theorem wire_e2422407928054 : Closed e2422407928054 ∧ code e2422407928054 = 11218500950262 := by decide
theorem cert_e2422407928054 : check e2422407928054 [[],[]] .smaller = true := by decide
def e2422407928058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))) (.var 0))))))
theorem wire_e2422407928058 : Closed e2422407928058 ∧ code e2422407928058 = 11218500950266 := by decide
theorem cert_e2422407928058 : check e2422407928058 [[],[]] .chain = true := by decide
def e2422407928250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e2422407928250 : Closed e2422407928250 ∧ code e2422407928250 = 11218500950458 := by decide
theorem cert_e2422407928250 : check e2422407928250 [[],[]] .smaller = true := by decide
def e2422407928298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e2422407928298 : Closed e2422407928298 ∧ code e2422407928298 = 11218500950506 := by decide
theorem cert_e2422407928298 : check e2422407928298 [[],[]] .smaller = true := by decide
def e2422407928706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407928706 : Closed e2422407928706 ∧ code e2422407928706 = 11218500950914 := by decide
theorem cert_e2422407928706 : check e2422407928706 [[],[]] .smaller = true := by decide
def e2422407928718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 2)))))))
theorem wire_e2422407928718 : Closed e2422407928718 ∧ code e2422407928718 = 11218500950926 := by decide
theorem cert_e2422407928718 : check e2422407928718 [[],[]] .smaller = true := by decide
def e2422407928730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407928730 : Closed e2422407928730 ∧ code e2422407928730 = 11218500950938 := by decide
theorem cert_e2422407928730 : check e2422407928730 [[],[]] .smaller = true := by decide
def e2422407928774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.lam (.var 1)))))))
theorem wire_e2422407928774 : Closed e2422407928774 ∧ code e2422407928774 = 11218500950982 := by decide
theorem cert_e2422407928774 : check e2422407928774 [[],[]] .chain = true := by decide
def e2422407929390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422407929390 : Closed e2422407929390 ∧ code e2422407929390 = 11218500951598 := by decide
theorem cert_e2422407929390 : check e2422407929390 [[],[]] .chain = true := by decide
def e2422407929398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422407929398 : Closed e2422407929398 ∧ code e2422407929398 = 11218500951606 := by decide
theorem cert_e2422407929398 : check e2422407929398 [[],[]] .smaller = true := by decide
def e2422407929450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e2422407929450 : Closed e2422407929450 ∧ code e2422407929450 = 11218500951658 := by decide
theorem cert_e2422407929450 : check e2422407929450 [[],[]] .smaller = true := by decide
def e2422407929474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407929474 : Closed e2422407929474 ∧ code e2422407929474 = 11218500951682 := by decide
theorem cert_e2422407929474 : check e2422407929474 [[],[]] .smaller = true := by decide
def e2422407929486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422407929486 : Closed e2422407929486 ∧ code e2422407929486 = 11218500951694 := by decide
theorem cert_e2422407929486 : check e2422407929486 [[],[]] .smaller = true := by decide
def e2422407929498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407929498 : Closed e2422407929498 ∧ code e2422407929498 = 11218500951706 := by decide
theorem cert_e2422407929498 : check e2422407929498 [[],[]] .smaller = true := by decide
def e2422407929582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 2))))) (.var 2))))))
theorem wire_e2422407929582 : Closed e2422407929582 ∧ code e2422407929582 = 11218500951790 := by decide
theorem cert_e2422407929582 : check e2422407929582 [[],[]] .chain = true := by decide
def e2422407929590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))) (.var 1))))))
theorem wire_e2422407929590 : Closed e2422407929590 ∧ code e2422407929590 = 11218500951798 := by decide
theorem cert_e2422407929590 : check e2422407929590 [[],[]] .chain = true := by decide
def e2422407929622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422407929622 : Closed e2422407929622 ∧ code e2422407929622 = 11218500951830 := by decide
theorem cert_e2422407929622 : check e2422407929622 [[],[]] .chain = true := by decide
def e2422407929626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e2422407929626 : Closed e2422407929626 ∧ code e2422407929626 = 11218500951834 := by decide
theorem cert_e2422407929626 : check e2422407929626 [[],[]] .chain = true := by decide
def e2422407929670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e2422407929670 : Closed e2422407929670 ∧ code e2422407929670 = 11218500951878 := by decide
theorem cert_e2422407929670 : check e2422407929670 [[],[]] .chain = true := by decide
def e2422407929718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))) (.var 1))))))
theorem wire_e2422407929718 : Closed e2422407929718 ∧ code e2422407929718 = 11218500951926 := by decide
theorem cert_e2422407929718 : check e2422407929718 [[],[]] .chain = true := by decide
def e2422407931678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407931678 : Closed e2422407931678 ∧ code e2422407931678 = 11218500953886 := by decide
theorem cert_e2422407931678 : check e2422407931678 [[],[]] .chain = true := by decide
def e2422407931790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407931790 : Closed e2422407931790 ∧ code e2422407931790 = 11218500953998 := by decide
theorem cert_e2422407931790 : check e2422407931790 [[],[]] .chain = true := by decide
def e2422407936062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.lam (.var 4))))))))
theorem wire_e2422407936062 : Closed e2422407936062 ∧ code e2422407936062 = 11218500958270 := by decide
theorem cert_e2422407936062 : check e2422407936062 [[],[]] .chain = true := by decide
def e2422407936482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407936482 : Closed e2422407936482 ∧ code e2422407936482 = 11218500958690 := by decide
theorem cert_e2422407936482 : check e2422407936482 [[],[]] .chain = true := by decide
def e2422407936494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407936494 : Closed e2422407936494 ∧ code e2422407936494 = 11218500958702 := by decide
theorem cert_e2422407936494 : check e2422407936494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422407937054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407937054 : Closed e2422407937054 ∧ code e2422407937054 = 11218500959262 := by decide
theorem cert_e2422407937054 : check e2422407937054 [[],[]] .chain = true := by decide
def e2422407937250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407937250 : Closed e2422407937250 ∧ code e2422407937250 = 11218500959458 := by decide
theorem cert_e2422407937250 : check e2422407937250 [[],[]] .chain = true := by decide
def e2422407937262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407937262 : Closed e2422407937262 ∧ code e2422407937262 = 11218500959470 := by decide
theorem cert_e2422407937262 : check e2422407937262 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407937270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407937270 : Closed e2422407937270 ∧ code e2422407937270 = 11218500959478 := by decide
theorem cert_e2422407937270 : check e2422407937270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422407938542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.var 3)))))) (.var 2))))))
theorem wire_e2422407938542 : Closed e2422407938542 ∧ code e2422407938542 = 11218500960750 := by decide
theorem cert_e2422407938542 : check e2422407938542 [[],[]] .chain = true := by decide
def e2422407938554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.var 5)))))) (.var 0))))))
theorem wire_e2422407938554 : Closed e2422407938554 ∧ code e2422407938554 = 11218500960762 := by decide
theorem cert_e2422407938554 : check e2422407938554 [[],[]] .chain = true := by decide
def e2422407939002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e2422407939002 : Closed e2422407939002 ∧ code e2422407939002 = 11218500961210 := by decide
theorem cert_e2422407939002 : check e2422407939002 [[],[]] .smaller = true := by decide
def e2422407939034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e2422407939034 : Closed e2422407939034 ∧ code e2422407939034 = 11218500961242 := by decide
theorem cert_e2422407939034 : check e2422407939034 [[],[]] .smaller = true := by decide
def e2422407939310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407939310 : Closed e2422407939310 ∧ code e2422407939310 = 11218500961518 := by decide
theorem cert_e2422407939310 : check e2422407939310 [[],[]] .chain = true := by decide
def e2422407939318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407939318 : Closed e2422407939318 ∧ code e2422407939318 = 11218500961526 := by decide
theorem cert_e2422407939318 : check e2422407939318 [[],[]] .chain = true := by decide
def e2422407939694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 1))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407939694 : Closed e2422407939694 ∧ code e2422407939694 = 11218500961902 := by decide
theorem cert_e2422407939694 : check e2422407939694 [[],[]] .chain = true := by decide
def e2422407939706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 1))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407939706 : Closed e2422407939706 ∧ code e2422407939706 = 11218500961914 := by decide
theorem cert_e2422407939706 : check e2422407939706 [[],[]] .chain = true := by decide
def e2422407939870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2))))) (.lam (.var 3)))))))
theorem wire_e2422407939870 : Closed e2422407939870 ∧ code e2422407939870 = 11218500962078 := by decide
theorem cert_e2422407939870 : check e2422407939870 [[],[]] .chain = true := by decide
def e2422407940038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))) (.lam (.var 1)))))))
theorem wire_e2422407940038 : Closed e2422407940038 ∧ code e2422407940038 = 11218500962246 := by decide
theorem cert_e2422407940038 : check e2422407940038 [[],[]] .chain = true := by decide
def e2422407940954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e2422407940954 : Closed e2422407940954 ∧ code e2422407940954 = 11218500963162 := by decide
theorem cert_e2422407940954 : check e2422407940954 [[],[]] .smaller = true := by decide
def e2422407940970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e2422407940970 : Closed e2422407940970 ∧ code e2422407940970 = 11218500963178 := by decide
theorem cert_e2422407940970 : check e2422407940970 [[],[]] .smaller = true := by decide
def e2422407941034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.var 0))))))
theorem wire_e2422407941034 : Closed e2422407941034 ∧ code e2422407941034 = 11218500963242 := by decide
theorem cert_e2422407941034 : check e2422407941034 [[],[]] .smaller = true := by decide
def e2422407941230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))) (.var 2))))))
theorem wire_e2422407941230 : Closed e2422407941230 ∧ code e2422407941230 = 11218500963438 := by decide
theorem cert_e2422407941230 : check e2422407941230 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407941238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 1))))))
theorem wire_e2422407941238 : Closed e2422407941238 ∧ code e2422407941238 = 11218500963446 := by decide
theorem cert_e2422407941238 : check e2422407941238 [[],[]] .smaller = true := by decide
def e2422407941338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e2422407941338 : Closed e2422407941338 ∧ code e2422407941338 = 11218500963546 := by decide
theorem cert_e2422407941338 : check e2422407941338 [[],[]] .smaller = true := by decide
def e2422407941354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e2422407941354 : Closed e2422407941354 ∧ code e2422407941354 = 11218500963562 := by decide
theorem cert_e2422407941354 : check e2422407941354 [[],[]] .smaller = true := by decide
def e2422407941406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.var 3)))))))
theorem wire_e2422407941406 : Closed e2422407941406 ∧ code e2422407941406 = 11218500963614 := by decide
theorem cert_e2422407941406 : check e2422407941406 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407941506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407941506 : Closed e2422407941506 ∧ code e2422407941506 = 11218500963714 := by decide
theorem cert_e2422407941506 : check e2422407941506 [[],[]] .smaller = true := by decide
def e2422407941518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 2)))))))
theorem wire_e2422407941518 : Closed e2422407941518 ∧ code e2422407941518 = 11218500963726 := by decide
theorem cert_e2422407941518 : check e2422407941518 [[],[]] .smaller = true := by decide
def e2422407941530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407941530 : Closed e2422407941530 ∧ code e2422407941530 = 11218500963738 := by decide
theorem cert_e2422407941530 : check e2422407941530 [[],[]] .smaller = true := by decide
def e2422407941614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))) (.var 2))))))
theorem wire_e2422407941614 : Closed e2422407941614 ∧ code e2422407941614 = 11218500963822 := by decide
theorem cert_e2422407941614 : check e2422407941614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407941678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422407941678 : Closed e2422407941678 ∧ code e2422407941678 = 11218500963886 := by decide
theorem cert_e2422407941678 : check e2422407941678 [[],[]] .chain = true := by decide
def e2422407941686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422407941686 : Closed e2422407941686 ∧ code e2422407941686 = 11218500963894 := by decide
theorem cert_e2422407941686 : check e2422407941686 [[],[]] .smaller = true := by decide
def e2422407941738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e2422407941738 : Closed e2422407941738 ∧ code e2422407941738 = 11218500963946 := by decide
theorem cert_e2422407941738 : check e2422407941738 [[],[]] .smaller = true := by decide
def e2422407941762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407941762 : Closed e2422407941762 ∧ code e2422407941762 = 11218500963970 := by decide
theorem cert_e2422407941762 : check e2422407941762 [[],[]] .smaller = true := by decide
def e2422407941774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422407941774 : Closed e2422407941774 ∧ code e2422407941774 = 11218500963982 := by decide
theorem cert_e2422407941774 : check e2422407941774 [[],[]] .smaller = true := by decide
end Blc.Floor43
