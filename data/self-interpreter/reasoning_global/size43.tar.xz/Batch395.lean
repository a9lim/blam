import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372821854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2422372821854 : Closed e2422372821854 ∧ code e2422372821854 = 11218465844062 := by decide
theorem cert_e2422372821854 : check e2422372821854 [[],[]] .three = true := by decide
def e2422372821858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372821858 : Closed e2422372821858 ∧ code e2422372821858 = 11218465844066 := by decide
theorem cert_e2422372821858 : check e2422372821858 [[],[]] .three = true := by decide
def e2422372821870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2422372821870 : Closed e2422372821870 ∧ code e2422372821870 = 11218465844078 := by decide
theorem cert_e2422372821870 : check e2422372821870 [[],[]] .three = true := by decide
def e2422372821878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2422372821878 : Closed e2422372821878 ∧ code e2422372821878 = 11218465844086 := by decide
theorem cert_e2422372821878 : check e2422372821878 [[],[]] .three = true := by decide
def e2422372821882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2422372821882 : Closed e2422372821882 ∧ code e2422372821882 = 11218465844090 := by decide
theorem cert_e2422372821882 : check e2422372821882 [[],[]] .three = true := by decide
def e2422372821898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372821898 : Closed e2422372821898 ∧ code e2422372821898 = 11218465844106 := by decide
theorem cert_e2422372821898 : check e2422372821898 [[],[]] .three = true := by decide
def e2422372821922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372821922 : Closed e2422372821922 ∧ code e2422372821922 = 11218465844130 := by decide
theorem cert_e2422372821922 : check e2422372821922 [[],[]] .three = true := by decide
def e2422372821934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2422372821934 : Closed e2422372821934 ∧ code e2422372821934 = 11218465844142 := by decide
theorem cert_e2422372821934 : check e2422372821934 [[],[]] .three = true := by decide
def e2422372821942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2422372821942 : Closed e2422372821942 ∧ code e2422372821942 = 11218465844150 := by decide
theorem cert_e2422372821942 : check e2422372821942 [[],[]] .three = true := by decide
def e2422372821946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2422372821946 : Closed e2422372821946 ∧ code e2422372821946 = 11218465844154 := by decide
theorem cert_e2422372821946 : check e2422372821946 [[],[]] .three = true := by decide
def e2422372821974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2422372821974 : Closed e2422372821974 ∧ code e2422372821974 = 11218465844182 := by decide
theorem cert_e2422372821974 : check e2422372821974 [[],[]] .three = true := by decide
def e2422372821978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2422372821978 : Closed e2422372821978 ∧ code e2422372821978 = 11218465844186 := by decide
theorem cert_e2422372821978 : check e2422372821978 [[],[]] .three = true := by decide
def e2422372822102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372822102 : Closed e2422372822102 ∧ code e2422372822102 = 11218465844310 := by decide
theorem cert_e2422372822102 : check e2422372822102 [[],[]] .three = true := by decide
def e2422372822106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372822106 : Closed e2422372822106 ∧ code e2422372822106 = 11218465844314 := by decide
theorem cert_e2422372822106 : check e2422372822106 [[],[]] .three = true := by decide
def e2422372822122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422372822122 : Closed e2422372822122 ∧ code e2422372822122 = 11218465844330 := by decide
theorem cert_e2422372822122 : check e2422372822122 [[],[]] .three = true := by decide
def e2422372822294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372822294 : Closed e2422372822294 ∧ code e2422372822294 = 11218465844502 := by decide
theorem cert_e2422372822294 : check e2422372822294 [[],[]] .three = true := by decide
def e2422372822298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372822298 : Closed e2422372822298 ∧ code e2422372822298 = 11218465844506 := by decide
theorem cert_e2422372822298 : check e2422372822298 [[],[]] .three = true := by decide
def e2422372822342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372822342 : Closed e2422372822342 ∧ code e2422372822342 = 11218465844550 := by decide
theorem cert_e2422372822342 : check e2422372822342 [[],[]] .three = true := by decide
def e2422372822366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2422372822366 : Closed e2422372822366 ∧ code e2422372822366 = 11218465844574 := by decide
theorem cert_e2422372822366 : check e2422372822366 [[],[]] .three = true := by decide
def e2422372822370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372822370 : Closed e2422372822370 ∧ code e2422372822370 = 11218465844578 := by decide
theorem cert_e2422372822370 : check e2422372822370 [[],[]] .three = true := by decide
def e2422372822382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372822382 : Closed e2422372822382 ∧ code e2422372822382 = 11218465844590 := by decide
theorem cert_e2422372822382 : check e2422372822382 [[],[]] .three = true := by decide
def e2422372822390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372822390 : Closed e2422372822390 ∧ code e2422372822390 = 11218465844598 := by decide
theorem cert_e2422372822390 : check e2422372822390 [[],[]] .three = true := by decide
def e2422372822394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2422372822394 : Closed e2422372822394 ∧ code e2422372822394 = 11218465844602 := by decide
theorem cert_e2422372822394 : check e2422372822394 [[],[]] .three = true := by decide
def e2422372822410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372822410 : Closed e2422372822410 ∧ code e2422372822410 = 11218465844618 := by decide
theorem cert_e2422372822410 : check e2422372822410 [[],[]] .three = true := by decide
def e2422372822434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372822434 : Closed e2422372822434 ∧ code e2422372822434 = 11218465844642 := by decide
theorem cert_e2422372822434 : check e2422372822434 [[],[]] .three = true := by decide
def e2422372822446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372822446 : Closed e2422372822446 ∧ code e2422372822446 = 11218465844654 := by decide
theorem cert_e2422372822446 : check e2422372822446 [[],[]] .three = true := by decide
def e2422372822458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372822458 : Closed e2422372822458 ∧ code e2422372822458 = 11218465844666 := by decide
theorem cert_e2422372822458 : check e2422372822458 [[],[]] .three = true := by decide
def e2422372822486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372822486 : Closed e2422372822486 ∧ code e2422372822486 = 11218465844694 := by decide
theorem cert_e2422372822486 : check e2422372822486 [[],[]] .three = true := by decide
def e2422372822490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372822490 : Closed e2422372822490 ∧ code e2422372822490 = 11218465844698 := by decide
theorem cert_e2422372822490 : check e2422372822490 [[],[]] .three = true := by decide
def e2422372822506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2422372822506 : Closed e2422372822506 ∧ code e2422372822506 = 11218465844714 := by decide
theorem cert_e2422372822506 : check e2422372822506 [[],[]] .three = true := by decide
def e2422372822570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372822570 : Closed e2422372822570 ∧ code e2422372822570 = 11218465844778 := by decide
theorem cert_e2422372822570 : check e2422372822570 [[],[]] .three = true := by decide
def e2422372822666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372822666 : Closed e2422372822666 ∧ code e2422372822666 = 11218465844874 := by decide
theorem cert_e2422372822666 : check e2422372822666 [[],[]] .three = true := by decide
def e2422372822690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372822690 : Closed e2422372822690 ∧ code e2422372822690 = 11218465844898 := by decide
theorem cert_e2422372822690 : check e2422372822690 [[],[]] .three = true := by decide
def e2422372822702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372822702 : Closed e2422372822702 ∧ code e2422372822702 = 11218465844910 := by decide
theorem cert_e2422372822702 : check e2422372822702 [[],[]] .three = true := by decide
def e2422372822710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2422372822710 : Closed e2422372822710 ∧ code e2422372822710 = 11218465844918 := by decide
theorem cert_e2422372822710 : check e2422372822710 [[],[]] .three = true := by decide
def e2422372822714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372822714 : Closed e2422372822714 ∧ code e2422372822714 = 11218465844922 := by decide
theorem cert_e2422372822714 : check e2422372822714 [[],[]] .three = true := by decide
def e2422372822742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2422372822742 : Closed e2422372822742 ∧ code e2422372822742 = 11218465844950 := by decide
theorem cert_e2422372822742 : check e2422372822742 [[],[]] .three = true := by decide
def e2422372822746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2422372822746 : Closed e2422372822746 ∧ code e2422372822746 = 11218465844954 := by decide
theorem cert_e2422372822746 : check e2422372822746 [[],[]] .three = true := by decide
def e2422372822762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372822762 : Closed e2422372822762 ∧ code e2422372822762 = 11218465844970 := by decide
theorem cert_e2422372822762 : check e2422372822762 [[],[]] .three = true := by decide
def e2422372822870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372822870 : Closed e2422372822870 ∧ code e2422372822870 = 11218465845078 := by decide
private def t_e2422372822870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e2422372822870 : ¬ IsSelfInterpreter e2422372822870 :=
  wSource (t := t_e2422372822870) (replay_sound (ps := []) (t := e2422372822870) (by decide)) (by decide)
def e2422372822874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372822874 : Closed e2422372822874 ∧ code e2422372822874 = 11218465845082 := by decide
private def t_e2422372822874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e2422372822874 : ¬ IsSelfInterpreter e2422372822874 :=
  wSource (t := t_e2422372822874) (replay_sound (ps := []) (t := e2422372822874) (by decide)) (by decide)
def e2422372822890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372822890 : Closed e2422372822890 ∧ code e2422372822890 = 11218465845098 := by decide
private def t_e2422372822890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e2422372822890 : ¬ IsSelfInterpreter e2422372822890 :=
  wSource (t := t_e2422372822890) (replay_sound (ps := []) (t := e2422372822890) (by decide)) (by decide)
def e2422372830574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 2)))))))
theorem wire_e2422372830574 : Closed e2422372830574 ∧ code e2422372830574 = 11218465852782 := by decide
theorem cert_e2422372830574 : check e2422372830574 [[],[]] .smaller = true := by decide
def e2422372830582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)) (.var 1)))))))
theorem wire_e2422372830582 : Closed e2422372830582 ∧ code e2422372830582 = 11218465852790 := by decide
theorem cert_e2422372830582 : check e2422372830582 [[],[]] .smaller = true := by decide
def e2422372832110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422372832110 : Closed e2422372832110 ∧ code e2422372832110 = 11218465854318 := by decide
theorem cert_e2422372832110 : check e2422372832110 [[],[]] .smaller = true := by decide
def e2422372832118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422372832118 : Closed e2422372832118 ∧ code e2422372832118 = 11218465854326 := by decide
theorem cert_e2422372832118 : check e2422372832118 [[],[]] .smaller = true := by decide
def e2422372832174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422372832174 : Closed e2422372832174 ∧ code e2422372832174 = 11218465854382 := by decide
theorem cert_e2422372832174 : check e2422372832174 [[],[]] .smaller = true := by decide
def e2422372832186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422372832186 : Closed e2422372832186 ∧ code e2422372832186 = 11218465854394 := by decide
theorem cert_e2422372832186 : check e2422372832186 [[],[]] .smaller = true := by decide
def e2422372832214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422372832214 : Closed e2422372832214 ∧ code e2422372832214 = 11218465854422 := by decide
theorem cert_e2422372832214 : check e2422372832214 [[],[]] .smaller = true := by decide
def e2422372832218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422372832218 : Closed e2422372832218 ∧ code e2422372832218 = 11218465854426 := by decide
theorem cert_e2422372832218 : check e2422372832218 [[],[]] .smaller = true := by decide
def e2422372832494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372832494 : Closed e2422372832494 ∧ code e2422372832494 = 11218465854702 := by decide
theorem cert_e2422372832494 : check e2422372832494 [[],[]] .smaller = true := by decide
def e2422372832502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372832502 : Closed e2422372832502 ∧ code e2422372832502 = 11218465854710 := by decide
theorem cert_e2422372832502 : check e2422372832502 [[],[]] .smaller = true := by decide
def e2422372832878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372832878 : Closed e2422372832878 ∧ code e2422372832878 = 11218465855086 := by decide
theorem cert_e2422372832878 : check e2422372832878 [[],[]] .smaller = true := by decide
def e2422372832890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372832890 : Closed e2422372832890 ∧ code e2422372832890 = 11218465855098 := by decide
theorem cert_e2422372832890 : check e2422372832890 [[],[]] .smaller = true := by decide
def e2422372833078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372833078 : Closed e2422372833078 ∧ code e2422372833078 = 11218465855286 := by decide
theorem cert_e2422372833078 : check e2422372833078 [[],[]] .smaller = true := by decide
def e2422372833082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372833082 : Closed e2422372833082 ∧ code e2422372833082 = 11218465855290 := by decide
theorem cert_e2422372833082 : check e2422372833082 [[],[]] .smaller = true := by decide
def e2422372834782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 3)))))))
theorem wire_e2422372834782 : Closed e2422372834782 ∧ code e2422372834782 = 11218465856990 := by decide
theorem cert_e2422372834782 : check e2422372834782 [[],[]] .three = true := by decide
def e2422372834798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 3)) (.var 2)))))))
theorem wire_e2422372834798 : Closed e2422372834798 ∧ code e2422372834798 = 11218465857006 := by decide
theorem cert_e2422372834798 : check e2422372834798 [[],[]] .three = true := by decide
def e2422372835038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1)) (.var 3)))))))
theorem wire_e2422372835038 : Closed e2422372835038 ∧ code e2422372835038 = 11218465857246 := by decide
theorem cert_e2422372835038 : check e2422372835038 [[],[]] .three = true := by decide
def e2422372835054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 2)))))))
theorem wire_e2422372835054 : Closed e2422372835054 ∧ code e2422372835054 = 11218465857262 := by decide
theorem cert_e2422372835054 : check e2422372835054 [[],[]] .smaller = true := by decide
def e2422372835062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 3)) (.var 1)))))))
theorem wire_e2422372835062 : Closed e2422372835062 ∧ code e2422372835062 = 11218465857270 := by decide
theorem cert_e2422372835062 : check e2422372835062 [[],[]] .three = true := by decide
def e2422372835166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372835166 : Closed e2422372835166 ∧ code e2422372835166 = 11218465857374 := by decide
theorem cert_e2422372835166 : check e2422372835166 [[],[]] .three = true := by decide
def e2422372835182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372835182 : Closed e2422372835182 ∧ code e2422372835182 = 11218465857390 := by decide
theorem cert_e2422372835182 : check e2422372835182 [[],[]] .smaller = true := by decide
def e2422372835190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372835190 : Closed e2422372835190 ∧ code e2422372835190 = 11218465857398 := by decide
theorem cert_e2422372835190 : check e2422372835190 [[],[]] .smaller = true := by decide
def e2422372835194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372835194 : Closed e2422372835194 ∧ code e2422372835194 = 11218465857402 := by decide
theorem cert_e2422372835194 : check e2422372835194 [[],[]] .three = true := by decide
def e2422372835246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372835246 : Closed e2422372835246 ∧ code e2422372835246 = 11218465857454 := by decide
theorem cert_e2422372835246 : check e2422372835246 [[],[]] .three = true := by decide
def e2422372835254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 1)) (.var 1)))))))
theorem wire_e2422372835254 : Closed e2422372835254 ∧ code e2422372835254 = 11218465857462 := by decide
theorem cert_e2422372835254 : check e2422372835254 [[],[]] .three = true := by decide
def e2422372835258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372835258 : Closed e2422372835258 ∧ code e2422372835258 = 11218465857466 := by decide
theorem cert_e2422372835258 : check e2422372835258 [[],[]] .three = true := by decide
def e2422372840926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 3)))))))
theorem wire_e2422372840926 : Closed e2422372840926 ∧ code e2422372840926 = 11218465863134 := by decide
theorem cert_e2422372840926 : check e2422372840926 [[],[]] .three = true := by decide
def e2422372840942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 3)) (.var 2)))))))
theorem wire_e2422372840942 : Closed e2422372840942 ∧ code e2422372840942 = 11218465863150 := by decide
theorem cert_e2422372840942 : check e2422372840942 [[],[]] .three = true := by decide
def e2422372841182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 3)))))))
theorem wire_e2422372841182 : Closed e2422372841182 ∧ code e2422372841182 = 11218465863390 := by decide
theorem cert_e2422372841182 : check e2422372841182 [[],[]] .three = true := by decide
def e2422372841206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 3)) (.var 1)))))))
theorem wire_e2422372841206 : Closed e2422372841206 ∧ code e2422372841206 = 11218465863414 := by decide
theorem cert_e2422372841206 : check e2422372841206 [[],[]] .three = true := by decide
def e2422372841310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372841310 : Closed e2422372841310 ∧ code e2422372841310 = 11218465863518 := by decide
theorem cert_e2422372841310 : check e2422372841310 [[],[]] .three = true := by decide
def e2422372841326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372841326 : Closed e2422372841326 ∧ code e2422372841326 = 11218465863534 := by decide
theorem cert_e2422372841326 : check e2422372841326 [[],[]] .smaller = true := by decide
def e2422372841334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372841334 : Closed e2422372841334 ∧ code e2422372841334 = 11218465863542 := by decide
theorem cert_e2422372841334 : check e2422372841334 [[],[]] .smaller = true := by decide
def e2422372841338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372841338 : Closed e2422372841338 ∧ code e2422372841338 = 11218465863546 := by decide
theorem cert_e2422372841338 : check e2422372841338 [[],[]] .three = true := by decide
def e2422372841398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 1)))))))
theorem wire_e2422372841398 : Closed e2422372841398 ∧ code e2422372841398 = 11218465863606 := by decide
theorem cert_e2422372841398 : check e2422372841398 [[],[]] .smaller = true := by decide
def e2422372841430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 4)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372841430 : Closed e2422372841430 ∧ code e2422372841430 = 11218465863638 := by decide
theorem cert_e2422372841430 : check e2422372841430 [[],[]] .three = true := by decide
def e2422372841434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 4)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372841434 : Closed e2422372841434 ∧ code e2422372841434 = 11218465863642 := by decide
theorem cert_e2422372841434 : check e2422372841434 [[],[]] .three = true := by decide
def e2422372842206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 3)))))))
theorem wire_e2422372842206 : Closed e2422372842206 ∧ code e2422372842206 = 11218465864414 := by decide
theorem cert_e2422372842206 : check e2422372842206 [[],[]] .three = true := by decide
def e2422372842230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 3)) (.var 1)))))))
theorem wire_e2422372842230 : Closed e2422372842230 ∧ code e2422372842230 = 11218465864438 := by decide
theorem cert_e2422372842230 : check e2422372842230 [[],[]] .three = true := by decide
def e2422372842350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372842350 : Closed e2422372842350 ∧ code e2422372842350 = 11218465864558 := by decide
theorem cert_e2422372842350 : check e2422372842350 [[],[]] .smaller = true := by decide
def e2422372842358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372842358 : Closed e2422372842358 ∧ code e2422372842358 = 11218465864566 := by decide
theorem cert_e2422372842358 : check e2422372842358 [[],[]] .smaller = true := by decide
def e2422372842414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372842414 : Closed e2422372842414 ∧ code e2422372842414 = 11218465864622 := by decide
theorem cert_e2422372842414 : check e2422372842414 [[],[]] .smaller = true := by decide
def e2422372842426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372842426 : Closed e2422372842426 ∧ code e2422372842426 = 11218465864634 := by decide
theorem cert_e2422372842426 : check e2422372842426 [[],[]] .smaller = true := by decide
def e2422372842454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372842454 : Closed e2422372842454 ∧ code e2422372842454 = 11218465864662 := by decide
theorem cert_e2422372842454 : check e2422372842454 [[],[]] .smaller = true := by decide
def e2422372842458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372842458 : Closed e2422372842458 ∧ code e2422372842458 = 11218465864666 := by decide
theorem cert_e2422372842458 : check e2422372842458 [[],[]] .smaller = true := by decide
def e2422372842846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372842846 : Closed e2422372842846 ∧ code e2422372842846 = 11218465865054 := by decide
theorem cert_e2422372842846 : check e2422372842846 [[],[]] .three = true := by decide
def e2422372842862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372842862 : Closed e2422372842862 ∧ code e2422372842862 = 11218465865070 := by decide
theorem cert_e2422372842862 : check e2422372842862 [[],[]] .smaller = true := by decide
def e2422372842870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372842870 : Closed e2422372842870 ∧ code e2422372842870 = 11218465865078 := by decide
theorem cert_e2422372842870 : check e2422372842870 [[],[]] .smaller = true := by decide
def e2422372842874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372842874 : Closed e2422372842874 ∧ code e2422372842874 = 11218465865082 := by decide
theorem cert_e2422372842874 : check e2422372842874 [[],[]] .three = true := by decide
def e2422372842926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372842926 : Closed e2422372842926 ∧ code e2422372842926 = 11218465865134 := by decide
theorem cert_e2422372842926 : check e2422372842926 [[],[]] .smaller = true := by decide
def e2422372842938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372842938 : Closed e2422372842938 ∧ code e2422372842938 = 11218465865146 := by decide
theorem cert_e2422372842938 : check e2422372842938 [[],[]] .smaller = true := by decide
def e2422372842986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372842986 : Closed e2422372842986 ∧ code e2422372842986 = 11218465865194 := by decide
theorem cert_e2422372842986 : check e2422372842986 [[],[]] .smaller = true := by decide
def e2422372843190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e2422372843190 : Closed e2422372843190 ∧ code e2422372843190 = 11218465865398 := by decide
theorem cert_e2422372843190 : check e2422372843190 [[],[]] .smaller = true := by decide
def e2422372843222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372843222 : Closed e2422372843222 ∧ code e2422372843222 = 11218465865430 := by decide
theorem cert_e2422372843222 : check e2422372843222 [[],[]] .smaller = true := by decide
def e2422372843226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372843226 : Closed e2422372843226 ∧ code e2422372843226 = 11218465865434 := by decide
theorem cert_e2422372843226 : check e2422372843226 [[],[]] .smaller = true := by decide
def e2422372843242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372843242 : Closed e2422372843242 ∧ code e2422372843242 = 11218465865450 := by decide
theorem cert_e2422372843242 : check e2422372843242 [[],[]] .smaller = true := by decide
def e2422372843350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 4) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372843350 : Closed e2422372843350 ∧ code e2422372843350 = 11218465865558 := by decide
theorem cert_e2422372843350 : check e2422372843350 [[],[]] .three = true := by decide
def e2422372843354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 4) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372843354 : Closed e2422372843354 ∧ code e2422372843354 = 11218465865562 := by decide
theorem cert_e2422372843354 : check e2422372843354 [[],[]] .three = true := by decide
def e2422372847070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2422372847070 : Closed e2422372847070 ∧ code e2422372847070 = 11218465869278 := by decide
theorem cert_e2422372847070 : check e2422372847070 [[],[]] .three = true := by decide
def e2422372847086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2422372847086 : Closed e2422372847086 ∧ code e2422372847086 = 11218465869294 := by decide
theorem cert_e2422372847086 : check e2422372847086 [[],[]] .three = true := by decide
def e2422372847326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2422372847326 : Closed e2422372847326 ∧ code e2422372847326 = 11218465869534 := by decide
theorem cert_e2422372847326 : check e2422372847326 [[],[]] .three = true := by decide
def e2422372847342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2422372847342 : Closed e2422372847342 ∧ code e2422372847342 = 11218465869550 := by decide
theorem cert_e2422372847342 : check e2422372847342 [[],[]] .smaller = true := by decide
def e2422372847350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2422372847350 : Closed e2422372847350 ∧ code e2422372847350 = 11218465869558 := by decide
theorem cert_e2422372847350 : check e2422372847350 [[],[]] .three = true := by decide
def e2422372847454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2422372847454 : Closed e2422372847454 ∧ code e2422372847454 = 11218465869662 := by decide
theorem cert_e2422372847454 : check e2422372847454 [[],[]] .three = true := by decide
def e2422372847470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2422372847470 : Closed e2422372847470 ∧ code e2422372847470 = 11218465869678 := by decide
theorem cert_e2422372847470 : check e2422372847470 [[],[]] .smaller = true := by decide
def e2422372847478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2422372847478 : Closed e2422372847478 ∧ code e2422372847478 = 11218465869686 := by decide
theorem cert_e2422372847478 : check e2422372847478 [[],[]] .smaller = true := by decide
def e2422372847482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2422372847482 : Closed e2422372847482 ∧ code e2422372847482 = 11218465869690 := by decide
theorem cert_e2422372847482 : check e2422372847482 [[],[]] .three = true := by decide
def e2422372847534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2422372847534 : Closed e2422372847534 ∧ code e2422372847534 = 11218465869742 := by decide
theorem cert_e2422372847534 : check e2422372847534 [[],[]] .three = true := by decide
def e2422372847542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2422372847542 : Closed e2422372847542 ∧ code e2422372847542 = 11218465869750 := by decide
theorem cert_e2422372847542 : check e2422372847542 [[],[]] .three = true := by decide
def e2422372847546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2422372847546 : Closed e2422372847546 ∧ code e2422372847546 = 11218465869754 := by decide
theorem cert_e2422372847546 : check e2422372847546 [[],[]] .three = true := by decide
def e2422372848606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2422372848606 : Closed e2422372848606 ∧ code e2422372848606 = 11218465870814 := by decide
theorem cert_e2422372848606 : check e2422372848606 [[],[]] .three = true := by decide
def e2422372848622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2422372848622 : Closed e2422372848622 ∧ code e2422372848622 = 11218465870830 := by decide
theorem cert_e2422372848622 : check e2422372848622 [[],[]] .three = true := by decide
def e2422372850142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372850142 : Closed e2422372850142 ∧ code e2422372850142 = 11218465872350 := by decide
theorem cert_e2422372850142 : check e2422372850142 [[],[]] .three = true := by decide
def e2422372850158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372850158 : Closed e2422372850158 ∧ code e2422372850158 = 11218465872366 := by decide
theorem cert_e2422372850158 : check e2422372850158 [[],[]] .smaller = true := by decide
def e2422372850166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372850166 : Closed e2422372850166 ∧ code e2422372850166 = 11218465872374 := by decide
theorem cert_e2422372850166 : check e2422372850166 [[],[]] .three = true := by decide
def e2422372850910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372850910 : Closed e2422372850910 ∧ code e2422372850910 = 11218465873118 := by decide
theorem cert_e2422372850910 : check e2422372850910 [[],[]] .three = true := by decide
def e2422372850926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372850926 : Closed e2422372850926 ∧ code e2422372850926 = 11218465873134 := by decide
theorem cert_e2422372850926 : check e2422372850926 [[],[]] .smaller = true := by decide
def e2422372850934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372850934 : Closed e2422372850934 ∧ code e2422372850934 = 11218465873142 := by decide
theorem cert_e2422372850934 : check e2422372850934 [[],[]] .smaller = true := by decide
def e2422372850938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372850938 : Closed e2422372850938 ∧ code e2422372850938 = 11218465873146 := by decide
theorem cert_e2422372850938 : check e2422372850938 [[],[]] .three = true := by decide
def e2422372851310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372851310 : Closed e2422372851310 ∧ code e2422372851310 = 11218465873518 := by decide
theorem cert_e2422372851310 : check e2422372851310 [[],[]] .three = true := by decide
def e2422372851318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372851318 : Closed e2422372851318 ∧ code e2422372851318 = 11218465873526 := by decide
theorem cert_e2422372851318 : check e2422372851318 [[],[]] .three = true := by decide
def e2422372851322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372851322 : Closed e2422372851322 ∧ code e2422372851322 = 11218465873530 := by decide
theorem cert_e2422372851322 : check e2422372851322 [[],[]] .three = true := by decide
def e2422372852702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 3)))))))
theorem wire_e2422372852702 : Closed e2422372852702 ∧ code e2422372852702 = 11218465874910 := by decide
theorem cert_e2422372852702 : check e2422372852702 [[],[]] .three = true := by decide
def e2422372852718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 4))) (.var 2)))))))
theorem wire_e2422372852718 : Closed e2422372852718 ∧ code e2422372852718 = 11218465874926 := by decide
theorem cert_e2422372852718 : check e2422372852718 [[],[]] .three = true := by decide
def e2422372853470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2422372853470 : Closed e2422372853470 ∧ code e2422372853470 = 11218465875678 := by decide
theorem cert_e2422372853470 : check e2422372853470 [[],[]] .three = true := by decide
def e2422372853494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2422372853494 : Closed e2422372853494 ∧ code e2422372853494 = 11218465875702 := by decide
theorem cert_e2422372853494 : check e2422372853494 [[],[]] .three = true := by decide
def e2422372853598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2422372853598 : Closed e2422372853598 ∧ code e2422372853598 = 11218465875806 := by decide
theorem cert_e2422372853598 : check e2422372853598 [[],[]] .three = true := by decide
def e2422372853614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2422372853614 : Closed e2422372853614 ∧ code e2422372853614 = 11218465875822 := by decide
theorem cert_e2422372853614 : check e2422372853614 [[],[]] .smaller = true := by decide
def e2422372853622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2422372853622 : Closed e2422372853622 ∧ code e2422372853622 = 11218465875830 := by decide
theorem cert_e2422372853622 : check e2422372853622 [[],[]] .smaller = true := by decide
def e2422372853626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2422372853626 : Closed e2422372853626 ∧ code e2422372853626 = 11218465875834 := by decide
theorem cert_e2422372853626 : check e2422372853626 [[],[]] .three = true := by decide
def e2422372853686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2422372853686 : Closed e2422372853686 ∧ code e2422372853686 = 11218465875894 := by decide
theorem cert_e2422372853686 : check e2422372853686 [[],[]] .smaller = true := by decide
def e2422372853718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2422372853718 : Closed e2422372853718 ∧ code e2422372853718 = 11218465875926 := by decide
theorem cert_e2422372853718 : check e2422372853718 [[],[]] .three = true := by decide
def e2422372853722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2422372853722 : Closed e2422372853722 ∧ code e2422372853722 = 11218465875930 := by decide
theorem cert_e2422372853722 : check e2422372853722 [[],[]] .three = true := by decide
def e2422372854238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372854238 : Closed e2422372854238 ∧ code e2422372854238 = 11218465876446 := by decide
theorem cert_e2422372854238 : check e2422372854238 [[],[]] .three = true := by decide
def e2422372854262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372854262 : Closed e2422372854262 ∧ code e2422372854262 = 11218465876470 := by decide
theorem cert_e2422372854262 : check e2422372854262 [[],[]] .three = true := by decide
def e2422372855006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372855006 : Closed e2422372855006 ∧ code e2422372855006 = 11218465877214 := by decide
theorem cert_e2422372855006 : check e2422372855006 [[],[]] .three = true := by decide
def e2422372855022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372855022 : Closed e2422372855022 ∧ code e2422372855022 = 11218465877230 := by decide
theorem cert_e2422372855022 : check e2422372855022 [[],[]] .smaller = true := by decide
def e2422372855030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372855030 : Closed e2422372855030 ∧ code e2422372855030 = 11218465877238 := by decide
theorem cert_e2422372855030 : check e2422372855030 [[],[]] .smaller = true := by decide
def e2422372855034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372855034 : Closed e2422372855034 ∧ code e2422372855034 = 11218465877242 := by decide
theorem cert_e2422372855034 : check e2422372855034 [[],[]] .three = true := by decide
def e2422372855358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 4))))))))
theorem wire_e2422372855358 : Closed e2422372855358 ∧ code e2422372855358 = 11218465877566 := by decide
theorem cert_e2422372855358 : check e2422372855358 [[],[]] .three = true := by decide
def e2422372855414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372855414 : Closed e2422372855414 ∧ code e2422372855414 = 11218465877622 := by decide
theorem cert_e2422372855414 : check e2422372855414 [[],[]] .smaller = true := by decide
def e2422372855582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.lam (.var 3))))))))
theorem wire_e2422372855582 : Closed e2422372855582 ∧ code e2422372855582 = 11218465877790 := by decide
theorem cert_e2422372855582 : check e2422372855582 [[],[]] .three = true := by decide
def e2422372855606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372855606 : Closed e2422372855606 ∧ code e2422372855606 = 11218465877814 := by decide
theorem cert_e2422372855606 : check e2422372855606 [[],[]] .three = true := by decide
def e2422372855610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372855610 : Closed e2422372855610 ∧ code e2422372855610 = 11218465877818 := by decide
theorem cert_e2422372855610 : check e2422372855610 [[],[]] .three = true := by decide
def e2422372856286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2422372856286 : Closed e2422372856286 ∧ code e2422372856286 = 11218465878494 := by decide
theorem cert_e2422372856286 : check e2422372856286 [[],[]] .three = true := by decide
def e2422372856302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 2)))))))
theorem wire_e2422372856302 : Closed e2422372856302 ∧ code e2422372856302 = 11218465878510 := by decide
theorem cert_e2422372856302 : check e2422372856302 [[],[]] .smaller = true := by decide
def e2422372856310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2422372856310 : Closed e2422372856310 ∧ code e2422372856310 = 11218465878518 := by decide
theorem cert_e2422372856310 : check e2422372856310 [[],[]] .three = true := by decide
def e2422372856670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2422372856670 : Closed e2422372856670 ∧ code e2422372856670 = 11218465878878 := by decide
theorem cert_e2422372856670 : check e2422372856670 [[],[]] .three = true := by decide
def e2422372856686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422372856686 : Closed e2422372856686 ∧ code e2422372856686 = 11218465878894 := by decide
theorem cert_e2422372856686 : check e2422372856686 [[],[]] .smaller = true := by decide
def e2422372856694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422372856694 : Closed e2422372856694 ∧ code e2422372856694 = 11218465878902 := by decide
theorem cert_e2422372856694 : check e2422372856694 [[],[]] .smaller = true := by decide
def e2422372856698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2422372856698 : Closed e2422372856698 ∧ code e2422372856698 = 11218465878906 := by decide
theorem cert_e2422372856698 : check e2422372856698 [[],[]] .three = true := by decide
def e2422372856750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422372856750 : Closed e2422372856750 ∧ code e2422372856750 = 11218465878958 := by decide
theorem cert_e2422372856750 : check e2422372856750 [[],[]] .smaller = true := by decide
def e2422372856762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422372856762 : Closed e2422372856762 ∧ code e2422372856762 = 11218465878970 := by decide
theorem cert_e2422372856762 : check e2422372856762 [[],[]] .smaller = true := by decide
def e2422372856790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422372856790 : Closed e2422372856790 ∧ code e2422372856790 = 11218465878998 := by decide
theorem cert_e2422372856790 : check e2422372856790 [[],[]] .smaller = true := by decide
def e2422372856794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422372856794 : Closed e2422372856794 ∧ code e2422372856794 = 11218465879002 := by decide
theorem cert_e2422372856794 : check e2422372856794 [[],[]] .smaller = true := by decide
def e2422372856810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2422372856810 : Closed e2422372856810 ∧ code e2422372856810 = 11218465879018 := by decide
theorem cert_e2422372856810 : check e2422372856810 [[],[]] .three = true := by decide
def e2422372857054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372857054 : Closed e2422372857054 ∧ code e2422372857054 = 11218465879262 := by decide
theorem cert_e2422372857054 : check e2422372857054 [[],[]] .three = true := by decide
def e2422372857070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372857070 : Closed e2422372857070 ∧ code e2422372857070 = 11218465879278 := by decide
theorem cert_e2422372857070 : check e2422372857070 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422372822870
#print axioms Blc.Floor43.cert_e2422372822874
#print axioms Blc.Floor43.cert_e2422372822890
