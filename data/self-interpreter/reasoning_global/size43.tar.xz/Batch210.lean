import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392313608682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2392313608682 : Closed e2392313608682 ∧ code e2392313608682 = 11188406630890 := by decide
theorem cert_e2392313608682 : check e2392313608682 [[],[.left]] .chain = true := by decide
def e2392313608814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392313608814 : Closed e2392313608814 ∧ code e2392313608814 = 11188406631022 := by decide
theorem cert_e2392313608814 : check e2392313608814 [[],[.left]] .chain = true := by decide
def e2392313608826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392313608826 : Closed e2392313608826 ∧ code e2392313608826 = 11188406631034 := by decide
theorem cert_e2392313608826 : check e2392313608826 [[],[.left]] .chain = true := by decide
def e2392313609114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392313609114 : Closed e2392313609114 ∧ code e2392313609114 = 11188406631322 := by decide
theorem cert_e2392313609114 : check e2392313609114 [[],[.left]] .chain = true := by decide
def e2392313609430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2392313609430 : Closed e2392313609430 ∧ code e2392313609430 = 11188406631638 := by decide
theorem cert_e2392313609430 : check e2392313609430 [[],[.left]] .chain = true := by decide
def e2392313609434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2392313609434 : Closed e2392313609434 ∧ code e2392313609434 = 11188406631642 := by decide
theorem cert_e2392313609434 : check e2392313609434 [[],[.left]] .chain = true := by decide
def e2392313609450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2392313609450 : Closed e2392313609450 ∧ code e2392313609450 = 11188406631658 := by decide
theorem cert_e2392313609450 : check e2392313609450 [[],[.left]] .chain = true := by decide
def e2392313609526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392313609526 : Closed e2392313609526 ∧ code e2392313609526 = 11188406631734 := by decide
theorem cert_e2392313609526 : check e2392313609526 [[],[.left]] .chain = true := by decide
def e2392313609530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392313609530 : Closed e2392313609530 ∧ code e2392313609530 = 11188406631738 := by decide
theorem cert_e2392313609530 : check e2392313609530 [[],[.left]] .chain = true := by decide
def e2392313609626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392313609626 : Closed e2392313609626 ∧ code e2392313609626 = 11188406631834 := by decide
theorem cert_e2392313609626 : check e2392313609626 [[],[.left]] .chain = true := by decide
def e2392313613166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392313613166 : Closed e2392313613166 ∧ code e2392313613166 = 11188406635374 := by decide
theorem cert_e2392313613166 : check e2392313613166 [[],[.left]] .chain = true := by decide
def e2392313613174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392313613174 : Closed e2392313613174 ∧ code e2392313613174 = 11188406635382 := by decide
theorem cert_e2392313613174 : check e2392313613174 [[],[.left]] .chain = true := by decide
def e2392313613230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392313613230 : Closed e2392313613230 ∧ code e2392313613230 = 11188406635438 := by decide
theorem cert_e2392313613230 : check e2392313613230 [[],[.left]] .chain = true := by decide
def e2392313613242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392313613242 : Closed e2392313613242 ∧ code e2392313613242 = 11188406635450 := by decide
theorem cert_e2392313613242 : check e2392313613242 [[],[.left]] .chain = true := by decide
def e2392313613270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392313613270 : Closed e2392313613270 ∧ code e2392313613270 = 11188406635478 := by decide
theorem cert_e2392313613270 : check e2392313613270 [[],[.left]] .chain = true := by decide
def e2392313613274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392313613274 : Closed e2392313613274 ∧ code e2392313613274 = 11188406635482 := by decide
theorem cert_e2392313613274 : check e2392313613274 [[],[.left]] .chain = true := by decide
def e2392313613550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392313613550 : Closed e2392313613550 ∧ code e2392313613550 = 11188406635758 := by decide
theorem cert_e2392313613550 : check e2392313613550 [[],[.left]] .chain = true := by decide
def e2392313613558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392313613558 : Closed e2392313613558 ∧ code e2392313613558 = 11188406635766 := by decide
theorem cert_e2392313613558 : check e2392313613558 [[],[.left]] .chain = true := by decide
def e2392313613934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392313613934 : Closed e2392313613934 ∧ code e2392313613934 = 11188406636142 := by decide
theorem cert_e2392313613934 : check e2392313613934 [[],[.left]] .chain = true := by decide
def e2392313613946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392313613946 : Closed e2392313613946 ∧ code e2392313613946 = 11188406636154 := by decide
theorem cert_e2392313613946 : check e2392313613946 [[],[.left]] .chain = true := by decide
def e2392313614134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392313614134 : Closed e2392313614134 ∧ code e2392313614134 = 11188406636342 := by decide
theorem cert_e2392313614134 : check e2392313614134 [[],[.left]] .chain = true := by decide
def e2392313614138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392313614138 : Closed e2392313614138 ∧ code e2392313614138 = 11188406636346 := by decide
theorem cert_e2392313614138 : check e2392313614138 [[],[.left]] .chain = true := by decide
def e2392313619886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2392313619886 : Closed e2392313619886 ∧ code e2392313619886 = 11188406642094 := by decide
theorem cert_e2392313619886 : check e2392313619886 [[],[.left]] .chain = true := by decide
def e2392313619898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2392313619898 : Closed e2392313619898 ∧ code e2392313619898 = 11188406642106 := by decide
theorem cert_e2392313619898 : check e2392313619898 [[],[.left]] .chain = true := by decide
def e2392313619946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2392313619946 : Closed e2392313619946 ∧ code e2392313619946 = 11188406642154 := by decide
theorem cert_e2392313619946 : check e2392313619946 [[],[.left]] .chain = true := by decide
def e2392313620078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2392313620078 : Closed e2392313620078 ∧ code e2392313620078 = 11188406642286 := by decide
theorem cert_e2392313620078 : check e2392313620078 [[],[.left]] .chain = true := by decide
def e2392313620090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2392313620090 : Closed e2392313620090 ∧ code e2392313620090 = 11188406642298 := by decide
theorem cert_e2392313620090 : check e2392313620090 [[],[.left]] .chain = true := by decide
def e2392313620378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2392313620378 : Closed e2392313620378 ∧ code e2392313620378 = 11188406642586 := by decide
theorem cert_e2392313620378 : check e2392313620378 [[],[.left]] .chain = true := by decide
def e2392313623254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2392313623254 : Closed e2392313623254 ∧ code e2392313623254 = 11188406645462 := by decide
theorem cert_e2392313623254 : check e2392313623254 [[],[.left]] .chain = true := by decide
def e2392313623258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2392313623258 : Closed e2392313623258 ∧ code e2392313623258 = 11188406645466 := by decide
theorem cert_e2392313623258 : check e2392313623258 [[],[.left]] .chain = true := by decide
def e2392313623274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2392313623274 : Closed e2392313623274 ∧ code e2392313623274 = 11188406645482 := by decide
theorem cert_e2392313623274 : check e2392313623274 [[],[.left]] .chain = true := by decide
def e2392313623350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2392313623350 : Closed e2392313623350 ∧ code e2392313623350 = 11188406645558 := by decide
theorem cert_e2392313623350 : check e2392313623350 [[],[.left]] .chain = true := by decide
def e2392313623354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2392313623354 : Closed e2392313623354 ∧ code e2392313623354 = 11188406645562 := by decide
theorem cert_e2392313623354 : check e2392313623354 [[],[.left]] .chain = true := by decide
def e2392313623450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2392313623450 : Closed e2392313623450 ∧ code e2392313623450 = 11188406645658 := by decide
theorem cert_e2392313623450 : check e2392313623450 [[],[.left]] .chain = true := by decide
def e2392313760622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392313760622 : Closed e2392313760622 ∧ code e2392313760622 = 11188406782830 := by decide
theorem cert_e2392313760622 : check e2392313760622 [[],[.left]] .chain = true := by decide
def e2392313760630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392313760630 : Closed e2392313760630 ∧ code e2392313760630 = 11188406782838 := by decide
theorem cert_e2392313760630 : check e2392313760630 [[],[.left]] .chain = true := by decide
def e2392313760686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392313760686 : Closed e2392313760686 ∧ code e2392313760686 = 11188406782894 := by decide
theorem cert_e2392313760686 : check e2392313760686 [[],[.left]] .chain = true := by decide
def e2392313760698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392313760698 : Closed e2392313760698 ∧ code e2392313760698 = 11188406782906 := by decide
theorem cert_e2392313760698 : check e2392313760698 [[],[.left]] .chain = true := by decide
def e2392313760726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392313760726 : Closed e2392313760726 ∧ code e2392313760726 = 11188406782934 := by decide
theorem cert_e2392313760726 : check e2392313760726 [[],[.left]] .chain = true := by decide
def e2392313760730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392313760730 : Closed e2392313760730 ∧ code e2392313760730 = 11188406782938 := by decide
theorem cert_e2392313760730 : check e2392313760730 [[],[.left]] .chain = true := by decide
def e2392313761006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392313761006 : Closed e2392313761006 ∧ code e2392313761006 = 11188406783214 := by decide
theorem cert_e2392313761006 : check e2392313761006 [[],[.left]] .chain = true := by decide
def e2392313761014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392313761014 : Closed e2392313761014 ∧ code e2392313761014 = 11188406783222 := by decide
theorem cert_e2392313761014 : check e2392313761014 [[],[.left]] .chain = true := by decide
def e2392313761390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392313761390 : Closed e2392313761390 ∧ code e2392313761390 = 11188406783598 := by decide
theorem cert_e2392313761390 : check e2392313761390 [[],[.left]] .chain = true := by decide
def e2392313761402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392313761402 : Closed e2392313761402 ∧ code e2392313761402 = 11188406783610 := by decide
theorem cert_e2392313761402 : check e2392313761402 [[],[.left]] .chain = true := by decide
def e2392313761590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392313761590 : Closed e2392313761590 ∧ code e2392313761590 = 11188406783798 := by decide
theorem cert_e2392313761590 : check e2392313761590 [[],[.left]] .chain = true := by decide
def e2392313761594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392313761594 : Closed e2392313761594 ∧ code e2392313761594 = 11188406783802 := by decide
theorem cert_e2392313761594 : check e2392313761594 [[],[.left]] .chain = true := by decide
def e2392314350446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392314350446 : Closed e2392314350446 ∧ code e2392314350446 = 11188407372654 := by decide
theorem cert_e2392314350446 : check e2392314350446 [[],[.left],[.left],[.left],[],[.left]] .smaller = true := by decide
def e2392314350454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392314350454 : Closed e2392314350454 ∧ code e2392314350454 = 11188407372662 := by decide
theorem cert_e2392314350454 : check e2392314350454 [[],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2392314350510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392314350510 : Closed e2392314350510 ∧ code e2392314350510 = 11188407372718 := by decide
theorem cert_e2392314350510 : check e2392314350510 [[],[.left],[.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e2392314350522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392314350522 : Closed e2392314350522 ∧ code e2392314350522 = 11188407372730 := by decide
private def t_e2392314350522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2392314350522 : ¬ IsSelfInterpreter e2392314350522 :=
  wSource (t := t_e2392314350522) (replay_sound (ps := []) (t := e2392314350522) (by decide)) (by decide)
def e2392314350550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392314350550 : Closed e2392314350550 ∧ code e2392314350550 = 11188407372758 := by decide
theorem cert_e2392314350550 : check e2392314350550 [[],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2392314350554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392314350554 : Closed e2392314350554 ∧ code e2392314350554 = 11188407372762 := by decide
private def t_e2392314350554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2392314350554 : ¬ IsSelfInterpreter e2392314350554 :=
  wSource (t := t_e2392314350554) (replay_sound (ps := []) (t := e2392314350554) (by decide)) (by decide)
def e2392314350830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392314350830 : Closed e2392314350830 ∧ code e2392314350830 = 11188407373038 := by decide
theorem cert_e2392314350830 : check e2392314350830 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2392314350838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392314350838 : Closed e2392314350838 ∧ code e2392314350838 = 11188407373046 := by decide
theorem cert_e2392314350838 : check e2392314350838 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2392314351214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392314351214 : Closed e2392314351214 ∧ code e2392314351214 = 11188407373422 := by decide
theorem cert_e2392314351214 : check e2392314351214 [[],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e2392314351226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392314351226 : Closed e2392314351226 ∧ code e2392314351226 = 11188407373434 := by decide
theorem cert_e2392314351226 : check e2392314351226 [[],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e2392314351414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392314351414 : Closed e2392314351414 ∧ code e2392314351414 = 11188407373622 := by decide
theorem cert_e2392314351414 : check e2392314351414 [[],[.left],[.left],[.left],[],[],[.left]] .chain = true := by decide
def e2392314351418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392314351418 : Closed e2392314351418 ∧ code e2392314351418 = 11188407373626 := by decide
theorem cert_e2392314351418 : check e2392314351418 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e2392341966362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392341966362 : Closed e2392341966362 ∧ code e2392341966362 = 11188434988570 := by decide
private def t_e2392341966362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392341966362 : ¬ IsSelfInterpreter e2392341966362 :=
  wSource (t := t_e2392341966362) (replay_sound (ps := []) (t := e2392341966362) (by decide)) (by decide)
def e2392341968410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392341968410 : Closed e2392341968410 ∧ code e2392341968410 = 11188434990618 := by decide
private def t_e2392341968410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392341968410 : ¬ IsSelfInterpreter e2392341968410 :=
  wSource (t := t_e2392341968410) (replay_sound (ps := []) (t := e2392341968410) (by decide)) (by decide)
def e2392342247450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342247450 : Closed e2392342247450 ∧ code e2392342247450 = 11188435269658 := by decide
theorem cert_e2392342247450 : check e2392342247450 [[]] .width = true := by decide
def e2392342255642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342255642 : Closed e2392342255642 ∧ code e2392342255642 = 11188435277850 := by decide
theorem cert_e2392342255642 : check e2392342255642 [[]] .width = true := by decide
def e2392342277658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342277658 : Closed e2392342277658 ∧ code e2392342277658 = 11188435299866 := by decide
private def t_e2392342277658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342277658 : ¬ IsSelfInterpreter e2392342277658 :=
  wSource (t := t_e2392342277658) (replay_sound (ps := []) (t := e2392342277658) (by decide)) (by decide)
def e2392342312986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342312986 : Closed e2392342312986 ∧ code e2392342312986 = 11188435335194 := by decide
theorem cert_e2392342312986 : check e2392342312986 [[]] .width = true := by decide
def e2392342323738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342323738 : Closed e2392342323738 ∧ code e2392342323738 = 11188435345946 := by decide
private def t_e2392342323738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342323738 : ¬ IsSelfInterpreter e2392342323738 :=
  wSource (t := t_e2392342323738) (replay_sound (ps := []) (t := e2392342323738) (by decide)) (by decide)
def e2392342325274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342325274 : Closed e2392342325274 ∧ code e2392342325274 = 11188435347482 := by decide
theorem cert_e2392342325274 : check e2392342325274 [[]] .width = true := by decide
def e2392342326810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342326810 : Closed e2392342326810 ∧ code e2392342326810 = 11188435349018 := by decide
private def t_e2392342326810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342326810 : ¬ IsSelfInterpreter e2392342326810 :=
  wSource (t := t_e2392342326810) (replay_sound (ps := []) (t := e2392342326810) (by decide)) (by decide)
def e2392342337050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342337050 : Closed e2392342337050 ∧ code e2392342337050 = 11188435359258 := by decide
private def t_e2392342337050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342337050 : ¬ IsSelfInterpreter e2392342337050 :=
  wSource (t := t_e2392342337050) (replay_sound (ps := []) (t := e2392342337050) (by decide)) (by decide)
def e2392342353946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342353946 : Closed e2392342353946 ∧ code e2392342353946 = 11188435376154 := by decide
theorem cert_e2392342353946 : check e2392342353946 [[]] .width = true := by decide
def e2392342356506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342356506 : Closed e2392342356506 ∧ code e2392342356506 = 11188435378714 := by decide
private def t_e2392342356506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342356506 : ¬ IsSelfInterpreter e2392342356506 :=
  wSource (t := t_e2392342356506) (replay_sound (ps := []) (t := e2392342356506) (by decide)) (by decide)
def e2392342358042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342358042 : Closed e2392342358042 ∧ code e2392342358042 = 11188435380250 := by decide
theorem cert_e2392342358042 : check e2392342358042 [[]] .width = true := by decide
def e2392342359578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342359578 : Closed e2392342359578 ∧ code e2392342359578 = 11188435381786 := by decide
private def t_e2392342359578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342359578 : ¬ IsSelfInterpreter e2392342359578 :=
  wSource (t := t_e2392342359578) (replay_sound (ps := []) (t := e2392342359578) (by decide)) (by decide)
def e2392342361626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342361626 : Closed e2392342361626 ∧ code e2392342361626 = 11188435383834 := by decide
private def t_e2392342361626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342361626 : ¬ IsSelfInterpreter e2392342361626 :=
  wSource (t := t_e2392342361626) (replay_sound (ps := []) (t := e2392342361626) (by decide)) (by decide)
def e2392342441498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342441498 : Closed e2392342441498 ∧ code e2392342441498 = 11188435463706 := by decide
private def t_e2392342441498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342441498 : ¬ IsSelfInterpreter e2392342441498 :=
  wSource (t := t_e2392342441498) (replay_sound (ps := []) (t := e2392342441498) (by decide)) (by decide)
def e2392342444570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342444570 : Closed e2392342444570 ∧ code e2392342444570 = 11188435466778 := by decide
private def t_e2392342444570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342444570 : ¬ IsSelfInterpreter e2392342444570 :=
  wSource (t := t_e2392342444570) (replay_sound (ps := []) (t := e2392342444570) (by decide)) (by decide)
def e2392342539802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342539802 : Closed e2392342539802 ∧ code e2392342539802 = 11188435562010 := by decide
private def t_e2392342539802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342539802 : ¬ IsSelfInterpreter e2392342539802 :=
  wSource (t := t_e2392342539802) (replay_sound (ps := []) (t := e2392342539802) (by decide)) (by decide)
def e2392342575130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342575130 : Closed e2392342575130 ∧ code e2392342575130 = 11188435597338 := by decide
theorem cert_e2392342575130 : check e2392342575130 [[]] .width = true := by decide
def e2392342585882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342585882 : Closed e2392342585882 ∧ code e2392342585882 = 11188435608090 := by decide
private def t_e2392342585882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342585882 : ¬ IsSelfInterpreter e2392342585882 :=
  wSource (t := t_e2392342585882) (replay_sound (ps := []) (t := e2392342585882) (by decide)) (by decide)
def e2392342587418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342587418 : Closed e2392342587418 ∧ code e2392342587418 = 11188435609626 := by decide
theorem cert_e2392342587418 : check e2392342587418 [[]] .width = true := by decide
def e2392342588954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342588954 : Closed e2392342588954 ∧ code e2392342588954 = 11188435611162 := by decide
private def t_e2392342588954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342588954 : ¬ IsSelfInterpreter e2392342588954 :=
  wSource (t := t_e2392342588954) (replay_sound (ps := []) (t := e2392342588954) (by decide)) (by decide)
def e2392342628890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342628890 : Closed e2392342628890 ∧ code e2392342628890 = 11188435651098 := by decide
private def t_e2392342628890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342628890 : ¬ IsSelfInterpreter e2392342628890 :=
  wSource (t := t_e2392342628890) (replay_sound (ps := []) (t := e2392342628890) (by decide)) (by decide)
def e2392342635034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342635034 : Closed e2392342635034 ∧ code e2392342635034 = 11188435657242 := by decide
private def t_e2392342635034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342635034 : ¬ IsSelfInterpreter e2392342635034 :=
  wSource (t := t_e2392342635034) (replay_sound (ps := []) (t := e2392342635034) (by decide)) (by decide)
def e2392342636570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342636570 : Closed e2392342636570 ∧ code e2392342636570 = 11188435658778 := by decide
theorem cert_e2392342636570 : check e2392342636570 [[]] .width = true := by decide
def e2392342638106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342638106 : Closed e2392342638106 ∧ code e2392342638106 = 11188435660314 := by decide
private def t_e2392342638106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342638106 : ¬ IsSelfInterpreter e2392342638106 :=
  wSource (t := t_e2392342638106) (replay_sound (ps := []) (t := e2392342638106) (by decide)) (by decide)
def e2392342641178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342641178 : Closed e2392342641178 ∧ code e2392342641178 = 11188435663386 := by decide
private def t_e2392342641178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342641178 : ¬ IsSelfInterpreter e2392342641178 :=
  wSource (t := t_e2392342641178) (replay_sound (ps := []) (t := e2392342641178) (by decide)) (by decide)
def e2392342681114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342681114 : Closed e2392342681114 ∧ code e2392342681114 = 11188435703322 := by decide
private def t_e2392342681114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342681114 : ¬ IsSelfInterpreter e2392342681114 :=
  wSource (t := t_e2392342681114) (replay_sound (ps := []) (t := e2392342681114) (by decide)) (by decide)
def e2392342682138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342682138 : Closed e2392342682138 ∧ code e2392342682138 = 11188435704346 := by decide
private def t_e2392342682138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342682138 : ¬ IsSelfInterpreter e2392342682138 :=
  wSource (t := t_e2392342682138) (replay_sound (ps := []) (t := e2392342682138) (by decide)) (by decide)
def e2392342730266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342730266 : Closed e2392342730266 ∧ code e2392342730266 = 11188435752474 := by decide
private def t_e2392342730266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342730266 : ¬ IsSelfInterpreter e2392342730266 :=
  wSource (t := t_e2392342730266) (replay_sound (ps := []) (t := e2392342730266) (by decide)) (by decide)
def e2392342747162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342747162 : Closed e2392342747162 ∧ code e2392342747162 = 11188435769370 := by decide
theorem cert_e2392342747162 : check e2392342747162 [[]] .width = true := by decide
def e2392342749722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342749722 : Closed e2392342749722 ∧ code e2392342749722 = 11188435771930 := by decide
private def t_e2392342749722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342749722 : ¬ IsSelfInterpreter e2392342749722 :=
  wSource (t := t_e2392342749722) (replay_sound (ps := []) (t := e2392342749722) (by decide)) (by decide)
def e2392342751258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342751258 : Closed e2392342751258 ∧ code e2392342751258 = 11188435773466 := by decide
theorem cert_e2392342751258 : check e2392342751258 [[]] .width = true := by decide
def e2392342752794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342752794 : Closed e2392342752794 ∧ code e2392342752794 = 11188435775002 := by decide
private def t_e2392342752794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342752794 : ¬ IsSelfInterpreter e2392342752794 :=
  wSource (t := t_e2392342752794) (replay_sound (ps := []) (t := e2392342752794) (by decide)) (by decide)
def e2392342754842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342754842 : Closed e2392342754842 ∧ code e2392342754842 = 11188435777050 := by decide
private def t_e2392342754842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342754842 : ¬ IsSelfInterpreter e2392342754842 :=
  wSource (t := t_e2392342754842) (replay_sound (ps := []) (t := e2392342754842) (by decide)) (by decide)
def e2392342759962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342759962 : Closed e2392342759962 ∧ code e2392342759962 = 11188435782170 := by decide
private def t_e2392342759962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342759962 : ¬ IsSelfInterpreter e2392342759962 :=
  wSource (t := t_e2392342759962) (replay_sound (ps := []) (t := e2392342759962) (by decide)) (by decide)
def e2392342766106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342766106 : Closed e2392342766106 ∧ code e2392342766106 = 11188435788314 := by decide
private def t_e2392342766106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342766106 : ¬ IsSelfInterpreter e2392342766106 :=
  wSource (t := t_e2392342766106) (replay_sound (ps := []) (t := e2392342766106) (by decide)) (by decide)
def e2392342767642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392342767642 : Closed e2392342767642 ∧ code e2392342767642 = 11188435789850 := by decide
theorem cert_e2392342767642 : check e2392342767642 [[]] .width = true := by decide
def e2392342769178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342769178 : Closed e2392342769178 ∧ code e2392342769178 = 11188435791386 := by decide
private def t_e2392342769178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342769178 : ¬ IsSelfInterpreter e2392342769178 :=
  wSource (t := t_e2392342769178) (replay_sound (ps := []) (t := e2392342769178) (by decide)) (by decide)
def e2392342772250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342772250 : Closed e2392342772250 ∧ code e2392342772250 = 11188435794458 := by decide
private def t_e2392342772250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342772250 : ¬ IsSelfInterpreter e2392342772250 :=
  wSource (t := t_e2392342772250) (replay_sound (ps := []) (t := e2392342772250) (by decide)) (by decide)
def e2392342779418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342779418 : Closed e2392342779418 ∧ code e2392342779418 = 11188435801626 := by decide
private def t_e2392342779418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342779418 : ¬ IsSelfInterpreter e2392342779418 :=
  wSource (t := t_e2392342779418) (replay_sound (ps := []) (t := e2392342779418) (by decide)) (by decide)
def e2392342780442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392342780442 : Closed e2392342780442 ∧ code e2392342780442 = 11188435802650 := by decide
private def t_e2392342780442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392342780442 : ¬ IsSelfInterpreter e2392342780442 :=
  wSource (t := t_e2392342780442) (replay_sound (ps := []) (t := e2392342780442) (by decide)) (by decide)
def e2392343047706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343047706 : Closed e2392343047706 ∧ code e2392343047706 = 11188436069914 := by decide
private def t_e2392343047706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343047706 : ¬ IsSelfInterpreter e2392343047706 :=
  wSource (t := t_e2392343047706) (replay_sound (ps := []) (t := e2392343047706) (by decide)) (by decide)
def e2392343049754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343049754 : Closed e2392343049754 ∧ code e2392343049754 = 11188436071962 := by decide
private def t_e2392343049754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343049754 : ¬ IsSelfInterpreter e2392343049754 :=
  wSource (t := t_e2392343049754) (replay_sound (ps := []) (t := e2392343049754) (by decide)) (by decide)
def e2392343244314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343244314 : Closed e2392343244314 ∧ code e2392343244314 = 11188436266522 := by decide
private def t_e2392343244314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343244314 : ¬ IsSelfInterpreter e2392343244314 :=
  wSource (t := t_e2392343244314) (replay_sound (ps := []) (t := e2392343244314) (by decide)) (by decide)
def e2392343246362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343246362 : Closed e2392343246362 ∧ code e2392343246362 = 11188436268570 := by decide
private def t_e2392343246362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343246362 : ¬ IsSelfInterpreter e2392343246362 :=
  wSource (t := t_e2392343246362) (replay_sound (ps := []) (t := e2392343246362) (by decide)) (by decide)
def e2392343387674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343387674 : Closed e2392343387674 ∧ code e2392343387674 = 11188436409882 := by decide
private def t_e2392343387674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343387674 : ¬ IsSelfInterpreter e2392343387674 :=
  wSource (t := t_e2392343387674) (replay_sound (ps := []) (t := e2392343387674) (by decide)) (by decide)
def e2392343408838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392343408838 : Closed e2392343408838 ∧ code e2392343408838 = 11188436431046 := by decide
theorem cert_e2392343408838 : check e2392343408838 [[]] .width = true := by decide
def e2392343416346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343416346 : Closed e2392343416346 ∧ code e2392343416346 = 11188436438554 := by decide
private def t_e2392343416346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343416346 : ¬ IsSelfInterpreter e2392343416346 :=
  wSource (t := t_e2392343416346) (replay_sound (ps := []) (t := e2392343416346) (by decide)) (by decide)
def e2392343425222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392343425222 : Closed e2392343425222 ∧ code e2392343425222 = 11188436447430 := by decide
theorem cert_e2392343425222 : check e2392343425222 [[]] .width = true := by decide
def e2392343820314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392343820314 : Closed e2392343820314 ∧ code e2392343820314 = 11188436842522 := by decide
theorem cert_e2392343820314 : check e2392343820314 [[]] .width = true := by decide
def e2392343828506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392343828506 : Closed e2392343828506 ∧ code e2392343828506 = 11188436850714 := by decide
theorem cert_e2392343828506 : check e2392343828506 [[]] .width = true := by decide
def e2392343850522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343850522 : Closed e2392343850522 ∧ code e2392343850522 = 11188436872730 := by decide
private def t_e2392343850522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343850522 : ¬ IsSelfInterpreter e2392343850522 :=
  wSource (t := t_e2392343850522) (replay_sound (ps := []) (t := e2392343850522) (by decide)) (by decide)
def e2392343885850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392343885850 : Closed e2392343885850 ∧ code e2392343885850 = 11188436908058 := by decide
theorem cert_e2392343885850 : check e2392343885850 [[]] .width = true := by decide
def e2392343896602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343896602 : Closed e2392343896602 ∧ code e2392343896602 = 11188436918810 := by decide
private def t_e2392343896602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343896602 : ¬ IsSelfInterpreter e2392343896602 :=
  wSource (t := t_e2392343896602) (replay_sound (ps := []) (t := e2392343896602) (by decide)) (by decide)
def e2392343898138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392343898138 : Closed e2392343898138 ∧ code e2392343898138 = 11188436920346 := by decide
theorem cert_e2392343898138 : check e2392343898138 [[]] .width = true := by decide
def e2392343899674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343899674 : Closed e2392343899674 ∧ code e2392343899674 = 11188436921882 := by decide
private def t_e2392343899674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343899674 : ¬ IsSelfInterpreter e2392343899674 :=
  wSource (t := t_e2392343899674) (replay_sound (ps := []) (t := e2392343899674) (by decide)) (by decide)
def e2392343909914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343909914 : Closed e2392343909914 ∧ code e2392343909914 = 11188436932122 := by decide
private def t_e2392343909914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343909914 : ¬ IsSelfInterpreter e2392343909914 :=
  wSource (t := t_e2392343909914) (replay_sound (ps := []) (t := e2392343909914) (by decide)) (by decide)
def e2392343926810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392343926810 : Closed e2392343926810 ∧ code e2392343926810 = 11188436949018 := by decide
theorem cert_e2392343926810 : check e2392343926810 [[]] .width = true := by decide
def e2392343929370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343929370 : Closed e2392343929370 ∧ code e2392343929370 = 11188436951578 := by decide
private def t_e2392343929370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343929370 : ¬ IsSelfInterpreter e2392343929370 :=
  wSource (t := t_e2392343929370) (replay_sound (ps := []) (t := e2392343929370) (by decide)) (by decide)
def e2392343930906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392343930906 : Closed e2392343930906 ∧ code e2392343930906 = 11188436953114 := by decide
theorem cert_e2392343930906 : check e2392343930906 [[]] .width = true := by decide
def e2392343932442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343932442 : Closed e2392343932442 ∧ code e2392343932442 = 11188436954650 := by decide
private def t_e2392343932442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343932442 : ¬ IsSelfInterpreter e2392343932442 :=
  wSource (t := t_e2392343932442) (replay_sound (ps := []) (t := e2392343932442) (by decide)) (by decide)
def e2392343934490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392343934490 : Closed e2392343934490 ∧ code e2392343934490 = 11188436956698 := by decide
private def t_e2392343934490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392343934490 : ¬ IsSelfInterpreter e2392343934490 :=
  wSource (t := t_e2392343934490) (replay_sound (ps := []) (t := e2392343934490) (by decide)) (by decide)
def e2392344213530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392344213530 : Closed e2392344213530 ∧ code e2392344213530 = 11188437235738 := by decide
theorem cert_e2392344213530 : check e2392344213530 [[]] .width = true := by decide
def e2392344221722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392344221722 : Closed e2392344221722 ∧ code e2392344221722 = 11188437243930 := by decide
theorem cert_e2392344221722 : check e2392344221722 [[]] .width = true := by decide
def e2392344509978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392344509978 : Closed e2392344509978 ∧ code e2392344509978 = 11188437532186 := by decide
private def t_e2392344509978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392344509978 : ¬ IsSelfInterpreter e2392344509978 :=
  wSource (t := t_e2392344509978) (replay_sound (ps := []) (t := e2392344509978) (by decide)) (by decide)
def e2392344555718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392344555718 : Closed e2392344555718 ∧ code e2392344555718 = 11188437577926 := by decide
theorem cert_e2392344555718 : check e2392344555718 [[]] .width = true := by decide
def e2392344606746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392344606746 : Closed e2392344606746 ∧ code e2392344606746 = 11188437628954 := by decide
theorem cert_e2392344606746 : check e2392344606746 [[]] .width = true := by decide
def e2392344617498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392344617498 : Closed e2392344617498 ∧ code e2392344617498 = 11188437639706 := by decide
private def t_e2392344617498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392344617498 : ¬ IsSelfInterpreter e2392344617498 :=
  wSource (t := t_e2392344617498) (replay_sound (ps := []) (t := e2392344617498) (by decide)) (by decide)
def e2392344619034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392344619034 : Closed e2392344619034 ∧ code e2392344619034 = 11188437641242 := by decide
theorem cert_e2392344619034 : check e2392344619034 [[]] .width = true := by decide
def e2392344620570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392344620570 : Closed e2392344620570 ∧ code e2392344620570 = 11188437642778 := by decide
private def t_e2392344620570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392344620570 : ¬ IsSelfInterpreter e2392344620570 :=
  wSource (t := t_e2392344620570) (replay_sound (ps := []) (t := e2392344620570) (by decide)) (by decide)
def e2392344723482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392344723482 : Closed e2392344723482 ∧ code e2392344723482 = 11188437745690 := by decide
theorem cert_e2392344723482 : check e2392344723482 [[]] .width = true := by decide
def e2392344723574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392344723574 : Closed e2392344723574 ∧ code e2392344723574 = 11188437745782 := by decide
theorem cert_e2392344723574 : check e2392344723574 [[]] .width = true := by decide
def e2392344723818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392344723818 : Closed e2392344723818 ∧ code e2392344723818 = 11188437746026 := by decide
theorem cert_e2392344723818 : check e2392344723818 [[]] .width = true := by decide
def e2392344723866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392344723866 : Closed e2392344723866 ∧ code e2392344723866 = 11188437746074 := by decide
theorem cert_e2392344723866 : check e2392344723866 [[]] .width = true := by decide
def e2392344724874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392344724874 : Closed e2392344724874 ∧ code e2392344724874 = 11188437747082 := by decide
theorem cert_e2392344724874 : check e2392344724874 [[]] .width = true := by decide
def e2392344724898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392344724898 : Closed e2392344724898 ∧ code e2392344724898 = 11188437747106 := by decide
private def t_e2392344724898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392344724898 : ¬ IsSelfInterpreter e2392344724898 :=
  wSource (t := t_e2392344724898) (replay_sound (ps := []) (t := e2392344724898) (by decide)) (by decide)
def e2392344725006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392344725006 : Closed e2392344725006 ∧ code e2392344725006 = 11188437747214 := by decide
theorem cert_e2392344725006 : check e2392344725006 [[]] .width = true := by decide
def e2392344725018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392344725018 : Closed e2392344725018 ∧ code e2392344725018 = 11188437747226 := by decide
private def t_e2392344725018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392344725018 : ¬ IsSelfInterpreter e2392344725018 :=
  wSource (t := t_e2392344725018) (replay_sound (ps := []) (t := e2392344725018) (by decide)) (by decide)
def e2392344725090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392344725090 : Closed e2392344725090 ∧ code e2392344725090 = 11188437747298 := by decide
theorem cert_e2392344725090 : check e2392344725090 [[]] .width = true := by decide
def e2392344763930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392344763930 : Closed e2392344763930 ∧ code e2392344763930 = 11188437786138 := by decide
private def t_e2392344763930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392344763930 : ¬ IsSelfInterpreter e2392344763930 :=
  wSource (t := t_e2392344763930) (replay_sound (ps := []) (t := e2392344763930) (by decide)) (by decide)
def e2392344785094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392344785094 : Closed e2392344785094 ∧ code e2392344785094 = 11188437807302 := by decide
theorem cert_e2392344785094 : check e2392344785094 [[]] .width = true := by decide
def e2392344811546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392344811546 : Closed e2392344811546 ∧ code e2392344811546 = 11188437833754 := by decide
theorem cert_e2392344811546 : check e2392344811546 [[]] .width = true := by decide
def e2392344814106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392344814106 : Closed e2392344814106 ∧ code e2392344814106 = 11188437836314 := by decide
private def t_e2392344814106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392344814106 : ¬ IsSelfInterpreter e2392344814106 :=
  wSource (t := t_e2392344814106) (replay_sound (ps := []) (t := e2392344814106) (by decide)) (by decide)
def e2392344815642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392344815642 : Closed e2392344815642 ∧ code e2392344815642 = 11188437837850 := by decide
theorem cert_e2392344815642 : check e2392344815642 [[]] .width = true := by decide
def e2392344817178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392344817178 : Closed e2392344817178 ∧ code e2392344817178 = 11188437839386 := by decide
private def t_e2392344817178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392344817178 : ¬ IsSelfInterpreter e2392344817178 :=
  wSource (t := t_e2392344817178) (replay_sound (ps := []) (t := e2392344817178) (by decide)) (by decide)
def e2392344819226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392344819226 : Closed e2392344819226 ∧ code e2392344819226 = 11188437841434 := by decide
private def t_e2392344819226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392344819226 : ¬ IsSelfInterpreter e2392344819226 :=
  wSource (t := t_e2392344819226) (replay_sound (ps := []) (t := e2392344819226) (by decide)) (by decide)
def e2392344854554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392344854554 : Closed e2392344854554 ∧ code e2392344854554 = 11188437876762 := by decide
theorem cert_e2392344854554 : check e2392344854554 [[]] .width = true := by decide
def e2392344854646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392344854646 : Closed e2392344854646 ∧ code e2392344854646 = 11188437876854 := by decide
theorem cert_e2392344854646 : check e2392344854646 [[]] .width = true := by decide
def e2392344854890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392344854890 : Closed e2392344854890 ∧ code e2392344854890 = 11188437877098 := by decide
theorem cert_e2392344854890 : check e2392344854890 [[]] .width = true := by decide
def e2392344854938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392344854938 : Closed e2392344854938 ∧ code e2392344854938 = 11188437877146 := by decide
theorem cert_e2392344854938 : check e2392344854938 [[]] .width = true := by decide
def e2392344855946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392344855946 : Closed e2392344855946 ∧ code e2392344855946 = 11188437878154 := by decide
theorem cert_e2392344855946 : check e2392344855946 [[]] .width = true := by decide
def e2392344855970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392344855970 : Closed e2392344855970 ∧ code e2392344855970 = 11188437878178 := by decide
private def t_e2392344855970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392344855970 : ¬ IsSelfInterpreter e2392344855970 :=
  wSource (t := t_e2392344855970) (replay_sound (ps := []) (t := e2392344855970) (by decide)) (by decide)
def e2392344856078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392344856078 : Closed e2392344856078 ∧ code e2392344856078 = 11188437878286 := by decide
theorem cert_e2392344856078 : check e2392344856078 [[]] .width = true := by decide
def e2392344856090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392344856090 : Closed e2392344856090 ∧ code e2392344856090 = 11188437878298 := by decide
private def t_e2392344856090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392344856090 : ¬ IsSelfInterpreter e2392344856090 :=
  wSource (t := t_e2392344856090) (replay_sound (ps := []) (t := e2392344856090) (by decide)) (by decide)
def e2392344856162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392344856162 : Closed e2392344856162 ∧ code e2392344856162 = 11188437878370 := by decide
theorem cert_e2392344856162 : check e2392344856162 [[]] .width = true := by decide
def e2392345079322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345079322 : Closed e2392345079322 ∧ code e2392345079322 = 11188438101530 := by decide
private def t_e2392345079322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345079322 : ¬ IsSelfInterpreter e2392345079322 :=
  wSource (t := t_e2392345079322) (replay_sound (ps := []) (t := e2392345079322) (by decide)) (by decide)
def e2392345082394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345082394 : Closed e2392345082394 ∧ code e2392345082394 = 11188438104602 := by decide
private def t_e2392345082394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345082394 : ¬ IsSelfInterpreter e2392345082394 :=
  wSource (t := t_e2392345082394) (replay_sound (ps := []) (t := e2392345082394) (by decide)) (by decide)
def e2392345177626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345177626 : Closed e2392345177626 ∧ code e2392345177626 = 11188438199834 := by decide
private def t_e2392345177626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345177626 : ¬ IsSelfInterpreter e2392345177626 :=
  wSource (t := t_e2392345177626) (replay_sound (ps := []) (t := e2392345177626) (by decide)) (by decide)
def e2392345180698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345180698 : Closed e2392345180698 ∧ code e2392345180698 = 11188438202906 := by decide
private def t_e2392345180698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345180698 : ¬ IsSelfInterpreter e2392345180698 :=
  wSource (t := t_e2392345180698) (replay_sound (ps := []) (t := e2392345180698) (by decide)) (by decide)
def e2392345222682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345222682 : Closed e2392345222682 ∧ code e2392345222682 = 11188438244890 := by decide
private def t_e2392345222682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345222682 : ¬ IsSelfInterpreter e2392345222682 :=
  wSource (t := t_e2392345222682) (replay_sound (ps := []) (t := e2392345222682) (by decide)) (by decide)
def e2392345243846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392345243846 : Closed e2392345243846 ∧ code e2392345243846 = 11188438266054 := by decide
theorem cert_e2392345243846 : check e2392345243846 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392314350522
#print axioms Blc.Floor43.cert_e2392314350554
#print axioms Blc.Floor43.cert_e2392341966362
#print axioms Blc.Floor43.cert_e2392341968410
#print axioms Blc.Floor43.cert_e2392342277658
#print axioms Blc.Floor43.cert_e2392342323738
#print axioms Blc.Floor43.cert_e2392342326810
#print axioms Blc.Floor43.cert_e2392342337050
#print axioms Blc.Floor43.cert_e2392342356506
#print axioms Blc.Floor43.cert_e2392342359578
#print axioms Blc.Floor43.cert_e2392342361626
#print axioms Blc.Floor43.cert_e2392342441498
#print axioms Blc.Floor43.cert_e2392342444570
#print axioms Blc.Floor43.cert_e2392342539802
#print axioms Blc.Floor43.cert_e2392342585882
#print axioms Blc.Floor43.cert_e2392342588954
#print axioms Blc.Floor43.cert_e2392342628890
#print axioms Blc.Floor43.cert_e2392342635034
#print axioms Blc.Floor43.cert_e2392342638106
#print axioms Blc.Floor43.cert_e2392342641178
#print axioms Blc.Floor43.cert_e2392342681114
#print axioms Blc.Floor43.cert_e2392342682138
#print axioms Blc.Floor43.cert_e2392342730266
#print axioms Blc.Floor43.cert_e2392342749722
#print axioms Blc.Floor43.cert_e2392342752794
#print axioms Blc.Floor43.cert_e2392342754842
#print axioms Blc.Floor43.cert_e2392342759962
#print axioms Blc.Floor43.cert_e2392342766106
#print axioms Blc.Floor43.cert_e2392342769178
#print axioms Blc.Floor43.cert_e2392342772250
#print axioms Blc.Floor43.cert_e2392342779418
#print axioms Blc.Floor43.cert_e2392342780442
#print axioms Blc.Floor43.cert_e2392343047706
#print axioms Blc.Floor43.cert_e2392343049754
#print axioms Blc.Floor43.cert_e2392343244314
#print axioms Blc.Floor43.cert_e2392343246362
#print axioms Blc.Floor43.cert_e2392343387674
#print axioms Blc.Floor43.cert_e2392343416346
#print axioms Blc.Floor43.cert_e2392343850522
#print axioms Blc.Floor43.cert_e2392343896602
#print axioms Blc.Floor43.cert_e2392343899674
#print axioms Blc.Floor43.cert_e2392343909914
#print axioms Blc.Floor43.cert_e2392343929370
#print axioms Blc.Floor43.cert_e2392343932442
#print axioms Blc.Floor43.cert_e2392343934490
#print axioms Blc.Floor43.cert_e2392344509978
#print axioms Blc.Floor43.cert_e2392344617498
#print axioms Blc.Floor43.cert_e2392344620570
#print axioms Blc.Floor43.cert_e2392344724898
#print axioms Blc.Floor43.cert_e2392344725018
#print axioms Blc.Floor43.cert_e2392344763930
#print axioms Blc.Floor43.cert_e2392344814106
#print axioms Blc.Floor43.cert_e2392344817178
#print axioms Blc.Floor43.cert_e2392344819226
#print axioms Blc.Floor43.cert_e2392344855970
#print axioms Blc.Floor43.cert_e2392344856090
#print axioms Blc.Floor43.cert_e2392345079322
#print axioms Blc.Floor43.cert_e2392345082394
#print axioms Blc.Floor43.cert_e2392345177626
#print axioms Blc.Floor43.cert_e2392345180698
#print axioms Blc.Floor43.cert_e2392345222682
