import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2408520404590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408520404590 : Closed e2408520404590 ∧ code e2408520404590 = 11204613426798 := by decide
theorem cert_e2408520404590 : check e2408520404590 [[],[]] .chain = true := by decide
def e2408520404602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408520404602 : Closed e2408520404602 ∧ code e2408520404602 = 11204613426810 := by decide
theorem cert_e2408520404602 : check e2408520404602 [[],[]] .chain = true := by decide
def e2408520404790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408520404790 : Closed e2408520404790 ∧ code e2408520404790 = 11204613426998 := by decide
theorem cert_e2408520404790 : check e2408520404790 [[],[]] .chain = true := by decide
def e2408520404794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408520404794 : Closed e2408520404794 ∧ code e2408520404794 = 11204613427002 := by decide
theorem cert_e2408520404794 : check e2408520404794 [[],[]] .chain = true := by decide
def e2408520410542 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2408520410542 : Closed e2408520410542 ∧ code e2408520410542 = 11204613432750 := by decide
theorem cert_e2408520410542 : check e2408520410542 [[],[]] .chain = true := by decide
def e2408520410554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2408520410554 : Closed e2408520410554 ∧ code e2408520410554 = 11204613432762 := by decide
theorem cert_e2408520410554 : check e2408520410554 [[],[]] .chain = true := by decide
def e2408520410602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2408520410602 : Closed e2408520410602 ∧ code e2408520410602 = 11204613432810 := by decide
theorem cert_e2408520410602 : check e2408520410602 [[],[]] .chain = true := by decide
def e2408520410734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2408520410734 : Closed e2408520410734 ∧ code e2408520410734 = 11204613432942 := by decide
theorem cert_e2408520410734 : check e2408520410734 [[],[]] .chain = true := by decide
def e2408520410746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2408520410746 : Closed e2408520410746 ∧ code e2408520410746 = 11204613432954 := by decide
theorem cert_e2408520410746 : check e2408520410746 [[],[]] .chain = true := by decide
def e2408520411034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2408520411034 : Closed e2408520411034 ∧ code e2408520411034 = 11204613433242 := by decide
theorem cert_e2408520411034 : check e2408520411034 [[],[]] .chain = true := by decide
def e2408520413910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2408520413910 : Closed e2408520413910 ∧ code e2408520413910 = 11204613436118 := by decide
theorem cert_e2408520413910 : check e2408520413910 [[],[]] .chain = true := by decide
def e2408520413914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2408520413914 : Closed e2408520413914 ∧ code e2408520413914 = 11204613436122 := by decide
theorem cert_e2408520413914 : check e2408520413914 [[],[]] .chain = true := by decide
def e2408520413930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2408520413930 : Closed e2408520413930 ∧ code e2408520413930 = 11204613436138 := by decide
theorem cert_e2408520413930 : check e2408520413930 [[],[]] .chain = true := by decide
def e2408520414006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2408520414006 : Closed e2408520414006 ∧ code e2408520414006 = 11204613436214 := by decide
theorem cert_e2408520414006 : check e2408520414006 [[],[]] .chain = true := by decide
def e2408520414010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2408520414010 : Closed e2408520414010 ∧ code e2408520414010 = 11204613436218 := by decide
theorem cert_e2408520414010 : check e2408520414010 [[],[]] .chain = true := by decide
def e2408520414106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2408520414106 : Closed e2408520414106 ∧ code e2408520414106 = 11204613436314 := by decide
theorem cert_e2408520414106 : check e2408520414106 [[],[]] .chain = true := by decide
def e2408520551278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408520551278 : Closed e2408520551278 ∧ code e2408520551278 = 11204613573486 := by decide
theorem cert_e2408520551278 : check e2408520551278 [[],[]] .chain = true := by decide
def e2408520551286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408520551286 : Closed e2408520551286 ∧ code e2408520551286 = 11204613573494 := by decide
theorem cert_e2408520551286 : check e2408520551286 [[],[]] .chain = true := by decide
def e2408520551342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408520551342 : Closed e2408520551342 ∧ code e2408520551342 = 11204613573550 := by decide
theorem cert_e2408520551342 : check e2408520551342 [[],[]] .chain = true := by decide
def e2408520551354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408520551354 : Closed e2408520551354 ∧ code e2408520551354 = 11204613573562 := by decide
theorem cert_e2408520551354 : check e2408520551354 [[],[]] .chain = true := by decide
def e2408520551382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408520551382 : Closed e2408520551382 ∧ code e2408520551382 = 11204613573590 := by decide
theorem cert_e2408520551382 : check e2408520551382 [[],[]] .chain = true := by decide
def e2408520551386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408520551386 : Closed e2408520551386 ∧ code e2408520551386 = 11204613573594 := by decide
theorem cert_e2408520551386 : check e2408520551386 [[],[]] .chain = true := by decide
def e2408520551662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408520551662 : Closed e2408520551662 ∧ code e2408520551662 = 11204613573870 := by decide
theorem cert_e2408520551662 : check e2408520551662 [[],[]] .chain = true := by decide
def e2408520551670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408520551670 : Closed e2408520551670 ∧ code e2408520551670 = 11204613573878 := by decide
theorem cert_e2408520551670 : check e2408520551670 [[],[]] .chain = true := by decide
def e2408520552046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408520552046 : Closed e2408520552046 ∧ code e2408520552046 = 11204613574254 := by decide
theorem cert_e2408520552046 : check e2408520552046 [[],[]] .chain = true := by decide
def e2408520552058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408520552058 : Closed e2408520552058 ∧ code e2408520552058 = 11204613574266 := by decide
theorem cert_e2408520552058 : check e2408520552058 [[],[]] .chain = true := by decide
def e2408520552246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408520552246 : Closed e2408520552246 ∧ code e2408520552246 = 11204613574454 := by decide
theorem cert_e2408520552246 : check e2408520552246 [[],[]] .chain = true := by decide
def e2408520552250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408520552250 : Closed e2408520552250 ∧ code e2408520552250 = 11204613574458 := by decide
theorem cert_e2408520552250 : check e2408520552250 [[],[]] .chain = true := by decide
def e2408521141102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408521141102 : Closed e2408521141102 ∧ code e2408521141102 = 11204614163310 := by decide
theorem cert_e2408521141102 : check e2408521141102 [[],[],[],[]] .sourceHead = true := by decide
def e2408521141110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408521141110 : Closed e2408521141110 ∧ code e2408521141110 = 11204614163318 := by decide
theorem cert_e2408521141110 : check e2408521141110 [[],[],[],[]] .sourceHead = true := by decide
def e2408521141166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408521141166 : Closed e2408521141166 ∧ code e2408521141166 = 11204614163374 := by decide
theorem cert_e2408521141166 : check e2408521141166 [[],[],[],[],[.under,.left],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2408521141178 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408521141178 : Closed e2408521141178 ∧ code e2408521141178 = 11204614163386 := by decide
theorem cert_e2408521141178 : check e2408521141178 [[],[],[],[],[.under,.left]] .smaller = true := by decide
def e2408521141206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408521141206 : Closed e2408521141206 ∧ code e2408521141206 = 11204614163414 := by decide
theorem cert_e2408521141206 : check e2408521141206 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e2408521141210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408521141210 : Closed e2408521141210 ∧ code e2408521141210 = 11204614163418 := by decide
theorem cert_e2408521141210 : check e2408521141210 [[],[],[],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2408521141486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408521141486 : Closed e2408521141486 ∧ code e2408521141486 = 11204614163694 := by decide
theorem cert_e2408521141486 : check e2408521141486 [[],[],[],[]] .sourceHead = true := by decide
def e2408521141494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408521141494 : Closed e2408521141494 ∧ code e2408521141494 = 11204614163702 := by decide
theorem cert_e2408521141494 : check e2408521141494 [[],[],[],[]] .sourceHead = true := by decide
def e2408521141870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408521141870 : Closed e2408521141870 ∧ code e2408521141870 = 11204614164078 := by decide
theorem cert_e2408521141870 : check e2408521141870 [[],[],[],[],[.under]] .smaller = true := by decide
def e2408521141882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408521141882 : Closed e2408521141882 ∧ code e2408521141882 = 11204614164090 := by decide
theorem cert_e2408521141882 : check e2408521141882 [[],[],[],[],[.under]] .smaller = true := by decide
def e2408521142070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408521142070 : Closed e2408521142070 ∧ code e2408521142070 = 11204614164278 := by decide
theorem cert_e2408521142070 : check e2408521142070 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e2408521142074 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408521142074 : Closed e2408521142074 ∧ code e2408521142074 = 11204614164282 := by decide
theorem cert_e2408521142074 : check e2408521142074 [[],[],[],[],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2408607234074 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607234074 : Closed e2408607234074 ∧ code e2408607234074 = 11204700256282 := by decide
theorem cert_e2408607234074 : check e2408607234074 [[]] .width = true := by decide
def e2408607242266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607242266 : Closed e2408607242266 ∧ code e2408607242266 = 11204700264474 := by decide
theorem cert_e2408607242266 : check e2408607242266 [[]] .width = true := by decide
def e2408607299610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607299610 : Closed e2408607299610 ∧ code e2408607299610 = 11204700321818 := by decide
theorem cert_e2408607299610 : check e2408607299610 [[]] .width = true := by decide
def e2408607311898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607311898 : Closed e2408607311898 ∧ code e2408607311898 = 11204700334106 := by decide
theorem cert_e2408607311898 : check e2408607311898 [[]] .width = true := by decide
def e2408607340570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607340570 : Closed e2408607340570 ∧ code e2408607340570 = 11204700362778 := by decide
theorem cert_e2408607340570 : check e2408607340570 [[]] .width = true := by decide
def e2408607344666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607344666 : Closed e2408607344666 ∧ code e2408607344666 = 11204700366874 := by decide
theorem cert_e2408607344666 : check e2408607344666 [[]] .width = true := by decide
def e2408607627290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607627290 : Closed e2408607627290 ∧ code e2408607627290 = 11204700649498 := by decide
theorem cert_e2408607627290 : check e2408607627290 [[]] .width = true := by decide
def e2408607635482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408607635482 : Closed e2408607635482 ∧ code e2408607635482 = 11204700657690 := by decide
theorem cert_e2408607635482 : check e2408607635482 [[]] .width = true := by decide
def e2408608020506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408608020506 : Closed e2408608020506 ∧ code e2408608020506 = 11204701042714 := by decide
theorem cert_e2408608020506 : check e2408608020506 [[]] .width = true := by decide
def e2408608032794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408608032794 : Closed e2408608032794 ∧ code e2408608032794 = 11204701055002 := by decide
theorem cert_e2408608032794 : check e2408608032794 [[]] .width = true := by decide
def e2408608225306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408608225306 : Closed e2408608225306 ∧ code e2408608225306 = 11204701247514 := by decide
theorem cert_e2408608225306 : check e2408608225306 [[]] .width = true := by decide
def e2408608229402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408608229402 : Closed e2408608229402 ∧ code e2408608229402 = 11204701251610 := by decide
theorem cert_e2408608229402 : check e2408608229402 [[]] .width = true := by decide
def e2408805653214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2408805653214 : Closed e2408805653214 ∧ code e2408805653214 = 11204898675422 := by decide
theorem cert_e2408805653214 : check e2408805653214 [[],[]] .three = true := by decide
def e2408805653238 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2408805653238 : Closed e2408805653238 ∧ code e2408805653238 = 11204898675446 := by decide
theorem cert_e2408805653238 : check e2408805653238 [[],[]] .three = true := by decide
def e2408805653342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2408805653342 : Closed e2408805653342 ∧ code e2408805653342 = 11204898675550 := by decide
theorem cert_e2408805653342 : check e2408805653342 [[],[]] .three = true := by decide
def e2408805653358 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2408805653358 : Closed e2408805653358 ∧ code e2408805653358 = 11204898675566 := by decide
theorem cert_e2408805653358 : check e2408805653358 [[],[]] .smaller = true := by decide
def e2408805653366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2408805653366 : Closed e2408805653366 ∧ code e2408805653366 = 11204898675574 := by decide
theorem cert_e2408805653366 : check e2408805653366 [[],[]] .smaller = true := by decide
def e2408805653370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2408805653370 : Closed e2408805653370 ∧ code e2408805653370 = 11204898675578 := by decide
theorem cert_e2408805653370 : check e2408805653370 [[],[]] .three = true := by decide
def e2408805653430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2408805653430 : Closed e2408805653430 ∧ code e2408805653430 = 11204898675638 := by decide
theorem cert_e2408805653430 : check e2408805653430 [[],[]] .smaller = true := by decide
def e2408805653462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2408805653462 : Closed e2408805653462 ∧ code e2408805653462 = 11204898675670 := by decide
theorem cert_e2408805653462 : check e2408805653462 [[],[]] .three = true := by decide
def e2408805653466 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2408805653466 : Closed e2408805653466 ∧ code e2408805653466 = 11204898675674 := by decide
theorem cert_e2408805653466 : check e2408805653466 [[],[]] .three = true := by decide
def e2408805653854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2408805653854 : Closed e2408805653854 ∧ code e2408805653854 = 11204898676062 := by decide
theorem cert_e2408805653854 : check e2408805653854 [[],[]] .three = true := by decide
def e2408805653870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2408805653870 : Closed e2408805653870 ∧ code e2408805653870 = 11204898676078 := by decide
theorem cert_e2408805653870 : check e2408805653870 [[],[]] .smaller = true := by decide
def e2408805653878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2408805653878 : Closed e2408805653878 ∧ code e2408805653878 = 11204898676086 := by decide
theorem cert_e2408805653878 : check e2408805653878 [[],[]] .smaller = true := by decide
def e2408805653882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2408805653882 : Closed e2408805653882 ∧ code e2408805653882 = 11204898676090 := by decide
theorem cert_e2408805653882 : check e2408805653882 [[],[]] .three = true := by decide
def e2408805653934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2408805653934 : Closed e2408805653934 ∧ code e2408805653934 = 11204898676142 := by decide
theorem cert_e2408805653934 : check e2408805653934 [[],[]] .smaller = true := by decide
def e2408805653946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2408805653946 : Closed e2408805653946 ∧ code e2408805653946 = 11204898676154 := by decide
theorem cert_e2408805653946 : check e2408805653946 [[],[]] .smaller = true := by decide
def e2408805653974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2408805653974 : Closed e2408805653974 ∧ code e2408805653974 = 11204898676182 := by decide
theorem cert_e2408805653974 : check e2408805653974 [[],[]] .smaller = true := by decide
def e2408805653978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2408805653978 : Closed e2408805653978 ∧ code e2408805653978 = 11204898676186 := by decide
theorem cert_e2408805653978 : check e2408805653978 [[],[]] .smaller = true := by decide
def e2408805653994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2408805653994 : Closed e2408805653994 ∧ code e2408805653994 = 11204898676202 := by decide
theorem cert_e2408805653994 : check e2408805653994 [[],[]] .three = true := by decide
def e2408805654198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2408805654198 : Closed e2408805654198 ∧ code e2408805654198 = 11204898676406 := by decide
theorem cert_e2408805654198 : check e2408805654198 [[],[]] .smaller = true := by decide
def e2408805654230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2408805654230 : Closed e2408805654230 ∧ code e2408805654230 = 11204898676438 := by decide
theorem cert_e2408805654230 : check e2408805654230 [[],[]] .smaller = true := by decide
def e2408805654234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2408805654234 : Closed e2408805654234 ∧ code e2408805654234 = 11204898676442 := by decide
theorem cert_e2408805654234 : check e2408805654234 [[],[]] .smaller = true := by decide
def e2408805654358 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2408805654358 : Closed e2408805654358 ∧ code e2408805654358 = 11204898676566 := by decide
theorem cert_e2408805654358 : check e2408805654358 [[],[]] .three = true := by decide
def e2408805654362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2408805654362 : Closed e2408805654362 ∧ code e2408805654362 = 11204898676570 := by decide
theorem cert_e2408805654362 : check e2408805654362 [[],[]] .three = true := by decide
def e2408805654378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2408805654378 : Closed e2408805654378 ∧ code e2408805654378 = 11204898676586 := by decide
theorem cert_e2408805654378 : check e2408805654378 [[],[]] .three = true := by decide
def e2408805656286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2408805656286 : Closed e2408805656286 ∧ code e2408805656286 = 11204898678494 := by decide
theorem cert_e2408805656286 : check e2408805656286 [[],[]] .three = true := by decide
def e2408805656310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2408805656310 : Closed e2408805656310 ∧ code e2408805656310 = 11204898678518 := by decide
theorem cert_e2408805656310 : check e2408805656310 [[],[]] .three = true := by decide
def e2408805656414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2408805656414 : Closed e2408805656414 ∧ code e2408805656414 = 11204898678622 := by decide
theorem cert_e2408805656414 : check e2408805656414 [[],[]] .three = true := by decide
def e2408805656430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2408805656430 : Closed e2408805656430 ∧ code e2408805656430 = 11204898678638 := by decide
theorem cert_e2408805656430 : check e2408805656430 [[],[]] .smaller = true := by decide
def e2408805656438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2408805656438 : Closed e2408805656438 ∧ code e2408805656438 = 11204898678646 := by decide
theorem cert_e2408805656438 : check e2408805656438 [[],[]] .smaller = true := by decide
def e2408805656442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2408805656442 : Closed e2408805656442 ∧ code e2408805656442 = 11204898678650 := by decide
theorem cert_e2408805656442 : check e2408805656442 [[],[]] .three = true := by decide
def e2408805656502 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2408805656502 : Closed e2408805656502 ∧ code e2408805656502 = 11204898678710 := by decide
theorem cert_e2408805656502 : check e2408805656502 [[],[]] .smaller = true := by decide
def e2408805656534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2408805656534 : Closed e2408805656534 ∧ code e2408805656534 = 11204898678742 := by decide
theorem cert_e2408805656534 : check e2408805656534 [[],[]] .three = true := by decide
def e2408805656538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2408805656538 : Closed e2408805656538 ∧ code e2408805656538 = 11204898678746 := by decide
theorem cert_e2408805656538 : check e2408805656538 [[],[]] .three = true := by decide
def e2408805657054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2408805657054 : Closed e2408805657054 ∧ code e2408805657054 = 11204898679262 := by decide
theorem cert_e2408805657054 : check e2408805657054 [[],[]] .three = true := by decide
def e2408805657078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2408805657078 : Closed e2408805657078 ∧ code e2408805657078 = 11204898679286 := by decide
theorem cert_e2408805657078 : check e2408805657078 [[],[]] .three = true := by decide
def e2408805657822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2408805657822 : Closed e2408805657822 ∧ code e2408805657822 = 11204898680030 := by decide
theorem cert_e2408805657822 : check e2408805657822 [[],[]] .three = true := by decide
def e2408805657838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2408805657838 : Closed e2408805657838 ∧ code e2408805657838 = 11204898680046 := by decide
theorem cert_e2408805657838 : check e2408805657838 [[],[]] .smaller = true := by decide
def e2408805657846 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2408805657846 : Closed e2408805657846 ∧ code e2408805657846 = 11204898680054 := by decide
theorem cert_e2408805657846 : check e2408805657846 [[],[]] .smaller = true := by decide
def e2408805657850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2408805657850 : Closed e2408805657850 ∧ code e2408805657850 = 11204898680058 := by decide
theorem cert_e2408805657850 : check e2408805657850 [[],[]] .three = true := by decide
def e2408805658230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2408805658230 : Closed e2408805658230 ∧ code e2408805658230 = 11204898680438 := by decide
theorem cert_e2408805658230 : check e2408805658230 [[],[]] .smaller = true := by decide
def e2408805658422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2408805658422 : Closed e2408805658422 ∧ code e2408805658422 = 11204898680630 := by decide
theorem cert_e2408805658422 : check e2408805658422 [[],[]] .three = true := by decide
def e2408805658426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2408805658426 : Closed e2408805658426 ∧ code e2408805658426 = 11204898680634 := by decide
theorem cert_e2408805658426 : check e2408805658426 [[],[]] .three = true := by decide
def e2408805659486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2408805659486 : Closed e2408805659486 ∧ code e2408805659486 = 11204898681694 := by decide
theorem cert_e2408805659486 : check e2408805659486 [[],[]] .three = true := by decide
def e2408805659502 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2408805659502 : Closed e2408805659502 ∧ code e2408805659502 = 11204898681710 := by decide
theorem cert_e2408805659502 : check e2408805659502 [[],[]] .smaller = true := by decide
def e2408805659510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2408805659510 : Closed e2408805659510 ∧ code e2408805659510 = 11204898681718 := by decide
theorem cert_e2408805659510 : check e2408805659510 [[],[]] .smaller = true := by decide
def e2408805659514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2408805659514 : Closed e2408805659514 ∧ code e2408805659514 = 11204898681722 := by decide
theorem cert_e2408805659514 : check e2408805659514 [[],[]] .three = true := by decide
def e2408805659566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2408805659566 : Closed e2408805659566 ∧ code e2408805659566 = 11204898681774 := by decide
theorem cert_e2408805659566 : check e2408805659566 [[],[]] .smaller = true := by decide
def e2408805659578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2408805659578 : Closed e2408805659578 ∧ code e2408805659578 = 11204898681786 := by decide
theorem cert_e2408805659578 : check e2408805659578 [[],[]] .smaller = true := by decide
def e2408805659606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2408805659606 : Closed e2408805659606 ∧ code e2408805659606 = 11204898681814 := by decide
theorem cert_e2408805659606 : check e2408805659606 [[],[]] .smaller = true := by decide
def e2408805659610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2408805659610 : Closed e2408805659610 ∧ code e2408805659610 = 11204898681818 := by decide
theorem cert_e2408805659610 : check e2408805659610 [[],[]] .smaller = true := by decide
def e2408805659626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2408805659626 : Closed e2408805659626 ∧ code e2408805659626 = 11204898681834 := by decide
theorem cert_e2408805659626 : check e2408805659626 [[],[]] .three = true := by decide
def e2408805659870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2408805659870 : Closed e2408805659870 ∧ code e2408805659870 = 11204898682078 := by decide
theorem cert_e2408805659870 : check e2408805659870 [[],[]] .three = true := by decide
def e2408805659886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2408805659886 : Closed e2408805659886 ∧ code e2408805659886 = 11204898682094 := by decide
theorem cert_e2408805659886 : check e2408805659886 [[],[]] .smaller = true := by decide
def e2408805659894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2408805659894 : Closed e2408805659894 ∧ code e2408805659894 = 11204898682102 := by decide
theorem cert_e2408805659894 : check e2408805659894 [[],[]] .smaller = true := by decide
def e2408805659898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2408805659898 : Closed e2408805659898 ∧ code e2408805659898 = 11204898682106 := by decide
theorem cert_e2408805659898 : check e2408805659898 [[],[]] .three = true := by decide
def e2408805660270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2408805660270 : Closed e2408805660270 ∧ code e2408805660270 = 11204898682478 := by decide
theorem cert_e2408805660270 : check e2408805660270 [[],[]] .smaller = true := by decide
def e2408805660282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2408805660282 : Closed e2408805660282 ∧ code e2408805660282 = 11204898682490 := by decide
theorem cert_e2408805660282 : check e2408805660282 [[],[]] .smaller = true := by decide
def e2408805660470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2408805660470 : Closed e2408805660470 ∧ code e2408805660470 = 11204898682678 := by decide
theorem cert_e2408805660470 : check e2408805660470 [[],[]] .smaller = true := by decide
def e2408805660474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2408805660474 : Closed e2408805660474 ∧ code e2408805660474 = 11204898682682 := by decide
theorem cert_e2408805660474 : check e2408805660474 [[],[]] .smaller = true := by decide
def e2408805660570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2408805660570 : Closed e2408805660570 ∧ code e2408805660570 = 11204898682778 := by decide
theorem cert_e2408805660570 : check e2408805660570 [[],[]] .three = true := by decide
def e2408805661110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2408805661110 : Closed e2408805661110 ∧ code e2408805661110 = 11204898683318 := by decide
theorem cert_e2408805661110 : check e2408805661110 [[],[]] .smaller = true := by decide
def e2408805661142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2408805661142 : Closed e2408805661142 ∧ code e2408805661142 = 11204898683350 := by decide
theorem cert_e2408805661142 : check e2408805661142 [[],[]] .smaller = true := by decide
def e2408805661146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2408805661146 : Closed e2408805661146 ∧ code e2408805661146 = 11204898683354 := by decide
theorem cert_e2408805661146 : check e2408805661146 [[],[]] .smaller = true := by decide
def e2408805661302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2408805661302 : Closed e2408805661302 ∧ code e2408805661302 = 11204898683510 := by decide
theorem cert_e2408805661302 : check e2408805661302 [[],[]] .smaller = true := by decide
def e2408805661494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2408805661494 : Closed e2408805661494 ∧ code e2408805661494 = 11204898683702 := by decide
theorem cert_e2408805661494 : check e2408805661494 [[],[]] .smaller = true := by decide
def e2408805661498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2408805661498 : Closed e2408805661498 ∧ code e2408805661498 = 11204898683706 := by decide
theorem cert_e2408805661498 : check e2408805661498 [[],[]] .smaller = true := by decide
def e2408805661910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2408805661910 : Closed e2408805661910 ∧ code e2408805661910 = 11204898684118 := by decide
theorem cert_e2408805661910 : check e2408805661910 [[],[]] .three = true := by decide
def e2408805661914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2408805661914 : Closed e2408805661914 ∧ code e2408805661914 = 11204898684122 := by decide
theorem cert_e2408805661914 : check e2408805661914 [[],[]] .three = true := by decide
def e2408805661930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2408805661930 : Closed e2408805661930 ∧ code e2408805661930 = 11204898684138 := by decide
theorem cert_e2408805661930 : check e2408805661930 [[],[]] .three = true := by decide
def e2408805662006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2408805662006 : Closed e2408805662006 ∧ code e2408805662006 = 11204898684214 := by decide
theorem cert_e2408805662006 : check e2408805662006 [[],[]] .three = true := by decide
def e2408805662010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2408805662010 : Closed e2408805662010 ∧ code e2408805662010 = 11204898684218 := by decide
theorem cert_e2408805662010 : check e2408805662010 [[],[]] .three = true := by decide
def e2408805662106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2408805662106 : Closed e2408805662106 ∧ code e2408805662106 = 11204898684314 := by decide
theorem cert_e2408805662106 : check e2408805662106 [[],[]] .three = true := by decide
def e2408805668574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2408805668574 : Closed e2408805668574 ∧ code e2408805668574 = 11204898690782 := by decide
theorem cert_e2408805668574 : check e2408805668574 [[],[]] .three = true := by decide
def e2408805668598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2408805668598 : Closed e2408805668598 ∧ code e2408805668598 = 11204898690806 := by decide
theorem cert_e2408805668598 : check e2408805668598 [[],[]] .three = true := by decide
def e2408805668702 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2408805668702 : Closed e2408805668702 ∧ code e2408805668702 = 11204898690910 := by decide
theorem cert_e2408805668702 : check e2408805668702 [[],[]] .three = true := by decide
def e2408805668718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2408805668718 : Closed e2408805668718 ∧ code e2408805668718 = 11204898690926 := by decide
theorem cert_e2408805668718 : check e2408805668718 [[],[]] .smaller = true := by decide
def e2408805668726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2408805668726 : Closed e2408805668726 ∧ code e2408805668726 = 11204898690934 := by decide
theorem cert_e2408805668726 : check e2408805668726 [[],[]] .smaller = true := by decide
def e2408805668730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2408805668730 : Closed e2408805668730 ∧ code e2408805668730 = 11204898690938 := by decide
theorem cert_e2408805668730 : check e2408805668730 [[],[]] .three = true := by decide
def e2408805668790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2408805668790 : Closed e2408805668790 ∧ code e2408805668790 = 11204898690998 := by decide
theorem cert_e2408805668790 : check e2408805668790 [[],[]] .smaller = true := by decide
def e2408805668822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2408805668822 : Closed e2408805668822 ∧ code e2408805668822 = 11204898691030 := by decide
theorem cert_e2408805668822 : check e2408805668822 [[],[]] .three = true := by decide
def e2408805668826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2408805668826 : Closed e2408805668826 ∧ code e2408805668826 = 11204898691034 := by decide
theorem cert_e2408805668826 : check e2408805668826 [[],[]] .three = true := by decide
def e2408805669342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2408805669342 : Closed e2408805669342 ∧ code e2408805669342 = 11204898691550 := by decide
theorem cert_e2408805669342 : check e2408805669342 [[],[]] .three = true := by decide
def e2408805669366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2408805669366 : Closed e2408805669366 ∧ code e2408805669366 = 11204898691574 := by decide
theorem cert_e2408805669366 : check e2408805669366 [[],[]] .three = true := by decide
def e2408805670110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2408805670110 : Closed e2408805670110 ∧ code e2408805670110 = 11204898692318 := by decide
theorem cert_e2408805670110 : check e2408805670110 [[],[]] .three = true := by decide
def e2408805670126 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2408805670126 : Closed e2408805670126 ∧ code e2408805670126 = 11204898692334 := by decide
theorem cert_e2408805670126 : check e2408805670126 [[],[]] .smaller = true := by decide
def e2408805670134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2408805670134 : Closed e2408805670134 ∧ code e2408805670134 = 11204898692342 := by decide
theorem cert_e2408805670134 : check e2408805670134 [[],[]] .smaller = true := by decide
def e2408805670138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2408805670138 : Closed e2408805670138 ∧ code e2408805670138 = 11204898692346 := by decide
theorem cert_e2408805670138 : check e2408805670138 [[],[]] .three = true := by decide
def e2408805670518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2408805670518 : Closed e2408805670518 ∧ code e2408805670518 = 11204898692726 := by decide
theorem cert_e2408805670518 : check e2408805670518 [[],[]] .smaller = true := by decide
def e2408805670710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2408805670710 : Closed e2408805670710 ∧ code e2408805670710 = 11204898692918 := by decide
theorem cert_e2408805670710 : check e2408805670710 [[],[]] .three = true := by decide
def e2408805670714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2408805670714 : Closed e2408805670714 ∧ code e2408805670714 = 11204898692922 := by decide
theorem cert_e2408805670714 : check e2408805670714 [[],[]] .three = true := by decide
def e2408805682014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2408805682014 : Closed e2408805682014 ∧ code e2408805682014 = 11204898704222 := by decide
theorem cert_e2408805682014 : check e2408805682014 [[],[]] .three = true := by decide
def e2408805682030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2408805682030 : Closed e2408805682030 ∧ code e2408805682030 = 11204898704238 := by decide
theorem cert_e2408805682030 : check e2408805682030 [[],[]] .smaller = true := by decide
def e2408805682038 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2408805682038 : Closed e2408805682038 ∧ code e2408805682038 = 11204898704246 := by decide
theorem cert_e2408805682038 : check e2408805682038 [[],[]] .smaller = true := by decide
def e2408805682042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2408805682042 : Closed e2408805682042 ∧ code e2408805682042 = 11204898704250 := by decide
theorem cert_e2408805682042 : check e2408805682042 [[],[]] .three = true := by decide
def e2408805682094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2408805682094 : Closed e2408805682094 ∧ code e2408805682094 = 11204898704302 := by decide
theorem cert_e2408805682094 : check e2408805682094 [[],[]] .smaller = true := by decide
def e2408805682106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2408805682106 : Closed e2408805682106 ∧ code e2408805682106 = 11204898704314 := by decide
theorem cert_e2408805682106 : check e2408805682106 [[],[]] .smaller = true := by decide
def e2408805682134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2408805682134 : Closed e2408805682134 ∧ code e2408805682134 = 11204898704342 := by decide
theorem cert_e2408805682134 : check e2408805682134 [[],[]] .smaller = true := by decide
def e2408805682138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2408805682138 : Closed e2408805682138 ∧ code e2408805682138 = 11204898704346 := by decide
theorem cert_e2408805682138 : check e2408805682138 [[],[]] .smaller = true := by decide
def e2408805682154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2408805682154 : Closed e2408805682154 ∧ code e2408805682154 = 11204898704362 := by decide
theorem cert_e2408805682154 : check e2408805682154 [[],[]] .three = true := by decide
def e2408805682398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2408805682398 : Closed e2408805682398 ∧ code e2408805682398 = 11204898704606 := by decide
theorem cert_e2408805682398 : check e2408805682398 [[],[]] .three = true := by decide
def e2408805682414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2408805682414 : Closed e2408805682414 ∧ code e2408805682414 = 11204898704622 := by decide
theorem cert_e2408805682414 : check e2408805682414 [[],[]] .smaller = true := by decide
def e2408805682422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2408805682422 : Closed e2408805682422 ∧ code e2408805682422 = 11204898704630 := by decide
theorem cert_e2408805682422 : check e2408805682422 [[],[]] .smaller = true := by decide
def e2408805682426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2408805682426 : Closed e2408805682426 ∧ code e2408805682426 = 11204898704634 := by decide
theorem cert_e2408805682426 : check e2408805682426 [[],[]] .three = true := by decide
def e2408805682798 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2408805682798 : Closed e2408805682798 ∧ code e2408805682798 = 11204898705006 := by decide
theorem cert_e2408805682798 : check e2408805682798 [[],[]] .smaller = true := by decide
def e2408805682810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2408805682810 : Closed e2408805682810 ∧ code e2408805682810 = 11204898705018 := by decide
theorem cert_e2408805682810 : check e2408805682810 [[],[]] .smaller = true := by decide
def e2408805682998 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2408805682998 : Closed e2408805682998 ∧ code e2408805682998 = 11204898705206 := by decide
theorem cert_e2408805682998 : check e2408805682998 [[],[]] .smaller = true := by decide
def e2408805683002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2408805683002 : Closed e2408805683002 ∧ code e2408805683002 = 11204898705210 := by decide
theorem cert_e2408805683002 : check e2408805683002 [[],[]] .smaller = true := by decide
def e2408805683098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2408805683098 : Closed e2408805683098 ∧ code e2408805683098 = 11204898705306 := by decide
theorem cert_e2408805683098 : check e2408805683098 [[],[]] .three = true := by decide
end Blc.Floor43
