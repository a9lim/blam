import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e834083532634 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e834083532634 : Closed e834083532634 ∧ code e834083532634 = 9630176554842 := by decide
theorem cert_e834083532634 : check e834083532634 [] .sourceHead = true := by decide
def e834083532650 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e834083532650 : Closed e834083532650 ∧ code e834083532650 = 9630176554858 := by decide
theorem cert_e834083532650 : check e834083532650 [] .sourceHead = true := by decide
def e834083533678 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e834083533678 : Closed e834083533678 ∧ code e834083533678 = 9630176555886 := by decide
theorem cert_e834083533678 : check e834083533678 [] .sourceHead = true := by decide
def e834083533686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e834083533686 : Closed e834083533686 ∧ code e834083533686 = 9630176555894 := by decide
theorem cert_e834083533686 : check e834083533686 [] .sourceHead = true := by decide
def e834083533742 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e834083533742 : Closed e834083533742 ∧ code e834083533742 = 9630176555950 := by decide
theorem cert_e834083533742 : check e834083533742 [] .sourceHead = true := by decide
def e834083533754 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e834083533754 : Closed e834083533754 ∧ code e834083533754 = 9630176555962 := by decide
theorem cert_e834083533754 : check e834083533754 [] .sourceHead = true := by decide
def e834083533782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e834083533782 : Closed e834083533782 ∧ code e834083533782 = 9630176555990 := by decide
theorem cert_e834083533782 : check e834083533782 [] .sourceHead = true := by decide
def e834083533786 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e834083533786 : Closed e834083533786 ∧ code e834083533786 = 9630176555994 := by decide
theorem cert_e834083533786 : check e834083533786 [] .sourceHead = true := by decide
def e834083534062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e834083534062 : Closed e834083534062 ∧ code e834083534062 = 9630176556270 := by decide
theorem cert_e834083534062 : check e834083534062 [] .sourceHead = true := by decide
def e834083534070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e834083534070 : Closed e834083534070 ∧ code e834083534070 = 9630176556278 := by decide
theorem cert_e834083534070 : check e834083534070 [] .sourceHead = true := by decide
def e834083534446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e834083534446 : Closed e834083534446 ∧ code e834083534446 = 9630176556654 := by decide
theorem cert_e834083534446 : check e834083534446 [] .sourceHead = true := by decide
def e834083534458 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e834083534458 : Closed e834083534458 ∧ code e834083534458 = 9630176556666 := by decide
theorem cert_e834083534458 : check e834083534458 [] .sourceHead = true := by decide
def e834083534646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e834083534646 : Closed e834083534646 ∧ code e834083534646 = 9630176556854 := by decide
theorem cert_e834083534646 : check e834083534646 [] .sourceHead = true := by decide
def e834083534650 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e834083534650 : Closed e834083534650 ∧ code e834083534650 = 9630176556858 := by decide
theorem cert_e834083534650 : check e834083534650 [] .sourceHead = true := by decide
def e834083535278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e834083535278 : Closed e834083535278 ∧ code e834083535278 = 9630176557486 := by decide
theorem cert_e834083535278 : check e834083535278 [] .sourceHead = true := by decide
def e834083535290 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e834083535290 : Closed e834083535290 ∧ code e834083535290 = 9630176557498 := by decide
theorem cert_e834083535290 : check e834083535290 [] .sourceHead = true := by decide
def e834083535338 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e834083535338 : Closed e834083535338 ∧ code e834083535338 = 9630176557546 := by decide
theorem cert_e834083535338 : check e834083535338 [] .sourceHead = true := by decide
def e834083535470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e834083535470 : Closed e834083535470 ∧ code e834083535470 = 9630176557678 := by decide
theorem cert_e834083535470 : check e834083535470 [] .sourceHead = true := by decide
def e834083535482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e834083535482 : Closed e834083535482 ∧ code e834083535482 = 9630176557690 := by decide
theorem cert_e834083535482 : check e834083535482 [] .sourceHead = true := by decide
def e834083535770 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834083535770 : Closed e834083535770 ∧ code e834083535770 = 9630176557978 := by decide
theorem cert_e834083535770 : check e834083535770 [] .sourceHead = true := by decide
def e834083536086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e834083536086 : Closed e834083536086 ∧ code e834083536086 = 9630176558294 := by decide
theorem cert_e834083536086 : check e834083536086 [] .sourceHead = true := by decide
def e834083536090 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e834083536090 : Closed e834083536090 ∧ code e834083536090 = 9630176558298 := by decide
theorem cert_e834083536090 : check e834083536090 [] .sourceHead = true := by decide
def e834083536106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e834083536106 : Closed e834083536106 ∧ code e834083536106 = 9630176558314 := by decide
theorem cert_e834083536106 : check e834083536106 [] .sourceHead = true := by decide
def e834083536182 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e834083536182 : Closed e834083536182 ∧ code e834083536182 = 9630176558390 := by decide
theorem cert_e834083536182 : check e834083536182 [] .sourceHead = true := by decide
def e834083536186 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e834083536186 : Closed e834083536186 ∧ code e834083536186 = 9630176558394 := by decide
theorem cert_e834083536186 : check e834083536186 [] .sourceHead = true := by decide
def e834083536282 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834083536282 : Closed e834083536282 ∧ code e834083536282 = 9630176558490 := by decide
theorem cert_e834083536282 : check e834083536282 [] .sourceHead = true := by decide
def e834083539822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e834083539822 : Closed e834083539822 ∧ code e834083539822 = 9630176562030 := by decide
theorem cert_e834083539822 : check e834083539822 [] .sourceHead = true := by decide
def e834083539830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e834083539830 : Closed e834083539830 ∧ code e834083539830 = 9630176562038 := by decide
theorem cert_e834083539830 : check e834083539830 [] .sourceHead = true := by decide
def e834083539886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e834083539886 : Closed e834083539886 ∧ code e834083539886 = 9630176562094 := by decide
theorem cert_e834083539886 : check e834083539886 [] .sourceHead = true := by decide
def e834083539898 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e834083539898 : Closed e834083539898 ∧ code e834083539898 = 9630176562106 := by decide
theorem cert_e834083539898 : check e834083539898 [] .sourceHead = true := by decide
def e834083539926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e834083539926 : Closed e834083539926 ∧ code e834083539926 = 9630176562134 := by decide
theorem cert_e834083539926 : check e834083539926 [] .sourceHead = true := by decide
def e834083539930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e834083539930 : Closed e834083539930 ∧ code e834083539930 = 9630176562138 := by decide
theorem cert_e834083539930 : check e834083539930 [] .sourceHead = true := by decide
def e834083540206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e834083540206 : Closed e834083540206 ∧ code e834083540206 = 9630176562414 := by decide
theorem cert_e834083540206 : check e834083540206 [] .sourceHead = true := by decide
def e834083540214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e834083540214 : Closed e834083540214 ∧ code e834083540214 = 9630176562422 := by decide
theorem cert_e834083540214 : check e834083540214 [] .sourceHead = true := by decide
def e834083540590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e834083540590 : Closed e834083540590 ∧ code e834083540590 = 9630176562798 := by decide
theorem cert_e834083540590 : check e834083540590 [] .sourceHead = true := by decide
def e834083540602 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e834083540602 : Closed e834083540602 ∧ code e834083540602 = 9630176562810 := by decide
theorem cert_e834083540602 : check e834083540602 [] .sourceHead = true := by decide
def e834083540790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e834083540790 : Closed e834083540790 ∧ code e834083540790 = 9630176562998 := by decide
theorem cert_e834083540790 : check e834083540790 [] .sourceHead = true := by decide
def e834083540794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e834083540794 : Closed e834083540794 ∧ code e834083540794 = 9630176563002 := by decide
theorem cert_e834083540794 : check e834083540794 [] .sourceHead = true := by decide
def e834083546542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e834083546542 : Closed e834083546542 ∧ code e834083546542 = 9630176568750 := by decide
theorem cert_e834083546542 : check e834083546542 [] .sourceHead = true := by decide
def e834083546554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e834083546554 : Closed e834083546554 ∧ code e834083546554 = 9630176568762 := by decide
theorem cert_e834083546554 : check e834083546554 [] .sourceHead = true := by decide
def e834083546602 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e834083546602 : Closed e834083546602 ∧ code e834083546602 = 9630176568810 := by decide
theorem cert_e834083546602 : check e834083546602 [] .sourceHead = true := by decide
def e834083546734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e834083546734 : Closed e834083546734 ∧ code e834083546734 = 9630176568942 := by decide
theorem cert_e834083546734 : check e834083546734 [] .sourceHead = true := by decide
def e834083546746 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e834083546746 : Closed e834083546746 ∧ code e834083546746 = 9630176568954 := by decide
theorem cert_e834083546746 : check e834083546746 [] .sourceHead = true := by decide
def e834083547034 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e834083547034 : Closed e834083547034 ∧ code e834083547034 = 9630176569242 := by decide
theorem cert_e834083547034 : check e834083547034 [] .sourceHead = true := by decide
def e834083549910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e834083549910 : Closed e834083549910 ∧ code e834083549910 = 9630176572118 := by decide
theorem cert_e834083549910 : check e834083549910 [] .sourceHead = true := by decide
def e834083549914 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e834083549914 : Closed e834083549914 ∧ code e834083549914 = 9630176572122 := by decide
theorem cert_e834083549914 : check e834083549914 [] .sourceHead = true := by decide
def e834083549930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e834083549930 : Closed e834083549930 ∧ code e834083549930 = 9630176572138 := by decide
theorem cert_e834083549930 : check e834083549930 [] .sourceHead = true := by decide
def e834083550006 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e834083550006 : Closed e834083550006 ∧ code e834083550006 = 9630176572214 := by decide
theorem cert_e834083550006 : check e834083550006 [] .sourceHead = true := by decide
def e834083550010 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e834083550010 : Closed e834083550010 ∧ code e834083550010 = 9630176572218 := by decide
theorem cert_e834083550010 : check e834083550010 [] .sourceHead = true := by decide
def e834083550106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e834083550106 : Closed e834083550106 ∧ code e834083550106 = 9630176572314 := by decide
theorem cert_e834083550106 : check e834083550106 [] .sourceHead = true := by decide
def e834083687278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e834083687278 : Closed e834083687278 ∧ code e834083687278 = 9630176709486 := by decide
theorem cert_e834083687278 : check e834083687278 [] .sourceHead = true := by decide
def e834083687286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e834083687286 : Closed e834083687286 ∧ code e834083687286 = 9630176709494 := by decide
theorem cert_e834083687286 : check e834083687286 [] .sourceHead = true := by decide
def e834083687342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e834083687342 : Closed e834083687342 ∧ code e834083687342 = 9630176709550 := by decide
theorem cert_e834083687342 : check e834083687342 [] .sourceHead = true := by decide
def e834083687354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e834083687354 : Closed e834083687354 ∧ code e834083687354 = 9630176709562 := by decide
theorem cert_e834083687354 : check e834083687354 [] .sourceHead = true := by decide
def e834083687382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e834083687382 : Closed e834083687382 ∧ code e834083687382 = 9630176709590 := by decide
theorem cert_e834083687382 : check e834083687382 [] .sourceHead = true := by decide
def e834083687386 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e834083687386 : Closed e834083687386 ∧ code e834083687386 = 9630176709594 := by decide
theorem cert_e834083687386 : check e834083687386 [] .sourceHead = true := by decide
def e834083687662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e834083687662 : Closed e834083687662 ∧ code e834083687662 = 9630176709870 := by decide
theorem cert_e834083687662 : check e834083687662 [] .sourceHead = true := by decide
def e834083687670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e834083687670 : Closed e834083687670 ∧ code e834083687670 = 9630176709878 := by decide
theorem cert_e834083687670 : check e834083687670 [] .sourceHead = true := by decide
def e834083688046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e834083688046 : Closed e834083688046 ∧ code e834083688046 = 9630176710254 := by decide
theorem cert_e834083688046 : check e834083688046 [] .sourceHead = true := by decide
def e834083688058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e834083688058 : Closed e834083688058 ∧ code e834083688058 = 9630176710266 := by decide
theorem cert_e834083688058 : check e834083688058 [] .sourceHead = true := by decide
def e834083688246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e834083688246 : Closed e834083688246 ∧ code e834083688246 = 9630176710454 := by decide
theorem cert_e834083688246 : check e834083688246 [] .sourceHead = true := by decide
def e834083688250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e834083688250 : Closed e834083688250 ∧ code e834083688250 = 9630176710458 := by decide
theorem cert_e834083688250 : check e834083688250 [] .sourceHead = true := by decide
def e834096115054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e834096115054 : Closed e834096115054 ∧ code e834096115054 = 9630189137262 := by decide
theorem cert_e834096115054 : check e834096115054 [] .sourceHead = true := by decide
def e834096115062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e834096115062 : Closed e834096115062 ∧ code e834096115062 = 9630189137270 := by decide
theorem cert_e834096115062 : check e834096115062 [] .sourceHead = true := by decide
def e834096115118 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e834096115118 : Closed e834096115118 ∧ code e834096115118 = 9630189137326 := by decide
theorem cert_e834096115118 : check e834096115118 [] .sourceHead = true := by decide
def e834096115130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e834096115130 : Closed e834096115130 ∧ code e834096115130 = 9630189137338 := by decide
theorem cert_e834096115130 : check e834096115130 [] .sourceHead = true := by decide
def e834096115158 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e834096115158 : Closed e834096115158 ∧ code e834096115158 = 9630189137366 := by decide
theorem cert_e834096115158 : check e834096115158 [] .sourceHead = true := by decide
def e834096115162 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e834096115162 : Closed e834096115162 ∧ code e834096115162 = 9630189137370 := by decide
theorem cert_e834096115162 : check e834096115162 [] .sourceHead = true := by decide
def e834096115374 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e834096115374 : Closed e834096115374 ∧ code e834096115374 = 9630189137582 := by decide
theorem cert_e834096115374 : check e834096115374 [] .sourceHead = true := by decide
def e834096115386 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e834096115386 : Closed e834096115386 ∧ code e834096115386 = 9630189137594 := by decide
theorem cert_e834096115386 : check e834096115386 [] .sourceHead = true := by decide
def e834096115434 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e834096115434 : Closed e834096115434 ∧ code e834096115434 = 9630189137642 := by decide
theorem cert_e834096115434 : check e834096115434 [] .sourceHead = true := by decide
def e834096115542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e834096115542 : Closed e834096115542 ∧ code e834096115542 = 9630189137750 := by decide
theorem cert_e834096115542 : check e834096115542 [] .sourceHead = true := by decide
def e834096115546 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e834096115546 : Closed e834096115546 ∧ code e834096115546 = 9630189137754 := by decide
theorem cert_e834096115546 : check e834096115546 [] .sourceHead = true := by decide
def e834096115562 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e834096115562 : Closed e834096115562 ∧ code e834096115562 = 9630189137770 := by decide
theorem cert_e834096115562 : check e834096115562 [] .sourceHead = true := by decide
def e834096116590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e834096116590 : Closed e834096116590 ∧ code e834096116590 = 9630189138798 := by decide
theorem cert_e834096116590 : check e834096116590 [] .sourceHead = true := by decide
def e834096116598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e834096116598 : Closed e834096116598 ∧ code e834096116598 = 9630189138806 := by decide
theorem cert_e834096116598 : check e834096116598 [] .sourceHead = true := by decide
def e834096116654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e834096116654 : Closed e834096116654 ∧ code e834096116654 = 9630189138862 := by decide
theorem cert_e834096116654 : check e834096116654 [] .sourceHead = true := by decide
def e834096116666 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e834096116666 : Closed e834096116666 ∧ code e834096116666 = 9630189138874 := by decide
theorem cert_e834096116666 : check e834096116666 [] .sourceHead = true := by decide
def e834096116694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e834096116694 : Closed e834096116694 ∧ code e834096116694 = 9630189138902 := by decide
theorem cert_e834096116694 : check e834096116694 [] .sourceHead = true := by decide
def e834096116698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e834096116698 : Closed e834096116698 ∧ code e834096116698 = 9630189138906 := by decide
theorem cert_e834096116698 : check e834096116698 [] .sourceHead = true := by decide
def e834096116974 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834096116974 : Closed e834096116974 ∧ code e834096116974 = 9630189139182 := by decide
theorem cert_e834096116974 : check e834096116974 [] .sourceHead = true := by decide
def e834096116982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834096116982 : Closed e834096116982 ∧ code e834096116982 = 9630189139190 := by decide
theorem cert_e834096116982 : check e834096116982 [] .sourceHead = true := by decide
def e834096117358 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096117358 : Closed e834096117358 ∧ code e834096117358 = 9630189139566 := by decide
theorem cert_e834096117358 : check e834096117358 [] .sourceHead = true := by decide
def e834096117370 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096117370 : Closed e834096117370 ∧ code e834096117370 = 9630189139578 := by decide
theorem cert_e834096117370 : check e834096117370 [] .sourceHead = true := by decide
def e834096117558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834096117558 : Closed e834096117558 ∧ code e834096117558 = 9630189139766 := by decide
theorem cert_e834096117558 : check e834096117558 [] .sourceHead = true := by decide
def e834096117562 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834096117562 : Closed e834096117562 ∧ code e834096117562 = 9630189139770 := by decide
theorem cert_e834096117562 : check e834096117562 [] .sourceHead = true := by decide
def e834096118190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e834096118190 : Closed e834096118190 ∧ code e834096118190 = 9630189140398 := by decide
theorem cert_e834096118190 : check e834096118190 [] .sourceHead = true := by decide
def e834096118202 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e834096118202 : Closed e834096118202 ∧ code e834096118202 = 9630189140410 := by decide
theorem cert_e834096118202 : check e834096118202 [] .sourceHead = true := by decide
def e834096118250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e834096118250 : Closed e834096118250 ∧ code e834096118250 = 9630189140458 := by decide
theorem cert_e834096118250 : check e834096118250 [] .sourceHead = true := by decide
def e834096118382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096118382 : Closed e834096118382 ∧ code e834096118382 = 9630189140590 := by decide
theorem cert_e834096118382 : check e834096118382 [] .sourceHead = true := by decide
def e834096118394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096118394 : Closed e834096118394 ∧ code e834096118394 = 9630189140602 := by decide
theorem cert_e834096118394 : check e834096118394 [] .sourceHead = true := by decide
def e834096118682 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834096118682 : Closed e834096118682 ∧ code e834096118682 = 9630189140890 := by decide
theorem cert_e834096118682 : check e834096118682 [] .sourceHead = true := by decide
def e834096118998 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e834096118998 : Closed e834096118998 ∧ code e834096118998 = 9630189141206 := by decide
theorem cert_e834096118998 : check e834096118998 [] .sourceHead = true := by decide
def e834096119002 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e834096119002 : Closed e834096119002 ∧ code e834096119002 = 9630189141210 := by decide
theorem cert_e834096119002 : check e834096119002 [] .sourceHead = true := by decide
def e834096119018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e834096119018 : Closed e834096119018 ∧ code e834096119018 = 9630189141226 := by decide
theorem cert_e834096119018 : check e834096119018 [] .sourceHead = true := by decide
def e834096119094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834096119094 : Closed e834096119094 ∧ code e834096119094 = 9630189141302 := by decide
theorem cert_e834096119094 : check e834096119094 [] .sourceHead = true := by decide
def e834096119098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834096119098 : Closed e834096119098 ∧ code e834096119098 = 9630189141306 := by decide
theorem cert_e834096119098 : check e834096119098 [] .sourceHead = true := by decide
def e834096119194 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834096119194 : Closed e834096119194 ∧ code e834096119194 = 9630189141402 := by decide
theorem cert_e834096119194 : check e834096119194 [] .sourceHead = true := by decide
def e834096122734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e834096122734 : Closed e834096122734 ∧ code e834096122734 = 9630189144942 := by decide
theorem cert_e834096122734 : check e834096122734 [] .sourceHead = true := by decide
def e834096122742 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e834096122742 : Closed e834096122742 ∧ code e834096122742 = 9630189144950 := by decide
theorem cert_e834096122742 : check e834096122742 [] .sourceHead = true := by decide
def e834096122798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e834096122798 : Closed e834096122798 ∧ code e834096122798 = 9630189145006 := by decide
theorem cert_e834096122798 : check e834096122798 [] .sourceHead = true := by decide
def e834096122810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e834096122810 : Closed e834096122810 ∧ code e834096122810 = 9630189145018 := by decide
theorem cert_e834096122810 : check e834096122810 [] .sourceHead = true := by decide
def e834096122838 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e834096122838 : Closed e834096122838 ∧ code e834096122838 = 9630189145046 := by decide
theorem cert_e834096122838 : check e834096122838 [] .sourceHead = true := by decide
def e834096122842 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e834096122842 : Closed e834096122842 ∧ code e834096122842 = 9630189145050 := by decide
theorem cert_e834096122842 : check e834096122842 [] .sourceHead = true := by decide
def e834096123118 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e834096123118 : Closed e834096123118 ∧ code e834096123118 = 9630189145326 := by decide
theorem cert_e834096123118 : check e834096123118 [] .sourceHead = true := by decide
def e834096123126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e834096123126 : Closed e834096123126 ∧ code e834096123126 = 9630189145334 := by decide
theorem cert_e834096123126 : check e834096123126 [] .sourceHead = true := by decide
def e834096123502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e834096123502 : Closed e834096123502 ∧ code e834096123502 = 9630189145710 := by decide
theorem cert_e834096123502 : check e834096123502 [] .sourceHead = true := by decide
def e834096123514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e834096123514 : Closed e834096123514 ∧ code e834096123514 = 9630189145722 := by decide
theorem cert_e834096123514 : check e834096123514 [] .sourceHead = true := by decide
def e834096123702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e834096123702 : Closed e834096123702 ∧ code e834096123702 = 9630189145910 := by decide
theorem cert_e834096123702 : check e834096123702 [] .sourceHead = true := by decide
def e834096123706 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e834096123706 : Closed e834096123706 ∧ code e834096123706 = 9630189145914 := by decide
theorem cert_e834096123706 : check e834096123706 [] .sourceHead = true := by decide
def e834096129454 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e834096129454 : Closed e834096129454 ∧ code e834096129454 = 9630189151662 := by decide
theorem cert_e834096129454 : check e834096129454 [] .sourceHead = true := by decide
def e834096129466 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e834096129466 : Closed e834096129466 ∧ code e834096129466 = 9630189151674 := by decide
theorem cert_e834096129466 : check e834096129466 [] .sourceHead = true := by decide
def e834096129514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e834096129514 : Closed e834096129514 ∧ code e834096129514 = 9630189151722 := by decide
theorem cert_e834096129514 : check e834096129514 [] .sourceHead = true := by decide
def e834096129646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e834096129646 : Closed e834096129646 ∧ code e834096129646 = 9630189151854 := by decide
theorem cert_e834096129646 : check e834096129646 [] .sourceHead = true := by decide
def e834096129658 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e834096129658 : Closed e834096129658 ∧ code e834096129658 = 9630189151866 := by decide
theorem cert_e834096129658 : check e834096129658 [] .sourceHead = true := by decide
def e834096129946 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e834096129946 : Closed e834096129946 ∧ code e834096129946 = 9630189152154 := by decide
theorem cert_e834096129946 : check e834096129946 [] .sourceHead = true := by decide
def e834096132822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e834096132822 : Closed e834096132822 ∧ code e834096132822 = 9630189155030 := by decide
theorem cert_e834096132822 : check e834096132822 [] .sourceHead = true := by decide
def e834096132826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e834096132826 : Closed e834096132826 ∧ code e834096132826 = 9630189155034 := by decide
theorem cert_e834096132826 : check e834096132826 [] .sourceHead = true := by decide
def e834096132842 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e834096132842 : Closed e834096132842 ∧ code e834096132842 = 9630189155050 := by decide
theorem cert_e834096132842 : check e834096132842 [] .sourceHead = true := by decide
def e834096132918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e834096132918 : Closed e834096132918 ∧ code e834096132918 = 9630189155126 := by decide
theorem cert_e834096132918 : check e834096132918 [] .sourceHead = true := by decide
def e834096132922 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e834096132922 : Closed e834096132922 ∧ code e834096132922 = 9630189155130 := by decide
theorem cert_e834096132922 : check e834096132922 [] .sourceHead = true := by decide
def e834096133018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e834096133018 : Closed e834096133018 ∧ code e834096133018 = 9630189155226 := by decide
theorem cert_e834096133018 : check e834096133018 [] .sourceHead = true := by decide
def e834096248286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e834096248286 : Closed e834096248286 ∧ code e834096248286 = 9630189270494 := by decide
theorem cert_e834096248286 : check e834096248286 [] .sourceHead = true := by decide
def e834096248302 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e834096248302 : Closed e834096248302 ∧ code e834096248302 = 9630189270510 := by decide
theorem cert_e834096248302 : check e834096248302 [] .sourceHead = true := by decide
def e834096248542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e834096248542 : Closed e834096248542 ∧ code e834096248542 = 9630189270750 := by decide
theorem cert_e834096248542 : check e834096248542 [] .sourceHead = true := by decide
def e834096248558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))))
theorem wire_e834096248558 : Closed e834096248558 ∧ code e834096248558 = 9630189270766 := by decide
theorem cert_e834096248558 : check e834096248558 [] .sourceHead = true := by decide
def e834096248566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e834096248566 : Closed e834096248566 ∧ code e834096248566 = 9630189270774 := by decide
theorem cert_e834096248566 : check e834096248566 [] .sourceHead = true := by decide
def e834096248670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e834096248670 : Closed e834096248670 ∧ code e834096248670 = 9630189270878 := by decide
theorem cert_e834096248670 : check e834096248670 [] .sourceHead = true := by decide
def e834096248686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))))
theorem wire_e834096248686 : Closed e834096248686 ∧ code e834096248686 = 9630189270894 := by decide
theorem cert_e834096248686 : check e834096248686 [] .sourceHead = true := by decide
def e834096248694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))))
theorem wire_e834096248694 : Closed e834096248694 ∧ code e834096248694 = 9630189270902 := by decide
theorem cert_e834096248694 : check e834096248694 [] .sourceHead = true := by decide
def e834096248698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e834096248698 : Closed e834096248698 ∧ code e834096248698 = 9630189270906 := by decide
theorem cert_e834096248698 : check e834096248698 [] .sourceHead = true := by decide
def e834096248750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e834096248750 : Closed e834096248750 ∧ code e834096248750 = 9630189270958 := by decide
theorem cert_e834096248750 : check e834096248750 [] .sourceHead = true := by decide
def e834096248758 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e834096248758 : Closed e834096248758 ∧ code e834096248758 = 9630189270966 := by decide
theorem cert_e834096248758 : check e834096248758 [] .sourceHead = true := by decide
def e834096248762 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e834096248762 : Closed e834096248762 ∧ code e834096248762 = 9630189270970 := by decide
theorem cert_e834096248762 : check e834096248762 [] .sourceHead = true := by decide
def e834096249566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e834096249566 : Closed e834096249566 ∧ code e834096249566 = 9630189271774 := by decide
theorem cert_e834096249566 : check e834096249566 [] .sourceHead = true := by decide
def e834096249582 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e834096249582 : Closed e834096249582 ∧ code e834096249582 = 9630189271790 := by decide
theorem cert_e834096249582 : check e834096249582 [] .sourceHead = true := by decide
def e834096249590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e834096249590 : Closed e834096249590 ∧ code e834096249590 = 9630189271798 := by decide
theorem cert_e834096249590 : check e834096249590 [] .sourceHead = true := by decide
def e834096249694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e834096249694 : Closed e834096249694 ∧ code e834096249694 = 9630189271902 := by decide
theorem cert_e834096249694 : check e834096249694 [] .sourceHead = true := by decide
def e834096249722 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e834096249722 : Closed e834096249722 ∧ code e834096249722 = 9630189271930 := by decide
theorem cert_e834096249722 : check e834096249722 [] .sourceHead = true := by decide
def e834096249774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e834096249774 : Closed e834096249774 ∧ code e834096249774 = 9630189271982 := by decide
theorem cert_e834096249774 : check e834096249774 [] .sourceHead = true := by decide
def e834096249786 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e834096249786 : Closed e834096249786 ∧ code e834096249786 = 9630189271994 := by decide
theorem cert_e834096249786 : check e834096249786 [] .sourceHead = true := by decide
def e834096249814 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e834096249814 : Closed e834096249814 ∧ code e834096249814 = 9630189272022 := by decide
theorem cert_e834096249814 : check e834096249814 [] .sourceHead = true := by decide
def e834096249818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e834096249818 : Closed e834096249818 ∧ code e834096249818 = 9630189272026 := by decide
theorem cert_e834096249818 : check e834096249818 [] .sourceHead = true := by decide
def e834096250206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e834096250206 : Closed e834096250206 ∧ code e834096250206 = 9630189272414 := by decide
theorem cert_e834096250206 : check e834096250206 [] .sourceHead = true := by decide
def e834096250222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e834096250222 : Closed e834096250222 ∧ code e834096250222 = 9630189272430 := by decide
theorem cert_e834096250222 : check e834096250222 [] .sourceHead = true := by decide
def e834096250230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e834096250230 : Closed e834096250230 ∧ code e834096250230 = 9630189272438 := by decide
theorem cert_e834096250230 : check e834096250230 [] .sourceHead = true := by decide
def e834096250234 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e834096250234 : Closed e834096250234 ∧ code e834096250234 = 9630189272442 := by decide
theorem cert_e834096250234 : check e834096250234 [] .sourceHead = true := by decide
def e834096250286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e834096250286 : Closed e834096250286 ∧ code e834096250286 = 9630189272494 := by decide
theorem cert_e834096250286 : check e834096250286 [] .sourceHead = true := by decide
def e834096250298 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e834096250298 : Closed e834096250298 ∧ code e834096250298 = 9630189272506 := by decide
theorem cert_e834096250298 : check e834096250298 [] .sourceHead = true := by decide
def e834096250326 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e834096250326 : Closed e834096250326 ∧ code e834096250326 = 9630189272534 := by decide
theorem cert_e834096250326 : check e834096250326 [] .sourceHead = true := by decide
def e834096250330 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e834096250330 : Closed e834096250330 ∧ code e834096250330 = 9630189272538 := by decide
theorem cert_e834096250330 : check e834096250330 [] .sourceHead = true := by decide
def e834096250346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e834096250346 : Closed e834096250346 ∧ code e834096250346 = 9630189272554 := by decide
theorem cert_e834096250346 : check e834096250346 [] .sourceHead = true := by decide
def e834096250542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e834096250542 : Closed e834096250542 ∧ code e834096250542 = 9630189272750 := by decide
theorem cert_e834096250542 : check e834096250542 [] .sourceHead = true := by decide
def e834096250550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e834096250550 : Closed e834096250550 ∧ code e834096250550 = 9630189272758 := by decide
theorem cert_e834096250550 : check e834096250550 [] .sourceHead = true := by decide
def e834096250554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e834096250554 : Closed e834096250554 ∧ code e834096250554 = 9630189272762 := by decide
theorem cert_e834096250554 : check e834096250554 [] .sourceHead = true := by decide
def e834096250582 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e834096250582 : Closed e834096250582 ∧ code e834096250582 = 9630189272790 := by decide
theorem cert_e834096250582 : check e834096250582 [] .sourceHead = true := by decide
def e834096250586 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e834096250586 : Closed e834096250586 ∧ code e834096250586 = 9630189272794 := by decide
theorem cert_e834096250586 : check e834096250586 [] .sourceHead = true := by decide
def e834096250602 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e834096250602 : Closed e834096250602 ∧ code e834096250602 = 9630189272810 := by decide
theorem cert_e834096250602 : check e834096250602 [] .sourceHead = true := by decide
def e834096254430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e834096254430 : Closed e834096254430 ∧ code e834096254430 = 9630189276638 := by decide
theorem cert_e834096254430 : check e834096254430 [] .sourceHead = true := by decide
def e834096254446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e834096254446 : Closed e834096254446 ∧ code e834096254446 = 9630189276654 := by decide
theorem cert_e834096254446 : check e834096254446 [] .sourceHead = true := by decide
end Blc.Floor43
