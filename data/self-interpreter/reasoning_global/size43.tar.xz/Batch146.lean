import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2249321467502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2249321467502 : Closed e2249321467502 ∧ code e2249321467502 = 11045414489710 := by decide
theorem cert_e2249321467502 : check e2249321467502 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321467514 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2249321467514 : Closed e2249321467514 ∧ code e2249321467514 = 11045414489722 := by decide
theorem cert_e2249321467514 : check e2249321467514 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321467702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2249321467702 : Closed e2249321467702 ∧ code e2249321467702 = 11045414489910 := by decide
theorem cert_e2249321467702 : check e2249321467702 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321467706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2249321467706 : Closed e2249321467706 ∧ code e2249321467706 = 11045414489914 := by decide
theorem cert_e2249321467706 : check e2249321467706 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321473462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2249321473462 : Closed e2249321473462 ∧ code e2249321473462 = 11045414495670 := by decide
theorem cert_e2249321473462 : check e2249321473462 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321473494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2249321473494 : Closed e2249321473494 ∧ code e2249321473494 = 11045414495702 := by decide
theorem cert_e2249321473494 : check e2249321473494 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321473498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2249321473498 : Closed e2249321473498 ∧ code e2249321473498 = 11045414495706 := by decide
theorem cert_e2249321473498 : check e2249321473498 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321473654 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2249321473654 : Closed e2249321473654 ∧ code e2249321473654 = 11045414495862 := by decide
theorem cert_e2249321473654 : check e2249321473654 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321473846 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2249321473846 : Closed e2249321473846 ∧ code e2249321473846 = 11045414496054 := by decide
theorem cert_e2249321473846 : check e2249321473846 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321473850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2249321473850 : Closed e2249321473850 ∧ code e2249321473850 = 11045414496058 := by decide
theorem cert_e2249321473850 : check e2249321473850 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321810798 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2249321810798 : Closed e2249321810798 ∧ code e2249321810798 = 11045414833006 := by decide
theorem cert_e2249321810798 : check e2249321810798 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2249321810806 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2249321810806 : Closed e2249321810806 ∧ code e2249321810806 = 11045414833014 := by decide
private def t_e2249321810806 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2249321810806 : ¬ IsSelfInterpreter e2249321810806 :=
  wSource (t := t_e2249321810806) (replay_sound (ps := []) (t := e2249321810806) (by decide)) (by decide)
def e2249321810862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2249321810862 : Closed e2249321810862 ∧ code e2249321810862 = 11045414833070 := by decide
theorem cert_e2249321810862 : check e2249321810862 [[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.left],[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .identityHead = true := by decide
def e2249321810874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2249321810874 : Closed e2249321810874 ∧ code e2249321810874 = 11045414833082 := by decide
theorem cert_e2249321810874 : check e2249321810874 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2249321810902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2249321810902 : Closed e2249321810902 ∧ code e2249321810902 = 11045414833110 := by decide
private def t_e2249321810902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2249321810902 : ¬ IsSelfInterpreter e2249321810902 :=
  wSource (t := t_e2249321810902) (replay_sound (ps := []) (t := e2249321810902) (by decide)) (by decide)
def e2249321810906 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2249321810906 : Closed e2249321810906 ∧ code e2249321810906 = 11045414833114 := by decide
theorem cert_e2249321810906 : check e2249321810906 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2249321811182 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2249321811182 : Closed e2249321811182 ∧ code e2249321811182 = 11045414833390 := by decide
theorem cert_e2249321811182 : check e2249321811182 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2249321811190 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2249321811190 : Closed e2249321811190 ∧ code e2249321811190 = 11045414833398 := by decide
theorem cert_e2249321811190 : check e2249321811190 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2249321811566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2249321811566 : Closed e2249321811566 ∧ code e2249321811566 = 11045414833774 := by decide
theorem cert_e2249321811566 : check e2249321811566 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2249321811578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2249321811578 : Closed e2249321811578 ∧ code e2249321811578 = 11045414833786 := by decide
theorem cert_e2249321811578 : check e2249321811578 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2249321811766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2249321811766 : Closed e2249321811766 ∧ code e2249321811766 = 11045414833974 := by decide
theorem cert_e2249321811766 : check e2249321811766 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2249321811770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2249321811770 : Closed e2249321811770 ∧ code e2249321811770 = 11045414833978 := by decide
theorem cert_e2249321811770 : check e2249321811770 [[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2251291549722 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251291549722 : Closed e2251291549722 ∧ code e2251291549722 = 11047384571930 := by decide
theorem cert_e2251291549722 : check e2251291549722 [[]] .width = true := by decide
def e2251291549814 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251291549814 : Closed e2251291549814 ∧ code e2251291549814 = 11047384572022 := by decide
theorem cert_e2251291549814 : check e2251291549814 [[]] .width = true := by decide
def e2251291550058 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251291550058 : Closed e2251291550058 ∧ code e2251291550058 = 11047384572266 := by decide
theorem cert_e2251291550058 : check e2251291550058 [[]] .width = true := by decide
def e2251291550106 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251291550106 : Closed e2251291550106 ∧ code e2251291550106 = 11047384572314 := by decide
theorem cert_e2251291550106 : check e2251291550106 [[]] .width = true := by decide
def e2251292074010 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251292074010 : Closed e2251292074010 ∧ code e2251292074010 = 11047385096218 := by decide
theorem cert_e2251292074010 : check e2251292074010 [[]] .width = true := by decide
def e2251292074102 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251292074102 : Closed e2251292074102 ∧ code e2251292074102 = 11047385096310 := by decide
theorem cert_e2251292074102 : check e2251292074102 [[]] .width = true := by decide
def e2251292074346 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251292074346 : Closed e2251292074346 ∧ code e2251292074346 = 11047385096554 := by decide
theorem cert_e2251292074346 : check e2251292074346 [[]] .width = true := by decide
def e2251292074394 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251292074394 : Closed e2251292074394 ∧ code e2251292074394 = 11047385096602 := by decide
theorem cert_e2251292074394 : check e2251292074394 [[]] .width = true := by decide
def e2251292106778 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251292106778 : Closed e2251292106778 ∧ code e2251292106778 = 11047385128986 := by decide
theorem cert_e2251292106778 : check e2251292106778 [[]] .width = true := by decide
def e2251292106870 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251292106870 : Closed e2251292106870 ∧ code e2251292106870 = 11047385129078 := by decide
theorem cert_e2251292106870 : check e2251292106870 [[]] .width = true := by decide
def e2251292107114 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251292107114 : Closed e2251292107114 ∧ code e2251292107114 = 11047385129322 := by decide
theorem cert_e2251292107114 : check e2251292107114 [[]] .width = true := by decide
def e2251292107162 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251292107162 : Closed e2251292107162 ∧ code e2251292107162 = 11047385129370 := by decide
theorem cert_e2251292107162 : check e2251292107162 [[]] .width = true := by decide
def e2251295744026 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251295744026 : Closed e2251295744026 ∧ code e2251295744026 = 11047388766234 := by decide
theorem cert_e2251295744026 : check e2251295744026 [[]] .width = true := by decide
def e2251295744118 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251295744118 : Closed e2251295744118 ∧ code e2251295744118 = 11047388766326 := by decide
theorem cert_e2251295744118 : check e2251295744118 [[]] .width = true := by decide
def e2251295744362 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251295744362 : Closed e2251295744362 ∧ code e2251295744362 = 11047388766570 := by decide
theorem cert_e2251295744362 : check e2251295744362 [[]] .width = true := by decide
def e2251295744410 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251295744410 : Closed e2251295744410 ∧ code e2251295744410 = 11047388766618 := by decide
theorem cert_e2251295744410 : check e2251295744410 [[]] .width = true := by decide
def e2251296530458 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251296530458 : Closed e2251296530458 ∧ code e2251296530458 = 11047389552666 := by decide
theorem cert_e2251296530458 : check e2251296530458 [[]] .width = true := by decide
def e2251296530550 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251296530550 : Closed e2251296530550 ∧ code e2251296530550 = 11047389552758 := by decide
theorem cert_e2251296530550 : check e2251296530550 [[]] .width = true := by decide
def e2251296530794 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251296530794 : Closed e2251296530794 ∧ code e2251296530794 = 11047389553002 := by decide
theorem cert_e2251296530794 : check e2251296530794 [[]] .width = true := by decide
def e2251296530842 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251296530842 : Closed e2251296530842 ∧ code e2251296530842 = 11047389553050 := by decide
theorem cert_e2251296530842 : check e2251296530842 [[]] .width = true := by decide
def e2251296579610 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251296579610 : Closed e2251296579610 ∧ code e2251296579610 = 11047389601818 := by decide
theorem cert_e2251296579610 : check e2251296579610 [[]] .width = true := by decide
def e2251296579702 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251296579702 : Closed e2251296579702 ∧ code e2251296579702 = 11047389601910 := by decide
theorem cert_e2251296579702 : check e2251296579702 [[]] .width = true := by decide
def e2251296579946 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251296579946 : Closed e2251296579946 ∧ code e2251296579946 = 11047389602154 := by decide
theorem cert_e2251296579946 : check e2251296579946 [[]] .width = true := by decide
def e2251296579994 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251296579994 : Closed e2251296579994 ∧ code e2251296579994 = 11047389602202 := by decide
theorem cert_e2251296579994 : check e2251296579994 [[]] .width = true := by decide
def e2251298365466 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251298365466 : Closed e2251298365466 ∧ code e2251298365466 = 11047391387674 := by decide
theorem cert_e2251298365466 : check e2251298365466 [[]] .width = true := by decide
def e2251298365558 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251298365558 : Closed e2251298365558 ∧ code e2251298365558 = 11047391387766 := by decide
theorem cert_e2251298365558 : check e2251298365558 [[]] .width = true := by decide
def e2251298365802 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251298365802 : Closed e2251298365802 ∧ code e2251298365802 = 11047391388010 := by decide
theorem cert_e2251298365802 : check e2251298365802 [[]] .width = true := by decide
def e2251298365850 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251298365850 : Closed e2251298365850 ∧ code e2251298365850 = 11047391388058 := by decide
theorem cert_e2251298365850 : check e2251298365850 [[]] .width = true := by decide
def e2251298398234 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251298398234 : Closed e2251298398234 ∧ code e2251298398234 = 11047391420442 := by decide
theorem cert_e2251298398234 : check e2251298398234 [[]] .width = true := by decide
def e2251298398326 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251298398326 : Closed e2251298398326 ∧ code e2251298398326 = 11047391420534 := by decide
theorem cert_e2251298398326 : check e2251298398326 [[]] .width = true := by decide
def e2251298398570 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251298398570 : Closed e2251298398570 ∧ code e2251298398570 = 11047391420778 := by decide
theorem cert_e2251298398570 : check e2251298398570 [[]] .width = true := by decide
def e2251298398618 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251298398618 : Closed e2251298398618 ∧ code e2251298398618 = 11047391420826 := by decide
theorem cert_e2251298398618 : check e2251298398618 [[]] .width = true := by decide
def e2251298627610 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251298627610 : Closed e2251298627610 ∧ code e2251298627610 = 11047391649818 := by decide
theorem cert_e2251298627610 : check e2251298627610 [[]] .width = true := by decide
def e2251298627702 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251298627702 : Closed e2251298627702 ∧ code e2251298627702 = 11047391649910 := by decide
theorem cert_e2251298627702 : check e2251298627702 [[]] .width = true := by decide
def e2251298627946 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251298627946 : Closed e2251298627946 ∧ code e2251298627946 = 11047391650154 := by decide
theorem cert_e2251298627946 : check e2251298627946 [[]] .width = true := by decide
def e2251298627994 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251298627994 : Closed e2251298627994 ∧ code e2251298627994 = 11047391650202 := by decide
theorem cert_e2251298627994 : check e2251298627994 [[]] .width = true := by decide
def e2251298676762 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251298676762 : Closed e2251298676762 ∧ code e2251298676762 = 11047391698970 := by decide
theorem cert_e2251298676762 : check e2251298676762 [[]] .width = true := by decide
def e2251298676854 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251298676854 : Closed e2251298676854 ∧ code e2251298676854 = 11047391699062 := by decide
theorem cert_e2251298676854 : check e2251298676854 [[]] .width = true := by decide
def e2251298677098 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251298677098 : Closed e2251298677098 ∧ code e2251298677098 = 11047391699306 := by decide
theorem cert_e2251298677098 : check e2251298677098 [[]] .width = true := by decide
def e2251298677146 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251298677146 : Closed e2251298677146 ∧ code e2251298677146 = 11047391699354 := by decide
theorem cert_e2251298677146 : check e2251298677146 [[]] .width = true := by decide
def e2251298791450 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251298791450 : Closed e2251298791450 ∧ code e2251298791450 = 11047391813658 := by decide
theorem cert_e2251298791450 : check e2251298791450 [[]] .width = true := by decide
def e2251298791542 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251298791542 : Closed e2251298791542 ∧ code e2251298791542 = 11047391813750 := by decide
theorem cert_e2251298791542 : check e2251298791542 [[]] .width = true := by decide
def e2251298791786 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251298791786 : Closed e2251298791786 ∧ code e2251298791786 = 11047391813994 := by decide
theorem cert_e2251298791786 : check e2251298791786 [[]] .width = true := by decide
def e2251298791834 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251298791834 : Closed e2251298791834 ∧ code e2251298791834 = 11047391814042 := by decide
theorem cert_e2251298791834 : check e2251298791834 [[]] .width = true := by decide
def e2251298807834 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251298807834 : Closed e2251298807834 ∧ code e2251298807834 = 11047391830042 := by decide
theorem cert_e2251298807834 : check e2251298807834 [[]] .width = true := by decide
def e2251298807926 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251298807926 : Closed e2251298807926 ∧ code e2251298807926 = 11047391830134 := by decide
theorem cert_e2251298807926 : check e2251298807926 [[]] .width = true := by decide
def e2251298808170 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251298808170 : Closed e2251298808170 ∧ code e2251298808170 = 11047391830378 := by decide
theorem cert_e2251298808170 : check e2251298808170 [[]] .width = true := by decide
def e2251298808218 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251298808218 : Closed e2251298808218 ∧ code e2251298808218 = 11047391830426 := by decide
theorem cert_e2251298808218 : check e2251298808218 [[]] .width = true := by decide
def e2251316715546 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251316715546 : Closed e2251316715546 ∧ code e2251316715546 = 11047409737754 := by decide
theorem cert_e2251316715546 : check e2251316715546 [[]] .width = true := by decide
def e2251316715638 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251316715638 : Closed e2251316715638 ∧ code e2251316715638 = 11047409737846 := by decide
theorem cert_e2251316715638 : check e2251316715638 [[]] .width = true := by decide
def e2251316715882 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251316715882 : Closed e2251316715882 ∧ code e2251316715882 = 11047409738090 := by decide
theorem cert_e2251316715882 : check e2251316715882 [[]] .width = true := by decide
def e2251316715930 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251316715930 : Closed e2251316715930 ∧ code e2251316715930 = 11047409738138 := by decide
theorem cert_e2251316715930 : check e2251316715930 [[]] .width = true := by decide
def e2251317239834 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251317239834 : Closed e2251317239834 ∧ code e2251317239834 = 11047410262042 := by decide
theorem cert_e2251317239834 : check e2251317239834 [[]] .width = true := by decide
def e2251317239926 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251317239926 : Closed e2251317239926 ∧ code e2251317239926 = 11047410262134 := by decide
theorem cert_e2251317239926 : check e2251317239926 [[]] .width = true := by decide
def e2251317240170 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251317240170 : Closed e2251317240170 ∧ code e2251317240170 = 11047410262378 := by decide
theorem cert_e2251317240170 : check e2251317240170 [[]] .width = true := by decide
def e2251317240218 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251317240218 : Closed e2251317240218 ∧ code e2251317240218 = 11047410262426 := by decide
theorem cert_e2251317240218 : check e2251317240218 [[]] .width = true := by decide
def e2251317272602 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251317272602 : Closed e2251317272602 ∧ code e2251317272602 = 11047410294810 := by decide
theorem cert_e2251317272602 : check e2251317272602 [[]] .width = true := by decide
def e2251317272694 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251317272694 : Closed e2251317272694 ∧ code e2251317272694 = 11047410294902 := by decide
theorem cert_e2251317272694 : check e2251317272694 [[]] .width = true := by decide
def e2251317272938 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251317272938 : Closed e2251317272938 ∧ code e2251317272938 = 11047410295146 := by decide
theorem cert_e2251317272938 : check e2251317272938 [[]] .width = true := by decide
def e2251317272986 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251317272986 : Closed e2251317272986 ∧ code e2251317272986 = 11047410295194 := by decide
theorem cert_e2251317272986 : check e2251317272986 [[]] .width = true := by decide
def e2251328249882 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251328249882 : Closed e2251328249882 ∧ code e2251328249882 = 11047421272090 := by decide
theorem cert_e2251328249882 : check e2251328249882 [[]] .width = true := by decide
def e2251328249974 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251328249974 : Closed e2251328249974 ∧ code e2251328249974 = 11047421272182 := by decide
theorem cert_e2251328249974 : check e2251328249974 [[]] .width = true := by decide
def e2251328250218 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251328250218 : Closed e2251328250218 ∧ code e2251328250218 = 11047421272426 := by decide
theorem cert_e2251328250218 : check e2251328250218 [[]] .width = true := by decide
def e2251328250266 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251328250266 : Closed e2251328250266 ∧ code e2251328250266 = 11047421272474 := by decide
theorem cert_e2251328250266 : check e2251328250266 [[]] .width = true := by decide
def e2251331395610 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251331395610 : Closed e2251331395610 ∧ code e2251331395610 = 11047424417818 := by decide
theorem cert_e2251331395610 : check e2251331395610 [[]] .width = true := by decide
def e2251331395702 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251331395702 : Closed e2251331395702 ∧ code e2251331395702 = 11047424417910 := by decide
theorem cert_e2251331395702 : check e2251331395702 [[]] .width = true := by decide
def e2251331395946 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251331395946 : Closed e2251331395946 ∧ code e2251331395946 = 11047424418154 := by decide
theorem cert_e2251331395946 : check e2251331395946 [[]] .width = true := by decide
def e2251331395994 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251331395994 : Closed e2251331395994 ∧ code e2251331395994 = 11047424418202 := by decide
theorem cert_e2251331395994 : check e2251331395994 [[]] .width = true := by decide
def e2251331428378 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251331428378 : Closed e2251331428378 ∧ code e2251331428378 = 11047424450586 := by decide
theorem cert_e2251331428378 : check e2251331428378 [[]] .width = true := by decide
def e2251331428470 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251331428470 : Closed e2251331428470 ∧ code e2251331428470 = 11047424450678 := by decide
theorem cert_e2251331428470 : check e2251331428470 [[]] .width = true := by decide
def e2251331428714 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251331428714 : Closed e2251331428714 ∧ code e2251331428714 = 11047424450922 := by decide
theorem cert_e2251331428714 : check e2251331428714 [[]] .width = true := by decide
def e2251331428762 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251331428762 : Closed e2251331428762 ∧ code e2251331428762 = 11047424450970 := by decide
theorem cert_e2251331428762 : check e2251331428762 [[]] .width = true := by decide
def e2251341881370 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251341881370 : Closed e2251341881370 ∧ code e2251341881370 = 11047434903578 := by decide
theorem cert_e2251341881370 : check e2251341881370 [[]] .width = true := by decide
def e2251341881462 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251341881462 : Closed e2251341881462 ∧ code e2251341881462 = 11047434903670 := by decide
theorem cert_e2251341881462 : check e2251341881462 [[]] .width = true := by decide
def e2251341881706 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251341881706 : Closed e2251341881706 ∧ code e2251341881706 = 11047434903914 := by decide
theorem cert_e2251341881706 : check e2251341881706 [[]] .width = true := by decide
def e2251341881754 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251341881754 : Closed e2251341881754 ∧ code e2251341881754 = 11047434903962 := by decide
theorem cert_e2251341881754 : check e2251341881754 [[]] .width = true := by decide
def e2251342667802 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251342667802 : Closed e2251342667802 ∧ code e2251342667802 = 11047435690010 := by decide
theorem cert_e2251342667802 : check e2251342667802 [[]] .width = true := by decide
def e2251342667894 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251342667894 : Closed e2251342667894 ∧ code e2251342667894 = 11047435690102 := by decide
theorem cert_e2251342667894 : check e2251342667894 [[]] .width = true := by decide
def e2251342668138 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251342668138 : Closed e2251342668138 ∧ code e2251342668138 = 11047435690346 := by decide
theorem cert_e2251342668138 : check e2251342668138 [[]] .width = true := by decide
def e2251342668186 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251342668186 : Closed e2251342668186 ∧ code e2251342668186 = 11047435690394 := by decide
theorem cert_e2251342668186 : check e2251342668186 [[]] .width = true := by decide
def e2251342716954 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251342716954 : Closed e2251342716954 ∧ code e2251342716954 = 11047435739162 := by decide
theorem cert_e2251342716954 : check e2251342716954 [[]] .width = true := by decide
def e2251342717046 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251342717046 : Closed e2251342717046 ∧ code e2251342717046 = 11047435739254 := by decide
theorem cert_e2251342717046 : check e2251342717046 [[]] .width = true := by decide
def e2251342717290 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251342717290 : Closed e2251342717290 ∧ code e2251342717290 = 11047435739498 := by decide
theorem cert_e2251342717290 : check e2251342717290 [[]] .width = true := by decide
def e2251342717338 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251342717338 : Closed e2251342717338 ∧ code e2251342717338 = 11047435739546 := by decide
theorem cert_e2251342717338 : check e2251342717338 [[]] .width = true := by decide
def e2251345027098 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251345027098 : Closed e2251345027098 ∧ code e2251345027098 = 11047438049306 := by decide
theorem cert_e2251345027098 : check e2251345027098 [[]] .width = true := by decide
def e2251345027190 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251345027190 : Closed e2251345027190 ∧ code e2251345027190 = 11047438049398 := by decide
theorem cert_e2251345027190 : check e2251345027190 [[]] .width = true := by decide
def e2251345027434 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251345027434 : Closed e2251345027434 ∧ code e2251345027434 = 11047438049642 := by decide
theorem cert_e2251345027434 : check e2251345027434 [[]] .width = true := by decide
def e2251345027482 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251345027482 : Closed e2251345027482 ∧ code e2251345027482 = 11047438049690 := by decide
theorem cert_e2251345027482 : check e2251345027482 [[]] .width = true := by decide
def e2251349745690 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251349745690 : Closed e2251349745690 ∧ code e2251349745690 = 11047442767898 := by decide
theorem cert_e2251349745690 : check e2251349745690 [[]] .width = true := by decide
def e2251349745782 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251349745782 : Closed e2251349745782 ∧ code e2251349745782 = 11047442767990 := by decide
theorem cert_e2251349745782 : check e2251349745782 [[]] .width = true := by decide
def e2251349746026 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251349746026 : Closed e2251349746026 ∧ code e2251349746026 = 11047442768234 := by decide
theorem cert_e2251349746026 : check e2251349746026 [[]] .width = true := by decide
def e2251349746074 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251349746074 : Closed e2251349746074 ∧ code e2251349746074 = 11047442768282 := by decide
theorem cert_e2251349746074 : check e2251349746074 [[]] .width = true := by decide
def e2251349794842 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251349794842 : Closed e2251349794842 ∧ code e2251349794842 = 11047442817050 := by decide
theorem cert_e2251349794842 : check e2251349794842 [[]] .width = true := by decide
def e2251349794934 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251349794934 : Closed e2251349794934 ∧ code e2251349794934 = 11047442817142 := by decide
theorem cert_e2251349794934 : check e2251349794934 [[]] .width = true := by decide
def e2251349795178 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251349795178 : Closed e2251349795178 ∧ code e2251349795178 = 11047442817386 := by decide
theorem cert_e2251349795178 : check e2251349795178 [[]] .width = true := by decide
def e2251349795226 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251349795226 : Closed e2251349795226 ∧ code e2251349795226 = 11047442817434 := by decide
theorem cert_e2251349795226 : check e2251349795226 [[]] .width = true := by decide
def e2251354988570 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251354988570 : Closed e2251354988570 ∧ code e2251354988570 = 11047448010778 := by decide
theorem cert_e2251354988570 : check e2251354988570 [[]] .width = true := by decide
def e2251354988662 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251354988662 : Closed e2251354988662 ∧ code e2251354988662 = 11047448010870 := by decide
theorem cert_e2251354988662 : check e2251354988662 [[]] .width = true := by decide
def e2251354988906 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251354988906 : Closed e2251354988906 ∧ code e2251354988906 = 11047448011114 := by decide
theorem cert_e2251354988906 : check e2251354988906 [[]] .width = true := by decide
def e2251354988954 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251354988954 : Closed e2251354988954 ∧ code e2251354988954 = 11047448011162 := by decide
theorem cert_e2251354988954 : check e2251354988954 [[]] .width = true := by decide
def e2251355021338 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251355021338 : Closed e2251355021338 ∧ code e2251355021338 = 11047448043546 := by decide
theorem cert_e2251355021338 : check e2251355021338 [[]] .width = true := by decide
def e2251355021430 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251355021430 : Closed e2251355021430 ∧ code e2251355021430 = 11047448043638 := by decide
theorem cert_e2251355021430 : check e2251355021430 [[]] .width = true := by decide
def e2251355021674 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251355021674 : Closed e2251355021674 ∧ code e2251355021674 = 11047448043882 := by decide
theorem cert_e2251355021674 : check e2251355021674 [[]] .width = true := by decide
def e2251355021722 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251355021722 : Closed e2251355021722 ∧ code e2251355021722 = 11047448043930 := by decide
theorem cert_e2251355021722 : check e2251355021722 [[]] .width = true := by decide
def e2251355250714 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251355250714 : Closed e2251355250714 ∧ code e2251355250714 = 11047448272922 := by decide
theorem cert_e2251355250714 : check e2251355250714 [[]] .width = true := by decide
def e2251355250806 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251355250806 : Closed e2251355250806 ∧ code e2251355250806 = 11047448273014 := by decide
theorem cert_e2251355250806 : check e2251355250806 [[]] .width = true := by decide
def e2251355251050 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251355251050 : Closed e2251355251050 ∧ code e2251355251050 = 11047448273258 := by decide
theorem cert_e2251355251050 : check e2251355251050 [[]] .width = true := by decide
def e2251355251098 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251355251098 : Closed e2251355251098 ∧ code e2251355251098 = 11047448273306 := by decide
theorem cert_e2251355251098 : check e2251355251098 [[]] .width = true := by decide
def e2251355299866 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251355299866 : Closed e2251355299866 ∧ code e2251355299866 = 11047448322074 := by decide
theorem cert_e2251355299866 : check e2251355299866 [[]] .width = true := by decide
def e2251355299958 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251355299958 : Closed e2251355299958 ∧ code e2251355299958 = 11047448322166 := by decide
theorem cert_e2251355299958 : check e2251355299958 [[]] .width = true := by decide
def e2251355300202 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251355300202 : Closed e2251355300202 ∧ code e2251355300202 = 11047448322410 := by decide
theorem cert_e2251355300202 : check e2251355300202 [[]] .width = true := by decide
def e2251355300250 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251355300250 : Closed e2251355300250 ∧ code e2251355300250 = 11047448322458 := by decide
theorem cert_e2251355300250 : check e2251355300250 [[]] .width = true := by decide
def e2251355414554 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251355414554 : Closed e2251355414554 ∧ code e2251355414554 = 11047448436762 := by decide
theorem cert_e2251355414554 : check e2251355414554 [[]] .width = true := by decide
def e2251355414646 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251355414646 : Closed e2251355414646 ∧ code e2251355414646 = 11047448436854 := by decide
theorem cert_e2251355414646 : check e2251355414646 [[]] .width = true := by decide
def e2251355414890 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251355414890 : Closed e2251355414890 ∧ code e2251355414890 = 11047448437098 := by decide
theorem cert_e2251355414890 : check e2251355414890 [[]] .width = true := by decide
def e2251355414938 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251355414938 : Closed e2251355414938 ∧ code e2251355414938 = 11047448437146 := by decide
theorem cert_e2251355414938 : check e2251355414938 [[]] .width = true := by decide
def e2251355430938 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251355430938 : Closed e2251355430938 ∧ code e2251355430938 = 11047448453146 := by decide
theorem cert_e2251355430938 : check e2251355430938 [[]] .width = true := by decide
def e2251355431030 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251355431030 : Closed e2251355431030 ∧ code e2251355431030 = 11047448453238 := by decide
theorem cert_e2251355431030 : check e2251355431030 [[]] .width = true := by decide
def e2251355431274 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251355431274 : Closed e2251355431274 ∧ code e2251355431274 = 11047448453482 := by decide
theorem cert_e2251355431274 : check e2251355431274 [[]] .width = true := by decide
def e2251355431322 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251355431322 : Closed e2251355431322 ∧ code e2251355431322 = 11047448453530 := by decide
theorem cert_e2251355431322 : check e2251355431322 [[]] .width = true := by decide
def e2251356561434 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251356561434 : Closed e2251356561434 ∧ code e2251356561434 = 11047449583642 := by decide
theorem cert_e2251356561434 : check e2251356561434 [[]] .width = true := by decide
def e2251356561526 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251356561526 : Closed e2251356561526 ∧ code e2251356561526 = 11047449583734 := by decide
theorem cert_e2251356561526 : check e2251356561526 [[]] .width = true := by decide
def e2251356561770 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251356561770 : Closed e2251356561770 ∧ code e2251356561770 = 11047449583978 := by decide
theorem cert_e2251356561770 : check e2251356561770 [[]] .width = true := by decide
def e2251356561818 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251356561818 : Closed e2251356561818 ∧ code e2251356561818 = 11047449584026 := by decide
theorem cert_e2251356561818 : check e2251356561818 [[]] .width = true := by decide
def e2251356594202 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251356594202 : Closed e2251356594202 ∧ code e2251356594202 = 11047449616410 := by decide
theorem cert_e2251356594202 : check e2251356594202 [[]] .width = true := by decide
def e2251356594294 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251356594294 : Closed e2251356594294 ∧ code e2251356594294 = 11047449616502 := by decide
theorem cert_e2251356594294 : check e2251356594294 [[]] .width = true := by decide
def e2251356594538 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251356594538 : Closed e2251356594538 ∧ code e2251356594538 = 11047449616746 := by decide
theorem cert_e2251356594538 : check e2251356594538 [[]] .width = true := by decide
def e2251356594586 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251356594586 : Closed e2251356594586 ∧ code e2251356594586 = 11047449616794 := by decide
theorem cert_e2251356594586 : check e2251356594586 [[]] .width = true := by decide
def e2251358134298 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251358134298 : Closed e2251358134298 ∧ code e2251358134298 = 11047451156506 := by decide
theorem cert_e2251358134298 : check e2251358134298 [[]] .width = true := by decide
def e2251358134390 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251358134390 : Closed e2251358134390 ∧ code e2251358134390 = 11047451156598 := by decide
theorem cert_e2251358134390 : check e2251358134390 [[]] .width = true := by decide
def e2251358134634 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251358134634 : Closed e2251358134634 ∧ code e2251358134634 = 11047451156842 := by decide
theorem cert_e2251358134634 : check e2251358134634 [[]] .width = true := by decide
def e2251358134682 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251358134682 : Closed e2251358134682 ∧ code e2251358134682 = 11047451156890 := by decide
theorem cert_e2251358134682 : check e2251358134682 [[]] .width = true := by decide
def e2251358183450 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251358183450 : Closed e2251358183450 ∧ code e2251358183450 = 11047451205658 := by decide
theorem cert_e2251358183450 : check e2251358183450 [[]] .width = true := by decide
def e2251358183542 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251358183542 : Closed e2251358183542 ∧ code e2251358183542 = 11047451205750 := by decide
theorem cert_e2251358183542 : check e2251358183542 [[]] .width = true := by decide
def e2251358183786 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2251358183786 : Closed e2251358183786 ∧ code e2251358183786 = 11047451205994 := by decide
theorem cert_e2251358183786 : check e2251358183786 [[]] .width = true := by decide
def e2251358183834 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2251358183834 : Closed e2251358183834 ∧ code e2251358183834 = 11047451206042 := by decide
theorem cert_e2251358183834 : check e2251358183834 [[]] .width = true := by decide
def e2251358953498 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2251358953498 : Closed e2251358953498 ∧ code e2251358953498 = 11047451975706 := by decide
theorem cert_e2251358953498 : check e2251358953498 [[]] .width = true := by decide
def e2251358953590 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2251358953590 : Closed e2251358953590 ∧ code e2251358953590 = 11047451975798 := by decide
theorem cert_e2251358953590 : check e2251358953590 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2249321810806
#print axioms Blc.Floor43.cert_e2249321810902
