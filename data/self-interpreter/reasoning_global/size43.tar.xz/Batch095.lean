import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e834096254686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e834096254686 : Closed e834096254686 ∧ code e834096254686 = 9630189276894 := by decide
theorem cert_e834096254686 : check e834096254686 [] .sourceHead = true := by decide
def e834096254702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))))
theorem wire_e834096254702 : Closed e834096254702 ∧ code e834096254702 = 9630189276910 := by decide
theorem cert_e834096254702 : check e834096254702 [] .sourceHead = true := by decide
def e834096254710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e834096254710 : Closed e834096254710 ∧ code e834096254710 = 9630189276918 := by decide
theorem cert_e834096254710 : check e834096254710 [] .sourceHead = true := by decide
def e834096254814 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e834096254814 : Closed e834096254814 ∧ code e834096254814 = 9630189277022 := by decide
theorem cert_e834096254814 : check e834096254814 [] .sourceHead = true := by decide
def e834096254830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))))
theorem wire_e834096254830 : Closed e834096254830 ∧ code e834096254830 = 9630189277038 := by decide
theorem cert_e834096254830 : check e834096254830 [] .sourceHead = true := by decide
def e834096254838 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))))
theorem wire_e834096254838 : Closed e834096254838 ∧ code e834096254838 = 9630189277046 := by decide
theorem cert_e834096254838 : check e834096254838 [] .sourceHead = true := by decide
def e834096254842 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e834096254842 : Closed e834096254842 ∧ code e834096254842 = 9630189277050 := by decide
theorem cert_e834096254842 : check e834096254842 [] .sourceHead = true := by decide
def e834096254894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e834096254894 : Closed e834096254894 ∧ code e834096254894 = 9630189277102 := by decide
theorem cert_e834096254894 : check e834096254894 [] .sourceHead = true := by decide
def e834096254902 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e834096254902 : Closed e834096254902 ∧ code e834096254902 = 9630189277110 := by decide
theorem cert_e834096254902 : check e834096254902 [] .sourceHead = true := by decide
def e834096254906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e834096254906 : Closed e834096254906 ∧ code e834096254906 = 9630189277114 := by decide
theorem cert_e834096254906 : check e834096254906 [] .sourceHead = true := by decide
def e834096255966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e834096255966 : Closed e834096255966 ∧ code e834096255966 = 9630189278174 := by decide
theorem cert_e834096255966 : check e834096255966 [] .sourceHead = true := by decide
def e834096255982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e834096255982 : Closed e834096255982 ∧ code e834096255982 = 9630189278190 := by decide
theorem cert_e834096255982 : check e834096255982 [] .sourceHead = true := by decide
def e834096257502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e834096257502 : Closed e834096257502 ∧ code e834096257502 = 9630189279710 := by decide
theorem cert_e834096257502 : check e834096257502 [] .sourceHead = true := by decide
def e834096257518 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))))
theorem wire_e834096257518 : Closed e834096257518 ∧ code e834096257518 = 9630189279726 := by decide
theorem cert_e834096257518 : check e834096257518 [] .sourceHead = true := by decide
def e834096257526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e834096257526 : Closed e834096257526 ∧ code e834096257526 = 9630189279734 := by decide
theorem cert_e834096257526 : check e834096257526 [] .sourceHead = true := by decide
def e834096258270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e834096258270 : Closed e834096258270 ∧ code e834096258270 = 9630189280478 := by decide
theorem cert_e834096258270 : check e834096258270 [] .sourceHead = true := by decide
def e834096258286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))))
theorem wire_e834096258286 : Closed e834096258286 ∧ code e834096258286 = 9630189280494 := by decide
theorem cert_e834096258286 : check e834096258286 [] .sourceHead = true := by decide
def e834096258294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))))
theorem wire_e834096258294 : Closed e834096258294 ∧ code e834096258294 = 9630189280502 := by decide
theorem cert_e834096258294 : check e834096258294 [] .sourceHead = true := by decide
def e834096258298 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e834096258298 : Closed e834096258298 ∧ code e834096258298 = 9630189280506 := by decide
theorem cert_e834096258298 : check e834096258298 [] .sourceHead = true := by decide
def e834096258670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096258670 : Closed e834096258670 ∧ code e834096258670 = 9630189280878 := by decide
theorem cert_e834096258670 : check e834096258670 [] .sourceHead = true := by decide
def e834096258678 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e834096258678 : Closed e834096258678 ∧ code e834096258678 = 9630189280886 := by decide
theorem cert_e834096258678 : check e834096258678 [] .sourceHead = true := by decide
def e834096258682 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096258682 : Closed e834096258682 ∧ code e834096258682 = 9630189280890 := by decide
theorem cert_e834096258682 : check e834096258682 [] .sourceHead = true := by decide
def e834096260830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e834096260830 : Closed e834096260830 ∧ code e834096260830 = 9630189283038 := by decide
theorem cert_e834096260830 : check e834096260830 [] .sourceHead = true := by decide
def e834096260846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e834096260846 : Closed e834096260846 ∧ code e834096260846 = 9630189283054 := by decide
theorem cert_e834096260846 : check e834096260846 [] .sourceHead = true := by decide
def e834096260854 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e834096260854 : Closed e834096260854 ∧ code e834096260854 = 9630189283062 := by decide
theorem cert_e834096260854 : check e834096260854 [] .sourceHead = true := by decide
def e834096260958 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e834096260958 : Closed e834096260958 ∧ code e834096260958 = 9630189283166 := by decide
theorem cert_e834096260958 : check e834096260958 [] .sourceHead = true := by decide
def e834096260986 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e834096260986 : Closed e834096260986 ∧ code e834096260986 = 9630189283194 := by decide
theorem cert_e834096260986 : check e834096260986 [] .sourceHead = true := by decide
def e834096261038 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e834096261038 : Closed e834096261038 ∧ code e834096261038 = 9630189283246 := by decide
theorem cert_e834096261038 : check e834096261038 [] .sourceHead = true := by decide
def e834096261050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e834096261050 : Closed e834096261050 ∧ code e834096261050 = 9630189283258 := by decide
theorem cert_e834096261050 : check e834096261050 [] .sourceHead = true := by decide
def e834096261078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e834096261078 : Closed e834096261078 ∧ code e834096261078 = 9630189283286 := by decide
theorem cert_e834096261078 : check e834096261078 [] .sourceHead = true := by decide
def e834096261082 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e834096261082 : Closed e834096261082 ∧ code e834096261082 = 9630189283290 := by decide
theorem cert_e834096261082 : check e834096261082 [] .sourceHead = true := by decide
def e834096261598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e834096261598 : Closed e834096261598 ∧ code e834096261598 = 9630189283806 := by decide
theorem cert_e834096261598 : check e834096261598 [] .sourceHead = true := by decide
def e834096261614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e834096261614 : Closed e834096261614 ∧ code e834096261614 = 9630189283822 := by decide
theorem cert_e834096261614 : check e834096261614 [] .sourceHead = true := by decide
def e834096261622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e834096261622 : Closed e834096261622 ∧ code e834096261622 = 9630189283830 := by decide
theorem cert_e834096261622 : check e834096261622 [] .sourceHead = true := by decide
def e834096262366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e834096262366 : Closed e834096262366 ∧ code e834096262366 = 9630189284574 := by decide
theorem cert_e834096262366 : check e834096262366 [] .sourceHead = true := by decide
def e834096262394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e834096262394 : Closed e834096262394 ∧ code e834096262394 = 9630189284602 := by decide
theorem cert_e834096262394 : check e834096262394 [] .sourceHead = true := by decide
def e834096262766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096262766 : Closed e834096262766 ∧ code e834096262766 = 9630189284974 := by decide
theorem cert_e834096262766 : check e834096262766 [] .sourceHead = true := by decide
def e834096262778 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096262778 : Closed e834096262778 ∧ code e834096262778 = 9630189284986 := by decide
theorem cert_e834096262778 : check e834096262778 [] .sourceHead = true := by decide
def e834096262966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096262966 : Closed e834096262966 ∧ code e834096262966 = 9630189285174 := by decide
theorem cert_e834096262966 : check e834096262966 [] .sourceHead = true := by decide
def e834096262970 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096262970 : Closed e834096262970 ∧ code e834096262970 = 9630189285178 := by decide
theorem cert_e834096262970 : check e834096262970 [] .sourceHead = true := by decide
def e834096264030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e834096264030 : Closed e834096264030 ∧ code e834096264030 = 9630189286238 := by decide
theorem cert_e834096264030 : check e834096264030 [] .sourceHead = true := by decide
def e834096264046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e834096264046 : Closed e834096264046 ∧ code e834096264046 = 9630189286254 := by decide
theorem cert_e834096264046 : check e834096264046 [] .sourceHead = true := by decide
def e834096264054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e834096264054 : Closed e834096264054 ∧ code e834096264054 = 9630189286262 := by decide
theorem cert_e834096264054 : check e834096264054 [] .sourceHead = true := by decide
def e834096264058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e834096264058 : Closed e834096264058 ∧ code e834096264058 = 9630189286266 := by decide
theorem cert_e834096264058 : check e834096264058 [] .sourceHead = true := by decide
def e834096264110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e834096264110 : Closed e834096264110 ∧ code e834096264110 = 9630189286318 := by decide
theorem cert_e834096264110 : check e834096264110 [] .sourceHead = true := by decide
def e834096264122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e834096264122 : Closed e834096264122 ∧ code e834096264122 = 9630189286330 := by decide
theorem cert_e834096264122 : check e834096264122 [] .sourceHead = true := by decide
def e834096264150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e834096264150 : Closed e834096264150 ∧ code e834096264150 = 9630189286358 := by decide
theorem cert_e834096264150 : check e834096264150 [] .sourceHead = true := by decide
def e834096264154 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e834096264154 : Closed e834096264154 ∧ code e834096264154 = 9630189286362 := by decide
theorem cert_e834096264154 : check e834096264154 [] .sourceHead = true := by decide
def e834096264170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e834096264170 : Closed e834096264170 ∧ code e834096264170 = 9630189286378 := by decide
theorem cert_e834096264170 : check e834096264170 [] .sourceHead = true := by decide
def e834096264414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e834096264414 : Closed e834096264414 ∧ code e834096264414 = 9630189286622 := by decide
theorem cert_e834096264414 : check e834096264414 [] .sourceHead = true := by decide
def e834096264430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e834096264430 : Closed e834096264430 ∧ code e834096264430 = 9630189286638 := by decide
theorem cert_e834096264430 : check e834096264430 [] .sourceHead = true := by decide
def e834096264438 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e834096264438 : Closed e834096264438 ∧ code e834096264438 = 9630189286646 := by decide
theorem cert_e834096264438 : check e834096264438 [] .sourceHead = true := by decide
def e834096264442 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e834096264442 : Closed e834096264442 ∧ code e834096264442 = 9630189286650 := by decide
theorem cert_e834096264442 : check e834096264442 [] .sourceHead = true := by decide
def e834096264814 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096264814 : Closed e834096264814 ∧ code e834096264814 = 9630189287022 := by decide
theorem cert_e834096264814 : check e834096264814 [] .sourceHead = true := by decide
def e834096264826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096264826 : Closed e834096264826 ∧ code e834096264826 = 9630189287034 := by decide
theorem cert_e834096264826 : check e834096264826 [] .sourceHead = true := by decide
def e834096265014 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096265014 : Closed e834096265014 ∧ code e834096265014 = 9630189287222 := by decide
theorem cert_e834096265014 : check e834096265014 [] .sourceHead = true := by decide
def e834096265018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096265018 : Closed e834096265018 ∧ code e834096265018 = 9630189287226 := by decide
theorem cert_e834096265018 : check e834096265018 [] .sourceHead = true := by decide
def e834096265114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096265114 : Closed e834096265114 ∧ code e834096265114 = 9630189287322 := by decide
theorem cert_e834096265114 : check e834096265114 [] .sourceHead = true := by decide
def e834096265646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e834096265646 : Closed e834096265646 ∧ code e834096265646 = 9630189287854 := by decide
theorem cert_e834096265646 : check e834096265646 [] .sourceHead = true := by decide
def e834096265654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e834096265654 : Closed e834096265654 ∧ code e834096265654 = 9630189287862 := by decide
theorem cert_e834096265654 : check e834096265654 [] .sourceHead = true := by decide
def e834096265658 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e834096265658 : Closed e834096265658 ∧ code e834096265658 = 9630189287866 := by decide
theorem cert_e834096265658 : check e834096265658 [] .sourceHead = true := by decide
def e834096265686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e834096265686 : Closed e834096265686 ∧ code e834096265686 = 9630189287894 := by decide
theorem cert_e834096265686 : check e834096265686 [] .sourceHead = true := by decide
def e834096265690 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e834096265690 : Closed e834096265690 ∧ code e834096265690 = 9630189287898 := by decide
theorem cert_e834096265690 : check e834096265690 [] .sourceHead = true := by decide
def e834096265706 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e834096265706 : Closed e834096265706 ∧ code e834096265706 = 9630189287914 := by decide
theorem cert_e834096265706 : check e834096265706 [] .sourceHead = true := by decide
def e834096265838 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096265838 : Closed e834096265838 ∧ code e834096265838 = 9630189288046 := by decide
theorem cert_e834096265838 : check e834096265838 [] .sourceHead = true := by decide
def e834096265846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e834096265846 : Closed e834096265846 ∧ code e834096265846 = 9630189288054 := by decide
theorem cert_e834096265846 : check e834096265846 [] .sourceHead = true := by decide
def e834096265850 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096265850 : Closed e834096265850 ∧ code e834096265850 = 9630189288058 := by decide
theorem cert_e834096265850 : check e834096265850 [] .sourceHead = true := by decide
def e834096266038 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096266038 : Closed e834096266038 ∧ code e834096266038 = 9630189288246 := by decide
theorem cert_e834096266038 : check e834096266038 [] .sourceHead = true := by decide
def e834096266042 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096266042 : Closed e834096266042 ∧ code e834096266042 = 9630189288250 := by decide
theorem cert_e834096266042 : check e834096266042 [] .sourceHead = true := by decide
def e834096266138 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096266138 : Closed e834096266138 ∧ code e834096266138 = 9630189288346 := by decide
theorem cert_e834096266138 : check e834096266138 [] .sourceHead = true := by decide
def e834096270190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e834096270190 : Closed e834096270190 ∧ code e834096270190 = 9630189292398 := by decide
theorem cert_e834096270190 : check e834096270190 [] .sourceHead = true := by decide
def e834096270198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e834096270198 : Closed e834096270198 ∧ code e834096270198 = 9630189292406 := by decide
theorem cert_e834096270198 : check e834096270198 [] .sourceHead = true := by decide
def e834096270254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e834096270254 : Closed e834096270254 ∧ code e834096270254 = 9630189292462 := by decide
theorem cert_e834096270254 : check e834096270254 [] .sourceHead = true := by decide
def e834096270266 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e834096270266 : Closed e834096270266 ∧ code e834096270266 = 9630189292474 := by decide
theorem cert_e834096270266 : check e834096270266 [] .sourceHead = true := by decide
def e834096270294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e834096270294 : Closed e834096270294 ∧ code e834096270294 = 9630189292502 := by decide
theorem cert_e834096270294 : check e834096270294 [] .sourceHead = true := by decide
def e834096270298 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e834096270298 : Closed e834096270298 ∧ code e834096270298 = 9630189292506 := by decide
theorem cert_e834096270298 : check e834096270298 [] .sourceHead = true := by decide
def e834096270574 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e834096270574 : Closed e834096270574 ∧ code e834096270574 = 9630189292782 := by decide
theorem cert_e834096270574 : check e834096270574 [] .sourceHead = true := by decide
def e834096270582 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e834096270582 : Closed e834096270582 ∧ code e834096270582 = 9630189292790 := by decide
theorem cert_e834096270582 : check e834096270582 [] .sourceHead = true := by decide
def e834096270958 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e834096270958 : Closed e834096270958 ∧ code e834096270958 = 9630189293166 := by decide
theorem cert_e834096270958 : check e834096270958 [] .sourceHead = true := by decide
def e834096270970 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e834096270970 : Closed e834096270970 ∧ code e834096270970 = 9630189293178 := by decide
theorem cert_e834096270970 : check e834096270970 [] .sourceHead = true := by decide
def e834096271158 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e834096271158 : Closed e834096271158 ∧ code e834096271158 = 9630189293366 := by decide
theorem cert_e834096271158 : check e834096271158 [] .sourceHead = true := by decide
def e834096271162 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e834096271162 : Closed e834096271162 ∧ code e834096271162 = 9630189293370 := by decide
theorem cert_e834096271162 : check e834096271162 [] .sourceHead = true := by decide
def e834096279006 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e834096279006 : Closed e834096279006 ∧ code e834096279006 = 9630189301214 := by decide
theorem cert_e834096279006 : check e834096279006 [] .sourceHead = true := by decide
def e834096279022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e834096279022 : Closed e834096279022 ∧ code e834096279022 = 9630189301230 := by decide
theorem cert_e834096279022 : check e834096279022 [] .sourceHead = true := by decide
def e834096279262 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e834096279262 : Closed e834096279262 ∧ code e834096279262 = 9630189301470 := by decide
theorem cert_e834096279262 : check e834096279262 [] .sourceHead = true := by decide
def e834096279278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))))
theorem wire_e834096279278 : Closed e834096279278 ∧ code e834096279278 = 9630189301486 := by decide
theorem cert_e834096279278 : check e834096279278 [] .sourceHead = true := by decide
def e834096279286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e834096279286 : Closed e834096279286 ∧ code e834096279286 = 9630189301494 := by decide
theorem cert_e834096279286 : check e834096279286 [] .sourceHead = true := by decide
def e834096279390 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e834096279390 : Closed e834096279390 ∧ code e834096279390 = 9630189301598 := by decide
theorem cert_e834096279390 : check e834096279390 [] .sourceHead = true := by decide
def e834096279406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))))
theorem wire_e834096279406 : Closed e834096279406 ∧ code e834096279406 = 9630189301614 := by decide
theorem cert_e834096279406 : check e834096279406 [] .sourceHead = true := by decide
def e834096279414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))))
theorem wire_e834096279414 : Closed e834096279414 ∧ code e834096279414 = 9630189301622 := by decide
theorem cert_e834096279414 : check e834096279414 [] .sourceHead = true := by decide
def e834096279418 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e834096279418 : Closed e834096279418 ∧ code e834096279418 = 9630189301626 := by decide
theorem cert_e834096279418 : check e834096279418 [] .sourceHead = true := by decide
def e834096279470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e834096279470 : Closed e834096279470 ∧ code e834096279470 = 9630189301678 := by decide
theorem cert_e834096279470 : check e834096279470 [] .sourceHead = true := by decide
def e834096279478 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e834096279478 : Closed e834096279478 ∧ code e834096279478 = 9630189301686 := by decide
theorem cert_e834096279478 : check e834096279478 [] .sourceHead = true := by decide
def e834096279482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e834096279482 : Closed e834096279482 ∧ code e834096279482 = 9630189301690 := by decide
theorem cert_e834096279482 : check e834096279482 [] .sourceHead = true := by decide
def e834096280542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e834096280542 : Closed e834096280542 ∧ code e834096280542 = 9630189302750 := by decide
theorem cert_e834096280542 : check e834096280542 [] .sourceHead = true := by decide
def e834096280558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e834096280558 : Closed e834096280558 ∧ code e834096280558 = 9630189302766 := by decide
theorem cert_e834096280558 : check e834096280558 [] .sourceHead = true := by decide
def e834096282078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e834096282078 : Closed e834096282078 ∧ code e834096282078 = 9630189304286 := by decide
theorem cert_e834096282078 : check e834096282078 [] .sourceHead = true := by decide
def e834096282094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))))
theorem wire_e834096282094 : Closed e834096282094 ∧ code e834096282094 = 9630189304302 := by decide
theorem cert_e834096282094 : check e834096282094 [] .sourceHead = true := by decide
def e834096282102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e834096282102 : Closed e834096282102 ∧ code e834096282102 = 9630189304310 := by decide
theorem cert_e834096282102 : check e834096282102 [] .sourceHead = true := by decide
def e834096282846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e834096282846 : Closed e834096282846 ∧ code e834096282846 = 9630189305054 := by decide
theorem cert_e834096282846 : check e834096282846 [] .sourceHead = true := by decide
def e834096282862 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834096282862 : Closed e834096282862 ∧ code e834096282862 = 9630189305070 := by decide
theorem cert_e834096282862 : check e834096282862 [] .sourceHead = true := by decide
def e834096282870 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834096282870 : Closed e834096282870 ∧ code e834096282870 = 9630189305078 := by decide
theorem cert_e834096282870 : check e834096282870 [] .sourceHead = true := by decide
def e834096282874 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e834096282874 : Closed e834096282874 ∧ code e834096282874 = 9630189305082 := by decide
theorem cert_e834096282874 : check e834096282874 [] .sourceHead = true := by decide
def e834096283246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096283246 : Closed e834096283246 ∧ code e834096283246 = 9630189305454 := by decide
theorem cert_e834096283246 : check e834096283246 [] .sourceHead = true := by decide
def e834096283254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e834096283254 : Closed e834096283254 ∧ code e834096283254 = 9630189305462 := by decide
theorem cert_e834096283254 : check e834096283254 [] .sourceHead = true := by decide
def e834096283258 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096283258 : Closed e834096283258 ∧ code e834096283258 = 9630189305466 := by decide
theorem cert_e834096283258 : check e834096283258 [] .sourceHead = true := by decide
def e834096305886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e834096305886 : Closed e834096305886 ∧ code e834096305886 = 9630189328094 := by decide
theorem cert_e834096305886 : check e834096305886 [] .sourceHead = true := by decide
def e834096305902 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e834096305902 : Closed e834096305902 ∧ code e834096305902 = 9630189328110 := by decide
theorem cert_e834096305902 : check e834096305902 [] .sourceHead = true := by decide
def e834096305910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e834096305910 : Closed e834096305910 ∧ code e834096305910 = 9630189328118 := by decide
theorem cert_e834096305910 : check e834096305910 [] .sourceHead = true := by decide
def e834096306014 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e834096306014 : Closed e834096306014 ∧ code e834096306014 = 9630189328222 := by decide
theorem cert_e834096306014 : check e834096306014 [] .sourceHead = true := by decide
def e834096306042 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e834096306042 : Closed e834096306042 ∧ code e834096306042 = 9630189328250 := by decide
theorem cert_e834096306042 : check e834096306042 [] .sourceHead = true := by decide
def e834096306094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e834096306094 : Closed e834096306094 ∧ code e834096306094 = 9630189328302 := by decide
theorem cert_e834096306094 : check e834096306094 [] .sourceHead = true := by decide
def e834096306106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e834096306106 : Closed e834096306106 ∧ code e834096306106 = 9630189328314 := by decide
theorem cert_e834096306106 : check e834096306106 [] .sourceHead = true := by decide
def e834096306134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e834096306134 : Closed e834096306134 ∧ code e834096306134 = 9630189328342 := by decide
theorem cert_e834096306134 : check e834096306134 [] .sourceHead = true := by decide
def e834096306138 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e834096306138 : Closed e834096306138 ∧ code e834096306138 = 9630189328346 := by decide
theorem cert_e834096306138 : check e834096306138 [] .sourceHead = true := by decide
def e834096306654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e834096306654 : Closed e834096306654 ∧ code e834096306654 = 9630189328862 := by decide
theorem cert_e834096306654 : check e834096306654 [] .sourceHead = true := by decide
def e834096306670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e834096306670 : Closed e834096306670 ∧ code e834096306670 = 9630189328878 := by decide
theorem cert_e834096306670 : check e834096306670 [] .sourceHead = true := by decide
def e834096306678 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e834096306678 : Closed e834096306678 ∧ code e834096306678 = 9630189328886 := by decide
theorem cert_e834096306678 : check e834096306678 [] .sourceHead = true := by decide
def e834096307422 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e834096307422 : Closed e834096307422 ∧ code e834096307422 = 9630189329630 := by decide
theorem cert_e834096307422 : check e834096307422 [] .sourceHead = true := by decide
def e834096307450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e834096307450 : Closed e834096307450 ∧ code e834096307450 = 9630189329658 := by decide
theorem cert_e834096307450 : check e834096307450 [] .sourceHead = true := by decide
def e834096307822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096307822 : Closed e834096307822 ∧ code e834096307822 = 9630189330030 := by decide
theorem cert_e834096307822 : check e834096307822 [] .sourceHead = true := by decide
def e834096307834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096307834 : Closed e834096307834 ∧ code e834096307834 = 9630189330042 := by decide
theorem cert_e834096307834 : check e834096307834 [] .sourceHead = true := by decide
def e834096308022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834096308022 : Closed e834096308022 ∧ code e834096308022 = 9630189330230 := by decide
theorem cert_e834096308022 : check e834096308022 [] .sourceHead = true := by decide
def e834096308026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834096308026 : Closed e834096308026 ∧ code e834096308026 = 9630189330234 := by decide
theorem cert_e834096308026 : check e834096308026 [] .sourceHead = true := by decide
def e834096319326 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e834096319326 : Closed e834096319326 ∧ code e834096319326 = 9630189341534 := by decide
theorem cert_e834096319326 : check e834096319326 [] .sourceHead = true := by decide
def e834096319342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e834096319342 : Closed e834096319342 ∧ code e834096319342 = 9630189341550 := by decide
theorem cert_e834096319342 : check e834096319342 [] .sourceHead = true := by decide
def e834096319350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e834096319350 : Closed e834096319350 ∧ code e834096319350 = 9630189341558 := by decide
theorem cert_e834096319350 : check e834096319350 [] .sourceHead = true := by decide
def e834096319354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e834096319354 : Closed e834096319354 ∧ code e834096319354 = 9630189341562 := by decide
theorem cert_e834096319354 : check e834096319354 [] .sourceHead = true := by decide
def e834096319406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e834096319406 : Closed e834096319406 ∧ code e834096319406 = 9630189341614 := by decide
theorem cert_e834096319406 : check e834096319406 [] .sourceHead = true := by decide
def e834096319418 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e834096319418 : Closed e834096319418 ∧ code e834096319418 = 9630189341626 := by decide
theorem cert_e834096319418 : check e834096319418 [] .sourceHead = true := by decide
def e834096319446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e834096319446 : Closed e834096319446 ∧ code e834096319446 = 9630189341654 := by decide
theorem cert_e834096319446 : check e834096319446 [] .sourceHead = true := by decide
def e834096319450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e834096319450 : Closed e834096319450 ∧ code e834096319450 = 9630189341658 := by decide
theorem cert_e834096319450 : check e834096319450 [] .sourceHead = true := by decide
def e834096319466 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e834096319466 : Closed e834096319466 ∧ code e834096319466 = 9630189341674 := by decide
theorem cert_e834096319466 : check e834096319466 [] .sourceHead = true := by decide
def e834096319710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e834096319710 : Closed e834096319710 ∧ code e834096319710 = 9630189341918 := by decide
theorem cert_e834096319710 : check e834096319710 [] .sourceHead = true := by decide
def e834096319726 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834096319726 : Closed e834096319726 ∧ code e834096319726 = 9630189341934 := by decide
theorem cert_e834096319726 : check e834096319726 [] .sourceHead = true := by decide
def e834096319734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834096319734 : Closed e834096319734 ∧ code e834096319734 = 9630189341942 := by decide
theorem cert_e834096319734 : check e834096319734 [] .sourceHead = true := by decide
def e834096319738 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e834096319738 : Closed e834096319738 ∧ code e834096319738 = 9630189341946 := by decide
theorem cert_e834096319738 : check e834096319738 [] .sourceHead = true := by decide
def e834096320110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096320110 : Closed e834096320110 ∧ code e834096320110 = 9630189342318 := by decide
theorem cert_e834096320110 : check e834096320110 [] .sourceHead = true := by decide
def e834096320122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096320122 : Closed e834096320122 ∧ code e834096320122 = 9630189342330 := by decide
theorem cert_e834096320122 : check e834096320122 [] .sourceHead = true := by decide
def e834096320310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834096320310 : Closed e834096320310 ∧ code e834096320310 = 9630189342518 := by decide
theorem cert_e834096320310 : check e834096320310 [] .sourceHead = true := by decide
def e834096320314 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834096320314 : Closed e834096320314 ∧ code e834096320314 = 9630189342522 := by decide
theorem cert_e834096320314 : check e834096320314 [] .sourceHead = true := by decide
def e834096320410 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834096320410 : Closed e834096320410 ∧ code e834096320410 = 9630189342618 := by decide
theorem cert_e834096320410 : check e834096320410 [] .sourceHead = true := by decide
def e834096326062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e834096326062 : Closed e834096326062 ∧ code e834096326062 = 9630189348270 := by decide
theorem cert_e834096326062 : check e834096326062 [] .sourceHead = true := by decide
def e834096326070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e834096326070 : Closed e834096326070 ∧ code e834096326070 = 9630189348278 := by decide
theorem cert_e834096326070 : check e834096326070 [] .sourceHead = true := by decide
def e834096326074 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e834096326074 : Closed e834096326074 ∧ code e834096326074 = 9630189348282 := by decide
theorem cert_e834096326074 : check e834096326074 [] .sourceHead = true := by decide
def e834096326102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e834096326102 : Closed e834096326102 ∧ code e834096326102 = 9630189348310 := by decide
theorem cert_e834096326102 : check e834096326102 [] .sourceHead = true := by decide
def e834096326106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e834096326106 : Closed e834096326106 ∧ code e834096326106 = 9630189348314 := by decide
theorem cert_e834096326106 : check e834096326106 [] .sourceHead = true := by decide
def e834096326122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e834096326122 : Closed e834096326122 ∧ code e834096326122 = 9630189348330 := by decide
theorem cert_e834096326122 : check e834096326122 [] .sourceHead = true := by decide
def e834096326254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096326254 : Closed e834096326254 ∧ code e834096326254 = 9630189348462 := by decide
theorem cert_e834096326254 : check e834096326254 [] .sourceHead = true := by decide
def e834096326262 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e834096326262 : Closed e834096326262 ∧ code e834096326262 = 9630189348470 := by decide
theorem cert_e834096326262 : check e834096326262 [] .sourceHead = true := by decide
def e834096326266 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096326266 : Closed e834096326266 ∧ code e834096326266 = 9630189348474 := by decide
theorem cert_e834096326266 : check e834096326266 [] .sourceHead = true := by decide
def e834096326454 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834096326454 : Closed e834096326454 ∧ code e834096326454 = 9630189348662 := by decide
theorem cert_e834096326454 : check e834096326454 [] .sourceHead = true := by decide
def e834096326458 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834096326458 : Closed e834096326458 ∧ code e834096326458 = 9630189348666 := by decide
theorem cert_e834096326458 : check e834096326458 [] .sourceHead = true := by decide
def e834096326554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834096326554 : Closed e834096326554 ∧ code e834096326554 = 9630189348762 := by decide
theorem cert_e834096326554 : check e834096326554 [] .sourceHead = true := by decide
def e834096772462 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e834096772462 : Closed e834096772462 ∧ code e834096772462 = 9630189794670 := by decide
theorem cert_e834096772462 : check e834096772462 [] .sourceHead = true := by decide
def e834096772470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e834096772470 : Closed e834096772470 ∧ code e834096772470 = 9630189794678 := by decide
theorem cert_e834096772470 : check e834096772470 [] .sourceHead = true := by decide
def e834096772526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e834096772526 : Closed e834096772526 ∧ code e834096772526 = 9630189794734 := by decide
theorem cert_e834096772526 : check e834096772526 [] .sourceHead = true := by decide
def e834096772538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e834096772538 : Closed e834096772538 ∧ code e834096772538 = 9630189794746 := by decide
theorem cert_e834096772538 : check e834096772538 [] .sourceHead = true := by decide
def e834096772566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e834096772566 : Closed e834096772566 ∧ code e834096772566 = 9630189794774 := by decide
theorem cert_e834096772566 : check e834096772566 [] .sourceHead = true := by decide
def e834096772570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e834096772570 : Closed e834096772570 ∧ code e834096772570 = 9630189794778 := by decide
theorem cert_e834096772570 : check e834096772570 [] .sourceHead = true := by decide
end Blc.Floor43
