import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e826969140762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969140762 : Closed e826969140762 ∧ code e826969140762 = 9623062162970 := by decide
theorem cert_e826969140762 : check e826969140762 [] .sourceHead = true := by decide
def e826969143834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969143834 : Closed e826969143834 ∧ code e826969143834 = 9623062166042 := by decide
theorem cert_e826969143834 : check e826969143834 [] .sourceHead = true := by decide
def e826969151002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969151002 : Closed e826969151002 ∧ code e826969151002 = 9623062173210 := by decide
theorem cert_e826969151002 : check e826969151002 [] .sourceHead = true := by decide
def e826969152026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969152026 : Closed e826969152026 ∧ code e826969152026 = 9623062174234 := by decide
theorem cert_e826969152026 : check e826969152026 [] .sourceHead = true := by decide
def e826969222682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969222682 : Closed e826969222682 ∧ code e826969222682 = 9623062244890 := by decide
theorem cert_e826969222682 : check e826969222682 [] .sourceHead = true := by decide
def e826969224730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969224730 : Closed e826969224730 ∧ code e826969224730 = 9623062246938 := by decide
theorem cert_e826969224730 : check e826969224730 [] .sourceHead = true := by decide
def e826969320986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969320986 : Closed e826969320986 ∧ code e826969320986 = 9623062343194 := by decide
theorem cert_e826969320986 : check e826969320986 [] .sourceHead = true := by decide
def e826969324058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969324058 : Closed e826969324058 ∧ code e826969324058 = 9623062346266 := by decide
theorem cert_e826969324058 : check e826969324058 [] .sourceHead = true := by decide
def e826969350170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826969350170 : Closed e826969350170 ∧ code e826969350170 = 9623062372378 := by decide
theorem cert_e826969350170 : check e826969350170 [] .sourceHead = true := by decide
def e826969350262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826969350262 : Closed e826969350262 ∧ code e826969350262 = 9623062372470 := by decide
theorem cert_e826969350262 : check e826969350262 [] .sourceHead = true := by decide
def e826969350506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826969350506 : Closed e826969350506 ∧ code e826969350506 = 9623062372714 := by decide
theorem cert_e826969350506 : check e826969350506 [] .sourceHead = true := by decide
def e826969350554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826969350554 : Closed e826969350554 ∧ code e826969350554 = 9623062372762 := by decide
theorem cert_e826969350554 : check e826969350554 [] .sourceHead = true := by decide
def e826969351706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826969351706 : Closed e826969351706 ∧ code e826969351706 = 9623062373914 := by decide
theorem cert_e826969351706 : check e826969351706 [] .sourceHead = true := by decide
def e826969372186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969372186 : Closed e826969372186 ∧ code e826969372186 = 9623062394394 := by decide
theorem cert_e826969372186 : check e826969372186 [] .sourceHead = true := by decide
def e826969373210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969373210 : Closed e826969373210 ∧ code e826969373210 = 9623062395418 := by decide
theorem cert_e826969373210 : check e826969373210 [] .sourceHead = true := by decide
def e826969382938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826969382938 : Closed e826969382938 ∧ code e826969382938 = 9623062405146 := by decide
theorem cert_e826969382938 : check e826969382938 [] .sourceHead = true := by decide
def e826969383030 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826969383030 : Closed e826969383030 ∧ code e826969383030 = 9623062405238 := by decide
theorem cert_e826969383030 : check e826969383030 [] .sourceHead = true := by decide
def e826969383274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826969383274 : Closed e826969383274 ∧ code e826969383274 = 9623062405482 := by decide
theorem cert_e826969383274 : check e826969383274 [] .sourceHead = true := by decide
def e826969383322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826969383322 : Closed e826969383322 ∧ code e826969383322 = 9623062405530 := by decide
theorem cert_e826969383322 : check e826969383322 [] .sourceHead = true := by decide
def e826969384474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826969384474 : Closed e826969384474 ∧ code e826969384474 = 9623062406682 := by decide
theorem cert_e826969384474 : check e826969384474 [] .sourceHead = true := by decide
def e826969533978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969533978 : Closed e826969533978 ∧ code e826969533978 = 9623062556186 := by decide
theorem cert_e826969533978 : check e826969533978 [] .sourceHead = true := by decide
def e826969537050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969537050 : Closed e826969537050 ∧ code e826969537050 = 9623062559258 := by decide
theorem cert_e826969537050 : check e826969537050 [] .sourceHead = true := by decide
def e826969549338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969549338 : Closed e826969549338 ∧ code e826969549338 = 9623062571546 := by decide
theorem cert_e826969549338 : check e826969549338 [] .sourceHead = true := by decide
def e826969583130 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969583130 : Closed e826969583130 ∧ code e826969583130 = 9623062605338 := by decide
theorem cert_e826969583130 : check e826969583130 [] .sourceHead = true := by decide
def e826969586202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969586202 : Closed e826969586202 ∧ code e826969586202 = 9623062608410 := by decide
theorem cert_e826969586202 : check e826969586202 [] .sourceHead = true := by decide
def e826969612314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826969612314 : Closed e826969612314 ∧ code e826969612314 = 9623062634522 := by decide
theorem cert_e826969612314 : check e826969612314 [] .sourceHead = true := by decide
def e826969612406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826969612406 : Closed e826969612406 ∧ code e826969612406 = 9623062634614 := by decide
theorem cert_e826969612406 : check e826969612406 [] .sourceHead = true := by decide
def e826969612650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826969612650 : Closed e826969612650 ∧ code e826969612650 = 9623062634858 := by decide
theorem cert_e826969612650 : check e826969612650 [] .sourceHead = true := by decide
def e826969612698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826969612698 : Closed e826969612698 ∧ code e826969612698 = 9623062634906 := by decide
theorem cert_e826969612698 : check e826969612698 [] .sourceHead = true := by decide
def e826969613850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826969613850 : Closed e826969613850 ∧ code e826969613850 = 9623062636058 := by decide
theorem cert_e826969613850 : check e826969613850 [] .sourceHead = true := by decide
def e826969659930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969659930 : Closed e826969659930 ∧ code e826969659930 = 9623062682138 := by decide
theorem cert_e826969659930 : check e826969659930 [] .sourceHead = true := by decide
def e826969661466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826969661466 : Closed e826969661466 ∧ code e826969661466 = 9623062683674 := by decide
theorem cert_e826969661466 : check e826969661466 [] .sourceHead = true := by decide
def e826969661558 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826969661558 : Closed e826969661558 ∧ code e826969661558 = 9623062683766 := by decide
theorem cert_e826969661558 : check e826969661558 [] .sourceHead = true := by decide
def e826969661802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826969661802 : Closed e826969661802 ∧ code e826969661802 = 9623062684010 := by decide
theorem cert_e826969661802 : check e826969661802 [] .sourceHead = true := by decide
def e826969661850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826969661850 : Closed e826969661850 ∧ code e826969661850 = 9623062684058 := by decide
theorem cert_e826969661850 : check e826969661850 [] .sourceHead = true := by decide
def e826969663002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826969663002 : Closed e826969663002 ∧ code e826969663002 = 9623062685210 := by decide
theorem cert_e826969663002 : check e826969663002 [] .sourceHead = true := by decide
def e826969740826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969740826 : Closed e826969740826 ∧ code e826969740826 = 9623062763034 := by decide
theorem cert_e826969740826 : check e826969740826 [] .sourceHead = true := by decide
def e826969741850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969741850 : Closed e826969741850 ∧ code e826969741850 = 9623062764058 := by decide
theorem cert_e826969741850 : check e826969741850 [] .sourceHead = true := by decide
def e826969745946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969745946 : Closed e826969745946 ∧ code e826969745946 = 9623062768154 := by decide
theorem cert_e826969745946 : check e826969745946 [] .sourceHead = true := by decide
def e826969765402 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969765402 : Closed e826969765402 ∧ code e826969765402 = 9623062787610 := by decide
theorem cert_e826969765402 : check e826969765402 [] .sourceHead = true := by decide
def e826969766426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969766426 : Closed e826969766426 ∧ code e826969766426 = 9623062788634 := by decide
theorem cert_e826969766426 : check e826969766426 [] .sourceHead = true := by decide
def e826969776154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826969776154 : Closed e826969776154 ∧ code e826969776154 = 9623062798362 := by decide
theorem cert_e826969776154 : check e826969776154 [] .sourceHead = true := by decide
def e826969776246 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826969776246 : Closed e826969776246 ∧ code e826969776246 = 9623062798454 := by decide
theorem cert_e826969776246 : check e826969776246 [] .sourceHead = true := by decide
def e826969776490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826969776490 : Closed e826969776490 ∧ code e826969776490 = 9623062798698 := by decide
theorem cert_e826969776490 : check e826969776490 [] .sourceHead = true := by decide
def e826969776538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826969776538 : Closed e826969776538 ∧ code e826969776538 = 9623062798746 := by decide
theorem cert_e826969776538 : check e826969776538 [] .sourceHead = true := by decide
def e826969777690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826969777690 : Closed e826969777690 ∧ code e826969777690 = 9623062799898 := by decide
theorem cert_e826969777690 : check e826969777690 [] .sourceHead = true := by decide
def e826969791002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969791002 : Closed e826969791002 ∧ code e826969791002 = 9623062813210 := by decide
theorem cert_e826969791002 : check e826969791002 [] .sourceHead = true := by decide
def e826969792538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826969792538 : Closed e826969792538 ∧ code e826969792538 = 9623062814746 := by decide
theorem cert_e826969792538 : check e826969792538 [] .sourceHead = true := by decide
def e826969792630 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826969792630 : Closed e826969792630 ∧ code e826969792630 = 9623062814838 := by decide
theorem cert_e826969792630 : check e826969792630 [] .sourceHead = true := by decide
def e826969792874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826969792874 : Closed e826969792874 ∧ code e826969792874 = 9623062815082 := by decide
theorem cert_e826969792874 : check e826969792874 [] .sourceHead = true := by decide
def e826969792922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826969792922 : Closed e826969792922 ∧ code e826969792922 = 9623062815130 := by decide
theorem cert_e826969792922 : check e826969792922 [] .sourceHead = true := by decide
def e826969794074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826969794074 : Closed e826969794074 ∧ code e826969794074 = 9623062816282 := by decide
theorem cert_e826969794074 : check e826969794074 [] .sourceHead = true := by decide
def e826970697242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970697242 : Closed e826970697242 ∧ code e826970697242 = 9623063719450 := by decide
theorem cert_e826970697242 : check e826970697242 [] .sourceHead = true := by decide
def e826970699290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970699290 : Closed e826970699290 ∧ code e826970699290 = 9623063721498 := by decide
theorem cert_e826970699290 : check e826970699290 [] .sourceHead = true := by decide
def e826970713626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970713626 : Closed e826970713626 ∧ code e826970713626 = 9623063735834 := by decide
theorem cert_e826970713626 : check e826970713626 [] .sourceHead = true := by decide
def e826970716698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970716698 : Closed e826970716698 ∧ code e826970716698 = 9623063738906 := by decide
theorem cert_e826970716698 : check e826970716698 [] .sourceHead = true := by decide
def e826970723866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970723866 : Closed e826970723866 ∧ code e826970723866 = 9623063746074 := by decide
theorem cert_e826970723866 : check e826970723866 [] .sourceHead = true := by decide
def e826970724890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970724890 : Closed e826970724890 ∧ code e826970724890 = 9623063747098 := by decide
theorem cert_e826970724890 : check e826970724890 [] .sourceHead = true := by decide
def e826970795546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970795546 : Closed e826970795546 ∧ code e826970795546 = 9623063817754 := by decide
theorem cert_e826970795546 : check e826970795546 [] .sourceHead = true := by decide
def e826970797594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970797594 : Closed e826970797594 ∧ code e826970797594 = 9623063819802 := by decide
theorem cert_e826970797594 : check e826970797594 [] .sourceHead = true := by decide
def e826970893850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970893850 : Closed e826970893850 ∧ code e826970893850 = 9623063916058 := by decide
theorem cert_e826970893850 : check e826970893850 [] .sourceHead = true := by decide
def e826970896922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970896922 : Closed e826970896922 ∧ code e826970896922 = 9623063919130 := by decide
theorem cert_e826970896922 : check e826970896922 [] .sourceHead = true := by decide
def e826970923034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826970923034 : Closed e826970923034 ∧ code e826970923034 = 9623063945242 := by decide
theorem cert_e826970923034 : check e826970923034 [] .sourceHead = true := by decide
def e826970923126 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826970923126 : Closed e826970923126 ∧ code e826970923126 = 9623063945334 := by decide
theorem cert_e826970923126 : check e826970923126 [] .sourceHead = true := by decide
def e826970923370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826970923370 : Closed e826970923370 ∧ code e826970923370 = 9623063945578 := by decide
theorem cert_e826970923370 : check e826970923370 [] .sourceHead = true := by decide
def e826970923418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826970923418 : Closed e826970923418 ∧ code e826970923418 = 9623063945626 := by decide
theorem cert_e826970923418 : check e826970923418 [] .sourceHead = true := by decide
def e826970924570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826970924570 : Closed e826970924570 ∧ code e826970924570 = 9623063946778 := by decide
theorem cert_e826970924570 : check e826970924570 [] .sourceHead = true := by decide
def e826970945050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970945050 : Closed e826970945050 ∧ code e826970945050 = 9623063967258 := by decide
theorem cert_e826970945050 : check e826970945050 [] .sourceHead = true := by decide
def e826970946074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826970946074 : Closed e826970946074 ∧ code e826970946074 = 9623063968282 := by decide
theorem cert_e826970946074 : check e826970946074 [] .sourceHead = true := by decide
def e826970955802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826970955802 : Closed e826970955802 ∧ code e826970955802 = 9623063978010 := by decide
theorem cert_e826970955802 : check e826970955802 [] .sourceHead = true := by decide
def e826970955894 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826970955894 : Closed e826970955894 ∧ code e826970955894 = 9623063978102 := by decide
theorem cert_e826970955894 : check e826970955894 [] .sourceHead = true := by decide
def e826970956138 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826970956138 : Closed e826970956138 ∧ code e826970956138 = 9623063978346 := by decide
theorem cert_e826970956138 : check e826970956138 [] .sourceHead = true := by decide
def e826970956186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826970956186 : Closed e826970956186 ∧ code e826970956186 = 9623063978394 := by decide
theorem cert_e826970956186 : check e826970956186 [] .sourceHead = true := by decide
def e826970957338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826970957338 : Closed e826970957338 ∧ code e826970957338 = 9623063979546 := by decide
theorem cert_e826970957338 : check e826970957338 [] .sourceHead = true := by decide
def e826971041134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e826971041134 : Closed e826971041134 ∧ code e826971041134 = 9623064063342 := by decide
theorem cert_e826971041134 : check e826971041134 [] .sourceHead = true := by decide
def e826971041142 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e826971041142 : Closed e826971041142 ∧ code e826971041142 = 9623064063350 := by decide
theorem cert_e826971041142 : check e826971041142 [] .sourceHead = true := by decide
def e826971041198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e826971041198 : Closed e826971041198 ∧ code e826971041198 = 9623064063406 := by decide
theorem cert_e826971041198 : check e826971041198 [] .sourceHead = true := by decide
def e826971041210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e826971041210 : Closed e826971041210 ∧ code e826971041210 = 9623064063418 := by decide
theorem cert_e826971041210 : check e826971041210 [] .sourceHead = true := by decide
def e826971041238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e826971041238 : Closed e826971041238 ∧ code e826971041238 = 9623064063446 := by decide
theorem cert_e826971041238 : check e826971041238 [] .sourceHead = true := by decide
def e826971041242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e826971041242 : Closed e826971041242 ∧ code e826971041242 = 9623064063450 := by decide
theorem cert_e826971041242 : check e826971041242 [] .sourceHead = true := by decide
def e826971041454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e826971041454 : Closed e826971041454 ∧ code e826971041454 = 9623064063662 := by decide
theorem cert_e826971041454 : check e826971041454 [] .sourceHead = true := by decide
def e826971041466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e826971041466 : Closed e826971041466 ∧ code e826971041466 = 9623064063674 := by decide
theorem cert_e826971041466 : check e826971041466 [] .sourceHead = true := by decide
def e826971041514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e826971041514 : Closed e826971041514 ∧ code e826971041514 = 9623064063722 := by decide
theorem cert_e826971041514 : check e826971041514 [] .sourceHead = true := by decide
def e826971041622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e826971041622 : Closed e826971041622 ∧ code e826971041622 = 9623064063830 := by decide
theorem cert_e826971041622 : check e826971041622 [] .sourceHead = true := by decide
def e826971041626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e826971041626 : Closed e826971041626 ∧ code e826971041626 = 9623064063834 := by decide
theorem cert_e826971041626 : check e826971041626 [] .sourceHead = true := by decide
def e826971041642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e826971041642 : Closed e826971041642 ∧ code e826971041642 = 9623064063850 := by decide
theorem cert_e826971041642 : check e826971041642 [] .sourceHead = true := by decide
def e826971042670 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e826971042670 : Closed e826971042670 ∧ code e826971042670 = 9623064064878 := by decide
theorem cert_e826971042670 : check e826971042670 [] .sourceHead = true := by decide
def e826971042678 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e826971042678 : Closed e826971042678 ∧ code e826971042678 = 9623064064886 := by decide
theorem cert_e826971042678 : check e826971042678 [] .sourceHead = true := by decide
def e826971042734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e826971042734 : Closed e826971042734 ∧ code e826971042734 = 9623064064942 := by decide
theorem cert_e826971042734 : check e826971042734 [] .sourceHead = true := by decide
def e826971042746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e826971042746 : Closed e826971042746 ∧ code e826971042746 = 9623064064954 := by decide
theorem cert_e826971042746 : check e826971042746 [] .sourceHead = true := by decide
def e826971042774 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e826971042774 : Closed e826971042774 ∧ code e826971042774 = 9623064064982 := by decide
theorem cert_e826971042774 : check e826971042774 [] .sourceHead = true := by decide
def e826971042778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e826971042778 : Closed e826971042778 ∧ code e826971042778 = 9623064064986 := by decide
theorem cert_e826971042778 : check e826971042778 [] .sourceHead = true := by decide
def e826971043054 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e826971043054 : Closed e826971043054 ∧ code e826971043054 = 9623064065262 := by decide
theorem cert_e826971043054 : check e826971043054 [] .sourceHead = true := by decide
def e826971043062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e826971043062 : Closed e826971043062 ∧ code e826971043062 = 9623064065270 := by decide
theorem cert_e826971043062 : check e826971043062 [] .sourceHead = true := by decide
def e826971043438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e826971043438 : Closed e826971043438 ∧ code e826971043438 = 9623064065646 := by decide
theorem cert_e826971043438 : check e826971043438 [] .sourceHead = true := by decide
def e826971043450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e826971043450 : Closed e826971043450 ∧ code e826971043450 = 9623064065658 := by decide
theorem cert_e826971043450 : check e826971043450 [] .sourceHead = true := by decide
def e826971043638 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e826971043638 : Closed e826971043638 ∧ code e826971043638 = 9623064065846 := by decide
theorem cert_e826971043638 : check e826971043638 [] .sourceHead = true := by decide
def e826971043642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e826971043642 : Closed e826971043642 ∧ code e826971043642 = 9623064065850 := by decide
theorem cert_e826971043642 : check e826971043642 [] .sourceHead = true := by decide
def e826971044270 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e826971044270 : Closed e826971044270 ∧ code e826971044270 = 9623064066478 := by decide
theorem cert_e826971044270 : check e826971044270 [] .sourceHead = true := by decide
def e826971044282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e826971044282 : Closed e826971044282 ∧ code e826971044282 = 9623064066490 := by decide
theorem cert_e826971044282 : check e826971044282 [] .sourceHead = true := by decide
def e826971044330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e826971044330 : Closed e826971044330 ∧ code e826971044330 = 9623064066538 := by decide
theorem cert_e826971044330 : check e826971044330 [] .sourceHead = true := by decide
def e826971044462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e826971044462 : Closed e826971044462 ∧ code e826971044462 = 9623064066670 := by decide
theorem cert_e826971044462 : check e826971044462 [] .sourceHead = true := by decide
def e826971044474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e826971044474 : Closed e826971044474 ∧ code e826971044474 = 9623064066682 := by decide
theorem cert_e826971044474 : check e826971044474 [] .sourceHead = true := by decide
def e826971044762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e826971044762 : Closed e826971044762 ∧ code e826971044762 = 9623064066970 := by decide
theorem cert_e826971044762 : check e826971044762 [] .sourceHead = true := by decide
def e826971045078 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e826971045078 : Closed e826971045078 ∧ code e826971045078 = 9623064067286 := by decide
theorem cert_e826971045078 : check e826971045078 [] .sourceHead = true := by decide
def e826971045082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e826971045082 : Closed e826971045082 ∧ code e826971045082 = 9623064067290 := by decide
theorem cert_e826971045082 : check e826971045082 [] .sourceHead = true := by decide
def e826971045098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e826971045098 : Closed e826971045098 ∧ code e826971045098 = 9623064067306 := by decide
theorem cert_e826971045098 : check e826971045098 [] .sourceHead = true := by decide
def e826971045174 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e826971045174 : Closed e826971045174 ∧ code e826971045174 = 9623064067382 := by decide
theorem cert_e826971045174 : check e826971045174 [] .sourceHead = true := by decide
def e826971045178 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e826971045178 : Closed e826971045178 ∧ code e826971045178 = 9623064067386 := by decide
theorem cert_e826971045178 : check e826971045178 [] .sourceHead = true := by decide
def e826971045274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e826971045274 : Closed e826971045274 ∧ code e826971045274 = 9623064067482 := by decide
theorem cert_e826971045274 : check e826971045274 [] .sourceHead = true := by decide
def e826971048814 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e826971048814 : Closed e826971048814 ∧ code e826971048814 = 9623064071022 := by decide
theorem cert_e826971048814 : check e826971048814 [] .sourceHead = true := by decide
def e826971048822 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e826971048822 : Closed e826971048822 ∧ code e826971048822 = 9623064071030 := by decide
theorem cert_e826971048822 : check e826971048822 [] .sourceHead = true := by decide
def e826971048878 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e826971048878 : Closed e826971048878 ∧ code e826971048878 = 9623064071086 := by decide
theorem cert_e826971048878 : check e826971048878 [] .sourceHead = true := by decide
def e826971048890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e826971048890 : Closed e826971048890 ∧ code e826971048890 = 9623064071098 := by decide
theorem cert_e826971048890 : check e826971048890 [] .sourceHead = true := by decide
def e826971048918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e826971048918 : Closed e826971048918 ∧ code e826971048918 = 9623064071126 := by decide
theorem cert_e826971048918 : check e826971048918 [] .sourceHead = true := by decide
def e826971048922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e826971048922 : Closed e826971048922 ∧ code e826971048922 = 9623064071130 := by decide
theorem cert_e826971048922 : check e826971048922 [] .sourceHead = true := by decide
def e826971049198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e826971049198 : Closed e826971049198 ∧ code e826971049198 = 9623064071406 := by decide
theorem cert_e826971049198 : check e826971049198 [] .sourceHead = true := by decide
def e826971049206 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e826971049206 : Closed e826971049206 ∧ code e826971049206 = 9623064071414 := by decide
theorem cert_e826971049206 : check e826971049206 [] .sourceHead = true := by decide
def e826971049582 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e826971049582 : Closed e826971049582 ∧ code e826971049582 = 9623064071790 := by decide
theorem cert_e826971049582 : check e826971049582 [] .sourceHead = true := by decide
def e826971049594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e826971049594 : Closed e826971049594 ∧ code e826971049594 = 9623064071802 := by decide
theorem cert_e826971049594 : check e826971049594 [] .sourceHead = true := by decide
def e826971049782 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e826971049782 : Closed e826971049782 ∧ code e826971049782 = 9623064071990 := by decide
theorem cert_e826971049782 : check e826971049782 [] .sourceHead = true := by decide
def e826971049786 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e826971049786 : Closed e826971049786 ∧ code e826971049786 = 9623064071994 := by decide
theorem cert_e826971049786 : check e826971049786 [] .sourceHead = true := by decide
def e826971055534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e826971055534 : Closed e826971055534 ∧ code e826971055534 = 9623064077742 := by decide
theorem cert_e826971055534 : check e826971055534 [] .sourceHead = true := by decide
def e826971055546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e826971055546 : Closed e826971055546 ∧ code e826971055546 = 9623064077754 := by decide
theorem cert_e826971055546 : check e826971055546 [] .sourceHead = true := by decide
def e826971055594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e826971055594 : Closed e826971055594 ∧ code e826971055594 = 9623064077802 := by decide
theorem cert_e826971055594 : check e826971055594 [] .sourceHead = true := by decide
def e826971055726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e826971055726 : Closed e826971055726 ∧ code e826971055726 = 9623064077934 := by decide
theorem cert_e826971055726 : check e826971055726 [] .sourceHead = true := by decide
def e826971055738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e826971055738 : Closed e826971055738 ∧ code e826971055738 = 9623064077946 := by decide
theorem cert_e826971055738 : check e826971055738 [] .sourceHead = true := by decide
def e826971056026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e826971056026 : Closed e826971056026 ∧ code e826971056026 = 9623064078234 := by decide
theorem cert_e826971056026 : check e826971056026 [] .sourceHead = true := by decide
def e826971058902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e826971058902 : Closed e826971058902 ∧ code e826971058902 = 9623064081110 := by decide
theorem cert_e826971058902 : check e826971058902 [] .sourceHead = true := by decide
def e826971058906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e826971058906 : Closed e826971058906 ∧ code e826971058906 = 9623064081114 := by decide
theorem cert_e826971058906 : check e826971058906 [] .sourceHead = true := by decide
def e826971058922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e826971058922 : Closed e826971058922 ∧ code e826971058922 = 9623064081130 := by decide
theorem cert_e826971058922 : check e826971058922 [] .sourceHead = true := by decide
def e826971058998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e826971058998 : Closed e826971058998 ∧ code e826971058998 = 9623064081206 := by decide
theorem cert_e826971058998 : check e826971058998 [] .sourceHead = true := by decide
def e826971059002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e826971059002 : Closed e826971059002 ∧ code e826971059002 = 9623064081210 := by decide
theorem cert_e826971059002 : check e826971059002 [] .sourceHead = true := by decide
def e826971059098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e826971059098 : Closed e826971059098 ∧ code e826971059098 = 9623064081306 := by decide
theorem cert_e826971059098 : check e826971059098 [] .sourceHead = true := by decide
def e826972417562 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826972417562 : Closed e826972417562 ∧ code e826972417562 = 9623065439770 := by decide
theorem cert_e826972417562 : check e826972417562 [] .sourceHead = true := by decide
def e826972420634 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826972420634 : Closed e826972420634 ∧ code e826972420634 = 9623065442842 := by decide
theorem cert_e826972420634 : check e826972420634 [] .sourceHead = true := by decide
def e826972432922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826972432922 : Closed e826972432922 ∧ code e826972432922 = 9623065455130 := by decide
theorem cert_e826972432922 : check e826972432922 [] .sourceHead = true := by decide
def e826972466714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826972466714 : Closed e826972466714 ∧ code e826972466714 = 9623065488922 := by decide
theorem cert_e826972466714 : check e826972466714 [] .sourceHead = true := by decide
def e826972469786 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826972469786 : Closed e826972469786 ∧ code e826972469786 = 9623065491994 := by decide
theorem cert_e826972469786 : check e826972469786 [] .sourceHead = true := by decide
def e826972495898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826972495898 : Closed e826972495898 ∧ code e826972495898 = 9623065518106 := by decide
theorem cert_e826972495898 : check e826972495898 [] .sourceHead = true := by decide
def e826972495990 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826972495990 : Closed e826972495990 ∧ code e826972495990 = 9623065518198 := by decide
theorem cert_e826972495990 : check e826972495990 [] .sourceHead = true := by decide
def e826972496234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826972496234 : Closed e826972496234 ∧ code e826972496234 = 9623065518442 := by decide
theorem cert_e826972496234 : check e826972496234 [] .sourceHead = true := by decide
def e826972496282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826972496282 : Closed e826972496282 ∧ code e826972496282 = 9623065518490 := by decide
theorem cert_e826972496282 : check e826972496282 [] .sourceHead = true := by decide
def e826972497434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826972497434 : Closed e826972497434 ∧ code e826972497434 = 9623065519642 := by decide
theorem cert_e826972497434 : check e826972497434 [] .sourceHead = true := by decide
def e826972543514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826972543514 : Closed e826972543514 ∧ code e826972543514 = 9623065565722 := by decide
theorem cert_e826972543514 : check e826972543514 [] .sourceHead = true := by decide
def e826972545050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826972545050 : Closed e826972545050 ∧ code e826972545050 = 9623065567258 := by decide
theorem cert_e826972545050 : check e826972545050 [] .sourceHead = true := by decide
def e826972545142 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826972545142 : Closed e826972545142 ∧ code e826972545142 = 9623065567350 := by decide
theorem cert_e826972545142 : check e826972545142 [] .sourceHead = true := by decide
def e826972545386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826972545386 : Closed e826972545386 ∧ code e826972545386 = 9623065567594 := by decide
theorem cert_e826972545386 : check e826972545386 [] .sourceHead = true := by decide
def e826972545434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826972545434 : Closed e826972545434 ∧ code e826972545434 = 9623065567642 := by decide
theorem cert_e826972545434 : check e826972545434 [] .sourceHead = true := by decide
def e826972546586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826972546586 : Closed e826972546586 ∧ code e826972546586 = 9623065568794 := by decide
theorem cert_e826972546586 : check e826972546586 [] .sourceHead = true := by decide
def e826973279770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826973279770 : Closed e826973279770 ∧ code e826973279770 = 9623066301978 := by decide
theorem cert_e826973279770 : check e826973279770 [] .sourceHead = true := by decide
def e826973280794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826973280794 : Closed e826973280794 ∧ code e826973280794 = 9623066303002 := by decide
theorem cert_e826973280794 : check e826973280794 [] .sourceHead = true := by decide
def e826973284890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826973284890 : Closed e826973284890 ∧ code e826973284890 = 9623066307098 := by decide
theorem cert_e826973284890 : check e826973284890 [] .sourceHead = true := by decide
def e826973304346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826973304346 : Closed e826973304346 ∧ code e826973304346 = 9623066326554 := by decide
theorem cert_e826973304346 : check e826973304346 [] .sourceHead = true := by decide
def e826973305370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826973305370 : Closed e826973305370 ∧ code e826973305370 = 9623066327578 := by decide
theorem cert_e826973305370 : check e826973305370 [] .sourceHead = true := by decide
def e826973315098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826973315098 : Closed e826973315098 ∧ code e826973315098 = 9623066337306 := by decide
theorem cert_e826973315098 : check e826973315098 [] .sourceHead = true := by decide
def e826973315190 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826973315190 : Closed e826973315190 ∧ code e826973315190 = 9623066337398 := by decide
theorem cert_e826973315190 : check e826973315190 [] .sourceHead = true := by decide
def e826973315434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826973315434 : Closed e826973315434 ∧ code e826973315434 = 9623066337642 := by decide
theorem cert_e826973315434 : check e826973315434 [] .sourceHead = true := by decide
def e826973315482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826973315482 : Closed e826973315482 ∧ code e826973315482 = 9623066337690 := by decide
theorem cert_e826973315482 : check e826973315482 [] .sourceHead = true := by decide
def e826973316634 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826973316634 : Closed e826973316634 ∧ code e826973316634 = 9623066338842 := by decide
theorem cert_e826973316634 : check e826973316634 [] .sourceHead = true := by decide
end Blc.Floor43
