import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2249153771118 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2249153771118 : Closed e2249153771118 ∧ code e2249153771118 = 11045246793326 := by decide
theorem cert_e2249153771118 : check e2249153771118 [[],[.under,.left]] .chain = true := by decide
def e2249153771130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2249153771130 : Closed e2249153771130 ∧ code e2249153771130 = 11045246793338 := by decide
theorem cert_e2249153771130 : check e2249153771130 [[],[.under,.left]] .chain = true := by decide
def e2249153771318 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2249153771318 : Closed e2249153771318 ∧ code e2249153771318 = 11045246793526 := by decide
theorem cert_e2249153771318 : check e2249153771318 [[],[.under,.left]] .chain = true := by decide
def e2249153771322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2249153771322 : Closed e2249153771322 ∧ code e2249153771322 = 11045246793530 := by decide
theorem cert_e2249153771322 : check e2249153771322 [[],[.under,.left]] .chain = true := by decide
def e2249153776494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2249153776494 : Closed e2249153776494 ∧ code e2249153776494 = 11045246798702 := by decide
theorem cert_e2249153776494 : check e2249153776494 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153776502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2249153776502 : Closed e2249153776502 ∧ code e2249153776502 = 11045246798710 := by decide
theorem cert_e2249153776502 : check e2249153776502 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153776558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2249153776558 : Closed e2249153776558 ∧ code e2249153776558 = 11045246798766 := by decide
theorem cert_e2249153776558 : check e2249153776558 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153776570 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2249153776570 : Closed e2249153776570 ∧ code e2249153776570 = 11045246798778 := by decide
theorem cert_e2249153776570 : check e2249153776570 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153776598 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2249153776598 : Closed e2249153776598 ∧ code e2249153776598 = 11045246798806 := by decide
theorem cert_e2249153776598 : check e2249153776598 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153776602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2249153776602 : Closed e2249153776602 ∧ code e2249153776602 = 11045246798810 := by decide
theorem cert_e2249153776602 : check e2249153776602 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153776878 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2249153776878 : Closed e2249153776878 ∧ code e2249153776878 = 11045246799086 := by decide
theorem cert_e2249153776878 : check e2249153776878 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153776886 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2249153776886 : Closed e2249153776886 ∧ code e2249153776886 = 11045246799094 := by decide
theorem cert_e2249153776886 : check e2249153776886 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153777262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249153777262 : Closed e2249153777262 ∧ code e2249153777262 = 11045246799470 := by decide
theorem cert_e2249153777262 : check e2249153777262 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153777274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249153777274 : Closed e2249153777274 ∧ code e2249153777274 = 11045246799482 := by decide
theorem cert_e2249153777274 : check e2249153777274 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153777462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249153777462 : Closed e2249153777462 ∧ code e2249153777462 = 11045246799670 := by decide
theorem cert_e2249153777462 : check e2249153777462 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153777466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249153777466 : Closed e2249153777466 ∧ code e2249153777466 = 11045246799674 := by decide
theorem cert_e2249153777466 : check e2249153777466 [[],[.under,.left],[.under]] .chain = true := by decide
def e2249153785582 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2249153785582 : Closed e2249153785582 ∧ code e2249153785582 = 11045246807790 := by decide
theorem cert_e2249153785582 : check e2249153785582 [[],[.under,.left]] .chain = true := by decide
def e2249153785710 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2249153785710 : Closed e2249153785710 ∧ code e2249153785710 = 11045246807918 := by decide
theorem cert_e2249153785710 : check e2249153785710 [[],[.under,.left]] .chain = true := by decide
def e2249153785718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2249153785718 : Closed e2249153785718 ∧ code e2249153785718 = 11045246807926 := by decide
theorem cert_e2249153785718 : check e2249153785718 [[],[.under,.left]] .chain = true := by decide
def e2249153788398 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2249153788398 : Closed e2249153788398 ∧ code e2249153788398 = 11045246810606 := by decide
theorem cert_e2249153788398 : check e2249153788398 [[],[.under,.left]] .chain = true := by decide
def e2249153789166 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2249153789166 : Closed e2249153789166 ∧ code e2249153789166 = 11045246811374 := by decide
theorem cert_e2249153789166 : check e2249153789166 [[],[.under,.left]] .chain = true := by decide
def e2249153789174 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2249153789174 : Closed e2249153789174 ∧ code e2249153789174 = 11045246811382 := by decide
theorem cert_e2249153789174 : check e2249153789174 [[],[.under,.left]] .chain = true := by decide
def e2249153812206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2249153812206 : Closed e2249153812206 ∧ code e2249153812206 = 11045246834414 := by decide
theorem cert_e2249153812206 : check e2249153812206 [[],[.under,.left]] .chain = true := by decide
def e2249153812398 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2249153812398 : Closed e2249153812398 ∧ code e2249153812398 = 11045246834606 := by decide
theorem cert_e2249153812398 : check e2249153812398 [[],[.under,.left]] .chain = true := by decide
def e2249153812410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2249153812410 : Closed e2249153812410 ∧ code e2249153812410 = 11045246834618 := by decide
theorem cert_e2249153812410 : check e2249153812410 [[],[.under,.left]] .chain = true := by decide
def e2249153812974 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2249153812974 : Closed e2249153812974 ∧ code e2249153812974 = 11045246835182 := by decide
theorem cert_e2249153812974 : check e2249153812974 [[],[.under,.left]] .chain = true := by decide
def e2249153814126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2249153814126 : Closed e2249153814126 ∧ code e2249153814126 = 11045246836334 := by decide
theorem cert_e2249153814126 : check e2249153814126 [[],[.under,.left]] .chain = true := by decide
def e2249153814138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2249153814138 : Closed e2249153814138 ∧ code e2249153814138 = 11045246836346 := by decide
theorem cert_e2249153814138 : check e2249153814138 [[],[.under,.left]] .chain = true := by decide
def e2249153825646 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2249153825646 : Closed e2249153825646 ∧ code e2249153825646 = 11045246847854 := by decide
theorem cert_e2249153825646 : check e2249153825646 [[],[.under,.left]] .chain = true := by decide
def e2249153825654 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2249153825654 : Closed e2249153825654 ∧ code e2249153825654 = 11045246847862 := by decide
theorem cert_e2249153825654 : check e2249153825654 [[],[.under,.left]] .chain = true := by decide
def e2249153825710 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2249153825710 : Closed e2249153825710 ∧ code e2249153825710 = 11045246847918 := by decide
theorem cert_e2249153825710 : check e2249153825710 [[],[.under,.left]] .chain = true := by decide
def e2249153825722 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2249153825722 : Closed e2249153825722 ∧ code e2249153825722 = 11045246847930 := by decide
theorem cert_e2249153825722 : check e2249153825722 [[],[.under,.left]] .chain = true := by decide
def e2249153825750 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2249153825750 : Closed e2249153825750 ∧ code e2249153825750 = 11045246847958 := by decide
theorem cert_e2249153825750 : check e2249153825750 [[],[.under,.left]] .chain = true := by decide
def e2249153825754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2249153825754 : Closed e2249153825754 ∧ code e2249153825754 = 11045246847962 := by decide
theorem cert_e2249153825754 : check e2249153825754 [[],[.under,.left]] .chain = true := by decide
def e2249153826030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2249153826030 : Closed e2249153826030 ∧ code e2249153826030 = 11045246848238 := by decide
theorem cert_e2249153826030 : check e2249153826030 [[],[.under,.left]] .chain = true := by decide
def e2249153826038 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2249153826038 : Closed e2249153826038 ∧ code e2249153826038 = 11045246848246 := by decide
theorem cert_e2249153826038 : check e2249153826038 [[],[.under,.left]] .chain = true := by decide
def e2249153826414 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2249153826414 : Closed e2249153826414 ∧ code e2249153826414 = 11045246848622 := by decide
theorem cert_e2249153826414 : check e2249153826414 [[],[.under,.left]] .chain = true := by decide
def e2249153826426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2249153826426 : Closed e2249153826426 ∧ code e2249153826426 = 11045246848634 := by decide
theorem cert_e2249153826426 : check e2249153826426 [[],[.under,.left]] .chain = true := by decide
def e2249153826614 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2249153826614 : Closed e2249153826614 ∧ code e2249153826614 = 11045246848822 := by decide
theorem cert_e2249153826614 : check e2249153826614 [[],[.under,.left]] .chain = true := by decide
def e2249153826618 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2249153826618 : Closed e2249153826618 ∧ code e2249153826618 = 11045246848826 := by decide
theorem cert_e2249153826618 : check e2249153826618 [[],[.under,.left]] .chain = true := by decide
def e2249154366318 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2249154366318 : Closed e2249154366318 ∧ code e2249154366318 = 11045247388526 := by decide
theorem cert_e2249154366318 : check e2249154366318 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154366326 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2249154366326 : Closed e2249154366326 ∧ code e2249154366326 = 11045247388534 := by decide
theorem cert_e2249154366326 : check e2249154366326 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154366382 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2249154366382 : Closed e2249154366382 ∧ code e2249154366382 = 11045247388590 := by decide
theorem cert_e2249154366382 : check e2249154366382 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154366394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2249154366394 : Closed e2249154366394 ∧ code e2249154366394 = 11045247388602 := by decide
theorem cert_e2249154366394 : check e2249154366394 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154366422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2249154366422 : Closed e2249154366422 ∧ code e2249154366422 = 11045247388630 := by decide
theorem cert_e2249154366422 : check e2249154366422 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154366426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2249154366426 : Closed e2249154366426 ∧ code e2249154366426 = 11045247388634 := by decide
theorem cert_e2249154366426 : check e2249154366426 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154366702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2249154366702 : Closed e2249154366702 ∧ code e2249154366702 = 11045247388910 := by decide
theorem cert_e2249154366702 : check e2249154366702 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154366710 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2249154366710 : Closed e2249154366710 ∧ code e2249154366710 = 11045247388918 := by decide
theorem cert_e2249154366710 : check e2249154366710 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154367086 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249154367086 : Closed e2249154367086 ∧ code e2249154367086 = 11045247389294 := by decide
theorem cert_e2249154367086 : check e2249154367086 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154367098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249154367098 : Closed e2249154367098 ∧ code e2249154367098 = 11045247389306 := by decide
theorem cert_e2249154367098 : check e2249154367098 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154367286 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249154367286 : Closed e2249154367286 ∧ code e2249154367286 = 11045247389494 := by decide
theorem cert_e2249154367286 : check e2249154367286 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249154367290 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249154367290 : Closed e2249154367290 ∧ code e2249154367290 = 11045247389498 := by decide
theorem cert_e2249154367290 : check e2249154367290 [[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2249223682074 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249223682074 : Closed e2249223682074 ∧ code e2249223682074 = 11045316704282 := by decide
theorem cert_e2249223682074 : check e2249223682074 [[]] .width = true := by decide
def e2249223690266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249223690266 : Closed e2249223690266 ∧ code e2249223690266 = 11045316712474 := by decide
theorem cert_e2249223690266 : check e2249223690266 [[]] .width = true := by decide
def e2249223691802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249223691802 : Closed e2249223691802 ∧ code e2249223691802 = 11045316714010 := by decide
private def t_e2249223691802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249223691802 : ¬ IsSelfInterpreter e2249223691802 :=
  wSource (t := t_e2249223691802) (replay_sound (ps := []) (t := e2249223691802) (by decide)) (by decide)
def e2249223695898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249223695898 : Closed e2249223695898 ∧ code e2249223695898 = 11045316718106 := by decide
private def t_e2249223695898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249223695898 : ¬ IsSelfInterpreter e2249223695898 :=
  wSource (t := t_e2249223695898) (replay_sound (ps := []) (t := e2249223695898) (by decide)) (by decide)
def e2249223747610 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249223747610 : Closed e2249223747610 ∧ code e2249223747610 = 11045316769818 := by decide
theorem cert_e2249223747610 : check e2249223747610 [[]] .width = true := by decide
def e2249223759898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249223759898 : Closed e2249223759898 ∧ code e2249223759898 = 11045316782106 := by decide
theorem cert_e2249223759898 : check e2249223759898 [[]] .width = true := by decide
def e2249223788570 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249223788570 : Closed e2249223788570 ∧ code e2249223788570 = 11045316810778 := by decide
theorem cert_e2249223788570 : check e2249223788570 [[]] .width = true := by decide
def e2249223790106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249223790106 : Closed e2249223790106 ∧ code e2249223790106 = 11045316812314 := by decide
private def t_e2249223790106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249223790106 : ¬ IsSelfInterpreter e2249223790106 :=
  wSource (t := t_e2249223790106) (replay_sound (ps := []) (t := e2249223790106) (by decide)) (by decide)
def e2249223792666 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249223792666 : Closed e2249223792666 ∧ code e2249223792666 = 11045316814874 := by decide
theorem cert_e2249223792666 : check e2249223792666 [[]] .width = true := by decide
def e2249223797274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249223797274 : Closed e2249223797274 ∧ code e2249223797274 = 11045316819482 := by decide
private def t_e2249223797274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249223797274 : ¬ IsSelfInterpreter e2249223797274 :=
  wSource (t := t_e2249223797274) (replay_sound (ps := []) (t := e2249223797274) (by decide)) (by decide)
def e2249223810586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249223810586 : Closed e2249223810586 ∧ code e2249223810586 = 11045316832794 := by decide
private def t_e2249223810586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249223810586 : ¬ IsSelfInterpreter e2249223810586 :=
  wSource (t := t_e2249223810586) (replay_sound (ps := []) (t := e2249223810586) (by decide)) (by decide)
def e2249223813658 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249223813658 : Closed e2249223813658 ∧ code e2249223813658 = 11045316835866 := by decide
private def t_e2249223813658 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249223813658 : ¬ IsSelfInterpreter e2249223813658 :=
  wSource (t := t_e2249223813658) (replay_sound (ps := []) (t := e2249223813658) (by decide)) (by decide)
def e2249224075290 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249224075290 : Closed e2249224075290 ∧ code e2249224075290 = 11045317097498 := by decide
theorem cert_e2249224075290 : check e2249224075290 [[]] .width = true := by decide
def e2249224083482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249224083482 : Closed e2249224083482 ∧ code e2249224083482 = 11045317105690 := by decide
theorem cert_e2249224083482 : check e2249224083482 [[]] .width = true := by decide
def e2249224085018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249224085018 : Closed e2249224085018 ∧ code e2249224085018 = 11045317107226 := by decide
private def t_e2249224085018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249224085018 : ¬ IsSelfInterpreter e2249224085018 :=
  wSource (t := t_e2249224085018) (replay_sound (ps := []) (t := e2249224085018) (by decide)) (by decide)
def e2249224089114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249224089114 : Closed e2249224089114 ∧ code e2249224089114 = 11045317111322 := by decide
private def t_e2249224089114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249224089114 : ¬ IsSelfInterpreter e2249224089114 :=
  wSource (t := t_e2249224089114) (replay_sound (ps := []) (t := e2249224089114) (by decide)) (by decide)
def e2249224468506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249224468506 : Closed e2249224468506 ∧ code e2249224468506 = 11045317490714 := by decide
theorem cert_e2249224468506 : check e2249224468506 [[]] .width = true := by decide
def e2249224480794 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249224480794 : Closed e2249224480794 ∧ code e2249224480794 = 11045317503002 := by decide
theorem cert_e2249224480794 : check e2249224480794 [[]] .width = true := by decide
def e2249224673306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249224673306 : Closed e2249224673306 ∧ code e2249224673306 = 11045317695514 := by decide
theorem cert_e2249224673306 : check e2249224673306 [[]] .width = true := by decide
def e2249224674842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249224674842 : Closed e2249224674842 ∧ code e2249224674842 = 11045317697050 := by decide
private def t_e2249224674842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249224674842 : ¬ IsSelfInterpreter e2249224674842 :=
  wSource (t := t_e2249224674842) (replay_sound (ps := []) (t := e2249224674842) (by decide)) (by decide)
def e2249224677402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2249224677402 : Closed e2249224677402 ∧ code e2249224677402 = 11045317699610 := by decide
theorem cert_e2249224677402 : check e2249224677402 [[]] .width = true := by decide
def e2249224682010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249224682010 : Closed e2249224682010 ∧ code e2249224682010 = 11045317704218 := by decide
private def t_e2249224682010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249224682010 : ¬ IsSelfInterpreter e2249224682010 :=
  wSource (t := t_e2249224682010) (replay_sound (ps := []) (t := e2249224682010) (by decide)) (by decide)
def e2249224777242 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249224777242 : Closed e2249224777242 ∧ code e2249224777242 = 11045317799450 := by decide
private def t_e2249224777242 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249224777242 : ¬ IsSelfInterpreter e2249224777242 :=
  wSource (t := t_e2249224777242) (replay_sound (ps := []) (t := e2249224777242) (by decide)) (by decide)
def e2249224780314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249224780314 : Closed e2249224780314 ∧ code e2249224780314 = 11045317802522 := by decide
private def t_e2249224780314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249224780314 : ¬ IsSelfInterpreter e2249224780314 :=
  wSource (t := t_e2249224780314) (replay_sound (ps := []) (t := e2249224780314) (by decide)) (by decide)
def e2249232051738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232051738 : Closed e2249232051738 ∧ code e2249232051738 = 11045325073946 := by decide
private def t_e2249232051738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232051738 : ¬ IsSelfInterpreter e2249232051738 :=
  wSource (t := t_e2249232051738) (replay_sound (ps := []) (t := e2249232051738) (by decide)) (by decide)
def e2249232053786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232053786 : Closed e2249232053786 ∧ code e2249232053786 = 11045325075994 := by decide
private def t_e2249232053786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232053786 : ¬ IsSelfInterpreter e2249232053786 :=
  wSource (t := t_e2249232053786) (replay_sound (ps := []) (t := e2249232053786) (by decide)) (by decide)
def e2249232068122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232068122 : Closed e2249232068122 ∧ code e2249232068122 = 11045325090330 := by decide
private def t_e2249232068122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232068122 : ¬ IsSelfInterpreter e2249232068122 :=
  wSource (t := t_e2249232068122) (replay_sound (ps := []) (t := e2249232068122) (by decide)) (by decide)
def e2249232071194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232071194 : Closed e2249232071194 ∧ code e2249232071194 = 11045325093402 := by decide
private def t_e2249232071194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232071194 : ¬ IsSelfInterpreter e2249232071194 :=
  wSource (t := t_e2249232071194) (replay_sound (ps := []) (t := e2249232071194) (by decide)) (by decide)
def e2249232078362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232078362 : Closed e2249232078362 ∧ code e2249232078362 = 11045325100570 := by decide
private def t_e2249232078362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232078362 : ¬ IsSelfInterpreter e2249232078362 :=
  wSource (t := t_e2249232078362) (replay_sound (ps := []) (t := e2249232078362) (by decide)) (by decide)
def e2249232079386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232079386 : Closed e2249232079386 ∧ code e2249232079386 = 11045325101594 := by decide
private def t_e2249232079386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232079386 : ¬ IsSelfInterpreter e2249232079386 :=
  wSource (t := t_e2249232079386) (replay_sound (ps := []) (t := e2249232079386) (by decide)) (by decide)
def e2249232133658 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232133658 : Closed e2249232133658 ∧ code e2249232133658 = 11045325155866 := by decide
private def t_e2249232133658 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232133658 : ¬ IsSelfInterpreter e2249232133658 :=
  wSource (t := t_e2249232133658) (replay_sound (ps := []) (t := e2249232133658) (by decide)) (by decide)
def e2249232136730 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232136730 : Closed e2249232136730 ∧ code e2249232136730 = 11045325158938 := by decide
private def t_e2249232136730 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232136730 : ¬ IsSelfInterpreter e2249232136730 :=
  wSource (t := t_e2249232136730) (replay_sound (ps := []) (t := e2249232136730) (by decide)) (by decide)
def e2249232149018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232149018 : Closed e2249232149018 ∧ code e2249232149018 = 11045325171226 := by decide
private def t_e2249232149018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232149018 : ¬ IsSelfInterpreter e2249232149018 :=
  wSource (t := t_e2249232149018) (replay_sound (ps := []) (t := e2249232149018) (by decide)) (by decide)
def e2249232176666 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232176666 : Closed e2249232176666 ∧ code e2249232176666 = 11045325198874 := by decide
private def t_e2249232176666 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232176666 : ¬ IsSelfInterpreter e2249232176666 :=
  wSource (t := t_e2249232176666) (replay_sound (ps := []) (t := e2249232176666) (by decide)) (by decide)
def e2249232177690 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232177690 : Closed e2249232177690 ∧ code e2249232177690 = 11045325199898 := by decide
private def t_e2249232177690 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232177690 : ¬ IsSelfInterpreter e2249232177690 :=
  wSource (t := t_e2249232177690) (replay_sound (ps := []) (t := e2249232177690) (by decide)) (by decide)
def e2249232181786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232181786 : Closed e2249232181786 ∧ code e2249232181786 = 11045325203994 := by decide
private def t_e2249232181786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232181786 : ¬ IsSelfInterpreter e2249232181786 :=
  wSource (t := t_e2249232181786) (replay_sound (ps := []) (t := e2249232181786) (by decide)) (by decide)
def e2249232444954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232444954 : Closed e2249232444954 ∧ code e2249232444954 = 11045325467162 := by decide
private def t_e2249232444954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232444954 : ¬ IsSelfInterpreter e2249232444954 :=
  wSource (t := t_e2249232444954) (replay_sound (ps := []) (t := e2249232444954) (by decide)) (by decide)
def e2249232447002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232447002 : Closed e2249232447002 ∧ code e2249232447002 = 11045325469210 := by decide
private def t_e2249232447002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232447002 : ¬ IsSelfInterpreter e2249232447002 :=
  wSource (t := t_e2249232447002) (replay_sound (ps := []) (t := e2249232447002) (by decide)) (by decide)
def e2249232461338 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232461338 : Closed e2249232461338 ∧ code e2249232461338 = 11045325483546 := by decide
private def t_e2249232461338 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232461338 : ¬ IsSelfInterpreter e2249232461338 :=
  wSource (t := t_e2249232461338) (replay_sound (ps := []) (t := e2249232461338) (by decide)) (by decide)
def e2249232464410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232464410 : Closed e2249232464410 ∧ code e2249232464410 = 11045325486618 := by decide
private def t_e2249232464410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232464410 : ¬ IsSelfInterpreter e2249232464410 :=
  wSource (t := t_e2249232464410) (replay_sound (ps := []) (t := e2249232464410) (by decide)) (by decide)
def e2249232471578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232471578 : Closed e2249232471578 ∧ code e2249232471578 = 11045325493786 := by decide
private def t_e2249232471578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232471578 : ¬ IsSelfInterpreter e2249232471578 :=
  wSource (t := t_e2249232471578) (replay_sound (ps := []) (t := e2249232471578) (by decide)) (by decide)
def e2249232472602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232472602 : Closed e2249232472602 ∧ code e2249232472602 = 11045325494810 := by decide
private def t_e2249232472602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232472602 : ¬ IsSelfInterpreter e2249232472602 :=
  wSource (t := t_e2249232472602) (replay_sound (ps := []) (t := e2249232472602) (by decide)) (by decide)
def e2249232543258 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232543258 : Closed e2249232543258 ∧ code e2249232543258 = 11045325565466 := by decide
private def t_e2249232543258 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232543258 : ¬ IsSelfInterpreter e2249232543258 :=
  wSource (t := t_e2249232543258) (replay_sound (ps := []) (t := e2249232543258) (by decide)) (by decide)
def e2249232545306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232545306 : Closed e2249232545306 ∧ code e2249232545306 = 11045325567514 := by decide
private def t_e2249232545306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232545306 : ¬ IsSelfInterpreter e2249232545306 :=
  wSource (t := t_e2249232545306) (replay_sound (ps := []) (t := e2249232545306) (by decide)) (by decide)
def e2249232641562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232641562 : Closed e2249232641562 ∧ code e2249232641562 = 11045325663770 := by decide
private def t_e2249232641562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232641562 : ¬ IsSelfInterpreter e2249232641562 :=
  wSource (t := t_e2249232641562) (replay_sound (ps := []) (t := e2249232641562) (by decide)) (by decide)
def e2249232644634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232644634 : Closed e2249232644634 ∧ code e2249232644634 = 11045325666842 := by decide
private def t_e2249232644634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232644634 : ¬ IsSelfInterpreter e2249232644634 :=
  wSource (t := t_e2249232644634) (replay_sound (ps := []) (t := e2249232644634) (by decide)) (by decide)
def e2249232670746 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249232670746 : Closed e2249232670746 ∧ code e2249232670746 = 11045325692954 := by decide
theorem cert_e2249232670746 : check e2249232670746 [[]] .width = true := by decide
def e2249232670838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249232670838 : Closed e2249232670838 ∧ code e2249232670838 = 11045325693046 := by decide
private def t_e2249232670838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249232670838 : ¬ IsSelfInterpreter e2249232670838 :=
  wSource (t := t_e2249232670838) (replay_sound (ps := []) (t := e2249232670838) (by decide)) (by decide)
def e2249232671082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249232671082 : Closed e2249232671082 ∧ code e2249232671082 = 11045325693290 := by decide
private def t_e2249232671082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249232671082 : ¬ IsSelfInterpreter e2249232671082 :=
  wSource (t := t_e2249232671082) (replay_sound (ps := []) (t := e2249232671082) (by decide)) (by decide)
def e2249232671130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249232671130 : Closed e2249232671130 ∧ code e2249232671130 = 11045325693338 := by decide
private def t_e2249232671130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249232671130 : ¬ IsSelfInterpreter e2249232671130 :=
  wSource (t := t_e2249232671130) (replay_sound (ps := []) (t := e2249232671130) (by decide)) (by decide)
def e2249232692762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232692762 : Closed e2249232692762 ∧ code e2249232692762 = 11045325714970 := by decide
private def t_e2249232692762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232692762 : ¬ IsSelfInterpreter e2249232692762 :=
  wSource (t := t_e2249232692762) (replay_sound (ps := []) (t := e2249232692762) (by decide)) (by decide)
def e2249232693786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232693786 : Closed e2249232693786 ∧ code e2249232693786 = 11045325715994 := by decide
private def t_e2249232693786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232693786 : ¬ IsSelfInterpreter e2249232693786 :=
  wSource (t := t_e2249232693786) (replay_sound (ps := []) (t := e2249232693786) (by decide)) (by decide)
def e2249232703514 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249232703514 : Closed e2249232703514 ∧ code e2249232703514 = 11045325725722 := by decide
theorem cert_e2249232703514 : check e2249232703514 [[]] .width = true := by decide
def e2249232703606 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249232703606 : Closed e2249232703606 ∧ code e2249232703606 = 11045325725814 := by decide
private def t_e2249232703606 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249232703606 : ¬ IsSelfInterpreter e2249232703606 :=
  wSource (t := t_e2249232703606) (replay_sound (ps := []) (t := e2249232703606) (by decide)) (by decide)
def e2249232703850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249232703850 : Closed e2249232703850 ∧ code e2249232703850 = 11045325726058 := by decide
private def t_e2249232703850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249232703850 : ¬ IsSelfInterpreter e2249232703850 :=
  wSource (t := t_e2249232703850) (replay_sound (ps := []) (t := e2249232703850) (by decide)) (by decide)
def e2249232703898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249232703898 : Closed e2249232703898 ∧ code e2249232703898 = 11045325726106 := by decide
private def t_e2249232703898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249232703898 : ¬ IsSelfInterpreter e2249232703898 :=
  wSource (t := t_e2249232703898) (replay_sound (ps := []) (t := e2249232703898) (by decide)) (by decide)
def e2249232854554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232854554 : Closed e2249232854554 ∧ code e2249232854554 = 11045325876762 := by decide
private def t_e2249232854554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232854554 : ¬ IsSelfInterpreter e2249232854554 :=
  wSource (t := t_e2249232854554) (replay_sound (ps := []) (t := e2249232854554) (by decide)) (by decide)
def e2249232857626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232857626 : Closed e2249232857626 ∧ code e2249232857626 = 11045325879834 := by decide
private def t_e2249232857626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232857626 : ¬ IsSelfInterpreter e2249232857626 :=
  wSource (t := t_e2249232857626) (replay_sound (ps := []) (t := e2249232857626) (by decide)) (by decide)
def e2249232869914 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232869914 : Closed e2249232869914 ∧ code e2249232869914 = 11045325892122 := by decide
private def t_e2249232869914 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232869914 : ¬ IsSelfInterpreter e2249232869914 :=
  wSource (t := t_e2249232869914) (replay_sound (ps := []) (t := e2249232869914) (by decide)) (by decide)
def e2249232903706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232903706 : Closed e2249232903706 ∧ code e2249232903706 = 11045325925914 := by decide
private def t_e2249232903706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232903706 : ¬ IsSelfInterpreter e2249232903706 :=
  wSource (t := t_e2249232903706) (replay_sound (ps := []) (t := e2249232903706) (by decide)) (by decide)
def e2249232906778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232906778 : Closed e2249232906778 ∧ code e2249232906778 = 11045325928986 := by decide
private def t_e2249232906778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232906778 : ¬ IsSelfInterpreter e2249232906778 :=
  wSource (t := t_e2249232906778) (replay_sound (ps := []) (t := e2249232906778) (by decide)) (by decide)
def e2249232932890 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249232932890 : Closed e2249232932890 ∧ code e2249232932890 = 11045325955098 := by decide
theorem cert_e2249232932890 : check e2249232932890 [[]] .width = true := by decide
def e2249232932982 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249232932982 : Closed e2249232932982 ∧ code e2249232932982 = 11045325955190 := by decide
private def t_e2249232932982 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249232932982 : ¬ IsSelfInterpreter e2249232932982 :=
  wSource (t := t_e2249232932982) (replay_sound (ps := []) (t := e2249232932982) (by decide)) (by decide)
def e2249232933226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249232933226 : Closed e2249232933226 ∧ code e2249232933226 = 11045325955434 := by decide
private def t_e2249232933226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249232933226 : ¬ IsSelfInterpreter e2249232933226 :=
  wSource (t := t_e2249232933226) (replay_sound (ps := []) (t := e2249232933226) (by decide)) (by decide)
def e2249232933274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249232933274 : Closed e2249232933274 ∧ code e2249232933274 = 11045325955482 := by decide
private def t_e2249232933274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249232933274 : ¬ IsSelfInterpreter e2249232933274 :=
  wSource (t := t_e2249232933274) (replay_sound (ps := []) (t := e2249232933274) (by decide)) (by decide)
def e2249232980506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249232980506 : Closed e2249232980506 ∧ code e2249232980506 = 11045326002714 := by decide
private def t_e2249232980506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249232980506 : ¬ IsSelfInterpreter e2249232980506 :=
  wSource (t := t_e2249232980506) (replay_sound (ps := []) (t := e2249232980506) (by decide)) (by decide)
def e2249232982042 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249232982042 : Closed e2249232982042 ∧ code e2249232982042 = 11045326004250 := by decide
theorem cert_e2249232982042 : check e2249232982042 [[]] .width = true := by decide
def e2249232982134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249232982134 : Closed e2249232982134 ∧ code e2249232982134 = 11045326004342 := by decide
private def t_e2249232982134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249232982134 : ¬ IsSelfInterpreter e2249232982134 :=
  wSource (t := t_e2249232982134) (replay_sound (ps := []) (t := e2249232982134) (by decide)) (by decide)
def e2249232982378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249232982378 : Closed e2249232982378 ∧ code e2249232982378 = 11045326004586 := by decide
private def t_e2249232982378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249232982378 : ¬ IsSelfInterpreter e2249232982378 :=
  wSource (t := t_e2249232982378) (replay_sound (ps := []) (t := e2249232982378) (by decide)) (by decide)
def e2249232982426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249232982426 : Closed e2249232982426 ∧ code e2249232982426 = 11045326004634 := by decide
private def t_e2249232982426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249232982426 : ¬ IsSelfInterpreter e2249232982426 :=
  wSource (t := t_e2249232982426) (replay_sound (ps := []) (t := e2249232982426) (by decide)) (by decide)
def e2249233061402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233061402 : Closed e2249233061402 ∧ code e2249233061402 = 11045326083610 := by decide
private def t_e2249233061402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233061402 : ¬ IsSelfInterpreter e2249233061402 :=
  wSource (t := t_e2249233061402) (replay_sound (ps := []) (t := e2249233061402) (by decide)) (by decide)
def e2249233062426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233062426 : Closed e2249233062426 ∧ code e2249233062426 = 11045326084634 := by decide
private def t_e2249233062426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233062426 : ¬ IsSelfInterpreter e2249233062426 :=
  wSource (t := t_e2249233062426) (replay_sound (ps := []) (t := e2249233062426) (by decide)) (by decide)
def e2249233066522 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233066522 : Closed e2249233066522 ∧ code e2249233066522 = 11045326088730 := by decide
private def t_e2249233066522 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233066522 : ¬ IsSelfInterpreter e2249233066522 :=
  wSource (t := t_e2249233066522) (replay_sound (ps := []) (t := e2249233066522) (by decide)) (by decide)
def e2249233085978 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233085978 : Closed e2249233085978 ∧ code e2249233085978 = 11045326108186 := by decide
private def t_e2249233085978 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233085978 : ¬ IsSelfInterpreter e2249233085978 :=
  wSource (t := t_e2249233085978) (replay_sound (ps := []) (t := e2249233085978) (by decide)) (by decide)
def e2249233087002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233087002 : Closed e2249233087002 ∧ code e2249233087002 = 11045326109210 := by decide
private def t_e2249233087002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233087002 : ¬ IsSelfInterpreter e2249233087002 :=
  wSource (t := t_e2249233087002) (replay_sound (ps := []) (t := e2249233087002) (by decide)) (by decide)
def e2249233096730 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249233096730 : Closed e2249233096730 ∧ code e2249233096730 = 11045326118938 := by decide
theorem cert_e2249233096730 : check e2249233096730 [[]] .width = true := by decide
def e2249233096822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249233096822 : Closed e2249233096822 ∧ code e2249233096822 = 11045326119030 := by decide
private def t_e2249233096822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249233096822 : ¬ IsSelfInterpreter e2249233096822 :=
  wSource (t := t_e2249233096822) (replay_sound (ps := []) (t := e2249233096822) (by decide)) (by decide)
def e2249233097066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249233097066 : Closed e2249233097066 ∧ code e2249233097066 = 11045326119274 := by decide
private def t_e2249233097066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249233097066 : ¬ IsSelfInterpreter e2249233097066 :=
  wSource (t := t_e2249233097066) (replay_sound (ps := []) (t := e2249233097066) (by decide)) (by decide)
def e2249233097114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249233097114 : Closed e2249233097114 ∧ code e2249233097114 = 11045326119322 := by decide
private def t_e2249233097114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249233097114 : ¬ IsSelfInterpreter e2249233097114 :=
  wSource (t := t_e2249233097114) (replay_sound (ps := []) (t := e2249233097114) (by decide)) (by decide)
def e2249233111578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233111578 : Closed e2249233111578 ∧ code e2249233111578 = 11045326133786 := by decide
private def t_e2249233111578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233111578 : ¬ IsSelfInterpreter e2249233111578 :=
  wSource (t := t_e2249233111578) (replay_sound (ps := []) (t := e2249233111578) (by decide)) (by decide)
def e2249233113114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249233113114 : Closed e2249233113114 ∧ code e2249233113114 = 11045326135322 := by decide
theorem cert_e2249233113114 : check e2249233113114 [[]] .width = true := by decide
def e2249233113206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249233113206 : Closed e2249233113206 ∧ code e2249233113206 = 11045326135414 := by decide
private def t_e2249233113206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249233113206 : ¬ IsSelfInterpreter e2249233113206 :=
  wSource (t := t_e2249233113206) (replay_sound (ps := []) (t := e2249233113206) (by decide)) (by decide)
def e2249233113450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249233113450 : Closed e2249233113450 ∧ code e2249233113450 = 11045326135658 := by decide
private def t_e2249233113450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249233113450 : ¬ IsSelfInterpreter e2249233113450 :=
  wSource (t := t_e2249233113450) (replay_sound (ps := []) (t := e2249233113450) (by decide)) (by decide)
def e2249233113498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249233113498 : Closed e2249233113498 ∧ code e2249233113498 = 11045326135706 := by decide
private def t_e2249233113498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249233113498 : ¬ IsSelfInterpreter e2249233113498 :=
  wSource (t := t_e2249233113498) (replay_sound (ps := []) (t := e2249233113498) (by decide)) (by decide)
def e2249233522202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233522202 : Closed e2249233522202 ∧ code e2249233522202 = 11045326544410 := by decide
private def t_e2249233522202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233522202 : ¬ IsSelfInterpreter e2249233522202 :=
  wSource (t := t_e2249233522202) (replay_sound (ps := []) (t := e2249233522202) (by decide)) (by decide)
def e2249233526298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249233526298 : Closed e2249233526298 ∧ code e2249233526298 = 11045326548506 := by decide
private def t_e2249233526298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249233526298 : ¬ IsSelfInterpreter e2249233526298 :=
  wSource (t := t_e2249233526298) (replay_sound (ps := []) (t := e2249233526298) (by decide)) (by decide)
def e2249234017818 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234017818 : Closed e2249234017818 ∧ code e2249234017818 = 11045327040026 := by decide
private def t_e2249234017818 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234017818 : ¬ IsSelfInterpreter e2249234017818 :=
  wSource (t := t_e2249234017818) (replay_sound (ps := []) (t := e2249234017818) (by decide)) (by decide)
def e2249234019866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234019866 : Closed e2249234019866 ∧ code e2249234019866 = 11045327042074 := by decide
private def t_e2249234019866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234019866 : ¬ IsSelfInterpreter e2249234019866 :=
  wSource (t := t_e2249234019866) (replay_sound (ps := []) (t := e2249234019866) (by decide)) (by decide)
def e2249234034202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234034202 : Closed e2249234034202 ∧ code e2249234034202 = 11045327056410 := by decide
private def t_e2249234034202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234034202 : ¬ IsSelfInterpreter e2249234034202 :=
  wSource (t := t_e2249234034202) (replay_sound (ps := []) (t := e2249234034202) (by decide)) (by decide)
def e2249234037274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234037274 : Closed e2249234037274 ∧ code e2249234037274 = 11045327059482 := by decide
private def t_e2249234037274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234037274 : ¬ IsSelfInterpreter e2249234037274 :=
  wSource (t := t_e2249234037274) (replay_sound (ps := []) (t := e2249234037274) (by decide)) (by decide)
def e2249234044442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234044442 : Closed e2249234044442 ∧ code e2249234044442 = 11045327066650 := by decide
private def t_e2249234044442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234044442 : ¬ IsSelfInterpreter e2249234044442 :=
  wSource (t := t_e2249234044442) (replay_sound (ps := []) (t := e2249234044442) (by decide)) (by decide)
def e2249234045466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234045466 : Closed e2249234045466 ∧ code e2249234045466 = 11045327067674 := by decide
private def t_e2249234045466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234045466 : ¬ IsSelfInterpreter e2249234045466 :=
  wSource (t := t_e2249234045466) (replay_sound (ps := []) (t := e2249234045466) (by decide)) (by decide)
def e2249234116122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234116122 : Closed e2249234116122 ∧ code e2249234116122 = 11045327138330 := by decide
private def t_e2249234116122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234116122 : ¬ IsSelfInterpreter e2249234116122 :=
  wSource (t := t_e2249234116122) (replay_sound (ps := []) (t := e2249234116122) (by decide)) (by decide)
def e2249234118170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234118170 : Closed e2249234118170 ∧ code e2249234118170 = 11045327140378 := by decide
private def t_e2249234118170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234118170 : ¬ IsSelfInterpreter e2249234118170 :=
  wSource (t := t_e2249234118170) (replay_sound (ps := []) (t := e2249234118170) (by decide)) (by decide)
def e2249234214426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234214426 : Closed e2249234214426 ∧ code e2249234214426 = 11045327236634 := by decide
private def t_e2249234214426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234214426 : ¬ IsSelfInterpreter e2249234214426 :=
  wSource (t := t_e2249234214426) (replay_sound (ps := []) (t := e2249234214426) (by decide)) (by decide)
def e2249234217498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234217498 : Closed e2249234217498 ∧ code e2249234217498 = 11045327239706 := by decide
private def t_e2249234217498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234217498 : ¬ IsSelfInterpreter e2249234217498 :=
  wSource (t := t_e2249234217498) (replay_sound (ps := []) (t := e2249234217498) (by decide)) (by decide)
def e2249234243610 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249234243610 : Closed e2249234243610 ∧ code e2249234243610 = 11045327265818 := by decide
theorem cert_e2249234243610 : check e2249234243610 [[]] .width = true := by decide
def e2249234243702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249234243702 : Closed e2249234243702 ∧ code e2249234243702 = 11045327265910 := by decide
private def t_e2249234243702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249234243702 : ¬ IsSelfInterpreter e2249234243702 :=
  wSource (t := t_e2249234243702) (replay_sound (ps := []) (t := e2249234243702) (by decide)) (by decide)
def e2249234243946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249234243946 : Closed e2249234243946 ∧ code e2249234243946 = 11045327266154 := by decide
private def t_e2249234243946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249234243946 : ¬ IsSelfInterpreter e2249234243946 :=
  wSource (t := t_e2249234243946) (replay_sound (ps := []) (t := e2249234243946) (by decide)) (by decide)
def e2249234243994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249234243994 : Closed e2249234243994 ∧ code e2249234243994 = 11045327266202 := by decide
private def t_e2249234243994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249234243994 : ¬ IsSelfInterpreter e2249234243994 :=
  wSource (t := t_e2249234243994) (replay_sound (ps := []) (t := e2249234243994) (by decide)) (by decide)
def e2249234265626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234265626 : Closed e2249234265626 ∧ code e2249234265626 = 11045327287834 := by decide
private def t_e2249234265626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234265626 : ¬ IsSelfInterpreter e2249234265626 :=
  wSource (t := t_e2249234265626) (replay_sound (ps := []) (t := e2249234265626) (by decide)) (by decide)
def e2249234266650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249234266650 : Closed e2249234266650 ∧ code e2249234266650 = 11045327288858 := by decide
private def t_e2249234266650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249234266650 : ¬ IsSelfInterpreter e2249234266650 :=
  wSource (t := t_e2249234266650) (replay_sound (ps := []) (t := e2249234266650) (by decide)) (by decide)
def e2249234276378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249234276378 : Closed e2249234276378 ∧ code e2249234276378 = 11045327298586 := by decide
theorem cert_e2249234276378 : check e2249234276378 [[]] .width = true := by decide
def e2249234276470 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249234276470 : Closed e2249234276470 ∧ code e2249234276470 = 11045327298678 := by decide
private def t_e2249234276470 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249234276470 : ¬ IsSelfInterpreter e2249234276470 :=
  wSource (t := t_e2249234276470) (replay_sound (ps := []) (t := e2249234276470) (by decide)) (by decide)
def e2249234276714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249234276714 : Closed e2249234276714 ∧ code e2249234276714 = 11045327298922 := by decide
private def t_e2249234276714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249234276714 : ¬ IsSelfInterpreter e2249234276714 :=
  wSource (t := t_e2249234276714) (replay_sound (ps := []) (t := e2249234276714) (by decide)) (by decide)
def e2249234276762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249234276762 : Closed e2249234276762 ∧ code e2249234276762 = 11045327298970 := by decide
private def t_e2249234276762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249234276762 : ¬ IsSelfInterpreter e2249234276762 :=
  wSource (t := t_e2249234276762) (replay_sound (ps := []) (t := e2249234276762) (by decide)) (by decide)
def e2249235488282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235488282 : Closed e2249235488282 ∧ code e2249235488282 = 11045328510490 := by decide
private def t_e2249235488282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235488282 : ¬ IsSelfInterpreter e2249235488282 :=
  wSource (t := t_e2249235488282) (replay_sound (ps := []) (t := e2249235488282) (by decide)) (by decide)
def e2249235494426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235494426 : Closed e2249235494426 ∧ code e2249235494426 = 11045328516634 := by decide
private def t_e2249235494426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235494426 : ¬ IsSelfInterpreter e2249235494426 :=
  wSource (t := t_e2249235494426) (replay_sound (ps := []) (t := e2249235494426) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2249223691802
#print axioms Blc.Floor43.cert_e2249223695898
#print axioms Blc.Floor43.cert_e2249223790106
#print axioms Blc.Floor43.cert_e2249223797274
#print axioms Blc.Floor43.cert_e2249223810586
#print axioms Blc.Floor43.cert_e2249223813658
#print axioms Blc.Floor43.cert_e2249224085018
#print axioms Blc.Floor43.cert_e2249224089114
#print axioms Blc.Floor43.cert_e2249224674842
#print axioms Blc.Floor43.cert_e2249224682010
#print axioms Blc.Floor43.cert_e2249224777242
#print axioms Blc.Floor43.cert_e2249224780314
#print axioms Blc.Floor43.cert_e2249232051738
#print axioms Blc.Floor43.cert_e2249232053786
#print axioms Blc.Floor43.cert_e2249232068122
#print axioms Blc.Floor43.cert_e2249232071194
#print axioms Blc.Floor43.cert_e2249232078362
#print axioms Blc.Floor43.cert_e2249232079386
#print axioms Blc.Floor43.cert_e2249232133658
#print axioms Blc.Floor43.cert_e2249232136730
#print axioms Blc.Floor43.cert_e2249232149018
#print axioms Blc.Floor43.cert_e2249232176666
#print axioms Blc.Floor43.cert_e2249232177690
#print axioms Blc.Floor43.cert_e2249232181786
#print axioms Blc.Floor43.cert_e2249232444954
#print axioms Blc.Floor43.cert_e2249232447002
#print axioms Blc.Floor43.cert_e2249232461338
#print axioms Blc.Floor43.cert_e2249232464410
#print axioms Blc.Floor43.cert_e2249232471578
#print axioms Blc.Floor43.cert_e2249232472602
#print axioms Blc.Floor43.cert_e2249232543258
#print axioms Blc.Floor43.cert_e2249232545306
#print axioms Blc.Floor43.cert_e2249232641562
#print axioms Blc.Floor43.cert_e2249232644634
#print axioms Blc.Floor43.cert_e2249232670838
#print axioms Blc.Floor43.cert_e2249232671082
#print axioms Blc.Floor43.cert_e2249232671130
#print axioms Blc.Floor43.cert_e2249232692762
#print axioms Blc.Floor43.cert_e2249232693786
#print axioms Blc.Floor43.cert_e2249232703606
#print axioms Blc.Floor43.cert_e2249232703850
#print axioms Blc.Floor43.cert_e2249232703898
#print axioms Blc.Floor43.cert_e2249232854554
#print axioms Blc.Floor43.cert_e2249232857626
#print axioms Blc.Floor43.cert_e2249232869914
#print axioms Blc.Floor43.cert_e2249232903706
#print axioms Blc.Floor43.cert_e2249232906778
#print axioms Blc.Floor43.cert_e2249232932982
#print axioms Blc.Floor43.cert_e2249232933226
#print axioms Blc.Floor43.cert_e2249232933274
#print axioms Blc.Floor43.cert_e2249232980506
#print axioms Blc.Floor43.cert_e2249232982134
#print axioms Blc.Floor43.cert_e2249232982378
#print axioms Blc.Floor43.cert_e2249232982426
#print axioms Blc.Floor43.cert_e2249233061402
#print axioms Blc.Floor43.cert_e2249233062426
#print axioms Blc.Floor43.cert_e2249233066522
#print axioms Blc.Floor43.cert_e2249233085978
#print axioms Blc.Floor43.cert_e2249233087002
#print axioms Blc.Floor43.cert_e2249233096822
#print axioms Blc.Floor43.cert_e2249233097066
#print axioms Blc.Floor43.cert_e2249233097114
#print axioms Blc.Floor43.cert_e2249233111578
#print axioms Blc.Floor43.cert_e2249233113206
#print axioms Blc.Floor43.cert_e2249233113450
#print axioms Blc.Floor43.cert_e2249233113498
#print axioms Blc.Floor43.cert_e2249233522202
#print axioms Blc.Floor43.cert_e2249233526298
#print axioms Blc.Floor43.cert_e2249234017818
#print axioms Blc.Floor43.cert_e2249234019866
#print axioms Blc.Floor43.cert_e2249234034202
#print axioms Blc.Floor43.cert_e2249234037274
#print axioms Blc.Floor43.cert_e2249234044442
#print axioms Blc.Floor43.cert_e2249234045466
#print axioms Blc.Floor43.cert_e2249234116122
#print axioms Blc.Floor43.cert_e2249234118170
#print axioms Blc.Floor43.cert_e2249234214426
#print axioms Blc.Floor43.cert_e2249234217498
#print axioms Blc.Floor43.cert_e2249234243702
#print axioms Blc.Floor43.cert_e2249234243946
#print axioms Blc.Floor43.cert_e2249234243994
#print axioms Blc.Floor43.cert_e2249234265626
#print axioms Blc.Floor43.cert_e2249234266650
#print axioms Blc.Floor43.cert_e2249234276470
#print axioms Blc.Floor43.cert_e2249234276714
#print axioms Blc.Floor43.cert_e2249234276762
#print axioms Blc.Floor43.cert_e2249235488282
#print axioms Blc.Floor43.cert_e2249235494426
