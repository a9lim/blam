import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418112583194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112583194 : Closed e2418112583194 ∧ code e2418112583194 = 11214205605402 := by decide
private def t_e2418112583194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112583194 : ¬ IsSelfInterpreter e2418112583194 :=
  wSource (t := t_e2418112583194) (replay_sound (ps := []) (t := e2418112583194) (by decide)) (by decide)
def e2418112584218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112584218 : Closed e2418112584218 ∧ code e2418112584218 = 11214205606426 := by decide
private def t_e2418112584218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112584218 : ¬ IsSelfInterpreter e2418112584218 :=
  wSource (t := t_e2418112584218) (replay_sound (ps := []) (t := e2418112584218) (by decide)) (by decide)
def e2418112851482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112851482 : Closed e2418112851482 ∧ code e2418112851482 = 11214205873690 := by decide
theorem cert_e2418112851482 : check e2418112851482 [[]] .width = true := by decide
def e2418112853530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112853530 : Closed e2418112853530 ∧ code e2418112853530 = 11214205875738 := by decide
theorem cert_e2418112853530 : check e2418112853530 [[]] .width = true := by decide
def e2418113048090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113048090 : Closed e2418113048090 ∧ code e2418113048090 = 11214206070298 := by decide
theorem cert_e2418113048090 : check e2418113048090 [[]] .width = true := by decide
def e2418113050138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113050138 : Closed e2418113050138 ∧ code e2418113050138 = 11214206072346 := by decide
theorem cert_e2418113050138 : check e2418113050138 [[]] .width = true := by decide
def e2418113191450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113191450 : Closed e2418113191450 ∧ code e2418113191450 = 11214206213658 := by decide
theorem cert_e2418113191450 : check e2418113191450 [[]] .width = true := by decide
def e2418113212614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418113212614 : Closed e2418113212614 ∧ code e2418113212614 = 11214206234822 := by decide
theorem cert_e2418113212614 : check e2418113212614 [[]] .width = true := by decide
def e2418113220122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113220122 : Closed e2418113220122 ∧ code e2418113220122 = 11214206242330 := by decide
theorem cert_e2418113220122 : check e2418113220122 [[]] .width = true := by decide
def e2418113228998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418113228998 : Closed e2418113228998 ∧ code e2418113228998 = 11214206251206 := by decide
theorem cert_e2418113228998 : check e2418113228998 [[]] .width = true := by decide
def e2418113624090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418113624090 : Closed e2418113624090 ∧ code e2418113624090 = 11214206646298 := by decide
theorem cert_e2418113624090 : check e2418113624090 [[]] .width = true := by decide
def e2418113632282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418113632282 : Closed e2418113632282 ∧ code e2418113632282 = 11214206654490 := by decide
theorem cert_e2418113632282 : check e2418113632282 [[]] .width = true := by decide
def e2418113654298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113654298 : Closed e2418113654298 ∧ code e2418113654298 = 11214206676506 := by decide
theorem cert_e2418113654298 : check e2418113654298 [[]] .width = true := by decide
def e2418113689626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418113689626 : Closed e2418113689626 ∧ code e2418113689626 = 11214206711834 := by decide
theorem cert_e2418113689626 : check e2418113689626 [[]] .width = true := by decide
def e2418113700378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113700378 : Closed e2418113700378 ∧ code e2418113700378 = 11214206722586 := by decide
theorem cert_e2418113700378 : check e2418113700378 [[]] .width = true := by decide
def e2418113701914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418113701914 : Closed e2418113701914 ∧ code e2418113701914 = 11214206724122 := by decide
theorem cert_e2418113701914 : check e2418113701914 [[]] .width = true := by decide
def e2418113703450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113703450 : Closed e2418113703450 ∧ code e2418113703450 = 11214206725658 := by decide
theorem cert_e2418113703450 : check e2418113703450 [[]] .width = true := by decide
def e2418113713690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113713690 : Closed e2418113713690 ∧ code e2418113713690 = 11214206735898 := by decide
theorem cert_e2418113713690 : check e2418113713690 [[]] .width = true := by decide
def e2418113730586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418113730586 : Closed e2418113730586 ∧ code e2418113730586 = 11214206752794 := by decide
theorem cert_e2418113730586 : check e2418113730586 [[]] .width = true := by decide
def e2418113733146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113733146 : Closed e2418113733146 ∧ code e2418113733146 = 11214206755354 := by decide
theorem cert_e2418113733146 : check e2418113733146 [[]] .width = true := by decide
def e2418113734682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418113734682 : Closed e2418113734682 ∧ code e2418113734682 = 11214206756890 := by decide
theorem cert_e2418113734682 : check e2418113734682 [[]] .width = true := by decide
def e2418113736218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113736218 : Closed e2418113736218 ∧ code e2418113736218 = 11214206758426 := by decide
theorem cert_e2418113736218 : check e2418113736218 [[]] .width = true := by decide
def e2418113738266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418113738266 : Closed e2418113738266 ∧ code e2418113738266 = 11214206760474 := by decide
theorem cert_e2418113738266 : check e2418113738266 [[]] .width = true := by decide
def e2418114017306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418114017306 : Closed e2418114017306 ∧ code e2418114017306 = 11214207039514 := by decide
theorem cert_e2418114017306 : check e2418114017306 [[]] .width = true := by decide
def e2418114025498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418114025498 : Closed e2418114025498 ∧ code e2418114025498 = 11214207047706 := by decide
theorem cert_e2418114025498 : check e2418114025498 [[]] .width = true := by decide
def e2418114313754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114313754 : Closed e2418114313754 ∧ code e2418114313754 = 11214207335962 := by decide
theorem cert_e2418114313754 : check e2418114313754 [[]] .width = true := by decide
def e2418114359494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418114359494 : Closed e2418114359494 ∧ code e2418114359494 = 11214207381702 := by decide
theorem cert_e2418114359494 : check e2418114359494 [[]] .width = true := by decide
def e2418114410522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418114410522 : Closed e2418114410522 ∧ code e2418114410522 = 11214207432730 := by decide
theorem cert_e2418114410522 : check e2418114410522 [[]] .width = true := by decide
def e2418114421274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114421274 : Closed e2418114421274 ∧ code e2418114421274 = 11214207443482 := by decide
theorem cert_e2418114421274 : check e2418114421274 [[]] .width = true := by decide
def e2418114422810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418114422810 : Closed e2418114422810 ∧ code e2418114422810 = 11214207445018 := by decide
theorem cert_e2418114422810 : check e2418114422810 [[]] .width = true := by decide
def e2418114424346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114424346 : Closed e2418114424346 ∧ code e2418114424346 = 11214207446554 := by decide
theorem cert_e2418114424346 : check e2418114424346 [[]] .width = true := by decide
def e2418114527258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418114527258 : Closed e2418114527258 ∧ code e2418114527258 = 11214207549466 := by decide
theorem cert_e2418114527258 : check e2418114527258 [[]] .width = true := by decide
def e2418114527350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418114527350 : Closed e2418114527350 ∧ code e2418114527350 = 11214207549558 := by decide
theorem cert_e2418114527350 : check e2418114527350 [[]] .width = true := by decide
def e2418114527594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418114527594 : Closed e2418114527594 ∧ code e2418114527594 = 11214207549802 := by decide
theorem cert_e2418114527594 : check e2418114527594 [[]] .width = true := by decide
def e2418114527642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418114527642 : Closed e2418114527642 ∧ code e2418114527642 = 11214207549850 := by decide
theorem cert_e2418114527642 : check e2418114527642 [[]] .width = true := by decide
def e2418114528650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418114528650 : Closed e2418114528650 ∧ code e2418114528650 = 11214207550858 := by decide
theorem cert_e2418114528650 : check e2418114528650 [[]] .width = true := by decide
def e2418114528674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418114528674 : Closed e2418114528674 ∧ code e2418114528674 = 11214207550882 := by decide
theorem cert_e2418114528674 : check e2418114528674 [[]] .width = true := by decide
def e2418114528782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418114528782 : Closed e2418114528782 ∧ code e2418114528782 = 11214207550990 := by decide
theorem cert_e2418114528782 : check e2418114528782 [[]] .width = true := by decide
def e2418114528794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418114528794 : Closed e2418114528794 ∧ code e2418114528794 = 11214207551002 := by decide
theorem cert_e2418114528794 : check e2418114528794 [[]] .width = true := by decide
def e2418114528866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418114528866 : Closed e2418114528866 ∧ code e2418114528866 = 11214207551074 := by decide
theorem cert_e2418114528866 : check e2418114528866 [[]] .width = true := by decide
def e2418114567706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114567706 : Closed e2418114567706 ∧ code e2418114567706 = 11214207589914 := by decide
theorem cert_e2418114567706 : check e2418114567706 [[]] .width = true := by decide
def e2418114588870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418114588870 : Closed e2418114588870 ∧ code e2418114588870 = 11214207611078 := by decide
theorem cert_e2418114588870 : check e2418114588870 [[]] .width = true := by decide
def e2418114615322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418114615322 : Closed e2418114615322 ∧ code e2418114615322 = 11214207637530 := by decide
theorem cert_e2418114615322 : check e2418114615322 [[]] .width = true := by decide
def e2418114617882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114617882 : Closed e2418114617882 ∧ code e2418114617882 = 11214207640090 := by decide
theorem cert_e2418114617882 : check e2418114617882 [[]] .width = true := by decide
def e2418114619418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418114619418 : Closed e2418114619418 ∧ code e2418114619418 = 11214207641626 := by decide
theorem cert_e2418114619418 : check e2418114619418 [[]] .width = true := by decide
def e2418114620954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114620954 : Closed e2418114620954 ∧ code e2418114620954 = 11214207643162 := by decide
theorem cert_e2418114620954 : check e2418114620954 [[]] .width = true := by decide
def e2418114623002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114623002 : Closed e2418114623002 ∧ code e2418114623002 = 11214207645210 := by decide
theorem cert_e2418114623002 : check e2418114623002 [[]] .width = true := by decide
def e2418114658330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418114658330 : Closed e2418114658330 ∧ code e2418114658330 = 11214207680538 := by decide
theorem cert_e2418114658330 : check e2418114658330 [[]] .width = true := by decide
def e2418114658422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418114658422 : Closed e2418114658422 ∧ code e2418114658422 = 11214207680630 := by decide
theorem cert_e2418114658422 : check e2418114658422 [[]] .width = true := by decide
def e2418114658666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418114658666 : Closed e2418114658666 ∧ code e2418114658666 = 11214207680874 := by decide
theorem cert_e2418114658666 : check e2418114658666 [[]] .width = true := by decide
def e2418114658714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418114658714 : Closed e2418114658714 ∧ code e2418114658714 = 11214207680922 := by decide
theorem cert_e2418114658714 : check e2418114658714 [[]] .width = true := by decide
def e2418114659722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418114659722 : Closed e2418114659722 ∧ code e2418114659722 = 11214207681930 := by decide
theorem cert_e2418114659722 : check e2418114659722 [[]] .width = true := by decide
def e2418114659746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418114659746 : Closed e2418114659746 ∧ code e2418114659746 = 11214207681954 := by decide
theorem cert_e2418114659746 : check e2418114659746 [[]] .width = true := by decide
def e2418114659854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418114659854 : Closed e2418114659854 ∧ code e2418114659854 = 11214207682062 := by decide
theorem cert_e2418114659854 : check e2418114659854 [[]] .width = true := by decide
def e2418114659866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418114659866 : Closed e2418114659866 ∧ code e2418114659866 = 11214207682074 := by decide
theorem cert_e2418114659866 : check e2418114659866 [[]] .width = true := by decide
def e2418114659938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418114659938 : Closed e2418114659938 ∧ code e2418114659938 = 11214207682146 := by decide
theorem cert_e2418114659938 : check e2418114659938 [[]] .width = true := by decide
def e2418114883098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114883098 : Closed e2418114883098 ∧ code e2418114883098 = 11214207905306 := by decide
theorem cert_e2418114883098 : check e2418114883098 [[]] .width = true := by decide
def e2418114886170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114886170 : Closed e2418114886170 ∧ code e2418114886170 = 11214207908378 := by decide
theorem cert_e2418114886170 : check e2418114886170 [[]] .width = true := by decide
def e2418114981402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114981402 : Closed e2418114981402 ∧ code e2418114981402 = 11214208003610 := by decide
theorem cert_e2418114981402 : check e2418114981402 [[]] .width = true := by decide
def e2418114984474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418114984474 : Closed e2418114984474 ∧ code e2418114984474 = 11214208006682 := by decide
theorem cert_e2418114984474 : check e2418114984474 [[]] .width = true := by decide
def e2418115026458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115026458 : Closed e2418115026458 ∧ code e2418115026458 = 11214208048666 := by decide
theorem cert_e2418115026458 : check e2418115026458 [[]] .width = true := by decide
def e2418115047622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418115047622 : Closed e2418115047622 ∧ code e2418115047622 = 11214208069830 := by decide
theorem cert_e2418115047622 : check e2418115047622 [[]] .width = true := by decide
def e2418115069466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115069466 : Closed e2418115069466 ∧ code e2418115069466 = 11214208091674 := by decide
theorem cert_e2418115069466 : check e2418115069466 [[]] .width = true := by decide
def e2418115072198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418115072198 : Closed e2418115072198 ∧ code e2418115072198 = 11214208094406 := by decide
theorem cert_e2418115072198 : check e2418115072198 [[]] .width = true := by decide
def e2418115227162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115227162 : Closed e2418115227162 ∧ code e2418115227162 = 11214208249370 := by decide
theorem cert_e2418115227162 : check e2418115227162 [[]] .width = true := by decide
def e2418115262490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418115262490 : Closed e2418115262490 ∧ code e2418115262490 = 11214208284698 := by decide
theorem cert_e2418115262490 : check e2418115262490 [[]] .width = true := by decide
def e2418115273242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115273242 : Closed e2418115273242 ∧ code e2418115273242 = 11214208295450 := by decide
theorem cert_e2418115273242 : check e2418115273242 [[]] .width = true := by decide
def e2418115274778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418115274778 : Closed e2418115274778 ∧ code e2418115274778 = 11214208296986 := by decide
theorem cert_e2418115274778 : check e2418115274778 [[]] .width = true := by decide
def e2418115276314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115276314 : Closed e2418115276314 ∧ code e2418115276314 = 11214208298522 := by decide
theorem cert_e2418115276314 : check e2418115276314 [[]] .width = true := by decide
def e2418115316250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115316250 : Closed e2418115316250 ∧ code e2418115316250 = 11214208338458 := by decide
theorem cert_e2418115316250 : check e2418115316250 [[]] .width = true := by decide
def e2418115322394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115322394 : Closed e2418115322394 ∧ code e2418115322394 = 11214208344602 := by decide
theorem cert_e2418115322394 : check e2418115322394 [[]] .width = true := by decide
def e2418115323930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418115323930 : Closed e2418115323930 ∧ code e2418115323930 = 11214208346138 := by decide
theorem cert_e2418115323930 : check e2418115323930 [[]] .width = true := by decide
def e2418115325466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115325466 : Closed e2418115325466 ∧ code e2418115325466 = 11214208347674 := by decide
theorem cert_e2418115325466 : check e2418115325466 [[]] .width = true := by decide
def e2418115328538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115328538 : Closed e2418115328538 ∧ code e2418115328538 = 11214208350746 := by decide
private def t_e2418115328538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418115328538 : ¬ IsSelfInterpreter e2418115328538 :=
  wSource (t := t_e2418115328538) (replay_sound (ps := []) (t := e2418115328538) (by decide)) (by decide)
def e2418115362330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115362330 : Closed e2418115362330 ∧ code e2418115362330 = 11214208384538 := by decide
theorem cert_e2418115362330 : check e2418115362330 [[]] .width = true := by decide
def e2418115408070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418115408070 : Closed e2418115408070 ∧ code e2418115408070 = 11214208430278 := by decide
theorem cert_e2418115408070 : check e2418115408070 [[]] .width = true := by decide
def e2418115459098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418115459098 : Closed e2418115459098 ∧ code e2418115459098 = 11214208481306 := by decide
theorem cert_e2418115459098 : check e2418115459098 [[]] .width = true := by decide
def e2418115469850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115469850 : Closed e2418115469850 ∧ code e2418115469850 = 11214208492058 := by decide
theorem cert_e2418115469850 : check e2418115469850 [[]] .width = true := by decide
def e2418115471386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418115471386 : Closed e2418115471386 ∧ code e2418115471386 = 11214208493594 := by decide
theorem cert_e2418115471386 : check e2418115471386 [[]] .width = true := by decide
def e2418115472922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115472922 : Closed e2418115472922 ∧ code e2418115472922 = 11214208495130 := by decide
theorem cert_e2418115472922 : check e2418115472922 [[]] .width = true := by decide
def e2418115575834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418115575834 : Closed e2418115575834 ∧ code e2418115575834 = 11214208598042 := by decide
theorem cert_e2418115575834 : check e2418115575834 [[]] .width = true := by decide
def e2418115575926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418115575926 : Closed e2418115575926 ∧ code e2418115575926 = 11214208598134 := by decide
theorem cert_e2418115575926 : check e2418115575926 [[]] .width = true := by decide
def e2418115576170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418115576170 : Closed e2418115576170 ∧ code e2418115576170 = 11214208598378 := by decide
theorem cert_e2418115576170 : check e2418115576170 [[]] .width = true := by decide
def e2418115576218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418115576218 : Closed e2418115576218 ∧ code e2418115576218 = 11214208598426 := by decide
theorem cert_e2418115576218 : check e2418115576218 [[]] .width = true := by decide
def e2418115577226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418115577226 : Closed e2418115577226 ∧ code e2418115577226 = 11214208599434 := by decide
theorem cert_e2418115577226 : check e2418115577226 [[]] .width = true := by decide
def e2418115577250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418115577250 : Closed e2418115577250 ∧ code e2418115577250 = 11214208599458 := by decide
theorem cert_e2418115577250 : check e2418115577250 [[]] .width = true := by decide
def e2418115577358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418115577358 : Closed e2418115577358 ∧ code e2418115577358 = 11214208599566 := by decide
theorem cert_e2418115577358 : check e2418115577358 [[]] .width = true := by decide
def e2418115577370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418115577370 : Closed e2418115577370 ∧ code e2418115577370 = 11214208599578 := by decide
theorem cert_e2418115577370 : check e2418115577370 [[]] .width = true := by decide
def e2418115577442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418115577442 : Closed e2418115577442 ∧ code e2418115577442 = 11214208599650 := by decide
theorem cert_e2418115577442 : check e2418115577442 [[]] .width = true := by decide
def e2418115743258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115743258 : Closed e2418115743258 ∧ code e2418115743258 = 11214208765466 := by decide
private def t_e2418115743258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418115743258 : ¬ IsSelfInterpreter e2418115743258 :=
  wSource (t := t_e2418115743258) (replay_sound (ps := []) (t := e2418115743258) (by decide)) (by decide)
def e2418115752134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418115752134 : Closed e2418115752134 ∧ code e2418115752134 = 11214208774342 := by decide
theorem cert_e2418115752134 : check e2418115752134 [[]] .width = true := by decide
def e2418115764762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115764762 : Closed e2418115764762 ∧ code e2418115764762 = 11214208786970 := by decide
private def t_e2418115764762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418115764762 : ¬ IsSelfInterpreter e2418115764762 :=
  wSource (t := t_e2418115764762) (replay_sound (ps := []) (t := e2418115764762) (by decide)) (by decide)
def e2418115766298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418115766298 : Closed e2418115766298 ∧ code e2418115766298 = 11214208788506 := by decide
theorem cert_e2418115766298 : check e2418115766298 [[]] .width = true := by decide
def e2418115767834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115767834 : Closed e2418115767834 ∧ code e2418115767834 = 11214208790042 := by decide
private def t_e2418115767834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418115767834 : ¬ IsSelfInterpreter e2418115767834 :=
  wSource (t := t_e2418115767834) (replay_sound (ps := []) (t := e2418115767834) (by decide)) (by decide)
def e2418115770906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115770906 : Closed e2418115770906 ∧ code e2418115770906 = 11214208793114 := by decide
private def t_e2418115770906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418115770906 : ¬ IsSelfInterpreter e2418115770906 :=
  wSource (t := t_e2418115770906) (replay_sound (ps := []) (t := e2418115770906) (by decide)) (by decide)
def e2418115772442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418115772442 : Closed e2418115772442 ∧ code e2418115772442 = 11214208794650 := by decide
theorem cert_e2418115772442 : check e2418115772442 [[]] .width = true := by decide
def e2418115772534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418115772534 : Closed e2418115772534 ∧ code e2418115772534 = 11214208794742 := by decide
theorem cert_e2418115772534 : check e2418115772534 [[]] .width = true := by decide
def e2418115772778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418115772778 : Closed e2418115772778 ∧ code e2418115772778 = 11214208794986 := by decide
theorem cert_e2418115772778 : check e2418115772778 [[]] .width = true := by decide
def e2418115772826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418115772826 : Closed e2418115772826 ∧ code e2418115772826 = 11214208795034 := by decide
theorem cert_e2418115772826 : check e2418115772826 [[]] .width = true := by decide
def e2418115773834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418115773834 : Closed e2418115773834 ∧ code e2418115773834 = 11214208796042 := by decide
theorem cert_e2418115773834 : check e2418115773834 [[]] .width = true := by decide
def e2418115773858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418115773858 : Closed e2418115773858 ∧ code e2418115773858 = 11214208796066 := by decide
private def t_e2418115773858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2418115773858 : ¬ IsSelfInterpreter e2418115773858 :=
  wSource (t := t_e2418115773858) (replay_sound (ps := []) (t := e2418115773858) (by decide)) (by decide)
def e2418115773966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418115773966 : Closed e2418115773966 ∧ code e2418115773966 = 11214208796174 := by decide
theorem cert_e2418115773966 : check e2418115773966 [[]] .width = true := by decide
def e2418115773978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418115773978 : Closed e2418115773978 ∧ code e2418115773978 = 11214208796186 := by decide
private def t_e2418115773978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2418115773978 : ¬ IsSelfInterpreter e2418115773978 :=
  wSource (t := t_e2418115773978) (replay_sound (ps := []) (t := e2418115773978) (by decide)) (by decide)
def e2418115774050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418115774050 : Closed e2418115774050 ∧ code e2418115774050 = 11214208796258 := by decide
theorem cert_e2418115774050 : check e2418115774050 [[]] .width = true := by decide
def e2418115900954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115900954 : Closed e2418115900954 ∧ code e2418115900954 = 11214208923162 := by decide
theorem cert_e2418115900954 : check e2418115900954 [[]] .width = true := by decide
def e2418115901978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115901978 : Closed e2418115901978 ∧ code e2418115901978 = 11214208924186 := by decide
theorem cert_e2418115901978 : check e2418115901978 [[]] .width = true := by decide
def e2418115950106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115950106 : Closed e2418115950106 ∧ code e2418115950106 = 11214208972314 := by decide
theorem cert_e2418115950106 : check e2418115950106 [[]] .width = true := by decide
def e2418115951130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115951130 : Closed e2418115951130 ∧ code e2418115951130 = 11214208973338 := by decide
theorem cert_e2418115951130 : check e2418115951130 [[]] .width = true := by decide
def e2418115972634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115972634 : Closed e2418115972634 ∧ code e2418115972634 = 11214208994842 := by decide
theorem cert_e2418115972634 : check e2418115972634 [[]] .width = true := by decide
def e2418115981510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418115981510 : Closed e2418115981510 ∧ code e2418115981510 = 11214209003718 := by decide
theorem cert_e2418115981510 : check e2418115981510 [[]] .width = true := by decide
def e2418115986970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418115986970 : Closed e2418115986970 ∧ code e2418115986970 = 11214209009178 := by decide
theorem cert_e2418115986970 : check e2418115986970 [[]] .width = true := by decide
def e2418115989702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418115989702 : Closed e2418115989702 ∧ code e2418115989702 = 11214209011910 := by decide
theorem cert_e2418115989702 : check e2418115989702 [[]] .width = true := by decide
def e2418116072986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116072986 : Closed e2418116072986 ∧ code e2418116072986 = 11214209095194 := by decide
theorem cert_e2418116072986 : check e2418116072986 [[]] .width = true := by decide
def e2418116089882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418116089882 : Closed e2418116089882 ∧ code e2418116089882 = 11214209112090 := by decide
theorem cert_e2418116089882 : check e2418116089882 [[]] .width = true := by decide
def e2418116092442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116092442 : Closed e2418116092442 ∧ code e2418116092442 = 11214209114650 := by decide
theorem cert_e2418116092442 : check e2418116092442 [[]] .width = true := by decide
def e2418116093978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418116093978 : Closed e2418116093978 ∧ code e2418116093978 = 11214209116186 := by decide
theorem cert_e2418116093978 : check e2418116093978 [[]] .width = true := by decide
def e2418116095514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116095514 : Closed e2418116095514 ∧ code e2418116095514 = 11214209117722 := by decide
theorem cert_e2418116095514 : check e2418116095514 [[]] .width = true := by decide
def e2418116097562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116097562 : Closed e2418116097562 ∧ code e2418116097562 = 11214209119770 := by decide
theorem cert_e2418116097562 : check e2418116097562 [[]] .width = true := by decide
def e2418116102682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116102682 : Closed e2418116102682 ∧ code e2418116102682 = 11214209124890 := by decide
theorem cert_e2418116102682 : check e2418116102682 [[]] .width = true := by decide
def e2418116108826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116108826 : Closed e2418116108826 ∧ code e2418116108826 = 11214209131034 := by decide
theorem cert_e2418116108826 : check e2418116108826 [[]] .width = true := by decide
def e2418116110362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418116110362 : Closed e2418116110362 ∧ code e2418116110362 = 11214209132570 := by decide
theorem cert_e2418116110362 : check e2418116110362 [[]] .width = true := by decide
def e2418116111898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116111898 : Closed e2418116111898 ∧ code e2418116111898 = 11214209134106 := by decide
theorem cert_e2418116111898 : check e2418116111898 [[]] .width = true := by decide
def e2418116114970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116114970 : Closed e2418116114970 ∧ code e2418116114970 = 11214209137178 := by decide
private def t_e2418116114970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116114970 : ¬ IsSelfInterpreter e2418116114970 :=
  wSource (t := t_e2418116114970) (replay_sound (ps := []) (t := e2418116114970) (by decide)) (by decide)
def e2418116122138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116122138 : Closed e2418116122138 ∧ code e2418116122138 = 11214209144346 := by decide
theorem cert_e2418116122138 : check e2418116122138 [[]] .width = true := by decide
def e2418116123162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116123162 : Closed e2418116123162 ∧ code e2418116123162 = 11214209145370 := by decide
private def t_e2418116123162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116123162 : ¬ IsSelfInterpreter e2418116123162 :=
  wSource (t := t_e2418116123162) (replay_sound (ps := []) (t := e2418116123162) (by decide)) (by decide)
def e2418116140570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116140570 : Closed e2418116140570 ∧ code e2418116140570 = 11214209162778 := by decide
theorem cert_e2418116140570 : check e2418116140570 [[]] .width = true := by decide
def e2418116161734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418116161734 : Closed e2418116161734 ∧ code e2418116161734 = 11214209183942 := by decide
theorem cert_e2418116161734 : check e2418116161734 [[]] .width = true := by decide
def e2418116188186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418116188186 : Closed e2418116188186 ∧ code e2418116188186 = 11214209210394 := by decide
theorem cert_e2418116188186 : check e2418116188186 [[]] .width = true := by decide
def e2418116190746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116190746 : Closed e2418116190746 ∧ code e2418116190746 = 11214209212954 := by decide
theorem cert_e2418116190746 : check e2418116190746 [[]] .width = true := by decide
def e2418116192282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418116192282 : Closed e2418116192282 ∧ code e2418116192282 = 11214209214490 := by decide
theorem cert_e2418116192282 : check e2418116192282 [[]] .width = true := by decide
def e2418116193818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116193818 : Closed e2418116193818 ∧ code e2418116193818 = 11214209216026 := by decide
theorem cert_e2418116193818 : check e2418116193818 [[]] .width = true := by decide
def e2418116195866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116195866 : Closed e2418116195866 ∧ code e2418116195866 = 11214209218074 := by decide
theorem cert_e2418116195866 : check e2418116195866 [[]] .width = true := by decide
def e2418116231194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418116231194 : Closed e2418116231194 ∧ code e2418116231194 = 11214209253402 := by decide
theorem cert_e2418116231194 : check e2418116231194 [[]] .width = true := by decide
def e2418116231286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418116231286 : Closed e2418116231286 ∧ code e2418116231286 = 11214209253494 := by decide
theorem cert_e2418116231286 : check e2418116231286 [[]] .width = true := by decide
def e2418116231530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418116231530 : Closed e2418116231530 ∧ code e2418116231530 = 11214209253738 := by decide
theorem cert_e2418116231530 : check e2418116231530 [[]] .width = true := by decide
def e2418116231578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418116231578 : Closed e2418116231578 ∧ code e2418116231578 = 11214209253786 := by decide
theorem cert_e2418116231578 : check e2418116231578 [[]] .width = true := by decide
def e2418116232586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418116232586 : Closed e2418116232586 ∧ code e2418116232586 = 11214209254794 := by decide
theorem cert_e2418116232586 : check e2418116232586 [[]] .width = true := by decide
def e2418116232610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418116232610 : Closed e2418116232610 ∧ code e2418116232610 = 11214209254818 := by decide
theorem cert_e2418116232610 : check e2418116232610 [[]] .width = true := by decide
def e2418116232718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418116232718 : Closed e2418116232718 ∧ code e2418116232718 = 11214209254926 := by decide
theorem cert_e2418116232718 : check e2418116232718 [[]] .width = true := by decide
def e2418116232730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418116232730 : Closed e2418116232730 ∧ code e2418116232730 = 11214209254938 := by decide
theorem cert_e2418116232730 : check e2418116232730 [[]] .width = true := by decide
def e2418116232802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418116232802 : Closed e2418116232802 ∧ code e2418116232802 = 11214209255010 := by decide
theorem cert_e2418116232802 : check e2418116232802 [[]] .width = true := by decide
def e2418116267546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116267546 : Closed e2418116267546 ∧ code e2418116267546 = 11214209289754 := by decide
private def t_e2418116267546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116267546 : ¬ IsSelfInterpreter e2418116267546 :=
  wSource (t := t_e2418116267546) (replay_sound (ps := []) (t := e2418116267546) (by decide)) (by decide)
def e2418116276422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418116276422 : Closed e2418116276422 ∧ code e2418116276422 = 11214209298630 := by decide
theorem cert_e2418116276422 : check e2418116276422 [[]] .width = true := by decide
def e2418116289050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116289050 : Closed e2418116289050 ∧ code e2418116289050 = 11214209311258 := by decide
private def t_e2418116289050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116289050 : ¬ IsSelfInterpreter e2418116289050 :=
  wSource (t := t_e2418116289050) (replay_sound (ps := []) (t := e2418116289050) (by decide)) (by decide)
def e2418116290586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418116290586 : Closed e2418116290586 ∧ code e2418116290586 = 11214209312794 := by decide
theorem cert_e2418116290586 : check e2418116290586 [[]] .width = true := by decide
def e2418116292122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116292122 : Closed e2418116292122 ∧ code e2418116292122 = 11214209314330 := by decide
private def t_e2418116292122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116292122 : ¬ IsSelfInterpreter e2418116292122 :=
  wSource (t := t_e2418116292122) (replay_sound (ps := []) (t := e2418116292122) (by decide)) (by decide)
def e2418116295194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116295194 : Closed e2418116295194 ∧ code e2418116295194 = 11214209317402 := by decide
private def t_e2418116295194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116295194 : ¬ IsSelfInterpreter e2418116295194 :=
  wSource (t := t_e2418116295194) (replay_sound (ps := []) (t := e2418116295194) (by decide)) (by decide)
def e2418116296730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418116296730 : Closed e2418116296730 ∧ code e2418116296730 = 11214209318938 := by decide
theorem cert_e2418116296730 : check e2418116296730 [[]] .width = true := by decide
def e2418116296822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418116296822 : Closed e2418116296822 ∧ code e2418116296822 = 11214209319030 := by decide
theorem cert_e2418116296822 : check e2418116296822 [[]] .width = true := by decide
def e2418116297066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418116297066 : Closed e2418116297066 ∧ code e2418116297066 = 11214209319274 := by decide
theorem cert_e2418116297066 : check e2418116297066 [[]] .width = true := by decide
def e2418116297114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418116297114 : Closed e2418116297114 ∧ code e2418116297114 = 11214209319322 := by decide
theorem cert_e2418116297114 : check e2418116297114 [[]] .width = true := by decide
def e2418116298122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418116298122 : Closed e2418116298122 ∧ code e2418116298122 = 11214209320330 := by decide
theorem cert_e2418116298122 : check e2418116298122 [[]] .width = true := by decide
def e2418116298146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418116298146 : Closed e2418116298146 ∧ code e2418116298146 = 11214209320354 := by decide
private def t_e2418116298146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2418116298146 : ¬ IsSelfInterpreter e2418116298146 :=
  wSource (t := t_e2418116298146) (replay_sound (ps := []) (t := e2418116298146) (by decide)) (by decide)
def e2418116298254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418116298254 : Closed e2418116298254 ∧ code e2418116298254 = 11214209320462 := by decide
theorem cert_e2418116298254 : check e2418116298254 [[]] .width = true := by decide
def e2418116298266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418116298266 : Closed e2418116298266 ∧ code e2418116298266 = 11214209320474 := by decide
private def t_e2418116298266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2418116298266 : ¬ IsSelfInterpreter e2418116298266 :=
  wSource (t := t_e2418116298266) (replay_sound (ps := []) (t := e2418116298266) (by decide)) (by decide)
def e2418116298338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418116298338 : Closed e2418116298338 ∧ code e2418116298338 = 11214209320546 := by decide
theorem cert_e2418116298338 : check e2418116298338 [[]] .width = true := by decide
def e2418116343322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116343322 : Closed e2418116343322 ∧ code e2418116343322 = 11214209365530 := by decide
private def t_e2418116343322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116343322 : ¬ IsSelfInterpreter e2418116343322 :=
  wSource (t := t_e2418116343322) (replay_sound (ps := []) (t := e2418116343322) (by decide)) (by decide)
def e2418116344346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418116344346 : Closed e2418116344346 ∧ code e2418116344346 = 11214209366554 := by decide
private def t_e2418116344346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418116344346 : ¬ IsSelfInterpreter e2418116344346 :=
  wSource (t := t_e2418116344346) (replay_sound (ps := []) (t := e2418116344346) (by decide)) (by decide)
def e2418117668378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117668378 : Closed e2418117668378 ∧ code e2418117668378 = 11214210690586 := by decide
def e2418117670426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117670426 : Closed e2418117670426 ∧ code e2418117670426 = 11214210692634 := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2418112583194
#print axioms Blc.Floor43.cert_e2418112584218
#print axioms Blc.Floor43.cert_e2418115328538
#print axioms Blc.Floor43.cert_e2418115743258
#print axioms Blc.Floor43.cert_e2418115764762
#print axioms Blc.Floor43.cert_e2418115767834
#print axioms Blc.Floor43.cert_e2418115770906
#print axioms Blc.Floor43.cert_e2418115773858
#print axioms Blc.Floor43.cert_e2418115773978
#print axioms Blc.Floor43.cert_e2418116114970
#print axioms Blc.Floor43.cert_e2418116123162
#print axioms Blc.Floor43.cert_e2418116267546
#print axioms Blc.Floor43.cert_e2418116289050
#print axioms Blc.Floor43.cert_e2418116292122
#print axioms Blc.Floor43.cert_e2418116295194
#print axioms Blc.Floor43.cert_e2418116298146
#print axioms Blc.Floor43.cert_e2418116298266
#print axioms Blc.Floor43.cert_e2418116343322
#print axioms Blc.Floor43.cert_e2418116344346
