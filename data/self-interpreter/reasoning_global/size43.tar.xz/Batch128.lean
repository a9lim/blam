import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2211748386410 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2211748386410 : Closed e2211748386410 ∧ code e2211748386410 = 11007841408618 := by decide
theorem cert_e2211748386410 : check e2211748386410 [[]] .width = true := by decide
def e2211748386434 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2211748386434 : Closed e2211748386434 ∧ code e2211748386434 = 11007841408642 := by decide
theorem cert_e2211748386434 : check e2211748386434 [[]] .width = true := by decide
def e2211748386458 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2211748386458 : Closed e2211748386458 ∧ code e2211748386458 = 11007841408666 := by decide
theorem cert_e2211748386458 : check e2211748386458 [[]] .width = true := by decide
def e2211748386842 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2211748386842 : Closed e2211748386842 ∧ code e2211748386842 = 11007841409050 := by decide
theorem cert_e2211748386842 : check e2211748386842 [[]] .width = true := by decide
def e2211748386934 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2211748386934 : Closed e2211748386934 ∧ code e2211748386934 = 11007841409142 := by decide
theorem cert_e2211748386934 : check e2211748386934 [[]] .width = true := by decide
def e2211748387178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2211748387178 : Closed e2211748387178 ∧ code e2211748387178 = 11007841409386 := by decide
theorem cert_e2211748387178 : check e2211748387178 [[]] .width = true := by decide
def e2211748387202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2211748387202 : Closed e2211748387202 ∧ code e2211748387202 = 11007841409410 := by decide
theorem cert_e2211748387202 : check e2211748387202 [[]] .width = true := by decide
def e2211748387226 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2211748387226 : Closed e2211748387226 ∧ code e2211748387226 = 11007841409434 := by decide
theorem cert_e2211748387226 : check e2211748387226 [[]] .width = true := by decide
def e2211758137370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211758137370 : Closed e2211758137370 ∧ code e2211758137370 = 11007851159578 := by decide
theorem cert_e2211758137370 : check e2211758137370 [[]] .width = true := by decide
def e2211758137462 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211758137462 : Closed e2211758137462 ∧ code e2211758137462 = 11007851159670 := by decide
private def t_e2211758137462 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211758137462 : ¬ IsSelfInterpreter e2211758137462 :=
  wSource (t := t_e2211758137462) (replay_sound (ps := []) (t := e2211758137462) (by decide)) (by decide)
def e2211758137706 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211758137706 : Closed e2211758137706 ∧ code e2211758137706 = 11007851159914 := by decide
private def t_e2211758137706 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211758137706 : ¬ IsSelfInterpreter e2211758137706 :=
  wSource (t := t_e2211758137706) (replay_sound (ps := []) (t := e2211758137706) (by decide)) (by decide)
def e2211758137754 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211758137754 : Closed e2211758137754 ∧ code e2211758137754 = 11007851159962 := by decide
private def t_e2211758137754 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211758137754 : ¬ IsSelfInterpreter e2211758137754 :=
  wSource (t := t_e2211758137754) (replay_sound (ps := []) (t := e2211758137754) (by decide)) (by decide)
def e2211758170138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211758170138 : Closed e2211758170138 ∧ code e2211758170138 = 11007851192346 := by decide
theorem cert_e2211758170138 : check e2211758170138 [[]] .width = true := by decide
def e2211758170230 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211758170230 : Closed e2211758170230 ∧ code e2211758170230 = 11007851192438 := by decide
private def t_e2211758170230 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211758170230 : ¬ IsSelfInterpreter e2211758170230 :=
  wSource (t := t_e2211758170230) (replay_sound (ps := []) (t := e2211758170230) (by decide)) (by decide)
def e2211758170474 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211758170474 : Closed e2211758170474 ∧ code e2211758170474 = 11007851192682 := by decide
private def t_e2211758170474 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211758170474 : ¬ IsSelfInterpreter e2211758170474 :=
  wSource (t := t_e2211758170474) (replay_sound (ps := []) (t := e2211758170474) (by decide)) (by decide)
def e2211758170522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211758170522 : Closed e2211758170522 ∧ code e2211758170522 = 11007851192730 := by decide
private def t_e2211758170522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211758170522 : ¬ IsSelfInterpreter e2211758170522 :=
  wSource (t := t_e2211758170522) (replay_sound (ps := []) (t := e2211758170522) (by decide)) (by decide)
def e2211760136218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211760136218 : Closed e2211760136218 ∧ code e2211760136218 = 11007853158426 := by decide
theorem cert_e2211760136218 : check e2211760136218 [[]] .width = true := by decide
def e2211760136310 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211760136310 : Closed e2211760136310 ∧ code e2211760136310 = 11007853158518 := by decide
private def t_e2211760136310 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211760136310 : ¬ IsSelfInterpreter e2211760136310 :=
  wSource (t := t_e2211760136310) (replay_sound (ps := []) (t := e2211760136310) (by decide)) (by decide)
def e2211760136554 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211760136554 : Closed e2211760136554 ∧ code e2211760136554 = 11007853158762 := by decide
private def t_e2211760136554 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211760136554 : ¬ IsSelfInterpreter e2211760136554 :=
  wSource (t := t_e2211760136554) (replay_sound (ps := []) (t := e2211760136554) (by decide)) (by decide)
def e2211760136602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211760136602 : Closed e2211760136602 ∧ code e2211760136602 = 11007853158810 := by decide
private def t_e2211760136602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211760136602 : ¬ IsSelfInterpreter e2211760136602 :=
  wSource (t := t_e2211760136602) (replay_sound (ps := []) (t := e2211760136602) (by decide)) (by decide)
def e2211760152602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211760152602 : Closed e2211760152602 ∧ code e2211760152602 = 11007853174810 := by decide
theorem cert_e2211760152602 : check e2211760152602 [[]] .width = true := by decide
def e2211760152694 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211760152694 : Closed e2211760152694 ∧ code e2211760152694 = 11007853174902 := by decide
private def t_e2211760152694 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211760152694 : ¬ IsSelfInterpreter e2211760152694 :=
  wSource (t := t_e2211760152694) (replay_sound (ps := []) (t := e2211760152694) (by decide)) (by decide)
def e2211760152938 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211760152938 : Closed e2211760152938 ∧ code e2211760152938 = 11007853175146 := by decide
private def t_e2211760152938 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211760152938 : ¬ IsSelfInterpreter e2211760152938 :=
  wSource (t := t_e2211760152938) (replay_sound (ps := []) (t := e2211760152938) (by decide)) (by decide)
def e2211760152986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211760152986 : Closed e2211760152986 ∧ code e2211760152986 = 11007853175194 := by decide
private def t_e2211760152986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211760152986 : ¬ IsSelfInterpreter e2211760152986 :=
  wSource (t := t_e2211760152986) (replay_sound (ps := []) (t := e2211760152986) (by decide)) (by decide)
def e2211760158746 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760158746 : Closed e2211760158746 ∧ code e2211760158746 = 11007853180954 := by decide
theorem cert_e2211760158746 : check e2211760158746 [[]] .width = true := by decide
def e2211760166938 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760166938 : Closed e2211760166938 ∧ code e2211760166938 = 11007853189146 := by decide
theorem cert_e2211760166938 : check e2211760166938 [[]] .width = true := by decide
def e2211760218138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211760218138 : Closed e2211760218138 ∧ code e2211760218138 = 11007853240346 := by decide
theorem cert_e2211760218138 : check e2211760218138 [[]] .width = true := by decide
def e2211760218230 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211760218230 : Closed e2211760218230 ∧ code e2211760218230 = 11007853240438 := by decide
private def t_e2211760218230 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211760218230 : ¬ IsSelfInterpreter e2211760218230 :=
  wSource (t := t_e2211760218230) (replay_sound (ps := []) (t := e2211760218230) (by decide)) (by decide)
def e2211760218474 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211760218474 : Closed e2211760218474 ∧ code e2211760218474 = 11007853240682 := by decide
private def t_e2211760218474 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211760218474 : ¬ IsSelfInterpreter e2211760218474 :=
  wSource (t := t_e2211760218474) (replay_sound (ps := []) (t := e2211760218474) (by decide)) (by decide)
def e2211760218522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211760218522 : Closed e2211760218522 ∧ code e2211760218522 = 11007853240730 := by decide
private def t_e2211760218522 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211760218522 : ¬ IsSelfInterpreter e2211760218522 :=
  wSource (t := t_e2211760218522) (replay_sound (ps := []) (t := e2211760218522) (by decide)) (by decide)
def e2211760224282 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760224282 : Closed e2211760224282 ∧ code e2211760224282 = 11007853246490 := by decide
theorem cert_e2211760224282 : check e2211760224282 [[]] .width = true := by decide
def e2211760236570 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760236570 : Closed e2211760236570 ∧ code e2211760236570 = 11007853258778 := by decide
theorem cert_e2211760236570 : check e2211760236570 [[]] .width = true := by decide
def e2211760265242 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760265242 : Closed e2211760265242 ∧ code e2211760265242 = 11007853287450 := by decide
theorem cert_e2211760265242 : check e2211760265242 [[]] .width = true := by decide
def e2211760269338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760269338 : Closed e2211760269338 ∧ code e2211760269338 = 11007853291546 := by decide
theorem cert_e2211760269338 : check e2211760269338 [[]] .width = true := by decide
def e2211760423110 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2211760423110 : Closed e2211760423110 ∧ code e2211760423110 = 11007853445318 := by decide
theorem cert_e2211760423110 : check e2211760423110 [[]] .width = true := by decide
def e2211760529434 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211760529434 : Closed e2211760529434 ∧ code e2211760529434 = 11007853551642 := by decide
theorem cert_e2211760529434 : check e2211760529434 [[]] .width = true := by decide
def e2211760529526 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211760529526 : Closed e2211760529526 ∧ code e2211760529526 = 11007853551734 := by decide
private def t_e2211760529526 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211760529526 : ¬ IsSelfInterpreter e2211760529526 :=
  wSource (t := t_e2211760529526) (replay_sound (ps := []) (t := e2211760529526) (by decide)) (by decide)
def e2211760529770 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211760529770 : Closed e2211760529770 ∧ code e2211760529770 = 11007853551978 := by decide
private def t_e2211760529770 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211760529770 : ¬ IsSelfInterpreter e2211760529770 :=
  wSource (t := t_e2211760529770) (replay_sound (ps := []) (t := e2211760529770) (by decide)) (by decide)
def e2211760529818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211760529818 : Closed e2211760529818 ∧ code e2211760529818 = 11007853552026 := by decide
private def t_e2211760529818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211760529818 : ¬ IsSelfInterpreter e2211760529818 :=
  wSource (t := t_e2211760529818) (replay_sound (ps := []) (t := e2211760529818) (by decide)) (by decide)
def e2211760545818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211760545818 : Closed e2211760545818 ∧ code e2211760545818 = 11007853568026 := by decide
theorem cert_e2211760545818 : check e2211760545818 [[]] .width = true := by decide
def e2211760545910 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211760545910 : Closed e2211760545910 ∧ code e2211760545910 = 11007853568118 := by decide
private def t_e2211760545910 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211760545910 : ¬ IsSelfInterpreter e2211760545910 :=
  wSource (t := t_e2211760545910) (replay_sound (ps := []) (t := e2211760545910) (by decide)) (by decide)
def e2211760546154 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211760546154 : Closed e2211760546154 ∧ code e2211760546154 = 11007853568362 := by decide
private def t_e2211760546154 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211760546154 : ¬ IsSelfInterpreter e2211760546154 :=
  wSource (t := t_e2211760546154) (replay_sound (ps := []) (t := e2211760546154) (by decide)) (by decide)
def e2211760546202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211760546202 : Closed e2211760546202 ∧ code e2211760546202 = 11007853568410 := by decide
private def t_e2211760546202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211760546202 : ¬ IsSelfInterpreter e2211760546202 :=
  wSource (t := t_e2211760546202) (replay_sound (ps := []) (t := e2211760546202) (by decide)) (by decide)
def e2211760551962 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760551962 : Closed e2211760551962 ∧ code e2211760551962 = 11007853574170 := by decide
theorem cert_e2211760551962 : check e2211760551962 [[]] .width = true := by decide
def e2211760560154 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760560154 : Closed e2211760560154 ∧ code e2211760560154 = 11007853582362 := by decide
theorem cert_e2211760560154 : check e2211760560154 [[]] .width = true := by decide
def e2211760701466 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2211760701466 : Closed e2211760701466 ∧ code e2211760701466 = 11007853723674 := by decide
theorem cert_e2211760701466 : check e2211760701466 [[]] .width = true := by decide
def e2211760701558 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2211760701558 : Closed e2211760701558 ∧ code e2211760701558 = 11007853723766 := by decide
theorem cert_e2211760701558 : check e2211760701558 [[]] .width = true := by decide
def e2211760701802 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2211760701802 : Closed e2211760701802 ∧ code e2211760701802 = 11007853724010 := by decide
theorem cert_e2211760701802 : check e2211760701802 [[]] .width = true := by decide
def e2211760701850 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2211760701850 : Closed e2211760701850 ∧ code e2211760701850 = 11007853724058 := by decide
theorem cert_e2211760701850 : check e2211760701850 [[]] .width = true := by decide
def e2211760701934 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2211760701934 : Closed e2211760701934 ∧ code e2211760701934 = 11007853724142 := by decide
private def t_e2211760701934 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e2211760701934 : ¬ IsSelfInterpreter e2211760701934 :=
  wSource (t := t_e2211760701934) (replay_sound (ps := []) (t := e2211760701934) (by decide)) (by decide)
def e2211760702858 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2211760702858 : Closed e2211760702858 ∧ code e2211760702858 = 11007853725066 := by decide
theorem cert_e2211760702858 : check e2211760702858 [[]] .width = true := by decide
def e2211760702882 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2211760702882 : Closed e2211760702882 ∧ code e2211760702882 = 11007853725090 := by decide
theorem cert_e2211760702882 : check e2211760702882 [[]] .width = true := by decide
def e2211760702902 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2211760702902 : Closed e2211760702902 ∧ code e2211760702902 = 11007853725110 := by decide
theorem cert_e2211760702902 : check e2211760702902 [[]] .width = true := by decide
def e2211760702934 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2211760702934 : Closed e2211760702934 ∧ code e2211760702934 = 11007853725142 := by decide
theorem cert_e2211760702934 : check e2211760702934 [[]] .width = true := by decide
def e2211760702938 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2211760702938 : Closed e2211760702938 ∧ code e2211760702938 = 11007853725146 := by decide
private def t_e2211760702938 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e2211760702938 : ¬ IsSelfInterpreter e2211760702938 :=
  wSource (t := t_e2211760702938) (replay_sound (ps := []) (t := e2211760702938) (by decide)) (by decide)
def e2211760702990 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2211760702990 : Closed e2211760702990 ∧ code e2211760702990 = 11007853725198 := by decide
theorem cert_e2211760702990 : check e2211760702990 [[]] .width = true := by decide
def e2211760703002 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2211760703002 : Closed e2211760703002 ∧ code e2211760703002 = 11007853725210 := by decide
theorem cert_e2211760703002 : check e2211760703002 [[]] .width = true := by decide
def e2211760703074 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2211760703074 : Closed e2211760703074 ∧ code e2211760703074 = 11007853725282 := by decide
theorem cert_e2211760703074 : check e2211760703074 [[]] .width = true := by decide
def e2211760703094 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2211760703094 : Closed e2211760703094 ∧ code e2211760703094 = 11007853725302 := by decide
theorem cert_e2211760703094 : check e2211760703094 [[]] .width = true := by decide
def e2211760703286 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2211760703286 : Closed e2211760703286 ∧ code e2211760703286 = 11007853725494 := by decide
theorem cert_e2211760703286 : check e2211760703286 [[]] .width = true := by decide
def e2211760703290 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2211760703290 : Closed e2211760703290 ∧ code e2211760703290 = 11007853725498 := by decide
theorem cert_e2211760703290 : check e2211760703290 [[]] .width = true := by decide
def e2211760706986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2211760706986 : Closed e2211760706986 ∧ code e2211760706986 = 11007853729194 := by decide
private def t_e2211760706986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e2211760706986 : ¬ IsSelfInterpreter e2211760706986 :=
  wSource (t := t_e2211760706986) (replay_sound (ps := []) (t := e2211760706986) (by decide)) (by decide)
def e2211760707082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2211760707082 : Closed e2211760707082 ∧ code e2211760707082 = 11007853729290 := by decide
theorem cert_e2211760707082 : check e2211760707082 [[]] .width = true := by decide
def e2211760707178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2211760707178 : Closed e2211760707178 ∧ code e2211760707178 = 11007853729386 := by decide
private def t_e2211760707178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e2211760707178 : ¬ IsSelfInterpreter e2211760707178 :=
  wSource (t := t_e2211760707178) (replay_sound (ps := []) (t := e2211760707178) (by decide)) (by decide)
def e2211760707202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2211760707202 : Closed e2211760707202 ∧ code e2211760707202 = 11007853729410 := by decide
private def t_e2211760707202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e2211760707202 : ¬ IsSelfInterpreter e2211760707202 :=
  wSource (t := t_e2211760707202) (replay_sound (ps := []) (t := e2211760707202) (by decide)) (by decide)
def e2211760707226 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2211760707226 : Closed e2211760707226 ∧ code e2211760707226 = 11007853729434 := by decide
private def t_e2211760707226 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e2211760707226 : ¬ IsSelfInterpreter e2211760707226 :=
  wSource (t := t_e2211760707226) (replay_sound (ps := []) (t := e2211760707226) (by decide)) (by decide)
def e2211760707610 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2211760707610 : Closed e2211760707610 ∧ code e2211760707610 = 11007853729818 := by decide
theorem cert_e2211760707610 : check e2211760707610 [[]] .width = true := by decide
def e2211760707702 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2211760707702 : Closed e2211760707702 ∧ code e2211760707702 = 11007853729910 := by decide
private def t_e2211760707702 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e2211760707702 : ¬ IsSelfInterpreter e2211760707702 :=
  wSource (t := t_e2211760707702) (replay_sound (ps := []) (t := e2211760707702) (by decide)) (by decide)
def e2211760707946 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2211760707946 : Closed e2211760707946 ∧ code e2211760707946 = 11007853730154 := by decide
private def t_e2211760707946 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e2211760707946 : ¬ IsSelfInterpreter e2211760707946 :=
  wSource (t := t_e2211760707946) (replay_sound (ps := []) (t := e2211760707946) (by decide)) (by decide)
def e2211760707970 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2211760707970 : Closed e2211760707970 ∧ code e2211760707970 = 11007853730178 := by decide
theorem cert_e2211760707970 : check e2211760707970 [[]] .width = true := by decide
def e2211760707994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2211760707994 : Closed e2211760707994 ∧ code e2211760707994 = 11007853730202 := by decide
private def t_e2211760707994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e2211760707994 : ¬ IsSelfInterpreter e2211760707994 :=
  wSource (t := t_e2211760707994) (replay_sound (ps := []) (t := e2211760707994) (by decide)) (by decide)
def e2211760881862 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2211760881862 : Closed e2211760881862 ∧ code e2211760881862 = 11007853904070 := by decide
theorem cert_e2211760881862 : check e2211760881862 [[]] .width = true := by decide
def e2211760939034 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2211760939034 : Closed e2211760939034 ∧ code e2211760939034 = 11007853961242 := by decide
theorem cert_e2211760939034 : check e2211760939034 [[]] .width = true := by decide
def e2211760939126 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2211760939126 : Closed e2211760939126 ∧ code e2211760939126 = 11007853961334 := by decide
private def t_e2211760939126 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2211760939126 : ¬ IsSelfInterpreter e2211760939126 :=
  wSource (t := t_e2211760939126) (replay_sound (ps := []) (t := e2211760939126) (by decide)) (by decide)
def e2211760939370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2211760939370 : Closed e2211760939370 ∧ code e2211760939370 = 11007853961578 := by decide
private def t_e2211760939370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2211760939370 : ¬ IsSelfInterpreter e2211760939370 :=
  wSource (t := t_e2211760939370) (replay_sound (ps := []) (t := e2211760939370) (by decide)) (by decide)
def e2211760939418 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2211760939418 : Closed e2211760939418 ∧ code e2211760939418 = 11007853961626 := by decide
private def t_e2211760939418 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2211760939418 : ¬ IsSelfInterpreter e2211760939418 :=
  wSource (t := t_e2211760939418) (replay_sound (ps := []) (t := e2211760939418) (by decide)) (by decide)
def e2211760945178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760945178 : Closed e2211760945178 ∧ code e2211760945178 = 11007853967386 := by decide
theorem cert_e2211760945178 : check e2211760945178 [[]] .width = true := by decide
def e2211760957466 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211760957466 : Closed e2211760957466 ∧ code e2211760957466 = 11007853979674 := by decide
theorem cert_e2211760957466 : check e2211760957466 [[]] .width = true := by decide
def e2211760963610 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2211760963610 : Closed e2211760963610 ∧ code e2211760963610 = 11007853985818 := by decide
theorem cert_e2211760963610 : check e2211760963610 [[]] .width = true := by decide
def e2211760963702 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2211760963702 : Closed e2211760963702 ∧ code e2211760963702 = 11007853985910 := by decide
theorem cert_e2211760963702 : check e2211760963702 [[]] .width = true := by decide
def e2211760963946 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2211760963946 : Closed e2211760963946 ∧ code e2211760963946 = 11007853986154 := by decide
theorem cert_e2211760963946 : check e2211760963946 [[]] .width = true := by decide
def e2211760963994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2211760963994 : Closed e2211760963994 ∧ code e2211760963994 = 11007853986202 := by decide
theorem cert_e2211760963994 : check e2211760963994 [[]] .width = true := by decide
def e2211760964078 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2211760964078 : Closed e2211760964078 ∧ code e2211760964078 = 11007853986286 := by decide
private def t_e2211760964078 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e2211760964078 : ¬ IsSelfInterpreter e2211760964078 :=
  wSource (t := t_e2211760964078) (replay_sound (ps := []) (t := e2211760964078) (by decide)) (by decide)
def e2211760965002 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2211760965002 : Closed e2211760965002 ∧ code e2211760965002 = 11007853987210 := by decide
theorem cert_e2211760965002 : check e2211760965002 [[]] .width = true := by decide
def e2211760965026 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2211760965026 : Closed e2211760965026 ∧ code e2211760965026 = 11007853987234 := by decide
theorem cert_e2211760965026 : check e2211760965026 [[]] .width = true := by decide
def e2211760965046 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2211760965046 : Closed e2211760965046 ∧ code e2211760965046 = 11007853987254 := by decide
theorem cert_e2211760965046 : check e2211760965046 [[]] .width = true := by decide
def e2211760965078 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2211760965078 : Closed e2211760965078 ∧ code e2211760965078 = 11007853987286 := by decide
theorem cert_e2211760965078 : check e2211760965078 [[]] .width = true := by decide
def e2211760965082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2211760965082 : Closed e2211760965082 ∧ code e2211760965082 = 11007853987290 := by decide
private def t_e2211760965082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e2211760965082 : ¬ IsSelfInterpreter e2211760965082 :=
  wSource (t := t_e2211760965082) (replay_sound (ps := []) (t := e2211760965082) (by decide)) (by decide)
def e2211760965134 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2211760965134 : Closed e2211760965134 ∧ code e2211760965134 = 11007853987342 := by decide
theorem cert_e2211760965134 : check e2211760965134 [[]] .width = true := by decide
def e2211760965146 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2211760965146 : Closed e2211760965146 ∧ code e2211760965146 = 11007853987354 := by decide
theorem cert_e2211760965146 : check e2211760965146 [[]] .width = true := by decide
def e2211760965218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2211760965218 : Closed e2211760965218 ∧ code e2211760965218 = 11007853987426 := by decide
theorem cert_e2211760965218 : check e2211760965218 [[]] .width = true := by decide
def e2211760965238 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2211760965238 : Closed e2211760965238 ∧ code e2211760965238 = 11007853987446 := by decide
theorem cert_e2211760965238 : check e2211760965238 [[]] .width = true := by decide
def e2211760965430 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2211760965430 : Closed e2211760965430 ∧ code e2211760965430 = 11007853987638 := by decide
theorem cert_e2211760965430 : check e2211760965430 [[]] .width = true := by decide
def e2211760965434 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2211760965434 : Closed e2211760965434 ∧ code e2211760965434 = 11007853987642 := by decide
theorem cert_e2211760965434 : check e2211760965434 [[]] .width = true := by decide
def e2211760969130 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2211760969130 : Closed e2211760969130 ∧ code e2211760969130 = 11007853991338 := by decide
private def t_e2211760969130 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e2211760969130 : ¬ IsSelfInterpreter e2211760969130 :=
  wSource (t := t_e2211760969130) (replay_sound (ps := []) (t := e2211760969130) (by decide)) (by decide)
def e2211760969226 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2211760969226 : Closed e2211760969226 ∧ code e2211760969226 = 11007853991434 := by decide
theorem cert_e2211760969226 : check e2211760969226 [[]] .width = true := by decide
def e2211760969322 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2211760969322 : Closed e2211760969322 ∧ code e2211760969322 = 11007853991530 := by decide
private def t_e2211760969322 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e2211760969322 : ¬ IsSelfInterpreter e2211760969322 :=
  wSource (t := t_e2211760969322) (replay_sound (ps := []) (t := e2211760969322) (by decide)) (by decide)
def e2211760969346 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2211760969346 : Closed e2211760969346 ∧ code e2211760969346 = 11007853991554 := by decide
private def t_e2211760969346 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e2211760969346 : ¬ IsSelfInterpreter e2211760969346 :=
  wSource (t := t_e2211760969346) (replay_sound (ps := []) (t := e2211760969346) (by decide)) (by decide)
def e2211760969370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2211760969370 : Closed e2211760969370 ∧ code e2211760969370 = 11007853991578 := by decide
private def t_e2211760969370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e2211760969370 : ¬ IsSelfInterpreter e2211760969370 :=
  wSource (t := t_e2211760969370) (replay_sound (ps := []) (t := e2211760969370) (by decide)) (by decide)
def e2211760969754 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2211760969754 : Closed e2211760969754 ∧ code e2211760969754 = 11007853991962 := by decide
theorem cert_e2211760969754 : check e2211760969754 [[]] .width = true := by decide
def e2211760969846 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2211760969846 : Closed e2211760969846 ∧ code e2211760969846 = 11007853992054 := by decide
private def t_e2211760969846 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e2211760969846 : ¬ IsSelfInterpreter e2211760969846 :=
  wSource (t := t_e2211760969846) (replay_sound (ps := []) (t := e2211760969846) (by decide)) (by decide)
def e2211760970090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2211760970090 : Closed e2211760970090 ∧ code e2211760970090 = 11007853992298 := by decide
private def t_e2211760970090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e2211760970090 : ¬ IsSelfInterpreter e2211760970090 :=
  wSource (t := t_e2211760970090) (replay_sound (ps := []) (t := e2211760970090) (by decide)) (by decide)
def e2211760970114 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2211760970114 : Closed e2211760970114 ∧ code e2211760970114 = 11007853992322 := by decide
theorem cert_e2211760970114 : check e2211760970114 [[]] .width = true := by decide
def e2211760970138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2211760970138 : Closed e2211760970138 ∧ code e2211760970138 = 11007853992346 := by decide
private def t_e2211760970138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e2211760970138 : ¬ IsSelfInterpreter e2211760970138 :=
  wSource (t := t_e2211760970138) (replay_sound (ps := []) (t := e2211760970138) (by decide)) (by decide)
def e2211761149978 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211761149978 : Closed e2211761149978 ∧ code e2211761149978 = 11007854172186 := by decide
theorem cert_e2211761149978 : check e2211761149978 [[]] .width = true := by decide
def e2211761154074 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2211761154074 : Closed e2211761154074 ∧ code e2211761154074 = 11007854176282 := by decide
theorem cert_e2211761154074 : check e2211761154074 [[]] .width = true := by decide
def e2212636844058 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212636844058 : Closed e2212636844058 ∧ code e2212636844058 = 11008729866266 := by decide
theorem cert_e2212636844058 : check e2212636844058 [[]] .width = true := by decide
def e2212636844150 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212636844150 : Closed e2212636844150 ∧ code e2212636844150 = 11008729866358 := by decide
theorem cert_e2212636844150 : check e2212636844150 [[]] .width = true := by decide
def e2212636844394 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212636844394 : Closed e2212636844394 ∧ code e2212636844394 = 11008729866602 := by decide
theorem cert_e2212636844394 : check e2212636844394 [[]] .width = true := by decide
def e2212636844442 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212636844442 : Closed e2212636844442 ∧ code e2212636844442 = 11008729866650 := by decide
theorem cert_e2212636844442 : check e2212636844442 [[]] .width = true := by decide
def e2212637368346 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212637368346 : Closed e2212637368346 ∧ code e2212637368346 = 11008730390554 := by decide
theorem cert_e2212637368346 : check e2212637368346 [[]] .width = true := by decide
def e2212637368438 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212637368438 : Closed e2212637368438 ∧ code e2212637368438 = 11008730390646 := by decide
theorem cert_e2212637368438 : check e2212637368438 [[]] .width = true := by decide
def e2212637368682 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212637368682 : Closed e2212637368682 ∧ code e2212637368682 = 11008730390890 := by decide
theorem cert_e2212637368682 : check e2212637368682 [[]] .width = true := by decide
def e2212637368730 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212637368730 : Closed e2212637368730 ∧ code e2212637368730 = 11008730390938 := by decide
theorem cert_e2212637368730 : check e2212637368730 [[]] .width = true := by decide
def e2212637401114 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212637401114 : Closed e2212637401114 ∧ code e2212637401114 = 11008730423322 := by decide
theorem cert_e2212637401114 : check e2212637401114 [[]] .width = true := by decide
def e2212637401206 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212637401206 : Closed e2212637401206 ∧ code e2212637401206 = 11008730423414 := by decide
theorem cert_e2212637401206 : check e2212637401206 [[]] .width = true := by decide
def e2212637401450 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212637401450 : Closed e2212637401450 ∧ code e2212637401450 = 11008730423658 := by decide
theorem cert_e2212637401450 : check e2212637401450 [[]] .width = true := by decide
def e2212637401498 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212637401498 : Closed e2212637401498 ∧ code e2212637401498 = 11008730423706 := by decide
theorem cert_e2212637401498 : check e2212637401498 [[]] .width = true := by decide
def e2212641038362 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212641038362 : Closed e2212641038362 ∧ code e2212641038362 = 11008734060570 := by decide
theorem cert_e2212641038362 : check e2212641038362 [[]] .width = true := by decide
def e2212641038454 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212641038454 : Closed e2212641038454 ∧ code e2212641038454 = 11008734060662 := by decide
theorem cert_e2212641038454 : check e2212641038454 [[]] .width = true := by decide
def e2212641038698 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212641038698 : Closed e2212641038698 ∧ code e2212641038698 = 11008734060906 := by decide
theorem cert_e2212641038698 : check e2212641038698 [[]] .width = true := by decide
def e2212641038746 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212641038746 : Closed e2212641038746 ∧ code e2212641038746 = 11008734060954 := by decide
theorem cert_e2212641038746 : check e2212641038746 [[]] .width = true := by decide
def e2212641824794 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212641824794 : Closed e2212641824794 ∧ code e2212641824794 = 11008734847002 := by decide
theorem cert_e2212641824794 : check e2212641824794 [[]] .width = true := by decide
def e2212641824886 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212641824886 : Closed e2212641824886 ∧ code e2212641824886 = 11008734847094 := by decide
theorem cert_e2212641824886 : check e2212641824886 [[]] .width = true := by decide
def e2212641825130 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212641825130 : Closed e2212641825130 ∧ code e2212641825130 = 11008734847338 := by decide
theorem cert_e2212641825130 : check e2212641825130 [[]] .width = true := by decide
def e2212641825178 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212641825178 : Closed e2212641825178 ∧ code e2212641825178 = 11008734847386 := by decide
theorem cert_e2212641825178 : check e2212641825178 [[]] .width = true := by decide
def e2212641873946 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212641873946 : Closed e2212641873946 ∧ code e2212641873946 = 11008734896154 := by decide
theorem cert_e2212641873946 : check e2212641873946 [[]] .width = true := by decide
def e2212641874038 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212641874038 : Closed e2212641874038 ∧ code e2212641874038 = 11008734896246 := by decide
theorem cert_e2212641874038 : check e2212641874038 [[]] .width = true := by decide
def e2212641874282 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212641874282 : Closed e2212641874282 ∧ code e2212641874282 = 11008734896490 := by decide
theorem cert_e2212641874282 : check e2212641874282 [[]] .width = true := by decide
def e2212641874330 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212641874330 : Closed e2212641874330 ∧ code e2212641874330 = 11008734896538 := by decide
theorem cert_e2212641874330 : check e2212641874330 [[]] .width = true := by decide
def e2212641880090 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212641880090 : Closed e2212641880090 ∧ code e2212641880090 = 11008734902298 := by decide
theorem cert_e2212641880090 : check e2212641880090 [[]] .width = true := by decide
def e2212643659802 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212643659802 : Closed e2212643659802 ∧ code e2212643659802 = 11008736682010 := by decide
theorem cert_e2212643659802 : check e2212643659802 [[]] .width = true := by decide
def e2212643659894 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212643659894 : Closed e2212643659894 ∧ code e2212643659894 = 11008736682102 := by decide
theorem cert_e2212643659894 : check e2212643659894 [[]] .width = true := by decide
def e2212643660138 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212643660138 : Closed e2212643660138 ∧ code e2212643660138 = 11008736682346 := by decide
theorem cert_e2212643660138 : check e2212643660138 [[]] .width = true := by decide
def e2212643660186 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212643660186 : Closed e2212643660186 ∧ code e2212643660186 = 11008736682394 := by decide
theorem cert_e2212643660186 : check e2212643660186 [[]] .width = true := by decide
def e2212643692570 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212643692570 : Closed e2212643692570 ∧ code e2212643692570 = 11008736714778 := by decide
theorem cert_e2212643692570 : check e2212643692570 [[]] .width = true := by decide
def e2212643692662 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212643692662 : Closed e2212643692662 ∧ code e2212643692662 = 11008736714870 := by decide
theorem cert_e2212643692662 : check e2212643692662 [[]] .width = true := by decide
def e2212643692906 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212643692906 : Closed e2212643692906 ∧ code e2212643692906 = 11008736715114 := by decide
theorem cert_e2212643692906 : check e2212643692906 [[]] .width = true := by decide
def e2212643692954 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212643692954 : Closed e2212643692954 ∧ code e2212643692954 = 11008736715162 := by decide
theorem cert_e2212643692954 : check e2212643692954 [[]] .width = true := by decide
def e2212643921946 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212643921946 : Closed e2212643921946 ∧ code e2212643921946 = 11008736944154 := by decide
theorem cert_e2212643921946 : check e2212643921946 [[]] .width = true := by decide
def e2212643922038 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212643922038 : Closed e2212643922038 ∧ code e2212643922038 = 11008736944246 := by decide
theorem cert_e2212643922038 : check e2212643922038 [[]] .width = true := by decide
def e2212643922282 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212643922282 : Closed e2212643922282 ∧ code e2212643922282 = 11008736944490 := by decide
theorem cert_e2212643922282 : check e2212643922282 [[]] .width = true := by decide
def e2212643922330 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212643922330 : Closed e2212643922330 ∧ code e2212643922330 = 11008736944538 := by decide
theorem cert_e2212643922330 : check e2212643922330 [[]] .width = true := by decide
def e2212643971098 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212643971098 : Closed e2212643971098 ∧ code e2212643971098 = 11008736993306 := by decide
theorem cert_e2212643971098 : check e2212643971098 [[]] .width = true := by decide
def e2212643971190 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212643971190 : Closed e2212643971190 ∧ code e2212643971190 = 11008736993398 := by decide
theorem cert_e2212643971190 : check e2212643971190 [[]] .width = true := by decide
def e2212643971434 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212643971434 : Closed e2212643971434 ∧ code e2212643971434 = 11008736993642 := by decide
theorem cert_e2212643971434 : check e2212643971434 [[]] .width = true := by decide
def e2212643971482 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212643971482 : Closed e2212643971482 ∧ code e2212643971482 = 11008736993690 := by decide
theorem cert_e2212643971482 : check e2212643971482 [[]] .width = true := by decide
def e2212643977242 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212643977242 : Closed e2212643977242 ∧ code e2212643977242 = 11008736999450 := by decide
theorem cert_e2212643977242 : check e2212643977242 [[]] .width = true := by decide
def e2212644085786 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212644085786 : Closed e2212644085786 ∧ code e2212644085786 = 11008737107994 := by decide
theorem cert_e2212644085786 : check e2212644085786 [[]] .width = true := by decide
def e2212644085878 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212644085878 : Closed e2212644085878 ∧ code e2212644085878 = 11008737108086 := by decide
theorem cert_e2212644085878 : check e2212644085878 [[]] .width = true := by decide
def e2212644086122 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212644086122 : Closed e2212644086122 ∧ code e2212644086122 = 11008737108330 := by decide
theorem cert_e2212644086122 : check e2212644086122 [[]] .width = true := by decide
def e2212644086170 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212644086170 : Closed e2212644086170 ∧ code e2212644086170 = 11008737108378 := by decide
theorem cert_e2212644086170 : check e2212644086170 [[]] .width = true := by decide
def e2212644102170 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212644102170 : Closed e2212644102170 ∧ code e2212644102170 = 11008737124378 := by decide
theorem cert_e2212644102170 : check e2212644102170 [[]] .width = true := by decide
def e2212644102262 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212644102262 : Closed e2212644102262 ∧ code e2212644102262 = 11008737124470 := by decide
theorem cert_e2212644102262 : check e2212644102262 [[]] .width = true := by decide
def e2212644102506 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212644102506 : Closed e2212644102506 ∧ code e2212644102506 = 11008737124714 := by decide
theorem cert_e2212644102506 : check e2212644102506 [[]] .width = true := by decide
def e2212644102554 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212644102554 : Closed e2212644102554 ∧ code e2212644102554 = 11008737124762 := by decide
theorem cert_e2212644102554 : check e2212644102554 [[]] .width = true := by decide
def e2212644108314 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212644108314 : Closed e2212644108314 ∧ code e2212644108314 = 11008737130522 := by decide
theorem cert_e2212644108314 : check e2212644108314 [[]] .width = true := by decide
def e2212644116506 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212644116506 : Closed e2212644116506 ∧ code e2212644116506 = 11008737138714 := by decide
theorem cert_e2212644116506 : check e2212644116506 [[]] .width = true := by decide
def e2212662009882 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212662009882 : Closed e2212662009882 ∧ code e2212662009882 = 11008755032090 := by decide
theorem cert_e2212662009882 : check e2212662009882 [[]] .width = true := by decide
def e2212662009974 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212662009974 : Closed e2212662009974 ∧ code e2212662009974 = 11008755032182 := by decide
theorem cert_e2212662009974 : check e2212662009974 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2211758137462
#print axioms Blc.Floor43.cert_e2211758137706
#print axioms Blc.Floor43.cert_e2211758137754
#print axioms Blc.Floor43.cert_e2211758170230
#print axioms Blc.Floor43.cert_e2211758170474
#print axioms Blc.Floor43.cert_e2211758170522
#print axioms Blc.Floor43.cert_e2211760136310
#print axioms Blc.Floor43.cert_e2211760136554
#print axioms Blc.Floor43.cert_e2211760136602
#print axioms Blc.Floor43.cert_e2211760152694
#print axioms Blc.Floor43.cert_e2211760152938
#print axioms Blc.Floor43.cert_e2211760152986
#print axioms Blc.Floor43.cert_e2211760218230
#print axioms Blc.Floor43.cert_e2211760218474
#print axioms Blc.Floor43.cert_e2211760218522
#print axioms Blc.Floor43.cert_e2211760529526
#print axioms Blc.Floor43.cert_e2211760529770
#print axioms Blc.Floor43.cert_e2211760529818
#print axioms Blc.Floor43.cert_e2211760545910
#print axioms Blc.Floor43.cert_e2211760546154
#print axioms Blc.Floor43.cert_e2211760546202
#print axioms Blc.Floor43.cert_e2211760701934
#print axioms Blc.Floor43.cert_e2211760702938
#print axioms Blc.Floor43.cert_e2211760706986
#print axioms Blc.Floor43.cert_e2211760707178
#print axioms Blc.Floor43.cert_e2211760707202
#print axioms Blc.Floor43.cert_e2211760707226
#print axioms Blc.Floor43.cert_e2211760707702
#print axioms Blc.Floor43.cert_e2211760707946
#print axioms Blc.Floor43.cert_e2211760707994
#print axioms Blc.Floor43.cert_e2211760939126
#print axioms Blc.Floor43.cert_e2211760939370
#print axioms Blc.Floor43.cert_e2211760939418
#print axioms Blc.Floor43.cert_e2211760964078
#print axioms Blc.Floor43.cert_e2211760965082
#print axioms Blc.Floor43.cert_e2211760969130
#print axioms Blc.Floor43.cert_e2211760969322
#print axioms Blc.Floor43.cert_e2211760969346
#print axioms Blc.Floor43.cert_e2211760969370
#print axioms Blc.Floor43.cert_e2211760969846
#print axioms Blc.Floor43.cert_e2211760970090
#print axioms Blc.Floor43.cert_e2211760970138
