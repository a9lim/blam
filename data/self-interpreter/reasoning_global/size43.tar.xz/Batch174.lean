import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262377050910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2262377050910 : Closed e2262377050910 ∧ code e2262377050910 = 11058470073118 := by decide
theorem cert_e2262377050910 : check e2262377050910 [[],[.under]] .three = true := by decide
def e2262377051078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2262377051078 : Closed e2262377051078 ∧ code e2262377051078 = 11058470073286 := by decide
theorem cert_e2262377051078 : check e2262377051078 [[],[.under]] .three = true := by decide
def e2262377053382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2262377053382 : Closed e2262377053382 ∧ code e2262377053382 = 11058470075590 := by decide
theorem cert_e2262377053382 : check e2262377053382 [[],[.under]] .three = true := by decide
def e2262377060526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2262377060526 : Closed e2262377060526 ∧ code e2262377060526 = 11058470082734 := by decide
theorem cert_e2262377060526 : check e2262377060526 [[],[.under]] .three = true := by decide
def e2262377060538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2262377060538 : Closed e2262377060538 ∧ code e2262377060538 = 11058470082746 := by decide
theorem cert_e2262377060538 : check e2262377060538 [[],[.under]] .three = true := by decide
def e2262377060910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2262377060910 : Closed e2262377060910 ∧ code e2262377060910 = 11058470083118 := by decide
theorem cert_e2262377060910 : check e2262377060910 [[],[.under]] .three = true := by decide
def e2262377061090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2262377061090 : Closed e2262377061090 ∧ code e2262377061090 = 11058470083298 := by decide
theorem cert_e2262377061090 : check e2262377061090 [[],[.under]] .three = true := by decide
def e2262377061102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2262377061102 : Closed e2262377061102 ∧ code e2262377061102 = 11058470083310 := by decide
theorem cert_e2262377061102 : check e2262377061102 [[],[.under]] .three = true := by decide
def e2262377061230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2262377061230 : Closed e2262377061230 ∧ code e2262377061230 = 11058470083438 := by decide
theorem cert_e2262377061230 : check e2262377061230 [[],[.under]] .three = true := by decide
def e2262377061238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2262377061238 : Closed e2262377061238 ∧ code e2262377061238 = 11058470083446 := by decide
theorem cert_e2262377061238 : check e2262377061238 [[],[.under]] .three = true := by decide
def e2262377061258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262377061258 : Closed e2262377061258 ∧ code e2262377061258 = 11058470083466 := by decide
theorem cert_e2262377061258 : check e2262377061258 [[],[.under]] .three = true := by decide
def e2262377061282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262377061282 : Closed e2262377061282 ∧ code e2262377061282 = 11058470083490 := by decide
theorem cert_e2262377061282 : check e2262377061282 [[],[.under]] .three = true := by decide
def e2262377061294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2262377061294 : Closed e2262377061294 ∧ code e2262377061294 = 11058470083502 := by decide
theorem cert_e2262377061294 : check e2262377061294 [[],[.under]] .three = true := by decide
def e2262377061302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2262377061302 : Closed e2262377061302 ∧ code e2262377061302 = 11058470083510 := by decide
theorem cert_e2262377061302 : check e2262377061302 [[],[.under]] .three = true := by decide
def e2262377061306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2262377061306 : Closed e2262377061306 ∧ code e2262377061306 = 11058470083514 := by decide
theorem cert_e2262377061306 : check e2262377061306 [[],[.under]] .three = true := by decide
def e2262377061742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2262377061742 : Closed e2262377061742 ∧ code e2262377061742 = 11058470083950 := by decide
theorem cert_e2262377061742 : check e2262377061742 [[],[.under]] .three = true := by decide
def e2262377061750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2262377061750 : Closed e2262377061750 ∧ code e2262377061750 = 11058470083958 := by decide
theorem cert_e2262377061750 : check e2262377061750 [[],[.under]] .three = true := by decide
def e2262377061806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2262377061806 : Closed e2262377061806 ∧ code e2262377061806 = 11058470084014 := by decide
theorem cert_e2262377061806 : check e2262377061806 [[],[.under]] .three = true := by decide
def e2262377061818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2262377061818 : Closed e2262377061818 ∧ code e2262377061818 = 11058470084026 := by decide
theorem cert_e2262377061818 : check e2262377061818 [[],[.under]] .three = true := by decide
def e2262377061846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2262377061846 : Closed e2262377061846 ∧ code e2262377061846 = 11058470084054 := by decide
theorem cert_e2262377061846 : check e2262377061846 [[],[.under]] .three = true := by decide
def e2262377061850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2262377061850 : Closed e2262377061850 ∧ code e2262377061850 = 11058470084058 := by decide
theorem cert_e2262377061850 : check e2262377061850 [[],[.under]] .three = true := by decide
def e2262377061930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2262377061930 : Closed e2262377061930 ∧ code e2262377061930 = 11058470084138 := by decide
theorem cert_e2262377061930 : check e2262377061930 [[],[.under]] .three = true := by decide
def e2262377062026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262377062026 : Closed e2262377062026 ∧ code e2262377062026 = 11058470084234 := by decide
theorem cert_e2262377062026 : check e2262377062026 [[],[.under]] .three = true := by decide
def e2262377062050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262377062050 : Closed e2262377062050 ∧ code e2262377062050 = 11058470084258 := by decide
theorem cert_e2262377062050 : check e2262377062050 [[],[.under]] .three = true := by decide
def e2262377062062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2262377062062 : Closed e2262377062062 ∧ code e2262377062062 = 11058470084270 := by decide
theorem cert_e2262377062062 : check e2262377062062 [[],[.under]] .three = true := by decide
def e2262377062070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2262377062070 : Closed e2262377062070 ∧ code e2262377062070 = 11058470084278 := by decide
theorem cert_e2262377062070 : check e2262377062070 [[],[.under]] .three = true := by decide
def e2262377062074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2262377062074 : Closed e2262377062074 ∧ code e2262377062074 = 11058470084282 := by decide
theorem cert_e2262377062074 : check e2262377062074 [[],[.under]] .three = true := by decide
def e2262377062102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2262377062102 : Closed e2262377062102 ∧ code e2262377062102 = 11058470084310 := by decide
theorem cert_e2262377062102 : check e2262377062102 [[],[.under]] .three = true := by decide
def e2262377062106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2262377062106 : Closed e2262377062106 ∧ code e2262377062106 = 11058470084314 := by decide
theorem cert_e2262377062106 : check e2262377062106 [[],[.under]] .three = true := by decide
def e2262377062122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2262377062122 : Closed e2262377062122 ∧ code e2262377062122 = 11058470084330 := by decide
theorem cert_e2262377062122 : check e2262377062122 [[],[.under]] .three = true := by decide
def e2262377062638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2262377062638 : Closed e2262377062638 ∧ code e2262377062638 = 11058470084846 := by decide
theorem cert_e2262377062638 : check e2262377062638 [[],[.under]] .three = true := by decide
def e2262377062650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2262377062650 : Closed e2262377062650 ∧ code e2262377062650 = 11058470084858 := by decide
theorem cert_e2262377062650 : check e2262377062650 [[],[.under]] .three = true := by decide
def e2262377062830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2262377062830 : Closed e2262377062830 ∧ code e2262377062830 = 11058470085038 := by decide
theorem cert_e2262377062830 : check e2262377062830 [[],[.under]] .three = true := by decide
def e2262377063022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377063022 : Closed e2262377063022 ∧ code e2262377063022 = 11058470085230 := by decide
theorem cert_e2262377063022 : check e2262377063022 [[],[.under]] .three = true := by decide
def e2262377063034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377063034 : Closed e2262377063034 ∧ code e2262377063034 = 11058470085242 := by decide
theorem cert_e2262377063034 : check e2262377063034 [[],[.under]] .three = true := by decide
def e2262377063198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2262377063198 : Closed e2262377063198 ∧ code e2262377063198 = 11058470085406 := by decide
theorem cert_e2262377063198 : check e2262377063198 [[],[.under]] .three = true := by decide
def e2262377063366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2262377063366 : Closed e2262377063366 ∧ code e2262377063366 = 11058470085574 := by decide
theorem cert_e2262377063366 : check e2262377063366 [[],[.under]] .three = true := by decide
def e2262377063982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2262377063982 : Closed e2262377063982 ∧ code e2262377063982 = 11058470086190 := by decide
theorem cert_e2262377063982 : check e2262377063982 [[],[.under]] .three = true := by decide
def e2262377064162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2262377064162 : Closed e2262377064162 ∧ code e2262377064162 = 11058470086370 := by decide
theorem cert_e2262377064162 : check e2262377064162 [[],[.under]] .three = true := by decide
def e2262377064174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2262377064174 : Closed e2262377064174 ∧ code e2262377064174 = 11058470086382 := by decide
theorem cert_e2262377064174 : check e2262377064174 [[],[.under]] .three = true := by decide
def e2262377064302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2262377064302 : Closed e2262377064302 ∧ code e2262377064302 = 11058470086510 := by decide
theorem cert_e2262377064302 : check e2262377064302 [[],[.under]] .three = true := by decide
def e2262377064310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2262377064310 : Closed e2262377064310 ∧ code e2262377064310 = 11058470086518 := by decide
theorem cert_e2262377064310 : check e2262377064310 [[],[.under]] .three = true := by decide
def e2262377064330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2262377064330 : Closed e2262377064330 ∧ code e2262377064330 = 11058470086538 := by decide
theorem cert_e2262377064330 : check e2262377064330 [[],[.under]] .three = true := by decide
def e2262377064354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2262377064354 : Closed e2262377064354 ∧ code e2262377064354 = 11058470086562 := by decide
theorem cert_e2262377064354 : check e2262377064354 [[],[.under]] .three = true := by decide
def e2262377064366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2262377064366 : Closed e2262377064366 ∧ code e2262377064366 = 11058470086574 := by decide
theorem cert_e2262377064366 : check e2262377064366 [[],[.under]] .three = true := by decide
def e2262377064374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2262377064374 : Closed e2262377064374 ∧ code e2262377064374 = 11058470086582 := by decide
theorem cert_e2262377064374 : check e2262377064374 [[],[.under]] .three = true := by decide
def e2262377064378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2262377064378 : Closed e2262377064378 ∧ code e2262377064378 = 11058470086586 := by decide
theorem cert_e2262377064378 : check e2262377064378 [[],[.under]] .three = true := by decide
def e2262377064510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2262377064510 : Closed e2262377064510 ∧ code e2262377064510 = 11058470086718 := by decide
theorem cert_e2262377064510 : check e2262377064510 [[],[.under]] .three = true := by decide
def e2262377064930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2262377064930 : Closed e2262377064930 ∧ code e2262377064930 = 11058470087138 := by decide
theorem cert_e2262377064930 : check e2262377064930 [[],[.under]] .three = true := by decide
def e2262377064942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2262377064942 : Closed e2262377064942 ∧ code e2262377064942 = 11058470087150 := by decide
theorem cert_e2262377064942 : check e2262377064942 [[],[.under]] .three = true := by decide
def e2262377065710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262377065710 : Closed e2262377065710 ∧ code e2262377065710 = 11058470087918 := by decide
theorem cert_e2262377065710 : check e2262377065710 [[],[.under]] .three = true := by decide
def e2262377065718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262377065718 : Closed e2262377065718 ∧ code e2262377065718 = 11058470087926 := by decide
theorem cert_e2262377065718 : check e2262377065718 [[],[.under]] .three = true := by decide
def e2262377065998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2262377065998 : Closed e2262377065998 ∧ code e2262377065998 = 11058470088206 := by decide
theorem cert_e2262377065998 : check e2262377065998 [[],[.under]] .three = true := by decide
def e2262377066010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262377066010 : Closed e2262377066010 ∧ code e2262377066010 = 11058470088218 := by decide
theorem cert_e2262377066010 : check e2262377066010 [[],[.under]] .three = true := by decide
def e2262377066082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262377066082 : Closed e2262377066082 ∧ code e2262377066082 = 11058470088290 := by decide
theorem cert_e2262377066082 : check e2262377066082 [[],[.under]] .three = true := by decide
def e2262377066094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377066094 : Closed e2262377066094 ∧ code e2262377066094 = 11058470088302 := by decide
theorem cert_e2262377066094 : check e2262377066094 [[],[.under]] .three = true := by decide
def e2262377066102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2262377066102 : Closed e2262377066102 ∧ code e2262377066102 = 11058470088310 := by decide
theorem cert_e2262377066102 : check e2262377066102 [[],[.under]] .three = true := by decide
def e2262377066106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377066106 : Closed e2262377066106 ∧ code e2262377066106 = 11058470088314 := by decide
theorem cert_e2262377066106 : check e2262377066106 [[],[.under]] .three = true := by decide
def e2262377067374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2262377067374 : Closed e2262377067374 ∧ code e2262377067374 = 11058470089582 := by decide
theorem cert_e2262377067374 : check e2262377067374 [[],[.under]] .three = true := by decide
def e2262377067382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2262377067382 : Closed e2262377067382 ∧ code e2262377067382 = 11058470089590 := by decide
theorem cert_e2262377067382 : check e2262377067382 [[],[.under]] .three = true := by decide
def e2262377067438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2262377067438 : Closed e2262377067438 ∧ code e2262377067438 = 11058470089646 := by decide
theorem cert_e2262377067438 : check e2262377067438 [[],[.under]] .three = true := by decide
def e2262377067450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2262377067450 : Closed e2262377067450 ∧ code e2262377067450 = 11058470089658 := by decide
theorem cert_e2262377067450 : check e2262377067450 [[],[.under]] .three = true := by decide
def e2262377067478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2262377067478 : Closed e2262377067478 ∧ code e2262377067478 = 11058470089686 := by decide
theorem cert_e2262377067478 : check e2262377067478 [[],[.under]] .three = true := by decide
def e2262377067482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2262377067482 : Closed e2262377067482 ∧ code e2262377067482 = 11058470089690 := by decide
theorem cert_e2262377067482 : check e2262377067482 [[],[.under]] .three = true := by decide
def e2262377067758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262377067758 : Closed e2262377067758 ∧ code e2262377067758 = 11058470089966 := by decide
theorem cert_e2262377067758 : check e2262377067758 [[],[.under]] .three = true := by decide
def e2262377067766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262377067766 : Closed e2262377067766 ∧ code e2262377067766 = 11058470089974 := by decide
theorem cert_e2262377067766 : check e2262377067766 [[],[.under]] .three = true := by decide
def e2262377068142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377068142 : Closed e2262377068142 ∧ code e2262377068142 = 11058470090350 := by decide
theorem cert_e2262377068142 : check e2262377068142 [[],[.under]] .three = true := by decide
def e2262377068154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377068154 : Closed e2262377068154 ∧ code e2262377068154 = 11058470090362 := by decide
theorem cert_e2262377068154 : check e2262377068154 [[],[.under]] .three = true := by decide
def e2262377068342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377068342 : Closed e2262377068342 ∧ code e2262377068342 = 11058470090550 := by decide
theorem cert_e2262377068342 : check e2262377068342 [[],[.under]] .three = true := by decide
def e2262377068346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377068346 : Closed e2262377068346 ∧ code e2262377068346 = 11058470090554 := by decide
theorem cert_e2262377068346 : check e2262377068346 [[],[.under]] .three = true := by decide
def e2262377068602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2262377068602 : Closed e2262377068602 ∧ code e2262377068602 = 11058470090810 := by decide
theorem cert_e2262377068602 : check e2262377068602 [[],[.under]] .three = true := by decide
def e2262377068650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2262377068650 : Closed e2262377068650 ∧ code e2262377068650 = 11058470090858 := by decide
theorem cert_e2262377068650 : check e2262377068650 [[],[.under]] .three = true := by decide
def e2262377068698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262377068698 : Closed e2262377068698 ∧ code e2262377068698 = 11058470090906 := by decide
theorem cert_e2262377068698 : check e2262377068698 [[],[.under]] .three = true := by decide
def e2262377068742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2262377068742 : Closed e2262377068742 ∧ code e2262377068742 = 11058470090950 := by decide
theorem cert_e2262377068742 : check e2262377068742 [[],[.under]] .three = true := by decide
def e2262377068938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2262377068938 : Closed e2262377068938 ∧ code e2262377068938 = 11058470091146 := by decide
theorem cert_e2262377068938 : check e2262377068938 [[],[.under]] .three = true := by decide
def e2262377068962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2262377068962 : Closed e2262377068962 ∧ code e2262377068962 = 11058470091170 := by decide
theorem cert_e2262377068962 : check e2262377068962 [[],[.under]] .three = true := by decide
def e2262377068974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2262377068974 : Closed e2262377068974 ∧ code e2262377068974 = 11058470091182 := by decide
theorem cert_e2262377068974 : check e2262377068974 [[],[.under]] .three = true := by decide
def e2262377068982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2262377068982 : Closed e2262377068982 ∧ code e2262377068982 = 11058470091190 := by decide
theorem cert_e2262377068982 : check e2262377068982 [[],[.under]] .three = true := by decide
def e2262377068986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2262377068986 : Closed e2262377068986 ∧ code e2262377068986 = 11058470091194 := by decide
theorem cert_e2262377068986 : check e2262377068986 [[],[.under]] .three = true := by decide
def e2262377069014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2262377069014 : Closed e2262377069014 ∧ code e2262377069014 = 11058470091222 := by decide
theorem cert_e2262377069014 : check e2262377069014 [[],[.under]] .three = true := by decide
def e2262377069018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2262377069018 : Closed e2262377069018 ∧ code e2262377069018 = 11058470091226 := by decide
theorem cert_e2262377069018 : check e2262377069018 [[],[.under]] .three = true := by decide
def e2262377069034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2262377069034 : Closed e2262377069034 ∧ code e2262377069034 = 11058470091242 := by decide
theorem cert_e2262377069034 : check e2262377069034 [[],[.under]] .three = true := by decide
def e2262377069070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2262377069070 : Closed e2262377069070 ∧ code e2262377069070 = 11058470091278 := by decide
theorem cert_e2262377069070 : check e2262377069070 [[],[.under]] .three = true := by decide
def e2262377069082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262377069082 : Closed e2262377069082 ∧ code e2262377069082 = 11058470091290 := by decide
theorem cert_e2262377069082 : check e2262377069082 [[],[.under]] .three = true := by decide
def e2262377069154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262377069154 : Closed e2262377069154 ∧ code e2262377069154 = 11058470091362 := by decide
theorem cert_e2262377069154 : check e2262377069154 [[],[.under]] .three = true := by decide
def e2262377069166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377069166 : Closed e2262377069166 ∧ code e2262377069166 = 11058470091374 := by decide
theorem cert_e2262377069166 : check e2262377069166 [[],[.under]] .three = true := by decide
def e2262377069174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2262377069174 : Closed e2262377069174 ∧ code e2262377069174 = 11058470091382 := by decide
theorem cert_e2262377069174 : check e2262377069174 [[],[.under]] .three = true := by decide
def e2262377069178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377069178 : Closed e2262377069178 ∧ code e2262377069178 = 11058470091386 := by decide
theorem cert_e2262377069178 : check e2262377069178 [[],[.under]] .three = true := by decide
def e2262377069366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377069366 : Closed e2262377069366 ∧ code e2262377069366 = 11058470091574 := by decide
theorem cert_e2262377069366 : check e2262377069366 [[],[.under]] .three = true := by decide
def e2262377069370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377069370 : Closed e2262377069370 ∧ code e2262377069370 = 11058470091578 := by decide
theorem cert_e2262377069370 : check e2262377069370 [[],[.under]] .three = true := by decide
def e2262377069466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262377069466 : Closed e2262377069466 ∧ code e2262377069466 = 11058470091674 := by decide
theorem cert_e2262377069466 : check e2262377069466 [[],[.under]] .three = true := by decide
def e2262377072606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2262377072606 : Closed e2262377072606 ∧ code e2262377072606 = 11058470094814 := by decide
theorem cert_e2262377072606 : check e2262377072606 [[],[.under]] .three = true := by decide
def e2262377076270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262377076270 : Closed e2262377076270 ∧ code e2262377076270 = 11058470098478 := by decide
theorem cert_e2262377076270 : check e2262377076270 [[],[.under]] .three = true := by decide
def e2262377076450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262377076450 : Closed e2262377076450 ∧ code e2262377076450 = 11058470098658 := by decide
theorem cert_e2262377076450 : check e2262377076450 [[],[.under]] .three = true := by decide
def e2262377076462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2262377076462 : Closed e2262377076462 ∧ code e2262377076462 = 11058470098670 := by decide
theorem cert_e2262377076462 : check e2262377076462 [[],[.under]] .three = true := by decide
def e2262377076590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2262377076590 : Closed e2262377076590 ∧ code e2262377076590 = 11058470098798 := by decide
theorem cert_e2262377076590 : check e2262377076590 [[],[.under]] .three = true := by decide
def e2262377076598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2262377076598 : Closed e2262377076598 ∧ code e2262377076598 = 11058470098806 := by decide
theorem cert_e2262377076598 : check e2262377076598 [[],[.under]] .three = true := by decide
def e2262377076618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377076618 : Closed e2262377076618 ∧ code e2262377076618 = 11058470098826 := by decide
theorem cert_e2262377076618 : check e2262377076618 [[],[.under]] .three = true := by decide
def e2262377076642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377076642 : Closed e2262377076642 ∧ code e2262377076642 = 11058470098850 := by decide
theorem cert_e2262377076642 : check e2262377076642 [[],[.under]] .three = true := by decide
def e2262377076654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2262377076654 : Closed e2262377076654 ∧ code e2262377076654 = 11058470098862 := by decide
theorem cert_e2262377076654 : check e2262377076654 [[],[.under]] .three = true := by decide
def e2262377076662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2262377076662 : Closed e2262377076662 ∧ code e2262377076662 = 11058470098870 := by decide
theorem cert_e2262377076662 : check e2262377076662 [[],[.under]] .three = true := by decide
def e2262377076666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2262377076666 : Closed e2262377076666 ∧ code e2262377076666 = 11058470098874 := by decide
theorem cert_e2262377076666 : check e2262377076666 [[],[.under]] .three = true := by decide
def e2262377076798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2262377076798 : Closed e2262377076798 ∧ code e2262377076798 = 11058470099006 := by decide
theorem cert_e2262377076798 : check e2262377076798 [[],[.under]] .three = true := by decide
def e2262377077218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262377077218 : Closed e2262377077218 ∧ code e2262377077218 = 11058470099426 := by decide
theorem cert_e2262377077218 : check e2262377077218 [[],[.under]] .three = true := by decide
def e2262377077230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2262377077230 : Closed e2262377077230 ∧ code e2262377077230 = 11058470099438 := by decide
theorem cert_e2262377077230 : check e2262377077230 [[],[.under]] .three = true := by decide
def e2262377077998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377077998 : Closed e2262377077998 ∧ code e2262377077998 = 11058470100206 := by decide
theorem cert_e2262377077998 : check e2262377077998 [[],[.under]] .three = true := by decide
def e2262377078006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377078006 : Closed e2262377078006 ∧ code e2262377078006 = 11058470100214 := by decide
theorem cert_e2262377078006 : check e2262377078006 [[],[.under]] .three = true := by decide
def e2262377078286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377078286 : Closed e2262377078286 ∧ code e2262377078286 = 11058470100494 := by decide
theorem cert_e2262377078286 : check e2262377078286 [[],[.under]] .three = true := by decide
def e2262377078298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377078298 : Closed e2262377078298 ∧ code e2262377078298 = 11058470100506 := by decide
theorem cert_e2262377078298 : check e2262377078298 [[],[.under]] .three = true := by decide
def e2262377078370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377078370 : Closed e2262377078370 ∧ code e2262377078370 = 11058470100578 := by decide
theorem cert_e2262377078370 : check e2262377078370 [[],[.under]] .three = true := by decide
def e2262377078382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377078382 : Closed e2262377078382 ∧ code e2262377078382 = 11058470100590 := by decide
theorem cert_e2262377078382 : check e2262377078382 [[],[.under]] .three = true := by decide
def e2262377078390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377078390 : Closed e2262377078390 ∧ code e2262377078390 = 11058470100598 := by decide
theorem cert_e2262377078390 : check e2262377078390 [[],[.under]] .three = true := by decide
def e2262377078394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377078394 : Closed e2262377078394 ∧ code e2262377078394 = 11058470100602 := by decide
theorem cert_e2262377078394 : check e2262377078394 [[],[.under]] .three = true := by decide
def e2262377089902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262377089902 : Closed e2262377089902 ∧ code e2262377089902 = 11058470112110 := by decide
theorem cert_e2262377089902 : check e2262377089902 [[],[.under]] .three = true := by decide
def e2262377089910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262377089910 : Closed e2262377089910 ∧ code e2262377089910 = 11058470112118 := by decide
theorem cert_e2262377089910 : check e2262377089910 [[],[.under]] .three = true := by decide
def e2262377089966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262377089966 : Closed e2262377089966 ∧ code e2262377089966 = 11058470112174 := by decide
theorem cert_e2262377089966 : check e2262377089966 [[],[.under]] .three = true := by decide
def e2262377089978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262377089978 : Closed e2262377089978 ∧ code e2262377089978 = 11058470112186 := by decide
theorem cert_e2262377089978 : check e2262377089978 [[],[.under]] .three = true := by decide
def e2262377090006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262377090006 : Closed e2262377090006 ∧ code e2262377090006 = 11058470112214 := by decide
theorem cert_e2262377090006 : check e2262377090006 [[],[.under]] .three = true := by decide
def e2262377090010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262377090010 : Closed e2262377090010 ∧ code e2262377090010 = 11058470112218 := by decide
theorem cert_e2262377090010 : check e2262377090010 [[],[.under]] .three = true := by decide
def e2262377090286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377090286 : Closed e2262377090286 ∧ code e2262377090286 = 11058470112494 := by decide
theorem cert_e2262377090286 : check e2262377090286 [[],[.under]] .three = true := by decide
def e2262377090294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377090294 : Closed e2262377090294 ∧ code e2262377090294 = 11058470112502 := by decide
theorem cert_e2262377090294 : check e2262377090294 [[],[.under]] .three = true := by decide
def e2262377090670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377090670 : Closed e2262377090670 ∧ code e2262377090670 = 11058470112878 := by decide
theorem cert_e2262377090670 : check e2262377090670 [[],[.under]] .three = true := by decide
def e2262377090682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377090682 : Closed e2262377090682 ∧ code e2262377090682 = 11058470112890 := by decide
theorem cert_e2262377090682 : check e2262377090682 [[],[.under]] .three = true := by decide
def e2262377090870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377090870 : Closed e2262377090870 ∧ code e2262377090870 = 11058470113078 := by decide
theorem cert_e2262377090870 : check e2262377090870 [[],[.under]] .three = true := by decide
def e2262377090874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377090874 : Closed e2262377090874 ∧ code e2262377090874 = 11058470113082 := by decide
theorem cert_e2262377090874 : check e2262377090874 [[],[.under]] .three = true := by decide
def e2262377095646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2262377095646 : Closed e2262377095646 ∧ code e2262377095646 = 11058470117854 := by decide
theorem cert_e2262377095646 : check e2262377095646 [[],[.under]] .three = true := by decide
def e2262377095670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2262377095670 : Closed e2262377095670 ∧ code e2262377095670 = 11058470117878 := by decide
theorem cert_e2262377095670 : check e2262377095670 [[],[.under]] .three = true := by decide
def e2262377096586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377096586 : Closed e2262377096586 ∧ code e2262377096586 = 11058470118794 := by decide
theorem cert_e2262377096586 : check e2262377096586 [[],[.under]] .three = true := by decide
def e2262377096610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377096610 : Closed e2262377096610 ∧ code e2262377096610 = 11058470118818 := by decide
theorem cert_e2262377096610 : check e2262377096610 [[],[.under]] .three = true := by decide
def e2262377096622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2262377096622 : Closed e2262377096622 ∧ code e2262377096622 = 11058470118830 := by decide
theorem cert_e2262377096622 : check e2262377096622 [[],[.under]] .three = true := by decide
def e2262377096630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2262377096630 : Closed e2262377096630 ∧ code e2262377096630 = 11058470118838 := by decide
theorem cert_e2262377096630 : check e2262377096630 [[],[.under]] .three = true := by decide
def e2262377096634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2262377096634 : Closed e2262377096634 ∧ code e2262377096634 = 11058470118842 := by decide
theorem cert_e2262377096634 : check e2262377096634 [[],[.under]] .three = true := by decide
def e2262377096662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2262377096662 : Closed e2262377096662 ∧ code e2262377096662 = 11058470118870 := by decide
theorem cert_e2262377096662 : check e2262377096662 [[],[.under]] .three = true := by decide
def e2262377096666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2262377096666 : Closed e2262377096666 ∧ code e2262377096666 = 11058470118874 := by decide
theorem cert_e2262377096666 : check e2262377096666 [[],[.under]] .three = true := by decide
def e2262377096682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2262377096682 : Closed e2262377096682 ∧ code e2262377096682 = 11058470118890 := by decide
theorem cert_e2262377096682 : check e2262377096682 [[],[.under]] .three = true := by decide
def e2262377096718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377096718 : Closed e2262377096718 ∧ code e2262377096718 = 11058470118926 := by decide
theorem cert_e2262377096718 : check e2262377096718 [[],[.under]] .three = true := by decide
def e2262377096730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377096730 : Closed e2262377096730 ∧ code e2262377096730 = 11058470118938 := by decide
theorem cert_e2262377096730 : check e2262377096730 [[],[.under]] .three = true := by decide
def e2262377096802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377096802 : Closed e2262377096802 ∧ code e2262377096802 = 11058470119010 := by decide
theorem cert_e2262377096802 : check e2262377096802 [[],[.under]] .three = true := by decide
def e2262377096814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377096814 : Closed e2262377096814 ∧ code e2262377096814 = 11058470119022 := by decide
theorem cert_e2262377096814 : check e2262377096814 [[],[.under]] .three = true := by decide
def e2262377096822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377096822 : Closed e2262377096822 ∧ code e2262377096822 = 11058470119030 := by decide
theorem cert_e2262377096822 : check e2262377096822 [[],[.under]] .three = true := by decide
def e2262377096826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377096826 : Closed e2262377096826 ∧ code e2262377096826 = 11058470119034 := by decide
theorem cert_e2262377096826 : check e2262377096826 [[],[.under]] .three = true := by decide
def e2262377097014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377097014 : Closed e2262377097014 ∧ code e2262377097014 = 11058470119222 := by decide
theorem cert_e2262377097014 : check e2262377097014 [[],[.under]] .three = true := by decide
def e2262377097018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377097018 : Closed e2262377097018 ∧ code e2262377097018 = 11058470119226 := by decide
theorem cert_e2262377097018 : check e2262377097018 [[],[.under]] .three = true := by decide
def e2262377097114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2262377097114 : Closed e2262377097114 ∧ code e2262377097114 = 11058470119322 := by decide
theorem cert_e2262377097114 : check e2262377097114 [[],[.under]] .three = true := by decide
def e2262377105206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377105206 : Closed e2262377105206 ∧ code e2262377105206 = 11058470127414 := by decide
theorem cert_e2262377105206 : check e2262377105206 [[],[.under]] .three = true := by decide
def e2262377105210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377105210 : Closed e2262377105210 ∧ code e2262377105210 = 11058470127418 := by decide
theorem cert_e2262377105210 : check e2262377105210 [[],[.under]] .three = true := by decide
def e2262377105306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262377105306 : Closed e2262377105306 ∧ code e2262377105306 = 11058470127514 := by decide
theorem cert_e2262377105306 : check e2262377105306 [[],[.under]] .three = true := by decide
def e2262377106742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377106742 : Closed e2262377106742 ∧ code e2262377106742 = 11058470128950 := by decide
private def t_e2262377106742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem cert_e2262377106742 : ¬ IsSelfInterpreter e2262377106742 :=
  wSource (t := t_e2262377106742) (replay_sound (ps := []) (t := e2262377106742) (by decide)) (by decide)
def e2262377106746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377106746 : Closed e2262377106746 ∧ code e2262377106746 = 11058470128954 := by decide
private def t_e2262377106746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem cert_e2262377106746 : ¬ IsSelfInterpreter e2262377106746 :=
  wSource (t := t_e2262377106746) (replay_sound (ps := []) (t := e2262377106746) (by decide)) (by decide)
def e2262377107182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2262377107182 : Closed e2262377107182 ∧ code e2262377107182 = 11058470129390 := by decide
theorem cert_e2262377107182 : check e2262377107182 [[],[.under]] .three = true := by decide
def e2262377107190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2262377107190 : Closed e2262377107190 ∧ code e2262377107190 = 11058470129398 := by decide
theorem cert_e2262377107190 : check e2262377107190 [[],[.under]] .three = true := by decide
def e2262377107310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2262377107310 : Closed e2262377107310 ∧ code e2262377107310 = 11058470129518 := by decide
theorem cert_e2262377107310 : check e2262377107310 [[],[.under]] .three = true := by decide
def e2262377107322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2262377107322 : Closed e2262377107322 ∧ code e2262377107322 = 11058470129530 := by decide
theorem cert_e2262377107322 : check e2262377107322 [[],[.under]] .three = true := by decide
def e2262377107382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2262377107382 : Closed e2262377107382 ∧ code e2262377107382 = 11058470129590 := by decide
theorem cert_e2262377107382 : check e2262377107382 [[],[.under]] .three = true := by decide
def e2262377107386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2262377107386 : Closed e2262377107386 ∧ code e2262377107386 = 11058470129594 := by decide
theorem cert_e2262377107386 : check e2262377107386 [[],[.under]] .three = true := by decide
def e2262377108182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2262377108182 : Closed e2262377108182 ∧ code e2262377108182 = 11058470130390 := by decide
theorem cert_e2262377108182 : check e2262377108182 [[],[.under]] .three = true := by decide
def e2262377108186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2262377108186 : Closed e2262377108186 ∧ code e2262377108186 = 11058470130394 := by decide
theorem cert_e2262377108186 : check e2262377108186 [[],[.under]] .three = true := by decide
def e2262377108202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2262377108202 : Closed e2262377108202 ∧ code e2262377108202 = 11058470130410 := by decide
theorem cert_e2262377108202 : check e2262377108202 [[],[.under]] .three = true := by decide
def e2262377108278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377108278 : Closed e2262377108278 ∧ code e2262377108278 = 11058470130486 := by decide
theorem cert_e2262377108278 : check e2262377108278 [[],[.under]] .three = true := by decide
def e2262377108282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377108282 : Closed e2262377108282 ∧ code e2262377108282 = 11058470130490 := by decide
theorem cert_e2262377108282 : check e2262377108282 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262377106742
#print axioms Blc.Floor43.cert_e2262377106746
