import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262376957838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2262376957838 : Closed e2262376957838 ∧ code e2262376957838 = 11058469980046 := by decide
theorem cert_e2262376957838 : check e2262376957838 [[],[.under]] .three = true := by decide
def e2262376959534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2262376959534 : Closed e2262376959534 ∧ code e2262376959534 = 11058469981742 := by decide
theorem cert_e2262376959534 : check e2262376959534 [[],[.under]] .three = true := by decide
def e2262376959714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2262376959714 : Closed e2262376959714 ∧ code e2262376959714 = 11058469981922 := by decide
theorem cert_e2262376959714 : check e2262376959714 [[],[.under]] .three = true := by decide
def e2262376959726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2262376959726 : Closed e2262376959726 ∧ code e2262376959726 = 11058469981934 := by decide
theorem cert_e2262376959726 : check e2262376959726 [[],[.under]] .three = true := by decide
def e2262376959766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2262376959766 : Closed e2262376959766 ∧ code e2262376959766 = 11058469981974 := by decide
theorem cert_e2262376959766 : check e2262376959766 [[],[.under]] .three = true := by decide
def e2262376959842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2262376959842 : Closed e2262376959842 ∧ code e2262376959842 = 11058469982050 := by decide
theorem cert_e2262376959842 : check e2262376959842 [[],[.under]] .three = true := by decide
def e2262376959854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2262376959854 : Closed e2262376959854 ∧ code e2262376959854 = 11058469982062 := by decide
theorem cert_e2262376959854 : check e2262376959854 [[],[.under]] .three = true := by decide
def e2262376959862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2262376959862 : Closed e2262376959862 ∧ code e2262376959862 = 11058469982070 := by decide
theorem cert_e2262376959862 : check e2262376959862 [[],[.under]] .three = true := by decide
def e2262376962110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2262376962110 : Closed e2262376962110 ∧ code e2262376962110 = 11058469984318 := by decide
theorem cert_e2262376962110 : check e2262376962110 [[],[.under]] .three = true := by decide
def e2262376962530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2262376962530 : Closed e2262376962530 ∧ code e2262376962530 = 11058469984738 := by decide
theorem cert_e2262376962530 : check e2262376962530 [[],[.under]] .three = true := by decide
def e2262376962542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2262376962542 : Closed e2262376962542 ∧ code e2262376962542 = 11058469984750 := by decide
theorem cert_e2262376962542 : check e2262376962542 [[],[.under]] .three = true := by decide
def e2262376963102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2262376963102 : Closed e2262376963102 ∧ code e2262376963102 = 11058469985310 := by decide
theorem cert_e2262376963102 : check e2262376963102 [[],[.under]] .three = true := by decide
def e2262376963298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2262376963298 : Closed e2262376963298 ∧ code e2262376963298 = 11058469985506 := by decide
theorem cert_e2262376963298 : check e2262376963298 [[],[.under]] .three = true := by decide
def e2262376963310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376963310 : Closed e2262376963310 ∧ code e2262376963310 = 11058469985518 := by decide
theorem cert_e2262376963310 : check e2262376963310 [[],[.under]] .three = true := by decide
def e2262376963318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376963318 : Closed e2262376963318 ∧ code e2262376963318 = 11058469985526 := by decide
theorem cert_e2262376963318 : check e2262376963318 [[],[.under]] .three = true := by decide
def e2262376964334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2262376964334 : Closed e2262376964334 ∧ code e2262376964334 = 11058469986542 := by decide
theorem cert_e2262376964334 : check e2262376964334 [[],[.under]] .three = true := by decide
def e2262376964346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2262376964346 : Closed e2262376964346 ∧ code e2262376964346 = 11058469986554 := by decide
theorem cert_e2262376964346 : check e2262376964346 [[],[.under]] .three = true := by decide
def e2262376964526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2262376964526 : Closed e2262376964526 ∧ code e2262376964526 = 11058469986734 := by decide
theorem cert_e2262376964526 : check e2262376964526 [[],[.under]] .three = true := by decide
def e2262376964718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376964718 : Closed e2262376964718 ∧ code e2262376964718 = 11058469986926 := by decide
theorem cert_e2262376964718 : check e2262376964718 [[],[.under]] .three = true := by decide
def e2262376964730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376964730 : Closed e2262376964730 ∧ code e2262376964730 = 11058469986938 := by decide
theorem cert_e2262376964730 : check e2262376964730 [[],[.under]] .three = true := by decide
def e2262376964894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2262376964894 : Closed e2262376964894 ∧ code e2262376964894 = 11058469987102 := by decide
theorem cert_e2262376964894 : check e2262376964894 [[],[.under]] .three = true := by decide
def e2262376965062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2262376965062 : Closed e2262376965062 ∧ code e2262376965062 = 11058469987270 := by decide
theorem cert_e2262376965062 : check e2262376965062 [[],[.under]] .three = true := by decide
def e2262376965678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2262376965678 : Closed e2262376965678 ∧ code e2262376965678 = 11058469987886 := by decide
theorem cert_e2262376965678 : check e2262376965678 [[],[.under]] .three = true := by decide
def e2262376965858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2262376965858 : Closed e2262376965858 ∧ code e2262376965858 = 11058469988066 := by decide
theorem cert_e2262376965858 : check e2262376965858 [[],[.under]] .three = true := by decide
def e2262376965870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2262376965870 : Closed e2262376965870 ∧ code e2262376965870 = 11058469988078 := by decide
theorem cert_e2262376965870 : check e2262376965870 [[],[.under]] .three = true := by decide
def e2262376965998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2262376965998 : Closed e2262376965998 ∧ code e2262376965998 = 11058469988206 := by decide
theorem cert_e2262376965998 : check e2262376965998 [[],[.under]] .three = true := by decide
def e2262376966006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2262376966006 : Closed e2262376966006 ∧ code e2262376966006 = 11058469988214 := by decide
theorem cert_e2262376966006 : check e2262376966006 [[],[.under]] .three = true := by decide
def e2262376966026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2262376966026 : Closed e2262376966026 ∧ code e2262376966026 = 11058469988234 := by decide
theorem cert_e2262376966026 : check e2262376966026 [[],[.under]] .three = true := by decide
def e2262376966050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2262376966050 : Closed e2262376966050 ∧ code e2262376966050 = 11058469988258 := by decide
theorem cert_e2262376966050 : check e2262376966050 [[],[.under]] .three = true := by decide
def e2262376966062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2262376966062 : Closed e2262376966062 ∧ code e2262376966062 = 11058469988270 := by decide
theorem cert_e2262376966062 : check e2262376966062 [[],[.under]] .three = true := by decide
def e2262376966070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2262376966070 : Closed e2262376966070 ∧ code e2262376966070 = 11058469988278 := by decide
theorem cert_e2262376966070 : check e2262376966070 [[],[.under]] .three = true := by decide
def e2262376966074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2262376966074 : Closed e2262376966074 ∧ code e2262376966074 = 11058469988282 := by decide
theorem cert_e2262376966074 : check e2262376966074 [[],[.under]] .three = true := by decide
def e2262376966206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2262376966206 : Closed e2262376966206 ∧ code e2262376966206 = 11058469988414 := by decide
theorem cert_e2262376966206 : check e2262376966206 [[],[.under]] .three = true := by decide
def e2262376966626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2262376966626 : Closed e2262376966626 ∧ code e2262376966626 = 11058469988834 := by decide
theorem cert_e2262376966626 : check e2262376966626 [[],[.under]] .three = true := by decide
def e2262376966638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2262376966638 : Closed e2262376966638 ∧ code e2262376966638 = 11058469988846 := by decide
theorem cert_e2262376966638 : check e2262376966638 [[],[.under]] .three = true := by decide
def e2262376967406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376967406 : Closed e2262376967406 ∧ code e2262376967406 = 11058469989614 := by decide
theorem cert_e2262376967406 : check e2262376967406 [[],[.under]] .three = true := by decide
def e2262376967414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376967414 : Closed e2262376967414 ∧ code e2262376967414 = 11058469989622 := by decide
theorem cert_e2262376967414 : check e2262376967414 [[],[.under]] .three = true := by decide
def e2262376967694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2262376967694 : Closed e2262376967694 ∧ code e2262376967694 = 11058469989902 := by decide
theorem cert_e2262376967694 : check e2262376967694 [[],[.under]] .three = true := by decide
def e2262376967706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376967706 : Closed e2262376967706 ∧ code e2262376967706 = 11058469989914 := by decide
theorem cert_e2262376967706 : check e2262376967706 [[],[.under]] .three = true := by decide
def e2262376967778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376967778 : Closed e2262376967778 ∧ code e2262376967778 = 11058469989986 := by decide
theorem cert_e2262376967778 : check e2262376967778 [[],[.under]] .three = true := by decide
def e2262376967790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376967790 : Closed e2262376967790 ∧ code e2262376967790 = 11058469989998 := by decide
theorem cert_e2262376967790 : check e2262376967790 [[],[.under]] .three = true := by decide
def e2262376967798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376967798 : Closed e2262376967798 ∧ code e2262376967798 = 11058469990006 := by decide
theorem cert_e2262376967798 : check e2262376967798 [[],[.under]] .three = true := by decide
def e2262376967802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376967802 : Closed e2262376967802 ∧ code e2262376967802 = 11058469990010 := by decide
theorem cert_e2262376967802 : check e2262376967802 [[],[.under]] .three = true := by decide
def e2262376968310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2262376968310 : Closed e2262376968310 ∧ code e2262376968310 = 11058469990518 := by decide
theorem cert_e2262376968310 : check e2262376968310 [[],[.under]] .three = true := by decide
def e2262376968314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2262376968314 : Closed e2262376968314 ∧ code e2262376968314 = 11058469990522 := by decide
theorem cert_e2262376968314 : check e2262376968314 [[],[.under]] .three = true := by decide
def e2262376968406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2262376968406 : Closed e2262376968406 ∧ code e2262376968406 = 11058469990614 := by decide
theorem cert_e2262376968406 : check e2262376968406 [[],[.under]] .three = true := by decide
def e2262376968502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376968502 : Closed e2262376968502 ∧ code e2262376968502 = 11058469990710 := by decide
theorem cert_e2262376968502 : check e2262376968502 [[],[.under]] .three = true := by decide
def e2262376968506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376968506 : Closed e2262376968506 ∧ code e2262376968506 = 11058469990714 := by decide
theorem cert_e2262376968506 : check e2262376968506 [[],[.under]] .three = true := by decide
def e2262376968590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2262376968590 : Closed e2262376968590 ∧ code e2262376968590 = 11058469990798 := by decide
theorem cert_e2262376968590 : check e2262376968590 [[],[.under]] .three = true := by decide
def e2262376968646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2262376968646 : Closed e2262376968646 ∧ code e2262376968646 = 11058469990854 := by decide
theorem cert_e2262376968646 : check e2262376968646 [[],[.under]] .three = true := by decide
def e2262376968982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2262376968982 : Closed e2262376968982 ∧ code e2262376968982 = 11058469991190 := by decide
theorem cert_e2262376968982 : check e2262376968982 [[],[.under]] .three = true := by decide
def e2262376969058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2262376969058 : Closed e2262376969058 ∧ code e2262376969058 = 11058469991266 := by decide
theorem cert_e2262376969058 : check e2262376969058 [[],[.under]] .three = true := by decide
def e2262376969070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2262376969070 : Closed e2262376969070 ∧ code e2262376969070 = 11058469991278 := by decide
theorem cert_e2262376969070 : check e2262376969070 [[],[.under]] .three = true := by decide
def e2262376969078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2262376969078 : Closed e2262376969078 ∧ code e2262376969078 = 11058469991286 := by decide
theorem cert_e2262376969078 : check e2262376969078 [[],[.under]] .three = true := by decide
def e2262376969098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2262376969098 : Closed e2262376969098 ∧ code e2262376969098 = 11058469991306 := by decide
theorem cert_e2262376969098 : check e2262376969098 [[],[.under]] .three = true := by decide
def e2262376969122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2262376969122 : Closed e2262376969122 ∧ code e2262376969122 = 11058469991330 := by decide
theorem cert_e2262376969122 : check e2262376969122 [[],[.under]] .three = true := by decide
def e2262376969134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2262376969134 : Closed e2262376969134 ∧ code e2262376969134 = 11058469991342 := by decide
theorem cert_e2262376969134 : check e2262376969134 [[],[.under]] .three = true := by decide
def e2262376969142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2262376969142 : Closed e2262376969142 ∧ code e2262376969142 = 11058469991350 := by decide
theorem cert_e2262376969142 : check e2262376969142 [[],[.under]] .three = true := by decide
def e2262376969146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2262376969146 : Closed e2262376969146 ∧ code e2262376969146 = 11058469991354 := by decide
theorem cert_e2262376969146 : check e2262376969146 [[],[.under]] .three = true := by decide
def e2262376969174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2262376969174 : Closed e2262376969174 ∧ code e2262376969174 = 11058469991382 := by decide
theorem cert_e2262376969174 : check e2262376969174 [[],[.under]] .three = true := by decide
def e2262376969178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2262376969178 : Closed e2262376969178 ∧ code e2262376969178 = 11058469991386 := by decide
theorem cert_e2262376969178 : check e2262376969178 [[],[.under]] .three = true := by decide
def e2262376969246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2262376969246 : Closed e2262376969246 ∧ code e2262376969246 = 11058469991454 := by decide
theorem cert_e2262376969246 : check e2262376969246 [[],[.under]] .three = true := by decide
def e2262376969442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2262376969442 : Closed e2262376969442 ∧ code e2262376969442 = 11058469991650 := by decide
theorem cert_e2262376969442 : check e2262376969442 [[],[.under]] .three = true := by decide
def e2262376969454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376969454 : Closed e2262376969454 ∧ code e2262376969454 = 11058469991662 := by decide
theorem cert_e2262376969454 : check e2262376969454 [[],[.under]] .three = true := by decide
def e2262376969462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376969462 : Closed e2262376969462 ∧ code e2262376969462 = 11058469991670 := by decide
theorem cert_e2262376969462 : check e2262376969462 [[],[.under]] .three = true := by decide
def e2262376969742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2262376969742 : Closed e2262376969742 ∧ code e2262376969742 = 11058469991950 := by decide
theorem cert_e2262376969742 : check e2262376969742 [[],[.under]] .three = true := by decide
def e2262376969754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376969754 : Closed e2262376969754 ∧ code e2262376969754 = 11058469991962 := by decide
theorem cert_e2262376969754 : check e2262376969754 [[],[.under]] .three = true := by decide
def e2262376969826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376969826 : Closed e2262376969826 ∧ code e2262376969826 = 11058469992034 := by decide
theorem cert_e2262376969826 : check e2262376969826 [[],[.under]] .three = true := by decide
def e2262376969838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376969838 : Closed e2262376969838 ∧ code e2262376969838 = 11058469992046 := by decide
theorem cert_e2262376969838 : check e2262376969838 [[],[.under]] .three = true := by decide
def e2262376969846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376969846 : Closed e2262376969846 ∧ code e2262376969846 = 11058469992054 := by decide
theorem cert_e2262376969846 : check e2262376969846 [[],[.under]] .three = true := by decide
def e2262376969850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376969850 : Closed e2262376969850 ∧ code e2262376969850 = 11058469992058 := by decide
theorem cert_e2262376969850 : check e2262376969850 [[],[.under]] .three = true := by decide
def e2262376970038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376970038 : Closed e2262376970038 ∧ code e2262376970038 = 11058469992246 := by decide
theorem cert_e2262376970038 : check e2262376970038 [[],[.under]] .three = true := by decide
def e2262376970042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376970042 : Closed e2262376970042 ∧ code e2262376970042 = 11058469992250 := by decide
theorem cert_e2262376970042 : check e2262376970042 [[],[.under]] .three = true := by decide
def e2262376975214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262376975214 : Closed e2262376975214 ∧ code e2262376975214 = 11058469997422 := by decide
theorem cert_e2262376975214 : check e2262376975214 [[],[.under]] .smaller = true := by decide
def e2262376975222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262376975222 : Closed e2262376975222 ∧ code e2262376975222 = 11058469997430 := by decide
theorem cert_e2262376975222 : check e2262376975222 [[],[.under]] .smaller = true := by decide
def e2262376975278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262376975278 : Closed e2262376975278 ∧ code e2262376975278 = 11058469997486 := by decide
theorem cert_e2262376975278 : check e2262376975278 [[],[.under]] .smaller = true := by decide
def e2262376975290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262376975290 : Closed e2262376975290 ∧ code e2262376975290 = 11058469997498 := by decide
theorem cert_e2262376975290 : check e2262376975290 [[],[.under]] .smaller = true := by decide
def e2262376975318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262376975318 : Closed e2262376975318 ∧ code e2262376975318 = 11058469997526 := by decide
theorem cert_e2262376975318 : check e2262376975318 [[],[.under]] .smaller = true := by decide
def e2262376975322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262376975322 : Closed e2262376975322 ∧ code e2262376975322 = 11058469997530 := by decide
theorem cert_e2262376975322 : check e2262376975322 [[],[.under]] .smaller = true := by decide
def e2262376975598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262376975598 : Closed e2262376975598 ∧ code e2262376975598 = 11058469997806 := by decide
theorem cert_e2262376975598 : check e2262376975598 [[],[.under]] .smaller = true := by decide
def e2262376975606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262376975606 : Closed e2262376975606 ∧ code e2262376975606 = 11058469997814 := by decide
theorem cert_e2262376975606 : check e2262376975606 [[],[.under]] .smaller = true := by decide
def e2262376975982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262376975982 : Closed e2262376975982 ∧ code e2262376975982 = 11058469998190 := by decide
theorem cert_e2262376975982 : check e2262376975982 [[],[.under]] .smaller = true := by decide
def e2262376975994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262376975994 : Closed e2262376975994 ∧ code e2262376975994 = 11058469998202 := by decide
theorem cert_e2262376975994 : check e2262376975994 [[],[.under]] .smaller = true := by decide
def e2262376976182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262376976182 : Closed e2262376976182 ∧ code e2262376976182 = 11058469998390 := by decide
theorem cert_e2262376976182 : check e2262376976182 [[],[.under]] .smaller = true := by decide
def e2262376976186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262376976186 : Closed e2262376976186 ∧ code e2262376976186 = 11058469998394 := by decide
theorem cert_e2262376976186 : check e2262376976186 [[],[.under]] .smaller = true := by decide
def e2262376984110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262376984110 : Closed e2262376984110 ∧ code e2262376984110 = 11058470006318 := by decide
theorem cert_e2262376984110 : check e2262376984110 [[],[.under]] .three = true := by decide
def e2262376984290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262376984290 : Closed e2262376984290 ∧ code e2262376984290 = 11058470006498 := by decide
theorem cert_e2262376984290 : check e2262376984290 [[],[.under]] .three = true := by decide
def e2262376984302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2262376984302 : Closed e2262376984302 ∧ code e2262376984302 = 11058470006510 := by decide
theorem cert_e2262376984302 : check e2262376984302 [[],[.under]] .three = true := by decide
def e2262376984342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262376984342 : Closed e2262376984342 ∧ code e2262376984342 = 11058470006550 := by decide
theorem cert_e2262376984342 : check e2262376984342 [[],[.under]] .three = true := by decide
def e2262376984418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262376984418 : Closed e2262376984418 ∧ code e2262376984418 = 11058470006626 := by decide
theorem cert_e2262376984418 : check e2262376984418 [[],[.under]] .three = true := by decide
def e2262376984430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2262376984430 : Closed e2262376984430 ∧ code e2262376984430 = 11058470006638 := by decide
theorem cert_e2262376984430 : check e2262376984430 [[],[.under]] .three = true := by decide
def e2262376984438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2262376984438 : Closed e2262376984438 ∧ code e2262376984438 = 11058470006646 := by decide
theorem cert_e2262376984438 : check e2262376984438 [[],[.under]] .three = true := by decide
def e2262376986686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2262376986686 : Closed e2262376986686 ∧ code e2262376986686 = 11058470008894 := by decide
theorem cert_e2262376986686 : check e2262376986686 [[],[.under]] .three = true := by decide
def e2262376987106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262376987106 : Closed e2262376987106 ∧ code e2262376987106 = 11058470009314 := by decide
theorem cert_e2262376987106 : check e2262376987106 [[],[.under]] .three = true := by decide
def e2262376987118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2262376987118 : Closed e2262376987118 ∧ code e2262376987118 = 11058470009326 := by decide
theorem cert_e2262376987118 : check e2262376987118 [[],[.under]] .three = true := by decide
def e2262376987678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2262376987678 : Closed e2262376987678 ∧ code e2262376987678 = 11058470009886 := by decide
theorem cert_e2262376987678 : check e2262376987678 [[],[.under]] .three = true := by decide
def e2262376987874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262376987874 : Closed e2262376987874 ∧ code e2262376987874 = 11058470010082 := by decide
theorem cert_e2262376987874 : check e2262376987874 [[],[.under]] .three = true := by decide
def e2262376987886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2262376987886 : Closed e2262376987886 ∧ code e2262376987886 = 11058470010094 := by decide
theorem cert_e2262376987886 : check e2262376987886 [[],[.under]] .three = true := by decide
def e2262376987894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2262376987894 : Closed e2262376987894 ∧ code e2262376987894 = 11058470010102 := by decide
theorem cert_e2262376987894 : check e2262376987894 [[],[.under]] .three = true := by decide
def e2262377007070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2262377007070 : Closed e2262377007070 ∧ code e2262377007070 = 11058470029278 := by decide
theorem cert_e2262377007070 : check e2262377007070 [[],[.under]] .three = true := by decide
def e2262377010734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262377010734 : Closed e2262377010734 ∧ code e2262377010734 = 11058470032942 := by decide
theorem cert_e2262377010734 : check e2262377010734 [[],[.under]] .three = true := by decide
def e2262377010914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262377010914 : Closed e2262377010914 ∧ code e2262377010914 = 11058470033122 := by decide
theorem cert_e2262377010914 : check e2262377010914 [[],[.under]] .three = true := by decide
def e2262377010926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2262377010926 : Closed e2262377010926 ∧ code e2262377010926 = 11058470033134 := by decide
theorem cert_e2262377010926 : check e2262377010926 [[],[.under]] .three = true := by decide
def e2262377011054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2262377011054 : Closed e2262377011054 ∧ code e2262377011054 = 11058470033262 := by decide
theorem cert_e2262377011054 : check e2262377011054 [[],[.under]] .three = true := by decide
def e2262377011062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2262377011062 : Closed e2262377011062 ∧ code e2262377011062 = 11058470033270 := by decide
theorem cert_e2262377011062 : check e2262377011062 [[],[.under]] .three = true := by decide
def e2262377011082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377011082 : Closed e2262377011082 ∧ code e2262377011082 = 11058470033290 := by decide
theorem cert_e2262377011082 : check e2262377011082 [[],[.under]] .three = true := by decide
def e2262377011106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377011106 : Closed e2262377011106 ∧ code e2262377011106 = 11058470033314 := by decide
theorem cert_e2262377011106 : check e2262377011106 [[],[.under]] .three = true := by decide
def e2262377011118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2262377011118 : Closed e2262377011118 ∧ code e2262377011118 = 11058470033326 := by decide
theorem cert_e2262377011118 : check e2262377011118 [[],[.under]] .three = true := by decide
def e2262377011126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2262377011126 : Closed e2262377011126 ∧ code e2262377011126 = 11058470033334 := by decide
theorem cert_e2262377011126 : check e2262377011126 [[],[.under]] .three = true := by decide
def e2262377011130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2262377011130 : Closed e2262377011130 ∧ code e2262377011130 = 11058470033338 := by decide
theorem cert_e2262377011130 : check e2262377011130 [[],[.under]] .three = true := by decide
def e2262377011262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2262377011262 : Closed e2262377011262 ∧ code e2262377011262 = 11058470033470 := by decide
theorem cert_e2262377011262 : check e2262377011262 [[],[.under]] .three = true := by decide
def e2262377011682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262377011682 : Closed e2262377011682 ∧ code e2262377011682 = 11058470033890 := by decide
theorem cert_e2262377011682 : check e2262377011682 [[],[.under]] .three = true := by decide
def e2262377011694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2262377011694 : Closed e2262377011694 ∧ code e2262377011694 = 11058470033902 := by decide
theorem cert_e2262377011694 : check e2262377011694 [[],[.under]] .three = true := by decide
def e2262377012462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377012462 : Closed e2262377012462 ∧ code e2262377012462 = 11058470034670 := by decide
theorem cert_e2262377012462 : check e2262377012462 [[],[.under]] .three = true := by decide
def e2262377012470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377012470 : Closed e2262377012470 ∧ code e2262377012470 = 11058470034678 := by decide
theorem cert_e2262377012470 : check e2262377012470 [[],[.under]] .three = true := by decide
def e2262377012750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377012750 : Closed e2262377012750 ∧ code e2262377012750 = 11058470034958 := by decide
theorem cert_e2262377012750 : check e2262377012750 [[],[.under]] .three = true := by decide
def e2262377012762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377012762 : Closed e2262377012762 ∧ code e2262377012762 = 11058470034970 := by decide
theorem cert_e2262377012762 : check e2262377012762 [[],[.under]] .three = true := by decide
def e2262377012834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377012834 : Closed e2262377012834 ∧ code e2262377012834 = 11058470035042 := by decide
theorem cert_e2262377012834 : check e2262377012834 [[],[.under]] .three = true := by decide
def e2262377012846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377012846 : Closed e2262377012846 ∧ code e2262377012846 = 11058470035054 := by decide
theorem cert_e2262377012846 : check e2262377012846 [[],[.under]] .three = true := by decide
def e2262377012854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377012854 : Closed e2262377012854 ∧ code e2262377012854 = 11058470035062 := by decide
theorem cert_e2262377012854 : check e2262377012854 [[],[.under]] .three = true := by decide
def e2262377012858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377012858 : Closed e2262377012858 ∧ code e2262377012858 = 11058470035066 := by decide
theorem cert_e2262377012858 : check e2262377012858 [[],[.under]] .three = true := by decide
def e2262377022430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2262377022430 : Closed e2262377022430 ∧ code e2262377022430 = 11058470044638 := by decide
theorem cert_e2262377022430 : check e2262377022430 [[],[.under]] .three = true := by decide
def e2262377022446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2262377022446 : Closed e2262377022446 ∧ code e2262377022446 = 11058470044654 := by decide
theorem cert_e2262377022446 : check e2262377022446 [[],[.under]] .three = true := by decide
def e2262377024278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262377024278 : Closed e2262377024278 ∧ code e2262377024278 = 11058470046486 := by decide
theorem cert_e2262377024278 : check e2262377024278 [[],[.under]] .three = true := by decide
def e2262377024354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262377024354 : Closed e2262377024354 ∧ code e2262377024354 = 11058470046562 := by decide
theorem cert_e2262377024354 : check e2262377024354 [[],[.under]] .three = true := by decide
def e2262377024366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262377024366 : Closed e2262377024366 ∧ code e2262377024366 = 11058470046574 := by decide
theorem cert_e2262377024366 : check e2262377024366 [[],[.under]] .three = true := by decide
def e2262377024374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262377024374 : Closed e2262377024374 ∧ code e2262377024374 = 11058470046582 := by decide
theorem cert_e2262377024374 : check e2262377024374 [[],[.under]] .three = true := by decide
def e2262377024394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377024394 : Closed e2262377024394 ∧ code e2262377024394 = 11058470046602 := by decide
theorem cert_e2262377024394 : check e2262377024394 [[],[.under]] .three = true := by decide
def e2262377024418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377024418 : Closed e2262377024418 ∧ code e2262377024418 = 11058470046626 := by decide
theorem cert_e2262377024418 : check e2262377024418 [[],[.under]] .three = true := by decide
def e2262377024430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262377024430 : Closed e2262377024430 ∧ code e2262377024430 = 11058470046638 := by decide
theorem cert_e2262377024430 : check e2262377024430 [[],[.under]] .three = true := by decide
def e2262377024438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2262377024438 : Closed e2262377024438 ∧ code e2262377024438 = 11058470046646 := by decide
theorem cert_e2262377024438 : check e2262377024438 [[],[.under]] .three = true := by decide
def e2262377024442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262377024442 : Closed e2262377024442 ∧ code e2262377024442 = 11058470046650 := by decide
theorem cert_e2262377024442 : check e2262377024442 [[],[.under]] .three = true := by decide
def e2262377024470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262377024470 : Closed e2262377024470 ∧ code e2262377024470 = 11058470046678 := by decide
theorem cert_e2262377024470 : check e2262377024470 [[],[.under]] .three = true := by decide
def e2262377024474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262377024474 : Closed e2262377024474 ∧ code e2262377024474 = 11058470046682 := by decide
theorem cert_e2262377024474 : check e2262377024474 [[],[.under]] .three = true := by decide
def e2262377024542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2262377024542 : Closed e2262377024542 ∧ code e2262377024542 = 11058470046750 := by decide
theorem cert_e2262377024542 : check e2262377024542 [[],[.under]] .three = true := by decide
def e2262377024738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262377024738 : Closed e2262377024738 ∧ code e2262377024738 = 11058470046946 := by decide
theorem cert_e2262377024738 : check e2262377024738 [[],[.under]] .three = true := by decide
def e2262377024750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377024750 : Closed e2262377024750 ∧ code e2262377024750 = 11058470046958 := by decide
theorem cert_e2262377024750 : check e2262377024750 [[],[.under]] .three = true := by decide
def e2262377024758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377024758 : Closed e2262377024758 ∧ code e2262377024758 = 11058470046966 := by decide
theorem cert_e2262377024758 : check e2262377024758 [[],[.under]] .three = true := by decide
def e2262377025038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377025038 : Closed e2262377025038 ∧ code e2262377025038 = 11058470047246 := by decide
theorem cert_e2262377025038 : check e2262377025038 [[],[.under]] .three = true := by decide
def e2262377025050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377025050 : Closed e2262377025050 ∧ code e2262377025050 = 11058470047258 := by decide
theorem cert_e2262377025050 : check e2262377025050 [[],[.under]] .three = true := by decide
def e2262377025122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377025122 : Closed e2262377025122 ∧ code e2262377025122 = 11058470047330 := by decide
theorem cert_e2262377025122 : check e2262377025122 [[],[.under]] .three = true := by decide
def e2262377025134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377025134 : Closed e2262377025134 ∧ code e2262377025134 = 11058470047342 := by decide
theorem cert_e2262377025134 : check e2262377025134 [[],[.under]] .three = true := by decide
def e2262377025142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377025142 : Closed e2262377025142 ∧ code e2262377025142 = 11058470047350 := by decide
theorem cert_e2262377025142 : check e2262377025142 [[],[.under]] .three = true := by decide
def e2262377025146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377025146 : Closed e2262377025146 ∧ code e2262377025146 = 11058470047354 := by decide
theorem cert_e2262377025146 : check e2262377025146 [[],[.under]] .three = true := by decide
def e2262377025334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377025334 : Closed e2262377025334 ∧ code e2262377025334 = 11058470047542 := by decide
theorem cert_e2262377025334 : check e2262377025334 [[],[.under]] .three = true := by decide
def e2262377025338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377025338 : Closed e2262377025338 ∧ code e2262377025338 = 11058470047546 := by decide
theorem cert_e2262377025338 : check e2262377025338 [[],[.under]] .three = true := by decide
def e2262377041518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377041518 : Closed e2262377041518 ∧ code e2262377041518 = 11058470063726 := by decide
theorem cert_e2262377041518 : check e2262377041518 [[],[.under]] .three = true := by decide
def e2262377041530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377041530 : Closed e2262377041530 ∧ code e2262377041530 = 11058470063738 := by decide
theorem cert_e2262377041530 : check e2262377041530 [[],[.under]] .three = true := by decide
def e2262377041818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262377041818 : Closed e2262377041818 ∧ code e2262377041818 = 11058470064026 := by decide
theorem cert_e2262377041818 : check e2262377041818 [[],[.under]] .three = true := by decide
def e2262377044590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377044590 : Closed e2262377044590 ∧ code e2262377044590 = 11058470066798 := by decide
theorem cert_e2262377044590 : check e2262377044590 [[],[.under]] .three = true := by decide
def e2262377044602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377044602 : Closed e2262377044602 ∧ code e2262377044602 = 11058470066810 := by decide
theorem cert_e2262377044602 : check e2262377044602 [[],[.under]] .three = true := by decide
def e2262377045486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2))))))
theorem wire_e2262377045486 : Closed e2262377045486 ∧ code e2262377045486 = 11058470067694 := by decide
theorem cert_e2262377045486 : check e2262377045486 [[],[.under]] .three = true := by decide
def e2262377045870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2))))))
theorem wire_e2262377045870 : Closed e2262377045870 ∧ code e2262377045870 = 11058470068078 := by decide
theorem cert_e2262377045870 : check e2262377045870 [[],[.under]] .three = true := by decide
def e2262377045882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0))))))
theorem wire_e2262377045882 : Closed e2262377045882 ∧ code e2262377045882 = 11058470068090 := by decide
theorem cert_e2262377045882 : check e2262377045882 [[],[.under]] .three = true := by decide
def e2262377047470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2262377047470 : Closed e2262377047470 ∧ code e2262377047470 = 11058470069678 := by decide
theorem cert_e2262377047470 : check e2262377047470 [[],[.under]] .three = true := by decide
def e2262377047482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2262377047482 : Closed e2262377047482 ∧ code e2262377047482 = 11058470069690 := by decide
theorem cert_e2262377047482 : check e2262377047482 [[],[.under]] .three = true := by decide
def e2262377047530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2262377047530 : Closed e2262377047530 ∧ code e2262377047530 = 11058470069738 := by decide
theorem cert_e2262377047530 : check e2262377047530 [[],[.under]] .three = true := by decide
def e2262377047662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377047662 : Closed e2262377047662 ∧ code e2262377047662 = 11058470069870 := by decide
theorem cert_e2262377047662 : check e2262377047662 [[],[.under]] .three = true := by decide
def e2262377047674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377047674 : Closed e2262377047674 ∧ code e2262377047674 = 11058470069882 := by decide
theorem cert_e2262377047674 : check e2262377047674 [[],[.under]] .three = true := by decide
def e2262377047962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2262377047962 : Closed e2262377047962 ∧ code e2262377047962 = 11058470070170 := by decide
theorem cert_e2262377047962 : check e2262377047962 [[],[.under]] .three = true := by decide
end Blc.Floor43
