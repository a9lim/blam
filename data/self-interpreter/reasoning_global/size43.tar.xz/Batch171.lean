import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262376869390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2262376869390 : Closed e2262376869390 ∧ code e2262376869390 = 11058469891598 := by decide
theorem cert_e2262376869390 : check e2262376869390 [[],[.under]] .three = true := by decide
def e2262376869402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376869402 : Closed e2262376869402 ∧ code e2262376869402 = 11058469891610 := by decide
theorem cert_e2262376869402 : check e2262376869402 [[],[.under]] .three = true := by decide
def e2262376869474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376869474 : Closed e2262376869474 ∧ code e2262376869474 = 11058469891682 := by decide
theorem cert_e2262376869474 : check e2262376869474 [[],[.under]] .three = true := by decide
def e2262376869486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376869486 : Closed e2262376869486 ∧ code e2262376869486 = 11058469891694 := by decide
theorem cert_e2262376869486 : check e2262376869486 [[],[.under]] .three = true := by decide
def e2262376869494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376869494 : Closed e2262376869494 ∧ code e2262376869494 = 11058469891702 := by decide
theorem cert_e2262376869494 : check e2262376869494 [[],[.under]] .three = true := by decide
def e2262376869498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376869498 : Closed e2262376869498 ∧ code e2262376869498 = 11058469891706 := by decide
theorem cert_e2262376869498 : check e2262376869498 [[],[.under]] .three = true := by decide
def e2262376870006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2262376870006 : Closed e2262376870006 ∧ code e2262376870006 = 11058469892214 := by decide
theorem cert_e2262376870006 : check e2262376870006 [[],[.under]] .three = true := by decide
def e2262376870010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2262376870010 : Closed e2262376870010 ∧ code e2262376870010 = 11058469892218 := by decide
theorem cert_e2262376870010 : check e2262376870010 [[],[.under]] .three = true := by decide
def e2262376870102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2262376870102 : Closed e2262376870102 ∧ code e2262376870102 = 11058469892310 := by decide
theorem cert_e2262376870102 : check e2262376870102 [[],[.under]] .three = true := by decide
def e2262376870198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376870198 : Closed e2262376870198 ∧ code e2262376870198 = 11058469892406 := by decide
theorem cert_e2262376870198 : check e2262376870198 [[],[.under]] .three = true := by decide
def e2262376870202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376870202 : Closed e2262376870202 ∧ code e2262376870202 = 11058469892410 := by decide
theorem cert_e2262376870202 : check e2262376870202 [[],[.under]] .three = true := by decide
def e2262376870286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2262376870286 : Closed e2262376870286 ∧ code e2262376870286 = 11058469892494 := by decide
theorem cert_e2262376870286 : check e2262376870286 [[],[.under]] .three = true := by decide
def e2262376870342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2262376870342 : Closed e2262376870342 ∧ code e2262376870342 = 11058469892550 := by decide
theorem cert_e2262376870342 : check e2262376870342 [[],[.under]] .three = true := by decide
def e2262376870678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2262376870678 : Closed e2262376870678 ∧ code e2262376870678 = 11058469892886 := by decide
theorem cert_e2262376870678 : check e2262376870678 [[],[.under]] .three = true := by decide
def e2262376870754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2262376870754 : Closed e2262376870754 ∧ code e2262376870754 = 11058469892962 := by decide
theorem cert_e2262376870754 : check e2262376870754 [[],[.under]] .three = true := by decide
def e2262376870766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2262376870766 : Closed e2262376870766 ∧ code e2262376870766 = 11058469892974 := by decide
theorem cert_e2262376870766 : check e2262376870766 [[],[.under]] .three = true := by decide
def e2262376870774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2262376870774 : Closed e2262376870774 ∧ code e2262376870774 = 11058469892982 := by decide
theorem cert_e2262376870774 : check e2262376870774 [[],[.under]] .three = true := by decide
def e2262376870794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376870794 : Closed e2262376870794 ∧ code e2262376870794 = 11058469893002 := by decide
theorem cert_e2262376870794 : check e2262376870794 [[],[.under]] .three = true := by decide
def e2262376870818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376870818 : Closed e2262376870818 ∧ code e2262376870818 = 11058469893026 := by decide
theorem cert_e2262376870818 : check e2262376870818 [[],[.under]] .three = true := by decide
def e2262376870830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2262376870830 : Closed e2262376870830 ∧ code e2262376870830 = 11058469893038 := by decide
theorem cert_e2262376870830 : check e2262376870830 [[],[.under]] .three = true := by decide
def e2262376870838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2262376870838 : Closed e2262376870838 ∧ code e2262376870838 = 11058469893046 := by decide
theorem cert_e2262376870838 : check e2262376870838 [[],[.under]] .three = true := by decide
def e2262376870842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2262376870842 : Closed e2262376870842 ∧ code e2262376870842 = 11058469893050 := by decide
theorem cert_e2262376870842 : check e2262376870842 [[],[.under]] .three = true := by decide
def e2262376870870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2262376870870 : Closed e2262376870870 ∧ code e2262376870870 = 11058469893078 := by decide
theorem cert_e2262376870870 : check e2262376870870 [[],[.under]] .three = true := by decide
def e2262376870874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2262376870874 : Closed e2262376870874 ∧ code e2262376870874 = 11058469893082 := by decide
theorem cert_e2262376870874 : check e2262376870874 [[],[.under]] .three = true := by decide
def e2262376870942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2262376870942 : Closed e2262376870942 ∧ code e2262376870942 = 11058469893150 := by decide
theorem cert_e2262376870942 : check e2262376870942 [[],[.under]] .three = true := by decide
def e2262376871138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2262376871138 : Closed e2262376871138 ∧ code e2262376871138 = 11058469893346 := by decide
theorem cert_e2262376871138 : check e2262376871138 [[],[.under]] .three = true := by decide
def e2262376871150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376871150 : Closed e2262376871150 ∧ code e2262376871150 = 11058469893358 := by decide
theorem cert_e2262376871150 : check e2262376871150 [[],[.under]] .three = true := by decide
def e2262376871158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376871158 : Closed e2262376871158 ∧ code e2262376871158 = 11058469893366 := by decide
theorem cert_e2262376871158 : check e2262376871158 [[],[.under]] .three = true := by decide
def e2262376871438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2262376871438 : Closed e2262376871438 ∧ code e2262376871438 = 11058469893646 := by decide
theorem cert_e2262376871438 : check e2262376871438 [[],[.under]] .three = true := by decide
def e2262376871450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376871450 : Closed e2262376871450 ∧ code e2262376871450 = 11058469893658 := by decide
theorem cert_e2262376871450 : check e2262376871450 [[],[.under]] .three = true := by decide
def e2262376871522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376871522 : Closed e2262376871522 ∧ code e2262376871522 = 11058469893730 := by decide
theorem cert_e2262376871522 : check e2262376871522 [[],[.under]] .three = true := by decide
def e2262376871534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376871534 : Closed e2262376871534 ∧ code e2262376871534 = 11058469893742 := by decide
theorem cert_e2262376871534 : check e2262376871534 [[],[.under]] .three = true := by decide
def e2262376871542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376871542 : Closed e2262376871542 ∧ code e2262376871542 = 11058469893750 := by decide
theorem cert_e2262376871542 : check e2262376871542 [[],[.under]] .three = true := by decide
def e2262376871546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376871546 : Closed e2262376871546 ∧ code e2262376871546 = 11058469893754 := by decide
theorem cert_e2262376871546 : check e2262376871546 [[],[.under]] .three = true := by decide
def e2262376871734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376871734 : Closed e2262376871734 ∧ code e2262376871734 = 11058469893942 := by decide
theorem cert_e2262376871734 : check e2262376871734 [[],[.under]] .three = true := by decide
def e2262376871738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376871738 : Closed e2262376871738 ∧ code e2262376871738 = 11058469893946 := by decide
theorem cert_e2262376871738 : check e2262376871738 [[],[.under]] .three = true := by decide
def e2262376874926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2262376874926 : Closed e2262376874926 ∧ code e2262376874926 = 11058469897134 := by decide
theorem cert_e2262376874926 : check e2262376874926 [[],[.under]] .three = true := by decide
def e2262376874938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2262376874938 : Closed e2262376874938 ∧ code e2262376874938 = 11058469897146 := by decide
theorem cert_e2262376874938 : check e2262376874938 [[],[.under]] .three = true := by decide
def e2262376874986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 0))))))
theorem wire_e2262376874986 : Closed e2262376874986 ∧ code e2262376874986 = 11058469897194 := by decide
theorem cert_e2262376874986 : check e2262376874986 [[],[.under]] .three = true := by decide
def e2262376875694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2262376875694 : Closed e2262376875694 ∧ code e2262376875694 = 11058469897902 := by decide
theorem cert_e2262376875694 : check e2262376875694 [[],[.under]] .three = true := by decide
def e2262376875706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2262376875706 : Closed e2262376875706 ∧ code e2262376875706 = 11058469897914 := by decide
theorem cert_e2262376875706 : check e2262376875706 [[],[.under]] .three = true := by decide
def e2262376876462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2262376876462 : Closed e2262376876462 ∧ code e2262376876462 = 11058469898670 := by decide
theorem cert_e2262376876462 : check e2262376876462 [[],[.under]] .three = true := by decide
def e2262376876474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2262376876474 : Closed e2262376876474 ∧ code e2262376876474 = 11058469898682 := by decide
theorem cert_e2262376876474 : check e2262376876474 [[],[.under]] .three = true := by decide
def e2262376876522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2262376876522 : Closed e2262376876522 ∧ code e2262376876522 = 11058469898730 := by decide
theorem cert_e2262376876522 : check e2262376876522 [[],[.under]] .three = true := by decide
def e2262376876654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376876654 : Closed e2262376876654 ∧ code e2262376876654 = 11058469898862 := by decide
theorem cert_e2262376876654 : check e2262376876654 [[],[.under]] .three = true := by decide
def e2262376876666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376876666 : Closed e2262376876666 ∧ code e2262376876666 = 11058469898874 := by decide
theorem cert_e2262376876666 : check e2262376876666 [[],[.under]] .three = true := by decide
def e2262376876954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2262376876954 : Closed e2262376876954 ∧ code e2262376876954 = 11058469899162 := by decide
theorem cert_e2262376876954 : check e2262376876954 [[],[.under]] .three = true := by decide
def e2262376877166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2262376877166 : Closed e2262376877166 ∧ code e2262376877166 = 11058469899374 := by decide
theorem cert_e2262376877166 : check e2262376877166 [[],[.under]] .three = true := by decide
def e2262376877178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2262376877178 : Closed e2262376877178 ∧ code e2262376877178 = 11058469899386 := by decide
theorem cert_e2262376877178 : check e2262376877178 [[],[.under]] .three = true := by decide
def e2262376877342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2262376877342 : Closed e2262376877342 ∧ code e2262376877342 = 11058469899550 := by decide
theorem cert_e2262376877342 : check e2262376877342 [[],[.under]] .three = true := by decide
def e2262376877510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2262376877510 : Closed e2262376877510 ∧ code e2262376877510 = 11058469899718 := by decide
theorem cert_e2262376877510 : check e2262376877510 [[],[.under]] .three = true := by decide
def e2262376877850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2262376877850 : Closed e2262376877850 ∧ code e2262376877850 = 11058469900058 := by decide
theorem cert_e2262376877850 : check e2262376877850 [[],[.under]] .three = true := by decide
def e2262376877894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2262376877894 : Closed e2262376877894 ∧ code e2262376877894 = 11058469900102 := by decide
theorem cert_e2262376877894 : check e2262376877894 [[],[.under]] .three = true := by decide
def e2262376880302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2262376880302 : Closed e2262376880302 ∧ code e2262376880302 = 11058469902510 := by decide
theorem cert_e2262376880302 : check e2262376880302 [[],[.under]] .three = true := by decide
def e2262376880314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2262376880314 : Closed e2262376880314 ∧ code e2262376880314 = 11058469902522 := by decide
theorem cert_e2262376880314 : check e2262376880314 [[],[.under]] .three = true := by decide
def e2262376880686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2262376880686 : Closed e2262376880686 ∧ code e2262376880686 = 11058469902894 := by decide
theorem cert_e2262376880686 : check e2262376880686 [[],[.under]] .three = true := by decide
def e2262376880866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2262376880866 : Closed e2262376880866 ∧ code e2262376880866 = 11058469903074 := by decide
theorem cert_e2262376880866 : check e2262376880866 [[],[.under]] .three = true := by decide
def e2262376880878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2262376880878 : Closed e2262376880878 ∧ code e2262376880878 = 11058469903086 := by decide
theorem cert_e2262376880878 : check e2262376880878 [[],[.under]] .three = true := by decide
def e2262376881006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2262376881006 : Closed e2262376881006 ∧ code e2262376881006 = 11058469903214 := by decide
theorem cert_e2262376881006 : check e2262376881006 [[],[.under]] .three = true := by decide
def e2262376881014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2262376881014 : Closed e2262376881014 ∧ code e2262376881014 = 11058469903222 := by decide
theorem cert_e2262376881014 : check e2262376881014 [[],[.under]] .three = true := by decide
def e2262376881034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376881034 : Closed e2262376881034 ∧ code e2262376881034 = 11058469903242 := by decide
theorem cert_e2262376881034 : check e2262376881034 [[],[.under]] .three = true := by decide
def e2262376881058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376881058 : Closed e2262376881058 ∧ code e2262376881058 = 11058469903266 := by decide
theorem cert_e2262376881058 : check e2262376881058 [[],[.under]] .three = true := by decide
def e2262376881070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2262376881070 : Closed e2262376881070 ∧ code e2262376881070 = 11058469903278 := by decide
theorem cert_e2262376881070 : check e2262376881070 [[],[.under]] .three = true := by decide
def e2262376881078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2262376881078 : Closed e2262376881078 ∧ code e2262376881078 = 11058469903286 := by decide
theorem cert_e2262376881078 : check e2262376881078 [[],[.under]] .three = true := by decide
def e2262376881082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2262376881082 : Closed e2262376881082 ∧ code e2262376881082 = 11058469903290 := by decide
theorem cert_e2262376881082 : check e2262376881082 [[],[.under]] .three = true := by decide
def e2262376881518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2262376881518 : Closed e2262376881518 ∧ code e2262376881518 = 11058469903726 := by decide
theorem cert_e2262376881518 : check e2262376881518 [[],[.under]] .three = true := by decide
def e2262376881526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2262376881526 : Closed e2262376881526 ∧ code e2262376881526 = 11058469903734 := by decide
theorem cert_e2262376881526 : check e2262376881526 [[],[.under]] .three = true := by decide
def e2262376881582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2262376881582 : Closed e2262376881582 ∧ code e2262376881582 = 11058469903790 := by decide
theorem cert_e2262376881582 : check e2262376881582 [[],[.under]] .three = true := by decide
def e2262376881594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2262376881594 : Closed e2262376881594 ∧ code e2262376881594 = 11058469903802 := by decide
theorem cert_e2262376881594 : check e2262376881594 [[],[.under]] .three = true := by decide
def e2262376881622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2262376881622 : Closed e2262376881622 ∧ code e2262376881622 = 11058469903830 := by decide
theorem cert_e2262376881622 : check e2262376881622 [[],[.under]] .three = true := by decide
def e2262376881626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2262376881626 : Closed e2262376881626 ∧ code e2262376881626 = 11058469903834 := by decide
theorem cert_e2262376881626 : check e2262376881626 [[],[.under]] .three = true := by decide
def e2262376881706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2262376881706 : Closed e2262376881706 ∧ code e2262376881706 = 11058469903914 := by decide
theorem cert_e2262376881706 : check e2262376881706 [[],[.under]] .three = true := by decide
def e2262376881802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376881802 : Closed e2262376881802 ∧ code e2262376881802 = 11058469904010 := by decide
theorem cert_e2262376881802 : check e2262376881802 [[],[.under]] .three = true := by decide
def e2262376881826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376881826 : Closed e2262376881826 ∧ code e2262376881826 = 11058469904034 := by decide
theorem cert_e2262376881826 : check e2262376881826 [[],[.under]] .three = true := by decide
def e2262376881838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2262376881838 : Closed e2262376881838 ∧ code e2262376881838 = 11058469904046 := by decide
theorem cert_e2262376881838 : check e2262376881838 [[],[.under]] .three = true := by decide
def e2262376881846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2262376881846 : Closed e2262376881846 ∧ code e2262376881846 = 11058469904054 := by decide
theorem cert_e2262376881846 : check e2262376881846 [[],[.under]] .three = true := by decide
def e2262376881850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2262376881850 : Closed e2262376881850 ∧ code e2262376881850 = 11058469904058 := by decide
theorem cert_e2262376881850 : check e2262376881850 [[],[.under]] .three = true := by decide
def e2262376881878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2262376881878 : Closed e2262376881878 ∧ code e2262376881878 = 11058469904086 := by decide
theorem cert_e2262376881878 : check e2262376881878 [[],[.under]] .three = true := by decide
def e2262376881882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2262376881882 : Closed e2262376881882 ∧ code e2262376881882 = 11058469904090 := by decide
theorem cert_e2262376881882 : check e2262376881882 [[],[.under]] .three = true := by decide
def e2262376881898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2262376881898 : Closed e2262376881898 ∧ code e2262376881898 = 11058469904106 := by decide
theorem cert_e2262376881898 : check e2262376881898 [[],[.under]] .three = true := by decide
def e2262376882414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2262376882414 : Closed e2262376882414 ∧ code e2262376882414 = 11058469904622 := by decide
theorem cert_e2262376882414 : check e2262376882414 [[],[.under]] .three = true := by decide
def e2262376882426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2262376882426 : Closed e2262376882426 ∧ code e2262376882426 = 11058469904634 := by decide
theorem cert_e2262376882426 : check e2262376882426 [[],[.under]] .three = true := by decide
def e2262376882606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2262376882606 : Closed e2262376882606 ∧ code e2262376882606 = 11058469904814 := by decide
theorem cert_e2262376882606 : check e2262376882606 [[],[.under]] .three = true := by decide
def e2262376882798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376882798 : Closed e2262376882798 ∧ code e2262376882798 = 11058469905006 := by decide
theorem cert_e2262376882798 : check e2262376882798 [[],[.under]] .three = true := by decide
def e2262376882810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376882810 : Closed e2262376882810 ∧ code e2262376882810 = 11058469905018 := by decide
theorem cert_e2262376882810 : check e2262376882810 [[],[.under]] .three = true := by decide
def e2262376882974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2262376882974 : Closed e2262376882974 ∧ code e2262376882974 = 11058469905182 := by decide
theorem cert_e2262376882974 : check e2262376882974 [[],[.under]] .three = true := by decide
def e2262376883142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2262376883142 : Closed e2262376883142 ∧ code e2262376883142 = 11058469905350 := by decide
theorem cert_e2262376883142 : check e2262376883142 [[],[.under]] .three = true := by decide
def e2262376883758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2262376883758 : Closed e2262376883758 ∧ code e2262376883758 = 11058469905966 := by decide
theorem cert_e2262376883758 : check e2262376883758 [[],[.under]] .three = true := by decide
def e2262376883938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2262376883938 : Closed e2262376883938 ∧ code e2262376883938 = 11058469906146 := by decide
theorem cert_e2262376883938 : check e2262376883938 [[],[.under]] .three = true := by decide
def e2262376883950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2262376883950 : Closed e2262376883950 ∧ code e2262376883950 = 11058469906158 := by decide
theorem cert_e2262376883950 : check e2262376883950 [[],[.under]] .three = true := by decide
def e2262376884078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2262376884078 : Closed e2262376884078 ∧ code e2262376884078 = 11058469906286 := by decide
theorem cert_e2262376884078 : check e2262376884078 [[],[.under]] .three = true := by decide
def e2262376884086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2262376884086 : Closed e2262376884086 ∧ code e2262376884086 = 11058469906294 := by decide
theorem cert_e2262376884086 : check e2262376884086 [[],[.under]] .three = true := by decide
def e2262376884106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376884106 : Closed e2262376884106 ∧ code e2262376884106 = 11058469906314 := by decide
theorem cert_e2262376884106 : check e2262376884106 [[],[.under]] .three = true := by decide
def e2262376884130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376884130 : Closed e2262376884130 ∧ code e2262376884130 = 11058469906338 := by decide
theorem cert_e2262376884130 : check e2262376884130 [[],[.under]] .three = true := by decide
def e2262376884142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2262376884142 : Closed e2262376884142 ∧ code e2262376884142 = 11058469906350 := by decide
theorem cert_e2262376884142 : check e2262376884142 [[],[.under]] .three = true := by decide
def e2262376884150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2262376884150 : Closed e2262376884150 ∧ code e2262376884150 = 11058469906358 := by decide
theorem cert_e2262376884150 : check e2262376884150 [[],[.under]] .three = true := by decide
def e2262376884154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2262376884154 : Closed e2262376884154 ∧ code e2262376884154 = 11058469906362 := by decide
theorem cert_e2262376884154 : check e2262376884154 [[],[.under]] .three = true := by decide
def e2262376884286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2262376884286 : Closed e2262376884286 ∧ code e2262376884286 = 11058469906494 := by decide
theorem cert_e2262376884286 : check e2262376884286 [[],[.under]] .three = true := by decide
def e2262376884706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2262376884706 : Closed e2262376884706 ∧ code e2262376884706 = 11058469906914 := by decide
theorem cert_e2262376884706 : check e2262376884706 [[],[.under]] .three = true := by decide
def e2262376884718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2262376884718 : Closed e2262376884718 ∧ code e2262376884718 = 11058469906926 := by decide
theorem cert_e2262376884718 : check e2262376884718 [[],[.under]] .three = true := by decide
def e2262376885486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376885486 : Closed e2262376885486 ∧ code e2262376885486 = 11058469907694 := by decide
theorem cert_e2262376885486 : check e2262376885486 [[],[.under]] .three = true := by decide
def e2262376885494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376885494 : Closed e2262376885494 ∧ code e2262376885494 = 11058469907702 := by decide
theorem cert_e2262376885494 : check e2262376885494 [[],[.under]] .three = true := by decide
def e2262376885774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2262376885774 : Closed e2262376885774 ∧ code e2262376885774 = 11058469907982 := by decide
theorem cert_e2262376885774 : check e2262376885774 [[],[.under]] .three = true := by decide
def e2262376885786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376885786 : Closed e2262376885786 ∧ code e2262376885786 = 11058469907994 := by decide
theorem cert_e2262376885786 : check e2262376885786 [[],[.under]] .three = true := by decide
def e2262376885858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376885858 : Closed e2262376885858 ∧ code e2262376885858 = 11058469908066 := by decide
theorem cert_e2262376885858 : check e2262376885858 [[],[.under]] .three = true := by decide
def e2262376885870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376885870 : Closed e2262376885870 ∧ code e2262376885870 = 11058469908078 := by decide
theorem cert_e2262376885870 : check e2262376885870 [[],[.under]] .three = true := by decide
def e2262376885878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376885878 : Closed e2262376885878 ∧ code e2262376885878 = 11058469908086 := by decide
theorem cert_e2262376885878 : check e2262376885878 [[],[.under]] .three = true := by decide
def e2262376885882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376885882 : Closed e2262376885882 ∧ code e2262376885882 = 11058469908090 := by decide
theorem cert_e2262376885882 : check e2262376885882 [[],[.under]] .three = true := by decide
def e2262376887150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2262376887150 : Closed e2262376887150 ∧ code e2262376887150 = 11058469909358 := by decide
theorem cert_e2262376887150 : check e2262376887150 [[],[.under]] .three = true := by decide
def e2262376887158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2262376887158 : Closed e2262376887158 ∧ code e2262376887158 = 11058469909366 := by decide
theorem cert_e2262376887158 : check e2262376887158 [[],[.under]] .three = true := by decide
def e2262376887214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2262376887214 : Closed e2262376887214 ∧ code e2262376887214 = 11058469909422 := by decide
theorem cert_e2262376887214 : check e2262376887214 [[],[.under]] .three = true := by decide
def e2262376887226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2262376887226 : Closed e2262376887226 ∧ code e2262376887226 = 11058469909434 := by decide
theorem cert_e2262376887226 : check e2262376887226 [[],[.under]] .three = true := by decide
def e2262376887254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2262376887254 : Closed e2262376887254 ∧ code e2262376887254 = 11058469909462 := by decide
theorem cert_e2262376887254 : check e2262376887254 [[],[.under]] .three = true := by decide
def e2262376887258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2262376887258 : Closed e2262376887258 ∧ code e2262376887258 = 11058469909466 := by decide
theorem cert_e2262376887258 : check e2262376887258 [[],[.under]] .three = true := by decide
def e2262376887534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376887534 : Closed e2262376887534 ∧ code e2262376887534 = 11058469909742 := by decide
theorem cert_e2262376887534 : check e2262376887534 [[],[.under]] .three = true := by decide
def e2262376887542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376887542 : Closed e2262376887542 ∧ code e2262376887542 = 11058469909750 := by decide
theorem cert_e2262376887542 : check e2262376887542 [[],[.under]] .three = true := by decide
def e2262376887918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376887918 : Closed e2262376887918 ∧ code e2262376887918 = 11058469910126 := by decide
theorem cert_e2262376887918 : check e2262376887918 [[],[.under]] .three = true := by decide
def e2262376887930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376887930 : Closed e2262376887930 ∧ code e2262376887930 = 11058469910138 := by decide
theorem cert_e2262376887930 : check e2262376887930 [[],[.under]] .three = true := by decide
def e2262376888118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376888118 : Closed e2262376888118 ∧ code e2262376888118 = 11058469910326 := by decide
theorem cert_e2262376888118 : check e2262376888118 [[],[.under]] .three = true := by decide
def e2262376888122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376888122 : Closed e2262376888122 ∧ code e2262376888122 = 11058469910330 := by decide
theorem cert_e2262376888122 : check e2262376888122 [[],[.under]] .three = true := by decide
def e2262376888378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2262376888378 : Closed e2262376888378 ∧ code e2262376888378 = 11058469910586 := by decide
theorem cert_e2262376888378 : check e2262376888378 [[],[.under]] .three = true := by decide
def e2262376888426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2262376888426 : Closed e2262376888426 ∧ code e2262376888426 = 11058469910634 := by decide
theorem cert_e2262376888426 : check e2262376888426 [[],[.under]] .three = true := by decide
def e2262376888474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262376888474 : Closed e2262376888474 ∧ code e2262376888474 = 11058469910682 := by decide
theorem cert_e2262376888474 : check e2262376888474 [[],[.under]] .three = true := by decide
def e2262376888518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2262376888518 : Closed e2262376888518 ∧ code e2262376888518 = 11058469910726 := by decide
theorem cert_e2262376888518 : check e2262376888518 [[],[.under]] .three = true := by decide
def e2262376888714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376888714 : Closed e2262376888714 ∧ code e2262376888714 = 11058469910922 := by decide
theorem cert_e2262376888714 : check e2262376888714 [[],[.under]] .three = true := by decide
def e2262376888738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376888738 : Closed e2262376888738 ∧ code e2262376888738 = 11058469910946 := by decide
theorem cert_e2262376888738 : check e2262376888738 [[],[.under]] .three = true := by decide
def e2262376888750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2262376888750 : Closed e2262376888750 ∧ code e2262376888750 = 11058469910958 := by decide
theorem cert_e2262376888750 : check e2262376888750 [[],[.under]] .three = true := by decide
def e2262376888758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2262376888758 : Closed e2262376888758 ∧ code e2262376888758 = 11058469910966 := by decide
theorem cert_e2262376888758 : check e2262376888758 [[],[.under]] .three = true := by decide
def e2262376888762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2262376888762 : Closed e2262376888762 ∧ code e2262376888762 = 11058469910970 := by decide
theorem cert_e2262376888762 : check e2262376888762 [[],[.under]] .three = true := by decide
def e2262376888790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2262376888790 : Closed e2262376888790 ∧ code e2262376888790 = 11058469910998 := by decide
theorem cert_e2262376888790 : check e2262376888790 [[],[.under]] .three = true := by decide
def e2262376888794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2262376888794 : Closed e2262376888794 ∧ code e2262376888794 = 11058469911002 := by decide
theorem cert_e2262376888794 : check e2262376888794 [[],[.under]] .three = true := by decide
def e2262376888810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2262376888810 : Closed e2262376888810 ∧ code e2262376888810 = 11058469911018 := by decide
theorem cert_e2262376888810 : check e2262376888810 [[],[.under]] .three = true := by decide
def e2262376888846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2262376888846 : Closed e2262376888846 ∧ code e2262376888846 = 11058469911054 := by decide
theorem cert_e2262376888846 : check e2262376888846 [[],[.under]] .three = true := by decide
def e2262376888858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376888858 : Closed e2262376888858 ∧ code e2262376888858 = 11058469911066 := by decide
theorem cert_e2262376888858 : check e2262376888858 [[],[.under]] .three = true := by decide
def e2262376888930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376888930 : Closed e2262376888930 ∧ code e2262376888930 = 11058469911138 := by decide
theorem cert_e2262376888930 : check e2262376888930 [[],[.under]] .three = true := by decide
def e2262376888942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376888942 : Closed e2262376888942 ∧ code e2262376888942 = 11058469911150 := by decide
theorem cert_e2262376888942 : check e2262376888942 [[],[.under]] .three = true := by decide
def e2262376888950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376888950 : Closed e2262376888950 ∧ code e2262376888950 = 11058469911158 := by decide
theorem cert_e2262376888950 : check e2262376888950 [[],[.under]] .three = true := by decide
def e2262376888954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376888954 : Closed e2262376888954 ∧ code e2262376888954 = 11058469911162 := by decide
theorem cert_e2262376888954 : check e2262376888954 [[],[.under]] .three = true := by decide
def e2262376889142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376889142 : Closed e2262376889142 ∧ code e2262376889142 = 11058469911350 := by decide
theorem cert_e2262376889142 : check e2262376889142 [[],[.under]] .three = true := by decide
def e2262376889146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376889146 : Closed e2262376889146 ∧ code e2262376889146 = 11058469911354 := by decide
theorem cert_e2262376889146 : check e2262376889146 [[],[.under]] .three = true := by decide
def e2262376889242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2262376889242 : Closed e2262376889242 ∧ code e2262376889242 = 11058469911450 := by decide
theorem cert_e2262376889242 : check e2262376889242 [[],[.under]] .three = true := by decide
def e2262376890838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2262376890838 : Closed e2262376890838 ∧ code e2262376890838 = 11058469913046 := by decide
theorem cert_e2262376890838 : check e2262376890838 [[],[.under]] .three = true := by decide
def e2262376890842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2262376890842 : Closed e2262376890842 ∧ code e2262376890842 = 11058469913050 := by decide
theorem cert_e2262376890842 : check e2262376890842 [[],[.under]] .three = true := by decide
def e2262376890858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2262376890858 : Closed e2262376890858 ∧ code e2262376890858 = 11058469913066 := by decide
theorem cert_e2262376890858 : check e2262376890858 [[],[.under]] .three = true := by decide
def e2262376891222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2262376891222 : Closed e2262376891222 ∧ code e2262376891222 = 11058469913430 := by decide
private def t_e2262376891222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem cert_e2262376891222 : ¬ IsSelfInterpreter e2262376891222 :=
  wSource (t := t_e2262376891222) (replay_sound (ps := []) (t := e2262376891222) (by decide)) (by decide)
def e2262376891226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2262376891226 : Closed e2262376891226 ∧ code e2262376891226 = 11058469913434 := by decide
private def t_e2262376891226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem cert_e2262376891226 : ¬ IsSelfInterpreter e2262376891226 :=
  wSource (t := t_e2262376891226) (replay_sound (ps := []) (t := e2262376891226) (by decide)) (by decide)
def e2262376891606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2262376891606 : Closed e2262376891606 ∧ code e2262376891606 = 11058469913814 := by decide
theorem cert_e2262376891606 : check e2262376891606 [[],[.under]] .three = true := by decide
def e2262376891610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2262376891610 : Closed e2262376891610 ∧ code e2262376891610 = 11058469913818 := by decide
theorem cert_e2262376891610 : check e2262376891610 [[],[.under]] .three = true := by decide
def e2262376891626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2262376891626 : Closed e2262376891626 ∧ code e2262376891626 = 11058469913834 := by decide
theorem cert_e2262376891626 : check e2262376891626 [[],[.under]] .three = true := by decide
def e2262376891702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376891702 : Closed e2262376891702 ∧ code e2262376891702 = 11058469913910 := by decide
theorem cert_e2262376891702 : check e2262376891702 [[],[.under]] .three = true := by decide
def e2262376891706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376891706 : Closed e2262376891706 ∧ code e2262376891706 = 11058469913914 := by decide
theorem cert_e2262376891706 : check e2262376891706 [[],[.under]] .three = true := by decide
def e2262376891802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2262376891802 : Closed e2262376891802 ∧ code e2262376891802 = 11058469914010 := by decide
theorem cert_e2262376891802 : check e2262376891802 [[],[.under]] .three = true := by decide
def e2262376891958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2262376891958 : Closed e2262376891958 ∧ code e2262376891958 = 11058469914166 := by decide
theorem cert_e2262376891958 : check e2262376891958 [[],[.under]] .three = true := by decide
def e2262376891962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2262376891962 : Closed e2262376891962 ∧ code e2262376891962 = 11058469914170 := by decide
theorem cert_e2262376891962 : check e2262376891962 [[],[.under]] .three = true := by decide
def e2262376892046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2262376892046 : Closed e2262376892046 ∧ code e2262376892046 = 11058469914254 := by decide
theorem cert_e2262376892046 : check e2262376892046 [[],[.under]] .three = true := by decide
def e2262376892102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2262376892102 : Closed e2262376892102 ∧ code e2262376892102 = 11058469914310 := by decide
theorem cert_e2262376892102 : check e2262376892102 [[],[.under]] .three = true := by decide
def e2262376892186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2262376892186 : Closed e2262376892186 ∧ code e2262376892186 = 11058469914394 := by decide
theorem cert_e2262376892186 : check e2262376892186 [[],[.under]] .three = true := by decide
def e2262376892230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2262376892230 : Closed e2262376892230 ∧ code e2262376892230 = 11058469914438 := by decide
theorem cert_e2262376892230 : check e2262376892230 [[],[.under]] .three = true := by decide
def e2262376893526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2262376893526 : Closed e2262376893526 ∧ code e2262376893526 = 11058469915734 := by decide
theorem cert_e2262376893526 : check e2262376893526 [[],[.under]] .three = true := by decide
def e2262376893530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2262376893530 : Closed e2262376893530 ∧ code e2262376893530 = 11058469915738 := by decide
theorem cert_e2262376893530 : check e2262376893530 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262376891222
#print axioms Blc.Floor43.cert_e2262376891226
