import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e833471164138 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e833471164138 : Closed e833471164138 ∧ code e833471164138 = 9629564186346 := by decide
theorem cert_e833471164138 : check e833471164138 [] .sourceHead = true := by decide
def e833471164246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e833471164246 : Closed e833471164246 ∧ code e833471164246 = 9629564186454 := by decide
theorem cert_e833471164246 : check e833471164246 [] .sourceHead = true := by decide
def e833471164250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e833471164250 : Closed e833471164250 ∧ code e833471164250 = 9629564186458 := by decide
theorem cert_e833471164250 : check e833471164250 [] .sourceHead = true := by decide
def e833471164266 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e833471164266 : Closed e833471164266 ∧ code e833471164266 = 9629564186474 := by decide
theorem cert_e833471164266 : check e833471164266 [] .sourceHead = true := by decide
def e833471165294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e833471165294 : Closed e833471165294 ∧ code e833471165294 = 9629564187502 := by decide
theorem cert_e833471165294 : check e833471165294 [] .sourceHead = true := by decide
def e833471165302 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e833471165302 : Closed e833471165302 ∧ code e833471165302 = 9629564187510 := by decide
theorem cert_e833471165302 : check e833471165302 [] .sourceHead = true := by decide
def e833471165358 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e833471165358 : Closed e833471165358 ∧ code e833471165358 = 9629564187566 := by decide
theorem cert_e833471165358 : check e833471165358 [] .sourceHead = true := by decide
def e833471165370 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e833471165370 : Closed e833471165370 ∧ code e833471165370 = 9629564187578 := by decide
theorem cert_e833471165370 : check e833471165370 [] .sourceHead = true := by decide
def e833471165398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e833471165398 : Closed e833471165398 ∧ code e833471165398 = 9629564187606 := by decide
theorem cert_e833471165398 : check e833471165398 [] .sourceHead = true := by decide
def e833471165402 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e833471165402 : Closed e833471165402 ∧ code e833471165402 = 9629564187610 := by decide
theorem cert_e833471165402 : check e833471165402 [] .sourceHead = true := by decide
def e833471165678 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e833471165678 : Closed e833471165678 ∧ code e833471165678 = 9629564187886 := by decide
theorem cert_e833471165678 : check e833471165678 [] .sourceHead = true := by decide
def e833471165686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e833471165686 : Closed e833471165686 ∧ code e833471165686 = 9629564187894 := by decide
theorem cert_e833471165686 : check e833471165686 [] .sourceHead = true := by decide
def e833471166062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e833471166062 : Closed e833471166062 ∧ code e833471166062 = 9629564188270 := by decide
theorem cert_e833471166062 : check e833471166062 [] .sourceHead = true := by decide
def e833471166074 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e833471166074 : Closed e833471166074 ∧ code e833471166074 = 9629564188282 := by decide
theorem cert_e833471166074 : check e833471166074 [] .sourceHead = true := by decide
def e833471166262 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e833471166262 : Closed e833471166262 ∧ code e833471166262 = 9629564188470 := by decide
theorem cert_e833471166262 : check e833471166262 [] .sourceHead = true := by decide
def e833471166266 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e833471166266 : Closed e833471166266 ∧ code e833471166266 = 9629564188474 := by decide
theorem cert_e833471166266 : check e833471166266 [] .sourceHead = true := by decide
def e833471166894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e833471166894 : Closed e833471166894 ∧ code e833471166894 = 9629564189102 := by decide
theorem cert_e833471166894 : check e833471166894 [] .sourceHead = true := by decide
def e833471166906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e833471166906 : Closed e833471166906 ∧ code e833471166906 = 9629564189114 := by decide
theorem cert_e833471166906 : check e833471166906 [] .sourceHead = true := by decide
def e833471166954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e833471166954 : Closed e833471166954 ∧ code e833471166954 = 9629564189162 := by decide
theorem cert_e833471166954 : check e833471166954 [] .sourceHead = true := by decide
def e833471167086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e833471167086 : Closed e833471167086 ∧ code e833471167086 = 9629564189294 := by decide
theorem cert_e833471167086 : check e833471167086 [] .sourceHead = true := by decide
def e833471167098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e833471167098 : Closed e833471167098 ∧ code e833471167098 = 9629564189306 := by decide
theorem cert_e833471167098 : check e833471167098 [] .sourceHead = true := by decide
def e833471167386 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e833471167386 : Closed e833471167386 ∧ code e833471167386 = 9629564189594 := by decide
theorem cert_e833471167386 : check e833471167386 [] .sourceHead = true := by decide
def e833471167702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e833471167702 : Closed e833471167702 ∧ code e833471167702 = 9629564189910 := by decide
theorem cert_e833471167702 : check e833471167702 [] .sourceHead = true := by decide
def e833471167706 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e833471167706 : Closed e833471167706 ∧ code e833471167706 = 9629564189914 := by decide
theorem cert_e833471167706 : check e833471167706 [] .sourceHead = true := by decide
def e833471167722 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e833471167722 : Closed e833471167722 ∧ code e833471167722 = 9629564189930 := by decide
theorem cert_e833471167722 : check e833471167722 [] .sourceHead = true := by decide
def e833471167798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e833471167798 : Closed e833471167798 ∧ code e833471167798 = 9629564190006 := by decide
theorem cert_e833471167798 : check e833471167798 [] .sourceHead = true := by decide
def e833471167802 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e833471167802 : Closed e833471167802 ∧ code e833471167802 = 9629564190010 := by decide
theorem cert_e833471167802 : check e833471167802 [] .sourceHead = true := by decide
def e833471167898 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e833471167898 : Closed e833471167898 ∧ code e833471167898 = 9629564190106 := by decide
theorem cert_e833471167898 : check e833471167898 [] .sourceHead = true := by decide
def e833471171438 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e833471171438 : Closed e833471171438 ∧ code e833471171438 = 9629564193646 := by decide
theorem cert_e833471171438 : check e833471171438 [] .sourceHead = true := by decide
def e833471171446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e833471171446 : Closed e833471171446 ∧ code e833471171446 = 9629564193654 := by decide
theorem cert_e833471171446 : check e833471171446 [] .sourceHead = true := by decide
def e833471171502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e833471171502 : Closed e833471171502 ∧ code e833471171502 = 9629564193710 := by decide
theorem cert_e833471171502 : check e833471171502 [] .sourceHead = true := by decide
def e833471171514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e833471171514 : Closed e833471171514 ∧ code e833471171514 = 9629564193722 := by decide
theorem cert_e833471171514 : check e833471171514 [] .sourceHead = true := by decide
def e833471171542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e833471171542 : Closed e833471171542 ∧ code e833471171542 = 9629564193750 := by decide
theorem cert_e833471171542 : check e833471171542 [] .sourceHead = true := by decide
def e833471171546 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e833471171546 : Closed e833471171546 ∧ code e833471171546 = 9629564193754 := by decide
theorem cert_e833471171546 : check e833471171546 [] .sourceHead = true := by decide
def e833471171822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e833471171822 : Closed e833471171822 ∧ code e833471171822 = 9629564194030 := by decide
theorem cert_e833471171822 : check e833471171822 [] .sourceHead = true := by decide
def e833471171830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e833471171830 : Closed e833471171830 ∧ code e833471171830 = 9629564194038 := by decide
theorem cert_e833471171830 : check e833471171830 [] .sourceHead = true := by decide
def e833471172206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e833471172206 : Closed e833471172206 ∧ code e833471172206 = 9629564194414 := by decide
theorem cert_e833471172206 : check e833471172206 [] .sourceHead = true := by decide
def e833471172218 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e833471172218 : Closed e833471172218 ∧ code e833471172218 = 9629564194426 := by decide
theorem cert_e833471172218 : check e833471172218 [] .sourceHead = true := by decide
def e833471172406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e833471172406 : Closed e833471172406 ∧ code e833471172406 = 9629564194614 := by decide
theorem cert_e833471172406 : check e833471172406 [] .sourceHead = true := by decide
def e833471172410 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e833471172410 : Closed e833471172410 ∧ code e833471172410 = 9629564194618 := by decide
theorem cert_e833471172410 : check e833471172410 [] .sourceHead = true := by decide
def e833471178158 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e833471178158 : Closed e833471178158 ∧ code e833471178158 = 9629564200366 := by decide
theorem cert_e833471178158 : check e833471178158 [] .sourceHead = true := by decide
def e833471178170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e833471178170 : Closed e833471178170 ∧ code e833471178170 = 9629564200378 := by decide
theorem cert_e833471178170 : check e833471178170 [] .sourceHead = true := by decide
def e833471178218 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e833471178218 : Closed e833471178218 ∧ code e833471178218 = 9629564200426 := by decide
theorem cert_e833471178218 : check e833471178218 [] .sourceHead = true := by decide
def e833471178350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e833471178350 : Closed e833471178350 ∧ code e833471178350 = 9629564200558 := by decide
theorem cert_e833471178350 : check e833471178350 [] .sourceHead = true := by decide
def e833471178362 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e833471178362 : Closed e833471178362 ∧ code e833471178362 = 9629564200570 := by decide
theorem cert_e833471178362 : check e833471178362 [] .sourceHead = true := by decide
def e833471178650 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e833471178650 : Closed e833471178650 ∧ code e833471178650 = 9629564200858 := by decide
theorem cert_e833471178650 : check e833471178650 [] .sourceHead = true := by decide
def e833471181526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e833471181526 : Closed e833471181526 ∧ code e833471181526 = 9629564203734 := by decide
theorem cert_e833471181526 : check e833471181526 [] .sourceHead = true := by decide
def e833471181530 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e833471181530 : Closed e833471181530 ∧ code e833471181530 = 9629564203738 := by decide
theorem cert_e833471181530 : check e833471181530 [] .sourceHead = true := by decide
def e833471181546 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e833471181546 : Closed e833471181546 ∧ code e833471181546 = 9629564203754 := by decide
theorem cert_e833471181546 : check e833471181546 [] .sourceHead = true := by decide
def e833471181622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e833471181622 : Closed e833471181622 ∧ code e833471181622 = 9629564203830 := by decide
theorem cert_e833471181622 : check e833471181622 [] .sourceHead = true := by decide
def e833471181626 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e833471181626 : Closed e833471181626 ∧ code e833471181626 = 9629564203834 := by decide
theorem cert_e833471181626 : check e833471181626 [] .sourceHead = true := by decide
def e833471181722 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e833471181722 : Closed e833471181722 ∧ code e833471181722 = 9629564203930 := by decide
theorem cert_e833471181722 : check e833471181722 [] .sourceHead = true := by decide
def e833471318894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e833471318894 : Closed e833471318894 ∧ code e833471318894 = 9629564341102 := by decide
theorem cert_e833471318894 : check e833471318894 [] .sourceHead = true := by decide
def e833471318902 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e833471318902 : Closed e833471318902 ∧ code e833471318902 = 9629564341110 := by decide
theorem cert_e833471318902 : check e833471318902 [] .sourceHead = true := by decide
def e833471318958 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e833471318958 : Closed e833471318958 ∧ code e833471318958 = 9629564341166 := by decide
theorem cert_e833471318958 : check e833471318958 [] .sourceHead = true := by decide
def e833471318970 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e833471318970 : Closed e833471318970 ∧ code e833471318970 = 9629564341178 := by decide
theorem cert_e833471318970 : check e833471318970 [] .sourceHead = true := by decide
def e833471318998 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e833471318998 : Closed e833471318998 ∧ code e833471318998 = 9629564341206 := by decide
theorem cert_e833471318998 : check e833471318998 [] .sourceHead = true := by decide
def e833471319002 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e833471319002 : Closed e833471319002 ∧ code e833471319002 = 9629564341210 := by decide
theorem cert_e833471319002 : check e833471319002 [] .sourceHead = true := by decide
def e833471319278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e833471319278 : Closed e833471319278 ∧ code e833471319278 = 9629564341486 := by decide
theorem cert_e833471319278 : check e833471319278 [] .sourceHead = true := by decide
def e833471319286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e833471319286 : Closed e833471319286 ∧ code e833471319286 = 9629564341494 := by decide
theorem cert_e833471319286 : check e833471319286 [] .sourceHead = true := by decide
def e833471319662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e833471319662 : Closed e833471319662 ∧ code e833471319662 = 9629564341870 := by decide
theorem cert_e833471319662 : check e833471319662 [] .sourceHead = true := by decide
def e833471319674 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e833471319674 : Closed e833471319674 ∧ code e833471319674 = 9629564341882 := by decide
theorem cert_e833471319674 : check e833471319674 [] .sourceHead = true := by decide
def e833471319862 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e833471319862 : Closed e833471319862 ∧ code e833471319862 = 9629564342070 := by decide
theorem cert_e833471319862 : check e833471319862 [] .sourceHead = true := by decide
def e833471319866 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e833471319866 : Closed e833471319866 ∧ code e833471319866 = 9629564342074 := by decide
theorem cert_e833471319866 : check e833471319866 [] .sourceHead = true := by decide
def e833478308038 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833478308038 : Closed e833478308038 ∧ code e833478308038 = 9629571330246 := by decide
theorem cert_e833478308038 : check e833478308038 [] .sourceHead = true := by decide
def e833478373574 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833478373574 : Closed e833478373574 ∧ code e833478373574 = 9629571395782 := by decide
theorem cert_e833478373574 : check e833478373574 [] .sourceHead = true := by decide
def e833478381766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833478381766 : Closed e833478381766 ∧ code e833478381766 = 9629571403974 := by decide
theorem cert_e833478381766 : check e833478381766 [] .sourceHead = true := by decide
def e833478701254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833478701254 : Closed e833478701254 ∧ code e833478701254 = 9629571723462 := by decide
theorem cert_e833478701254 : check e833478701254 [] .sourceHead = true := by decide
def e833479094470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833479094470 : Closed e833479094470 ∧ code e833479094470 = 9629572116678 := by decide
theorem cert_e833479094470 : check e833479094470 [] .sourceHead = true := by decide
def e833479102662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833479102662 : Closed e833479102662 ∧ code e833479102662 = 9629572124870 := by decide
theorem cert_e833479102662 : check e833479102662 [] .sourceHead = true := by decide
def e833964849690 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833964849690 : Closed e833964849690 ∧ code e833964849690 = 9630057871898 := by decide
theorem cert_e833964849690 : check e833964849690 [] .sourceHead = true := by decide
def e833964857882 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833964857882 : Closed e833964857882 ∧ code e833964857882 = 9630057880090 := by decide
theorem cert_e833964857882 : check e833964857882 [] .sourceHead = true := by decide
def e833964915226 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833964915226 : Closed e833964915226 ∧ code e833964915226 = 9630057937434 := by decide
theorem cert_e833964915226 : check e833964915226 [] .sourceHead = true := by decide
def e833964927514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833964927514 : Closed e833964927514 ∧ code e833964927514 = 9630057949722 := by decide
theorem cert_e833964927514 : check e833964927514 [] .sourceHead = true := by decide
def e833964956186 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833964956186 : Closed e833964956186 ∧ code e833964956186 = 9630057978394 := by decide
theorem cert_e833964956186 : check e833964956186 [] .sourceHead = true := by decide
def e833964960282 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833964960282 : Closed e833964960282 ∧ code e833964960282 = 9630057982490 := by decide
theorem cert_e833964960282 : check e833964960282 [] .sourceHead = true := by decide
def e833965242906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833965242906 : Closed e833965242906 ∧ code e833965242906 = 9630058265114 := by decide
theorem cert_e833965242906 : check e833965242906 [] .sourceHead = true := by decide
def e833965251098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833965251098 : Closed e833965251098 ∧ code e833965251098 = 9630058273306 := by decide
theorem cert_e833965251098 : check e833965251098 [] .sourceHead = true := by decide
def e833965636122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833965636122 : Closed e833965636122 ∧ code e833965636122 = 9630058658330 := by decide
theorem cert_e833965636122 : check e833965636122 [] .sourceHead = true := by decide
def e833965648410 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833965648410 : Closed e833965648410 ∧ code e833965648410 = 9630058670618 := by decide
theorem cert_e833965648410 : check e833965648410 [] .sourceHead = true := by decide
def e833965840922 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833965840922 : Closed e833965840922 ∧ code e833965840922 = 9630058863130 := by decide
theorem cert_e833965840922 : check e833965840922 [] .sourceHead = true := by decide
def e833965845018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833965845018 : Closed e833965845018 ∧ code e833965845018 = 9630058867226 := by decide
theorem cert_e833965845018 : check e833965845018 [] .sourceHead = true := by decide
def e833979379226 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979379226 : Closed e833979379226 ∧ code e833979379226 = 9630072401434 := by decide
theorem cert_e833979379226 : check e833979379226 [] .sourceHead = true := by decide
def e833979381274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979381274 : Closed e833979381274 ∧ code e833979381274 = 9630072403482 := by decide
theorem cert_e833979381274 : check e833979381274 [] .sourceHead = true := by decide
def e833979395610 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979395610 : Closed e833979395610 ∧ code e833979395610 = 9630072417818 := by decide
theorem cert_e833979395610 : check e833979395610 [] .sourceHead = true := by decide
def e833979398682 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979398682 : Closed e833979398682 ∧ code e833979398682 = 9630072420890 := by decide
theorem cert_e833979398682 : check e833979398682 [] .sourceHead = true := by decide
def e833979405850 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979405850 : Closed e833979405850 ∧ code e833979405850 = 9630072428058 := by decide
theorem cert_e833979405850 : check e833979405850 [] .sourceHead = true := by decide
def e833979406874 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979406874 : Closed e833979406874 ∧ code e833979406874 = 9630072429082 := by decide
theorem cert_e833979406874 : check e833979406874 [] .sourceHead = true := by decide
def e833979477530 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979477530 : Closed e833979477530 ∧ code e833979477530 = 9630072499738 := by decide
theorem cert_e833979477530 : check e833979477530 [] .sourceHead = true := by decide
def e833979479578 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979479578 : Closed e833979479578 ∧ code e833979479578 = 9630072501786 := by decide
theorem cert_e833979479578 : check e833979479578 [] .sourceHead = true := by decide
def e833979575834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979575834 : Closed e833979575834 ∧ code e833979575834 = 9630072598042 := by decide
theorem cert_e833979575834 : check e833979575834 [] .sourceHead = true := by decide
def e833979578906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979578906 : Closed e833979578906 ∧ code e833979578906 = 9630072601114 := by decide
theorem cert_e833979578906 : check e833979578906 [] .sourceHead = true := by decide
def e833979627034 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979627034 : Closed e833979627034 ∧ code e833979627034 = 9630072649242 := by decide
theorem cert_e833979627034 : check e833979627034 [] .sourceHead = true := by decide
def e833979628058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e833979628058 : Closed e833979628058 ∧ code e833979628058 = 9630072650266 := by decide
theorem cert_e833979628058 : check e833979628058 [] .sourceHead = true := by decide
def e833982868846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e833982868846 : Closed e833982868846 ∧ code e833982868846 = 9630075891054 := by decide
theorem cert_e833982868846 : check e833982868846 [] .sourceHead = true := by decide
def e833982868854 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e833982868854 : Closed e833982868854 ∧ code e833982868854 = 9630075891062 := by decide
theorem cert_e833982868854 : check e833982868854 [] .sourceHead = true := by decide
def e833982868910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e833982868910 : Closed e833982868910 ∧ code e833982868910 = 9630075891118 := by decide
theorem cert_e833982868910 : check e833982868910 [] .sourceHead = true := by decide
def e833982868922 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e833982868922 : Closed e833982868922 ∧ code e833982868922 = 9630075891130 := by decide
theorem cert_e833982868922 : check e833982868922 [] .sourceHead = true := by decide
def e833982868950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e833982868950 : Closed e833982868950 ∧ code e833982868950 = 9630075891158 := by decide
theorem cert_e833982868950 : check e833982868950 [] .sourceHead = true := by decide
def e833982868954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e833982868954 : Closed e833982868954 ∧ code e833982868954 = 9630075891162 := by decide
theorem cert_e833982868954 : check e833982868954 [] .sourceHead = true := by decide
def e833982869166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e833982869166 : Closed e833982869166 ∧ code e833982869166 = 9630075891374 := by decide
theorem cert_e833982869166 : check e833982869166 [] .sourceHead = true := by decide
def e833982869178 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e833982869178 : Closed e833982869178 ∧ code e833982869178 = 9630075891386 := by decide
theorem cert_e833982869178 : check e833982869178 [] .sourceHead = true := by decide
def e833982869226 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e833982869226 : Closed e833982869226 ∧ code e833982869226 = 9630075891434 := by decide
theorem cert_e833982869226 : check e833982869226 [] .sourceHead = true := by decide
def e833982869334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e833982869334 : Closed e833982869334 ∧ code e833982869334 = 9630075891542 := by decide
theorem cert_e833982869334 : check e833982869334 [] .sourceHead = true := by decide
def e833982869338 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e833982869338 : Closed e833982869338 ∧ code e833982869338 = 9630075891546 := by decide
theorem cert_e833982869338 : check e833982869338 [] .sourceHead = true := by decide
def e833982869354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e833982869354 : Closed e833982869354 ∧ code e833982869354 = 9630075891562 := by decide
theorem cert_e833982869354 : check e833982869354 [] .sourceHead = true := by decide
def e833982870382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e833982870382 : Closed e833982870382 ∧ code e833982870382 = 9630075892590 := by decide
theorem cert_e833982870382 : check e833982870382 [] .sourceHead = true := by decide
def e833982870390 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e833982870390 : Closed e833982870390 ∧ code e833982870390 = 9630075892598 := by decide
theorem cert_e833982870390 : check e833982870390 [] .sourceHead = true := by decide
def e833982870446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e833982870446 : Closed e833982870446 ∧ code e833982870446 = 9630075892654 := by decide
theorem cert_e833982870446 : check e833982870446 [] .sourceHead = true := by decide
def e833982870458 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e833982870458 : Closed e833982870458 ∧ code e833982870458 = 9630075892666 := by decide
theorem cert_e833982870458 : check e833982870458 [] .sourceHead = true := by decide
def e833982870486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e833982870486 : Closed e833982870486 ∧ code e833982870486 = 9630075892694 := by decide
theorem cert_e833982870486 : check e833982870486 [] .sourceHead = true := by decide
def e833982870490 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e833982870490 : Closed e833982870490 ∧ code e833982870490 = 9630075892698 := by decide
theorem cert_e833982870490 : check e833982870490 [] .sourceHead = true := by decide
def e833982870766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e833982870766 : Closed e833982870766 ∧ code e833982870766 = 9630075892974 := by decide
theorem cert_e833982870766 : check e833982870766 [] .sourceHead = true := by decide
def e833982870774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e833982870774 : Closed e833982870774 ∧ code e833982870774 = 9630075892982 := by decide
theorem cert_e833982870774 : check e833982870774 [] .sourceHead = true := by decide
def e833982871150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e833982871150 : Closed e833982871150 ∧ code e833982871150 = 9630075893358 := by decide
theorem cert_e833982871150 : check e833982871150 [] .sourceHead = true := by decide
def e833982871162 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e833982871162 : Closed e833982871162 ∧ code e833982871162 = 9630075893370 := by decide
theorem cert_e833982871162 : check e833982871162 [] .sourceHead = true := by decide
def e833982871350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e833982871350 : Closed e833982871350 ∧ code e833982871350 = 9630075893558 := by decide
theorem cert_e833982871350 : check e833982871350 [] .sourceHead = true := by decide
def e833982871354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e833982871354 : Closed e833982871354 ∧ code e833982871354 = 9630075893562 := by decide
theorem cert_e833982871354 : check e833982871354 [] .sourceHead = true := by decide
def e833982871982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e833982871982 : Closed e833982871982 ∧ code e833982871982 = 9630075894190 := by decide
theorem cert_e833982871982 : check e833982871982 [] .sourceHead = true := by decide
def e833982871994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e833982871994 : Closed e833982871994 ∧ code e833982871994 = 9630075894202 := by decide
theorem cert_e833982871994 : check e833982871994 [] .sourceHead = true := by decide
def e833982872042 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e833982872042 : Closed e833982872042 ∧ code e833982872042 = 9630075894250 := by decide
theorem cert_e833982872042 : check e833982872042 [] .sourceHead = true := by decide
def e833982872174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e833982872174 : Closed e833982872174 ∧ code e833982872174 = 9630075894382 := by decide
theorem cert_e833982872174 : check e833982872174 [] .sourceHead = true := by decide
def e833982872186 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e833982872186 : Closed e833982872186 ∧ code e833982872186 = 9630075894394 := by decide
theorem cert_e833982872186 : check e833982872186 [] .sourceHead = true := by decide
def e833982872474 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e833982872474 : Closed e833982872474 ∧ code e833982872474 = 9630075894682 := by decide
theorem cert_e833982872474 : check e833982872474 [] .sourceHead = true := by decide
def e833982872790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e833982872790 : Closed e833982872790 ∧ code e833982872790 = 9630075894998 := by decide
theorem cert_e833982872790 : check e833982872790 [] .sourceHead = true := by decide
def e833982872794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e833982872794 : Closed e833982872794 ∧ code e833982872794 = 9630075895002 := by decide
theorem cert_e833982872794 : check e833982872794 [] .sourceHead = true := by decide
def e833982872810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e833982872810 : Closed e833982872810 ∧ code e833982872810 = 9630075895018 := by decide
theorem cert_e833982872810 : check e833982872810 [] .sourceHead = true := by decide
def e833982872886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e833982872886 : Closed e833982872886 ∧ code e833982872886 = 9630075895094 := by decide
theorem cert_e833982872886 : check e833982872886 [] .sourceHead = true := by decide
def e833982872890 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e833982872890 : Closed e833982872890 ∧ code e833982872890 = 9630075895098 := by decide
theorem cert_e833982872890 : check e833982872890 [] .sourceHead = true := by decide
def e833982872986 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e833982872986 : Closed e833982872986 ∧ code e833982872986 = 9630075895194 := by decide
theorem cert_e833982872986 : check e833982872986 [] .sourceHead = true := by decide
def e833982876526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e833982876526 : Closed e833982876526 ∧ code e833982876526 = 9630075898734 := by decide
theorem cert_e833982876526 : check e833982876526 [] .sourceHead = true := by decide
def e833982876534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e833982876534 : Closed e833982876534 ∧ code e833982876534 = 9630075898742 := by decide
theorem cert_e833982876534 : check e833982876534 [] .sourceHead = true := by decide
def e833982876590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e833982876590 : Closed e833982876590 ∧ code e833982876590 = 9630075898798 := by decide
theorem cert_e833982876590 : check e833982876590 [] .sourceHead = true := by decide
def e833982876602 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e833982876602 : Closed e833982876602 ∧ code e833982876602 = 9630075898810 := by decide
theorem cert_e833982876602 : check e833982876602 [] .sourceHead = true := by decide
def e833982876630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e833982876630 : Closed e833982876630 ∧ code e833982876630 = 9630075898838 := by decide
theorem cert_e833982876630 : check e833982876630 [] .sourceHead = true := by decide
def e833982876634 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e833982876634 : Closed e833982876634 ∧ code e833982876634 = 9630075898842 := by decide
theorem cert_e833982876634 : check e833982876634 [] .sourceHead = true := by decide
def e833982876910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e833982876910 : Closed e833982876910 ∧ code e833982876910 = 9630075899118 := by decide
theorem cert_e833982876910 : check e833982876910 [] .sourceHead = true := by decide
def e833982876918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e833982876918 : Closed e833982876918 ∧ code e833982876918 = 9630075899126 := by decide
theorem cert_e833982876918 : check e833982876918 [] .sourceHead = true := by decide
def e833982877294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e833982877294 : Closed e833982877294 ∧ code e833982877294 = 9630075899502 := by decide
theorem cert_e833982877294 : check e833982877294 [] .sourceHead = true := by decide
def e833982877306 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e833982877306 : Closed e833982877306 ∧ code e833982877306 = 9630075899514 := by decide
theorem cert_e833982877306 : check e833982877306 [] .sourceHead = true := by decide
def e833982877494 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e833982877494 : Closed e833982877494 ∧ code e833982877494 = 9630075899702 := by decide
theorem cert_e833982877494 : check e833982877494 [] .sourceHead = true := by decide
def e833982877498 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e833982877498 : Closed e833982877498 ∧ code e833982877498 = 9630075899706 := by decide
theorem cert_e833982877498 : check e833982877498 [] .sourceHead = true := by decide
def e833982883246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e833982883246 : Closed e833982883246 ∧ code e833982883246 = 9630075905454 := by decide
theorem cert_e833982883246 : check e833982883246 [] .sourceHead = true := by decide
def e833982883258 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e833982883258 : Closed e833982883258 ∧ code e833982883258 = 9630075905466 := by decide
theorem cert_e833982883258 : check e833982883258 [] .sourceHead = true := by decide
def e833982883306 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e833982883306 : Closed e833982883306 ∧ code e833982883306 = 9630075905514 := by decide
theorem cert_e833982883306 : check e833982883306 [] .sourceHead = true := by decide
def e833982883438 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e833982883438 : Closed e833982883438 ∧ code e833982883438 = 9630075905646 := by decide
theorem cert_e833982883438 : check e833982883438 [] .sourceHead = true := by decide
def e833982883450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e833982883450 : Closed e833982883450 ∧ code e833982883450 = 9630075905658 := by decide
theorem cert_e833982883450 : check e833982883450 [] .sourceHead = true := by decide
def e833982883738 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e833982883738 : Closed e833982883738 ∧ code e833982883738 = 9630075905946 := by decide
theorem cert_e833982883738 : check e833982883738 [] .sourceHead = true := by decide
def e833982886614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e833982886614 : Closed e833982886614 ∧ code e833982886614 = 9630075908822 := by decide
theorem cert_e833982886614 : check e833982886614 [] .sourceHead = true := by decide
def e833982886618 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e833982886618 : Closed e833982886618 ∧ code e833982886618 = 9630075908826 := by decide
theorem cert_e833982886618 : check e833982886618 [] .sourceHead = true := by decide
def e833982886634 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e833982886634 : Closed e833982886634 ∧ code e833982886634 = 9630075908842 := by decide
theorem cert_e833982886634 : check e833982886634 [] .sourceHead = true := by decide
def e833982886710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e833982886710 : Closed e833982886710 ∧ code e833982886710 = 9630075908918 := by decide
theorem cert_e833982886710 : check e833982886710 [] .sourceHead = true := by decide
def e833982886714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e833982886714 : Closed e833982886714 ∧ code e833982886714 = 9630075908922 := by decide
theorem cert_e833982886714 : check e833982886714 [] .sourceHead = true := by decide
def e833982886810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e833982886810 : Closed e833982886810 ∧ code e833982886810 = 9630075909018 := by decide
theorem cert_e833982886810 : check e833982886810 [] .sourceHead = true := by decide
def e833983023982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e833983023982 : Closed e833983023982 ∧ code e833983023982 = 9630076046190 := by decide
theorem cert_e833983023982 : check e833983023982 [] .sourceHead = true := by decide
def e833983023990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e833983023990 : Closed e833983023990 ∧ code e833983023990 = 9630076046198 := by decide
theorem cert_e833983023990 : check e833983023990 [] .sourceHead = true := by decide
def e833983024046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e833983024046 : Closed e833983024046 ∧ code e833983024046 = 9630076046254 := by decide
theorem cert_e833983024046 : check e833983024046 [] .sourceHead = true := by decide
def e833983024058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e833983024058 : Closed e833983024058 ∧ code e833983024058 = 9630076046266 := by decide
theorem cert_e833983024058 : check e833983024058 [] .sourceHead = true := by decide
def e833983024086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e833983024086 : Closed e833983024086 ∧ code e833983024086 = 9630076046294 := by decide
theorem cert_e833983024086 : check e833983024086 [] .sourceHead = true := by decide
def e833983024090 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e833983024090 : Closed e833983024090 ∧ code e833983024090 = 9630076046298 := by decide
theorem cert_e833983024090 : check e833983024090 [] .sourceHead = true := by decide
end Blc.Floor43
