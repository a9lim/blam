import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605825628954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605825628954 : Closed e605825628954 ∧ code e605825628954 = 9401918651162 := by decide
theorem cert_e605825628954 : check e605825628954 [[.under],[.under]] .chain = true := by decide
def e605825628998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605825628998 : Closed e605825628998 ∧ code e605825628998 = 9401918651206 := by decide
theorem cert_e605825628998 : check e605825628998 [[.under],[.under]] .chain = true := by decide
def e605825633518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605825633518 : Closed e605825633518 ∧ code e605825633518 = 9401918655726 := by decide
theorem cert_e605825633518 : check e605825633518 [[.under],[.under]] .chain = true := by decide
def e605825633526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605825633526 : Closed e605825633526 ∧ code e605825633526 = 9401918655734 := by decide
theorem cert_e605825633526 : check e605825633526 [[.under],[.under]] .chain = true := by decide
def e605825633902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605825633902 : Closed e605825633902 ∧ code e605825633902 = 9401918656110 := by decide
theorem cert_e605825633902 : check e605825633902 [[.under],[.under]] .chain = true := by decide
def e605825633914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605825633914 : Closed e605825633914 ∧ code e605825633914 = 9401918656122 := by decide
theorem cert_e605825633914 : check e605825633914 [[.under],[.under]] .chain = true := by decide
def e605825634102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605825634102 : Closed e605825634102 ∧ code e605825634102 = 9401918656310 := by decide
theorem cert_e605825634102 : check e605825634102 [[.under],[.under]] .chain = true := by decide
def e605825634106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605825634106 : Closed e605825634106 ∧ code e605825634106 = 9401918656314 := by decide
theorem cert_e605825634106 : check e605825634106 [[.under],[.under]] .chain = true := by decide
def e605825636590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e605825636590 : Closed e605825636590 ∧ code e605825636590 = 9401918658798 := by decide
theorem cert_e605825636590 : check e605825636590 [[.under],[.under]] .chain = true := by decide
def e605825636598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e605825636598 : Closed e605825636598 ∧ code e605825636598 = 9401918658806 := by decide
theorem cert_e605825636598 : check e605825636598 [[.under],[.under]] .chain = true := by decide
def e605825637150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e605825637150 : Closed e605825637150 ∧ code e605825637150 = 9401918659358 := by decide
theorem cert_e605825637150 : check e605825637150 [[.under],[.under]] .chain = true := by decide
def e605825637262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e605825637262 : Closed e605825637262 ∧ code e605825637262 = 9401918659470 := by decide
theorem cert_e605825637262 : check e605825637262 [[.under],[.under]] .chain = true := by decide
def e605825637486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e605825637486 : Closed e605825637486 ∧ code e605825637486 = 9401918659694 := by decide
theorem cert_e605825637486 : check e605825637486 [[.under],[.under]] .chain = true := by decide
def e605825637498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e605825637498 : Closed e605825637498 ∧ code e605825637498 = 9401918659706 := by decide
theorem cert_e605825637498 : check e605825637498 [[.under],[.under]] .chain = true := by decide
def e605825637662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e605825637662 : Closed e605825637662 ∧ code e605825637662 = 9401918659870 := by decide
theorem cert_e605825637662 : check e605825637662 [[.under],[.under]] .chain = true := by decide
def e605825637830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e605825637830 : Closed e605825637830 ∧ code e605825637830 = 9401918660038 := by decide
theorem cert_e605825637830 : check e605825637830 [[.under],[.under]] .chain = true := by decide
def e605825637942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e605825637942 : Closed e605825637942 ∧ code e605825637942 = 9401918660150 := by decide
theorem cert_e605825637942 : check e605825637942 [[.under],[.under]] .chain = true := by decide
def e605825637946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605825637946 : Closed e605825637946 ∧ code e605825637946 = 9401918660154 := by decide
theorem cert_e605825637946 : check e605825637946 [[.under],[.under]] .chain = true := by decide
def e605825638030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e605825638030 : Closed e605825638030 ∧ code e605825638030 = 9401918660238 := by decide
theorem cert_e605825638030 : check e605825638030 [[.under],[.under]] .chain = true := by decide
def e605825638086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605825638086 : Closed e605825638086 ∧ code e605825638086 = 9401918660294 := by decide
theorem cert_e605825638086 : check e605825638086 [[.under],[.under]] .chain = true := by decide
def e605825640222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605825640222 : Closed e605825640222 ∧ code e605825640222 = 9401918662430 := by decide
theorem cert_e605825640222 : check e605825640222 [[.under],[.under]] .chain = true := by decide
def e605825640334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605825640334 : Closed e605825640334 ∧ code e605825640334 = 9401918662542 := by decide
theorem cert_e605825640334 : check e605825640334 [[.under],[.under]] .chain = true := by decide
def e605825643294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605825643294 : Closed e605825643294 ∧ code e605825643294 = 9401918665502 := by decide
theorem cert_e605825643294 : check e605825643294 [[.under],[.under]] .chain = true := by decide
def e605825643462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605825643462 : Closed e605825643462 ∧ code e605825643462 = 9401918665670 := by decide
theorem cert_e605825643462 : check e605825643462 [[.under],[.under]] .chain = true := by decide
def e605825644942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605825644942 : Closed e605825644942 ∧ code e605825644942 = 9401918667150 := by decide
theorem cert_e605825644942 : check e605825644942 [[.under],[.under]] .chain = true := by decide
def e605825644998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605825644998 : Closed e605825644998 ∧ code e605825644998 = 9401918667206 := by decide
theorem cert_e605825644998 : check e605825644998 [[.under],[.under]] .chain = true := by decide
def e605825648238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605825648238 : Closed e605825648238 ∧ code e605825648238 = 9401918670446 := by decide
theorem cert_e605825648238 : check e605825648238 [[.under],[.under]] .chain = true := by decide
def e605825648250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605825648250 : Closed e605825648250 ∧ code e605825648250 = 9401918670458 := by decide
theorem cert_e605825648250 : check e605825648250 [[.under],[.under]] .chain = true := by decide
def e605825648538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605825648538 : Closed e605825648538 ∧ code e605825648538 = 9401918670746 := by decide
theorem cert_e605825648538 : check e605825648538 [[.under],[.under]] .chain = true := by decide
def e605825649774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e605825649774 : Closed e605825649774 ∧ code e605825649774 = 9401918671982 := by decide
theorem cert_e605825649774 : check e605825649774 [[.under],[.under]] .chain = true := by decide
def e605825649786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e605825649786 : Closed e605825649786 ∧ code e605825649786 = 9401918671994 := by decide
theorem cert_e605825649786 : check e605825649786 [[.under],[.under]] .chain = true := by decide
def e605825649950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e605825649950 : Closed e605825649950 ∧ code e605825649950 = 9401918672158 := by decide
theorem cert_e605825649950 : check e605825649950 [[.under],[.under]] .chain = true := by decide
def e605825650118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e605825650118 : Closed e605825650118 ∧ code e605825650118 = 9401918672326 := by decide
theorem cert_e605825650118 : check e605825650118 [[.under],[.under]] .chain = true := by decide
def e605825650458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e605825650458 : Closed e605825650458 ∧ code e605825650458 = 9401918672666 := by decide
theorem cert_e605825650458 : check e605825650458 [[.under],[.under]] .chain = true := by decide
def e605825650502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e605825650502 : Closed e605825650502 ∧ code e605825650502 = 9401918672710 := by decide
theorem cert_e605825650502 : check e605825650502 [[.under],[.under]] .chain = true := by decide
def e605825651486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605825651486 : Closed e605825651486 ∧ code e605825651486 = 9401918673694 := by decide
theorem cert_e605825651486 : check e605825651486 [[.under],[.under]] .chain = true := by decide
def e605825651654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605825651654 : Closed e605825651654 ∧ code e605825651654 = 9401918673862 := by decide
theorem cert_e605825651654 : check e605825651654 [[.under],[.under]] .chain = true := by decide
def e605825653958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605825653958 : Closed e605825653958 ∧ code e605825653958 = 9401918676166 := by decide
theorem cert_e605825653958 : check e605825653958 [[.under],[.under]] .chain = true := by decide
def e605825655606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605825655606 : Closed e605825655606 ∧ code e605825655606 = 9401918677814 := by decide
theorem cert_e605825655606 : check e605825655606 [[.under],[.under]] .chain = true := by decide
def e605825655610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605825655610 : Closed e605825655610 ∧ code e605825655610 = 9401918677818 := by decide
theorem cert_e605825655610 : check e605825655610 [[.under],[.under]] .chain = true := by decide
def e605825655706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605825655706 : Closed e605825655706 ∧ code e605825655706 = 9401918677914 := by decide
theorem cert_e605825655706 : check e605825655706 [[.under],[.under]] .chain = true := by decide
def e605825656374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e605825656374 : Closed e605825656374 ∧ code e605825656374 = 9401918678582 := by decide
theorem cert_e605825656374 : check e605825656374 [[.under],[.under]] .chain = true := by decide
def e605825656378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605825656378 : Closed e605825656378 ∧ code e605825656378 = 9401918678586 := by decide
theorem cert_e605825656378 : check e605825656378 [[.under],[.under]] .chain = true := by decide
def e605825656462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e605825656462 : Closed e605825656462 ∧ code e605825656462 = 9401918678670 := by decide
theorem cert_e605825656462 : check e605825656462 [[.under],[.under]] .chain = true := by decide
def e605825656518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605825656518 : Closed e605825656518 ∧ code e605825656518 = 9401918678726 := by decide
theorem cert_e605825656518 : check e605825656518 [[.under],[.under]] .chain = true := by decide
def e605825656602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e605825656602 : Closed e605825656602 ∧ code e605825656602 = 9401918678810 := by decide
theorem cert_e605825656602 : check e605825656602 [[.under],[.under]] .chain = true := by decide
def e605825656646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e605825656646 : Closed e605825656646 ∧ code e605825656646 = 9401918678854 := by decide
theorem cert_e605825656646 : check e605825656646 [[.under],[.under]] .chain = true := by decide
def e605825657230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605825657230 : Closed e605825657230 ∧ code e605825657230 = 9401918679438 := by decide
theorem cert_e605825657230 : check e605825657230 [[.under],[.under]] .chain = true := by decide
def e605825657286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605825657286 : Closed e605825657286 ∧ code e605825657286 = 9401918679494 := by decide
theorem cert_e605825657286 : check e605825657286 [[.under],[.under]] .chain = true := by decide
def e605825658054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605825658054 : Closed e605825658054 ∧ code e605825658054 = 9401918680262 := by decide
theorem cert_e605825658054 : check e605825658054 [[.under],[.under]] .chain = true := by decide
def e605825668830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e605825668830 : Closed e605825668830 ∧ code e605825668830 = 9401918691038 := by decide
theorem cert_e605825668830 : check e605825668830 [[.under],[.under]] .chain = true := by decide
def e605825668854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e605825668854 : Closed e605825668854 ∧ code e605825668854 = 9401918691062 := by decide
theorem cert_e605825668854 : check e605825668854 [[.under],[.under]] .chain = true := by decide
def e605825668958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e605825668958 : Closed e605825668958 ∧ code e605825668958 = 9401918691166 := by decide
theorem cert_e605825668958 : check e605825668958 [[.under],[.under]] .chain = true := by decide
def e605825668986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e605825668986 : Closed e605825668986 ∧ code e605825668986 = 9401918691194 := by decide
theorem cert_e605825668986 : check e605825668986 [[.under],[.under]] .chain = true := by decide
def e605825669078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e605825669078 : Closed e605825669078 ∧ code e605825669078 = 9401918691286 := by decide
theorem cert_e605825669078 : check e605825669078 [[.under],[.under]] .chain = true := by decide
def e605825669082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e605825669082 : Closed e605825669082 ∧ code e605825669082 = 9401918691290 := by decide
theorem cert_e605825669082 : check e605825669082 [[.under],[.under]] .chain = true := by decide
def e605825669598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e605825669598 : Closed e605825669598 ∧ code e605825669598 = 9401918691806 := by decide
theorem cert_e605825669598 : check e605825669598 [[.under],[.under]] .chain = true := by decide
def e605825669622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e605825669622 : Closed e605825669622 ∧ code e605825669622 = 9401918691830 := by decide
theorem cert_e605825669622 : check e605825669622 [[.under],[.under]] .chain = true := by decide
def e605825670366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605825670366 : Closed e605825670366 ∧ code e605825670366 = 9401918692574 := by decide
theorem cert_e605825670366 : check e605825670366 [[.under],[.under]] .chain = true := by decide
def e605825670394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605825670394 : Closed e605825670394 ∧ code e605825670394 = 9401918692602 := by decide
theorem cert_e605825670394 : check e605825670394 [[.under],[.under]] .chain = true := by decide
def e605825670966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605825670966 : Closed e605825670966 ∧ code e605825670966 = 9401918693174 := by decide
theorem cert_e605825670966 : check e605825670966 [[.under],[.under]] .chain = true := by decide
def e605825670970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605825670970 : Closed e605825670970 ∧ code e605825670970 = 9401918693178 := by decide
theorem cert_e605825670970 : check e605825670970 [[.under],[.under]] .chain = true := by decide
def e605825685742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e605825685742 : Closed e605825685742 ∧ code e605825685742 = 9401918707950 := by decide
theorem cert_e605825685742 : check e605825685742 [[.under],[.under]] .chain = true := by decide
def e605825685750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e605825685750 : Closed e605825685750 ∧ code e605825685750 = 9401918707958 := by decide
theorem cert_e605825685750 : check e605825685750 [[.under],[.under]] .chain = true := by decide
def e605825686302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e605825686302 : Closed e605825686302 ∧ code e605825686302 = 9401918708510 := by decide
theorem cert_e605825686302 : check e605825686302 [[.under],[.under]] .chain = true := by decide
def e605825686414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e605825686414 : Closed e605825686414 ∧ code e605825686414 = 9401918708622 := by decide
theorem cert_e605825686414 : check e605825686414 [[.under],[.under]] .chain = true := by decide
def e605825686638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e605825686638 : Closed e605825686638 ∧ code e605825686638 = 9401918708846 := by decide
theorem cert_e605825686638 : check e605825686638 [[.under],[.under]] .chain = true := by decide
def e605825686650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e605825686650 : Closed e605825686650 ∧ code e605825686650 = 9401918708858 := by decide
theorem cert_e605825686650 : check e605825686650 [[.under],[.under]] .chain = true := by decide
def e605825686814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e605825686814 : Closed e605825686814 ∧ code e605825686814 = 9401918709022 := by decide
theorem cert_e605825686814 : check e605825686814 [[.under],[.under]] .chain = true := by decide
def e605825686982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e605825686982 : Closed e605825686982 ∧ code e605825686982 = 9401918709190 := by decide
theorem cert_e605825686982 : check e605825686982 [[.under],[.under]] .chain = true := by decide
def e605825687094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605825687094 : Closed e605825687094 ∧ code e605825687094 = 9401918709302 := by decide
theorem cert_e605825687094 : check e605825687094 [[.under],[.under]] .chain = true := by decide
def e605825687098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605825687098 : Closed e605825687098 ∧ code e605825687098 = 9401918709306 := by decide
theorem cert_e605825687098 : check e605825687098 [[.under],[.under]] .chain = true := by decide
def e605825687182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605825687182 : Closed e605825687182 ∧ code e605825687182 = 9401918709390 := by decide
theorem cert_e605825687182 : check e605825687182 [[.under],[.under]] .chain = true := by decide
def e605825687238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605825687238 : Closed e605825687238 ∧ code e605825687238 = 9401918709446 := by decide
theorem cert_e605825687238 : check e605825687238 [[.under],[.under]] .chain = true := by decide
def e605825689374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e605825689374 : Closed e605825689374 ∧ code e605825689374 = 9401918711582 := by decide
theorem cert_e605825689374 : check e605825689374 [[.under],[.under]] .chain = true := by decide
def e605825689486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e605825689486 : Closed e605825689486 ∧ code e605825689486 = 9401918711694 := by decide
theorem cert_e605825689486 : check e605825689486 [[.under],[.under]] .chain = true := by decide
def e605825692446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e605825692446 : Closed e605825692446 ∧ code e605825692446 = 9401918714654 := by decide
theorem cert_e605825692446 : check e605825692446 [[.under],[.under]] .chain = true := by decide
def e605825692614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e605825692614 : Closed e605825692614 ∧ code e605825692614 = 9401918714822 := by decide
theorem cert_e605825692614 : check e605825692614 [[.under],[.under]] .chain = true := by decide
def e605825694094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605825694094 : Closed e605825694094 ∧ code e605825694094 = 9401918716302 := by decide
theorem cert_e605825694094 : check e605825694094 [[.under],[.under]] .chain = true := by decide
def e605825694150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605825694150 : Closed e605825694150 ∧ code e605825694150 = 9401918716358 := by decide
theorem cert_e605825694150 : check e605825694150 [[.under],[.under]] .chain = true := by decide
def e605825731438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605825731438 : Closed e605825731438 ∧ code e605825731438 = 9401918753646 := by decide
theorem cert_e605825731438 : check e605825731438 [[.under],[.under]] .smaller = true := by decide
def e605825731446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605825731446 : Closed e605825731446 ∧ code e605825731446 = 9401918753654 := by decide
theorem cert_e605825731446 : check e605825731446 [[.under],[.under]] .smaller = true := by decide
def e605825731502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605825731502 : Closed e605825731502 ∧ code e605825731502 = 9401918753710 := by decide
theorem cert_e605825731502 : check e605825731502 [[.under],[.under]] .smaller = true := by decide
def e605825731514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605825731514 : Closed e605825731514 ∧ code e605825731514 = 9401918753722 := by decide
theorem cert_e605825731514 : check e605825731514 [[.under],[.under]] .smaller = true := by decide
def e605825731542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605825731542 : Closed e605825731542 ∧ code e605825731542 = 9401918753750 := by decide
theorem cert_e605825731542 : check e605825731542 [[.under],[.under]] .smaller = true := by decide
def e605825731546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605825731546 : Closed e605825731546 ∧ code e605825731546 = 9401918753754 := by decide
theorem cert_e605825731546 : check e605825731546 [[.under],[.under]] .smaller = true := by decide
def e605825731822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605825731822 : Closed e605825731822 ∧ code e605825731822 = 9401918754030 := by decide
theorem cert_e605825731822 : check e605825731822 [[.under],[.under]] .smaller = true := by decide
def e605825731830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605825731830 : Closed e605825731830 ∧ code e605825731830 = 9401918754038 := by decide
theorem cert_e605825731830 : check e605825731830 [[.under],[.under]] .smaller = true := by decide
def e605825732206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605825732206 : Closed e605825732206 ∧ code e605825732206 = 9401918754414 := by decide
theorem cert_e605825732206 : check e605825732206 [[.under],[.under]] .smaller = true := by decide
def e605825732218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605825732218 : Closed e605825732218 ∧ code e605825732218 = 9401918754426 := by decide
theorem cert_e605825732218 : check e605825732218 [[.under],[.under]] .smaller = true := by decide
def e605825732406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605825732406 : Closed e605825732406 ∧ code e605825732406 = 9401918754614 := by decide
theorem cert_e605825732406 : check e605825732406 [[.under],[.under]] .smaller = true := by decide
def e605825732410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605825732410 : Closed e605825732410 ∧ code e605825732410 = 9401918754618 := by decide
theorem cert_e605825732410 : check e605825732410 [[.under],[.under]] .smaller = true := by decide
def e605825739886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e605825739886 : Closed e605825739886 ∧ code e605825739886 = 9401918762094 := by decide
theorem cert_e605825739886 : check e605825739886 [[.under],[.under]] .chain = true := by decide
def e605825739898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e605825739898 : Closed e605825739898 ∧ code e605825739898 = 9401918762106 := by decide
theorem cert_e605825739898 : check e605825739898 [[.under],[.under]] .chain = true := by decide
def e605825740062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e605825740062 : Closed e605825740062 ∧ code e605825740062 = 9401918762270 := by decide
theorem cert_e605825740062 : check e605825740062 [[.under],[.under]] .chain = true := by decide
def e605825740230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e605825740230 : Closed e605825740230 ∧ code e605825740230 = 9401918762438 := by decide
theorem cert_e605825740230 : check e605825740230 [[.under],[.under]] .chain = true := by decide
def e605825740570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e605825740570 : Closed e605825740570 ∧ code e605825740570 = 9401918762778 := by decide
theorem cert_e605825740570 : check e605825740570 [[.under],[.under]] .chain = true := by decide
def e605825740614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e605825740614 : Closed e605825740614 ∧ code e605825740614 = 9401918762822 := by decide
theorem cert_e605825740614 : check e605825740614 [[.under],[.under]] .chain = true := by decide
def e605825741598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e605825741598 : Closed e605825741598 ∧ code e605825741598 = 9401918763806 := by decide
theorem cert_e605825741598 : check e605825741598 [[.under],[.under]] .chain = true := by decide
def e605825741766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e605825741766 : Closed e605825741766 ∧ code e605825741766 = 9401918763974 := by decide
theorem cert_e605825741766 : check e605825741766 [[.under],[.under]] .chain = true := by decide
def e605825744070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e605825744070 : Closed e605825744070 ∧ code e605825744070 = 9401918766278 := by decide
theorem cert_e605825744070 : check e605825744070 [[.under],[.under]] .chain = true := by decide
def e605825766966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605825766966 : Closed e605825766966 ∧ code e605825766966 = 9401918789174 := by decide
theorem cert_e605825766966 : check e605825766966 [[.under],[.under]] .chain = true := by decide
def e605825766970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605825766970 : Closed e605825766970 ∧ code e605825766970 = 9401918789178 := by decide
theorem cert_e605825766970 : check e605825766970 [[.under],[.under]] .chain = true := by decide
def e605825767054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605825767054 : Closed e605825767054 ∧ code e605825767054 = 9401918789262 := by decide
theorem cert_e605825767054 : check e605825767054 [[.under],[.under]] .chain = true := by decide
def e605825767110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605825767110 : Closed e605825767110 ∧ code e605825767110 = 9401918789318 := by decide
theorem cert_e605825767110 : check e605825767110 [[.under],[.under]] .chain = true := by decide
def e605825767194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e605825767194 : Closed e605825767194 ∧ code e605825767194 = 9401918789402 := by decide
theorem cert_e605825767194 : check e605825767194 [[.under],[.under]] .chain = true := by decide
def e605825767238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e605825767238 : Closed e605825767238 ∧ code e605825767238 = 9401918789446 := by decide
theorem cert_e605825767238 : check e605825767238 [[.under],[.under]] .chain = true := by decide
def e605825767822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605825767822 : Closed e605825767822 ∧ code e605825767822 = 9401918790030 := by decide
theorem cert_e605825767822 : check e605825767822 [[.under],[.under]] .chain = true := by decide
def e605825767878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605825767878 : Closed e605825767878 ∧ code e605825767878 = 9401918790086 := by decide
theorem cert_e605825767878 : check e605825767878 [[.under],[.under]] .chain = true := by decide
def e605825768646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e605825768646 : Closed e605825768646 ∧ code e605825768646 = 9401918790854 := by decide
theorem cert_e605825768646 : check e605825768646 [[.under],[.under]] .chain = true := by decide
def e605826865390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e605826865390 : Closed e605826865390 ∧ code e605826865390 = 9401919887598 := by decide
theorem cert_e605826865390 : check e605826865390 [[.under],[.under]] .chain = true := by decide
def e605826865398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e605826865398 : Closed e605826865398 ∧ code e605826865398 = 9401919887606 := by decide
theorem cert_e605826865398 : check e605826865398 [[.under],[.under]] .chain = true := by decide
def e605826865950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e605826865950 : Closed e605826865950 ∧ code e605826865950 = 9401919888158 := by decide
theorem cert_e605826865950 : check e605826865950 [[.under],[.under]] .chain = true := by decide
def e605826866062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e605826866062 : Closed e605826866062 ∧ code e605826866062 = 9401919888270 := by decide
theorem cert_e605826866062 : check e605826866062 [[.under],[.under]] .chain = true := by decide
def e605826866286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e605826866286 : Closed e605826866286 ∧ code e605826866286 = 9401919888494 := by decide
theorem cert_e605826866286 : check e605826866286 [[.under],[.under]] .chain = true := by decide
def e605826866298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e605826866298 : Closed e605826866298 ∧ code e605826866298 = 9401919888506 := by decide
theorem cert_e605826866298 : check e605826866298 [[.under],[.under]] .chain = true := by decide
def e605826866462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e605826866462 : Closed e605826866462 ∧ code e605826866462 = 9401919888670 := by decide
theorem cert_e605826866462 : check e605826866462 [[.under],[.under]] .chain = true := by decide
def e605826866630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e605826866630 : Closed e605826866630 ∧ code e605826866630 = 9401919888838 := by decide
theorem cert_e605826866630 : check e605826866630 [[.under],[.under]] .chain = true := by decide
def e605826866742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605826866742 : Closed e605826866742 ∧ code e605826866742 = 9401919888950 := by decide
theorem cert_e605826866742 : check e605826866742 [[.under],[.under]] .chain = true := by decide
def e605826866746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605826866746 : Closed e605826866746 ∧ code e605826866746 = 9401919888954 := by decide
theorem cert_e605826866746 : check e605826866746 [[.under],[.under]] .chain = true := by decide
def e605826866830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605826866830 : Closed e605826866830 ∧ code e605826866830 = 9401919889038 := by decide
theorem cert_e605826866830 : check e605826866830 [[.under],[.under]] .chain = true := by decide
def e605826866886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605826866886 : Closed e605826866886 ∧ code e605826866886 = 9401919889094 := by decide
theorem cert_e605826866886 : check e605826866886 [[.under],[.under]] .chain = true := by decide
def e605826869022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e605826869022 : Closed e605826869022 ∧ code e605826869022 = 9401919891230 := by decide
theorem cert_e605826869022 : check e605826869022 [[.under],[.under]] .chain = true := by decide
def e605826869134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e605826869134 : Closed e605826869134 ∧ code e605826869134 = 9401919891342 := by decide
theorem cert_e605826869134 : check e605826869134 [[.under],[.under]] .chain = true := by decide
def e605826872094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e605826872094 : Closed e605826872094 ∧ code e605826872094 = 9401919894302 := by decide
theorem cert_e605826872094 : check e605826872094 [[.under],[.under]] .chain = true := by decide
def e605826872262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e605826872262 : Closed e605826872262 ∧ code e605826872262 = 9401919894470 := by decide
theorem cert_e605826872262 : check e605826872262 [[.under],[.under]] .chain = true := by decide
def e605826873742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605826873742 : Closed e605826873742 ∧ code e605826873742 = 9401919895950 := by decide
theorem cert_e605826873742 : check e605826873742 [[.under],[.under]] .chain = true := by decide
def e605826873798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605826873798 : Closed e605826873798 ∧ code e605826873798 = 9401919896006 := by decide
theorem cert_e605826873798 : check e605826873798 [[.under],[.under]] .chain = true := by decide
def e605831567070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e605831567070 : Closed e605831567070 ∧ code e605831567070 = 9401924589278 := by decide
theorem cert_e605831567070 : check e605831567070 [[.under],[.under]] .sourceHead = true := by decide
def e605831567094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e605831567094 : Closed e605831567094 ∧ code e605831567094 = 9401924589302 := by decide
theorem cert_e605831567094 : check e605831567094 [[.under],[.under]] .sourceHead = true := by decide
def e605831567198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e605831567198 : Closed e605831567198 ∧ code e605831567198 = 9401924589406 := by decide
theorem cert_e605831567198 : check e605831567198 [[.under],[.under]] .sourceHead = true := by decide
def e605831567226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e605831567226 : Closed e605831567226 ∧ code e605831567226 = 9401924589434 := by decide
theorem cert_e605831567226 : check e605831567226 [[.under],[.under]] .sourceHead = true := by decide
def e605831567318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e605831567318 : Closed e605831567318 ∧ code e605831567318 = 9401924589526 := by decide
theorem cert_e605831567318 : check e605831567318 [[.under],[.under]] .sourceHead = true := by decide
def e605831567322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e605831567322 : Closed e605831567322 ∧ code e605831567322 = 9401924589530 := by decide
theorem cert_e605831567322 : check e605831567322 [[.under],[.under]] .sourceHead = true := by decide
def e605831567838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e605831567838 : Closed e605831567838 ∧ code e605831567838 = 9401924590046 := by decide
theorem cert_e605831567838 : check e605831567838 [[.under],[.under]] .sourceHead = true := by decide
def e605831567862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e605831567862 : Closed e605831567862 ∧ code e605831567862 = 9401924590070 := by decide
theorem cert_e605831567862 : check e605831567862 [[.under],[.under]] .sourceHead = true := by decide
def e605831568606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605831568606 : Closed e605831568606 ∧ code e605831568606 = 9401924590814 := by decide
theorem cert_e605831568606 : check e605831568606 [[.under],[.under]] .sourceHead = true := by decide
def e605831568634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605831568634 : Closed e605831568634 ∧ code e605831568634 = 9401924590842 := by decide
theorem cert_e605831568634 : check e605831568634 [[.under],[.under]] .sourceHead = true := by decide
def e605831569206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605831569206 : Closed e605831569206 ∧ code e605831569206 = 9401924591414 := by decide
theorem cert_e605831569206 : check e605831569206 [[.under],[.under]] .sourceHead = true := by decide
def e605831569210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605831569210 : Closed e605831569210 ∧ code e605831569210 = 9401924591418 := by decide
theorem cert_e605831569210 : check e605831569210 [[.under],[.under]] .sourceHead = true := by decide
def e605831583982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e605831583982 : Closed e605831583982 ∧ code e605831583982 = 9401924606190 := by decide
theorem cert_e605831583982 : check e605831583982 [[.under],[.under]] .sourceHead = true := by decide
def e605831583990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e605831583990 : Closed e605831583990 ∧ code e605831583990 = 9401924606198 := by decide
theorem cert_e605831583990 : check e605831583990 [[.under],[.under]] .sourceHead = true := by decide
def e605831584542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e605831584542 : Closed e605831584542 ∧ code e605831584542 = 9401924606750 := by decide
theorem cert_e605831584542 : check e605831584542 [[.under],[.under]] .sourceHead = true := by decide
def e605831584654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e605831584654 : Closed e605831584654 ∧ code e605831584654 = 9401924606862 := by decide
theorem cert_e605831584654 : check e605831584654 [[.under],[.under]] .sourceHead = true := by decide
def e605831584878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e605831584878 : Closed e605831584878 ∧ code e605831584878 = 9401924607086 := by decide
theorem cert_e605831584878 : check e605831584878 [[.under],[.under]] .sourceHead = true := by decide
def e605831584890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e605831584890 : Closed e605831584890 ∧ code e605831584890 = 9401924607098 := by decide
theorem cert_e605831584890 : check e605831584890 [[.under],[.under]] .sourceHead = true := by decide
def e605831585054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e605831585054 : Closed e605831585054 ∧ code e605831585054 = 9401924607262 := by decide
theorem cert_e605831585054 : check e605831585054 [[.under],[.under]] .sourceHead = true := by decide
def e605831585222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e605831585222 : Closed e605831585222 ∧ code e605831585222 = 9401924607430 := by decide
theorem cert_e605831585222 : check e605831585222 [[.under],[.under]] .sourceHead = true := by decide
def e605831585334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605831585334 : Closed e605831585334 ∧ code e605831585334 = 9401924607542 := by decide
theorem cert_e605831585334 : check e605831585334 [[.under],[.under]] .sourceHead = true := by decide
def e605831585338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605831585338 : Closed e605831585338 ∧ code e605831585338 = 9401924607546 := by decide
theorem cert_e605831585338 : check e605831585338 [[.under],[.under]] .sourceHead = true := by decide
def e605831585422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605831585422 : Closed e605831585422 ∧ code e605831585422 = 9401924607630 := by decide
theorem cert_e605831585422 : check e605831585422 [[.under],[.under]] .sourceHead = true := by decide
def e605831585478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605831585478 : Closed e605831585478 ∧ code e605831585478 = 9401924607686 := by decide
theorem cert_e605831585478 : check e605831585478 [[.under],[.under]] .sourceHead = true := by decide
def e605831587614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e605831587614 : Closed e605831587614 ∧ code e605831587614 = 9401924609822 := by decide
theorem cert_e605831587614 : check e605831587614 [[.under],[.under]] .sourceHead = true := by decide
def e605831587726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e605831587726 : Closed e605831587726 ∧ code e605831587726 = 9401924609934 := by decide
theorem cert_e605831587726 : check e605831587726 [[.under],[.under]] .sourceHead = true := by decide
def e605831590686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e605831590686 : Closed e605831590686 ∧ code e605831590686 = 9401924612894 := by decide
theorem cert_e605831590686 : check e605831590686 [[.under],[.under]] .sourceHead = true := by decide
def e605831590854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e605831590854 : Closed e605831590854 ∧ code e605831590854 = 9401924613062 := by decide
theorem cert_e605831590854 : check e605831590854 [[.under],[.under]] .sourceHead = true := by decide
def e605831592334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605831592334 : Closed e605831592334 ∧ code e605831592334 = 9401924614542 := by decide
theorem cert_e605831592334 : check e605831592334 [[.under],[.under]] .sourceHead = true := by decide
def e605831592390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605831592390 : Closed e605831592390 ∧ code e605831592390 = 9401924614598 := by decide
theorem cert_e605831592390 : check e605831592390 [[.under],[.under]] .sourceHead = true := by decide
def e606177778586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177778586 : Closed e606177778586 ∧ code e606177778586 = 9402270800794 := by decide
theorem cert_e606177778586 : check e606177778586 [[.under],[.under,.left]] .chain = true := by decide
def e606177779098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177779098 : Closed e606177779098 ∧ code e606177779098 = 9402270801306 := by decide
theorem cert_e606177779098 : check e606177779098 [[.under],[.under,.left]] .chain = true := by decide
end Blc.Floor43
