import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389344937402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2389344937402 : Closed e2389344937402 ∧ code e2389344937402 = 11185437959610 := by decide
theorem cert_e2389344937402 : check e2389344937402 [[],[.left],[]] .chain = true := by decide
def e2389344937450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2389344937450 : Closed e2389344937450 ∧ code e2389344937450 = 11185437959658 := by decide
theorem cert_e2389344937450 : check e2389344937450 [[],[.left],[]] .chain = true := by decide
def e2389344937582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344937582 : Closed e2389344937582 ∧ code e2389344937582 = 11185437959790 := by decide
theorem cert_e2389344937582 : check e2389344937582 [[],[.left],[]] .chain = true := by decide
def e2389344937594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344937594 : Closed e2389344937594 ∧ code e2389344937594 = 11185437959802 := by decide
theorem cert_e2389344937594 : check e2389344937594 [[],[.left],[]] .chain = true := by decide
def e2389344937758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2389344937758 : Closed e2389344937758 ∧ code e2389344937758 = 11185437959966 := by decide
theorem cert_e2389344937758 : check e2389344937758 [[],[.left],[],[.under]] .three = true := by decide
def e2389344937870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2389344937870 : Closed e2389344937870 ∧ code e2389344937870 = 11185437960078 := by decide
theorem cert_e2389344937870 : check e2389344937870 [[],[.left],[],[.under]] .three = true := by decide
def e2389344937882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344937882 : Closed e2389344937882 ∧ code e2389344937882 = 11185437960090 := by decide
theorem cert_e2389344937882 : check e2389344937882 [[],[.left],[]] .chain = true := by decide
def e2389344940830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2389344940830 : Closed e2389344940830 ∧ code e2389344940830 = 11185437963038 := by decide
theorem cert_e2389344940830 : check e2389344940830 [[],[.left],[],[.under]] .three = true := by decide
def e2389344940998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2389344940998 : Closed e2389344940998 ∧ code e2389344940998 = 11185437963206 := by decide
theorem cert_e2389344940998 : check e2389344940998 [[],[.left],[],[.under]] .three = true := by decide
def e2389344942198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2389344942198 : Closed e2389344942198 ∧ code e2389344942198 = 11185437964406 := by decide
theorem cert_e2389344942198 : check e2389344942198 [[],[.left],[]] .chain = true := by decide
def e2389344942442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2389344942442 : Closed e2389344942442 ∧ code e2389344942442 = 11185437964650 := by decide
theorem cert_e2389344942442 : check e2389344942442 [[],[.left],[]] .chain = true := by decide
def e2389344942478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2389344942478 : Closed e2389344942478 ∧ code e2389344942478 = 11185437964686 := by decide
theorem cert_e2389344942478 : check e2389344942478 [[],[.left],[],[.under]] .three = true := by decide
def e2389344942490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344942490 : Closed e2389344942490 ∧ code e2389344942490 = 11185437964698 := by decide
theorem cert_e2389344942490 : check e2389344942490 [[],[.left],[]] .chain = true := by decide
def e2389344942534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2389344942534 : Closed e2389344942534 ∧ code e2389344942534 = 11185437964742 := by decide
theorem cert_e2389344942534 : check e2389344942534 [[],[.left],[],[.under]] .three = true := by decide
def e2389344987990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2389344987990 : Closed e2389344987990 ∧ code e2389344987990 = 11185438010198 := by decide
theorem cert_e2389344987990 : check e2389344987990 [[],[.left],[]] .chain = true := by decide
def e2389344987994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2389344987994 : Closed e2389344987994 ∧ code e2389344987994 = 11185438010202 := by decide
theorem cert_e2389344987994 : check e2389344987994 [[],[.left],[]] .chain = true := by decide
def e2389344988010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2389344988010 : Closed e2389344988010 ∧ code e2389344988010 = 11185438010218 := by decide
theorem cert_e2389344988010 : check e2389344988010 [[],[.left],[]] .chain = true := by decide
def e2389344988074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2389344988074 : Closed e2389344988074 ∧ code e2389344988074 = 11185438010282 := by decide
theorem cert_e2389344988074 : check e2389344988074 [[],[.left],[]] .chain = true := by decide
def e2389344988278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2389344988278 : Closed e2389344988278 ∧ code e2389344988278 = 11185438010486 := by decide
theorem cert_e2389344988278 : check e2389344988278 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389344988374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2389344988374 : Closed e2389344988374 ∧ code e2389344988374 = 11185438010582 := by decide
theorem cert_e2389344988374 : check e2389344988374 [[],[.left],[]] .chain = true := by decide
def e2389344988378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2389344988378 : Closed e2389344988378 ∧ code e2389344988378 = 11185438010586 := by decide
theorem cert_e2389344988378 : check e2389344988378 [[],[.left],[]] .chain = true := by decide
def e2389344988394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2389344988394 : Closed e2389344988394 ∧ code e2389344988394 = 11185438010602 := by decide
theorem cert_e2389344988394 : check e2389344988394 [[],[.left],[]] .chain = true := by decide
def e2389344988470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344988470 : Closed e2389344988470 ∧ code e2389344988470 = 11185438010678 := by decide
theorem cert_e2389344988470 : check e2389344988470 [[],[.left],[]] .chain = true := by decide
def e2389344988474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344988474 : Closed e2389344988474 ∧ code e2389344988474 = 11185438010682 := by decide
theorem cert_e2389344988474 : check e2389344988474 [[],[.left],[]] .chain = true := by decide
def e2389344988558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2389344988558 : Closed e2389344988558 ∧ code e2389344988558 = 11185438010766 := by decide
theorem cert_e2389344988558 : check e2389344988558 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389344988570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344988570 : Closed e2389344988570 ∧ code e2389344988570 = 11185438010778 := by decide
theorem cert_e2389344988570 : check e2389344988570 [[],[.left],[]] .chain = true := by decide
def e2389344988726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2389344988726 : Closed e2389344988726 ∧ code e2389344988726 = 11185438010934 := by decide
theorem cert_e2389344988726 : check e2389344988726 [[],[.left],[],[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e2389344988730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2389344988730 : Closed e2389344988730 ∧ code e2389344988730 = 11185438010938 := by decide
theorem cert_e2389344988730 : check e2389344988730 [[],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e2389344988778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2389344988778 : Closed e2389344988778 ∧ code e2389344988778 = 11185438010986 := by decide
theorem cert_e2389344988778 : check e2389344988778 [[],[.left],[]] .chain = true := by decide
def e2389344988814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2389344988814 : Closed e2389344988814 ∧ code e2389344988814 = 11185438011022 := by decide
theorem cert_e2389344988814 : check e2389344988814 [[],[.left],[],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e2389344988826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344988826 : Closed e2389344988826 ∧ code e2389344988826 = 11185438011034 := by decide
theorem cert_e2389344988826 : check e2389344988826 [[],[.left],[]] .chain = true := by decide
def e2389344988870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2389344988870 : Closed e2389344988870 ∧ code e2389344988870 = 11185438011078 := by decide
theorem cert_e2389344988870 : check e2389344988870 [[],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e2389344989422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2389344989422 : Closed e2389344989422 ∧ code e2389344989422 = 11185438011630 := by decide
theorem cert_e2389344989422 : check e2389344989422 [[],[.left],[]] .chain = true := by decide
def e2389344989430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2389344989430 : Closed e2389344989430 ∧ code e2389344989430 = 11185438011638 := by decide
theorem cert_e2389344989430 : check e2389344989430 [[],[.left],[]] .chain = true := by decide
def e2389344989910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2389344989910 : Closed e2389344989910 ∧ code e2389344989910 = 11185438012118 := by decide
theorem cert_e2389344989910 : check e2389344989910 [[],[.left],[]] .chain = true := by decide
def e2389344989914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2389344989914 : Closed e2389344989914 ∧ code e2389344989914 = 11185438012122 := by decide
theorem cert_e2389344989914 : check e2389344989914 [[],[.left],[]] .chain = true := by decide
def e2389344989930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2389344989930 : Closed e2389344989930 ∧ code e2389344989930 = 11185438012138 := by decide
theorem cert_e2389344989930 : check e2389344989930 [[],[.left],[]] .chain = true := by decide
def e2389344990006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344990006 : Closed e2389344990006 ∧ code e2389344990006 = 11185438012214 := by decide
theorem cert_e2389344990006 : check e2389344990006 [[],[.left],[]] .chain = true := by decide
def e2389344990010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344990010 : Closed e2389344990010 ∧ code e2389344990010 = 11185438012218 := by decide
theorem cert_e2389344990010 : check e2389344990010 [[],[.left],[]] .chain = true := by decide
def e2389344990094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2389344990094 : Closed e2389344990094 ∧ code e2389344990094 = 11185438012302 := by decide
theorem cert_e2389344990094 : check e2389344990094 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389344990106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344990106 : Closed e2389344990106 ∧ code e2389344990106 = 11185438012314 := by decide
theorem cert_e2389344990106 : check e2389344990106 [[],[.left],[]] .chain = true := by decide
def e2389344991350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2389344991350 : Closed e2389344991350 ∧ code e2389344991350 = 11185438013558 := by decide
theorem cert_e2389344991350 : check e2389344991350 [[],[.left],[]] .chain = true := by decide
def e2389344991594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2389344991594 : Closed e2389344991594 ∧ code e2389344991594 = 11185438013802 := by decide
theorem cert_e2389344991594 : check e2389344991594 [[],[.left],[]] .chain = true := by decide
def e2389344991630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2389344991630 : Closed e2389344991630 ∧ code e2389344991630 = 11185438013838 := by decide
theorem cert_e2389344991630 : check e2389344991630 [[],[.left],[],[.under],[.under]] .three = true := by decide
def e2389344991642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344991642 : Closed e2389344991642 ∧ code e2389344991642 = 11185438013850 := by decide
theorem cert_e2389344991642 : check e2389344991642 [[],[.left],[]] .chain = true := by decide
def e2389344991686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2389344991686 : Closed e2389344991686 ∧ code e2389344991686 = 11185438013894 := by decide
theorem cert_e2389344991686 : check e2389344991686 [[],[.left],[],[.under],[.under]] .three = true := by decide
def e2389346889146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e2389346889146 : Closed e2389346889146 ∧ code e2389346889146 = 11185439911354 := by decide
def e2389346889178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e2389346889178 : Closed e2389346889178 ∧ code e2389346889178 = 11185439911386 := by decide
def e2389346889402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e2389346889402 : Closed e2389346889402 ∧ code e2389346889402 = 11185439911610 := by decide
def e2389346889450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e2389346889450 : Closed e2389346889450 ∧ code e2389346889450 = 11185439911658 := by decide
def e2389346889562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e2389346889562 : Closed e2389346889562 ∧ code e2389346889562 = 11185439911770 := by decide
def e2389346889578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e2389346889578 : Closed e2389346889578 ∧ code e2389346889578 = 11185439911786 := by decide
def e2389346890682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e2389346890682 : Closed e2389346890682 ∧ code e2389346890682 = 11185439912890 := by decide
def e2389346890714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e2389346890714 : Closed e2389346890714 ∧ code e2389346890714 = 11185439912922 := by decide
def e2389346892218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e2389346892218 : Closed e2389346892218 ∧ code e2389346892218 = 11185439914426 := by decide
def e2389346892266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e2389346892266 : Closed e2389346892266 ∧ code e2389346892266 = 11185439914474 := by decide
def e2389346893018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e2389346893018 : Closed e2389346893018 ∧ code e2389346893018 = 11185439915226 := by decide
def e2389346893034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e2389346893034 : Closed e2389346893034 ∧ code e2389346893034 = 11185439915242 := by decide
def e2389346945902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389346945902 : Closed e2389346945902 ∧ code e2389346945902 = 11185439968110 := by decide
theorem cert_e2389346945902 : check e2389346945902 [[],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2389346945910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389346945910 : Closed e2389346945910 ∧ code e2389346945910 = 11185439968118 := by decide
def e2389346945966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389346945966 : Closed e2389346945966 ∧ code e2389346945966 = 11185439968174 := by decide
theorem cert_e2389346945966 : check e2389346945966 [[],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2389346945978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389346945978 : Closed e2389346945978 ∧ code e2389346945978 = 11185439968186 := by decide
def e2389346946006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389346946006 : Closed e2389346946006 ∧ code e2389346946006 = 11185439968214 := by decide
def e2389346946010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389346946010 : Closed e2389346946010 ∧ code e2389346946010 = 11185439968218 := by decide
def e2389346946286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389346946286 : Closed e2389346946286 ∧ code e2389346946286 = 11185439968494 := by decide
def e2389346946294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389346946294 : Closed e2389346946294 ∧ code e2389346946294 = 11185439968502 := by decide
def e2389346946670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389346946670 : Closed e2389346946670 ∧ code e2389346946670 = 11185439968878 := by decide
def e2389346946682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389346946682 : Closed e2389346946682 ∧ code e2389346946682 = 11185439968890 := by decide
def e2389346946870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389346946870 : Closed e2389346946870 ∧ code e2389346946870 = 11185439969078 := by decide
def e2389346946874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389346946874 : Closed e2389346946874 ∧ code e2389346946874 = 11185439969082 := by decide
def e2389347151326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2389347151326 : Closed e2389347151326 ∧ code e2389347151326 = 11185440173534 := by decide
theorem cert_e2389347151326 : check e2389347151326 [[],[.left],[],[]] .chain = true := by decide
def e2389347151342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2389347151342 : Closed e2389347151342 ∧ code e2389347151342 = 11185440173550 := by decide
theorem cert_e2389347151342 : check e2389347151342 [[],[.left],[],[]] .chain = true := by decide
def e2389347151710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2389347151710 : Closed e2389347151710 ∧ code e2389347151710 = 11185440173918 := by decide
theorem cert_e2389347151710 : check e2389347151710 [[],[.left],[],[]] .chain = true := by decide
def e2389347151738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2389347151738 : Closed e2389347151738 ∧ code e2389347151738 = 11185440173946 := by decide
theorem cert_e2389347151738 : check e2389347151738 [[],[.left],[],[]] .chain = true := by decide
def e2389347151790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2389347151790 : Closed e2389347151790 ∧ code e2389347151790 = 11185440173998 := by decide
theorem cert_e2389347151790 : check e2389347151790 [[],[.left],[],[]] .chain = true := by decide
def e2389347151802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2389347151802 : Closed e2389347151802 ∧ code e2389347151802 = 11185440174010 := by decide
theorem cert_e2389347151802 : check e2389347151802 [[],[.left],[],[]] .chain = true := by decide
def e2389347152862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2389347152862 : Closed e2389347152862 ∧ code e2389347152862 = 11185440175070 := by decide
theorem cert_e2389347152862 : check e2389347152862 [[],[.left],[],[]] .chain = true := by decide
def e2389347152878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2389347152878 : Closed e2389347152878 ∧ code e2389347152878 = 11185440175086 := by decide
theorem cert_e2389347152878 : check e2389347152878 [[],[.left],[],[]] .chain = true := by decide
def e2389347155166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389347155166 : Closed e2389347155166 ∧ code e2389347155166 = 11185440177374 := by decide
theorem cert_e2389347155166 : check e2389347155166 [[],[.left],[],[]] .chain = true := by decide
def e2389347155194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389347155194 : Closed e2389347155194 ∧ code e2389347155194 = 11185440177402 := by decide
theorem cert_e2389347155194 : check e2389347155194 [[],[.left],[],[]] .chain = true := by decide
def e2389347155566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389347155566 : Closed e2389347155566 ∧ code e2389347155566 = 11185440177774 := by decide
theorem cert_e2389347155566 : check e2389347155566 [[],[.left],[],[]] .chain = true := by decide
def e2389347155578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389347155578 : Closed e2389347155578 ∧ code e2389347155578 = 11185440177786 := by decide
theorem cert_e2389347155578 : check e2389347155578 [[],[.left],[],[]] .chain = true := by decide
def e2389347183982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2389347183982 : Closed e2389347183982 ∧ code e2389347183982 = 11185440206190 := by decide
theorem cert_e2389347183982 : check e2389347183982 [[],[.left],[],[]] .chain = true := by decide
def e2389347183990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2389347183990 : Closed e2389347183990 ∧ code e2389347183990 = 11185440206198 := by decide
theorem cert_e2389347183990 : check e2389347183990 [[],[.left],[],[]] .chain = true := by decide
def e2389347184046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2389347184046 : Closed e2389347184046 ∧ code e2389347184046 = 11185440206254 := by decide
theorem cert_e2389347184046 : check e2389347184046 [[],[.left],[],[]] .chain = true := by decide
def e2389347184058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2389347184058 : Closed e2389347184058 ∧ code e2389347184058 = 11185440206266 := by decide
theorem cert_e2389347184058 : check e2389347184058 [[],[.left],[],[]] .chain = true := by decide
def e2389347184086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2389347184086 : Closed e2389347184086 ∧ code e2389347184086 = 11185440206294 := by decide
theorem cert_e2389347184086 : check e2389347184086 [[],[.left],[],[]] .chain = true := by decide
def e2389347184090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2389347184090 : Closed e2389347184090 ∧ code e2389347184090 = 11185440206298 := by decide
theorem cert_e2389347184090 : check e2389347184090 [[],[.left],[],[]] .chain = true := by decide
def e2389347184302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2389347184302 : Closed e2389347184302 ∧ code e2389347184302 = 11185440206510 := by decide
theorem cert_e2389347184302 : check e2389347184302 [[],[.left],[],[]] .chain = true := by decide
def e2389347184314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2389347184314 : Closed e2389347184314 ∧ code e2389347184314 = 11185440206522 := by decide
theorem cert_e2389347184314 : check e2389347184314 [[],[.left],[],[]] .chain = true := by decide
def e2389347184362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2389347184362 : Closed e2389347184362 ∧ code e2389347184362 = 11185440206570 := by decide
theorem cert_e2389347184362 : check e2389347184362 [[],[.left],[],[]] .chain = true := by decide
def e2389347184470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2389347184470 : Closed e2389347184470 ∧ code e2389347184470 = 11185440206678 := by decide
theorem cert_e2389347184470 : check e2389347184470 [[],[.left],[],[]] .chain = true := by decide
def e2389347184474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2389347184474 : Closed e2389347184474 ∧ code e2389347184474 = 11185440206682 := by decide
theorem cert_e2389347184474 : check e2389347184474 [[],[.left],[],[]] .chain = true := by decide
def e2389347184490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2389347184490 : Closed e2389347184490 ∧ code e2389347184490 = 11185440206698 := by decide
theorem cert_e2389347184490 : check e2389347184490 [[],[.left],[],[]] .chain = true := by decide
def e2389347185518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2389347185518 : Closed e2389347185518 ∧ code e2389347185518 = 11185440207726 := by decide
theorem cert_e2389347185518 : check e2389347185518 [[],[.left],[],[]] .chain = true := by decide
def e2389347185526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2389347185526 : Closed e2389347185526 ∧ code e2389347185526 = 11185440207734 := by decide
theorem cert_e2389347185526 : check e2389347185526 [[],[.left],[],[]] .chain = true := by decide
def e2389347185582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2389347185582 : Closed e2389347185582 ∧ code e2389347185582 = 11185440207790 := by decide
theorem cert_e2389347185582 : check e2389347185582 [[],[.left],[],[]] .chain = true := by decide
def e2389347185594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2389347185594 : Closed e2389347185594 ∧ code e2389347185594 = 11185440207802 := by decide
theorem cert_e2389347185594 : check e2389347185594 [[],[.left],[],[]] .chain = true := by decide
def e2389347185622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2389347185622 : Closed e2389347185622 ∧ code e2389347185622 = 11185440207830 := by decide
theorem cert_e2389347185622 : check e2389347185622 [[],[.left],[],[]] .chain = true := by decide
def e2389347185626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2389347185626 : Closed e2389347185626 ∧ code e2389347185626 = 11185440207834 := by decide
theorem cert_e2389347185626 : check e2389347185626 [[],[.left],[],[]] .chain = true := by decide
def e2389347185902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2389347185902 : Closed e2389347185902 ∧ code e2389347185902 = 11185440208110 := by decide
theorem cert_e2389347185902 : check e2389347185902 [[],[.left],[],[]] .chain = true := by decide
def e2389347185910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2389347185910 : Closed e2389347185910 ∧ code e2389347185910 = 11185440208118 := by decide
theorem cert_e2389347185910 : check e2389347185910 [[],[.left],[],[]] .chain = true := by decide
def e2389347186286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389347186286 : Closed e2389347186286 ∧ code e2389347186286 = 11185440208494 := by decide
theorem cert_e2389347186286 : check e2389347186286 [[],[.left],[],[]] .chain = true := by decide
def e2389347186298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389347186298 : Closed e2389347186298 ∧ code e2389347186298 = 11185440208506 := by decide
theorem cert_e2389347186298 : check e2389347186298 [[],[.left],[],[]] .chain = true := by decide
def e2389347186486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389347186486 : Closed e2389347186486 ∧ code e2389347186486 = 11185440208694 := by decide
theorem cert_e2389347186486 : check e2389347186486 [[],[.left],[],[]] .chain = true := by decide
def e2389347186490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389347186490 : Closed e2389347186490 ∧ code e2389347186490 = 11185440208698 := by decide
theorem cert_e2389347186490 : check e2389347186490 [[],[.left],[],[]] .chain = true := by decide
def e2389347187118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2389347187118 : Closed e2389347187118 ∧ code e2389347187118 = 11185440209326 := by decide
theorem cert_e2389347187118 : check e2389347187118 [[],[.left],[],[]] .chain = true := by decide
def e2389347187130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2389347187130 : Closed e2389347187130 ∧ code e2389347187130 = 11185440209338 := by decide
theorem cert_e2389347187130 : check e2389347187130 [[],[.left],[],[]] .chain = true := by decide
def e2389347187178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2389347187178 : Closed e2389347187178 ∧ code e2389347187178 = 11185440209386 := by decide
theorem cert_e2389347187178 : check e2389347187178 [[],[.left],[],[]] .chain = true := by decide
def e2389347187310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389347187310 : Closed e2389347187310 ∧ code e2389347187310 = 11185440209518 := by decide
theorem cert_e2389347187310 : check e2389347187310 [[],[.left],[],[]] .chain = true := by decide
def e2389347187322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389347187322 : Closed e2389347187322 ∧ code e2389347187322 = 11185440209530 := by decide
theorem cert_e2389347187322 : check e2389347187322 [[],[.left],[],[]] .chain = true := by decide
def e2389347187610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389347187610 : Closed e2389347187610 ∧ code e2389347187610 = 11185440209818 := by decide
theorem cert_e2389347187610 : check e2389347187610 [[],[.left],[],[]] .chain = true := by decide
def e2389347187926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2389347187926 : Closed e2389347187926 ∧ code e2389347187926 = 11185440210134 := by decide
theorem cert_e2389347187926 : check e2389347187926 [[],[.left],[],[]] .chain = true := by decide
def e2389347187930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2389347187930 : Closed e2389347187930 ∧ code e2389347187930 = 11185440210138 := by decide
theorem cert_e2389347187930 : check e2389347187930 [[],[.left],[],[]] .chain = true := by decide
def e2389347187946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2389347187946 : Closed e2389347187946 ∧ code e2389347187946 = 11185440210154 := by decide
theorem cert_e2389347187946 : check e2389347187946 [[],[.left],[],[]] .chain = true := by decide
def e2389347188022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389347188022 : Closed e2389347188022 ∧ code e2389347188022 = 11185440210230 := by decide
theorem cert_e2389347188022 : check e2389347188022 [[],[.left],[],[]] .chain = true := by decide
def e2389347188026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389347188026 : Closed e2389347188026 ∧ code e2389347188026 = 11185440210234 := by decide
theorem cert_e2389347188026 : check e2389347188026 [[],[.left],[],[]] .chain = true := by decide
def e2389347188122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389347188122 : Closed e2389347188122 ∧ code e2389347188122 = 11185440210330 := by decide
theorem cert_e2389347188122 : check e2389347188122 [[],[.left],[],[]] .chain = true := by decide
def e2389347189726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2389347189726 : Closed e2389347189726 ∧ code e2389347189726 = 11185440211934 := by decide
theorem cert_e2389347189726 : check e2389347189726 [[],[.left],[],[]] .chain = true := by decide
def e2389347189742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2389347189742 : Closed e2389347189742 ∧ code e2389347189742 = 11185440211950 := by decide
theorem cert_e2389347189742 : check e2389347189742 [[],[.left],[],[]] .chain = true := by decide
def e2389347191662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389347191662 : Closed e2389347191662 ∧ code e2389347191662 = 11185440213870 := by decide
theorem cert_e2389347191662 : check e2389347191662 [[],[.left],[],[]] .chain = true := by decide
def e2389347191670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389347191670 : Closed e2389347191670 ∧ code e2389347191670 = 11185440213878 := by decide
theorem cert_e2389347191670 : check e2389347191670 [[],[.left],[],[]] .chain = true := by decide
def e2389347191726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389347191726 : Closed e2389347191726 ∧ code e2389347191726 = 11185440213934 := by decide
theorem cert_e2389347191726 : check e2389347191726 [[],[.left],[],[]] .chain = true := by decide
def e2389347191738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389347191738 : Closed e2389347191738 ∧ code e2389347191738 = 11185440213946 := by decide
theorem cert_e2389347191738 : check e2389347191738 [[],[.left],[],[]] .chain = true := by decide
def e2389347191766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389347191766 : Closed e2389347191766 ∧ code e2389347191766 = 11185440213974 := by decide
theorem cert_e2389347191766 : check e2389347191766 [[],[.left],[],[]] .chain = true := by decide
def e2389347191770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389347191770 : Closed e2389347191770 ∧ code e2389347191770 = 11185440213978 := by decide
theorem cert_e2389347191770 : check e2389347191770 [[],[.left],[],[]] .chain = true := by decide
def e2389347192046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389347192046 : Closed e2389347192046 ∧ code e2389347192046 = 11185440214254 := by decide
theorem cert_e2389347192046 : check e2389347192046 [[],[.left],[],[]] .chain = true := by decide
def e2389347192054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389347192054 : Closed e2389347192054 ∧ code e2389347192054 = 11185440214262 := by decide
theorem cert_e2389347192054 : check e2389347192054 [[],[.left],[],[]] .chain = true := by decide
def e2389347192430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389347192430 : Closed e2389347192430 ∧ code e2389347192430 = 11185440214638 := by decide
theorem cert_e2389347192430 : check e2389347192430 [[],[.left],[],[]] .chain = true := by decide
def e2389347192442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389347192442 : Closed e2389347192442 ∧ code e2389347192442 = 11185440214650 := by decide
theorem cert_e2389347192442 : check e2389347192442 [[],[.left],[],[]] .chain = true := by decide
def e2389347192630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389347192630 : Closed e2389347192630 ∧ code e2389347192630 = 11185440214838 := by decide
theorem cert_e2389347192630 : check e2389347192630 [[],[.left],[],[]] .chain = true := by decide
def e2389347192634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389347192634 : Closed e2389347192634 ∧ code e2389347192634 = 11185440214842 := by decide
theorem cert_e2389347192634 : check e2389347192634 [[],[.left],[],[]] .chain = true := by decide
def e2389347197406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2389347197406 : Closed e2389347197406 ∧ code e2389347197406 = 11185440219614 := by decide
theorem cert_e2389347197406 : check e2389347197406 [[],[.left],[],[]] .chain = true := by decide
def e2389347197430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2389347197430 : Closed e2389347197430 ∧ code e2389347197430 = 11185440219638 := by decide
theorem cert_e2389347197430 : check e2389347197430 [[],[.left],[],[]] .chain = true := by decide
def e2389347198382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2389347198382 : Closed e2389347198382 ∧ code e2389347198382 = 11185440220590 := by decide
theorem cert_e2389347198382 : check e2389347198382 [[],[.left],[],[]] .chain = true := by decide
def e2389347198394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2389347198394 : Closed e2389347198394 ∧ code e2389347198394 = 11185440220602 := by decide
theorem cert_e2389347198394 : check e2389347198394 [[],[.left],[],[]] .chain = true := by decide
def e2389347198442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2389347198442 : Closed e2389347198442 ∧ code e2389347198442 = 11185440220650 := by decide
theorem cert_e2389347198442 : check e2389347198442 [[],[.left],[],[]] .chain = true := by decide
def e2389347198574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389347198574 : Closed e2389347198574 ∧ code e2389347198574 = 11185440220782 := by decide
theorem cert_e2389347198574 : check e2389347198574 [[],[.left],[],[]] .chain = true := by decide
def e2389347198586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389347198586 : Closed e2389347198586 ∧ code e2389347198586 = 11185440220794 := by decide
theorem cert_e2389347198586 : check e2389347198586 [[],[.left],[],[]] .chain = true := by decide
def e2389347198874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389347198874 : Closed e2389347198874 ∧ code e2389347198874 = 11185440221082 := by decide
theorem cert_e2389347198874 : check e2389347198874 [[],[.left],[],[]] .chain = true := by decide
def e2389347201262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2389347201262 : Closed e2389347201262 ∧ code e2389347201262 = 11185440223470 := by decide
theorem cert_e2389347201262 : check e2389347201262 [[],[.left],[],[]] .chain = true := by decide
def e2389347201270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2389347201270 : Closed e2389347201270 ∧ code e2389347201270 = 11185440223478 := by decide
theorem cert_e2389347201270 : check e2389347201270 [[],[.left],[],[]] .chain = true := by decide
def e2389347201750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2389347201750 : Closed e2389347201750 ∧ code e2389347201750 = 11185440223958 := by decide
theorem cert_e2389347201750 : check e2389347201750 [[],[.left],[],[]] .chain = true := by decide
def e2389347201754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2389347201754 : Closed e2389347201754 ∧ code e2389347201754 = 11185440223962 := by decide
theorem cert_e2389347201754 : check e2389347201754 [[],[.left],[],[]] .chain = true := by decide
def e2389347201770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2389347201770 : Closed e2389347201770 ∧ code e2389347201770 = 11185440223978 := by decide
theorem cert_e2389347201770 : check e2389347201770 [[],[.left],[],[]] .chain = true := by decide
def e2389347201846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389347201846 : Closed e2389347201846 ∧ code e2389347201846 = 11185440224054 := by decide
theorem cert_e2389347201846 : check e2389347201846 [[],[.left],[],[]] .chain = true := by decide
def e2389347201850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389347201850 : Closed e2389347201850 ∧ code e2389347201850 = 11185440224058 := by decide
theorem cert_e2389347201850 : check e2389347201850 [[],[.left],[],[]] .chain = true := by decide
def e2389347201946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389347201946 : Closed e2389347201946 ∧ code e2389347201946 = 11185440224154 := by decide
theorem cert_e2389347201946 : check e2389347201946 [[],[.left],[],[]] .chain = true := by decide
def e2389347339118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389347339118 : Closed e2389347339118 ∧ code e2389347339118 = 11185440361326 := by decide
theorem cert_e2389347339118 : check e2389347339118 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389347339126 : Closed e2389347339126 ∧ code e2389347339126 = 11185440361334 := by decide
theorem cert_e2389347339126 : check e2389347339126 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389347339182 : Closed e2389347339182 ∧ code e2389347339182 = 11185440361390 := by decide
theorem cert_e2389347339182 : check e2389347339182 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389347339194 : Closed e2389347339194 ∧ code e2389347339194 = 11185440361402 := by decide
theorem cert_e2389347339194 : check e2389347339194 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389347339222 : Closed e2389347339222 ∧ code e2389347339222 = 11185440361430 := by decide
theorem cert_e2389347339222 : check e2389347339222 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389347339226 : Closed e2389347339226 ∧ code e2389347339226 = 11185440361434 := by decide
theorem cert_e2389347339226 : check e2389347339226 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389347339502 : Closed e2389347339502 ∧ code e2389347339502 = 11185440361710 := by decide
theorem cert_e2389347339502 : check e2389347339502 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389347339510 : Closed e2389347339510 ∧ code e2389347339510 = 11185440361718 := by decide
theorem cert_e2389347339510 : check e2389347339510 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389347339886 : Closed e2389347339886 ∧ code e2389347339886 = 11185440362094 := by decide
theorem cert_e2389347339886 : check e2389347339886 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347339898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389347339898 : Closed e2389347339898 ∧ code e2389347339898 = 11185440362106 := by decide
theorem cert_e2389347339898 : check e2389347339898 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347340086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389347340086 : Closed e2389347340086 ∧ code e2389347340086 = 11185440362294 := by decide
theorem cert_e2389347340086 : check e2389347340086 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389347340090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389347340090 : Closed e2389347340090 ∧ code e2389347340090 = 11185440362298 := by decide
theorem cert_e2389347340090 : check e2389347340090 [[],[.left],[],[]] .sourceHead = true := by decide
end Blc.Floor43
