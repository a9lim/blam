import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418469345118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2418469345118 : Closed e2418469345118 ∧ code e2418469345118 = 11214562367326 := by decide
theorem cert_e2418469345118 : check e2418469345118 [[],[]] .three = true := by decide
def e2418469345134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2418469345134 : Closed e2418469345134 ∧ code e2418469345134 = 11214562367342 := by decide
theorem cert_e2418469345134 : check e2418469345134 [[],[]] .smaller = true := by decide
def e2418469345142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2418469345142 : Closed e2418469345142 ∧ code e2418469345142 = 11214562367350 := by decide
theorem cert_e2418469345142 : check e2418469345142 [[],[]] .smaller = true := by decide
def e2418469345146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2418469345146 : Closed e2418469345146 ∧ code e2418469345146 = 11214562367354 := by decide
theorem cert_e2418469345146 : check e2418469345146 [[],[]] .three = true := by decide
def e2418469345206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2418469345206 : Closed e2418469345206 ∧ code e2418469345206 = 11214562367414 := by decide
theorem cert_e2418469345206 : check e2418469345206 [[],[]] .smaller = true := by decide
def e2418469345238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2418469345238 : Closed e2418469345238 ∧ code e2418469345238 = 11214562367446 := by decide
theorem cert_e2418469345238 : check e2418469345238 [[],[]] .three = true := by decide
def e2418469345242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2418469345242 : Closed e2418469345242 ∧ code e2418469345242 = 11214562367450 := by decide
theorem cert_e2418469345242 : check e2418469345242 [[],[]] .three = true := by decide
def e2418469345758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2418469345758 : Closed e2418469345758 ∧ code e2418469345758 = 11214562367966 := by decide
theorem cert_e2418469345758 : check e2418469345758 [[],[]] .three = true := by decide
def e2418469345782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2418469345782 : Closed e2418469345782 ∧ code e2418469345782 = 11214562367990 := by decide
theorem cert_e2418469345782 : check e2418469345782 [[],[]] .three = true := by decide
def e2418469346526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418469346526 : Closed e2418469346526 ∧ code e2418469346526 = 11214562368734 := by decide
theorem cert_e2418469346526 : check e2418469346526 [[],[]] .three = true := by decide
def e2418469346542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418469346542 : Closed e2418469346542 ∧ code e2418469346542 = 11214562368750 := by decide
theorem cert_e2418469346542 : check e2418469346542 [[],[]] .smaller = true := by decide
def e2418469346550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418469346550 : Closed e2418469346550 ∧ code e2418469346550 = 11214562368758 := by decide
theorem cert_e2418469346550 : check e2418469346550 [[],[]] .smaller = true := by decide
def e2418469346554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418469346554 : Closed e2418469346554 ∧ code e2418469346554 = 11214562368762 := by decide
theorem cert_e2418469346554 : check e2418469346554 [[],[]] .three = true := by decide
def e2418469346934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2418469346934 : Closed e2418469346934 ∧ code e2418469346934 = 11214562369142 := by decide
theorem cert_e2418469346934 : check e2418469346934 [[],[]] .smaller = true := by decide
def e2418469347126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418469347126 : Closed e2418469347126 ∧ code e2418469347126 = 11214562369334 := by decide
theorem cert_e2418469347126 : check e2418469347126 [[],[]] .three = true := by decide
def e2418469347130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418469347130 : Closed e2418469347130 ∧ code e2418469347130 = 11214562369338 := by decide
theorem cert_e2418469347130 : check e2418469347130 [[],[]] .three = true := by decide
def e2418469358430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2418469358430 : Closed e2418469358430 ∧ code e2418469358430 = 11214562380638 := by decide
theorem cert_e2418469358430 : check e2418469358430 [[],[]] .three = true := by decide
def e2418469358446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418469358446 : Closed e2418469358446 ∧ code e2418469358446 = 11214562380654 := by decide
theorem cert_e2418469358446 : check e2418469358446 [[],[]] .smaller = true := by decide
def e2418469358454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418469358454 : Closed e2418469358454 ∧ code e2418469358454 = 11214562380662 := by decide
theorem cert_e2418469358454 : check e2418469358454 [[],[]] .smaller = true := by decide
def e2418469358458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2418469358458 : Closed e2418469358458 ∧ code e2418469358458 = 11214562380666 := by decide
theorem cert_e2418469358458 : check e2418469358458 [[],[]] .three = true := by decide
def e2418469358510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418469358510 : Closed e2418469358510 ∧ code e2418469358510 = 11214562380718 := by decide
theorem cert_e2418469358510 : check e2418469358510 [[],[]] .smaller = true := by decide
def e2418469358522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418469358522 : Closed e2418469358522 ∧ code e2418469358522 = 11214562380730 := by decide
theorem cert_e2418469358522 : check e2418469358522 [[],[]] .smaller = true := by decide
def e2418469358550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418469358550 : Closed e2418469358550 ∧ code e2418469358550 = 11214562380758 := by decide
theorem cert_e2418469358550 : check e2418469358550 [[],[]] .smaller = true := by decide
def e2418469358554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418469358554 : Closed e2418469358554 ∧ code e2418469358554 = 11214562380762 := by decide
theorem cert_e2418469358554 : check e2418469358554 [[],[]] .smaller = true := by decide
def e2418469358570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2418469358570 : Closed e2418469358570 ∧ code e2418469358570 = 11214562380778 := by decide
theorem cert_e2418469358570 : check e2418469358570 [[],[]] .three = true := by decide
def e2418469358814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418469358814 : Closed e2418469358814 ∧ code e2418469358814 = 11214562381022 := by decide
theorem cert_e2418469358814 : check e2418469358814 [[],[]] .three = true := by decide
def e2418469358830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418469358830 : Closed e2418469358830 ∧ code e2418469358830 = 11214562381038 := by decide
theorem cert_e2418469358830 : check e2418469358830 [[],[]] .smaller = true := by decide
def e2418469358838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418469358838 : Closed e2418469358838 ∧ code e2418469358838 = 11214562381046 := by decide
theorem cert_e2418469358838 : check e2418469358838 [[],[]] .smaller = true := by decide
def e2418469358842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418469358842 : Closed e2418469358842 ∧ code e2418469358842 = 11214562381050 := by decide
theorem cert_e2418469358842 : check e2418469358842 [[],[]] .three = true := by decide
def e2418469359214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418469359214 : Closed e2418469359214 ∧ code e2418469359214 = 11214562381422 := by decide
theorem cert_e2418469359214 : check e2418469359214 [[],[]] .smaller = true := by decide
def e2418469359226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418469359226 : Closed e2418469359226 ∧ code e2418469359226 = 11214562381434 := by decide
theorem cert_e2418469359226 : check e2418469359226 [[],[]] .smaller = true := by decide
def e2418469359414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418469359414 : Closed e2418469359414 ∧ code e2418469359414 = 11214562381622 := by decide
theorem cert_e2418469359414 : check e2418469359414 [[],[]] .smaller = true := by decide
def e2418469359418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418469359418 : Closed e2418469359418 ∧ code e2418469359418 = 11214562381626 := by decide
theorem cert_e2418469359418 : check e2418469359418 [[],[]] .smaller = true := by decide
def e2418469359514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418469359514 : Closed e2418469359514 ∧ code e2418469359514 = 11214562381722 := by decide
theorem cert_e2418469359514 : check e2418469359514 [[],[]] .three = true := by decide
def e2418469365174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2418469365174 : Closed e2418469365174 ∧ code e2418469365174 = 11214562387382 := by decide
theorem cert_e2418469365174 : check e2418469365174 [[],[]] .smaller = true := by decide
def e2418469365206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2418469365206 : Closed e2418469365206 ∧ code e2418469365206 = 11214562387414 := by decide
theorem cert_e2418469365206 : check e2418469365206 [[],[]] .smaller = true := by decide
def e2418469365210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2418469365210 : Closed e2418469365210 ∧ code e2418469365210 = 11214562387418 := by decide
theorem cert_e2418469365210 : check e2418469365210 [[],[]] .smaller = true := by decide
def e2418469365366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2418469365366 : Closed e2418469365366 ∧ code e2418469365366 = 11214562387574 := by decide
theorem cert_e2418469365366 : check e2418469365366 [[],[]] .smaller = true := by decide
def e2418469365558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418469365558 : Closed e2418469365558 ∧ code e2418469365558 = 11214562387766 := by decide
theorem cert_e2418469365558 : check e2418469365558 [[],[]] .smaller = true := by decide
def e2418469365562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418469365562 : Closed e2418469365562 ∧ code e2418469365562 = 11214562387770 := by decide
theorem cert_e2418469365562 : check e2418469365562 [[],[]] .smaller = true := by decide
def e2418469368534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2418469368534 : Closed e2418469368534 ∧ code e2418469368534 = 11214562390742 := by decide
theorem cert_e2418469368534 : check e2418469368534 [[],[]] .three = true := by decide
def e2418469368538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2418469368538 : Closed e2418469368538 ∧ code e2418469368538 = 11214562390746 := by decide
theorem cert_e2418469368538 : check e2418469368538 [[],[]] .three = true := by decide
def e2418469368554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2418469368554 : Closed e2418469368554 ∧ code e2418469368554 = 11214562390762 := by decide
theorem cert_e2418469368554 : check e2418469368554 [[],[]] .three = true := by decide
def e2418469368630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418469368630 : Closed e2418469368630 ∧ code e2418469368630 = 11214562390838 := by decide
theorem cert_e2418469368630 : check e2418469368630 [[],[]] .three = true := by decide
def e2418469368634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418469368634 : Closed e2418469368634 ∧ code e2418469368634 = 11214562390842 := by decide
theorem cert_e2418469368634 : check e2418469368634 [[],[]] .three = true := by decide
def e2418469368730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418469368730 : Closed e2418469368730 ∧ code e2418469368730 = 11214562390938 := by decide
theorem cert_e2418469368730 : check e2418469368730 [[],[]] .three = true := by decide
def e2418469593966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2418469593966 : Closed e2418469593966 ∧ code e2418469593966 = 11214562616174 := by decide
theorem cert_e2418469593966 : check e2418469593966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418469593974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2418469593974 : Closed e2418469593974 ∧ code e2418469593974 = 11214562616182 := by decide
theorem cert_e2418469593974 : checkPay e2418469593974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418469594030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2418469594030 : Closed e2418469594030 ∧ code e2418469594030 = 11214562616238 := by decide
theorem cert_e2418469594030 : check e2418469594030 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418469594042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2418469594042 : Closed e2418469594042 ∧ code e2418469594042 = 11214562616250 := by decide
theorem cert_e2418469594042 : check e2418469594042 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418469594070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2418469594070 : Closed e2418469594070 ∧ code e2418469594070 = 11214562616278 := by decide
theorem cert_e2418469594070 : check e2418469594070 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469594074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2418469594074 : Closed e2418469594074 ∧ code e2418469594074 = 11214562616282 := by decide
theorem cert_e2418469594074 : check e2418469594074 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418469595374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2418469595374 : Closed e2418469595374 ∧ code e2418469595374 = 11214562617582 := by decide
theorem cert_e2418469595374 : check e2418469595374 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418469595382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2418469595382 : Closed e2418469595382 ∧ code e2418469595382 = 11214562617590 := by decide
theorem cert_e2418469595382 : checkPay e2418469595382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418469595934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2418469595934 : Closed e2418469595934 ∧ code e2418469595934 = 11214562618142 := by decide
theorem cert_e2418469595934 : check e2418469595934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2418469596046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2418469596046 : Closed e2418469596046 ∧ code e2418469596046 = 11214562618254 := by decide
theorem cert_e2418469596046 : check e2418469596046 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418469596270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2418469596270 : Closed e2418469596270 ∧ code e2418469596270 = 11214562618478 := by decide
theorem cert_e2418469596270 : check e2418469596270 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418469596282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2418469596282 : Closed e2418469596282 ∧ code e2418469596282 = 11214562618490 := by decide
theorem cert_e2418469596282 : check e2418469596282 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418469596446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2418469596446 : Closed e2418469596446 ∧ code e2418469596446 = 11214562618654 := by decide
theorem cert_e2418469596446 : check e2418469596446 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418469596614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2418469596614 : Closed e2418469596614 ∧ code e2418469596614 = 11214562618822 := by decide
theorem cert_e2418469596614 : check e2418469596614 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418469596726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2418469596726 : Closed e2418469596726 ∧ code e2418469596726 = 11214562618934 := by decide
theorem cert_e2418469596726 : checkPay e2418469596726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2418469596730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2418469596730 : Closed e2418469596730 ∧ code e2418469596730 = 11214562618938 := by decide
theorem cert_e2418469596730 : check e2418469596730 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469596814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2418469596814 : Closed e2418469596814 ∧ code e2418469596814 = 11214562619022 := by decide
theorem cert_e2418469596814 : check e2418469596814 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469596870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2418469596870 : Closed e2418469596870 ∧ code e2418469596870 = 11214562619078 := by decide
theorem cert_e2418469596870 : check e2418469596870 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469597614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2418469597614 : Closed e2418469597614 ∧ code e2418469597614 = 11214562619822 := by decide
theorem cert_e2418469597614 : check e2418469597614 [[],[]] .sourceHead = true := by decide
def e2418469597626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2418469597626 : Closed e2418469597626 ∧ code e2418469597626 = 11214562619834 := by decide
theorem cert_e2418469597626 : check e2418469597626 [[],[]] .sourceHead = true := by decide
def e2418469597674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2418469597674 : Closed e2418469597674 ∧ code e2418469597674 = 11214562619882 := by decide
theorem cert_e2418469597674 : check e2418469597674 [[],[]] .sourceHead = true := by decide
def e2418469598318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2418469598318 : Closed e2418469598318 ∧ code e2418469598318 = 11214562620526 := by decide
theorem cert_e2418469598318 : check e2418469598318 [[],[]] .sourceHead = true := by decide
def e2418469598330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2418469598330 : Closed e2418469598330 ∧ code e2418469598330 = 11214562620538 := by decide
theorem cert_e2418469598330 : check e2418469598330 [[],[]] .sourceHead = true := by decide
def e2418469598494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2418469598494 : Closed e2418469598494 ∧ code e2418469598494 = 11214562620702 := by decide
theorem cert_e2418469598494 : check e2418469598494 [[],[]] .sourceHead = true := by decide
def e2418469598662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2418469598662 : Closed e2418469598662 ∧ code e2418469598662 = 11214562620870 := by decide
theorem cert_e2418469598662 : check e2418469598662 [[],[]] .sourceHead = true := by decide
def e2418469599002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2418469599002 : Closed e2418469599002 ∧ code e2418469599002 = 11214562621210 := by decide
theorem cert_e2418469599002 : check e2418469599002 [[],[]] .sourceHead = true := by decide
def e2418469599046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2418469599046 : Closed e2418469599046 ∧ code e2418469599046 = 11214562621254 := by decide
theorem cert_e2418469599046 : check e2418469599046 [[],[]] .sourceHead = true := by decide
def e2418469599446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2418469599446 : Closed e2418469599446 ∧ code e2418469599446 = 11214562621654 := by decide
theorem cert_e2418469599446 : check e2418469599446 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469599450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2418469599450 : Closed e2418469599450 ∧ code e2418469599450 = 11214562621658 := by decide
theorem cert_e2418469599450 : check e2418469599450 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469599466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2418469599466 : Closed e2418469599466 ∧ code e2418469599466 = 11214562621674 := by decide
theorem cert_e2418469599466 : check e2418469599466 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469599798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2418469599798 : Closed e2418469599798 ∧ code e2418469599798 = 11214562622006 := by decide
theorem cert_e2418469599798 : check e2418469599798 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469599802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2418469599802 : Closed e2418469599802 ∧ code e2418469599802 = 11214562622010 := by decide
theorem cert_e2418469599802 : check e2418469599802 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469599886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2418469599886 : Closed e2418469599886 ∧ code e2418469599886 = 11214562622094 := by decide
theorem cert_e2418469599886 : check e2418469599886 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469599942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2418469599942 : Closed e2418469599942 ∧ code e2418469599942 = 11214562622150 := by decide
theorem cert_e2418469599942 : check e2418469599942 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469600026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2418469600026 : Closed e2418469600026 ∧ code e2418469600026 = 11214562622234 := by decide
theorem cert_e2418469600026 : check e2418469600026 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469600070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2418469600070 : Closed e2418469600070 ∧ code e2418469600070 = 11214562622278 := by decide
theorem cert_e2418469600070 : check e2418469600070 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418469604590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2418469604590 : Closed e2418469604590 ∧ code e2418469604590 = 11214562626798 := by decide
theorem cert_e2418469604590 : check e2418469604590 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469604598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2418469604598 : Closed e2418469604598 ∧ code e2418469604598 = 11214562626806 := by decide
theorem cert_e2418469604598 : check e2418469604598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469604974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2418469604974 : Closed e2418469604974 ∧ code e2418469604974 = 11214562627182 := by decide
theorem cert_e2418469604974 : checkPay e2418469604974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2418469604986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2418469604986 : Closed e2418469604986 ∧ code e2418469604986 = 11214562627194 := by decide
theorem cert_e2418469604986 : checkPay e2418469604986 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2418469605174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2418469605174 : Closed e2418469605174 ∧ code e2418469605174 = 11214562627382 := by decide
theorem cert_e2418469605174 : check e2418469605174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418469605178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2418469605178 : Closed e2418469605178 ∧ code e2418469605178 = 11214562627386 := by decide
theorem cert_e2418469605178 : check e2418469605178 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469607662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2418469607662 : Closed e2418469607662 ∧ code e2418469607662 = 11214562629870 := by decide
theorem cert_e2418469607662 : check e2418469607662 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2418469607670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2418469607670 : Closed e2418469607670 ∧ code e2418469607670 = 11214562629878 := by decide
theorem cert_e2418469607670 : check e2418469607670 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469608222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2418469608222 : Closed e2418469608222 ∧ code e2418469608222 = 11214562630430 := by decide
theorem cert_e2418469608222 : check e2418469608222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418469608334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2418469608334 : Closed e2418469608334 ∧ code e2418469608334 = 11214562630542 := by decide
theorem cert_e2418469608334 : check e2418469608334 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2418469608558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2418469608558 : Closed e2418469608558 ∧ code e2418469608558 = 11214562630766 := by decide
theorem cert_e2418469608558 : check e2418469608558 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418469608570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2418469608570 : Closed e2418469608570 ∧ code e2418469608570 = 11214562630778 := by decide
theorem cert_e2418469608570 : check e2418469608570 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418469608734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2418469608734 : Closed e2418469608734 ∧ code e2418469608734 = 11214562630942 := by decide
theorem cert_e2418469608734 : check e2418469608734 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418469608902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2418469608902 : Closed e2418469608902 ∧ code e2418469608902 = 11214562631110 := by decide
theorem cert_e2418469608902 : check e2418469608902 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418469609014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2418469609014 : Closed e2418469609014 ∧ code e2418469609014 = 11214562631222 := by decide
theorem cert_e2418469609014 : check e2418469609014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469609018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2418469609018 : Closed e2418469609018 ∧ code e2418469609018 = 11214562631226 := by decide
theorem cert_e2418469609018 : check e2418469609018 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469609102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2418469609102 : Closed e2418469609102 ∧ code e2418469609102 = 11214562631310 := by decide
theorem cert_e2418469609102 : check e2418469609102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469609158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2418469609158 : Closed e2418469609158 ∧ code e2418469609158 = 11214562631366 := by decide
theorem cert_e2418469609158 : check e2418469609158 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469611294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2418469611294 : Closed e2418469611294 ∧ code e2418469611294 = 11214562633502 := by decide
theorem cert_e2418469611294 : check e2418469611294 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469611406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2418469611406 : Closed e2418469611406 ∧ code e2418469611406 = 11214562633614 := by decide
theorem cert_e2418469611406 : check e2418469611406 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469614366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2418469614366 : Closed e2418469614366 ∧ code e2418469614366 = 11214562636574 := by decide
theorem cert_e2418469614366 : check e2418469614366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418469614534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2418469614534 : Closed e2418469614534 ∧ code e2418469614534 = 11214562636742 := by decide
theorem cert_e2418469614534 : check e2418469614534 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418469616014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2418469616014 : Closed e2418469616014 ∧ code e2418469616014 = 11214562638222 := by decide
theorem cert_e2418469616014 : check e2418469616014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418469616070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2418469616070 : Closed e2418469616070 ∧ code e2418469616070 = 11214562638278 := by decide
theorem cert_e2418469616070 : check e2418469616070 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469619310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2418469619310 : Closed e2418469619310 ∧ code e2418469619310 = 11214562641518 := by decide
theorem cert_e2418469619310 : checkPay e2418469619310 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418469619322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2418469619322 : Closed e2418469619322 ∧ code e2418469619322 = 11214562641530 := by decide
theorem cert_e2418469619322 : checkPay e2418469619322 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418469619610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418469619610 : Closed e2418469619610 ∧ code e2418469619610 = 11214562641818 := by decide
theorem cert_e2418469619610 : checkPay e2418469619610 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e2418469620846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2418469620846 : Closed e2418469620846 ∧ code e2418469620846 = 11214562643054 := by decide
theorem cert_e2418469620846 : checkPay e2418469620846 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2418469620858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2418469620858 : Closed e2418469620858 ∧ code e2418469620858 = 11214562643066 := by decide
theorem cert_e2418469620858 : checkPay e2418469620858 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e2418469621022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2418469621022 : Closed e2418469621022 ∧ code e2418469621022 = 11214562643230 := by decide
theorem cert_e2418469621022 : checkPay e2418469621022 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2418469621190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2418469621190 : Closed e2418469621190 ∧ code e2418469621190 = 11214562643398 := by decide
theorem cert_e2418469621190 : checkPay e2418469621190 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e2418469621530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2418469621530 : Closed e2418469621530 ∧ code e2418469621530 = 11214562643738 := by decide
theorem cert_e2418469621530 : checkPay e2418469621530 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e2418469621574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2418469621574 : Closed e2418469621574 ∧ code e2418469621574 = 11214562643782 := by decide
theorem cert_e2418469621574 : checkPay e2418469621574 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e2418469622558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2418469622558 : Closed e2418469622558 ∧ code e2418469622558 = 11214562644766 := by decide
theorem cert_e2418469622558 : checkPay e2418469622558 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418469622726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2418469622726 : Closed e2418469622726 ∧ code e2418469622726 = 11214562644934 := by decide
theorem cert_e2418469622726 : checkPay e2418469622726 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418469625030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2418469625030 : Closed e2418469625030 ∧ code e2418469625030 = 11214562647238 := by decide
theorem cert_e2418469625030 : checkPay e2418469625030 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2418469626678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2418469626678 : Closed e2418469626678 ∧ code e2418469626678 = 11214562648886 := by decide
theorem cert_e2418469626678 : check e2418469626678 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469626682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2418469626682 : Closed e2418469626682 ∧ code e2418469626682 = 11214562648890 := by decide
theorem cert_e2418469626682 : check e2418469626682 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469626778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418469626778 : Closed e2418469626778 ∧ code e2418469626778 = 11214562648986 := by decide
theorem cert_e2418469626778 : check e2418469626778 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469627446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2418469627446 : Closed e2418469627446 ∧ code e2418469627446 = 11214562649654 := by decide
theorem cert_e2418469627446 : check e2418469627446 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469627450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2418469627450 : Closed e2418469627450 ∧ code e2418469627450 = 11214562649658 := by decide
theorem cert_e2418469627450 : check e2418469627450 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469627534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2418469627534 : Closed e2418469627534 ∧ code e2418469627534 = 11214562649742 := by decide
theorem cert_e2418469627534 : check e2418469627534 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469627590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2418469627590 : Closed e2418469627590 ∧ code e2418469627590 = 11214562649798 := by decide
theorem cert_e2418469627590 : check e2418469627590 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469627674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2418469627674 : Closed e2418469627674 ∧ code e2418469627674 = 11214562649882 := by decide
theorem cert_e2418469627674 : check e2418469627674 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469627718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2418469627718 : Closed e2418469627718 ∧ code e2418469627718 = 11214562649926 := by decide
theorem cert_e2418469627718 : check e2418469627718 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469628302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2418469628302 : Closed e2418469628302 ∧ code e2418469628302 = 11214562650510 := by decide
theorem cert_e2418469628302 : check e2418469628302 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469628358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2418469628358 : Closed e2418469628358 ∧ code e2418469628358 = 11214562650566 := by decide
theorem cert_e2418469628358 : check e2418469628358 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469629126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2418469629126 : Closed e2418469629126 ∧ code e2418469629126 = 11214562651334 := by decide
theorem cert_e2418469629126 : check e2418469629126 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418469639902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2418469639902 : Closed e2418469639902 ∧ code e2418469639902 = 11214562662110 := by decide
theorem cert_e2418469639902 : check e2418469639902 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469639926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2418469639926 : Closed e2418469639926 ∧ code e2418469639926 = 11214562662134 := by decide
theorem cert_e2418469639926 : check e2418469639926 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2418469640030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2418469640030 : Closed e2418469640030 ∧ code e2418469640030 = 11214562662238 := by decide
theorem cert_e2418469640030 : check e2418469640030 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418469640058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2418469640058 : Closed e2418469640058 ∧ code e2418469640058 = 11214562662266 := by decide
theorem cert_e2418469640058 : check e2418469640058 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418469640150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2418469640150 : Closed e2418469640150 ∧ code e2418469640150 = 11214562662358 := by decide
theorem cert_e2418469640150 : check e2418469640150 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469640154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2418469640154 : Closed e2418469640154 ∧ code e2418469640154 = 11214562662362 := by decide
theorem cert_e2418469640154 : check e2418469640154 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2418469640670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2418469640670 : Closed e2418469640670 ∧ code e2418469640670 = 11214562662878 := by decide
theorem cert_e2418469640670 : check e2418469640670 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[],[],[.left,.left],[.left],[],[],[.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2418469640694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2418469640694 : Closed e2418469640694 ∧ code e2418469640694 = 11214562662902 := by decide
theorem cert_e2418469640694 : check e2418469640694 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418469641438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418469641438 : Closed e2418469641438 ∧ code e2418469641438 = 11214562663646 := by decide
theorem cert_e2418469641438 : check e2418469641438 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469641466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418469641466 : Closed e2418469641466 ∧ code e2418469641466 = 11214562663674 := by decide
theorem cert_e2418469641466 : check e2418469641466 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e2418469642038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418469642038 : Closed e2418469642038 ∧ code e2418469642038 = 11214562664246 := by decide
theorem cert_e2418469642038 : check e2418469642038 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2418469642042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418469642042 : Closed e2418469642042 ∧ code e2418469642042 = 11214562664250 := by decide
theorem cert_e2418469642042 : check e2418469642042 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2418469656814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2418469656814 : Closed e2418469656814 ∧ code e2418469656814 = 11214562679022 := by decide
theorem cert_e2418469656814 : check e2418469656814 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2418469656822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2418469656822 : Closed e2418469656822 ∧ code e2418469656822 = 11214562679030 := by decide
theorem cert_e2418469656822 : check e2418469656822 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418469657374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2418469657374 : Closed e2418469657374 ∧ code e2418469657374 = 11214562679582 := by decide
theorem cert_e2418469657374 : check e2418469657374 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2418469657486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2418469657486 : Closed e2418469657486 ∧ code e2418469657486 = 11214562679694 := by decide
theorem cert_e2418469657486 : check e2418469657486 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418469657710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2418469657710 : Closed e2418469657710 ∧ code e2418469657710 = 11214562679918 := by decide
theorem cert_e2418469657710 : check e2418469657710 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418469657722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2418469657722 : Closed e2418469657722 ∧ code e2418469657722 = 11214562679930 := by decide
theorem cert_e2418469657722 : check e2418469657722 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418469657886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2418469657886 : Closed e2418469657886 ∧ code e2418469657886 = 11214562680094 := by decide
theorem cert_e2418469657886 : check e2418469657886 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418469658054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2418469658054 : Closed e2418469658054 ∧ code e2418469658054 = 11214562680262 := by decide
theorem cert_e2418469658054 : check e2418469658054 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418469658166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2418469658166 : Closed e2418469658166 ∧ code e2418469658166 = 11214562680374 := by decide
theorem cert_e2418469658166 : check e2418469658166 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418469658170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2418469658170 : Closed e2418469658170 ∧ code e2418469658170 = 11214562680378 := by decide
theorem cert_e2418469658170 : check e2418469658170 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418469658254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2418469658254 : Closed e2418469658254 ∧ code e2418469658254 = 11214562680462 := by decide
theorem cert_e2418469658254 : checkPay e2418469658254 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e2418469658310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2418469658310 : Closed e2418469658310 ∧ code e2418469658310 = 11214562680518 := by decide
theorem cert_e2418469658310 : check e2418469658310 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418469660446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2418469660446 : Closed e2418469660446 ∧ code e2418469660446 = 11214562682654 := by decide
theorem cert_e2418469660446 : check e2418469660446 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2418469660558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2418469660558 : Closed e2418469660558 ∧ code e2418469660558 = 11214562682766 := by decide
theorem cert_e2418469660558 : check e2418469660558 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2418469663518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2418469663518 : Closed e2418469663518 ∧ code e2418469663518 = 11214562685726 := by decide
theorem cert_e2418469663518 : check e2418469663518 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418469663686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2418469663686 : Closed e2418469663686 ∧ code e2418469663686 = 11214562685894 := by decide
theorem cert_e2418469663686 : check e2418469663686 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418469665166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2418469665166 : Closed e2418469665166 ∧ code e2418469665166 = 11214562687374 := by decide
theorem cert_e2418469665166 : check e2418469665166 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2418469665222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2418469665222 : Closed e2418469665222 ∧ code e2418469665222 = 11214562687430 := by decide
theorem cert_e2418469665222 : check e2418469665222 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
end Blc.Floor43
