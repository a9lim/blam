import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e768814213658 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768814213658 : Closed e768814213658 ∧ code e768814213658 = 9564907235866 := by decide
theorem cert_e768814213658 : check e768814213658 [] .sourceHead = true := by decide
def e768814247450 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768814247450 : Closed e768814247450 ∧ code e768814247450 = 9564907269658 := by decide
theorem cert_e768814247450 : check e768814247450 [] .sourceHead = true := by decide
def e768814250522 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768814250522 : Closed e768814250522 ∧ code e768814250522 = 9564907272730 := by decide
theorem cert_e768814250522 : check e768814250522 [] .sourceHead = true := by decide
def e768814324250 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768814324250 : Closed e768814324250 ∧ code e768814324250 = 9564907346458 := by decide
theorem cert_e768814324250 : check e768814324250 [] .sourceHead = true := by decide
def e768815060506 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768815060506 : Closed e768815060506 ∧ code e768815060506 = 9564908082714 := by decide
theorem cert_e768815060506 : check e768815060506 [] .sourceHead = true := by decide
def e768815061530 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768815061530 : Closed e768815061530 ∧ code e768815061530 = 9564908083738 := by decide
theorem cert_e768815061530 : check e768815061530 [] .sourceHead = true := by decide
def e768815065626 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768815065626 : Closed e768815065626 ∧ code e768815065626 = 9564908087834 := by decide
theorem cert_e768815065626 : check e768815065626 [] .sourceHead = true := by decide
def e768815085082 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768815085082 : Closed e768815085082 ∧ code e768815085082 = 9564908107290 := by decide
theorem cert_e768815085082 : check e768815085082 [] .sourceHead = true := by decide
def e768815086106 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768815086106 : Closed e768815086106 ∧ code e768815086106 = 9564908108314 := by decide
theorem cert_e768815086106 : check e768815086106 [] .sourceHead = true := by decide
def e768815110682 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768815110682 : Closed e768815110682 ∧ code e768815110682 = 9564908132890 := by decide
theorem cert_e768815110682 : check e768815110682 [] .sourceHead = true := by decide
def e768850226714 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850226714 : Closed e768850226714 ∧ code e768850226714 = 9564943248922 := by decide
theorem cert_e768850226714 : check e768850226714 [] .sourceHead = true := by decide
def e768850228762 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850228762 : Closed e768850228762 ∧ code e768850228762 = 9564943250970 := by decide
theorem cert_e768850228762 : check e768850228762 [] .sourceHead = true := by decide
def e768850243098 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850243098 : Closed e768850243098 ∧ code e768850243098 = 9564943265306 := by decide
theorem cert_e768850243098 : check e768850243098 [] .sourceHead = true := by decide
def e768850246170 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850246170 : Closed e768850246170 ∧ code e768850246170 = 9564943268378 := by decide
theorem cert_e768850246170 : check e768850246170 [] .sourceHead = true := by decide
def e768850253338 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850253338 : Closed e768850253338 ∧ code e768850253338 = 9564943275546 := by decide
theorem cert_e768850253338 : check e768850253338 [] .sourceHead = true := by decide
def e768850254362 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850254362 : Closed e768850254362 ∧ code e768850254362 = 9564943276570 := by decide
theorem cert_e768850254362 : check e768850254362 [] .sourceHead = true := by decide
def e768850325018 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850325018 : Closed e768850325018 ∧ code e768850325018 = 9564943347226 := by decide
theorem cert_e768850325018 : check e768850325018 [] .sourceHead = true := by decide
def e768850327066 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850327066 : Closed e768850327066 ∧ code e768850327066 = 9564943349274 := by decide
theorem cert_e768850327066 : check e768850327066 [] .sourceHead = true := by decide
def e768850423322 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850423322 : Closed e768850423322 ∧ code e768850423322 = 9564943445530 := by decide
theorem cert_e768850423322 : check e768850423322 [] .sourceHead = true := by decide
def e768850426394 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850426394 : Closed e768850426394 ∧ code e768850426394 = 9564943448602 := by decide
theorem cert_e768850426394 : check e768850426394 [] .sourceHead = true := by decide
def e768850474522 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850474522 : Closed e768850474522 ∧ code e768850474522 = 9564943496730 := by decide
theorem cert_e768850474522 : check e768850474522 [] .sourceHead = true := by decide
def e768850475546 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768850475546 : Closed e768850475546 ∧ code e768850475546 = 9564943497754 := by decide
theorem cert_e768850475546 : check e768850475546 [] .sourceHead = true := by decide
def e769001221658 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001221658 : Closed e769001221658 ∧ code e769001221658 = 9565094243866 := by decide
theorem cert_e769001221658 : check e769001221658 [] .sourceHead = true := by decide
def e769001223706 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001223706 : Closed e769001223706 ∧ code e769001223706 = 9565094245914 := by decide
theorem cert_e769001223706 : check e769001223706 [] .sourceHead = true := by decide
def e769001238042 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001238042 : Closed e769001238042 ∧ code e769001238042 = 9565094260250 := by decide
theorem cert_e769001238042 : check e769001238042 [] .sourceHead = true := by decide
def e769001241114 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001241114 : Closed e769001241114 ∧ code e769001241114 = 9565094263322 := by decide
theorem cert_e769001241114 : check e769001241114 [] .sourceHead = true := by decide
def e769001248282 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001248282 : Closed e769001248282 ∧ code e769001248282 = 9565094270490 := by decide
theorem cert_e769001248282 : check e769001248282 [] .sourceHead = true := by decide
def e769001249306 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001249306 : Closed e769001249306 ∧ code e769001249306 = 9565094271514 := by decide
theorem cert_e769001249306 : check e769001249306 [] .sourceHead = true := by decide
def e769001319962 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001319962 : Closed e769001319962 ∧ code e769001319962 = 9565094342170 := by decide
theorem cert_e769001319962 : check e769001319962 [] .sourceHead = true := by decide
def e769001322010 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001322010 : Closed e769001322010 ∧ code e769001322010 = 9565094344218 := by decide
theorem cert_e769001322010 : check e769001322010 [] .sourceHead = true := by decide
def e769001418266 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001418266 : Closed e769001418266 ∧ code e769001418266 = 9565094440474 := by decide
theorem cert_e769001418266 : check e769001418266 [] .sourceHead = true := by decide
def e769001421338 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001421338 : Closed e769001421338 ∧ code e769001421338 = 9565094443546 := by decide
theorem cert_e769001421338 : check e769001421338 [] .sourceHead = true := by decide
def e769001469466 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001469466 : Closed e769001469466 ∧ code e769001469466 = 9565094491674 := by decide
theorem cert_e769001469466 : check e769001469466 [] .sourceHead = true := by decide
def e769001470490 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e769001470490 : Closed e769001470490 ∧ code e769001470490 = 9565094492698 := by decide
theorem cert_e769001470490 : check e769001470490 [] .sourceHead = true := by decide
def e769017294190 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e769017294190 : Closed e769017294190 ∧ code e769017294190 = 9565110316398 := by decide
theorem cert_e769017294190 : check e769017294190 [] .sourceHead = true := by decide
def e769017294198 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e769017294198 : Closed e769017294198 ∧ code e769017294198 = 9565110316406 := by decide
theorem cert_e769017294198 : check e769017294198 [] .sourceHead = true := by decide
def e769017294254 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e769017294254 : Closed e769017294254 ∧ code e769017294254 = 9565110316462 := by decide
theorem cert_e769017294254 : check e769017294254 [] .sourceHead = true := by decide
def e769017294266 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e769017294266 : Closed e769017294266 ∧ code e769017294266 = 9565110316474 := by decide
theorem cert_e769017294266 : check e769017294266 [] .sourceHead = true := by decide
def e769017294294 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e769017294294 : Closed e769017294294 ∧ code e769017294294 = 9565110316502 := by decide
theorem cert_e769017294294 : check e769017294294 [] .sourceHead = true := by decide
def e769017294298 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e769017294298 : Closed e769017294298 ∧ code e769017294298 = 9565110316506 := by decide
theorem cert_e769017294298 : check e769017294298 [] .sourceHead = true := by decide
def e769017294510 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e769017294510 : Closed e769017294510 ∧ code e769017294510 = 9565110316718 := by decide
theorem cert_e769017294510 : check e769017294510 [] .sourceHead = true := by decide
def e769017294522 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e769017294522 : Closed e769017294522 ∧ code e769017294522 = 9565110316730 := by decide
theorem cert_e769017294522 : check e769017294522 [] .sourceHead = true := by decide
def e769017294570 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e769017294570 : Closed e769017294570 ∧ code e769017294570 = 9565110316778 := by decide
theorem cert_e769017294570 : check e769017294570 [] .sourceHead = true := by decide
def e769017294678 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e769017294678 : Closed e769017294678 ∧ code e769017294678 = 9565110316886 := by decide
theorem cert_e769017294678 : check e769017294678 [] .sourceHead = true := by decide
def e769017294682 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e769017294682 : Closed e769017294682 ∧ code e769017294682 = 9565110316890 := by decide
theorem cert_e769017294682 : check e769017294682 [] .sourceHead = true := by decide
def e769017294698 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e769017294698 : Closed e769017294698 ∧ code e769017294698 = 9565110316906 := by decide
theorem cert_e769017294698 : check e769017294698 [] .sourceHead = true := by decide
def e769017295726 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e769017295726 : Closed e769017295726 ∧ code e769017295726 = 9565110317934 := by decide
theorem cert_e769017295726 : check e769017295726 [] .sourceHead = true := by decide
def e769017295734 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e769017295734 : Closed e769017295734 ∧ code e769017295734 = 9565110317942 := by decide
theorem cert_e769017295734 : check e769017295734 [] .sourceHead = true := by decide
def e769017295790 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e769017295790 : Closed e769017295790 ∧ code e769017295790 = 9565110317998 := by decide
theorem cert_e769017295790 : check e769017295790 [] .sourceHead = true := by decide
def e769017295802 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e769017295802 : Closed e769017295802 ∧ code e769017295802 = 9565110318010 := by decide
theorem cert_e769017295802 : check e769017295802 [] .sourceHead = true := by decide
def e769017295830 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e769017295830 : Closed e769017295830 ∧ code e769017295830 = 9565110318038 := by decide
theorem cert_e769017295830 : check e769017295830 [] .sourceHead = true := by decide
def e769017295834 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e769017295834 : Closed e769017295834 ∧ code e769017295834 = 9565110318042 := by decide
theorem cert_e769017295834 : check e769017295834 [] .sourceHead = true := by decide
def e769017296110 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e769017296110 : Closed e769017296110 ∧ code e769017296110 = 9565110318318 := by decide
theorem cert_e769017296110 : check e769017296110 [] .sourceHead = true := by decide
def e769017296118 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e769017296118 : Closed e769017296118 ∧ code e769017296118 = 9565110318326 := by decide
theorem cert_e769017296118 : check e769017296118 [] .sourceHead = true := by decide
def e769017296494 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e769017296494 : Closed e769017296494 ∧ code e769017296494 = 9565110318702 := by decide
theorem cert_e769017296494 : check e769017296494 [] .sourceHead = true := by decide
def e769017296506 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e769017296506 : Closed e769017296506 ∧ code e769017296506 = 9565110318714 := by decide
theorem cert_e769017296506 : check e769017296506 [] .sourceHead = true := by decide
def e769017296694 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e769017296694 : Closed e769017296694 ∧ code e769017296694 = 9565110318902 := by decide
theorem cert_e769017296694 : check e769017296694 [] .sourceHead = true := by decide
def e769017296698 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e769017296698 : Closed e769017296698 ∧ code e769017296698 = 9565110318906 := by decide
theorem cert_e769017296698 : check e769017296698 [] .sourceHead = true := by decide
def e769017297326 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e769017297326 : Closed e769017297326 ∧ code e769017297326 = 9565110319534 := by decide
theorem cert_e769017297326 : check e769017297326 [] .sourceHead = true := by decide
def e769017297338 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e769017297338 : Closed e769017297338 ∧ code e769017297338 = 9565110319546 := by decide
theorem cert_e769017297338 : check e769017297338 [] .sourceHead = true := by decide
def e769017297386 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e769017297386 : Closed e769017297386 ∧ code e769017297386 = 9565110319594 := by decide
theorem cert_e769017297386 : check e769017297386 [] .sourceHead = true := by decide
def e769017297518 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e769017297518 : Closed e769017297518 ∧ code e769017297518 = 9565110319726 := by decide
theorem cert_e769017297518 : check e769017297518 [] .sourceHead = true := by decide
def e769017297530 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e769017297530 : Closed e769017297530 ∧ code e769017297530 = 9565110319738 := by decide
theorem cert_e769017297530 : check e769017297530 [] .sourceHead = true := by decide
def e769017297818 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e769017297818 : Closed e769017297818 ∧ code e769017297818 = 9565110320026 := by decide
theorem cert_e769017297818 : check e769017297818 [] .sourceHead = true := by decide
def e769017298134 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e769017298134 : Closed e769017298134 ∧ code e769017298134 = 9565110320342 := by decide
theorem cert_e769017298134 : check e769017298134 [] .sourceHead = true := by decide
def e769017298138 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e769017298138 : Closed e769017298138 ∧ code e769017298138 = 9565110320346 := by decide
theorem cert_e769017298138 : check e769017298138 [] .sourceHead = true := by decide
def e769017298154 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e769017298154 : Closed e769017298154 ∧ code e769017298154 = 9565110320362 := by decide
theorem cert_e769017298154 : check e769017298154 [] .sourceHead = true := by decide
def e769017298230 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e769017298230 : Closed e769017298230 ∧ code e769017298230 = 9565110320438 := by decide
theorem cert_e769017298230 : check e769017298230 [] .sourceHead = true := by decide
def e769017298234 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e769017298234 : Closed e769017298234 ∧ code e769017298234 = 9565110320442 := by decide
theorem cert_e769017298234 : check e769017298234 [] .sourceHead = true := by decide
def e769017298330 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e769017298330 : Closed e769017298330 ∧ code e769017298330 = 9565110320538 := by decide
theorem cert_e769017298330 : check e769017298330 [] .sourceHead = true := by decide
def e769017301870 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e769017301870 : Closed e769017301870 ∧ code e769017301870 = 9565110324078 := by decide
theorem cert_e769017301870 : check e769017301870 [] .sourceHead = true := by decide
def e769017301878 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e769017301878 : Closed e769017301878 ∧ code e769017301878 = 9565110324086 := by decide
theorem cert_e769017301878 : check e769017301878 [] .sourceHead = true := by decide
def e769017301934 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e769017301934 : Closed e769017301934 ∧ code e769017301934 = 9565110324142 := by decide
theorem cert_e769017301934 : check e769017301934 [] .sourceHead = true := by decide
def e769017301946 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e769017301946 : Closed e769017301946 ∧ code e769017301946 = 9565110324154 := by decide
theorem cert_e769017301946 : check e769017301946 [] .sourceHead = true := by decide
def e769017301974 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e769017301974 : Closed e769017301974 ∧ code e769017301974 = 9565110324182 := by decide
theorem cert_e769017301974 : check e769017301974 [] .sourceHead = true := by decide
def e769017301978 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e769017301978 : Closed e769017301978 ∧ code e769017301978 = 9565110324186 := by decide
theorem cert_e769017301978 : check e769017301978 [] .sourceHead = true := by decide
def e769017302254 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e769017302254 : Closed e769017302254 ∧ code e769017302254 = 9565110324462 := by decide
theorem cert_e769017302254 : check e769017302254 [] .sourceHead = true := by decide
def e769017302262 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e769017302262 : Closed e769017302262 ∧ code e769017302262 = 9565110324470 := by decide
theorem cert_e769017302262 : check e769017302262 [] .sourceHead = true := by decide
def e769017302638 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e769017302638 : Closed e769017302638 ∧ code e769017302638 = 9565110324846 := by decide
theorem cert_e769017302638 : check e769017302638 [] .sourceHead = true := by decide
def e769017302650 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e769017302650 : Closed e769017302650 ∧ code e769017302650 = 9565110324858 := by decide
theorem cert_e769017302650 : check e769017302650 [] .sourceHead = true := by decide
def e769017302838 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e769017302838 : Closed e769017302838 ∧ code e769017302838 = 9565110325046 := by decide
theorem cert_e769017302838 : check e769017302838 [] .sourceHead = true := by decide
def e769017302842 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e769017302842 : Closed e769017302842 ∧ code e769017302842 = 9565110325050 := by decide
theorem cert_e769017302842 : check e769017302842 [] .sourceHead = true := by decide
def e769017308590 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e769017308590 : Closed e769017308590 ∧ code e769017308590 = 9565110330798 := by decide
theorem cert_e769017308590 : check e769017308590 [] .sourceHead = true := by decide
def e769017308602 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e769017308602 : Closed e769017308602 ∧ code e769017308602 = 9565110330810 := by decide
theorem cert_e769017308602 : check e769017308602 [] .sourceHead = true := by decide
def e769017308650 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e769017308650 : Closed e769017308650 ∧ code e769017308650 = 9565110330858 := by decide
theorem cert_e769017308650 : check e769017308650 [] .sourceHead = true := by decide
def e769017308782 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e769017308782 : Closed e769017308782 ∧ code e769017308782 = 9565110330990 := by decide
theorem cert_e769017308782 : check e769017308782 [] .sourceHead = true := by decide
def e769017308794 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e769017308794 : Closed e769017308794 ∧ code e769017308794 = 9565110331002 := by decide
theorem cert_e769017308794 : check e769017308794 [] .sourceHead = true := by decide
def e769017309082 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e769017309082 : Closed e769017309082 ∧ code e769017309082 = 9565110331290 := by decide
theorem cert_e769017309082 : check e769017309082 [] .sourceHead = true := by decide
def e769017311958 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e769017311958 : Closed e769017311958 ∧ code e769017311958 = 9565110334166 := by decide
theorem cert_e769017311958 : check e769017311958 [] .sourceHead = true := by decide
def e769017311962 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e769017311962 : Closed e769017311962 ∧ code e769017311962 = 9565110334170 := by decide
theorem cert_e769017311962 : check e769017311962 [] .sourceHead = true := by decide
def e769017311978 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e769017311978 : Closed e769017311978 ∧ code e769017311978 = 9565110334186 := by decide
theorem cert_e769017311978 : check e769017311978 [] .sourceHead = true := by decide
def e769017312054 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e769017312054 : Closed e769017312054 ∧ code e769017312054 = 9565110334262 := by decide
theorem cert_e769017312054 : check e769017312054 [] .sourceHead = true := by decide
def e769017312058 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e769017312058 : Closed e769017312058 ∧ code e769017312058 = 9565110334266 := by decide
theorem cert_e769017312058 : check e769017312058 [] .sourceHead = true := by decide
def e769017312154 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e769017312154 : Closed e769017312154 ∧ code e769017312154 = 9565110334362 := by decide
theorem cert_e769017312154 : check e769017312154 [] .sourceHead = true := by decide
def e769017449326 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e769017449326 : Closed e769017449326 ∧ code e769017449326 = 9565110471534 := by decide
theorem cert_e769017449326 : check e769017449326 [] .sourceHead = true := by decide
def e769017449334 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e769017449334 : Closed e769017449334 ∧ code e769017449334 = 9565110471542 := by decide
theorem cert_e769017449334 : check e769017449334 [] .sourceHead = true := by decide
def e769017449390 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e769017449390 : Closed e769017449390 ∧ code e769017449390 = 9565110471598 := by decide
theorem cert_e769017449390 : check e769017449390 [] .sourceHead = true := by decide
def e769017449402 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e769017449402 : Closed e769017449402 ∧ code e769017449402 = 9565110471610 := by decide
theorem cert_e769017449402 : check e769017449402 [] .sourceHead = true := by decide
def e769017449430 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e769017449430 : Closed e769017449430 ∧ code e769017449430 = 9565110471638 := by decide
theorem cert_e769017449430 : check e769017449430 [] .sourceHead = true := by decide
def e769017449434 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e769017449434 : Closed e769017449434 ∧ code e769017449434 = 9565110471642 := by decide
theorem cert_e769017449434 : check e769017449434 [] .sourceHead = true := by decide
def e769017449710 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e769017449710 : Closed e769017449710 ∧ code e769017449710 = 9565110471918 := by decide
theorem cert_e769017449710 : check e769017449710 [] .sourceHead = true := by decide
def e769017449718 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e769017449718 : Closed e769017449718 ∧ code e769017449718 = 9565110471926 := by decide
theorem cert_e769017449718 : check e769017449718 [] .sourceHead = true := by decide
def e769017450094 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e769017450094 : Closed e769017450094 ∧ code e769017450094 = 9565110472302 := by decide
theorem cert_e769017450094 : check e769017450094 [] .sourceHead = true := by decide
def e769017450106 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e769017450106 : Closed e769017450106 ∧ code e769017450106 = 9565110472314 := by decide
theorem cert_e769017450106 : check e769017450106 [] .sourceHead = true := by decide
def e769017450294 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e769017450294 : Closed e769017450294 ∧ code e769017450294 = 9565110472502 := by decide
theorem cert_e769017450294 : check e769017450294 [] .sourceHead = true := by decide
def e769017450298 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e769017450298 : Closed e769017450298 ∧ code e769017450298 = 9565110472506 := by decide
theorem cert_e769017450298 : check e769017450298 [] .sourceHead = true := by decide
def e769018039150 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e769018039150 : Closed e769018039150 ∧ code e769018039150 = 9565111061358 := by decide
theorem cert_e769018039150 : check e769018039150 [] .sourceHead = true := by decide
def e769018039158 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e769018039158 : Closed e769018039158 ∧ code e769018039158 = 9565111061366 := by decide
theorem cert_e769018039158 : check e769018039158 [] .sourceHead = true := by decide
def e769018039214 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e769018039214 : Closed e769018039214 ∧ code e769018039214 = 9565111061422 := by decide
theorem cert_e769018039214 : check e769018039214 [] .sourceHead = true := by decide
def e769018039226 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e769018039226 : Closed e769018039226 ∧ code e769018039226 = 9565111061434 := by decide
theorem cert_e769018039226 : check e769018039226 [] .sourceHead = true := by decide
def e769018039254 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e769018039254 : Closed e769018039254 ∧ code e769018039254 = 9565111061462 := by decide
theorem cert_e769018039254 : check e769018039254 [] .sourceHead = true := by decide
def e769018039258 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e769018039258 : Closed e769018039258 ∧ code e769018039258 = 9565111061466 := by decide
theorem cert_e769018039258 : check e769018039258 [] .sourceHead = true := by decide
def e769018039534 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e769018039534 : Closed e769018039534 ∧ code e769018039534 = 9565111061742 := by decide
theorem cert_e769018039534 : check e769018039534 [] .sourceHead = true := by decide
def e769018039542 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e769018039542 : Closed e769018039542 ∧ code e769018039542 = 9565111061750 := by decide
theorem cert_e769018039542 : check e769018039542 [] .sourceHead = true := by decide
def e769018039918 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e769018039918 : Closed e769018039918 ∧ code e769018039918 = 9565111062126 := by decide
theorem cert_e769018039918 : check e769018039918 [] .sourceHead = true := by decide
def e769018039930 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e769018039930 : Closed e769018039930 ∧ code e769018039930 = 9565111062138 := by decide
theorem cert_e769018039930 : check e769018039930 [] .sourceHead = true := by decide
def e769018040118 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e769018040118 : Closed e769018040118 ∧ code e769018040118 = 9565111062326 := by decide
theorem cert_e769018040118 : check e769018040118 [] .sourceHead = true := by decide
def e769018040122 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e769018040122 : Closed e769018040122 ∧ code e769018040122 = 9565111062330 := by decide
theorem cert_e769018040122 : check e769018040122 [] .sourceHead = true := by decide
def e773242006894 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e773242006894 : Closed e773242006894 ∧ code e773242006894 = 9569335029102 := by decide
theorem cert_e773242006894 : check e773242006894 [] .sourceHead = true := by decide
def e773242006902 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e773242006902 : Closed e773242006902 ∧ code e773242006902 = 9569335029110 := by decide
theorem cert_e773242006902 : check e773242006902 [] .sourceHead = true := by decide
def e773242006958 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e773242006958 : Closed e773242006958 ∧ code e773242006958 = 9569335029166 := by decide
theorem cert_e773242006958 : check e773242006958 [] .sourceHead = true := by decide
def e773242006970 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e773242006970 : Closed e773242006970 ∧ code e773242006970 = 9569335029178 := by decide
theorem cert_e773242006970 : check e773242006970 [] .sourceHead = true := by decide
def e773242006998 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e773242006998 : Closed e773242006998 ∧ code e773242006998 = 9569335029206 := by decide
theorem cert_e773242006998 : check e773242006998 [] .sourceHead = true := by decide
def e773242007002 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e773242007002 : Closed e773242007002 ∧ code e773242007002 = 9569335029210 := by decide
theorem cert_e773242007002 : check e773242007002 [] .sourceHead = true := by decide
def e773242007214 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e773242007214 : Closed e773242007214 ∧ code e773242007214 = 9569335029422 := by decide
theorem cert_e773242007214 : check e773242007214 [] .sourceHead = true := by decide
def e773242007226 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e773242007226 : Closed e773242007226 ∧ code e773242007226 = 9569335029434 := by decide
theorem cert_e773242007226 : check e773242007226 [] .sourceHead = true := by decide
def e773242007274 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e773242007274 : Closed e773242007274 ∧ code e773242007274 = 9569335029482 := by decide
theorem cert_e773242007274 : check e773242007274 [] .sourceHead = true := by decide
def e773242007382 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e773242007382 : Closed e773242007382 ∧ code e773242007382 = 9569335029590 := by decide
theorem cert_e773242007382 : check e773242007382 [] .sourceHead = true := by decide
def e773242007386 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e773242007386 : Closed e773242007386 ∧ code e773242007386 = 9569335029594 := by decide
theorem cert_e773242007386 : check e773242007386 [] .sourceHead = true := by decide
def e773242007402 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e773242007402 : Closed e773242007402 ∧ code e773242007402 = 9569335029610 := by decide
theorem cert_e773242007402 : check e773242007402 [] .sourceHead = true := by decide
def e773242008430 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e773242008430 : Closed e773242008430 ∧ code e773242008430 = 9569335030638 := by decide
theorem cert_e773242008430 : check e773242008430 [] .sourceHead = true := by decide
def e773242008438 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e773242008438 : Closed e773242008438 ∧ code e773242008438 = 9569335030646 := by decide
theorem cert_e773242008438 : check e773242008438 [] .sourceHead = true := by decide
def e773242008494 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e773242008494 : Closed e773242008494 ∧ code e773242008494 = 9569335030702 := by decide
theorem cert_e773242008494 : check e773242008494 [] .sourceHead = true := by decide
def e773242008506 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e773242008506 : Closed e773242008506 ∧ code e773242008506 = 9569335030714 := by decide
theorem cert_e773242008506 : check e773242008506 [] .sourceHead = true := by decide
def e773242008534 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e773242008534 : Closed e773242008534 ∧ code e773242008534 = 9569335030742 := by decide
theorem cert_e773242008534 : check e773242008534 [] .sourceHead = true := by decide
def e773242008538 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e773242008538 : Closed e773242008538 ∧ code e773242008538 = 9569335030746 := by decide
theorem cert_e773242008538 : check e773242008538 [] .sourceHead = true := by decide
def e773242008814 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e773242008814 : Closed e773242008814 ∧ code e773242008814 = 9569335031022 := by decide
theorem cert_e773242008814 : check e773242008814 [] .sourceHead = true := by decide
def e773242008822 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e773242008822 : Closed e773242008822 ∧ code e773242008822 = 9569335031030 := by decide
theorem cert_e773242008822 : check e773242008822 [] .sourceHead = true := by decide
def e773242009198 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e773242009198 : Closed e773242009198 ∧ code e773242009198 = 9569335031406 := by decide
theorem cert_e773242009198 : check e773242009198 [] .sourceHead = true := by decide
def e773242009210 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e773242009210 : Closed e773242009210 ∧ code e773242009210 = 9569335031418 := by decide
theorem cert_e773242009210 : check e773242009210 [] .sourceHead = true := by decide
def e773242009398 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e773242009398 : Closed e773242009398 ∧ code e773242009398 = 9569335031606 := by decide
theorem cert_e773242009398 : check e773242009398 [] .sourceHead = true := by decide
def e773242009402 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e773242009402 : Closed e773242009402 ∧ code e773242009402 = 9569335031610 := by decide
theorem cert_e773242009402 : check e773242009402 [] .sourceHead = true := by decide
def e773242010030 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e773242010030 : Closed e773242010030 ∧ code e773242010030 = 9569335032238 := by decide
theorem cert_e773242010030 : check e773242010030 [] .sourceHead = true := by decide
def e773242010042 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e773242010042 : Closed e773242010042 ∧ code e773242010042 = 9569335032250 := by decide
theorem cert_e773242010042 : check e773242010042 [] .sourceHead = true := by decide
def e773242010090 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e773242010090 : Closed e773242010090 ∧ code e773242010090 = 9569335032298 := by decide
theorem cert_e773242010090 : check e773242010090 [] .sourceHead = true := by decide
def e773242010222 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e773242010222 : Closed e773242010222 ∧ code e773242010222 = 9569335032430 := by decide
theorem cert_e773242010222 : check e773242010222 [] .sourceHead = true := by decide
def e773242010234 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e773242010234 : Closed e773242010234 ∧ code e773242010234 = 9569335032442 := by decide
theorem cert_e773242010234 : check e773242010234 [] .sourceHead = true := by decide
def e773242010522 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e773242010522 : Closed e773242010522 ∧ code e773242010522 = 9569335032730 := by decide
theorem cert_e773242010522 : check e773242010522 [] .sourceHead = true := by decide
def e773242010838 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e773242010838 : Closed e773242010838 ∧ code e773242010838 = 9569335033046 := by decide
theorem cert_e773242010838 : check e773242010838 [] .sourceHead = true := by decide
def e773242010842 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e773242010842 : Closed e773242010842 ∧ code e773242010842 = 9569335033050 := by decide
theorem cert_e773242010842 : check e773242010842 [] .sourceHead = true := by decide
def e773242010858 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e773242010858 : Closed e773242010858 ∧ code e773242010858 = 9569335033066 := by decide
theorem cert_e773242010858 : check e773242010858 [] .sourceHead = true := by decide
def e773242010934 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e773242010934 : Closed e773242010934 ∧ code e773242010934 = 9569335033142 := by decide
theorem cert_e773242010934 : check e773242010934 [] .sourceHead = true := by decide
def e773242010938 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e773242010938 : Closed e773242010938 ∧ code e773242010938 = 9569335033146 := by decide
theorem cert_e773242010938 : check e773242010938 [] .sourceHead = true := by decide
def e773242011034 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e773242011034 : Closed e773242011034 ∧ code e773242011034 = 9569335033242 := by decide
theorem cert_e773242011034 : check e773242011034 [] .sourceHead = true := by decide
def e773242014574 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e773242014574 : Closed e773242014574 ∧ code e773242014574 = 9569335036782 := by decide
theorem cert_e773242014574 : check e773242014574 [] .sourceHead = true := by decide
def e773242014582 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e773242014582 : Closed e773242014582 ∧ code e773242014582 = 9569335036790 := by decide
theorem cert_e773242014582 : check e773242014582 [] .sourceHead = true := by decide
def e773242014638 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e773242014638 : Closed e773242014638 ∧ code e773242014638 = 9569335036846 := by decide
theorem cert_e773242014638 : check e773242014638 [] .sourceHead = true := by decide
def e773242014650 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e773242014650 : Closed e773242014650 ∧ code e773242014650 = 9569335036858 := by decide
theorem cert_e773242014650 : check e773242014650 [] .sourceHead = true := by decide
def e773242014678 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e773242014678 : Closed e773242014678 ∧ code e773242014678 = 9569335036886 := by decide
theorem cert_e773242014678 : check e773242014678 [] .sourceHead = true := by decide
def e773242014682 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e773242014682 : Closed e773242014682 ∧ code e773242014682 = 9569335036890 := by decide
theorem cert_e773242014682 : check e773242014682 [] .sourceHead = true := by decide
end Blc.Floor43
