import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405955985818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405955985818 : Closed e2405955985818 ∧ code e2405955985818 = 11202049008026 := by decide
theorem cert_e2405955985818 : check e2405955985818 [[]] .width = true := by decide
def e2405956034586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405956034586 : Closed e2405956034586 ∧ code e2405956034586 = 11202049056794 := by decide
theorem cert_e2405956034586 : check e2405956034586 [[]] .width = true := by decide
def e2405956034678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405956034678 : Closed e2405956034678 ∧ code e2405956034678 = 11202049056886 := by decide
theorem cert_e2405956034678 : check e2405956034678 [[]] .width = true := by decide
def e2405956034922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405956034922 : Closed e2405956034922 ∧ code e2405956034922 = 11202049057130 := by decide
theorem cert_e2405956034922 : check e2405956034922 [[]] .width = true := by decide
def e2405956034970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405956034970 : Closed e2405956034970 ∧ code e2405956034970 = 11202049057178 := by decide
theorem cert_e2405956034970 : check e2405956034970 [[]] .width = true := by decide
def e2405956706330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405956706330 : Closed e2405956706330 ∧ code e2405956706330 = 11202049728538 := by decide
theorem cert_e2405956706330 : check e2405956706330 [[]] .width = true := by decide
def e2405956706422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405956706422 : Closed e2405956706422 ∧ code e2405956706422 = 11202049728630 := by decide
theorem cert_e2405956706422 : check e2405956706422 [[]] .width = true := by decide
def e2405956706666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405956706666 : Closed e2405956706666 ∧ code e2405956706666 = 11202049728874 := by decide
theorem cert_e2405956706666 : check e2405956706666 [[]] .width = true := by decide
def e2405956706714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405956706714 : Closed e2405956706714 ∧ code e2405956706714 = 11202049728922 := by decide
theorem cert_e2405956706714 : check e2405956706714 [[]] .width = true := by decide
def e2405956808902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405956808902 : Closed e2405956808902 ∧ code e2405956808902 = 11202049831110 := by decide
theorem cert_e2405956808902 : check e2405956808902 [[]] .width = true := by decide
def e2405956827162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405956827162 : Closed e2405956827162 ∧ code e2405956827162 = 11202049849370 := by decide
theorem cert_e2405956827162 : check e2405956827162 [[]] .width = true := by decide
def e2405956833478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405956833478 : Closed e2405956833478 ∧ code e2405956833478 = 11202049855686 := by decide
theorem cert_e2405956833478 : check e2405956833478 [[]] .width = true := by decide
def e2405956835354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405956835354 : Closed e2405956835354 ∧ code e2405956835354 = 11202049857562 := by decide
theorem cert_e2405956835354 : check e2405956835354 [[]] .width = true := by decide
def e2405957042374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405957042374 : Closed e2405957042374 ∧ code e2405957042374 = 11202050064582 := by decide
theorem cert_e2405957042374 : check e2405957042374 [[]] .width = true := by decide
def e2405957042902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405957042902 : Closed e2405957042902 ∧ code e2405957042902 = 11202050065110 := by decide
theorem cert_e2405957042902 : check e2405957042902 [[]] .width = true := by decide
def e2405957042906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405957042906 : Closed e2405957042906 ∧ code e2405957042906 = 11202050065114 := by decide
theorem cert_e2405957042906 : check e2405957042906 [[]] .width = true := by decide
def e2405957042922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405957042922 : Closed e2405957042922 ∧ code e2405957042922 = 11202050065130 := by decide
theorem cert_e2405957042922 : check e2405957042922 [[]] .width = true := by decide
def e2405957042998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405957042998 : Closed e2405957042998 ∧ code e2405957042998 = 11202050065206 := by decide
theorem cert_e2405957042998 : check e2405957042998 [[]] .width = true := by decide
def e2405957043002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405957043002 : Closed e2405957043002 ∧ code e2405957043002 = 11202050065210 := by decide
theorem cert_e2405957043002 : check e2405957043002 [[]] .width = true := by decide
def e2405957043086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405957043086 : Closed e2405957043086 ∧ code e2405957043086 = 11202050065294 := by decide
theorem cert_e2405957043086 : check e2405957043086 [[]] .width = true := by decide
def e2405957043098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405957043098 : Closed e2405957043098 ∧ code e2405957043098 = 11202050065306 := by decide
theorem cert_e2405957043098 : check e2405957043098 [[]] .width = true := by decide
def e2405957045018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405957045018 : Closed e2405957045018 ∧ code e2405957045018 = 11202050067226 := by decide
theorem cert_e2405957045018 : check e2405957045018 [[]] .width = true := by decide
def e2405957045062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405957045062 : Closed e2405957045062 ∧ code e2405957045062 = 11202050067270 := by decide
theorem cert_e2405957045062 : check e2405957045062 [[]] .width = true := by decide
def e2405957045302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405957045302 : Closed e2405957045302 ∧ code e2405957045302 = 11202050067510 := by decide
theorem cert_e2405957045302 : check e2405957045302 [[]] .width = true := by decide
def e2405957045306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405957045306 : Closed e2405957045306 ∧ code e2405957045306 = 11202050067514 := by decide
theorem cert_e2405957045306 : check e2405957045306 [[]] .width = true := by decide
def e2405957045446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405957045446 : Closed e2405957045446 ∧ code e2405957045446 = 11202050067654 := by decide
theorem cert_e2405957045446 : check e2405957045446 [[]] .width = true := by decide
def e2405957220378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405957220378 : Closed e2405957220378 ∧ code e2405957220378 = 11202050242586 := by decide
theorem cert_e2405957220378 : check e2405957220378 [[]] .width = true := by decide
def e2405957232666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405957232666 : Closed e2405957232666 ∧ code e2405957232666 = 11202050254874 := by decide
theorem cert_e2405957232666 : check e2405957232666 [[]] .width = true := by decide
def e2405957394458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405957394458 : Closed e2405957394458 ∧ code e2405957394458 = 11202050416666 := by decide
theorem cert_e2405957394458 : check e2405957394458 [[]] .width = true := by decide
def e2405957394550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405957394550 : Closed e2405957394550 ∧ code e2405957394550 = 11202050416758 := by decide
theorem cert_e2405957394550 : check e2405957394550 [[]] .width = true := by decide
def e2405957394794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405957394794 : Closed e2405957394794 ∧ code e2405957394794 = 11202050417002 := by decide
theorem cert_e2405957394794 : check e2405957394794 [[]] .width = true := by decide
def e2405957394842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405957394842 : Closed e2405957394842 ∧ code e2405957394842 = 11202050417050 := by decide
theorem cert_e2405957394842 : check e2405957394842 [[]] .width = true := by decide
def e2405957423302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405957423302 : Closed e2405957423302 ∧ code e2405957423302 = 11202050445510 := by decide
theorem cert_e2405957423302 : check e2405957423302 [[]] .width = true := by decide
def e2405957435590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405957435590 : Closed e2405957435590 ∧ code e2405957435590 = 11202050457798 := by decide
theorem cert_e2405957435590 : check e2405957435590 [[]] .width = true := by decide
def e2405957436118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405957436118 : Closed e2405957436118 ∧ code e2405957436118 = 11202050458326 := by decide
theorem cert_e2405957436118 : check e2405957436118 [[]] .width = true := by decide
def e2405957436122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405957436122 : Closed e2405957436122 ∧ code e2405957436122 = 11202050458330 := by decide
theorem cert_e2405957436122 : check e2405957436122 [[]] .width = true := by decide
def e2405957436138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405957436138 : Closed e2405957436138 ∧ code e2405957436138 = 11202050458346 := by decide
theorem cert_e2405957436138 : check e2405957436138 [[]] .width = true := by decide
def e2405957436214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405957436214 : Closed e2405957436214 ∧ code e2405957436214 = 11202050458422 := by decide
theorem cert_e2405957436214 : check e2405957436214 [[]] .width = true := by decide
def e2405957436218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405957436218 : Closed e2405957436218 ∧ code e2405957436218 = 11202050458426 := by decide
theorem cert_e2405957436218 : check e2405957436218 [[]] .width = true := by decide
def e2405957436302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405957436302 : Closed e2405957436302 ∧ code e2405957436302 = 11202050458510 := by decide
theorem cert_e2405957436302 : check e2405957436302 [[]] .width = true := by decide
def e2405957436314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405957436314 : Closed e2405957436314 ∧ code e2405957436314 = 11202050458522 := by decide
theorem cert_e2405957436314 : check e2405957436314 [[]] .width = true := by decide
def e2405957438234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405957438234 : Closed e2405957438234 ∧ code e2405957438234 = 11202050460442 := by decide
theorem cert_e2405957438234 : check e2405957438234 [[]] .width = true := by decide
def e2405957438278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405957438278 : Closed e2405957438278 ∧ code e2405957438278 = 11202050460486 := by decide
theorem cert_e2405957438278 : check e2405957438278 [[]] .width = true := by decide
def e2405957438518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405957438518 : Closed e2405957438518 ∧ code e2405957438518 = 11202050460726 := by decide
theorem cert_e2405957438518 : check e2405957438518 [[]] .width = true := by decide
def e2405957438522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405957438522 : Closed e2405957438522 ∧ code e2405957438522 = 11202050460730 := by decide
theorem cert_e2405957438522 : check e2405957438522 [[]] .width = true := by decide
def e2405957438662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405957438662 : Closed e2405957438662 ∧ code e2405957438662 = 11202050460870 := by decide
theorem cert_e2405957438662 : check e2405957438662 [[]] .width = true := by decide
def e2405959383066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405959383066 : Closed e2405959383066 ∧ code e2405959383066 = 11202052405274 := by decide
theorem cert_e2405959383066 : check e2405959383066 [[]] .width = true := by decide
def e2405959395354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405959395354 : Closed e2405959395354 ∧ code e2405959395354 = 11202052417562 := by decide
theorem cert_e2405959395354 : check e2405959395354 [[]] .width = true := by decide
def e2405959396890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405959396890 : Closed e2405959396890 ∧ code e2405959396890 = 11202052419098 := by decide
theorem cert_e2405959396890 : check e2405959396890 [[]] .width = true := by decide
def e2405959444506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405959444506 : Closed e2405959444506 ∧ code e2405959444506 = 11202052466714 := by decide
theorem cert_e2405959444506 : check e2405959444506 [[]] .width = true := by decide
def e2405959446042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405959446042 : Closed e2405959446042 ∧ code e2405959446042 = 11202052468250 := by decide
theorem cert_e2405959446042 : check e2405959446042 [[]] .width = true := by decide
def e2405959449114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405959449114 : Closed e2405959449114 ∧ code e2405959449114 = 11202052471322 := by decide
theorem cert_e2405959449114 : check e2405959449114 [[]] .width = true := by decide
def e2405959641114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405959641114 : Closed e2405959641114 ∧ code e2405959641114 = 11202052663322 := by decide
theorem cert_e2405959641114 : check e2405959641114 [[]] .width = true := by decide
def e2405959642650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405959642650 : Closed e2405959642650 ∧ code e2405959642650 = 11202052664858 := by decide
theorem cert_e2405959642650 : check e2405959642650 [[]] .width = true := by decide
def e2405959645722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405959645722 : Closed e2405959645722 ∧ code e2405959645722 = 11202052667930 := by decide
theorem cert_e2405959645722 : check e2405959645722 [[]] .width = true := by decide
def e2405959658010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405959658010 : Closed e2405959658010 ∧ code e2405959658010 = 11202052680218 := by decide
private def t_e2405959658010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405959658010 : ¬ IsSelfInterpreter e2405959658010 :=
  wSource (t := t_e2405959658010) (replay_sound (ps := []) (t := e2405959658010) (by decide)) (by decide)
def e2405959776282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405959776282 : Closed e2405959776282 ∧ code e2405959776282 = 11202052798490 := by decide
theorem cert_e2405959776282 : check e2405959776282 [[]] .width = true := by decide
def e2405959917594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405959917594 : Closed e2405959917594 ∧ code e2405959917594 = 11202052939802 := by decide
theorem cert_e2405959917594 : check e2405959917594 [[]] .width = true := by decide
def e2405959917686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405959917686 : Closed e2405959917686 ∧ code e2405959917686 = 11202052939894 := by decide
theorem cert_e2405959917686 : check e2405959917686 [[]] .width = true := by decide
def e2405959917930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405959917930 : Closed e2405959917930 ∧ code e2405959917930 = 11202052940138 := by decide
theorem cert_e2405959917930 : check e2405959917930 [[]] .width = true := by decide
def e2405959917978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405959917978 : Closed e2405959917978 ∧ code e2405959917978 = 11202052940186 := by decide
theorem cert_e2405959917978 : check e2405959917978 [[]] .width = true := by decide
def e2405959954630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405959954630 : Closed e2405959954630 ∧ code e2405959954630 = 11202052976838 := by decide
theorem cert_e2405959954630 : check e2405959954630 [[]] .width = true := by decide
def e2405959972890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405959972890 : Closed e2405959972890 ∧ code e2405959972890 = 11202052995098 := by decide
theorem cert_e2405959972890 : check e2405959972890 [[]] .width = true := by decide
def e2405959979206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405959979206 : Closed e2405959979206 ∧ code e2405959979206 = 11202053001414 := by decide
theorem cert_e2405959979206 : check e2405959979206 [[]] .width = true := by decide
def e2405960169498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960169498 : Closed e2405960169498 ∧ code e2405960169498 = 11202053191706 := by decide
theorem cert_e2405960169498 : check e2405960169498 [[]] .width = true := by decide
def e2405960181786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960181786 : Closed e2405960181786 ∧ code e2405960181786 = 11202053203994 := by decide
theorem cert_e2405960181786 : check e2405960181786 [[]] .width = true := by decide
def e2405960183322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405960183322 : Closed e2405960183322 ∧ code e2405960183322 = 11202053205530 := by decide
theorem cert_e2405960183322 : check e2405960183322 [[]] .width = true := by decide
def e2405960230938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960230938 : Closed e2405960230938 ∧ code e2405960230938 = 11202053253146 := by decide
theorem cert_e2405960230938 : check e2405960230938 [[]] .width = true := by decide
def e2405960232474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405960232474 : Closed e2405960232474 ∧ code e2405960232474 = 11202053254682 := by decide
theorem cert_e2405960232474 : check e2405960232474 [[]] .width = true := by decide
def e2405960235546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405960235546 : Closed e2405960235546 ∧ code e2405960235546 = 11202053257754 := by decide
theorem cert_e2405960235546 : check e2405960235546 [[]] .width = true := by decide
def e2405960315078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405960315078 : Closed e2405960315078 ∧ code e2405960315078 = 11202053337286 := by decide
theorem cert_e2405960315078 : check e2405960315078 [[]] .width = true := by decide
def e2405960366106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960366106 : Closed e2405960366106 ∧ code e2405960366106 = 11202053388314 := by decide
theorem cert_e2405960366106 : check e2405960366106 [[]] .width = true := by decide
def e2405960378394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960378394 : Closed e2405960378394 ∧ code e2405960378394 = 11202053400602 := by decide
theorem cert_e2405960378394 : check e2405960378394 [[]] .width = true := by decide
def e2405960379930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405960379930 : Closed e2405960379930 ∧ code e2405960379930 = 11202053402138 := by decide
theorem cert_e2405960379930 : check e2405960379930 [[]] .width = true := by decide
def e2405960482842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405960482842 : Closed e2405960482842 ∧ code e2405960482842 = 11202053505050 := by decide
theorem cert_e2405960482842 : check e2405960482842 [[]] .width = true := by decide
def e2405960482934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405960482934 : Closed e2405960482934 ∧ code e2405960482934 = 11202053505142 := by decide
theorem cert_e2405960482934 : check e2405960482934 [[]] .width = true := by decide
def e2405960483178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405960483178 : Closed e2405960483178 ∧ code e2405960483178 = 11202053505386 := by decide
theorem cert_e2405960483178 : check e2405960483178 [[]] .width = true := by decide
def e2405960483226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405960483226 : Closed e2405960483226 ∧ code e2405960483226 = 11202053505434 := by decide
theorem cert_e2405960483226 : check e2405960483226 [[]] .width = true := by decide
def e2405960484234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405960484234 : Closed e2405960484234 ∧ code e2405960484234 = 11202053506442 := by decide
theorem cert_e2405960484234 : check e2405960484234 [[]] .width = true := by decide
def e2405960484258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405960484258 : Closed e2405960484258 ∧ code e2405960484258 = 11202053506466 := by decide
theorem cert_e2405960484258 : check e2405960484258 [[]] .width = true := by decide
def e2405960484366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405960484366 : Closed e2405960484366 ∧ code e2405960484366 = 11202053506574 := by decide
theorem cert_e2405960484366 : check e2405960484366 [[]] .width = true := by decide
def e2405960484378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405960484378 : Closed e2405960484378 ∧ code e2405960484378 = 11202053506586 := by decide
theorem cert_e2405960484378 : check e2405960484378 [[]] .width = true := by decide
def e2405960484450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405960484450 : Closed e2405960484450 ∧ code e2405960484450 = 11202053506658 := by decide
theorem cert_e2405960484450 : check e2405960484450 [[]] .width = true := by decide
def e2405960630470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405960630470 : Closed e2405960630470 ∧ code e2405960630470 = 11202053652678 := by decide
theorem cert_e2405960630470 : check e2405960630470 [[]] .width = true := by decide
def e2405960648730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960648730 : Closed e2405960648730 ∧ code e2405960648730 = 11202053670938 := by decide
theorem cert_e2405960648730 : check e2405960648730 [[]] .width = true := by decide
def e2405960654874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405960654874 : Closed e2405960654874 ∧ code e2405960654874 = 11202053677082 := by decide
theorem cert_e2405960654874 : check e2405960654874 [[]] .width = true := by decide
def e2405960654966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405960654966 : Closed e2405960654966 ∧ code e2405960654966 = 11202053677174 := by decide
theorem cert_e2405960654966 : check e2405960654966 [[]] .width = true := by decide
def e2405960655210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405960655210 : Closed e2405960655210 ∧ code e2405960655210 = 11202053677418 := by decide
theorem cert_e2405960655210 : check e2405960655210 [[]] .width = true := by decide
def e2405960655258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405960655258 : Closed e2405960655258 ∧ code e2405960655258 = 11202053677466 := by decide
theorem cert_e2405960655258 : check e2405960655258 [[]] .width = true := by decide
def e2405960659142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405960659142 : Closed e2405960659142 ∧ code e2405960659142 = 11202053681350 := by decide
theorem cert_e2405960659142 : check e2405960659142 [[]] .width = true := by decide
def e2405960661018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960661018 : Closed e2405960661018 ∧ code e2405960661018 = 11202053683226 := by decide
theorem cert_e2405960661018 : check e2405960661018 [[]] .width = true := by decide
def e2405960673306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960673306 : Closed e2405960673306 ∧ code e2405960673306 = 11202053695514 := by decide
theorem cert_e2405960673306 : check e2405960673306 [[]] .width = true := by decide
def e2405960674842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405960674842 : Closed e2405960674842 ∧ code e2405960674842 = 11202053697050 := by decide
theorem cert_e2405960674842 : check e2405960674842 [[]] .width = true := by decide
def e2405960677914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405960677914 : Closed e2405960677914 ∧ code e2405960677914 = 11202053700122 := by decide
theorem cert_e2405960677914 : check e2405960677914 [[]] .width = true := by decide
def e2405960679450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405960679450 : Closed e2405960679450 ∧ code e2405960679450 = 11202053701658 := by decide
theorem cert_e2405960679450 : check e2405960679450 [[]] .width = true := by decide
def e2405960679542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405960679542 : Closed e2405960679542 ∧ code e2405960679542 = 11202053701750 := by decide
theorem cert_e2405960679542 : check e2405960679542 [[]] .width = true := by decide
def e2405960679786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405960679786 : Closed e2405960679786 ∧ code e2405960679786 = 11202053701994 := by decide
theorem cert_e2405960679786 : check e2405960679786 [[]] .width = true := by decide
def e2405960679834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405960679834 : Closed e2405960679834 ∧ code e2405960679834 = 11202053702042 := by decide
theorem cert_e2405960679834 : check e2405960679834 [[]] .width = true := by decide
def e2405960680842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405960680842 : Closed e2405960680842 ∧ code e2405960680842 = 11202053703050 := by decide
theorem cert_e2405960680842 : check e2405960680842 [[]] .width = true := by decide
def e2405960680866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405960680866 : Closed e2405960680866 ∧ code e2405960680866 = 11202053703074 := by decide
theorem cert_e2405960680866 : check e2405960680866 [[]] .width = true := by decide
def e2405960680974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405960680974 : Closed e2405960680974 ∧ code e2405960680974 = 11202053703182 := by decide
theorem cert_e2405960680974 : check e2405960680974 [[]] .width = true := by decide
def e2405960680986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405960680986 : Closed e2405960680986 ∧ code e2405960680986 = 11202053703194 := by decide
theorem cert_e2405960680986 : check e2405960680986 [[]] .width = true := by decide
def e2405960681058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405960681058 : Closed e2405960681058 ∧ code e2405960681058 = 11202053703266 := by decide
theorem cert_e2405960681058 : check e2405960681058 [[]] .width = true := by decide
def e2405960696006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405960696006 : Closed e2405960696006 ∧ code e2405960696006 = 11202053718214 := by decide
theorem cert_e2405960696006 : check e2405960696006 [[]] .width = true := by decide
def e2405960704026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405960704026 : Closed e2405960704026 ∧ code e2405960704026 = 11202053726234 := by decide
theorem cert_e2405960704026 : check e2405960704026 [[]] .width = true := by decide
def e2405960704118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405960704118 : Closed e2405960704118 ∧ code e2405960704118 = 11202053726326 := by decide
theorem cert_e2405960704118 : check e2405960704118 [[]] .width = true := by decide
def e2405960704362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405960704362 : Closed e2405960704362 ∧ code e2405960704362 = 11202053726570 := by decide
theorem cert_e2405960704362 : check e2405960704362 [[]] .width = true := by decide
def e2405960704410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405960704410 : Closed e2405960704410 ∧ code e2405960704410 = 11202053726618 := by decide
theorem cert_e2405960704410 : check e2405960704410 [[]] .width = true := by decide
def e2405960890394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405960890394 : Closed e2405960890394 ∧ code e2405960890394 = 11202053912602 := by decide
theorem cert_e2405960890394 : check e2405960890394 [[]] .width = true := by decide
def e2405961154758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405961154758 : Closed e2405961154758 ∧ code e2405961154758 = 11202054176966 := by decide
theorem cert_e2405961154758 : check e2405961154758 [[]] .width = true := by decide
def e2405961242650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961242650 : Closed e2405961242650 ∧ code e2405961242650 = 11202054264858 := by decide
theorem cert_e2405961242650 : check e2405961242650 [[]] .width = true := by decide
def e2405961253062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405961253062 : Closed e2405961253062 ∧ code e2405961253062 = 11202054275270 := by decide
theorem cert_e2405961253062 : check e2405961253062 [[]] .width = true := by decide
def e2405961312282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961312282 : Closed e2405961312282 ∧ code e2405961312282 = 11202054334490 := by decide
theorem cert_e2405961312282 : check e2405961312282 [[]] .width = true := by decide
def e2405961343002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405961343002 : Closed e2405961343002 ∧ code e2405961343002 = 11202054365210 := by decide
theorem cert_e2405961343002 : check e2405961343002 [[]] .width = true := by decide
def e2405961343094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405961343094 : Closed e2405961343094 ∧ code e2405961343094 = 11202054365302 := by decide
theorem cert_e2405961343094 : check e2405961343094 [[]] .width = true := by decide
def e2405961343338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405961343338 : Closed e2405961343338 ∧ code e2405961343338 = 11202054365546 := by decide
theorem cert_e2405961343338 : check e2405961343338 [[]] .width = true := by decide
def e2405961343386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405961343386 : Closed e2405961343386 ∧ code e2405961343386 = 11202054365594 := by decide
theorem cert_e2405961343386 : check e2405961343386 [[]] .width = true := by decide
def e2405961355462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405961355462 : Closed e2405961355462 ∧ code e2405961355462 = 11202054377670 := by decide
theorem cert_e2405961355462 : check e2405961355462 [[]] .width = true := by decide
def e2405961357338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961357338 : Closed e2405961357338 ∧ code e2405961357338 = 11202054379546 := by decide
theorem cert_e2405961357338 : check e2405961357338 [[]] .width = true := by decide
def e2405961361434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961361434 : Closed e2405961361434 ∧ code e2405961361434 = 11202054383642 := by decide
theorem cert_e2405961361434 : check e2405961361434 [[]] .width = true := by decide
def e2405961410586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961410586 : Closed e2405961410586 ∧ code e2405961410586 = 11202054432794 := by decide
theorem cert_e2405961410586 : check e2405961410586 [[]] .width = true := by decide
def e2405961412122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405961412122 : Closed e2405961412122 ∧ code e2405961412122 = 11202054434330 := by decide
theorem cert_e2405961412122 : check e2405961412122 [[]] .width = true := by decide
def e2405961415194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405961415194 : Closed e2405961415194 ∧ code e2405961415194 = 11202054437402 := by decide
theorem cert_e2405961415194 : check e2405961415194 [[]] .width = true := by decide
def e2405961427482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405961427482 : Closed e2405961427482 ∧ code e2405961427482 = 11202054449690 := by decide
theorem cert_e2405961427482 : check e2405961427482 [[]] .width = true := by decide
def e2405961435162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961435162 : Closed e2405961435162 ∧ code e2405961435162 = 11202054457370 := by decide
theorem cert_e2405961435162 : check e2405961435162 [[]] .width = true := by decide
def e2405961441306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405961441306 : Closed e2405961441306 ∧ code e2405961441306 = 11202054463514 := by decide
theorem cert_e2405961441306 : check e2405961441306 [[]] .width = true := by decide
def e2405961441398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405961441398 : Closed e2405961441398 ∧ code e2405961441398 = 11202054463606 := by decide
theorem cert_e2405961441398 : check e2405961441398 [[]] .width = true := by decide
def e2405961441642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405961441642 : Closed e2405961441642 ∧ code e2405961441642 = 11202054463850 := by decide
theorem cert_e2405961441642 : check e2405961441642 [[]] .width = true := by decide
def e2405961441690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405961441690 : Closed e2405961441690 ∧ code e2405961441690 = 11202054463898 := by decide
theorem cert_e2405961441690 : check e2405961441690 [[]] .width = true := by decide
def e2405961445574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405961445574 : Closed e2405961445574 ∧ code e2405961445574 = 11202054467782 := by decide
theorem cert_e2405961445574 : check e2405961445574 [[]] .width = true := by decide
def e2405961447450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961447450 : Closed e2405961447450 ∧ code e2405961447450 = 11202054469658 := by decide
theorem cert_e2405961447450 : check e2405961447450 [[]] .width = true := by decide
def e2405961459738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961459738 : Closed e2405961459738 ∧ code e2405961459738 = 11202054481946 := by decide
theorem cert_e2405961459738 : check e2405961459738 [[]] .width = true := by decide
def e2405961461274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405961461274 : Closed e2405961461274 ∧ code e2405961461274 = 11202054483482 := by decide
theorem cert_e2405961461274 : check e2405961461274 [[]] .width = true := by decide
def e2405961464346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405961464346 : Closed e2405961464346 ∧ code e2405961464346 = 11202054486554 := by decide
theorem cert_e2405961464346 : check e2405961464346 [[]] .width = true := by decide
def e2405961465882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405961465882 : Closed e2405961465882 ∧ code e2405961465882 = 11202054488090 := by decide
theorem cert_e2405961465882 : check e2405961465882 [[]] .width = true := by decide
def e2405961465974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405961465974 : Closed e2405961465974 ∧ code e2405961465974 = 11202054488182 := by decide
theorem cert_e2405961465974 : check e2405961465974 [[]] .width = true := by decide
def e2405961466218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405961466218 : Closed e2405961466218 ∧ code e2405961466218 = 11202054488426 := by decide
theorem cert_e2405961466218 : check e2405961466218 [[]] .width = true := by decide
def e2405961466266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405961466266 : Closed e2405961466266 ∧ code e2405961466266 = 11202054488474 := by decide
theorem cert_e2405961466266 : check e2405961466266 [[]] .width = true := by decide
def e2405961467274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405961467274 : Closed e2405961467274 ∧ code e2405961467274 = 11202054489482 := by decide
theorem cert_e2405961467274 : check e2405961467274 [[]] .width = true := by decide
def e2405961467298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405961467298 : Closed e2405961467298 ∧ code e2405961467298 = 11202054489506 := by decide
theorem cert_e2405961467298 : check e2405961467298 [[]] .width = true := by decide
def e2405961467406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405961467406 : Closed e2405961467406 ∧ code e2405961467406 = 11202054489614 := by decide
theorem cert_e2405961467406 : check e2405961467406 [[]] .width = true := by decide
def e2405961467418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405961467418 : Closed e2405961467418 ∧ code e2405961467418 = 11202054489626 := by decide
theorem cert_e2405961467418 : check e2405961467418 [[]] .width = true := by decide
def e2405961467490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405961467490 : Closed e2405961467490 ∧ code e2405961467490 = 11202054489698 := by decide
theorem cert_e2405961467490 : check e2405961467490 [[]] .width = true := by decide
def e2405961482438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405961482438 : Closed e2405961482438 ∧ code e2405961482438 = 11202054504646 := by decide
theorem cert_e2405961482438 : check e2405961482438 [[]] .width = true := by decide
def e2405961490458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405961490458 : Closed e2405961490458 ∧ code e2405961490458 = 11202054512666 := by decide
theorem cert_e2405961490458 : check e2405961490458 [[]] .width = true := by decide
def e2405961490550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405961490550 : Closed e2405961490550 ∧ code e2405961490550 = 11202054512758 := by decide
theorem cert_e2405961490550 : check e2405961490550 [[]] .width = true := by decide
def e2405961490794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405961490794 : Closed e2405961490794 ∧ code e2405961490794 = 11202054513002 := by decide
theorem cert_e2405961490794 : check e2405961490794 [[]] .width = true := by decide
def e2405961490842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405961490842 : Closed e2405961490842 ∧ code e2405961490842 = 11202054513050 := by decide
theorem cert_e2405961490842 : check e2405961490842 [[]] .width = true := by decide
def e2405961504794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405961504794 : Closed e2405961504794 ∧ code e2405961504794 = 11202054527002 := by decide
theorem cert_e2405961504794 : check e2405961504794 [[]] .width = true := by decide
def e2405961515206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405961515206 : Closed e2405961515206 ∧ code e2405961515206 = 11202054537414 := by decide
theorem cert_e2405961515206 : check e2405961515206 [[]] .width = true := by decide
def e2405961538074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405961538074 : Closed e2405961538074 ∧ code e2405961538074 = 11202054560282 := by decide
private def t_e2405961538074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405961538074 : ¬ IsSelfInterpreter e2405961538074 :=
  wSource (t := t_e2405961538074) (replay_sound (ps := []) (t := e2405961538074) (by decide)) (by decide)
def e2405961539610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405961539610 : Closed e2405961539610 ∧ code e2405961539610 = 11202054561818 := by decide
theorem cert_e2405961539610 : check e2405961539610 [[]] .width = true := by decide
def e2405961539702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405961539702 : Closed e2405961539702 ∧ code e2405961539702 = 11202054561910 := by decide
private def t_e2405961539702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405961539702 : ¬ IsSelfInterpreter e2405961539702 :=
  wSource (t := t_e2405961539702) (replay_sound (ps := []) (t := e2405961539702) (by decide)) (by decide)
def e2405961539946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405961539946 : Closed e2405961539946 ∧ code e2405961539946 = 11202054562154 := by decide
private def t_e2405961539946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405961539946 : ¬ IsSelfInterpreter e2405961539946 :=
  wSource (t := t_e2405961539946) (replay_sound (ps := []) (t := e2405961539946) (by decide)) (by decide)
def e2405961539994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405961539994 : Closed e2405961539994 ∧ code e2405961539994 = 11202054562202 := by decide
private def t_e2405961539994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405961539994 : ¬ IsSelfInterpreter e2405961539994 :=
  wSource (t := t_e2405961539994) (replay_sound (ps := []) (t := e2405961539994) (by decide)) (by decide)
def e2405962080282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405962080282 : Closed e2405962080282 ∧ code e2405962080282 = 11202055102490 := by decide
theorem cert_e2405962080282 : check e2405962080282 [[]] .width = true := by decide
def e2405962080374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405962080374 : Closed e2405962080374 ∧ code e2405962080374 = 11202055102582 := by decide
theorem cert_e2405962080374 : check e2405962080374 [[]] .width = true := by decide
def e2405962080618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405962080618 : Closed e2405962080618 ∧ code e2405962080618 = 11202055102826 := by decide
theorem cert_e2405962080618 : check e2405962080618 [[]] .width = true := by decide
def e2405962080666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405962080666 : Closed e2405962080666 ∧ code e2405962080666 = 11202055102874 := by decide
theorem cert_e2405962080666 : check e2405962080666 [[]] .width = true := by decide
def e2405962281158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405962281158 : Closed e2405962281158 ∧ code e2405962281158 = 11202055303366 := by decide
theorem cert_e2405962281158 : check e2405962281158 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405959658010
#print axioms Blc.Floor43.cert_e2405961538074
#print axioms Blc.Floor43.cert_e2405961539702
#print axioms Blc.Floor43.cert_e2405961539946
#print axioms Blc.Floor43.cert_e2405961539994
