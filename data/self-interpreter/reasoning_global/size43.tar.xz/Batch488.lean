import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407761134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422407761134 : Closed e2422407761134 ∧ code e2422407761134 = 11218500783342 := by decide
theorem cert_e2422407761134 : check e2422407761134 [[],[]] .smaller = true := by decide
def e2422407761142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422407761142 : Closed e2422407761142 ∧ code e2422407761142 = 11218500783350 := by decide
theorem cert_e2422407761142 : check e2422407761142 [[],[]] .smaller = true := by decide
def e2422407761518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422407761518 : Closed e2422407761518 ∧ code e2422407761518 = 11218500783726 := by decide
theorem cert_e2422407761518 : check e2422407761518 [[],[]] .smaller = true := by decide
def e2422407761530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422407761530 : Closed e2422407761530 ∧ code e2422407761530 = 11218500783738 := by decide
theorem cert_e2422407761530 : check e2422407761530 [[],[]] .smaller = true := by decide
def e2422407761718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422407761718 : Closed e2422407761718 ∧ code e2422407761718 = 11218500783926 := by decide
theorem cert_e2422407761718 : check e2422407761718 [[],[]] .smaller = true := by decide
def e2422407761722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422407761722 : Closed e2422407761722 ∧ code e2422407761722 = 11218500783930 := by decide
theorem cert_e2422407761722 : check e2422407761722 [[],[]] .smaller = true := by decide
def e2422407769838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2422407769838 : Closed e2422407769838 ∧ code e2422407769838 = 11218500792046 := by decide
theorem cert_e2422407769838 : check e2422407769838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407769966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2422407769966 : Closed e2422407769966 ∧ code e2422407769966 = 11218500792174 := by decide
theorem cert_e2422407769966 : check e2422407769966 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407769974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2422407769974 : Closed e2422407769974 ∧ code e2422407769974 = 11218500792182 := by decide
theorem cert_e2422407769974 : check e2422407769974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407772654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2422407772654 : Closed e2422407772654 ∧ code e2422407772654 = 11218500794862 := by decide
theorem cert_e2422407772654 : check e2422407772654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407773422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407773422 : Closed e2422407773422 ∧ code e2422407773422 = 11218500795630 := by decide
theorem cert_e2422407773422 : check e2422407773422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407773430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407773430 : Closed e2422407773430 ∧ code e2422407773430 = 11218500795638 := by decide
theorem cert_e2422407773430 : check e2422407773430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407796590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2422407796590 : Closed e2422407796590 ∧ code e2422407796590 = 11218500818798 := by decide
theorem cert_e2422407796590 : check e2422407796590 [[],[]] .chain = true := by decide
def e2422407796598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2422407796598 : Closed e2422407796598 ∧ code e2422407796598 = 11218500818806 := by decide
theorem cert_e2422407796598 : check e2422407796598 [[],[]] .chain = true := by decide
def e2422407796662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2422407796662 : Closed e2422407796662 ∧ code e2422407796662 = 11218500818870 := by decide
theorem cert_e2422407796662 : check e2422407796662 [[],[]] .chain = true := by decide
def e2422407797998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407797998 : Closed e2422407797998 ∧ code e2422407797998 = 11218500820206 := by decide
theorem cert_e2422407797998 : check e2422407797998 [[],[]] .chain = true := by decide
def e2422407798006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407798006 : Closed e2422407798006 ∧ code e2422407798006 = 11218500820214 := by decide
theorem cert_e2422407798006 : check e2422407798006 [[],[]] .chain = true := by decide
def e2422407798390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407798390 : Closed e2422407798390 ∧ code e2422407798390 = 11218500820598 := by decide
theorem cert_e2422407798390 : check e2422407798390 [[],[]] .chain = true := by decide
def e2422407807966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407807966 : Closed e2422407807966 ∧ code e2422407807966 = 11218500830174 := by decide
theorem cert_e2422407807966 : check e2422407807966 [[],[]] .chain = true := by decide
def e2422407807982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407807982 : Closed e2422407807982 ∧ code e2422407807982 = 11218500830190 := by decide
theorem cert_e2422407807982 : check e2422407807982 [[],[]] .chain = true := by decide
def e2422407809902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407809902 : Closed e2422407809902 ∧ code e2422407809902 = 11218500832110 := by decide
theorem cert_e2422407809902 : check e2422407809902 [[],[]] .chain = true := by decide
def e2422407809910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407809910 : Closed e2422407809910 ∧ code e2422407809910 = 11218500832118 := by decide
theorem cert_e2422407809910 : check e2422407809910 [[],[]] .chain = true := by decide
def e2422407809966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407809966 : Closed e2422407809966 ∧ code e2422407809966 = 11218500832174 := by decide
theorem cert_e2422407809966 : check e2422407809966 [[],[]] .chain = true := by decide
def e2422407809978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407809978 : Closed e2422407809978 ∧ code e2422407809978 = 11218500832186 := by decide
theorem cert_e2422407809978 : check e2422407809978 [[],[]] .chain = true := by decide
def e2422407810006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407810006 : Closed e2422407810006 ∧ code e2422407810006 = 11218500832214 := by decide
theorem cert_e2422407810006 : check e2422407810006 [[],[]] .chain = true := by decide
def e2422407810010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407810010 : Closed e2422407810010 ∧ code e2422407810010 = 11218500832218 := by decide
theorem cert_e2422407810010 : check e2422407810010 [[],[]] .chain = true := by decide
def e2422407810286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407810286 : Closed e2422407810286 ∧ code e2422407810286 = 11218500832494 := by decide
theorem cert_e2422407810286 : check e2422407810286 [[],[]] .chain = true := by decide
def e2422407810294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407810294 : Closed e2422407810294 ∧ code e2422407810294 = 11218500832502 := by decide
theorem cert_e2422407810294 : check e2422407810294 [[],[]] .chain = true := by decide
def e2422407810670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407810670 : Closed e2422407810670 ∧ code e2422407810670 = 11218500832878 := by decide
theorem cert_e2422407810670 : check e2422407810670 [[],[]] .chain = true := by decide
def e2422407810682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407810682 : Closed e2422407810682 ∧ code e2422407810682 = 11218500832890 := by decide
theorem cert_e2422407810682 : check e2422407810682 [[],[]] .chain = true := by decide
def e2422407810870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407810870 : Closed e2422407810870 ∧ code e2422407810870 = 11218500833078 := by decide
theorem cert_e2422407810870 : check e2422407810870 [[],[]] .chain = true := by decide
def e2422407810874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407810874 : Closed e2422407810874 ∧ code e2422407810874 = 11218500833082 := by decide
theorem cert_e2422407810874 : check e2422407810874 [[],[]] .chain = true := by decide
def e2422407815646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407815646 : Closed e2422407815646 ∧ code e2422407815646 = 11218500837854 := by decide
theorem cert_e2422407815646 : check e2422407815646 [[],[]] .chain = true := by decide
def e2422407815670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407815670 : Closed e2422407815670 ∧ code e2422407815670 = 11218500837878 := by decide
theorem cert_e2422407815670 : check e2422407815670 [[],[]] .chain = true := by decide
def e2422407816622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407816622 : Closed e2422407816622 ∧ code e2422407816622 = 11218500838830 := by decide
theorem cert_e2422407816622 : check e2422407816622 [[],[]] .chain = true := by decide
def e2422407816634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407816634 : Closed e2422407816634 ∧ code e2422407816634 = 11218500838842 := by decide
theorem cert_e2422407816634 : check e2422407816634 [[],[]] .chain = true := by decide
def e2422407816682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407816682 : Closed e2422407816682 ∧ code e2422407816682 = 11218500838890 := by decide
theorem cert_e2422407816682 : check e2422407816682 [[],[]] .chain = true := by decide
def e2422407816814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407816814 : Closed e2422407816814 ∧ code e2422407816814 = 11218500839022 := by decide
theorem cert_e2422407816814 : check e2422407816814 [[],[]] .chain = true := by decide
def e2422407816826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407816826 : Closed e2422407816826 ∧ code e2422407816826 = 11218500839034 := by decide
theorem cert_e2422407816826 : check e2422407816826 [[],[]] .chain = true := by decide
def e2422407816990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407816990 : Closed e2422407816990 ∧ code e2422407816990 = 11218500839198 := by decide
theorem cert_e2422407816990 : check e2422407816990 [[],[]] .chain = true := by decide
def e2422407817102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407817102 : Closed e2422407817102 ∧ code e2422407817102 = 11218500839310 := by decide
theorem cert_e2422407817102 : check e2422407817102 [[],[]] .chain = true := by decide
def e2422407817114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407817114 : Closed e2422407817114 ∧ code e2422407817114 = 11218500839322 := by decide
theorem cert_e2422407817114 : check e2422407817114 [[],[]] .chain = true := by decide
def e2422407819502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407819502 : Closed e2422407819502 ∧ code e2422407819502 = 11218500841710 := by decide
theorem cert_e2422407819502 : check e2422407819502 [[],[]] .chain = true := by decide
def e2422407819510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407819510 : Closed e2422407819510 ∧ code e2422407819510 = 11218500841718 := by decide
theorem cert_e2422407819510 : check e2422407819510 [[],[]] .chain = true := by decide
def e2422407819990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407819990 : Closed e2422407819990 ∧ code e2422407819990 = 11218500842198 := by decide
theorem cert_e2422407819990 : check e2422407819990 [[],[]] .chain = true := by decide
def e2422407819994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407819994 : Closed e2422407819994 ∧ code e2422407819994 = 11218500842202 := by decide
theorem cert_e2422407819994 : check e2422407819994 [[],[]] .chain = true := by decide
def e2422407820010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407820010 : Closed e2422407820010 ∧ code e2422407820010 = 11218500842218 := by decide
theorem cert_e2422407820010 : check e2422407820010 [[],[]] .chain = true := by decide
def e2422407820086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407820086 : Closed e2422407820086 ∧ code e2422407820086 = 11218500842294 := by decide
theorem cert_e2422407820086 : check e2422407820086 [[],[]] .chain = true := by decide
def e2422407820090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407820090 : Closed e2422407820090 ∧ code e2422407820090 = 11218500842298 := by decide
theorem cert_e2422407820090 : check e2422407820090 [[],[]] .chain = true := by decide
def e2422407820174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422407820174 : Closed e2422407820174 ∧ code e2422407820174 = 11218500842382 := by decide
theorem cert_e2422407820174 : check e2422407820174 [[],[]] .chain = true := by decide
def e2422407820186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407820186 : Closed e2422407820186 ∧ code e2422407820186 = 11218500842394 := by decide
theorem cert_e2422407820186 : check e2422407820186 [[],[]] .chain = true := by decide
def e2422407869882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2422407869882 : Closed e2422407869882 ∧ code e2422407869882 = 11218500892090 := by decide
theorem cert_e2422407869882 : check e2422407869882 [[],[]] .smaller = true := by decide
def e2422407869914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2422407869914 : Closed e2422407869914 ∧ code e2422407869914 = 11218500892122 := by decide
theorem cert_e2422407869914 : check e2422407869914 [[],[]] .smaller = true := by decide
def e2422407870138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2422407870138 : Closed e2422407870138 ∧ code e2422407870138 = 11218500892346 := by decide
theorem cert_e2422407870138 : check e2422407870138 [[],[]] .smaller = true := by decide
def e2422407870186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2422407870186 : Closed e2422407870186 ∧ code e2422407870186 = 11218500892394 := by decide
theorem cert_e2422407870186 : check e2422407870186 [[],[]] .smaller = true := by decide
def e2422407870298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2422407870298 : Closed e2422407870298 ∧ code e2422407870298 = 11218500892506 := by decide
theorem cert_e2422407870298 : check e2422407870298 [[],[]] .smaller = true := by decide
def e2422407870314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2422407870314 : Closed e2422407870314 ∧ code e2422407870314 = 11218500892522 := by decide
theorem cert_e2422407870314 : check e2422407870314 [[],[]] .smaller = true := by decide
def e2422407871162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2422407871162 : Closed e2422407871162 ∧ code e2422407871162 = 11218500893370 := by decide
theorem cert_e2422407871162 : check e2422407871162 [[],[]] .smaller = true := by decide
def e2422407871210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2422407871210 : Closed e2422407871210 ∧ code e2422407871210 = 11218500893418 := by decide
theorem cert_e2422407871210 : check e2422407871210 [[],[]] .smaller = true := by decide
def e2422407871402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e2422407871402 : Closed e2422407871402 ∧ code e2422407871402 = 11218500893610 := by decide
theorem cert_e2422407871402 : check e2422407871402 [[],[]] .smaller = true := by decide
def e2422407871834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2422407871834 : Closed e2422407871834 ∧ code e2422407871834 = 11218500894042 := by decide
theorem cert_e2422407871834 : check e2422407871834 [[],[]] .smaller = true := by decide
def e2422407871850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2422407871850 : Closed e2422407871850 ∧ code e2422407871850 = 11218500894058 := by decide
theorem cert_e2422407871850 : check e2422407871850 [[],[]] .smaller = true := by decide
def e2422407871914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e2422407871914 : Closed e2422407871914 ∧ code e2422407871914 = 11218500894122 := by decide
theorem cert_e2422407871914 : check e2422407871914 [[],[]] .smaller = true := by decide
def e2422407874286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))) (.var 2))))))
theorem wire_e2422407874286 : Closed e2422407874286 ∧ code e2422407874286 = 11218500896494 := by decide
theorem cert_e2422407874286 : check e2422407874286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407874294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 3)))) (.var 1))))))
theorem wire_e2422407874294 : Closed e2422407874294 ∧ code e2422407874294 = 11218500896502 := by decide
theorem cert_e2422407874294 : check e2422407874294 [[],[]] .chain = true := by decide
def e2422407874422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 1))))))
theorem wire_e2422407874422 : Closed e2422407874422 ∧ code e2422407874422 = 11218500896630 := by decide
theorem cert_e2422407874422 : check e2422407874422 [[],[]] .smaller = true := by decide
def e2422407874426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))) (.var 0))))))
theorem wire_e2422407874426 : Closed e2422407874426 ∧ code e2422407874426 = 11218500896634 := by decide
theorem cert_e2422407874426 : check e2422407874426 [[],[]] .chain = true := by decide
def e2422407874478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))) (.var 2))))))
theorem wire_e2422407874478 : Closed e2422407874478 ∧ code e2422407874478 = 11218500896686 := by decide
theorem cert_e2422407874478 : check e2422407874478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407874486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 1))))))
theorem wire_e2422407874486 : Closed e2422407874486 ∧ code e2422407874486 = 11218500896694 := by decide
theorem cert_e2422407874486 : check e2422407874486 [[],[]] .smaller = true := by decide
def e2422407874518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 0)))) (.var 1))))))
theorem wire_e2422407874518 : Closed e2422407874518 ∧ code e2422407874518 = 11218500896726 := by decide
theorem cert_e2422407874518 : check e2422407874518 [[],[]] .chain = true := by decide
def e2422407874522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))) (.var 0))))))
theorem wire_e2422407874522 : Closed e2422407874522 ∧ code e2422407874522 = 11218500896730 := by decide
theorem cert_e2422407874522 : check e2422407874522 [[],[]] .chain = true := by decide
def e2422407876026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.var 0))))))
theorem wire_e2422407876026 : Closed e2422407876026 ∧ code e2422407876026 = 11218500898234 := by decide
theorem cert_e2422407876026 : check e2422407876026 [[],[]] .smaller = true := by decide
def e2422407876058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0))))))
theorem wire_e2422407876058 : Closed e2422407876058 ∧ code e2422407876058 = 11218500898266 := by decide
theorem cert_e2422407876058 : check e2422407876058 [[],[]] .smaller = true := by decide
def e2422407876282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.var 0))))))
theorem wire_e2422407876282 : Closed e2422407876282 ∧ code e2422407876282 = 11218500898490 := by decide
theorem cert_e2422407876282 : check e2422407876282 [[],[]] .smaller = true := by decide
def e2422407876330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.var 0))))))
theorem wire_e2422407876330 : Closed e2422407876330 ∧ code e2422407876330 = 11218500898538 := by decide
theorem cert_e2422407876330 : check e2422407876330 [[],[]] .smaller = true := by decide
def e2422407876442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 0))))))
theorem wire_e2422407876442 : Closed e2422407876442 ∧ code e2422407876442 = 11218500898650 := by decide
theorem cert_e2422407876442 : check e2422407876442 [[],[]] .smaller = true := by decide
def e2422407876458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.var 0))))))
theorem wire_e2422407876458 : Closed e2422407876458 ∧ code e2422407876458 = 11218500898666 := by decide
theorem cert_e2422407876458 : check e2422407876458 [[],[]] .smaller = true := by decide
def e2422407877102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))) (.var 2))))))
theorem wire_e2422407877102 : Closed e2422407877102 ∧ code e2422407877102 = 11218500899310 := by decide
theorem cert_e2422407877102 : check e2422407877102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407877110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4))))) (.var 1))))))
theorem wire_e2422407877110 : Closed e2422407877110 ∧ code e2422407877110 = 11218500899318 := by decide
theorem cert_e2422407877110 : check e2422407877110 [[],[]] .chain = true := by decide
def e2422407877562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2422407877562 : Closed e2422407877562 ∧ code e2422407877562 = 11218500899770 := by decide
theorem cert_e2422407877562 : check e2422407877562 [[],[]] .smaller = true := by decide
def e2422407877594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2422407877594 : Closed e2422407877594 ∧ code e2422407877594 = 11218500899802 := by decide
theorem cert_e2422407877594 : check e2422407877594 [[],[]] .smaller = true := by decide
def e2422407877870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407877870 : Closed e2422407877870 ∧ code e2422407877870 = 11218500900078 := by decide
theorem cert_e2422407877870 : check e2422407877870 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407877878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407877878 : Closed e2422407877878 ∧ code e2422407877878 = 11218500900086 := by decide
theorem cert_e2422407877878 : check e2422407877878 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407878430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2422407878430 : Closed e2422407878430 ∧ code e2422407878430 = 11218500900638 := by decide
theorem cert_e2422407878430 : check e2422407878430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407878542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2422407878542 : Closed e2422407878542 ∧ code e2422407878542 = 11218500900750 := by decide
theorem cert_e2422407878542 : check e2422407878542 [[],[]] .chain = true := by decide
def e2422407878902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 1))))))
theorem wire_e2422407878902 : Closed e2422407878902 ∧ code e2422407878902 = 11218500901110 := by decide
theorem cert_e2422407878902 : check e2422407878902 [[],[]] .smaller = true := by decide
def e2422407878906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407878906 : Closed e2422407878906 ∧ code e2422407878906 = 11218500901114 := by decide
theorem cert_e2422407878906 : check e2422407878906 [[],[]] .chain = true := by decide
def e2422407879098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2422407879098 : Closed e2422407879098 ∧ code e2422407879098 = 11218500901306 := by decide
theorem cert_e2422407879098 : check e2422407879098 [[],[]] .smaller = true := by decide
def e2422407879146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2422407879146 : Closed e2422407879146 ∧ code e2422407879146 = 11218500901354 := by decide
theorem cert_e2422407879146 : check e2422407879146 [[],[]] .smaller = true := by decide
def e2422407879554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407879554 : Closed e2422407879554 ∧ code e2422407879554 = 11218500901762 := by decide
theorem cert_e2422407879554 : check e2422407879554 [[],[]] .smaller = true := by decide
def e2422407879566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2422407879566 : Closed e2422407879566 ∧ code e2422407879566 = 11218500901774 := by decide
theorem cert_e2422407879566 : check e2422407879566 [[],[]] .smaller = true := by decide
def e2422407879578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407879578 : Closed e2422407879578 ∧ code e2422407879578 = 11218500901786 := by decide
theorem cert_e2422407879578 : check e2422407879578 [[],[]] .smaller = true := by decide
def e2422407879622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407879622 : Closed e2422407879622 ∧ code e2422407879622 = 11218500901830 := by decide
theorem cert_e2422407879622 : check e2422407879622 [[],[]] .chain = true := by decide
def e2422407879790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422407879790 : Closed e2422407879790 ∧ code e2422407879790 = 11218500901998 := by decide
theorem cert_e2422407879790 : checkPay e2422407879790 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422407879798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422407879798 : Closed e2422407879798 ∧ code e2422407879798 = 11218500902006 := by decide
theorem cert_e2422407879798 : check e2422407879798 [[],[]] .smaller = true := by decide
def e2422407879898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2422407879898 : Closed e2422407879898 ∧ code e2422407879898 = 11218500902106 := by decide
theorem cert_e2422407879898 : check e2422407879898 [[],[]] .smaller = true := by decide
def e2422407879914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2422407879914 : Closed e2422407879914 ∧ code e2422407879914 = 11218500902122 := by decide
theorem cert_e2422407879914 : check e2422407879914 [[],[]] .smaller = true := by decide
def e2422407879966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422407879966 : Closed e2422407879966 ∧ code e2422407879966 = 11218500902174 := by decide
theorem cert_e2422407879966 : checkPay e2422407879966 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422407880066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407880066 : Closed e2422407880066 ∧ code e2422407880066 = 11218500902274 := by decide
theorem cert_e2422407880066 : check e2422407880066 [[],[]] .smaller = true := by decide
def e2422407880078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422407880078 : Closed e2422407880078 ∧ code e2422407880078 = 11218500902286 := by decide
theorem cert_e2422407880078 : check e2422407880078 [[],[]] .smaller = true := by decide
def e2422407880090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407880090 : Closed e2422407880090 ∧ code e2422407880090 = 11218500902298 := by decide
theorem cert_e2422407880090 : check e2422407880090 [[],[]] .smaller = true := by decide
def e2422407880174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))) (.var 2))))))
theorem wire_e2422407880174 : Closed e2422407880174 ∧ code e2422407880174 = 11218500902382 := by decide
theorem cert_e2422407880174 : checkPay e2422407880174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422407880246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407880246 : Closed e2422407880246 ∧ code e2422407880246 = 11218500902454 := by decide
theorem cert_e2422407880246 : check e2422407880246 [[],[]] .chain = true := by decide
def e2422407880250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407880250 : Closed e2422407880250 ∧ code e2422407880250 = 11218500902458 := by decide
theorem cert_e2422407880250 : check e2422407880250 [[],[]] .chain = true := by decide
def e2422407880334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407880334 : Closed e2422407880334 ∧ code e2422407880334 = 11218500902542 := by decide
theorem cert_e2422407880334 : check e2422407880334 [[],[]] .chain = true := by decide
def e2422407880390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407880390 : Closed e2422407880390 ∧ code e2422407880390 = 11218500902598 := by decide
theorem cert_e2422407880390 : check e2422407880390 [[],[]] .chain = true := by decide
def e2422407880430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))) (.var 2))))))
theorem wire_e2422407880430 : Closed e2422407880430 ∧ code e2422407880430 = 11218500902638 := by decide
theorem cert_e2422407880430 : check e2422407880430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407880438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 3)))) (.var 1))))))
theorem wire_e2422407880438 : Closed e2422407880438 ∧ code e2422407880438 = 11218500902646 := by decide
theorem cert_e2422407880438 : check e2422407880438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407881454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))) (.var 2))))))
theorem wire_e2422407881454 : Closed e2422407881454 ∧ code e2422407881454 = 11218500903662 := by decide
theorem cert_e2422407881454 : check e2422407881454 [[],[]] .chain = true := by decide
def e2422407881462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 3)))) (.var 1))))))
theorem wire_e2422407881462 : Closed e2422407881462 ∧ code e2422407881462 = 11218500903670 := by decide
theorem cert_e2422407881462 : check e2422407881462 [[],[]] .chain = true := by decide
def e2422407881590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 1))))))
theorem wire_e2422407881590 : Closed e2422407881590 ∧ code e2422407881590 = 11218500903798 := by decide
theorem cert_e2422407881590 : check e2422407881590 [[],[]] .smaller = true := by decide
def e2422407881594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))) (.var 0))))))
theorem wire_e2422407881594 : Closed e2422407881594 ∧ code e2422407881594 = 11218500903802 := by decide
theorem cert_e2422407881594 : check e2422407881594 [[],[]] .chain = true := by decide
def e2422407881686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 1))))))
theorem wire_e2422407881686 : Closed e2422407881686 ∧ code e2422407881686 = 11218500903894 := by decide
theorem cert_e2422407881686 : check e2422407881686 [[],[]] .smaller = true := by decide
def e2422407881706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))) (.var 0))))))
theorem wire_e2422407881706 : Closed e2422407881706 ∧ code e2422407881706 = 11218500903914 := by decide
theorem cert_e2422407881706 : check e2422407881706 [[],[]] .chain = true := by decide
def e2422407882426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.var 0))))))
theorem wire_e2422407882426 : Closed e2422407882426 ∧ code e2422407882426 = 11218500904634 := by decide
theorem cert_e2422407882426 : check e2422407882426 [[],[]] .smaller = true := by decide
def e2422407882474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.var 0))))))
theorem wire_e2422407882474 : Closed e2422407882474 ∧ code e2422407882474 = 11218500904682 := by decide
theorem cert_e2422407882474 : check e2422407882474 [[],[]] .smaller = true := by decide
def e2422407882666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.var 0))))))
theorem wire_e2422407882666 : Closed e2422407882666 ∧ code e2422407882666 = 11218500904874 := by decide
theorem cert_e2422407882666 : check e2422407882666 [[],[]] .smaller = true := by decide
def e2422407882998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 1))))))
theorem wire_e2422407882998 : Closed e2422407882998 ∧ code e2422407882998 = 11218500905206 := by decide
theorem cert_e2422407882998 : check e2422407882998 [[],[]] .smaller = true := by decide
def e2422407883002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407883002 : Closed e2422407883002 ∧ code e2422407883002 = 11218500905210 := by decide
theorem cert_e2422407883002 : check e2422407883002 [[],[]] .chain = true := by decide
def e2422407883194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2422407883194 : Closed e2422407883194 ∧ code e2422407883194 = 11218500905402 := by decide
theorem cert_e2422407883194 : check e2422407883194 [[],[]] .smaller = true := by decide
def e2422407883242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2422407883242 : Closed e2422407883242 ∧ code e2422407883242 = 11218500905450 := by decide
theorem cert_e2422407883242 : check e2422407883242 [[],[]] .smaller = true := by decide
def e2422407883650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407883650 : Closed e2422407883650 ∧ code e2422407883650 = 11218500905858 := by decide
theorem cert_e2422407883650 : check e2422407883650 [[],[]] .smaller = true := by decide
def e2422407883662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2422407883662 : Closed e2422407883662 ∧ code e2422407883662 = 11218500905870 := by decide
theorem cert_e2422407883662 : check e2422407883662 [[],[]] .smaller = true := by decide
def e2422407883674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407883674 : Closed e2422407883674 ∧ code e2422407883674 = 11218500905882 := by decide
theorem cert_e2422407883674 : check e2422407883674 [[],[]] .smaller = true := by decide
def e2422407883718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407883718 : Closed e2422407883718 ∧ code e2422407883718 = 11218500905926 := by decide
theorem cert_e2422407883718 : check e2422407883718 [[],[]] .chain = true := by decide
def e2422407884334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407884334 : Closed e2422407884334 ∧ code e2422407884334 = 11218500906542 := by decide
theorem cert_e2422407884334 : check e2422407884334 [[],[]] .chain = true := by decide
def e2422407884342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407884342 : Closed e2422407884342 ∧ code e2422407884342 = 11218500906550 := by decide
theorem cert_e2422407884342 : check e2422407884342 [[],[]] .smaller = true := by decide
def e2422407884394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407884394 : Closed e2422407884394 ∧ code e2422407884394 = 11218500906602 := by decide
theorem cert_e2422407884394 : check e2422407884394 [[],[]] .smaller = true := by decide
def e2422407884418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407884418 : Closed e2422407884418 ∧ code e2422407884418 = 11218500906626 := by decide
theorem cert_e2422407884418 : check e2422407884418 [[],[]] .smaller = true := by decide
def e2422407884430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407884430 : Closed e2422407884430 ∧ code e2422407884430 = 11218500906638 := by decide
theorem cert_e2422407884430 : check e2422407884430 [[],[]] .smaller = true := by decide
def e2422407884442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407884442 : Closed e2422407884442 ∧ code e2422407884442 = 11218500906650 := by decide
theorem cert_e2422407884442 : check e2422407884442 [[],[]] .smaller = true := by decide
def e2422407884526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 2)))) (.var 2))))))
theorem wire_e2422407884526 : Closed e2422407884526 ∧ code e2422407884526 = 11218500906734 := by decide
theorem cert_e2422407884526 : check e2422407884526 [[],[]] .chain = true := by decide
def e2422407884534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))) (.var 1))))))
theorem wire_e2422407884534 : Closed e2422407884534 ∧ code e2422407884534 = 11218500906742 := by decide
theorem cert_e2422407884534 : check e2422407884534 [[],[]] .chain = true := by decide
def e2422407884566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407884566 : Closed e2422407884566 ∧ code e2422407884566 = 11218500906774 := by decide
theorem cert_e2422407884566 : check e2422407884566 [[],[]] .chain = true := by decide
def e2422407884570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407884570 : Closed e2422407884570 ∧ code e2422407884570 = 11218500906778 := by decide
theorem cert_e2422407884570 : check e2422407884570 [[],[]] .chain = true := by decide
def e2422407884614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407884614 : Closed e2422407884614 ∧ code e2422407884614 = 11218500906822 := by decide
theorem cert_e2422407884614 : check e2422407884614 [[],[]] .chain = true := by decide
def e2422407884662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))) (.var 1))))))
theorem wire_e2422407884662 : Closed e2422407884662 ∧ code e2422407884662 = 11218500906870 := by decide
theorem cert_e2422407884662 : check e2422407884662 [[],[]] .chain = true := by decide
def e2422407885166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))) (.var 2))))))
theorem wire_e2422407885166 : Closed e2422407885166 ∧ code e2422407885166 = 11218500907374 := by decide
theorem cert_e2422407885166 : check e2422407885166 [[],[]] .chain = true := by decide
def e2422407885178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.var 3)))) (.var 0))))))
theorem wire_e2422407885178 : Closed e2422407885178 ∧ code e2422407885178 = 11218500907386 := by decide
theorem cert_e2422407885178 : check e2422407885178 [[],[]] .chain = true := by decide
def e2422407885230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))) (.var 2))))))
theorem wire_e2422407885230 : Closed e2422407885230 ∧ code e2422407885230 = 11218500907438 := by decide
theorem cert_e2422407885230 : check e2422407885230 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407885238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 1))))))
theorem wire_e2422407885238 : Closed e2422407885238 ∧ code e2422407885238 = 11218500907446 := by decide
theorem cert_e2422407885238 : check e2422407885238 [[],[]] .smaller = true := by decide
def e2422407885270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 1))))))
theorem wire_e2422407885270 : Closed e2422407885270 ∧ code e2422407885270 = 11218500907478 := by decide
theorem cert_e2422407885270 : check e2422407885270 [[],[]] .smaller = true := by decide
def e2422407885658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 0))))))
theorem wire_e2422407885658 : Closed e2422407885658 ∧ code e2422407885658 = 11218500907866 := by decide
theorem cert_e2422407885658 : check e2422407885658 [[],[]] .smaller = true := by decide
def e2422407885674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.var 0))))))
theorem wire_e2422407885674 : Closed e2422407885674 ∧ code e2422407885674 = 11218500907882 := by decide
theorem cert_e2422407885674 : check e2422407885674 [[],[]] .smaller = true := by decide
def e2422407885738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.var 0))))))
theorem wire_e2422407885738 : Closed e2422407885738 ∧ code e2422407885738 = 11218500907946 := by decide
theorem cert_e2422407885738 : check e2422407885738 [[],[]] .smaller = true := by decide
def e2422407885934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422407885934 : Closed e2422407885934 ∧ code e2422407885934 = 11218500908142 := by decide
theorem cert_e2422407885934 : check e2422407885934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407885942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422407885942 : Closed e2422407885942 ∧ code e2422407885942 = 11218500908150 := by decide
theorem cert_e2422407885942 : check e2422407885942 [[],[]] .smaller = true := by decide
def e2422407886042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2422407886042 : Closed e2422407886042 ∧ code e2422407886042 = 11218500908250 := by decide
theorem cert_e2422407886042 : check e2422407886042 [[],[]] .smaller = true := by decide
def e2422407886058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2422407886058 : Closed e2422407886058 ∧ code e2422407886058 = 11218500908266 := by decide
theorem cert_e2422407886058 : check e2422407886058 [[],[]] .smaller = true := by decide
def e2422407886110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422407886110 : Closed e2422407886110 ∧ code e2422407886110 = 11218500908318 := by decide
theorem cert_e2422407886110 : check e2422407886110 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407886210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407886210 : Closed e2422407886210 ∧ code e2422407886210 = 11218500908418 := by decide
theorem cert_e2422407886210 : check e2422407886210 [[],[]] .smaller = true := by decide
def e2422407886222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422407886222 : Closed e2422407886222 ∧ code e2422407886222 = 11218500908430 := by decide
theorem cert_e2422407886222 : check e2422407886222 [[],[]] .smaller = true := by decide
def e2422407886234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407886234 : Closed e2422407886234 ∧ code e2422407886234 = 11218500908442 := by decide
theorem cert_e2422407886234 : check e2422407886234 [[],[]] .smaller = true := by decide
def e2422407886318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))) (.var 2))))))
theorem wire_e2422407886318 : Closed e2422407886318 ∧ code e2422407886318 = 11218500908526 := by decide
theorem cert_e2422407886318 : check e2422407886318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407886382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407886382 : Closed e2422407886382 ∧ code e2422407886382 = 11218500908590 := by decide
theorem cert_e2422407886382 : check e2422407886382 [[],[]] .chain = true := by decide
def e2422407886390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407886390 : Closed e2422407886390 ∧ code e2422407886390 = 11218500908598 := by decide
theorem cert_e2422407886390 : check e2422407886390 [[],[]] .smaller = true := by decide
def e2422407886442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407886442 : Closed e2422407886442 ∧ code e2422407886442 = 11218500908650 := by decide
theorem cert_e2422407886442 : check e2422407886442 [[],[]] .smaller = true := by decide
def e2422407886466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407886466 : Closed e2422407886466 ∧ code e2422407886466 = 11218500908674 := by decide
theorem cert_e2422407886466 : check e2422407886466 [[],[]] .smaller = true := by decide
def e2422407886478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407886478 : Closed e2422407886478 ∧ code e2422407886478 = 11218500908686 := by decide
theorem cert_e2422407886478 : check e2422407886478 [[],[]] .smaller = true := by decide
def e2422407886490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407886490 : Closed e2422407886490 ∧ code e2422407886490 = 11218500908698 := by decide
theorem cert_e2422407886490 : check e2422407886490 [[],[]] .smaller = true := by decide
end Blc.Floor43
