import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2408990903534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408990903534 : Closed e2408990903534 ∧ code e2408990903534 = 11205083925742 := by decide
theorem cert_e2408990903534 : check e2408990903534 [[],[],[],[],[]] .chain = true := by decide
def e2408990903542 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408990903542 : Closed e2408990903542 ∧ code e2408990903542 = 11205083925750 := by decide
theorem cert_e2408990903542 : check e2408990903542 [[],[],[],[],[]] .chain = true := by decide
def e2408990903918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408990903918 : Closed e2408990903918 ∧ code e2408990903918 = 11205083926126 := by decide
theorem cert_e2408990903918 : check e2408990903918 [[],[],[],[],[]] .chain = true := by decide
def e2408990903930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408990903930 : Closed e2408990903930 ∧ code e2408990903930 = 11205083926138 := by decide
theorem cert_e2408990903930 : check e2408990903930 [[],[],[],[],[]] .chain = true := by decide
def e2408990904118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408990904118 : Closed e2408990904118 ∧ code e2408990904118 = 11205083926326 := by decide
theorem cert_e2408990904118 : check e2408990904118 [[],[],[],[],[]] .chain = true := by decide
def e2408990904122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408990904122 : Closed e2408990904122 ∧ code e2408990904122 = 11205083926330 := by decide
theorem cert_e2408990904122 : check e2408990904122 [[],[],[],[],[]] .chain = true := by decide
def e2409057971738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409057971738 : Closed e2409057971738 ∧ code e2409057971738 = 11205150993946 := by decide
private def t_e2409057971738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409057971738 : ¬ IsSelfInterpreter e2409057971738 :=
  wSource (t := t_e2409057971738) (replay_sound (ps := []) (t := e2409057971738) (by decide)) (by decide)
def e2409057973786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409057973786 : Closed e2409057973786 ∧ code e2409057973786 = 11205150995994 := by decide
private def t_e2409057973786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409057973786 : ¬ IsSelfInterpreter e2409057973786 :=
  wSource (t := t_e2409057973786) (replay_sound (ps := []) (t := e2409057973786) (by decide)) (by decide)
def e2409057988122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409057988122 : Closed e2409057988122 ∧ code e2409057988122 = 11205151010330 := by decide
private def t_e2409057988122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409057988122 : ¬ IsSelfInterpreter e2409057988122 :=
  wSource (t := t_e2409057988122) (replay_sound (ps := []) (t := e2409057988122) (by decide)) (by decide)
def e2409057991194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409057991194 : Closed e2409057991194 ∧ code e2409057991194 = 11205151013402 := by decide
private def t_e2409057991194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409057991194 : ¬ IsSelfInterpreter e2409057991194 :=
  wSource (t := t_e2409057991194) (replay_sound (ps := []) (t := e2409057991194) (by decide)) (by decide)
def e2409057998362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409057998362 : Closed e2409057998362 ∧ code e2409057998362 = 11205151020570 := by decide
private def t_e2409057998362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409057998362 : ¬ IsSelfInterpreter e2409057998362 :=
  wSource (t := t_e2409057998362) (replay_sound (ps := []) (t := e2409057998362) (by decide)) (by decide)
def e2409057999386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409057999386 : Closed e2409057999386 ∧ code e2409057999386 = 11205151021594 := by decide
private def t_e2409057999386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409057999386 : ¬ IsSelfInterpreter e2409057999386 :=
  wSource (t := t_e2409057999386) (replay_sound (ps := []) (t := e2409057999386) (by decide)) (by decide)
def e2409058070042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409058070042 : Closed e2409058070042 ∧ code e2409058070042 = 11205151092250 := by decide
private def t_e2409058070042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409058070042 : ¬ IsSelfInterpreter e2409058070042 :=
  wSource (t := t_e2409058070042) (replay_sound (ps := []) (t := e2409058070042) (by decide)) (by decide)
def e2409058072090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409058072090 : Closed e2409058072090 ∧ code e2409058072090 = 11205151094298 := by decide
private def t_e2409058072090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409058072090 : ¬ IsSelfInterpreter e2409058072090 :=
  wSource (t := t_e2409058072090) (replay_sound (ps := []) (t := e2409058072090) (by decide)) (by decide)
def e2409058168346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409058168346 : Closed e2409058168346 ∧ code e2409058168346 = 11205151190554 := by decide
private def t_e2409058168346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409058168346 : ¬ IsSelfInterpreter e2409058168346 :=
  wSource (t := t_e2409058168346) (replay_sound (ps := []) (t := e2409058168346) (by decide)) (by decide)
def e2409058171418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409058171418 : Closed e2409058171418 ∧ code e2409058171418 = 11205151193626 := by decide
private def t_e2409058171418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409058171418 : ¬ IsSelfInterpreter e2409058171418 :=
  wSource (t := t_e2409058171418) (replay_sound (ps := []) (t := e2409058171418) (by decide)) (by decide)
def e2409058219546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409058219546 : Closed e2409058219546 ∧ code e2409058219546 = 11205151241754 := by decide
private def t_e2409058219546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409058219546 : ¬ IsSelfInterpreter e2409058219546 :=
  wSource (t := t_e2409058219546) (replay_sound (ps := []) (t := e2409058219546) (by decide)) (by decide)
def e2409058220570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2409058220570 : Closed e2409058220570 ∧ code e2409058220570 = 11205151242778 := by decide
private def t_e2409058220570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2409058220570 : ¬ IsSelfInterpreter e2409058220570 :=
  wSource (t := t_e2409058220570) (replay_sound (ps := []) (t := e2409058220570) (by decide)) (by decide)
def e2409074088670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2409074088670 : Closed e2409074088670 ∧ code e2409074088670 = 11205167110878 := by decide
theorem cert_e2409074088670 : check e2409074088670 [[],[]] .three = true := by decide
def e2409074088694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2409074088694 : Closed e2409074088694 ∧ code e2409074088694 = 11205167110902 := by decide
theorem cert_e2409074088694 : check e2409074088694 [[],[]] .three = true := by decide
def e2409074088798 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2409074088798 : Closed e2409074088798 ∧ code e2409074088798 = 11205167111006 := by decide
theorem cert_e2409074088798 : check e2409074088798 [[],[]] .three = true := by decide
def e2409074088814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2409074088814 : Closed e2409074088814 ∧ code e2409074088814 = 11205167111022 := by decide
theorem cert_e2409074088814 : check e2409074088814 [[],[]] .smaller = true := by decide
def e2409074088822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2409074088822 : Closed e2409074088822 ∧ code e2409074088822 = 11205167111030 := by decide
theorem cert_e2409074088822 : check e2409074088822 [[],[]] .smaller = true := by decide
def e2409074088826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2409074088826 : Closed e2409074088826 ∧ code e2409074088826 = 11205167111034 := by decide
theorem cert_e2409074088826 : check e2409074088826 [[],[]] .three = true := by decide
def e2409074088886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2409074088886 : Closed e2409074088886 ∧ code e2409074088886 = 11205167111094 := by decide
theorem cert_e2409074088886 : check e2409074088886 [[],[]] .smaller = true := by decide
def e2409074088918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2409074088918 : Closed e2409074088918 ∧ code e2409074088918 = 11205167111126 := by decide
theorem cert_e2409074088918 : check e2409074088918 [[],[]] .three = true := by decide
def e2409074088922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2409074088922 : Closed e2409074088922 ∧ code e2409074088922 = 11205167111130 := by decide
theorem cert_e2409074088922 : check e2409074088922 [[],[]] .three = true := by decide
def e2409074089310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2409074089310 : Closed e2409074089310 ∧ code e2409074089310 = 11205167111518 := by decide
theorem cert_e2409074089310 : check e2409074089310 [[],[]] .three = true := by decide
def e2409074089326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2409074089326 : Closed e2409074089326 ∧ code e2409074089326 = 11205167111534 := by decide
theorem cert_e2409074089326 : check e2409074089326 [[],[]] .smaller = true := by decide
def e2409074089334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2409074089334 : Closed e2409074089334 ∧ code e2409074089334 = 11205167111542 := by decide
theorem cert_e2409074089334 : check e2409074089334 [[],[]] .smaller = true := by decide
def e2409074089338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2409074089338 : Closed e2409074089338 ∧ code e2409074089338 = 11205167111546 := by decide
theorem cert_e2409074089338 : check e2409074089338 [[],[]] .three = true := by decide
def e2409074089390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2409074089390 : Closed e2409074089390 ∧ code e2409074089390 = 11205167111598 := by decide
theorem cert_e2409074089390 : check e2409074089390 [[],[]] .smaller = true := by decide
def e2409074089402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2409074089402 : Closed e2409074089402 ∧ code e2409074089402 = 11205167111610 := by decide
theorem cert_e2409074089402 : check e2409074089402 [[],[]] .smaller = true := by decide
def e2409074089430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2409074089430 : Closed e2409074089430 ∧ code e2409074089430 = 11205167111638 := by decide
theorem cert_e2409074089430 : check e2409074089430 [[],[]] .smaller = true := by decide
def e2409074089434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2409074089434 : Closed e2409074089434 ∧ code e2409074089434 = 11205167111642 := by decide
theorem cert_e2409074089434 : check e2409074089434 [[],[]] .smaller = true := by decide
def e2409074089450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2409074089450 : Closed e2409074089450 ∧ code e2409074089450 = 11205167111658 := by decide
theorem cert_e2409074089450 : check e2409074089450 [[],[]] .three = true := by decide
def e2409074089654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2409074089654 : Closed e2409074089654 ∧ code e2409074089654 = 11205167111862 := by decide
theorem cert_e2409074089654 : check e2409074089654 [[],[]] .smaller = true := by decide
def e2409074089686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2409074089686 : Closed e2409074089686 ∧ code e2409074089686 = 11205167111894 := by decide
theorem cert_e2409074089686 : check e2409074089686 [[],[]] .smaller = true := by decide
def e2409074089690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2409074089690 : Closed e2409074089690 ∧ code e2409074089690 = 11205167111898 := by decide
theorem cert_e2409074089690 : check e2409074089690 [[],[]] .smaller = true := by decide
def e2409074089814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2409074089814 : Closed e2409074089814 ∧ code e2409074089814 = 11205167112022 := by decide
theorem cert_e2409074089814 : check e2409074089814 [[],[]] .three = true := by decide
def e2409074089818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2409074089818 : Closed e2409074089818 ∧ code e2409074089818 = 11205167112026 := by decide
theorem cert_e2409074089818 : check e2409074089818 [[],[]] .three = true := by decide
def e2409074089834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2409074089834 : Closed e2409074089834 ∧ code e2409074089834 = 11205167112042 := by decide
theorem cert_e2409074089834 : check e2409074089834 [[],[]] .three = true := by decide
def e2409074091742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2409074091742 : Closed e2409074091742 ∧ code e2409074091742 = 11205167113950 := by decide
theorem cert_e2409074091742 : check e2409074091742 [[],[]] .three = true := by decide
def e2409074091766 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2409074091766 : Closed e2409074091766 ∧ code e2409074091766 = 11205167113974 := by decide
theorem cert_e2409074091766 : check e2409074091766 [[],[]] .three = true := by decide
def e2409074091870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2409074091870 : Closed e2409074091870 ∧ code e2409074091870 = 11205167114078 := by decide
theorem cert_e2409074091870 : check e2409074091870 [[],[]] .three = true := by decide
def e2409074091886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2409074091886 : Closed e2409074091886 ∧ code e2409074091886 = 11205167114094 := by decide
theorem cert_e2409074091886 : check e2409074091886 [[],[]] .smaller = true := by decide
def e2409074091894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2409074091894 : Closed e2409074091894 ∧ code e2409074091894 = 11205167114102 := by decide
theorem cert_e2409074091894 : check e2409074091894 [[],[]] .smaller = true := by decide
def e2409074091898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2409074091898 : Closed e2409074091898 ∧ code e2409074091898 = 11205167114106 := by decide
theorem cert_e2409074091898 : check e2409074091898 [[],[]] .three = true := by decide
def e2409074091958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2409074091958 : Closed e2409074091958 ∧ code e2409074091958 = 11205167114166 := by decide
theorem cert_e2409074091958 : check e2409074091958 [[],[]] .smaller = true := by decide
def e2409074091990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2409074091990 : Closed e2409074091990 ∧ code e2409074091990 = 11205167114198 := by decide
theorem cert_e2409074091990 : check e2409074091990 [[],[]] .three = true := by decide
def e2409074091994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2409074091994 : Closed e2409074091994 ∧ code e2409074091994 = 11205167114202 := by decide
theorem cert_e2409074091994 : check e2409074091994 [[],[]] .three = true := by decide
def e2409074092510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2409074092510 : Closed e2409074092510 ∧ code e2409074092510 = 11205167114718 := by decide
theorem cert_e2409074092510 : check e2409074092510 [[],[]] .three = true := by decide
def e2409074092534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2409074092534 : Closed e2409074092534 ∧ code e2409074092534 = 11205167114742 := by decide
theorem cert_e2409074092534 : check e2409074092534 [[],[]] .three = true := by decide
def e2409074093278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2409074093278 : Closed e2409074093278 ∧ code e2409074093278 = 11205167115486 := by decide
theorem cert_e2409074093278 : check e2409074093278 [[],[]] .three = true := by decide
def e2409074093294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2409074093294 : Closed e2409074093294 ∧ code e2409074093294 = 11205167115502 := by decide
theorem cert_e2409074093294 : check e2409074093294 [[],[]] .smaller = true := by decide
def e2409074093302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2409074093302 : Closed e2409074093302 ∧ code e2409074093302 = 11205167115510 := by decide
theorem cert_e2409074093302 : check e2409074093302 [[],[]] .smaller = true := by decide
def e2409074093306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2409074093306 : Closed e2409074093306 ∧ code e2409074093306 = 11205167115514 := by decide
theorem cert_e2409074093306 : check e2409074093306 [[],[]] .three = true := by decide
def e2409074093686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2409074093686 : Closed e2409074093686 ∧ code e2409074093686 = 11205167115894 := by decide
theorem cert_e2409074093686 : check e2409074093686 [[],[]] .smaller = true := by decide
def e2409074093878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2409074093878 : Closed e2409074093878 ∧ code e2409074093878 = 11205167116086 := by decide
theorem cert_e2409074093878 : check e2409074093878 [[],[]] .three = true := by decide
def e2409074093882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2409074093882 : Closed e2409074093882 ∧ code e2409074093882 = 11205167116090 := by decide
theorem cert_e2409074093882 : check e2409074093882 [[],[]] .three = true := by decide
def e2409074094942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2409074094942 : Closed e2409074094942 ∧ code e2409074094942 = 11205167117150 := by decide
theorem cert_e2409074094942 : check e2409074094942 [[],[]] .three = true := by decide
def e2409074094958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2409074094958 : Closed e2409074094958 ∧ code e2409074094958 = 11205167117166 := by decide
theorem cert_e2409074094958 : check e2409074094958 [[],[]] .smaller = true := by decide
def e2409074094966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2409074094966 : Closed e2409074094966 ∧ code e2409074094966 = 11205167117174 := by decide
theorem cert_e2409074094966 : check e2409074094966 [[],[]] .smaller = true := by decide
def e2409074094970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2409074094970 : Closed e2409074094970 ∧ code e2409074094970 = 11205167117178 := by decide
theorem cert_e2409074094970 : check e2409074094970 [[],[]] .three = true := by decide
def e2409074095022 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2409074095022 : Closed e2409074095022 ∧ code e2409074095022 = 11205167117230 := by decide
theorem cert_e2409074095022 : check e2409074095022 [[],[]] .smaller = true := by decide
def e2409074095034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2409074095034 : Closed e2409074095034 ∧ code e2409074095034 = 11205167117242 := by decide
theorem cert_e2409074095034 : check e2409074095034 [[],[]] .smaller = true := by decide
def e2409074095062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2409074095062 : Closed e2409074095062 ∧ code e2409074095062 = 11205167117270 := by decide
theorem cert_e2409074095062 : check e2409074095062 [[],[]] .smaller = true := by decide
def e2409074095066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2409074095066 : Closed e2409074095066 ∧ code e2409074095066 = 11205167117274 := by decide
theorem cert_e2409074095066 : check e2409074095066 [[],[]] .smaller = true := by decide
def e2409074095082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2409074095082 : Closed e2409074095082 ∧ code e2409074095082 = 11205167117290 := by decide
theorem cert_e2409074095082 : check e2409074095082 [[],[]] .three = true := by decide
def e2409074095326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2409074095326 : Closed e2409074095326 ∧ code e2409074095326 = 11205167117534 := by decide
theorem cert_e2409074095326 : check e2409074095326 [[],[]] .three = true := by decide
def e2409074095342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2409074095342 : Closed e2409074095342 ∧ code e2409074095342 = 11205167117550 := by decide
theorem cert_e2409074095342 : check e2409074095342 [[],[]] .smaller = true := by decide
def e2409074095350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2409074095350 : Closed e2409074095350 ∧ code e2409074095350 = 11205167117558 := by decide
theorem cert_e2409074095350 : check e2409074095350 [[],[]] .smaller = true := by decide
def e2409074095354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2409074095354 : Closed e2409074095354 ∧ code e2409074095354 = 11205167117562 := by decide
theorem cert_e2409074095354 : check e2409074095354 [[],[]] .three = true := by decide
def e2409074095726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2409074095726 : Closed e2409074095726 ∧ code e2409074095726 = 11205167117934 := by decide
theorem cert_e2409074095726 : check e2409074095726 [[],[]] .smaller = true := by decide
def e2409074095738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2409074095738 : Closed e2409074095738 ∧ code e2409074095738 = 11205167117946 := by decide
theorem cert_e2409074095738 : check e2409074095738 [[],[]] .smaller = true := by decide
def e2409074095926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2409074095926 : Closed e2409074095926 ∧ code e2409074095926 = 11205167118134 := by decide
theorem cert_e2409074095926 : check e2409074095926 [[],[]] .smaller = true := by decide
def e2409074095930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2409074095930 : Closed e2409074095930 ∧ code e2409074095930 = 11205167118138 := by decide
theorem cert_e2409074095930 : check e2409074095930 [[],[]] .smaller = true := by decide
def e2409074096026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2409074096026 : Closed e2409074096026 ∧ code e2409074096026 = 11205167118234 := by decide
theorem cert_e2409074096026 : check e2409074096026 [[],[]] .three = true := by decide
def e2409074096566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2409074096566 : Closed e2409074096566 ∧ code e2409074096566 = 11205167118774 := by decide
theorem cert_e2409074096566 : check e2409074096566 [[],[]] .smaller = true := by decide
def e2409074096598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2409074096598 : Closed e2409074096598 ∧ code e2409074096598 = 11205167118806 := by decide
theorem cert_e2409074096598 : check e2409074096598 [[],[]] .smaller = true := by decide
def e2409074096602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2409074096602 : Closed e2409074096602 ∧ code e2409074096602 = 11205167118810 := by decide
theorem cert_e2409074096602 : check e2409074096602 [[],[]] .smaller = true := by decide
def e2409074096758 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2409074096758 : Closed e2409074096758 ∧ code e2409074096758 = 11205167118966 := by decide
theorem cert_e2409074096758 : check e2409074096758 [[],[]] .smaller = true := by decide
def e2409074096950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2409074096950 : Closed e2409074096950 ∧ code e2409074096950 = 11205167119158 := by decide
theorem cert_e2409074096950 : check e2409074096950 [[],[]] .smaller = true := by decide
def e2409074096954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2409074096954 : Closed e2409074096954 ∧ code e2409074096954 = 11205167119162 := by decide
theorem cert_e2409074096954 : check e2409074096954 [[],[]] .smaller = true := by decide
def e2409074097366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2409074097366 : Closed e2409074097366 ∧ code e2409074097366 = 11205167119574 := by decide
theorem cert_e2409074097366 : check e2409074097366 [[],[]] .three = true := by decide
def e2409074097370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2409074097370 : Closed e2409074097370 ∧ code e2409074097370 = 11205167119578 := by decide
theorem cert_e2409074097370 : check e2409074097370 [[],[]] .three = true := by decide
def e2409074097386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2409074097386 : Closed e2409074097386 ∧ code e2409074097386 = 11205167119594 := by decide
theorem cert_e2409074097386 : check e2409074097386 [[],[]] .three = true := by decide
def e2409074097462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2409074097462 : Closed e2409074097462 ∧ code e2409074097462 = 11205167119670 := by decide
theorem cert_e2409074097462 : check e2409074097462 [[],[]] .three = true := by decide
def e2409074097466 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2409074097466 : Closed e2409074097466 ∧ code e2409074097466 = 11205167119674 := by decide
theorem cert_e2409074097466 : check e2409074097466 [[],[]] .three = true := by decide
def e2409074097562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2409074097562 : Closed e2409074097562 ∧ code e2409074097562 = 11205167119770 := by decide
theorem cert_e2409074097562 : check e2409074097562 [[],[]] .three = true := by decide
def e2409074104030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2409074104030 : Closed e2409074104030 ∧ code e2409074104030 = 11205167126238 := by decide
theorem cert_e2409074104030 : check e2409074104030 [[],[]] .three = true := by decide
def e2409074104054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2409074104054 : Closed e2409074104054 ∧ code e2409074104054 = 11205167126262 := by decide
theorem cert_e2409074104054 : check e2409074104054 [[],[]] .three = true := by decide
def e2409074104158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2409074104158 : Closed e2409074104158 ∧ code e2409074104158 = 11205167126366 := by decide
theorem cert_e2409074104158 : check e2409074104158 [[],[]] .three = true := by decide
def e2409074104174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2409074104174 : Closed e2409074104174 ∧ code e2409074104174 = 11205167126382 := by decide
theorem cert_e2409074104174 : check e2409074104174 [[],[]] .smaller = true := by decide
def e2409074104182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2409074104182 : Closed e2409074104182 ∧ code e2409074104182 = 11205167126390 := by decide
theorem cert_e2409074104182 : check e2409074104182 [[],[]] .smaller = true := by decide
def e2409074104186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2409074104186 : Closed e2409074104186 ∧ code e2409074104186 = 11205167126394 := by decide
theorem cert_e2409074104186 : check e2409074104186 [[],[]] .three = true := by decide
def e2409074104246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2409074104246 : Closed e2409074104246 ∧ code e2409074104246 = 11205167126454 := by decide
theorem cert_e2409074104246 : check e2409074104246 [[],[]] .smaller = true := by decide
def e2409074104278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2409074104278 : Closed e2409074104278 ∧ code e2409074104278 = 11205167126486 := by decide
theorem cert_e2409074104278 : check e2409074104278 [[],[]] .three = true := by decide
def e2409074104282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2409074104282 : Closed e2409074104282 ∧ code e2409074104282 = 11205167126490 := by decide
theorem cert_e2409074104282 : check e2409074104282 [[],[]] .three = true := by decide
def e2409074104798 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2409074104798 : Closed e2409074104798 ∧ code e2409074104798 = 11205167127006 := by decide
theorem cert_e2409074104798 : check e2409074104798 [[],[]] .three = true := by decide
def e2409074104822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2409074104822 : Closed e2409074104822 ∧ code e2409074104822 = 11205167127030 := by decide
theorem cert_e2409074104822 : check e2409074104822 [[],[]] .three = true := by decide
def e2409074105566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2409074105566 : Closed e2409074105566 ∧ code e2409074105566 = 11205167127774 := by decide
theorem cert_e2409074105566 : check e2409074105566 [[],[]] .three = true := by decide
def e2409074105582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2409074105582 : Closed e2409074105582 ∧ code e2409074105582 = 11205167127790 := by decide
theorem cert_e2409074105582 : check e2409074105582 [[],[]] .smaller = true := by decide
def e2409074105590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2409074105590 : Closed e2409074105590 ∧ code e2409074105590 = 11205167127798 := by decide
theorem cert_e2409074105590 : check e2409074105590 [[],[]] .smaller = true := by decide
def e2409074105594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2409074105594 : Closed e2409074105594 ∧ code e2409074105594 = 11205167127802 := by decide
theorem cert_e2409074105594 : check e2409074105594 [[],[]] .three = true := by decide
def e2409074105974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2409074105974 : Closed e2409074105974 ∧ code e2409074105974 = 11205167128182 := by decide
theorem cert_e2409074105974 : check e2409074105974 [[],[]] .smaller = true := by decide
def e2409074106166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409074106166 : Closed e2409074106166 ∧ code e2409074106166 = 11205167128374 := by decide
theorem cert_e2409074106166 : check e2409074106166 [[],[]] .three = true := by decide
def e2409074106170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409074106170 : Closed e2409074106170 ∧ code e2409074106170 = 11205167128378 := by decide
theorem cert_e2409074106170 : check e2409074106170 [[],[]] .three = true := by decide
def e2409074117470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2409074117470 : Closed e2409074117470 ∧ code e2409074117470 = 11205167139678 := by decide
theorem cert_e2409074117470 : check e2409074117470 [[],[]] .three = true := by decide
def e2409074117486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2409074117486 : Closed e2409074117486 ∧ code e2409074117486 = 11205167139694 := by decide
theorem cert_e2409074117486 : check e2409074117486 [[],[]] .smaller = true := by decide
def e2409074117494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2409074117494 : Closed e2409074117494 ∧ code e2409074117494 = 11205167139702 := by decide
theorem cert_e2409074117494 : check e2409074117494 [[],[]] .smaller = true := by decide
def e2409074117498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2409074117498 : Closed e2409074117498 ∧ code e2409074117498 = 11205167139706 := by decide
theorem cert_e2409074117498 : check e2409074117498 [[],[]] .three = true := by decide
def e2409074117550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2409074117550 : Closed e2409074117550 ∧ code e2409074117550 = 11205167139758 := by decide
theorem cert_e2409074117550 : check e2409074117550 [[],[]] .smaller = true := by decide
def e2409074117562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2409074117562 : Closed e2409074117562 ∧ code e2409074117562 = 11205167139770 := by decide
theorem cert_e2409074117562 : check e2409074117562 [[],[]] .smaller = true := by decide
def e2409074117590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2409074117590 : Closed e2409074117590 ∧ code e2409074117590 = 11205167139798 := by decide
theorem cert_e2409074117590 : check e2409074117590 [[],[]] .smaller = true := by decide
def e2409074117594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2409074117594 : Closed e2409074117594 ∧ code e2409074117594 = 11205167139802 := by decide
theorem cert_e2409074117594 : check e2409074117594 [[],[]] .smaller = true := by decide
def e2409074117610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2409074117610 : Closed e2409074117610 ∧ code e2409074117610 = 11205167139818 := by decide
theorem cert_e2409074117610 : check e2409074117610 [[],[]] .three = true := by decide
def e2409074117854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2409074117854 : Closed e2409074117854 ∧ code e2409074117854 = 11205167140062 := by decide
theorem cert_e2409074117854 : check e2409074117854 [[],[]] .three = true := by decide
def e2409074117870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2409074117870 : Closed e2409074117870 ∧ code e2409074117870 = 11205167140078 := by decide
theorem cert_e2409074117870 : check e2409074117870 [[],[]] .smaller = true := by decide
def e2409074117878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2409074117878 : Closed e2409074117878 ∧ code e2409074117878 = 11205167140086 := by decide
theorem cert_e2409074117878 : check e2409074117878 [[],[]] .smaller = true := by decide
def e2409074117882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2409074117882 : Closed e2409074117882 ∧ code e2409074117882 = 11205167140090 := by decide
theorem cert_e2409074117882 : check e2409074117882 [[],[]] .three = true := by decide
def e2409074118254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2409074118254 : Closed e2409074118254 ∧ code e2409074118254 = 11205167140462 := by decide
theorem cert_e2409074118254 : check e2409074118254 [[],[]] .smaller = true := by decide
def e2409074118266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2409074118266 : Closed e2409074118266 ∧ code e2409074118266 = 11205167140474 := by decide
theorem cert_e2409074118266 : check e2409074118266 [[],[]] .smaller = true := by decide
def e2409074118454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409074118454 : Closed e2409074118454 ∧ code e2409074118454 = 11205167140662 := by decide
theorem cert_e2409074118454 : check e2409074118454 [[],[]] .smaller = true := by decide
def e2409074118458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409074118458 : Closed e2409074118458 ∧ code e2409074118458 = 11205167140666 := by decide
theorem cert_e2409074118458 : check e2409074118458 [[],[]] .smaller = true := by decide
def e2409074118554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2409074118554 : Closed e2409074118554 ∧ code e2409074118554 = 11205167140762 := by decide
theorem cert_e2409074118554 : check e2409074118554 [[],[]] .three = true := by decide
def e2409074124214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2409074124214 : Closed e2409074124214 ∧ code e2409074124214 = 11205167146422 := by decide
theorem cert_e2409074124214 : check e2409074124214 [[],[]] .smaller = true := by decide
def e2409074124246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2409074124246 : Closed e2409074124246 ∧ code e2409074124246 = 11205167146454 := by decide
theorem cert_e2409074124246 : check e2409074124246 [[],[]] .smaller = true := by decide
def e2409074124250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2409074124250 : Closed e2409074124250 ∧ code e2409074124250 = 11205167146458 := by decide
theorem cert_e2409074124250 : check e2409074124250 [[],[]] .smaller = true := by decide
def e2409074124406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2409074124406 : Closed e2409074124406 ∧ code e2409074124406 = 11205167146614 := by decide
theorem cert_e2409074124406 : check e2409074124406 [[],[]] .smaller = true := by decide
def e2409074124598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409074124598 : Closed e2409074124598 ∧ code e2409074124598 = 11205167146806 := by decide
theorem cert_e2409074124598 : check e2409074124598 [[],[]] .smaller = true := by decide
def e2409074124602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409074124602 : Closed e2409074124602 ∧ code e2409074124602 = 11205167146810 := by decide
theorem cert_e2409074124602 : check e2409074124602 [[],[]] .smaller = true := by decide
def e2409074127574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2409074127574 : Closed e2409074127574 ∧ code e2409074127574 = 11205167149782 := by decide
theorem cert_e2409074127574 : check e2409074127574 [[],[]] .three = true := by decide
def e2409074127578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2409074127578 : Closed e2409074127578 ∧ code e2409074127578 = 11205167149786 := by decide
theorem cert_e2409074127578 : check e2409074127578 [[],[]] .three = true := by decide
def e2409074127594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2409074127594 : Closed e2409074127594 ∧ code e2409074127594 = 11205167149802 := by decide
theorem cert_e2409074127594 : check e2409074127594 [[],[]] .three = true := by decide
def e2409074127670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409074127670 : Closed e2409074127670 ∧ code e2409074127670 = 11205167149878 := by decide
theorem cert_e2409074127670 : check e2409074127670 [[],[]] .three = true := by decide
def e2409074127674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409074127674 : Closed e2409074127674 ∧ code e2409074127674 = 11205167149882 := by decide
theorem cert_e2409074127674 : check e2409074127674 [[],[]] .three = true := by decide
def e2409074127770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2409074127770 : Closed e2409074127770 ∧ code e2409074127770 = 11205167149978 := by decide
theorem cert_e2409074127770 : check e2409074127770 [[],[]] .three = true := by decide
def e2409074353006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2409074353006 : Closed e2409074353006 ∧ code e2409074353006 = 11205167375214 := by decide
theorem cert_e2409074353006 : check e2409074353006 [[],[]] .chain = true := by decide
def e2409074353014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2409074353014 : Closed e2409074353014 ∧ code e2409074353014 = 11205167375222 := by decide
theorem cert_e2409074353014 : check e2409074353014 [[],[]] .chain = true := by decide
def e2409074353070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2409074353070 : Closed e2409074353070 ∧ code e2409074353070 = 11205167375278 := by decide
theorem cert_e2409074353070 : check e2409074353070 [[],[]] .chain = true := by decide
def e2409074353082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2409074353082 : Closed e2409074353082 ∧ code e2409074353082 = 11205167375290 := by decide
theorem cert_e2409074353082 : check e2409074353082 [[],[]] .chain = true := by decide
def e2409074353110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2409074353110 : Closed e2409074353110 ∧ code e2409074353110 = 11205167375318 := by decide
theorem cert_e2409074353110 : check e2409074353110 [[],[]] .chain = true := by decide
def e2409074353114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2409074353114 : Closed e2409074353114 ∧ code e2409074353114 = 11205167375322 := by decide
theorem cert_e2409074353114 : check e2409074353114 [[],[]] .chain = true := by decide
def e2409074354414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2409074354414 : Closed e2409074354414 ∧ code e2409074354414 = 11205167376622 := by decide
theorem cert_e2409074354414 : check e2409074354414 [[],[]] .chain = true := by decide
def e2409074354422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2409074354422 : Closed e2409074354422 ∧ code e2409074354422 = 11205167376630 := by decide
theorem cert_e2409074354422 : check e2409074354422 [[],[]] .chain = true := by decide
def e2409074354974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2409074354974 : Closed e2409074354974 ∧ code e2409074354974 = 11205167377182 := by decide
theorem cert_e2409074354974 : check e2409074354974 [[],[]] .chain = true := by decide
def e2409074355086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2409074355086 : Closed e2409074355086 ∧ code e2409074355086 = 11205167377294 := by decide
theorem cert_e2409074355086 : check e2409074355086 [[],[]] .chain = true := by decide
def e2409074355310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2409074355310 : Closed e2409074355310 ∧ code e2409074355310 = 11205167377518 := by decide
theorem cert_e2409074355310 : check e2409074355310 [[],[]] .chain = true := by decide
def e2409074355322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2409074355322 : Closed e2409074355322 ∧ code e2409074355322 = 11205167377530 := by decide
theorem cert_e2409074355322 : check e2409074355322 [[],[]] .chain = true := by decide
def e2409074355486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2409074355486 : Closed e2409074355486 ∧ code e2409074355486 = 11205167377694 := by decide
theorem cert_e2409074355486 : check e2409074355486 [[],[]] .chain = true := by decide
def e2409074355654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2409074355654 : Closed e2409074355654 ∧ code e2409074355654 = 11205167377862 := by decide
theorem cert_e2409074355654 : check e2409074355654 [[],[]] .chain = true := by decide
def e2409074355766 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2409074355766 : Closed e2409074355766 ∧ code e2409074355766 = 11205167377974 := by decide
theorem cert_e2409074355766 : check e2409074355766 [[],[]] .chain = true := by decide
def e2409074355770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2409074355770 : Closed e2409074355770 ∧ code e2409074355770 = 11205167377978 := by decide
theorem cert_e2409074355770 : check e2409074355770 [[],[]] .chain = true := by decide
def e2409074355854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2409074355854 : Closed e2409074355854 ∧ code e2409074355854 = 11205167378062 := by decide
theorem cert_e2409074355854 : check e2409074355854 [[],[]] .chain = true := by decide
def e2409074355910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2409074355910 : Closed e2409074355910 ∧ code e2409074355910 = 11205167378118 := by decide
theorem cert_e2409074355910 : check e2409074355910 [[],[]] .chain = true := by decide
def e2409074356654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2409074356654 : Closed e2409074356654 ∧ code e2409074356654 = 11205167378862 := by decide
theorem cert_e2409074356654 : check e2409074356654 [[],[]] .chain = true := by decide
def e2409074356666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2409074356666 : Closed e2409074356666 ∧ code e2409074356666 = 11205167378874 := by decide
theorem cert_e2409074356666 : check e2409074356666 [[],[]] .chain = true := by decide
def e2409074356714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2409074356714 : Closed e2409074356714 ∧ code e2409074356714 = 11205167378922 := by decide
theorem cert_e2409074356714 : check e2409074356714 [[],[]] .chain = true := by decide
def e2409074357358 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2409074357358 : Closed e2409074357358 ∧ code e2409074357358 = 11205167379566 := by decide
theorem cert_e2409074357358 : check e2409074357358 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2409057971738
#print axioms Blc.Floor43.cert_e2409057973786
#print axioms Blc.Floor43.cert_e2409057988122
#print axioms Blc.Floor43.cert_e2409057991194
#print axioms Blc.Floor43.cert_e2409057998362
#print axioms Blc.Floor43.cert_e2409057999386
#print axioms Blc.Floor43.cert_e2409058070042
#print axioms Blc.Floor43.cert_e2409058072090
#print axioms Blc.Floor43.cert_e2409058168346
#print axioms Blc.Floor43.cert_e2409058171418
#print axioms Blc.Floor43.cert_e2409058219546
#print axioms Blc.Floor43.cert_e2409058220570
