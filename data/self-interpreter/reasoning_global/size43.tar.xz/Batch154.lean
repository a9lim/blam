import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259550455322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259550455322 : Closed e2259550455322 ∧ code e2259550455322 = 11055643477530 := by decide
theorem cert_e2259550455322 : check e2259550455322 [[]] .width = true := by decide
def e2259550458054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259550458054 : Closed e2259550458054 ∧ code e2259550458054 = 11055643480262 := by decide
theorem cert_e2259550458054 : check e2259550458054 [[]] .width = true := by decide
def e2259550470342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259550470342 : Closed e2259550470342 ∧ code e2259550470342 = 11055643492550 := by decide
theorem cert_e2259550470342 : check e2259550470342 [[]] .width = true := by decide
def e2259550470870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259550470870 : Closed e2259550470870 ∧ code e2259550470870 = 11055643493078 := by decide
theorem cert_e2259550470870 : check e2259550470870 [[]] .width = true := by decide
def e2259550470874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259550470874 : Closed e2259550470874 ∧ code e2259550470874 = 11055643493082 := by decide
theorem cert_e2259550470874 : check e2259550470874 [[]] .width = true := by decide
def e2259550470890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259550470890 : Closed e2259550470890 ∧ code e2259550470890 = 11055643493098 := by decide
theorem cert_e2259550470890 : check e2259550470890 [[]] .width = true := by decide
def e2259550470966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259550470966 : Closed e2259550470966 ∧ code e2259550470966 = 11055643493174 := by decide
theorem cert_e2259550470966 : check e2259550470966 [[]] .width = true := by decide
def e2259550470970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259550470970 : Closed e2259550470970 ∧ code e2259550470970 = 11055643493178 := by decide
theorem cert_e2259550470970 : check e2259550470970 [[]] .width = true := by decide
def e2259550471054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259550471054 : Closed e2259550471054 ∧ code e2259550471054 = 11055643493262 := by decide
theorem cert_e2259550471054 : check e2259550471054 [[]] .width = true := by decide
def e2259550471066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259550471066 : Closed e2259550471066 ∧ code e2259550471066 = 11055643493274 := by decide
theorem cert_e2259550471066 : check e2259550471066 [[]] .width = true := by decide
def e2259550472986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259550472986 : Closed e2259550472986 ∧ code e2259550472986 = 11055643495194 := by decide
theorem cert_e2259550472986 : check e2259550472986 [[]] .width = true := by decide
def e2259550473030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259550473030 : Closed e2259550473030 ∧ code e2259550473030 = 11055643495238 := by decide
theorem cert_e2259550473030 : check e2259550473030 [[]] .width = true := by decide
def e2259550473142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259550473142 : Closed e2259550473142 ∧ code e2259550473142 = 11055643495350 := by decide
theorem cert_e2259550473142 : check e2259550473142 [[]] .width = true := by decide
def e2259550473270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259550473270 : Closed e2259550473270 ∧ code e2259550473270 = 11055643495478 := by decide
theorem cert_e2259550473270 : check e2259550473270 [[]] .width = true := by decide
def e2259550473274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259550473274 : Closed e2259550473274 ∧ code e2259550473274 = 11055643495482 := by decide
theorem cert_e2259550473274 : check e2259550473274 [[]] .width = true := by decide
def e2259550473414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259550473414 : Closed e2259550473414 ∧ code e2259550473414 = 11055643495622 := by decide
theorem cert_e2259550473414 : check e2259550473414 [[]] .width = true := by decide
def e2259550473754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259550473754 : Closed e2259550473754 ∧ code e2259550473754 = 11055643495962 := by decide
theorem cert_e2259550473754 : check e2259550473754 [[]] .width = true := by decide
def e2259550473846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259550473846 : Closed e2259550473846 ∧ code e2259550473846 = 11055643496054 := by decide
theorem cert_e2259550473846 : check e2259550473846 [[]] .width = true := by decide
def e2259550481434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259550481434 : Closed e2259550481434 ∧ code e2259550481434 = 11055643503642 := by decide
theorem cert_e2259550481434 : check e2259550481434 [[]] .width = true := by decide
def e2259550481478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259550481478 : Closed e2259550481478 ∧ code e2259550481478 = 11055643503686 := by decide
theorem cert_e2259550481478 : check e2259550481478 [[]] .width = true := by decide
def e2259550481506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259550481506 : Closed e2259550481506 ∧ code e2259550481506 = 11055643503714 := by decide
theorem cert_e2259550481506 : check e2259550481506 [[]] .width = true := by decide
def e2259550481670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259550481670 : Closed e2259550481670 ∧ code e2259550481670 = 11055643503878 := by decide
theorem cert_e2259550481670 : check e2259550481670 [[]] .width = true := by decide
def e2259550482462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259550482462 : Closed e2259550482462 ∧ code e2259550482462 = 11055643504670 := by decide
theorem cert_e2259550482462 : check e2259550482462 [[]] .width = true := by decide
def e2259550482630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259550482630 : Closed e2259550482630 ∧ code e2259550482630 = 11055643504838 := by decide
theorem cert_e2259550482630 : check e2259550482630 [[]] .width = true := by decide
def e2259550482658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259550482658 : Closed e2259550482658 ∧ code e2259550482658 = 11055643504866 := by decide
theorem cert_e2259550482658 : check e2259550482658 [[]] .width = true := by decide
def e2259550483206 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259550483206 : Closed e2259550483206 ∧ code e2259550483206 = 11055643505414 := by decide
theorem cert_e2259550483206 : check e2259550483206 [[]] .width = true := by decide
def e2259550834202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259550834202 : Closed e2259550834202 ∧ code e2259550834202 = 11055643856410 := by decide
private def t_e2259550834202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259550834202 : ¬ IsSelfInterpreter e2259550834202 :=
  wSource (t := t_e2259550834202) (replay_sound (ps := []) (t := e2259550834202) (by decide)) (by decide)
def e2259550843078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259550843078 : Closed e2259550843078 ∧ code e2259550843078 = 11055643865286 := by decide
theorem cert_e2259550843078 : check e2259550843078 [[]] .width = true := by decide
def e2259550848538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259550848538 : Closed e2259550848538 ∧ code e2259550848538 = 11055643870746 := by decide
private def t_e2259550848538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259550848538 : ¬ IsSelfInterpreter e2259550848538 :=
  wSource (t := t_e2259550848538) (replay_sound (ps := []) (t := e2259550848538) (by decide)) (by decide)
def e2259550851270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259550851270 : Closed e2259550851270 ∧ code e2259550851270 = 11055643873478 := by decide
theorem cert_e2259550851270 : check e2259550851270 [[]] .width = true := by decide
def e2259563561158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259563561158 : Closed e2259563561158 ∧ code e2259563561158 = 11055656583366 := by decide
theorem cert_e2259563561158 : check e2259563561158 [[]] .width = true := by decide
def e2259563692230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259563692230 : Closed e2259563692230 ∧ code e2259563692230 = 11055656714438 := by decide
theorem cert_e2259563692230 : check e2259563692230 [[]] .width = true := by decide
def e2259579420870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259579420870 : Closed e2259579420870 ∧ code e2259579420870 = 11055672443078 := by decide
theorem cert_e2259579420870 : check e2259579420870 [[]] .width = true := by decide
def e2259579486406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259579486406 : Closed e2259579486406 ∧ code e2259579486406 = 11055672508614 := by decide
theorem cert_e2259579486406 : check e2259579486406 [[]] .width = true := by decide
def e2259579662534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259579662534 : Closed e2259579662534 ∧ code e2259579662534 = 11055672684742 := by decide
theorem cert_e2259579662534 : check e2259579662534 [[]] .width = true := by decide
def e2259579694618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259579694618 : Closed e2259579694618 ∧ code e2259579694618 = 11055672716826 := by decide
theorem cert_e2259579694618 : check e2259579694618 [[]] .width = true := by decide
def e2259579945158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259579945158 : Closed e2259579945158 ∧ code e2259579945158 = 11055672967366 := by decide
theorem cert_e2259579945158 : check e2259579945158 [[]] .width = true := by decide
def e2259580018714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259580018714 : Closed e2259580018714 ∧ code e2259580018714 = 11055673040922 := by decide
theorem cert_e2259580018714 : check e2259580018714 [[]] .width = true := by decide
def e2259580018806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259580018806 : Closed e2259580018806 ∧ code e2259580018806 = 11055673041014 := by decide
theorem cert_e2259580018806 : check e2259580018806 [[]] .width = true := by decide
def e2259580019050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259580019050 : Closed e2259580019050 ∧ code e2259580019050 = 11055673041258 := by decide
theorem cert_e2259580019050 : check e2259580019050 [[]] .width = true := by decide
def e2259580019098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259580019098 : Closed e2259580019098 ∧ code e2259580019098 = 11055673041306 := by decide
theorem cert_e2259580019098 : check e2259580019098 [[]] .width = true := by decide
def e2259580031174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259580031174 : Closed e2259580031174 ∧ code e2259580031174 = 11055673053382 := by decide
theorem cert_e2259580031174 : check e2259580031174 [[]] .width = true := by decide
def e2259580034586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259580034586 : Closed e2259580034586 ∧ code e2259580034586 = 11055673056794 := by decide
theorem cert_e2259580034586 : check e2259580034586 [[]] .width = true := by decide
def e2259580043462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259580043462 : Closed e2259580043462 ∧ code e2259580043462 = 11055673065670 := by decide
theorem cert_e2259580043462 : check e2259580043462 [[]] .width = true := by decide
def e2259580051482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259580051482 : Closed e2259580051482 ∧ code e2259580051482 = 11055673073690 := by decide
theorem cert_e2259580051482 : check e2259580051482 [[]] .width = true := by decide
def e2259580051574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259580051574 : Closed e2259580051574 ∧ code e2259580051574 = 11055673073782 := by decide
theorem cert_e2259580051574 : check e2259580051574 [[]] .width = true := by decide
def e2259580051818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259580051818 : Closed e2259580051818 ∧ code e2259580051818 = 11055673074026 := by decide
theorem cert_e2259580051818 : check e2259580051818 [[]] .width = true := by decide
def e2259580051866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259580051866 : Closed e2259580051866 ∧ code e2259580051866 = 11055673074074 := by decide
theorem cert_e2259580051866 : check e2259580051866 [[]] .width = true := by decide
def e2259580055750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259580055750 : Closed e2259580055750 ∧ code e2259580055750 = 11055673077958 := by decide
theorem cert_e2259580055750 : check e2259580055750 [[]] .width = true := by decide
def e2259580137670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259580137670 : Closed e2259580137670 ∧ code e2259580137670 = 11055673159878 := by decide
theorem cert_e2259580137670 : check e2259580137670 [[]] .width = true := by decide
def e2259580153370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259580153370 : Closed e2259580153370 ∧ code e2259580153370 = 11055673175578 := by decide
theorem cert_e2259580153370 : check e2259580153370 [[]] .width = true := by decide
def e2259580155418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259580155418 : Closed e2259580155418 ∧ code e2259580155418 = 11055673177626 := by decide
theorem cert_e2259580155418 : check e2259580155418 [[]] .width = true := by decide
def e2259580272838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259580272838 : Closed e2259580272838 ∧ code e2259580272838 = 11055673295046 := by decide
theorem cert_e2259580272838 : check e2259580272838 [[]] .width = true := by decide
def e2259580293318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259580293318 : Closed e2259580293318 ∧ code e2259580293318 = 11055673315526 := by decide
theorem cert_e2259580293318 : check e2259580293318 [[]] .width = true := by decide
def e2259580296730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259580296730 : Closed e2259580296730 ∧ code e2259580296730 = 11055673318938 := by decide
theorem cert_e2259580296730 : check e2259580296730 [[]] .width = true := by decide
def e2259580305606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259580305606 : Closed e2259580305606 ∧ code e2259580305606 = 11055673327814 := by decide
theorem cert_e2259580305606 : check e2259580305606 [[]] .width = true := by decide
def e2259580313626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259580313626 : Closed e2259580313626 ∧ code e2259580313626 = 11055673335834 := by decide
theorem cert_e2259580313626 : check e2259580313626 [[]] .width = true := by decide
def e2259580313718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259580313718 : Closed e2259580313718 ∧ code e2259580313718 = 11055673335926 := by decide
theorem cert_e2259580313718 : check e2259580313718 [[]] .width = true := by decide
def e2259580313962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259580313962 : Closed e2259580313962 ∧ code e2259580313962 = 11055673336170 := by decide
theorem cert_e2259580313962 : check e2259580313962 [[]] .width = true := by decide
def e2259580314010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259580314010 : Closed e2259580314010 ∧ code e2259580314010 = 11055673336218 := by decide
theorem cert_e2259580314010 : check e2259580314010 [[]] .width = true := by decide
def e2259580317894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259580317894 : Closed e2259580317894 ∧ code e2259580317894 = 11055673340102 := by decide
theorem cert_e2259580317894 : check e2259580317894 [[]] .width = true := by decide
def e2259580325402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259580325402 : Closed e2259580325402 ∧ code e2259580325402 = 11055673347610 := by decide
private def t_e2259580325402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259580325402 : ¬ IsSelfInterpreter e2259580325402 :=
  wSource (t := t_e2259580325402) (replay_sound (ps := []) (t := e2259580325402) (by decide)) (by decide)
def e2259580334278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259580334278 : Closed e2259580334278 ∧ code e2259580334278 = 11055673356486 := by decide
theorem cert_e2259580334278 : check e2259580334278 [[]] .width = true := by decide
def e2259582566598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259582566598 : Closed e2259582566598 ∧ code e2259582566598 = 11055675588806 := by decide
theorem cert_e2259582566598 : check e2259582566598 [[]] .width = true := by decide
def e2259582632134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259582632134 : Closed e2259582632134 ∧ code e2259582632134 = 11055675654342 := by decide
theorem cert_e2259582632134 : check e2259582632134 [[]] .width = true := by decide
def e2259585302554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259585302554 : Closed e2259585302554 ∧ code e2259585302554 = 11055678324762 := by decide
theorem cert_e2259585302554 : check e2259585302554 [[]] .width = true := by decide
def e2259585302646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259585302646 : Closed e2259585302646 ∧ code e2259585302646 = 11055678324854 := by decide
theorem cert_e2259585302646 : check e2259585302646 [[]] .width = true := by decide
def e2259585302890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259585302890 : Closed e2259585302890 ∧ code e2259585302890 = 11055678325098 := by decide
theorem cert_e2259585302890 : check e2259585302890 [[]] .width = true := by decide
def e2259585302938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259585302938 : Closed e2259585302938 ∧ code e2259585302938 = 11055678325146 := by decide
theorem cert_e2259585302938 : check e2259585302938 [[]] .width = true := by decide
def e2259585303946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259585303946 : Closed e2259585303946 ∧ code e2259585303946 = 11055678326154 := by decide
theorem cert_e2259585303946 : check e2259585303946 [[]] .width = true := by decide
def e2259585303970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259585303970 : Closed e2259585303970 ∧ code e2259585303970 = 11055678326178 := by decide
theorem cert_e2259585303970 : check e2259585303970 [[]] .width = true := by decide
def e2259585304078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259585304078 : Closed e2259585304078 ∧ code e2259585304078 = 11055678326286 := by decide
theorem cert_e2259585304078 : check e2259585304078 [[]] .width = true := by decide
def e2259585304090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259585304090 : Closed e2259585304090 ∧ code e2259585304090 = 11055678326298 := by decide
theorem cert_e2259585304090 : check e2259585304090 [[]] .width = true := by decide
def e2259585304162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259585304162 : Closed e2259585304162 ∧ code e2259585304162 = 11055678326370 := by decide
theorem cert_e2259585304162 : check e2259585304162 [[]] .width = true := by decide
def e2259585712326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259585712326 : Closed e2259585712326 ∧ code e2259585712326 = 11055678734534 := by decide
theorem cert_e2259585712326 : check e2259585712326 [[]] .width = true := by decide
def e2259585785882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259585785882 : Closed e2259585785882 ∧ code e2259585785882 = 11055678808090 := by decide
theorem cert_e2259585785882 : check e2259585785882 [[]] .width = true := by decide
def e2259585785974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259585785974 : Closed e2259585785974 ∧ code e2259585785974 = 11055678808182 := by decide
theorem cert_e2259585785974 : check e2259585785974 [[]] .width = true := by decide
def e2259585786218 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259585786218 : Closed e2259585786218 ∧ code e2259585786218 = 11055678808426 := by decide
theorem cert_e2259585786218 : check e2259585786218 [[]] .width = true := by decide
def e2259585786266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259585786266 : Closed e2259585786266 ∧ code e2259585786266 = 11055678808474 := by decide
theorem cert_e2259585786266 : check e2259585786266 [[]] .width = true := by decide
def e2259585798342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259585798342 : Closed e2259585798342 ∧ code e2259585798342 = 11055678820550 := by decide
theorem cert_e2259585798342 : check e2259585798342 [[]] .width = true := by decide
def e2259585801754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259585801754 : Closed e2259585801754 ∧ code e2259585801754 = 11055678823962 := by decide
theorem cert_e2259585801754 : check e2259585801754 [[]] .width = true := by decide
def e2259585810630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259585810630 : Closed e2259585810630 ∧ code e2259585810630 = 11055678832838 := by decide
theorem cert_e2259585810630 : check e2259585810630 [[]] .width = true := by decide
def e2259585818650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259585818650 : Closed e2259585818650 ∧ code e2259585818650 = 11055678840858 := by decide
theorem cert_e2259585818650 : check e2259585818650 [[]] .width = true := by decide
def e2259585818742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259585818742 : Closed e2259585818742 ∧ code e2259585818742 = 11055678840950 := by decide
theorem cert_e2259585818742 : check e2259585818742 [[]] .width = true := by decide
def e2259585818986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259585818986 : Closed e2259585818986 ∧ code e2259585818986 = 11055678841194 := by decide
theorem cert_e2259585818986 : check e2259585818986 [[]] .width = true := by decide
def e2259585819034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259585819034 : Closed e2259585819034 ∧ code e2259585819034 = 11055678841242 := by decide
theorem cert_e2259585819034 : check e2259585819034 [[]] .width = true := by decide
def e2259585822918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259585822918 : Closed e2259585822918 ∧ code e2259585822918 = 11055678845126 := by decide
theorem cert_e2259585822918 : check e2259585822918 [[]] .width = true := by decide
def e2259586646214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259586646214 : Closed e2259586646214 ∧ code e2259586646214 = 11055679668422 := by decide
theorem cert_e2259586646214 : check e2259586646214 [[]] .width = true := by decide
def e2259586646742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259586646742 : Closed e2259586646742 ∧ code e2259586646742 = 11055679668950 := by decide
theorem cert_e2259586646742 : check e2259586646742 [[]] .width = true := by decide
def e2259586646746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259586646746 : Closed e2259586646746 ∧ code e2259586646746 = 11055679668954 := by decide
theorem cert_e2259586646746 : check e2259586646746 [[]] .width = true := by decide
def e2259586646762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259586646762 : Closed e2259586646762 ∧ code e2259586646762 = 11055679668970 := by decide
theorem cert_e2259586646762 : check e2259586646762 [[]] .width = true := by decide
def e2259586646838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259586646838 : Closed e2259586646838 ∧ code e2259586646838 = 11055679669046 := by decide
theorem cert_e2259586646838 : check e2259586646838 [[]] .width = true := by decide
def e2259586646842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259586646842 : Closed e2259586646842 ∧ code e2259586646842 = 11055679669050 := by decide
theorem cert_e2259586646842 : check e2259586646842 [[]] .width = true := by decide
def e2259586646926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259586646926 : Closed e2259586646926 ∧ code e2259586646926 = 11055679669134 := by decide
theorem cert_e2259586646926 : check e2259586646926 [[]] .width = true := by decide
def e2259586646938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259586646938 : Closed e2259586646938 ∧ code e2259586646938 = 11055679669146 := by decide
theorem cert_e2259586646938 : check e2259586646938 [[]] .width = true := by decide
def e2259586648858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259586648858 : Closed e2259586648858 ∧ code e2259586648858 = 11055679671066 := by decide
theorem cert_e2259586648858 : check e2259586648858 [[]] .width = true := by decide
def e2259586648902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259586648902 : Closed e2259586648902 ∧ code e2259586648902 = 11055679671110 := by decide
theorem cert_e2259586648902 : check e2259586648902 [[]] .width = true := by decide
def e2259586649014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259586649014 : Closed e2259586649014 ∧ code e2259586649014 = 11055679671222 := by decide
theorem cert_e2259586649014 : check e2259586649014 [[]] .width = true := by decide
def e2259586649142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259586649142 : Closed e2259586649142 ∧ code e2259586649142 = 11055679671350 := by decide
theorem cert_e2259586649142 : check e2259586649142 [[]] .width = true := by decide
def e2259586649146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259586649146 : Closed e2259586649146 ∧ code e2259586649146 = 11055679671354 := by decide
theorem cert_e2259586649146 : check e2259586649146 [[]] .width = true := by decide
def e2259586649286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259586649286 : Closed e2259586649286 ∧ code e2259586649286 = 11055679671494 := by decide
theorem cert_e2259586649286 : check e2259586649286 [[]] .width = true := by decide
def e2259586649626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259586649626 : Closed e2259586649626 ∧ code e2259586649626 = 11055679671834 := by decide
theorem cert_e2259586649626 : check e2259586649626 [[]] .width = true := by decide
def e2259586649718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259586649718 : Closed e2259586649718 ∧ code e2259586649718 = 11055679671926 := by decide
theorem cert_e2259586649718 : check e2259586649718 [[]] .width = true := by decide
def e2259586657306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259586657306 : Closed e2259586657306 ∧ code e2259586657306 = 11055679679514 := by decide
theorem cert_e2259586657306 : check e2259586657306 [[]] .width = true := by decide
def e2259586657350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259586657350 : Closed e2259586657350 ∧ code e2259586657350 = 11055679679558 := by decide
theorem cert_e2259586657350 : check e2259586657350 [[]] .width = true := by decide
def e2259586657378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259586657378 : Closed e2259586657378 ∧ code e2259586657378 = 11055679679586 := by decide
theorem cert_e2259586657378 : check e2259586657378 [[]] .width = true := by decide
def e2259586657542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259586657542 : Closed e2259586657542 ∧ code e2259586657542 = 11055679679750 := by decide
theorem cert_e2259586657542 : check e2259586657542 [[]] .width = true := by decide
def e2259586658334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259586658334 : Closed e2259586658334 ∧ code e2259586658334 = 11055679680542 := by decide
theorem cert_e2259586658334 : check e2259586658334 [[]] .width = true := by decide
def e2259586658502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259586658502 : Closed e2259586658502 ∧ code e2259586658502 = 11055679680710 := by decide
theorem cert_e2259586658502 : check e2259586658502 [[]] .width = true := by decide
def e2259586658530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259586658530 : Closed e2259586658530 ∧ code e2259586658530 = 11055679680738 := by decide
theorem cert_e2259586658530 : check e2259586658530 [[]] .width = true := by decide
def e2259586659078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259586659078 : Closed e2259586659078 ∧ code e2259586659078 = 11055679681286 := by decide
theorem cert_e2259586659078 : check e2259586659078 [[]] .width = true := by decide
def e2259586969798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259586969798 : Closed e2259586969798 ∧ code e2259586969798 = 11055679992006 := by decide
theorem cert_e2259586969798 : check e2259586969798 [[]] .width = true := by decide
def e2259587137562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259587137562 : Closed e2259587137562 ∧ code e2259587137562 = 11055680159770 := by decide
theorem cert_e2259587137562 : check e2259587137562 [[]] .width = true := by decide
def e2259587137654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259587137654 : Closed e2259587137654 ∧ code e2259587137654 = 11055680159862 := by decide
theorem cert_e2259587137654 : check e2259587137654 [[]] .width = true := by decide
def e2259587137898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259587137898 : Closed e2259587137898 ∧ code e2259587137898 = 11055680160106 := by decide
theorem cert_e2259587137898 : check e2259587137898 [[]] .width = true := by decide
def e2259587137946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259587137946 : Closed e2259587137946 ∧ code e2259587137946 = 11055680160154 := by decide
theorem cert_e2259587137946 : check e2259587137946 [[]] .width = true := by decide
def e2259587138954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259587138954 : Closed e2259587138954 ∧ code e2259587138954 = 11055680161162 := by decide
theorem cert_e2259587138954 : check e2259587138954 [[]] .width = true := by decide
def e2259587138978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259587138978 : Closed e2259587138978 ∧ code e2259587138978 = 11055680161186 := by decide
theorem cert_e2259587138978 : check e2259587138978 [[]] .width = true := by decide
def e2259587139086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259587139086 : Closed e2259587139086 ∧ code e2259587139086 = 11055680161294 := by decide
theorem cert_e2259587139086 : check e2259587139086 [[]] .width = true := by decide
def e2259587139098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259587139098 : Closed e2259587139098 ∧ code e2259587139098 = 11055680161306 := by decide
theorem cert_e2259587139098 : check e2259587139098 [[]] .width = true := by decide
def e2259587139170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259587139170 : Closed e2259587139170 ∧ code e2259587139170 = 11055680161378 := by decide
theorem cert_e2259587139170 : check e2259587139170 [[]] .width = true := by decide
def e2259587350726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259587350726 : Closed e2259587350726 ∧ code e2259587350726 = 11055680372934 := by decide
theorem cert_e2259587350726 : check e2259587350726 [[]] .width = true := by decide
def e2259587371206 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259587371206 : Closed e2259587371206 ∧ code e2259587371206 = 11055680393414 := by decide
theorem cert_e2259587371206 : check e2259587371206 [[]] .width = true := by decide
def e2259587374618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259587374618 : Closed e2259587374618 ∧ code e2259587374618 = 11055680396826 := by decide
theorem cert_e2259587374618 : check e2259587374618 [[]] .width = true := by decide
def e2259587383494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259587383494 : Closed e2259587383494 ∧ code e2259587383494 = 11055680405702 := by decide
theorem cert_e2259587383494 : check e2259587383494 [[]] .width = true := by decide
def e2259587391514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259587391514 : Closed e2259587391514 ∧ code e2259587391514 = 11055680413722 := by decide
theorem cert_e2259587391514 : check e2259587391514 [[]] .width = true := by decide
def e2259587391606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259587391606 : Closed e2259587391606 ∧ code e2259587391606 = 11055680413814 := by decide
theorem cert_e2259587391606 : check e2259587391606 [[]] .width = true := by decide
def e2259587391850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259587391850 : Closed e2259587391850 ∧ code e2259587391850 = 11055680414058 := by decide
theorem cert_e2259587391850 : check e2259587391850 [[]] .width = true := by decide
def e2259587391898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259587391898 : Closed e2259587391898 ∧ code e2259587391898 = 11055680414106 := by decide
theorem cert_e2259587391898 : check e2259587391898 [[]] .width = true := by decide
def e2259587395782 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259587395782 : Closed e2259587395782 ∧ code e2259587395782 = 11055680417990 := by decide
theorem cert_e2259587395782 : check e2259587395782 [[]] .width = true := by decide
def e2259587403290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259587403290 : Closed e2259587403290 ∧ code e2259587403290 = 11055680425498 := by decide
theorem cert_e2259587403290 : check e2259587403290 [[]] .width = true := by decide
def e2259587412166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259587412166 : Closed e2259587412166 ∧ code e2259587412166 = 11055680434374 := by decide
theorem cert_e2259587412166 : check e2259587412166 [[]] .width = true := by decide
def e2259587694790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259587694790 : Closed e2259587694790 ∧ code e2259587694790 = 11055680716998 := by decide
theorem cert_e2259587694790 : check e2259587694790 [[]] .width = true := by decide
def e2259587695318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259587695318 : Closed e2259587695318 ∧ code e2259587695318 = 11055680717526 := by decide
theorem cert_e2259587695318 : check e2259587695318 [[]] .width = true := by decide
def e2259587695322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259587695322 : Closed e2259587695322 ∧ code e2259587695322 = 11055680717530 := by decide
theorem cert_e2259587695322 : check e2259587695322 [[]] .width = true := by decide
def e2259587695338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259587695338 : Closed e2259587695338 ∧ code e2259587695338 = 11055680717546 := by decide
theorem cert_e2259587695338 : check e2259587695338 [[]] .width = true := by decide
def e2259587695414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259587695414 : Closed e2259587695414 ∧ code e2259587695414 = 11055680717622 := by decide
theorem cert_e2259587695414 : check e2259587695414 [[]] .width = true := by decide
def e2259587695418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259587695418 : Closed e2259587695418 ∧ code e2259587695418 = 11055680717626 := by decide
theorem cert_e2259587695418 : check e2259587695418 [[]] .width = true := by decide
def e2259587695502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259587695502 : Closed e2259587695502 ∧ code e2259587695502 = 11055680717710 := by decide
theorem cert_e2259587695502 : check e2259587695502 [[]] .width = true := by decide
def e2259587695514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259587695514 : Closed e2259587695514 ∧ code e2259587695514 = 11055680717722 := by decide
theorem cert_e2259587695514 : check e2259587695514 [[]] .width = true := by decide
def e2259587697434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259587697434 : Closed e2259587697434 ∧ code e2259587697434 = 11055680719642 := by decide
theorem cert_e2259587697434 : check e2259587697434 [[]] .width = true := by decide
def e2259587697478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259587697478 : Closed e2259587697478 ∧ code e2259587697478 = 11055680719686 := by decide
theorem cert_e2259587697478 : check e2259587697478 [[]] .width = true := by decide
def e2259587697590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259587697590 : Closed e2259587697590 ∧ code e2259587697590 = 11055680719798 := by decide
theorem cert_e2259587697590 : check e2259587697590 [[]] .width = true := by decide
def e2259587697718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259587697718 : Closed e2259587697718 ∧ code e2259587697718 = 11055680719926 := by decide
theorem cert_e2259587697718 : check e2259587697718 [[]] .width = true := by decide
def e2259587697722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259587697722 : Closed e2259587697722 ∧ code e2259587697722 = 11055680719930 := by decide
theorem cert_e2259587697722 : check e2259587697722 [[]] .width = true := by decide
def e2259587697862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259587697862 : Closed e2259587697862 ∧ code e2259587697862 = 11055680720070 := by decide
theorem cert_e2259587697862 : check e2259587697862 [[]] .width = true := by decide
def e2259587698202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259587698202 : Closed e2259587698202 ∧ code e2259587698202 = 11055680720410 := by decide
theorem cert_e2259587698202 : check e2259587698202 [[]] .width = true := by decide
def e2259587698294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259587698294 : Closed e2259587698294 ∧ code e2259587698294 = 11055680720502 := by decide
theorem cert_e2259587698294 : check e2259587698294 [[]] .width = true := by decide
def e2259587705882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259587705882 : Closed e2259587705882 ∧ code e2259587705882 = 11055680728090 := by decide
theorem cert_e2259587705882 : check e2259587705882 [[]] .width = true := by decide
def e2259587705926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259587705926 : Closed e2259587705926 ∧ code e2259587705926 = 11055680728134 := by decide
theorem cert_e2259587705926 : check e2259587705926 [[]] .width = true := by decide
def e2259587705954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259587705954 : Closed e2259587705954 ∧ code e2259587705954 = 11055680728162 := by decide
theorem cert_e2259587705954 : check e2259587705954 [[]] .width = true := by decide
def e2259587706118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259587706118 : Closed e2259587706118 ∧ code e2259587706118 = 11055680728326 := by decide
theorem cert_e2259587706118 : check e2259587706118 [[]] .width = true := by decide
def e2259587706910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259587706910 : Closed e2259587706910 ∧ code e2259587706910 = 11055680729118 := by decide
theorem cert_e2259587706910 : check e2259587706910 [[]] .width = true := by decide
def e2259587707078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259587707078 : Closed e2259587707078 ∧ code e2259587707078 = 11055680729286 := by decide
theorem cert_e2259587707078 : check e2259587707078 [[]] .width = true := by decide
def e2259587707106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259587707106 : Closed e2259587707106 ∧ code e2259587707106 = 11055680729314 := by decide
theorem cert_e2259587707106 : check e2259587707106 [[]] .width = true := by decide
def e2259587707654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259587707654 : Closed e2259587707654 ∧ code e2259587707654 = 11055680729862 := by decide
theorem cert_e2259587707654 : check e2259587707654 [[]] .width = true := by decide
def e2259626475718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259626475718 : Closed e2259626475718 ∧ code e2259626475718 = 11055719497926 := by decide
theorem cert_e2259626475718 : check e2259626475718 [[]] .width = true := by decide
def e2259626672326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259626672326 : Closed e2259626672326 ∧ code e2259626672326 = 11055719694534 := by decide
theorem cert_e2259626672326 : check e2259626672326 [[]] .width = true := by decide
def e2259634188486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259634188486 : Closed e2259634188486 ∧ code e2259634188486 = 11055727210694 := by decide
theorem cert_e2259634188486 : check e2259634188486 [[]] .width = true := by decide
def e2259634220570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259634220570 : Closed e2259634220570 ∧ code e2259634220570 = 11055727242778 := by decide
theorem cert_e2259634220570 : check e2259634220570 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259550834202
#print axioms Blc.Floor43.cert_e2259550848538
#print axioms Blc.Floor43.cert_e2259580325402
