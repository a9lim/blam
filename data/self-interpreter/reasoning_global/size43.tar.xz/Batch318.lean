import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411653542830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2411653542830 : Closed e2411653542830 ∧ code e2411653542830 = 11207746565038 := by decide
theorem cert_e2411653542830 : check e2411653542830 [[],[],[.under]] .smaller = true := by decide
def e2411653542842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2411653542842 : Closed e2411653542842 ∧ code e2411653542842 = 11207746565050 := by decide
theorem cert_e2411653542842 : check e2411653542842 [[],[],[.under]] .smaller = true := by decide
def e2411653542870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2411653542870 : Closed e2411653542870 ∧ code e2411653542870 = 11207746565078 := by decide
theorem cert_e2411653542870 : check e2411653542870 [[],[],[.under]] .smaller = true := by decide
def e2411653542874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2411653542874 : Closed e2411653542874 ∧ code e2411653542874 = 11207746565082 := by decide
theorem cert_e2411653542874 : check e2411653542874 [[],[],[.under]] .smaller = true := by decide
def e2411653543150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411653543150 : Closed e2411653543150 ∧ code e2411653543150 = 11207746565358 := by decide
theorem cert_e2411653543150 : check e2411653543150 [[],[],[.under]] .smaller = true := by decide
def e2411653543158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411653543158 : Closed e2411653543158 ∧ code e2411653543158 = 11207746565366 := by decide
theorem cert_e2411653543158 : check e2411653543158 [[],[],[.under]] .smaller = true := by decide
def e2411653543486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2411653543486 : Closed e2411653543486 ∧ code e2411653543486 = 11207746565694 := by decide
theorem cert_e2411653543486 : check e2411653543486 [[],[],[.under]] .smaller = true := by decide
def e2411653543534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411653543534 : Closed e2411653543534 ∧ code e2411653543534 = 11207746565742 := by decide
theorem cert_e2411653543534 : check e2411653543534 [[],[],[.under]] .smaller = true := by decide
def e2411653543546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411653543546 : Closed e2411653543546 ∧ code e2411653543546 = 11207746565754 := by decide
theorem cert_e2411653543546 : check e2411653543546 [[],[],[.under]] .smaller = true := by decide
def e2411653543734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411653543734 : Closed e2411653543734 ∧ code e2411653543734 = 11207746565942 := by decide
theorem cert_e2411653543734 : check e2411653543734 [[],[],[.under]] .smaller = true := by decide
def e2411653543738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411653543738 : Closed e2411653543738 ∧ code e2411653543738 = 11207746565946 := by decide
theorem cert_e2411653543738 : check e2411653543738 [[],[],[.under]] .smaller = true := by decide
def e2411653543822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2411653543822 : Closed e2411653543822 ∧ code e2411653543822 = 11207746566030 := by decide
theorem cert_e2411653543822 : check e2411653543822 [[],[],[.under]] .smaller = true := by decide
def e2411653544158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2411653544158 : Closed e2411653544158 ∧ code e2411653544158 = 11207746566366 := by decide
theorem cert_e2411653544158 : check e2411653544158 [[],[],[.under]] .smaller = true := by decide
def e2411653544186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2411653544186 : Closed e2411653544186 ∧ code e2411653544186 = 11207746566394 := by decide
theorem cert_e2411653544186 : check e2411653544186 [[],[],[.under]] .smaller = true := by decide
def e2411653544366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2411653544366 : Closed e2411653544366 ∧ code e2411653544366 = 11207746566574 := by decide
theorem cert_e2411653544366 : check e2411653544366 [[],[],[.under]] .smaller = true := by decide
def e2411653544378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2411653544378 : Closed e2411653544378 ∧ code e2411653544378 = 11207746566586 := by decide
theorem cert_e2411653544378 : check e2411653544378 [[],[],[.under]] .smaller = true := by decide
def e2411653544426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2411653544426 : Closed e2411653544426 ∧ code e2411653544426 = 11207746566634 := by decide
theorem cert_e2411653544426 : check e2411653544426 [[],[],[.under]] .smaller = true := by decide
def e2411653544510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2411653544510 : Closed e2411653544510 ∧ code e2411653544510 = 11207746566718 := by decide
theorem cert_e2411653544510 : check e2411653544510 [[],[],[.under]] .smaller = true := by decide
def e2411653544558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411653544558 : Closed e2411653544558 ∧ code e2411653544558 = 11207746566766 := by decide
theorem cert_e2411653544558 : check e2411653544558 [[],[],[.under]] .smaller = true := by decide
def e2411653544570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411653544570 : Closed e2411653544570 ∧ code e2411653544570 = 11207746566778 := by decide
theorem cert_e2411653544570 : check e2411653544570 [[],[],[.under]] .smaller = true := by decide
def e2411653544858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411653544858 : Closed e2411653544858 ∧ code e2411653544858 = 11207746567066 := by decide
theorem cert_e2411653544858 : check e2411653544858 [[],[],[.under]] .smaller = true := by decide
def e2411653544902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2411653544902 : Closed e2411653544902 ∧ code e2411653544902 = 11207746567110 := by decide
theorem cert_e2411653544902 : check e2411653544902 [[],[],[.under]] .smaller = true := by decide
def e2411653545174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411653545174 : Closed e2411653545174 ∧ code e2411653545174 = 11207746567382 := by decide
theorem cert_e2411653545174 : check e2411653545174 [[],[],[.under]] .smaller = true := by decide
def e2411653545178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411653545178 : Closed e2411653545178 ∧ code e2411653545178 = 11207746567386 := by decide
theorem cert_e2411653545178 : check e2411653545178 [[],[],[.under]] .smaller = true := by decide
def e2411653545194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411653545194 : Closed e2411653545194 ∧ code e2411653545194 = 11207746567402 := by decide
theorem cert_e2411653545194 : check e2411653545194 [[],[],[.under]] .smaller = true := by decide
def e2411653545270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411653545270 : Closed e2411653545270 ∧ code e2411653545270 = 11207746567478 := by decide
theorem cert_e2411653545270 : check e2411653545270 [[],[],[.under]] .smaller = true := by decide
def e2411653545274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411653545274 : Closed e2411653545274 ∧ code e2411653545274 = 11207746567482 := by decide
theorem cert_e2411653545274 : check e2411653545274 [[],[],[.under]] .smaller = true := by decide
def e2411653545370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411653545370 : Closed e2411653545370 ∧ code e2411653545370 = 11207746567578 := by decide
theorem cert_e2411653545370 : check e2411653545370 [[],[],[.under]] .smaller = true := by decide
def e2411653545526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411653545526 : Closed e2411653545526 ∧ code e2411653545526 = 11207746567734 := by decide
theorem cert_e2411653545526 : check e2411653545526 [[],[],[.under]] .smaller = true := by decide
def e2411653545530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411653545530 : Closed e2411653545530 ∧ code e2411653545530 = 11207746567738 := by decide
theorem cert_e2411653545530 : check e2411653545530 [[],[],[.under]] .smaller = true := by decide
def e2411653545614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411653545614 : Closed e2411653545614 ∧ code e2411653545614 = 11207746567822 := by decide
theorem cert_e2411653545614 : check e2411653545614 [[],[],[.under]] .smaller = true := by decide
def e2411653545670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411653545670 : Closed e2411653545670 ∧ code e2411653545670 = 11207746567878 := by decide
theorem cert_e2411653545670 : check e2411653545670 [[],[],[.under]] .smaller = true := by decide
def e2411653548910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411653548910 : Closed e2411653548910 ∧ code e2411653548910 = 11207746571118 := by decide
theorem cert_e2411653548910 : check e2411653548910 [[],[],[.under]] .smaller = true := by decide
def e2411653548918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411653548918 : Closed e2411653548918 ∧ code e2411653548918 = 11207746571126 := by decide
theorem cert_e2411653548918 : check e2411653548918 [[],[],[.under]] .smaller = true := by decide
def e2411653548974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411653548974 : Closed e2411653548974 ∧ code e2411653548974 = 11207746571182 := by decide
theorem cert_e2411653548974 : check e2411653548974 [[],[],[.under]] .smaller = true := by decide
def e2411653548986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411653548986 : Closed e2411653548986 ∧ code e2411653548986 = 11207746571194 := by decide
theorem cert_e2411653548986 : check e2411653548986 [[],[],[.under]] .smaller = true := by decide
def e2411653549014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411653549014 : Closed e2411653549014 ∧ code e2411653549014 = 11207746571222 := by decide
theorem cert_e2411653549014 : check e2411653549014 [[],[],[.under]] .smaller = true := by decide
def e2411653549018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411653549018 : Closed e2411653549018 ∧ code e2411653549018 = 11207746571226 := by decide
theorem cert_e2411653549018 : check e2411653549018 [[],[],[.under]] .smaller = true := by decide
def e2411653549294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411653549294 : Closed e2411653549294 ∧ code e2411653549294 = 11207746571502 := by decide
theorem cert_e2411653549294 : check e2411653549294 [[],[],[.under]] .smaller = true := by decide
def e2411653549302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411653549302 : Closed e2411653549302 ∧ code e2411653549302 = 11207746571510 := by decide
theorem cert_e2411653549302 : check e2411653549302 [[],[],[.under]] .smaller = true := by decide
def e2411653549630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2411653549630 : Closed e2411653549630 ∧ code e2411653549630 = 11207746571838 := by decide
theorem cert_e2411653549630 : check e2411653549630 [[],[],[.under]] .smaller = true := by decide
def e2411653549678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411653549678 : Closed e2411653549678 ∧ code e2411653549678 = 11207746571886 := by decide
theorem cert_e2411653549678 : check e2411653549678 [[],[],[.under]] .smaller = true := by decide
def e2411653549690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411653549690 : Closed e2411653549690 ∧ code e2411653549690 = 11207746571898 := by decide
theorem cert_e2411653549690 : check e2411653549690 [[],[],[.under]] .smaller = true := by decide
def e2411653549878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411653549878 : Closed e2411653549878 ∧ code e2411653549878 = 11207746572086 := by decide
theorem cert_e2411653549878 : check e2411653549878 [[],[],[.under]] .smaller = true := by decide
def e2411653549882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411653549882 : Closed e2411653549882 ∧ code e2411653549882 = 11207746572090 := by decide
theorem cert_e2411653549882 : check e2411653549882 [[],[],[.under]] .smaller = true := by decide
def e2411653549966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2411653549966 : Closed e2411653549966 ∧ code e2411653549966 = 11207746572174 := by decide
theorem cert_e2411653549966 : check e2411653549966 [[],[],[.under]] .smaller = true := by decide
def e2411653555630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2411653555630 : Closed e2411653555630 ∧ code e2411653555630 = 11207746577838 := by decide
theorem cert_e2411653555630 : check e2411653555630 [[],[],[.under]] .smaller = true := by decide
def e2411653555642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2411653555642 : Closed e2411653555642 ∧ code e2411653555642 = 11207746577850 := by decide
theorem cert_e2411653555642 : check e2411653555642 [[],[],[.under]] .smaller = true := by decide
def e2411653555690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2411653555690 : Closed e2411653555690 ∧ code e2411653555690 = 11207746577898 := by decide
theorem cert_e2411653555690 : check e2411653555690 [[],[],[.under]] .smaller = true := by decide
def e2411653555774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2411653555774 : Closed e2411653555774 ∧ code e2411653555774 = 11207746577982 := by decide
theorem cert_e2411653555774 : check e2411653555774 [[],[],[.under]] .smaller = true := by decide
def e2411653555822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411653555822 : Closed e2411653555822 ∧ code e2411653555822 = 11207746578030 := by decide
theorem cert_e2411653555822 : check e2411653555822 [[],[],[.under]] .smaller = true := by decide
def e2411653555834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411653555834 : Closed e2411653555834 ∧ code e2411653555834 = 11207746578042 := by decide
theorem cert_e2411653555834 : check e2411653555834 [[],[],[.under]] .smaller = true := by decide
def e2411653556122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411653556122 : Closed e2411653556122 ∧ code e2411653556122 = 11207746578330 := by decide
theorem cert_e2411653556122 : check e2411653556122 [[],[],[.under]] .smaller = true := by decide
def e2411653556166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2411653556166 : Closed e2411653556166 ∧ code e2411653556166 = 11207746578374 := by decide
theorem cert_e2411653556166 : check e2411653556166 [[],[],[.under]] .smaller = true := by decide
def e2411653558998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411653558998 : Closed e2411653558998 ∧ code e2411653558998 = 11207746581206 := by decide
theorem cert_e2411653558998 : check e2411653558998 [[],[],[.under]] .smaller = true := by decide
def e2411653559002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411653559002 : Closed e2411653559002 ∧ code e2411653559002 = 11207746581210 := by decide
theorem cert_e2411653559002 : check e2411653559002 [[],[],[.under]] .smaller = true := by decide
def e2411653559018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411653559018 : Closed e2411653559018 ∧ code e2411653559018 = 11207746581226 := by decide
theorem cert_e2411653559018 : check e2411653559018 [[],[],[.under]] .smaller = true := by decide
def e2411653559094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411653559094 : Closed e2411653559094 ∧ code e2411653559094 = 11207746581302 := by decide
theorem cert_e2411653559094 : check e2411653559094 [[],[],[.under]] .smaller = true := by decide
def e2411653559098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411653559098 : Closed e2411653559098 ∧ code e2411653559098 = 11207746581306 := by decide
theorem cert_e2411653559098 : check e2411653559098 [[],[],[.under]] .smaller = true := by decide
def e2411653559194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411653559194 : Closed e2411653559194 ∧ code e2411653559194 = 11207746581402 := by decide
theorem cert_e2411653559194 : check e2411653559194 [[],[],[.under]] .smaller = true := by decide
def e2411653560718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411653560718 : Closed e2411653560718 ∧ code e2411653560718 = 11207746582926 := by decide
theorem cert_e2411653560718 : check e2411653560718 [[],[],[.under]] .smaller = true := by decide
def e2411653560774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411653560774 : Closed e2411653560774 ∧ code e2411653560774 = 11207746582982 := by decide
theorem cert_e2411653560774 : check e2411653560774 [[],[],[.under]] .smaller = true := by decide
def e2411653673326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2411653673326 : Closed e2411653673326 ∧ code e2411653673326 = 11207746695534 := by decide
theorem cert_e2411653673326 : check e2411653673326 [[],[],[.under]] .smaller = true := by decide
def e2411653673334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2411653673334 : Closed e2411653673334 ∧ code e2411653673334 = 11207746695542 := by decide
theorem cert_e2411653673334 : check e2411653673334 [[],[],[.under]] .smaller = true := by decide
def e2411653674542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411653674542 : Closed e2411653674542 ∧ code e2411653674542 = 11207746696750 := by decide
theorem cert_e2411653674542 : check e2411653674542 [[],[],[.under]] .smaller = true := by decide
def e2411653674722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411653674722 : Closed e2411653674722 ∧ code e2411653674722 = 11207746696930 := by decide
theorem cert_e2411653674722 : check e2411653674722 [[],[],[.under]] .smaller = true := by decide
def e2411653674734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2411653674734 : Closed e2411653674734 ∧ code e2411653674734 = 11207746696942 := by decide
theorem cert_e2411653674734 : check e2411653674734 [[],[],[.under]] .smaller = true := by decide
def e2411653674774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411653674774 : Closed e2411653674774 ∧ code e2411653674774 = 11207746696982 := by decide
theorem cert_e2411653674774 : check e2411653674774 [[],[],[.under]] .smaller = true := by decide
def e2411653674850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411653674850 : Closed e2411653674850 ∧ code e2411653674850 = 11207746697058 := by decide
theorem cert_e2411653674850 : check e2411653674850 [[],[],[.under]] .smaller = true := by decide
def e2411653674862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2411653674862 : Closed e2411653674862 ∧ code e2411653674862 = 11207746697070 := by decide
theorem cert_e2411653674862 : check e2411653674862 [[],[],[.under]] .smaller = true := by decide
def e2411653674870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2411653674870 : Closed e2411653674870 ∧ code e2411653674870 = 11207746697078 := by decide
theorem cert_e2411653674870 : check e2411653674870 [[],[],[.under]] .smaller = true := by decide
def e2411653675182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2411653675182 : Closed e2411653675182 ∧ code e2411653675182 = 11207746697390 := by decide
theorem cert_e2411653675182 : check e2411653675182 [[],[],[.under]] .smaller = true := by decide
def e2411653675194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2411653675194 : Closed e2411653675194 ∧ code e2411653675194 = 11207746697402 := by decide
theorem cert_e2411653675194 : check e2411653675194 [[],[],[.under]] .smaller = true := by decide
def e2411653675566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411653675566 : Closed e2411653675566 ∧ code e2411653675566 = 11207746697774 := by decide
theorem cert_e2411653675566 : check e2411653675566 [[],[],[.under]] .smaller = true := by decide
def e2411653675746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411653675746 : Closed e2411653675746 ∧ code e2411653675746 = 11207746697954 := by decide
theorem cert_e2411653675746 : check e2411653675746 [[],[],[.under]] .smaller = true := by decide
def e2411653675758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2411653675758 : Closed e2411653675758 ∧ code e2411653675758 = 11207746697966 := by decide
theorem cert_e2411653675758 : check e2411653675758 [[],[],[.under]] .smaller = true := by decide
def e2411653675914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411653675914 : Closed e2411653675914 ∧ code e2411653675914 = 11207746698122 := by decide
theorem cert_e2411653675914 : check e2411653675914 [[],[],[.under]] .smaller = true := by decide
def e2411653675938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411653675938 : Closed e2411653675938 ∧ code e2411653675938 = 11207746698146 := by decide
theorem cert_e2411653675938 : check e2411653675938 [[],[],[.under]] .smaller = true := by decide
def e2411653675950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2411653675950 : Closed e2411653675950 ∧ code e2411653675950 = 11207746698158 := by decide
theorem cert_e2411653675950 : check e2411653675950 [[],[],[.under]] .smaller = true := by decide
def e2411653675962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2411653675962 : Closed e2411653675962 ∧ code e2411653675962 = 11207746698170 := by decide
theorem cert_e2411653675962 : check e2411653675962 [[],[],[.under]] .smaller = true := by decide
def e2411653676118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2411653676118 : Closed e2411653676118 ∧ code e2411653676118 = 11207746698326 := by decide
theorem cert_e2411653676118 : check e2411653676118 [[],[],[.under]] .smaller = true := by decide
def e2411653676122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2411653676122 : Closed e2411653676122 ∧ code e2411653676122 = 11207746698330 := by decide
theorem cert_e2411653676122 : check e2411653676122 [[],[],[.under]] .smaller = true := by decide
def e2411653676310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411653676310 : Closed e2411653676310 ∧ code e2411653676310 = 11207746698518 := by decide
theorem cert_e2411653676310 : check e2411653676310 [[],[],[.under]] .smaller = true := by decide
def e2411653676386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411653676386 : Closed e2411653676386 ∧ code e2411653676386 = 11207746698594 := by decide
theorem cert_e2411653676386 : check e2411653676386 [[],[],[.under]] .smaller = true := by decide
def e2411653676398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2411653676398 : Closed e2411653676398 ∧ code e2411653676398 = 11207746698606 := by decide
theorem cert_e2411653676398 : check e2411653676398 [[],[],[.under]] .smaller = true := by decide
def e2411653676406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2411653676406 : Closed e2411653676406 ∧ code e2411653676406 = 11207746698614 := by decide
theorem cert_e2411653676406 : check e2411653676406 [[],[],[.under]] .smaller = true := by decide
def e2411653676426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411653676426 : Closed e2411653676426 ∧ code e2411653676426 = 11207746698634 := by decide
theorem cert_e2411653676426 : check e2411653676426 [[],[],[.under]] .smaller = true := by decide
def e2411653676450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411653676450 : Closed e2411653676450 ∧ code e2411653676450 = 11207746698658 := by decide
theorem cert_e2411653676450 : check e2411653676450 [[],[],[.under]] .smaller = true := by decide
def e2411653676462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2411653676462 : Closed e2411653676462 ∧ code e2411653676462 = 11207746698670 := by decide
theorem cert_e2411653676462 : check e2411653676462 [[],[],[.under]] .smaller = true := by decide
def e2411653676474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2411653676474 : Closed e2411653676474 ∧ code e2411653676474 = 11207746698682 := by decide
theorem cert_e2411653676474 : check e2411653676474 [[],[],[.under]] .smaller = true := by decide
def e2411653676502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2411653676502 : Closed e2411653676502 ∧ code e2411653676502 = 11207746698710 := by decide
theorem cert_e2411653676502 : check e2411653676502 [[],[],[.under]] .smaller = true := by decide
def e2411653676506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2411653676506 : Closed e2411653676506 ∧ code e2411653676506 = 11207746698714 := by decide
theorem cert_e2411653676506 : check e2411653676506 [[],[],[.under]] .smaller = true := by decide
def e2411653677550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2411653677550 : Closed e2411653677550 ∧ code e2411653677550 = 11207746699758 := by decide
theorem cert_e2411653677550 : check e2411653677550 [[],[],[.under]] .smaller = true := by decide
def e2411653677558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2411653677558 : Closed e2411653677558 ∧ code e2411653677558 = 11207746699766 := by decide
theorem cert_e2411653677558 : check e2411653677558 [[],[],[.under]] .smaller = true := by decide
def e2411653678318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411653678318 : Closed e2411653678318 ∧ code e2411653678318 = 11207746700526 := by decide
theorem cert_e2411653678318 : check e2411653678318 [[],[],[.under]] .smaller = true := by decide
def e2411653678326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411653678326 : Closed e2411653678326 ∧ code e2411653678326 = 11207746700534 := by decide
theorem cert_e2411653678326 : check e2411653678326 [[],[],[.under]] .smaller = true := by decide
def e2411653678878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2411653678878 : Closed e2411653678878 ∧ code e2411653678878 = 11207746701086 := by decide
theorem cert_e2411653678878 : check e2411653678878 [[],[],[.under]] .smaller = true := by decide
def e2411653678990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2411653678990 : Closed e2411653678990 ∧ code e2411653678990 = 11207746701198 := by decide
theorem cert_e2411653678990 : check e2411653678990 [[],[],[.under]] .smaller = true := by decide
def e2411653680686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2411653680686 : Closed e2411653680686 ∧ code e2411653680686 = 11207746702894 := by decide
theorem cert_e2411653680686 : check e2411653680686 [[],[],[.under]] .smaller = true := by decide
def e2411653680866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2411653680866 : Closed e2411653680866 ∧ code e2411653680866 = 11207746703074 := by decide
theorem cert_e2411653680866 : check e2411653680866 [[],[],[.under]] .smaller = true := by decide
def e2411653680878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2411653680878 : Closed e2411653680878 ∧ code e2411653680878 = 11207746703086 := by decide
theorem cert_e2411653680878 : check e2411653680878 [[],[],[.under]] .smaller = true := by decide
def e2411653680918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411653680918 : Closed e2411653680918 ∧ code e2411653680918 = 11207746703126 := by decide
theorem cert_e2411653680918 : check e2411653680918 [[],[],[.under]] .smaller = true := by decide
def e2411653680994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411653680994 : Closed e2411653680994 ∧ code e2411653680994 = 11207746703202 := by decide
theorem cert_e2411653680994 : check e2411653680994 [[],[],[.under]] .smaller = true := by decide
def e2411653681006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2411653681006 : Closed e2411653681006 ∧ code e2411653681006 = 11207746703214 := by decide
theorem cert_e2411653681006 : check e2411653681006 [[],[],[.under]] .smaller = true := by decide
def e2411653681014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2411653681014 : Closed e2411653681014 ∧ code e2411653681014 = 11207746703222 := by decide
theorem cert_e2411653681014 : check e2411653681014 [[],[],[.under]] .smaller = true := by decide
def e2411653683262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2411653683262 : Closed e2411653683262 ∧ code e2411653683262 = 11207746705470 := by decide
theorem cert_e2411653683262 : check e2411653683262 [[],[],[.under]] .smaller = true := by decide
def e2411653683682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411653683682 : Closed e2411653683682 ∧ code e2411653683682 = 11207746705890 := by decide
theorem cert_e2411653683682 : check e2411653683682 [[],[],[.under]] .smaller = true := by decide
def e2411653683694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2411653683694 : Closed e2411653683694 ∧ code e2411653683694 = 11207746705902 := by decide
theorem cert_e2411653683694 : check e2411653683694 [[],[],[.under]] .smaller = true := by decide
def e2411653684254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411653684254 : Closed e2411653684254 ∧ code e2411653684254 = 11207746706462 := by decide
theorem cert_e2411653684254 : check e2411653684254 [[],[],[.under]] .smaller = true := by decide
def e2411653684450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411653684450 : Closed e2411653684450 ∧ code e2411653684450 = 11207746706658 := by decide
theorem cert_e2411653684450 : check e2411653684450 [[],[],[.under]] .smaller = true := by decide
def e2411653684462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411653684462 : Closed e2411653684462 ∧ code e2411653684462 = 11207746706670 := by decide
theorem cert_e2411653684462 : check e2411653684462 [[],[],[.under]] .smaller = true := by decide
def e2411653684470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411653684470 : Closed e2411653684470 ∧ code e2411653684470 = 11207746706678 := by decide
theorem cert_e2411653684470 : check e2411653684470 [[],[],[.under]] .smaller = true := by decide
def e2411653685486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2411653685486 : Closed e2411653685486 ∧ code e2411653685486 = 11207746707694 := by decide
theorem cert_e2411653685486 : check e2411653685486 [[],[],[.under]] .smaller = true := by decide
def e2411653685498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2411653685498 : Closed e2411653685498 ∧ code e2411653685498 = 11207746707706 := by decide
theorem cert_e2411653685498 : check e2411653685498 [[],[],[.under]] .smaller = true := by decide
def e2411653685870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411653685870 : Closed e2411653685870 ∧ code e2411653685870 = 11207746708078 := by decide
theorem cert_e2411653685870 : check e2411653685870 [[],[],[.under]] .smaller = true := by decide
def e2411653685882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411653685882 : Closed e2411653685882 ∧ code e2411653685882 = 11207746708090 := by decide
theorem cert_e2411653685882 : check e2411653685882 [[],[],[.under]] .smaller = true := by decide
def e2411653686046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2411653686046 : Closed e2411653686046 ∧ code e2411653686046 = 11207746708254 := by decide
theorem cert_e2411653686046 : check e2411653686046 [[],[],[.under]] .smaller = true := by decide
def e2411653686214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2411653686214 : Closed e2411653686214 ∧ code e2411653686214 = 11207746708422 := by decide
theorem cert_e2411653686214 : check e2411653686214 [[],[],[.under]] .smaller = true := by decide
def e2411653686830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2411653686830 : Closed e2411653686830 ∧ code e2411653686830 = 11207746709038 := by decide
theorem cert_e2411653686830 : check e2411653686830 [[],[],[.under]] .smaller = true := by decide
def e2411653687010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2411653687010 : Closed e2411653687010 ∧ code e2411653687010 = 11207746709218 := by decide
theorem cert_e2411653687010 : check e2411653687010 [[],[],[.under]] .smaller = true := by decide
def e2411653687022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2411653687022 : Closed e2411653687022 ∧ code e2411653687022 = 11207746709230 := by decide
theorem cert_e2411653687022 : check e2411653687022 [[],[],[.under]] .smaller = true := by decide
def e2411653687178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2411653687178 : Closed e2411653687178 ∧ code e2411653687178 = 11207746709386 := by decide
theorem cert_e2411653687178 : check e2411653687178 [[],[],[.under]] .smaller = true := by decide
def e2411653687202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2411653687202 : Closed e2411653687202 ∧ code e2411653687202 = 11207746709410 := by decide
theorem cert_e2411653687202 : check e2411653687202 [[],[],[.under]] .smaller = true := by decide
def e2411653687214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2411653687214 : Closed e2411653687214 ∧ code e2411653687214 = 11207746709422 := by decide
theorem cert_e2411653687214 : check e2411653687214 [[],[],[.under]] .smaller = true := by decide
def e2411653687226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2411653687226 : Closed e2411653687226 ∧ code e2411653687226 = 11207746709434 := by decide
theorem cert_e2411653687226 : check e2411653687226 [[],[],[.under]] .smaller = true := by decide
def e2411653687358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2411653687358 : Closed e2411653687358 ∧ code e2411653687358 = 11207746709566 := by decide
theorem cert_e2411653687358 : check e2411653687358 [[],[],[.under]] .smaller = true := by decide
def e2411653687778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411653687778 : Closed e2411653687778 ∧ code e2411653687778 = 11207746709986 := by decide
theorem cert_e2411653687778 : check e2411653687778 [[],[],[.under]] .smaller = true := by decide
def e2411653687790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2411653687790 : Closed e2411653687790 ∧ code e2411653687790 = 11207746709998 := by decide
theorem cert_e2411653687790 : check e2411653687790 [[],[],[.under]] .smaller = true := by decide
def e2411653688846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2411653688846 : Closed e2411653688846 ∧ code e2411653688846 = 11207746711054 := by decide
theorem cert_e2411653688846 : check e2411653688846 [[],[],[.under]] .smaller = true := by decide
def e2411653688930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411653688930 : Closed e2411653688930 ∧ code e2411653688930 = 11207746711138 := by decide
theorem cert_e2411653688930 : check e2411653688930 [[],[],[.under]] .smaller = true := by decide
def e2411653688942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411653688942 : Closed e2411653688942 ∧ code e2411653688942 = 11207746711150 := by decide
theorem cert_e2411653688942 : check e2411653688942 [[],[],[.under]] .smaller = true := by decide
def e2411653688954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411653688954 : Closed e2411653688954 ∧ code e2411653688954 = 11207746711162 := by decide
theorem cert_e2411653688954 : check e2411653688954 [[],[],[.under]] .smaller = true := by decide
def e2411653689462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2411653689462 : Closed e2411653689462 ∧ code e2411653689462 = 11207746711670 := by decide
theorem cert_e2411653689462 : check e2411653689462 [[],[],[.under]] .smaller = true := by decide
def e2411653689466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411653689466 : Closed e2411653689466 ∧ code e2411653689466 = 11207746711674 := by decide
theorem cert_e2411653689466 : check e2411653689466 [[],[],[.under]] .smaller = true := by decide
def e2411653689654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411653689654 : Closed e2411653689654 ∧ code e2411653689654 = 11207746711862 := by decide
theorem cert_e2411653689654 : check e2411653689654 [[],[],[.under]] .smaller = true := by decide
def e2411653689658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411653689658 : Closed e2411653689658 ∧ code e2411653689658 = 11207746711866 := by decide
theorem cert_e2411653689658 : check e2411653689658 [[],[],[.under]] .smaller = true := by decide
def e2411653689742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2411653689742 : Closed e2411653689742 ∧ code e2411653689742 = 11207746711950 := by decide
theorem cert_e2411653689742 : check e2411653689742 [[],[],[.under]] .smaller = true := by decide
def e2411653689798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411653689798 : Closed e2411653689798 ∧ code e2411653689798 = 11207746712006 := by decide
theorem cert_e2411653689798 : check e2411653689798 [[],[],[.under]] .smaller = true := by decide
def e2411653690134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411653690134 : Closed e2411653690134 ∧ code e2411653690134 = 11207746712342 := by decide
theorem cert_e2411653690134 : check e2411653690134 [[],[],[.under]] .smaller = true := by decide
def e2411653690210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411653690210 : Closed e2411653690210 ∧ code e2411653690210 = 11207746712418 := by decide
theorem cert_e2411653690210 : check e2411653690210 [[],[],[.under]] .smaller = true := by decide
def e2411653690222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2411653690222 : Closed e2411653690222 ∧ code e2411653690222 = 11207746712430 := by decide
theorem cert_e2411653690222 : check e2411653690222 [[],[],[.under]] .smaller = true := by decide
def e2411653690230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2411653690230 : Closed e2411653690230 ∧ code e2411653690230 = 11207746712438 := by decide
theorem cert_e2411653690230 : check e2411653690230 [[],[],[.under]] .smaller = true := by decide
def e2411653690250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2411653690250 : Closed e2411653690250 ∧ code e2411653690250 = 11207746712458 := by decide
theorem cert_e2411653690250 : check e2411653690250 [[],[],[.under]] .smaller = true := by decide
def e2411653690274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2411653690274 : Closed e2411653690274 ∧ code e2411653690274 = 11207746712482 := by decide
theorem cert_e2411653690274 : check e2411653690274 [[],[],[.under]] .smaller = true := by decide
def e2411653690286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2411653690286 : Closed e2411653690286 ∧ code e2411653690286 = 11207746712494 := by decide
theorem cert_e2411653690286 : check e2411653690286 [[],[],[.under]] .smaller = true := by decide
def e2411653690298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2411653690298 : Closed e2411653690298 ∧ code e2411653690298 = 11207746712506 := by decide
theorem cert_e2411653690298 : check e2411653690298 [[],[],[.under]] .smaller = true := by decide
def e2411653690326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2411653690326 : Closed e2411653690326 ∧ code e2411653690326 = 11207746712534 := by decide
theorem cert_e2411653690326 : check e2411653690326 [[],[],[.under]] .smaller = true := by decide
def e2411653690330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2411653690330 : Closed e2411653690330 ∧ code e2411653690330 = 11207746712538 := by decide
theorem cert_e2411653690330 : check e2411653690330 [[],[],[.under]] .smaller = true := by decide
def e2411653690398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411653690398 : Closed e2411653690398 ∧ code e2411653690398 = 11207746712606 := by decide
theorem cert_e2411653690398 : check e2411653690398 [[],[],[.under]] .smaller = true := by decide
def e2411653690594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411653690594 : Closed e2411653690594 ∧ code e2411653690594 = 11207746712802 := by decide
theorem cert_e2411653690594 : check e2411653690594 [[],[],[.under]] .smaller = true := by decide
def e2411653690606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411653690606 : Closed e2411653690606 ∧ code e2411653690606 = 11207746712814 := by decide
theorem cert_e2411653690606 : check e2411653690606 [[],[],[.under]] .smaller = true := by decide
def e2411653690614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411653690614 : Closed e2411653690614 ∧ code e2411653690614 = 11207746712822 := by decide
theorem cert_e2411653690614 : check e2411653690614 [[],[],[.under]] .smaller = true := by decide
def e2411653690894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2411653690894 : Closed e2411653690894 ∧ code e2411653690894 = 11207746713102 := by decide
theorem cert_e2411653690894 : check e2411653690894 [[],[],[.under]] .smaller = true := by decide
def e2411653690978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411653690978 : Closed e2411653690978 ∧ code e2411653690978 = 11207746713186 := by decide
theorem cert_e2411653690978 : check e2411653690978 [[],[],[.under]] .smaller = true := by decide
def e2411653690990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411653690990 : Closed e2411653690990 ∧ code e2411653690990 = 11207746713198 := by decide
theorem cert_e2411653690990 : check e2411653690990 [[],[],[.under]] .smaller = true := by decide
def e2411653691002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411653691002 : Closed e2411653691002 ∧ code e2411653691002 = 11207746713210 := by decide
theorem cert_e2411653691002 : check e2411653691002 [[],[],[.under]] .smaller = true := by decide
def e2411653691190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411653691190 : Closed e2411653691190 ∧ code e2411653691190 = 11207746713398 := by decide
theorem cert_e2411653691190 : check e2411653691190 [[],[],[.under]] .smaller = true := by decide
def e2411653691194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411653691194 : Closed e2411653691194 ∧ code e2411653691194 = 11207746713402 := by decide
theorem cert_e2411653691194 : check e2411653691194 [[],[],[.under]] .smaller = true := by decide
def e2411653696366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411653696366 : Closed e2411653696366 ∧ code e2411653696366 = 11207746718574 := by decide
theorem cert_e2411653696366 : check e2411653696366 [[],[],[.under]] .smaller = true := by decide
def e2411653696374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411653696374 : Closed e2411653696374 ∧ code e2411653696374 = 11207746718582 := by decide
theorem cert_e2411653696374 : check e2411653696374 [[],[],[.under]] .smaller = true := by decide
end Blc.Floor43
