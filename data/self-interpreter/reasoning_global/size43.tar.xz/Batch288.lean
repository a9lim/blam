import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411624225718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e2411624225718 : Closed e2411624225718 ∧ code e2411624225718 = 11207717247926 := by decide
theorem cert_e2411624225718 : check e2411624225718 [[],[]] .smaller = true := by decide
def e2411624225750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e2411624225750 : Closed e2411624225750 ∧ code e2411624225750 = 11207717247958 := by decide
theorem cert_e2411624225750 : check e2411624225750 [[],[]] .smaller = true := by decide
def e2411624225754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e2411624225754 : Closed e2411624225754 ∧ code e2411624225754 = 11207717247962 := by decide
theorem cert_e2411624225754 : check e2411624225754 [[],[]] .smaller = true := by decide
def e2411624226142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e2411624226142 : Closed e2411624226142 ∧ code e2411624226142 = 11207717248350 := by decide
theorem cert_e2411624226142 : check e2411624226142 [[],[]] .smaller = true := by decide
def e2411624226158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2411624226158 : Closed e2411624226158 ∧ code e2411624226158 = 11207717248366 := by decide
theorem cert_e2411624226158 : check e2411624226158 [[],[]] .smaller = true := by decide
def e2411624226166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2411624226166 : Closed e2411624226166 ∧ code e2411624226166 = 11207717248374 := by decide
theorem cert_e2411624226166 : check e2411624226166 [[],[]] .smaller = true := by decide
def e2411624226170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e2411624226170 : Closed e2411624226170 ∧ code e2411624226170 = 11207717248378 := by decide
theorem cert_e2411624226170 : check e2411624226170 [[],[]] .smaller = true := by decide
def e2411624226222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2411624226222 : Closed e2411624226222 ∧ code e2411624226222 = 11207717248430 := by decide
theorem cert_e2411624226222 : check e2411624226222 [[],[]] .smaller = true := by decide
def e2411624226234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2411624226234 : Closed e2411624226234 ∧ code e2411624226234 = 11207717248442 := by decide
theorem cert_e2411624226234 : check e2411624226234 [[],[]] .smaller = true := by decide
def e2411624226262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2411624226262 : Closed e2411624226262 ∧ code e2411624226262 = 11207717248470 := by decide
theorem cert_e2411624226262 : check e2411624226262 [[],[]] .smaller = true := by decide
def e2411624226266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2411624226266 : Closed e2411624226266 ∧ code e2411624226266 = 11207717248474 := by decide
theorem cert_e2411624226266 : check e2411624226266 [[],[]] .smaller = true := by decide
def e2411624226282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e2411624226282 : Closed e2411624226282 ∧ code e2411624226282 = 11207717248490 := by decide
theorem cert_e2411624226282 : check e2411624226282 [[],[]] .smaller = true := by decide
def e2411624226486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2411624226486 : Closed e2411624226486 ∧ code e2411624226486 = 11207717248694 := by decide
theorem cert_e2411624226486 : check e2411624226486 [[],[]] .smaller = true := by decide
def e2411624226518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2411624226518 : Closed e2411624226518 ∧ code e2411624226518 = 11207717248726 := by decide
theorem cert_e2411624226518 : check e2411624226518 [[],[]] .smaller = true := by decide
def e2411624226522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2411624226522 : Closed e2411624226522 ∧ code e2411624226522 = 11207717248730 := by decide
theorem cert_e2411624226522 : check e2411624226522 [[],[]] .smaller = true := by decide
def e2411624226646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2411624226646 : Closed e2411624226646 ∧ code e2411624226646 = 11207717248854 := by decide
theorem cert_e2411624226646 : check e2411624226646 [[],[]] .smaller = true := by decide
def e2411624226650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2411624226650 : Closed e2411624226650 ∧ code e2411624226650 = 11207717248858 := by decide
theorem cert_e2411624226650 : check e2411624226650 [[],[]] .smaller = true := by decide
def e2411624226666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2411624226666 : Closed e2411624226666 ∧ code e2411624226666 = 11207717248874 := by decide
theorem cert_e2411624226666 : check e2411624226666 [[],[]] .smaller = true := by decide
def e2411624228574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e2411624228574 : Closed e2411624228574 ∧ code e2411624228574 = 11207717250782 := by decide
theorem cert_e2411624228574 : check e2411624228574 [[],[]] .smaller = true := by decide
def e2411624228598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e2411624228598 : Closed e2411624228598 ∧ code e2411624228598 = 11207717250806 := by decide
theorem cert_e2411624228598 : check e2411624228598 [[],[]] .smaller = true := by decide
def e2411624228702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e2411624228702 : Closed e2411624228702 ∧ code e2411624228702 = 11207717250910 := by decide
theorem cert_e2411624228702 : check e2411624228702 [[],[]] .smaller = true := by decide
def e2411624228718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e2411624228718 : Closed e2411624228718 ∧ code e2411624228718 = 11207717250926 := by decide
theorem cert_e2411624228718 : check e2411624228718 [[],[]] .smaller = true := by decide
def e2411624228726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e2411624228726 : Closed e2411624228726 ∧ code e2411624228726 = 11207717250934 := by decide
theorem cert_e2411624228726 : check e2411624228726 [[],[]] .smaller = true := by decide
def e2411624228730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e2411624228730 : Closed e2411624228730 ∧ code e2411624228730 = 11207717250938 := by decide
theorem cert_e2411624228730 : check e2411624228730 [[],[]] .smaller = true := by decide
def e2411624228790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e2411624228790 : Closed e2411624228790 ∧ code e2411624228790 = 11207717250998 := by decide
theorem cert_e2411624228790 : check e2411624228790 [[],[]] .smaller = true := by decide
def e2411624228822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e2411624228822 : Closed e2411624228822 ∧ code e2411624228822 = 11207717251030 := by decide
theorem cert_e2411624228822 : check e2411624228822 [[],[]] .smaller = true := by decide
def e2411624228826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e2411624228826 : Closed e2411624228826 ∧ code e2411624228826 = 11207717251034 := by decide
theorem cert_e2411624228826 : check e2411624228826 [[],[]] .smaller = true := by decide
def e2411624229342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411624229342 : Closed e2411624229342 ∧ code e2411624229342 = 11207717251550 := by decide
theorem cert_e2411624229342 : check e2411624229342 [[],[]] .smaller = true := by decide
def e2411624229366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411624229366 : Closed e2411624229366 ∧ code e2411624229366 = 11207717251574 := by decide
theorem cert_e2411624229366 : check e2411624229366 [[],[]] .smaller = true := by decide
def e2411624230110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411624230110 : Closed e2411624230110 ∧ code e2411624230110 = 11207717252318 := by decide
theorem cert_e2411624230110 : check e2411624230110 [[],[]] .smaller = true := by decide
def e2411624230126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411624230126 : Closed e2411624230126 ∧ code e2411624230126 = 11207717252334 := by decide
theorem cert_e2411624230126 : check e2411624230126 [[],[]] .smaller = true := by decide
def e2411624230134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411624230134 : Closed e2411624230134 ∧ code e2411624230134 = 11207717252342 := by decide
theorem cert_e2411624230134 : check e2411624230134 [[],[]] .smaller = true := by decide
def e2411624230138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411624230138 : Closed e2411624230138 ∧ code e2411624230138 = 11207717252346 := by decide
theorem cert_e2411624230138 : check e2411624230138 [[],[]] .smaller = true := by decide
def e2411624230518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411624230518 : Closed e2411624230518 ∧ code e2411624230518 = 11207717252726 := by decide
theorem cert_e2411624230518 : check e2411624230518 [[],[]] .smaller = true := by decide
def e2411624230710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411624230710 : Closed e2411624230710 ∧ code e2411624230710 = 11207717252918 := by decide
theorem cert_e2411624230710 : check e2411624230710 [[],[]] .smaller = true := by decide
def e2411624230714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411624230714 : Closed e2411624230714 ∧ code e2411624230714 = 11207717252922 := by decide
theorem cert_e2411624230714 : check e2411624230714 [[],[]] .smaller = true := by decide
def e2411624231774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e2411624231774 : Closed e2411624231774 ∧ code e2411624231774 = 11207717253982 := by decide
theorem cert_e2411624231774 : check e2411624231774 [[],[]] .smaller = true := by decide
def e2411624231790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2411624231790 : Closed e2411624231790 ∧ code e2411624231790 = 11207717253998 := by decide
theorem cert_e2411624231790 : check e2411624231790 [[],[]] .smaller = true := by decide
def e2411624231798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2411624231798 : Closed e2411624231798 ∧ code e2411624231798 = 11207717254006 := by decide
theorem cert_e2411624231798 : check e2411624231798 [[],[]] .smaller = true := by decide
def e2411624231802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e2411624231802 : Closed e2411624231802 ∧ code e2411624231802 = 11207717254010 := by decide
theorem cert_e2411624231802 : check e2411624231802 [[],[]] .smaller = true := by decide
def e2411624231854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2411624231854 : Closed e2411624231854 ∧ code e2411624231854 = 11207717254062 := by decide
theorem cert_e2411624231854 : check e2411624231854 [[],[]] .smaller = true := by decide
def e2411624231866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2411624231866 : Closed e2411624231866 ∧ code e2411624231866 = 11207717254074 := by decide
theorem cert_e2411624231866 : check e2411624231866 [[],[]] .smaller = true := by decide
def e2411624231894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2411624231894 : Closed e2411624231894 ∧ code e2411624231894 = 11207717254102 := by decide
theorem cert_e2411624231894 : check e2411624231894 [[],[]] .smaller = true := by decide
def e2411624231898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2411624231898 : Closed e2411624231898 ∧ code e2411624231898 = 11207717254106 := by decide
theorem cert_e2411624231898 : check e2411624231898 [[],[]] .smaller = true := by decide
def e2411624231914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e2411624231914 : Closed e2411624231914 ∧ code e2411624231914 = 11207717254122 := by decide
theorem cert_e2411624231914 : check e2411624231914 [[],[]] .smaller = true := by decide
def e2411624232158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411624232158 : Closed e2411624232158 ∧ code e2411624232158 = 11207717254366 := by decide
theorem cert_e2411624232158 : check e2411624232158 [[],[]] .smaller = true := by decide
def e2411624232174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411624232174 : Closed e2411624232174 ∧ code e2411624232174 = 11207717254382 := by decide
theorem cert_e2411624232174 : check e2411624232174 [[],[]] .smaller = true := by decide
def e2411624232182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411624232182 : Closed e2411624232182 ∧ code e2411624232182 = 11207717254390 := by decide
theorem cert_e2411624232182 : check e2411624232182 [[],[]] .smaller = true := by decide
def e2411624232186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411624232186 : Closed e2411624232186 ∧ code e2411624232186 = 11207717254394 := by decide
theorem cert_e2411624232186 : check e2411624232186 [[],[]] .smaller = true := by decide
def e2411624232558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411624232558 : Closed e2411624232558 ∧ code e2411624232558 = 11207717254766 := by decide
theorem cert_e2411624232558 : check e2411624232558 [[],[]] .smaller = true := by decide
def e2411624232570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411624232570 : Closed e2411624232570 ∧ code e2411624232570 = 11207717254778 := by decide
theorem cert_e2411624232570 : check e2411624232570 [[],[]] .smaller = true := by decide
def e2411624232758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411624232758 : Closed e2411624232758 ∧ code e2411624232758 = 11207717254966 := by decide
theorem cert_e2411624232758 : check e2411624232758 [[],[]] .smaller = true := by decide
def e2411624232762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411624232762 : Closed e2411624232762 ∧ code e2411624232762 = 11207717254970 := by decide
theorem cert_e2411624232762 : check e2411624232762 [[],[]] .smaller = true := by decide
def e2411624232858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411624232858 : Closed e2411624232858 ∧ code e2411624232858 = 11207717255066 := by decide
theorem cert_e2411624232858 : check e2411624232858 [[],[]] .smaller = true := by decide
def e2411624233398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2411624233398 : Closed e2411624233398 ∧ code e2411624233398 = 11207717255606 := by decide
theorem cert_e2411624233398 : check e2411624233398 [[],[]] .smaller = true := by decide
def e2411624233430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2411624233430 : Closed e2411624233430 ∧ code e2411624233430 = 11207717255638 := by decide
theorem cert_e2411624233430 : check e2411624233430 [[],[]] .smaller = true := by decide
def e2411624233434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2411624233434 : Closed e2411624233434 ∧ code e2411624233434 = 11207717255642 := by decide
theorem cert_e2411624233434 : check e2411624233434 [[],[]] .smaller = true := by decide
def e2411624233590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411624233590 : Closed e2411624233590 ∧ code e2411624233590 = 11207717255798 := by decide
theorem cert_e2411624233590 : check e2411624233590 [[],[]] .smaller = true := by decide
def e2411624233782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411624233782 : Closed e2411624233782 ∧ code e2411624233782 = 11207717255990 := by decide
theorem cert_e2411624233782 : check e2411624233782 [[],[]] .smaller = true := by decide
def e2411624233786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411624233786 : Closed e2411624233786 ∧ code e2411624233786 = 11207717255994 := by decide
theorem cert_e2411624233786 : check e2411624233786 [[],[]] .smaller = true := by decide
def e2411624234198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2411624234198 : Closed e2411624234198 ∧ code e2411624234198 = 11207717256406 := by decide
theorem cert_e2411624234198 : check e2411624234198 [[],[]] .smaller = true := by decide
def e2411624234202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2411624234202 : Closed e2411624234202 ∧ code e2411624234202 = 11207717256410 := by decide
theorem cert_e2411624234202 : check e2411624234202 [[],[]] .smaller = true := by decide
def e2411624234218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2411624234218 : Closed e2411624234218 ∧ code e2411624234218 = 11207717256426 := by decide
theorem cert_e2411624234218 : check e2411624234218 [[],[]] .smaller = true := by decide
def e2411624234294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411624234294 : Closed e2411624234294 ∧ code e2411624234294 = 11207717256502 := by decide
theorem cert_e2411624234294 : check e2411624234294 [[],[]] .smaller = true := by decide
def e2411624234298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411624234298 : Closed e2411624234298 ∧ code e2411624234298 = 11207717256506 := by decide
theorem cert_e2411624234298 : check e2411624234298 [[],[]] .smaller = true := by decide
def e2411624234394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411624234394 : Closed e2411624234394 ∧ code e2411624234394 = 11207717256602 := by decide
theorem cert_e2411624234394 : check e2411624234394 [[],[]] .smaller = true := by decide
def e2411624240862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2411624240862 : Closed e2411624240862 ∧ code e2411624240862 = 11207717263070 := by decide
theorem cert_e2411624240862 : check e2411624240862 [[],[]] .smaller = true := by decide
def e2411624240886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2411624240886 : Closed e2411624240886 ∧ code e2411624240886 = 11207717263094 := by decide
theorem cert_e2411624240886 : check e2411624240886 [[],[]] .smaller = true := by decide
def e2411624240990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2411624240990 : Closed e2411624240990 ∧ code e2411624240990 = 11207717263198 := by decide
theorem cert_e2411624240990 : check e2411624240990 [[],[]] .smaller = true := by decide
def e2411624241006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e2411624241006 : Closed e2411624241006 ∧ code e2411624241006 = 11207717263214 := by decide
theorem cert_e2411624241006 : check e2411624241006 [[],[]] .smaller = true := by decide
def e2411624241014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e2411624241014 : Closed e2411624241014 ∧ code e2411624241014 = 11207717263222 := by decide
theorem cert_e2411624241014 : check e2411624241014 [[],[]] .smaller = true := by decide
def e2411624241018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2411624241018 : Closed e2411624241018 ∧ code e2411624241018 = 11207717263226 := by decide
theorem cert_e2411624241018 : check e2411624241018 [[],[]] .smaller = true := by decide
def e2411624241078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e2411624241078 : Closed e2411624241078 ∧ code e2411624241078 = 11207717263286 := by decide
theorem cert_e2411624241078 : check e2411624241078 [[],[]] .smaller = true := by decide
def e2411624241110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2411624241110 : Closed e2411624241110 ∧ code e2411624241110 = 11207717263318 := by decide
theorem cert_e2411624241110 : check e2411624241110 [[],[]] .smaller = true := by decide
def e2411624241114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2411624241114 : Closed e2411624241114 ∧ code e2411624241114 = 11207717263322 := by decide
theorem cert_e2411624241114 : check e2411624241114 [[],[]] .smaller = true := by decide
def e2411624241630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2411624241630 : Closed e2411624241630 ∧ code e2411624241630 = 11207717263838 := by decide
theorem cert_e2411624241630 : check e2411624241630 [[],[]] .smaller = true := by decide
def e2411624241654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2411624241654 : Closed e2411624241654 ∧ code e2411624241654 = 11207717263862 := by decide
theorem cert_e2411624241654 : check e2411624241654 [[],[]] .smaller = true := by decide
def e2411624242398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2411624242398 : Closed e2411624242398 ∧ code e2411624242398 = 11207717264606 := by decide
theorem cert_e2411624242398 : check e2411624242398 [[],[]] .smaller = true := by decide
def e2411624242414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2411624242414 : Closed e2411624242414 ∧ code e2411624242414 = 11207717264622 := by decide
theorem cert_e2411624242414 : check e2411624242414 [[],[]] .smaller = true := by decide
def e2411624242422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2411624242422 : Closed e2411624242422 ∧ code e2411624242422 = 11207717264630 := by decide
theorem cert_e2411624242422 : check e2411624242422 [[],[]] .smaller = true := by decide
def e2411624242426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2411624242426 : Closed e2411624242426 ∧ code e2411624242426 = 11207717264634 := by decide
theorem cert_e2411624242426 : check e2411624242426 [[],[]] .smaller = true := by decide
def e2411624242806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2411624242806 : Closed e2411624242806 ∧ code e2411624242806 = 11207717265014 := by decide
theorem cert_e2411624242806 : check e2411624242806 [[],[]] .smaller = true := by decide
def e2411624242998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2411624242998 : Closed e2411624242998 ∧ code e2411624242998 = 11207717265206 := by decide
theorem cert_e2411624242998 : check e2411624242998 [[],[]] .smaller = true := by decide
def e2411624243002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2411624243002 : Closed e2411624243002 ∧ code e2411624243002 = 11207717265210 := by decide
theorem cert_e2411624243002 : check e2411624243002 [[],[]] .smaller = true := by decide
def e2411624254302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e2411624254302 : Closed e2411624254302 ∧ code e2411624254302 = 11207717276510 := by decide
theorem cert_e2411624254302 : check e2411624254302 [[],[]] .smaller = true := by decide
def e2411624254318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2411624254318 : Closed e2411624254318 ∧ code e2411624254318 = 11207717276526 := by decide
theorem cert_e2411624254318 : check e2411624254318 [[],[]] .smaller = true := by decide
def e2411624254326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2411624254326 : Closed e2411624254326 ∧ code e2411624254326 = 11207717276534 := by decide
theorem cert_e2411624254326 : check e2411624254326 [[],[]] .smaller = true := by decide
def e2411624254330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e2411624254330 : Closed e2411624254330 ∧ code e2411624254330 = 11207717276538 := by decide
theorem cert_e2411624254330 : check e2411624254330 [[],[]] .smaller = true := by decide
def e2411624254382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2411624254382 : Closed e2411624254382 ∧ code e2411624254382 = 11207717276590 := by decide
theorem cert_e2411624254382 : check e2411624254382 [[],[]] .smaller = true := by decide
def e2411624254394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2411624254394 : Closed e2411624254394 ∧ code e2411624254394 = 11207717276602 := by decide
theorem cert_e2411624254394 : check e2411624254394 [[],[]] .smaller = true := by decide
def e2411624254422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2411624254422 : Closed e2411624254422 ∧ code e2411624254422 = 11207717276630 := by decide
theorem cert_e2411624254422 : check e2411624254422 [[],[]] .smaller = true := by decide
def e2411624254426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2411624254426 : Closed e2411624254426 ∧ code e2411624254426 = 11207717276634 := by decide
theorem cert_e2411624254426 : check e2411624254426 [[],[]] .smaller = true := by decide
def e2411624254442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e2411624254442 : Closed e2411624254442 ∧ code e2411624254442 = 11207717276650 := by decide
theorem cert_e2411624254442 : check e2411624254442 [[],[]] .smaller = true := by decide
def e2411624254686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2411624254686 : Closed e2411624254686 ∧ code e2411624254686 = 11207717276894 := by decide
theorem cert_e2411624254686 : check e2411624254686 [[],[]] .smaller = true := by decide
def e2411624254702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2411624254702 : Closed e2411624254702 ∧ code e2411624254702 = 11207717276910 := by decide
theorem cert_e2411624254702 : check e2411624254702 [[],[]] .smaller = true := by decide
def e2411624254710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2411624254710 : Closed e2411624254710 ∧ code e2411624254710 = 11207717276918 := by decide
theorem cert_e2411624254710 : check e2411624254710 [[],[]] .smaller = true := by decide
def e2411624254714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2411624254714 : Closed e2411624254714 ∧ code e2411624254714 = 11207717276922 := by decide
theorem cert_e2411624254714 : check e2411624254714 [[],[]] .smaller = true := by decide
def e2411624255086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2411624255086 : Closed e2411624255086 ∧ code e2411624255086 = 11207717277294 := by decide
theorem cert_e2411624255086 : check e2411624255086 [[],[]] .smaller = true := by decide
def e2411624255098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2411624255098 : Closed e2411624255098 ∧ code e2411624255098 = 11207717277306 := by decide
theorem cert_e2411624255098 : check e2411624255098 [[],[]] .smaller = true := by decide
def e2411624255286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2411624255286 : Closed e2411624255286 ∧ code e2411624255286 = 11207717277494 := by decide
theorem cert_e2411624255286 : check e2411624255286 [[],[]] .smaller = true := by decide
def e2411624255290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2411624255290 : Closed e2411624255290 ∧ code e2411624255290 = 11207717277498 := by decide
theorem cert_e2411624255290 : check e2411624255290 [[],[]] .smaller = true := by decide
def e2411624255386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2411624255386 : Closed e2411624255386 ∧ code e2411624255386 = 11207717277594 := by decide
theorem cert_e2411624255386 : check e2411624255386 [[],[]] .smaller = true := by decide
def e2411624261046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2411624261046 : Closed e2411624261046 ∧ code e2411624261046 = 11207717283254 := by decide
theorem cert_e2411624261046 : check e2411624261046 [[],[]] .smaller = true := by decide
def e2411624261078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2411624261078 : Closed e2411624261078 ∧ code e2411624261078 = 11207717283286 := by decide
theorem cert_e2411624261078 : check e2411624261078 [[],[]] .smaller = true := by decide
def e2411624261082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2411624261082 : Closed e2411624261082 ∧ code e2411624261082 = 11207717283290 := by decide
theorem cert_e2411624261082 : check e2411624261082 [[],[]] .smaller = true := by decide
def e2411624261238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2411624261238 : Closed e2411624261238 ∧ code e2411624261238 = 11207717283446 := by decide
theorem cert_e2411624261238 : check e2411624261238 [[],[]] .smaller = true := by decide
def e2411624261430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2411624261430 : Closed e2411624261430 ∧ code e2411624261430 = 11207717283638 := by decide
theorem cert_e2411624261430 : check e2411624261430 [[],[]] .smaller = true := by decide
def e2411624261434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2411624261434 : Closed e2411624261434 ∧ code e2411624261434 = 11207717283642 := by decide
theorem cert_e2411624261434 : check e2411624261434 [[],[]] .smaller = true := by decide
def e2411624264406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2411624264406 : Closed e2411624264406 ∧ code e2411624264406 = 11207717286614 := by decide
theorem cert_e2411624264406 : check e2411624264406 [[],[]] .smaller = true := by decide
def e2411624264410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2411624264410 : Closed e2411624264410 ∧ code e2411624264410 = 11207717286618 := by decide
theorem cert_e2411624264410 : check e2411624264410 [[],[]] .smaller = true := by decide
def e2411624264426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2411624264426 : Closed e2411624264426 ∧ code e2411624264426 = 11207717286634 := by decide
theorem cert_e2411624264426 : check e2411624264426 [[],[]] .smaller = true := by decide
def e2411624264502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2411624264502 : Closed e2411624264502 ∧ code e2411624264502 = 11207717286710 := by decide
theorem cert_e2411624264502 : check e2411624264502 [[],[]] .smaller = true := by decide
def e2411624264506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2411624264506 : Closed e2411624264506 ∧ code e2411624264506 = 11207717286714 := by decide
theorem cert_e2411624264506 : check e2411624264506 [[],[]] .smaller = true := by decide
def e2411624264602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2411624264602 : Closed e2411624264602 ∧ code e2411624264602 = 11207717286810 := by decide
theorem cert_e2411624264602 : check e2411624264602 [[],[]] .smaller = true := by decide
def e2411624489838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e2411624489838 : Closed e2411624489838 ∧ code e2411624489838 = 11207717512046 := by decide
theorem cert_e2411624489838 : check e2411624489838 [[],[]] .smaller = true := by decide
def e2411624489846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e2411624489846 : Closed e2411624489846 ∧ code e2411624489846 = 11207717512054 := by decide
theorem cert_e2411624489846 : check e2411624489846 [[],[]] .smaller = true := by decide
def e2411624489902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e2411624489902 : Closed e2411624489902 ∧ code e2411624489902 = 11207717512110 := by decide
theorem cert_e2411624489902 : check e2411624489902 [[],[]] .smaller = true := by decide
def e2411624489914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e2411624489914 : Closed e2411624489914 ∧ code e2411624489914 = 11207717512122 := by decide
theorem cert_e2411624489914 : check e2411624489914 [[],[]] .smaller = true := by decide
def e2411624489942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e2411624489942 : Closed e2411624489942 ∧ code e2411624489942 = 11207717512150 := by decide
theorem cert_e2411624489942 : check e2411624489942 [[],[]] .smaller = true := by decide
def e2411624489946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e2411624489946 : Closed e2411624489946 ∧ code e2411624489946 = 11207717512154 := by decide
theorem cert_e2411624489946 : check e2411624489946 [[],[]] .smaller = true := by decide
def e2411624491246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411624491246 : Closed e2411624491246 ∧ code e2411624491246 = 11207717513454 := by decide
theorem cert_e2411624491246 : check e2411624491246 [[],[]] .smaller = true := by decide
def e2411624491254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411624491254 : Closed e2411624491254 ∧ code e2411624491254 = 11207717513462 := by decide
theorem cert_e2411624491254 : check e2411624491254 [[],[]] .smaller = true := by decide
def e2411624491806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411624491806 : Closed e2411624491806 ∧ code e2411624491806 = 11207717514014 := by decide
theorem cert_e2411624491806 : check e2411624491806 [[],[]] .smaller = true := by decide
def e2411624491918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411624491918 : Closed e2411624491918 ∧ code e2411624491918 = 11207717514126 := by decide
theorem cert_e2411624491918 : check e2411624491918 [[],[]] .smaller = true := by decide
def e2411624491966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 4))))))))
theorem wire_e2411624491966 : Closed e2411624491966 ∧ code e2411624491966 = 11207717514174 := by decide
theorem cert_e2411624491966 : check e2411624491966 [[],[]] .three = true := by decide
def e2411624492014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 2))))))))
theorem wire_e2411624492014 : Closed e2411624492014 ∧ code e2411624492014 = 11207717514222 := by decide
theorem cert_e2411624492014 : check e2411624492014 [[],[]] .three = true := by decide
def e2411624492142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411624492142 : Closed e2411624492142 ∧ code e2411624492142 = 11207717514350 := by decide
theorem cert_e2411624492142 : check e2411624492142 [[],[]] .smaller = true := by decide
def e2411624492154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411624492154 : Closed e2411624492154 ∧ code e2411624492154 = 11207717514362 := by decide
theorem cert_e2411624492154 : check e2411624492154 [[],[]] .smaller = true := by decide
def e2411624492318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411624492318 : Closed e2411624492318 ∧ code e2411624492318 = 11207717514526 := by decide
theorem cert_e2411624492318 : check e2411624492318 [[],[]] .smaller = true := by decide
def e2411624492478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 4))))))))
theorem wire_e2411624492478 : Closed e2411624492478 ∧ code e2411624492478 = 11207717514686 := by decide
theorem cert_e2411624492478 : check e2411624492478 [[],[]] .three = true := by decide
def e2411624492486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411624492486 : Closed e2411624492486 ∧ code e2411624492486 = 11207717514694 := by decide
theorem cert_e2411624492486 : check e2411624492486 [[],[]] .smaller = true := by decide
def e2411624492534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 1))))))))
theorem wire_e2411624492534 : Closed e2411624492534 ∧ code e2411624492534 = 11207717514742 := by decide
theorem cert_e2411624492534 : check e2411624492534 [[],[]] .three = true := by decide
def e2411624492598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411624492598 : Closed e2411624492598 ∧ code e2411624492598 = 11207717514806 := by decide
theorem cert_e2411624492598 : check e2411624492598 [[],[]] .smaller = true := by decide
def e2411624492602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411624492602 : Closed e2411624492602 ∧ code e2411624492602 = 11207717514810 := by decide
theorem cert_e2411624492602 : check e2411624492602 [[],[]] .smaller = true := by decide
def e2411624492686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411624492686 : Closed e2411624492686 ∧ code e2411624492686 = 11207717514894 := by decide
theorem cert_e2411624492686 : check e2411624492686 [[],[]] .smaller = true := by decide
def e2411624492734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 4))))))))
theorem wire_e2411624492734 : Closed e2411624492734 ∧ code e2411624492734 = 11207717514942 := by decide
theorem cert_e2411624492734 : check e2411624492734 [[],[]] .three = true := by decide
def e2411624492742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411624492742 : Closed e2411624492742 ∧ code e2411624492742 = 11207717514950 := by decide
theorem cert_e2411624492742 : check e2411624492742 [[],[]] .smaller = true := by decide
def e2411624492794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 4)) (.var 0))))))))
theorem wire_e2411624492794 : Closed e2411624492794 ∧ code e2411624492794 = 11207717515002 := by decide
theorem cert_e2411624492794 : check e2411624492794 [[],[]] .three = true := by decide
def e2411624492974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 2))))))))
theorem wire_e2411624492974 : Closed e2411624492974 ∧ code e2411624492974 = 11207717515182 := by decide
theorem cert_e2411624492974 : check e2411624492974 [[],[]] .three = true := by decide
def e2411624492982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 1))))))))
theorem wire_e2411624492982 : Closed e2411624492982 ∧ code e2411624492982 = 11207717515190 := by decide
theorem cert_e2411624492982 : check e2411624492982 [[],[]] .three = true := by decide
def e2411624492986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 2)) (.var 0))))))))
theorem wire_e2411624492986 : Closed e2411624492986 ∧ code e2411624492986 = 11207717515194 := by decide
theorem cert_e2411624492986 : check e2411624492986 [[],[]] .three = true := by decide
def e2411624493486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e2411624493486 : Closed e2411624493486 ∧ code e2411624493486 = 11207717515694 := by decide
theorem cert_e2411624493486 : check e2411624493486 [[],[]] .smaller = true := by decide
def e2411624493498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e2411624493498 : Closed e2411624493498 ∧ code e2411624493498 = 11207717515706 := by decide
theorem cert_e2411624493498 : check e2411624493498 [[],[]] .smaller = true := by decide
def e2411624493546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e2411624493546 : Closed e2411624493546 ∧ code e2411624493546 = 11207717515754 := by decide
theorem cert_e2411624493546 : check e2411624493546 [[],[]] .smaller = true := by decide
def e2411624494190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411624494190 : Closed e2411624494190 ∧ code e2411624494190 = 11207717516398 := by decide
theorem cert_e2411624494190 : check e2411624494190 [[],[]] .smaller = true := by decide
def e2411624494202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411624494202 : Closed e2411624494202 ∧ code e2411624494202 = 11207717516410 := by decide
theorem cert_e2411624494202 : check e2411624494202 [[],[]] .smaller = true := by decide
def e2411624494366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411624494366 : Closed e2411624494366 ∧ code e2411624494366 = 11207717516574 := by decide
theorem cert_e2411624494366 : check e2411624494366 [[],[]] .smaller = true := by decide
def e2411624494526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e2411624494526 : Closed e2411624494526 ∧ code e2411624494526 = 11207717516734 := by decide
theorem cert_e2411624494526 : check e2411624494526 [[],[]] .three = true := by decide
def e2411624494534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411624494534 : Closed e2411624494534 ∧ code e2411624494534 = 11207717516742 := by decide
theorem cert_e2411624494534 : check e2411624494534 [[],[]] .smaller = true := by decide
def e2411624494582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e2411624494582 : Closed e2411624494582 ∧ code e2411624494582 = 11207717516790 := by decide
theorem cert_e2411624494582 : check e2411624494582 [[],[]] .three = true := by decide
def e2411624494782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e2411624494782 : Closed e2411624494782 ∧ code e2411624494782 = 11207717516990 := by decide
theorem cert_e2411624494782 : check e2411624494782 [[],[]] .three = true := by decide
def e2411624494842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e2411624494842 : Closed e2411624494842 ∧ code e2411624494842 = 11207717517050 := by decide
theorem cert_e2411624494842 : check e2411624494842 [[],[]] .three = true := by decide
def e2411624494874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411624494874 : Closed e2411624494874 ∧ code e2411624494874 = 11207717517082 := by decide
theorem cert_e2411624494874 : check e2411624494874 [[],[]] .smaller = true := by decide
def e2411624494918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411624494918 : Closed e2411624494918 ∧ code e2411624494918 = 11207717517126 := by decide
theorem cert_e2411624494918 : check e2411624494918 [[],[]] .smaller = true := by decide
def e2411624495062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e2411624495062 : Closed e2411624495062 ∧ code e2411624495062 = 11207717517270 := by decide
theorem cert_e2411624495062 : check e2411624495062 [[],[]] .three = true := by decide
def e2411624495066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e2411624495066 : Closed e2411624495066 ∧ code e2411624495066 = 11207717517274 := by decide
theorem cert_e2411624495066 : check e2411624495066 [[],[]] .three = true := by decide
def e2411624495318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2411624495318 : Closed e2411624495318 ∧ code e2411624495318 = 11207717517526 := by decide
theorem cert_e2411624495318 : check e2411624495318 [[],[]] .smaller = true := by decide
def e2411624495322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2411624495322 : Closed e2411624495322 ∧ code e2411624495322 = 11207717517530 := by decide
theorem cert_e2411624495322 : check e2411624495322 [[],[]] .smaller = true := by decide
def e2411624495338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2411624495338 : Closed e2411624495338 ∧ code e2411624495338 = 11207717517546 := by decide
theorem cert_e2411624495338 : check e2411624495338 [[],[]] .smaller = true := by decide
def e2411624495670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411624495670 : Closed e2411624495670 ∧ code e2411624495670 = 11207717517878 := by decide
theorem cert_e2411624495670 : check e2411624495670 [[],[]] .smaller = true := by decide
end Blc.Floor43
