import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373145822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373145822 : Closed e2422373145822 ∧ code e2422373145822 = 11218466168030 := by decide
theorem cert_e2422373145822 : check e2422373145822 [[],[]] .three = true := by decide
def e2422373145838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373145838 : Closed e2422373145838 ∧ code e2422373145838 = 11218466168046 := by decide
theorem cert_e2422373145838 : check e2422373145838 [[],[]] .smaller = true := by decide
def e2422373145846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373145846 : Closed e2422373145846 ∧ code e2422373145846 = 11218466168054 := by decide
theorem cert_e2422373145846 : check e2422373145846 [[],[]] .smaller = true := by decide
def e2422373145850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373145850 : Closed e2422373145850 ∧ code e2422373145850 = 11218466168058 := by decide
theorem cert_e2422373145850 : check e2422373145850 [[],[]] .three = true := by decide
def e2422373146230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373146230 : Closed e2422373146230 ∧ code e2422373146230 = 11218466168438 := by decide
theorem cert_e2422373146230 : check e2422373146230 [[],[]] .smaller = true := by decide
def e2422373146422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 4)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373146422 : Closed e2422373146422 ∧ code e2422373146422 = 11218466168630 := by decide
theorem cert_e2422373146422 : check e2422373146422 [[],[]] .three = true := by decide
def e2422373146426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 4)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373146426 : Closed e2422373146426 ∧ code e2422373146426 = 11218466168634 := by decide
theorem cert_e2422373146426 : check e2422373146426 [[],[]] .three = true := by decide
def e2422373147614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 3)))))))
theorem wire_e2422373147614 : Closed e2422373147614 ∧ code e2422373147614 = 11218466169822 := by decide
theorem cert_e2422373147614 : check e2422373147614 [[],[]] .three = true := by decide
def e2422373147638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 5))))) (.var 1)))))))
theorem wire_e2422373147638 : Closed e2422373147638 ∧ code e2422373147638 = 11218466169846 := by decide
theorem cert_e2422373147638 : check e2422373147638 [[],[]] .three = true := by decide
def e2422373148386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))))))
theorem wire_e2422373148386 : Closed e2422373148386 ∧ code e2422373148386 = 11218466170594 := by decide
theorem cert_e2422373148386 : check e2422373148386 [[],[]] .smaller = true := by decide
def e2422373148398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 2)))))))
theorem wire_e2422373148398 : Closed e2422373148398 ∧ code e2422373148398 = 11218466170606 := by decide
theorem cert_e2422373148398 : check e2422373148398 [[],[]] .smaller = true := by decide
def e2422373148406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 1)))))))
theorem wire_e2422373148406 : Closed e2422373148406 ∧ code e2422373148406 = 11218466170614 := by decide
theorem cert_e2422373148406 : check e2422373148406 [[],[]] .smaller = true := by decide
def e2422373148410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))) (.var 0)))))))
theorem wire_e2422373148410 : Closed e2422373148410 ∧ code e2422373148410 = 11218466170618 := by decide
theorem cert_e2422373148410 : check e2422373148410 [[],[]] .three = true := by decide
def e2422373148578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))))))
theorem wire_e2422373148578 : Closed e2422373148578 ∧ code e2422373148578 = 11218466170786 := by decide
theorem cert_e2422373148578 : check e2422373148578 [[],[]] .smaller = true := by decide
def e2422373148590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 2)))))))
theorem wire_e2422373148590 : Closed e2422373148590 ∧ code e2422373148590 = 11218466170798 := by decide
theorem cert_e2422373148590 : check e2422373148590 [[],[]] .smaller = true := by decide
def e2422373148630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 1)))))))
theorem wire_e2422373148630 : Closed e2422373148630 ∧ code e2422373148630 = 11218466170838 := by decide
theorem cert_e2422373148630 : check e2422373148630 [[],[]] .smaller = true := by decide
def e2422373148650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))) (.var 0)))))))
theorem wire_e2422373148650 : Closed e2422373148650 ∧ code e2422373148650 = 11218466170858 := by decide
theorem cert_e2422373148650 : check e2422373148650 [[],[]] .three = true := by decide
def e2422373149150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373149150 : Closed e2422373149150 ∧ code e2422373149150 = 11218466171358 := by decide
theorem cert_e2422373149150 : check e2422373149150 [[],[]] .three = true := by decide
def e2422373149174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373149174 : Closed e2422373149174 ∧ code e2422373149174 = 11218466171382 := by decide
theorem cert_e2422373149174 : check e2422373149174 [[],[]] .three = true := by decide
def e2422373149934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373149934 : Closed e2422373149934 ∧ code e2422373149934 = 11218466172142 := by decide
theorem cert_e2422373149934 : check e2422373149934 [[],[]] .smaller = true := by decide
def e2422373149942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373149942 : Closed e2422373149942 ∧ code e2422373149942 = 11218466172150 := by decide
theorem cert_e2422373149942 : check e2422373149942 [[],[]] .smaller = true := by decide
def e2422373150270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 4))))))))
theorem wire_e2422373150270 : Closed e2422373150270 ∧ code e2422373150270 = 11218466172478 := by decide
theorem cert_e2422373150270 : check e2422373150270 [[],[]] .three = true := by decide
def e2422373150318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373150318 : Closed e2422373150318 ∧ code e2422373150318 = 11218466172526 := by decide
theorem cert_e2422373150318 : check e2422373150318 [[],[]] .smaller = true := by decide
def e2422373150330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373150330 : Closed e2422373150330 ∧ code e2422373150330 = 11218466172538 := by decide
theorem cert_e2422373150330 : check e2422373150330 [[],[]] .smaller = true := by decide
def e2422373150518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373150518 : Closed e2422373150518 ∧ code e2422373150518 = 11218466172726 := by decide
theorem cert_e2422373150518 : check e2422373150518 [[],[]] .smaller = true := by decide
def e2422373150522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373150522 : Closed e2422373150522 ∧ code e2422373150522 = 11218466172730 := by decide
theorem cert_e2422373150522 : check e2422373150522 [[],[]] .smaller = true := by decide
def e2422373150606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 4)))) (.lam (.var 2))))))))
theorem wire_e2422373150606 : Closed e2422373150606 ∧ code e2422373150606 = 11218466172814 := by decide
theorem cert_e2422373150606 : check e2422373150606 [[],[]] .three = true := by decide
def e2422373151198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 3)))))))
theorem wire_e2422373151198 : Closed e2422373151198 ∧ code e2422373151198 = 11218466173406 := by decide
theorem cert_e2422373151198 : check e2422373151198 [[],[]] .three = true := by decide
def e2422373151214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 3))))) (.var 2)))))))
theorem wire_e2422373151214 : Closed e2422373151214 ∧ code e2422373151214 = 11218466173422 := by decide
theorem cert_e2422373151214 : check e2422373151214 [[],[]] .smaller = true := by decide
def e2422373151222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 1)))))))
theorem wire_e2422373151222 : Closed e2422373151222 ∧ code e2422373151222 = 11218466173430 := by decide
theorem cert_e2422373151222 : check e2422373151222 [[],[]] .smaller = true := by decide
def e2422373151226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 5))))) (.var 0)))))))
theorem wire_e2422373151226 : Closed e2422373151226 ∧ code e2422373151226 = 11218466173434 := by decide
theorem cert_e2422373151226 : check e2422373151226 [[],[]] .three = true := by decide
def e2422373151582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 3)))))))
theorem wire_e2422373151582 : Closed e2422373151582 ∧ code e2422373151582 = 11218466173790 := by decide
theorem cert_e2422373151582 : check e2422373151582 [[],[]] .three = true := by decide
def e2422373151586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))))))
theorem wire_e2422373151586 : Closed e2422373151586 ∧ code e2422373151586 = 11218466173794 := by decide
theorem cert_e2422373151586 : check e2422373151586 [[],[]] .smaller = true := by decide
def e2422373151598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 2)))))))
theorem wire_e2422373151598 : Closed e2422373151598 ∧ code e2422373151598 = 11218466173806 := by decide
theorem cert_e2422373151598 : check e2422373151598 [[],[]] .smaller = true := by decide
def e2422373151610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))) (.var 0)))))))
theorem wire_e2422373151610 : Closed e2422373151610 ∧ code e2422373151610 = 11218466173818 := by decide
theorem cert_e2422373151610 : check e2422373151610 [[],[]] .smaller = true := by decide
def e2422373151650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))))))
theorem wire_e2422373151650 : Closed e2422373151650 ∧ code e2422373151650 = 11218466173858 := by decide
theorem cert_e2422373151650 : check e2422373151650 [[],[]] .smaller = true := by decide
def e2422373151662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 2)))))))
theorem wire_e2422373151662 : Closed e2422373151662 ∧ code e2422373151662 = 11218466173870 := by decide
theorem cert_e2422373151662 : check e2422373151662 [[],[]] .smaller = true := by decide
def e2422373151722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))) (.var 0)))))))
theorem wire_e2422373151722 : Closed e2422373151722 ∧ code e2422373151722 = 11218466173930 := by decide
theorem cert_e2422373151722 : check e2422373151722 [[],[]] .smaller = true := by decide
def e2422373151966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373151966 : Closed e2422373151966 ∧ code e2422373151966 = 11218466174174 := by decide
theorem cert_e2422373151966 : check e2422373151966 [[],[]] .three = true := by decide
def e2422373151982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373151982 : Closed e2422373151982 ∧ code e2422373151982 = 11218466174190 := by decide
theorem cert_e2422373151982 : check e2422373151982 [[],[]] .smaller = true := by decide
def e2422373151990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373151990 : Closed e2422373151990 ∧ code e2422373151990 = 11218466174198 := by decide
theorem cert_e2422373151990 : check e2422373151990 [[],[]] .smaller = true := by decide
def e2422373151994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373151994 : Closed e2422373151994 ∧ code e2422373151994 = 11218466174202 := by decide
theorem cert_e2422373151994 : check e2422373151994 [[],[]] .three = true := by decide
def e2422373152318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 4))))))))
theorem wire_e2422373152318 : Closed e2422373152318 ∧ code e2422373152318 = 11218466174526 := by decide
theorem cert_e2422373152318 : check e2422373152318 [[],[]] .three = true := by decide
def e2422373152366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373152366 : Closed e2422373152366 ∧ code e2422373152366 = 11218466174574 := by decide
theorem cert_e2422373152366 : check e2422373152366 [[],[]] .smaller = true := by decide
def e2422373152378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373152378 : Closed e2422373152378 ∧ code e2422373152378 = 11218466174586 := by decide
theorem cert_e2422373152378 : check e2422373152378 [[],[]] .smaller = true := by decide
def e2422373152542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 3))))))))
theorem wire_e2422373152542 : Closed e2422373152542 ∧ code e2422373152542 = 11218466174750 := by decide
theorem cert_e2422373152542 : check e2422373152542 [[],[]] .smaller = true := by decide
def e2422373152654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 2))))))))
theorem wire_e2422373152654 : Closed e2422373152654 ∧ code e2422373152654 = 11218466174862 := by decide
theorem cert_e2422373152654 : check e2422373152654 [[],[]] .smaller = true := by decide
def e2422373152666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373152666 : Closed e2422373152666 ∧ code e2422373152666 = 11218466174874 := by decide
theorem cert_e2422373152666 : check e2422373152666 [[],[]] .smaller = true := by decide
def e2422373152710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 4)))) (.lam (.var 1))))))))
theorem wire_e2422373152710 : Closed e2422373152710 ∧ code e2422373152710 = 11218466174918 := by decide
theorem cert_e2422373152710 : check e2422373152710 [[],[]] .three = true := by decide
def e2422373152734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 4)))) (.var 3)))))))
theorem wire_e2422373152734 : Closed e2422373152734 ∧ code e2422373152734 = 11218466174942 := by decide
theorem cert_e2422373152734 : check e2422373152734 [[],[]] .three = true := by decide
def e2422373153014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 1)))))))
theorem wire_e2422373153014 : Closed e2422373153014 ∧ code e2422373153014 = 11218466175222 := by decide
theorem cert_e2422373153014 : check e2422373153014 [[],[]] .smaller = true := by decide
def e2422373153206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422373153206 : Closed e2422373153206 ∧ code e2422373153206 = 11218466175414 := by decide
theorem cert_e2422373153206 : check e2422373153206 [[],[]] .smaller = true := by decide
def e2422373153210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373153210 : Closed e2422373153210 ∧ code e2422373153210 = 11218466175418 := by decide
theorem cert_e2422373153210 : check e2422373153210 [[],[]] .smaller = true := by decide
def e2422373153238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422373153238 : Closed e2422373153238 ∧ code e2422373153238 = 11218466175446 := by decide
theorem cert_e2422373153238 : check e2422373153238 [[],[]] .smaller = true := by decide
def e2422373153258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373153258 : Closed e2422373153258 ∧ code e2422373153258 = 11218466175466 := by decide
theorem cert_e2422373153258 : check e2422373153258 [[],[]] .smaller = true := by decide
def e2422373153398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373153398 : Closed e2422373153398 ∧ code e2422373153398 = 11218466175606 := by decide
theorem cert_e2422373153398 : check e2422373153398 [[],[]] .smaller = true := by decide
def e2422373153590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373153590 : Closed e2422373153590 ∧ code e2422373153590 = 11218466175798 := by decide
theorem cert_e2422373153590 : check e2422373153590 [[],[]] .smaller = true := by decide
def e2422373153594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373153594 : Closed e2422373153594 ∧ code e2422373153594 = 11218466175802 := by decide
theorem cert_e2422373153594 : check e2422373153594 [[],[]] .smaller = true := by decide
def e2422373153678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 2))))))))
theorem wire_e2422373153678 : Closed e2422373153678 ∧ code e2422373153678 = 11218466175886 := by decide
theorem cert_e2422373153678 : check e2422373153678 [[],[]] .smaller = true := by decide
def e2422373153690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373153690 : Closed e2422373153690 ∧ code e2422373153690 = 11218466175898 := by decide
theorem cert_e2422373153690 : check e2422373153690 [[],[]] .smaller = true := by decide
def e2422373153758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 3)))))))
theorem wire_e2422373153758 : Closed e2422373153758 ∧ code e2422373153758 = 11218466175966 := by decide
theorem cert_e2422373153758 : check e2422373153758 [[],[]] .three = true := by decide
def e2422373153774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 4)))) (.var 2)))))))
theorem wire_e2422373153774 : Closed e2422373153774 ∧ code e2422373153774 = 11218466175982 := by decide
theorem cert_e2422373153774 : check e2422373153774 [[],[]] .three = true := by decide
def e2422373153910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373153910 : Closed e2422373153910 ∧ code e2422373153910 = 11218466176118 := by decide
theorem cert_e2422373153910 : check e2422373153910 [[],[]] .three = true := by decide
def e2422373153914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373153914 : Closed e2422373153914 ∧ code e2422373153914 = 11218466176122 := by decide
theorem cert_e2422373153914 : check e2422373153914 [[],[]] .three = true := by decide
def e2422373154006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e2422373154006 : Closed e2422373154006 ∧ code e2422373154006 = 11218466176214 := by decide
theorem cert_e2422373154006 : check e2422373154006 [[],[]] .three = true := by decide
def e2422373154010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422373154010 : Closed e2422373154010 ∧ code e2422373154010 = 11218466176218 := by decide
theorem cert_e2422373154010 : check e2422373154010 [[],[]] .three = true := by decide
def e2422373154026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422373154026 : Closed e2422373154026 ∧ code e2422373154026 = 11218466176234 := by decide
theorem cert_e2422373154026 : check e2422373154026 [[],[]] .three = true := by decide
def e2422373154102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373154102 : Closed e2422373154102 ∧ code e2422373154102 = 11218466176310 := by decide
theorem cert_e2422373154102 : check e2422373154102 [[],[]] .three = true := by decide
def e2422373154106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373154106 : Closed e2422373154106 ∧ code e2422373154106 = 11218466176314 := by decide
theorem cert_e2422373154106 : check e2422373154106 [[],[]] .three = true := by decide
def e2422373154190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373154190 : Closed e2422373154190 ∧ code e2422373154190 = 11218466176398 := by decide
theorem cert_e2422373154190 : check e2422373154190 [[],[]] .three = true := by decide
def e2422373154246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373154246 : Closed e2422373154246 ∧ code e2422373154246 = 11218466176454 := by decide
theorem cert_e2422373154246 : check e2422373154246 [[],[]] .three = true := by decide
def e2422373154270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 2)))) (.var 3)))))))
theorem wire_e2422373154270 : Closed e2422373154270 ∧ code e2422373154270 = 11218466176478 := by decide
theorem cert_e2422373154270 : check e2422373154270 [[],[]] .three = true := by decide
def e2422373154286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 3)))) (.var 2)))))))
theorem wire_e2422373154286 : Closed e2422373154286 ∧ code e2422373154286 = 11218466176494 := by decide
theorem cert_e2422373154286 : check e2422373154286 [[],[]] .three = true := by decide
def e2422373154294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 4)))) (.var 1)))))))
theorem wire_e2422373154294 : Closed e2422373154294 ∧ code e2422373154294 = 11218466176502 := by decide
theorem cert_e2422373154294 : check e2422373154294 [[],[]] .three = true := by decide
def e2422373157742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422373157742 : Closed e2422373157742 ∧ code e2422373157742 = 11218466179950 := by decide
theorem cert_e2422373157742 : check e2422373157742 [[],[]] .smaller = true := by decide
def e2422373157750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422373157750 : Closed e2422373157750 ∧ code e2422373157750 = 11218466179958 := by decide
theorem cert_e2422373157750 : check e2422373157750 [[],[]] .smaller = true := by decide
def e2422373157806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422373157806 : Closed e2422373157806 ∧ code e2422373157806 = 11218466180014 := by decide
theorem cert_e2422373157806 : check e2422373157806 [[],[]] .smaller = true := by decide
def e2422373157818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422373157818 : Closed e2422373157818 ∧ code e2422373157818 = 11218466180026 := by decide
theorem cert_e2422373157818 : check e2422373157818 [[],[]] .smaller = true := by decide
def e2422373157846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422373157846 : Closed e2422373157846 ∧ code e2422373157846 = 11218466180054 := by decide
theorem cert_e2422373157846 : check e2422373157846 [[],[]] .smaller = true := by decide
def e2422373157850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422373157850 : Closed e2422373157850 ∧ code e2422373157850 = 11218466180058 := by decide
theorem cert_e2422373157850 : check e2422373157850 [[],[]] .smaller = true := by decide
def e2422373158126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373158126 : Closed e2422373158126 ∧ code e2422373158126 = 11218466180334 := by decide
theorem cert_e2422373158126 : check e2422373158126 [[],[]] .smaller = true := by decide
def e2422373158134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373158134 : Closed e2422373158134 ∧ code e2422373158134 = 11218466180342 := by decide
theorem cert_e2422373158134 : check e2422373158134 [[],[]] .smaller = true := by decide
def e2422373158510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373158510 : Closed e2422373158510 ∧ code e2422373158510 = 11218466180718 := by decide
theorem cert_e2422373158510 : check e2422373158510 [[],[]] .smaller = true := by decide
def e2422373158522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373158522 : Closed e2422373158522 ∧ code e2422373158522 = 11218466180730 := by decide
theorem cert_e2422373158522 : check e2422373158522 [[],[]] .smaller = true := by decide
def e2422373158710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373158710 : Closed e2422373158710 ∧ code e2422373158710 = 11218466180918 := by decide
theorem cert_e2422373158710 : check e2422373158710 [[],[]] .smaller = true := by decide
def e2422373158714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373158714 : Closed e2422373158714 ∧ code e2422373158714 = 11218466180922 := by decide
theorem cert_e2422373158714 : check e2422373158714 [[],[]] .smaller = true := by decide
def e2422373166558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2422373166558 : Closed e2422373166558 ∧ code e2422373166558 = 11218466188766 := by decide
theorem cert_e2422373166558 : check e2422373166558 [[],[]] .three = true := by decide
def e2422373166574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2422373166574 : Closed e2422373166574 ∧ code e2422373166574 = 11218466188782 := by decide
theorem cert_e2422373166574 : check e2422373166574 [[],[]] .three = true := by decide
def e2422373166814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2422373166814 : Closed e2422373166814 ∧ code e2422373166814 = 11218466189022 := by decide
theorem cert_e2422373166814 : check e2422373166814 [[],[]] .three = true := by decide
def e2422373166830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2422373166830 : Closed e2422373166830 ∧ code e2422373166830 = 11218466189038 := by decide
theorem cert_e2422373166830 : check e2422373166830 [[],[]] .smaller = true := by decide
def e2422373166838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2422373166838 : Closed e2422373166838 ∧ code e2422373166838 = 11218466189046 := by decide
theorem cert_e2422373166838 : check e2422373166838 [[],[]] .three = true := by decide
def e2422373166942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2422373166942 : Closed e2422373166942 ∧ code e2422373166942 = 11218466189150 := by decide
theorem cert_e2422373166942 : check e2422373166942 [[],[]] .three = true := by decide
def e2422373166958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2422373166958 : Closed e2422373166958 ∧ code e2422373166958 = 11218466189166 := by decide
theorem cert_e2422373166958 : check e2422373166958 [[],[]] .smaller = true := by decide
def e2422373166966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2422373166966 : Closed e2422373166966 ∧ code e2422373166966 = 11218466189174 := by decide
theorem cert_e2422373166966 : check e2422373166966 [[],[]] .smaller = true := by decide
def e2422373166970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2422373166970 : Closed e2422373166970 ∧ code e2422373166970 = 11218466189178 := by decide
theorem cert_e2422373166970 : check e2422373166970 [[],[]] .three = true := by decide
def e2422373167022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2422373167022 : Closed e2422373167022 ∧ code e2422373167022 = 11218466189230 := by decide
theorem cert_e2422373167022 : check e2422373167022 [[],[]] .three = true := by decide
def e2422373167030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2422373167030 : Closed e2422373167030 ∧ code e2422373167030 = 11218466189238 := by decide
theorem cert_e2422373167030 : check e2422373167030 [[],[]] .three = true := by decide
def e2422373167034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2422373167034 : Closed e2422373167034 ∧ code e2422373167034 = 11218466189242 := by decide
theorem cert_e2422373167034 : check e2422373167034 [[],[]] .three = true := by decide
def e2422373168094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373168094 : Closed e2422373168094 ∧ code e2422373168094 = 11218466190302 := by decide
theorem cert_e2422373168094 : check e2422373168094 [[],[]] .three = true := by decide
def e2422373168110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373168110 : Closed e2422373168110 ∧ code e2422373168110 = 11218466190318 := by decide
theorem cert_e2422373168110 : check e2422373168110 [[],[]] .three = true := by decide
def e2422373169630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373169630 : Closed e2422373169630 ∧ code e2422373169630 = 11218466191838 := by decide
theorem cert_e2422373169630 : check e2422373169630 [[],[]] .three = true := by decide
def e2422373169646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373169646 : Closed e2422373169646 ∧ code e2422373169646 = 11218466191854 := by decide
theorem cert_e2422373169646 : check e2422373169646 [[],[]] .smaller = true := by decide
def e2422373169654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373169654 : Closed e2422373169654 ∧ code e2422373169654 = 11218466191862 := by decide
theorem cert_e2422373169654 : check e2422373169654 [[],[]] .three = true := by decide
def e2422373170398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373170398 : Closed e2422373170398 ∧ code e2422373170398 = 11218466192606 := by decide
theorem cert_e2422373170398 : check e2422373170398 [[],[]] .three = true := by decide
def e2422373170414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373170414 : Closed e2422373170414 ∧ code e2422373170414 = 11218466192622 := by decide
theorem cert_e2422373170414 : check e2422373170414 [[],[]] .smaller = true := by decide
def e2422373170422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373170422 : Closed e2422373170422 ∧ code e2422373170422 = 11218466192630 := by decide
theorem cert_e2422373170422 : check e2422373170422 [[],[]] .smaller = true := by decide
def e2422373170426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373170426 : Closed e2422373170426 ∧ code e2422373170426 = 11218466192634 := by decide
theorem cert_e2422373170426 : check e2422373170426 [[],[]] .three = true := by decide
def e2422373170798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373170798 : Closed e2422373170798 ∧ code e2422373170798 = 11218466193006 := by decide
theorem cert_e2422373170798 : check e2422373170798 [[],[]] .three = true := by decide
def e2422373170806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373170806 : Closed e2422373170806 ∧ code e2422373170806 = 11218466193014 := by decide
theorem cert_e2422373170806 : check e2422373170806 [[],[]] .three = true := by decide
def e2422373170810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373170810 : Closed e2422373170810 ∧ code e2422373170810 = 11218466193018 := by decide
theorem cert_e2422373170810 : check e2422373170810 [[],[]] .three = true := by decide
def e2422373189566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e2422373189566 : Closed e2422373189566 ∧ code e2422373189566 = 11218466211774 := by decide
theorem cert_e2422373189566 : check e2422373189566 [[],[]] .three = true := by decide
def e2422373189614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e2422373189614 : Closed e2422373189614 ∧ code e2422373189614 = 11218466211822 := by decide
theorem cert_e2422373189614 : check e2422373189614 [[],[]] .three = true := by decide
def e2422373193438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2422373193438 : Closed e2422373193438 ∧ code e2422373193438 = 11218466215646 := by decide
theorem cert_e2422373193438 : check e2422373193438 [[],[]] .three = true := by decide
def e2422373193462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2422373193462 : Closed e2422373193462 ∧ code e2422373193462 = 11218466215670 := by decide
theorem cert_e2422373193462 : check e2422373193462 [[],[]] .three = true := by decide
def e2422373193566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2422373193566 : Closed e2422373193566 ∧ code e2422373193566 = 11218466215774 := by decide
theorem cert_e2422373193566 : check e2422373193566 [[],[]] .three = true := by decide
def e2422373193582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2422373193582 : Closed e2422373193582 ∧ code e2422373193582 = 11218466215790 := by decide
theorem cert_e2422373193582 : check e2422373193582 [[],[]] .smaller = true := by decide
def e2422373193590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2422373193590 : Closed e2422373193590 ∧ code e2422373193590 = 11218466215798 := by decide
theorem cert_e2422373193590 : check e2422373193590 [[],[]] .smaller = true := by decide
def e2422373193594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2422373193594 : Closed e2422373193594 ∧ code e2422373193594 = 11218466215802 := by decide
theorem cert_e2422373193594 : check e2422373193594 [[],[]] .three = true := by decide
def e2422373193654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2422373193654 : Closed e2422373193654 ∧ code e2422373193654 = 11218466215862 := by decide
theorem cert_e2422373193654 : check e2422373193654 [[],[]] .smaller = true := by decide
def e2422373193686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2422373193686 : Closed e2422373193686 ∧ code e2422373193686 = 11218466215894 := by decide
theorem cert_e2422373193686 : check e2422373193686 [[],[]] .three = true := by decide
def e2422373193690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2422373193690 : Closed e2422373193690 ∧ code e2422373193690 = 11218466215898 := by decide
theorem cert_e2422373193690 : check e2422373193690 [[],[]] .three = true := by decide
def e2422373194206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373194206 : Closed e2422373194206 ∧ code e2422373194206 = 11218466216414 := by decide
theorem cert_e2422373194206 : check e2422373194206 [[],[]] .three = true := by decide
def e2422373194230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373194230 : Closed e2422373194230 ∧ code e2422373194230 = 11218466216438 := by decide
theorem cert_e2422373194230 : check e2422373194230 [[],[]] .three = true := by decide
def e2422373194974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373194974 : Closed e2422373194974 ∧ code e2422373194974 = 11218466217182 := by decide
theorem cert_e2422373194974 : check e2422373194974 [[],[]] .three = true := by decide
def e2422373194990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373194990 : Closed e2422373194990 ∧ code e2422373194990 = 11218466217198 := by decide
theorem cert_e2422373194990 : check e2422373194990 [[],[]] .smaller = true := by decide
def e2422373194998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373194998 : Closed e2422373194998 ∧ code e2422373194998 = 11218466217206 := by decide
theorem cert_e2422373194998 : check e2422373194998 [[],[]] .smaller = true := by decide
def e2422373195002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373195002 : Closed e2422373195002 ∧ code e2422373195002 = 11218466217210 := by decide
theorem cert_e2422373195002 : check e2422373195002 [[],[]] .three = true := by decide
def e2422373195326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2422373195326 : Closed e2422373195326 ∧ code e2422373195326 = 11218466217534 := by decide
theorem cert_e2422373195326 : check e2422373195326 [[],[]] .three = true := by decide
def e2422373195382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373195382 : Closed e2422373195382 ∧ code e2422373195382 = 11218466217590 := by decide
theorem cert_e2422373195382 : check e2422373195382 [[],[]] .smaller = true := by decide
def e2422373195550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2422373195550 : Closed e2422373195550 ∧ code e2422373195550 = 11218466217758 := by decide
theorem cert_e2422373195550 : check e2422373195550 [[],[]] .three = true := by decide
def e2422373195574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373195574 : Closed e2422373195574 ∧ code e2422373195574 = 11218466217782 := by decide
theorem cert_e2422373195574 : check e2422373195574 [[],[]] .three = true := by decide
def e2422373195578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373195578 : Closed e2422373195578 ∧ code e2422373195578 = 11218466217786 := by decide
theorem cert_e2422373195578 : check e2422373195578 [[],[]] .three = true := by decide
def e2422373204926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e2422373204926 : Closed e2422373204926 ∧ code e2422373204926 = 11218466227134 := by decide
theorem cert_e2422373204926 : check e2422373204926 [[],[]] .three = true := by decide
def e2422373204958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373204958 : Closed e2422373204958 ∧ code e2422373204958 = 11218466227166 := by decide
theorem cert_e2422373204958 : check e2422373204958 [[],[]] .smaller = true := by decide
def e2422373204974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373204974 : Closed e2422373204974 ∧ code e2422373204974 = 11218466227182 := by decide
theorem cert_e2422373204974 : check e2422373204974 [[],[]] .smaller = true := by decide
def e2422373204982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e2422373204982 : Closed e2422373204982 ∧ code e2422373204982 = 11218466227190 := by decide
theorem cert_e2422373204982 : check e2422373204982 [[],[]] .three = true := by decide
def e2422373206878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2422373206878 : Closed e2422373206878 ∧ code e2422373206878 = 11218466229086 := by decide
theorem cert_e2422373206878 : check e2422373206878 [[],[]] .three = true := by decide
def e2422373206894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422373206894 : Closed e2422373206894 ∧ code e2422373206894 = 11218466229102 := by decide
theorem cert_e2422373206894 : check e2422373206894 [[],[]] .smaller = true := by decide
def e2422373206902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422373206902 : Closed e2422373206902 ∧ code e2422373206902 = 11218466229110 := by decide
theorem cert_e2422373206902 : check e2422373206902 [[],[]] .smaller = true := by decide
def e2422373206906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2422373206906 : Closed e2422373206906 ∧ code e2422373206906 = 11218466229114 := by decide
theorem cert_e2422373206906 : check e2422373206906 [[],[]] .three = true := by decide
def e2422373206958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422373206958 : Closed e2422373206958 ∧ code e2422373206958 = 11218466229166 := by decide
theorem cert_e2422373206958 : check e2422373206958 [[],[]] .smaller = true := by decide
def e2422373206970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422373206970 : Closed e2422373206970 ∧ code e2422373206970 = 11218466229178 := by decide
theorem cert_e2422373206970 : check e2422373206970 [[],[]] .smaller = true := by decide
def e2422373206998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422373206998 : Closed e2422373206998 ∧ code e2422373206998 = 11218466229206 := by decide
theorem cert_e2422373206998 : check e2422373206998 [[],[]] .smaller = true := by decide
def e2422373207002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422373207002 : Closed e2422373207002 ∧ code e2422373207002 = 11218466229210 := by decide
theorem cert_e2422373207002 : check e2422373207002 [[],[]] .smaller = true := by decide
def e2422373207018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2422373207018 : Closed e2422373207018 ∧ code e2422373207018 = 11218466229226 := by decide
theorem cert_e2422373207018 : check e2422373207018 [[],[]] .three = true := by decide
def e2422373207262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373207262 : Closed e2422373207262 ∧ code e2422373207262 = 11218466229470 := by decide
theorem cert_e2422373207262 : check e2422373207262 [[],[]] .three = true := by decide
def e2422373207278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373207278 : Closed e2422373207278 ∧ code e2422373207278 = 11218466229486 := by decide
theorem cert_e2422373207278 : check e2422373207278 [[],[]] .smaller = true := by decide
def e2422373207286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373207286 : Closed e2422373207286 ∧ code e2422373207286 = 11218466229494 := by decide
theorem cert_e2422373207286 : check e2422373207286 [[],[]] .smaller = true := by decide
def e2422373207290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373207290 : Closed e2422373207290 ∧ code e2422373207290 = 11218466229498 := by decide
theorem cert_e2422373207290 : check e2422373207290 [[],[]] .three = true := by decide
def e2422373207614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2422373207614 : Closed e2422373207614 ∧ code e2422373207614 = 11218466229822 := by decide
theorem cert_e2422373207614 : check e2422373207614 [[],[]] .three = true := by decide
def e2422373207662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373207662 : Closed e2422373207662 ∧ code e2422373207662 = 11218466229870 := by decide
theorem cert_e2422373207662 : check e2422373207662 [[],[]] .smaller = true := by decide
def e2422373207674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373207674 : Closed e2422373207674 ∧ code e2422373207674 = 11218466229882 := by decide
theorem cert_e2422373207674 : check e2422373207674 [[],[]] .smaller = true := by decide
def e2422373207838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e2422373207838 : Closed e2422373207838 ∧ code e2422373207838 = 11218466230046 := by decide
theorem cert_e2422373207838 : check e2422373207838 [[],[]] .smaller = true := by decide
def e2422373207862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373207862 : Closed e2422373207862 ∧ code e2422373207862 = 11218466230070 := by decide
theorem cert_e2422373207862 : check e2422373207862 [[],[]] .smaller = true := by decide
def e2422373207866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373207866 : Closed e2422373207866 ∧ code e2422373207866 = 11218466230074 := by decide
theorem cert_e2422373207866 : check e2422373207866 [[],[]] .smaller = true := by decide
def e2422373207950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2422373207950 : Closed e2422373207950 ∧ code e2422373207950 = 11218466230158 := by decide
theorem cert_e2422373207950 : check e2422373207950 [[],[]] .three = true := by decide
def e2422373207962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373207962 : Closed e2422373207962 ∧ code e2422373207962 = 11218466230170 := by decide
theorem cert_e2422373207962 : check e2422373207962 [[],[]] .three = true := by decide
def e2422373212654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373212654 : Closed e2422373212654 ∧ code e2422373212654 = 11218466234862 := by decide
theorem cert_e2422373212654 : check e2422373212654 [[],[]] .smaller = true := by decide
def e2422373213622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2422373213622 : Closed e2422373213622 ∧ code e2422373213622 = 11218466235830 := by decide
theorem cert_e2422373213622 : check e2422373213622 [[],[]] .smaller = true := by decide
def e2422373213654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2422373213654 : Closed e2422373213654 ∧ code e2422373213654 = 11218466235862 := by decide
theorem cert_e2422373213654 : check e2422373213654 [[],[]] .smaller = true := by decide
end Blc.Floor43
