import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262374069166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2262374069166 : Closed e2262374069166 ∧ code e2262374069166 = 11058467091374 := by decide
theorem cert_e2262374069166 : check e2262374069166 [[],[.under]] .smaller = true := by decide
def e2262374069178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2262374069178 : Closed e2262374069178 ∧ code e2262374069178 = 11058467091386 := by decide
theorem cert_e2262374069178 : check e2262374069178 [[],[.under]] .smaller = true := by decide
def e2262374069206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2262374069206 : Closed e2262374069206 ∧ code e2262374069206 = 11058467091414 := by decide
theorem cert_e2262374069206 : check e2262374069206 [[],[.under]] .smaller = true := by decide
def e2262374069210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2262374069210 : Closed e2262374069210 ∧ code e2262374069210 = 11058467091418 := by decide
theorem cert_e2262374069210 : check e2262374069210 [[],[.under]] .smaller = true := by decide
def e2262374069486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262374069486 : Closed e2262374069486 ∧ code e2262374069486 = 11058467091694 := by decide
theorem cert_e2262374069486 : check e2262374069486 [[],[.under]] .smaller = true := by decide
def e2262374069494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262374069494 : Closed e2262374069494 ∧ code e2262374069494 = 11058467091702 := by decide
theorem cert_e2262374069494 : check e2262374069494 [[],[.under]] .smaller = true := by decide
def e2262374069870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374069870 : Closed e2262374069870 ∧ code e2262374069870 = 11058467092078 := by decide
theorem cert_e2262374069870 : check e2262374069870 [[],[.under]] .smaller = true := by decide
def e2262374069882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374069882 : Closed e2262374069882 ∧ code e2262374069882 = 11058467092090 := by decide
theorem cert_e2262374069882 : check e2262374069882 [[],[.under]] .smaller = true := by decide
def e2262374070070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374070070 : Closed e2262374070070 ∧ code e2262374070070 = 11058467092278 := by decide
theorem cert_e2262374070070 : check e2262374070070 [[],[.under]] .smaller = true := by decide
def e2262374070074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374070074 : Closed e2262374070074 ∧ code e2262374070074 = 11058467092282 := by decide
theorem cert_e2262374070074 : check e2262374070074 [[],[.under]] .smaller = true := by decide
def e2262374070702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2262374070702 : Closed e2262374070702 ∧ code e2262374070702 = 11058467092910 := by decide
theorem cert_e2262374070702 : check e2262374070702 [[],[.under]] .smaller = true := by decide
def e2262374070714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2262374070714 : Closed e2262374070714 ∧ code e2262374070714 = 11058467092922 := by decide
theorem cert_e2262374070714 : check e2262374070714 [[],[.under]] .smaller = true := by decide
def e2262374070762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2262374070762 : Closed e2262374070762 ∧ code e2262374070762 = 11058467092970 := by decide
theorem cert_e2262374070762 : check e2262374070762 [[],[.under]] .smaller = true := by decide
def e2262374070894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374070894 : Closed e2262374070894 ∧ code e2262374070894 = 11058467093102 := by decide
theorem cert_e2262374070894 : check e2262374070894 [[],[.under]] .smaller = true := by decide
def e2262374070906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374070906 : Closed e2262374070906 ∧ code e2262374070906 = 11058467093114 := by decide
theorem cert_e2262374070906 : check e2262374070906 [[],[.under]] .smaller = true := by decide
def e2262374071194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374071194 : Closed e2262374071194 ∧ code e2262374071194 = 11058467093402 := by decide
theorem cert_e2262374071194 : check e2262374071194 [[],[.under]] .smaller = true := by decide
def e2262374071510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2262374071510 : Closed e2262374071510 ∧ code e2262374071510 = 11058467093718 := by decide
theorem cert_e2262374071510 : check e2262374071510 [[],[.under]] .smaller = true := by decide
def e2262374071514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2262374071514 : Closed e2262374071514 ∧ code e2262374071514 = 11058467093722 := by decide
theorem cert_e2262374071514 : check e2262374071514 [[],[.under]] .smaller = true := by decide
def e2262374071530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2262374071530 : Closed e2262374071530 ∧ code e2262374071530 = 11058467093738 := by decide
theorem cert_e2262374071530 : check e2262374071530 [[],[.under]] .smaller = true := by decide
def e2262374071606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374071606 : Closed e2262374071606 ∧ code e2262374071606 = 11058467093814 := by decide
theorem cert_e2262374071606 : check e2262374071606 [[],[.under]] .smaller = true := by decide
def e2262374071610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374071610 : Closed e2262374071610 ∧ code e2262374071610 = 11058467093818 := by decide
theorem cert_e2262374071610 : check e2262374071610 [[],[.under]] .smaller = true := by decide
def e2262374071706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374071706 : Closed e2262374071706 ∧ code e2262374071706 = 11058467093914 := by decide
theorem cert_e2262374071706 : check e2262374071706 [[],[.under]] .smaller = true := by decide
def e2262374075246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2262374075246 : Closed e2262374075246 ∧ code e2262374075246 = 11058467097454 := by decide
theorem cert_e2262374075246 : check e2262374075246 [[],[.under]] .smaller = true := by decide
def e2262374075254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2262374075254 : Closed e2262374075254 ∧ code e2262374075254 = 11058467097462 := by decide
theorem cert_e2262374075254 : check e2262374075254 [[],[.under]] .smaller = true := by decide
def e2262374075310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2262374075310 : Closed e2262374075310 ∧ code e2262374075310 = 11058467097518 := by decide
theorem cert_e2262374075310 : check e2262374075310 [[],[.under]] .smaller = true := by decide
def e2262374075322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2262374075322 : Closed e2262374075322 ∧ code e2262374075322 = 11058467097530 := by decide
theorem cert_e2262374075322 : check e2262374075322 [[],[.under]] .smaller = true := by decide
def e2262374075350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2262374075350 : Closed e2262374075350 ∧ code e2262374075350 = 11058467097558 := by decide
theorem cert_e2262374075350 : check e2262374075350 [[],[.under]] .smaller = true := by decide
def e2262374075354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2262374075354 : Closed e2262374075354 ∧ code e2262374075354 = 11058467097562 := by decide
theorem cert_e2262374075354 : check e2262374075354 [[],[.under]] .smaller = true := by decide
def e2262374075630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2262374075630 : Closed e2262374075630 ∧ code e2262374075630 = 11058467097838 := by decide
theorem cert_e2262374075630 : check e2262374075630 [[],[.under]] .smaller = true := by decide
def e2262374075638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2262374075638 : Closed e2262374075638 ∧ code e2262374075638 = 11058467097846 := by decide
theorem cert_e2262374075638 : check e2262374075638 [[],[.under]] .smaller = true := by decide
def e2262374076014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2262374076014 : Closed e2262374076014 ∧ code e2262374076014 = 11058467098222 := by decide
theorem cert_e2262374076014 : check e2262374076014 [[],[.under]] .smaller = true := by decide
def e2262374076026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2262374076026 : Closed e2262374076026 ∧ code e2262374076026 = 11058467098234 := by decide
theorem cert_e2262374076026 : check e2262374076026 [[],[.under]] .smaller = true := by decide
def e2262374076214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2262374076214 : Closed e2262374076214 ∧ code e2262374076214 = 11058467098422 := by decide
theorem cert_e2262374076214 : check e2262374076214 [[],[.under]] .smaller = true := by decide
def e2262374076218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2262374076218 : Closed e2262374076218 ∧ code e2262374076218 = 11058467098426 := by decide
theorem cert_e2262374076218 : check e2262374076218 [[],[.under]] .smaller = true := by decide
def e2262374081966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2262374081966 : Closed e2262374081966 ∧ code e2262374081966 = 11058467104174 := by decide
theorem cert_e2262374081966 : check e2262374081966 [[],[.under]] .smaller = true := by decide
def e2262374081978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2262374081978 : Closed e2262374081978 ∧ code e2262374081978 = 11058467104186 := by decide
theorem cert_e2262374081978 : check e2262374081978 [[],[.under]] .smaller = true := by decide
def e2262374082026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2262374082026 : Closed e2262374082026 ∧ code e2262374082026 = 11058467104234 := by decide
theorem cert_e2262374082026 : check e2262374082026 [[],[.under]] .smaller = true := by decide
def e2262374082158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2262374082158 : Closed e2262374082158 ∧ code e2262374082158 = 11058467104366 := by decide
theorem cert_e2262374082158 : check e2262374082158 [[],[.under]] .smaller = true := by decide
def e2262374082170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2262374082170 : Closed e2262374082170 ∧ code e2262374082170 = 11058467104378 := by decide
theorem cert_e2262374082170 : check e2262374082170 [[],[.under]] .smaller = true := by decide
def e2262374082458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2262374082458 : Closed e2262374082458 ∧ code e2262374082458 = 11058467104666 := by decide
theorem cert_e2262374082458 : check e2262374082458 [[],[.under]] .smaller = true := by decide
def e2262374085334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2262374085334 : Closed e2262374085334 ∧ code e2262374085334 = 11058467107542 := by decide
theorem cert_e2262374085334 : check e2262374085334 [[],[.under]] .smaller = true := by decide
def e2262374085338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2262374085338 : Closed e2262374085338 ∧ code e2262374085338 = 11058467107546 := by decide
theorem cert_e2262374085338 : check e2262374085338 [[],[.under]] .smaller = true := by decide
def e2262374085354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2262374085354 : Closed e2262374085354 ∧ code e2262374085354 = 11058467107562 := by decide
theorem cert_e2262374085354 : check e2262374085354 [[],[.under]] .smaller = true := by decide
def e2262374085430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2262374085430 : Closed e2262374085430 ∧ code e2262374085430 = 11058467107638 := by decide
theorem cert_e2262374085430 : check e2262374085430 [[],[.under]] .smaller = true := by decide
def e2262374085434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2262374085434 : Closed e2262374085434 ∧ code e2262374085434 = 11058467107642 := by decide
theorem cert_e2262374085434 : check e2262374085434 [[],[.under]] .smaller = true := by decide
def e2262374085530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2262374085530 : Closed e2262374085530 ∧ code e2262374085530 = 11058467107738 := by decide
theorem cert_e2262374085530 : check e2262374085530 [[],[.under]] .smaller = true := by decide
def e2262374200766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e2262374200766 : Closed e2262374200766 ∧ code e2262374200766 = 11058467222974 := by decide
theorem cert_e2262374200766 : check e2262374200766 [[],[.under]] .three = true := by decide
def e2262374200798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e2262374200798 : Closed e2262374200798 ∧ code e2262374200798 = 11058467223006 := by decide
theorem cert_e2262374200798 : check e2262374200798 [[],[.under]] .smaller = true := by decide
def e2262374200814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e2262374200814 : Closed e2262374200814 ∧ code e2262374200814 = 11058467223022 := by decide
theorem cert_e2262374200814 : check e2262374200814 [[],[.under]] .smaller = true := by decide
def e2262374200822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e2262374200822 : Closed e2262374200822 ∧ code e2262374200822 = 11058467223030 := by decide
theorem cert_e2262374200822 : check e2262374200822 [[],[.under]] .three = true := by decide
def e2262374201022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e2262374201022 : Closed e2262374201022 ∧ code e2262374201022 = 11058467223230 := by decide
theorem cert_e2262374201022 : check e2262374201022 [[],[.under]] .three = true := by decide
def e2262374201054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e2262374201054 : Closed e2262374201054 ∧ code e2262374201054 = 11058467223262 := by decide
theorem cert_e2262374201054 : check e2262374201054 [[],[.under]] .smaller = true := by decide
def e2262374201070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e2262374201070 : Closed e2262374201070 ∧ code e2262374201070 = 11058467223278 := by decide
theorem cert_e2262374201070 : check e2262374201070 [[],[.under]] .smaller = true := by decide
def e2262374201078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e2262374201078 : Closed e2262374201078 ∧ code e2262374201078 = 11058467223286 := by decide
theorem cert_e2262374201078 : check e2262374201078 [[],[.under]] .smaller = true := by decide
def e2262374201082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e2262374201082 : Closed e2262374201082 ∧ code e2262374201082 = 11058467223290 := by decide
theorem cert_e2262374201082 : check e2262374201082 [[],[.under]] .three = true := by decide
def e2262374201182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e2262374201182 : Closed e2262374201182 ∧ code e2262374201182 = 11058467223390 := by decide
theorem cert_e2262374201182 : check e2262374201182 [[],[.under]] .smaller = true := by decide
def e2262374201198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e2262374201198 : Closed e2262374201198 ∧ code e2262374201198 = 11058467223406 := by decide
theorem cert_e2262374201198 : check e2262374201198 [[],[.under]] .smaller = true := by decide
def e2262374201206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e2262374201206 : Closed e2262374201206 ∧ code e2262374201206 = 11058467223414 := by decide
theorem cert_e2262374201206 : check e2262374201206 [[],[.under]] .smaller = true := by decide
def e2262374201210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e2262374201210 : Closed e2262374201210 ∧ code e2262374201210 = 11058467223418 := by decide
theorem cert_e2262374201210 : check e2262374201210 [[],[.under]] .smaller = true := by decide
def e2262374201262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e2262374201262 : Closed e2262374201262 ∧ code e2262374201262 = 11058467223470 := by decide
theorem cert_e2262374201262 : check e2262374201262 [[],[.under]] .smaller = true := by decide
def e2262374201270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e2262374201270 : Closed e2262374201270 ∧ code e2262374201270 = 11058467223478 := by decide
theorem cert_e2262374201270 : check e2262374201270 [[],[.under]] .smaller = true := by decide
def e2262374201274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e2262374201274 : Closed e2262374201274 ∧ code e2262374201274 = 11058467223482 := by decide
theorem cert_e2262374201274 : check e2262374201274 [[],[.under]] .smaller = true := by decide
def e2262374201302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e2262374201302 : Closed e2262374201302 ∧ code e2262374201302 = 11058467223510 := by decide
theorem cert_e2262374201302 : check e2262374201302 [[],[.under]] .three = true := by decide
def e2262374201306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e2262374201306 : Closed e2262374201306 ∧ code e2262374201306 = 11058467223514 := by decide
theorem cert_e2262374201306 : check e2262374201306 [[],[.under]] .three = true := by decide
def e2262374202046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e2262374202046 : Closed e2262374202046 ∧ code e2262374202046 = 11058467224254 := by decide
theorem cert_e2262374202046 : check e2262374202046 [[],[.under]] .three = true := by decide
def e2262374202078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2262374202078 : Closed e2262374202078 ∧ code e2262374202078 = 11058467224286 := by decide
theorem cert_e2262374202078 : check e2262374202078 [[],[.under]] .smaller = true := by decide
def e2262374202094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2262374202094 : Closed e2262374202094 ∧ code e2262374202094 = 11058467224302 := by decide
theorem cert_e2262374202094 : check e2262374202094 [[],[.under]] .smaller = true := by decide
def e2262374202102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2262374202102 : Closed e2262374202102 ∧ code e2262374202102 = 11058467224310 := by decide
theorem cert_e2262374202102 : check e2262374202102 [[],[.under]] .smaller = true := by decide
def e2262374202106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e2262374202106 : Closed e2262374202106 ∧ code e2262374202106 = 11058467224314 := by decide
theorem cert_e2262374202106 : check e2262374202106 [[],[.under]] .three = true := by decide
def e2262374202206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2262374202206 : Closed e2262374202206 ∧ code e2262374202206 = 11058467224414 := by decide
theorem cert_e2262374202206 : check e2262374202206 [[],[.under]] .smaller = true := by decide
def e2262374202234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2262374202234 : Closed e2262374202234 ∧ code e2262374202234 = 11058467224442 := by decide
theorem cert_e2262374202234 : check e2262374202234 [[],[.under]] .smaller = true := by decide
def e2262374202286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2262374202286 : Closed e2262374202286 ∧ code e2262374202286 = 11058467224494 := by decide
theorem cert_e2262374202286 : check e2262374202286 [[],[.under]] .smaller = true := by decide
def e2262374202298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2262374202298 : Closed e2262374202298 ∧ code e2262374202298 = 11058467224506 := by decide
theorem cert_e2262374202298 : check e2262374202298 [[],[.under]] .smaller = true := by decide
def e2262374202326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2262374202326 : Closed e2262374202326 ∧ code e2262374202326 = 11058467224534 := by decide
theorem cert_e2262374202326 : check e2262374202326 [[],[.under]] .smaller = true := by decide
def e2262374202330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2262374202330 : Closed e2262374202330 ∧ code e2262374202330 = 11058467224538 := by decide
theorem cert_e2262374202330 : check e2262374202330 [[],[.under]] .smaller = true := by decide
def e2262374202346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e2262374202346 : Closed e2262374202346 ∧ code e2262374202346 = 11058467224554 := by decide
theorem cert_e2262374202346 : check e2262374202346 [[],[.under]] .three = true := by decide
def e2262374202718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2262374202718 : Closed e2262374202718 ∧ code e2262374202718 = 11058467224926 := by decide
theorem cert_e2262374202718 : check e2262374202718 [[],[.under]] .smaller = true := by decide
def e2262374202734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2262374202734 : Closed e2262374202734 ∧ code e2262374202734 = 11058467224942 := by decide
theorem cert_e2262374202734 : check e2262374202734 [[],[.under]] .smaller = true := by decide
def e2262374202742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2262374202742 : Closed e2262374202742 ∧ code e2262374202742 = 11058467224950 := by decide
theorem cert_e2262374202742 : check e2262374202742 [[],[.under]] .smaller = true := by decide
def e2262374202746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2262374202746 : Closed e2262374202746 ∧ code e2262374202746 = 11058467224954 := by decide
theorem cert_e2262374202746 : check e2262374202746 [[],[.under]] .smaller = true := by decide
def e2262374202798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2262374202798 : Closed e2262374202798 ∧ code e2262374202798 = 11058467225006 := by decide
theorem cert_e2262374202798 : check e2262374202798 [[],[.under]] .smaller = true := by decide
def e2262374202810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2262374202810 : Closed e2262374202810 ∧ code e2262374202810 = 11058467225018 := by decide
theorem cert_e2262374202810 : check e2262374202810 [[],[.under]] .smaller = true := by decide
def e2262374202838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2262374202838 : Closed e2262374202838 ∧ code e2262374202838 = 11058467225046 := by decide
theorem cert_e2262374202838 : check e2262374202838 [[],[.under]] .smaller = true := by decide
def e2262374202842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2262374202842 : Closed e2262374202842 ∧ code e2262374202842 = 11058467225050 := by decide
theorem cert_e2262374202842 : check e2262374202842 [[],[.under]] .smaller = true := by decide
def e2262374202858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2262374202858 : Closed e2262374202858 ∧ code e2262374202858 = 11058467225066 := by decide
theorem cert_e2262374202858 : check e2262374202858 [[],[.under]] .smaller = true := by decide
def e2262374203054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2262374203054 : Closed e2262374203054 ∧ code e2262374203054 = 11058467225262 := by decide
theorem cert_e2262374203054 : check e2262374203054 [[],[.under]] .smaller = true := by decide
def e2262374203062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2262374203062 : Closed e2262374203062 ∧ code e2262374203062 = 11058467225270 := by decide
theorem cert_e2262374203062 : check e2262374203062 [[],[.under]] .smaller = true := by decide
def e2262374203066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2262374203066 : Closed e2262374203066 ∧ code e2262374203066 = 11058467225274 := by decide
theorem cert_e2262374203066 : check e2262374203066 [[],[.under]] .smaller = true := by decide
def e2262374203094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2262374203094 : Closed e2262374203094 ∧ code e2262374203094 = 11058467225302 := by decide
theorem cert_e2262374203094 : check e2262374203094 [[],[.under]] .smaller = true := by decide
def e2262374203098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2262374203098 : Closed e2262374203098 ∧ code e2262374203098 = 11058467225306 := by decide
theorem cert_e2262374203098 : check e2262374203098 [[],[.under]] .smaller = true := by decide
def e2262374203114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2262374203114 : Closed e2262374203114 ∧ code e2262374203114 = 11058467225322 := by decide
theorem cert_e2262374203114 : check e2262374203114 [[],[.under]] .smaller = true := by decide
def e2262374203222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2262374203222 : Closed e2262374203222 ∧ code e2262374203222 = 11058467225430 := by decide
theorem cert_e2262374203222 : check e2262374203222 [[],[.under]] .three = true := by decide
def e2262374203226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2262374203226 : Closed e2262374203226 ∧ code e2262374203226 = 11058467225434 := by decide
theorem cert_e2262374203226 : check e2262374203226 [[],[.under]] .three = true := by decide
def e2262374203242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2262374203242 : Closed e2262374203242 ∧ code e2262374203242 = 11058467225450 := by decide
theorem cert_e2262374203242 : check e2262374203242 [[],[.under]] .three = true := by decide
def e2262374206910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e2262374206910 : Closed e2262374206910 ∧ code e2262374206910 = 11058467229118 := by decide
theorem cert_e2262374206910 : check e2262374206910 [[],[.under]] .three = true := by decide
def e2262374206942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e2262374206942 : Closed e2262374206942 ∧ code e2262374206942 = 11058467229150 := by decide
theorem cert_e2262374206942 : check e2262374206942 [[],[.under]] .smaller = true := by decide
def e2262374206958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e2262374206958 : Closed e2262374206958 ∧ code e2262374206958 = 11058467229166 := by decide
theorem cert_e2262374206958 : check e2262374206958 [[],[.under]] .smaller = true := by decide
def e2262374206966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e2262374206966 : Closed e2262374206966 ∧ code e2262374206966 = 11058467229174 := by decide
theorem cert_e2262374206966 : check e2262374206966 [[],[.under]] .three = true := by decide
def e2262374207166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e2262374207166 : Closed e2262374207166 ∧ code e2262374207166 = 11058467229374 := by decide
theorem cert_e2262374207166 : check e2262374207166 [[],[.under]] .three = true := by decide
def e2262374207198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e2262374207198 : Closed e2262374207198 ∧ code e2262374207198 = 11058467229406 := by decide
theorem cert_e2262374207198 : check e2262374207198 [[],[.under]] .smaller = true := by decide
def e2262374207214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e2262374207214 : Closed e2262374207214 ∧ code e2262374207214 = 11058467229422 := by decide
theorem cert_e2262374207214 : check e2262374207214 [[],[.under]] .smaller = true := by decide
def e2262374207222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e2262374207222 : Closed e2262374207222 ∧ code e2262374207222 = 11058467229430 := by decide
theorem cert_e2262374207222 : check e2262374207222 [[],[.under]] .smaller = true := by decide
def e2262374207226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e2262374207226 : Closed e2262374207226 ∧ code e2262374207226 = 11058467229434 := by decide
theorem cert_e2262374207226 : check e2262374207226 [[],[.under]] .three = true := by decide
def e2262374207326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e2262374207326 : Closed e2262374207326 ∧ code e2262374207326 = 11058467229534 := by decide
theorem cert_e2262374207326 : check e2262374207326 [[],[.under]] .smaller = true := by decide
def e2262374207342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e2262374207342 : Closed e2262374207342 ∧ code e2262374207342 = 11058467229550 := by decide
theorem cert_e2262374207342 : check e2262374207342 [[],[.under]] .smaller = true := by decide
def e2262374207350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e2262374207350 : Closed e2262374207350 ∧ code e2262374207350 = 11058467229558 := by decide
theorem cert_e2262374207350 : check e2262374207350 [[],[.under]] .smaller = true := by decide
def e2262374207354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e2262374207354 : Closed e2262374207354 ∧ code e2262374207354 = 11058467229562 := by decide
theorem cert_e2262374207354 : check e2262374207354 [[],[.under]] .smaller = true := by decide
def e2262374207406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e2262374207406 : Closed e2262374207406 ∧ code e2262374207406 = 11058467229614 := by decide
theorem cert_e2262374207406 : check e2262374207406 [[],[.under]] .smaller = true := by decide
def e2262374207414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e2262374207414 : Closed e2262374207414 ∧ code e2262374207414 = 11058467229622 := by decide
theorem cert_e2262374207414 : check e2262374207414 [[],[.under]] .smaller = true := by decide
def e2262374207418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e2262374207418 : Closed e2262374207418 ∧ code e2262374207418 = 11058467229626 := by decide
theorem cert_e2262374207418 : check e2262374207418 [[],[.under]] .smaller = true := by decide
def e2262374207446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e2262374207446 : Closed e2262374207446 ∧ code e2262374207446 = 11058467229654 := by decide
theorem cert_e2262374207446 : check e2262374207446 [[],[.under]] .three = true := by decide
def e2262374207450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e2262374207450 : Closed e2262374207450 ∧ code e2262374207450 = 11058467229658 := by decide
theorem cert_e2262374207450 : check e2262374207450 [[],[.under]] .three = true := by decide
def e2262374208446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2262374208446 : Closed e2262374208446 ∧ code e2262374208446 = 11058467230654 := by decide
theorem cert_e2262374208446 : check e2262374208446 [[],[.under]] .three = true := by decide
def e2262374208478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262374208478 : Closed e2262374208478 ∧ code e2262374208478 = 11058467230686 := by decide
theorem cert_e2262374208478 : check e2262374208478 [[],[.under]] .smaller = true := by decide
def e2262374208494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262374208494 : Closed e2262374208494 ∧ code e2262374208494 = 11058467230702 := by decide
theorem cert_e2262374208494 : check e2262374208494 [[],[.under]] .smaller = true := by decide
def e2262374208502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2262374208502 : Closed e2262374208502 ∧ code e2262374208502 = 11058467230710 := by decide
theorem cert_e2262374208502 : check e2262374208502 [[],[.under]] .three = true := by decide
def e2262374209982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2262374209982 : Closed e2262374209982 ∧ code e2262374209982 = 11058467232190 := by decide
theorem cert_e2262374209982 : check e2262374209982 [[],[.under]] .three = true := by decide
def e2262374210014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262374210014 : Closed e2262374210014 ∧ code e2262374210014 = 11058467232222 := by decide
theorem cert_e2262374210014 : check e2262374210014 [[],[.under]] .smaller = true := by decide
def e2262374210030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262374210030 : Closed e2262374210030 ∧ code e2262374210030 = 11058467232238 := by decide
theorem cert_e2262374210030 : check e2262374210030 [[],[.under]] .smaller = true := by decide
def e2262374210038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262374210038 : Closed e2262374210038 ∧ code e2262374210038 = 11058467232246 := by decide
theorem cert_e2262374210038 : check e2262374210038 [[],[.under]] .smaller = true := by decide
def e2262374210042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2262374210042 : Closed e2262374210042 ∧ code e2262374210042 = 11058467232250 := by decide
theorem cert_e2262374210042 : check e2262374210042 [[],[.under]] .three = true := by decide
def e2262374210782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2262374210782 : Closed e2262374210782 ∧ code e2262374210782 = 11058467232990 := by decide
theorem cert_e2262374210782 : check e2262374210782 [[],[.under]] .smaller = true := by decide
def e2262374210798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262374210798 : Closed e2262374210798 ∧ code e2262374210798 = 11058467233006 := by decide
theorem cert_e2262374210798 : check e2262374210798 [[],[.under]] .smaller = true := by decide
def e2262374210806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262374210806 : Closed e2262374210806 ∧ code e2262374210806 = 11058467233014 := by decide
theorem cert_e2262374210806 : check e2262374210806 [[],[.under]] .smaller = true := by decide
def e2262374210810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2262374210810 : Closed e2262374210810 ∧ code e2262374210810 = 11058467233018 := by decide
theorem cert_e2262374210810 : check e2262374210810 [[],[.under]] .smaller = true := by decide
def e2262374211182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374211182 : Closed e2262374211182 ∧ code e2262374211182 = 11058467233390 := by decide
theorem cert_e2262374211182 : check e2262374211182 [[],[.under]] .smaller = true := by decide
def e2262374211190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262374211190 : Closed e2262374211190 ∧ code e2262374211190 = 11058467233398 := by decide
theorem cert_e2262374211190 : check e2262374211190 [[],[.under]] .smaller = true := by decide
def e2262374211194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374211194 : Closed e2262374211194 ∧ code e2262374211194 = 11058467233402 := by decide
theorem cert_e2262374211194 : check e2262374211194 [[],[.under]] .smaller = true := by decide
def e2262374211382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374211382 : Closed e2262374211382 ∧ code e2262374211382 = 11058467233590 := by decide
theorem cert_e2262374211382 : check e2262374211382 [[],[.under]] .three = true := by decide
def e2262374211386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374211386 : Closed e2262374211386 ∧ code e2262374211386 = 11058467233594 := by decide
theorem cert_e2262374211386 : check e2262374211386 [[],[.under]] .three = true := by decide
def e2262374213310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e2262374213310 : Closed e2262374213310 ∧ code e2262374213310 = 11058467235518 := by decide
theorem cert_e2262374213310 : check e2262374213310 [[],[.under]] .three = true := by decide
def e2262374213342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2262374213342 : Closed e2262374213342 ∧ code e2262374213342 = 11058467235550 := by decide
theorem cert_e2262374213342 : check e2262374213342 [[],[.under]] .smaller = true := by decide
def e2262374213358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2262374213358 : Closed e2262374213358 ∧ code e2262374213358 = 11058467235566 := by decide
theorem cert_e2262374213358 : check e2262374213358 [[],[.under]] .smaller = true := by decide
def e2262374213366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2262374213366 : Closed e2262374213366 ∧ code e2262374213366 = 11058467235574 := by decide
theorem cert_e2262374213366 : check e2262374213366 [[],[.under]] .smaller = true := by decide
def e2262374213370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e2262374213370 : Closed e2262374213370 ∧ code e2262374213370 = 11058467235578 := by decide
theorem cert_e2262374213370 : check e2262374213370 [[],[.under]] .three = true := by decide
def e2262374213470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2262374213470 : Closed e2262374213470 ∧ code e2262374213470 = 11058467235678 := by decide
theorem cert_e2262374213470 : check e2262374213470 [[],[.under]] .smaller = true := by decide
def e2262374213498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2262374213498 : Closed e2262374213498 ∧ code e2262374213498 = 11058467235706 := by decide
theorem cert_e2262374213498 : check e2262374213498 [[],[.under]] .smaller = true := by decide
def e2262374213550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2262374213550 : Closed e2262374213550 ∧ code e2262374213550 = 11058467235758 := by decide
theorem cert_e2262374213550 : check e2262374213550 [[],[.under]] .smaller = true := by decide
def e2262374213562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2262374213562 : Closed e2262374213562 ∧ code e2262374213562 = 11058467235770 := by decide
theorem cert_e2262374213562 : check e2262374213562 [[],[.under]] .smaller = true := by decide
def e2262374213590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2262374213590 : Closed e2262374213590 ∧ code e2262374213590 = 11058467235798 := by decide
theorem cert_e2262374213590 : check e2262374213590 [[],[.under]] .smaller = true := by decide
def e2262374213594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2262374213594 : Closed e2262374213594 ∧ code e2262374213594 = 11058467235802 := by decide
theorem cert_e2262374213594 : check e2262374213594 [[],[.under]] .smaller = true := by decide
def e2262374213610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e2262374213610 : Closed e2262374213610 ∧ code e2262374213610 = 11058467235818 := by decide
theorem cert_e2262374213610 : check e2262374213610 [[],[.under]] .three = true := by decide
def e2262374214078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2262374214078 : Closed e2262374214078 ∧ code e2262374214078 = 11058467236286 := by decide
theorem cert_e2262374214078 : check e2262374214078 [[],[.under]] .three = true := by decide
def e2262374214110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262374214110 : Closed e2262374214110 ∧ code e2262374214110 = 11058467236318 := by decide
theorem cert_e2262374214110 : check e2262374214110 [[],[.under]] .smaller = true := by decide
def e2262374214126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262374214126 : Closed e2262374214126 ∧ code e2262374214126 = 11058467236334 := by decide
theorem cert_e2262374214126 : check e2262374214126 [[],[.under]] .smaller = true := by decide
def e2262374214134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262374214134 : Closed e2262374214134 ∧ code e2262374214134 = 11058467236342 := by decide
theorem cert_e2262374214134 : check e2262374214134 [[],[.under]] .smaller = true := by decide
def e2262374214138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2262374214138 : Closed e2262374214138 ∧ code e2262374214138 = 11058467236346 := by decide
theorem cert_e2262374214138 : check e2262374214138 [[],[.under]] .three = true := by decide
def e2262374214878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2262374214878 : Closed e2262374214878 ∧ code e2262374214878 = 11058467237086 := by decide
theorem cert_e2262374214878 : check e2262374214878 [[],[.under]] .smaller = true := by decide
def e2262374214906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2262374214906 : Closed e2262374214906 ∧ code e2262374214906 = 11058467237114 := by decide
theorem cert_e2262374214906 : check e2262374214906 [[],[.under]] .smaller = true := by decide
def e2262374215278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374215278 : Closed e2262374215278 ∧ code e2262374215278 = 11058467237486 := by decide
theorem cert_e2262374215278 : check e2262374215278 [[],[.under]] .smaller = true := by decide
def e2262374215290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374215290 : Closed e2262374215290 ∧ code e2262374215290 = 11058467237498 := by decide
theorem cert_e2262374215290 : check e2262374215290 [[],[.under]] .smaller = true := by decide
def e2262374215478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374215478 : Closed e2262374215478 ∧ code e2262374215478 = 11058467237686 := by decide
theorem cert_e2262374215478 : check e2262374215478 [[],[.under]] .smaller = true := by decide
def e2262374215482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374215482 : Closed e2262374215482 ∧ code e2262374215482 = 11058467237690 := by decide
theorem cert_e2262374215482 : check e2262374215482 [[],[.under]] .smaller = true := by decide
def e2262374215578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374215578 : Closed e2262374215578 ∧ code e2262374215578 = 11058467237786 := by decide
theorem cert_e2262374215578 : check e2262374215578 [[],[.under]] .three = true := by decide
def e2262374216542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2262374216542 : Closed e2262374216542 ∧ code e2262374216542 = 11058467238750 := by decide
theorem cert_e2262374216542 : check e2262374216542 [[],[.under]] .smaller = true := by decide
def e2262374216558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2262374216558 : Closed e2262374216558 ∧ code e2262374216558 = 11058467238766 := by decide
theorem cert_e2262374216558 : check e2262374216558 [[],[.under]] .smaller = true := by decide
def e2262374216566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2262374216566 : Closed e2262374216566 ∧ code e2262374216566 = 11058467238774 := by decide
theorem cert_e2262374216566 : check e2262374216566 [[],[.under]] .smaller = true := by decide
def e2262374216570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2262374216570 : Closed e2262374216570 ∧ code e2262374216570 = 11058467238778 := by decide
theorem cert_e2262374216570 : check e2262374216570 [[],[.under]] .smaller = true := by decide
def e2262374216622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2262374216622 : Closed e2262374216622 ∧ code e2262374216622 = 11058467238830 := by decide
theorem cert_e2262374216622 : check e2262374216622 [[],[.under]] .smaller = true := by decide
def e2262374216634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2262374216634 : Closed e2262374216634 ∧ code e2262374216634 = 11058467238842 := by decide
theorem cert_e2262374216634 : check e2262374216634 [[],[.under]] .smaller = true := by decide
end Blc.Floor43
