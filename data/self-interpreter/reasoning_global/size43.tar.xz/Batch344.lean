import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419141047962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141047962 : Closed e2419141047962 ∧ code e2419141047962 = 11215234070170 := by decide
theorem cert_e2419141047962 : check e2419141047962 [[],[]] .smaller = true := by decide
def e2419141048006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2419141048006 : Closed e2419141048006 ∧ code e2419141048006 = 11215234070214 := by decide
theorem cert_e2419141048006 : check e2419141048006 [[],[]] .smaller = true := by decide
def e2419141048030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2419141048030 : Closed e2419141048030 ∧ code e2419141048030 = 11215234070238 := by decide
theorem cert_e2419141048030 : check e2419141048030 [[],[]] .three = true := by decide
def e2419141048054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2419141048054 : Closed e2419141048054 ∧ code e2419141048054 = 11215234070262 := by decide
theorem cert_e2419141048054 : check e2419141048054 [[],[]] .three = true := by decide
def e2419141048158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2419141048158 : Closed e2419141048158 ∧ code e2419141048158 = 11215234070366 := by decide
theorem cert_e2419141048158 : check e2419141048158 [[],[]] .three = true := by decide
def e2419141048186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2419141048186 : Closed e2419141048186 ∧ code e2419141048186 = 11215234070394 := by decide
theorem cert_e2419141048186 : check e2419141048186 [[],[]] .three = true := by decide
def e2419141048238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2419141048238 : Closed e2419141048238 ∧ code e2419141048238 = 11215234070446 := by decide
theorem cert_e2419141048238 : check e2419141048238 [[],[]] .three = true := by decide
def e2419141048246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2419141048246 : Closed e2419141048246 ∧ code e2419141048246 = 11215234070454 := by decide
theorem cert_e2419141048246 : check e2419141048246 [[],[]] .three = true := by decide
def e2419141048250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2419141048250 : Closed e2419141048250 ∧ code e2419141048250 = 11215234070458 := by decide
theorem cert_e2419141048250 : check e2419141048250 [[],[]] .three = true := by decide
def e2419141048534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2419141048534 : Closed e2419141048534 ∧ code e2419141048534 = 11215234070742 := by decide
theorem cert_e2419141048534 : check e2419141048534 [[],[]] .three = true := by decide
def e2419141048538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2419141048538 : Closed e2419141048538 ∧ code e2419141048538 = 11215234070746 := by decide
theorem cert_e2419141048538 : check e2419141048538 [[],[]] .three = true := by decide
def e2419141048554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2419141048554 : Closed e2419141048554 ∧ code e2419141048554 = 11215234070762 := by decide
theorem cert_e2419141048554 : check e2419141048554 [[],[]] .three = true := by decide
def e2419141048886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2419141048886 : Closed e2419141048886 ∧ code e2419141048886 = 11215234071094 := by decide
theorem cert_e2419141048886 : check e2419141048886 [[],[]] .three = true := by decide
def e2419141048890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2419141048890 : Closed e2419141048890 ∧ code e2419141048890 = 11215234071098 := by decide
theorem cert_e2419141048890 : check e2419141048890 [[],[]] .three = true := by decide
def e2419141048974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2419141048974 : Closed e2419141048974 ∧ code e2419141048974 = 11215234071182 := by decide
theorem cert_e2419141048974 : check e2419141048974 [[],[]] .three = true := by decide
def e2419141049030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2419141049030 : Closed e2419141049030 ∧ code e2419141049030 = 11215234071238 := by decide
theorem cert_e2419141049030 : check e2419141049030 [[],[]] .three = true := by decide
def e2419141049054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2419141049054 : Closed e2419141049054 ∧ code e2419141049054 = 11215234071262 := by decide
theorem cert_e2419141049054 : check e2419141049054 [[],[]] .three = true := by decide
def e2419141049070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2419141049070 : Closed e2419141049070 ∧ code e2419141049070 = 11215234071278 := by decide
theorem cert_e2419141049070 : check e2419141049070 [[],[]] .three = true := by decide
def e2419141049078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2419141049078 : Closed e2419141049078 ∧ code e2419141049078 = 11215234071286 := by decide
theorem cert_e2419141049078 : check e2419141049078 [[],[]] .three = true := by decide
def e2419141049114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2419141049114 : Closed e2419141049114 ∧ code e2419141049114 = 11215234071322 := by decide
theorem cert_e2419141049114 : check e2419141049114 [[],[]] .three = true := by decide
def e2419141049158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2419141049158 : Closed e2419141049158 ∧ code e2419141049158 = 11215234071366 := by decide
theorem cert_e2419141049158 : check e2419141049158 [[],[]] .three = true := by decide
def e2419141049182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2419141049182 : Closed e2419141049182 ∧ code e2419141049182 = 11215234071390 := by decide
theorem cert_e2419141049182 : check e2419141049182 [[],[]] .three = true := by decide
def e2419141049198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2419141049198 : Closed e2419141049198 ∧ code e2419141049198 = 11215234071406 := by decide
theorem cert_e2419141049198 : check e2419141049198 [[],[]] .three = true := by decide
def e2419141049206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2419141049206 : Closed e2419141049206 ∧ code e2419141049206 = 11215234071414 := by decide
theorem cert_e2419141049206 : check e2419141049206 [[],[]] .three = true := by decide
def e2419141049210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2419141049210 : Closed e2419141049210 ∧ code e2419141049210 = 11215234071418 := by decide
theorem cert_e2419141049210 : check e2419141049210 [[],[]] .three = true := by decide
def e2419141049262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2419141049262 : Closed e2419141049262 ∧ code e2419141049262 = 11215234071470 := by decide
theorem cert_e2419141049262 : check e2419141049262 [[],[]] .three = true := by decide
def e2419141049270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2419141049270 : Closed e2419141049270 ∧ code e2419141049270 = 11215234071478 := by decide
theorem cert_e2419141049270 : check e2419141049270 [[],[]] .three = true := by decide
def e2419141049274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2419141049274 : Closed e2419141049274 ∧ code e2419141049274 = 11215234071482 := by decide
theorem cert_e2419141049274 : check e2419141049274 [[],[]] .three = true := by decide
def e2419141049302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2419141049302 : Closed e2419141049302 ∧ code e2419141049302 = 11215234071510 := by decide
private def t_e2419141049302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))
theorem cert_e2419141049302 : ¬ IsSelfInterpreter e2419141049302 :=
  wSource (t := t_e2419141049302) (replay_sound (ps := []) (t := e2419141049302) (by decide)) (by decide)
def e2419141049306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2419141049306 : Closed e2419141049306 ∧ code e2419141049306 = 11215234071514 := by decide
private def t_e2419141049306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))
theorem cert_e2419141049306 : ¬ IsSelfInterpreter e2419141049306 :=
  wSource (t := t_e2419141049306) (replay_sound (ps := []) (t := e2419141049306) (by decide)) (by decide)
def e2419141054190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e2419141054190 : Closed e2419141054190 ∧ code e2419141054190 = 11215234076398 := by decide
theorem cert_e2419141054190 : check e2419141054190 [[],[]] .smaller = true := by decide
def e2419141054198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e2419141054198 : Closed e2419141054198 ∧ code e2419141054198 = 11215234076406 := by decide
theorem cert_e2419141054198 : check e2419141054198 [[],[]] .smaller = true := by decide
def e2419141054318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e2419141054318 : Closed e2419141054318 ∧ code e2419141054318 = 11215234076526 := by decide
theorem cert_e2419141054318 : check e2419141054318 [[],[]] .smaller = true := by decide
def e2419141054330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2419141054330 : Closed e2419141054330 ∧ code e2419141054330 = 11215234076538 := by decide
theorem cert_e2419141054330 : check e2419141054330 [[],[]] .smaller = true := by decide
def e2419141054390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e2419141054390 : Closed e2419141054390 ∧ code e2419141054390 = 11215234076598 := by decide
theorem cert_e2419141054390 : check e2419141054390 [[],[]] .smaller = true := by decide
def e2419141054394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2419141054394 : Closed e2419141054394 ∧ code e2419141054394 = 11215234076602 := by decide
theorem cert_e2419141054394 : check e2419141054394 [[],[]] .smaller = true := by decide
def e2419141056990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2419141056990 : Closed e2419141056990 ∧ code e2419141056990 = 11215234079198 := by decide
theorem cert_e2419141056990 : check e2419141056990 [[],[]] .three = true := by decide
def e2419141057014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2419141057014 : Closed e2419141057014 ∧ code e2419141057014 = 11215234079222 := by decide
theorem cert_e2419141057014 : check e2419141057014 [[],[]] .three = true := by decide
def e2419141057758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2419141057758 : Closed e2419141057758 ∧ code e2419141057758 = 11215234079966 := by decide
theorem cert_e2419141057758 : check e2419141057758 [[],[]] .three = true := by decide
def e2419141057774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e2419141057774 : Closed e2419141057774 ∧ code e2419141057774 = 11215234079982 := by decide
theorem cert_e2419141057774 : check e2419141057774 [[],[]] .smaller = true := by decide
def e2419141057782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e2419141057782 : Closed e2419141057782 ∧ code e2419141057782 = 11215234079990 := by decide
theorem cert_e2419141057782 : check e2419141057782 [[],[]] .smaller = true := by decide
def e2419141057786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2419141057786 : Closed e2419141057786 ∧ code e2419141057786 = 11215234079994 := by decide
theorem cert_e2419141057786 : check e2419141057786 [[],[]] .three = true := by decide
def e2419141058166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e2419141058166 : Closed e2419141058166 ∧ code e2419141058166 = 11215234080374 := by decide
theorem cert_e2419141058166 : check e2419141058166 [[],[]] .smaller = true := by decide
def e2419141058358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141058358 : Closed e2419141058358 ∧ code e2419141058358 = 11215234080566 := by decide
theorem cert_e2419141058358 : check e2419141058358 [[],[]] .three = true := by decide
def e2419141058362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141058362 : Closed e2419141058362 ∧ code e2419141058362 = 11215234080570 := by decide
theorem cert_e2419141058362 : check e2419141058362 [[],[]] .three = true := by decide
def e2419141061998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2419141061998 : Closed e2419141061998 ∧ code e2419141061998 = 11215234084206 := by decide
theorem cert_e2419141061998 : check e2419141061998 [[],[]] .smaller = true := by decide
def e2419141062006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2419141062006 : Closed e2419141062006 ∧ code e2419141062006 = 11215234084214 := by decide
theorem cert_e2419141062006 : check e2419141062006 [[],[]] .smaller = true := by decide
def e2419141062062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2419141062062 : Closed e2419141062062 ∧ code e2419141062062 = 11215234084270 := by decide
theorem cert_e2419141062062 : check e2419141062062 [[],[]] .smaller = true := by decide
def e2419141062074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2419141062074 : Closed e2419141062074 ∧ code e2419141062074 = 11215234084282 := by decide
theorem cert_e2419141062074 : check e2419141062074 [[],[]] .smaller = true := by decide
def e2419141062102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2419141062102 : Closed e2419141062102 ∧ code e2419141062102 = 11215234084310 := by decide
theorem cert_e2419141062102 : check e2419141062102 [[],[]] .smaller = true := by decide
def e2419141062106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2419141062106 : Closed e2419141062106 ∧ code e2419141062106 = 11215234084314 := by decide
theorem cert_e2419141062106 : check e2419141062106 [[],[]] .smaller = true := by decide
def e2419141062318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2419141062318 : Closed e2419141062318 ∧ code e2419141062318 = 11215234084526 := by decide
theorem cert_e2419141062318 : check e2419141062318 [[],[]] .smaller = true := by decide
def e2419141062330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2419141062330 : Closed e2419141062330 ∧ code e2419141062330 = 11215234084538 := by decide
theorem cert_e2419141062330 : check e2419141062330 [[],[]] .smaller = true := by decide
def e2419141062378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2419141062378 : Closed e2419141062378 ∧ code e2419141062378 = 11215234084586 := by decide
theorem cert_e2419141062378 : check e2419141062378 [[],[]] .smaller = true := by decide
def e2419141062486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2419141062486 : Closed e2419141062486 ∧ code e2419141062486 = 11215234084694 := by decide
theorem cert_e2419141062486 : check e2419141062486 [[],[]] .smaller = true := by decide
def e2419141062490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2419141062490 : Closed e2419141062490 ∧ code e2419141062490 = 11215234084698 := by decide
theorem cert_e2419141062490 : check e2419141062490 [[],[]] .smaller = true := by decide
def e2419141062506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2419141062506 : Closed e2419141062506 ∧ code e2419141062506 = 11215234084714 := by decide
theorem cert_e2419141062506 : check e2419141062506 [[],[]] .smaller = true := by decide
def e2419141063134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2419141063134 : Closed e2419141063134 ∧ code e2419141063134 = 11215234085342 := by decide
theorem cert_e2419141063134 : check e2419141063134 [[],[]] .three = true := by decide
def e2419141063158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2419141063158 : Closed e2419141063158 ∧ code e2419141063158 = 11215234085366 := by decide
theorem cert_e2419141063158 : check e2419141063158 [[],[]] .three = true := by decide
def e2419141063534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2419141063534 : Closed e2419141063534 ∧ code e2419141063534 = 11215234085742 := by decide
theorem cert_e2419141063534 : check e2419141063534 [[],[]] .smaller = true := by decide
def e2419141063542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2419141063542 : Closed e2419141063542 ∧ code e2419141063542 = 11215234085750 := by decide
theorem cert_e2419141063542 : check e2419141063542 [[],[]] .smaller = true := by decide
def e2419141063598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2419141063598 : Closed e2419141063598 ∧ code e2419141063598 = 11215234085806 := by decide
theorem cert_e2419141063598 : check e2419141063598 [[],[]] .smaller = true := by decide
def e2419141063610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2419141063610 : Closed e2419141063610 ∧ code e2419141063610 = 11215234085818 := by decide
theorem cert_e2419141063610 : check e2419141063610 [[],[]] .smaller = true := by decide
def e2419141063638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2419141063638 : Closed e2419141063638 ∧ code e2419141063638 = 11215234085846 := by decide
theorem cert_e2419141063638 : check e2419141063638 [[],[]] .smaller = true := by decide
def e2419141063642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2419141063642 : Closed e2419141063642 ∧ code e2419141063642 = 11215234085850 := by decide
theorem cert_e2419141063642 : check e2419141063642 [[],[]] .smaller = true := by decide
def e2419141063918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2419141063918 : Closed e2419141063918 ∧ code e2419141063918 = 11215234086126 := by decide
theorem cert_e2419141063918 : check e2419141063918 [[],[]] .smaller = true := by decide
def e2419141063926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2419141063926 : Closed e2419141063926 ∧ code e2419141063926 = 11215234086134 := by decide
theorem cert_e2419141063926 : check e2419141063926 [[],[]] .smaller = true := by decide
def e2419141064254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2419141064254 : Closed e2419141064254 ∧ code e2419141064254 = 11215234086462 := by decide
theorem cert_e2419141064254 : check e2419141064254 [[],[]] .three = true := by decide
def e2419141064302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141064302 : Closed e2419141064302 ∧ code e2419141064302 = 11215234086510 := by decide
theorem cert_e2419141064302 : check e2419141064302 [[],[]] .smaller = true := by decide
def e2419141064314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141064314 : Closed e2419141064314 ∧ code e2419141064314 = 11215234086522 := by decide
theorem cert_e2419141064314 : check e2419141064314 [[],[]] .smaller = true := by decide
def e2419141064502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141064502 : Closed e2419141064502 ∧ code e2419141064502 = 11215234086710 := by decide
theorem cert_e2419141064502 : check e2419141064502 [[],[]] .smaller = true := by decide
def e2419141064506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141064506 : Closed e2419141064506 ∧ code e2419141064506 = 11215234086714 := by decide
theorem cert_e2419141064506 : check e2419141064506 [[],[]] .smaller = true := by decide
def e2419141064590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2419141064590 : Closed e2419141064590 ∧ code e2419141064590 = 11215234086798 := by decide
theorem cert_e2419141064590 : check e2419141064590 [[],[]] .three = true := by decide
def e2419141064926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2419141064926 : Closed e2419141064926 ∧ code e2419141064926 = 11215234087134 := by decide
theorem cert_e2419141064926 : check e2419141064926 [[],[]] .three = true := by decide
def e2419141064942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2419141064942 : Closed e2419141064942 ∧ code e2419141064942 = 11215234087150 := by decide
theorem cert_e2419141064942 : check e2419141064942 [[],[]] .smaller = true := by decide
def e2419141064950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2419141064950 : Closed e2419141064950 ∧ code e2419141064950 = 11215234087158 := by decide
theorem cert_e2419141064950 : check e2419141064950 [[],[]] .smaller = true := by decide
def e2419141064954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2419141064954 : Closed e2419141064954 ∧ code e2419141064954 = 11215234087162 := by decide
theorem cert_e2419141064954 : check e2419141064954 [[],[]] .three = true := by decide
def e2419141065134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2419141065134 : Closed e2419141065134 ∧ code e2419141065134 = 11215234087342 := by decide
theorem cert_e2419141065134 : check e2419141065134 [[],[]] .smaller = true := by decide
def e2419141065146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2419141065146 : Closed e2419141065146 ∧ code e2419141065146 = 11215234087354 := by decide
theorem cert_e2419141065146 : check e2419141065146 [[],[]] .smaller = true := by decide
def e2419141065194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2419141065194 : Closed e2419141065194 ∧ code e2419141065194 = 11215234087402 := by decide
theorem cert_e2419141065194 : check e2419141065194 [[],[]] .smaller = true := by decide
def e2419141065278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2419141065278 : Closed e2419141065278 ∧ code e2419141065278 = 11215234087486 := by decide
theorem cert_e2419141065278 : check e2419141065278 [[],[]] .three = true := by decide
def e2419141065326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141065326 : Closed e2419141065326 ∧ code e2419141065326 = 11215234087534 := by decide
theorem cert_e2419141065326 : check e2419141065326 [[],[]] .smaller = true := by decide
def e2419141065338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141065338 : Closed e2419141065338 ∧ code e2419141065338 = 11215234087546 := by decide
theorem cert_e2419141065338 : check e2419141065338 [[],[]] .smaller = true := by decide
def e2419141065502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2419141065502 : Closed e2419141065502 ∧ code e2419141065502 = 11215234087710 := by decide
theorem cert_e2419141065502 : check e2419141065502 [[],[]] .smaller = true := by decide
def e2419141065614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2419141065614 : Closed e2419141065614 ∧ code e2419141065614 = 11215234087822 := by decide
theorem cert_e2419141065614 : check e2419141065614 [[],[]] .smaller = true := by decide
def e2419141065626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141065626 : Closed e2419141065626 ∧ code e2419141065626 = 11215234087834 := by decide
theorem cert_e2419141065626 : check e2419141065626 [[],[]] .smaller = true := by decide
def e2419141065670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2419141065670 : Closed e2419141065670 ∧ code e2419141065670 = 11215234087878 := by decide
theorem cert_e2419141065670 : check e2419141065670 [[],[]] .three = true := by decide
def e2419141065694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3)))))))
theorem wire_e2419141065694 : Closed e2419141065694 ∧ code e2419141065694 = 11215234087902 := by decide
theorem cert_e2419141065694 : check e2419141065694 [[],[]] .three = true := by decide
def e2419141065846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2419141065846 : Closed e2419141065846 ∧ code e2419141065846 = 11215234088054 := by decide
theorem cert_e2419141065846 : check e2419141065846 [[],[]] .smaller = true := by decide
def e2419141065942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2419141065942 : Closed e2419141065942 ∧ code e2419141065942 = 11215234088150 := by decide
theorem cert_e2419141065942 : check e2419141065942 [[],[]] .smaller = true := by decide
def e2419141065946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2419141065946 : Closed e2419141065946 ∧ code e2419141065946 = 11215234088154 := by decide
theorem cert_e2419141065946 : check e2419141065946 [[],[]] .smaller = true := by decide
def e2419141065962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2419141065962 : Closed e2419141065962 ∧ code e2419141065962 = 11215234088170 := by decide
theorem cert_e2419141065962 : check e2419141065962 [[],[]] .smaller = true := by decide
def e2419141066038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141066038 : Closed e2419141066038 ∧ code e2419141066038 = 11215234088246 := by decide
theorem cert_e2419141066038 : check e2419141066038 [[],[]] .smaller = true := by decide
def e2419141066042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141066042 : Closed e2419141066042 ∧ code e2419141066042 = 11215234088250 := by decide
theorem cert_e2419141066042 : check e2419141066042 [[],[]] .smaller = true := by decide
def e2419141066126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2419141066126 : Closed e2419141066126 ∧ code e2419141066126 = 11215234088334 := by decide
theorem cert_e2419141066126 : check e2419141066126 [[],[]] .smaller = true := by decide
def e2419141066138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141066138 : Closed e2419141066138 ∧ code e2419141066138 = 11215234088346 := by decide
theorem cert_e2419141066138 : check e2419141066138 [[],[]] .smaller = true := by decide
def e2419141066206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3)))))))
theorem wire_e2419141066206 : Closed e2419141066206 ∧ code e2419141066206 = 11215234088414 := by decide
theorem cert_e2419141066206 : check e2419141066206 [[],[]] .three = true := by decide
def e2419141066222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2)))))))
theorem wire_e2419141066222 : Closed e2419141066222 ∧ code e2419141066222 = 11215234088430 := by decide
theorem cert_e2419141066222 : check e2419141066222 [[],[]] .three = true := by decide
def e2419141066294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2419141066294 : Closed e2419141066294 ∧ code e2419141066294 = 11215234088502 := by decide
theorem cert_e2419141066294 : check e2419141066294 [[],[]] .three = true := by decide
def e2419141066298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2419141066298 : Closed e2419141066298 ∧ code e2419141066298 = 11215234088506 := by decide
theorem cert_e2419141066298 : check e2419141066298 [[],[]] .three = true := by decide
def e2419141066382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2419141066382 : Closed e2419141066382 ∧ code e2419141066382 = 11215234088590 := by decide
theorem cert_e2419141066382 : check e2419141066382 [[],[]] .three = true := by decide
def e2419141066438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2419141066438 : Closed e2419141066438 ∧ code e2419141066438 = 11215234088646 := by decide
theorem cert_e2419141066438 : check e2419141066438 [[],[]] .three = true := by decide
def e2419141066462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3)))))))
theorem wire_e2419141066462 : Closed e2419141066462 ∧ code e2419141066462 = 11215234088670 := by decide
theorem cert_e2419141066462 : check e2419141066462 [[],[]] .three = true := by decide
def e2419141066478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2)))))))
theorem wire_e2419141066478 : Closed e2419141066478 ∧ code e2419141066478 = 11215234088686 := by decide
theorem cert_e2419141066478 : check e2419141066478 [[],[]] .three = true := by decide
def e2419141066486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1)))))))
theorem wire_e2419141066486 : Closed e2419141066486 ∧ code e2419141066486 = 11215234088694 := by decide
theorem cert_e2419141066486 : check e2419141066486 [[],[]] .three = true := by decide
def e2419141067742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2419141067742 : Closed e2419141067742 ∧ code e2419141067742 = 11215234089950 := by decide
theorem cert_e2419141067742 : check e2419141067742 [[],[]] .smaller = true := by decide
def e2419141067758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2419141067758 : Closed e2419141067758 ∧ code e2419141067758 = 11215234089966 := by decide
theorem cert_e2419141067758 : check e2419141067758 [[],[]] .smaller = true := by decide
def e2419141069678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419141069678 : Closed e2419141069678 ∧ code e2419141069678 = 11215234091886 := by decide
theorem cert_e2419141069678 : check e2419141069678 [[],[]] .smaller = true := by decide
def e2419141069686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419141069686 : Closed e2419141069686 ∧ code e2419141069686 = 11215234091894 := by decide
theorem cert_e2419141069686 : check e2419141069686 [[],[]] .smaller = true := by decide
def e2419141069742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419141069742 : Closed e2419141069742 ∧ code e2419141069742 = 11215234091950 := by decide
theorem cert_e2419141069742 : check e2419141069742 [[],[]] .smaller = true := by decide
def e2419141069754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419141069754 : Closed e2419141069754 ∧ code e2419141069754 = 11215234091962 := by decide
theorem cert_e2419141069754 : check e2419141069754 [[],[]] .smaller = true := by decide
def e2419141069782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419141069782 : Closed e2419141069782 ∧ code e2419141069782 = 11215234091990 := by decide
theorem cert_e2419141069782 : check e2419141069782 [[],[]] .smaller = true := by decide
def e2419141069786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419141069786 : Closed e2419141069786 ∧ code e2419141069786 = 11215234091994 := by decide
theorem cert_e2419141069786 : check e2419141069786 [[],[]] .smaller = true := by decide
def e2419141070062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419141070062 : Closed e2419141070062 ∧ code e2419141070062 = 11215234092270 := by decide
theorem cert_e2419141070062 : check e2419141070062 [[],[]] .smaller = true := by decide
def e2419141070070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419141070070 : Closed e2419141070070 ∧ code e2419141070070 = 11215234092278 := by decide
theorem cert_e2419141070070 : check e2419141070070 [[],[]] .smaller = true := by decide
def e2419141070398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2419141070398 : Closed e2419141070398 ∧ code e2419141070398 = 11215234092606 := by decide
theorem cert_e2419141070398 : check e2419141070398 [[],[]] .three = true := by decide
def e2419141070446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141070446 : Closed e2419141070446 ∧ code e2419141070446 = 11215234092654 := by decide
theorem cert_e2419141070446 : check e2419141070446 [[],[]] .smaller = true := by decide
def e2419141070458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141070458 : Closed e2419141070458 ∧ code e2419141070458 = 11215234092666 := by decide
theorem cert_e2419141070458 : check e2419141070458 [[],[]] .smaller = true := by decide
def e2419141070646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419141070646 : Closed e2419141070646 ∧ code e2419141070646 = 11215234092854 := by decide
theorem cert_e2419141070646 : check e2419141070646 [[],[]] .smaller = true := by decide
def e2419141070650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419141070650 : Closed e2419141070650 ∧ code e2419141070650 = 11215234092858 := by decide
theorem cert_e2419141070650 : check e2419141070650 [[],[]] .smaller = true := by decide
def e2419141070734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2419141070734 : Closed e2419141070734 ∧ code e2419141070734 = 11215234092942 := by decide
theorem cert_e2419141070734 : check e2419141070734 [[],[]] .three = true := by decide
def e2419141075422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2419141075422 : Closed e2419141075422 ∧ code e2419141075422 = 11215234097630 := by decide
theorem cert_e2419141075422 : check e2419141075422 [[],[]] .smaller = true := by decide
def e2419141075446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2419141075446 : Closed e2419141075446 ∧ code e2419141075446 = 11215234097654 := by decide
theorem cert_e2419141075446 : check e2419141075446 [[],[]] .smaller = true := by decide
def e2419141076398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2419141076398 : Closed e2419141076398 ∧ code e2419141076398 = 11215234098606 := by decide
theorem cert_e2419141076398 : check e2419141076398 [[],[]] .smaller = true := by decide
def e2419141076410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2419141076410 : Closed e2419141076410 ∧ code e2419141076410 = 11215234098618 := by decide
theorem cert_e2419141076410 : check e2419141076410 [[],[]] .smaller = true := by decide
def e2419141076458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2419141076458 : Closed e2419141076458 ∧ code e2419141076458 = 11215234098666 := by decide
theorem cert_e2419141076458 : check e2419141076458 [[],[]] .smaller = true := by decide
def e2419141076542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2419141076542 : Closed e2419141076542 ∧ code e2419141076542 = 11215234098750 := by decide
theorem cert_e2419141076542 : check e2419141076542 [[],[]] .three = true := by decide
def e2419141076590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141076590 : Closed e2419141076590 ∧ code e2419141076590 = 11215234098798 := by decide
theorem cert_e2419141076590 : check e2419141076590 [[],[]] .smaller = true := by decide
def e2419141076602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141076602 : Closed e2419141076602 ∧ code e2419141076602 = 11215234098810 := by decide
theorem cert_e2419141076602 : check e2419141076602 [[],[]] .smaller = true := by decide
def e2419141076766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2419141076766 : Closed e2419141076766 ∧ code e2419141076766 = 11215234098974 := by decide
theorem cert_e2419141076766 : check e2419141076766 [[],[]] .smaller = true := by decide
def e2419141076878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2419141076878 : Closed e2419141076878 ∧ code e2419141076878 = 11215234099086 := by decide
theorem cert_e2419141076878 : check e2419141076878 [[],[]] .smaller = true := by decide
def e2419141076890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141076890 : Closed e2419141076890 ∧ code e2419141076890 = 11215234099098 := by decide
theorem cert_e2419141076890 : check e2419141076890 [[],[]] .smaller = true := by decide
def e2419141076934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2419141076934 : Closed e2419141076934 ∧ code e2419141076934 = 11215234099142 := by decide
theorem cert_e2419141076934 : check e2419141076934 [[],[]] .three = true := by decide
def e2419141076958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3))))))))
theorem wire_e2419141076958 : Closed e2419141076958 ∧ code e2419141076958 = 11215234099166 := by decide
theorem cert_e2419141076958 : check e2419141076958 [[],[]] .three = true := by decide
def e2419141079278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2419141079278 : Closed e2419141079278 ∧ code e2419141079278 = 11215234101486 := by decide
theorem cert_e2419141079278 : check e2419141079278 [[],[]] .smaller = true := by decide
def e2419141079286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2419141079286 : Closed e2419141079286 ∧ code e2419141079286 = 11215234101494 := by decide
theorem cert_e2419141079286 : check e2419141079286 [[],[]] .smaller = true := by decide
def e2419141079766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2419141079766 : Closed e2419141079766 ∧ code e2419141079766 = 11215234101974 := by decide
theorem cert_e2419141079766 : check e2419141079766 [[],[]] .smaller = true := by decide
def e2419141079770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2419141079770 : Closed e2419141079770 ∧ code e2419141079770 = 11215234101978 := by decide
theorem cert_e2419141079770 : check e2419141079770 [[],[]] .smaller = true := by decide
def e2419141079786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2419141079786 : Closed e2419141079786 ∧ code e2419141079786 = 11215234101994 := by decide
theorem cert_e2419141079786 : check e2419141079786 [[],[]] .smaller = true := by decide
def e2419141079862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419141079862 : Closed e2419141079862 ∧ code e2419141079862 = 11215234102070 := by decide
theorem cert_e2419141079862 : check e2419141079862 [[],[]] .smaller = true := by decide
def e2419141079866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419141079866 : Closed e2419141079866 ∧ code e2419141079866 = 11215234102074 := by decide
theorem cert_e2419141079866 : check e2419141079866 [[],[]] .smaller = true := by decide
def e2419141079950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2419141079950 : Closed e2419141079950 ∧ code e2419141079950 = 11215234102158 := by decide
theorem cert_e2419141079950 : check e2419141079950 [[],[]] .smaller = true := by decide
def e2419141079962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141079962 : Closed e2419141079962 ∧ code e2419141079962 = 11215234102170 := by decide
theorem cert_e2419141079962 : check e2419141079962 [[],[]] .smaller = true := by decide
def e2419141080030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3))))))))
theorem wire_e2419141080030 : Closed e2419141080030 ∧ code e2419141080030 = 11215234102238 := by decide
theorem cert_e2419141080030 : check e2419141080030 [[],[]] .three = true := by decide
def e2419141080046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2))))))))
theorem wire_e2419141080046 : Closed e2419141080046 ∧ code e2419141080046 = 11215234102254 := by decide
theorem cert_e2419141080046 : check e2419141080046 [[],[]] .three = true := by decide
def e2419141081486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2419141081486 : Closed e2419141081486 ∧ code e2419141081486 = 11215234103694 := by decide
theorem cert_e2419141081486 : check e2419141081486 [[],[]] .three = true := by decide
def e2419141081542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2419141081542 : Closed e2419141081542 ∧ code e2419141081542 = 11215234103750 := by decide
theorem cert_e2419141081542 : check e2419141081542 [[],[]] .three = true := by decide
def e2419141081566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3))))))))
theorem wire_e2419141081566 : Closed e2419141081566 ∧ code e2419141081566 = 11215234103774 := by decide
theorem cert_e2419141081566 : check e2419141081566 [[],[]] .three = true := by decide
def e2419141081582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419141081582 : Closed e2419141081582 ∧ code e2419141081582 = 11215234103790 := by decide
theorem cert_e2419141081582 : check e2419141081582 [[],[]] .three = true := by decide
def e2419141081590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1))))))))
theorem wire_e2419141081590 : Closed e2419141081590 ∧ code e2419141081590 = 11215234103798 := by decide
theorem cert_e2419141081590 : check e2419141081590 [[],[]] .three = true := by decide
def e2419141085038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2419141085038 : Closed e2419141085038 ∧ code e2419141085038 = 11215234107246 := by decide
theorem cert_e2419141085038 : check e2419141085038 [[],[]] .smaller = true := by decide
def e2419141085050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2419141085050 : Closed e2419141085050 ∧ code e2419141085050 = 11215234107258 := by decide
theorem cert_e2419141085050 : check e2419141085050 [[],[]] .smaller = true := by decide
def e2419141085146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2419141085146 : Closed e2419141085146 ∧ code e2419141085146 = 11215234107354 := by decide
theorem cert_e2419141085146 : check e2419141085146 [[],[]] .smaller = true := by decide
def e2419141086430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2419141086430 : Closed e2419141086430 ∧ code e2419141086430 = 11215234108638 := by decide
theorem cert_e2419141086430 : check e2419141086430 [[],[]] .three = true := by decide
def e2419141086446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2419141086446 : Closed e2419141086446 ∧ code e2419141086446 = 11215234108654 := by decide
theorem cert_e2419141086446 : check e2419141086446 [[],[]] .smaller = true := by decide
def e2419141086454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2419141086454 : Closed e2419141086454 ∧ code e2419141086454 = 11215234108662 := by decide
theorem cert_e2419141086454 : check e2419141086454 [[],[]] .smaller = true := by decide
def e2419141086458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2419141086458 : Closed e2419141086458 ∧ code e2419141086458 = 11215234108666 := by decide
theorem cert_e2419141086458 : check e2419141086458 [[],[]] .three = true := by decide
def e2419141086830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141086830 : Closed e2419141086830 ∧ code e2419141086830 = 11215234109038 := by decide
theorem cert_e2419141086830 : check e2419141086830 [[],[]] .smaller = true := by decide
def e2419141086842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141086842 : Closed e2419141086842 ∧ code e2419141086842 = 11215234109050 := by decide
theorem cert_e2419141086842 : check e2419141086842 [[],[]] .smaller = true := by decide
def e2419141087030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141087030 : Closed e2419141087030 ∧ code e2419141087030 = 11215234109238 := by decide
theorem cert_e2419141087030 : check e2419141087030 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419141049302
#print axioms Blc.Floor43.cert_e2419141049306
