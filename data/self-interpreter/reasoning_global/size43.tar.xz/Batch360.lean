import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419155033822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2419155033822 : Closed e2419155033822 ∧ code e2419155033822 = 11215248056030 := by decide
theorem cert_e2419155033822 : check e2419155033822 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155033846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2419155033846 : Closed e2419155033846 ∧ code e2419155033846 = 11215248056054 := by decide
theorem cert_e2419155033846 : check e2419155033846 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155033966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2419155033966 : Closed e2419155033966 ∧ code e2419155033966 = 11215248056174 := by decide
private def t_e2419155033966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem cert_e2419155033966 : ¬ IsSelfInterpreter e2419155033966 :=
  wSource (t := t_e2419155033966) (replay_sound (ps := []) (t := e2419155033966) (by decide)) (by decide)
def e2419155033974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2419155033974 : Closed e2419155033974 ∧ code e2419155033974 = 11215248056182 := by decide
theorem cert_e2419155033974 : check e2419155033974 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155039198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419155039198 : Closed e2419155039198 ∧ code e2419155039198 = 11215248061406 := by decide
theorem cert_e2419155039198 : check e2419155039198 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155039214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419155039214 : Closed e2419155039214 ∧ code e2419155039214 = 11215248061422 := by decide
theorem cert_e2419155039214 : check e2419155039214 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155040734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419155040734 : Closed e2419155040734 ∧ code e2419155040734 = 11215248062942 := by decide
theorem cert_e2419155040734 : check e2419155040734 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155040758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419155040758 : Closed e2419155040758 ∧ code e2419155040758 = 11215248062966 := by decide
theorem cert_e2419155040758 : check e2419155040758 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155041518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419155041518 : Closed e2419155041518 ∧ code e2419155041518 = 11215248063726 := by decide
theorem cert_e2419155041518 : check e2419155041518 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155041526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419155041526 : Closed e2419155041526 ∧ code e2419155041526 = 11215248063734 := by decide
theorem cert_e2419155041526 : check e2419155041526 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155098478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2419155098478 : Closed e2419155098478 ∧ code e2419155098478 = 11215248120686 := by decide
theorem cert_e2419155098478 : check e2419155098478 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419155098486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2419155098486 : Closed e2419155098486 ∧ code e2419155098486 = 11215248120694 := by decide
theorem cert_e2419155098486 : check e2419155098486 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419155098550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2419155098550 : Closed e2419155098550 ∧ code e2419155098550 = 11215248120758 := by decide
private def t_e2419155098550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem cert_e2419155098550 : ¬ IsSelfInterpreter e2419155098550 :=
  wSource (t := t_e2419155098550) (replay_sound (ps := []) (t := e2419155098550) (by decide)) (by decide)
def e2419155098990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2419155098990 : Closed e2419155098990 ∧ code e2419155098990 = 11215248121198 := by decide
theorem cert_e2419155098990 : check e2419155098990 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419155098998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2419155098998 : Closed e2419155098998 ∧ code e2419155098998 = 11215248121206 := by decide
theorem cert_e2419155098998 : check e2419155098998 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419155099054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2419155099054 : Closed e2419155099054 ∧ code e2419155099054 = 11215248121262 := by decide
theorem cert_e2419155099054 : check e2419155099054 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419155099066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2419155099066 : Closed e2419155099066 ∧ code e2419155099066 = 11215248121274 := by decide
theorem cert_e2419155099066 : check e2419155099066 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419155099094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2419155099094 : Closed e2419155099094 ∧ code e2419155099094 = 11215248121302 := by decide
theorem cert_e2419155099094 : check e2419155099094 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419155099098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2419155099098 : Closed e2419155099098 ∧ code e2419155099098 = 11215248121306 := by decide
theorem cert_e2419155099098 : check e2419155099098 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419155099318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2419155099318 : Closed e2419155099318 ∧ code e2419155099318 = 11215248121526 := by decide
private def t_e2419155099318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem cert_e2419155099318 : ¬ IsSelfInterpreter e2419155099318 :=
  wSource (t := t_e2419155099318) (replay_sound (ps := []) (t := e2419155099318) (by decide)) (by decide)
def e2419155099350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2419155099350 : Closed e2419155099350 ∧ code e2419155099350 = 11215248121558 := by decide
def e2419155099354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2419155099354 : Closed e2419155099354 ∧ code e2419155099354 = 11215248121562 := by decide
def e2419155101550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2419155101550 : Closed e2419155101550 ∧ code e2419155101550 = 11215248123758 := by decide
theorem cert_e2419155101550 : check e2419155101550 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e2419155101558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2419155101558 : Closed e2419155101558 ∧ code e2419155101558 = 11215248123766 := by decide
theorem cert_e2419155101558 : check e2419155101558 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e2419155101622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2419155101622 : Closed e2419155101622 ∧ code e2419155101622 = 11215248123830 := by decide
def e2419155102958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419155102958 : Closed e2419155102958 ∧ code e2419155102958 = 11215248125166 := by decide
theorem cert_e2419155102958 : check e2419155102958 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419155102966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419155102966 : Closed e2419155102966 ∧ code e2419155102966 = 11215248125174 := by decide
theorem cert_e2419155102966 : check e2419155102966 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419155103350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419155103350 : Closed e2419155103350 ∧ code e2419155103350 = 11215248125558 := by decide
private def t_e2419155103350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem cert_e2419155103350 : ¬ IsSelfInterpreter e2419155103350 :=
  wSource (t := t_e2419155103350) (replay_sound (ps := []) (t := e2419155103350) (by decide)) (by decide)
def e2419155104622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2419155104622 : Closed e2419155104622 ∧ code e2419155104622 = 11215248126830 := by decide
theorem cert_e2419155104622 : check e2419155104622 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155104630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2419155104630 : Closed e2419155104630 ∧ code e2419155104630 = 11215248126838 := by decide
theorem cert_e2419155104630 : check e2419155104630 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155104686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2419155104686 : Closed e2419155104686 ∧ code e2419155104686 = 11215248126894 := by decide
theorem cert_e2419155104686 : check e2419155104686 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155104698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2419155104698 : Closed e2419155104698 ∧ code e2419155104698 = 11215248126906 := by decide
theorem cert_e2419155104698 : check e2419155104698 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155104726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2419155104726 : Closed e2419155104726 ∧ code e2419155104726 = 11215248126934 := by decide
theorem cert_e2419155104726 : check e2419155104726 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155104730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2419155104730 : Closed e2419155104730 ∧ code e2419155104730 = 11215248126938 := by decide
theorem cert_e2419155104730 : check e2419155104730 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155105006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419155105006 : Closed e2419155105006 ∧ code e2419155105006 = 11215248127214 := by decide
theorem cert_e2419155105006 : check e2419155105006 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155105014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419155105014 : Closed e2419155105014 ∧ code e2419155105014 = 11215248127222 := by decide
theorem cert_e2419155105014 : check e2419155105014 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155105390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419155105390 : Closed e2419155105390 ∧ code e2419155105390 = 11215248127598 := by decide
theorem cert_e2419155105390 : check e2419155105390 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155105402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419155105402 : Closed e2419155105402 ∧ code e2419155105402 = 11215248127610 := by decide
theorem cert_e2419155105402 : check e2419155105402 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155105590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419155105590 : Closed e2419155105590 ∧ code e2419155105590 = 11215248127798 := by decide
theorem cert_e2419155105590 : check e2419155105590 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155105594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419155105594 : Closed e2419155105594 ∧ code e2419155105594 = 11215248127802 := by decide
theorem cert_e2419155105594 : check e2419155105594 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155106230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2419155106230 : Closed e2419155106230 ∧ code e2419155106230 = 11215248128438 := by decide
def e2419155106262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2419155106262 : Closed e2419155106262 ∧ code e2419155106262 = 11215248128470 := by decide
def e2419155106266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2419155106266 : Closed e2419155106266 ∧ code e2419155106266 = 11215248128474 := by decide
def e2419155106422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419155106422 : Closed e2419155106422 ∧ code e2419155106422 = 11215248128630 := by decide
private def t_e2419155106422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem cert_e2419155106422 : ¬ IsSelfInterpreter e2419155106422 :=
  wSource (t := t_e2419155106422) (replay_sound (ps := []) (t := e2419155106422) (by decide)) (by decide)
def e2419155106614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419155106614 : Closed e2419155106614 ∧ code e2419155106614 = 11215248128822 := by decide
def e2419155106618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419155106618 : Closed e2419155106618 ∧ code e2419155106618 = 11215248128826 := by decide
def e2419155113838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2419155113838 : Closed e2419155113838 ∧ code e2419155113838 = 11215248136046 := by decide
theorem cert_e2419155113838 : check e2419155113838 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419155113846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2419155113846 : Closed e2419155113846 ∧ code e2419155113846 = 11215248136054 := by decide
theorem cert_e2419155113846 : check e2419155113846 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155113910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2419155113910 : Closed e2419155113910 ∧ code e2419155113910 = 11215248136118 := by decide
theorem cert_e2419155113910 : check e2419155113910 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e2419155115246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419155115246 : Closed e2419155115246 ∧ code e2419155115246 = 11215248137454 := by decide
theorem cert_e2419155115246 : check e2419155115246 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155115254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419155115254 : Closed e2419155115254 ∧ code e2419155115254 = 11215248137462 := by decide
theorem cert_e2419155115254 : check e2419155115254 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419155115638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419155115638 : Closed e2419155115638 ∧ code e2419155115638 = 11215248137846 := by decide
def e2419155127150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419155127150 : Closed e2419155127150 ∧ code e2419155127150 = 11215248149358 := by decide
theorem cert_e2419155127150 : check e2419155127150 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419155127158 : Closed e2419155127158 ∧ code e2419155127158 = 11215248149366 := by decide
theorem cert_e2419155127158 : check e2419155127158 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419155127214 : Closed e2419155127214 ∧ code e2419155127214 = 11215248149422 := by decide
theorem cert_e2419155127214 : check e2419155127214 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419155127226 : Closed e2419155127226 ∧ code e2419155127226 = 11215248149434 := by decide
theorem cert_e2419155127226 : check e2419155127226 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419155127254 : Closed e2419155127254 ∧ code e2419155127254 = 11215248149462 := by decide
theorem cert_e2419155127254 : check e2419155127254 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419155127258 : Closed e2419155127258 ∧ code e2419155127258 = 11215248149466 := by decide
theorem cert_e2419155127258 : check e2419155127258 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419155127534 : Closed e2419155127534 ∧ code e2419155127534 = 11215248149742 := by decide
theorem cert_e2419155127534 : check e2419155127534 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419155127542 : Closed e2419155127542 ∧ code e2419155127542 = 11215248149750 := by decide
theorem cert_e2419155127542 : check e2419155127542 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419155127918 : Closed e2419155127918 ∧ code e2419155127918 = 11215248150126 := by decide
theorem cert_e2419155127918 : check e2419155127918 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155127930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419155127930 : Closed e2419155127930 ∧ code e2419155127930 = 11215248150138 := by decide
theorem cert_e2419155127930 : check e2419155127930 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155128118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419155128118 : Closed e2419155128118 ∧ code e2419155128118 = 11215248150326 := by decide
theorem cert_e2419155128118 : check e2419155128118 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155128122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419155128122 : Closed e2419155128122 ∧ code e2419155128122 = 11215248150330 := by decide
theorem cert_e2419155128122 : check e2419155128122 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2419155133878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2419155133878 : Closed e2419155133878 ∧ code e2419155133878 = 11215248156086 := by decide
def e2419155133910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2419155133910 : Closed e2419155133910 ∧ code e2419155133910 = 11215248156118 := by decide
def e2419155133914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2419155133914 : Closed e2419155133914 ∧ code e2419155133914 = 11215248156122 := by decide
def e2419155134070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419155134070 : Closed e2419155134070 ∧ code e2419155134070 = 11215248156278 := by decide
def e2419155134262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419155134262 : Closed e2419155134262 ∧ code e2419155134262 = 11215248156470 := by decide
def e2419155134266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419155134266 : Closed e2419155134266 ∧ code e2419155134266 = 11215248156474 := by decide
def e2419155471214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419155471214 : Closed e2419155471214 ∧ code e2419155471214 = 11215248493422 := by decide
def e2419155471222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419155471222 : Closed e2419155471222 ∧ code e2419155471222 = 11215248493430 := by decide
private def t_e2419155471222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e2419155471222 : ¬ IsSelfInterpreter e2419155471222 :=
  wSource (t := t_e2419155471222) (replay_sound (ps := []) (t := e2419155471222) (by decide)) (by decide)
def e2419155471278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419155471278 : Closed e2419155471278 ∧ code e2419155471278 = 11215248493486 := by decide
def e2419155471290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419155471290 : Closed e2419155471290 ∧ code e2419155471290 = 11215248493498 := by decide
def e2419155471318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419155471318 : Closed e2419155471318 ∧ code e2419155471318 = 11215248493526 := by decide
private def t_e2419155471318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e2419155471318 : ¬ IsSelfInterpreter e2419155471318 :=
  wSource (t := t_e2419155471318) (replay_sound (ps := []) (t := e2419155471318) (by decide)) (by decide)
def e2419155471322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419155471322 : Closed e2419155471322 ∧ code e2419155471322 = 11215248493530 := by decide
def e2419155471598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419155471598 : Closed e2419155471598 ∧ code e2419155471598 = 11215248493806 := by decide
def e2419155471606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419155471606 : Closed e2419155471606 ∧ code e2419155471606 = 11215248493814 := by decide
def e2419155471982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419155471982 : Closed e2419155471982 ∧ code e2419155471982 = 11215248494190 := by decide
def e2419155471994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419155471994 : Closed e2419155471994 ∧ code e2419155471994 = 11215248494202 := by decide
def e2419155472182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419155472182 : Closed e2419155472182 ∧ code e2419155472182 = 11215248494390 := by decide
def e2419155472186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419155472186 : Closed e2419155472186 ∧ code e2419155472186 = 11215248494394 := by decide
def e2419177294702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419177294702 : Closed e2419177294702 ∧ code e2419177294702 = 11215270316910 := by decide
theorem cert_e2419177294702 : check e2419177294702 [[],[],[],[]] .sourceHead = true := by decide
def e2419177294710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419177294710 : Closed e2419177294710 ∧ code e2419177294710 = 11215270316918 := by decide
theorem cert_e2419177294710 : check e2419177294710 [[],[],[],[]] .sourceHead = true := by decide
def e2419177294766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419177294766 : Closed e2419177294766 ∧ code e2419177294766 = 11215270316974 := by decide
theorem cert_e2419177294766 : check e2419177294766 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2419177294778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419177294778 : Closed e2419177294778 ∧ code e2419177294778 = 11215270316986 := by decide
private def t_e2419177294778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2419177294778 : ¬ IsSelfInterpreter e2419177294778 :=
  wSource (t := t_e2419177294778) (replay_sound (ps := []) (t := e2419177294778) (by decide)) (by decide)
def e2419177294806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419177294806 : Closed e2419177294806 ∧ code e2419177294806 = 11215270317014 := by decide
theorem cert_e2419177294806 : check e2419177294806 [[],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2419177294810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419177294810 : Closed e2419177294810 ∧ code e2419177294810 = 11215270317018 := by decide
private def t_e2419177294810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2419177294810 : ¬ IsSelfInterpreter e2419177294810 :=
  wSource (t := t_e2419177294810) (replay_sound (ps := []) (t := e2419177294810) (by decide)) (by decide)
def e2419177295086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419177295086 : Closed e2419177295086 ∧ code e2419177295086 = 11215270317294 := by decide
theorem cert_e2419177295086 : check e2419177295086 [[],[],[],[]] .sourceHead = true := by decide
def e2419177295094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419177295094 : Closed e2419177295094 ∧ code e2419177295094 = 11215270317302 := by decide
theorem cert_e2419177295094 : check e2419177295094 [[],[],[],[]] .sourceHead = true := by decide
def e2419177295470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419177295470 : Closed e2419177295470 ∧ code e2419177295470 = 11215270317678 := by decide
theorem cert_e2419177295470 : checkPay e2419177295470 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[],[],[.under],[.under,.under,.left,.right,.under],[.under,.under,.left,.right,.under],[.under,.under,.left,.right,.under,.under],[.under,.under,.right,.right,.under],[.under,.under,.right,.right,.under],[.under,.under,.right,.right,.under,.under]] = true := by decide
def e2419177295482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419177295482 : Closed e2419177295482 ∧ code e2419177295482 = 11215270317690 := by decide
theorem cert_e2419177295482 : check e2419177295482 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2419177295670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419177295670 : Closed e2419177295670 ∧ code e2419177295670 = 11215270317878 := by decide
theorem cert_e2419177295670 : check e2419177295670 [[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e2419177295674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419177295674 : Closed e2419177295674 ∧ code e2419177295674 = 11215270317882 := by decide
theorem cert_e2419177295674 : check e2419177295674 [[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2419186478522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e2419186478522 : Closed e2419186478522 ∧ code e2419186478522 = 11215279500730 := by decide
theorem cert_e2419186478522 : check e2419186478522 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .chain = true := by decide
def e2419186478554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e2419186478554 : Closed e2419186478554 ∧ code e2419186478554 = 11215279500762 := by decide
theorem cert_e2419186478554 : check e2419186478554 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .chain = true := by decide
def e2419186478778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e2419186478778 : Closed e2419186478778 ∧ code e2419186478778 = 11215279500986 := by decide
def e2419186478826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e2419186478826 : Closed e2419186478826 ∧ code e2419186478826 = 11215279501034 := by decide
theorem cert_e2419186478826 : check e2419186478826 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2419186478938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e2419186478938 : Closed e2419186478938 ∧ code e2419186478938 = 11215279501146 := by decide
theorem cert_e2419186478938 : check e2419186478938 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2419186478954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e2419186478954 : Closed e2419186478954 ∧ code e2419186478954 = 11215279501162 := by decide
theorem cert_e2419186478954 : check e2419186478954 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419186480058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e2419186480058 : Closed e2419186480058 ∧ code e2419186480058 = 11215279502266 := by decide
theorem cert_e2419186480058 : check e2419186480058 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419186480090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e2419186480090 : Closed e2419186480090 ∧ code e2419186480090 = 11215279502298 := by decide
theorem cert_e2419186480090 : check e2419186480090 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419186481594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e2419186481594 : Closed e2419186481594 ∧ code e2419186481594 = 11215279503802 := by decide
theorem cert_e2419186481594 : check e2419186481594 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2419186481642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e2419186481642 : Closed e2419186481642 ∧ code e2419186481642 = 11215279503850 := by decide
theorem cert_e2419186481642 : check e2419186481642 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2419186482394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e2419186482394 : Closed e2419186482394 ∧ code e2419186482394 = 11215279504602 := by decide
theorem cert_e2419186482394 : check e2419186482394 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2419186482410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e2419186482410 : Closed e2419186482410 ∧ code e2419186482410 = 11215279504618 := by decide
theorem cert_e2419186482410 : check e2419186482410 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under]] .sourceHead = true := by decide
def e2419186513634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e2419186513634 : Closed e2419186513634 ∧ code e2419186513634 = 11215279535842 := by decide
def e2419186513762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e2419186513762 : Closed e2419186513762 ∧ code e2419186513762 = 11215279535970 := by decide
def e2419186514658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e2419186514658 : Closed e2419186514658 ∧ code e2419186514658 = 11215279536866 := by decide
def e2419186514850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e2419186514850 : Closed e2419186514850 ∧ code e2419186514850 = 11215279537058 := by decide
private def t_e2419186514850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))
theorem cert_e2419186514850 : ¬ IsSelfInterpreter e2419186514850 :=
  wSource (t := t_e2419186514850) (replay_sound (ps := []) (t := e2419186514850) (by decide)) (by decide)
def e2419186515298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e2419186515298 : Closed e2419186515298 ∧ code e2419186515298 = 11215279537506 := by decide
theorem cert_e2419186515298 : check e2419186515298 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left]] .chain = true := by decide
def e2419186515362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e2419186515362 : Closed e2419186515362 ∧ code e2419186515362 = 11215279537570 := by decide
private def t_e2419186515362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))
theorem cert_e2419186515362 : ¬ IsSelfInterpreter e2419186515362 :=
  wSource (t := t_e2419186515362) (replay_sound (ps := []) (t := e2419186515362) (by decide)) (by decide)
def e2419186519778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e2419186519778 : Closed e2419186519778 ∧ code e2419186519778 = 11215279541986 := by decide
def e2419186519906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e2419186519906 : Closed e2419186519906 ∧ code e2419186519906 = 11215279542114 := by decide
def e2419186525922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e2419186525922 : Closed e2419186525922 ∧ code e2419186525922 = 11215279548130 := by decide
def e2419186526114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e2419186526114 : Closed e2419186526114 ∧ code e2419186526114 = 11215279548322 := by decide
theorem cert_e2419186526114 : check e2419186526114 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[],[],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2419186529122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e2419186529122 : Closed e2419186529122 ∧ code e2419186529122 = 11215279551330 := by decide
def e2419186529186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e2419186529186 : Closed e2419186529186 ∧ code e2419186529186 = 11215279551394 := by decide
def e2419186731886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419186731886 : Closed e2419186731886 ∧ code e2419186731886 = 11215279754094 := by decide
theorem cert_e2419186731886 : check e2419186731886 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2419186731894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419186731894 : Closed e2419186731894 ∧ code e2419186731894 = 11215279754102 := by decide
theorem cert_e2419186731894 : check e2419186731894 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2419186731950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419186731950 : Closed e2419186731950 ∧ code e2419186731950 = 11215279754158 := by decide
theorem cert_e2419186731950 : check e2419186731950 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2419186731962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419186731962 : Closed e2419186731962 ∧ code e2419186731962 = 11215279754170 := by decide
theorem cert_e2419186731962 : check e2419186731962 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2419186731990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419186731990 : Closed e2419186731990 ∧ code e2419186731990 = 11215279754198 := by decide
theorem cert_e2419186731990 : check e2419186731990 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2419186731994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419186731994 : Closed e2419186731994 ∧ code e2419186731994 = 11215279754202 := by decide
theorem cert_e2419186731994 : check e2419186731994 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419186732270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419186732270 : Closed e2419186732270 ∧ code e2419186732270 = 11215279754478 := by decide
theorem cert_e2419186732270 : check e2419186732270 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419186732278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419186732278 : Closed e2419186732278 ∧ code e2419186732278 = 11215279754486 := by decide
theorem cert_e2419186732278 : check e2419186732278 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419186732654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419186732654 : Closed e2419186732654 ∧ code e2419186732654 = 11215279754862 := by decide
theorem cert_e2419186732654 : check e2419186732654 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2419186732666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419186732666 : Closed e2419186732666 ∧ code e2419186732666 = 11215279754874 := by decide
theorem cert_e2419186732666 : check e2419186732666 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2419186732854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419186732854 : Closed e2419186732854 ∧ code e2419186732854 = 11215279755062 := by decide
theorem cert_e2419186732854 : check e2419186732854 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2419186732858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419186732858 : Closed e2419186732858 ∧ code e2419186732858 = 11215279755066 := by decide
theorem cert_e2419186732858 : check e2419186732858 [[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e2419187518318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419187518318 : Closed e2419187518318 ∧ code e2419187518318 = 11215280540526 := by decide
private def t_e2419187518318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e2419187518318 : ¬ IsSelfInterpreter e2419187518318 :=
  wSource (t := t_e2419187518318) (replay_sound (ps := []) (t := e2419187518318) (by decide)) (by decide)
def e2419187518326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419187518326 : Closed e2419187518326 ∧ code e2419187518326 = 11215280540534 := by decide
private def t_e2419187518326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e2419187518326 : ¬ IsSelfInterpreter e2419187518326 :=
  wSource (t := t_e2419187518326) (replay_sound (ps := []) (t := e2419187518326) (by decide)) (by decide)
def e2419187518382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419187518382 : Closed e2419187518382 ∧ code e2419187518382 = 11215280540590 := by decide
private def t_e2419187518382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e2419187518382 : ¬ IsSelfInterpreter e2419187518382 :=
  wSource (t := t_e2419187518382) (replay_sound (ps := []) (t := e2419187518382) (by decide)) (by decide)
def e2419187518394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419187518394 : Closed e2419187518394 ∧ code e2419187518394 = 11215280540602 := by decide
private def t_e2419187518394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2419187518394 : ¬ IsSelfInterpreter e2419187518394 :=
  wSource (t := t_e2419187518394) (replay_sound (ps := []) (t := e2419187518394) (by decide)) (by decide)
def e2419187518422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419187518422 : Closed e2419187518422 ∧ code e2419187518422 = 11215280540630 := by decide
private def t_e2419187518422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e2419187518422 : ¬ IsSelfInterpreter e2419187518422 :=
  wSource (t := t_e2419187518422) (replay_sound (ps := []) (t := e2419187518422) (by decide)) (by decide)
def e2419187518426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419187518426 : Closed e2419187518426 ∧ code e2419187518426 = 11215280540634 := by decide
private def t_e2419187518426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2419187518426 : ¬ IsSelfInterpreter e2419187518426 :=
  wSource (t := t_e2419187518426) (replay_sound (ps := []) (t := e2419187518426) (by decide)) (by decide)
def e2419187518702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419187518702 : Closed e2419187518702 ∧ code e2419187518702 = 11215280540910 := by decide
private def t_e2419187518702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e2419187518702 : ¬ IsSelfInterpreter e2419187518702 :=
  wSource (t := t_e2419187518702) (replay_sound (ps := []) (t := e2419187518702) (by decide)) (by decide)
def e2419187518710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419187518710 : Closed e2419187518710 ∧ code e2419187518710 = 11215280540918 := by decide
private def t_e2419187518710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e2419187518710 : ¬ IsSelfInterpreter e2419187518710 :=
  wSource (t := t_e2419187518710) (replay_sound (ps := []) (t := e2419187518710) (by decide)) (by decide)
def e2419187519086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419187519086 : Closed e2419187519086 ∧ code e2419187519086 = 11215280541294 := by decide
private def t_e2419187519086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e2419187519086 : ¬ IsSelfInterpreter e2419187519086 :=
  wSource (t := t_e2419187519086) (replay_sound (ps := []) (t := e2419187519086) (by decide)) (by decide)
def e2419187519098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419187519098 : Closed e2419187519098 ∧ code e2419187519098 = 11215280541306 := by decide
private def t_e2419187519098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e2419187519098 : ¬ IsSelfInterpreter e2419187519098 :=
  wSource (t := t_e2419187519098) (replay_sound (ps := []) (t := e2419187519098) (by decide)) (by decide)
def e2419187519286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419187519286 : Closed e2419187519286 ∧ code e2419187519286 = 11215280541494 := by decide
private def t_e2419187519286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e2419187519286 : ¬ IsSelfInterpreter e2419187519286 :=
  wSource (t := t_e2419187519286) (replay_sound (ps := []) (t := e2419187519286) (by decide)) (by decide)
def e2419187519290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419187519290 : Closed e2419187519290 ∧ code e2419187519290 = 11215280541498 := by decide
private def t_e2419187519290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e2419187519290 : ¬ IsSelfInterpreter e2419187519290 :=
  wSource (t := t_e2419187519290) (replay_sound (ps := []) (t := e2419187519290) (by decide)) (by decide)
def e2419190672830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2419190672830 : Closed e2419190672830 ∧ code e2419190672830 = 11215283695038 := by decide
theorem cert_e2419190672830 : check e2419190672830 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190672886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2419190672886 : Closed e2419190672886 ∧ code e2419190672886 = 11215283695094 := by decide
theorem cert_e2419190672886 : check e2419190672886 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190673086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2419190673086 : Closed e2419190673086 ∧ code e2419190673086 = 11215283695294 := by decide
theorem cert_e2419190673086 : check e2419190673086 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190673146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2419190673146 : Closed e2419190673146 ∧ code e2419190673146 = 11215283695354 := by decide
theorem cert_e2419190673146 : check e2419190673146 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190673366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2419190673366 : Closed e2419190673366 ∧ code e2419190673366 = 11215283695574 := by decide
theorem cert_e2419190673366 : check e2419190673366 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190673370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2419190673370 : Closed e2419190673370 ∧ code e2419190673370 = 11215283695578 := by decide
theorem cert_e2419190673370 : check e2419190673370 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190674366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2419190674366 : Closed e2419190674366 ∧ code e2419190674366 = 11215283696574 := by decide
theorem cert_e2419190674366 : check e2419190674366 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190674422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2419190674422 : Closed e2419190674422 ∧ code e2419190674422 = 11215283696630 := by decide
theorem cert_e2419190674422 : check e2419190674422 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190675902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2419190675902 : Closed e2419190675902 ∧ code e2419190675902 = 11215283698110 := by decide
theorem cert_e2419190675902 : check e2419190675902 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190675962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2419190675962 : Closed e2419190675962 ∧ code e2419190675962 = 11215283698170 := by decide
theorem cert_e2419190675962 : check e2419190675962 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190677302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419190677302 : Closed e2419190677302 ∧ code e2419190677302 = 11215283699510 := by decide
theorem cert_e2419190677302 : check e2419190677302 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190677306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419190677306 : Closed e2419190677306 ∧ code e2419190677306 = 11215283699514 := by decide
theorem cert_e2419190677306 : check e2419190677306 [[],[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2419190705518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2419190705518 : Closed e2419190705518 ∧ code e2419190705518 = 11215283727726 := by decide
theorem cert_e2419190705518 : check e2419190705518 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190705526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2419190705526 : Closed e2419190705526 ∧ code e2419190705526 = 11215283727734 := by decide
theorem cert_e2419190705526 : check e2419190705526 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190705582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2419190705582 : Closed e2419190705582 ∧ code e2419190705582 = 11215283727790 := by decide
theorem cert_e2419190705582 : check e2419190705582 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190705594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2419190705594 : Closed e2419190705594 ∧ code e2419190705594 = 11215283727802 := by decide
theorem cert_e2419190705594 : check e2419190705594 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190705622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2419190705622 : Closed e2419190705622 ∧ code e2419190705622 = 11215283727830 := by decide
theorem cert_e2419190705622 : check e2419190705622 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190705626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2419190705626 : Closed e2419190705626 ∧ code e2419190705626 = 11215283727834 := by decide
theorem cert_e2419190705626 : check e2419190705626 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419155033966
#print axioms Blc.Floor43.cert_e2419155098550
#print axioms Blc.Floor43.cert_e2419155099318
#print axioms Blc.Floor43.cert_e2419155103350
#print axioms Blc.Floor43.cert_e2419155106422
#print axioms Blc.Floor43.cert_e2419155471222
#print axioms Blc.Floor43.cert_e2419155471318
#print axioms Blc.Floor43.cert_e2419177294778
#print axioms Blc.Floor43.cert_e2419177294810
#print axioms Blc.Floor43.cert_e2419186514850
#print axioms Blc.Floor43.cert_e2419186515362
#print axioms Blc.Floor43.cert_e2419187518318
#print axioms Blc.Floor43.cert_e2419187518326
#print axioms Blc.Floor43.cert_e2419187518382
#print axioms Blc.Floor43.cert_e2419187518394
#print axioms Blc.Floor43.cert_e2419187518422
#print axioms Blc.Floor43.cert_e2419187518426
#print axioms Blc.Floor43.cert_e2419187518702
#print axioms Blc.Floor43.cert_e2419187518710
#print axioms Blc.Floor43.cert_e2419187519086
#print axioms Blc.Floor43.cert_e2419187519098
#print axioms Blc.Floor43.cert_e2419187519286
#print axioms Blc.Floor43.cert_e2419187519290
