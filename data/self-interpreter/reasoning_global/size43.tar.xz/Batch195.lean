import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388820682778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388820682778 : Closed e2388820682778 ∧ code e2388820682778 = 11184913704986 := by decide
theorem cert_e2388820682778 : check e2388820682778 [[]] .width = true := by decide
def e2388820715546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388820715546 : Closed e2388820715546 ∧ code e2388820715546 = 11184913737754 := by decide
theorem cert_e2388820715546 : check e2388820715546 [[]] .width = true := by decide
def e2388822255642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388822255642 : Closed e2388822255642 ∧ code e2388822255642 = 11184915277850 := by decide
theorem cert_e2388822255642 : check e2388822255642 [[]] .width = true := by decide
def e2388822304794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388822304794 : Closed e2388822304794 ∧ code e2388822304794 = 11184915327002 := by decide
theorem cert_e2388822304794 : check e2388822304794 [[]] .width = true := by decide
def e2388823074842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388823074842 : Closed e2388823074842 ∧ code e2388823074842 = 11184916097050 := by decide
theorem cert_e2388823074842 : check e2388823074842 [[]] .width = true := by decide
def e2388823091226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388823091226 : Closed e2388823091226 ∧ code e2388823091226 = 11184916113434 := by decide
theorem cert_e2388823091226 : check e2388823091226 [[]] .width = true := by decide
def e2388891053422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2388891053422 : Closed e2388891053422 ∧ code e2388891053422 = 11184984075630 := by decide
theorem cert_e2388891053422 : check e2388891053422 [[],[.left],[]] .sourceHead = true := by decide
def e2388891053430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2388891053430 : Closed e2388891053430 ∧ code e2388891053430 = 11184984075638 := by decide
theorem cert_e2388891053430 : check e2388891053430 [[],[.left],[]] .sourceHead = true := by decide
def e2388891053486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2388891053486 : Closed e2388891053486 ∧ code e2388891053486 = 11184984075694 := by decide
theorem cert_e2388891053486 : check e2388891053486 [[],[.left],[]] .sourceHead = true := by decide
def e2388891053498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2388891053498 : Closed e2388891053498 ∧ code e2388891053498 = 11184984075706 := by decide
theorem cert_e2388891053498 : check e2388891053498 [[],[.left],[]] .sourceHead = true := by decide
def e2388891053526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2388891053526 : Closed e2388891053526 ∧ code e2388891053526 = 11184984075734 := by decide
theorem cert_e2388891053526 : check e2388891053526 [[],[.left],[]] .sourceHead = true := by decide
def e2388891053530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2388891053530 : Closed e2388891053530 ∧ code e2388891053530 = 11184984075738 := by decide
theorem cert_e2388891053530 : check e2388891053530 [[],[.left],[]] .sourceHead = true := by decide
def e2388891053742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2388891053742 : Closed e2388891053742 ∧ code e2388891053742 = 11184984075950 := by decide
theorem cert_e2388891053742 : check e2388891053742 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388891053754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2388891053754 : Closed e2388891053754 ∧ code e2388891053754 = 11184984075962 := by decide
theorem cert_e2388891053754 : check e2388891053754 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388891053802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2388891053802 : Closed e2388891053802 ∧ code e2388891053802 = 11184984076010 := by decide
theorem cert_e2388891053802 : check e2388891053802 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388891053910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2388891053910 : Closed e2388891053910 ∧ code e2388891053910 = 11184984076118 := by decide
theorem cert_e2388891053910 : check e2388891053910 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388891053914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2388891053914 : Closed e2388891053914 ∧ code e2388891053914 = 11184984076122 := by decide
theorem cert_e2388891053914 : check e2388891053914 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388891053930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2388891053930 : Closed e2388891053930 ∧ code e2388891053930 = 11184984076138 := by decide
theorem cert_e2388891053930 : check e2388891053930 [[],[.left],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2388891054958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2388891054958 : Closed e2388891054958 ∧ code e2388891054958 = 11184984077166 := by decide
theorem cert_e2388891054958 : check e2388891054958 [[],[.left],[]] .sourceHead = true := by decide
def e2388891054966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2388891054966 : Closed e2388891054966 ∧ code e2388891054966 = 11184984077174 := by decide
theorem cert_e2388891054966 : check e2388891054966 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2388891055022 : Closed e2388891055022 ∧ code e2388891055022 = 11184984077230 := by decide
theorem cert_e2388891055022 : check e2388891055022 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2388891055034 : Closed e2388891055034 ∧ code e2388891055034 = 11184984077242 := by decide
theorem cert_e2388891055034 : check e2388891055034 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2388891055062 : Closed e2388891055062 ∧ code e2388891055062 = 11184984077270 := by decide
theorem cert_e2388891055062 : check e2388891055062 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2388891055066 : Closed e2388891055066 ∧ code e2388891055066 = 11184984077274 := by decide
theorem cert_e2388891055066 : check e2388891055066 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2388891055342 : Closed e2388891055342 ∧ code e2388891055342 = 11184984077550 := by decide
theorem cert_e2388891055342 : check e2388891055342 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2388891055350 : Closed e2388891055350 ∧ code e2388891055350 = 11184984077558 := by decide
theorem cert_e2388891055350 : check e2388891055350 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388891055726 : Closed e2388891055726 ∧ code e2388891055726 = 11184984077934 := by decide
theorem cert_e2388891055726 : check e2388891055726 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388891055738 : Closed e2388891055738 ∧ code e2388891055738 = 11184984077946 := by decide
theorem cert_e2388891055738 : check e2388891055738 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388891055926 : Closed e2388891055926 ∧ code e2388891055926 = 11184984078134 := by decide
theorem cert_e2388891055926 : check e2388891055926 [[],[.left],[]] .sourceHead = true := by decide
def e2388891055930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388891055930 : Closed e2388891055930 ∧ code e2388891055930 = 11184984078138 := by decide
theorem cert_e2388891055930 : check e2388891055930 [[],[.left],[]] .sourceHead = true := by decide
def e2388891056558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2388891056558 : Closed e2388891056558 ∧ code e2388891056558 = 11184984078766 := by decide
theorem cert_e2388891056558 : check e2388891056558 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891056570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2388891056570 : Closed e2388891056570 ∧ code e2388891056570 = 11184984078778 := by decide
theorem cert_e2388891056570 : check e2388891056570 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891056618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2388891056618 : Closed e2388891056618 ∧ code e2388891056618 = 11184984078826 := by decide
theorem cert_e2388891056618 : check e2388891056618 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891056750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388891056750 : Closed e2388891056750 ∧ code e2388891056750 = 11184984078958 := by decide
theorem cert_e2388891056750 : check e2388891056750 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891056762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388891056762 : Closed e2388891056762 ∧ code e2388891056762 = 11184984078970 := by decide
theorem cert_e2388891056762 : check e2388891056762 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891057050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2388891057050 : Closed e2388891057050 ∧ code e2388891057050 = 11184984079258 := by decide
theorem cert_e2388891057050 : check e2388891057050 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891057366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2388891057366 : Closed e2388891057366 ∧ code e2388891057366 = 11184984079574 := by decide
theorem cert_e2388891057366 : check e2388891057366 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891057370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2388891057370 : Closed e2388891057370 ∧ code e2388891057370 = 11184984079578 := by decide
theorem cert_e2388891057370 : check e2388891057370 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2388891057386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2388891057386 : Closed e2388891057386 ∧ code e2388891057386 = 11184984079594 := by decide
theorem cert_e2388891057386 : check e2388891057386 [[],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2388891057462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388891057462 : Closed e2388891057462 ∧ code e2388891057462 = 11184984079670 := by decide
theorem cert_e2388891057462 : check e2388891057462 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891057466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388891057466 : Closed e2388891057466 ∧ code e2388891057466 = 11184984079674 := by decide
theorem cert_e2388891057466 : check e2388891057466 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388891057562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2388891057562 : Closed e2388891057562 ∧ code e2388891057562 = 11184984079770 := by decide
theorem cert_e2388891057562 : check e2388891057562 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2388891061102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388891061102 : Closed e2388891061102 ∧ code e2388891061102 = 11184984083310 := by decide
theorem cert_e2388891061102 : check e2388891061102 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388891061110 : Closed e2388891061110 ∧ code e2388891061110 = 11184984083318 := by decide
theorem cert_e2388891061110 : check e2388891061110 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388891061166 : Closed e2388891061166 ∧ code e2388891061166 = 11184984083374 := by decide
theorem cert_e2388891061166 : check e2388891061166 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388891061178 : Closed e2388891061178 ∧ code e2388891061178 = 11184984083386 := by decide
theorem cert_e2388891061178 : check e2388891061178 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388891061206 : Closed e2388891061206 ∧ code e2388891061206 = 11184984083414 := by decide
theorem cert_e2388891061206 : check e2388891061206 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388891061210 : Closed e2388891061210 ∧ code e2388891061210 = 11184984083418 := by decide
theorem cert_e2388891061210 : check e2388891061210 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388891061486 : Closed e2388891061486 ∧ code e2388891061486 = 11184984083694 := by decide
theorem cert_e2388891061486 : check e2388891061486 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388891061494 : Closed e2388891061494 ∧ code e2388891061494 = 11184984083702 := by decide
theorem cert_e2388891061494 : check e2388891061494 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388891061870 : Closed e2388891061870 ∧ code e2388891061870 = 11184984084078 := by decide
theorem cert_e2388891061870 : check e2388891061870 [[],[.left],[]] .sourceHead = true := by decide
def e2388891061882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388891061882 : Closed e2388891061882 ∧ code e2388891061882 = 11184984084090 := by decide
theorem cert_e2388891061882 : check e2388891061882 [[],[.left],[]] .sourceHead = true := by decide
def e2388891062070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388891062070 : Closed e2388891062070 ∧ code e2388891062070 = 11184984084278 := by decide
theorem cert_e2388891062070 : check e2388891062070 [[],[.left],[]] .sourceHead = true := by decide
def e2388891062074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388891062074 : Closed e2388891062074 ∧ code e2388891062074 = 11184984084282 := by decide
theorem cert_e2388891062074 : check e2388891062074 [[],[.left],[]] .sourceHead = true := by decide
def e2388891067822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2388891067822 : Closed e2388891067822 ∧ code e2388891067822 = 11184984090030 := by decide
theorem cert_e2388891067822 : check e2388891067822 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388891067834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2388891067834 : Closed e2388891067834 ∧ code e2388891067834 = 11184984090042 := by decide
theorem cert_e2388891067834 : check e2388891067834 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388891067882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2388891067882 : Closed e2388891067882 ∧ code e2388891067882 = 11184984090090 := by decide
theorem cert_e2388891067882 : check e2388891067882 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388891068014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2388891068014 : Closed e2388891068014 ∧ code e2388891068014 = 11184984090222 := by decide
theorem cert_e2388891068014 : check e2388891068014 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388891068026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2388891068026 : Closed e2388891068026 ∧ code e2388891068026 = 11184984090234 := by decide
theorem cert_e2388891068026 : check e2388891068026 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388891068314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2388891068314 : Closed e2388891068314 ∧ code e2388891068314 = 11184984090522 := by decide
theorem cert_e2388891068314 : check e2388891068314 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388891071190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2388891071190 : Closed e2388891071190 ∧ code e2388891071190 = 11184984093398 := by decide
theorem cert_e2388891071190 : check e2388891071190 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2388891071194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2388891071194 : Closed e2388891071194 ∧ code e2388891071194 = 11184984093402 := by decide
theorem cert_e2388891071194 : check e2388891071194 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2388891071210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2388891071210 : Closed e2388891071210 ∧ code e2388891071210 = 11184984093418 := by decide
theorem cert_e2388891071210 : check e2388891071210 [[],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2388891071286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2388891071286 : Closed e2388891071286 ∧ code e2388891071286 = 11184984093494 := by decide
theorem cert_e2388891071286 : check e2388891071286 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2388891071290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2388891071290 : Closed e2388891071290 ∧ code e2388891071290 = 11184984093498 := by decide
theorem cert_e2388891071290 : check e2388891071290 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2388891071386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2388891071386 : Closed e2388891071386 ∧ code e2388891071386 = 11184984093594 := by decide
theorem cert_e2388891071386 : check e2388891071386 [[],[.left],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e2388891208558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388891208558 : Closed e2388891208558 ∧ code e2388891208558 = 11184984230766 := by decide
theorem cert_e2388891208558 : check e2388891208558 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891208566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388891208566 : Closed e2388891208566 ∧ code e2388891208566 = 11184984230774 := by decide
theorem cert_e2388891208566 : check e2388891208566 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891208622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388891208622 : Closed e2388891208622 ∧ code e2388891208622 = 11184984230830 := by decide
theorem cert_e2388891208622 : check e2388891208622 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891208634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388891208634 : Closed e2388891208634 ∧ code e2388891208634 = 11184984230842 := by decide
theorem cert_e2388891208634 : check e2388891208634 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891208662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388891208662 : Closed e2388891208662 ∧ code e2388891208662 = 11184984230870 := by decide
theorem cert_e2388891208662 : check e2388891208662 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891208666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388891208666 : Closed e2388891208666 ∧ code e2388891208666 = 11184984230874 := by decide
theorem cert_e2388891208666 : check e2388891208666 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891208942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388891208942 : Closed e2388891208942 ∧ code e2388891208942 = 11184984231150 := by decide
theorem cert_e2388891208942 : check e2388891208942 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891208950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388891208950 : Closed e2388891208950 ∧ code e2388891208950 = 11184984231158 := by decide
theorem cert_e2388891208950 : check e2388891208950 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891209326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388891209326 : Closed e2388891209326 ∧ code e2388891209326 = 11184984231534 := by decide
theorem cert_e2388891209326 : check e2388891209326 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891209338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388891209338 : Closed e2388891209338 ∧ code e2388891209338 = 11184984231546 := by decide
theorem cert_e2388891209338 : check e2388891209338 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891209526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388891209526 : Closed e2388891209526 ∧ code e2388891209526 = 11184984231734 := by decide
theorem cert_e2388891209526 : check e2388891209526 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891209530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388891209530 : Closed e2388891209530 ∧ code e2388891209530 = 11184984231738 := by decide
theorem cert_e2388891209530 : check e2388891209530 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388891798382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388891798382 : Closed e2388891798382 ∧ code e2388891798382 = 11184984820590 := by decide
theorem cert_e2388891798382 : check e2388891798382 [[],[.left],[.left],[.left],[],[.left]] .width = true := by decide
def e2388891798390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388891798390 : Closed e2388891798390 ∧ code e2388891798390 = 11184984820598 := by decide
theorem cert_e2388891798390 : check e2388891798390 [[],[.left],[.left],[.left],[],[.left]] .width = true := by decide
def e2388891798446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388891798446 : Closed e2388891798446 ∧ code e2388891798446 = 11184984820654 := by decide
theorem cert_e2388891798446 : check e2388891798446 [[],[.left],[.left],[.left],[],[.left],[],[.left]] .smaller = true := by decide
def e2388891798458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388891798458 : Closed e2388891798458 ∧ code e2388891798458 = 11184984820666 := by decide
private def t_e2388891798458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2388891798458 : ¬ IsSelfInterpreter e2388891798458 :=
  wSource (t := t_e2388891798458) (replay_sound (ps := []) (t := e2388891798458) (by decide)) (by decide)
def e2388891798486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388891798486 : Closed e2388891798486 ∧ code e2388891798486 = 11184984820694 := by decide
def e2388891798490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388891798490 : Closed e2388891798490 ∧ code e2388891798490 = 11184984820698 := by decide
private def t_e2388891798490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2388891798490 : ¬ IsSelfInterpreter e2388891798490 :=
  wSource (t := t_e2388891798490) (replay_sound (ps := []) (t := e2388891798490) (by decide)) (by decide)
def e2388891798766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388891798766 : Closed e2388891798766 ∧ code e2388891798766 = 11184984820974 := by decide
theorem cert_e2388891798766 : check e2388891798766 [[],[.left],[.left],[.left],[],[]] .width = true := by decide
def e2388891798774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388891798774 : Closed e2388891798774 ∧ code e2388891798774 = 11184984820982 := by decide
theorem cert_e2388891798774 : check e2388891798774 [[],[.left],[.left],[.left],[],[]] .width = true := by decide
def e2388891799150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388891799150 : Closed e2388891799150 ∧ code e2388891799150 = 11184984821358 := by decide
theorem cert_e2388891799150 : check e2388891799150 [[],[.left],[.left],[.left],[],[],[.under,.left]] .width = true := by decide
def e2388891799162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388891799162 : Closed e2388891799162 ∧ code e2388891799162 = 11184984821370 := by decide
theorem cert_e2388891799162 : check e2388891799162 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2388891799350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388891799350 : Closed e2388891799350 ∧ code e2388891799350 = 11184984821558 := by decide
def e2388891799354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388891799354 : Closed e2388891799354 ∧ code e2388891799354 = 11184984821562 := by decide
def e2389087543322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389087543322 : Closed e2389087543322 ∧ code e2389087543322 = 11185180565530 := by decide
theorem cert_e2389087543322 : check e2389087543322 [[]] .width = true := by decide
def e2389087543414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389087543414 : Closed e2389087543414 ∧ code e2389087543414 = 11185180565622 := by decide
theorem cert_e2389087543414 : check e2389087543414 [[]] .width = true := by decide
def e2389087543658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389087543658 : Closed e2389087543658 ∧ code e2389087543658 = 11185180565866 := by decide
theorem cert_e2389087543658 : check e2389087543658 [[]] .width = true := by decide
def e2389087543706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389087543706 : Closed e2389087543706 ∧ code e2389087543706 = 11185180565914 := by decide
theorem cert_e2389087543706 : check e2389087543706 [[]] .width = true := by decide
def e2389087576090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389087576090 : Closed e2389087576090 ∧ code e2389087576090 = 11185180598298 := by decide
theorem cert_e2389087576090 : check e2389087576090 [[]] .width = true := by decide
def e2389087576182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389087576182 : Closed e2389087576182 ∧ code e2389087576182 = 11185180598390 := by decide
theorem cert_e2389087576182 : check e2389087576182 [[]] .width = true := by decide
def e2389087576426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389087576426 : Closed e2389087576426 ∧ code e2389087576426 = 11185180598634 := by decide
theorem cert_e2389087576426 : check e2389087576426 [[]] .width = true := by decide
def e2389087576474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389087576474 : Closed e2389087576474 ∧ code e2389087576474 = 11185180598682 := by decide
theorem cert_e2389087576474 : check e2389087576474 [[]] .width = true := by decide
def e2389087805466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389087805466 : Closed e2389087805466 ∧ code e2389087805466 = 11185180827674 := by decide
theorem cert_e2389087805466 : check e2389087805466 [[]] .width = true := by decide
def e2389087805558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389087805558 : Closed e2389087805558 ∧ code e2389087805558 = 11185180827766 := by decide
theorem cert_e2389087805558 : check e2389087805558 [[]] .width = true := by decide
def e2389087805802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389087805802 : Closed e2389087805802 ∧ code e2389087805802 = 11185180828010 := by decide
theorem cert_e2389087805802 : check e2389087805802 [[]] .width = true := by decide
def e2389087805850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389087805850 : Closed e2389087805850 ∧ code e2389087805850 = 11185180828058 := by decide
theorem cert_e2389087805850 : check e2389087805850 [[]] .width = true := by decide
def e2389087854618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389087854618 : Closed e2389087854618 ∧ code e2389087854618 = 11185180876826 := by decide
theorem cert_e2389087854618 : check e2389087854618 [[]] .width = true := by decide
def e2389087854710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389087854710 : Closed e2389087854710 ∧ code e2389087854710 = 11185180876918 := by decide
theorem cert_e2389087854710 : check e2389087854710 [[]] .width = true := by decide
def e2389087854954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389087854954 : Closed e2389087854954 ∧ code e2389087854954 = 11185180877162 := by decide
theorem cert_e2389087854954 : check e2389087854954 [[]] .width = true := by decide
def e2389087855002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389087855002 : Closed e2389087855002 ∧ code e2389087855002 = 11185180877210 := by decide
theorem cert_e2389087855002 : check e2389087855002 [[]] .width = true := by decide
def e2389087969306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389087969306 : Closed e2389087969306 ∧ code e2389087969306 = 11185180991514 := by decide
theorem cert_e2389087969306 : check e2389087969306 [[]] .width = true := by decide
def e2389087969398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389087969398 : Closed e2389087969398 ∧ code e2389087969398 = 11185180991606 := by decide
theorem cert_e2389087969398 : check e2389087969398 [[]] .width = true := by decide
def e2389087969642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389087969642 : Closed e2389087969642 ∧ code e2389087969642 = 11185180991850 := by decide
theorem cert_e2389087969642 : check e2389087969642 [[]] .width = true := by decide
def e2389087969690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389087969690 : Closed e2389087969690 ∧ code e2389087969690 = 11185180991898 := by decide
theorem cert_e2389087969690 : check e2389087969690 [[]] .width = true := by decide
def e2389087985690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389087985690 : Closed e2389087985690 ∧ code e2389087985690 = 11185181007898 := by decide
theorem cert_e2389087985690 : check e2389087985690 [[]] .width = true := by decide
def e2389087985782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389087985782 : Closed e2389087985782 ∧ code e2389087985782 = 11185181007990 := by decide
theorem cert_e2389087985782 : check e2389087985782 [[]] .width = true := by decide
def e2389087986026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389087986026 : Closed e2389087986026 ∧ code e2389087986026 = 11185181008234 := by decide
theorem cert_e2389087986026 : check e2389087986026 [[]] .width = true := by decide
def e2389087986074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389087986074 : Closed e2389087986074 ∧ code e2389087986074 = 11185181008282 := by decide
theorem cert_e2389087986074 : check e2389087986074 [[]] .width = true := by decide
def e2389089116186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389089116186 : Closed e2389089116186 ∧ code e2389089116186 = 11185182138394 := by decide
theorem cert_e2389089116186 : check e2389089116186 [[]] .width = true := by decide
def e2389089116278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389089116278 : Closed e2389089116278 ∧ code e2389089116278 = 11185182138486 := by decide
theorem cert_e2389089116278 : check e2389089116278 [[]] .width = true := by decide
def e2389089116522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389089116522 : Closed e2389089116522 ∧ code e2389089116522 = 11185182138730 := by decide
theorem cert_e2389089116522 : check e2389089116522 [[]] .width = true := by decide
def e2389089116570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389089116570 : Closed e2389089116570 ∧ code e2389089116570 = 11185182138778 := by decide
theorem cert_e2389089116570 : check e2389089116570 [[]] .width = true := by decide
def e2389089148954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389089148954 : Closed e2389089148954 ∧ code e2389089148954 = 11185182171162 := by decide
theorem cert_e2389089148954 : check e2389089148954 [[]] .width = true := by decide
def e2389089149046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389089149046 : Closed e2389089149046 ∧ code e2389089149046 = 11185182171254 := by decide
theorem cert_e2389089149046 : check e2389089149046 [[]] .width = true := by decide
def e2389089149290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389089149290 : Closed e2389089149290 ∧ code e2389089149290 = 11185182171498 := by decide
theorem cert_e2389089149290 : check e2389089149290 [[]] .width = true := by decide
def e2389089149338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389089149338 : Closed e2389089149338 ∧ code e2389089149338 = 11185182171546 := by decide
theorem cert_e2389089149338 : check e2389089149338 [[]] .width = true := by decide
def e2389090689050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389090689050 : Closed e2389090689050 ∧ code e2389090689050 = 11185183711258 := by decide
theorem cert_e2389090689050 : check e2389090689050 [[]] .width = true := by decide
def e2389090689142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389090689142 : Closed e2389090689142 ∧ code e2389090689142 = 11185183711350 := by decide
theorem cert_e2389090689142 : check e2389090689142 [[]] .width = true := by decide
def e2389090689386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389090689386 : Closed e2389090689386 ∧ code e2389090689386 = 11185183711594 := by decide
theorem cert_e2389090689386 : check e2389090689386 [[]] .width = true := by decide
def e2389090689434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389090689434 : Closed e2389090689434 ∧ code e2389090689434 = 11185183711642 := by decide
theorem cert_e2389090689434 : check e2389090689434 [[]] .width = true := by decide
def e2389090738202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389090738202 : Closed e2389090738202 ∧ code e2389090738202 = 11185183760410 := by decide
theorem cert_e2389090738202 : check e2389090738202 [[]] .width = true := by decide
def e2389090738294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389090738294 : Closed e2389090738294 ∧ code e2389090738294 = 11185183760502 := by decide
theorem cert_e2389090738294 : check e2389090738294 [[]] .width = true := by decide
def e2389090738538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389090738538 : Closed e2389090738538 ∧ code e2389090738538 = 11185183760746 := by decide
theorem cert_e2389090738538 : check e2389090738538 [[]] .width = true := by decide
def e2389090738586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389090738586 : Closed e2389090738586 ∧ code e2389090738586 = 11185183760794 := by decide
theorem cert_e2389090738586 : check e2389090738586 [[]] .width = true := by decide
def e2389091508250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389091508250 : Closed e2389091508250 ∧ code e2389091508250 = 11185184530458 := by decide
theorem cert_e2389091508250 : check e2389091508250 [[]] .width = true := by decide
def e2389091508342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389091508342 : Closed e2389091508342 ∧ code e2389091508342 = 11185184530550 := by decide
theorem cert_e2389091508342 : check e2389091508342 [[]] .width = true := by decide
def e2389091508586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389091508586 : Closed e2389091508586 ∧ code e2389091508586 = 11185184530794 := by decide
theorem cert_e2389091508586 : check e2389091508586 [[]] .width = true := by decide
def e2389091508634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389091508634 : Closed e2389091508634 ∧ code e2389091508634 = 11185184530842 := by decide
theorem cert_e2389091508634 : check e2389091508634 [[]] .width = true := by decide
def e2389091524634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2389091524634 : Closed e2389091524634 ∧ code e2389091524634 = 11185184546842 := by decide
theorem cert_e2389091524634 : check e2389091524634 [[]] .width = true := by decide
def e2389091524726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2389091524726 : Closed e2389091524726 ∧ code e2389091524726 = 11185184546934 := by decide
theorem cert_e2389091524726 : check e2389091524726 [[]] .width = true := by decide
def e2389091524970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2389091524970 : Closed e2389091524970 ∧ code e2389091524970 = 11185184547178 := by decide
theorem cert_e2389091524970 : check e2389091524970 [[]] .width = true := by decide
def e2389091525018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2389091525018 : Closed e2389091525018 ∧ code e2389091525018 = 11185184547226 := by decide
theorem cert_e2389091525018 : check e2389091525018 [[]] .width = true := by decide
def e2389176310638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2389176310638 : Closed e2389176310638 ∧ code e2389176310638 = 11185269332846 := by decide
theorem cert_e2389176310638 : check e2389176310638 [[],[.left],[]] .sourceHead = true := by decide
def e2389176310646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2389176310646 : Closed e2389176310646 ∧ code e2389176310646 = 11185269332854 := by decide
theorem cert_e2389176310646 : check e2389176310646 [[],[.left],[]] .sourceHead = true := by decide
def e2389176310710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2389176310710 : Closed e2389176310710 ∧ code e2389176310710 = 11185269332918 := by decide
theorem cert_e2389176310710 : check e2389176310710 [[],[.left],[]] .sourceHead = true := by decide
def e2389176311150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2389176311150 : Closed e2389176311150 ∧ code e2389176311150 = 11185269333358 := by decide
theorem cert_e2389176311150 : check e2389176311150 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389176311158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2389176311158 : Closed e2389176311158 ∧ code e2389176311158 = 11185269333366 := by decide
theorem cert_e2389176311158 : check e2389176311158 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389176311214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2389176311214 : Closed e2389176311214 ∧ code e2389176311214 = 11185269333422 := by decide
theorem cert_e2389176311214 : check e2389176311214 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2389176311226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2389176311226 : Closed e2389176311226 ∧ code e2389176311226 = 11185269333434 := by decide
theorem cert_e2389176311226 : check e2389176311226 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2389176311254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2389176311254 : Closed e2389176311254 ∧ code e2389176311254 = 11185269333462 := by decide
theorem cert_e2389176311254 : check e2389176311254 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389176311258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2389176311258 : Closed e2389176311258 ∧ code e2389176311258 = 11185269333466 := by decide
theorem cert_e2389176311258 : check e2389176311258 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389176311478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2389176311478 : Closed e2389176311478 ∧ code e2389176311478 = 11185269333686 := by decide
theorem cert_e2389176311478 : check e2389176311478 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2389176311510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2389176311510 : Closed e2389176311510 ∧ code e2389176311510 = 11185269333718 := by decide
theorem cert_e2389176311510 : check e2389176311510 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .three = true := by decide
def e2389176311514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2389176311514 : Closed e2389176311514 ∧ code e2389176311514 = 11185269333722 := by decide
theorem cert_e2389176311514 : check e2389176311514 [[],[.left],[],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2389176313710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2389176313710 : Closed e2389176313710 ∧ code e2389176313710 = 11185269335918 := by decide
theorem cert_e2389176313710 : check e2389176313710 [[],[.left],[]] .sourceHead = true := by decide
def e2389176313718 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2389176313718 : Closed e2389176313718 ∧ code e2389176313718 = 11185269335926 := by decide
theorem cert_e2389176313718 : check e2389176313718 [[],[.left],[]] .sourceHead = true := by decide
def e2389176313782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2389176313782 : Closed e2389176313782 ∧ code e2389176313782 = 11185269335990 := by decide
theorem cert_e2389176313782 : check e2389176313782 [[],[.left],[]] .sourceHead = true := by decide
def e2389176315118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2389176315118 : Closed e2389176315118 ∧ code e2389176315118 = 11185269337326 := by decide
theorem cert_e2389176315118 : check e2389176315118 [[],[.left],[]] .sourceHead = true := by decide
def e2389176315126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2389176315126 : Closed e2389176315126 ∧ code e2389176315126 = 11185269337334 := by decide
theorem cert_e2389176315126 : check e2389176315126 [[],[.left],[]] .sourceHead = true := by decide
def e2389176315510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2389176315510 : Closed e2389176315510 ∧ code e2389176315510 = 11185269337718 := by decide
theorem cert_e2389176315510 : check e2389176315510 [[],[.left],[]] .sourceHead = true := by decide
def e2389176316782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2389176316782 : Closed e2389176316782 ∧ code e2389176316782 = 11185269338990 := by decide
theorem cert_e2389176316782 : check e2389176316782 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389176316790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2389176316790 : Closed e2389176316790 ∧ code e2389176316790 = 11185269338998 := by decide
theorem cert_e2389176316790 : check e2389176316790 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389176316846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2389176316846 : Closed e2389176316846 ∧ code e2389176316846 = 11185269339054 := by decide
theorem cert_e2389176316846 : check e2389176316846 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389176316858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2389176316858 : Closed e2389176316858 ∧ code e2389176316858 = 11185269339066 := by decide
theorem cert_e2389176316858 : check e2389176316858 [[],[.left],[],[.under,.left]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2388891798458
#print axioms Blc.Floor43.cert_e2388891798490
