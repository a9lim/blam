import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701206900410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701206900410 : Closed e701206900410 ∧ code e701206900410 = 9497299922618 := by decide
def e701206900458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701206900458 : Closed e701206900458 ∧ code e701206900458 = 9497299922666 := by decide
private def t_e701206900458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem cert_e701206900458 : ¬ IsSelfInterpreter e701206900458 :=
  wSource (t := t_e701206900458) (replay_sound (ps := []) (t := e701206900458) (by decide)) (by decide)
def e701206900570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701206900570 : Closed e701206900570 ∧ code e701206900570 = 9497299922778 := by decide
def e701206900586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701206900586 : Closed e701206900586 ∧ code e701206900586 = 9497299922794 := by decide
private def t_e701206900586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem cert_e701206900586 : ¬ IsSelfInterpreter e701206900586 :=
  wSource (t := t_e701206900586) (replay_sound (ps := []) (t := e701206900586) (by decide)) (by decide)
def e701206901690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701206901690 : Closed e701206901690 ∧ code e701206901690 = 9497299923898 := by decide
def e701206901722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701206901722 : Closed e701206901722 ∧ code e701206901722 = 9497299923930 := by decide
def e701206903226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701206903226 : Closed e701206903226 ∧ code e701206903226 = 9497299925434 := by decide
def e701206903274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701206903274 : Closed e701206903274 ∧ code e701206903274 = 9497299925482 := by decide
def e701206904026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701206904026 : Closed e701206904026 ∧ code e701206904026 = 9497299926234 := by decide
def e701206904042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701206904042 : Closed e701206904042 ∧ code e701206904042 = 9497299926250 := by decide
def e701354915258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701354915258 : Closed e701354915258 ∧ code e701354915258 = 9497447937466 := by decide
theorem cert_e701354915258 : check e701354915258 [[.under,.left]] .sourceHead = true := by decide
def e701354915290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701354915290 : Closed e701354915290 ∧ code e701354915290 = 9497447937498 := by decide
theorem cert_e701354915290 : check e701354915290 [[.under,.left]] .sourceHead = true := by decide
def e701354915514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701354915514 : Closed e701354915514 ∧ code e701354915514 = 9497447937722 := by decide
theorem cert_e701354915514 : check e701354915514 [[.under,.left]] .sourceHead = true := by decide
def e701354915562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701354915562 : Closed e701354915562 ∧ code e701354915562 = 9497447937770 := by decide
theorem cert_e701354915562 : check e701354915562 [[.under,.left]] .sourceHead = true := by decide
def e701354915674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701354915674 : Closed e701354915674 ∧ code e701354915674 = 9497447937882 := by decide
theorem cert_e701354915674 : check e701354915674 [[.under,.left]] .sourceHead = true := by decide
def e701354915690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701354915690 : Closed e701354915690 ∧ code e701354915690 = 9497447937898 := by decide
theorem cert_e701354915690 : check e701354915690 [[.under,.left]] .sourceHead = true := by decide
def e701354916538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701354916538 : Closed e701354916538 ∧ code e701354916538 = 9497447938746 := by decide
theorem cert_e701354916538 : check e701354916538 [[.under,.left]] .sourceHead = true := by decide
def e701354916586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701354916586 : Closed e701354916586 ∧ code e701354916586 = 9497447938794 := by decide
theorem cert_e701354916586 : check e701354916586 [[.under,.left]] .sourceHead = true := by decide
def e701354916778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701354916778 : Closed e701354916778 ∧ code e701354916778 = 9497447938986 := by decide
theorem cert_e701354916778 : check e701354916778 [[.under,.left]] .sourceHead = true := by decide
def e701354917210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701354917210 : Closed e701354917210 ∧ code e701354917210 = 9497447939418 := by decide
theorem cert_e701354917210 : check e701354917210 [[.under,.left]] .sourceHead = true := by decide
def e701354917226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701354917226 : Closed e701354917226 ∧ code e701354917226 = 9497447939434 := by decide
theorem cert_e701354917226 : check e701354917226 [[.under,.left]] .sourceHead = true := by decide
def e701354917290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701354917290 : Closed e701354917290 ∧ code e701354917290 = 9497447939498 := by decide
theorem cert_e701354917290 : check e701354917290 [[.under,.left]] .sourceHead = true := by decide
def e701354921402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701354921402 : Closed e701354921402 ∧ code e701354921402 = 9497447943610 := by decide
theorem cert_e701354921402 : check e701354921402 [[.under,.left]] .sourceHead = true := by decide
def e701354921434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701354921434 : Closed e701354921434 ∧ code e701354921434 = 9497447943642 := by decide
theorem cert_e701354921434 : check e701354921434 [[.under,.left]] .sourceHead = true := by decide
def e701354921658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701354921658 : Closed e701354921658 ∧ code e701354921658 = 9497447943866 := by decide
theorem cert_e701354921658 : check e701354921658 [[.under,.left]] .sourceHead = true := by decide
def e701354921706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701354921706 : Closed e701354921706 ∧ code e701354921706 = 9497447943914 := by decide
theorem cert_e701354921706 : check e701354921706 [[.under,.left]] .sourceHead = true := by decide
def e701354921818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701354921818 : Closed e701354921818 ∧ code e701354921818 = 9497447944026 := by decide
theorem cert_e701354921818 : check e701354921818 [[.under,.left]] .sourceHead = true := by decide
def e701354921834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701354921834 : Closed e701354921834 ∧ code e701354921834 = 9497447944042 := by decide
theorem cert_e701354921834 : check e701354921834 [[.under,.left]] .sourceHead = true := by decide
def e701354922938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701354922938 : Closed e701354922938 ∧ code e701354922938 = 9497447945146 := by decide
theorem cert_e701354922938 : check e701354922938 [[.under,.left]] .sourceHead = true := by decide
def e701354922970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701354922970 : Closed e701354922970 ∧ code e701354922970 = 9497447945178 := by decide
theorem cert_e701354922970 : check e701354922970 [[.under,.left]] .sourceHead = true := by decide
def e701354924474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701354924474 : Closed e701354924474 ∧ code e701354924474 = 9497447946682 := by decide
theorem cert_e701354924474 : check e701354924474 [[.under,.left]] .sourceHead = true := by decide
def e701354924522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701354924522 : Closed e701354924522 ∧ code e701354924522 = 9497447946730 := by decide
theorem cert_e701354924522 : check e701354924522 [[.under,.left]] .sourceHead = true := by decide
def e701354925274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701354925274 : Closed e701354925274 ∧ code e701354925274 = 9497447947482 := by decide
theorem cert_e701354925274 : check e701354925274 [[.under,.left]] .sourceHead = true := by decide
def e701354925290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701354925290 : Closed e701354925290 ∧ code e701354925290 = 9497447947498 := by decide
theorem cert_e701354925290 : check e701354925290 [[.under,.left]] .sourceHead = true := by decide
def e701354927802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701354927802 : Closed e701354927802 ∧ code e701354927802 = 9497447950010 := by decide
theorem cert_e701354927802 : check e701354927802 [[.under,.left]] .sourceHead = true := by decide
def e701354927850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701354927850 : Closed e701354927850 ∧ code e701354927850 = 9497447950058 := by decide
theorem cert_e701354927850 : check e701354927850 [[.under,.left]] .sourceHead = true := by decide
def e701354928042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701354928042 : Closed e701354928042 ∧ code e701354928042 = 9497447950250 := by decide
theorem cert_e701354928042 : check e701354928042 [[.under,.left]] .sourceHead = true := by decide
def e701354928570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701354928570 : Closed e701354928570 ∧ code e701354928570 = 9497447950778 := by decide
theorem cert_e701354928570 : check e701354928570 [[.under,.left]] .sourceHead = true := by decide
def e701354928618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701354928618 : Closed e701354928618 ∧ code e701354928618 = 9497447950826 := by decide
theorem cert_e701354928618 : check e701354928618 [[.under,.left]] .sourceHead = true := by decide
def e701354929770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701354929770 : Closed e701354929770 ∧ code e701354929770 = 9497447951978 := by decide
theorem cert_e701354929770 : check e701354929770 [[.under,.left]] .sourceHead = true := by decide
def e701354931034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701354931034 : Closed e701354931034 ∧ code e701354931034 = 9497447953242 := by decide
theorem cert_e701354931034 : check e701354931034 [[.under,.left]] .sourceHead = true := by decide
def e701354931050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701354931050 : Closed e701354931050 ∧ code e701354931050 = 9497447953258 := by decide
theorem cert_e701354931050 : check e701354931050 [[.under,.left]] .sourceHead = true := by decide
def e701354931114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701354931114 : Closed e701354931114 ∧ code e701354931114 = 9497447953322 := by decide
theorem cert_e701354931114 : check e701354931114 [[.under,.left]] .sourceHead = true := by decide
def e701354931418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701354931418 : Closed e701354931418 ∧ code e701354931418 = 9497447953626 := by decide
theorem cert_e701354931418 : check e701354931418 [[.under,.left]] .sourceHead = true := by decide
def e701354931434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701354931434 : Closed e701354931434 ∧ code e701354931434 = 9497447953642 := by decide
theorem cert_e701354931434 : check e701354931434 [[.under,.left]] .sourceHead = true := by decide
def e701354931818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701354931818 : Closed e701354931818 ∧ code e701354931818 = 9497447954026 := by decide
theorem cert_e701354931818 : check e701354931818 [[.under,.left]] .sourceHead = true := by decide
def e701354945978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701354945978 : Closed e701354945978 ∧ code e701354945978 = 9497447968186 := by decide
theorem cert_e701354945978 : check e701354945978 [[.under,.left]] .sourceHead = true := by decide
def e701354946010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701354946010 : Closed e701354946010 ∧ code e701354946010 = 9497447968218 := by decide
theorem cert_e701354946010 : check e701354946010 [[.under,.left]] .sourceHead = true := by decide
def e701354946234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701354946234 : Closed e701354946234 ∧ code e701354946234 = 9497447968442 := by decide
theorem cert_e701354946234 : check e701354946234 [[.under,.left]] .sourceHead = true := by decide
def e701354946282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701354946282 : Closed e701354946282 ∧ code e701354946282 = 9497447968490 := by decide
theorem cert_e701354946282 : check e701354946282 [[.under,.left]] .sourceHead = true := by decide
def e701354946394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701354946394 : Closed e701354946394 ∧ code e701354946394 = 9497447968602 := by decide
theorem cert_e701354946394 : check e701354946394 [[.under,.left]] .sourceHead = true := by decide
def e701354946410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701354946410 : Closed e701354946410 ∧ code e701354946410 = 9497447968618 := by decide
theorem cert_e701354946410 : check e701354946410 [[.under,.left]] .sourceHead = true := by decide
def e701354947514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701354947514 : Closed e701354947514 ∧ code e701354947514 = 9497447969722 := by decide
theorem cert_e701354947514 : check e701354947514 [[.under,.left]] .sourceHead = true := by decide
def e701354947546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701354947546 : Closed e701354947546 ∧ code e701354947546 = 9497447969754 := by decide
theorem cert_e701354947546 : check e701354947546 [[.under,.left]] .sourceHead = true := by decide
def e701354949050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701354949050 : Closed e701354949050 ∧ code e701354949050 = 9497447971258 := by decide
theorem cert_e701354949050 : check e701354949050 [[.under,.left]] .sourceHead = true := by decide
def e701354949098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701354949098 : Closed e701354949098 ∧ code e701354949098 = 9497447971306 := by decide
theorem cert_e701354949098 : check e701354949098 [[.under,.left]] .sourceHead = true := by decide
def e701354949850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701354949850 : Closed e701354949850 ∧ code e701354949850 = 9497447972058 := by decide
theorem cert_e701354949850 : check e701354949850 [[.under,.left]] .sourceHead = true := by decide
def e701354949866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701354949866 : Closed e701354949866 ∧ code e701354949866 = 9497447972074 := by decide
theorem cert_e701354949866 : check e701354949866 [[.under,.left]] .sourceHead = true := by decide
def e701354972858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701354972858 : Closed e701354972858 ∧ code e701354972858 = 9497447995066 := by decide
theorem cert_e701354972858 : check e701354972858 [[.under,.left]] .sourceHead = true := by decide
def e701354972906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701354972906 : Closed e701354972906 ∧ code e701354972906 = 9497447995114 := by decide
theorem cert_e701354972906 : check e701354972906 [[.under,.left]] .sourceHead = true := by decide
def e701354973098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701354973098 : Closed e701354973098 ∧ code e701354973098 = 9497447995306 := by decide
theorem cert_e701354973098 : check e701354973098 [[.under,.left]] .sourceHead = true := by decide
def e701354973626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701354973626 : Closed e701354973626 ∧ code e701354973626 = 9497447995834 := by decide
theorem cert_e701354973626 : check e701354973626 [[.under,.left]] .sourceHead = true := by decide
def e701354973674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701354973674 : Closed e701354973674 ∧ code e701354973674 = 9497447995882 := by decide
theorem cert_e701354973674 : check e701354973674 [[.under,.left]] .sourceHead = true := by decide
def e701354974826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701354974826 : Closed e701354974826 ∧ code e701354974826 = 9497447997034 := by decide
theorem cert_e701354974826 : check e701354974826 [[.under,.left]] .sourceHead = true := by decide
def e701354986330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701354986330 : Closed e701354986330 ∧ code e701354986330 = 9497448008538 := by decide
theorem cert_e701354986330 : check e701354986330 [[.under,.left]] .sourceHead = true := by decide
def e701354986346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701354986346 : Closed e701354986346 ∧ code e701354986346 = 9497448008554 := by decide
theorem cert_e701354986346 : check e701354986346 [[.under,.left]] .sourceHead = true := by decide
def e701354986410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701354986410 : Closed e701354986410 ∧ code e701354986410 = 9497448008618 := by decide
theorem cert_e701354986410 : check e701354986410 [[.under,.left]] .sourceHead = true := by decide
def e701354986714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701354986714 : Closed e701354986714 ∧ code e701354986714 = 9497448008922 := by decide
theorem cert_e701354986714 : check e701354986714 [[.under,.left]] .sourceHead = true := by decide
def e701354986730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701354986730 : Closed e701354986730 ∧ code e701354986730 = 9497448008938 := by decide
theorem cert_e701354986730 : check e701354986730 [[.under,.left]] .sourceHead = true := by decide
def e701354987114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701354987114 : Closed e701354987114 ∧ code e701354987114 = 9497448009322 := by decide
theorem cert_e701354987114 : check e701354987114 [[.under,.left]] .sourceHead = true := by decide
def e701355535802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701355535802 : Closed e701355535802 ∧ code e701355535802 = 9497448558010 := by decide
theorem cert_e701355535802 : check e701355535802 [[.under,.left]] .sourceHead = true := by decide
def e701355535834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701355535834 : Closed e701355535834 ∧ code e701355535834 = 9497448558042 := by decide
theorem cert_e701355535834 : check e701355535834 [[.under,.left]] .sourceHead = true := by decide
def e701355536058 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701355536058 : Closed e701355536058 ∧ code e701355536058 = 9497448558266 := by decide
theorem cert_e701355536058 : check e701355536058 [[.under,.left]] .sourceHead = true := by decide
def e701355536106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701355536106 : Closed e701355536106 ∧ code e701355536106 = 9497448558314 := by decide
theorem cert_e701355536106 : check e701355536106 [[.under,.left]] .sourceHead = true := by decide
def e701355536218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701355536218 : Closed e701355536218 ∧ code e701355536218 = 9497448558426 := by decide
theorem cert_e701355536218 : check e701355536218 [[.under,.left]] .sourceHead = true := by decide
def e701355536234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701355536234 : Closed e701355536234 ∧ code e701355536234 = 9497448558442 := by decide
theorem cert_e701355536234 : check e701355536234 [[.under,.left]] .sourceHead = true := by decide
def e701355537338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701355537338 : Closed e701355537338 ∧ code e701355537338 = 9497448559546 := by decide
theorem cert_e701355537338 : check e701355537338 [[.under,.left]] .sourceHead = true := by decide
def e701355537370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701355537370 : Closed e701355537370 ∧ code e701355537370 = 9497448559578 := by decide
theorem cert_e701355537370 : check e701355537370 [[.under,.left]] .sourceHead = true := by decide
def e701355538874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701355538874 : Closed e701355538874 ∧ code e701355538874 = 9497448561082 := by decide
theorem cert_e701355538874 : check e701355538874 [[.under,.left]] .sourceHead = true := by decide
def e701355538922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701355538922 : Closed e701355538922 ∧ code e701355538922 = 9497448561130 := by decide
theorem cert_e701355538922 : check e701355538922 [[.under,.left]] .sourceHead = true := by decide
def e701355539674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701355539674 : Closed e701355539674 ∧ code e701355539674 = 9497448561882 := by decide
theorem cert_e701355539674 : check e701355539674 [[.under,.left]] .sourceHead = true := by decide
def e701355539690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701355539690 : Closed e701355539690 ∧ code e701355539690 = 9497448561898 := by decide
theorem cert_e701355539690 : check e701355539690 [[.under,.left]] .sourceHead = true := by decide
def e701357895098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701357895098 : Closed e701357895098 ∧ code e701357895098 = 9497450917306 := by decide
theorem cert_e701357895098 : check e701357895098 [[.under,.left]] .sourceHead = true := by decide
def e701357895130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701357895130 : Closed e701357895130 ∧ code e701357895130 = 9497450917338 := by decide
theorem cert_e701357895130 : check e701357895130 [[.under,.left]] .sourceHead = true := by decide
def e701357895354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701357895354 : Closed e701357895354 ∧ code e701357895354 = 9497450917562 := by decide
theorem cert_e701357895354 : check e701357895354 [[.under,.left]] .sourceHead = true := by decide
def e701357895402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701357895402 : Closed e701357895402 ∧ code e701357895402 = 9497450917610 := by decide
theorem cert_e701357895402 : check e701357895402 [[.under,.left]] .sourceHead = true := by decide
def e701357895514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701357895514 : Closed e701357895514 ∧ code e701357895514 = 9497450917722 := by decide
theorem cert_e701357895514 : check e701357895514 [[.under,.left]] .sourceHead = true := by decide
def e701357895530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701357895530 : Closed e701357895530 ∧ code e701357895530 = 9497450917738 := by decide
theorem cert_e701357895530 : check e701357895530 [[.under,.left]] .sourceHead = true := by decide
def e701357896634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701357896634 : Closed e701357896634 ∧ code e701357896634 = 9497450918842 := by decide
theorem cert_e701357896634 : check e701357896634 [[.under,.left]] .sourceHead = true := by decide
def e701357896666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701357896666 : Closed e701357896666 ∧ code e701357896666 = 9497450918874 := by decide
theorem cert_e701357896666 : check e701357896666 [[.under,.left]] .sourceHead = true := by decide
def e701357898170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701357898170 : Closed e701357898170 ∧ code e701357898170 = 9497450920378 := by decide
theorem cert_e701357898170 : check e701357898170 [[.under,.left]] .sourceHead = true := by decide
def e701357898218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701357898218 : Closed e701357898218 ∧ code e701357898218 = 9497450920426 := by decide
theorem cert_e701357898218 : check e701357898218 [[.under,.left]] .sourceHead = true := by decide
def e701357898970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701357898970 : Closed e701357898970 ∧ code e701357898970 = 9497450921178 := by decide
theorem cert_e701357898970 : check e701357898970 [[.under,.left]] .sourceHead = true := by decide
def e701357898986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701357898986 : Closed e701357898986 ∧ code e701357898986 = 9497450921194 := by decide
theorem cert_e701357898986 : check e701357898986 [[.under,.left]] .sourceHead = true := by decide
def e725044877034 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)) (.var 0)))
theorem wire_e725044877034 : Closed e725044877034 ∧ code e725044877034 = 9521137899242 := by decide
theorem cert_e725044877034 : check e725044877034 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044877162 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)) (.var 0)))
theorem wire_e725044877162 : Closed e725044877162 ∧ code e725044877162 = 9521137899370 := by decide
theorem cert_e725044877162 : check e725044877162 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044878058 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.var 0)))
theorem wire_e725044878058 : Closed e725044878058 ∧ code e725044878058 = 9521137900266 := by decide
theorem cert_e725044878058 : check e725044878058 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044878250 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044878250 : Closed e725044878250 ∧ code e725044878250 = 9521137900458 := by decide
theorem cert_e725044878250 : check e725044878250 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044878698 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)) (.var 0)))
theorem wire_e725044878698 : Closed e725044878698 ∧ code e725044878698 = 9521137900906 := by decide
theorem cert_e725044878698 : check e725044878698 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044878762 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044878762 : Closed e725044878762 ∧ code e725044878762 = 9521137900970 := by decide
theorem cert_e725044878762 : check e725044878762 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044882154 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)) (.var 0)))
theorem wire_e725044882154 : Closed e725044882154 ∧ code e725044882154 = 9521137904362 := by decide
theorem cert_e725044882154 : check e725044882154 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044882346 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044882346 : Closed e725044882346 ∧ code e725044882346 = 9521137904554 := by decide
theorem cert_e725044882346 : check e725044882346 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044883114 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044883114 : Closed e725044883114 ∧ code e725044883114 = 9521137905322 := by decide
theorem cert_e725044883114 : check e725044883114 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044884842 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)) (.var 0)))
theorem wire_e725044884842 : Closed e725044884842 ∧ code e725044884842 = 9521137907050 := by decide
theorem cert_e725044884842 : check e725044884842 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044884906 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044884906 : Closed e725044884906 ∧ code e725044884906 = 9521137907114 := by decide
theorem cert_e725044884906 : check e725044884906 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044885162 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044885162 : Closed e725044885162 ∧ code e725044885162 = 9521137907370 := by decide
theorem cert_e725044885162 : check e725044885162 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044901610 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)) (.var 0)))
theorem wire_e725044901610 : Closed e725044901610 ∧ code e725044901610 = 9521137923818 := by decide
theorem cert_e725044901610 : check e725044901610 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044901738 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)) (.var 0)))
theorem wire_e725044901738 : Closed e725044901738 ∧ code e725044901738 = 9521137923946 := by decide
theorem cert_e725044901738 : check e725044901738 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044902634 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)) (.var 0)))
theorem wire_e725044902634 : Closed e725044902634 ∧ code e725044902634 = 9521137924842 := by decide
theorem cert_e725044902634 : check e725044902634 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044902826 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044902826 : Closed e725044902826 ∧ code e725044902826 = 9521137925034 := by decide
theorem cert_e725044902826 : check e725044902826 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044903274 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)) (.var 0)))
theorem wire_e725044903274 : Closed e725044903274 ∧ code e725044903274 = 9521137925482 := by decide
theorem cert_e725044903274 : check e725044903274 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044903338 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044903338 : Closed e725044903338 ∧ code e725044903338 = 9521137925546 := by decide
theorem cert_e725044903338 : check e725044903338 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044907754 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725044907754 : Closed e725044907754 ∧ code e725044907754 = 9521137929962 := by decide
theorem cert_e725044907754 : check e725044907754 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044907882 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725044907882 : Closed e725044907882 ∧ code e725044907882 = 9521137930090 := by decide
theorem cert_e725044907882 : check e725044907882 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044913898 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725044913898 : Closed e725044913898 ∧ code e725044913898 = 9521137936106 := by decide
theorem cert_e725044913898 : check e725044913898 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044914090 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725044914090 : Closed e725044914090 ∧ code e725044914090 = 9521137936298 := by decide
theorem cert_e725044914090 : check e725044914090 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044917098 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725044917098 : Closed e725044917098 ∧ code e725044917098 = 9521137939306 := by decide
theorem cert_e725044917098 : check e725044917098 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044917162 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725044917162 : Closed e725044917162 ∧ code e725044917162 = 9521137939370 := by decide
theorem cert_e725044917162 : check e725044917162 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044927210 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)) (.var 0)))
theorem wire_e725044927210 : Closed e725044927210 ∧ code e725044927210 = 9521137949418 := by decide
theorem cert_e725044927210 : check e725044927210 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044927402 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044927402 : Closed e725044927402 ∧ code e725044927402 = 9521137949610 := by decide
theorem cert_e725044927402 : check e725044927402 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044928170 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044928170 : Closed e725044928170 ∧ code e725044928170 = 9521137950378 := by decide
theorem cert_e725044928170 : check e725044928170 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044930282 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725044930282 : Closed e725044930282 ∧ code e725044930282 = 9521137952490 := by decide
theorem cert_e725044930282 : check e725044930282 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044930474 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725044930474 : Closed e725044930474 ∧ code e725044930474 = 9521137952682 := by decide
theorem cert_e725044930474 : check e725044930474 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044935082 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725044935082 : Closed e725044935082 ∧ code e725044935082 = 9521137957290 := by decide
theorem cert_e725044935082 : check e725044935082 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044940138 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)) (.var 0)))
theorem wire_e725044940138 : Closed e725044940138 ∧ code e725044940138 = 9521137962346 := by decide
theorem cert_e725044940138 : check e725044940138 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044940202 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044940202 : Closed e725044940202 ∧ code e725044940202 = 9521137962410 := by decide
theorem cert_e725044940202 : check e725044940202 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044940458 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)) (.var 0)))
theorem wire_e725044940458 : Closed e725044940458 ∧ code e725044940458 = 9521137962666 := by decide
theorem cert_e725044940458 : check e725044940458 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044941674 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725044941674 : Closed e725044941674 ∧ code e725044941674 = 9521137963882 := by decide
theorem cert_e725044941674 : check e725044941674 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044941738 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725044941738 : Closed e725044941738 ∧ code e725044941738 = 9521137963946 := by decide
theorem cert_e725044941738 : check e725044941738 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044943274 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725044943274 : Closed e725044943274 ∧ code e725044943274 = 9521137965482 := by decide
theorem cert_e725044943274 : check e725044943274 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725044999914 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725044999914 : Closed e725044999914 ∧ code e725044999914 = 9521138022122 := by decide
theorem cert_e725044999914 : check e725044999914 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045000042 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725045000042 : Closed e725045000042 ∧ code e725045000042 = 9521138022250 := by decide
theorem cert_e725045000042 : check e725045000042 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045000938 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725045000938 : Closed e725045000938 ∧ code e725045000938 = 9521138023146 := by decide
theorem cert_e725045000938 : check e725045000938 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045001130 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725045001130 : Closed e725045001130 ∧ code e725045001130 = 9521138023338 := by decide
theorem cert_e725045001130 : check e725045001130 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045001578 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725045001578 : Closed e725045001578 ∧ code e725045001578 = 9521138023786 := by decide
theorem cert_e725045001578 : check e725045001578 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045001642 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725045001642 : Closed e725045001642 ∧ code e725045001642 = 9521138023850 := by decide
theorem cert_e725045001642 : check e725045001642 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045006058 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)) (.var 0)))
theorem wire_e725045006058 : Closed e725045006058 ∧ code e725045006058 = 9521138028266 := by decide
theorem cert_e725045006058 : check e725045006058 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045006186 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)) (.var 0)))
theorem wire_e725045006186 : Closed e725045006186 ∧ code e725045006186 = 9521138028394 := by decide
theorem cert_e725045006186 : check e725045006186 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045012202 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)) (.var 0)))
theorem wire_e725045012202 : Closed e725045012202 ∧ code e725045012202 = 9521138034410 := by decide
theorem cert_e725045012202 : check e725045012202 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045012394 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725045012394 : Closed e725045012394 ∧ code e725045012394 = 9521138034602 := by decide
theorem cert_e725045012394 : check e725045012394 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045015402 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)) (.var 0)))
theorem wire_e725045015402 : Closed e725045015402 ∧ code e725045015402 = 9521138037610 := by decide
theorem cert_e725045015402 : check e725045015402 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045015466 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725045015466 : Closed e725045015466 ∧ code e725045015466 = 9521138037674 := by decide
theorem cert_e725045015466 : check e725045015466 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045107434 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725045107434 : Closed e725045107434 ∧ code e725045107434 = 9521138129642 := by decide
theorem cert_e725045107434 : check e725045107434 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045107626 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725045107626 : Closed e725045107626 ∧ code e725045107626 = 9521138129834 := by decide
theorem cert_e725045107626 : check e725045107626 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045108394 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725045108394 : Closed e725045108394 ∧ code e725045108394 = 9521138130602 := by decide
theorem cert_e725045108394 : check e725045108394 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045110506 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)) (.var 0)))
theorem wire_e725045110506 : Closed e725045110506 ∧ code e725045110506 = 9521138132714 := by decide
theorem cert_e725045110506 : check e725045110506 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045110698 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725045110698 : Closed e725045110698 ∧ code e725045110698 = 9521138132906 := by decide
theorem cert_e725045110698 : check e725045110698 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045115306 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725045115306 : Closed e725045115306 ∧ code e725045115306 = 9521138137514 := by decide
theorem cert_e725045115306 : check e725045115306 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045161322 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725045161322 : Closed e725045161322 ∧ code e725045161322 = 9521138183530 := by decide
theorem cert_e725045161322 : check e725045161322 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045161386 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725045161386 : Closed e725045161386 ∧ code e725045161386 = 9521138183594 := by decide
theorem cert_e725045161386 : check e725045161386 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045161642 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725045161642 : Closed e725045161642 ∧ code e725045161642 = 9521138183850 := by decide
theorem cert_e725045161642 : check e725045161642 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045162858 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)) (.var 0)))
theorem wire_e725045162858 : Closed e725045162858 ∧ code e725045162858 = 9521138185066 := by decide
theorem cert_e725045162858 : check e725045162858 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045162922 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725045162922 : Closed e725045162922 ∧ code e725045162922 = 9521138185130 := by decide
theorem cert_e725045162922 : check e725045162922 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725045164458 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725045164458 : Closed e725045164458 ∧ code e725045164458 = 9521138186666 := by decide
theorem cert_e725045164458 : check e725045164458 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047359210 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725047359210 : Closed e725047359210 ∧ code e725047359210 = 9521140381418 := by decide
theorem cert_e725047359210 : check e725047359210 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047359338 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725047359338 : Closed e725047359338 ∧ code e725047359338 = 9521140381546 := by decide
theorem cert_e725047359338 : check e725047359338 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047360234 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725047360234 : Closed e725047360234 ∧ code e725047360234 = 9521140382442 := by decide
theorem cert_e725047360234 : check e725047360234 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047360426 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725047360426 : Closed e725047360426 ∧ code e725047360426 = 9521140382634 := by decide
theorem cert_e725047360426 : check e725047360426 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047360874 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725047360874 : Closed e725047360874 ∧ code e725047360874 = 9521140383082 := by decide
theorem cert_e725047360874 : check e725047360874 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047360938 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725047360938 : Closed e725047360938 ∧ code e725047360938 = 9521140383146 := by decide
theorem cert_e725047360938 : check e725047360938 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e701206900458
#print axioms Blc.Floor43.cert_e701206900586
