import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2212704419866 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2212704419866 : Closed e2212704419866 ∧ code e2212704419866 = 11008797442074 := by decide
theorem cert_e2212704419866 : check e2212704419866 [[]] .width = true := by decide
def e2212704419958 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2212704419958 : Closed e2212704419958 ∧ code e2212704419958 = 11008797442166 := by decide
theorem cert_e2212704419958 : check e2212704419958 [[]] .width = true := by decide
def e2212704420202 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2212704420202 : Closed e2212704420202 ∧ code e2212704420202 = 11008797442410 := by decide
theorem cert_e2212704420202 : check e2212704420202 [[]] .width = true := by decide
def e2212704420250 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2212704420250 : Closed e2212704420250 ∧ code e2212704420250 = 11008797442458 := by decide
theorem cert_e2212704420250 : check e2212704420250 [[]] .width = true := by decide
def e2212704420334 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2212704420334 : Closed e2212704420334 ∧ code e2212704420334 = 11008797442542 := by decide
theorem cert_e2212704420334 : check e2212704420334 [[]] .width = true := by decide
def e2212704421258 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2212704421258 : Closed e2212704421258 ∧ code e2212704421258 = 11008797443466 := by decide
theorem cert_e2212704421258 : check e2212704421258 [[]] .width = true := by decide
def e2212704421282 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2212704421282 : Closed e2212704421282 ∧ code e2212704421282 = 11008797443490 := by decide
theorem cert_e2212704421282 : check e2212704421282 [[]] .width = true := by decide
def e2212704421302 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2212704421302 : Closed e2212704421302 ∧ code e2212704421302 = 11008797443510 := by decide
theorem cert_e2212704421302 : check e2212704421302 [[]] .width = true := by decide
def e2212704421334 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2212704421334 : Closed e2212704421334 ∧ code e2212704421334 = 11008797443542 := by decide
theorem cert_e2212704421334 : check e2212704421334 [[]] .width = true := by decide
def e2212704421338 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2212704421338 : Closed e2212704421338 ∧ code e2212704421338 = 11008797443546 := by decide
theorem cert_e2212704421338 : check e2212704421338 [[]] .width = true := by decide
def e2212704421390 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2212704421390 : Closed e2212704421390 ∧ code e2212704421390 = 11008797443598 := by decide
theorem cert_e2212704421390 : check e2212704421390 [[]] .width = true := by decide
def e2212704421402 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212704421402 : Closed e2212704421402 ∧ code e2212704421402 = 11008797443610 := by decide
theorem cert_e2212704421402 : check e2212704421402 [[]] .width = true := by decide
def e2212704421474 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2212704421474 : Closed e2212704421474 ∧ code e2212704421474 = 11008797443682 := by decide
theorem cert_e2212704421474 : check e2212704421474 [[]] .width = true := by decide
def e2212704421494 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2212704421494 : Closed e2212704421494 ∧ code e2212704421494 = 11008797443702 := by decide
theorem cert_e2212704421494 : check e2212704421494 [[]] .width = true := by decide
def e2212704421686 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2212704421686 : Closed e2212704421686 ∧ code e2212704421686 = 11008797443894 := by decide
theorem cert_e2212704421686 : check e2212704421686 [[]] .width = true := by decide
def e2212704421690 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2212704421690 : Closed e2212704421690 ∧ code e2212704421690 = 11008797443898 := by decide
theorem cert_e2212704421690 : check e2212704421690 [[]] .width = true := by decide
def e2212704425386 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2212704425386 : Closed e2212704425386 ∧ code e2212704425386 = 11008797447594 := by decide
theorem cert_e2212704425386 : check e2212704425386 [[]] .width = true := by decide
def e2212704425482 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2212704425482 : Closed e2212704425482 ∧ code e2212704425482 = 11008797447690 := by decide
theorem cert_e2212704425482 : check e2212704425482 [[]] .width = true := by decide
def e2212704425578 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2212704425578 : Closed e2212704425578 ∧ code e2212704425578 = 11008797447786 := by decide
theorem cert_e2212704425578 : check e2212704425578 [[]] .width = true := by decide
def e2212704425602 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2212704425602 : Closed e2212704425602 ∧ code e2212704425602 = 11008797447810 := by decide
theorem cert_e2212704425602 : check e2212704425602 [[]] .width = true := by decide
def e2212704425626 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2212704425626 : Closed e2212704425626 ∧ code e2212704425626 = 11008797447834 := by decide
theorem cert_e2212704425626 : check e2212704425626 [[]] .width = true := by decide
def e2212704426010 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212704426010 : Closed e2212704426010 ∧ code e2212704426010 = 11008797448218 := by decide
theorem cert_e2212704426010 : check e2212704426010 [[]] .width = true := by decide
def e2212704426102 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2212704426102 : Closed e2212704426102 ∧ code e2212704426102 = 11008797448310 := by decide
theorem cert_e2212704426102 : check e2212704426102 [[]] .width = true := by decide
def e2212704426346 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2212704426346 : Closed e2212704426346 ∧ code e2212704426346 = 11008797448554 := by decide
theorem cert_e2212704426346 : check e2212704426346 [[]] .width = true := by decide
def e2212704426370 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2212704426370 : Closed e2212704426370 ∧ code e2212704426370 = 11008797448578 := by decide
theorem cert_e2212704426370 : check e2212704426370 [[]] .width = true := by decide
def e2212704426394 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2212704426394 : Closed e2212704426394 ∧ code e2212704426394 = 11008797448602 := by decide
theorem cert_e2212704426394 : check e2212704426394 [[]] .width = true := by decide
def e2212762673178 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212762673178 : Closed e2212762673178 ∧ code e2212762673178 = 11008855695386 := by decide
theorem cert_e2212762673178 : check e2212762673178 [[]] .width = true := by decide
def e2212762673270 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212762673270 : Closed e2212762673270 ∧ code e2212762673270 = 11008855695478 := by decide
theorem cert_e2212762673270 : check e2212762673270 [[]] .width = true := by decide
def e2212762673514 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212762673514 : Closed e2212762673514 ∧ code e2212762673514 = 11008855695722 := by decide
theorem cert_e2212762673514 : check e2212762673514 [[]] .width = true := by decide
def e2212762673562 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212762673562 : Closed e2212762673562 ∧ code e2212762673562 = 11008855695770 := by decide
theorem cert_e2212762673562 : check e2212762673562 [[]] .width = true := by decide
def e2212763197466 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212763197466 : Closed e2212763197466 ∧ code e2212763197466 = 11008856219674 := by decide
theorem cert_e2212763197466 : check e2212763197466 [[]] .width = true := by decide
def e2212763197558 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212763197558 : Closed e2212763197558 ∧ code e2212763197558 = 11008856219766 := by decide
theorem cert_e2212763197558 : check e2212763197558 [[]] .width = true := by decide
def e2212763197802 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212763197802 : Closed e2212763197802 ∧ code e2212763197802 = 11008856220010 := by decide
theorem cert_e2212763197802 : check e2212763197802 [[]] .width = true := by decide
def e2212763197850 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212763197850 : Closed e2212763197850 ∧ code e2212763197850 = 11008856220058 := by decide
theorem cert_e2212763197850 : check e2212763197850 [[]] .width = true := by decide
def e2212763230234 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212763230234 : Closed e2212763230234 ∧ code e2212763230234 = 11008856252442 := by decide
theorem cert_e2212763230234 : check e2212763230234 [[]] .width = true := by decide
def e2212763230326 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212763230326 : Closed e2212763230326 ∧ code e2212763230326 = 11008856252534 := by decide
theorem cert_e2212763230326 : check e2212763230326 [[]] .width = true := by decide
def e2212763230570 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212763230570 : Closed e2212763230570 ∧ code e2212763230570 = 11008856252778 := by decide
theorem cert_e2212763230570 : check e2212763230570 [[]] .width = true := by decide
def e2212763230618 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212763230618 : Closed e2212763230618 ∧ code e2212763230618 = 11008856252826 := by decide
theorem cert_e2212763230618 : check e2212763230618 [[]] .width = true := by decide
def e2212774207514 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212774207514 : Closed e2212774207514 ∧ code e2212774207514 = 11008867229722 := by decide
theorem cert_e2212774207514 : check e2212774207514 [[]] .width = true := by decide
def e2212774207606 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212774207606 : Closed e2212774207606 ∧ code e2212774207606 = 11008867229814 := by decide
theorem cert_e2212774207606 : check e2212774207606 [[]] .width = true := by decide
def e2212774207850 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212774207850 : Closed e2212774207850 ∧ code e2212774207850 = 11008867230058 := by decide
theorem cert_e2212774207850 : check e2212774207850 [[]] .width = true := by decide
def e2212774207898 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212774207898 : Closed e2212774207898 ∧ code e2212774207898 = 11008867230106 := by decide
theorem cert_e2212774207898 : check e2212774207898 [[]] .width = true := by decide
def e2212777353242 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212777353242 : Closed e2212777353242 ∧ code e2212777353242 = 11008870375450 := by decide
theorem cert_e2212777353242 : check e2212777353242 [[]] .width = true := by decide
def e2212777353334 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212777353334 : Closed e2212777353334 ∧ code e2212777353334 = 11008870375542 := by decide
theorem cert_e2212777353334 : check e2212777353334 [[]] .width = true := by decide
def e2212777353578 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212777353578 : Closed e2212777353578 ∧ code e2212777353578 = 11008870375786 := by decide
theorem cert_e2212777353578 : check e2212777353578 [[]] .width = true := by decide
def e2212777353626 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212777353626 : Closed e2212777353626 ∧ code e2212777353626 = 11008870375834 := by decide
theorem cert_e2212777353626 : check e2212777353626 [[]] .width = true := by decide
def e2212777386010 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212777386010 : Closed e2212777386010 ∧ code e2212777386010 = 11008870408218 := by decide
theorem cert_e2212777386010 : check e2212777386010 [[]] .width = true := by decide
def e2212777386102 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212777386102 : Closed e2212777386102 ∧ code e2212777386102 = 11008870408310 := by decide
theorem cert_e2212777386102 : check e2212777386102 [[]] .width = true := by decide
def e2212777386346 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212777386346 : Closed e2212777386346 ∧ code e2212777386346 = 11008870408554 := by decide
theorem cert_e2212777386346 : check e2212777386346 [[]] .width = true := by decide
def e2212777386394 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212777386394 : Closed e2212777386394 ∧ code e2212777386394 = 11008870408602 := by decide
theorem cert_e2212777386394 : check e2212777386394 [[]] .width = true := by decide
def e2212871725082 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212871725082 : Closed e2212871725082 ∧ code e2212871725082 = 11008964747290 := by decide
theorem cert_e2212871725082 : check e2212871725082 [[]] .width = true := by decide
def e2212871725174 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212871725174 : Closed e2212871725174 ∧ code e2212871725174 = 11008964747382 := by decide
theorem cert_e2212871725174 : check e2212871725174 [[]] .width = true := by decide
def e2212871725418 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212871725418 : Closed e2212871725418 ∧ code e2212871725418 = 11008964747626 := by decide
theorem cert_e2212871725418 : check e2212871725418 [[]] .width = true := by decide
def e2212871725466 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212871725466 : Closed e2212871725466 ∧ code e2212871725466 = 11008964747674 := by decide
theorem cert_e2212871725466 : check e2212871725466 [[]] .width = true := by decide
def e2212872511514 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212872511514 : Closed e2212872511514 ∧ code e2212872511514 = 11008965533722 := by decide
theorem cert_e2212872511514 : check e2212872511514 [[]] .width = true := by decide
def e2212872511606 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212872511606 : Closed e2212872511606 ∧ code e2212872511606 = 11008965533814 := by decide
theorem cert_e2212872511606 : check e2212872511606 [[]] .width = true := by decide
def e2212872511850 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212872511850 : Closed e2212872511850 ∧ code e2212872511850 = 11008965534058 := by decide
theorem cert_e2212872511850 : check e2212872511850 [[]] .width = true := by decide
def e2212872511898 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212872511898 : Closed e2212872511898 ∧ code e2212872511898 = 11008965534106 := by decide
theorem cert_e2212872511898 : check e2212872511898 [[]] .width = true := by decide
def e2212872560666 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212872560666 : Closed e2212872560666 ∧ code e2212872560666 = 11008965582874 := by decide
theorem cert_e2212872560666 : check e2212872560666 [[]] .width = true := by decide
def e2212872560758 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212872560758 : Closed e2212872560758 ∧ code e2212872560758 = 11008965582966 := by decide
theorem cert_e2212872560758 : check e2212872560758 [[]] .width = true := by decide
def e2212872561002 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212872561002 : Closed e2212872561002 ∧ code e2212872561002 = 11008965583210 := by decide
theorem cert_e2212872561002 : check e2212872561002 [[]] .width = true := by decide
def e2212872561050 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212872561050 : Closed e2212872561050 ∧ code e2212872561050 = 11008965583258 := by decide
theorem cert_e2212872561050 : check e2212872561050 [[]] .width = true := by decide
def e2212872566810 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212872566810 : Closed e2212872566810 ∧ code e2212872566810 = 11008965589018 := by decide
theorem cert_e2212872566810 : check e2212872566810 [[]] .width = true := by decide
def e2212874870810 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212874870810 : Closed e2212874870810 ∧ code e2212874870810 = 11008967893018 := by decide
theorem cert_e2212874870810 : check e2212874870810 [[]] .width = true := by decide
def e2212874870902 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212874870902 : Closed e2212874870902 ∧ code e2212874870902 = 11008967893110 := by decide
theorem cert_e2212874870902 : check e2212874870902 [[]] .width = true := by decide
def e2212874871146 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212874871146 : Closed e2212874871146 ∧ code e2212874871146 = 11008967893354 := by decide
theorem cert_e2212874871146 : check e2212874871146 [[]] .width = true := by decide
def e2212874871194 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212874871194 : Closed e2212874871194 ∧ code e2212874871194 = 11008967893402 := by decide
theorem cert_e2212874871194 : check e2212874871194 [[]] .width = true := by decide
def e2212879384774 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2212879384774 : Closed e2212879384774 ∧ code e2212879384774 = 11008972406982 := by decide
theorem cert_e2212879384774 : check e2212879384774 [[]] .width = true := by decide
def e2212879589402 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212879589402 : Closed e2212879589402 ∧ code e2212879589402 = 11008972611610 := by decide
theorem cert_e2212879589402 : check e2212879589402 [[]] .width = true := by decide
def e2212879589494 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212879589494 : Closed e2212879589494 ∧ code e2212879589494 = 11008972611702 := by decide
theorem cert_e2212879589494 : check e2212879589494 [[]] .width = true := by decide
def e2212879589738 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212879589738 : Closed e2212879589738 ∧ code e2212879589738 = 11008972611946 := by decide
theorem cert_e2212879589738 : check e2212879589738 [[]] .width = true := by decide
def e2212879589786 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212879589786 : Closed e2212879589786 ∧ code e2212879589786 = 11008972611994 := by decide
theorem cert_e2212879589786 : check e2212879589786 [[]] .width = true := by decide
def e2212879638554 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212879638554 : Closed e2212879638554 ∧ code e2212879638554 = 11008972660762 := by decide
theorem cert_e2212879638554 : check e2212879638554 [[]] .width = true := by decide
def e2212879638646 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212879638646 : Closed e2212879638646 ∧ code e2212879638646 = 11008972660854 := by decide
theorem cert_e2212879638646 : check e2212879638646 [[]] .width = true := by decide
def e2212879638890 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212879638890 : Closed e2212879638890 ∧ code e2212879638890 = 11008972661098 := by decide
theorem cert_e2212879638890 : check e2212879638890 [[]] .width = true := by decide
def e2212879638938 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212879638938 : Closed e2212879638938 ∧ code e2212879638938 = 11008972661146 := by decide
theorem cert_e2212879638938 : check e2212879638938 [[]] .width = true := by decide
def e2212879644698 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212879644698 : Closed e2212879644698 ∧ code e2212879644698 = 11008972666906 := by decide
theorem cert_e2212879644698 : check e2212879644698 [[]] .width = true := by decide
def e2212880056346 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2212880056346 : Closed e2212880056346 ∧ code e2212880056346 = 11008973078554 := by decide
theorem cert_e2212880056346 : check e2212880056346 [[]] .width = true := by decide
def e2212880056438 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2212880056438 : Closed e2212880056438 ∧ code e2212880056438 = 11008973078646 := by decide
theorem cert_e2212880056438 : check e2212880056438 [[]] .width = true := by decide
def e2212880056682 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2212880056682 : Closed e2212880056682 ∧ code e2212880056682 = 11008973078890 := by decide
theorem cert_e2212880056682 : check e2212880056682 [[]] .width = true := by decide
def e2212880056730 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2212880056730 : Closed e2212880056730 ∧ code e2212880056730 = 11008973078938 := by decide
theorem cert_e2212880056730 : check e2212880056730 [[]] .width = true := by decide
def e2212880056814 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2212880056814 : Closed e2212880056814 ∧ code e2212880056814 = 11008973079022 := by decide
theorem cert_e2212880056814 : check e2212880056814 [[]] .width = true := by decide
def e2212880057738 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2212880057738 : Closed e2212880057738 ∧ code e2212880057738 = 11008973079946 := by decide
theorem cert_e2212880057738 : check e2212880057738 [[]] .width = true := by decide
def e2212880057762 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2212880057762 : Closed e2212880057762 ∧ code e2212880057762 = 11008973079970 := by decide
theorem cert_e2212880057762 : check e2212880057762 [[]] .width = true := by decide
def e2212880057782 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2212880057782 : Closed e2212880057782 ∧ code e2212880057782 = 11008973079990 := by decide
theorem cert_e2212880057782 : check e2212880057782 [[]] .width = true := by decide
def e2212880057814 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2212880057814 : Closed e2212880057814 ∧ code e2212880057814 = 11008973080022 := by decide
theorem cert_e2212880057814 : check e2212880057814 [[]] .width = true := by decide
def e2212880057818 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2212880057818 : Closed e2212880057818 ∧ code e2212880057818 = 11008973080026 := by decide
theorem cert_e2212880057818 : check e2212880057818 [[]] .width = true := by decide
def e2212880057870 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2212880057870 : Closed e2212880057870 ∧ code e2212880057870 = 11008973080078 := by decide
theorem cert_e2212880057870 : check e2212880057870 [[]] .width = true := by decide
def e2212880057882 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212880057882 : Closed e2212880057882 ∧ code e2212880057882 = 11008973080090 := by decide
theorem cert_e2212880057882 : check e2212880057882 [[]] .width = true := by decide
def e2212880057954 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2212880057954 : Closed e2212880057954 ∧ code e2212880057954 = 11008973080162 := by decide
theorem cert_e2212880057954 : check e2212880057954 [[]] .width = true := by decide
def e2212880057974 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2212880057974 : Closed e2212880057974 ∧ code e2212880057974 = 11008973080182 := by decide
theorem cert_e2212880057974 : check e2212880057974 [[]] .width = true := by decide
def e2212880058166 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2212880058166 : Closed e2212880058166 ∧ code e2212880058166 = 11008973080374 := by decide
theorem cert_e2212880058166 : check e2212880058166 [[]] .width = true := by decide
def e2212880058170 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2212880058170 : Closed e2212880058170 ∧ code e2212880058170 = 11008973080378 := by decide
theorem cert_e2212880058170 : check e2212880058170 [[]] .width = true := by decide
def e2212880061866 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2212880061866 : Closed e2212880061866 ∧ code e2212880061866 = 11008973084074 := by decide
theorem cert_e2212880061866 : check e2212880061866 [[]] .width = true := by decide
def e2212880061962 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2212880061962 : Closed e2212880061962 ∧ code e2212880061962 = 11008973084170 := by decide
theorem cert_e2212880061962 : check e2212880061962 [[]] .width = true := by decide
def e2212880062058 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2212880062058 : Closed e2212880062058 ∧ code e2212880062058 = 11008973084266 := by decide
theorem cert_e2212880062058 : check e2212880062058 [[]] .width = true := by decide
def e2212880062082 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2212880062082 : Closed e2212880062082 ∧ code e2212880062082 = 11008973084290 := by decide
theorem cert_e2212880062082 : check e2212880062082 [[]] .width = true := by decide
def e2212880062106 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2212880062106 : Closed e2212880062106 ∧ code e2212880062106 = 11008973084314 := by decide
theorem cert_e2212880062106 : check e2212880062106 [[]] .width = true := by decide
def e2212880062490 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212880062490 : Closed e2212880062490 ∧ code e2212880062490 = 11008973084698 := by decide
theorem cert_e2212880062490 : check e2212880062490 [[]] .width = true := by decide
def e2212880062582 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2212880062582 : Closed e2212880062582 ∧ code e2212880062582 = 11008973084790 := by decide
theorem cert_e2212880062582 : check e2212880062582 [[]] .width = true := by decide
def e2212880062826 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2212880062826 : Closed e2212880062826 ∧ code e2212880062826 = 11008973085034 := by decide
theorem cert_e2212880062826 : check e2212880062826 [[]] .width = true := by decide
def e2212880062850 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2212880062850 : Closed e2212880062850 ∧ code e2212880062850 = 11008973085058 := by decide
theorem cert_e2212880062850 : check e2212880062850 [[]] .width = true := by decide
def e2212880062874 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2212880062874 : Closed e2212880062874 ∧ code e2212880062874 = 11008973085082 := by decide
theorem cert_e2212880062874 : check e2212880062874 [[]] .width = true := by decide
def e2212926775322 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212926775322 : Closed e2212926775322 ∧ code e2212926775322 = 11009019797530 := by decide
theorem cert_e2212926775322 : check e2212926775322 [[]] .width = true := by decide
def e2212926775414 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212926775414 : Closed e2212926775414 ∧ code e2212926775414 = 11009019797622 := by decide
theorem cert_e2212926775414 : check e2212926775414 [[]] .width = true := by decide
def e2212926775658 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212926775658 : Closed e2212926775658 ∧ code e2212926775658 = 11009019797866 := by decide
theorem cert_e2212926775658 : check e2212926775658 [[]] .width = true := by decide
def e2212926775706 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212926775706 : Closed e2212926775706 ∧ code e2212926775706 = 11009019797914 := by decide
theorem cert_e2212926775706 : check e2212926775706 [[]] .width = true := by decide
def e2212926808090 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212926808090 : Closed e2212926808090 ∧ code e2212926808090 = 11009019830298 := by decide
theorem cert_e2212926808090 : check e2212926808090 [[]] .width = true := by decide
def e2212926808182 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212926808182 : Closed e2212926808182 ∧ code e2212926808182 = 11009019830390 := by decide
theorem cert_e2212926808182 : check e2212926808182 [[]] .width = true := by decide
def e2212926808426 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212926808426 : Closed e2212926808426 ∧ code e2212926808426 = 11009019830634 := by decide
theorem cert_e2212926808426 : check e2212926808426 [[]] .width = true := by decide
def e2212926808474 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212926808474 : Closed e2212926808474 ∧ code e2212926808474 = 11009019830682 := by decide
theorem cert_e2212926808474 : check e2212926808474 [[]] .width = true := by decide
def e2212927037466 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212927037466 : Closed e2212927037466 ∧ code e2212927037466 = 11009020059674 := by decide
theorem cert_e2212927037466 : check e2212927037466 [[]] .width = true := by decide
def e2212927037558 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212927037558 : Closed e2212927037558 ∧ code e2212927037558 = 11009020059766 := by decide
theorem cert_e2212927037558 : check e2212927037558 [[]] .width = true := by decide
def e2212927037802 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212927037802 : Closed e2212927037802 ∧ code e2212927037802 = 11009020060010 := by decide
theorem cert_e2212927037802 : check e2212927037802 [[]] .width = true := by decide
def e2212927037850 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212927037850 : Closed e2212927037850 ∧ code e2212927037850 = 11009020060058 := by decide
theorem cert_e2212927037850 : check e2212927037850 [[]] .width = true := by decide
def e2212927086618 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212927086618 : Closed e2212927086618 ∧ code e2212927086618 = 11009020108826 := by decide
theorem cert_e2212927086618 : check e2212927086618 [[]] .width = true := by decide
def e2212927086710 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212927086710 : Closed e2212927086710 ∧ code e2212927086710 = 11009020108918 := by decide
theorem cert_e2212927086710 : check e2212927086710 [[]] .width = true := by decide
def e2212927086954 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212927086954 : Closed e2212927086954 ∧ code e2212927086954 = 11009020109162 := by decide
theorem cert_e2212927086954 : check e2212927086954 [[]] .width = true := by decide
def e2212927087002 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212927087002 : Closed e2212927087002 ∧ code e2212927087002 = 11009020109210 := by decide
theorem cert_e2212927087002 : check e2212927087002 [[]] .width = true := by decide
def e2212927092762 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212927092762 : Closed e2212927092762 ∧ code e2212927092762 = 11009020114970 := by decide
theorem cert_e2212927092762 : check e2212927092762 [[]] .width = true := by decide
def e2212927201306 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212927201306 : Closed e2212927201306 ∧ code e2212927201306 = 11009020223514 := by decide
theorem cert_e2212927201306 : check e2212927201306 [[]] .width = true := by decide
def e2212927201398 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212927201398 : Closed e2212927201398 ∧ code e2212927201398 = 11009020223606 := by decide
theorem cert_e2212927201398 : check e2212927201398 [[]] .width = true := by decide
def e2212927201642 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212927201642 : Closed e2212927201642 ∧ code e2212927201642 = 11009020223850 := by decide
theorem cert_e2212927201642 : check e2212927201642 [[]] .width = true := by decide
def e2212927201690 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212927201690 : Closed e2212927201690 ∧ code e2212927201690 = 11009020223898 := by decide
theorem cert_e2212927201690 : check e2212927201690 [[]] .width = true := by decide
def e2212927217690 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212927217690 : Closed e2212927217690 ∧ code e2212927217690 = 11009020239898 := by decide
theorem cert_e2212927217690 : check e2212927217690 [[]] .width = true := by decide
def e2212927217782 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212927217782 : Closed e2212927217782 ∧ code e2212927217782 = 11009020239990 := by decide
theorem cert_e2212927217782 : check e2212927217782 [[]] .width = true := by decide
def e2212927218026 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212927218026 : Closed e2212927218026 ∧ code e2212927218026 = 11009020240234 := by decide
theorem cert_e2212927218026 : check e2212927218026 [[]] .width = true := by decide
def e2212927218074 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212927218074 : Closed e2212927218074 ∧ code e2212927218074 = 11009020240282 := by decide
theorem cert_e2212927218074 : check e2212927218074 [[]] .width = true := by decide
def e2212927223834 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212927223834 : Closed e2212927223834 ∧ code e2212927223834 = 11009020246042 := by decide
theorem cert_e2212927223834 : check e2212927223834 [[]] .width = true := by decide
def e2212927232026 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212927232026 : Closed e2212927232026 ∧ code e2212927232026 = 11009020254234 := by decide
theorem cert_e2212927232026 : check e2212927232026 [[]] .width = true := by decide
def e2212928348186 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212928348186 : Closed e2212928348186 ∧ code e2212928348186 = 11009021370394 := by decide
theorem cert_e2212928348186 : check e2212928348186 [[]] .width = true := by decide
def e2212928348278 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212928348278 : Closed e2212928348278 ∧ code e2212928348278 = 11009021370486 := by decide
theorem cert_e2212928348278 : check e2212928348278 [[]] .width = true := by decide
def e2212928348522 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212928348522 : Closed e2212928348522 ∧ code e2212928348522 = 11009021370730 := by decide
theorem cert_e2212928348522 : check e2212928348522 [[]] .width = true := by decide
def e2212928348570 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212928348570 : Closed e2212928348570 ∧ code e2212928348570 = 11009021370778 := by decide
theorem cert_e2212928348570 : check e2212928348570 [[]] .width = true := by decide
def e2212928380954 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212928380954 : Closed e2212928380954 ∧ code e2212928380954 = 11009021403162 := by decide
theorem cert_e2212928380954 : check e2212928380954 [[]] .width = true := by decide
def e2212928381046 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212928381046 : Closed e2212928381046 ∧ code e2212928381046 = 11009021403254 := by decide
theorem cert_e2212928381046 : check e2212928381046 [[]] .width = true := by decide
def e2212928381290 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212928381290 : Closed e2212928381290 ∧ code e2212928381290 = 11009021403498 := by decide
theorem cert_e2212928381290 : check e2212928381290 [[]] .width = true := by decide
def e2212928381338 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212928381338 : Closed e2212928381338 ∧ code e2212928381338 = 11009021403546 := by decide
theorem cert_e2212928381338 : check e2212928381338 [[]] .width = true := by decide
def e2212929716422 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2212929716422 : Closed e2212929716422 ∧ code e2212929716422 = 11009022738630 := by decide
theorem cert_e2212929716422 : check e2212929716422 [[]] .width = true := by decide
def e2212929921050 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212929921050 : Closed e2212929921050 ∧ code e2212929921050 = 11009022943258 := by decide
theorem cert_e2212929921050 : check e2212929921050 [[]] .width = true := by decide
def e2212929921142 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212929921142 : Closed e2212929921142 ∧ code e2212929921142 = 11009022943350 := by decide
theorem cert_e2212929921142 : check e2212929921142 [[]] .width = true := by decide
def e2212929921386 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212929921386 : Closed e2212929921386 ∧ code e2212929921386 = 11009022943594 := by decide
theorem cert_e2212929921386 : check e2212929921386 [[]] .width = true := by decide
def e2212929921434 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212929921434 : Closed e2212929921434 ∧ code e2212929921434 = 11009022943642 := by decide
theorem cert_e2212929921434 : check e2212929921434 [[]] .width = true := by decide
def e2212929970202 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212929970202 : Closed e2212929970202 ∧ code e2212929970202 = 11009022992410 := by decide
theorem cert_e2212929970202 : check e2212929970202 [[]] .width = true := by decide
def e2212929970294 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212929970294 : Closed e2212929970294 ∧ code e2212929970294 = 11009022992502 := by decide
theorem cert_e2212929970294 : check e2212929970294 [[]] .width = true := by decide
def e2212929970538 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212929970538 : Closed e2212929970538 ∧ code e2212929970538 = 11009022992746 := by decide
theorem cert_e2212929970538 : check e2212929970538 [[]] .width = true := by decide
def e2212929970586 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212929970586 : Closed e2212929970586 ∧ code e2212929970586 = 11009022992794 := by decide
theorem cert_e2212929970586 : check e2212929970586 [[]] .width = true := by decide
def e2212929976346 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212929976346 : Closed e2212929976346 ∧ code e2212929976346 = 11009022998554 := by decide
theorem cert_e2212929976346 : check e2212929976346 [[]] .width = true := by decide
def e2212930387994 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2212930387994 : Closed e2212930387994 ∧ code e2212930387994 = 11009023410202 := by decide
theorem cert_e2212930387994 : check e2212930387994 [[]] .width = true := by decide
def e2212930388086 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2212930388086 : Closed e2212930388086 ∧ code e2212930388086 = 11009023410294 := by decide
theorem cert_e2212930388086 : check e2212930388086 [[]] .width = true := by decide
def e2212930388330 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2212930388330 : Closed e2212930388330 ∧ code e2212930388330 = 11009023410538 := by decide
theorem cert_e2212930388330 : check e2212930388330 [[]] .width = true := by decide
def e2212930388378 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2212930388378 : Closed e2212930388378 ∧ code e2212930388378 = 11009023410586 := by decide
theorem cert_e2212930388378 : check e2212930388378 [[]] .width = true := by decide
def e2212930388462 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2212930388462 : Closed e2212930388462 ∧ code e2212930388462 = 11009023410670 := by decide
theorem cert_e2212930388462 : check e2212930388462 [[]] .width = true := by decide
def e2212930389386 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2212930389386 : Closed e2212930389386 ∧ code e2212930389386 = 11009023411594 := by decide
theorem cert_e2212930389386 : check e2212930389386 [[]] .width = true := by decide
def e2212930389410 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2212930389410 : Closed e2212930389410 ∧ code e2212930389410 = 11009023411618 := by decide
theorem cert_e2212930389410 : check e2212930389410 [[]] .width = true := by decide
def e2212930389430 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2212930389430 : Closed e2212930389430 ∧ code e2212930389430 = 11009023411638 := by decide
theorem cert_e2212930389430 : check e2212930389430 [[]] .width = true := by decide
def e2212930389462 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2212930389462 : Closed e2212930389462 ∧ code e2212930389462 = 11009023411670 := by decide
theorem cert_e2212930389462 : check e2212930389462 [[]] .width = true := by decide
def e2212930389466 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2212930389466 : Closed e2212930389466 ∧ code e2212930389466 = 11009023411674 := by decide
theorem cert_e2212930389466 : check e2212930389466 [[]] .width = true := by decide
def e2212930389518 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2212930389518 : Closed e2212930389518 ∧ code e2212930389518 = 11009023411726 := by decide
theorem cert_e2212930389518 : check e2212930389518 [[]] .width = true := by decide
def e2212930389530 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212930389530 : Closed e2212930389530 ∧ code e2212930389530 = 11009023411738 := by decide
theorem cert_e2212930389530 : check e2212930389530 [[]] .width = true := by decide
end Blc.Floor43
