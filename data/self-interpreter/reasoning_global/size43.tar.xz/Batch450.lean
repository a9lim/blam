import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422377897706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422377897706 : Closed e2422377897706 ∧ code e2422377897706 = 11218470919914 := by decide
theorem cert_e2422377897706 : check e2422377897706 [[],[]] .three = true := by decide
def e2422377897814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422377897814 : Closed e2422377897814 ∧ code e2422377897814 = 11218470920022 := by decide
theorem cert_e2422377897814 : check e2422377897814 [[],[]] .three = true := by decide
def e2422377897818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422377897818 : Closed e2422377897818 ∧ code e2422377897818 = 11218470920026 := by decide
theorem cert_e2422377897818 : check e2422377897818 [[],[]] .three = true := by decide
def e2422377897834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422377897834 : Closed e2422377897834 ∧ code e2422377897834 = 11218470920042 := by decide
theorem cert_e2422377897834 : check e2422377897834 [[],[]] .three = true := by decide
def e2422377898222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422377898222 : Closed e2422377898222 ∧ code e2422377898222 = 11218470920430 := by decide
theorem cert_e2422377898222 : check e2422377898222 [[],[]] .three = true := by decide
def e2422377898230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1))))))))
theorem wire_e2422377898230 : Closed e2422377898230 ∧ code e2422377898230 = 11218470920438 := by decide
theorem cert_e2422377898230 : check e2422377898230 [[],[]] .three = true := by decide
def e2422377898234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422377898234 : Closed e2422377898234 ∧ code e2422377898234 = 11218470920442 := by decide
theorem cert_e2422377898234 : check e2422377898234 [[],[]] .three = true := by decide
def e2422377898414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422377898414 : Closed e2422377898414 ∧ code e2422377898414 = 11218470920622 := by decide
theorem cert_e2422377898414 : check e2422377898414 [[],[]] .three = true := by decide
def e2422377898422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422377898422 : Closed e2422377898422 ∧ code e2422377898422 = 11218470920630 := by decide
theorem cert_e2422377898422 : check e2422377898422 [[],[]] .three = true := by decide
def e2422377898426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422377898426 : Closed e2422377898426 ∧ code e2422377898426 = 11218470920634 := by decide
theorem cert_e2422377898426 : check e2422377898426 [[],[]] .three = true := by decide
def e2422377898454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422377898454 : Closed e2422377898454 ∧ code e2422377898454 = 11218470920662 := by decide
theorem cert_e2422377898454 : check e2422377898454 [[],[]] .three = true := by decide
def e2422377898474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422377898474 : Closed e2422377898474 ∧ code e2422377898474 = 11218470920682 := by decide
theorem cert_e2422377898474 : check e2422377898474 [[],[]] .three = true := by decide
def e2422377898606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377898606 : Closed e2422377898606 ∧ code e2422377898606 = 11218470920814 := by decide
theorem cert_e2422377898606 : check e2422377898606 [[],[]] .three = true := by decide
def e2422377898614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422377898614 : Closed e2422377898614 ∧ code e2422377898614 = 11218470920822 := by decide
theorem cert_e2422377898614 : check e2422377898614 [[],[]] .three = true := by decide
def e2422377898618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377898618 : Closed e2422377898618 ∧ code e2422377898618 = 11218470920826 := by decide
theorem cert_e2422377898618 : check e2422377898618 [[],[]] .three = true := by decide
def e2422377898782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422377898782 : Closed e2422377898782 ∧ code e2422377898782 = 11218470920990 := by decide
theorem cert_e2422377898782 : check e2422377898782 [[],[]] .three = true := by decide
def e2422377898806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377898806 : Closed e2422377898806 ∧ code e2422377898806 = 11218470921014 := by decide
theorem cert_e2422377898806 : check e2422377898806 [[],[]] .three = true := by decide
def e2422377898810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377898810 : Closed e2422377898810 ∧ code e2422377898810 = 11218470921018 := by decide
theorem cert_e2422377898810 : check e2422377898810 [[],[]] .three = true := by decide
def e2422377898894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2)))))))))
theorem wire_e2422377898894 : Closed e2422377898894 ∧ code e2422377898894 = 11218470921102 := by decide
theorem cert_e2422377898894 : check e2422377898894 [[],[]] .three = true := by decide
def e2422377898906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377898906 : Closed e2422377898906 ∧ code e2422377898906 = 11218470921114 := by decide
theorem cert_e2422377898906 : check e2422377898906 [[],[]] .three = true := by decide
def e2422377898950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422377898950 : Closed e2422377898950 ∧ code e2422377898950 = 11218470921158 := by decide
theorem cert_e2422377898950 : check e2422377898950 [[],[]] .three = true := by decide
def e2422377898974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e2422377898974 : Closed e2422377898974 ∧ code e2422377898974 = 11218470921182 := by decide
theorem cert_e2422377898974 : check e2422377898974 [[],[]] .three = true := by decide
def e2422377898990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e2422377898990 : Closed e2422377898990 ∧ code e2422377898990 = 11218470921198 := by decide
theorem cert_e2422377898990 : check e2422377898990 [[],[]] .three = true := by decide
def e2422377899566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422377899566 : Closed e2422377899566 ∧ code e2422377899566 = 11218470921774 := by decide
theorem cert_e2422377899566 : check e2422377899566 [[],[]] .three = true := by decide
def e2422377899574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422377899574 : Closed e2422377899574 ∧ code e2422377899574 = 11218470921782 := by decide
theorem cert_e2422377899574 : check e2422377899574 [[],[]] .three = true := by decide
def e2422377899578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422377899578 : Closed e2422377899578 ∧ code e2422377899578 = 11218470921786 := by decide
theorem cert_e2422377899578 : check e2422377899578 [[],[]] .three = true := by decide
def e2422377899662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422377899662 : Closed e2422377899662 ∧ code e2422377899662 = 11218470921870 := by decide
theorem cert_e2422377899662 : check e2422377899662 [[],[]] .three = true := by decide
def e2422377899718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422377899718 : Closed e2422377899718 ∧ code e2422377899718 = 11218470921926 := by decide
theorem cert_e2422377899718 : check e2422377899718 [[],[]] .three = true := by decide
def e2422377899742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2422377899742 : Closed e2422377899742 ∧ code e2422377899742 = 11218470921950 := by decide
theorem cert_e2422377899742 : check e2422377899742 [[],[]] .three = true := by decide
def e2422377899746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422377899746 : Closed e2422377899746 ∧ code e2422377899746 = 11218470921954 := by decide
theorem cert_e2422377899746 : check e2422377899746 [[],[]] .three = true := by decide
def e2422377899758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2422377899758 : Closed e2422377899758 ∧ code e2422377899758 = 11218470921966 := by decide
theorem cert_e2422377899758 : check e2422377899758 [[],[]] .three = true := by decide
def e2422377899766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2422377899766 : Closed e2422377899766 ∧ code e2422377899766 = 11218470921974 := by decide
theorem cert_e2422377899766 : check e2422377899766 [[],[]] .three = true := by decide
def e2422377899798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422377899798 : Closed e2422377899798 ∧ code e2422377899798 = 11218470922006 := by decide
theorem cert_e2422377899798 : check e2422377899798 [[],[]] .three = true := by decide
def e2422377899802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422377899802 : Closed e2422377899802 ∧ code e2422377899802 = 11218470922010 := by decide
theorem cert_e2422377899802 : check e2422377899802 [[],[]] .three = true := by decide
def e2422377899846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422377899846 : Closed e2422377899846 ∧ code e2422377899846 = 11218470922054 := by decide
theorem cert_e2422377899846 : check e2422377899846 [[],[]] .three = true := by decide
def e2422377899870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2422377899870 : Closed e2422377899870 ∧ code e2422377899870 = 11218470922078 := by decide
theorem cert_e2422377899870 : check e2422377899870 [[],[]] .three = true := by decide
def e2422377899874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422377899874 : Closed e2422377899874 ∧ code e2422377899874 = 11218470922082 := by decide
theorem cert_e2422377899874 : check e2422377899874 [[],[]] .three = true := by decide
def e2422377899886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2422377899886 : Closed e2422377899886 ∧ code e2422377899886 = 11218470922094 := by decide
theorem cert_e2422377899886 : check e2422377899886 [[],[]] .three = true := by decide
def e2422377899894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2422377899894 : Closed e2422377899894 ∧ code e2422377899894 = 11218470922102 := by decide
theorem cert_e2422377899894 : check e2422377899894 [[],[]] .three = true := by decide
def e2422377899898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2422377899898 : Closed e2422377899898 ∧ code e2422377899898 = 11218470922106 := by decide
theorem cert_e2422377899898 : check e2422377899898 [[],[]] .three = true := by decide
def e2422377899914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377899914 : Closed e2422377899914 ∧ code e2422377899914 = 11218470922122 := by decide
theorem cert_e2422377899914 : check e2422377899914 [[],[]] .three = true := by decide
def e2422377899938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422377899938 : Closed e2422377899938 ∧ code e2422377899938 = 11218470922146 := by decide
theorem cert_e2422377899938 : check e2422377899938 [[],[]] .three = true := by decide
def e2422377899950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2422377899950 : Closed e2422377899950 ∧ code e2422377899950 = 11218470922158 := by decide
theorem cert_e2422377899950 : check e2422377899950 [[],[]] .three = true := by decide
def e2422377899958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2422377899958 : Closed e2422377899958 ∧ code e2422377899958 = 11218470922166 := by decide
theorem cert_e2422377899958 : check e2422377899958 [[],[]] .three = true := by decide
def e2422377899962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2422377899962 : Closed e2422377899962 ∧ code e2422377899962 = 11218470922170 := by decide
theorem cert_e2422377899962 : check e2422377899962 [[],[]] .three = true := by decide
def e2422377899990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2422377899990 : Closed e2422377899990 ∧ code e2422377899990 = 11218470922198 := by decide
theorem cert_e2422377899990 : check e2422377899990 [[],[]] .three = true := by decide
def e2422377899994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2422377899994 : Closed e2422377899994 ∧ code e2422377899994 = 11218470922202 := by decide
theorem cert_e2422377899994 : check e2422377899994 [[],[]] .three = true := by decide
def e2422377900094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422377900094 : Closed e2422377900094 ∧ code e2422377900094 = 11218470922302 := by decide
theorem cert_e2422377900094 : check e2422377900094 [[],[]] .three = true := by decide
def e2422377900142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377900142 : Closed e2422377900142 ∧ code e2422377900142 = 11218470922350 := by decide
theorem cert_e2422377900142 : check e2422377900142 [[],[]] .three = true := by decide
def e2422377900154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377900154 : Closed e2422377900154 ∧ code e2422377900154 = 11218470922362 := by decide
theorem cert_e2422377900154 : check e2422377900154 [[],[]] .three = true := by decide
def e2422377900430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422377900430 : Closed e2422377900430 ∧ code e2422377900430 = 11218470922638 := by decide
theorem cert_e2422377900430 : check e2422377900430 [[],[]] .three = true := by decide
def e2422377900486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422377900486 : Closed e2422377900486 ∧ code e2422377900486 = 11218470922694 := by decide
theorem cert_e2422377900486 : check e2422377900486 [[],[]] .three = true := by decide
def e2422377900510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422377900510 : Closed e2422377900510 ∧ code e2422377900510 = 11218470922718 := by decide
theorem cert_e2422377900510 : check e2422377900510 [[],[]] .three = true := by decide
def e2422377900514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422377900514 : Closed e2422377900514 ∧ code e2422377900514 = 11218470922722 := by decide
theorem cert_e2422377900514 : check e2422377900514 [[],[]] .three = true := by decide
def e2422377900526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422377900526 : Closed e2422377900526 ∧ code e2422377900526 = 11218470922734 := by decide
theorem cert_e2422377900526 : check e2422377900526 [[],[]] .three = true := by decide
def e2422377900534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422377900534 : Closed e2422377900534 ∧ code e2422377900534 = 11218470922742 := by decide
theorem cert_e2422377900534 : check e2422377900534 [[],[]] .three = true := by decide
def e2422377901086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422377901086 : Closed e2422377901086 ∧ code e2422377901086 = 11218470923294 := by decide
theorem cert_e2422377901086 : check e2422377901086 [[],[]] .three = true := by decide
def e2422377901110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377901110 : Closed e2422377901110 ∧ code e2422377901110 = 11218470923318 := by decide
theorem cert_e2422377901110 : check e2422377901110 [[],[]] .three = true := by decide
def e2422377901114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377901114 : Closed e2422377901114 ∧ code e2422377901114 = 11218470923322 := by decide
theorem cert_e2422377901114 : check e2422377901114 [[],[]] .three = true := by decide
def e2422377901254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422377901254 : Closed e2422377901254 ∧ code e2422377901254 = 11218470923462 := by decide
theorem cert_e2422377901254 : check e2422377901254 [[],[]] .three = true := by decide
def e2422377901278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422377901278 : Closed e2422377901278 ∧ code e2422377901278 = 11218470923486 := by decide
theorem cert_e2422377901278 : check e2422377901278 [[],[]] .three = true := by decide
def e2422377901282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422377901282 : Closed e2422377901282 ∧ code e2422377901282 = 11218470923490 := by decide
theorem cert_e2422377901282 : check e2422377901282 [[],[]] .three = true := by decide
def e2422377901294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422377901294 : Closed e2422377901294 ∧ code e2422377901294 = 11218470923502 := by decide
theorem cert_e2422377901294 : check e2422377901294 [[],[]] .three = true := by decide
def e2422377901302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422377901302 : Closed e2422377901302 ∧ code e2422377901302 = 11218470923510 := by decide
theorem cert_e2422377901302 : check e2422377901302 [[],[]] .three = true := by decide
def e2422377901306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422377901306 : Closed e2422377901306 ∧ code e2422377901306 = 11218470923514 := by decide
theorem cert_e2422377901306 : check e2422377901306 [[],[]] .three = true := by decide
def e2422377901582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422377901582 : Closed e2422377901582 ∧ code e2422377901582 = 11218470923790 := by decide
theorem cert_e2422377901582 : check e2422377901582 [[],[]] .three = true := by decide
def e2422377901594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377901594 : Closed e2422377901594 ∧ code e2422377901594 = 11218470923802 := by decide
theorem cert_e2422377901594 : check e2422377901594 [[],[]] .three = true := by decide
def e2422377901630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e2422377901630 : Closed e2422377901630 ∧ code e2422377901630 = 11218470923838 := by decide
theorem cert_e2422377901630 : check e2422377901630 [[],[]] .three = true := by decide
def e2422377901666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422377901666 : Closed e2422377901666 ∧ code e2422377901666 = 11218470923874 := by decide
theorem cert_e2422377901666 : check e2422377901666 [[],[]] .three = true := by decide
def e2422377901678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377901678 : Closed e2422377901678 ∧ code e2422377901678 = 11218470923886 := by decide
theorem cert_e2422377901678 : check e2422377901678 [[],[]] .three = true := by decide
def e2422377901686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422377901686 : Closed e2422377901686 ∧ code e2422377901686 = 11218470923894 := by decide
theorem cert_e2422377901686 : check e2422377901686 [[],[]] .three = true := by decide
def e2422377901690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377901690 : Closed e2422377901690 ∧ code e2422377901690 = 11218470923898 := by decide
theorem cert_e2422377901690 : check e2422377901690 [[],[]] .three = true := by decide
def e2422377901854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e2422377901854 : Closed e2422377901854 ∧ code e2422377901854 = 11218470924062 := by decide
theorem cert_e2422377901854 : check e2422377901854 [[],[]] .three = true := by decide
def e2422377901878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377901878 : Closed e2422377901878 ∧ code e2422377901878 = 11218470924086 := by decide
theorem cert_e2422377901878 : check e2422377901878 [[],[]] .three = true := by decide
def e2422377901882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377901882 : Closed e2422377901882 ∧ code e2422377901882 = 11218470924090 := by decide
theorem cert_e2422377901882 : check e2422377901882 [[],[]] .three = true := by decide
def e2422377902198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422377902198 : Closed e2422377902198 ∧ code e2422377902198 = 11218470924406 := by decide
theorem cert_e2422377902198 : check e2422377902198 [[],[]] .three = true := by decide
def e2422377902202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422377902202 : Closed e2422377902202 ∧ code e2422377902202 = 11218470924410 := by decide
theorem cert_e2422377902202 : check e2422377902202 [[],[]] .three = true := by decide
def e2422377902298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422377902298 : Closed e2422377902298 ∧ code e2422377902298 = 11218470924506 := by decide
theorem cert_e2422377902298 : check e2422377902298 [[],[]] .three = true := by decide
def e2422377902314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422377902314 : Closed e2422377902314 ∧ code e2422377902314 = 11218470924522 := by decide
theorem cert_e2422377902314 : check e2422377902314 [[],[]] .three = true := by decide
def e2422377902390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377902390 : Closed e2422377902390 ∧ code e2422377902390 = 11218470924598 := by decide
theorem cert_e2422377902390 : check e2422377902390 [[],[]] .three = true := by decide
def e2422377902394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377902394 : Closed e2422377902394 ∧ code e2422377902394 = 11218470924602 := by decide
theorem cert_e2422377902394 : check e2422377902394 [[],[]] .three = true := by decide
def e2422377902478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422377902478 : Closed e2422377902478 ∧ code e2422377902478 = 11218470924686 := by decide
theorem cert_e2422377902478 : check e2422377902478 [[],[]] .three = true := by decide
def e2422377902490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377902490 : Closed e2422377902490 ∧ code e2422377902490 = 11218470924698 := by decide
theorem cert_e2422377902490 : check e2422377902490 [[],[]] .three = true := by decide
def e2422377902534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422377902534 : Closed e2422377902534 ∧ code e2422377902534 = 11218470924742 := by decide
theorem cert_e2422377902534 : check e2422377902534 [[],[]] .three = true := by decide
def e2422377902574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))))
theorem wire_e2422377902574 : Closed e2422377902574 ∧ code e2422377902574 = 11218470924782 := by decide
theorem cert_e2422377902574 : check e2422377902574 [[],[]] .three = true := by decide
def e2422377902870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422377902870 : Closed e2422377902870 ∧ code e2422377902870 = 11218470925078 := by decide
theorem cert_e2422377902870 : check e2422377902870 [[],[]] .three = true := by decide
def e2422377902874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422377902874 : Closed e2422377902874 ∧ code e2422377902874 = 11218470925082 := by decide
theorem cert_e2422377902874 : check e2422377902874 [[],[]] .three = true := by decide
def e2422377902918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422377902918 : Closed e2422377902918 ∧ code e2422377902918 = 11218470925126 := by decide
theorem cert_e2422377902918 : check e2422377902918 [[],[]] .three = true := by decide
def e2422377902942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2422377902942 : Closed e2422377902942 ∧ code e2422377902942 = 11218470925150 := by decide
theorem cert_e2422377902942 : check e2422377902942 [[],[]] .three = true := by decide
def e2422377902946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422377902946 : Closed e2422377902946 ∧ code e2422377902946 = 11218470925154 := by decide
theorem cert_e2422377902946 : check e2422377902946 [[],[]] .three = true := by decide
def e2422377902958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422377902958 : Closed e2422377902958 ∧ code e2422377902958 = 11218470925166 := by decide
theorem cert_e2422377902958 : check e2422377902958 [[],[]] .three = true := by decide
def e2422377902966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422377902966 : Closed e2422377902966 ∧ code e2422377902966 = 11218470925174 := by decide
theorem cert_e2422377902966 : check e2422377902966 [[],[]] .three = true := by decide
def e2422377902970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2422377902970 : Closed e2422377902970 ∧ code e2422377902970 = 11218470925178 := by decide
theorem cert_e2422377902970 : check e2422377902970 [[],[]] .three = true := by decide
def e2422377902986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377902986 : Closed e2422377902986 ∧ code e2422377902986 = 11218470925194 := by decide
theorem cert_e2422377902986 : check e2422377902986 [[],[]] .three = true := by decide
def e2422377903010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422377903010 : Closed e2422377903010 ∧ code e2422377903010 = 11218470925218 := by decide
theorem cert_e2422377903010 : check e2422377903010 [[],[]] .three = true := by decide
def e2422377903022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422377903022 : Closed e2422377903022 ∧ code e2422377903022 = 11218470925230 := by decide
theorem cert_e2422377903022 : check e2422377903022 [[],[]] .three = true := by decide
def e2422377903034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422377903034 : Closed e2422377903034 ∧ code e2422377903034 = 11218470925242 := by decide
theorem cert_e2422377903034 : check e2422377903034 [[],[]] .three = true := by decide
def e2422377903062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422377903062 : Closed e2422377903062 ∧ code e2422377903062 = 11218470925270 := by decide
theorem cert_e2422377903062 : check e2422377903062 [[],[]] .three = true := by decide
def e2422377903066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422377903066 : Closed e2422377903066 ∧ code e2422377903066 = 11218470925274 := by decide
theorem cert_e2422377903066 : check e2422377903066 [[],[]] .three = true := by decide
def e2422377903082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2422377903082 : Closed e2422377903082 ∧ code e2422377903082 = 11218470925290 := by decide
theorem cert_e2422377903082 : check e2422377903082 [[],[]] .three = true := by decide
def e2422377903134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422377903134 : Closed e2422377903134 ∧ code e2422377903134 = 11218470925342 := by decide
theorem cert_e2422377903134 : check e2422377903134 [[],[]] .three = true := by decide
def e2422377903158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377903158 : Closed e2422377903158 ∧ code e2422377903158 = 11218470925366 := by decide
theorem cert_e2422377903158 : check e2422377903158 [[],[]] .three = true := by decide
def e2422377903162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377903162 : Closed e2422377903162 ∧ code e2422377903162 = 11218470925370 := by decide
theorem cert_e2422377903162 : check e2422377903162 [[],[]] .three = true := by decide
def e2422377903302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422377903302 : Closed e2422377903302 ∧ code e2422377903302 = 11218470925510 := by decide
theorem cert_e2422377903302 : check e2422377903302 [[],[]] .three = true := by decide
def e2422377903326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422377903326 : Closed e2422377903326 ∧ code e2422377903326 = 11218470925534 := by decide
theorem cert_e2422377903326 : check e2422377903326 [[],[]] .three = true := by decide
def e2422377903330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422377903330 : Closed e2422377903330 ∧ code e2422377903330 = 11218470925538 := by decide
theorem cert_e2422377903330 : check e2422377903330 [[],[]] .three = true := by decide
def e2422377903342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422377903342 : Closed e2422377903342 ∧ code e2422377903342 = 11218470925550 := by decide
theorem cert_e2422377903342 : check e2422377903342 [[],[]] .three = true := by decide
def e2422377903350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422377903350 : Closed e2422377903350 ∧ code e2422377903350 = 11218470925558 := by decide
theorem cert_e2422377903350 : check e2422377903350 [[],[]] .three = true := by decide
def e2422377903354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422377903354 : Closed e2422377903354 ∧ code e2422377903354 = 11218470925562 := by decide
theorem cert_e2422377903354 : check e2422377903354 [[],[]] .three = true := by decide
def e2422377903630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422377903630 : Closed e2422377903630 ∧ code e2422377903630 = 11218470925838 := by decide
theorem cert_e2422377903630 : check e2422377903630 [[],[]] .three = true := by decide
def e2422377903714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422377903714 : Closed e2422377903714 ∧ code e2422377903714 = 11218470925922 := by decide
theorem cert_e2422377903714 : check e2422377903714 [[],[]] .three = true := by decide
def e2422377903726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377903726 : Closed e2422377903726 ∧ code e2422377903726 = 11218470925934 := by decide
theorem cert_e2422377903726 : check e2422377903726 [[],[]] .three = true := by decide
def e2422377903738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377903738 : Closed e2422377903738 ∧ code e2422377903738 = 11218470925946 := by decide
theorem cert_e2422377903738 : check e2422377903738 [[],[]] .three = true := by decide
def e2422377903902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e2422377903902 : Closed e2422377903902 ∧ code e2422377903902 = 11218470926110 := by decide
theorem cert_e2422377903902 : check e2422377903902 [[],[]] .three = true := by decide
def e2422377903926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377903926 : Closed e2422377903926 ∧ code e2422377903926 = 11218470926134 := by decide
theorem cert_e2422377903926 : check e2422377903926 [[],[]] .three = true := by decide
def e2422377903930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377903930 : Closed e2422377903930 ∧ code e2422377903930 = 11218470926138 := by decide
theorem cert_e2422377903930 : check e2422377903930 [[],[]] .three = true := by decide
def e2422377904026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377904026 : Closed e2422377904026 ∧ code e2422377904026 = 11218470926234 := by decide
theorem cert_e2422377904026 : check e2422377904026 [[],[]] .three = true := by decide
def e2422377904186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422377904186 : Closed e2422377904186 ∧ code e2422377904186 = 11218470926394 := by decide
theorem cert_e2422377904186 : check e2422377904186 [[],[]] .three = true := by decide
def e2422377904234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422377904234 : Closed e2422377904234 ∧ code e2422377904234 = 11218470926442 := by decide
theorem cert_e2422377904234 : check e2422377904234 [[],[]] .three = true := by decide
def e2422377904282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377904282 : Closed e2422377904282 ∧ code e2422377904282 = 11218470926490 := by decide
theorem cert_e2422377904282 : check e2422377904282 [[],[]] .three = true := by decide
def e2422377904326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422377904326 : Closed e2422377904326 ∧ code e2422377904326 = 11218470926534 := by decide
theorem cert_e2422377904326 : check e2422377904326 [[],[]] .three = true := by decide
def e2422377904350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422377904350 : Closed e2422377904350 ∧ code e2422377904350 = 11218470926558 := by decide
theorem cert_e2422377904350 : check e2422377904350 [[],[]] .three = true := by decide
def e2422377904366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422377904366 : Closed e2422377904366 ∧ code e2422377904366 = 11218470926574 := by decide
theorem cert_e2422377904366 : check e2422377904366 [[],[]] .three = true := by decide
def e2422377904374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422377904374 : Closed e2422377904374 ∧ code e2422377904374 = 11218470926582 := by decide
theorem cert_e2422377904374 : check e2422377904374 [[],[]] .three = true := by decide
def e2422377904378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422377904378 : Closed e2422377904378 ∧ code e2422377904378 = 11218470926586 := by decide
theorem cert_e2422377904378 : check e2422377904378 [[],[]] .three = true := by decide
def e2422377904522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377904522 : Closed e2422377904522 ∧ code e2422377904522 = 11218470926730 := by decide
theorem cert_e2422377904522 : check e2422377904522 [[],[]] .three = true := by decide
def e2422377904546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422377904546 : Closed e2422377904546 ∧ code e2422377904546 = 11218470926754 := by decide
theorem cert_e2422377904546 : check e2422377904546 [[],[]] .three = true := by decide
def e2422377904558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422377904558 : Closed e2422377904558 ∧ code e2422377904558 = 11218470926766 := by decide
theorem cert_e2422377904558 : check e2422377904558 [[],[]] .three = true := by decide
def e2422377904566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2422377904566 : Closed e2422377904566 ∧ code e2422377904566 = 11218470926774 := by decide
theorem cert_e2422377904566 : check e2422377904566 [[],[]] .three = true := by decide
def e2422377904570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422377904570 : Closed e2422377904570 ∧ code e2422377904570 = 11218470926778 := by decide
theorem cert_e2422377904570 : check e2422377904570 [[],[]] .three = true := by decide
def e2422377904598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2422377904598 : Closed e2422377904598 ∧ code e2422377904598 = 11218470926806 := by decide
theorem cert_e2422377904598 : check e2422377904598 [[],[]] .three = true := by decide
def e2422377904602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2422377904602 : Closed e2422377904602 ∧ code e2422377904602 = 11218470926810 := by decide
theorem cert_e2422377904602 : check e2422377904602 [[],[]] .three = true := by decide
def e2422377904618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422377904618 : Closed e2422377904618 ∧ code e2422377904618 = 11218470926826 := by decide
theorem cert_e2422377904618 : check e2422377904618 [[],[]] .three = true := by decide
def e2422377904654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422377904654 : Closed e2422377904654 ∧ code e2422377904654 = 11218470926862 := by decide
theorem cert_e2422377904654 : check e2422377904654 [[],[]] .three = true := by decide
def e2422377904666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377904666 : Closed e2422377904666 ∧ code e2422377904666 = 11218470926874 := by decide
theorem cert_e2422377904666 : check e2422377904666 [[],[]] .three = true := by decide
def e2422377904702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422377904702 : Closed e2422377904702 ∧ code e2422377904702 = 11218470926910 := by decide
theorem cert_e2422377904702 : check e2422377904702 [[],[]] .three = true := by decide
def e2422377904738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422377904738 : Closed e2422377904738 ∧ code e2422377904738 = 11218470926946 := by decide
theorem cert_e2422377904738 : check e2422377904738 [[],[]] .three = true := by decide
def e2422377904750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377904750 : Closed e2422377904750 ∧ code e2422377904750 = 11218470926958 := by decide
theorem cert_e2422377904750 : check e2422377904750 [[],[]] .three = true := by decide
def e2422377904758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422377904758 : Closed e2422377904758 ∧ code e2422377904758 = 11218470926966 := by decide
theorem cert_e2422377904758 : check e2422377904758 [[],[]] .three = true := by decide
def e2422377904762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377904762 : Closed e2422377904762 ∧ code e2422377904762 = 11218470926970 := by decide
theorem cert_e2422377904762 : check e2422377904762 [[],[]] .three = true := by decide
def e2422377904926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422377904926 : Closed e2422377904926 ∧ code e2422377904926 = 11218470927134 := by decide
theorem cert_e2422377904926 : check e2422377904926 [[],[]] .three = true := by decide
def e2422377904950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377904950 : Closed e2422377904950 ∧ code e2422377904950 = 11218470927158 := by decide
theorem cert_e2422377904950 : check e2422377904950 [[],[]] .three = true := by decide
def e2422377904954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377904954 : Closed e2422377904954 ∧ code e2422377904954 = 11218470927162 := by decide
theorem cert_e2422377904954 : check e2422377904954 [[],[]] .three = true := by decide
def e2422377905038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422377905038 : Closed e2422377905038 ∧ code e2422377905038 = 11218470927246 := by decide
theorem cert_e2422377905038 : check e2422377905038 [[],[]] .three = true := by decide
def e2422377905050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377905050 : Closed e2422377905050 ∧ code e2422377905050 = 11218470927258 := by decide
theorem cert_e2422377905050 : check e2422377905050 [[],[]] .three = true := by decide
def e2422377905094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422377905094 : Closed e2422377905094 ∧ code e2422377905094 = 11218470927302 := by decide
theorem cert_e2422377905094 : check e2422377905094 [[],[]] .three = true := by decide
def e2422377905262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422377905262 : Closed e2422377905262 ∧ code e2422377905262 = 11218470927470 := by decide
theorem cert_e2422377905262 : check e2422377905262 [[],[]] .three = true := by decide
def e2422377905274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422377905274 : Closed e2422377905274 ∧ code e2422377905274 = 11218470927482 := by decide
theorem cert_e2422377905274 : check e2422377905274 [[],[]] .three = true := by decide
def e2422377905366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422377905366 : Closed e2422377905366 ∧ code e2422377905366 = 11218470927574 := by decide
theorem cert_e2422377905366 : check e2422377905366 [[],[]] .three = true := by decide
def e2422377905370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422377905370 : Closed e2422377905370 ∧ code e2422377905370 = 11218470927578 := by decide
theorem cert_e2422377905370 : check e2422377905370 [[],[]] .three = true := by decide
def e2422377905386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422377905386 : Closed e2422377905386 ∧ code e2422377905386 = 11218470927594 := by decide
theorem cert_e2422377905386 : check e2422377905386 [[],[]] .three = true := by decide
def e2422377905438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422377905438 : Closed e2422377905438 ∧ code e2422377905438 = 11218470927646 := by decide
theorem cert_e2422377905438 : check e2422377905438 [[],[]] .three = true := by decide
def e2422377905462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377905462 : Closed e2422377905462 ∧ code e2422377905462 = 11218470927670 := by decide
theorem cert_e2422377905462 : check e2422377905462 [[],[]] .three = true := by decide
def e2422377905466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377905466 : Closed e2422377905466 ∧ code e2422377905466 = 11218470927674 := by decide
theorem cert_e2422377905466 : check e2422377905466 [[],[]] .three = true := by decide
def e2422377905562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377905562 : Closed e2422377905562 ∧ code e2422377905562 = 11218470927770 := by decide
theorem cert_e2422377905562 : check e2422377905562 [[],[]] .three = true := by decide
def e2422377905606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422377905606 : Closed e2422377905606 ∧ code e2422377905606 = 11218470927814 := by decide
theorem cert_e2422377905606 : check e2422377905606 [[],[]] .three = true := by decide
def e2422377907630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422377907630 : Closed e2422377907630 ∧ code e2422377907630 = 11218470929838 := by decide
theorem cert_e2422377907630 : check e2422377907630 [[],[]] .three = true := by decide
def e2422377907642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422377907642 : Closed e2422377907642 ∧ code e2422377907642 = 11218470929850 := by decide
theorem cert_e2422377907642 : check e2422377907642 [[],[]] .three = true := by decide
def e2422377907690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422377907690 : Closed e2422377907690 ∧ code e2422377907690 = 11218470929898 := by decide
theorem cert_e2422377907690 : check e2422377907690 [[],[]] .three = true := by decide
def e2422377907822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422377907822 : Closed e2422377907822 ∧ code e2422377907822 = 11218470930030 := by decide
theorem cert_e2422377907822 : check e2422377907822 [[],[]] .three = true := by decide
end Blc.Floor43
