import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422398887710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422398887710 : Closed e2422398887710 ∧ code e2422398887710 = 11218491909918 := by decide
theorem cert_e2422398887710 : check e2422398887710 [[.left,.left],[.left,.left],[.left],[],[],[]] .identityHead = true := by decide
def e2422398887822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422398887822 : Closed e2422398887822 ∧ code e2422398887822 = 11218491910030 := by decide
theorem cert_e2422398887822 : check e2422398887822 [[.left,.left],[.left,.left],[.left],[],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422399092334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422399092334 : Closed e2422399092334 ∧ code e2422399092334 = 11218492114542 := by decide
theorem cert_e2422399092334 : check e2422399092334 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422399092346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422399092346 : Closed e2422399092346 ∧ code e2422399092346 = 11218492114554 := by decide
theorem cert_e2422399092346 : check e2422399092346 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422399095582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422399095582 : Closed e2422399095582 ∧ code e2422399095582 = 11218492117790 := by decide
theorem cert_e2422399095582 : check e2422399095582 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422399095750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422399095750 : Closed e2422399095750 ∧ code e2422399095750 = 11218492117958 := by decide
theorem cert_e2422399095750 : check e2422399095750 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422399199630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 3) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422399199630 : Closed e2422399199630 ∧ code e2422399199630 = 11218492221838 := by decide
theorem cert_e2422399199630 : check e2422399199630 [[],[]] .chain = true := by decide
def e2422399199686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 3) (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422399199686 : Closed e2422399199686 ∧ code e2422399199686 = 11218492221894 := by decide
theorem cert_e2422399199686 : check e2422399199686 [[],[]] .chain = true := by decide
def e2422403740526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422403740526 : Closed e2422403740526 ∧ code e2422403740526 = 11218496762734 := by decide
theorem cert_e2422403740526 : check e2422403740526 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422403740534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422403740534 : Closed e2422403740534 ∧ code e2422403740534 = 11218496762742 := by decide
theorem cert_e2422403740534 : check e2422403740534 [[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under]] .identityHead = true := by decide
def e2422403740590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422403740590 : Closed e2422403740590 ∧ code e2422403740590 = 11218496762798 := by decide
theorem cert_e2422403740590 : check e2422403740590 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422403740602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422403740602 : Closed e2422403740602 ∧ code e2422403740602 = 11218496762810 := by decide
theorem cert_e2422403740602 : checkPay e2422403740602 [[.left,.left],[.left,.left],[.left],[],[.left],[]] 0 [[.under,.under,.under,.left],[.under,.under,.under]] = true := by decide
def e2422403740630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422403740630 : Closed e2422403740630 ∧ code e2422403740630 = 11218496762838 := by decide
theorem cert_e2422403740630 : check e2422403740630 [[],[],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422403740634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422403740634 : Closed e2422403740634 ∧ code e2422403740634 = 11218496762842 := by decide
theorem cert_e2422403740634 : check e2422403740634 [[],[],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422404240238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422404240238 : Closed e2422404240238 ∧ code e2422404240238 = 11218497262446 := by decide
theorem cert_e2422404240238 : check e2422404240238 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404240246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422404240246 : Closed e2422404240246 ∧ code e2422404240246 = 11218497262454 := by decide
theorem cert_e2422404240246 : check e2422404240246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422404240302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422404240302 : Closed e2422404240302 ∧ code e2422404240302 = 11218497262510 := by decide
theorem cert_e2422404240302 : check e2422404240302 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404240314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422404240314 : Closed e2422404240314 ∧ code e2422404240314 = 11218497262522 := by decide
theorem cert_e2422404240314 : check e2422404240314 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404240342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422404240342 : Closed e2422404240342 ∧ code e2422404240342 = 11218497262550 := by decide
def e2422404240346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422404240346 : Closed e2422404240346 ∧ code e2422404240346 = 11218497262554 := by decide
theorem cert_e2422404240346 : check e2422404240346 [[],[],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2422404338542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422404338542 : Closed e2422404338542 ∧ code e2422404338542 = 11218497360750 := by decide
theorem cert_e2422404338542 : check e2422404338542 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404338550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422404338550 : Closed e2422404338550 ∧ code e2422404338550 = 11218497360758 := by decide
def e2422404338606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422404338606 : Closed e2422404338606 ∧ code e2422404338606 = 11218497360814 := by decide
theorem cert_e2422404338606 : check e2422404338606 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404338618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422404338618 : Closed e2422404338618 ∧ code e2422404338618 = 11218497360826 := by decide
theorem cert_e2422404338618 : check e2422404338618 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404338646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422404338646 : Closed e2422404338646 ∧ code e2422404338646 = 11218497360854 := by decide
theorem cert_e2422404338646 : check e2422404338646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422404338650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422404338650 : Closed e2422404338650 ∧ code e2422404338650 = 11218497360858 := by decide
theorem cert_e2422404338650 : check e2422404338650 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404353774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2422404353774 : Closed e2422404353774 ∧ code e2422404353774 = 11218497375982 := by decide
theorem cert_e2422404353774 : check e2422404353774 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404353782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2422404353782 : Closed e2422404353782 ∧ code e2422404353782 = 11218497375990 := by decide
theorem cert_e2422404353782 : check e2422404353782 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2422404353902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2422404353902 : Closed e2422404353902 ∧ code e2422404353902 = 11218497376110 := by decide
theorem cert_e2422404353902 : check e2422404353902 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404353914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2422404353914 : Closed e2422404353914 ∧ code e2422404353914 = 11218497376122 := by decide
theorem cert_e2422404353914 : check e2422404353914 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2422404353974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2422404353974 : Closed e2422404353974 ∧ code e2422404353974 = 11218497376182 := by decide
theorem cert_e2422404353974 : check e2422404353974 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2422404353978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2422404353978 : Closed e2422404353978 ∧ code e2422404353978 = 11218497376186 := by decide
theorem cert_e2422404353978 : check e2422404353978 [[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2422404361582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422404361582 : Closed e2422404361582 ∧ code e2422404361582 = 11218497383790 := by decide
theorem cert_e2422404361582 : check e2422404361582 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404361590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422404361590 : Closed e2422404361590 ∧ code e2422404361590 = 11218497383798 := by decide
theorem cert_e2422404361590 : check e2422404361590 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422404361646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422404361646 : Closed e2422404361646 ∧ code e2422404361646 = 11218497383854 := by decide
theorem cert_e2422404361646 : check e2422404361646 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404361658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422404361658 : Closed e2422404361658 ∧ code e2422404361658 = 11218497383866 := by decide
theorem cert_e2422404361658 : check e2422404361658 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422404361686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422404361686 : Closed e2422404361686 ∧ code e2422404361686 = 11218497383894 := by decide
theorem cert_e2422404361686 : checkPay e2422404361686 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422404361690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422404361690 : Closed e2422404361690 ∧ code e2422404361690 = 11218497383898 := by decide
theorem cert_e2422404361690 : check e2422404361690 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422404361902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422404361902 : Closed e2422404361902 ∧ code e2422404361902 = 11218497384110 := by decide
theorem cert_e2422404361902 : check e2422404361902 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404361914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422404361914 : Closed e2422404361914 ∧ code e2422404361914 = 11218497384122 := by decide
theorem cert_e2422404361914 : check e2422404361914 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404361962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422404361962 : Closed e2422404361962 ∧ code e2422404361962 = 11218497384170 := by decide
theorem cert_e2422404361962 : check e2422404361962 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404362070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422404362070 : Closed e2422404362070 ∧ code e2422404362070 = 11218497384278 := by decide
def e2422404362074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422404362074 : Closed e2422404362074 ∧ code e2422404362074 = 11218497384282 := by decide
theorem cert_e2422404362074 : check e2422404362074 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422404362090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422404362090 : Closed e2422404362090 ∧ code e2422404362090 = 11218497384298 := by decide
theorem cert_e2422404362090 : check e2422404362090 [[],[],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2422404363118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422404363118 : Closed e2422404363118 ∧ code e2422404363118 = 11218497385326 := by decide
theorem cert_e2422404363118 : check e2422404363118 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404363126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422404363126 : Closed e2422404363126 ∧ code e2422404363126 = 11218497385334 := by decide
theorem cert_e2422404363126 : checkPay e2422404363126 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422404363182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422404363182 : Closed e2422404363182 ∧ code e2422404363182 = 11218497385390 := by decide
theorem cert_e2422404363182 : check e2422404363182 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404363194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422404363194 : Closed e2422404363194 ∧ code e2422404363194 = 11218497385402 := by decide
theorem cert_e2422404363194 : check e2422404363194 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422404363222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422404363222 : Closed e2422404363222 ∧ code e2422404363222 = 11218497385430 := by decide
def e2422404363226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422404363226 : Closed e2422404363226 ∧ code e2422404363226 = 11218497385434 := by decide
theorem cert_e2422404363226 : check e2422404363226 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422404364086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422404364086 : Closed e2422404364086 ∧ code e2422404364086 = 11218497386294 := by decide
theorem cert_e2422404364086 : check e2422404364086 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422404364090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422404364090 : Closed e2422404364090 ∧ code e2422404364090 = 11218497386298 := by decide
theorem cert_e2422404364090 : check e2422404364090 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2422404364718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422404364718 : Closed e2422404364718 ∧ code e2422404364718 = 11218497386926 := by decide
theorem cert_e2422404364718 : check e2422404364718 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2422404364730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422404364730 : Closed e2422404364730 ∧ code e2422404364730 = 11218497386938 := by decide
theorem cert_e2422404364730 : check e2422404364730 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404364778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422404364778 : Closed e2422404364778 ∧ code e2422404364778 = 11218497386986 := by decide
theorem cert_e2422404364778 : check e2422404364778 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404365210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422404365210 : Closed e2422404365210 ∧ code e2422404365210 = 11218497387418 := by decide
theorem cert_e2422404365210 : check e2422404365210 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404365526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422404365526 : Closed e2422404365526 ∧ code e2422404365526 = 11218497387734 := by decide
theorem cert_e2422404365526 : check e2422404365526 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e2422404365530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422404365530 : Closed e2422404365530 ∧ code e2422404365530 = 11218497387738 := by decide
theorem cert_e2422404365530 : check e2422404365530 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422404365546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422404365546 : Closed e2422404365546 ∧ code e2422404365546 = 11218497387754 := by decide
theorem cert_e2422404365546 : check e2422404365546 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2422404365622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422404365622 : Closed e2422404365622 ∧ code e2422404365622 = 11218497387830 := by decide
theorem cert_e2422404365622 : check e2422404365622 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e2422404365626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422404365626 : Closed e2422404365626 ∧ code e2422404365626 = 11218497387834 := by decide
theorem cert_e2422404365626 : check e2422404365626 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e2422404365722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422404365722 : Closed e2422404365722 ∧ code e2422404365722 = 11218497387930 := by decide
theorem cert_e2422404365722 : check e2422404365722 [[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2422405811670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422405811670 : Closed e2422405811670 ∧ code e2422405811670 = 11218498833878 := by decide
theorem cert_e2422405811670 : checkPay e2422405811670 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422405811674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422405811674 : Closed e2422405811674 ∧ code e2422405811674 = 11218498833882 := by decide
theorem cert_e2422405811674 : check e2422405811674 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422405811946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422405811946 : Closed e2422405811946 ∧ code e2422405811946 = 11218498834154 := by decide
theorem cert_e2422405811946 : check e2422405811946 [[],[],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2422405812054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422405812054 : Closed e2422405812054 ∧ code e2422405812054 = 11218498834262 := by decide
theorem cert_e2422405812054 : check e2422405812054 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422405812058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422405812058 : Closed e2422405812058 ∧ code e2422405812058 = 11218498834266 := by decide
theorem cert_e2422405812058 : check e2422405812058 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422405812074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422405812074 : Closed e2422405812074 ∧ code e2422405812074 = 11218498834282 := by decide
theorem cert_e2422405812074 : check e2422405812074 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e2422406321518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406321518 : Closed e2422406321518 ∧ code e2422406321518 = 11218499343726 := by decide
theorem cert_e2422406321518 : check e2422406321518 [[],[]] .chain = true := by decide
def e2422406321526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406321526 : Closed e2422406321526 ∧ code e2422406321526 = 11218499343734 := by decide
theorem cert_e2422406321526 : check e2422406321526 [[],[]] .chain = true := by decide
def e2422406321582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406321582 : Closed e2422406321582 ∧ code e2422406321582 = 11218499343790 := by decide
theorem cert_e2422406321582 : check e2422406321582 [[],[]] .chain = true := by decide
def e2422406321594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406321594 : Closed e2422406321594 ∧ code e2422406321594 = 11218499343802 := by decide
theorem cert_e2422406321594 : check e2422406321594 [[],[]] .chain = true := by decide
def e2422406321622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406321622 : Closed e2422406321622 ∧ code e2422406321622 = 11218499343830 := by decide
theorem cert_e2422406321622 : check e2422406321622 [[],[]] .chain = true := by decide
def e2422406321626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406321626 : Closed e2422406321626 ∧ code e2422406321626 = 11218499343834 := by decide
theorem cert_e2422406321626 : check e2422406321626 [[],[]] .chain = true := by decide
def e2422406321838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406321838 : Closed e2422406321838 ∧ code e2422406321838 = 11218499344046 := by decide
theorem cert_e2422406321838 : check e2422406321838 [[],[]] .chain = true := by decide
def e2422406321850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406321850 : Closed e2422406321850 ∧ code e2422406321850 = 11218499344058 := by decide
theorem cert_e2422406321850 : check e2422406321850 [[],[]] .chain = true := by decide
def e2422406321898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406321898 : Closed e2422406321898 ∧ code e2422406321898 = 11218499344106 := by decide
theorem cert_e2422406321898 : check e2422406321898 [[],[]] .chain = true := by decide
def e2422406322006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406322006 : Closed e2422406322006 ∧ code e2422406322006 = 11218499344214 := by decide
theorem cert_e2422406322006 : check e2422406322006 [[],[]] .chain = true := by decide
def e2422406322010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406322010 : Closed e2422406322010 ∧ code e2422406322010 = 11218499344218 := by decide
theorem cert_e2422406322010 : check e2422406322010 [[],[]] .chain = true := by decide
def e2422406322026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406322026 : Closed e2422406322026 ∧ code e2422406322026 = 11218499344234 := by decide
theorem cert_e2422406322026 : check e2422406322026 [[],[]] .chain = true := by decide
def e2422406333806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406333806 : Closed e2422406333806 ∧ code e2422406333806 = 11218499356014 := by decide
theorem cert_e2422406333806 : check e2422406333806 [[],[]] .chain = true := by decide
def e2422406333814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406333814 : Closed e2422406333814 ∧ code e2422406333814 = 11218499356022 := by decide
theorem cert_e2422406333814 : check e2422406333814 [[],[]] .chain = true := by decide
def e2422406333870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406333870 : Closed e2422406333870 ∧ code e2422406333870 = 11218499356078 := by decide
theorem cert_e2422406333870 : check e2422406333870 [[],[]] .chain = true := by decide
def e2422406333882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406333882 : Closed e2422406333882 ∧ code e2422406333882 = 11218499356090 := by decide
theorem cert_e2422406333882 : check e2422406333882 [[],[]] .chain = true := by decide
def e2422406333910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406333910 : Closed e2422406333910 ∧ code e2422406333910 = 11218499356118 := by decide
theorem cert_e2422406333910 : check e2422406333910 [[],[]] .chain = true := by decide
def e2422406333914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406333914 : Closed e2422406333914 ∧ code e2422406333914 = 11218499356122 := by decide
theorem cert_e2422406333914 : check e2422406333914 [[],[]] .chain = true := by decide
def e2422406336878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406336878 : Closed e2422406336878 ∧ code e2422406336878 = 11218499359086 := by decide
theorem cert_e2422406336878 : check e2422406336878 [[],[]] .chain = true := by decide
def e2422406336886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406336886 : Closed e2422406336886 ∧ code e2422406336886 = 11218499359094 := by decide
theorem cert_e2422406336886 : check e2422406336886 [[],[]] .chain = true := by decide
def e2422406338094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406338094 : Closed e2422406338094 ∧ code e2422406338094 = 11218499360302 := by decide
theorem cert_e2422406338094 : check e2422406338094 [[],[]] .chain = true := by decide
def e2422406338274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406338274 : Closed e2422406338274 ∧ code e2422406338274 = 11218499360482 := by decide
theorem cert_e2422406338274 : check e2422406338274 [[],[]] .chain = true := by decide
def e2422406338286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2422406338286 : Closed e2422406338286 ∧ code e2422406338286 = 11218499360494 := by decide
theorem cert_e2422406338286 : check e2422406338286 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406338326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406338326 : Closed e2422406338326 ∧ code e2422406338326 = 11218499360534 := by decide
theorem cert_e2422406338326 : check e2422406338326 [[],[]] .chain = true := by decide
def e2422406338402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406338402 : Closed e2422406338402 ∧ code e2422406338402 = 11218499360610 := by decide
theorem cert_e2422406338402 : check e2422406338402 [[],[]] .chain = true := by decide
def e2422406338414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2422406338414 : Closed e2422406338414 ∧ code e2422406338414 = 11218499360622 := by decide
theorem cert_e2422406338414 : check e2422406338414 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406338422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2422406338422 : Closed e2422406338422 ∧ code e2422406338422 = 11218499360630 := by decide
theorem cert_e2422406338422 : check e2422406338422 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406338734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406338734 : Closed e2422406338734 ∧ code e2422406338734 = 11218499360942 := by decide
theorem cert_e2422406338734 : check e2422406338734 [[],[]] .chain = true := by decide
def e2422406338746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406338746 : Closed e2422406338746 ∧ code e2422406338746 = 11218499360954 := by decide
theorem cert_e2422406338746 : check e2422406338746 [[],[]] .chain = true := by decide
def e2422406339118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406339118 : Closed e2422406339118 ∧ code e2422406339118 = 11218499361326 := by decide
theorem cert_e2422406339118 : check e2422406339118 [[],[]] .chain = true := by decide
def e2422406339298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406339298 : Closed e2422406339298 ∧ code e2422406339298 = 11218499361506 := by decide
theorem cert_e2422406339298 : check e2422406339298 [[],[]] .chain = true := by decide
def e2422406339310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406339310 : Closed e2422406339310 ∧ code e2422406339310 = 11218499361518 := by decide
theorem cert_e2422406339310 : check e2422406339310 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406339438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406339438 : Closed e2422406339438 ∧ code e2422406339438 = 11218499361646 := by decide
theorem cert_e2422406339438 : check e2422406339438 [[],[]] .chain = true := by decide
def e2422406339446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406339446 : Closed e2422406339446 ∧ code e2422406339446 = 11218499361654 := by decide
theorem cert_e2422406339446 : check e2422406339446 [[],[]] .chain = true := by decide
def e2422406339466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406339466 : Closed e2422406339466 ∧ code e2422406339466 = 11218499361674 := by decide
theorem cert_e2422406339466 : check e2422406339466 [[],[]] .chain = true := by decide
def e2422406339490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406339490 : Closed e2422406339490 ∧ code e2422406339490 = 11218499361698 := by decide
theorem cert_e2422406339490 : check e2422406339490 [[],[]] .chain = true := by decide
def e2422406339502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406339502 : Closed e2422406339502 ∧ code e2422406339502 = 11218499361710 := by decide
theorem cert_e2422406339502 : check e2422406339502 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406339510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406339510 : Closed e2422406339510 ∧ code e2422406339510 = 11218499361718 := by decide
theorem cert_e2422406339510 : check e2422406339510 [[],[]] .chain = true := by decide
def e2422406339514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406339514 : Closed e2422406339514 ∧ code e2422406339514 = 11218499361722 := by decide
def e2422406339670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406339670 : Closed e2422406339670 ∧ code e2422406339670 = 11218499361878 := by decide
theorem cert_e2422406339670 : check e2422406339670 [[],[]] .chain = true := by decide
def e2422406339674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406339674 : Closed e2422406339674 ∧ code e2422406339674 = 11218499361882 := by decide
theorem cert_e2422406339674 : check e2422406339674 [[],[]] .chain = true := by decide
def e2422406339862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406339862 : Closed e2422406339862 ∧ code e2422406339862 = 11218499362070 := by decide
theorem cert_e2422406339862 : check e2422406339862 [[],[]] .chain = true := by decide
def e2422406339938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406339938 : Closed e2422406339938 ∧ code e2422406339938 = 11218499362146 := by decide
theorem cert_e2422406339938 : check e2422406339938 [[],[]] .chain = true := by decide
def e2422406339950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406339950 : Closed e2422406339950 ∧ code e2422406339950 = 11218499362158 := by decide
theorem cert_e2422406339950 : check e2422406339950 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406339958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406339958 : Closed e2422406339958 ∧ code e2422406339958 = 11218499362166 := by decide
theorem cert_e2422406339958 : checkPay e2422406339958 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422406339978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406339978 : Closed e2422406339978 ∧ code e2422406339978 = 11218499362186 := by decide
theorem cert_e2422406339978 : check e2422406339978 [[],[]] .chain = true := by decide
def e2422406340002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406340002 : Closed e2422406340002 ∧ code e2422406340002 = 11218499362210 := by decide
theorem cert_e2422406340002 : check e2422406340002 [[],[]] .chain = true := by decide
def e2422406340014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406340014 : Closed e2422406340014 ∧ code e2422406340014 = 11218499362222 := by decide
theorem cert_e2422406340014 : check e2422406340014 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406340022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2422406340022 : Closed e2422406340022 ∧ code e2422406340022 = 11218499362230 := by decide
theorem cert_e2422406340022 : check e2422406340022 [[],[]] .chain = true := by decide
def e2422406340026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406340026 : Closed e2422406340026 ∧ code e2422406340026 = 11218499362234 := by decide
theorem cert_e2422406340026 : check e2422406340026 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406340054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406340054 : Closed e2422406340054 ∧ code e2422406340054 = 11218499362262 := by decide
theorem cert_e2422406340054 : checkPay e2422406340054 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406340058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406340058 : Closed e2422406340058 ∧ code e2422406340058 = 11218499362266 := by decide
theorem cert_e2422406340058 : check e2422406340058 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406341294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406341294 : Closed e2422406341294 ∧ code e2422406341294 = 11218499363502 := by decide
theorem cert_e2422406341294 : check e2422406341294 [[],[]] .chain = true := by decide
def e2422406341306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406341306 : Closed e2422406341306 ∧ code e2422406341306 = 11218499363514 := by decide
theorem cert_e2422406341306 : check e2422406341306 [[],[]] .chain = true := by decide
def e2422406341354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406341354 : Closed e2422406341354 ∧ code e2422406341354 = 11218499363562 := by decide
theorem cert_e2422406341354 : check e2422406341354 [[],[]] .chain = true := by decide
def e2422406342830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406342830 : Closed e2422406342830 ∧ code e2422406342830 = 11218499365038 := by decide
theorem cert_e2422406342830 : check e2422406342830 [[],[]] .chain = true := by decide
def e2422406342842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406342842 : Closed e2422406342842 ∧ code e2422406342842 = 11218499365050 := by decide
theorem cert_e2422406342842 : check e2422406342842 [[],[]] .chain = true := by decide
def e2422406343214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406343214 : Closed e2422406343214 ∧ code e2422406343214 = 11218499365422 := by decide
theorem cert_e2422406343214 : check e2422406343214 [[],[]] .chain = true := by decide
def e2422406343394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406343394 : Closed e2422406343394 ∧ code e2422406343394 = 11218499365602 := by decide
theorem cert_e2422406343394 : check e2422406343394 [[],[]] .chain = true := by decide
def e2422406343406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406343406 : Closed e2422406343406 ∧ code e2422406343406 = 11218499365614 := by decide
theorem cert_e2422406343406 : check e2422406343406 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406343534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406343534 : Closed e2422406343534 ∧ code e2422406343534 = 11218499365742 := by decide
theorem cert_e2422406343534 : check e2422406343534 [[],[]] .chain = true := by decide
def e2422406343542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406343542 : Closed e2422406343542 ∧ code e2422406343542 = 11218499365750 := by decide
theorem cert_e2422406343542 : check e2422406343542 [[],[]] .chain = true := by decide
def e2422406343562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406343562 : Closed e2422406343562 ∧ code e2422406343562 = 11218499365770 := by decide
theorem cert_e2422406343562 : check e2422406343562 [[],[]] .chain = true := by decide
def e2422406343586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406343586 : Closed e2422406343586 ∧ code e2422406343586 = 11218499365794 := by decide
theorem cert_e2422406343586 : check e2422406343586 [[],[]] .chain = true := by decide
def e2422406343598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406343598 : Closed e2422406343598 ∧ code e2422406343598 = 11218499365806 := by decide
theorem cert_e2422406343598 : check e2422406343598 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406343606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406343606 : Closed e2422406343606 ∧ code e2422406343606 = 11218499365814 := by decide
theorem cert_e2422406343606 : check e2422406343606 [[],[]] .chain = true := by decide
def e2422406343610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406343610 : Closed e2422406343610 ∧ code e2422406343610 = 11218499365818 := by decide
theorem cert_e2422406343610 : check e2422406343610 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406344046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406344046 : Closed e2422406344046 ∧ code e2422406344046 = 11218499366254 := by decide
theorem cert_e2422406344046 : check e2422406344046 [[],[]] .chain = true := by decide
def e2422406344054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406344054 : Closed e2422406344054 ∧ code e2422406344054 = 11218499366262 := by decide
theorem cert_e2422406344054 : check e2422406344054 [[],[]] .chain = true := by decide
def e2422406344110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406344110 : Closed e2422406344110 ∧ code e2422406344110 = 11218499366318 := by decide
theorem cert_e2422406344110 : check e2422406344110 [[],[]] .chain = true := by decide
def e2422406344122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406344122 : Closed e2422406344122 ∧ code e2422406344122 = 11218499366330 := by decide
theorem cert_e2422406344122 : check e2422406344122 [[],[]] .chain = true := by decide
def e2422406344150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406344150 : Closed e2422406344150 ∧ code e2422406344150 = 11218499366358 := by decide
theorem cert_e2422406344150 : check e2422406344150 [[],[]] .chain = true := by decide
def e2422406344154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406344154 : Closed e2422406344154 ∧ code e2422406344154 = 11218499366362 := by decide
theorem cert_e2422406344154 : check e2422406344154 [[],[]] .chain = true := by decide
def e2422406344234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406344234 : Closed e2422406344234 ∧ code e2422406344234 = 11218499366442 := by decide
theorem cert_e2422406344234 : check e2422406344234 [[],[]] .chain = true := by decide
def e2422406344330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406344330 : Closed e2422406344330 ∧ code e2422406344330 = 11218499366538 := by decide
theorem cert_e2422406344330 : check e2422406344330 [[],[]] .chain = true := by decide
def e2422406344354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406344354 : Closed e2422406344354 ∧ code e2422406344354 = 11218499366562 := by decide
theorem cert_e2422406344354 : check e2422406344354 [[],[]] .chain = true := by decide
def e2422406344366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406344366 : Closed e2422406344366 ∧ code e2422406344366 = 11218499366574 := by decide
theorem cert_e2422406344366 : check e2422406344366 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406344374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406344374 : Closed e2422406344374 ∧ code e2422406344374 = 11218499366582 := by decide
theorem cert_e2422406344374 : check e2422406344374 [[],[]] .chain = true := by decide
def e2422406344378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406344378 : Closed e2422406344378 ∧ code e2422406344378 = 11218499366586 := by decide
theorem cert_e2422406344378 : check e2422406344378 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406344406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406344406 : Closed e2422406344406 ∧ code e2422406344406 = 11218499366614 := by decide
theorem cert_e2422406344406 : check e2422406344406 [[],[]] .chain = true := by decide
def e2422406344410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406344410 : Closed e2422406344410 ∧ code e2422406344410 = 11218499366618 := by decide
theorem cert_e2422406344410 : check e2422406344410 [[],[]] .chain = true := by decide
def e2422406344426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406344426 : Closed e2422406344426 ∧ code e2422406344426 = 11218499366634 := by decide
theorem cert_e2422406344426 : check e2422406344426 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406345046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406345046 : Closed e2422406345046 ∧ code e2422406345046 = 11218499367254 := by decide
theorem cert_e2422406345046 : check e2422406345046 [[],[]] .chain = true := by decide
def e2422406345050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406345050 : Closed e2422406345050 ∧ code e2422406345050 = 11218499367258 := by decide
theorem cert_e2422406345050 : check e2422406345050 [[],[]] .chain = true := by decide
def e2422406345066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406345066 : Closed e2422406345066 ∧ code e2422406345066 = 11218499367274 := by decide
theorem cert_e2422406345066 : check e2422406345066 [[],[]] .chain = true := by decide
def e2422406345814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406345814 : Closed e2422406345814 ∧ code e2422406345814 = 11218499368022 := by decide
theorem cert_e2422406345814 : check e2422406345814 [[],[]] .chain = true := by decide
def e2422406345818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406345818 : Closed e2422406345818 ∧ code e2422406345818 = 11218499368026 := by decide
theorem cert_e2422406345818 : check e2422406345818 [[],[]] .chain = true := by decide
def e2422406346006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406346006 : Closed e2422406346006 ∧ code e2422406346006 = 11218499368214 := by decide
theorem cert_e2422406346006 : check e2422406346006 [[],[]] .chain = true := by decide
def e2422406346082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406346082 : Closed e2422406346082 ∧ code e2422406346082 = 11218499368290 := by decide
theorem cert_e2422406346082 : check e2422406346082 [[],[]] .chain = true := by decide
def e2422406346094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406346094 : Closed e2422406346094 ∧ code e2422406346094 = 11218499368302 := by decide
theorem cert_e2422406346094 : check e2422406346094 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406346102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406346102 : Closed e2422406346102 ∧ code e2422406346102 = 11218499368310 := by decide
theorem cert_e2422406346102 : check e2422406346102 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406346122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406346122 : Closed e2422406346122 ∧ code e2422406346122 = 11218499368330 := by decide
theorem cert_e2422406346122 : check e2422406346122 [[],[]] .chain = true := by decide
end Blc.Floor43
