import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422377477754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377477754 : Closed e2422377477754 ∧ code e2422377477754 = 11218470499962 := by decide
theorem cert_e2422377477754 : check e2422377477754 [[],[]] .smaller = true := by decide
def e2422377477942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377477942 : Closed e2422377477942 ∧ code e2422377477942 = 11218470500150 := by decide
theorem cert_e2422377477942 : check e2422377477942 [[],[]] .smaller = true := by decide
def e2422377477946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377477946 : Closed e2422377477946 ∧ code e2422377477946 = 11218470500154 := by decide
theorem cert_e2422377477946 : check e2422377477946 [[],[]] .smaller = true := by decide
def e2422377478030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2422377478030 : Closed e2422377478030 ∧ code e2422377478030 = 11218470500238 := by decide
theorem cert_e2422377478030 : check e2422377478030 [[],[]] .three = true := by decide
def e2422377478042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377478042 : Closed e2422377478042 ∧ code e2422377478042 = 11218470500250 := by decide
theorem cert_e2422377478042 : check e2422377478042 [[],[]] .three = true := by decide
def e2422377478202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422377478202 : Closed e2422377478202 ∧ code e2422377478202 = 11218470500410 := by decide
theorem cert_e2422377478202 : check e2422377478202 [[],[]] .three = true := by decide
def e2422377478250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422377478250 : Closed e2422377478250 ∧ code e2422377478250 = 11218470500458 := by decide
theorem cert_e2422377478250 : check e2422377478250 [[],[]] .three = true := by decide
def e2422377478298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377478298 : Closed e2422377478298 ∧ code e2422377478298 = 11218470500506 := by decide
theorem cert_e2422377478298 : check e2422377478298 [[],[]] .three = true := by decide
def e2422377478342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422377478342 : Closed e2422377478342 ∧ code e2422377478342 = 11218470500550 := by decide
theorem cert_e2422377478342 : check e2422377478342 [[],[]] .three = true := by decide
def e2422377478366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422377478366 : Closed e2422377478366 ∧ code e2422377478366 = 11218470500574 := by decide
theorem cert_e2422377478366 : check e2422377478366 [[],[]] .three = true := by decide
def e2422377478382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422377478382 : Closed e2422377478382 ∧ code e2422377478382 = 11218470500590 := by decide
theorem cert_e2422377478382 : check e2422377478382 [[],[]] .three = true := by decide
def e2422377478390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422377478390 : Closed e2422377478390 ∧ code e2422377478390 = 11218470500598 := by decide
theorem cert_e2422377478390 : check e2422377478390 [[],[]] .three = true := by decide
def e2422377478394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422377478394 : Closed e2422377478394 ∧ code e2422377478394 = 11218470500602 := by decide
theorem cert_e2422377478394 : check e2422377478394 [[],[]] .three = true := by decide
def e2422377478538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377478538 : Closed e2422377478538 ∧ code e2422377478538 = 11218470500746 := by decide
theorem cert_e2422377478538 : check e2422377478538 [[],[]] .three = true := by decide
def e2422377478562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422377478562 : Closed e2422377478562 ∧ code e2422377478562 = 11218470500770 := by decide
theorem cert_e2422377478562 : check e2422377478562 [[],[]] .three = true := by decide
def e2422377478574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422377478574 : Closed e2422377478574 ∧ code e2422377478574 = 11218470500782 := by decide
theorem cert_e2422377478574 : check e2422377478574 [[],[]] .three = true := by decide
def e2422377478582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2422377478582 : Closed e2422377478582 ∧ code e2422377478582 = 11218470500790 := by decide
theorem cert_e2422377478582 : check e2422377478582 [[],[]] .three = true := by decide
def e2422377478586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422377478586 : Closed e2422377478586 ∧ code e2422377478586 = 11218470500794 := by decide
theorem cert_e2422377478586 : check e2422377478586 [[],[]] .three = true := by decide
def e2422377478614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2422377478614 : Closed e2422377478614 ∧ code e2422377478614 = 11218470500822 := by decide
theorem cert_e2422377478614 : check e2422377478614 [[],[]] .three = true := by decide
def e2422377478618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2422377478618 : Closed e2422377478618 ∧ code e2422377478618 = 11218470500826 := by decide
theorem cert_e2422377478618 : check e2422377478618 [[],[]] .three = true := by decide
def e2422377478634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422377478634 : Closed e2422377478634 ∧ code e2422377478634 = 11218470500842 := by decide
theorem cert_e2422377478634 : check e2422377478634 [[],[]] .three = true := by decide
def e2422377478670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422377478670 : Closed e2422377478670 ∧ code e2422377478670 = 11218470500878 := by decide
theorem cert_e2422377478670 : check e2422377478670 [[],[]] .three = true := by decide
def e2422377478682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377478682 : Closed e2422377478682 ∧ code e2422377478682 = 11218470500890 := by decide
theorem cert_e2422377478682 : check e2422377478682 [[],[]] .three = true := by decide
def e2422377478718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422377478718 : Closed e2422377478718 ∧ code e2422377478718 = 11218470500926 := by decide
theorem cert_e2422377478718 : check e2422377478718 [[],[]] .three = true := by decide
def e2422377478754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422377478754 : Closed e2422377478754 ∧ code e2422377478754 = 11218470500962 := by decide
theorem cert_e2422377478754 : check e2422377478754 [[],[]] .three = true := by decide
def e2422377478766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377478766 : Closed e2422377478766 ∧ code e2422377478766 = 11218470500974 := by decide
theorem cert_e2422377478766 : check e2422377478766 [[],[]] .three = true := by decide
def e2422377478774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422377478774 : Closed e2422377478774 ∧ code e2422377478774 = 11218470500982 := by decide
theorem cert_e2422377478774 : check e2422377478774 [[],[]] .three = true := by decide
def e2422377478778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377478778 : Closed e2422377478778 ∧ code e2422377478778 = 11218470500986 := by decide
theorem cert_e2422377478778 : check e2422377478778 [[],[]] .three = true := by decide
def e2422377478942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422377478942 : Closed e2422377478942 ∧ code e2422377478942 = 11218470501150 := by decide
theorem cert_e2422377478942 : check e2422377478942 [[],[]] .three = true := by decide
def e2422377478966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377478966 : Closed e2422377478966 ∧ code e2422377478966 = 11218470501174 := by decide
theorem cert_e2422377478966 : check e2422377478966 [[],[]] .three = true := by decide
def e2422377478970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377478970 : Closed e2422377478970 ∧ code e2422377478970 = 11218470501178 := by decide
theorem cert_e2422377478970 : check e2422377478970 [[],[]] .three = true := by decide
def e2422377479054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422377479054 : Closed e2422377479054 ∧ code e2422377479054 = 11218470501262 := by decide
theorem cert_e2422377479054 : check e2422377479054 [[],[]] .three = true := by decide
def e2422377479066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377479066 : Closed e2422377479066 ∧ code e2422377479066 = 11218470501274 := by decide
theorem cert_e2422377479066 : check e2422377479066 [[],[]] .three = true := by decide
def e2422377479110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422377479110 : Closed e2422377479110 ∧ code e2422377479110 = 11218470501318 := by decide
theorem cert_e2422377479110 : check e2422377479110 [[],[]] .three = true := by decide
def e2422377481182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422377481182 : Closed e2422377481182 ∧ code e2422377481182 = 11218470503390 := by decide
theorem cert_e2422377481182 : check e2422377481182 [[],[]] .smaller = true := by decide
def e2422377481198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422377481198 : Closed e2422377481198 ∧ code e2422377481198 = 11218470503406 := by decide
theorem cert_e2422377481198 : check e2422377481198 [[],[]] .smaller = true := by decide
def e2422377483118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422377483118 : Closed e2422377483118 ∧ code e2422377483118 = 11218470505326 := by decide
theorem cert_e2422377483118 : check e2422377483118 [[],[]] .smaller = true := by decide
def e2422377483126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422377483126 : Closed e2422377483126 ∧ code e2422377483126 = 11218470505334 := by decide
theorem cert_e2422377483126 : check e2422377483126 [[],[]] .smaller = true := by decide
def e2422377483182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422377483182 : Closed e2422377483182 ∧ code e2422377483182 = 11218470505390 := by decide
theorem cert_e2422377483182 : check e2422377483182 [[],[]] .smaller = true := by decide
def e2422377483194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422377483194 : Closed e2422377483194 ∧ code e2422377483194 = 11218470505402 := by decide
theorem cert_e2422377483194 : check e2422377483194 [[],[]] .smaller = true := by decide
def e2422377483222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422377483222 : Closed e2422377483222 ∧ code e2422377483222 = 11218470505430 := by decide
theorem cert_e2422377483222 : check e2422377483222 [[],[]] .smaller = true := by decide
def e2422377483226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422377483226 : Closed e2422377483226 ∧ code e2422377483226 = 11218470505434 := by decide
theorem cert_e2422377483226 : check e2422377483226 [[],[]] .smaller = true := by decide
def e2422377483502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422377483502 : Closed e2422377483502 ∧ code e2422377483502 = 11218470505710 := by decide
theorem cert_e2422377483502 : check e2422377483502 [[],[]] .smaller = true := by decide
def e2422377483510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422377483510 : Closed e2422377483510 ∧ code e2422377483510 = 11218470505718 := by decide
theorem cert_e2422377483510 : check e2422377483510 [[],[]] .smaller = true := by decide
def e2422377483886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422377483886 : Closed e2422377483886 ∧ code e2422377483886 = 11218470506094 := by decide
theorem cert_e2422377483886 : check e2422377483886 [[],[]] .smaller = true := by decide
def e2422377483898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422377483898 : Closed e2422377483898 ∧ code e2422377483898 = 11218470506106 := by decide
theorem cert_e2422377483898 : check e2422377483898 [[],[]] .smaller = true := by decide
def e2422377484062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 3)))))))))))
theorem wire_e2422377484062 : Closed e2422377484062 ∧ code e2422377484062 = 11218470506270 := by decide
theorem cert_e2422377484062 : check e2422377484062 [[],[]] .smaller = true := by decide
def e2422377484086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377484086 : Closed e2422377484086 ∧ code e2422377484086 = 11218470506294 := by decide
theorem cert_e2422377484086 : check e2422377484086 [[],[]] .smaller = true := by decide
def e2422377484090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377484090 : Closed e2422377484090 ∧ code e2422377484090 = 11218470506298 := by decide
theorem cert_e2422377484090 : check e2422377484090 [[],[]] .smaller = true := by decide
def e2422377484222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e2422377484222 : Closed e2422377484222 ∧ code e2422377484222 = 11218470506430 := by decide
theorem cert_e2422377484222 : check e2422377484222 [[],[]] .three = true := by decide
def e2422377484254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e2422377484254 : Closed e2422377484254 ∧ code e2422377484254 = 11218470506462 := by decide
theorem cert_e2422377484254 : check e2422377484254 [[],[]] .three = true := by decide
def e2422377491286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422377491286 : Closed e2422377491286 ∧ code e2422377491286 = 11218470513494 := by decide
theorem cert_e2422377491286 : check e2422377491286 [[],[]] .smaller = true := by decide
def e2422377491290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422377491290 : Closed e2422377491290 ∧ code e2422377491290 = 11218470513498 := by decide
theorem cert_e2422377491290 : check e2422377491290 [[],[]] .smaller = true := by decide
def e2422377491306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422377491306 : Closed e2422377491306 ∧ code e2422377491306 = 11218470513514 := by decide
theorem cert_e2422377491306 : check e2422377491306 [[],[]] .smaller = true := by decide
def e2422377491370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422377491370 : Closed e2422377491370 ∧ code e2422377491370 = 11218470513578 := by decide
theorem cert_e2422377491370 : check e2422377491370 [[],[]] .smaller = true := by decide
def e2422377491478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422377491478 : Closed e2422377491478 ∧ code e2422377491478 = 11218470513686 := by decide
theorem cert_e2422377491478 : check e2422377491478 [[],[]] .smaller = true := by decide
def e2422377491550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e2422377491550 : Closed e2422377491550 ∧ code e2422377491550 = 11218470513758 := by decide
theorem cert_e2422377491550 : check e2422377491550 [[],[]] .three = true := by decide
def e2422377491574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422377491574 : Closed e2422377491574 ∧ code e2422377491574 = 11218470513782 := by decide
theorem cert_e2422377491574 : check e2422377491574 [[],[]] .smaller = true := by decide
def e2422377491670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422377491670 : Closed e2422377491670 ∧ code e2422377491670 = 11218470513878 := by decide
theorem cert_e2422377491670 : check e2422377491670 [[],[]] .smaller = true := by decide
def e2422377491674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422377491674 : Closed e2422377491674 ∧ code e2422377491674 = 11218470513882 := by decide
theorem cert_e2422377491674 : check e2422377491674 [[],[]] .smaller = true := by decide
def e2422377491690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422377491690 : Closed e2422377491690 ∧ code e2422377491690 = 11218470513898 := by decide
theorem cert_e2422377491690 : check e2422377491690 [[],[]] .smaller = true := by decide
def e2422377491766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377491766 : Closed e2422377491766 ∧ code e2422377491766 = 11218470513974 := by decide
theorem cert_e2422377491766 : check e2422377491766 [[],[]] .smaller = true := by decide
def e2422377491770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377491770 : Closed e2422377491770 ∧ code e2422377491770 = 11218470513978 := by decide
theorem cert_e2422377491770 : check e2422377491770 [[],[]] .smaller = true := by decide
def e2422377491842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422377491842 : Closed e2422377491842 ∧ code e2422377491842 = 11218470514050 := by decide
theorem cert_e2422377491842 : check e2422377491842 [[],[]] .smaller = true := by decide
def e2422377491854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422377491854 : Closed e2422377491854 ∧ code e2422377491854 = 11218470514062 := by decide
theorem cert_e2422377491854 : check e2422377491854 [[],[]] .smaller = true := by decide
def e2422377491866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377491866 : Closed e2422377491866 ∧ code e2422377491866 = 11218470514074 := by decide
theorem cert_e2422377491866 : check e2422377491866 [[],[]] .smaller = true := by decide
def e2422377491934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2422377491934 : Closed e2422377491934 ∧ code e2422377491934 = 11218470514142 := by decide
theorem cert_e2422377491934 : check e2422377491934 [[],[]] .three = true := by decide
def e2422377491938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e2422377491938 : Closed e2422377491938 ∧ code e2422377491938 = 11218470514146 := by decide
theorem cert_e2422377491938 : check e2422377491938 [[],[]] .three = true := by decide
def e2422377491950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2422377491950 : Closed e2422377491950 ∧ code e2422377491950 = 11218470514158 := by decide
theorem cert_e2422377491950 : check e2422377491950 [[],[]] .three = true := by decide
def e2422377491978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422377491978 : Closed e2422377491978 ∧ code e2422377491978 = 11218470514186 := by decide
theorem cert_e2422377491978 : check e2422377491978 [[],[]] .smaller = true := by decide
def e2422377492014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422377492014 : Closed e2422377492014 ∧ code e2422377492014 = 11218470514222 := by decide
theorem cert_e2422377492014 : check e2422377492014 [[],[]] .smaller = true := by decide
def e2422377492022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422377492022 : Closed e2422377492022 ∧ code e2422377492022 = 11218470514230 := by decide
theorem cert_e2422377492022 : check e2422377492022 [[],[]] .smaller = true := by decide
def e2422377492026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422377492026 : Closed e2422377492026 ∧ code e2422377492026 = 11218470514234 := by decide
theorem cert_e2422377492026 : check e2422377492026 [[],[]] .smaller = true := by decide
def e2422377492074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422377492074 : Closed e2422377492074 ∧ code e2422377492074 = 11218470514282 := by decide
theorem cert_e2422377492074 : check e2422377492074 [[],[]] .smaller = true := by decide
def e2422377492098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422377492098 : Closed e2422377492098 ∧ code e2422377492098 = 11218470514306 := by decide
theorem cert_e2422377492098 : check e2422377492098 [[],[]] .smaller = true := by decide
def e2422377492110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422377492110 : Closed e2422377492110 ∧ code e2422377492110 = 11218470514318 := by decide
theorem cert_e2422377492110 : check e2422377492110 [[],[]] .smaller = true := by decide
def e2422377492122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377492122 : Closed e2422377492122 ∧ code e2422377492122 = 11218470514330 := by decide
theorem cert_e2422377492122 : check e2422377492122 [[],[]] .smaller = true := by decide
def e2422377492166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422377492166 : Closed e2422377492166 ∧ code e2422377492166 = 11218470514374 := by decide
theorem cert_e2422377492166 : check e2422377492166 [[],[]] .smaller = true := by decide
def e2422377492190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2422377492190 : Closed e2422377492190 ∧ code e2422377492190 = 11218470514398 := by decide
theorem cert_e2422377492190 : check e2422377492190 [[],[]] .three = true := by decide
def e2422377492194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422377492194 : Closed e2422377492194 ∧ code e2422377492194 = 11218470514402 := by decide
theorem cert_e2422377492194 : check e2422377492194 [[],[]] .smaller = true := by decide
def e2422377492206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e2422377492206 : Closed e2422377492206 ∧ code e2422377492206 = 11218470514414 := by decide
theorem cert_e2422377492206 : check e2422377492206 [[],[]] .smaller = true := by decide
def e2422377492214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2422377492214 : Closed e2422377492214 ∧ code e2422377492214 = 11218470514422 := by decide
theorem cert_e2422377492214 : check e2422377492214 [[],[]] .three = true := by decide
def e2422377492246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422377492246 : Closed e2422377492246 ∧ code e2422377492246 = 11218470514454 := by decide
theorem cert_e2422377492246 : check e2422377492246 [[],[]] .smaller = true := by decide
def e2422377492318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2422377492318 : Closed e2422377492318 ∧ code e2422377492318 = 11218470514526 := by decide
theorem cert_e2422377492318 : check e2422377492318 [[],[]] .three = true := by decide
def e2422377492322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422377492322 : Closed e2422377492322 ∧ code e2422377492322 = 11218470514530 := by decide
theorem cert_e2422377492322 : check e2422377492322 [[],[]] .smaller = true := by decide
def e2422377492334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e2422377492334 : Closed e2422377492334 ∧ code e2422377492334 = 11218470514542 := by decide
theorem cert_e2422377492334 : check e2422377492334 [[],[]] .smaller = true := by decide
def e2422377492342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e2422377492342 : Closed e2422377492342 ∧ code e2422377492342 = 11218470514550 := by decide
theorem cert_e2422377492342 : check e2422377492342 [[],[]] .smaller = true := by decide
def e2422377492346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2422377492346 : Closed e2422377492346 ∧ code e2422377492346 = 11218470514554 := by decide
theorem cert_e2422377492346 : check e2422377492346 [[],[]] .three = true := by decide
def e2422377492362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422377492362 : Closed e2422377492362 ∧ code e2422377492362 = 11218470514570 := by decide
theorem cert_e2422377492362 : check e2422377492362 [[],[]] .three = true := by decide
def e2422377492386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422377492386 : Closed e2422377492386 ∧ code e2422377492386 = 11218470514594 := by decide
theorem cert_e2422377492386 : check e2422377492386 [[],[]] .three = true := by decide
def e2422377492398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2422377492398 : Closed e2422377492398 ∧ code e2422377492398 = 11218470514606 := by decide
theorem cert_e2422377492398 : check e2422377492398 [[],[]] .three = true := by decide
def e2422377492406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2422377492406 : Closed e2422377492406 ∧ code e2422377492406 = 11218470514614 := by decide
theorem cert_e2422377492406 : check e2422377492406 [[],[]] .three = true := by decide
def e2422377492410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2422377492410 : Closed e2422377492410 ∧ code e2422377492410 = 11218470514618 := by decide
theorem cert_e2422377492410 : check e2422377492410 [[],[]] .three = true := by decide
def e2422377492606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 5)))))))))))
theorem wire_e2422377492606 : Closed e2422377492606 ∧ code e2422377492606 = 11218470514814 := by decide
theorem cert_e2422377492606 : check e2422377492606 [[],[]] .three = true := by decide
def e2422377492718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422377492718 : Closed e2422377492718 ∧ code e2422377492718 = 11218470514926 := by decide
theorem cert_e2422377492718 : check e2422377492718 [[],[]] .smaller = true := by decide
def e2422377492726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422377492726 : Closed e2422377492726 ∧ code e2422377492726 = 11218470514934 := by decide
theorem cert_e2422377492726 : check e2422377492726 [[],[]] .smaller = true := by decide
def e2422377493206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422377493206 : Closed e2422377493206 ∧ code e2422377493206 = 11218470515414 := by decide
theorem cert_e2422377493206 : check e2422377493206 [[],[]] .smaller = true := by decide
def e2422377493210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422377493210 : Closed e2422377493210 ∧ code e2422377493210 = 11218470515418 := by decide
theorem cert_e2422377493210 : check e2422377493210 [[],[]] .smaller = true := by decide
def e2422377493226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422377493226 : Closed e2422377493226 ∧ code e2422377493226 = 11218470515434 := by decide
theorem cert_e2422377493226 : check e2422377493226 [[],[]] .smaller = true := by decide
def e2422377493302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377493302 : Closed e2422377493302 ∧ code e2422377493302 = 11218470515510 := by decide
theorem cert_e2422377493302 : check e2422377493302 [[],[]] .smaller = true := by decide
def e2422377493306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377493306 : Closed e2422377493306 ∧ code e2422377493306 = 11218470515514 := by decide
theorem cert_e2422377493306 : check e2422377493306 [[],[]] .smaller = true := by decide
def e2422377493378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422377493378 : Closed e2422377493378 ∧ code e2422377493378 = 11218470515586 := by decide
theorem cert_e2422377493378 : check e2422377493378 [[],[]] .smaller = true := by decide
def e2422377493390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422377493390 : Closed e2422377493390 ∧ code e2422377493390 = 11218470515598 := by decide
theorem cert_e2422377493390 : check e2422377493390 [[],[]] .smaller = true := by decide
def e2422377493402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377493402 : Closed e2422377493402 ∧ code e2422377493402 = 11218470515610 := by decide
theorem cert_e2422377493402 : check e2422377493402 [[],[]] .smaller = true := by decide
def e2422377493470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422377493470 : Closed e2422377493470 ∧ code e2422377493470 = 11218470515678 := by decide
theorem cert_e2422377493470 : check e2422377493470 [[],[]] .three = true := by decide
def e2422377493474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e2422377493474 : Closed e2422377493474 ∧ code e2422377493474 = 11218470515682 := by decide
theorem cert_e2422377493474 : check e2422377493474 [[],[]] .three = true := by decide
def e2422377493486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422377493486 : Closed e2422377493486 ∧ code e2422377493486 = 11218470515694 := by decide
theorem cert_e2422377493486 : check e2422377493486 [[],[]] .three = true := by decide
def e2422377494554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422377494554 : Closed e2422377494554 ∧ code e2422377494554 = 11218470516762 := by decide
theorem cert_e2422377494554 : check e2422377494554 [[],[]] .smaller = true := by decide
def e2422377494590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422377494590 : Closed e2422377494590 ∧ code e2422377494590 = 11218470516798 := by decide
theorem cert_e2422377494590 : check e2422377494590 [[],[]] .smaller = true := by decide
def e2422377494638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422377494638 : Closed e2422377494638 ∧ code e2422377494638 = 11218470516846 := by decide
theorem cert_e2422377494638 : check e2422377494638 [[],[]] .smaller = true := by decide
def e2422377494646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422377494646 : Closed e2422377494646 ∧ code e2422377494646 = 11218470516854 := by decide
theorem cert_e2422377494646 : check e2422377494646 [[],[]] .smaller = true := by decide
def e2422377494650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422377494650 : Closed e2422377494650 ∧ code e2422377494650 = 11218470516858 := by decide
theorem cert_e2422377494650 : check e2422377494650 [[],[]] .smaller = true := by decide
def e2422377494890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422377494890 : Closed e2422377494890 ∧ code e2422377494890 = 11218470517098 := by decide
theorem cert_e2422377494890 : check e2422377494890 [[],[]] .smaller = true := by decide
def e2422377494914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422377494914 : Closed e2422377494914 ∧ code e2422377494914 = 11218470517122 := by decide
theorem cert_e2422377494914 : check e2422377494914 [[],[]] .smaller = true := by decide
def e2422377494926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422377494926 : Closed e2422377494926 ∧ code e2422377494926 = 11218470517134 := by decide
theorem cert_e2422377494926 : check e2422377494926 [[],[]] .smaller = true := by decide
def e2422377494938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377494938 : Closed e2422377494938 ∧ code e2422377494938 = 11218470517146 := by decide
theorem cert_e2422377494938 : check e2422377494938 [[],[]] .smaller = true := by decide
def e2422377494982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422377494982 : Closed e2422377494982 ∧ code e2422377494982 = 11218470517190 := by decide
theorem cert_e2422377494982 : check e2422377494982 [[],[]] .smaller = true := by decide
def e2422377495006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422377495006 : Closed e2422377495006 ∧ code e2422377495006 = 11218470517214 := by decide
theorem cert_e2422377495006 : check e2422377495006 [[],[]] .three = true := by decide
def e2422377495010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422377495010 : Closed e2422377495010 ∧ code e2422377495010 = 11218470517218 := by decide
theorem cert_e2422377495010 : check e2422377495010 [[],[]] .smaller = true := by decide
def e2422377495022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422377495022 : Closed e2422377495022 ∧ code e2422377495022 = 11218470517230 := by decide
theorem cert_e2422377495022 : check e2422377495022 [[],[]] .smaller = true := by decide
def e2422377495030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422377495030 : Closed e2422377495030 ∧ code e2422377495030 = 11218470517238 := by decide
theorem cert_e2422377495030 : check e2422377495030 [[],[]] .three = true := by decide
def e2422377495582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422377495582 : Closed e2422377495582 ∧ code e2422377495582 = 11218470517790 := by decide
theorem cert_e2422377495582 : check e2422377495582 [[],[]] .smaller = true := by decide
def e2422377495774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422377495774 : Closed e2422377495774 ∧ code e2422377495774 = 11218470517982 := by decide
theorem cert_e2422377495774 : check e2422377495774 [[],[]] .three = true := by decide
def e2422377495778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422377495778 : Closed e2422377495778 ∧ code e2422377495778 = 11218470517986 := by decide
theorem cert_e2422377495778 : check e2422377495778 [[],[]] .smaller = true := by decide
def e2422377495790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422377495790 : Closed e2422377495790 ∧ code e2422377495790 = 11218470517998 := by decide
theorem cert_e2422377495790 : check e2422377495790 [[],[]] .smaller = true := by decide
def e2422377495798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422377495798 : Closed e2422377495798 ∧ code e2422377495798 = 11218470518006 := by decide
theorem cert_e2422377495798 : check e2422377495798 [[],[]] .smaller = true := by decide
def e2422377495802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422377495802 : Closed e2422377495802 ∧ code e2422377495802 = 11218470518010 := by decide
theorem cert_e2422377495802 : check e2422377495802 [[],[]] .three = true := by decide
def e2422377496078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422377496078 : Closed e2422377496078 ∧ code e2422377496078 = 11218470518286 := by decide
theorem cert_e2422377496078 : check e2422377496078 [[],[]] .three = true := by decide
def e2422377496090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377496090 : Closed e2422377496090 ∧ code e2422377496090 = 11218470518298 := by decide
theorem cert_e2422377496090 : check e2422377496090 [[],[]] .three = true := by decide
def e2422377496126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.var 4))))))))))
theorem wire_e2422377496126 : Closed e2422377496126 ∧ code e2422377496126 = 11218470518334 := by decide
theorem cert_e2422377496126 : check e2422377496126 [[],[]] .three = true := by decide
def e2422377496162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422377496162 : Closed e2422377496162 ∧ code e2422377496162 = 11218470518370 := by decide
theorem cert_e2422377496162 : check e2422377496162 [[],[]] .three = true := by decide
def e2422377496174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377496174 : Closed e2422377496174 ∧ code e2422377496174 = 11218470518382 := by decide
theorem cert_e2422377496174 : check e2422377496174 [[],[]] .three = true := by decide
def e2422377496182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422377496182 : Closed e2422377496182 ∧ code e2422377496182 = 11218470518390 := by decide
theorem cert_e2422377496182 : check e2422377496182 [[],[]] .three = true := by decide
def e2422377496186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377496186 : Closed e2422377496186 ∧ code e2422377496186 = 11218470518394 := by decide
theorem cert_e2422377496186 : check e2422377496186 [[],[]] .three = true := by decide
def e2422377513454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422377513454 : Closed e2422377513454 ∧ code e2422377513454 = 11218470535662 := by decide
theorem cert_e2422377513454 : check e2422377513454 [[],[]] .smaller = true := by decide
def e2422377514422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422377514422 : Closed e2422377514422 ∧ code e2422377514422 = 11218470536630 := by decide
theorem cert_e2422377514422 : check e2422377514422 [[],[]] .smaller = true := by decide
def e2422377514454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422377514454 : Closed e2422377514454 ∧ code e2422377514454 = 11218470536662 := by decide
theorem cert_e2422377514454 : check e2422377514454 [[],[]] .smaller = true := by decide
def e2422377514458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422377514458 : Closed e2422377514458 ∧ code e2422377514458 = 11218470536666 := by decide
theorem cert_e2422377514458 : check e2422377514458 [[],[]] .smaller = true := by decide
def e2422377514614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422377514614 : Closed e2422377514614 ∧ code e2422377514614 = 11218470536822 := by decide
theorem cert_e2422377514614 : check e2422377514614 [[],[]] .smaller = true := by decide
def e2422377514782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422377514782 : Closed e2422377514782 ∧ code e2422377514782 = 11218470536990 := by decide
theorem cert_e2422377514782 : check e2422377514782 [[],[]] .smaller = true := by decide
def e2422377514806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377514806 : Closed e2422377514806 ∧ code e2422377514806 = 11218470537014 := by decide
theorem cert_e2422377514806 : check e2422377514806 [[],[]] .smaller = true := by decide
def e2422377514810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377514810 : Closed e2422377514810 ∧ code e2422377514810 = 11218470537018 := by decide
theorem cert_e2422377514810 : check e2422377514810 [[],[]] .smaller = true := by decide
def e2422377514894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422377514894 : Closed e2422377514894 ∧ code e2422377514894 = 11218470537102 := by decide
theorem cert_e2422377514894 : check e2422377514894 [[],[]] .smaller = true := by decide
def e2422377514942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422377514942 : Closed e2422377514942 ∧ code e2422377514942 = 11218470537150 := by decide
theorem cert_e2422377514942 : check e2422377514942 [[],[]] .three = true := by decide
def e2422377514990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422377514990 : Closed e2422377514990 ∧ code e2422377514990 = 11218470537198 := by decide
theorem cert_e2422377514990 : check e2422377514990 [[],[]] .three = true := by decide
def e2422377518506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422377518506 : Closed e2422377518506 ∧ code e2422377518506 = 11218470540714 := by decide
theorem cert_e2422377518506 : check e2422377518506 [[],[]] .smaller = true := by decide
def e2422377518602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422377518602 : Closed e2422377518602 ∧ code e2422377518602 = 11218470540810 := by decide
theorem cert_e2422377518602 : check e2422377518602 [[],[]] .smaller = true := by decide
def e2422377518638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422377518638 : Closed e2422377518638 ∧ code e2422377518638 = 11218470540846 := by decide
theorem cert_e2422377518638 : check e2422377518638 [[],[]] .smaller = true := by decide
def e2422377518646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422377518646 : Closed e2422377518646 ∧ code e2422377518646 = 11218470540854 := by decide
theorem cert_e2422377518646 : check e2422377518646 [[],[]] .smaller = true := by decide
def e2422377518650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422377518650 : Closed e2422377518650 ∧ code e2422377518650 = 11218470540858 := by decide
theorem cert_e2422377518650 : check e2422377518650 [[],[]] .smaller = true := by decide
def e2422377518698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422377518698 : Closed e2422377518698 ∧ code e2422377518698 = 11218470540906 := by decide
theorem cert_e2422377518698 : check e2422377518698 [[],[]] .smaller = true := by decide
def e2422377518722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422377518722 : Closed e2422377518722 ∧ code e2422377518722 = 11218470540930 := by decide
theorem cert_e2422377518722 : check e2422377518722 [[],[]] .smaller = true := by decide
def e2422377518734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422377518734 : Closed e2422377518734 ∧ code e2422377518734 = 11218470540942 := by decide
theorem cert_e2422377518734 : check e2422377518734 [[],[]] .smaller = true := by decide
def e2422377518746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377518746 : Closed e2422377518746 ∧ code e2422377518746 = 11218470540954 := by decide
theorem cert_e2422377518746 : check e2422377518746 [[],[]] .smaller = true := by decide
def e2422377518790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422377518790 : Closed e2422377518790 ∧ code e2422377518790 = 11218470540998 := by decide
theorem cert_e2422377518790 : check e2422377518790 [[],[]] .smaller = true := by decide
def e2422377518814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422377518814 : Closed e2422377518814 ∧ code e2422377518814 = 11218470541022 := by decide
theorem cert_e2422377518814 : check e2422377518814 [[],[]] .three = true := by decide
def e2422377518818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422377518818 : Closed e2422377518818 ∧ code e2422377518818 = 11218470541026 := by decide
theorem cert_e2422377518818 : check e2422377518818 [[],[]] .smaller = true := by decide
def e2422377518830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2422377518830 : Closed e2422377518830 ∧ code e2422377518830 = 11218470541038 := by decide
theorem cert_e2422377518830 : check e2422377518830 [[],[]] .smaller = true := by decide
def e2422377518838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422377518838 : Closed e2422377518838 ∧ code e2422377518838 = 11218470541046 := by decide
theorem cert_e2422377518838 : check e2422377518838 [[],[]] .three = true := by decide
def e2422377518874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422377518874 : Closed e2422377518874 ∧ code e2422377518874 = 11218470541082 := by decide
theorem cert_e2422377518874 : check e2422377518874 [[],[]] .smaller = true := by decide
end Blc.Floor43
