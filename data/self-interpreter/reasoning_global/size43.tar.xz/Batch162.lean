import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2261099134422 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2261099134422 : Closed e2261099134422 ∧ code e2261099134422 = 11057192156630 := by decide
theorem cert_e2261099134422 : check e2261099134422 [[],[.under]] .three = true := by decide
def e2261099134426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2261099134426 : Closed e2261099134426 ∧ code e2261099134426 = 11057192156634 := by decide
theorem cert_e2261099134426 : check e2261099134426 [[],[.under]] .three = true := by decide
def e2261099138798 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2261099138798 : Closed e2261099138798 ∧ code e2261099138798 = 11057192161006 := by decide
theorem cert_e2261099138798 : check e2261099138798 [[],[.under]] .three = true := by decide
def e2261099138926 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2261099138926 : Closed e2261099138926 ∧ code e2261099138926 = 11057192161134 := by decide
theorem cert_e2261099138926 : check e2261099138926 [[],[.under]] .three = true := by decide
def e2261099138934 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2261099138934 : Closed e2261099138934 ∧ code e2261099138934 = 11057192161142 := by decide
theorem cert_e2261099138934 : check e2261099138934 [[],[.under]] .three = true := by decide
def e2261099141614 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2261099141614 : Closed e2261099141614 ∧ code e2261099141614 = 11057192163822 := by decide
theorem cert_e2261099141614 : check e2261099141614 [[],[.under]] .three = true := by decide
def e2261099142382 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2261099142382 : Closed e2261099142382 ∧ code e2261099142382 = 11057192164590 := by decide
theorem cert_e2261099142382 : check e2261099142382 [[],[.under]] .three = true := by decide
def e2261099142390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2261099142390 : Closed e2261099142390 ∧ code e2261099142390 = 11057192164598 := by decide
theorem cert_e2261099142390 : check e2261099142390 [[],[.under]] .three = true := by decide
def e2261099144942 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2261099144942 : Closed e2261099144942 ∧ code e2261099144942 = 11057192167150 := by decide
theorem cert_e2261099144942 : check e2261099144942 [[],[.under]] .three = true := by decide
def e2261099145134 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2261099145134 : Closed e2261099145134 ∧ code e2261099145134 = 11057192167342 := by decide
theorem cert_e2261099145134 : check e2261099145134 [[],[.under]] .three = true := by decide
def e2261099145146 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2261099145146 : Closed e2261099145146 ∧ code e2261099145146 = 11057192167354 := by decide
theorem cert_e2261099145146 : check e2261099145146 [[],[.under]] .three = true := by decide
def e2261099145710 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2261099145710 : Closed e2261099145710 ∧ code e2261099145710 = 11057192167918 := by decide
theorem cert_e2261099145710 : check e2261099145710 [[],[.under]] .three = true := by decide
def e2261099146862 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2261099146862 : Closed e2261099146862 ∧ code e2261099146862 = 11057192169070 := by decide
theorem cert_e2261099146862 : check e2261099146862 [[],[.under]] .three = true := by decide
def e2261099146874 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2261099146874 : Closed e2261099146874 ∧ code e2261099146874 = 11057192169082 := by decide
theorem cert_e2261099146874 : check e2261099146874 [[],[.under]] .three = true := by decide
def e2261099148142 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2261099148142 : Closed e2261099148142 ∧ code e2261099148142 = 11057192170350 := by decide
theorem cert_e2261099148142 : check e2261099148142 [[],[.under]] .three = true := by decide
def e2261099148150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2261099148150 : Closed e2261099148150 ∧ code e2261099148150 = 11057192170358 := by decide
theorem cert_e2261099148150 : check e2261099148150 [[],[.under]] .three = true := by decide
def e2261099148206 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2261099148206 : Closed e2261099148206 ∧ code e2261099148206 = 11057192170414 := by decide
theorem cert_e2261099148206 : check e2261099148206 [[],[.under]] .three = true := by decide
def e2261099148218 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2261099148218 : Closed e2261099148218 ∧ code e2261099148218 = 11057192170426 := by decide
theorem cert_e2261099148218 : check e2261099148218 [[],[.under]] .three = true := by decide
def e2261099148246 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2261099148246 : Closed e2261099148246 ∧ code e2261099148246 = 11057192170454 := by decide
theorem cert_e2261099148246 : check e2261099148246 [[],[.under]] .three = true := by decide
def e2261099148250 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2261099148250 : Closed e2261099148250 ∧ code e2261099148250 = 11057192170458 := by decide
theorem cert_e2261099148250 : check e2261099148250 [[],[.under]] .three = true := by decide
def e2261099148526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2261099148526 : Closed e2261099148526 ∧ code e2261099148526 = 11057192170734 := by decide
theorem cert_e2261099148526 : check e2261099148526 [[],[.under]] .three = true := by decide
def e2261099148534 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2261099148534 : Closed e2261099148534 ∧ code e2261099148534 = 11057192170742 := by decide
theorem cert_e2261099148534 : check e2261099148534 [[],[.under]] .three = true := by decide
def e2261099148910 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2261099148910 : Closed e2261099148910 ∧ code e2261099148910 = 11057192171118 := by decide
theorem cert_e2261099148910 : check e2261099148910 [[],[.under]] .three = true := by decide
def e2261099148922 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2261099148922 : Closed e2261099148922 ∧ code e2261099148922 = 11057192171130 := by decide
theorem cert_e2261099148922 : check e2261099148922 [[],[.under]] .three = true := by decide
def e2261099149110 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2261099149110 : Closed e2261099149110 ∧ code e2261099149110 = 11057192171318 := by decide
theorem cert_e2261099149110 : check e2261099149110 [[],[.under]] .three = true := by decide
def e2261099149114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2261099149114 : Closed e2261099149114 ∧ code e2261099149114 = 11057192171322 := by decide
theorem cert_e2261099149114 : check e2261099149114 [[],[.under]] .three = true := by decide
def e2261099154286 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2261099154286 : Closed e2261099154286 ∧ code e2261099154286 = 11057192176494 := by decide
theorem cert_e2261099154286 : check e2261099154286 [[],[.under]] .smaller = true := by decide
def e2261099154294 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2261099154294 : Closed e2261099154294 ∧ code e2261099154294 = 11057192176502 := by decide
theorem cert_e2261099154294 : check e2261099154294 [[],[.under]] .smaller = true := by decide
def e2261099154350 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2261099154350 : Closed e2261099154350 ∧ code e2261099154350 = 11057192176558 := by decide
theorem cert_e2261099154350 : check e2261099154350 [[],[.under]] .smaller = true := by decide
def e2261099154362 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2261099154362 : Closed e2261099154362 ∧ code e2261099154362 = 11057192176570 := by decide
theorem cert_e2261099154362 : check e2261099154362 [[],[.under]] .smaller = true := by decide
def e2261099154390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2261099154390 : Closed e2261099154390 ∧ code e2261099154390 = 11057192176598 := by decide
theorem cert_e2261099154390 : check e2261099154390 [[],[.under]] .smaller = true := by decide
def e2261099154394 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2261099154394 : Closed e2261099154394 ∧ code e2261099154394 = 11057192176602 := by decide
theorem cert_e2261099154394 : check e2261099154394 [[],[.under]] .smaller = true := by decide
def e2261099154670 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2261099154670 : Closed e2261099154670 ∧ code e2261099154670 = 11057192176878 := by decide
theorem cert_e2261099154670 : check e2261099154670 [[],[.under]] .smaller = true := by decide
def e2261099154678 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2261099154678 : Closed e2261099154678 ∧ code e2261099154678 = 11057192176886 := by decide
theorem cert_e2261099154678 : check e2261099154678 [[],[.under]] .smaller = true := by decide
def e2261099155054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2261099155054 : Closed e2261099155054 ∧ code e2261099155054 = 11057192177262 := by decide
theorem cert_e2261099155054 : check e2261099155054 [[],[.under]] .smaller = true := by decide
def e2261099155066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2261099155066 : Closed e2261099155066 ∧ code e2261099155066 = 11057192177274 := by decide
theorem cert_e2261099155066 : check e2261099155066 [[],[.under]] .smaller = true := by decide
def e2261099155254 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2261099155254 : Closed e2261099155254 ∧ code e2261099155254 = 11057192177462 := by decide
theorem cert_e2261099155254 : check e2261099155254 [[],[.under]] .smaller = true := by decide
def e2261099155258 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2261099155258 : Closed e2261099155258 ∧ code e2261099155258 = 11057192177466 := by decide
theorem cert_e2261099155258 : check e2261099155258 [[],[.under]] .smaller = true := by decide
def e2261099163374 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2261099163374 : Closed e2261099163374 ∧ code e2261099163374 = 11057192185582 := by decide
theorem cert_e2261099163374 : check e2261099163374 [[],[.under]] .three = true := by decide
def e2261099163502 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2261099163502 : Closed e2261099163502 ∧ code e2261099163502 = 11057192185710 := by decide
theorem cert_e2261099163502 : check e2261099163502 [[],[.under]] .three = true := by decide
def e2261099163510 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2261099163510 : Closed e2261099163510 ∧ code e2261099163510 = 11057192185718 := by decide
theorem cert_e2261099163510 : check e2261099163510 [[],[.under]] .three = true := by decide
def e2261099166190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2261099166190 : Closed e2261099166190 ∧ code e2261099166190 = 11057192188398 := by decide
theorem cert_e2261099166190 : check e2261099166190 [[],[.under]] .three = true := by decide
def e2261099166958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2261099166958 : Closed e2261099166958 ∧ code e2261099166958 = 11057192189166 := by decide
theorem cert_e2261099166958 : check e2261099166958 [[],[.under]] .three = true := by decide
def e2261099166966 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2261099166966 : Closed e2261099166966 ∧ code e2261099166966 = 11057192189174 := by decide
theorem cert_e2261099166966 : check e2261099166966 [[],[.under]] .three = true := by decide
def e2261099189998 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2261099189998 : Closed e2261099189998 ∧ code e2261099189998 = 11057192212206 := by decide
theorem cert_e2261099189998 : check e2261099189998 [[],[.under]] .three = true := by decide
def e2261099190190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2261099190190 : Closed e2261099190190 ∧ code e2261099190190 = 11057192212398 := by decide
theorem cert_e2261099190190 : check e2261099190190 [[],[.under]] .three = true := by decide
def e2261099190202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2261099190202 : Closed e2261099190202 ∧ code e2261099190202 = 11057192212410 := by decide
theorem cert_e2261099190202 : check e2261099190202 [[],[.under]] .three = true := by decide
def e2261099190766 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2261099190766 : Closed e2261099190766 ∧ code e2261099190766 = 11057192212974 := by decide
theorem cert_e2261099190766 : check e2261099190766 [[],[.under]] .three = true := by decide
def e2261099191918 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2261099191918 : Closed e2261099191918 ∧ code e2261099191918 = 11057192214126 := by decide
theorem cert_e2261099191918 : check e2261099191918 [[],[.under]] .three = true := by decide
def e2261099191930 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2261099191930 : Closed e2261099191930 ∧ code e2261099191930 = 11057192214138 := by decide
theorem cert_e2261099191930 : check e2261099191930 [[],[.under]] .three = true := by decide
def e2261099203438 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2261099203438 : Closed e2261099203438 ∧ code e2261099203438 = 11057192225646 := by decide
theorem cert_e2261099203438 : check e2261099203438 [[],[.under]] .three = true := by decide
def e2261099203446 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2261099203446 : Closed e2261099203446 ∧ code e2261099203446 = 11057192225654 := by decide
theorem cert_e2261099203446 : check e2261099203446 [[],[.under]] .three = true := by decide
def e2261099203502 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2261099203502 : Closed e2261099203502 ∧ code e2261099203502 = 11057192225710 := by decide
theorem cert_e2261099203502 : check e2261099203502 [[],[.under]] .three = true := by decide
def e2261099203514 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2261099203514 : Closed e2261099203514 ∧ code e2261099203514 = 11057192225722 := by decide
theorem cert_e2261099203514 : check e2261099203514 [[],[.under]] .three = true := by decide
def e2261099203542 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2261099203542 : Closed e2261099203542 ∧ code e2261099203542 = 11057192225750 := by decide
theorem cert_e2261099203542 : check e2261099203542 [[],[.under]] .three = true := by decide
def e2261099203546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2261099203546 : Closed e2261099203546 ∧ code e2261099203546 = 11057192225754 := by decide
theorem cert_e2261099203546 : check e2261099203546 [[],[.under]] .three = true := by decide
def e2261099203822 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2261099203822 : Closed e2261099203822 ∧ code e2261099203822 = 11057192226030 := by decide
theorem cert_e2261099203822 : check e2261099203822 [[],[.under]] .three = true := by decide
def e2261099203830 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2261099203830 : Closed e2261099203830 ∧ code e2261099203830 = 11057192226038 := by decide
theorem cert_e2261099203830 : check e2261099203830 [[],[.under]] .three = true := by decide
def e2261099204206 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2261099204206 : Closed e2261099204206 ∧ code e2261099204206 = 11057192226414 := by decide
theorem cert_e2261099204206 : check e2261099204206 [[],[.under]] .three = true := by decide
def e2261099204218 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2261099204218 : Closed e2261099204218 ∧ code e2261099204218 = 11057192226426 := by decide
theorem cert_e2261099204218 : check e2261099204218 [[],[.under]] .three = true := by decide
def e2261099204406 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2261099204406 : Closed e2261099204406 ∧ code e2261099204406 = 11057192226614 := by decide
theorem cert_e2261099204406 : check e2261099204406 [[],[.under]] .three = true := by decide
def e2261099204410 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2261099204410 : Closed e2261099204410 ∧ code e2261099204410 = 11057192226618 := by decide
theorem cert_e2261099204410 : check e2261099204410 [[],[.under]] .three = true := by decide
def e2261099744110 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2261099744110 : Closed e2261099744110 ∧ code e2261099744110 = 11057192766318 := by decide
theorem cert_e2261099744110 : check e2261099744110 [[],[.under]] .smaller = true := by decide
def e2261099744118 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2261099744118 : Closed e2261099744118 ∧ code e2261099744118 = 11057192766326 := by decide
theorem cert_e2261099744118 : check e2261099744118 [[],[.under]] .smaller = true := by decide
def e2261099744174 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2261099744174 : Closed e2261099744174 ∧ code e2261099744174 = 11057192766382 := by decide
theorem cert_e2261099744174 : check e2261099744174 [[],[.under]] .smaller = true := by decide
def e2261099744186 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2261099744186 : Closed e2261099744186 ∧ code e2261099744186 = 11057192766394 := by decide
theorem cert_e2261099744186 : check e2261099744186 [[],[.under]] .smaller = true := by decide
def e2261099744214 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2261099744214 : Closed e2261099744214 ∧ code e2261099744214 = 11057192766422 := by decide
theorem cert_e2261099744214 : check e2261099744214 [[],[.under]] .smaller = true := by decide
def e2261099744218 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2261099744218 : Closed e2261099744218 ∧ code e2261099744218 = 11057192766426 := by decide
theorem cert_e2261099744218 : check e2261099744218 [[],[.under]] .smaller = true := by decide
def e2261099744494 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2261099744494 : Closed e2261099744494 ∧ code e2261099744494 = 11057192766702 := by decide
theorem cert_e2261099744494 : check e2261099744494 [[],[.under]] .smaller = true := by decide
def e2261099744502 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2261099744502 : Closed e2261099744502 ∧ code e2261099744502 = 11057192766710 := by decide
theorem cert_e2261099744502 : check e2261099744502 [[],[.under]] .smaller = true := by decide
def e2261099744878 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2261099744878 : Closed e2261099744878 ∧ code e2261099744878 = 11057192767086 := by decide
theorem cert_e2261099744878 : check e2261099744878 [[],[.under]] .smaller = true := by decide
def e2261099744890 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2261099744890 : Closed e2261099744890 ∧ code e2261099744890 = 11057192767098 := by decide
theorem cert_e2261099744890 : check e2261099744890 [[],[.under]] .smaller = true := by decide
def e2261099745078 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2261099745078 : Closed e2261099745078 ∧ code e2261099745078 = 11057192767286 := by decide
theorem cert_e2261099745078 : check e2261099745078 [[],[.under]] .smaller = true := by decide
def e2261099745082 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2261099745082 : Closed e2261099745082 ∧ code e2261099745082 = 11057192767290 := by decide
theorem cert_e2261099745082 : check e2261099745082 [[],[.under]] .smaller = true := by decide
def e2261132598126 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2261132598126 : Closed e2261132598126 ∧ code e2261132598126 = 11057225620334 := by decide
theorem cert_e2261132598126 : check e2261132598126 [[],[.under]] .three = true := by decide
def e2261132598134 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2261132598134 : Closed e2261132598134 ∧ code e2261132598134 = 11057225620342 := by decide
theorem cert_e2261132598134 : check e2261132598134 [[],[.under]] .three = true := by decide
def e2261132598198 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2261132598198 : Closed e2261132598198 ∧ code e2261132598198 = 11057225620406 := by decide
theorem cert_e2261132598198 : check e2261132598198 [[],[.under]] .three = true := by decide
def e2261132598638 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2261132598638 : Closed e2261132598638 ∧ code e2261132598638 = 11057225620846 := by decide
theorem cert_e2261132598638 : check e2261132598638 [[],[.under]] .three = true := by decide
def e2261132598646 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2261132598646 : Closed e2261132598646 ∧ code e2261132598646 = 11057225620854 := by decide
theorem cert_e2261132598646 : check e2261132598646 [[],[.under]] .three = true := by decide
def e2261132598702 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2261132598702 : Closed e2261132598702 ∧ code e2261132598702 = 11057225620910 := by decide
theorem cert_e2261132598702 : check e2261132598702 [[],[.under]] .three = true := by decide
def e2261132598714 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2261132598714 : Closed e2261132598714 ∧ code e2261132598714 = 11057225620922 := by decide
theorem cert_e2261132598714 : check e2261132598714 [[],[.under]] .three = true := by decide
def e2261132598742 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2261132598742 : Closed e2261132598742 ∧ code e2261132598742 = 11057225620950 := by decide
theorem cert_e2261132598742 : check e2261132598742 [[],[.under]] .three = true := by decide
def e2261132598746 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2261132598746 : Closed e2261132598746 ∧ code e2261132598746 = 11057225620954 := by decide
theorem cert_e2261132598746 : check e2261132598746 [[],[.under]] .three = true := by decide
def e2261132598966 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2261132598966 : Closed e2261132598966 ∧ code e2261132598966 = 11057225621174 := by decide
theorem cert_e2261132598966 : check e2261132598966 [[],[.under]] .three = true := by decide
def e2261132598998 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2261132598998 : Closed e2261132598998 ∧ code e2261132598998 = 11057225621206 := by decide
theorem cert_e2261132598998 : check e2261132598998 [[],[.under]] .three = true := by decide
def e2261132599002 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2261132599002 : Closed e2261132599002 ∧ code e2261132599002 = 11057225621210 := by decide
theorem cert_e2261132599002 : check e2261132599002 [[],[.under]] .three = true := by decide
def e2261132601198 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2261132601198 : Closed e2261132601198 ∧ code e2261132601198 = 11057225623406 := by decide
theorem cert_e2261132601198 : check e2261132601198 [[],[.under]] .three = true := by decide
def e2261132601206 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2261132601206 : Closed e2261132601206 ∧ code e2261132601206 = 11057225623414 := by decide
theorem cert_e2261132601206 : check e2261132601206 [[],[.under]] .three = true := by decide
def e2261132601270 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2261132601270 : Closed e2261132601270 ∧ code e2261132601270 = 11057225623478 := by decide
theorem cert_e2261132601270 : check e2261132601270 [[],[.under]] .three = true := by decide
def e2261132602606 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2261132602606 : Closed e2261132602606 ∧ code e2261132602606 = 11057225624814 := by decide
theorem cert_e2261132602606 : check e2261132602606 [[],[.under]] .three = true := by decide
def e2261132602614 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2261132602614 : Closed e2261132602614 ∧ code e2261132602614 = 11057225624822 := by decide
theorem cert_e2261132602614 : check e2261132602614 [[],[.under]] .three = true := by decide
def e2261132602998 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2261132602998 : Closed e2261132602998 ∧ code e2261132602998 = 11057225625206 := by decide
theorem cert_e2261132602998 : check e2261132602998 [[],[.under]] .three = true := by decide
def e2261132604270 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2261132604270 : Closed e2261132604270 ∧ code e2261132604270 = 11057225626478 := by decide
theorem cert_e2261132604270 : check e2261132604270 [[],[.under]] .three = true := by decide
def e2261132604278 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2261132604278 : Closed e2261132604278 ∧ code e2261132604278 = 11057225626486 := by decide
theorem cert_e2261132604278 : check e2261132604278 [[],[.under]] .three = true := by decide
def e2261132604334 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2261132604334 : Closed e2261132604334 ∧ code e2261132604334 = 11057225626542 := by decide
theorem cert_e2261132604334 : check e2261132604334 [[],[.under]] .three = true := by decide
def e2261132604346 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2261132604346 : Closed e2261132604346 ∧ code e2261132604346 = 11057225626554 := by decide
theorem cert_e2261132604346 : check e2261132604346 [[],[.under]] .three = true := by decide
def e2261132604374 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2261132604374 : Closed e2261132604374 ∧ code e2261132604374 = 11057225626582 := by decide
theorem cert_e2261132604374 : check e2261132604374 [[],[.under]] .three = true := by decide
def e2261132604378 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2261132604378 : Closed e2261132604378 ∧ code e2261132604378 = 11057225626586 := by decide
theorem cert_e2261132604378 : check e2261132604378 [[],[.under]] .three = true := by decide
def e2261132604654 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2261132604654 : Closed e2261132604654 ∧ code e2261132604654 = 11057225626862 := by decide
theorem cert_e2261132604654 : check e2261132604654 [[],[.under]] .three = true := by decide
def e2261132604662 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2261132604662 : Closed e2261132604662 ∧ code e2261132604662 = 11057225626870 := by decide
theorem cert_e2261132604662 : check e2261132604662 [[],[.under]] .three = true := by decide
def e2261132605038 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2261132605038 : Closed e2261132605038 ∧ code e2261132605038 = 11057225627246 := by decide
theorem cert_e2261132605038 : check e2261132605038 [[],[.under]] .three = true := by decide
def e2261132605050 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2261132605050 : Closed e2261132605050 ∧ code e2261132605050 = 11057225627258 := by decide
theorem cert_e2261132605050 : check e2261132605050 [[],[.under]] .three = true := by decide
def e2261132605238 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2261132605238 : Closed e2261132605238 ∧ code e2261132605238 = 11057225627446 := by decide
theorem cert_e2261132605238 : check e2261132605238 [[],[.under]] .three = true := by decide
def e2261132605242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2261132605242 : Closed e2261132605242 ∧ code e2261132605242 = 11057225627450 := by decide
theorem cert_e2261132605242 : check e2261132605242 [[],[.under]] .three = true := by decide
def e2261132605878 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2261132605878 : Closed e2261132605878 ∧ code e2261132605878 = 11057225628086 := by decide
theorem cert_e2261132605878 : check e2261132605878 [[],[.under]] .three = true := by decide
def e2261132605910 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2261132605910 : Closed e2261132605910 ∧ code e2261132605910 = 11057225628118 := by decide
theorem cert_e2261132605910 : check e2261132605910 [[],[.under]] .three = true := by decide
def e2261132605914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2261132605914 : Closed e2261132605914 ∧ code e2261132605914 = 11057225628122 := by decide
theorem cert_e2261132605914 : check e2261132605914 [[],[.under]] .three = true := by decide
def e2261132606070 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2261132606070 : Closed e2261132606070 ∧ code e2261132606070 = 11057225628278 := by decide
theorem cert_e2261132606070 : check e2261132606070 [[],[.under]] .three = true := by decide
def e2261132606262 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2261132606262 : Closed e2261132606262 ∧ code e2261132606262 = 11057225628470 := by decide
theorem cert_e2261132606262 : check e2261132606262 [[],[.under]] .three = true := by decide
def e2261132606266 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2261132606266 : Closed e2261132606266 ∧ code e2261132606266 = 11057225628474 := by decide
theorem cert_e2261132606266 : check e2261132606266 [[],[.under]] .three = true := by decide
def e2261132613486 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2261132613486 : Closed e2261132613486 ∧ code e2261132613486 = 11057225635694 := by decide
theorem cert_e2261132613486 : check e2261132613486 [[],[.under]] .three = true := by decide
def e2261132613494 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2261132613494 : Closed e2261132613494 ∧ code e2261132613494 = 11057225635702 := by decide
theorem cert_e2261132613494 : check e2261132613494 [[],[.under]] .three = true := by decide
def e2261132613558 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2261132613558 : Closed e2261132613558 ∧ code e2261132613558 = 11057225635766 := by decide
theorem cert_e2261132613558 : check e2261132613558 [[],[.under]] .three = true := by decide
def e2261132614894 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2261132614894 : Closed e2261132614894 ∧ code e2261132614894 = 11057225637102 := by decide
theorem cert_e2261132614894 : check e2261132614894 [[],[.under]] .three = true := by decide
def e2261132614902 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2261132614902 : Closed e2261132614902 ∧ code e2261132614902 = 11057225637110 := by decide
theorem cert_e2261132614902 : check e2261132614902 [[],[.under]] .three = true := by decide
def e2261132615286 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2261132615286 : Closed e2261132615286 ∧ code e2261132615286 = 11057225637494 := by decide
theorem cert_e2261132615286 : check e2261132615286 [[],[.under]] .three = true := by decide
def e2261132626798 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2261132626798 : Closed e2261132626798 ∧ code e2261132626798 = 11057225649006 := by decide
theorem cert_e2261132626798 : check e2261132626798 [[],[.under]] .three = true := by decide
def e2261132626806 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2261132626806 : Closed e2261132626806 ∧ code e2261132626806 = 11057225649014 := by decide
theorem cert_e2261132626806 : check e2261132626806 [[],[.under]] .three = true := by decide
def e2261132626862 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2261132626862 : Closed e2261132626862 ∧ code e2261132626862 = 11057225649070 := by decide
theorem cert_e2261132626862 : check e2261132626862 [[],[.under]] .three = true := by decide
def e2261132626874 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2261132626874 : Closed e2261132626874 ∧ code e2261132626874 = 11057225649082 := by decide
theorem cert_e2261132626874 : check e2261132626874 [[],[.under]] .three = true := by decide
def e2261132626902 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2261132626902 : Closed e2261132626902 ∧ code e2261132626902 = 11057225649110 := by decide
theorem cert_e2261132626902 : check e2261132626902 [[],[.under]] .three = true := by decide
def e2261132626906 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2261132626906 : Closed e2261132626906 ∧ code e2261132626906 = 11057225649114 := by decide
theorem cert_e2261132626906 : check e2261132626906 [[],[.under]] .three = true := by decide
def e2261132627182 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2261132627182 : Closed e2261132627182 ∧ code e2261132627182 = 11057225649390 := by decide
theorem cert_e2261132627182 : check e2261132627182 [[],[.under]] .three = true := by decide
def e2261132627190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2261132627190 : Closed e2261132627190 ∧ code e2261132627190 = 11057225649398 := by decide
theorem cert_e2261132627190 : check e2261132627190 [[],[.under]] .three = true := by decide
def e2261132627566 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2261132627566 : Closed e2261132627566 ∧ code e2261132627566 = 11057225649774 := by decide
theorem cert_e2261132627566 : check e2261132627566 [[],[.under]] .three = true := by decide
def e2261132627578 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2261132627578 : Closed e2261132627578 ∧ code e2261132627578 = 11057225649786 := by decide
theorem cert_e2261132627578 : check e2261132627578 [[],[.under]] .three = true := by decide
def e2261132627766 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2261132627766 : Closed e2261132627766 ∧ code e2261132627766 = 11057225649974 := by decide
theorem cert_e2261132627766 : check e2261132627766 [[],[.under]] .three = true := by decide
def e2261132627770 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2261132627770 : Closed e2261132627770 ∧ code e2261132627770 = 11057225649978 := by decide
theorem cert_e2261132627770 : check e2261132627770 [[],[.under]] .three = true := by decide
def e2261132633526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2261132633526 : Closed e2261132633526 ∧ code e2261132633526 = 11057225655734 := by decide
theorem cert_e2261132633526 : check e2261132633526 [[],[.under]] .three = true := by decide
def e2261132633558 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2261132633558 : Closed e2261132633558 ∧ code e2261132633558 = 11057225655766 := by decide
theorem cert_e2261132633558 : check e2261132633558 [[],[.under]] .three = true := by decide
def e2261132633562 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2261132633562 : Closed e2261132633562 ∧ code e2261132633562 = 11057225655770 := by decide
theorem cert_e2261132633562 : check e2261132633562 [[],[.under]] .three = true := by decide
def e2261132633718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2261132633718 : Closed e2261132633718 ∧ code e2261132633718 = 11057225655926 := by decide
theorem cert_e2261132633718 : check e2261132633718 [[],[.under]] .three = true := by decide
def e2261132633910 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2261132633910 : Closed e2261132633910 ∧ code e2261132633910 = 11057225656118 := by decide
theorem cert_e2261132633910 : check e2261132633910 [[],[.under]] .three = true := by decide
def e2261132633914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2261132633914 : Closed e2261132633914 ∧ code e2261132633914 = 11057225656122 := by decide
theorem cert_e2261132633914 : check e2261132633914 [[],[.under]] .three = true := by decide
def e2261132970862 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2261132970862 : Closed e2261132970862 ∧ code e2261132970862 = 11057225993070 := by decide
theorem cert_e2261132970862 : check e2261132970862 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132970870 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2261132970870 : Closed e2261132970870 ∧ code e2261132970870 = 11057225993078 := by decide
private def t_e2261132970870 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2261132970870 : ¬ IsSelfInterpreter e2261132970870 :=
  wSource (t := t_e2261132970870) (replay_sound (ps := []) (t := e2261132970870) (by decide)) (by decide)
def e2261132970926 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2261132970926 : Closed e2261132970926 ∧ code e2261132970926 = 11057225993134 := by decide
theorem cert_e2261132970926 : check e2261132970926 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132970938 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2261132970938 : Closed e2261132970938 ∧ code e2261132970938 = 11057225993146 := by decide
theorem cert_e2261132970938 : check e2261132970938 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132970966 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2261132970966 : Closed e2261132970966 ∧ code e2261132970966 = 11057225993174 := by decide
private def t_e2261132970966 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2261132970966 : ¬ IsSelfInterpreter e2261132970966 :=
  wSource (t := t_e2261132970966) (replay_sound (ps := []) (t := e2261132970966) (by decide)) (by decide)
def e2261132970970 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2261132970970 : Closed e2261132970970 ∧ code e2261132970970 = 11057225993178 := by decide
theorem cert_e2261132970970 : check e2261132970970 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132971246 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2261132971246 : Closed e2261132971246 ∧ code e2261132971246 = 11057225993454 := by decide
theorem cert_e2261132971246 : check e2261132971246 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132971254 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2261132971254 : Closed e2261132971254 ∧ code e2261132971254 = 11057225993462 := by decide
theorem cert_e2261132971254 : check e2261132971254 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132971630 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2261132971630 : Closed e2261132971630 ∧ code e2261132971630 = 11057225993838 := by decide
theorem cert_e2261132971630 : check e2261132971630 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132971642 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2261132971642 : Closed e2261132971642 ∧ code e2261132971642 = 11057225993850 := by decide
theorem cert_e2261132971642 : check e2261132971642 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132971830 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2261132971830 : Closed e2261132971830 ∧ code e2261132971830 = 11057225994038 := by decide
theorem cert_e2261132971830 : check e2261132971830 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2261132971834 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2261132971834 : Closed e2261132971834 ∧ code e2261132971834 = 11057225994042 := by decide
theorem cert_e2261132971834 : check e2261132971834 [[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2262374067566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2262374067566 : Closed e2262374067566 ∧ code e2262374067566 = 11058467089774 := by decide
theorem cert_e2262374067566 : check e2262374067566 [[],[.under]] .smaller = true := by decide
def e2262374067574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2262374067574 : Closed e2262374067574 ∧ code e2262374067574 = 11058467089782 := by decide
theorem cert_e2262374067574 : check e2262374067574 [[],[.under]] .smaller = true := by decide
def e2262374067630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2262374067630 : Closed e2262374067630 ∧ code e2262374067630 = 11058467089838 := by decide
theorem cert_e2262374067630 : check e2262374067630 [[],[.under]] .smaller = true := by decide
def e2262374067642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2262374067642 : Closed e2262374067642 ∧ code e2262374067642 = 11058467089850 := by decide
theorem cert_e2262374067642 : check e2262374067642 [[],[.under]] .smaller = true := by decide
def e2262374067670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2262374067670 : Closed e2262374067670 ∧ code e2262374067670 = 11058467089878 := by decide
theorem cert_e2262374067670 : check e2262374067670 [[],[.under]] .smaller = true := by decide
def e2262374067674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2262374067674 : Closed e2262374067674 ∧ code e2262374067674 = 11058467089882 := by decide
theorem cert_e2262374067674 : check e2262374067674 [[],[.under]] .smaller = true := by decide
def e2262374067886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2262374067886 : Closed e2262374067886 ∧ code e2262374067886 = 11058467090094 := by decide
theorem cert_e2262374067886 : check e2262374067886 [[],[.under]] .smaller = true := by decide
def e2262374067898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2262374067898 : Closed e2262374067898 ∧ code e2262374067898 = 11058467090106 := by decide
theorem cert_e2262374067898 : check e2262374067898 [[],[.under]] .smaller = true := by decide
def e2262374067946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2262374067946 : Closed e2262374067946 ∧ code e2262374067946 = 11058467090154 := by decide
theorem cert_e2262374067946 : check e2262374067946 [[],[.under]] .smaller = true := by decide
def e2262374068054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2262374068054 : Closed e2262374068054 ∧ code e2262374068054 = 11058467090262 := by decide
theorem cert_e2262374068054 : check e2262374068054 [[],[.under]] .smaller = true := by decide
def e2262374068058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2262374068058 : Closed e2262374068058 ∧ code e2262374068058 = 11058467090266 := by decide
theorem cert_e2262374068058 : check e2262374068058 [[],[.under]] .smaller = true := by decide
def e2262374068074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2262374068074 : Closed e2262374068074 ∧ code e2262374068074 = 11058467090282 := by decide
theorem cert_e2262374068074 : check e2262374068074 [[],[.under]] .smaller = true := by decide
def e2262374069102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2262374069102 : Closed e2262374069102 ∧ code e2262374069102 = 11058467091310 := by decide
theorem cert_e2262374069102 : check e2262374069102 [[],[.under]] .smaller = true := by decide
def e2262374069110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2262374069110 : Closed e2262374069110 ∧ code e2262374069110 = 11058467091318 := by decide
theorem cert_e2262374069110 : check e2262374069110 [[],[.under]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2261132970870
#print axioms Blc.Floor43.cert_e2261132970966
