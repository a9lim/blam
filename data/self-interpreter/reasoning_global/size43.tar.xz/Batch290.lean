import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411624598446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2411624598446 : Closed e2411624598446 ∧ code e2411624598446 = 11207717620654 := by decide
theorem cert_e2411624598446 : check e2411624598446 [[],[]] .smaller = true := by decide
def e2411624598458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2411624598458 : Closed e2411624598458 ∧ code e2411624598458 = 11207717620666 := by decide
theorem cert_e2411624598458 : check e2411624598458 [[],[]] .smaller = true := by decide
def e2411624598486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2411624598486 : Closed e2411624598486 ∧ code e2411624598486 = 11207717620694 := by decide
theorem cert_e2411624598486 : check e2411624598486 [[],[]] .smaller = true := by decide
def e2411624598490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2411624598490 : Closed e2411624598490 ∧ code e2411624598490 = 11207717620698 := by decide
theorem cert_e2411624598490 : check e2411624598490 [[],[]] .smaller = true := by decide
def e2411624598766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2411624598766 : Closed e2411624598766 ∧ code e2411624598766 = 11207717620974 := by decide
theorem cert_e2411624598766 : check e2411624598766 [[],[]] .smaller = true := by decide
def e2411624598774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2411624598774 : Closed e2411624598774 ∧ code e2411624598774 = 11207717620982 := by decide
theorem cert_e2411624598774 : check e2411624598774 [[],[]] .smaller = true := by decide
def e2411624599150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2411624599150 : Closed e2411624599150 ∧ code e2411624599150 = 11207717621358 := by decide
theorem cert_e2411624599150 : check e2411624599150 [[],[]] .smaller = true := by decide
def e2411624599162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2411624599162 : Closed e2411624599162 ∧ code e2411624599162 = 11207717621370 := by decide
theorem cert_e2411624599162 : check e2411624599162 [[],[]] .smaller = true := by decide
def e2411624599350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2411624599350 : Closed e2411624599350 ∧ code e2411624599350 = 11207717621558 := by decide
theorem cert_e2411624599350 : check e2411624599350 [[],[]] .smaller = true := by decide
def e2411624599354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2411624599354 : Closed e2411624599354 ∧ code e2411624599354 = 11207717621562 := by decide
theorem cert_e2411624599354 : check e2411624599354 [[],[]] .smaller = true := by decide
def e2411624606830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2411624606830 : Closed e2411624606830 ∧ code e2411624606830 = 11207717629038 := by decide
theorem cert_e2411624606830 : check e2411624606830 [[],[]] .smaller = true := by decide
def e2411624606842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2411624606842 : Closed e2411624606842 ∧ code e2411624606842 = 11207717629050 := by decide
theorem cert_e2411624606842 : check e2411624606842 [[],[]] .smaller = true := by decide
def e2411624607006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2411624607006 : Closed e2411624607006 ∧ code e2411624607006 = 11207717629214 := by decide
theorem cert_e2411624607006 : check e2411624607006 [[],[]] .smaller = true := by decide
def e2411624607166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2411624607166 : Closed e2411624607166 ∧ code e2411624607166 = 11207717629374 := by decide
theorem cert_e2411624607166 : check e2411624607166 [[],[]] .three = true := by decide
def e2411624607174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2411624607174 : Closed e2411624607174 ∧ code e2411624607174 = 11207717629382 := by decide
theorem cert_e2411624607174 : check e2411624607174 [[],[]] .smaller = true := by decide
def e2411624607222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2411624607222 : Closed e2411624607222 ∧ code e2411624607222 = 11207717629430 := by decide
theorem cert_e2411624607222 : check e2411624607222 [[],[]] .three = true := by decide
def e2411624607422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2411624607422 : Closed e2411624607422 ∧ code e2411624607422 = 11207717629630 := by decide
theorem cert_e2411624607422 : check e2411624607422 [[],[]] .three = true := by decide
def e2411624607482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2411624607482 : Closed e2411624607482 ∧ code e2411624607482 = 11207717629690 := by decide
theorem cert_e2411624607482 : check e2411624607482 [[],[]] .three = true := by decide
def e2411624607514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2411624607514 : Closed e2411624607514 ∧ code e2411624607514 = 11207717629722 := by decide
theorem cert_e2411624607514 : check e2411624607514 [[],[]] .smaller = true := by decide
def e2411624607558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2411624607558 : Closed e2411624607558 ∧ code e2411624607558 = 11207717629766 := by decide
theorem cert_e2411624607558 : check e2411624607558 [[],[]] .smaller = true := by decide
def e2411624607702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2411624607702 : Closed e2411624607702 ∧ code e2411624607702 = 11207717629910 := by decide
theorem cert_e2411624607702 : check e2411624607702 [[],[]] .three = true := by decide
def e2411624607706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2411624607706 : Closed e2411624607706 ∧ code e2411624607706 = 11207717629914 := by decide
theorem cert_e2411624607706 : check e2411624607706 [[],[]] .three = true := by decide
def e2411624608542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2411624608542 : Closed e2411624608542 ∧ code e2411624608542 = 11207717630750 := by decide
theorem cert_e2411624608542 : check e2411624608542 [[],[]] .smaller = true := by decide
def e2411624608702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2411624608702 : Closed e2411624608702 ∧ code e2411624608702 = 11207717630910 := by decide
theorem cert_e2411624608702 : check e2411624608702 [[],[]] .three = true := by decide
def e2411624608710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2411624608710 : Closed e2411624608710 ∧ code e2411624608710 = 11207717630918 := by decide
theorem cert_e2411624608710 : check e2411624608710 [[],[]] .smaller = true := by decide
def e2411624608758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2411624608758 : Closed e2411624608758 ∧ code e2411624608758 = 11207717630966 := by decide
theorem cert_e2411624608758 : check e2411624608758 [[],[]] .three = true := by decide
def e2411624610238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2411624610238 : Closed e2411624610238 ∧ code e2411624610238 = 11207717632446 := by decide
theorem cert_e2411624610238 : check e2411624610238 [[],[]] .three = true := by decide
def e2411624610298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2411624610298 : Closed e2411624610298 ∧ code e2411624610298 = 11207717632506 := by decide
theorem cert_e2411624610298 : check e2411624610298 [[],[]] .three = true := by decide
def e2411624611014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2411624611014 : Closed e2411624611014 ∧ code e2411624611014 = 11207717633222 := by decide
theorem cert_e2411624611014 : check e2411624611014 [[],[]] .smaller = true := by decide
def e2411624611638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411624611638 : Closed e2411624611638 ∧ code e2411624611638 = 11207717633846 := by decide
theorem cert_e2411624611638 : check e2411624611638 [[],[]] .three = true := by decide
def e2411624611642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411624611642 : Closed e2411624611642 ∧ code e2411624611642 = 11207717633850 := by decide
theorem cert_e2411624611642 : check e2411624611642 [[],[]] .three = true := by decide
def e2411624633910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2411624633910 : Closed e2411624633910 ∧ code e2411624633910 = 11207717656118 := by decide
theorem cert_e2411624633910 : check e2411624633910 [[],[]] .smaller = true := by decide
def e2411624633914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2411624633914 : Closed e2411624633914 ∧ code e2411624633914 = 11207717656122 := by decide
theorem cert_e2411624633914 : check e2411624633914 [[],[]] .smaller = true := by decide
def e2411624633998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2411624633998 : Closed e2411624633998 ∧ code e2411624633998 = 11207717656206 := by decide
theorem cert_e2411624633998 : check e2411624633998 [[],[]] .smaller = true := by decide
def e2411624634046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2411624634046 : Closed e2411624634046 ∧ code e2411624634046 = 11207717656254 := by decide
theorem cert_e2411624634046 : check e2411624634046 [[],[]] .three = true := by decide
def e2411624634054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2411624634054 : Closed e2411624634054 ∧ code e2411624634054 = 11207717656262 := by decide
theorem cert_e2411624634054 : check e2411624634054 [[],[]] .smaller = true := by decide
def e2411624634106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2411624634106 : Closed e2411624634106 ∧ code e2411624634106 = 11207717656314 := by decide
theorem cert_e2411624634106 : check e2411624634106 [[],[]] .three = true := by decide
def e2411624634138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2411624634138 : Closed e2411624634138 ∧ code e2411624634138 = 11207717656346 := by decide
theorem cert_e2411624634138 : check e2411624634138 [[],[]] .smaller = true := by decide
def e2411624634182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2411624634182 : Closed e2411624634182 ∧ code e2411624634182 = 11207717656390 := by decide
theorem cert_e2411624634182 : check e2411624634182 [[],[]] .smaller = true := by decide
def e2411624634346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2411624634346 : Closed e2411624634346 ∧ code e2411624634346 = 11207717656554 := by decide
theorem cert_e2411624634346 : check e2411624634346 [[],[]] .three = true := by decide
def e2411624634766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2411624634766 : Closed e2411624634766 ∧ code e2411624634766 = 11207717656974 := by decide
theorem cert_e2411624634766 : check e2411624634766 [[],[]] .smaller = true := by decide
def e2411624634814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2411624634814 : Closed e2411624634814 ∧ code e2411624634814 = 11207717657022 := by decide
theorem cert_e2411624634814 : check e2411624634814 [[],[]] .three = true := by decide
def e2411624634822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2411624634822 : Closed e2411624634822 ∧ code e2411624634822 = 11207717657030 := by decide
theorem cert_e2411624634822 : check e2411624634822 [[],[]] .smaller = true := by decide
def e2411624634874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2411624634874 : Closed e2411624634874 ∧ code e2411624634874 = 11207717657082 := by decide
theorem cert_e2411624634874 : check e2411624634874 [[],[]] .three = true := by decide
def e2411624635590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2411624635590 : Closed e2411624635590 ∧ code e2411624635590 = 11207717657798 := by decide
theorem cert_e2411624635590 : check e2411624635590 [[],[]] .smaller = true := by decide
def e2411624636314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411624636314 : Closed e2411624636314 ∧ code e2411624636314 = 11207717658522 := by decide
theorem cert_e2411624636314 : check e2411624636314 [[],[]] .three = true := by decide
def e2411624654254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2411624654254 : Closed e2411624654254 ∧ code e2411624654254 = 11207717676462 := by decide
theorem cert_e2411624654254 : check e2411624654254 [[],[]] .three = true := by decide
def e2411624654262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2411624654262 : Closed e2411624654262 ∧ code e2411624654262 = 11207717676470 := by decide
theorem cert_e2411624654262 : check e2411624654262 [[],[]] .three = true := by decide
def e2411624654266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2411624654266 : Closed e2411624654266 ∧ code e2411624654266 = 11207717676474 := by decide
theorem cert_e2411624654266 : check e2411624654266 [[],[]] .three = true := by decide
def e2411624654294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2411624654294 : Closed e2411624654294 ∧ code e2411624654294 = 11207717676502 := by decide
theorem cert_e2411624654294 : check e2411624654294 [[],[]] .three = true := by decide
def e2411624654298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2411624654298 : Closed e2411624654298 ∧ code e2411624654298 = 11207717676506 := by decide
theorem cert_e2411624654298 : check e2411624654298 [[],[]] .three = true := by decide
def e2411624654314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2411624654314 : Closed e2411624654314 ∧ code e2411624654314 = 11207717676522 := by decide
theorem cert_e2411624654314 : check e2411624654314 [[],[]] .three = true := by decide
def e2411624654446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411624654446 : Closed e2411624654446 ∧ code e2411624654446 = 11207717676654 := by decide
theorem cert_e2411624654446 : check e2411624654446 [[],[]] .three = true := by decide
def e2411624654454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411624654454 : Closed e2411624654454 ∧ code e2411624654454 = 11207717676662 := by decide
theorem cert_e2411624654454 : check e2411624654454 [[],[]] .three = true := by decide
def e2411624654458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411624654458 : Closed e2411624654458 ∧ code e2411624654458 = 11207717676666 := by decide
theorem cert_e2411624654458 : check e2411624654458 [[],[]] .three = true := by decide
def e2411624654646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411624654646 : Closed e2411624654646 ∧ code e2411624654646 = 11207717676854 := by decide
theorem cert_e2411624654646 : check e2411624654646 [[],[]] .three = true := by decide
def e2411624654650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411624654650 : Closed e2411624654650 ∧ code e2411624654650 = 11207717676858 := by decide
theorem cert_e2411624654650 : check e2411624654650 [[],[]] .three = true := by decide
def e2411624654746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411624654746 : Closed e2411624654746 ∧ code e2411624654746 = 11207717676954 := by decide
theorem cert_e2411624654746 : check e2411624654746 [[],[]] .three = true := by decide
def e2411625540318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2411625540318 : Closed e2411625540318 ∧ code e2411625540318 = 11207718562526 := by decide
theorem cert_e2411625540318 : check e2411625540318 [[],[]] .three = true := by decide
def e2411625540342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2411625540342 : Closed e2411625540342 ∧ code e2411625540342 = 11207718562550 := by decide
theorem cert_e2411625540342 : check e2411625540342 [[],[]] .three = true := by decide
def e2411625540446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2411625540446 : Closed e2411625540446 ∧ code e2411625540446 = 11207718562654 := by decide
theorem cert_e2411625540446 : check e2411625540446 [[],[]] .three = true := by decide
def e2411625540462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2411625540462 : Closed e2411625540462 ∧ code e2411625540462 = 11207718562670 := by decide
theorem cert_e2411625540462 : check e2411625540462 [[],[]] .smaller = true := by decide
def e2411625540470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2411625540470 : Closed e2411625540470 ∧ code e2411625540470 = 11207718562678 := by decide
theorem cert_e2411625540470 : check e2411625540470 [[],[]] .smaller = true := by decide
def e2411625540474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2411625540474 : Closed e2411625540474 ∧ code e2411625540474 = 11207718562682 := by decide
theorem cert_e2411625540474 : check e2411625540474 [[],[]] .three = true := by decide
def e2411625540534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2411625540534 : Closed e2411625540534 ∧ code e2411625540534 = 11207718562742 := by decide
theorem cert_e2411625540534 : check e2411625540534 [[],[]] .smaller = true := by decide
def e2411625540566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2411625540566 : Closed e2411625540566 ∧ code e2411625540566 = 11207718562774 := by decide
theorem cert_e2411625540566 : check e2411625540566 [[],[]] .three = true := by decide
def e2411625540570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2411625540570 : Closed e2411625540570 ∧ code e2411625540570 = 11207718562778 := by decide
theorem cert_e2411625540570 : check e2411625540570 [[],[]] .three = true := by decide
def e2411625540958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2411625540958 : Closed e2411625540958 ∧ code e2411625540958 = 11207718563166 := by decide
theorem cert_e2411625540958 : check e2411625540958 [[],[]] .three = true := by decide
def e2411625540974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2411625540974 : Closed e2411625540974 ∧ code e2411625540974 = 11207718563182 := by decide
theorem cert_e2411625540974 : check e2411625540974 [[],[]] .smaller = true := by decide
def e2411625540982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2411625540982 : Closed e2411625540982 ∧ code e2411625540982 = 11207718563190 := by decide
theorem cert_e2411625540982 : check e2411625540982 [[],[]] .smaller = true := by decide
def e2411625540986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2411625540986 : Closed e2411625540986 ∧ code e2411625540986 = 11207718563194 := by decide
theorem cert_e2411625540986 : check e2411625540986 [[],[]] .three = true := by decide
def e2411625541038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2411625541038 : Closed e2411625541038 ∧ code e2411625541038 = 11207718563246 := by decide
theorem cert_e2411625541038 : check e2411625541038 [[],[]] .smaller = true := by decide
def e2411625541050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2411625541050 : Closed e2411625541050 ∧ code e2411625541050 = 11207718563258 := by decide
theorem cert_e2411625541050 : check e2411625541050 [[],[]] .smaller = true := by decide
def e2411625541078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2411625541078 : Closed e2411625541078 ∧ code e2411625541078 = 11207718563286 := by decide
theorem cert_e2411625541078 : check e2411625541078 [[],[]] .smaller = true := by decide
def e2411625541082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2411625541082 : Closed e2411625541082 ∧ code e2411625541082 = 11207718563290 := by decide
theorem cert_e2411625541082 : check e2411625541082 [[],[]] .smaller = true := by decide
def e2411625541098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2411625541098 : Closed e2411625541098 ∧ code e2411625541098 = 11207718563306 := by decide
theorem cert_e2411625541098 : check e2411625541098 [[],[]] .three = true := by decide
def e2411625541302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2411625541302 : Closed e2411625541302 ∧ code e2411625541302 = 11207718563510 := by decide
theorem cert_e2411625541302 : check e2411625541302 [[],[]] .smaller = true := by decide
def e2411625541334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2411625541334 : Closed e2411625541334 ∧ code e2411625541334 = 11207718563542 := by decide
theorem cert_e2411625541334 : check e2411625541334 [[],[]] .smaller = true := by decide
def e2411625541338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2411625541338 : Closed e2411625541338 ∧ code e2411625541338 = 11207718563546 := by decide
theorem cert_e2411625541338 : check e2411625541338 [[],[]] .smaller = true := by decide
def e2411625541462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2411625541462 : Closed e2411625541462 ∧ code e2411625541462 = 11207718563670 := by decide
theorem cert_e2411625541462 : check e2411625541462 [[],[]] .three = true := by decide
def e2411625541466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2411625541466 : Closed e2411625541466 ∧ code e2411625541466 = 11207718563674 := by decide
theorem cert_e2411625541466 : check e2411625541466 [[],[]] .three = true := by decide
def e2411625541482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2411625541482 : Closed e2411625541482 ∧ code e2411625541482 = 11207718563690 := by decide
theorem cert_e2411625541482 : check e2411625541482 [[],[]] .three = true := by decide
def e2411625543006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2411625543006 : Closed e2411625543006 ∧ code e2411625543006 = 11207718565214 := by decide
theorem cert_e2411625543006 : check e2411625543006 [[],[]] .three = true := by decide
def e2411625543022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2411625543022 : Closed e2411625543022 ∧ code e2411625543022 = 11207718565230 := by decide
theorem cert_e2411625543022 : check e2411625543022 [[],[]] .smaller = true := by decide
def e2411625543030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2411625543030 : Closed e2411625543030 ∧ code e2411625543030 = 11207718565238 := by decide
theorem cert_e2411625543030 : check e2411625543030 [[],[]] .smaller = true := by decide
def e2411625543034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2411625543034 : Closed e2411625543034 ∧ code e2411625543034 = 11207718565242 := by decide
theorem cert_e2411625543034 : check e2411625543034 [[],[]] .three = true := by decide
def e2411625543086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2411625543086 : Closed e2411625543086 ∧ code e2411625543086 = 11207718565294 := by decide
theorem cert_e2411625543086 : check e2411625543086 [[],[]] .smaller = true := by decide
def e2411625543098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2411625543098 : Closed e2411625543098 ∧ code e2411625543098 = 11207718565306 := by decide
theorem cert_e2411625543098 : check e2411625543098 [[],[]] .smaller = true := by decide
def e2411625543126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2411625543126 : Closed e2411625543126 ∧ code e2411625543126 = 11207718565334 := by decide
theorem cert_e2411625543126 : check e2411625543126 [[],[]] .smaller = true := by decide
def e2411625543130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2411625543130 : Closed e2411625543130 ∧ code e2411625543130 = 11207718565338 := by decide
theorem cert_e2411625543130 : check e2411625543130 [[],[]] .smaller = true := by decide
def e2411625543146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2411625543146 : Closed e2411625543146 ∧ code e2411625543146 = 11207718565354 := by decide
theorem cert_e2411625543146 : check e2411625543146 [[],[]] .three = true := by decide
def e2411625543342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2411625543342 : Closed e2411625543342 ∧ code e2411625543342 = 11207718565550 := by decide
theorem cert_e2411625543342 : check e2411625543342 [[],[]] .smaller = true := by decide
def e2411625543354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2411625543354 : Closed e2411625543354 ∧ code e2411625543354 = 11207718565562 := by decide
theorem cert_e2411625543354 : check e2411625543354 [[],[]] .smaller = true := by decide
def e2411625543402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2411625543402 : Closed e2411625543402 ∧ code e2411625543402 = 11207718565610 := by decide
theorem cert_e2411625543402 : check e2411625543402 [[],[]] .smaller = true := by decide
def e2411625543510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2411625543510 : Closed e2411625543510 ∧ code e2411625543510 = 11207718565718 := by decide
theorem cert_e2411625543510 : check e2411625543510 [[],[]] .smaller = true := by decide
def e2411625543514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2411625543514 : Closed e2411625543514 ∧ code e2411625543514 = 11207718565722 := by decide
theorem cert_e2411625543514 : check e2411625543514 [[],[]] .smaller = true := by decide
def e2411625543530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2411625543530 : Closed e2411625543530 ∧ code e2411625543530 = 11207718565738 := by decide
theorem cert_e2411625543530 : check e2411625543530 [[],[]] .smaller = true := by decide
def e2411625543594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2411625543594 : Closed e2411625543594 ∧ code e2411625543594 = 11207718565802 := by decide
theorem cert_e2411625543594 : check e2411625543594 [[],[]] .three = true := by decide
def e2411625544374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2411625544374 : Closed e2411625544374 ∧ code e2411625544374 = 11207718566582 := by decide
theorem cert_e2411625544374 : check e2411625544374 [[],[]] .smaller = true := by decide
def e2411625544406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2411625544406 : Closed e2411625544406 ∧ code e2411625544406 = 11207718566614 := by decide
theorem cert_e2411625544406 : check e2411625544406 [[],[]] .smaller = true := by decide
def e2411625544410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2411625544410 : Closed e2411625544410 ∧ code e2411625544410 = 11207718566618 := by decide
theorem cert_e2411625544410 : check e2411625544410 [[],[]] .smaller = true := by decide
def e2411625544534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2411625544534 : Closed e2411625544534 ∧ code e2411625544534 = 11207718566742 := by decide
theorem cert_e2411625544534 : check e2411625544534 [[],[]] .smaller = true := by decide
def e2411625544538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2411625544538 : Closed e2411625544538 ∧ code e2411625544538 = 11207718566746 := by decide
theorem cert_e2411625544538 : check e2411625544538 [[],[]] .smaller = true := by decide
def e2411625544554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2411625544554 : Closed e2411625544554 ∧ code e2411625544554 = 11207718566762 := by decide
theorem cert_e2411625544554 : check e2411625544554 [[],[]] .smaller = true := by decide
def e2411625545046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2411625545046 : Closed e2411625545046 ∧ code e2411625545046 = 11207718567254 := by decide
theorem cert_e2411625545046 : check e2411625545046 [[],[]] .three = true := by decide
def e2411625545050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2411625545050 : Closed e2411625545050 ∧ code e2411625545050 = 11207718567258 := by decide
theorem cert_e2411625545050 : check e2411625545050 [[],[]] .three = true := by decide
def e2411625545066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2411625545066 : Closed e2411625545066 ∧ code e2411625545066 = 11207718567274 := by decide
theorem cert_e2411625545066 : check e2411625545066 [[],[]] .three = true := by decide
def e2411625545130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2411625545130 : Closed e2411625545130 ∧ code e2411625545130 = 11207718567338 := by decide
theorem cert_e2411625545130 : check e2411625545130 [[],[]] .three = true := by decide
def e2411625549278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e2411625549278 : Closed e2411625549278 ∧ code e2411625549278 = 11207718571486 := by decide
theorem cert_e2411625549278 : check e2411625549278 [[],[]] .three = true := by decide
def e2411625549294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e2411625549294 : Closed e2411625549294 ∧ code e2411625549294 = 11207718571502 := by decide
theorem cert_e2411625549294 : check e2411625549294 [[],[]] .three = true := by decide
def e2411625549534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e2411625549534 : Closed e2411625549534 ∧ code e2411625549534 = 11207718571742 := by decide
theorem cert_e2411625549534 : check e2411625549534 [[],[]] .three = true := by decide
def e2411625549550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e2411625549550 : Closed e2411625549550 ∧ code e2411625549550 = 11207718571758 := by decide
theorem cert_e2411625549550 : check e2411625549550 [[],[]] .smaller = true := by decide
def e2411625549558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e2411625549558 : Closed e2411625549558 ∧ code e2411625549558 = 11207718571766 := by decide
theorem cert_e2411625549558 : check e2411625549558 [[],[]] .three = true := by decide
def e2411625549662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 3)))))))
theorem wire_e2411625549662 : Closed e2411625549662 ∧ code e2411625549662 = 11207718571870 := by decide
theorem cert_e2411625549662 : check e2411625549662 [[],[]] .three = true := by decide
def e2411625549678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e2411625549678 : Closed e2411625549678 ∧ code e2411625549678 = 11207718571886 := by decide
theorem cert_e2411625549678 : check e2411625549678 [[],[]] .smaller = true := by decide
def e2411625549686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e2411625549686 : Closed e2411625549686 ∧ code e2411625549686 = 11207718571894 := by decide
theorem cert_e2411625549686 : check e2411625549686 [[],[]] .smaller = true := by decide
def e2411625549690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 3)) (.var 0)))))))
theorem wire_e2411625549690 : Closed e2411625549690 ∧ code e2411625549690 = 11207718571898 := by decide
theorem cert_e2411625549690 : check e2411625549690 [[],[]] .three = true := by decide
def e2411625549742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 2)))))))
theorem wire_e2411625549742 : Closed e2411625549742 ∧ code e2411625549742 = 11207718571950 := by decide
theorem cert_e2411625549742 : check e2411625549742 [[],[]] .three = true := by decide
def e2411625549750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 1)))))))
theorem wire_e2411625549750 : Closed e2411625549750 ∧ code e2411625549750 = 11207718571958 := by decide
theorem cert_e2411625549750 : check e2411625549750 [[],[]] .three = true := by decide
def e2411625549754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 2)) (.var 0)))))))
theorem wire_e2411625549754 : Closed e2411625549754 ∧ code e2411625549754 = 11207718571962 := by decide
theorem cert_e2411625549754 : check e2411625549754 [[],[]] .three = true := by decide
def e2411625552606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e2411625552606 : Closed e2411625552606 ∧ code e2411625552606 = 11207718574814 := by decide
theorem cert_e2411625552606 : check e2411625552606 [[],[]] .three = true := by decide
def e2411625552630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e2411625552630 : Closed e2411625552630 ∧ code e2411625552630 = 11207718574838 := by decide
theorem cert_e2411625552630 : check e2411625552630 [[],[]] .three = true := by decide
def e2411625552734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2411625552734 : Closed e2411625552734 ∧ code e2411625552734 = 11207718574942 := by decide
theorem cert_e2411625552734 : check e2411625552734 [[],[]] .three = true := by decide
def e2411625552750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2411625552750 : Closed e2411625552750 ∧ code e2411625552750 = 11207718574958 := by decide
theorem cert_e2411625552750 : check e2411625552750 [[],[]] .smaller = true := by decide
def e2411625552758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2411625552758 : Closed e2411625552758 ∧ code e2411625552758 = 11207718574966 := by decide
theorem cert_e2411625552758 : check e2411625552758 [[],[]] .smaller = true := by decide
def e2411625552762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2411625552762 : Closed e2411625552762 ∧ code e2411625552762 = 11207718574970 := by decide
theorem cert_e2411625552762 : check e2411625552762 [[],[]] .three = true := by decide
def e2411625552822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e2411625552822 : Closed e2411625552822 ∧ code e2411625552822 = 11207718575030 := by decide
theorem cert_e2411625552822 : check e2411625552822 [[],[]] .smaller = true := by decide
def e2411625552854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2411625552854 : Closed e2411625552854 ∧ code e2411625552854 = 11207718575062 := by decide
theorem cert_e2411625552854 : check e2411625552854 [[],[]] .three = true := by decide
def e2411625552858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2411625552858 : Closed e2411625552858 ∧ code e2411625552858 = 11207718575066 := by decide
theorem cert_e2411625552858 : check e2411625552858 [[],[]] .three = true := by decide
def e2411625553246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2411625553246 : Closed e2411625553246 ∧ code e2411625553246 = 11207718575454 := by decide
theorem cert_e2411625553246 : check e2411625553246 [[],[]] .three = true := by decide
def e2411625553262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2411625553262 : Closed e2411625553262 ∧ code e2411625553262 = 11207718575470 := by decide
theorem cert_e2411625553262 : check e2411625553262 [[],[]] .smaller = true := by decide
def e2411625553270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2411625553270 : Closed e2411625553270 ∧ code e2411625553270 = 11207718575478 := by decide
theorem cert_e2411625553270 : check e2411625553270 [[],[]] .smaller = true := by decide
def e2411625553274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2411625553274 : Closed e2411625553274 ∧ code e2411625553274 = 11207718575482 := by decide
theorem cert_e2411625553274 : check e2411625553274 [[],[]] .three = true := by decide
def e2411625553326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2411625553326 : Closed e2411625553326 ∧ code e2411625553326 = 11207718575534 := by decide
theorem cert_e2411625553326 : check e2411625553326 [[],[]] .smaller = true := by decide
def e2411625553338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2411625553338 : Closed e2411625553338 ∧ code e2411625553338 = 11207718575546 := by decide
theorem cert_e2411625553338 : check e2411625553338 [[],[]] .smaller = true := by decide
def e2411625553366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2411625553366 : Closed e2411625553366 ∧ code e2411625553366 = 11207718575574 := by decide
theorem cert_e2411625553366 : check e2411625553366 [[],[]] .smaller = true := by decide
def e2411625553370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2411625553370 : Closed e2411625553370 ∧ code e2411625553370 = 11207718575578 := by decide
theorem cert_e2411625553370 : check e2411625553370 [[],[]] .smaller = true := by decide
def e2411625553386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2411625553386 : Closed e2411625553386 ∧ code e2411625553386 = 11207718575594 := by decide
theorem cert_e2411625553386 : check e2411625553386 [[],[]] .three = true := by decide
def e2411625553590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2411625553590 : Closed e2411625553590 ∧ code e2411625553590 = 11207718575798 := by decide
theorem cert_e2411625553590 : check e2411625553590 [[],[]] .smaller = true := by decide
def e2411625553622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2411625553622 : Closed e2411625553622 ∧ code e2411625553622 = 11207718575830 := by decide
theorem cert_e2411625553622 : check e2411625553622 [[],[]] .smaller = true := by decide
def e2411625553626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2411625553626 : Closed e2411625553626 ∧ code e2411625553626 = 11207718575834 := by decide
theorem cert_e2411625553626 : check e2411625553626 [[],[]] .smaller = true := by decide
def e2411625553750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2411625553750 : Closed e2411625553750 ∧ code e2411625553750 = 11207718575958 := by decide
theorem cert_e2411625553750 : check e2411625553750 [[],[]] .three = true := by decide
def e2411625553754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2411625553754 : Closed e2411625553754 ∧ code e2411625553754 = 11207718575962 := by decide
theorem cert_e2411625553754 : check e2411625553754 [[],[]] .three = true := by decide
def e2411625553770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2411625553770 : Closed e2411625553770 ∧ code e2411625553770 = 11207718575978 := by decide
theorem cert_e2411625553770 : check e2411625553770 [[],[]] .three = true := by decide
def e2411625554910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e2411625554910 : Closed e2411625554910 ∧ code e2411625554910 = 11207718577118 := by decide
theorem cert_e2411625554910 : check e2411625554910 [[],[]] .three = true := by decide
def e2411625554926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e2411625554926 : Closed e2411625554926 ∧ code e2411625554926 = 11207718577134 := by decide
theorem cert_e2411625554926 : check e2411625554926 [[],[]] .three = true := by decide
def e2411625555678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2411625555678 : Closed e2411625555678 ∧ code e2411625555678 = 11207718577886 := by decide
theorem cert_e2411625555678 : check e2411625555678 [[],[]] .three = true := by decide
def e2411625555702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2411625555702 : Closed e2411625555702 ∧ code e2411625555702 = 11207718577910 := by decide
theorem cert_e2411625555702 : check e2411625555702 [[],[]] .three = true := by decide
def e2411625555806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2411625555806 : Closed e2411625555806 ∧ code e2411625555806 = 11207718578014 := by decide
theorem cert_e2411625555806 : check e2411625555806 [[],[]] .three = true := by decide
def e2411625555822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2411625555822 : Closed e2411625555822 ∧ code e2411625555822 = 11207718578030 := by decide
theorem cert_e2411625555822 : check e2411625555822 [[],[]] .smaller = true := by decide
def e2411625555830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2411625555830 : Closed e2411625555830 ∧ code e2411625555830 = 11207718578038 := by decide
theorem cert_e2411625555830 : check e2411625555830 [[],[]] .smaller = true := by decide
def e2411625555834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2411625555834 : Closed e2411625555834 ∧ code e2411625555834 = 11207718578042 := by decide
theorem cert_e2411625555834 : check e2411625555834 [[],[]] .three = true := by decide
def e2411625555894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2411625555894 : Closed e2411625555894 ∧ code e2411625555894 = 11207718578102 := by decide
theorem cert_e2411625555894 : check e2411625555894 [[],[]] .smaller = true := by decide
def e2411625555926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2411625555926 : Closed e2411625555926 ∧ code e2411625555926 = 11207718578134 := by decide
theorem cert_e2411625555926 : check e2411625555926 [[],[]] .three = true := by decide
def e2411625555930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2411625555930 : Closed e2411625555930 ∧ code e2411625555930 = 11207718578138 := by decide
theorem cert_e2411625555930 : check e2411625555930 [[],[]] .three = true := by decide
def e2411625556446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2411625556446 : Closed e2411625556446 ∧ code e2411625556446 = 11207718578654 := by decide
theorem cert_e2411625556446 : check e2411625556446 [[],[]] .three = true := by decide
def e2411625556470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2411625556470 : Closed e2411625556470 ∧ code e2411625556470 = 11207718578678 := by decide
theorem cert_e2411625556470 : check e2411625556470 [[],[]] .three = true := by decide
def e2411625557214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625557214 : Closed e2411625557214 ∧ code e2411625557214 = 11207718579422 := by decide
theorem cert_e2411625557214 : check e2411625557214 [[],[]] .three = true := by decide
def e2411625557230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625557230 : Closed e2411625557230 ∧ code e2411625557230 = 11207718579438 := by decide
theorem cert_e2411625557230 : check e2411625557230 [[],[]] .smaller = true := by decide
def e2411625557238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625557238 : Closed e2411625557238 ∧ code e2411625557238 = 11207718579446 := by decide
theorem cert_e2411625557238 : check e2411625557238 [[],[]] .smaller = true := by decide
end Blc.Floor43
