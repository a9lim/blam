import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862533498678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862533498678 : Closed e862533498678 ∧ code e862533498678 = 9658626520886 := by decide
theorem cert_e862533498678 : check e862533498678 [] .sourceHead = true := by decide
def e862533498682 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862533498682 : Closed e862533498682 ∧ code e862533498682 = 9658626520890 := by decide
theorem cert_e862533498682 : check e862533498682 [] .sourceHead = true := by decide
def e862533499310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e862533499310 : Closed e862533499310 ∧ code e862533499310 = 9658626521518 := by decide
theorem cert_e862533499310 : check e862533499310 [] .sourceHead = true := by decide
def e862533499322 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e862533499322 : Closed e862533499322 ∧ code e862533499322 = 9658626521530 := by decide
theorem cert_e862533499322 : check e862533499322 [] .sourceHead = true := by decide
def e862533499370 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e862533499370 : Closed e862533499370 ∧ code e862533499370 = 9658626521578 := by decide
theorem cert_e862533499370 : check e862533499370 [] .sourceHead = true := by decide
def e862533499502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862533499502 : Closed e862533499502 ∧ code e862533499502 = 9658626521710 := by decide
theorem cert_e862533499502 : check e862533499502 [] .sourceHead = true := by decide
def e862533499514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862533499514 : Closed e862533499514 ∧ code e862533499514 = 9658626521722 := by decide
theorem cert_e862533499514 : check e862533499514 [] .sourceHead = true := by decide
def e862533499802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862533499802 : Closed e862533499802 ∧ code e862533499802 = 9658626522010 := by decide
theorem cert_e862533499802 : check e862533499802 [] .sourceHead = true := by decide
def e862533500118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e862533500118 : Closed e862533500118 ∧ code e862533500118 = 9658626522326 := by decide
theorem cert_e862533500118 : check e862533500118 [] .sourceHead = true := by decide
def e862533500122 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e862533500122 : Closed e862533500122 ∧ code e862533500122 = 9658626522330 := by decide
theorem cert_e862533500122 : check e862533500122 [] .sourceHead = true := by decide
def e862533500138 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e862533500138 : Closed e862533500138 ∧ code e862533500138 = 9658626522346 := by decide
theorem cert_e862533500138 : check e862533500138 [] .sourceHead = true := by decide
def e862533500214 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862533500214 : Closed e862533500214 ∧ code e862533500214 = 9658626522422 := by decide
theorem cert_e862533500214 : check e862533500214 [] .sourceHead = true := by decide
def e862533500218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862533500218 : Closed e862533500218 ∧ code e862533500218 = 9658626522426 := by decide
theorem cert_e862533500218 : check e862533500218 [] .sourceHead = true := by decide
def e862533500314 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862533500314 : Closed e862533500314 ∧ code e862533500314 = 9658626522522 := by decide
theorem cert_e862533500314 : check e862533500314 [] .sourceHead = true := by decide
def e862533503854 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862533503854 : Closed e862533503854 ∧ code e862533503854 = 9658626526062 := by decide
theorem cert_e862533503854 : check e862533503854 [] .sourceHead = true := by decide
def e862533503862 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862533503862 : Closed e862533503862 ∧ code e862533503862 = 9658626526070 := by decide
theorem cert_e862533503862 : check e862533503862 [] .sourceHead = true := by decide
def e862533503918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862533503918 : Closed e862533503918 ∧ code e862533503918 = 9658626526126 := by decide
theorem cert_e862533503918 : check e862533503918 [] .sourceHead = true := by decide
def e862533503930 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862533503930 : Closed e862533503930 ∧ code e862533503930 = 9658626526138 := by decide
theorem cert_e862533503930 : check e862533503930 [] .sourceHead = true := by decide
def e862533503958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862533503958 : Closed e862533503958 ∧ code e862533503958 = 9658626526166 := by decide
theorem cert_e862533503958 : check e862533503958 [] .sourceHead = true := by decide
def e862533503962 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862533503962 : Closed e862533503962 ∧ code e862533503962 = 9658626526170 := by decide
theorem cert_e862533503962 : check e862533503962 [] .sourceHead = true := by decide
def e862533504238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862533504238 : Closed e862533504238 ∧ code e862533504238 = 9658626526446 := by decide
theorem cert_e862533504238 : check e862533504238 [] .sourceHead = true := by decide
def e862533504246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862533504246 : Closed e862533504246 ∧ code e862533504246 = 9658626526454 := by decide
theorem cert_e862533504246 : check e862533504246 [] .sourceHead = true := by decide
def e862533504622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862533504622 : Closed e862533504622 ∧ code e862533504622 = 9658626526830 := by decide
theorem cert_e862533504622 : check e862533504622 [] .sourceHead = true := by decide
def e862533504634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862533504634 : Closed e862533504634 ∧ code e862533504634 = 9658626526842 := by decide
theorem cert_e862533504634 : check e862533504634 [] .sourceHead = true := by decide
def e862533504822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862533504822 : Closed e862533504822 ∧ code e862533504822 = 9658626527030 := by decide
theorem cert_e862533504822 : check e862533504822 [] .sourceHead = true := by decide
def e862533504826 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862533504826 : Closed e862533504826 ∧ code e862533504826 = 9658626527034 := by decide
theorem cert_e862533504826 : check e862533504826 [] .sourceHead = true := by decide
def e862533510574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e862533510574 : Closed e862533510574 ∧ code e862533510574 = 9658626532782 := by decide
theorem cert_e862533510574 : check e862533510574 [] .sourceHead = true := by decide
def e862533510586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e862533510586 : Closed e862533510586 ∧ code e862533510586 = 9658626532794 := by decide
theorem cert_e862533510586 : check e862533510586 [] .sourceHead = true := by decide
def e862533510634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e862533510634 : Closed e862533510634 ∧ code e862533510634 = 9658626532842 := by decide
theorem cert_e862533510634 : check e862533510634 [] .sourceHead = true := by decide
def e862533510766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862533510766 : Closed e862533510766 ∧ code e862533510766 = 9658626532974 := by decide
theorem cert_e862533510766 : check e862533510766 [] .sourceHead = true := by decide
def e862533510778 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862533510778 : Closed e862533510778 ∧ code e862533510778 = 9658626532986 := by decide
theorem cert_e862533510778 : check e862533510778 [] .sourceHead = true := by decide
def e862533511066 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862533511066 : Closed e862533511066 ∧ code e862533511066 = 9658626533274 := by decide
theorem cert_e862533511066 : check e862533511066 [] .sourceHead = true := by decide
def e862533513942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e862533513942 : Closed e862533513942 ∧ code e862533513942 = 9658626536150 := by decide
theorem cert_e862533513942 : check e862533513942 [] .sourceHead = true := by decide
def e862533513946 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e862533513946 : Closed e862533513946 ∧ code e862533513946 = 9658626536154 := by decide
theorem cert_e862533513946 : check e862533513946 [] .sourceHead = true := by decide
def e862533513962 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e862533513962 : Closed e862533513962 ∧ code e862533513962 = 9658626536170 := by decide
theorem cert_e862533513962 : check e862533513962 [] .sourceHead = true := by decide
def e862533514038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862533514038 : Closed e862533514038 ∧ code e862533514038 = 9658626536246 := by decide
theorem cert_e862533514038 : check e862533514038 [] .sourceHead = true := by decide
def e862533514042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862533514042 : Closed e862533514042 ∧ code e862533514042 = 9658626536250 := by decide
theorem cert_e862533514042 : check e862533514042 [] .sourceHead = true := by decide
def e862533514138 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862533514138 : Closed e862533514138 ∧ code e862533514138 = 9658626536346 := by decide
theorem cert_e862533514138 : check e862533514138 [] .sourceHead = true := by decide
def e862533651310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862533651310 : Closed e862533651310 ∧ code e862533651310 = 9658626673518 := by decide
theorem cert_e862533651310 : check e862533651310 [] .sourceHead = true := by decide
def e862533651318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862533651318 : Closed e862533651318 ∧ code e862533651318 = 9658626673526 := by decide
theorem cert_e862533651318 : check e862533651318 [] .sourceHead = true := by decide
def e862533651374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862533651374 : Closed e862533651374 ∧ code e862533651374 = 9658626673582 := by decide
theorem cert_e862533651374 : check e862533651374 [] .sourceHead = true := by decide
def e862533651386 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862533651386 : Closed e862533651386 ∧ code e862533651386 = 9658626673594 := by decide
theorem cert_e862533651386 : check e862533651386 [] .sourceHead = true := by decide
def e862533651414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862533651414 : Closed e862533651414 ∧ code e862533651414 = 9658626673622 := by decide
theorem cert_e862533651414 : check e862533651414 [] .sourceHead = true := by decide
def e862533651418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862533651418 : Closed e862533651418 ∧ code e862533651418 = 9658626673626 := by decide
theorem cert_e862533651418 : check e862533651418 [] .sourceHead = true := by decide
def e862533651694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862533651694 : Closed e862533651694 ∧ code e862533651694 = 9658626673902 := by decide
theorem cert_e862533651694 : check e862533651694 [] .sourceHead = true := by decide
def e862533651702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862533651702 : Closed e862533651702 ∧ code e862533651702 = 9658626673910 := by decide
theorem cert_e862533651702 : check e862533651702 [] .sourceHead = true := by decide
def e862533652078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862533652078 : Closed e862533652078 ∧ code e862533652078 = 9658626674286 := by decide
theorem cert_e862533652078 : check e862533652078 [] .sourceHead = true := by decide
def e862533652090 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862533652090 : Closed e862533652090 ∧ code e862533652090 = 9658626674298 := by decide
theorem cert_e862533652090 : check e862533652090 [] .sourceHead = true := by decide
def e862533652278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862533652278 : Closed e862533652278 ∧ code e862533652278 = 9658626674486 := by decide
theorem cert_e862533652278 : check e862533652278 [] .sourceHead = true := by decide
def e862533652282 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862533652282 : Closed e862533652282 ∧ code e862533652282 = 9658626674490 := by decide
theorem cert_e862533652282 : check e862533652282 [] .sourceHead = true := by decide
def e862534241134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862534241134 : Closed e862534241134 ∧ code e862534241134 = 9658627263342 := by decide
theorem cert_e862534241134 : check e862534241134 [] .sourceHead = true := by decide
def e862534241142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862534241142 : Closed e862534241142 ∧ code e862534241142 = 9658627263350 := by decide
theorem cert_e862534241142 : check e862534241142 [] .sourceHead = true := by decide
def e862534241198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862534241198 : Closed e862534241198 ∧ code e862534241198 = 9658627263406 := by decide
theorem cert_e862534241198 : check e862534241198 [] .sourceHead = true := by decide
def e862534241210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862534241210 : Closed e862534241210 ∧ code e862534241210 = 9658627263418 := by decide
theorem cert_e862534241210 : check e862534241210 [] .sourceHead = true := by decide
def e862534241238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862534241238 : Closed e862534241238 ∧ code e862534241238 = 9658627263446 := by decide
theorem cert_e862534241238 : check e862534241238 [] .sourceHead = true := by decide
def e862534241242 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862534241242 : Closed e862534241242 ∧ code e862534241242 = 9658627263450 := by decide
theorem cert_e862534241242 : check e862534241242 [] .sourceHead = true := by decide
def e862534241518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862534241518 : Closed e862534241518 ∧ code e862534241518 = 9658627263726 := by decide
theorem cert_e862534241518 : check e862534241518 [] .sourceHead = true := by decide
def e862534241526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862534241526 : Closed e862534241526 ∧ code e862534241526 = 9658627263734 := by decide
theorem cert_e862534241526 : check e862534241526 [] .sourceHead = true := by decide
def e862534241902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862534241902 : Closed e862534241902 ∧ code e862534241902 = 9658627264110 := by decide
theorem cert_e862534241902 : check e862534241902 [] .sourceHead = true := by decide
def e862534241914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862534241914 : Closed e862534241914 ∧ code e862534241914 = 9658627264122 := by decide
theorem cert_e862534241914 : check e862534241914 [] .sourceHead = true := by decide
def e862534242102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862534242102 : Closed e862534242102 ∧ code e862534242102 = 9658627264310 := by decide
theorem cert_e862534242102 : check e862534242102 [] .sourceHead = true := by decide
def e862534242106 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862534242106 : Closed e862534242106 ∧ code e862534242106 = 9658627264314 := by decide
theorem cert_e862534242106 : check e862534242106 [] .sourceHead = true := by decide
def e868455986618 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e868455986618 : Closed e868455986618 ∧ code e868455986618 = 9664549008826 := by decide
theorem cert_e868455986618 : check e868455986618 [] .sourceHead = true := by decide
def e868455986650 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e868455986650 : Closed e868455986650 ∧ code e868455986650 = 9664549008858 := by decide
theorem cert_e868455986650 : check e868455986650 [] .sourceHead = true := by decide
def e868455986874 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e868455986874 : Closed e868455986874 ∧ code e868455986874 = 9664549009082 := by decide
theorem cert_e868455986874 : check e868455986874 [] .sourceHead = true := by decide
def e868455986922 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e868455986922 : Closed e868455986922 ∧ code e868455986922 = 9664549009130 := by decide
theorem cert_e868455986922 : check e868455986922 [] .sourceHead = true := by decide
def e868455987034 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e868455987034 : Closed e868455987034 ∧ code e868455987034 = 9664549009242 := by decide
theorem cert_e868455987034 : check e868455987034 [] .sourceHead = true := by decide
def e868455987050 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e868455987050 : Closed e868455987050 ∧ code e868455987050 = 9664549009258 := by decide
theorem cert_e868455987050 : check e868455987050 [] .sourceHead = true := by decide
def e868455987898 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e868455987898 : Closed e868455987898 ∧ code e868455987898 = 9664549010106 := by decide
theorem cert_e868455987898 : check e868455987898 [] .sourceHead = true := by decide
def e868455987946 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e868455987946 : Closed e868455987946 ∧ code e868455987946 = 9664549010154 := by decide
theorem cert_e868455987946 : check e868455987946 [] .sourceHead = true := by decide
def e868455988138 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0))))
theorem wire_e868455988138 : Closed e868455988138 ∧ code e868455988138 = 9664549010346 := by decide
theorem cert_e868455988138 : check e868455988138 [] .sourceHead = true := by decide
def e868455988570 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e868455988570 : Closed e868455988570 ∧ code e868455988570 = 9664549010778 := by decide
theorem cert_e868455988570 : check e868455988570 [] .sourceHead = true := by decide
def e868455988586 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e868455988586 : Closed e868455988586 ∧ code e868455988586 = 9664549010794 := by decide
theorem cert_e868455988586 : check e868455988586 [] .sourceHead = true := by decide
def e868455988650 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0))))
theorem wire_e868455988650 : Closed e868455988650 ∧ code e868455988650 = 9664549010858 := by decide
theorem cert_e868455988650 : check e868455988650 [] .sourceHead = true := by decide
def e868455992762 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0))))
theorem wire_e868455992762 : Closed e868455992762 ∧ code e868455992762 = 9664549014970 := by decide
theorem cert_e868455992762 : check e868455992762 [] .sourceHead = true := by decide
def e868455992794 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0))))
theorem wire_e868455992794 : Closed e868455992794 ∧ code e868455992794 = 9664549015002 := by decide
theorem cert_e868455992794 : check e868455992794 [] .sourceHead = true := by decide
def e868455993018 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0))))
theorem wire_e868455993018 : Closed e868455993018 ∧ code e868455993018 = 9664549015226 := by decide
theorem cert_e868455993018 : check e868455993018 [] .sourceHead = true := by decide
def e868455993066 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0))))
theorem wire_e868455993066 : Closed e868455993066 ∧ code e868455993066 = 9664549015274 := by decide
theorem cert_e868455993066 : check e868455993066 [] .sourceHead = true := by decide
def e868455993178 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0))))
theorem wire_e868455993178 : Closed e868455993178 ∧ code e868455993178 = 9664549015386 := by decide
theorem cert_e868455993178 : check e868455993178 [] .sourceHead = true := by decide
def e868455993194 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0))))
theorem wire_e868455993194 : Closed e868455993194 ∧ code e868455993194 = 9664549015402 := by decide
theorem cert_e868455993194 : check e868455993194 [] .sourceHead = true := by decide
def e868455994298 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e868455994298 : Closed e868455994298 ∧ code e868455994298 = 9664549016506 := by decide
theorem cert_e868455994298 : check e868455994298 [] .sourceHead = true := by decide
def e868455994330 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e868455994330 : Closed e868455994330 ∧ code e868455994330 = 9664549016538 := by decide
theorem cert_e868455994330 : check e868455994330 [] .sourceHead = true := by decide
def e868455995834 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e868455995834 : Closed e868455995834 ∧ code e868455995834 = 9664549018042 := by decide
theorem cert_e868455995834 : check e868455995834 [] .sourceHead = true := by decide
def e868455995882 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e868455995882 : Closed e868455995882 ∧ code e868455995882 = 9664549018090 := by decide
theorem cert_e868455995882 : check e868455995882 [] .sourceHead = true := by decide
def e868455996634 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e868455996634 : Closed e868455996634 ∧ code e868455996634 = 9664549018842 := by decide
theorem cert_e868455996634 : check e868455996634 [] .sourceHead = true := by decide
def e868455996650 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e868455996650 : Closed e868455996650 ∧ code e868455996650 = 9664549018858 := by decide
theorem cert_e868455996650 : check e868455996650 [] .sourceHead = true := by decide
def e868455999162 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0))))
theorem wire_e868455999162 : Closed e868455999162 ∧ code e868455999162 = 9664549021370 := by decide
theorem cert_e868455999162 : check e868455999162 [] .sourceHead = true := by decide
def e868455999210 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0))))
theorem wire_e868455999210 : Closed e868455999210 ∧ code e868455999210 = 9664549021418 := by decide
theorem cert_e868455999210 : check e868455999210 [] .sourceHead = true := by decide
def e868455999402 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0))))
theorem wire_e868455999402 : Closed e868455999402 ∧ code e868455999402 = 9664549021610 := by decide
theorem cert_e868455999402 : check e868455999402 [] .sourceHead = true := by decide
def e868455999930 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e868455999930 : Closed e868455999930 ∧ code e868455999930 = 9664549022138 := by decide
theorem cert_e868455999930 : check e868455999930 [] .sourceHead = true := by decide
def e868455999978 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e868455999978 : Closed e868455999978 ∧ code e868455999978 = 9664549022186 := by decide
theorem cert_e868455999978 : check e868455999978 [] .sourceHead = true := by decide
def e868456001130 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0))))
theorem wire_e868456001130 : Closed e868456001130 ∧ code e868456001130 = 9664549023338 := by decide
theorem cert_e868456001130 : check e868456001130 [] .sourceHead = true := by decide
def e868456002394 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0))))
theorem wire_e868456002394 : Closed e868456002394 ∧ code e868456002394 = 9664549024602 := by decide
theorem cert_e868456002394 : check e868456002394 [] .sourceHead = true := by decide
def e868456002410 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0))))
theorem wire_e868456002410 : Closed e868456002410 ∧ code e868456002410 = 9664549024618 := by decide
theorem cert_e868456002410 : check e868456002410 [] .sourceHead = true := by decide
def e868456002474 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0))))
theorem wire_e868456002474 : Closed e868456002474 ∧ code e868456002474 = 9664549024682 := by decide
theorem cert_e868456002474 : check e868456002474 [] .sourceHead = true := by decide
def e868456002778 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e868456002778 : Closed e868456002778 ∧ code e868456002778 = 9664549024986 := by decide
theorem cert_e868456002778 : check e868456002778 [] .sourceHead = true := by decide
def e868456002794 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e868456002794 : Closed e868456002794 ∧ code e868456002794 = 9664549025002 := by decide
theorem cert_e868456002794 : check e868456002794 [] .sourceHead = true := by decide
def e868456003178 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0))))
theorem wire_e868456003178 : Closed e868456003178 ∧ code e868456003178 = 9664549025386 := by decide
theorem cert_e868456003178 : check e868456003178 [] .sourceHead = true := by decide
def e868456017338 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))))
theorem wire_e868456017338 : Closed e868456017338 ∧ code e868456017338 = 9664549039546 := by decide
theorem cert_e868456017338 : check e868456017338 [] .sourceHead = true := by decide
def e868456017370 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))))
theorem wire_e868456017370 : Closed e868456017370 ∧ code e868456017370 = 9664549039578 := by decide
theorem cert_e868456017370 : check e868456017370 [] .sourceHead = true := by decide
def e868456017594 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e868456017594 : Closed e868456017594 ∧ code e868456017594 = 9664549039802 := by decide
theorem cert_e868456017594 : check e868456017594 [] .sourceHead = true := by decide
def e868456017642 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e868456017642 : Closed e868456017642 ∧ code e868456017642 = 9664549039850 := by decide
theorem cert_e868456017642 : check e868456017642 [] .sourceHead = true := by decide
def e868456017754 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e868456017754 : Closed e868456017754 ∧ code e868456017754 = 9664549039962 := by decide
theorem cert_e868456017754 : check e868456017754 [] .sourceHead = true := by decide
def e868456017770 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e868456017770 : Closed e868456017770 ∧ code e868456017770 = 9664549039978 := by decide
theorem cert_e868456017770 : check e868456017770 [] .sourceHead = true := by decide
def e868456018874 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))))
theorem wire_e868456018874 : Closed e868456018874 ∧ code e868456018874 = 9664549041082 := by decide
theorem cert_e868456018874 : check e868456018874 [] .sourceHead = true := by decide
def e868456018906 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))))
theorem wire_e868456018906 : Closed e868456018906 ∧ code e868456018906 = 9664549041114 := by decide
theorem cert_e868456018906 : check e868456018906 [] .sourceHead = true := by decide
def e868456020410 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e868456020410 : Closed e868456020410 ∧ code e868456020410 = 9664549042618 := by decide
theorem cert_e868456020410 : check e868456020410 [] .sourceHead = true := by decide
def e868456020458 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e868456020458 : Closed e868456020458 ∧ code e868456020458 = 9664549042666 := by decide
theorem cert_e868456020458 : check e868456020458 [] .sourceHead = true := by decide
def e868456021210 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e868456021210 : Closed e868456021210 ∧ code e868456021210 = 9664549043418 := by decide
theorem cert_e868456021210 : check e868456021210 [] .sourceHead = true := by decide
def e868456021226 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e868456021226 : Closed e868456021226 ∧ code e868456021226 = 9664549043434 := by decide
theorem cert_e868456021226 : check e868456021226 [] .sourceHead = true := by decide
def e868456044218 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e868456044218 : Closed e868456044218 ∧ code e868456044218 = 9664549066426 := by decide
theorem cert_e868456044218 : check e868456044218 [] .sourceHead = true := by decide
def e868456044266 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e868456044266 : Closed e868456044266 ∧ code e868456044266 = 9664549066474 := by decide
theorem cert_e868456044266 : check e868456044266 [] .sourceHead = true := by decide
def e868456044458 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0))))
theorem wire_e868456044458 : Closed e868456044458 ∧ code e868456044458 = 9664549066666 := by decide
theorem cert_e868456044458 : check e868456044458 [] .sourceHead = true := by decide
def e868456044986 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e868456044986 : Closed e868456044986 ∧ code e868456044986 = 9664549067194 := by decide
theorem cert_e868456044986 : check e868456044986 [] .sourceHead = true := by decide
def e868456045034 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e868456045034 : Closed e868456045034 ∧ code e868456045034 = 9664549067242 := by decide
theorem cert_e868456045034 : check e868456045034 [] .sourceHead = true := by decide
def e868456046186 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0))))
theorem wire_e868456046186 : Closed e868456046186 ∧ code e868456046186 = 9664549068394 := by decide
theorem cert_e868456046186 : check e868456046186 [] .sourceHead = true := by decide
def e868456057690 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e868456057690 : Closed e868456057690 ∧ code e868456057690 = 9664549079898 := by decide
theorem cert_e868456057690 : check e868456057690 [] .sourceHead = true := by decide
def e868456057706 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e868456057706 : Closed e868456057706 ∧ code e868456057706 = 9664549079914 := by decide
theorem cert_e868456057706 : check e868456057706 [] .sourceHead = true := by decide
def e868456057770 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0))))
theorem wire_e868456057770 : Closed e868456057770 ∧ code e868456057770 = 9664549079978 := by decide
theorem cert_e868456057770 : check e868456057770 [] .sourceHead = true := by decide
def e868456058074 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e868456058074 : Closed e868456058074 ∧ code e868456058074 = 9664549080282 := by decide
theorem cert_e868456058074 : check e868456058074 [] .sourceHead = true := by decide
def e868456058090 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e868456058090 : Closed e868456058090 ∧ code e868456058090 = 9664549080298 := by decide
theorem cert_e868456058090 : check e868456058090 [] .sourceHead = true := by decide
def e868456058474 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0))))
theorem wire_e868456058474 : Closed e868456058474 ∧ code e868456058474 = 9664549080682 := by decide
theorem cert_e868456058474 : check e868456058474 [] .sourceHead = true := by decide
def e868456607162 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))))
theorem wire_e868456607162 : Closed e868456607162 ∧ code e868456607162 = 9664549629370 := by decide
theorem cert_e868456607162 : check e868456607162 [] .sourceHead = true := by decide
def e868456607194 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))))
theorem wire_e868456607194 : Closed e868456607194 ∧ code e868456607194 = 9664549629402 := by decide
theorem cert_e868456607194 : check e868456607194 [] .sourceHead = true := by decide
def e868456607418 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e868456607418 : Closed e868456607418 ∧ code e868456607418 = 9664549629626 := by decide
theorem cert_e868456607418 : check e868456607418 [] .sourceHead = true := by decide
def e868456607466 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e868456607466 : Closed e868456607466 ∧ code e868456607466 = 9664549629674 := by decide
theorem cert_e868456607466 : check e868456607466 [] .sourceHead = true := by decide
def e868456607578 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e868456607578 : Closed e868456607578 ∧ code e868456607578 = 9664549629786 := by decide
theorem cert_e868456607578 : check e868456607578 [] .sourceHead = true := by decide
def e868456607594 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e868456607594 : Closed e868456607594 ∧ code e868456607594 = 9664549629802 := by decide
theorem cert_e868456607594 : check e868456607594 [] .sourceHead = true := by decide
def e868456608698 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))))
theorem wire_e868456608698 : Closed e868456608698 ∧ code e868456608698 = 9664549630906 := by decide
theorem cert_e868456608698 : check e868456608698 [] .sourceHead = true := by decide
def e868456608730 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))))
theorem wire_e868456608730 : Closed e868456608730 ∧ code e868456608730 = 9664549630938 := by decide
theorem cert_e868456608730 : check e868456608730 [] .sourceHead = true := by decide
def e868456610234 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e868456610234 : Closed e868456610234 ∧ code e868456610234 = 9664549632442 := by decide
theorem cert_e868456610234 : check e868456610234 [] .sourceHead = true := by decide
def e868456610282 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e868456610282 : Closed e868456610282 ∧ code e868456610282 = 9664549632490 := by decide
theorem cert_e868456610282 : check e868456610282 [] .sourceHead = true := by decide
def e868456611034 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e868456611034 : Closed e868456611034 ∧ code e868456611034 = 9664549633242 := by decide
theorem cert_e868456611034 : check e868456611034 [] .sourceHead = true := by decide
def e868456611050 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e868456611050 : Closed e868456611050 ∧ code e868456611050 = 9664549633258 := by decide
theorem cert_e868456611050 : check e868456611050 [] .sourceHead = true := by decide
def e868458966458 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))))
theorem wire_e868458966458 : Closed e868458966458 ∧ code e868458966458 = 9664551988666 := by decide
theorem cert_e868458966458 : check e868458966458 [] .sourceHead = true := by decide
def e868458966490 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))))
theorem wire_e868458966490 : Closed e868458966490 ∧ code e868458966490 = 9664551988698 := by decide
theorem cert_e868458966490 : check e868458966490 [] .sourceHead = true := by decide
def e868458966714 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e868458966714 : Closed e868458966714 ∧ code e868458966714 = 9664551988922 := by decide
theorem cert_e868458966714 : check e868458966714 [] .sourceHead = true := by decide
def e868458966762 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e868458966762 : Closed e868458966762 ∧ code e868458966762 = 9664551988970 := by decide
theorem cert_e868458966762 : check e868458966762 [] .sourceHead = true := by decide
def e868458966874 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e868458966874 : Closed e868458966874 ∧ code e868458966874 = 9664551989082 := by decide
theorem cert_e868458966874 : check e868458966874 [] .sourceHead = true := by decide
def e868458966890 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e868458966890 : Closed e868458966890 ∧ code e868458966890 = 9664551989098 := by decide
theorem cert_e868458966890 : check e868458966890 [] .sourceHead = true := by decide
def e868458967994 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))))
theorem wire_e868458967994 : Closed e868458967994 ∧ code e868458967994 = 9664551990202 := by decide
theorem cert_e868458967994 : check e868458967994 [] .sourceHead = true := by decide
def e868458968026 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))))
theorem wire_e868458968026 : Closed e868458968026 ∧ code e868458968026 = 9664551990234 := by decide
theorem cert_e868458968026 : check e868458968026 [] .sourceHead = true := by decide
def e868458969530 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e868458969530 : Closed e868458969530 ∧ code e868458969530 = 9664551991738 := by decide
theorem cert_e868458969530 : check e868458969530 [] .sourceHead = true := by decide
def e868458969578 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e868458969578 : Closed e868458969578 ∧ code e868458969578 = 9664551991786 := by decide
theorem cert_e868458969578 : check e868458969578 [] .sourceHead = true := by decide
def e868458970330 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e868458970330 : Closed e868458970330 ∧ code e868458970330 = 9664551992538 := by decide
theorem cert_e868458970330 : check e868458970330 [] .sourceHead = true := by decide
def e868458970346 : Term := (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e868458970346 : Closed e868458970346 ∧ code e868458970346 = 9664551992554 := by decide
theorem cert_e868458970346 : check e868458970346 [] .sourceHead = true := by decide
def e871889727002 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889727002 : Closed e871889727002 ∧ code e871889727002 = 9667982749210 := by decide
theorem cert_e871889727002 : check e871889727002 [] .sourceHead = true := by decide
def e871889729050 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889729050 : Closed e871889729050 ∧ code e871889729050 = 9667982751258 := by decide
theorem cert_e871889729050 : check e871889729050 [] .sourceHead = true := by decide
def e871889743386 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889743386 : Closed e871889743386 ∧ code e871889743386 = 9667982765594 := by decide
theorem cert_e871889743386 : check e871889743386 [] .sourceHead = true := by decide
def e871889746458 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889746458 : Closed e871889746458 ∧ code e871889746458 = 9667982768666 := by decide
theorem cert_e871889746458 : check e871889746458 [] .sourceHead = true := by decide
def e871889753626 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889753626 : Closed e871889753626 ∧ code e871889753626 = 9667982775834 := by decide
theorem cert_e871889753626 : check e871889753626 [] .sourceHead = true := by decide
def e871889754650 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889754650 : Closed e871889754650 ∧ code e871889754650 = 9667982776858 := by decide
theorem cert_e871889754650 : check e871889754650 [] .sourceHead = true := by decide
def e871889808922 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889808922 : Closed e871889808922 ∧ code e871889808922 = 9667982831130 := by decide
theorem cert_e871889808922 : check e871889808922 [] .sourceHead = true := by decide
def e871889811994 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889811994 : Closed e871889811994 ∧ code e871889811994 = 9667982834202 := by decide
theorem cert_e871889811994 : check e871889811994 [] .sourceHead = true := by decide
def e871889824282 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889824282 : Closed e871889824282 ∧ code e871889824282 = 9667982846490 := by decide
theorem cert_e871889824282 : check e871889824282 [] .sourceHead = true := by decide
def e871889851930 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889851930 : Closed e871889851930 ∧ code e871889851930 = 9667982874138 := by decide
theorem cert_e871889851930 : check e871889851930 [] .sourceHead = true := by decide
def e871889852954 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889852954 : Closed e871889852954 ∧ code e871889852954 = 9667982875162 := by decide
theorem cert_e871889852954 : check e871889852954 [] .sourceHead = true := by decide
def e871889857050 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871889857050 : Closed e871889857050 ∧ code e871889857050 = 9667982879258 := by decide
theorem cert_e871889857050 : check e871889857050 [] .sourceHead = true := by decide
def e871890120218 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890120218 : Closed e871890120218 ∧ code e871890120218 = 9667983142426 := by decide
theorem cert_e871890120218 : check e871890120218 [] .sourceHead = true := by decide
def e871890122266 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890122266 : Closed e871890122266 ∧ code e871890122266 = 9667983144474 := by decide
theorem cert_e871890122266 : check e871890122266 [] .sourceHead = true := by decide
end Blc.Floor43
