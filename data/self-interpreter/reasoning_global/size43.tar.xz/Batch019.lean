import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605059723462 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605059723462 : Closed e605059723462 ∧ code e605059723462 = 9401152745670 := by decide
theorem cert_e605059723462 : check e605059723462 [[.under]] .width = true := by decide
def e605059731654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605059731654 : Closed e605059731654 ∧ code e605059731654 = 9401152753862 := by decide
theorem cert_e605059731654 : check e605059731654 [[.under]] .width = true := by decide
def e605060296902 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605060296902 : Closed e605060296902 ∧ code e605060296902 = 9401153319110 := by decide
theorem cert_e605060296902 : check e605060296902 [[.under]] .width = true := by decide
def e605060313286 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605060313286 : Closed e605060313286 ∧ code e605060313286 = 9401153335494 := by decide
theorem cert_e605060313286 : check e605060313286 [[.under]] .width = true := by decide
def e605061083334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605061083334 : Closed e605061083334 ∧ code e605061083334 = 9401154105542 := by decide
theorem cert_e605061083334 : check e605061083334 [[.under]] .width = true := by decide
def e605061107910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605061107910 : Closed e605061107910 ∧ code e605061107910 = 9401154130118 := by decide
theorem cert_e605061107910 : check e605061107910 [[.under]] .width = true := by decide
def e605061492934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605061492934 : Closed e605061492934 ∧ code e605061492934 = 9401154515142 := by decide
theorem cert_e605061492934 : check e605061492934 [[.under]] .width = true := by decide
def e605061501126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605061501126 : Closed e605061501126 ∧ code e605061501126 = 9401154523334 := by decide
theorem cert_e605061501126 : check e605061501126 [[.under]] .width = true := by decide
def e605103893870 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605103893870 : Closed e605103893870 ∧ code e605103893870 = 9401196916078 := by decide
theorem cert_e605103893870 : check e605103893870 [[.under],[.under]] .three = true := by decide
def e605103893878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605103893878 : Closed e605103893878 ∧ code e605103893878 = 9401196916086 := by decide
theorem cert_e605103893878 : check e605103893878 [[.under],[.under]] .three = true := by decide
def e605103893934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605103893934 : Closed e605103893934 ∧ code e605103893934 = 9401196916142 := by decide
theorem cert_e605103893934 : check e605103893934 [[.under],[.under]] .three = true := by decide
def e605103893946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605103893946 : Closed e605103893946 ∧ code e605103893946 = 9401196916154 := by decide
theorem cert_e605103893946 : check e605103893946 [[.under],[.under]] .three = true := by decide
def e605103893974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605103893974 : Closed e605103893974 ∧ code e605103893974 = 9401196916182 := by decide
theorem cert_e605103893974 : check e605103893974 [[.under],[.under]] .three = true := by decide
def e605103893978 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605103893978 : Closed e605103893978 ∧ code e605103893978 = 9401196916186 := by decide
theorem cert_e605103893978 : check e605103893978 [[.under],[.under]] .three = true := by decide
def e605103894190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605103894190 : Closed e605103894190 ∧ code e605103894190 = 9401196916398 := by decide
theorem cert_e605103894190 : check e605103894190 [[.under],[.under]] .three = true := by decide
def e605103894202 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605103894202 : Closed e605103894202 ∧ code e605103894202 = 9401196916410 := by decide
theorem cert_e605103894202 : check e605103894202 [[.under],[.under]] .three = true := by decide
def e605103894250 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605103894250 : Closed e605103894250 ∧ code e605103894250 = 9401196916458 := by decide
theorem cert_e605103894250 : check e605103894250 [[.under],[.under]] .three = true := by decide
def e605103894358 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605103894358 : Closed e605103894358 ∧ code e605103894358 = 9401196916566 := by decide
theorem cert_e605103894358 : check e605103894358 [[.under],[.under]] .three = true := by decide
def e605103894362 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605103894362 : Closed e605103894362 ∧ code e605103894362 = 9401196916570 := by decide
theorem cert_e605103894362 : check e605103894362 [[.under],[.under]] .three = true := by decide
def e605103894378 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605103894378 : Closed e605103894378 ∧ code e605103894378 = 9401196916586 := by decide
theorem cert_e605103894378 : check e605103894378 [[.under],[.under]] .three = true := by decide
def e605103895406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605103895406 : Closed e605103895406 ∧ code e605103895406 = 9401196917614 := by decide
theorem cert_e605103895406 : check e605103895406 [[.under],[.under]] .three = true := by decide
def e605103895414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605103895414 : Closed e605103895414 ∧ code e605103895414 = 9401196917622 := by decide
theorem cert_e605103895414 : check e605103895414 [[.under],[.under]] .three = true := by decide
def e605103895470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605103895470 : Closed e605103895470 ∧ code e605103895470 = 9401196917678 := by decide
theorem cert_e605103895470 : check e605103895470 [[.under],[.under]] .three = true := by decide
def e605103895482 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605103895482 : Closed e605103895482 ∧ code e605103895482 = 9401196917690 := by decide
theorem cert_e605103895482 : check e605103895482 [[.under],[.under]] .three = true := by decide
def e605103895510 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605103895510 : Closed e605103895510 ∧ code e605103895510 = 9401196917718 := by decide
theorem cert_e605103895510 : check e605103895510 [[.under],[.under]] .three = true := by decide
def e605103895514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605103895514 : Closed e605103895514 ∧ code e605103895514 = 9401196917722 := by decide
theorem cert_e605103895514 : check e605103895514 [[.under],[.under]] .three = true := by decide
def e605103895790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605103895790 : Closed e605103895790 ∧ code e605103895790 = 9401196917998 := by decide
theorem cert_e605103895790 : check e605103895790 [[.under],[.under]] .three = true := by decide
def e605103895798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605103895798 : Closed e605103895798 ∧ code e605103895798 = 9401196918006 := by decide
theorem cert_e605103895798 : check e605103895798 [[.under],[.under]] .three = true := by decide
def e605103896174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605103896174 : Closed e605103896174 ∧ code e605103896174 = 9401196918382 := by decide
theorem cert_e605103896174 : check e605103896174 [[.under],[.under]] .three = true := by decide
def e605103896186 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605103896186 : Closed e605103896186 ∧ code e605103896186 = 9401196918394 := by decide
theorem cert_e605103896186 : check e605103896186 [[.under],[.under]] .three = true := by decide
def e605103896374 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605103896374 : Closed e605103896374 ∧ code e605103896374 = 9401196918582 := by decide
theorem cert_e605103896374 : check e605103896374 [[.under],[.under]] .three = true := by decide
def e605103896378 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605103896378 : Closed e605103896378 ∧ code e605103896378 = 9401196918586 := by decide
theorem cert_e605103896378 : check e605103896378 [[.under],[.under]] .three = true := by decide
def e605103897006 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605103897006 : Closed e605103897006 ∧ code e605103897006 = 9401196919214 := by decide
theorem cert_e605103897006 : check e605103897006 [[.under],[.under]] .three = true := by decide
def e605103897018 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605103897018 : Closed e605103897018 ∧ code e605103897018 = 9401196919226 := by decide
theorem cert_e605103897018 : check e605103897018 [[.under],[.under]] .three = true := by decide
def e605103897066 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605103897066 : Closed e605103897066 ∧ code e605103897066 = 9401196919274 := by decide
theorem cert_e605103897066 : check e605103897066 [[.under],[.under]] .three = true := by decide
def e605103897198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605103897198 : Closed e605103897198 ∧ code e605103897198 = 9401196919406 := by decide
theorem cert_e605103897198 : check e605103897198 [[.under],[.under]] .three = true := by decide
def e605103897210 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605103897210 : Closed e605103897210 ∧ code e605103897210 = 9401196919418 := by decide
theorem cert_e605103897210 : check e605103897210 [[.under],[.under]] .three = true := by decide
def e605103897498 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605103897498 : Closed e605103897498 ∧ code e605103897498 = 9401196919706 := by decide
theorem cert_e605103897498 : check e605103897498 [[.under],[.under]] .three = true := by decide
def e605103897814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605103897814 : Closed e605103897814 ∧ code e605103897814 = 9401196920022 := by decide
theorem cert_e605103897814 : check e605103897814 [[.under],[.under]] .three = true := by decide
def e605103897818 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605103897818 : Closed e605103897818 ∧ code e605103897818 = 9401196920026 := by decide
theorem cert_e605103897818 : check e605103897818 [[.under],[.under]] .three = true := by decide
def e605103897834 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605103897834 : Closed e605103897834 ∧ code e605103897834 = 9401196920042 := by decide
theorem cert_e605103897834 : check e605103897834 [[.under],[.under]] .three = true := by decide
def e605103897910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605103897910 : Closed e605103897910 ∧ code e605103897910 = 9401196920118 := by decide
theorem cert_e605103897910 : check e605103897910 [[.under],[.under]] .three = true := by decide
def e605103897914 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605103897914 : Closed e605103897914 ∧ code e605103897914 = 9401196920122 := by decide
theorem cert_e605103897914 : check e605103897914 [[.under],[.under]] .three = true := by decide
def e605103898010 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605103898010 : Closed e605103898010 ∧ code e605103898010 = 9401196920218 := by decide
theorem cert_e605103898010 : check e605103898010 [[.under],[.under]] .three = true := by decide
def e605103901550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605103901550 : Closed e605103901550 ∧ code e605103901550 = 9401196923758 := by decide
theorem cert_e605103901550 : check e605103901550 [[.under],[.under]] .three = true := by decide
def e605103901558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605103901558 : Closed e605103901558 ∧ code e605103901558 = 9401196923766 := by decide
theorem cert_e605103901558 : check e605103901558 [[.under],[.under]] .three = true := by decide
def e605103901614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605103901614 : Closed e605103901614 ∧ code e605103901614 = 9401196923822 := by decide
theorem cert_e605103901614 : check e605103901614 [[.under],[.under]] .three = true := by decide
def e605103901626 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605103901626 : Closed e605103901626 ∧ code e605103901626 = 9401196923834 := by decide
theorem cert_e605103901626 : check e605103901626 [[.under],[.under]] .three = true := by decide
def e605103901654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605103901654 : Closed e605103901654 ∧ code e605103901654 = 9401196923862 := by decide
theorem cert_e605103901654 : check e605103901654 [[.under],[.under]] .three = true := by decide
def e605103901658 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605103901658 : Closed e605103901658 ∧ code e605103901658 = 9401196923866 := by decide
theorem cert_e605103901658 : check e605103901658 [[.under],[.under]] .three = true := by decide
def e605103901934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605103901934 : Closed e605103901934 ∧ code e605103901934 = 9401196924142 := by decide
theorem cert_e605103901934 : check e605103901934 [[.under],[.under]] .three = true := by decide
def e605103901942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605103901942 : Closed e605103901942 ∧ code e605103901942 = 9401196924150 := by decide
theorem cert_e605103901942 : check e605103901942 [[.under],[.under]] .three = true := by decide
def e605103902318 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605103902318 : Closed e605103902318 ∧ code e605103902318 = 9401196924526 := by decide
theorem cert_e605103902318 : check e605103902318 [[.under],[.under]] .three = true := by decide
def e605103902330 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605103902330 : Closed e605103902330 ∧ code e605103902330 = 9401196924538 := by decide
theorem cert_e605103902330 : check e605103902330 [[.under],[.under]] .three = true := by decide
def e605103902518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605103902518 : Closed e605103902518 ∧ code e605103902518 = 9401196924726 := by decide
theorem cert_e605103902518 : check e605103902518 [[.under],[.under]] .three = true := by decide
def e605103902522 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605103902522 : Closed e605103902522 ∧ code e605103902522 = 9401196924730 := by decide
theorem cert_e605103902522 : check e605103902522 [[.under],[.under]] .three = true := by decide
def e605103908270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605103908270 : Closed e605103908270 ∧ code e605103908270 = 9401196930478 := by decide
theorem cert_e605103908270 : check e605103908270 [[.under],[.under]] .three = true := by decide
def e605103908282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605103908282 : Closed e605103908282 ∧ code e605103908282 = 9401196930490 := by decide
theorem cert_e605103908282 : check e605103908282 [[.under],[.under]] .three = true := by decide
def e605103908330 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605103908330 : Closed e605103908330 ∧ code e605103908330 = 9401196930538 := by decide
theorem cert_e605103908330 : check e605103908330 [[.under],[.under]] .three = true := by decide
def e605103908462 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605103908462 : Closed e605103908462 ∧ code e605103908462 = 9401196930670 := by decide
theorem cert_e605103908462 : check e605103908462 [[.under],[.under]] .three = true := by decide
def e605103908474 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605103908474 : Closed e605103908474 ∧ code e605103908474 = 9401196930682 := by decide
theorem cert_e605103908474 : check e605103908474 [[.under],[.under]] .three = true := by decide
def e605103908762 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605103908762 : Closed e605103908762 ∧ code e605103908762 = 9401196930970 := by decide
theorem cert_e605103908762 : check e605103908762 [[.under],[.under]] .three = true := by decide
def e605103911638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605103911638 : Closed e605103911638 ∧ code e605103911638 = 9401196933846 := by decide
theorem cert_e605103911638 : check e605103911638 [[.under],[.under]] .three = true := by decide
def e605103911642 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605103911642 : Closed e605103911642 ∧ code e605103911642 = 9401196933850 := by decide
theorem cert_e605103911642 : check e605103911642 [[.under],[.under]] .three = true := by decide
def e605103911658 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605103911658 : Closed e605103911658 ∧ code e605103911658 = 9401196933866 := by decide
theorem cert_e605103911658 : check e605103911658 [[.under],[.under]] .three = true := by decide
def e605103911734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605103911734 : Closed e605103911734 ∧ code e605103911734 = 9401196933942 := by decide
theorem cert_e605103911734 : check e605103911734 [[.under],[.under]] .three = true := by decide
def e605103911738 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605103911738 : Closed e605103911738 ∧ code e605103911738 = 9401196933946 := by decide
theorem cert_e605103911738 : check e605103911738 [[.under],[.under]] .three = true := by decide
def e605103911834 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605103911834 : Closed e605103911834 ∧ code e605103911834 = 9401196934042 := by decide
theorem cert_e605103911834 : check e605103911834 [[.under],[.under]] .three = true := by decide
def e605104049006 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605104049006 : Closed e605104049006 ∧ code e605104049006 = 9401197071214 := by decide
theorem cert_e605104049006 : check e605104049006 [[.under],[.under]] .chain = true := by decide
def e605104049014 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605104049014 : Closed e605104049014 ∧ code e605104049014 = 9401197071222 := by decide
theorem cert_e605104049014 : check e605104049014 [[.under],[.under]] .chain = true := by decide
def e605104049070 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605104049070 : Closed e605104049070 ∧ code e605104049070 = 9401197071278 := by decide
theorem cert_e605104049070 : check e605104049070 [[.under],[.under]] .chain = true := by decide
def e605104049082 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605104049082 : Closed e605104049082 ∧ code e605104049082 = 9401197071290 := by decide
theorem cert_e605104049082 : check e605104049082 [[.under],[.under]] .chain = true := by decide
def e605104049110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605104049110 : Closed e605104049110 ∧ code e605104049110 = 9401197071318 := by decide
theorem cert_e605104049110 : check e605104049110 [[.under],[.under]] .chain = true := by decide
def e605104049114 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605104049114 : Closed e605104049114 ∧ code e605104049114 = 9401197071322 := by decide
theorem cert_e605104049114 : check e605104049114 [[.under],[.under]] .chain = true := by decide
def e605104049390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605104049390 : Closed e605104049390 ∧ code e605104049390 = 9401197071598 := by decide
theorem cert_e605104049390 : check e605104049390 [[.under],[.under]] .chain = true := by decide
def e605104049398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605104049398 : Closed e605104049398 ∧ code e605104049398 = 9401197071606 := by decide
theorem cert_e605104049398 : check e605104049398 [[.under],[.under]] .chain = true := by decide
def e605104049774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605104049774 : Closed e605104049774 ∧ code e605104049774 = 9401197071982 := by decide
theorem cert_e605104049774 : check e605104049774 [[.under],[.under]] .chain = true := by decide
def e605104049786 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605104049786 : Closed e605104049786 ∧ code e605104049786 = 9401197071994 := by decide
theorem cert_e605104049786 : check e605104049786 [[.under],[.under]] .chain = true := by decide
def e605104049974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605104049974 : Closed e605104049974 ∧ code e605104049974 = 9401197072182 := by decide
theorem cert_e605104049974 : check e605104049974 [[.under],[.under]] .chain = true := by decide
def e605104049978 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605104049978 : Closed e605104049978 ∧ code e605104049978 = 9401197072186 := by decide
theorem cert_e605104049978 : check e605104049978 [[.under],[.under]] .chain = true := by decide
def e605104638830 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605104638830 : Closed e605104638830 ∧ code e605104638830 = 9401197661038 := by decide
theorem cert_e605104638830 : check e605104638830 [[.under],[.under]] .sourceHead = true := by decide
def e605104638838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605104638838 : Closed e605104638838 ∧ code e605104638838 = 9401197661046 := by decide
theorem cert_e605104638838 : check e605104638838 [[.under],[.under]] .sourceHead = true := by decide
def e605104638894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605104638894 : Closed e605104638894 ∧ code e605104638894 = 9401197661102 := by decide
theorem cert_e605104638894 : check e605104638894 [[.under],[.under]] .sourceHead = true := by decide
def e605104638906 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605104638906 : Closed e605104638906 ∧ code e605104638906 = 9401197661114 := by decide
theorem cert_e605104638906 : check e605104638906 [[.under],[.under]] .sourceHead = true := by decide
def e605104638934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605104638934 : Closed e605104638934 ∧ code e605104638934 = 9401197661142 := by decide
theorem cert_e605104638934 : check e605104638934 [[.under],[.under]] .sourceHead = true := by decide
def e605104638938 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605104638938 : Closed e605104638938 ∧ code e605104638938 = 9401197661146 := by decide
theorem cert_e605104638938 : check e605104638938 [[.under],[.under]] .sourceHead = true := by decide
def e605104639214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605104639214 : Closed e605104639214 ∧ code e605104639214 = 9401197661422 := by decide
theorem cert_e605104639214 : check e605104639214 [[.under],[.under]] .sourceHead = true := by decide
def e605104639222 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605104639222 : Closed e605104639222 ∧ code e605104639222 = 9401197661430 := by decide
theorem cert_e605104639222 : check e605104639222 [[.under],[.under]] .sourceHead = true := by decide
def e605104639598 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605104639598 : Closed e605104639598 ∧ code e605104639598 = 9401197661806 := by decide
theorem cert_e605104639598 : check e605104639598 [[.under],[.under]] .sourceHead = true := by decide
def e605104639610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605104639610 : Closed e605104639610 ∧ code e605104639610 = 9401197661818 := by decide
theorem cert_e605104639610 : check e605104639610 [[.under],[.under]] .sourceHead = true := by decide
def e605104639798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605104639798 : Closed e605104639798 ∧ code e605104639798 = 9401197662006 := by decide
theorem cert_e605104639798 : check e605104639798 [[.under],[.under]] .sourceHead = true := by decide
def e605104639802 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605104639802 : Closed e605104639802 ∧ code e605104639802 = 9401197662010 := by decide
theorem cert_e605104639802 : check e605104639802 [[.under],[.under]] .sourceHead = true := by decide
def e605187824350 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605187824350 : Closed e605187824350 ∧ code e605187824350 = 9401280846558 := by decide
theorem cert_e605187824350 : check e605187824350 [[.under],[.under]] .three = true := by decide
def e605187824374 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605187824374 : Closed e605187824374 ∧ code e605187824374 = 9401280846582 := by decide
theorem cert_e605187824374 : check e605187824374 [[.under],[.under]] .three = true := by decide
def e605187824478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605187824478 : Closed e605187824478 ∧ code e605187824478 = 9401280846686 := by decide
theorem cert_e605187824478 : check e605187824478 [[.under],[.under]] .three = true := by decide
def e605187824494 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605187824494 : Closed e605187824494 ∧ code e605187824494 = 9401280846702 := by decide
theorem cert_e605187824494 : check e605187824494 [[.under],[.under]] .smaller = true := by decide
def e605187824502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605187824502 : Closed e605187824502 ∧ code e605187824502 = 9401280846710 := by decide
theorem cert_e605187824502 : check e605187824502 [[.under],[.under]] .smaller = true := by decide
def e605187824506 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605187824506 : Closed e605187824506 ∧ code e605187824506 = 9401280846714 := by decide
theorem cert_e605187824506 : check e605187824506 [[.under],[.under]] .three = true := by decide
def e605187824566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605187824566 : Closed e605187824566 ∧ code e605187824566 = 9401280846774 := by decide
theorem cert_e605187824566 : check e605187824566 [[.under],[.under]] .smaller = true := by decide
def e605187824598 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605187824598 : Closed e605187824598 ∧ code e605187824598 = 9401280846806 := by decide
theorem cert_e605187824598 : check e605187824598 [[.under],[.under]] .three = true := by decide
def e605187824602 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605187824602 : Closed e605187824602 ∧ code e605187824602 = 9401280846810 := by decide
theorem cert_e605187824602 : check e605187824602 [[.under],[.under]] .three = true := by decide
def e605187824990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605187824990 : Closed e605187824990 ∧ code e605187824990 = 9401280847198 := by decide
theorem cert_e605187824990 : check e605187824990 [[.under],[.under]] .three = true := by decide
def e605187825006 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605187825006 : Closed e605187825006 ∧ code e605187825006 = 9401280847214 := by decide
theorem cert_e605187825006 : check e605187825006 [[.under],[.under]] .smaller = true := by decide
def e605187825014 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605187825014 : Closed e605187825014 ∧ code e605187825014 = 9401280847222 := by decide
theorem cert_e605187825014 : check e605187825014 [[.under],[.under]] .smaller = true := by decide
def e605187825018 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605187825018 : Closed e605187825018 ∧ code e605187825018 = 9401280847226 := by decide
theorem cert_e605187825018 : check e605187825018 [[.under],[.under]] .three = true := by decide
def e605187825070 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605187825070 : Closed e605187825070 ∧ code e605187825070 = 9401280847278 := by decide
theorem cert_e605187825070 : check e605187825070 [[.under],[.under]] .smaller = true := by decide
def e605187825082 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605187825082 : Closed e605187825082 ∧ code e605187825082 = 9401280847290 := by decide
theorem cert_e605187825082 : check e605187825082 [[.under],[.under]] .smaller = true := by decide
def e605187825110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605187825110 : Closed e605187825110 ∧ code e605187825110 = 9401280847318 := by decide
theorem cert_e605187825110 : check e605187825110 [[.under],[.under]] .smaller = true := by decide
def e605187825114 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605187825114 : Closed e605187825114 ∧ code e605187825114 = 9401280847322 := by decide
theorem cert_e605187825114 : check e605187825114 [[.under],[.under]] .smaller = true := by decide
def e605187825130 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605187825130 : Closed e605187825130 ∧ code e605187825130 = 9401280847338 := by decide
theorem cert_e605187825130 : check e605187825130 [[.under],[.under]] .three = true := by decide
def e605187825334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605187825334 : Closed e605187825334 ∧ code e605187825334 = 9401280847542 := by decide
theorem cert_e605187825334 : check e605187825334 [[.under],[.under]] .smaller = true := by decide
def e605187825366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605187825366 : Closed e605187825366 ∧ code e605187825366 = 9401280847574 := by decide
theorem cert_e605187825366 : check e605187825366 [[.under],[.under]] .smaller = true := by decide
def e605187825370 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605187825370 : Closed e605187825370 ∧ code e605187825370 = 9401280847578 := by decide
theorem cert_e605187825370 : check e605187825370 [[.under],[.under]] .smaller = true := by decide
def e605187825494 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605187825494 : Closed e605187825494 ∧ code e605187825494 = 9401280847702 := by decide
theorem cert_e605187825494 : check e605187825494 [[.under],[.under]] .three = true := by decide
def e605187825498 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605187825498 : Closed e605187825498 ∧ code e605187825498 = 9401280847706 := by decide
theorem cert_e605187825498 : check e605187825498 [[.under],[.under]] .three = true := by decide
def e605187825514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605187825514 : Closed e605187825514 ∧ code e605187825514 = 9401280847722 := by decide
theorem cert_e605187825514 : check e605187825514 [[.under],[.under]] .three = true := by decide
def e605187827422 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605187827422 : Closed e605187827422 ∧ code e605187827422 = 9401280849630 := by decide
theorem cert_e605187827422 : check e605187827422 [[.under],[.under]] .three = true := by decide
def e605187827446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605187827446 : Closed e605187827446 ∧ code e605187827446 = 9401280849654 := by decide
theorem cert_e605187827446 : check e605187827446 [[.under],[.under]] .three = true := by decide
def e605187827550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605187827550 : Closed e605187827550 ∧ code e605187827550 = 9401280849758 := by decide
theorem cert_e605187827550 : check e605187827550 [[.under],[.under]] .three = true := by decide
def e605187827566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605187827566 : Closed e605187827566 ∧ code e605187827566 = 9401280849774 := by decide
theorem cert_e605187827566 : check e605187827566 [[.under],[.under]] .smaller = true := by decide
def e605187827574 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605187827574 : Closed e605187827574 ∧ code e605187827574 = 9401280849782 := by decide
theorem cert_e605187827574 : check e605187827574 [[.under],[.under]] .smaller = true := by decide
def e605187827578 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605187827578 : Closed e605187827578 ∧ code e605187827578 = 9401280849786 := by decide
theorem cert_e605187827578 : check e605187827578 [[.under],[.under]] .three = true := by decide
def e605187827638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605187827638 : Closed e605187827638 ∧ code e605187827638 = 9401280849846 := by decide
theorem cert_e605187827638 : check e605187827638 [[.under],[.under]] .smaller = true := by decide
def e605187827670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605187827670 : Closed e605187827670 ∧ code e605187827670 = 9401280849878 := by decide
theorem cert_e605187827670 : check e605187827670 [[.under],[.under]] .three = true := by decide
def e605187827674 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605187827674 : Closed e605187827674 ∧ code e605187827674 = 9401280849882 := by decide
theorem cert_e605187827674 : check e605187827674 [[.under],[.under]] .three = true := by decide
def e605187828190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605187828190 : Closed e605187828190 ∧ code e605187828190 = 9401280850398 := by decide
theorem cert_e605187828190 : check e605187828190 [[.under],[.under]] .three = true := by decide
def e605187828214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605187828214 : Closed e605187828214 ∧ code e605187828214 = 9401280850422 := by decide
theorem cert_e605187828214 : check e605187828214 [[.under],[.under]] .three = true := by decide
def e605187828958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605187828958 : Closed e605187828958 ∧ code e605187828958 = 9401280851166 := by decide
theorem cert_e605187828958 : check e605187828958 [[.under],[.under]] .three = true := by decide
def e605187828974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605187828974 : Closed e605187828974 ∧ code e605187828974 = 9401280851182 := by decide
theorem cert_e605187828974 : check e605187828974 [[.under],[.under]] .smaller = true := by decide
def e605187828982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605187828982 : Closed e605187828982 ∧ code e605187828982 = 9401280851190 := by decide
theorem cert_e605187828982 : check e605187828982 [[.under],[.under]] .smaller = true := by decide
def e605187828986 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605187828986 : Closed e605187828986 ∧ code e605187828986 = 9401280851194 := by decide
theorem cert_e605187828986 : check e605187828986 [[.under],[.under]] .three = true := by decide
def e605187829366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605187829366 : Closed e605187829366 ∧ code e605187829366 = 9401280851574 := by decide
theorem cert_e605187829366 : check e605187829366 [[.under],[.under]] .smaller = true := by decide
def e605187829558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605187829558 : Closed e605187829558 ∧ code e605187829558 = 9401280851766 := by decide
theorem cert_e605187829558 : check e605187829558 [[.under],[.under]] .three = true := by decide
def e605187829562 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605187829562 : Closed e605187829562 ∧ code e605187829562 = 9401280851770 := by decide
theorem cert_e605187829562 : check e605187829562 [[.under],[.under]] .three = true := by decide
def e605187830622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605187830622 : Closed e605187830622 ∧ code e605187830622 = 9401280852830 := by decide
theorem cert_e605187830622 : check e605187830622 [[.under],[.under]] .three = true := by decide
def e605187830638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605187830638 : Closed e605187830638 ∧ code e605187830638 = 9401280852846 := by decide
theorem cert_e605187830638 : check e605187830638 [[.under],[.under]] .smaller = true := by decide
def e605187830646 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605187830646 : Closed e605187830646 ∧ code e605187830646 = 9401280852854 := by decide
theorem cert_e605187830646 : check e605187830646 [[.under],[.under]] .smaller = true := by decide
def e605187830650 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605187830650 : Closed e605187830650 ∧ code e605187830650 = 9401280852858 := by decide
theorem cert_e605187830650 : check e605187830650 [[.under],[.under]] .three = true := by decide
def e605187830702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605187830702 : Closed e605187830702 ∧ code e605187830702 = 9401280852910 := by decide
theorem cert_e605187830702 : check e605187830702 [[.under],[.under]] .smaller = true := by decide
def e605187830714 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605187830714 : Closed e605187830714 ∧ code e605187830714 = 9401280852922 := by decide
theorem cert_e605187830714 : check e605187830714 [[.under],[.under]] .smaller = true := by decide
def e605187830742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605187830742 : Closed e605187830742 ∧ code e605187830742 = 9401280852950 := by decide
theorem cert_e605187830742 : check e605187830742 [[.under],[.under]] .smaller = true := by decide
def e605187830746 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605187830746 : Closed e605187830746 ∧ code e605187830746 = 9401280852954 := by decide
theorem cert_e605187830746 : check e605187830746 [[.under],[.under]] .smaller = true := by decide
def e605187830762 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605187830762 : Closed e605187830762 ∧ code e605187830762 = 9401280852970 := by decide
theorem cert_e605187830762 : check e605187830762 [[.under],[.under]] .three = true := by decide
def e605187831006 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605187831006 : Closed e605187831006 ∧ code e605187831006 = 9401280853214 := by decide
theorem cert_e605187831006 : check e605187831006 [[.under],[.under]] .three = true := by decide
def e605187831022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605187831022 : Closed e605187831022 ∧ code e605187831022 = 9401280853230 := by decide
theorem cert_e605187831022 : check e605187831022 [[.under],[.under]] .smaller = true := by decide
def e605187831030 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605187831030 : Closed e605187831030 ∧ code e605187831030 = 9401280853238 := by decide
theorem cert_e605187831030 : check e605187831030 [[.under],[.under]] .smaller = true := by decide
def e605187831034 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605187831034 : Closed e605187831034 ∧ code e605187831034 = 9401280853242 := by decide
theorem cert_e605187831034 : check e605187831034 [[.under],[.under]] .three = true := by decide
def e605187831406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605187831406 : Closed e605187831406 ∧ code e605187831406 = 9401280853614 := by decide
theorem cert_e605187831406 : check e605187831406 [[.under],[.under]] .smaller = true := by decide
def e605187831418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605187831418 : Closed e605187831418 ∧ code e605187831418 = 9401280853626 := by decide
theorem cert_e605187831418 : check e605187831418 [[.under],[.under]] .smaller = true := by decide
def e605187831606 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605187831606 : Closed e605187831606 ∧ code e605187831606 = 9401280853814 := by decide
theorem cert_e605187831606 : check e605187831606 [[.under],[.under]] .smaller = true := by decide
def e605187831610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605187831610 : Closed e605187831610 ∧ code e605187831610 = 9401280853818 := by decide
theorem cert_e605187831610 : check e605187831610 [[.under],[.under]] .smaller = true := by decide
def e605187831706 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605187831706 : Closed e605187831706 ∧ code e605187831706 = 9401280853914 := by decide
theorem cert_e605187831706 : check e605187831706 [[.under],[.under]] .three = true := by decide
def e605187832246 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605187832246 : Closed e605187832246 ∧ code e605187832246 = 9401280854454 := by decide
theorem cert_e605187832246 : check e605187832246 [[.under],[.under]] .smaller = true := by decide
def e605187832278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605187832278 : Closed e605187832278 ∧ code e605187832278 = 9401280854486 := by decide
theorem cert_e605187832278 : check e605187832278 [[.under],[.under]] .smaller = true := by decide
def e605187832282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605187832282 : Closed e605187832282 ∧ code e605187832282 = 9401280854490 := by decide
theorem cert_e605187832282 : check e605187832282 [[.under],[.under]] .smaller = true := by decide
def e605187832438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605187832438 : Closed e605187832438 ∧ code e605187832438 = 9401280854646 := by decide
theorem cert_e605187832438 : check e605187832438 [[.under],[.under]] .smaller = true := by decide
def e605187832630 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605187832630 : Closed e605187832630 ∧ code e605187832630 = 9401280854838 := by decide
theorem cert_e605187832630 : check e605187832630 [[.under],[.under]] .smaller = true := by decide
def e605187832634 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605187832634 : Closed e605187832634 ∧ code e605187832634 = 9401280854842 := by decide
theorem cert_e605187832634 : check e605187832634 [[.under],[.under]] .smaller = true := by decide
def e605187833046 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605187833046 : Closed e605187833046 ∧ code e605187833046 = 9401280855254 := by decide
theorem cert_e605187833046 : check e605187833046 [[.under],[.under]] .three = true := by decide
def e605187833050 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605187833050 : Closed e605187833050 ∧ code e605187833050 = 9401280855258 := by decide
theorem cert_e605187833050 : check e605187833050 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
