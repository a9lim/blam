import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373953070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373953070 : Closed e2422373953070 ∧ code e2422373953070 = 11218466975278 := by decide
theorem cert_e2422373953070 : check e2422373953070 [[],[]] .smaller = true := by decide
def e2422373953078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373953078 : Closed e2422373953078 ∧ code e2422373953078 = 11218466975286 := by decide
theorem cert_e2422373953078 : check e2422373953078 [[],[]] .smaller = true := by decide
def e2422373953082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373953082 : Closed e2422373953082 ∧ code e2422373953082 = 11218466975290 := by decide
theorem cert_e2422373953082 : check e2422373953082 [[],[]] .smaller = true := by decide
def e2422373953130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422373953130 : Closed e2422373953130 ∧ code e2422373953130 = 11218466975338 := by decide
theorem cert_e2422373953130 : check e2422373953130 [[],[]] .smaller = true := by decide
def e2422373953154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373953154 : Closed e2422373953154 ∧ code e2422373953154 = 11218466975362 := by decide
theorem cert_e2422373953154 : check e2422373953154 [[],[]] .smaller = true := by decide
def e2422373953166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373953166 : Closed e2422373953166 ∧ code e2422373953166 = 11218466975374 := by decide
theorem cert_e2422373953166 : check e2422373953166 [[],[]] .smaller = true := by decide
def e2422373953178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373953178 : Closed e2422373953178 ∧ code e2422373953178 = 11218466975386 := by decide
theorem cert_e2422373953178 : check e2422373953178 [[],[]] .smaller = true := by decide
def e2422373953222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373953222 : Closed e2422373953222 ∧ code e2422373953222 = 11218466975430 := by decide
theorem cert_e2422373953222 : check e2422373953222 [[],[]] .smaller = true := by decide
def e2422373953246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2422373953246 : Closed e2422373953246 ∧ code e2422373953246 = 11218466975454 := by decide
theorem cert_e2422373953246 : check e2422373953246 [[],[]] .three = true := by decide
def e2422373953250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373953250 : Closed e2422373953250 ∧ code e2422373953250 = 11218466975458 := by decide
theorem cert_e2422373953250 : check e2422373953250 [[],[]] .smaller = true := by decide
def e2422373953262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2422373953262 : Closed e2422373953262 ∧ code e2422373953262 = 11218466975470 := by decide
theorem cert_e2422373953262 : check e2422373953262 [[],[]] .smaller = true := by decide
def e2422373953270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2422373953270 : Closed e2422373953270 ∧ code e2422373953270 = 11218466975478 := by decide
theorem cert_e2422373953270 : check e2422373953270 [[],[]] .three = true := by decide
def e2422373953302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422373953302 : Closed e2422373953302 ∧ code e2422373953302 = 11218466975510 := by decide
theorem cert_e2422373953302 : check e2422373953302 [[],[]] .smaller = true := by decide
def e2422373953374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2422373953374 : Closed e2422373953374 ∧ code e2422373953374 = 11218466975582 := by decide
theorem cert_e2422373953374 : check e2422373953374 [[],[]] .three = true := by decide
def e2422373953378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422373953378 : Closed e2422373953378 ∧ code e2422373953378 = 11218466975586 := by decide
theorem cert_e2422373953378 : check e2422373953378 [[],[]] .smaller = true := by decide
def e2422373953390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2422373953390 : Closed e2422373953390 ∧ code e2422373953390 = 11218466975598 := by decide
theorem cert_e2422373953390 : check e2422373953390 [[],[]] .smaller = true := by decide
def e2422373953398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2422373953398 : Closed e2422373953398 ∧ code e2422373953398 = 11218466975606 := by decide
theorem cert_e2422373953398 : check e2422373953398 [[],[]] .smaller = true := by decide
def e2422373953402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2422373953402 : Closed e2422373953402 ∧ code e2422373953402 = 11218466975610 := by decide
theorem cert_e2422373953402 : check e2422373953402 [[],[]] .three = true := by decide
def e2422373953418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373953418 : Closed e2422373953418 ∧ code e2422373953418 = 11218466975626 := by decide
theorem cert_e2422373953418 : check e2422373953418 [[],[]] .three = true := by decide
def e2422373953442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373953442 : Closed e2422373953442 ∧ code e2422373953442 = 11218466975650 := by decide
theorem cert_e2422373953442 : check e2422373953442 [[],[]] .three = true := by decide
def e2422373953454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2422373953454 : Closed e2422373953454 ∧ code e2422373953454 = 11218466975662 := by decide
theorem cert_e2422373953454 : check e2422373953454 [[],[]] .three = true := by decide
def e2422373953462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2422373953462 : Closed e2422373953462 ∧ code e2422373953462 = 11218466975670 := by decide
theorem cert_e2422373953462 : check e2422373953462 [[],[]] .three = true := by decide
def e2422373953466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2422373953466 : Closed e2422373953466 ∧ code e2422373953466 = 11218466975674 := by decide
theorem cert_e2422373953466 : check e2422373953466 [[],[]] .three = true := by decide
def e2422373953662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 5))))))))))
theorem wire_e2422373953662 : Closed e2422373953662 ∧ code e2422373953662 = 11218466975870 := by decide
theorem cert_e2422373953662 : check e2422373953662 [[],[]] .three = true := by decide
def e2422373953774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373953774 : Closed e2422373953774 ∧ code e2422373953774 = 11218466975982 := by decide
theorem cert_e2422373953774 : check e2422373953774 [[],[]] .smaller = true := by decide
def e2422373953782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373953782 : Closed e2422373953782 ∧ code e2422373953782 = 11218466975990 := by decide
theorem cert_e2422373953782 : check e2422373953782 [[],[]] .smaller = true := by decide
def e2422373954262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422373954262 : Closed e2422373954262 ∧ code e2422373954262 = 11218466976470 := by decide
theorem cert_e2422373954262 : check e2422373954262 [[],[]] .smaller = true := by decide
def e2422373954266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422373954266 : Closed e2422373954266 ∧ code e2422373954266 = 11218466976474 := by decide
theorem cert_e2422373954266 : check e2422373954266 [[],[]] .smaller = true := by decide
def e2422373954282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422373954282 : Closed e2422373954282 ∧ code e2422373954282 = 11218466976490 := by decide
theorem cert_e2422373954282 : check e2422373954282 [[],[]] .smaller = true := by decide
def e2422373954358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373954358 : Closed e2422373954358 ∧ code e2422373954358 = 11218466976566 := by decide
theorem cert_e2422373954358 : check e2422373954358 [[],[]] .smaller = true := by decide
def e2422373954362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373954362 : Closed e2422373954362 ∧ code e2422373954362 = 11218466976570 := by decide
theorem cert_e2422373954362 : check e2422373954362 [[],[]] .smaller = true := by decide
def e2422373954434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373954434 : Closed e2422373954434 ∧ code e2422373954434 = 11218466976642 := by decide
theorem cert_e2422373954434 : check e2422373954434 [[],[]] .smaller = true := by decide
def e2422373954446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422373954446 : Closed e2422373954446 ∧ code e2422373954446 = 11218466976654 := by decide
theorem cert_e2422373954446 : check e2422373954446 [[],[]] .smaller = true := by decide
def e2422373954458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373954458 : Closed e2422373954458 ∧ code e2422373954458 = 11218466976666 := by decide
theorem cert_e2422373954458 : check e2422373954458 [[],[]] .smaller = true := by decide
def e2422373954526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373954526 : Closed e2422373954526 ∧ code e2422373954526 = 11218466976734 := by decide
theorem cert_e2422373954526 : check e2422373954526 [[],[]] .three = true := by decide
def e2422373954530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422373954530 : Closed e2422373954530 ∧ code e2422373954530 = 11218466976738 := by decide
theorem cert_e2422373954530 : check e2422373954530 [[],[]] .three = true := by decide
def e2422373954542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373954542 : Closed e2422373954542 ∧ code e2422373954542 = 11218466976750 := by decide
theorem cert_e2422373954542 : check e2422373954542 [[],[]] .three = true := by decide
def e2422373955610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422373955610 : Closed e2422373955610 ∧ code e2422373955610 = 11218466977818 := by decide
theorem cert_e2422373955610 : check e2422373955610 [[],[]] .smaller = true := by decide
def e2422373955646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373955646 : Closed e2422373955646 ∧ code e2422373955646 = 11218466977854 := by decide
theorem cert_e2422373955646 : check e2422373955646 [[],[]] .smaller = true := by decide
def e2422373955694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373955694 : Closed e2422373955694 ∧ code e2422373955694 = 11218466977902 := by decide
theorem cert_e2422373955694 : check e2422373955694 [[],[]] .smaller = true := by decide
def e2422373955702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373955702 : Closed e2422373955702 ∧ code e2422373955702 = 11218466977910 := by decide
theorem cert_e2422373955702 : check e2422373955702 [[],[]] .smaller = true := by decide
def e2422373955706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373955706 : Closed e2422373955706 ∧ code e2422373955706 = 11218466977914 := by decide
theorem cert_e2422373955706 : check e2422373955706 [[],[]] .smaller = true := by decide
def e2422373955946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422373955946 : Closed e2422373955946 ∧ code e2422373955946 = 11218466978154 := by decide
theorem cert_e2422373955946 : check e2422373955946 [[],[]] .smaller = true := by decide
def e2422373955970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373955970 : Closed e2422373955970 ∧ code e2422373955970 = 11218466978178 := by decide
theorem cert_e2422373955970 : check e2422373955970 [[],[]] .smaller = true := by decide
def e2422373955982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373955982 : Closed e2422373955982 ∧ code e2422373955982 = 11218466978190 := by decide
theorem cert_e2422373955982 : check e2422373955982 [[],[]] .smaller = true := by decide
def e2422373955994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373955994 : Closed e2422373955994 ∧ code e2422373955994 = 11218466978202 := by decide
theorem cert_e2422373955994 : check e2422373955994 [[],[]] .smaller = true := by decide
def e2422373956038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373956038 : Closed e2422373956038 ∧ code e2422373956038 = 11218466978246 := by decide
theorem cert_e2422373956038 : check e2422373956038 [[],[]] .smaller = true := by decide
def e2422373956062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373956062 : Closed e2422373956062 ∧ code e2422373956062 = 11218466978270 := by decide
theorem cert_e2422373956062 : check e2422373956062 [[],[]] .three = true := by decide
def e2422373956066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373956066 : Closed e2422373956066 ∧ code e2422373956066 = 11218466978274 := by decide
theorem cert_e2422373956066 : check e2422373956066 [[],[]] .smaller = true := by decide
def e2422373956078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373956078 : Closed e2422373956078 ∧ code e2422373956078 = 11218466978286 := by decide
theorem cert_e2422373956078 : check e2422373956078 [[],[]] .smaller = true := by decide
def e2422373956086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373956086 : Closed e2422373956086 ∧ code e2422373956086 = 11218466978294 := by decide
theorem cert_e2422373956086 : check e2422373956086 [[],[]] .three = true := by decide
def e2422373956638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2422373956638 : Closed e2422373956638 ∧ code e2422373956638 = 11218466978846 := by decide
theorem cert_e2422373956638 : check e2422373956638 [[],[]] .smaller = true := by decide
def e2422373956830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373956830 : Closed e2422373956830 ∧ code e2422373956830 = 11218466979038 := by decide
theorem cert_e2422373956830 : check e2422373956830 [[],[]] .three = true := by decide
def e2422373956834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422373956834 : Closed e2422373956834 ∧ code e2422373956834 = 11218466979042 := by decide
theorem cert_e2422373956834 : check e2422373956834 [[],[]] .smaller = true := by decide
def e2422373956846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373956846 : Closed e2422373956846 ∧ code e2422373956846 = 11218466979054 := by decide
theorem cert_e2422373956846 : check e2422373956846 [[],[]] .smaller = true := by decide
def e2422373956854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373956854 : Closed e2422373956854 ∧ code e2422373956854 = 11218466979062 := by decide
theorem cert_e2422373956854 : check e2422373956854 [[],[]] .smaller = true := by decide
def e2422373956858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373956858 : Closed e2422373956858 ∧ code e2422373956858 = 11218466979066 := by decide
theorem cert_e2422373956858 : check e2422373956858 [[],[]] .three = true := by decide
def e2422373957134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373957134 : Closed e2422373957134 ∧ code e2422373957134 = 11218466979342 := by decide
theorem cert_e2422373957134 : check e2422373957134 [[],[]] .three = true := by decide
def e2422373957146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373957146 : Closed e2422373957146 ∧ code e2422373957146 = 11218466979354 := by decide
theorem cert_e2422373957146 : check e2422373957146 [[],[]] .three = true := by decide
def e2422373957182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.var 4)))))))))
theorem wire_e2422373957182 : Closed e2422373957182 ∧ code e2422373957182 = 11218466979390 := by decide
theorem cert_e2422373957182 : check e2422373957182 [[],[]] .three = true := by decide
def e2422373957218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373957218 : Closed e2422373957218 ∧ code e2422373957218 = 11218466979426 := by decide
theorem cert_e2422373957218 : check e2422373957218 [[],[]] .three = true := by decide
def e2422373957230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373957230 : Closed e2422373957230 ∧ code e2422373957230 = 11218466979438 := by decide
theorem cert_e2422373957230 : check e2422373957230 [[],[]] .three = true := by decide
def e2422373957238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373957238 : Closed e2422373957238 ∧ code e2422373957238 = 11218466979446 := by decide
theorem cert_e2422373957238 : check e2422373957238 [[],[]] .three = true := by decide
def e2422373957242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373957242 : Closed e2422373957242 ∧ code e2422373957242 = 11218466979450 := by decide
theorem cert_e2422373957242 : check e2422373957242 [[],[]] .three = true := by decide
def e2422373974510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2422373974510 : Closed e2422373974510 ∧ code e2422373974510 = 11218466996718 := by decide
theorem cert_e2422373974510 : check e2422373974510 [[],[]] .smaller = true := by decide
def e2422373975478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422373975478 : Closed e2422373975478 ∧ code e2422373975478 = 11218466997686 := by decide
theorem cert_e2422373975478 : check e2422373975478 [[],[]] .smaller = true := by decide
def e2422373975510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422373975510 : Closed e2422373975510 ∧ code e2422373975510 = 11218466997718 := by decide
theorem cert_e2422373975510 : check e2422373975510 [[],[]] .smaller = true := by decide
def e2422373975514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422373975514 : Closed e2422373975514 ∧ code e2422373975514 = 11218466997722 := by decide
theorem cert_e2422373975514 : check e2422373975514 [[],[]] .smaller = true := by decide
def e2422373975670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373975670 : Closed e2422373975670 ∧ code e2422373975670 = 11218466997878 := by decide
theorem cert_e2422373975670 : check e2422373975670 [[],[]] .smaller = true := by decide
def e2422373975838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422373975838 : Closed e2422373975838 ∧ code e2422373975838 = 11218466998046 := by decide
theorem cert_e2422373975838 : check e2422373975838 [[],[]] .smaller = true := by decide
def e2422373975862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373975862 : Closed e2422373975862 ∧ code e2422373975862 = 11218466998070 := by decide
theorem cert_e2422373975862 : check e2422373975862 [[],[]] .smaller = true := by decide
def e2422373975866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373975866 : Closed e2422373975866 ∧ code e2422373975866 = 11218466998074 := by decide
theorem cert_e2422373975866 : check e2422373975866 [[],[]] .smaller = true := by decide
def e2422373975950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422373975950 : Closed e2422373975950 ∧ code e2422373975950 = 11218466998158 := by decide
theorem cert_e2422373975950 : check e2422373975950 [[],[]] .smaller = true := by decide
def e2422373975998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e2422373975998 : Closed e2422373975998 ∧ code e2422373975998 = 11218466998206 := by decide
theorem cert_e2422373975998 : check e2422373975998 [[],[]] .three = true := by decide
def e2422373976046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e2422373976046 : Closed e2422373976046 ∧ code e2422373976046 = 11218466998254 := by decide
theorem cert_e2422373976046 : check e2422373976046 [[],[]] .three = true := by decide
def e2422373979562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422373979562 : Closed e2422373979562 ∧ code e2422373979562 = 11218467001770 := by decide
theorem cert_e2422373979562 : check e2422373979562 [[],[]] .smaller = true := by decide
def e2422373979658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422373979658 : Closed e2422373979658 ∧ code e2422373979658 = 11218467001866 := by decide
theorem cert_e2422373979658 : check e2422373979658 [[],[]] .smaller = true := by decide
def e2422373979694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373979694 : Closed e2422373979694 ∧ code e2422373979694 = 11218467001902 := by decide
theorem cert_e2422373979694 : check e2422373979694 [[],[]] .smaller = true := by decide
def e2422373979702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373979702 : Closed e2422373979702 ∧ code e2422373979702 = 11218467001910 := by decide
theorem cert_e2422373979702 : check e2422373979702 [[],[]] .smaller = true := by decide
def e2422373979706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373979706 : Closed e2422373979706 ∧ code e2422373979706 = 11218467001914 := by decide
theorem cert_e2422373979706 : check e2422373979706 [[],[]] .smaller = true := by decide
def e2422373979754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422373979754 : Closed e2422373979754 ∧ code e2422373979754 = 11218467001962 := by decide
theorem cert_e2422373979754 : check e2422373979754 [[],[]] .smaller = true := by decide
def e2422373979778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373979778 : Closed e2422373979778 ∧ code e2422373979778 = 11218467001986 := by decide
theorem cert_e2422373979778 : check e2422373979778 [[],[]] .smaller = true := by decide
def e2422373979790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373979790 : Closed e2422373979790 ∧ code e2422373979790 = 11218467001998 := by decide
theorem cert_e2422373979790 : check e2422373979790 [[],[]] .smaller = true := by decide
def e2422373979802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373979802 : Closed e2422373979802 ∧ code e2422373979802 = 11218467002010 := by decide
theorem cert_e2422373979802 : check e2422373979802 [[],[]] .smaller = true := by decide
def e2422373979846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373979846 : Closed e2422373979846 ∧ code e2422373979846 = 11218467002054 := by decide
theorem cert_e2422373979846 : check e2422373979846 [[],[]] .smaller = true := by decide
def e2422373979870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2422373979870 : Closed e2422373979870 ∧ code e2422373979870 = 11218467002078 := by decide
theorem cert_e2422373979870 : check e2422373979870 [[],[]] .three = true := by decide
def e2422373979874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373979874 : Closed e2422373979874 ∧ code e2422373979874 = 11218467002082 := by decide
theorem cert_e2422373979874 : check e2422373979874 [[],[]] .smaller = true := by decide
def e2422373979886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2422373979886 : Closed e2422373979886 ∧ code e2422373979886 = 11218467002094 := by decide
theorem cert_e2422373979886 : check e2422373979886 [[],[]] .smaller = true := by decide
def e2422373979894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2422373979894 : Closed e2422373979894 ∧ code e2422373979894 = 11218467002102 := by decide
theorem cert_e2422373979894 : check e2422373979894 [[],[]] .three = true := by decide
def e2422373979930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422373979930 : Closed e2422373979930 ∧ code e2422373979930 = 11218467002138 := by decide
theorem cert_e2422373979930 : check e2422373979930 [[],[]] .smaller = true := by decide
def e2422373979974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422373979974 : Closed e2422373979974 ∧ code e2422373979974 = 11218467002182 := by decide
theorem cert_e2422373979974 : check e2422373979974 [[],[]] .smaller = true := by decide
def e2422373979998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2422373979998 : Closed e2422373979998 ∧ code e2422373979998 = 11218467002206 := by decide
theorem cert_e2422373979998 : check e2422373979998 [[],[]] .three = true := by decide
def e2422373980026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2422373980026 : Closed e2422373980026 ∧ code e2422373980026 = 11218467002234 := by decide
theorem cert_e2422373980026 : check e2422373980026 [[],[]] .three = true := by decide
def e2422373980042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373980042 : Closed e2422373980042 ∧ code e2422373980042 = 11218467002250 := by decide
theorem cert_e2422373980042 : check e2422373980042 [[],[]] .smaller = true := by decide
def e2422373980066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373980066 : Closed e2422373980066 ∧ code e2422373980066 = 11218467002274 := by decide
theorem cert_e2422373980066 : check e2422373980066 [[],[]] .smaller = true := by decide
def e2422373980078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2422373980078 : Closed e2422373980078 ∧ code e2422373980078 = 11218467002286 := by decide
theorem cert_e2422373980078 : check e2422373980078 [[],[]] .smaller = true := by decide
def e2422373980090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2422373980090 : Closed e2422373980090 ∧ code e2422373980090 = 11218467002298 := by decide
theorem cert_e2422373980090 : check e2422373980090 [[],[]] .smaller = true := by decide
def e2422373980118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2422373980118 : Closed e2422373980118 ∧ code e2422373980118 = 11218467002326 := by decide
theorem cert_e2422373980118 : check e2422373980118 [[],[]] .three = true := by decide
def e2422373980122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2422373980122 : Closed e2422373980122 ∧ code e2422373980122 = 11218467002330 := by decide
theorem cert_e2422373980122 : check e2422373980122 [[],[]] .three = true := by decide
def e2422373980186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422373980186 : Closed e2422373980186 ∧ code e2422373980186 = 11218467002394 := by decide
theorem cert_e2422373980186 : check e2422373980186 [[],[]] .smaller = true := by decide
def e2422373980222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373980222 : Closed e2422373980222 ∧ code e2422373980222 = 11218467002430 := by decide
theorem cert_e2422373980222 : check e2422373980222 [[],[]] .smaller = true := by decide
def e2422373980270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373980270 : Closed e2422373980270 ∧ code e2422373980270 = 11218467002478 := by decide
theorem cert_e2422373980270 : check e2422373980270 [[],[]] .smaller = true := by decide
def e2422373980278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373980278 : Closed e2422373980278 ∧ code e2422373980278 = 11218467002486 := by decide
theorem cert_e2422373980278 : check e2422373980278 [[],[]] .smaller = true := by decide
def e2422373980282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373980282 : Closed e2422373980282 ∧ code e2422373980282 = 11218467002490 := by decide
theorem cert_e2422373980282 : check e2422373980282 [[],[]] .smaller = true := by decide
def e2422373980522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422373980522 : Closed e2422373980522 ∧ code e2422373980522 = 11218467002730 := by decide
theorem cert_e2422373980522 : check e2422373980522 [[],[]] .smaller = true := by decide
def e2422373980546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373980546 : Closed e2422373980546 ∧ code e2422373980546 = 11218467002754 := by decide
theorem cert_e2422373980546 : check e2422373980546 [[],[]] .smaller = true := by decide
def e2422373980558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373980558 : Closed e2422373980558 ∧ code e2422373980558 = 11218467002766 := by decide
theorem cert_e2422373980558 : check e2422373980558 [[],[]] .smaller = true := by decide
def e2422373980570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373980570 : Closed e2422373980570 ∧ code e2422373980570 = 11218467002778 := by decide
theorem cert_e2422373980570 : check e2422373980570 [[],[]] .smaller = true := by decide
def e2422373980614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373980614 : Closed e2422373980614 ∧ code e2422373980614 = 11218467002822 := by decide
theorem cert_e2422373980614 : check e2422373980614 [[],[]] .smaller = true := by decide
def e2422373980638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373980638 : Closed e2422373980638 ∧ code e2422373980638 = 11218467002846 := by decide
theorem cert_e2422373980638 : check e2422373980638 [[],[]] .three = true := by decide
def e2422373980642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373980642 : Closed e2422373980642 ∧ code e2422373980642 = 11218467002850 := by decide
theorem cert_e2422373980642 : check e2422373980642 [[],[]] .smaller = true := by decide
def e2422373980654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373980654 : Closed e2422373980654 ∧ code e2422373980654 = 11218467002862 := by decide
theorem cert_e2422373980654 : check e2422373980654 [[],[]] .smaller = true := by decide
def e2422373980662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373980662 : Closed e2422373980662 ∧ code e2422373980662 = 11218467002870 := by decide
theorem cert_e2422373980662 : check e2422373980662 [[],[]] .three = true := by decide
def e2422373981238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373981238 : Closed e2422373981238 ∧ code e2422373981238 = 11218467003446 := by decide
theorem cert_e2422373981238 : check e2422373981238 [[],[]] .smaller = true := by decide
def e2422373981242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373981242 : Closed e2422373981242 ∧ code e2422373981242 = 11218467003450 := by decide
theorem cert_e2422373981242 : check e2422373981242 [[],[]] .smaller = true := by decide
def e2422373981382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422373981382 : Closed e2422373981382 ∧ code e2422373981382 = 11218467003590 := by decide
theorem cert_e2422373981382 : check e2422373981382 [[],[]] .smaller = true := by decide
def e2422373981406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373981406 : Closed e2422373981406 ∧ code e2422373981406 = 11218467003614 := by decide
theorem cert_e2422373981406 : check e2422373981406 [[],[]] .three = true := by decide
def e2422373981434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373981434 : Closed e2422373981434 ∧ code e2422373981434 = 11218467003642 := by decide
theorem cert_e2422373981434 : check e2422373981434 [[],[]] .three = true := by decide
def e2422373981710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373981710 : Closed e2422373981710 ∧ code e2422373981710 = 11218467003918 := by decide
theorem cert_e2422373981710 : check e2422373981710 [[],[]] .smaller = true := by decide
def e2422373981758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2422373981758 : Closed e2422373981758 ∧ code e2422373981758 = 11218467003966 := by decide
theorem cert_e2422373981758 : check e2422373981758 [[],[]] .three = true := by decide
def e2422373981794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373981794 : Closed e2422373981794 ∧ code e2422373981794 = 11218467004002 := by decide
theorem cert_e2422373981794 : check e2422373981794 [[],[]] .smaller = true := by decide
def e2422373981806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373981806 : Closed e2422373981806 ∧ code e2422373981806 = 11218467004014 := by decide
theorem cert_e2422373981806 : check e2422373981806 [[],[]] .smaller = true := by decide
def e2422373981818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373981818 : Closed e2422373981818 ∧ code e2422373981818 = 11218467004026 := by decide
theorem cert_e2422373981818 : check e2422373981818 [[],[]] .smaller = true := by decide
def e2422373981982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2422373981982 : Closed e2422373981982 ∧ code e2422373981982 = 11218467004190 := by decide
theorem cert_e2422373981982 : check e2422373981982 [[],[]] .three = true := by decide
def e2422373982006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373982006 : Closed e2422373982006 ∧ code e2422373982006 = 11218467004214 := by decide
theorem cert_e2422373982006 : check e2422373982006 [[],[]] .three = true := by decide
def e2422373982010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373982010 : Closed e2422373982010 ∧ code e2422373982010 = 11218467004218 := by decide
theorem cert_e2422373982010 : check e2422373982010 [[],[]] .three = true := by decide
def e2422373991358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e2422373991358 : Closed e2422373991358 ∧ code e2422373991358 = 11218467013566 := by decide
theorem cert_e2422373991358 : check e2422373991358 [[],[]] .three = true := by decide
def e2422373991414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e2422373991414 : Closed e2422373991414 ∧ code e2422373991414 = 11218467013622 := by decide
theorem cert_e2422373991414 : check e2422373991414 [[],[]] .three = true := by decide
def e2422373993238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422373993238 : Closed e2422373993238 ∧ code e2422373993238 = 11218467015446 := by decide
theorem cert_e2422373993238 : check e2422373993238 [[],[]] .smaller = true := by decide
def e2422373993310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2422373993310 : Closed e2422373993310 ∧ code e2422373993310 = 11218467015518 := by decide
theorem cert_e2422373993310 : check e2422373993310 [[],[]] .three = true := by decide
def e2422373993314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422373993314 : Closed e2422373993314 ∧ code e2422373993314 = 11218467015522 := by decide
theorem cert_e2422373993314 : check e2422373993314 [[],[]] .smaller = true := by decide
def e2422373993326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422373993326 : Closed e2422373993326 ∧ code e2422373993326 = 11218467015534 := by decide
theorem cert_e2422373993326 : check e2422373993326 [[],[]] .smaller = true := by decide
def e2422373993334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422373993334 : Closed e2422373993334 ∧ code e2422373993334 = 11218467015542 := by decide
theorem cert_e2422373993334 : check e2422373993334 [[],[]] .smaller = true := by decide
def e2422373993338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2422373993338 : Closed e2422373993338 ∧ code e2422373993338 = 11218467015546 := by decide
theorem cert_e2422373993338 : check e2422373993338 [[],[]] .three = true := by decide
def e2422373993354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373993354 : Closed e2422373993354 ∧ code e2422373993354 = 11218467015562 := by decide
theorem cert_e2422373993354 : check e2422373993354 [[],[]] .smaller = true := by decide
def e2422373993378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373993378 : Closed e2422373993378 ∧ code e2422373993378 = 11218467015586 := by decide
theorem cert_e2422373993378 : check e2422373993378 [[],[]] .smaller = true := by decide
def e2422373993390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422373993390 : Closed e2422373993390 ∧ code e2422373993390 = 11218467015598 := by decide
theorem cert_e2422373993390 : check e2422373993390 [[],[]] .smaller = true := by decide
def e2422373993402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422373993402 : Closed e2422373993402 ∧ code e2422373993402 = 11218467015610 := by decide
theorem cert_e2422373993402 : check e2422373993402 [[],[]] .smaller = true := by decide
def e2422373993430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422373993430 : Closed e2422373993430 ∧ code e2422373993430 = 11218467015638 := by decide
theorem cert_e2422373993430 : check e2422373993430 [[],[]] .smaller = true := by decide
def e2422373993434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422373993434 : Closed e2422373993434 ∧ code e2422373993434 = 11218467015642 := by decide
theorem cert_e2422373993434 : check e2422373993434 [[],[]] .smaller = true := by decide
def e2422373993450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2422373993450 : Closed e2422373993450 ∧ code e2422373993450 = 11218467015658 := by decide
theorem cert_e2422373993450 : check e2422373993450 [[],[]] .three = true := by decide
def e2422373993502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2422373993502 : Closed e2422373993502 ∧ code e2422373993502 = 11218467015710 := by decide
theorem cert_e2422373993502 : check e2422373993502 [[],[]] .smaller = true := by decide
def e2422373993694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373993694 : Closed e2422373993694 ∧ code e2422373993694 = 11218467015902 := by decide
theorem cert_e2422373993694 : check e2422373993694 [[],[]] .three = true := by decide
def e2422373993698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422373993698 : Closed e2422373993698 ∧ code e2422373993698 = 11218467015906 := by decide
theorem cert_e2422373993698 : check e2422373993698 [[],[]] .smaller = true := by decide
def e2422373993710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373993710 : Closed e2422373993710 ∧ code e2422373993710 = 11218467015918 := by decide
theorem cert_e2422373993710 : check e2422373993710 [[],[]] .smaller = true := by decide
def e2422373993718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373993718 : Closed e2422373993718 ∧ code e2422373993718 = 11218467015926 := by decide
theorem cert_e2422373993718 : check e2422373993718 [[],[]] .smaller = true := by decide
def e2422373993722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373993722 : Closed e2422373993722 ∧ code e2422373993722 = 11218467015930 := by decide
theorem cert_e2422373993722 : check e2422373993722 [[],[]] .three = true := by decide
def e2422373993998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373993998 : Closed e2422373993998 ∧ code e2422373993998 = 11218467016206 := by decide
theorem cert_e2422373993998 : check e2422373993998 [[],[]] .smaller = true := by decide
def e2422373994046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2422373994046 : Closed e2422373994046 ∧ code e2422373994046 = 11218467016254 := by decide
theorem cert_e2422373994046 : check e2422373994046 [[],[]] .three = true := by decide
def e2422373994082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373994082 : Closed e2422373994082 ∧ code e2422373994082 = 11218467016290 := by decide
theorem cert_e2422373994082 : check e2422373994082 [[],[]] .smaller = true := by decide
def e2422373994094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373994094 : Closed e2422373994094 ∧ code e2422373994094 = 11218467016302 := by decide
theorem cert_e2422373994094 : check e2422373994094 [[],[]] .smaller = true := by decide
def e2422373994106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373994106 : Closed e2422373994106 ∧ code e2422373994106 = 11218467016314 := by decide
theorem cert_e2422373994106 : check e2422373994106 [[],[]] .smaller = true := by decide
def e2422373994294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373994294 : Closed e2422373994294 ∧ code e2422373994294 = 11218467016502 := by decide
theorem cert_e2422373994294 : check e2422373994294 [[],[]] .smaller = true := by decide
def e2422373994298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373994298 : Closed e2422373994298 ∧ code e2422373994298 = 11218467016506 := by decide
theorem cert_e2422373994298 : check e2422373994298 [[],[]] .smaller = true := by decide
def e2422373994382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2422373994382 : Closed e2422373994382 ∧ code e2422373994382 = 11218467016590 := by decide
theorem cert_e2422373994382 : check e2422373994382 [[],[]] .three = true := by decide
def e2422373994394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373994394 : Closed e2422373994394 ∧ code e2422373994394 = 11218467016602 := by decide
theorem cert_e2422373994394 : check e2422373994394 [[],[]] .three = true := by decide
def e2422373999070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373999070 : Closed e2422373999070 ∧ code e2422373999070 = 11218467021278 := by decide
theorem cert_e2422373999070 : check e2422373999070 [[],[]] .three = true := by decide
def e2422373999086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373999086 : Closed e2422373999086 ∧ code e2422373999086 = 11218467021294 := by decide
theorem cert_e2422373999086 : check e2422373999086 [[],[]] .three = true := by decide
def e2422373999094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373999094 : Closed e2422373999094 ∧ code e2422373999094 = 11218467021302 := by decide
theorem cert_e2422373999094 : check e2422373999094 [[],[]] .three = true := by decide
def e2422374000010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422374000010 : Closed e2422374000010 ∧ code e2422374000010 = 11218467022218 := by decide
theorem cert_e2422374000010 : check e2422374000010 [[],[]] .three = true := by decide
end Blc.Floor43
