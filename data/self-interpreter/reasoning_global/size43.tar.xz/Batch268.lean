import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406150047330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2406150047330 : Closed e2406150047330 ∧ code e2406150047330 = 11202243069538 := by decide
theorem cert_e2406150047330 : check e2406150047330 [[]] .width = true := by decide
def e2406150047342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2406150047342 : Closed e2406150047342 ∧ code e2406150047342 = 11202243069550 := by decide
theorem cert_e2406150047342 : check e2406150047342 [[]] .width = true := by decide
def e2406150047350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2406150047350 : Closed e2406150047350 ∧ code e2406150047350 = 11202243069558 := by decide
theorem cert_e2406150047350 : check e2406150047350 [[]] .width = true := by decide
def e2406150047354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2406150047354 : Closed e2406150047354 ∧ code e2406150047354 = 11202243069562 := by decide
theorem cert_e2406150047354 : check e2406150047354 [[]] .width = true := by decide
def e2406150047542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2406150047542 : Closed e2406150047542 ∧ code e2406150047542 = 11202243069750 := by decide
theorem cert_e2406150047542 : check e2406150047542 [[]] .width = true := by decide
def e2406150047546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2406150047546 : Closed e2406150047546 ∧ code e2406150047546 = 11202243069754 := by decide
theorem cert_e2406150047546 : check e2406150047546 [[]] .width = true := by decide
def e2406150047642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2406150047642 : Closed e2406150047642 ∧ code e2406150047642 = 11202243069850 := by decide
theorem cert_e2406150047642 : check e2406150047642 [[]] .width = true := by decide
def e2406150051242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2406150051242 : Closed e2406150051242 ∧ code e2406150051242 = 11202243073450 := by decide
theorem cert_e2406150051242 : check e2406150051242 [[]] .width = true := by decide
def e2406150051338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2406150051338 : Closed e2406150051338 ∧ code e2406150051338 = 11202243073546 := by decide
theorem cert_e2406150051338 : check e2406150051338 [[]] .width = true := by decide
def e2406150051382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2406150051382 : Closed e2406150051382 ∧ code e2406150051382 = 11202243073590 := by decide
theorem cert_e2406150051382 : check e2406150051382 [[]] .width = true := by decide
def e2406150051386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2406150051386 : Closed e2406150051386 ∧ code e2406150051386 = 11202243073594 := by decide
theorem cert_e2406150051386 : check e2406150051386 [[]] .width = true := by decide
def e2406150051434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2406150051434 : Closed e2406150051434 ∧ code e2406150051434 = 11202243073642 := by decide
theorem cert_e2406150051434 : check e2406150051434 [[]] .width = true := by decide
def e2406150051458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2406150051458 : Closed e2406150051458 ∧ code e2406150051458 = 11202243073666 := by decide
theorem cert_e2406150051458 : check e2406150051458 [[]] .width = true := by decide
def e2406150051470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2406150051470 : Closed e2406150051470 ∧ code e2406150051470 = 11202243073678 := by decide
theorem cert_e2406150051470 : check e2406150051470 [[]] .width = true := by decide
def e2406150051482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2406150051482 : Closed e2406150051482 ∧ code e2406150051482 = 11202243073690 := by decide
theorem cert_e2406150051482 : check e2406150051482 [[]] .width = true := by decide
def e2406150051526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2406150051526 : Closed e2406150051526 ∧ code e2406150051526 = 11202243073734 := by decide
theorem cert_e2406150051526 : check e2406150051526 [[]] .width = true := by decide
def e2406150051606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2406150051606 : Closed e2406150051606 ∧ code e2406150051606 = 11202243073814 := by decide
theorem cert_e2406150051606 : check e2406150051606 [[]] .width = true := by decide
def e2406150051610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2406150051610 : Closed e2406150051610 ∧ code e2406150051610 = 11202243073818 := by decide
theorem cert_e2406150051610 : check e2406150051610 [[]] .width = true := by decide
def e2406150051654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2406150051654 : Closed e2406150051654 ∧ code e2406150051654 = 11202243073862 := by decide
theorem cert_e2406150051654 : check e2406150051654 [[]] .width = true := by decide
def e2406150051682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2406150051682 : Closed e2406150051682 ∧ code e2406150051682 = 11202243073890 := by decide
theorem cert_e2406150051682 : check e2406150051682 [[]] .width = true := by decide
def e2406150051866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406150051866 : Closed e2406150051866 ∧ code e2406150051866 = 11202243074074 := by decide
theorem cert_e2406150051866 : check e2406150051866 [[]] .width = true := by decide
def e2406150051958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406150051958 : Closed e2406150051958 ∧ code e2406150051958 = 11202243074166 := by decide
theorem cert_e2406150051958 : check e2406150051958 [[]] .width = true := by decide
def e2406150052202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406150052202 : Closed e2406150052202 ∧ code e2406150052202 = 11202243074410 := by decide
theorem cert_e2406150052202 : check e2406150052202 [[]] .width = true := by decide
def e2406150052226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2406150052226 : Closed e2406150052226 ∧ code e2406150052226 = 11202243074434 := by decide
theorem cert_e2406150052226 : check e2406150052226 [[]] .width = true := by decide
def e2406150052238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406150052238 : Closed e2406150052238 ∧ code e2406150052238 = 11202243074446 := by decide
theorem cert_e2406150052238 : check e2406150052238 [[]] .width = true := by decide
def e2406150052250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406150052250 : Closed e2406150052250 ∧ code e2406150052250 = 11202243074458 := by decide
theorem cert_e2406150052250 : check e2406150052250 [[]] .width = true := by decide
def e2406150052294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406150052294 : Closed e2406150052294 ∧ code e2406150052294 = 11202243074502 := by decide
theorem cert_e2406150052294 : check e2406150052294 [[]] .width = true := by decide
def e2406150052894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2406150052894 : Closed e2406150052894 ∧ code e2406150052894 = 11202243075102 := by decide
theorem cert_e2406150052894 : check e2406150052894 [[]] .width = true := by decide
def e2406150053062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406150053062 : Closed e2406150053062 ∧ code e2406150053062 = 11202243075270 := by decide
theorem cert_e2406150053062 : check e2406150053062 [[]] .width = true := by decide
def e2406150053090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2406150053090 : Closed e2406150053090 ∧ code e2406150053090 = 11202243075298 := by decide
theorem cert_e2406150053090 : check e2406150053090 [[]] .width = true := by decide
def e2406150067754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2406150067754 : Closed e2406150067754 ∧ code e2406150067754 = 11202243089962 := by decide
theorem cert_e2406150067754 : check e2406150067754 [[]] .width = true := by decide
def e2406150067850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2406150067850 : Closed e2406150067850 ∧ code e2406150067850 = 11202243090058 := by decide
theorem cert_e2406150067850 : check e2406150067850 [[]] .width = true := by decide
def e2406150067874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406150067874 : Closed e2406150067874 ∧ code e2406150067874 = 11202243090082 := by decide
theorem cert_e2406150067874 : check e2406150067874 [[]] .width = true := by decide
def e2406150068234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2406150068234 : Closed e2406150068234 ∧ code e2406150068234 = 11202243090442 := by decide
theorem cert_e2406150068234 : check e2406150068234 [[]] .width = true := by decide
def e2406150068282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2406150068282 : Closed e2406150068282 ∧ code e2406150068282 = 11202243090490 := by decide
theorem cert_e2406150068282 : check e2406150068282 [[]] .width = true := by decide
def e2406150068330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2406150068330 : Closed e2406150068330 ∧ code e2406150068330 = 11202243090538 := by decide
theorem cert_e2406150068330 : check e2406150068330 [[]] .width = true := by decide
def e2406150068378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2406150068378 : Closed e2406150068378 ∧ code e2406150068378 = 11202243090586 := by decide
theorem cert_e2406150068378 : check e2406150068378 [[]] .width = true := by decide
def e2406150068422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2406150068422 : Closed e2406150068422 ∧ code e2406150068422 = 11202243090630 := by decide
theorem cert_e2406150068422 : check e2406150068422 [[]] .width = true := by decide
def e2406150068618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2406150068618 : Closed e2406150068618 ∧ code e2406150068618 = 11202243090826 := by decide
theorem cert_e2406150068618 : check e2406150068618 [[]] .width = true := by decide
def e2406150068642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2406150068642 : Closed e2406150068642 ∧ code e2406150068642 = 11202243090850 := by decide
theorem cert_e2406150068642 : check e2406150068642 [[]] .width = true := by decide
def e2406150068738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2406150068738 : Closed e2406150068738 ∧ code e2406150068738 = 11202243090946 := by decide
theorem cert_e2406150068738 : check e2406150068738 [[]] .width = true := by decide
def e2406150068750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2406150068750 : Closed e2406150068750 ∧ code e2406150068750 = 11202243090958 := by decide
theorem cert_e2406150068750 : check e2406150068750 [[]] .width = true := by decide
def e2406150068762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406150068762 : Closed e2406150068762 ∧ code e2406150068762 = 11202243090970 := by decide
theorem cert_e2406150068762 : check e2406150068762 [[]] .width = true := by decide
def e2406150068834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406150068834 : Closed e2406150068834 ∧ code e2406150068834 = 11202243091042 := by decide
theorem cert_e2406150068834 : check e2406150068834 [[]] .width = true := by decide
def e2406150070298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406150070298 : Closed e2406150070298 ∧ code e2406150070298 = 11202243092506 := by decide
theorem cert_e2406150070298 : check e2406150070298 [[]] .width = true := by decide
def e2406150070382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2406150070382 : Closed e2406150070382 ∧ code e2406150070382 = 11202243092590 := by decide
theorem cert_e2406150070382 : check e2406150070382 [[]] .width = true := by decide
def e2406150070390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406150070390 : Closed e2406150070390 ∧ code e2406150070390 = 11202243092598 := by decide
theorem cert_e2406150070390 : check e2406150070390 [[]] .width = true := by decide
def e2406150070394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2406150070394 : Closed e2406150070394 ∧ code e2406150070394 = 11202243092602 := by decide
theorem cert_e2406150070394 : check e2406150070394 [[]] .width = true := by decide
def e2406150070634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406150070634 : Closed e2406150070634 ∧ code e2406150070634 = 11202243092842 := by decide
theorem cert_e2406150070634 : check e2406150070634 [[]] .width = true := by decide
def e2406150070670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406150070670 : Closed e2406150070670 ∧ code e2406150070670 = 11202243092878 := by decide
theorem cert_e2406150070670 : check e2406150070670 [[]] .width = true := by decide
def e2406150070682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406150070682 : Closed e2406150070682 ∧ code e2406150070682 = 11202243092890 := by decide
theorem cert_e2406150070682 : check e2406150070682 [[]] .width = true := by decide
def e2406150070726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406150070726 : Closed e2406150070726 ∧ code e2406150070726 = 11202243092934 := by decide
theorem cert_e2406150070726 : check e2406150070726 [[]] .width = true := by decide
def e2406150071690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2406150071690 : Closed e2406150071690 ∧ code e2406150071690 = 11202243093898 := by decide
theorem cert_e2406150071690 : check e2406150071690 [[]] .width = true := by decide
def e2406150071714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2406150071714 : Closed e2406150071714 ∧ code e2406150071714 = 11202243093922 := by decide
theorem cert_e2406150071714 : check e2406150071714 [[]] .width = true := by decide
def e2406150071810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2406150071810 : Closed e2406150071810 ∧ code e2406150071810 = 11202243094018 := by decide
theorem cert_e2406150071810 : check e2406150071810 [[]] .width = true := by decide
def e2406150071822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2406150071822 : Closed e2406150071822 ∧ code e2406150071822 = 11202243094030 := by decide
theorem cert_e2406150071822 : check e2406150071822 [[]] .width = true := by decide
def e2406150071834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406150071834 : Closed e2406150071834 ∧ code e2406150071834 = 11202243094042 := by decide
theorem cert_e2406150071834 : check e2406150071834 [[]] .width = true := by decide
def e2406150071906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2406150071906 : Closed e2406150071906 ∧ code e2406150071906 = 11202243094114 := by decide
theorem cert_e2406150071906 : check e2406150071906 [[]] .width = true := by decide
def e2406150117890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2406150117890 : Closed e2406150117890 ∧ code e2406150117890 = 11202243140098 := by decide
theorem cert_e2406150117890 : check e2406150117890 [[]] .width = true := by decide
def e2406150117914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406150117914 : Closed e2406150117914 ∧ code e2406150117914 = 11202243140122 := by decide
theorem cert_e2406150117914 : check e2406150117914 [[]] .width = true := by decide
def e2406151471302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406151471302 : Closed e2406151471302 ∧ code e2406151471302 = 11202244493510 := by decide
theorem cert_e2406151471302 : check e2406151471302 [[]] .width = true := by decide
def e2406151559194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406151559194 : Closed e2406151559194 ∧ code e2406151559194 = 11202244581402 := by decide
theorem cert_e2406151559194 : check e2406151559194 [[]] .width = true := by decide
def e2406151569606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406151569606 : Closed e2406151569606 ∧ code e2406151569606 = 11202244591814 := by decide
theorem cert_e2406151569606 : check e2406151569606 [[]] .width = true := by decide
def e2406152724506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406152724506 : Closed e2406152724506 ∧ code e2406152724506 = 11202245746714 := by decide
theorem cert_e2406152724506 : check e2406152724506 [[]] .width = true := by decide
def e2406152724598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406152724598 : Closed e2406152724598 ∧ code e2406152724598 = 11202245746806 := by decide
theorem cert_e2406152724598 : check e2406152724598 [[]] .width = true := by decide
def e2406152724842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406152724842 : Closed e2406152724842 ∧ code e2406152724842 = 11202245747050 := by decide
theorem cert_e2406152724842 : check e2406152724842 [[]] .width = true := by decide
def e2406152724890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406152724890 : Closed e2406152724890 ∧ code e2406152724890 = 11202245747098 := by decide
theorem cert_e2406152724890 : check e2406152724890 [[]] .width = true := by decide
def e2406152777926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406152777926 : Closed e2406152777926 ∧ code e2406152777926 = 11202245800134 := by decide
theorem cert_e2406152777926 : check e2406152777926 [[]] .width = true := by decide
def e2406152786118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406152786118 : Closed e2406152786118 ∧ code e2406152786118 = 11202245808326 := by decide
theorem cert_e2406152786118 : check e2406152786118 [[]] .width = true := by decide
def e2406152787994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406152787994 : Closed e2406152787994 ∧ code e2406152787994 = 11202245810202 := by decide
theorem cert_e2406152787994 : check e2406152787994 [[]] .width = true := by decide
def e2406152789530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406152789530 : Closed e2406152789530 ∧ code e2406152789530 = 11202245811738 := by decide
theorem cert_e2406152789530 : check e2406152789530 [[]] .width = true := by decide
def e2406152795674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406152795674 : Closed e2406152795674 ∧ code e2406152795674 = 11202245817882 := by decide
theorem cert_e2406152795674 : check e2406152795674 [[]] .width = true := by decide
def e2406152863942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406152863942 : Closed e2406152863942 ∧ code e2406152863942 = 11202245886150 := by decide
theorem cert_e2406152863942 : check e2406152863942 [[]] .width = true := by decide
def e2406152864470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2406152864470 : Closed e2406152864470 ∧ code e2406152864470 = 11202245886678 := by decide
theorem cert_e2406152864470 : check e2406152864470 [[]] .width = true := by decide
def e2406152864474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2406152864474 : Closed e2406152864474 ∧ code e2406152864474 = 11202245886682 := by decide
theorem cert_e2406152864474 : check e2406152864474 [[]] .width = true := by decide
def e2406152864490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2406152864490 : Closed e2406152864490 ∧ code e2406152864490 = 11202245886698 := by decide
theorem cert_e2406152864490 : check e2406152864490 [[]] .width = true := by decide
def e2406152864566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2406152864566 : Closed e2406152864566 ∧ code e2406152864566 = 11202245886774 := by decide
theorem cert_e2406152864566 : check e2406152864566 [[]] .width = true := by decide
def e2406152864570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2406152864570 : Closed e2406152864570 ∧ code e2406152864570 = 11202245886778 := by decide
theorem cert_e2406152864570 : check e2406152864570 [[]] .width = true := by decide
def e2406152864654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2406152864654 : Closed e2406152864654 ∧ code e2406152864654 = 11202245886862 := by decide
theorem cert_e2406152864654 : check e2406152864654 [[]] .width = true := by decide
def e2406152864666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2406152864666 : Closed e2406152864666 ∧ code e2406152864666 = 11202245886874 := by decide
theorem cert_e2406152864666 : check e2406152864666 [[]] .width = true := by decide
def e2406152866586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2406152866586 : Closed e2406152866586 ∧ code e2406152866586 = 11202245888794 := by decide
theorem cert_e2406152866586 : check e2406152866586 [[]] .width = true := by decide
def e2406152866630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2406152866630 : Closed e2406152866630 ∧ code e2406152866630 = 11202245888838 := by decide
theorem cert_e2406152866630 : check e2406152866630 [[]] .width = true := by decide
def e2406152866870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2406152866870 : Closed e2406152866870 ∧ code e2406152866870 = 11202245889078 := by decide
theorem cert_e2406152866870 : check e2406152866870 [[]] .width = true := by decide
def e2406152866874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2406152866874 : Closed e2406152866874 ∧ code e2406152866874 = 11202245889082 := by decide
theorem cert_e2406152866874 : check e2406152866874 [[]] .width = true := by decide
def e2406152867014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406152867014 : Closed e2406152867014 ∧ code e2406152867014 = 11202245889222 := by decide
theorem cert_e2406152867014 : check e2406152867014 [[]] .width = true := by decide
def e2406153037850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406153037850 : Closed e2406153037850 ∧ code e2406153037850 = 11202246060058 := by decide
theorem cert_e2406153037850 : check e2406153037850 [[]] .width = true := by decide
def e2406153039386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406153039386 : Closed e2406153039386 ∧ code e2406153039386 = 11202246061594 := by decide
theorem cert_e2406153039386 : check e2406153039386 [[]] .width = true := by decide
def e2406153042458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406153042458 : Closed e2406153042458 ∧ code e2406153042458 = 11202246064666 := by decide
theorem cert_e2406153042458 : check e2406153042458 [[]] .width = true := by decide
def e2406153054746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406153054746 : Closed e2406153054746 ∧ code e2406153054746 = 11202246076954 := by decide
theorem cert_e2406153054746 : check e2406153054746 [[]] .width = true := by decide
def e2406153062426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406153062426 : Closed e2406153062426 ∧ code e2406153062426 = 11202246084634 := by decide
theorem cert_e2406153062426 : check e2406153062426 [[]] .width = true := by decide
def e2406153068570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406153068570 : Closed e2406153068570 ∧ code e2406153068570 = 11202246090778 := by decide
theorem cert_e2406153068570 : check e2406153068570 [[]] .width = true := by decide
def e2406153068662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406153068662 : Closed e2406153068662 ∧ code e2406153068662 = 11202246090870 := by decide
theorem cert_e2406153068662 : check e2406153068662 [[]] .width = true := by decide
def e2406153068906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406153068906 : Closed e2406153068906 ∧ code e2406153068906 = 11202246091114 := by decide
theorem cert_e2406153068906 : check e2406153068906 [[]] .width = true := by decide
def e2406153068954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406153068954 : Closed e2406153068954 ∧ code e2406153068954 = 11202246091162 := by decide
theorem cert_e2406153068954 : check e2406153068954 [[]] .width = true := by decide
def e2406153072838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406153072838 : Closed e2406153072838 ∧ code e2406153072838 = 11202246095046 := by decide
theorem cert_e2406153072838 : check e2406153072838 [[]] .width = true := by decide
def e2406153074714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406153074714 : Closed e2406153074714 ∧ code e2406153074714 = 11202246096922 := by decide
theorem cert_e2406153074714 : check e2406153074714 [[]] .width = true := by decide
def e2406153087002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406153087002 : Closed e2406153087002 ∧ code e2406153087002 = 11202246109210 := by decide
theorem cert_e2406153087002 : check e2406153087002 [[]] .width = true := by decide
def e2406153088538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406153088538 : Closed e2406153088538 ∧ code e2406153088538 = 11202246110746 := by decide
theorem cert_e2406153088538 : check e2406153088538 [[]] .width = true := by decide
def e2406153091610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406153091610 : Closed e2406153091610 ∧ code e2406153091610 = 11202246113818 := by decide
theorem cert_e2406153091610 : check e2406153091610 [[]] .width = true := by decide
def e2406153093146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406153093146 : Closed e2406153093146 ∧ code e2406153093146 = 11202246115354 := by decide
theorem cert_e2406153093146 : check e2406153093146 [[]] .width = true := by decide
def e2406153093238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406153093238 : Closed e2406153093238 ∧ code e2406153093238 = 11202246115446 := by decide
theorem cert_e2406153093238 : check e2406153093238 [[]] .width = true := by decide
def e2406153093482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406153093482 : Closed e2406153093482 ∧ code e2406153093482 = 11202246115690 := by decide
theorem cert_e2406153093482 : check e2406153093482 [[]] .width = true := by decide
def e2406153093530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406153093530 : Closed e2406153093530 ∧ code e2406153093530 = 11202246115738 := by decide
theorem cert_e2406153093530 : check e2406153093530 [[]] .width = true := by decide
def e2406153094538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406153094538 : Closed e2406153094538 ∧ code e2406153094538 = 11202246116746 := by decide
theorem cert_e2406153094538 : check e2406153094538 [[]] .width = true := by decide
def e2406153094562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406153094562 : Closed e2406153094562 ∧ code e2406153094562 = 11202246116770 := by decide
theorem cert_e2406153094562 : check e2406153094562 [[]] .width = true := by decide
def e2406153094670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406153094670 : Closed e2406153094670 ∧ code e2406153094670 = 11202246116878 := by decide
theorem cert_e2406153094670 : check e2406153094670 [[]] .width = true := by decide
def e2406153094682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406153094682 : Closed e2406153094682 ∧ code e2406153094682 = 11202246116890 := by decide
theorem cert_e2406153094682 : check e2406153094682 [[]] .width = true := by decide
def e2406153094754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406153094754 : Closed e2406153094754 ∧ code e2406153094754 = 11202246116962 := by decide
theorem cert_e2406153094754 : check e2406153094754 [[]] .width = true := by decide
def e2406153109702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406153109702 : Closed e2406153109702 ∧ code e2406153109702 = 11202246131910 := by decide
theorem cert_e2406153109702 : check e2406153109702 [[]] .width = true := by decide
def e2406153117722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406153117722 : Closed e2406153117722 ∧ code e2406153117722 = 11202246139930 := by decide
theorem cert_e2406153117722 : check e2406153117722 [[]] .width = true := by decide
def e2406153117814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406153117814 : Closed e2406153117814 ∧ code e2406153117814 = 11202246140022 := by decide
theorem cert_e2406153117814 : check e2406153117814 [[]] .width = true := by decide
def e2406153118058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406153118058 : Closed e2406153118058 ∧ code e2406153118058 = 11202246140266 := by decide
theorem cert_e2406153118058 : check e2406153118058 [[]] .width = true := by decide
def e2406153118106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406153118106 : Closed e2406153118106 ∧ code e2406153118106 = 11202246140314 := by decide
theorem cert_e2406153118106 : check e2406153118106 [[]] .width = true := by decide
def e2406153132058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406153132058 : Closed e2406153132058 ∧ code e2406153132058 = 11202246154266 := by decide
theorem cert_e2406153132058 : check e2406153132058 [[]] .width = true := by decide
def e2406153142470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406153142470 : Closed e2406153142470 ∧ code e2406153142470 = 11202246164678 := by decide
theorem cert_e2406153142470 : check e2406153142470 [[]] .width = true := by decide
def e2406153165338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406153165338 : Closed e2406153165338 ∧ code e2406153165338 = 11202246187546 := by decide
theorem cert_e2406153165338 : check e2406153165338 [[]] .width = true := by decide
def e2406153166874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406153166874 : Closed e2406153166874 ∧ code e2406153166874 = 11202246189082 := by decide
theorem cert_e2406153166874 : check e2406153166874 [[]] .width = true := by decide
def e2406153166966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406153166966 : Closed e2406153166966 ∧ code e2406153166966 = 11202246189174 := by decide
theorem cert_e2406153166966 : check e2406153166966 [[]] .width = true := by decide
def e2406153167210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406153167210 : Closed e2406153167210 ∧ code e2406153167210 = 11202246189418 := by decide
theorem cert_e2406153167210 : check e2406153167210 [[]] .width = true := by decide
def e2406153167258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406153167258 : Closed e2406153167258 ∧ code e2406153167258 = 11202246189466 := by decide
theorem cert_e2406153167258 : check e2406153167258 [[]] .width = true := by decide
def e2406153191450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2406153191450 : Closed e2406153191450 ∧ code e2406153191450 = 11202246213658 := by decide
theorem cert_e2406153191450 : check e2406153191450 [[]] .width = true := by decide
def e2406153191542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2406153191542 : Closed e2406153191542 ∧ code e2406153191542 = 11202246213750 := by decide
theorem cert_e2406153191542 : check e2406153191542 [[]] .width = true := by decide
def e2406153191786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2406153191786 : Closed e2406153191786 ∧ code e2406153191786 = 11202246213994 := by decide
theorem cert_e2406153191786 : check e2406153191786 [[]] .width = true := by decide
def e2406153191834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2406153191834 : Closed e2406153191834 ∧ code e2406153191834 = 11202246214042 := by decide
theorem cert_e2406153191834 : check e2406153191834 [[]] .width = true := by decide
def e2406153191918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2406153191918 : Closed e2406153191918 ∧ code e2406153191918 = 11202246214126 := by decide
theorem cert_e2406153191918 : check e2406153191918 [[]] .width = true := by decide
def e2406153192842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2406153192842 : Closed e2406153192842 ∧ code e2406153192842 = 11202246215050 := by decide
theorem cert_e2406153192842 : check e2406153192842 [[]] .width = true := by decide
def e2406153192866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2406153192866 : Closed e2406153192866 ∧ code e2406153192866 = 11202246215074 := by decide
theorem cert_e2406153192866 : check e2406153192866 [[]] .width = true := by decide
def e2406153192878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2406153192878 : Closed e2406153192878 ∧ code e2406153192878 = 11202246215086 := by decide
theorem cert_e2406153192878 : check e2406153192878 [[]] .width = true := by decide
def e2406153192886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2406153192886 : Closed e2406153192886 ∧ code e2406153192886 = 11202246215094 := by decide
theorem cert_e2406153192886 : check e2406153192886 [[]] .width = true := by decide
def e2406153192890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2406153192890 : Closed e2406153192890 ∧ code e2406153192890 = 11202246215098 := by decide
theorem cert_e2406153192890 : check e2406153192890 [[]] .width = true := by decide
def e2406153192918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2406153192918 : Closed e2406153192918 ∧ code e2406153192918 = 11202246215126 := by decide
theorem cert_e2406153192918 : check e2406153192918 [[]] .width = true := by decide
def e2406153192922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2406153192922 : Closed e2406153192922 ∧ code e2406153192922 = 11202246215130 := by decide
theorem cert_e2406153192922 : check e2406153192922 [[]] .width = true := by decide
def e2406153192938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2406153192938 : Closed e2406153192938 ∧ code e2406153192938 = 11202246215146 := by decide
theorem cert_e2406153192938 : check e2406153192938 [[]] .width = true := by decide
def e2406153192974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2406153192974 : Closed e2406153192974 ∧ code e2406153192974 = 11202246215182 := by decide
theorem cert_e2406153192974 : check e2406153192974 [[]] .width = true := by decide
def e2406153192986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406153192986 : Closed e2406153192986 ∧ code e2406153192986 = 11202246215194 := by decide
theorem cert_e2406153192986 : check e2406153192986 [[]] .width = true := by decide
def e2406153193058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2406153193058 : Closed e2406153193058 ∧ code e2406153193058 = 11202246215266 := by decide
theorem cert_e2406153193058 : check e2406153193058 [[]] .width = true := by decide
def e2406153193070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2406153193070 : Closed e2406153193070 ∧ code e2406153193070 = 11202246215278 := by decide
theorem cert_e2406153193070 : check e2406153193070 [[]] .width = true := by decide
def e2406153193078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2406153193078 : Closed e2406153193078 ∧ code e2406153193078 = 11202246215286 := by decide
theorem cert_e2406153193078 : check e2406153193078 [[]] .width = true := by decide
def e2406153193082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2406153193082 : Closed e2406153193082 ∧ code e2406153193082 = 11202246215290 := by decide
theorem cert_e2406153193082 : check e2406153193082 [[]] .width = true := by decide
def e2406153193270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2406153193270 : Closed e2406153193270 ∧ code e2406153193270 = 11202246215478 := by decide
theorem cert_e2406153193270 : check e2406153193270 [[]] .width = true := by decide
def e2406153193274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2406153193274 : Closed e2406153193274 ∧ code e2406153193274 = 11202246215482 := by decide
theorem cert_e2406153193274 : check e2406153193274 [[]] .width = true := by decide
def e2406153193370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2406153193370 : Closed e2406153193370 ∧ code e2406153193370 = 11202246215578 := by decide
theorem cert_e2406153193370 : check e2406153193370 [[]] .width = true := by decide
def e2406153196970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2406153196970 : Closed e2406153196970 ∧ code e2406153196970 = 11202246219178 := by decide
theorem cert_e2406153196970 : check e2406153196970 [[]] .width = true := by decide
def e2406153197066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2406153197066 : Closed e2406153197066 ∧ code e2406153197066 = 11202246219274 := by decide
theorem cert_e2406153197066 : check e2406153197066 [[]] .width = true := by decide
def e2406153197110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2406153197110 : Closed e2406153197110 ∧ code e2406153197110 = 11202246219318 := by decide
theorem cert_e2406153197110 : check e2406153197110 [[]] .width = true := by decide
def e2406153197114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2406153197114 : Closed e2406153197114 ∧ code e2406153197114 = 11202246219322 := by decide
theorem cert_e2406153197114 : check e2406153197114 [[]] .width = true := by decide
def e2406153197162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2406153197162 : Closed e2406153197162 ∧ code e2406153197162 = 11202246219370 := by decide
theorem cert_e2406153197162 : check e2406153197162 [[]] .width = true := by decide
def e2406153197186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2406153197186 : Closed e2406153197186 ∧ code e2406153197186 = 11202246219394 := by decide
theorem cert_e2406153197186 : check e2406153197186 [[]] .width = true := by decide
def e2406153197198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2406153197198 : Closed e2406153197198 ∧ code e2406153197198 = 11202246219406 := by decide
theorem cert_e2406153197198 : check e2406153197198 [[]] .width = true := by decide
def e2406153197210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2406153197210 : Closed e2406153197210 ∧ code e2406153197210 = 11202246219418 := by decide
theorem cert_e2406153197210 : check e2406153197210 [[]] .width = true := by decide
def e2406153197254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2406153197254 : Closed e2406153197254 ∧ code e2406153197254 = 11202246219462 := by decide
theorem cert_e2406153197254 : check e2406153197254 [[]] .width = true := by decide
def e2406153197334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2406153197334 : Closed e2406153197334 ∧ code e2406153197334 = 11202246219542 := by decide
theorem cert_e2406153197334 : check e2406153197334 [[]] .width = true := by decide
def e2406153197338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2406153197338 : Closed e2406153197338 ∧ code e2406153197338 = 11202246219546 := by decide
theorem cert_e2406153197338 : check e2406153197338 [[]] .width = true := by decide
def e2406153197382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2406153197382 : Closed e2406153197382 ∧ code e2406153197382 = 11202246219590 := by decide
theorem cert_e2406153197382 : check e2406153197382 [[]] .width = true := by decide
def e2406153197410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2406153197410 : Closed e2406153197410 ∧ code e2406153197410 = 11202246219618 := by decide
theorem cert_e2406153197410 : check e2406153197410 [[]] .width = true := by decide
def e2406153197594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406153197594 : Closed e2406153197594 ∧ code e2406153197594 = 11202246219802 := by decide
theorem cert_e2406153197594 : check e2406153197594 [[]] .width = true := by decide
def e2406153197686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406153197686 : Closed e2406153197686 ∧ code e2406153197686 = 11202246219894 := by decide
theorem cert_e2406153197686 : check e2406153197686 [[]] .width = true := by decide
def e2406153197930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406153197930 : Closed e2406153197930 ∧ code e2406153197930 = 11202246220138 := by decide
theorem cert_e2406153197930 : check e2406153197930 [[]] .width = true := by decide
def e2406153197954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2406153197954 : Closed e2406153197954 ∧ code e2406153197954 = 11202246220162 := by decide
theorem cert_e2406153197954 : check e2406153197954 [[]] .width = true := by decide
def e2406153197966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406153197966 : Closed e2406153197966 ∧ code e2406153197966 = 11202246220174 := by decide
theorem cert_e2406153197966 : check e2406153197966 [[]] .width = true := by decide
end Blc.Floor43
