import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602682590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605602682590 : Closed e605602682590 ∧ code e605602682590 = 9401695704798 := by decide
theorem cert_e605602682590 : check e605602682590 [[.under],[.under]] .three = true := by decide
def e605602682614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605602682614 : Closed e605602682614 ∧ code e605602682614 = 9401695704822 := by decide
theorem cert_e605602682614 : check e605602682614 [[.under],[.under]] .three = true := by decide
def e605602682718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605602682718 : Closed e605602682718 ∧ code e605602682718 = 9401695704926 := by decide
theorem cert_e605602682718 : check e605602682718 [[.under],[.under]] .three = true := by decide
def e605602682746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605602682746 : Closed e605602682746 ∧ code e605602682746 = 9401695704954 := by decide
theorem cert_e605602682746 : check e605602682746 [[.under],[.under]] .three = true := by decide
def e605602682838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605602682838 : Closed e605602682838 ∧ code e605602682838 = 9401695705046 := by decide
theorem cert_e605602682838 : check e605602682838 [[.under],[.under]] .three = true := by decide
def e605602682842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605602682842 : Closed e605602682842 ∧ code e605602682842 = 9401695705050 := by decide
theorem cert_e605602682842 : check e605602682842 [[.under],[.under]] .three = true := by decide
def e605602683358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602683358 : Closed e605602683358 ∧ code e605602683358 = 9401695705566 := by decide
theorem cert_e605602683358 : check e605602683358 [[.under],[.under]] .three = true := by decide
def e605602683382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602683382 : Closed e605602683382 ∧ code e605602683382 = 9401695705590 := by decide
theorem cert_e605602683382 : check e605602683382 [[.under],[.under]] .three = true := by decide
def e605602684126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605602684126 : Closed e605602684126 ∧ code e605602684126 = 9401695706334 := by decide
theorem cert_e605602684126 : check e605602684126 [[.under],[.under]] .three = true := by decide
def e605602684154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605602684154 : Closed e605602684154 ∧ code e605602684154 = 9401695706362 := by decide
theorem cert_e605602684154 : check e605602684154 [[.under],[.under]] .three = true := by decide
def e605602684726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602684726 : Closed e605602684726 ∧ code e605602684726 = 9401695706934 := by decide
theorem cert_e605602684726 : check e605602684726 [[.under],[.under]] .three = true := by decide
def e605602684730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602684730 : Closed e605602684730 ∧ code e605602684730 = 9401695706938 := by decide
theorem cert_e605602684730 : check e605602684730 [[.under],[.under]] .three = true := by decide
def e605602696046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605602696046 : Closed e605602696046 ∧ code e605602696046 = 9401695718254 := by decide
theorem cert_e605602696046 : check e605602696046 [[.under],[.under]] .three = true := by decide
def e605602696054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605602696054 : Closed e605602696054 ∧ code e605602696054 = 9401695718262 := by decide
theorem cert_e605602696054 : check e605602696054 [[.under],[.under]] .three = true := by decide
def e605602696110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605602696110 : Closed e605602696110 ∧ code e605602696110 = 9401695718318 := by decide
theorem cert_e605602696110 : check e605602696110 [[.under],[.under]] .three = true := by decide
def e605602696122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605602696122 : Closed e605602696122 ∧ code e605602696122 = 9401695718330 := by decide
theorem cert_e605602696122 : check e605602696122 [[.under],[.under]] .three = true := by decide
def e605602696150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605602696150 : Closed e605602696150 ∧ code e605602696150 = 9401695718358 := by decide
theorem cert_e605602696150 : check e605602696150 [[.under],[.under]] .three = true := by decide
def e605602696154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605602696154 : Closed e605602696154 ∧ code e605602696154 = 9401695718362 := by decide
theorem cert_e605602696154 : check e605602696154 [[.under],[.under]] .three = true := by decide
def e605602696430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602696430 : Closed e605602696430 ∧ code e605602696430 = 9401695718638 := by decide
theorem cert_e605602696430 : check e605602696430 [[.under],[.under]] .three = true := by decide
def e605602696438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602696438 : Closed e605602696438 ∧ code e605602696438 = 9401695718646 := by decide
theorem cert_e605602696438 : check e605602696438 [[.under],[.under]] .three = true := by decide
def e605602696814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602696814 : Closed e605602696814 ∧ code e605602696814 = 9401695719022 := by decide
theorem cert_e605602696814 : check e605602696814 [[.under],[.under]] .three = true := by decide
def e605602696826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602696826 : Closed e605602696826 ∧ code e605602696826 = 9401695719034 := by decide
theorem cert_e605602696826 : check e605602696826 [[.under],[.under]] .three = true := by decide
def e605602697014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602697014 : Closed e605602697014 ∧ code e605602697014 = 9401695719222 := by decide
theorem cert_e605602697014 : check e605602697014 [[.under],[.under]] .three = true := by decide
def e605602697018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602697018 : Closed e605602697018 ∧ code e605602697018 = 9401695719226 := by decide
theorem cert_e605602697018 : check e605602697018 [[.under],[.under]] .three = true := by decide
def e605602756318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 3)))))))
theorem wire_e605602756318 : Closed e605602756318 ∧ code e605602756318 = 9401695778526 := by decide
theorem cert_e605602756318 : check e605602756318 [[.under],[.under]] .three = true := by decide
def e605602756342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 1)))))))
theorem wire_e605602756342 : Closed e605602756342 ∧ code e605602756342 = 9401695778550 := by decide
theorem cert_e605602756342 : check e605602756342 [[.under],[.under]] .three = true := by decide
def e605602756534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 1)))))))
theorem wire_e605602756534 : Closed e605602756534 ∧ code e605602756534 = 9401695778742 := by decide
theorem cert_e605602756534 : check e605602756534 [[.under],[.under]] .three = true := by decide
def e605602757342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e605602757342 : Closed e605602757342 ∧ code e605602757342 = 9401695779550 := by decide
theorem cert_e605602757342 : check e605602757342 [[.under],[.under]] .three = true := by decide
def e605602757366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e605602757366 : Closed e605602757366 ∧ code e605602757366 = 9401695779574 := by decide
theorem cert_e605602757366 : check e605602757366 [[.under],[.under]] .three = true := by decide
def e605602757470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e605602757470 : Closed e605602757470 ∧ code e605602757470 = 9401695779678 := by decide
theorem cert_e605602757470 : check e605602757470 [[.under],[.under]] .three = true := by decide
def e605602757498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e605602757498 : Closed e605602757498 ∧ code e605602757498 = 9401695779706 := by decide
theorem cert_e605602757498 : check e605602757498 [[.under],[.under]] .three = true := by decide
def e605602757590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e605602757590 : Closed e605602757590 ∧ code e605602757590 = 9401695779798 := by decide
theorem cert_e605602757590 : check e605602757590 [[.under],[.under]] .three = true := by decide
def e605602757594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e605602757594 : Closed e605602757594 ∧ code e605602757594 = 9401695779802 := by decide
theorem cert_e605602757594 : check e605602757594 [[.under],[.under]] .three = true := by decide
def e605602758326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e605602758326 : Closed e605602758326 ∧ code e605602758326 = 9401695780534 := by decide
theorem cert_e605602758326 : check e605602758326 [[.under],[.under]] .three = true := by decide
def e605602758358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e605602758358 : Closed e605602758358 ∧ code e605602758358 = 9401695780566 := by decide
theorem cert_e605602758358 : check e605602758358 [[.under],[.under]] .three = true := by decide
def e605602758362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e605602758362 : Closed e605602758362 ∧ code e605602758362 = 9401695780570 := by decide
theorem cert_e605602758362 : check e605602758362 [[.under],[.under]] .three = true := by decide
def e605602762462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e605602762462 : Closed e605602762462 ∧ code e605602762462 = 9401695784670 := by decide
theorem cert_e605602762462 : check e605602762462 [[.under],[.under]] .three = true := by decide
def e605602762486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e605602762486 : Closed e605602762486 ∧ code e605602762486 = 9401695784694 := by decide
theorem cert_e605602762486 : check e605602762486 [[.under],[.under]] .three = true := by decide
def e605602762678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e605602762678 : Closed e605602762678 ∧ code e605602762678 = 9401695784886 := by decide
theorem cert_e605602762678 : check e605602762678 [[.under],[.under]] .three = true := by decide
def e605602765278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e605602765278 : Closed e605602765278 ∧ code e605602765278 = 9401695787486 := by decide
theorem cert_e605602765278 : check e605602765278 [[.under],[.under]] .three = true := by decide
def e605602765302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e605602765302 : Closed e605602765302 ∧ code e605602765302 = 9401695787510 := by decide
theorem cert_e605602765302 : check e605602765302 [[.under],[.under]] .three = true := by decide
def e605602766454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e605602766454 : Closed e605602766454 ∧ code e605602766454 = 9401695788662 := by decide
theorem cert_e605602766454 : check e605602766454 [[.under],[.under]] .three = true := by decide
def e605602768606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e605602768606 : Closed e605602768606 ∧ code e605602768606 = 9401695790814 := by decide
theorem cert_e605602768606 : check e605602768606 [[.under],[.under]] .three = true := by decide
def e605602768630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e605602768630 : Closed e605602768630 ∧ code e605602768630 = 9401695790838 := by decide
theorem cert_e605602768630 : check e605602768630 [[.under],[.under]] .three = true := by decide
def e605602768734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e605602768734 : Closed e605602768734 ∧ code e605602768734 = 9401695790942 := by decide
theorem cert_e605602768734 : check e605602768734 [[.under],[.under]] .three = true := by decide
def e605602768762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605602768762 : Closed e605602768762 ∧ code e605602768762 = 9401695790970 := by decide
theorem cert_e605602768762 : check e605602768762 [[.under],[.under]] .three = true := by decide
def e605602768854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e605602768854 : Closed e605602768854 ∧ code e605602768854 = 9401695791062 := by decide
theorem cert_e605602768854 : check e605602768854 [[.under],[.under]] .three = true := by decide
def e605602768858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605602768858 : Closed e605602768858 ∧ code e605602768858 = 9401695791066 := by decide
theorem cert_e605602768858 : check e605602768858 [[.under],[.under]] .three = true := by decide
def e605602769374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e605602769374 : Closed e605602769374 ∧ code e605602769374 = 9401695791582 := by decide
theorem cert_e605602769374 : check e605602769374 [[.under],[.under]] .three = true := by decide
def e605602769398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e605602769398 : Closed e605602769398 ∧ code e605602769398 = 9401695791606 := by decide
theorem cert_e605602769398 : check e605602769398 [[.under],[.under]] .three = true := by decide
def e605602770142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e605602770142 : Closed e605602770142 ∧ code e605602770142 = 9401695792350 := by decide
theorem cert_e605602770142 : check e605602770142 [[.under],[.under]] .three = true := by decide
def e605602770170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e605602770170 : Closed e605602770170 ∧ code e605602770170 = 9401695792378 := by decide
theorem cert_e605602770170 : check e605602770170 [[.under],[.under]] .three = true := by decide
def e605602770742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605602770742 : Closed e605602770742 ∧ code e605602770742 = 9401695792950 := by decide
theorem cert_e605602770742 : check e605602770742 [[.under],[.under]] .three = true := by decide
def e605602770746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605602770746 : Closed e605602770746 ∧ code e605602770746 = 9401695792954 := by decide
theorem cert_e605602770746 : check e605602770746 [[.under],[.under]] .three = true := by decide
def e605602773430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605602773430 : Closed e605602773430 ∧ code e605602773430 = 9401695795638 := by decide
theorem cert_e605602773430 : check e605602773430 [[.under],[.under]] .three = true := by decide
def e605602773462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605602773462 : Closed e605602773462 ∧ code e605602773462 = 9401695795670 := by decide
theorem cert_e605602773462 : check e605602773462 [[.under],[.under]] .three = true := by decide
def e605602773466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605602773466 : Closed e605602773466 ∧ code e605602773466 = 9401695795674 := by decide
theorem cert_e605602773466 : check e605602773466 [[.under],[.under]] .three = true := by decide
def e605602773622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e605602773622 : Closed e605602773622 ∧ code e605602773622 = 9401695795830 := by decide
theorem cert_e605602773622 : check e605602773622 [[.under],[.under]] .three = true := by decide
def e605602773814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605602773814 : Closed e605602773814 ∧ code e605602773814 = 9401695796022 := by decide
theorem cert_e605602773814 : check e605602773814 [[.under],[.under]] .three = true := by decide
def e605602773818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605602773818 : Closed e605602773818 ∧ code e605602773818 = 9401695796026 := by decide
theorem cert_e605602773818 : check e605602773818 [[.under],[.under]] .three = true := by decide
def e605602787038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e605602787038 : Closed e605602787038 ∧ code e605602787038 = 9401695809246 := by decide
theorem cert_e605602787038 : check e605602787038 [[.under],[.under]] .three = true := by decide
def e605602787062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e605602787062 : Closed e605602787062 ∧ code e605602787062 = 9401695809270 := by decide
theorem cert_e605602787062 : check e605602787062 [[.under],[.under]] .three = true := by decide
def e605602787254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e605602787254 : Closed e605602787254 ∧ code e605602787254 = 9401695809462 := by decide
theorem cert_e605602787254 : check e605602787254 [[.under],[.under]] .three = true := by decide
def e605602789854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602789854 : Closed e605602789854 ∧ code e605602789854 = 9401695812062 := by decide
theorem cert_e605602789854 : check e605602789854 [[.under],[.under]] .three = true := by decide
def e605602789878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602789878 : Closed e605602789878 ∧ code e605602789878 = 9401695812086 := by decide
theorem cert_e605602789878 : check e605602789878 [[.under],[.under]] .three = true := by decide
def e605602791030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602791030 : Closed e605602791030 ∧ code e605602791030 = 9401695813238 := by decide
theorem cert_e605602791030 : check e605602791030 [[.under],[.under]] .three = true := by decide
def e605602813662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605602813662 : Closed e605602813662 ∧ code e605602813662 = 9401695835870 := by decide
theorem cert_e605602813662 : check e605602813662 [[.under],[.under]] .three = true := by decide
def e605602813686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605602813686 : Closed e605602813686 ∧ code e605602813686 = 9401695835894 := by decide
theorem cert_e605602813686 : check e605602813686 [[.under],[.under]] .three = true := by decide
def e605602813790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605602813790 : Closed e605602813790 ∧ code e605602813790 = 9401695835998 := by decide
theorem cert_e605602813790 : check e605602813790 [[.under],[.under]] .three = true := by decide
def e605602813818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605602813818 : Closed e605602813818 ∧ code e605602813818 = 9401695836026 := by decide
theorem cert_e605602813818 : check e605602813818 [[.under],[.under]] .three = true := by decide
def e605602813910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605602813910 : Closed e605602813910 ∧ code e605602813910 = 9401695836118 := by decide
theorem cert_e605602813910 : check e605602813910 [[.under],[.under]] .three = true := by decide
def e605602813914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605602813914 : Closed e605602813914 ∧ code e605602813914 = 9401695836122 := by decide
theorem cert_e605602813914 : check e605602813914 [[.under],[.under]] .three = true := by decide
def e605602814430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602814430 : Closed e605602814430 ∧ code e605602814430 = 9401695836638 := by decide
theorem cert_e605602814430 : check e605602814430 [[.under],[.under]] .three = true := by decide
def e605602814454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602814454 : Closed e605602814454 ∧ code e605602814454 = 9401695836662 := by decide
theorem cert_e605602814454 : check e605602814454 [[.under],[.under]] .three = true := by decide
def e605602815198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605602815198 : Closed e605602815198 ∧ code e605602815198 = 9401695837406 := by decide
theorem cert_e605602815198 : check e605602815198 [[.under],[.under]] .three = true := by decide
def e605602815226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605602815226 : Closed e605602815226 ∧ code e605602815226 = 9401695837434 := by decide
theorem cert_e605602815226 : check e605602815226 [[.under],[.under]] .three = true := by decide
def e605602815798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602815798 : Closed e605602815798 ∧ code e605602815798 = 9401695838006 := by decide
theorem cert_e605602815798 : check e605602815798 [[.under],[.under]] .three = true := by decide
def e605602815802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602815802 : Closed e605602815802 ∧ code e605602815802 = 9401695838010 := by decide
theorem cert_e605602815802 : check e605602815802 [[.under],[.under]] .three = true := by decide
def e605602833846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605602833846 : Closed e605602833846 ∧ code e605602833846 = 9401695856054 := by decide
theorem cert_e605602833846 : check e605602833846 [[.under],[.under]] .three = true := by decide
def e605602833878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605602833878 : Closed e605602833878 ∧ code e605602833878 = 9401695856086 := by decide
theorem cert_e605602833878 : check e605602833878 [[.under],[.under]] .three = true := by decide
def e605602833882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605602833882 : Closed e605602833882 ∧ code e605602833882 = 9401695856090 := by decide
theorem cert_e605602833882 : check e605602833882 [[.under],[.under]] .three = true := by decide
def e605602834038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602834038 : Closed e605602834038 ∧ code e605602834038 = 9401695856246 := by decide
theorem cert_e605602834038 : check e605602834038 [[.under],[.under]] .three = true := by decide
def e605602834230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602834230 : Closed e605602834230 ∧ code e605602834230 = 9401695856438 := by decide
theorem cert_e605602834230 : check e605602834230 [[.under],[.under]] .three = true := by decide
def e605602834234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602834234 : Closed e605602834234 ∧ code e605602834234 = 9401695856442 := by decide
theorem cert_e605602834234 : check e605602834234 [[.under],[.under]] .three = true := by decide
def e605602863982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e605602863982 : Closed e605602863982 ∧ code e605602863982 = 9401695886190 := by decide
theorem cert_e605602863982 : check e605602863982 [[.under],[.under]] .three = true := by decide
def e605602863990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e605602863990 : Closed e605602863990 ∧ code e605602863990 = 9401695886198 := by decide
theorem cert_e605602863990 : check e605602863990 [[.under],[.under]] .three = true := by decide
def e605602864054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e605602864054 : Closed e605602864054 ∧ code e605602864054 = 9401695886262 := by decide
theorem cert_e605602864054 : check e605602864054 [[.under],[.under]] .three = true := by decide
def e605602864494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605602864494 : Closed e605602864494 ∧ code e605602864494 = 9401695886702 := by decide
theorem cert_e605602864494 : check e605602864494 [[.under],[.under]] .three = true := by decide
def e605602864502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605602864502 : Closed e605602864502 ∧ code e605602864502 = 9401695886710 := by decide
theorem cert_e605602864502 : check e605602864502 [[.under],[.under]] .three = true := by decide
def e605602864558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605602864558 : Closed e605602864558 ∧ code e605602864558 = 9401695886766 := by decide
theorem cert_e605602864558 : check e605602864558 [[.under],[.under]] .three = true := by decide
def e605602864570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605602864570 : Closed e605602864570 ∧ code e605602864570 = 9401695886778 := by decide
theorem cert_e605602864570 : check e605602864570 [[.under],[.under]] .three = true := by decide
def e605602864598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605602864598 : Closed e605602864598 ∧ code e605602864598 = 9401695886806 := by decide
theorem cert_e605602864598 : check e605602864598 [[.under],[.under]] .three = true := by decide
def e605602864602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605602864602 : Closed e605602864602 ∧ code e605602864602 = 9401695886810 := by decide
theorem cert_e605602864602 : check e605602864602 [[.under],[.under]] .three = true := by decide
def e605602864822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e605602864822 : Closed e605602864822 ∧ code e605602864822 = 9401695887030 := by decide
theorem cert_e605602864822 : check e605602864822 [[.under],[.under]] .three = true := by decide
def e605602864854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e605602864854 : Closed e605602864854 ∧ code e605602864854 = 9401695887062 := by decide
theorem cert_e605602864854 : check e605602864854 [[.under],[.under]] .three = true := by decide
def e605602864858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e605602864858 : Closed e605602864858 ∧ code e605602864858 = 9401695887066 := by decide
theorem cert_e605602864858 : check e605602864858 [[.under],[.under]] .three = true := by decide
def e605602867054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605602867054 : Closed e605602867054 ∧ code e605602867054 = 9401695889262 := by decide
theorem cert_e605602867054 : check e605602867054 [[.under],[.under]] .three = true := by decide
def e605602867062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e605602867062 : Closed e605602867062 ∧ code e605602867062 = 9401695889270 := by decide
theorem cert_e605602867062 : check e605602867062 [[.under],[.under]] .three = true := by decide
def e605602867126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e605602867126 : Closed e605602867126 ∧ code e605602867126 = 9401695889334 := by decide
theorem cert_e605602867126 : check e605602867126 [[.under],[.under]] .three = true := by decide
def e605602868462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605602868462 : Closed e605602868462 ∧ code e605602868462 = 9401695890670 := by decide
theorem cert_e605602868462 : check e605602868462 [[.under],[.under]] .three = true := by decide
def e605602868470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605602868470 : Closed e605602868470 ∧ code e605602868470 = 9401695890678 := by decide
theorem cert_e605602868470 : check e605602868470 [[.under],[.under]] .three = true := by decide
def e605602868854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e605602868854 : Closed e605602868854 ∧ code e605602868854 = 9401695891062 := by decide
theorem cert_e605602868854 : check e605602868854 [[.under],[.under]] .three = true := by decide
def e605602870126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605602870126 : Closed e605602870126 ∧ code e605602870126 = 9401695892334 := by decide
theorem cert_e605602870126 : check e605602870126 [[.under],[.under]] .three = true := by decide
def e605602870134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605602870134 : Closed e605602870134 ∧ code e605602870134 = 9401695892342 := by decide
theorem cert_e605602870134 : check e605602870134 [[.under],[.under]] .three = true := by decide
def e605602870190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605602870190 : Closed e605602870190 ∧ code e605602870190 = 9401695892398 := by decide
theorem cert_e605602870190 : check e605602870190 [[.under],[.under]] .three = true := by decide
def e605602870202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605602870202 : Closed e605602870202 ∧ code e605602870202 = 9401695892410 := by decide
theorem cert_e605602870202 : check e605602870202 [[.under],[.under]] .three = true := by decide
def e605602870230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605602870230 : Closed e605602870230 ∧ code e605602870230 = 9401695892438 := by decide
theorem cert_e605602870230 : check e605602870230 [[.under],[.under]] .three = true := by decide
def e605602870234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605602870234 : Closed e605602870234 ∧ code e605602870234 = 9401695892442 := by decide
theorem cert_e605602870234 : check e605602870234 [[.under],[.under]] .three = true := by decide
def e605602870510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605602870510 : Closed e605602870510 ∧ code e605602870510 = 9401695892718 := by decide
theorem cert_e605602870510 : check e605602870510 [[.under],[.under]] .three = true := by decide
def e605602870518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605602870518 : Closed e605602870518 ∧ code e605602870518 = 9401695892726 := by decide
theorem cert_e605602870518 : check e605602870518 [[.under],[.under]] .three = true := by decide
def e605602870894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605602870894 : Closed e605602870894 ∧ code e605602870894 = 9401695893102 := by decide
theorem cert_e605602870894 : check e605602870894 [[.under],[.under]] .three = true := by decide
def e605602870906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605602870906 : Closed e605602870906 ∧ code e605602870906 = 9401695893114 := by decide
theorem cert_e605602870906 : check e605602870906 [[.under],[.under]] .three = true := by decide
def e605602871094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605602871094 : Closed e605602871094 ∧ code e605602871094 = 9401695893302 := by decide
theorem cert_e605602871094 : check e605602871094 [[.under],[.under]] .three = true := by decide
def e605602871098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605602871098 : Closed e605602871098 ∧ code e605602871098 = 9401695893306 := by decide
theorem cert_e605602871098 : check e605602871098 [[.under],[.under]] .three = true := by decide
def e605602871734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605602871734 : Closed e605602871734 ∧ code e605602871734 = 9401695893942 := by decide
theorem cert_e605602871734 : check e605602871734 [[.under],[.under]] .three = true := by decide
def e605602871766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605602871766 : Closed e605602871766 ∧ code e605602871766 = 9401695893974 := by decide
theorem cert_e605602871766 : check e605602871766 [[.under],[.under]] .three = true := by decide
def e605602871770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605602871770 : Closed e605602871770 ∧ code e605602871770 = 9401695893978 := by decide
theorem cert_e605602871770 : check e605602871770 [[.under],[.under]] .three = true := by decide
def e605602871926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e605602871926 : Closed e605602871926 ∧ code e605602871926 = 9401695894134 := by decide
theorem cert_e605602871926 : check e605602871926 [[.under],[.under]] .three = true := by decide
def e605602872118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605602872118 : Closed e605602872118 ∧ code e605602872118 = 9401695894326 := by decide
theorem cert_e605602872118 : check e605602872118 [[.under],[.under]] .three = true := by decide
def e605602872122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605602872122 : Closed e605602872122 ∧ code e605602872122 = 9401695894330 := by decide
theorem cert_e605602872122 : check e605602872122 [[.under],[.under]] .three = true := by decide
def e605602879342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e605602879342 : Closed e605602879342 ∧ code e605602879342 = 9401695901550 := by decide
theorem cert_e605602879342 : check e605602879342 [[.under],[.under]] .three = true := by decide
def e605602879350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e605602879350 : Closed e605602879350 ∧ code e605602879350 = 9401695901558 := by decide
theorem cert_e605602879350 : check e605602879350 [[.under],[.under]] .three = true := by decide
def e605602879414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e605602879414 : Closed e605602879414 ∧ code e605602879414 = 9401695901622 := by decide
theorem cert_e605602879414 : check e605602879414 [[.under],[.under]] .three = true := by decide
def e605602880750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602880750 : Closed e605602880750 ∧ code e605602880750 = 9401695902958 := by decide
theorem cert_e605602880750 : check e605602880750 [[.under],[.under]] .three = true := by decide
def e605602880758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602880758 : Closed e605602880758 ∧ code e605602880758 = 9401695902966 := by decide
theorem cert_e605602880758 : check e605602880758 [[.under],[.under]] .three = true := by decide
def e605602881142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602881142 : Closed e605602881142 ∧ code e605602881142 = 9401695903350 := by decide
theorem cert_e605602881142 : check e605602881142 [[.under],[.under]] .three = true := by decide
def e605602892654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605602892654 : Closed e605602892654 ∧ code e605602892654 = 9401695914862 := by decide
theorem cert_e605602892654 : check e605602892654 [[.under],[.under]] .three = true := by decide
def e605602892662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605602892662 : Closed e605602892662 ∧ code e605602892662 = 9401695914870 := by decide
theorem cert_e605602892662 : check e605602892662 [[.under],[.under]] .three = true := by decide
def e605602892718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605602892718 : Closed e605602892718 ∧ code e605602892718 = 9401695914926 := by decide
theorem cert_e605602892718 : check e605602892718 [[.under],[.under]] .three = true := by decide
def e605602892730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605602892730 : Closed e605602892730 ∧ code e605602892730 = 9401695914938 := by decide
theorem cert_e605602892730 : check e605602892730 [[.under],[.under]] .three = true := by decide
def e605602892758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605602892758 : Closed e605602892758 ∧ code e605602892758 = 9401695914966 := by decide
theorem cert_e605602892758 : check e605602892758 [[.under],[.under]] .three = true := by decide
def e605602892762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605602892762 : Closed e605602892762 ∧ code e605602892762 = 9401695914970 := by decide
theorem cert_e605602892762 : check e605602892762 [[.under],[.under]] .three = true := by decide
def e605602893038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602893038 : Closed e605602893038 ∧ code e605602893038 = 9401695915246 := by decide
theorem cert_e605602893038 : check e605602893038 [[.under],[.under]] .three = true := by decide
def e605602893046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602893046 : Closed e605602893046 ∧ code e605602893046 = 9401695915254 := by decide
theorem cert_e605602893046 : check e605602893046 [[.under],[.under]] .three = true := by decide
def e605602893422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602893422 : Closed e605602893422 ∧ code e605602893422 = 9401695915630 := by decide
theorem cert_e605602893422 : check e605602893422 [[.under],[.under]] .three = true := by decide
def e605602893434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602893434 : Closed e605602893434 ∧ code e605602893434 = 9401695915642 := by decide
theorem cert_e605602893434 : check e605602893434 [[.under],[.under]] .three = true := by decide
def e605602893622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602893622 : Closed e605602893622 ∧ code e605602893622 = 9401695915830 := by decide
theorem cert_e605602893622 : check e605602893622 [[.under],[.under]] .three = true := by decide
def e605602893626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602893626 : Closed e605602893626 ∧ code e605602893626 = 9401695915834 := by decide
theorem cert_e605602893626 : check e605602893626 [[.under],[.under]] .three = true := by decide
def e605602899382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605602899382 : Closed e605602899382 ∧ code e605602899382 = 9401695921590 := by decide
theorem cert_e605602899382 : check e605602899382 [[.under],[.under]] .three = true := by decide
def e605602899414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605602899414 : Closed e605602899414 ∧ code e605602899414 = 9401695921622 := by decide
theorem cert_e605602899414 : check e605602899414 [[.under],[.under]] .three = true := by decide
def e605602899418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605602899418 : Closed e605602899418 ∧ code e605602899418 = 9401695921626 := by decide
theorem cert_e605602899418 : check e605602899418 [[.under],[.under]] .three = true := by decide
def e605602899574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602899574 : Closed e605602899574 ∧ code e605602899574 = 9401695921782 := by decide
theorem cert_e605602899574 : check e605602899574 [[.under],[.under]] .three = true := by decide
def e605602899766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602899766 : Closed e605602899766 ∧ code e605602899766 = 9401695921974 := by decide
theorem cert_e605602899766 : check e605602899766 [[.under],[.under]] .three = true := by decide
def e605602899770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602899770 : Closed e605602899770 ∧ code e605602899770 = 9401695921978 := by decide
theorem cert_e605602899770 : check e605602899770 [[.under],[.under]] .three = true := by decide
def e605603687902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e605603687902 : Closed e605603687902 ∧ code e605603687902 = 9401696710110 := by decide
theorem cert_e605603687902 : check e605603687902 [[.under],[.under]] .three = true := by decide
def e605603687918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e605603687918 : Closed e605603687918 ∧ code e605603687918 = 9401696710126 := by decide
theorem cert_e605603687918 : check e605603687918 [[.under],[.under]] .three = true := by decide
def e605603688158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e605603688158 : Closed e605603688158 ∧ code e605603688158 = 9401696710366 := by decide
theorem cert_e605603688158 : check e605603688158 [[.under],[.under]] .three = true := by decide
def e605603688182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e605603688182 : Closed e605603688182 ∧ code e605603688182 = 9401696710390 := by decide
theorem cert_e605603688182 : check e605603688182 [[.under],[.under]] .three = true := by decide
def e605603688302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e605603688302 : Closed e605603688302 ∧ code e605603688302 = 9401696710510 := by decide
theorem cert_e605603688302 : check e605603688302 [[.under],[.under]] .three = true := by decide
def e605603688310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e605603688310 : Closed e605603688310 ∧ code e605603688310 = 9401696710518 := by decide
theorem cert_e605603688310 : check e605603688310 [[.under],[.under]] .three = true := by decide
def e605603690206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e605603690206 : Closed e605603690206 ∧ code e605603690206 = 9401696712414 := by decide
theorem cert_e605603690206 : check e605603690206 [[.under],[.under]] .three = true := by decide
def e605603690230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e605603690230 : Closed e605603690230 ∧ code e605603690230 = 9401696712438 := by decide
theorem cert_e605603690230 : check e605603690230 [[.under],[.under]] .three = true := by decide
def e605603690422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e605603690422 : Closed e605603690422 ∧ code e605603690422 = 9401696712630 := by decide
theorem cert_e605603690422 : check e605603690422 [[.under],[.under]] .three = true := by decide
def e605603691374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605603691374 : Closed e605603691374 ∧ code e605603691374 = 9401696713582 := by decide
theorem cert_e605603691374 : check e605603691374 [[.under],[.under]] .three = true := by decide
def e605603691382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605603691382 : Closed e605603691382 ∧ code e605603691382 = 9401696713590 := by decide
theorem cert_e605603691382 : check e605603691382 [[.under],[.under]] .three = true := by decide
def e605603691446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605603691446 : Closed e605603691446 ∧ code e605603691446 = 9401696713654 := by decide
theorem cert_e605603691446 : check e605603691446 [[.under],[.under]] .three = true := by decide
def e605603732958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e605603732958 : Closed e605603732958 ∧ code e605603732958 = 9401696755166 := by decide
theorem cert_e605603732958 : check e605603732958 [[.under],[.under]] .three = true := by decide
def e605603732974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e605603732974 : Closed e605603732974 ∧ code e605603732974 = 9401696755182 := by decide
theorem cert_e605603732974 : check e605603732974 [[.under],[.under]] .three = true := by decide
def e605603733214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e605603733214 : Closed e605603733214 ∧ code e605603733214 = 9401696755422 := by decide
theorem cert_e605603733214 : check e605603733214 [[.under],[.under]] .three = true := by decide
def e605603733238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e605603733238 : Closed e605603733238 ∧ code e605603733238 = 9401696755446 := by decide
theorem cert_e605603733238 : check e605603733238 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
