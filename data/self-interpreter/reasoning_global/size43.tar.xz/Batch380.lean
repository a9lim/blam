import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364601910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422364601910 : Closed e2422364601910 ∧ code e2422364601910 = 11218457624118 := by decide
theorem cert_e2422364601910 : check e2422364601910 [[],[]] .three = true := by decide
def e2422364601914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422364601914 : Closed e2422364601914 ∧ code e2422364601914 = 11218457624122 := by decide
theorem cert_e2422364601914 : check e2422364601914 [[],[]] .three = true := by decide
def e2422364601962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422364601962 : Closed e2422364601962 ∧ code e2422364601962 = 11218457624170 := by decide
theorem cert_e2422364601962 : check e2422364601962 [[],[]] .three = true := by decide
def e2422364601998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422364601998 : Closed e2422364601998 ∧ code e2422364601998 = 11218457624206 := by decide
theorem cert_e2422364601998 : check e2422364601998 [[],[]] .three = true := by decide
def e2422364602010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364602010 : Closed e2422364602010 ∧ code e2422364602010 = 11218457624218 := by decide
theorem cert_e2422364602010 : check e2422364602010 [[],[]] .three = true := by decide
def e2422364602046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 4))))))))
theorem wire_e2422364602046 : Closed e2422364602046 ∧ code e2422364602046 = 11218457624254 := by decide
theorem cert_e2422364602046 : check e2422364602046 [[],[]] .three = true := by decide
def e2422364602054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422364602054 : Closed e2422364602054 ∧ code e2422364602054 = 11218457624262 := by decide
theorem cert_e2422364602054 : check e2422364602054 [[],[]] .three = true := by decide
def e2422364602078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 1))) (.var 3))))))))
theorem wire_e2422364602078 : Closed e2422364602078 ∧ code e2422364602078 = 11218457624286 := by decide
theorem cert_e2422364602078 : check e2422364602078 [[],[]] .three = true := by decide
def e2422364602094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 2))) (.var 2))))))))
theorem wire_e2422364602094 : Closed e2422364602094 ∧ code e2422364602094 = 11218457624302 := by decide
theorem cert_e2422364602094 : check e2422364602094 [[],[]] .three = true := by decide
def e2422364602102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 3))) (.var 1))))))))
theorem wire_e2422364602102 : Closed e2422364602102 ∧ code e2422364602102 = 11218457624310 := by decide
theorem cert_e2422364602102 : check e2422364602102 [[],[]] .three = true := by decide
def e2422364602106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 4))) (.var 0))))))))
theorem wire_e2422364602106 : Closed e2422364602106 ∧ code e2422364602106 = 11218457624314 := by decide
theorem cert_e2422364602106 : check e2422364602106 [[],[]] .three = true := by decide
def e2422364604286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 5))))))))))
theorem wire_e2422364604286 : Closed e2422364604286 ∧ code e2422364604286 = 11218457626494 := by decide
theorem cert_e2422364604286 : check e2422364604286 [[],[]] .three = true := by decide
def e2422364604350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422364604350 : Closed e2422364604350 ∧ code e2422364604350 = 11218457626558 := by decide
theorem cert_e2422364604350 : check e2422364604350 [[],[]] .smaller = true := by decide
def e2422364604382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e2422364604382 : Closed e2422364604382 ∧ code e2422364604382 = 11218457626590 := by decide
theorem cert_e2422364604382 : check e2422364604382 [[],[]] .smaller = true := by decide
def e2422364604398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422364604398 : Closed e2422364604398 ∧ code e2422364604398 = 11218457626606 := by decide
theorem cert_e2422364604398 : check e2422364604398 [[],[]] .smaller = true := by decide
def e2422364604406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 5) (.var 1))))))))))
theorem wire_e2422364604406 : Closed e2422364604406 ∧ code e2422364604406 = 11218457626614 := by decide
theorem cert_e2422364604406 : check e2422364604406 [[],[]] .three = true := by decide
def e2422364608046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422364608046 : Closed e2422364608046 ∧ code e2422364608046 = 11218457630254 := by decide
theorem cert_e2422364608046 : check e2422364608046 [[],[]] .smaller = true := by decide
def e2422364608190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2422364608190 : Closed e2422364608190 ∧ code e2422364608190 = 11218457630398 := by decide
theorem cert_e2422364608190 : check e2422364608190 [[],[]] .three = true := by decide
def e2422364608222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422364608222 : Closed e2422364608222 ∧ code e2422364608222 = 11218457630430 := by decide
theorem cert_e2422364608222 : check e2422364608222 [[],[]] .smaller = true := by decide
def e2422364608226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422364608226 : Closed e2422364608226 ∧ code e2422364608226 = 11218457630434 := by decide
theorem cert_e2422364608226 : check e2422364608226 [[],[]] .smaller = true := by decide
def e2422364608238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2422364608238 : Closed e2422364608238 ∧ code e2422364608238 = 11218457630446 := by decide
theorem cert_e2422364608238 : check e2422364608238 [[],[]] .smaller = true := by decide
def e2422364608246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422364608246 : Closed e2422364608246 ∧ code e2422364608246 = 11218457630454 := by decide
theorem cert_e2422364608246 : check e2422364608246 [[],[]] .smaller = true := by decide
def e2422364608250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2422364608250 : Closed e2422364608250 ∧ code e2422364608250 = 11218457630458 := by decide
theorem cert_e2422364608250 : check e2422364608250 [[],[]] .three = true := by decide
def e2422364608350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422364608350 : Closed e2422364608350 ∧ code e2422364608350 = 11218457630558 := by decide
theorem cert_e2422364608350 : check e2422364608350 [[],[]] .smaller = true := by decide
def e2422364608366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2422364608366 : Closed e2422364608366 ∧ code e2422364608366 = 11218457630574 := by decide
theorem cert_e2422364608366 : check e2422364608366 [[],[]] .smaller = true := by decide
def e2422364608374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2422364608374 : Closed e2422364608374 ∧ code e2422364608374 = 11218457630582 := by decide
theorem cert_e2422364608374 : check e2422364608374 [[],[]] .smaller = true := by decide
def e2422364608378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422364608378 : Closed e2422364608378 ∧ code e2422364608378 = 11218457630586 := by decide
theorem cert_e2422364608378 : check e2422364608378 [[],[]] .smaller = true := by decide
def e2422364608394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364608394 : Closed e2422364608394 ∧ code e2422364608394 = 11218457630602 := by decide
theorem cert_e2422364608394 : check e2422364608394 [[],[]] .smaller = true := by decide
def e2422364608418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364608418 : Closed e2422364608418 ∧ code e2422364608418 = 11218457630626 := by decide
theorem cert_e2422364608418 : check e2422364608418 [[],[]] .smaller = true := by decide
def e2422364608430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2422364608430 : Closed e2422364608430 ∧ code e2422364608430 = 11218457630638 := by decide
theorem cert_e2422364608430 : check e2422364608430 [[],[]] .smaller = true := by decide
def e2422364608438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2422364608438 : Closed e2422364608438 ∧ code e2422364608438 = 11218457630646 := by decide
theorem cert_e2422364608438 : check e2422364608438 [[],[]] .smaller = true := by decide
def e2422364608442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2422364608442 : Closed e2422364608442 ∧ code e2422364608442 = 11218457630650 := by decide
theorem cert_e2422364608442 : check e2422364608442 [[],[]] .smaller = true := by decide
def e2422364608470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422364608470 : Closed e2422364608470 ∧ code e2422364608470 = 11218457630678 := by decide
theorem cert_e2422364608470 : check e2422364608470 [[],[]] .smaller = true := by decide
def e2422364608474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422364608474 : Closed e2422364608474 ∧ code e2422364608474 = 11218457630682 := by decide
theorem cert_e2422364608474 : check e2422364608474 [[],[]] .smaller = true := by decide
def e2422364608490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2422364608490 : Closed e2422364608490 ∧ code e2422364608490 = 11218457630698 := by decide
theorem cert_e2422364608490 : check e2422364608490 [[],[]] .three = true := by decide
def e2422364608574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422364608574 : Closed e2422364608574 ∧ code e2422364608574 = 11218457630782 := by decide
theorem cert_e2422364608574 : check e2422364608574 [[],[]] .smaller = true := by decide
def e2422364608958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422364608958 : Closed e2422364608958 ∧ code e2422364608958 = 11218457631166 := by decide
theorem cert_e2422364608958 : check e2422364608958 [[],[]] .three = true := by decide
def e2422364608990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364608990 : Closed e2422364608990 ∧ code e2422364608990 = 11218457631198 := by decide
theorem cert_e2422364608990 : check e2422364608990 [[],[]] .smaller = true := by decide
def e2422364608994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422364608994 : Closed e2422364608994 ∧ code e2422364608994 = 11218457631202 := by decide
theorem cert_e2422364608994 : check e2422364608994 [[],[]] .smaller = true := by decide
def e2422364609006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422364609006 : Closed e2422364609006 ∧ code e2422364609006 = 11218457631214 := by decide
theorem cert_e2422364609006 : check e2422364609006 [[],[]] .smaller = true := by decide
def e2422364609014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364609014 : Closed e2422364609014 ∧ code e2422364609014 = 11218457631222 := by decide
theorem cert_e2422364609014 : check e2422364609014 [[],[]] .smaller = true := by decide
def e2422364609018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422364609018 : Closed e2422364609018 ∧ code e2422364609018 = 11218457631226 := by decide
theorem cert_e2422364609018 : check e2422364609018 [[],[]] .three = true := by decide
def e2422364609662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 5))))))))))
theorem wire_e2422364609662 : Closed e2422364609662 ∧ code e2422364609662 = 11218457631870 := by decide
theorem cert_e2422364609662 : check e2422364609662 [[],[]] .three = true := by decide
def e2422364609758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364609758 : Closed e2422364609758 ∧ code e2422364609758 = 11218457631966 := by decide
theorem cert_e2422364609758 : check e2422364609758 [[],[]] .smaller = true := by decide
def e2422364609774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364609774 : Closed e2422364609774 ∧ code e2422364609774 = 11218457631982 := by decide
theorem cert_e2422364609774 : check e2422364609774 [[],[]] .smaller = true := by decide
def e2422364609782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364609782 : Closed e2422364609782 ∧ code e2422364609782 = 11218457631990 := by decide
theorem cert_e2422364609782 : check e2422364609782 [[],[]] .smaller = true := by decide
def e2422364609786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364609786 : Closed e2422364609786 ∧ code e2422364609786 = 11218457631994 := by decide
theorem cert_e2422364609786 : check e2422364609786 [[],[]] .smaller = true := by decide
def e2422364610062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364610062 : Closed e2422364610062 ∧ code e2422364610062 = 11218457632270 := by decide
theorem cert_e2422364610062 : check e2422364610062 [[],[]] .smaller = true := by decide
def e2422364610074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364610074 : Closed e2422364610074 ∧ code e2422364610074 = 11218457632282 := by decide
theorem cert_e2422364610074 : check e2422364610074 [[],[]] .smaller = true := by decide
def e2422364610146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364610146 : Closed e2422364610146 ∧ code e2422364610146 = 11218457632354 := by decide
theorem cert_e2422364610146 : check e2422364610146 [[],[]] .smaller = true := by decide
def e2422364610158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364610158 : Closed e2422364610158 ∧ code e2422364610158 = 11218457632366 := by decide
theorem cert_e2422364610158 : check e2422364610158 [[],[]] .smaller = true := by decide
def e2422364610166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364610166 : Closed e2422364610166 ∧ code e2422364610166 = 11218457632374 := by decide
theorem cert_e2422364610166 : check e2422364610166 [[],[]] .smaller = true := by decide
def e2422364610170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364610170 : Closed e2422364610170 ∧ code e2422364610170 = 11218457632378 := by decide
theorem cert_e2422364610170 : check e2422364610170 [[],[]] .smaller = true := by decide
def e2422364610358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364610358 : Closed e2422364610358 ∧ code e2422364610358 = 11218457632566 := by decide
theorem cert_e2422364610358 : check e2422364610358 [[],[]] .smaller = true := by decide
def e2422364610362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364610362 : Closed e2422364610362 ∧ code e2422364610362 = 11218457632570 := by decide
theorem cert_e2422364610362 : check e2422364610362 [[],[]] .smaller = true := by decide
def e2422364610446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.lam (.var 2))))))))))
theorem wire_e2422364610446 : Closed e2422364610446 ∧ code e2422364610446 = 11218457632654 := by decide
theorem cert_e2422364610446 : check e2422364610446 [[],[]] .three = true := by decide
def e2422364610458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364610458 : Closed e2422364610458 ∧ code e2422364610458 = 11218457632666 := by decide
theorem cert_e2422364610458 : check e2422364610458 [[],[]] .three = true := by decide
def e2422364610494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 4)))))))))
theorem wire_e2422364610494 : Closed e2422364610494 ∧ code e2422364610494 = 11218457632702 := by decide
theorem cert_e2422364610494 : check e2422364610494 [[],[]] .three = true := by decide
def e2422364619710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2422364619710 : Closed e2422364619710 ∧ code e2422364619710 = 11218457641918 := by decide
theorem cert_e2422364619710 : check e2422364619710 [[],[]] .smaller = true := by decide
def e2422364619766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2422364619766 : Closed e2422364619766 ∧ code e2422364619766 = 11218457641974 := by decide
theorem cert_e2422364619766 : check e2422364619766 [[],[]] .smaller = true := by decide
def e2422364621662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2422364621662 : Closed e2422364621662 ∧ code e2422364621662 = 11218457643870 := by decide
theorem cert_e2422364621662 : check e2422364621662 [[],[]] .smaller = true := by decide
def e2422364621678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422364621678 : Closed e2422364621678 ∧ code e2422364621678 = 11218457643886 := by decide
theorem cert_e2422364621678 : check e2422364621678 [[],[]] .smaller = true := by decide
def e2422364621686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422364621686 : Closed e2422364621686 ∧ code e2422364621686 = 11218457643894 := by decide
theorem cert_e2422364621686 : check e2422364621686 [[],[]] .smaller = true := by decide
def e2422364621690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2422364621690 : Closed e2422364621690 ∧ code e2422364621690 = 11218457643898 := by decide
theorem cert_e2422364621690 : check e2422364621690 [[],[]] .smaller = true := by decide
def e2422364621742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422364621742 : Closed e2422364621742 ∧ code e2422364621742 = 11218457643950 := by decide
theorem cert_e2422364621742 : check e2422364621742 [[],[]] .smaller = true := by decide
def e2422364621754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422364621754 : Closed e2422364621754 ∧ code e2422364621754 = 11218457643962 := by decide
theorem cert_e2422364621754 : check e2422364621754 [[],[]] .smaller = true := by decide
def e2422364621782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422364621782 : Closed e2422364621782 ∧ code e2422364621782 = 11218457643990 := by decide
theorem cert_e2422364621782 : check e2422364621782 [[],[]] .smaller = true := by decide
def e2422364621786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422364621786 : Closed e2422364621786 ∧ code e2422364621786 = 11218457643994 := by decide
theorem cert_e2422364621786 : check e2422364621786 [[],[]] .smaller = true := by decide
def e2422364621802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2422364621802 : Closed e2422364621802 ∧ code e2422364621802 = 11218457644010 := by decide
theorem cert_e2422364621802 : check e2422364621802 [[],[]] .smaller = true := by decide
def e2422364621950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 5))))))))))
theorem wire_e2422364621950 : Closed e2422364621950 ∧ code e2422364621950 = 11218457644158 := by decide
theorem cert_e2422364621950 : check e2422364621950 [[],[]] .three = true := by decide
def e2422364622046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364622046 : Closed e2422364622046 ∧ code e2422364622046 = 11218457644254 := by decide
theorem cert_e2422364622046 : check e2422364622046 [[],[]] .smaller = true := by decide
def e2422364622062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364622062 : Closed e2422364622062 ∧ code e2422364622062 = 11218457644270 := by decide
theorem cert_e2422364622062 : check e2422364622062 [[],[]] .smaller = true := by decide
def e2422364622070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364622070 : Closed e2422364622070 ∧ code e2422364622070 = 11218457644278 := by decide
theorem cert_e2422364622070 : check e2422364622070 [[],[]] .smaller = true := by decide
def e2422364622074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364622074 : Closed e2422364622074 ∧ code e2422364622074 = 11218457644282 := by decide
theorem cert_e2422364622074 : check e2422364622074 [[],[]] .smaller = true := by decide
def e2422364622446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364622446 : Closed e2422364622446 ∧ code e2422364622446 = 11218457644654 := by decide
theorem cert_e2422364622446 : check e2422364622446 [[],[]] .smaller = true := by decide
def e2422364622458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364622458 : Closed e2422364622458 ∧ code e2422364622458 = 11218457644666 := by decide
theorem cert_e2422364622458 : check e2422364622458 [[],[]] .smaller = true := by decide
def e2422364622646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364622646 : Closed e2422364622646 ∧ code e2422364622646 = 11218457644854 := by decide
theorem cert_e2422364622646 : check e2422364622646 [[],[]] .smaller = true := by decide
def e2422364622650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364622650 : Closed e2422364622650 ∧ code e2422364622650 = 11218457644858 := by decide
theorem cert_e2422364622650 : check e2422364622650 [[],[]] .smaller = true := by decide
def e2422364622746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364622746 : Closed e2422364622746 ∧ code e2422364622746 = 11218457644954 := by decide
theorem cert_e2422364622746 : check e2422364622746 [[],[]] .smaller = true := by decide
def e2422364622782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 4)))))))))
theorem wire_e2422364622782 : Closed e2422364622782 ∧ code e2422364622782 = 11218457644990 := by decide
theorem cert_e2422364622782 : check e2422364622782 [[],[]] .three = true := by decide
def e2422364622790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 4) (.lam (.var 1))))))))))
theorem wire_e2422364622790 : Closed e2422364622790 ∧ code e2422364622790 = 11218457644998 := by decide
theorem cert_e2422364622790 : check e2422364622790 [[],[]] .three = true := by decide
def e2422364622814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 4) (.var 3)))))))))
theorem wire_e2422364622814 : Closed e2422364622814 ∧ code e2422364622814 = 11218457645022 := by decide
theorem cert_e2422364622814 : check e2422364622814 [[],[]] .three = true := by decide
def e2422364627422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364627422 : Closed e2422364627422 ∧ code e2422364627422 = 11218457649630 := by decide
theorem cert_e2422364627422 : check e2422364627422 [[],[]] .smaller = true := by decide
def e2422364627446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364627446 : Closed e2422364627446 ∧ code e2422364627446 = 11218457649654 := by decide
theorem cert_e2422364627446 : check e2422364627446 [[],[]] .smaller = true := by decide
def e2422364628362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364628362 : Closed e2422364628362 ∧ code e2422364628362 = 11218457650570 := by decide
theorem cert_e2422364628362 : check e2422364628362 [[],[]] .smaller = true := by decide
def e2422364628386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364628386 : Closed e2422364628386 ∧ code e2422364628386 = 11218457650594 := by decide
theorem cert_e2422364628386 : check e2422364628386 [[],[]] .smaller = true := by decide
def e2422364628398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422364628398 : Closed e2422364628398 ∧ code e2422364628398 = 11218457650606 := by decide
theorem cert_e2422364628398 : check e2422364628398 [[],[]] .smaller = true := by decide
def e2422364628406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422364628406 : Closed e2422364628406 ∧ code e2422364628406 = 11218457650614 := by decide
theorem cert_e2422364628406 : check e2422364628406 [[],[]] .smaller = true := by decide
def e2422364628410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422364628410 : Closed e2422364628410 ∧ code e2422364628410 = 11218457650618 := by decide
theorem cert_e2422364628410 : check e2422364628410 [[],[]] .smaller = true := by decide
def e2422364628438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422364628438 : Closed e2422364628438 ∧ code e2422364628438 = 11218457650646 := by decide
theorem cert_e2422364628438 : check e2422364628438 [[],[]] .smaller = true := by decide
def e2422364628442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422364628442 : Closed e2422364628442 ∧ code e2422364628442 = 11218457650650 := by decide
theorem cert_e2422364628442 : check e2422364628442 [[],[]] .smaller = true := by decide
def e2422364628458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422364628458 : Closed e2422364628458 ∧ code e2422364628458 = 11218457650666 := by decide
theorem cert_e2422364628458 : check e2422364628458 [[],[]] .smaller = true := by decide
def e2422364628494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364628494 : Closed e2422364628494 ∧ code e2422364628494 = 11218457650702 := by decide
theorem cert_e2422364628494 : check e2422364628494 [[],[]] .smaller = true := by decide
def e2422364628506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364628506 : Closed e2422364628506 ∧ code e2422364628506 = 11218457650714 := by decide
theorem cert_e2422364628506 : check e2422364628506 [[],[]] .smaller = true := by decide
def e2422364628578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364628578 : Closed e2422364628578 ∧ code e2422364628578 = 11218457650786 := by decide
theorem cert_e2422364628578 : check e2422364628578 [[],[]] .smaller = true := by decide
def e2422364628590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364628590 : Closed e2422364628590 ∧ code e2422364628590 = 11218457650798 := by decide
theorem cert_e2422364628590 : check e2422364628590 [[],[]] .smaller = true := by decide
def e2422364628598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364628598 : Closed e2422364628598 ∧ code e2422364628598 = 11218457650806 := by decide
theorem cert_e2422364628598 : check e2422364628598 [[],[]] .smaller = true := by decide
def e2422364628602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364628602 : Closed e2422364628602 ∧ code e2422364628602 = 11218457650810 := by decide
theorem cert_e2422364628602 : check e2422364628602 [[],[]] .smaller = true := by decide
def e2422364628790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364628790 : Closed e2422364628790 ∧ code e2422364628790 = 11218457650998 := by decide
theorem cert_e2422364628790 : check e2422364628790 [[],[]] .smaller = true := by decide
def e2422364628794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364628794 : Closed e2422364628794 ∧ code e2422364628794 = 11218457651002 := by decide
theorem cert_e2422364628794 : check e2422364628794 [[],[]] .smaller = true := by decide
def e2422364628890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364628890 : Closed e2422364628890 ∧ code e2422364628890 = 11218457651098 := by decide
theorem cert_e2422364628890 : check e2422364628890 [[],[]] .smaller = true := by decide
def e2422364628926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 4)))))))))
theorem wire_e2422364628926 : Closed e2422364628926 ∧ code e2422364628926 = 11218457651134 := by decide
theorem cert_e2422364628926 : check e2422364628926 [[],[]] .three = true := by decide
def e2422364628958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422364628958 : Closed e2422364628958 ∧ code e2422364628958 = 11218457651166 := by decide
theorem cert_e2422364628958 : check e2422364628958 [[],[]] .smaller = true := by decide
def e2422364628974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 4) (.var 2)))))))))
theorem wire_e2422364628974 : Closed e2422364628974 ∧ code e2422364628974 = 11218457651182 := by decide
theorem cert_e2422364628974 : check e2422364628974 [[],[]] .three = true := by decide
def e2422364631278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364631278 : Closed e2422364631278 ∧ code e2422364631278 = 11218457653486 := by decide
theorem cert_e2422364631278 : check e2422364631278 [[],[]] .smaller = true := by decide
def e2422364631286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364631286 : Closed e2422364631286 ∧ code e2422364631286 = 11218457653494 := by decide
theorem cert_e2422364631286 : check e2422364631286 [[],[]] .smaller = true := by decide
def e2422364631766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422364631766 : Closed e2422364631766 ∧ code e2422364631766 = 11218457653974 := by decide
theorem cert_e2422364631766 : check e2422364631766 [[],[]] .smaller = true := by decide
def e2422364631770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422364631770 : Closed e2422364631770 ∧ code e2422364631770 = 11218457653978 := by decide
theorem cert_e2422364631770 : check e2422364631770 [[],[]] .smaller = true := by decide
def e2422364631786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422364631786 : Closed e2422364631786 ∧ code e2422364631786 = 11218457653994 := by decide
theorem cert_e2422364631786 : check e2422364631786 [[],[]] .smaller = true := by decide
def e2422364631862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364631862 : Closed e2422364631862 ∧ code e2422364631862 = 11218457654070 := by decide
theorem cert_e2422364631862 : check e2422364631862 [[],[]] .smaller = true := by decide
def e2422364631866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364631866 : Closed e2422364631866 ∧ code e2422364631866 = 11218457654074 := by decide
theorem cert_e2422364631866 : check e2422364631866 [[],[]] .smaller = true := by decide
def e2422364631962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364631962 : Closed e2422364631962 ∧ code e2422364631962 = 11218457654170 := by decide
theorem cert_e2422364631962 : check e2422364631962 [[],[]] .smaller = true := by decide
def e2422364631998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364631998 : Closed e2422364631998 ∧ code e2422364631998 = 11218457654206 := by decide
theorem cert_e2422364631998 : check e2422364631998 [[],[]] .three = true := by decide
def e2422364632030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422364632030 : Closed e2422364632030 ∧ code e2422364632030 = 11218457654238 := by decide
theorem cert_e2422364632030 : check e2422364632030 [[],[]] .smaller = true := by decide
def e2422364632046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422364632046 : Closed e2422364632046 ∧ code e2422364632046 = 11218457654254 := by decide
theorem cert_e2422364632046 : check e2422364632046 [[],[]] .smaller = true := by decide
def e2422364632054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364632054 : Closed e2422364632054 ∧ code e2422364632054 = 11218457654262 := by decide
theorem cert_e2422364632054 : check e2422364632054 [[],[]] .three = true := by decide
def e2422364633206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364633206 : Closed e2422364633206 ∧ code e2422364633206 = 11218457655414 := by decide
theorem cert_e2422364633206 : check e2422364633206 [[],[]] .three = true := by decide
def e2422364633450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422364633450 : Closed e2422364633450 ∧ code e2422364633450 = 11218457655658 := by decide
theorem cert_e2422364633450 : check e2422364633450 [[],[]] .three = true := by decide
def e2422364633486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422364633486 : Closed e2422364633486 ∧ code e2422364633486 = 11218457655694 := by decide
theorem cert_e2422364633486 : check e2422364633486 [[],[]] .three = true := by decide
def e2422364633498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364633498 : Closed e2422364633498 ∧ code e2422364633498 = 11218457655706 := by decide
theorem cert_e2422364633498 : check e2422364633498 [[],[]] .three = true := by decide
def e2422364633534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364633534 : Closed e2422364633534 ∧ code e2422364633534 = 11218457655742 := by decide
theorem cert_e2422364633534 : check e2422364633534 [[],[]] .three = true := by decide
def e2422364633542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422364633542 : Closed e2422364633542 ∧ code e2422364633542 = 11218457655750 := by decide
theorem cert_e2422364633542 : check e2422364633542 [[],[]] .three = true := by decide
def e2422364633566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364633566 : Closed e2422364633566 ∧ code e2422364633566 = 11218457655774 := by decide
theorem cert_e2422364633566 : check e2422364633566 [[],[]] .three = true := by decide
def e2422364633582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364633582 : Closed e2422364633582 ∧ code e2422364633582 = 11218457655790 := by decide
theorem cert_e2422364633582 : check e2422364633582 [[],[]] .three = true := by decide
def e2422364633590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364633590 : Closed e2422364633590 ∧ code e2422364633590 = 11218457655798 := by decide
theorem cert_e2422364633590 : check e2422364633590 [[],[]] .three = true := by decide
def e2422364633594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364633594 : Closed e2422364633594 ∧ code e2422364633594 = 11218457655802 := by decide
theorem cert_e2422364633594 : check e2422364633594 [[],[]] .three = true := by decide
def e2422364636982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364636982 : Closed e2422364636982 ∧ code e2422364636982 = 11218457659190 := by decide
theorem cert_e2422364636982 : check e2422364636982 [[],[]] .smaller = true := by decide
def e2422364636986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364636986 : Closed e2422364636986 ∧ code e2422364636986 = 11218457659194 := by decide
theorem cert_e2422364636986 : check e2422364636986 [[],[]] .smaller = true := by decide
def e2422364637082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364637082 : Closed e2422364637082 ∧ code e2422364637082 = 11218457659290 := by decide
theorem cert_e2422364637082 : check e2422364637082 [[],[]] .smaller = true := by decide
def e2422364638518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364638518 : Closed e2422364638518 ∧ code e2422364638518 = 11218457660726 := by decide
theorem cert_e2422364638518 : check e2422364638518 [[],[]] .smaller = true := by decide
def e2422364638522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364638522 : Closed e2422364638522 ∧ code e2422364638522 = 11218457660730 := by decide
theorem cert_e2422364638522 : check e2422364638522 [[],[]] .smaller = true := by decide
def e2422364638942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 3))))))))
theorem wire_e2422364638942 : Closed e2422364638942 ∧ code e2422364638942 = 11218457661150 := by decide
theorem cert_e2422364638942 : check e2422364638942 [[],[]] .smaller = true := by decide
def e2422364638958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e2422364638958 : Closed e2422364638958 ∧ code e2422364638958 = 11218457661166 := by decide
theorem cert_e2422364638958 : check e2422364638958 [[],[]] .smaller = true := by decide
def e2422364638966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e2422364638966 : Closed e2422364638966 ∧ code e2422364638966 = 11218457661174 := by decide
theorem cert_e2422364638966 : check e2422364638966 [[],[]] .smaller = true := by decide
def e2422364638970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 4)))) (.var 0))))))))
theorem wire_e2422364638970 : Closed e2422364638970 ∧ code e2422364638970 = 11218457661178 := by decide
theorem cert_e2422364638970 : check e2422364638970 [[],[]] .smaller = true := by decide
def e2422364639086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e2422364639086 : Closed e2422364639086 ∧ code e2422364639086 = 11218457661294 := by decide
theorem cert_e2422364639086 : check e2422364639086 [[],[]] .smaller = true := by decide
def e2422364639098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e2422364639098 : Closed e2422364639098 ∧ code e2422364639098 = 11218457661306 := by decide
theorem cert_e2422364639098 : check e2422364639098 [[],[]] .smaller = true := by decide
def e2422364639158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e2422364639158 : Closed e2422364639158 ∧ code e2422364639158 = 11218457661366 := by decide
theorem cert_e2422364639158 : check e2422364639158 [[],[]] .smaller = true := by decide
def e2422364639162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e2422364639162 : Closed e2422364639162 ∧ code e2422364639162 = 11218457661370 := by decide
theorem cert_e2422364639162 : check e2422364639162 [[],[]] .smaller = true := by decide
def e2422364639194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 4) (.var 1)))) (.var 0))))))))
theorem wire_e2422364639194 : Closed e2422364639194 ∧ code e2422364639194 = 11218457661402 := by decide
theorem cert_e2422364639194 : check e2422364639194 [[],[]] .smaller = true := by decide
def e2422364639958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422364639958 : Closed e2422364639958 ∧ code e2422364639958 = 11218457662166 := by decide
theorem cert_e2422364639958 : check e2422364639958 [[],[]] .smaller = true := by decide
def e2422364639962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422364639962 : Closed e2422364639962 ∧ code e2422364639962 = 11218457662170 := by decide
theorem cert_e2422364639962 : check e2422364639962 [[],[]] .smaller = true := by decide
def e2422364639978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422364639978 : Closed e2422364639978 ∧ code e2422364639978 = 11218457662186 := by decide
theorem cert_e2422364639978 : check e2422364639978 [[],[]] .smaller = true := by decide
def e2422364640054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364640054 : Closed e2422364640054 ∧ code e2422364640054 = 11218457662262 := by decide
theorem cert_e2422364640054 : check e2422364640054 [[],[]] .smaller = true := by decide
def e2422364640058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364640058 : Closed e2422364640058 ∧ code e2422364640058 = 11218457662266 := by decide
theorem cert_e2422364640058 : check e2422364640058 [[],[]] .smaller = true := by decide
def e2422364640154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364640154 : Closed e2422364640154 ∧ code e2422364640154 = 11218457662362 := by decide
theorem cert_e2422364640154 : check e2422364640154 [[],[]] .smaller = true := by decide
def e2422364641678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422364641678 : Closed e2422364641678 ∧ code e2422364641678 = 11218457663886 := by decide
theorem cert_e2422364641678 : check e2422364641678 [[],[]] .smaller = true := by decide
def e2422364641726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364641726 : Closed e2422364641726 ∧ code e2422364641726 = 11218457663934 := by decide
theorem cert_e2422364641726 : check e2422364641726 [[],[]] .three = true := by decide
def e2422364641734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422364641734 : Closed e2422364641734 ∧ code e2422364641734 = 11218457663942 := by decide
theorem cert_e2422364641734 : check e2422364641734 [[],[]] .smaller = true := by decide
def e2422364641786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364641786 : Closed e2422364641786 ∧ code e2422364641786 = 11218457663994 := by decide
theorem cert_e2422364641786 : check e2422364641786 [[],[]] .three = true := by decide
def e2422364642502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422364642502 : Closed e2422364642502 ∧ code e2422364642502 = 11218457664710 := by decide
theorem cert_e2422364642502 : check e2422364642502 [[],[]] .smaller = true := by decide
def e2422364643226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 5))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364643226 : Closed e2422364643226 ∧ code e2422364643226 = 11218457665434 := by decide
theorem cert_e2422364643226 : check e2422364643226 [[],[]] .three = true := by decide
def e2422364646486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1))))))))
theorem wire_e2422364646486 : Closed e2422364646486 ∧ code e2422364646486 = 11218457668694 := by decide
theorem cert_e2422364646486 : check e2422364646486 [[],[]] .smaller = true := by decide
def e2422364646490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0))))))))
theorem wire_e2422364646490 : Closed e2422364646490 ∧ code e2422364646490 = 11218457668698 := by decide
theorem cert_e2422364646490 : check e2422364646490 [[],[]] .smaller = true := by decide
def e2422364646678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422364646678 : Closed e2422364646678 ∧ code e2422364646678 = 11218457668886 := by decide
theorem cert_e2422364646678 : check e2422364646678 [[],[]] .smaller = true := by decide
def e2422364646750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 3))))))))
theorem wire_e2422364646750 : Closed e2422364646750 ∧ code e2422364646750 = 11218457668958 := by decide
theorem cert_e2422364646750 : check e2422364646750 [[],[]] .smaller = true := by decide
def e2422364646754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422364646754 : Closed e2422364646754 ∧ code e2422364646754 = 11218457668962 := by decide
theorem cert_e2422364646754 : check e2422364646754 [[],[]] .smaller = true := by decide
def e2422364646766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e2422364646766 : Closed e2422364646766 ∧ code e2422364646766 = 11218457668974 := by decide
theorem cert_e2422364646766 : check e2422364646766 [[],[]] .smaller = true := by decide
def e2422364646774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e2422364646774 : Closed e2422364646774 ∧ code e2422364646774 = 11218457668982 := by decide
theorem cert_e2422364646774 : check e2422364646774 [[],[]] .smaller = true := by decide
def e2422364646778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 0))))))))
theorem wire_e2422364646778 : Closed e2422364646778 ∧ code e2422364646778 = 11218457668986 := by decide
theorem cert_e2422364646778 : check e2422364646778 [[],[]] .smaller = true := by decide
end Blc.Floor43
