import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389344709406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2389344709406 : Closed e2389344709406 ∧ code e2389344709406 = 11185437731614 := by decide
def e2389344709518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2389344709518 : Closed e2389344709518 ∧ code e2389344709518 = 11185437731726 := by decide
theorem cert_e2389344709518 : check e2389344709518 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344709530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344709530 : Closed e2389344709530 ∧ code e2389344709530 = 11185437731738 := by decide
theorem cert_e2389344709530 : check e2389344709530 [[],[.left],[]] .chain = true := by decide
def e2389344709742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2389344709742 : Closed e2389344709742 ∧ code e2389344709742 = 11185437731950 := by decide
theorem cert_e2389344709742 : check e2389344709742 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389344709754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2389344709754 : Closed e2389344709754 ∧ code e2389344709754 = 11185437731962 := by decide
theorem cert_e2389344709754 : check e2389344709754 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389344709918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2389344709918 : Closed e2389344709918 ∧ code e2389344709918 = 11185437732126 := by decide
theorem cert_e2389344709918 : check e2389344709918 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389344710086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2389344710086 : Closed e2389344710086 ∧ code e2389344710086 = 11185437732294 := by decide
theorem cert_e2389344710086 : check e2389344710086 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389344710198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2389344710198 : Closed e2389344710198 ∧ code e2389344710198 = 11185437732406 := by decide
theorem cert_e2389344710198 : check e2389344710198 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344710202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2389344710202 : Closed e2389344710202 ∧ code e2389344710202 = 11185437732410 := by decide
theorem cert_e2389344710202 : check e2389344710202 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344710250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2389344710250 : Closed e2389344710250 ∧ code e2389344710250 = 11185437732458 := by decide
theorem cert_e2389344710250 : check e2389344710250 [[],[.left],[]] .chain = true := by decide
def e2389344710286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2389344710286 : Closed e2389344710286 ∧ code e2389344710286 = 11185437732494 := by decide
theorem cert_e2389344710286 : check e2389344710286 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344710298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344710298 : Closed e2389344710298 ∧ code e2389344710298 = 11185437732506 := by decide
theorem cert_e2389344710298 : check e2389344710298 [[],[.left],[]] .chain = true := by decide
def e2389344710342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2389344710342 : Closed e2389344710342 ∧ code e2389344710342 = 11185437732550 := by decide
def e2389344711094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2389344711094 : Closed e2389344711094 ∧ code e2389344711094 = 11185437733302 := by decide
theorem cert_e2389344711094 : check e2389344711094 [[],[.left],[],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2389344711126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2389344711126 : Closed e2389344711126 ∧ code e2389344711126 = 11185437733334 := by decide
theorem cert_e2389344711126 : check e2389344711126 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .three = true := by decide
def e2389344711130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2389344711130 : Closed e2389344711130 ∧ code e2389344711130 = 11185437733338 := by decide
theorem cert_e2389344711130 : check e2389344711130 [[],[.left],[],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2389344711510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2389344711510 : Closed e2389344711510 ∧ code e2389344711510 = 11185437733718 := by decide
theorem cert_e2389344711510 : check e2389344711510 [[],[.left],[]] .chain = true := by decide
def e2389344711514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2389344711514 : Closed e2389344711514 ∧ code e2389344711514 = 11185437733722 := by decide
theorem cert_e2389344711514 : check e2389344711514 [[],[.left],[]] .chain = true := by decide
def e2389344711530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2389344711530 : Closed e2389344711530 ∧ code e2389344711530 = 11185437733738 := by decide
theorem cert_e2389344711530 : check e2389344711530 [[],[.left],[]] .chain = true := by decide
def e2389344711594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2389344711594 : Closed e2389344711594 ∧ code e2389344711594 = 11185437733802 := by decide
theorem cert_e2389344711594 : check e2389344711594 [[],[.left],[]] .chain = true := by decide
def e2389344711798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2389344711798 : Closed e2389344711798 ∧ code e2389344711798 = 11185437734006 := by decide
theorem cert_e2389344711798 : check e2389344711798 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2389344711894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2389344711894 : Closed e2389344711894 ∧ code e2389344711894 = 11185437734102 := by decide
theorem cert_e2389344711894 : check e2389344711894 [[],[.left],[]] .chain = true := by decide
def e2389344711898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2389344711898 : Closed e2389344711898 ∧ code e2389344711898 = 11185437734106 := by decide
theorem cert_e2389344711898 : check e2389344711898 [[],[.left],[]] .chain = true := by decide
def e2389344711914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2389344711914 : Closed e2389344711914 ∧ code e2389344711914 = 11185437734122 := by decide
theorem cert_e2389344711914 : check e2389344711914 [[],[.left],[]] .chain = true := by decide
def e2389344711990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344711990 : Closed e2389344711990 ∧ code e2389344711990 = 11185437734198 := by decide
theorem cert_e2389344711990 : check e2389344711990 [[],[.left],[]] .chain = true := by decide
def e2389344711994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344711994 : Closed e2389344711994 ∧ code e2389344711994 = 11185437734202 := by decide
theorem cert_e2389344711994 : check e2389344711994 [[],[.left],[]] .chain = true := by decide
def e2389344712078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2389344712078 : Closed e2389344712078 ∧ code e2389344712078 = 11185437734286 := by decide
theorem cert_e2389344712078 : check e2389344712078 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2389344712090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344712090 : Closed e2389344712090 ∧ code e2389344712090 = 11185437734298 := by decide
theorem cert_e2389344712090 : check e2389344712090 [[],[.left],[]] .chain = true := by decide
def e2389344712246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2389344712246 : Closed e2389344712246 ∧ code e2389344712246 = 11185437734454 := by decide
theorem cert_e2389344712246 : check e2389344712246 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2389344712250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2389344712250 : Closed e2389344712250 ∧ code e2389344712250 = 11185437734458 := by decide
theorem cert_e2389344712250 : check e2389344712250 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344712298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2389344712298 : Closed e2389344712298 ∧ code e2389344712298 = 11185437734506 := by decide
theorem cert_e2389344712298 : check e2389344712298 [[],[.left],[]] .chain = true := by decide
def e2389344712334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2389344712334 : Closed e2389344712334 ∧ code e2389344712334 = 11185437734542 := by decide
theorem cert_e2389344712334 : check e2389344712334 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2389344712346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344712346 : Closed e2389344712346 ∧ code e2389344712346 = 11185437734554 := by decide
theorem cert_e2389344712346 : check e2389344712346 [[],[.left],[]] .chain = true := by decide
def e2389344712390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2389344712390 : Closed e2389344712390 ∧ code e2389344712390 = 11185437734598 := by decide
theorem cert_e2389344712390 : check e2389344712390 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344718574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2389344718574 : Closed e2389344718574 ∧ code e2389344718574 = 11185437740782 := by decide
theorem cert_e2389344718574 : check e2389344718574 [[],[.left],[]] .chain = true := by decide
def e2389344718582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2389344718582 : Closed e2389344718582 ∧ code e2389344718582 = 11185437740790 := by decide
theorem cert_e2389344718582 : check e2389344718582 [[],[.left],[]] .chain = true := by decide
def e2389344718702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2389344718702 : Closed e2389344718702 ∧ code e2389344718702 = 11185437740910 := by decide
theorem cert_e2389344718702 : check e2389344718702 [[],[.left],[]] .chain = true := by decide
def e2389344718714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2389344718714 : Closed e2389344718714 ∧ code e2389344718714 = 11185437740922 := by decide
theorem cert_e2389344718714 : check e2389344718714 [[],[.left],[]] .chain = true := by decide
def e2389344718774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2389344718774 : Closed e2389344718774 ∧ code e2389344718774 = 11185437740982 := by decide
theorem cert_e2389344718774 : check e2389344718774 [[],[.left],[]] .chain = true := by decide
def e2389344718778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2389344718778 : Closed e2389344718778 ∧ code e2389344718778 = 11185437740986 := by decide
theorem cert_e2389344718778 : check e2389344718778 [[],[.left],[]] .chain = true := by decide
def e2389344722158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2389344722158 : Closed e2389344722158 ∧ code e2389344722158 = 11185437744366 := by decide
theorem cert_e2389344722158 : check e2389344722158 [[],[.left],[]] .sourceHead = true := by decide
def e2389344722166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2389344722166 : Closed e2389344722166 ∧ code e2389344722166 = 11185437744374 := by decide
theorem cert_e2389344722166 : check e2389344722166 [[],[.left],[]] .sourceHead = true := by decide
def e2389344722550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e2389344722550 : Closed e2389344722550 ∧ code e2389344722550 = 11185437744758 := by decide
theorem cert_e2389344722550 : check e2389344722550 [[],[.left],[]] .sourceHead = true := by decide
def e2389344726382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2389344726382 : Closed e2389344726382 ∧ code e2389344726382 = 11185437748590 := by decide
theorem cert_e2389344726382 : check e2389344726382 [[],[.left],[]] .chain = true := by decide
def e2389344726390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2389344726390 : Closed e2389344726390 ∧ code e2389344726390 = 11185437748598 := by decide
theorem cert_e2389344726390 : check e2389344726390 [[],[.left],[]] .chain = true := by decide
def e2389344726446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2389344726446 : Closed e2389344726446 ∧ code e2389344726446 = 11185437748654 := by decide
theorem cert_e2389344726446 : check e2389344726446 [[],[.left],[]] .chain = true := by decide
def e2389344726458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2389344726458 : Closed e2389344726458 ∧ code e2389344726458 = 11185437748666 := by decide
theorem cert_e2389344726458 : check e2389344726458 [[],[.left],[]] .chain = true := by decide
def e2389344726486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2389344726486 : Closed e2389344726486 ∧ code e2389344726486 = 11185437748694 := by decide
theorem cert_e2389344726486 : check e2389344726486 [[],[.left],[]] .chain = true := by decide
def e2389344726490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2389344726490 : Closed e2389344726490 ∧ code e2389344726490 = 11185437748698 := by decide
theorem cert_e2389344726490 : check e2389344726490 [[],[.left],[]] .chain = true := by decide
def e2389344726702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2389344726702 : Closed e2389344726702 ∧ code e2389344726702 = 11185437748910 := by decide
theorem cert_e2389344726702 : check e2389344726702 [[],[.left],[]] .chain = true := by decide
def e2389344726714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2389344726714 : Closed e2389344726714 ∧ code e2389344726714 = 11185437748922 := by decide
theorem cert_e2389344726714 : check e2389344726714 [[],[.left],[]] .chain = true := by decide
def e2389344726762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2389344726762 : Closed e2389344726762 ∧ code e2389344726762 = 11185437748970 := by decide
theorem cert_e2389344726762 : check e2389344726762 [[],[.left],[]] .chain = true := by decide
def e2389344726870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2389344726870 : Closed e2389344726870 ∧ code e2389344726870 = 11185437749078 := by decide
theorem cert_e2389344726870 : check e2389344726870 [[],[.left],[]] .chain = true := by decide
def e2389344726874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2389344726874 : Closed e2389344726874 ∧ code e2389344726874 = 11185437749082 := by decide
theorem cert_e2389344726874 : check e2389344726874 [[],[.left],[]] .chain = true := by decide
def e2389344726890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2389344726890 : Closed e2389344726890 ∧ code e2389344726890 = 11185437749098 := by decide
theorem cert_e2389344726890 : check e2389344726890 [[],[.left],[]] .chain = true := by decide
def e2389344727918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2389344727918 : Closed e2389344727918 ∧ code e2389344727918 = 11185437750126 := by decide
theorem cert_e2389344727918 : check e2389344727918 [[],[.left],[]] .chain = true := by decide
def e2389344727926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2389344727926 : Closed e2389344727926 ∧ code e2389344727926 = 11185437750134 := by decide
theorem cert_e2389344727926 : check e2389344727926 [[],[.left],[]] .chain = true := by decide
def e2389344727982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2389344727982 : Closed e2389344727982 ∧ code e2389344727982 = 11185437750190 := by decide
theorem cert_e2389344727982 : check e2389344727982 [[],[.left],[]] .chain = true := by decide
def e2389344727994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2389344727994 : Closed e2389344727994 ∧ code e2389344727994 = 11185437750202 := by decide
theorem cert_e2389344727994 : check e2389344727994 [[],[.left],[]] .chain = true := by decide
def e2389344728022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2389344728022 : Closed e2389344728022 ∧ code e2389344728022 = 11185437750230 := by decide
theorem cert_e2389344728022 : check e2389344728022 [[],[.left],[]] .chain = true := by decide
def e2389344728026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2389344728026 : Closed e2389344728026 ∧ code e2389344728026 = 11185437750234 := by decide
theorem cert_e2389344728026 : check e2389344728026 [[],[.left],[]] .chain = true := by decide
def e2389344728302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2389344728302 : Closed e2389344728302 ∧ code e2389344728302 = 11185437750510 := by decide
theorem cert_e2389344728302 : check e2389344728302 [[],[.left],[]] .chain = true := by decide
def e2389344728310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2389344728310 : Closed e2389344728310 ∧ code e2389344728310 = 11185437750518 := by decide
theorem cert_e2389344728310 : check e2389344728310 [[],[.left],[]] .chain = true := by decide
def e2389344728686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2389344728686 : Closed e2389344728686 ∧ code e2389344728686 = 11185437750894 := by decide
theorem cert_e2389344728686 : check e2389344728686 [[],[.left],[]] .chain = true := by decide
def e2389344728698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2389344728698 : Closed e2389344728698 ∧ code e2389344728698 = 11185437750906 := by decide
theorem cert_e2389344728698 : check e2389344728698 [[],[.left],[]] .chain = true := by decide
def e2389344728886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344728886 : Closed e2389344728886 ∧ code e2389344728886 = 11185437751094 := by decide
theorem cert_e2389344728886 : check e2389344728886 [[],[.left],[]] .chain = true := by decide
def e2389344728890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344728890 : Closed e2389344728890 ∧ code e2389344728890 = 11185437751098 := by decide
theorem cert_e2389344728890 : check e2389344728890 [[],[.left],[]] .chain = true := by decide
def e2389344729326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2389344729326 : Closed e2389344729326 ∧ code e2389344729326 = 11185437751534 := by decide
theorem cert_e2389344729326 : check e2389344729326 [[],[.left],[]] .sourceHead = true := by decide
def e2389344729334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2389344729334 : Closed e2389344729334 ∧ code e2389344729334 = 11185437751542 := by decide
theorem cert_e2389344729334 : check e2389344729334 [[],[.left],[]] .sourceHead = true := by decide
def e2389344729518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2389344729518 : Closed e2389344729518 ∧ code e2389344729518 = 11185437751726 := by decide
theorem cert_e2389344729518 : check e2389344729518 [[],[.left],[]] .chain = true := by decide
def e2389344729530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2389344729530 : Closed e2389344729530 ∧ code e2389344729530 = 11185437751738 := by decide
theorem cert_e2389344729530 : check e2389344729530 [[],[.left],[]] .chain = true := by decide
def e2389344729578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2389344729578 : Closed e2389344729578 ∧ code e2389344729578 = 11185437751786 := by decide
theorem cert_e2389344729578 : check e2389344729578 [[],[.left],[]] .chain = true := by decide
def e2389344729710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2389344729710 : Closed e2389344729710 ∧ code e2389344729710 = 11185437751918 := by decide
theorem cert_e2389344729710 : check e2389344729710 [[],[.left],[]] .chain = true := by decide
def e2389344729722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2389344729722 : Closed e2389344729722 ∧ code e2389344729722 = 11185437751930 := by decide
theorem cert_e2389344729722 : check e2389344729722 [[],[.left],[]] .chain = true := by decide
def e2389344729886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2389344729886 : Closed e2389344729886 ∧ code e2389344729886 = 11185437752094 := by decide
theorem cert_e2389344729886 : check e2389344729886 [[],[.left],[]] .sourceHead = true := by decide
def e2389344729998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2389344729998 : Closed e2389344729998 ∧ code e2389344729998 = 11185437752206 := by decide
theorem cert_e2389344729998 : check e2389344729998 [[],[.left],[]] .sourceHead = true := by decide
def e2389344730010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344730010 : Closed e2389344730010 ∧ code e2389344730010 = 11185437752218 := by decide
theorem cert_e2389344730010 : check e2389344730010 [[],[.left],[]] .chain = true := by decide
def e2389344730230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2389344730230 : Closed e2389344730230 ∧ code e2389344730230 = 11185437752438 := by decide
theorem cert_e2389344730230 : check e2389344730230 [[],[.left],[]] .sourceHead = true := by decide
def e2389344730326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2389344730326 : Closed e2389344730326 ∧ code e2389344730326 = 11185437752534 := by decide
theorem cert_e2389344730326 : check e2389344730326 [[],[.left],[]] .chain = true := by decide
def e2389344730330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2389344730330 : Closed e2389344730330 ∧ code e2389344730330 = 11185437752538 := by decide
theorem cert_e2389344730330 : check e2389344730330 [[],[.left],[]] .chain = true := by decide
def e2389344730346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2389344730346 : Closed e2389344730346 ∧ code e2389344730346 = 11185437752554 := by decide
theorem cert_e2389344730346 : check e2389344730346 [[],[.left],[]] .chain = true := by decide
def e2389344730422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344730422 : Closed e2389344730422 ∧ code e2389344730422 = 11185437752630 := by decide
theorem cert_e2389344730422 : check e2389344730422 [[],[.left],[]] .chain = true := by decide
def e2389344730426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344730426 : Closed e2389344730426 ∧ code e2389344730426 = 11185437752634 := by decide
theorem cert_e2389344730426 : check e2389344730426 [[],[.left],[]] .chain = true := by decide
def e2389344730510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2389344730510 : Closed e2389344730510 ∧ code e2389344730510 = 11185437752718 := by decide
theorem cert_e2389344730510 : check e2389344730510 [[],[.left],[]] .sourceHead = true := by decide
def e2389344730522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344730522 : Closed e2389344730522 ∧ code e2389344730522 = 11185437752730 := by decide
theorem cert_e2389344730522 : check e2389344730522 [[],[.left],[]] .chain = true := by decide
def e2389344732126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2389344732126 : Closed e2389344732126 ∧ code e2389344732126 = 11185437754334 := by decide
theorem cert_e2389344732126 : check e2389344732126 [[],[.left],[]] .chain = true := by decide
def e2389344732142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2389344732142 : Closed e2389344732142 ∧ code e2389344732142 = 11185437754350 := by decide
theorem cert_e2389344732142 : check e2389344732142 [[],[.left],[]] .chain = true := by decide
def e2389344734062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389344734062 : Closed e2389344734062 ∧ code e2389344734062 = 11185437756270 := by decide
theorem cert_e2389344734062 : check e2389344734062 [[],[.left],[]] .chain = true := by decide
def e2389344734070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389344734070 : Closed e2389344734070 ∧ code e2389344734070 = 11185437756278 := by decide
theorem cert_e2389344734070 : check e2389344734070 [[],[.left],[]] .chain = true := by decide
def e2389344734126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389344734126 : Closed e2389344734126 ∧ code e2389344734126 = 11185437756334 := by decide
theorem cert_e2389344734126 : check e2389344734126 [[],[.left],[]] .chain = true := by decide
def e2389344734138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389344734138 : Closed e2389344734138 ∧ code e2389344734138 = 11185437756346 := by decide
theorem cert_e2389344734138 : check e2389344734138 [[],[.left],[]] .chain = true := by decide
def e2389344734166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389344734166 : Closed e2389344734166 ∧ code e2389344734166 = 11185437756374 := by decide
theorem cert_e2389344734166 : check e2389344734166 [[],[.left],[]] .chain = true := by decide
def e2389344734170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389344734170 : Closed e2389344734170 ∧ code e2389344734170 = 11185437756378 := by decide
theorem cert_e2389344734170 : check e2389344734170 [[],[.left],[]] .chain = true := by decide
def e2389344734446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389344734446 : Closed e2389344734446 ∧ code e2389344734446 = 11185437756654 := by decide
theorem cert_e2389344734446 : check e2389344734446 [[],[.left],[]] .chain = true := by decide
def e2389344734454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389344734454 : Closed e2389344734454 ∧ code e2389344734454 = 11185437756662 := by decide
theorem cert_e2389344734454 : check e2389344734454 [[],[.left],[]] .chain = true := by decide
def e2389344734830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344734830 : Closed e2389344734830 ∧ code e2389344734830 = 11185437757038 := by decide
theorem cert_e2389344734830 : check e2389344734830 [[],[.left],[]] .chain = true := by decide
def e2389344734842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344734842 : Closed e2389344734842 ∧ code e2389344734842 = 11185437757050 := by decide
theorem cert_e2389344734842 : check e2389344734842 [[],[.left],[]] .chain = true := by decide
def e2389344735030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344735030 : Closed e2389344735030 ∧ code e2389344735030 = 11185437757238 := by decide
theorem cert_e2389344735030 : check e2389344735030 [[],[.left],[]] .chain = true := by decide
def e2389344735034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344735034 : Closed e2389344735034 ∧ code e2389344735034 = 11185437757242 := by decide
theorem cert_e2389344735034 : check e2389344735034 [[],[.left],[]] .chain = true := by decide
def e2389344739806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2389344739806 : Closed e2389344739806 ∧ code e2389344739806 = 11185437762014 := by decide
theorem cert_e2389344739806 : check e2389344739806 [[],[.left],[]] .chain = true := by decide
def e2389344739830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2389344739830 : Closed e2389344739830 ∧ code e2389344739830 = 11185437762038 := by decide
theorem cert_e2389344739830 : check e2389344739830 [[],[.left],[]] .chain = true := by decide
def e2389344740782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2389344740782 : Closed e2389344740782 ∧ code e2389344740782 = 11185437762990 := by decide
theorem cert_e2389344740782 : check e2389344740782 [[],[.left],[]] .chain = true := by decide
def e2389344740794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2389344740794 : Closed e2389344740794 ∧ code e2389344740794 = 11185437763002 := by decide
theorem cert_e2389344740794 : check e2389344740794 [[],[.left],[]] .chain = true := by decide
def e2389344740842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2389344740842 : Closed e2389344740842 ∧ code e2389344740842 = 11185437763050 := by decide
theorem cert_e2389344740842 : check e2389344740842 [[],[.left],[]] .chain = true := by decide
def e2389344740974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344740974 : Closed e2389344740974 ∧ code e2389344740974 = 11185437763182 := by decide
theorem cert_e2389344740974 : check e2389344740974 [[],[.left],[]] .chain = true := by decide
def e2389344740986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344740986 : Closed e2389344740986 ∧ code e2389344740986 = 11185437763194 := by decide
theorem cert_e2389344740986 : check e2389344740986 [[],[.left],[]] .chain = true := by decide
def e2389344741150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2389344741150 : Closed e2389344741150 ∧ code e2389344741150 = 11185437763358 := by decide
theorem cert_e2389344741150 : check e2389344741150 [[],[.left],[]] .sourceHead = true := by decide
def e2389344741262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2389344741262 : Closed e2389344741262 ∧ code e2389344741262 = 11185437763470 := by decide
theorem cert_e2389344741262 : check e2389344741262 [[],[.left],[]] .sourceHead = true := by decide
def e2389344741274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344741274 : Closed e2389344741274 ∧ code e2389344741274 = 11185437763482 := by decide
theorem cert_e2389344741274 : check e2389344741274 [[],[.left],[]] .chain = true := by decide
def e2389344743662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2389344743662 : Closed e2389344743662 ∧ code e2389344743662 = 11185437765870 := by decide
theorem cert_e2389344743662 : check e2389344743662 [[],[.left],[]] .chain = true := by decide
def e2389344743670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2389344743670 : Closed e2389344743670 ∧ code e2389344743670 = 11185437765878 := by decide
theorem cert_e2389344743670 : check e2389344743670 [[],[.left],[]] .chain = true := by decide
def e2389344744150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2389344744150 : Closed e2389344744150 ∧ code e2389344744150 = 11185437766358 := by decide
theorem cert_e2389344744150 : check e2389344744150 [[],[.left],[]] .chain = true := by decide
def e2389344744154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2389344744154 : Closed e2389344744154 ∧ code e2389344744154 = 11185437766362 := by decide
theorem cert_e2389344744154 : check e2389344744154 [[],[.left],[]] .chain = true := by decide
def e2389344744170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2389344744170 : Closed e2389344744170 ∧ code e2389344744170 = 11185437766378 := by decide
theorem cert_e2389344744170 : check e2389344744170 [[],[.left],[]] .chain = true := by decide
def e2389344744246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344744246 : Closed e2389344744246 ∧ code e2389344744246 = 11185437766454 := by decide
theorem cert_e2389344744246 : check e2389344744246 [[],[.left],[]] .chain = true := by decide
def e2389344744250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344744250 : Closed e2389344744250 ∧ code e2389344744250 = 11185437766458 := by decide
theorem cert_e2389344744250 : check e2389344744250 [[],[.left],[]] .chain = true := by decide
def e2389344744334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2389344744334 : Closed e2389344744334 ∧ code e2389344744334 = 11185437766542 := by decide
theorem cert_e2389344744334 : check e2389344744334 [[],[.left],[]] .sourceHead = true := by decide
def e2389344744346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344744346 : Closed e2389344744346 ∧ code e2389344744346 = 11185437766554 := by decide
theorem cert_e2389344744346 : check e2389344744346 [[],[.left],[]] .chain = true := by decide
def e2389344749422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2389344749422 : Closed e2389344749422 ∧ code e2389344749422 = 11185437771630 := by decide
theorem cert_e2389344749422 : check e2389344749422 [[],[.left],[]] .chain = true := by decide
def e2389344749434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e2389344749434 : Closed e2389344749434 ∧ code e2389344749434 = 11185437771642 := by decide
theorem cert_e2389344749434 : check e2389344749434 [[],[.left],[]] .chain = true := by decide
def e2389344749530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e2389344749530 : Closed e2389344749530 ∧ code e2389344749530 = 11185437771738 := by decide
theorem cert_e2389344749530 : check e2389344749530 [[],[.left],[]] .chain = true := by decide
def e2389344750830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2389344750830 : Closed e2389344750830 ∧ code e2389344750830 = 11185437773038 := by decide
theorem cert_e2389344750830 : check e2389344750830 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2389344750838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2389344750838 : Closed e2389344750838 ∧ code e2389344750838 = 11185437773046 := by decide
theorem cert_e2389344750838 : check e2389344750838 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344751214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2389344751214 : Closed e2389344751214 ∧ code e2389344751214 = 11185437773422 := by decide
theorem cert_e2389344751214 : check e2389344751214 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344751226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2389344751226 : Closed e2389344751226 ∧ code e2389344751226 = 11185437773434 := by decide
theorem cert_e2389344751226 : check e2389344751226 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344751414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344751414 : Closed e2389344751414 ∧ code e2389344751414 = 11185437773622 := by decide
theorem cert_e2389344751414 : check e2389344751414 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2389344751418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344751418 : Closed e2389344751418 ∧ code e2389344751418 = 11185437773626 := by decide
theorem cert_e2389344751418 : check e2389344751418 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2389344753326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2389344753326 : Closed e2389344753326 ∧ code e2389344753326 = 11185437775534 := by decide
theorem cert_e2389344753326 : check e2389344753326 [[],[.left],[]] .chain = true := by decide
def e2389344753338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2389344753338 : Closed e2389344753338 ∧ code e2389344753338 = 11185437775546 := by decide
theorem cert_e2389344753338 : check e2389344753338 [[],[.left],[]] .chain = true := by decide
def e2389344753386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2389344753386 : Closed e2389344753386 ∧ code e2389344753386 = 11185437775594 := by decide
theorem cert_e2389344753386 : check e2389344753386 [[],[.left],[]] .chain = true := by decide
def e2389344753578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2389344753578 : Closed e2389344753578 ∧ code e2389344753578 = 11185437775786 := by decide
theorem cert_e2389344753578 : check e2389344753578 [[],[.left],[]] .chain = true := by decide
def e2389344753902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2389344753902 : Closed e2389344753902 ∧ code e2389344753902 = 11185437776110 := by decide
theorem cert_e2389344753902 : check e2389344753902 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344753910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2389344753910 : Closed e2389344753910 ∧ code e2389344753910 = 11185437776118 := by decide
theorem cert_e2389344753910 : check e2389344753910 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344754094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2389344754094 : Closed e2389344754094 ∧ code e2389344754094 = 11185437776302 := by decide
theorem cert_e2389344754094 : check e2389344754094 [[],[.left],[]] .chain = true := by decide
def e2389344754106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2389344754106 : Closed e2389344754106 ∧ code e2389344754106 = 11185437776314 := by decide
theorem cert_e2389344754106 : check e2389344754106 [[],[.left],[]] .chain = true := by decide
def e2389344754154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2389344754154 : Closed e2389344754154 ∧ code e2389344754154 = 11185437776362 := by decide
theorem cert_e2389344754154 : check e2389344754154 [[],[.left],[]] .chain = true := by decide
def e2389344754286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2389344754286 : Closed e2389344754286 ∧ code e2389344754286 = 11185437776494 := by decide
theorem cert_e2389344754286 : check e2389344754286 [[],[.left],[]] .chain = true := by decide
def e2389344754298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2389344754298 : Closed e2389344754298 ∧ code e2389344754298 = 11185437776506 := by decide
theorem cert_e2389344754298 : check e2389344754298 [[],[.left],[]] .chain = true := by decide
def e2389344754462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2389344754462 : Closed e2389344754462 ∧ code e2389344754462 = 11185437776670 := by decide
theorem cert_e2389344754462 : check e2389344754462 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344754574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2389344754574 : Closed e2389344754574 ∧ code e2389344754574 = 11185437776782 := by decide
theorem cert_e2389344754574 : check e2389344754574 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344754586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344754586 : Closed e2389344754586 ∧ code e2389344754586 = 11185437776794 := by decide
theorem cert_e2389344754586 : check e2389344754586 [[],[.left],[]] .chain = true := by decide
def e2389344754798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2389344754798 : Closed e2389344754798 ∧ code e2389344754798 = 11185437777006 := by decide
theorem cert_e2389344754798 : check e2389344754798 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344754810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2389344754810 : Closed e2389344754810 ∧ code e2389344754810 = 11185437777018 := by decide
theorem cert_e2389344754810 : check e2389344754810 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344754974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2389344754974 : Closed e2389344754974 ∧ code e2389344754974 = 11185437777182 := by decide
theorem cert_e2389344754974 : check e2389344754974 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344755142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2389344755142 : Closed e2389344755142 ∧ code e2389344755142 = 11185437777350 := by decide
theorem cert_e2389344755142 : check e2389344755142 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344755254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2389344755254 : Closed e2389344755254 ∧ code e2389344755254 = 11185437777462 := by decide
theorem cert_e2389344755254 : check e2389344755254 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344755258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2389344755258 : Closed e2389344755258 ∧ code e2389344755258 = 11185437777466 := by decide
theorem cert_e2389344755258 : check e2389344755258 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344755306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2389344755306 : Closed e2389344755306 ∧ code e2389344755306 = 11185437777514 := by decide
theorem cert_e2389344755306 : check e2389344755306 [[],[.left],[]] .chain = true := by decide
def e2389344755342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2389344755342 : Closed e2389344755342 ∧ code e2389344755342 = 11185437777550 := by decide
theorem cert_e2389344755342 : check e2389344755342 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344755354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344755354 : Closed e2389344755354 ∧ code e2389344755354 = 11185437777562 := by decide
theorem cert_e2389344755354 : check e2389344755354 [[],[.left],[]] .chain = true := by decide
def e2389344755398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2389344755398 : Closed e2389344755398 ∧ code e2389344755398 = 11185437777606 := by decide
theorem cert_e2389344755398 : check e2389344755398 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344756190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2389344756190 : Closed e2389344756190 ∧ code e2389344756190 = 11185437778398 := by decide
theorem cert_e2389344756190 : check e2389344756190 [[],[.left],[]] .chain = true := by decide
def e2389344756214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2389344756214 : Closed e2389344756214 ∧ code e2389344756214 = 11185437778422 := by decide
theorem cert_e2389344756214 : check e2389344756214 [[],[.left],[]] .chain = true := by decide
def e2389344757166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2389344757166 : Closed e2389344757166 ∧ code e2389344757166 = 11185437779374 := by decide
theorem cert_e2389344757166 : check e2389344757166 [[],[.left],[]] .chain = true := by decide
def e2389344757178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2389344757178 : Closed e2389344757178 ∧ code e2389344757178 = 11185437779386 := by decide
theorem cert_e2389344757178 : check e2389344757178 [[],[.left],[]] .chain = true := by decide
def e2389344757226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2389344757226 : Closed e2389344757226 ∧ code e2389344757226 = 11185437779434 := by decide
theorem cert_e2389344757226 : check e2389344757226 [[],[.left],[]] .chain = true := by decide
def e2389344757358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344757358 : Closed e2389344757358 ∧ code e2389344757358 = 11185437779566 := by decide
theorem cert_e2389344757358 : check e2389344757358 [[],[.left],[]] .chain = true := by decide
def e2389344757370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344757370 : Closed e2389344757370 ∧ code e2389344757370 = 11185437779578 := by decide
theorem cert_e2389344757370 : check e2389344757370 [[],[.left],[]] .chain = true := by decide
def e2389344757534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2389344757534 : Closed e2389344757534 ∧ code e2389344757534 = 11185437779742 := by decide
theorem cert_e2389344757534 : check e2389344757534 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2389344757646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2389344757646 : Closed e2389344757646 ∧ code e2389344757646 = 11185437779854 := by decide
theorem cert_e2389344757646 : check e2389344757646 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
end Blc.Floor43
