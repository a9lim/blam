import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422377467522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422377467522 : Closed e2422377467522 ∧ code e2422377467522 = 11218470489730 := by decide
theorem cert_e2422377467522 : check e2422377467522 [[],[]] .smaller = true := by decide
def e2422377467534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422377467534 : Closed e2422377467534 ∧ code e2422377467534 = 11218470489742 := by decide
theorem cert_e2422377467534 : check e2422377467534 [[],[]] .smaller = true := by decide
def e2422377467546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377467546 : Closed e2422377467546 ∧ code e2422377467546 = 11218470489754 := by decide
theorem cert_e2422377467546 : check e2422377467546 [[],[]] .smaller = true := by decide
def e2422377467590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422377467590 : Closed e2422377467590 ∧ code e2422377467590 = 11218470489798 := by decide
theorem cert_e2422377467590 : check e2422377467590 [[],[]] .smaller = true := by decide
def e2422377467614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e2422377467614 : Closed e2422377467614 ∧ code e2422377467614 = 11218470489822 := by decide
theorem cert_e2422377467614 : check e2422377467614 [[],[]] .three = true := by decide
def e2422377467618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422377467618 : Closed e2422377467618 ∧ code e2422377467618 = 11218470489826 := by decide
theorem cert_e2422377467618 : check e2422377467618 [[],[]] .smaller = true := by decide
def e2422377467630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e2422377467630 : Closed e2422377467630 ∧ code e2422377467630 = 11218470489838 := by decide
theorem cert_e2422377467630 : check e2422377467630 [[],[]] .smaller = true := by decide
def e2422377467638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e2422377467638 : Closed e2422377467638 ∧ code e2422377467638 = 11218470489846 := by decide
theorem cert_e2422377467638 : check e2422377467638 [[],[]] .three = true := by decide
def e2422377467670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422377467670 : Closed e2422377467670 ∧ code e2422377467670 = 11218470489878 := by decide
theorem cert_e2422377467670 : check e2422377467670 [[],[]] .smaller = true := by decide
def e2422377467742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e2422377467742 : Closed e2422377467742 ∧ code e2422377467742 = 11218470489950 := by decide
theorem cert_e2422377467742 : check e2422377467742 [[],[]] .three = true := by decide
def e2422377467746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422377467746 : Closed e2422377467746 ∧ code e2422377467746 = 11218470489954 := by decide
theorem cert_e2422377467746 : check e2422377467746 [[],[]] .smaller = true := by decide
def e2422377467758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e2422377467758 : Closed e2422377467758 ∧ code e2422377467758 = 11218470489966 := by decide
theorem cert_e2422377467758 : check e2422377467758 [[],[]] .smaller = true := by decide
def e2422377467766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e2422377467766 : Closed e2422377467766 ∧ code e2422377467766 = 11218470489974 := by decide
theorem cert_e2422377467766 : check e2422377467766 [[],[]] .smaller = true := by decide
def e2422377467770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e2422377467770 : Closed e2422377467770 ∧ code e2422377467770 = 11218470489978 := by decide
theorem cert_e2422377467770 : check e2422377467770 [[],[]] .three = true := by decide
def e2422377467786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377467786 : Closed e2422377467786 ∧ code e2422377467786 = 11218470489994 := by decide
theorem cert_e2422377467786 : check e2422377467786 [[],[]] .three = true := by decide
def e2422377467810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422377467810 : Closed e2422377467810 ∧ code e2422377467810 = 11218470490018 := by decide
theorem cert_e2422377467810 : check e2422377467810 [[],[]] .three = true := by decide
def e2422377467822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e2422377467822 : Closed e2422377467822 ∧ code e2422377467822 = 11218470490030 := by decide
theorem cert_e2422377467822 : check e2422377467822 [[],[]] .three = true := by decide
def e2422377467830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e2422377467830 : Closed e2422377467830 ∧ code e2422377467830 = 11218470490038 := by decide
theorem cert_e2422377467830 : check e2422377467830 [[],[]] .three = true := by decide
def e2422377467834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e2422377467834 : Closed e2422377467834 ∧ code e2422377467834 = 11218470490042 := by decide
theorem cert_e2422377467834 : check e2422377467834 [[],[]] .three = true := by decide
def e2422377468030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 5))))))))))
theorem wire_e2422377468030 : Closed e2422377468030 ∧ code e2422377468030 = 11218470490238 := by decide
theorem cert_e2422377468030 : check e2422377468030 [[],[]] .three = true := by decide
def e2422377468142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422377468142 : Closed e2422377468142 ∧ code e2422377468142 = 11218470490350 := by decide
theorem cert_e2422377468142 : check e2422377468142 [[],[]] .smaller = true := by decide
def e2422377468150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422377468150 : Closed e2422377468150 ∧ code e2422377468150 = 11218470490358 := by decide
theorem cert_e2422377468150 : check e2422377468150 [[],[]] .smaller = true := by decide
def e2422377468630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422377468630 : Closed e2422377468630 ∧ code e2422377468630 = 11218470490838 := by decide
theorem cert_e2422377468630 : check e2422377468630 [[],[]] .smaller = true := by decide
def e2422377468634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422377468634 : Closed e2422377468634 ∧ code e2422377468634 = 11218470490842 := by decide
theorem cert_e2422377468634 : check e2422377468634 [[],[]] .smaller = true := by decide
def e2422377468650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422377468650 : Closed e2422377468650 ∧ code e2422377468650 = 11218470490858 := by decide
theorem cert_e2422377468650 : check e2422377468650 [[],[]] .smaller = true := by decide
def e2422377468726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377468726 : Closed e2422377468726 ∧ code e2422377468726 = 11218470490934 := by decide
theorem cert_e2422377468726 : check e2422377468726 [[],[]] .smaller = true := by decide
def e2422377468730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377468730 : Closed e2422377468730 ∧ code e2422377468730 = 11218470490938 := by decide
theorem cert_e2422377468730 : check e2422377468730 [[],[]] .smaller = true := by decide
def e2422377468802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422377468802 : Closed e2422377468802 ∧ code e2422377468802 = 11218470491010 := by decide
theorem cert_e2422377468802 : check e2422377468802 [[],[]] .smaller = true := by decide
def e2422377468814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422377468814 : Closed e2422377468814 ∧ code e2422377468814 = 11218470491022 := by decide
theorem cert_e2422377468814 : check e2422377468814 [[],[]] .smaller = true := by decide
def e2422377468826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377468826 : Closed e2422377468826 ∧ code e2422377468826 = 11218470491034 := by decide
theorem cert_e2422377468826 : check e2422377468826 [[],[]] .smaller = true := by decide
def e2422377468894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422377468894 : Closed e2422377468894 ∧ code e2422377468894 = 11218470491102 := by decide
theorem cert_e2422377468894 : check e2422377468894 [[],[]] .three = true := by decide
def e2422377468898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422377468898 : Closed e2422377468898 ∧ code e2422377468898 = 11218470491106 := by decide
theorem cert_e2422377468898 : check e2422377468898 [[],[]] .three = true := by decide
def e2422377468910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422377468910 : Closed e2422377468910 ∧ code e2422377468910 = 11218470491118 := by decide
theorem cert_e2422377468910 : check e2422377468910 [[],[]] .three = true := by decide
def e2422377469978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377469978 : Closed e2422377469978 ∧ code e2422377469978 = 11218470492186 := by decide
theorem cert_e2422377469978 : check e2422377469978 [[],[]] .smaller = true := by decide
def e2422377470014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422377470014 : Closed e2422377470014 ∧ code e2422377470014 = 11218470492222 := by decide
theorem cert_e2422377470014 : check e2422377470014 [[],[]] .smaller = true := by decide
def e2422377470062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377470062 : Closed e2422377470062 ∧ code e2422377470062 = 11218470492270 := by decide
theorem cert_e2422377470062 : check e2422377470062 [[],[]] .smaller = true := by decide
def e2422377470070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422377470070 : Closed e2422377470070 ∧ code e2422377470070 = 11218470492278 := by decide
theorem cert_e2422377470070 : check e2422377470070 [[],[]] .smaller = true := by decide
def e2422377470074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377470074 : Closed e2422377470074 ∧ code e2422377470074 = 11218470492282 := by decide
theorem cert_e2422377470074 : check e2422377470074 [[],[]] .smaller = true := by decide
def e2422377470314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422377470314 : Closed e2422377470314 ∧ code e2422377470314 = 11218470492522 := by decide
theorem cert_e2422377470314 : check e2422377470314 [[],[]] .smaller = true := by decide
def e2422377470338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422377470338 : Closed e2422377470338 ∧ code e2422377470338 = 11218470492546 := by decide
theorem cert_e2422377470338 : check e2422377470338 [[],[]] .smaller = true := by decide
def e2422377470350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422377470350 : Closed e2422377470350 ∧ code e2422377470350 = 11218470492558 := by decide
theorem cert_e2422377470350 : check e2422377470350 [[],[]] .smaller = true := by decide
def e2422377470362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377470362 : Closed e2422377470362 ∧ code e2422377470362 = 11218470492570 := by decide
theorem cert_e2422377470362 : check e2422377470362 [[],[]] .smaller = true := by decide
def e2422377470406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422377470406 : Closed e2422377470406 ∧ code e2422377470406 = 11218470492614 := by decide
theorem cert_e2422377470406 : check e2422377470406 [[],[]] .smaller = true := by decide
def e2422377470430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422377470430 : Closed e2422377470430 ∧ code e2422377470430 = 11218470492638 := by decide
theorem cert_e2422377470430 : check e2422377470430 [[],[]] .three = true := by decide
def e2422377470434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422377470434 : Closed e2422377470434 ∧ code e2422377470434 = 11218470492642 := by decide
theorem cert_e2422377470434 : check e2422377470434 [[],[]] .smaller = true := by decide
def e2422377470446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422377470446 : Closed e2422377470446 ∧ code e2422377470446 = 11218470492654 := by decide
theorem cert_e2422377470446 : check e2422377470446 [[],[]] .smaller = true := by decide
def e2422377470454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422377470454 : Closed e2422377470454 ∧ code e2422377470454 = 11218470492662 := by decide
theorem cert_e2422377470454 : check e2422377470454 [[],[]] .three = true := by decide
def e2422377471006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422377471006 : Closed e2422377471006 ∧ code e2422377471006 = 11218470493214 := by decide
theorem cert_e2422377471006 : check e2422377471006 [[],[]] .smaller = true := by decide
def e2422377471198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422377471198 : Closed e2422377471198 ∧ code e2422377471198 = 11218470493406 := by decide
theorem cert_e2422377471198 : check e2422377471198 [[],[]] .three = true := by decide
def e2422377471202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422377471202 : Closed e2422377471202 ∧ code e2422377471202 = 11218470493410 := by decide
theorem cert_e2422377471202 : check e2422377471202 [[],[]] .smaller = true := by decide
def e2422377471214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422377471214 : Closed e2422377471214 ∧ code e2422377471214 = 11218470493422 := by decide
theorem cert_e2422377471214 : check e2422377471214 [[],[]] .smaller = true := by decide
def e2422377471222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422377471222 : Closed e2422377471222 ∧ code e2422377471222 = 11218470493430 := by decide
theorem cert_e2422377471222 : check e2422377471222 [[],[]] .smaller = true := by decide
def e2422377471226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422377471226 : Closed e2422377471226 ∧ code e2422377471226 = 11218470493434 := by decide
theorem cert_e2422377471226 : check e2422377471226 [[],[]] .three = true := by decide
def e2422377471502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422377471502 : Closed e2422377471502 ∧ code e2422377471502 = 11218470493710 := by decide
theorem cert_e2422377471502 : check e2422377471502 [[],[]] .three = true := by decide
def e2422377471514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377471514 : Closed e2422377471514 ∧ code e2422377471514 = 11218470493722 := by decide
theorem cert_e2422377471514 : check e2422377471514 [[],[]] .three = true := by decide
def e2422377471550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.var 4)))))))))
theorem wire_e2422377471550 : Closed e2422377471550 ∧ code e2422377471550 = 11218470493758 := by decide
theorem cert_e2422377471550 : check e2422377471550 [[],[]] .three = true := by decide
def e2422377471586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422377471586 : Closed e2422377471586 ∧ code e2422377471586 = 11218470493794 := by decide
theorem cert_e2422377471586 : check e2422377471586 [[],[]] .three = true := by decide
def e2422377471598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377471598 : Closed e2422377471598 ∧ code e2422377471598 = 11218470493806 := by decide
theorem cert_e2422377471598 : check e2422377471598 [[],[]] .three = true := by decide
def e2422377471606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422377471606 : Closed e2422377471606 ∧ code e2422377471606 = 11218470493814 := by decide
theorem cert_e2422377471606 : check e2422377471606 [[],[]] .three = true := by decide
def e2422377471610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377471610 : Closed e2422377471610 ∧ code e2422377471610 = 11218470493818 := by decide
theorem cert_e2422377471610 : check e2422377471610 [[],[]] .three = true := by decide
def e2422377472106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0))))))))
theorem wire_e2422377472106 : Closed e2422377472106 ∧ code e2422377472106 = 11218470494314 := by decide
theorem cert_e2422377472106 : check e2422377472106 [[],[]] .smaller = true := by decide
def e2422377472154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377472154 : Closed e2422377472154 ∧ code e2422377472154 = 11218470494362 := by decide
theorem cert_e2422377472154 : check e2422377472154 [[],[]] .smaller = true := by decide
def e2422377472238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422377472238 : Closed e2422377472238 ∧ code e2422377472238 = 11218470494446 := by decide
theorem cert_e2422377472238 : check e2422377472238 [[],[]] .smaller = true := by decide
def e2422377472250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422377472250 : Closed e2422377472250 ∧ code e2422377472250 = 11218470494458 := by decide
theorem cert_e2422377472250 : check e2422377472250 [[],[]] .smaller = true := by decide
def e2422377472438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422377472438 : Closed e2422377472438 ∧ code e2422377472438 = 11218470494646 := by decide
theorem cert_e2422377472438 : check e2422377472438 [[],[]] .smaller = true := by decide
def e2422377472442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422377472442 : Closed e2422377472442 ∧ code e2422377472442 = 11218470494650 := by decide
theorem cert_e2422377472442 : check e2422377472442 [[],[]] .smaller = true := by decide
def e2422377472470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422377472470 : Closed e2422377472470 ∧ code e2422377472470 = 11218470494678 := by decide
theorem cert_e2422377472470 : check e2422377472470 [[],[]] .smaller = true := by decide
def e2422377472474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e2422377472474 : Closed e2422377472474 ∧ code e2422377472474 = 11218470494682 := by decide
theorem cert_e2422377472474 : check e2422377472474 [[],[]] .smaller = true := by decide
def e2422377472490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422377472490 : Closed e2422377472490 ∧ code e2422377472490 = 11218470494698 := by decide
theorem cert_e2422377472490 : check e2422377472490 [[],[]] .smaller = true := by decide
def e2422377472622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377472622 : Closed e2422377472622 ∧ code e2422377472622 = 11218470494830 := by decide
theorem cert_e2422377472622 : check e2422377472622 [[],[]] .smaller = true := by decide
def e2422377472634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377472634 : Closed e2422377472634 ∧ code e2422377472634 = 11218470494842 := by decide
theorem cert_e2422377472634 : check e2422377472634 [[],[]] .smaller = true := by decide
def e2422377472798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422377472798 : Closed e2422377472798 ∧ code e2422377472798 = 11218470495006 := by decide
theorem cert_e2422377472798 : check e2422377472798 [[],[]] .smaller = true := by decide
def e2422377472822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377472822 : Closed e2422377472822 ∧ code e2422377472822 = 11218470495030 := by decide
theorem cert_e2422377472822 : check e2422377472822 [[],[]] .smaller = true := by decide
def e2422377472826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377472826 : Closed e2422377472826 ∧ code e2422377472826 = 11218470495034 := by decide
theorem cert_e2422377472826 : check e2422377472826 [[],[]] .smaller = true := by decide
def e2422377472922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377472922 : Closed e2422377472922 ∧ code e2422377472922 = 11218470495130 := by decide
theorem cert_e2422377472922 : check e2422377472922 [[],[]] .smaller = true := by decide
def e2422377472966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422377472966 : Closed e2422377472966 ∧ code e2422377472966 = 11218470495174 := by decide
theorem cert_e2422377472966 : check e2422377472966 [[],[]] .smaller = true := by decide
def e2422377472990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 3))))))))
theorem wire_e2422377472990 : Closed e2422377472990 ∧ code e2422377472990 = 11218470495198 := by decide
theorem cert_e2422377472990 : check e2422377472990 [[],[]] .three = true := by decide
def e2422377473006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 4))) (.var 2))))))))
theorem wire_e2422377473006 : Closed e2422377473006 ∧ code e2422377473006 = 11218470495214 := by decide
theorem cert_e2422377473006 : check e2422377473006 [[],[]] .three = true := by decide
def e2422377473450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422377473450 : Closed e2422377473450 ∧ code e2422377473450 = 11218470495658 := by decide
theorem cert_e2422377473450 : check e2422377473450 [[],[]] .smaller = true := by decide
def e2422377473546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422377473546 : Closed e2422377473546 ∧ code e2422377473546 = 11218470495754 := by decide
theorem cert_e2422377473546 : check e2422377473546 [[],[]] .smaller = true := by decide
def e2422377473582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422377473582 : Closed e2422377473582 ∧ code e2422377473582 = 11218470495790 := by decide
theorem cert_e2422377473582 : check e2422377473582 [[],[]] .smaller = true := by decide
def e2422377473590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422377473590 : Closed e2422377473590 ∧ code e2422377473590 = 11218470495798 := by decide
theorem cert_e2422377473590 : check e2422377473590 [[],[]] .smaller = true := by decide
def e2422377473594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422377473594 : Closed e2422377473594 ∧ code e2422377473594 = 11218470495802 := by decide
theorem cert_e2422377473594 : check e2422377473594 [[],[]] .smaller = true := by decide
def e2422377473642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422377473642 : Closed e2422377473642 ∧ code e2422377473642 = 11218470495850 := by decide
theorem cert_e2422377473642 : check e2422377473642 [[],[]] .smaller = true := by decide
def e2422377473666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422377473666 : Closed e2422377473666 ∧ code e2422377473666 = 11218470495874 := by decide
theorem cert_e2422377473666 : check e2422377473666 [[],[]] .smaller = true := by decide
def e2422377473678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422377473678 : Closed e2422377473678 ∧ code e2422377473678 = 11218470495886 := by decide
theorem cert_e2422377473678 : check e2422377473678 [[],[]] .smaller = true := by decide
def e2422377473690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377473690 : Closed e2422377473690 ∧ code e2422377473690 = 11218470495898 := by decide
theorem cert_e2422377473690 : check e2422377473690 [[],[]] .smaller = true := by decide
def e2422377473734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422377473734 : Closed e2422377473734 ∧ code e2422377473734 = 11218470495942 := by decide
theorem cert_e2422377473734 : check e2422377473734 [[],[]] .smaller = true := by decide
def e2422377473758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2422377473758 : Closed e2422377473758 ∧ code e2422377473758 = 11218470495966 := by decide
theorem cert_e2422377473758 : check e2422377473758 [[],[]] .three = true := by decide
def e2422377473762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422377473762 : Closed e2422377473762 ∧ code e2422377473762 = 11218470495970 := by decide
theorem cert_e2422377473762 : check e2422377473762 [[],[]] .smaller = true := by decide
def e2422377473774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2422377473774 : Closed e2422377473774 ∧ code e2422377473774 = 11218470495982 := by decide
theorem cert_e2422377473774 : check e2422377473774 [[],[]] .smaller = true := by decide
def e2422377473782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2422377473782 : Closed e2422377473782 ∧ code e2422377473782 = 11218470495990 := by decide
theorem cert_e2422377473782 : check e2422377473782 [[],[]] .three = true := by decide
def e2422377473818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422377473818 : Closed e2422377473818 ∧ code e2422377473818 = 11218470496026 := by decide
theorem cert_e2422377473818 : check e2422377473818 [[],[]] .smaller = true := by decide
def e2422377473862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422377473862 : Closed e2422377473862 ∧ code e2422377473862 = 11218470496070 := by decide
theorem cert_e2422377473862 : check e2422377473862 [[],[]] .smaller = true := by decide
def e2422377473886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2422377473886 : Closed e2422377473886 ∧ code e2422377473886 = 11218470496094 := by decide
theorem cert_e2422377473886 : check e2422377473886 [[],[]] .three = true := by decide
def e2422377473914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2422377473914 : Closed e2422377473914 ∧ code e2422377473914 = 11218470496122 := by decide
theorem cert_e2422377473914 : check e2422377473914 [[],[]] .three = true := by decide
def e2422377473930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377473930 : Closed e2422377473930 ∧ code e2422377473930 = 11218470496138 := by decide
theorem cert_e2422377473930 : check e2422377473930 [[],[]] .smaller = true := by decide
def e2422377473954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422377473954 : Closed e2422377473954 ∧ code e2422377473954 = 11218470496162 := by decide
theorem cert_e2422377473954 : check e2422377473954 [[],[]] .smaller = true := by decide
def e2422377473966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2422377473966 : Closed e2422377473966 ∧ code e2422377473966 = 11218470496174 := by decide
theorem cert_e2422377473966 : check e2422377473966 [[],[]] .smaller = true := by decide
def e2422377473978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2422377473978 : Closed e2422377473978 ∧ code e2422377473978 = 11218470496186 := by decide
theorem cert_e2422377473978 : check e2422377473978 [[],[]] .smaller = true := by decide
def e2422377474006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2422377474006 : Closed e2422377474006 ∧ code e2422377474006 = 11218470496214 := by decide
theorem cert_e2422377474006 : check e2422377474006 [[],[]] .three = true := by decide
def e2422377474010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2422377474010 : Closed e2422377474010 ∧ code e2422377474010 = 11218470496218 := by decide
theorem cert_e2422377474010 : check e2422377474010 [[],[]] .three = true := by decide
def e2422377474074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377474074 : Closed e2422377474074 ∧ code e2422377474074 = 11218470496282 := by decide
theorem cert_e2422377474074 : check e2422377474074 [[],[]] .smaller = true := by decide
def e2422377474110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422377474110 : Closed e2422377474110 ∧ code e2422377474110 = 11218470496318 := by decide
theorem cert_e2422377474110 : check e2422377474110 [[],[]] .smaller = true := by decide
def e2422377474158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377474158 : Closed e2422377474158 ∧ code e2422377474158 = 11218470496366 := by decide
theorem cert_e2422377474158 : check e2422377474158 [[],[]] .smaller = true := by decide
def e2422377474166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422377474166 : Closed e2422377474166 ∧ code e2422377474166 = 11218470496374 := by decide
theorem cert_e2422377474166 : check e2422377474166 [[],[]] .smaller = true := by decide
def e2422377474170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377474170 : Closed e2422377474170 ∧ code e2422377474170 = 11218470496378 := by decide
theorem cert_e2422377474170 : check e2422377474170 [[],[]] .smaller = true := by decide
def e2422377474410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422377474410 : Closed e2422377474410 ∧ code e2422377474410 = 11218470496618 := by decide
theorem cert_e2422377474410 : check e2422377474410 [[],[]] .smaller = true := by decide
def e2422377474434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422377474434 : Closed e2422377474434 ∧ code e2422377474434 = 11218470496642 := by decide
theorem cert_e2422377474434 : check e2422377474434 [[],[]] .smaller = true := by decide
def e2422377474446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422377474446 : Closed e2422377474446 ∧ code e2422377474446 = 11218470496654 := by decide
theorem cert_e2422377474446 : check e2422377474446 [[],[]] .smaller = true := by decide
def e2422377474458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377474458 : Closed e2422377474458 ∧ code e2422377474458 = 11218470496666 := by decide
theorem cert_e2422377474458 : check e2422377474458 [[],[]] .smaller = true := by decide
def e2422377474502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422377474502 : Closed e2422377474502 ∧ code e2422377474502 = 11218470496710 := by decide
theorem cert_e2422377474502 : check e2422377474502 [[],[]] .smaller = true := by decide
def e2422377474526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422377474526 : Closed e2422377474526 ∧ code e2422377474526 = 11218470496734 := by decide
theorem cert_e2422377474526 : check e2422377474526 [[],[]] .three = true := by decide
def e2422377474530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422377474530 : Closed e2422377474530 ∧ code e2422377474530 = 11218470496738 := by decide
theorem cert_e2422377474530 : check e2422377474530 [[],[]] .smaller = true := by decide
def e2422377474542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422377474542 : Closed e2422377474542 ∧ code e2422377474542 = 11218470496750 := by decide
theorem cert_e2422377474542 : check e2422377474542 [[],[]] .smaller = true := by decide
def e2422377474550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422377474550 : Closed e2422377474550 ∧ code e2422377474550 = 11218470496758 := by decide
theorem cert_e2422377474550 : check e2422377474550 [[],[]] .three = true := by decide
def e2422377475126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377475126 : Closed e2422377475126 ∧ code e2422377475126 = 11218470497334 := by decide
theorem cert_e2422377475126 : check e2422377475126 [[],[]] .smaller = true := by decide
def e2422377475130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377475130 : Closed e2422377475130 ∧ code e2422377475130 = 11218470497338 := by decide
theorem cert_e2422377475130 : check e2422377475130 [[],[]] .smaller = true := by decide
def e2422377475270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422377475270 : Closed e2422377475270 ∧ code e2422377475270 = 11218470497478 := by decide
theorem cert_e2422377475270 : check e2422377475270 [[],[]] .smaller = true := by decide
def e2422377475294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422377475294 : Closed e2422377475294 ∧ code e2422377475294 = 11218470497502 := by decide
theorem cert_e2422377475294 : check e2422377475294 [[],[]] .three = true := by decide
def e2422377475322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422377475322 : Closed e2422377475322 ∧ code e2422377475322 = 11218470497530 := by decide
theorem cert_e2422377475322 : check e2422377475322 [[],[]] .three = true := by decide
def e2422377475598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422377475598 : Closed e2422377475598 ∧ code e2422377475598 = 11218470497806 := by decide
theorem cert_e2422377475598 : check e2422377475598 [[],[]] .smaller = true := by decide
def e2422377475646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e2422377475646 : Closed e2422377475646 ∧ code e2422377475646 = 11218470497854 := by decide
theorem cert_e2422377475646 : check e2422377475646 [[],[]] .three = true := by decide
def e2422377475682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422377475682 : Closed e2422377475682 ∧ code e2422377475682 = 11218470497890 := by decide
theorem cert_e2422377475682 : check e2422377475682 [[],[]] .smaller = true := by decide
def e2422377475694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377475694 : Closed e2422377475694 ∧ code e2422377475694 = 11218470497902 := by decide
theorem cert_e2422377475694 : check e2422377475694 [[],[]] .smaller = true := by decide
def e2422377475706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377475706 : Closed e2422377475706 ∧ code e2422377475706 = 11218470497914 := by decide
theorem cert_e2422377475706 : check e2422377475706 [[],[]] .smaller = true := by decide
def e2422377475870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e2422377475870 : Closed e2422377475870 ∧ code e2422377475870 = 11218470498078 := by decide
theorem cert_e2422377475870 : check e2422377475870 [[],[]] .three = true := by decide
def e2422377475894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377475894 : Closed e2422377475894 ∧ code e2422377475894 = 11218470498102 := by decide
theorem cert_e2422377475894 : check e2422377475894 [[],[]] .three = true := by decide
def e2422377475898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377475898 : Closed e2422377475898 ∧ code e2422377475898 = 11218470498106 := by decide
theorem cert_e2422377475898 : check e2422377475898 [[],[]] .three = true := by decide
def e2422377476214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422377476214 : Closed e2422377476214 ∧ code e2422377476214 = 11218470498422 := by decide
theorem cert_e2422377476214 : check e2422377476214 [[],[]] .smaller = true := by decide
def e2422377476218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422377476218 : Closed e2422377476218 ∧ code e2422377476218 = 11218470498426 := by decide
theorem cert_e2422377476218 : check e2422377476218 [[],[]] .smaller = true := by decide
def e2422377476406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377476406 : Closed e2422377476406 ∧ code e2422377476406 = 11218470498614 := by decide
theorem cert_e2422377476406 : check e2422377476406 [[],[]] .smaller = true := by decide
def e2422377476410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377476410 : Closed e2422377476410 ∧ code e2422377476410 = 11218470498618 := by decide
theorem cert_e2422377476410 : check e2422377476410 [[],[]] .smaller = true := by decide
def e2422377476494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422377476494 : Closed e2422377476494 ∧ code e2422377476494 = 11218470498702 := by decide
theorem cert_e2422377476494 : check e2422377476494 [[],[]] .smaller = true := by decide
def e2422377476550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422377476550 : Closed e2422377476550 ∧ code e2422377476550 = 11218470498758 := by decide
theorem cert_e2422377476550 : check e2422377476550 [[],[]] .smaller = true := by decide
def e2422377476574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2422377476574 : Closed e2422377476574 ∧ code e2422377476574 = 11218470498782 := by decide
theorem cert_e2422377476574 : check e2422377476574 [[],[]] .three = true := by decide
def e2422377476598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2422377476598 : Closed e2422377476598 ∧ code e2422377476598 = 11218470498806 := by decide
theorem cert_e2422377476598 : check e2422377476598 [[],[]] .three = true := by decide
def e2422377476886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422377476886 : Closed e2422377476886 ∧ code e2422377476886 = 11218470499094 := by decide
theorem cert_e2422377476886 : check e2422377476886 [[],[]] .smaller = true := by decide
def e2422377476958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2422377476958 : Closed e2422377476958 ∧ code e2422377476958 = 11218470499166 := by decide
theorem cert_e2422377476958 : check e2422377476958 [[],[]] .three = true := by decide
def e2422377476962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422377476962 : Closed e2422377476962 ∧ code e2422377476962 = 11218470499170 := by decide
theorem cert_e2422377476962 : check e2422377476962 [[],[]] .smaller = true := by decide
def e2422377476974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422377476974 : Closed e2422377476974 ∧ code e2422377476974 = 11218470499182 := by decide
theorem cert_e2422377476974 : check e2422377476974 [[],[]] .smaller = true := by decide
def e2422377476982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422377476982 : Closed e2422377476982 ∧ code e2422377476982 = 11218470499190 := by decide
theorem cert_e2422377476982 : check e2422377476982 [[],[]] .smaller = true := by decide
def e2422377476986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2422377476986 : Closed e2422377476986 ∧ code e2422377476986 = 11218470499194 := by decide
theorem cert_e2422377476986 : check e2422377476986 [[],[]] .three = true := by decide
def e2422377477002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377477002 : Closed e2422377477002 ∧ code e2422377477002 = 11218470499210 := by decide
theorem cert_e2422377477002 : check e2422377477002 [[],[]] .smaller = true := by decide
def e2422377477026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422377477026 : Closed e2422377477026 ∧ code e2422377477026 = 11218470499234 := by decide
theorem cert_e2422377477026 : check e2422377477026 [[],[]] .smaller = true := by decide
def e2422377477038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422377477038 : Closed e2422377477038 ∧ code e2422377477038 = 11218470499246 := by decide
theorem cert_e2422377477038 : check e2422377477038 [[],[]] .smaller = true := by decide
def e2422377477050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422377477050 : Closed e2422377477050 ∧ code e2422377477050 = 11218470499258 := by decide
theorem cert_e2422377477050 : check e2422377477050 [[],[]] .smaller = true := by decide
def e2422377477078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422377477078 : Closed e2422377477078 ∧ code e2422377477078 = 11218470499286 := by decide
theorem cert_e2422377477078 : check e2422377477078 [[],[]] .smaller = true := by decide
def e2422377477082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422377477082 : Closed e2422377477082 ∧ code e2422377477082 = 11218470499290 := by decide
theorem cert_e2422377477082 : check e2422377477082 [[],[]] .smaller = true := by decide
def e2422377477098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2422377477098 : Closed e2422377477098 ∧ code e2422377477098 = 11218470499306 := by decide
theorem cert_e2422377477098 : check e2422377477098 [[],[]] .three = true := by decide
def e2422377477150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422377477150 : Closed e2422377477150 ∧ code e2422377477150 = 11218470499358 := by decide
theorem cert_e2422377477150 : check e2422377477150 [[],[]] .smaller = true := by decide
def e2422377477342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422377477342 : Closed e2422377477342 ∧ code e2422377477342 = 11218470499550 := by decide
theorem cert_e2422377477342 : check e2422377477342 [[],[]] .three = true := by decide
def e2422377477346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422377477346 : Closed e2422377477346 ∧ code e2422377477346 = 11218470499554 := by decide
theorem cert_e2422377477346 : check e2422377477346 [[],[]] .smaller = true := by decide
def e2422377477358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422377477358 : Closed e2422377477358 ∧ code e2422377477358 = 11218470499566 := by decide
theorem cert_e2422377477358 : check e2422377477358 [[],[]] .smaller = true := by decide
def e2422377477366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422377477366 : Closed e2422377477366 ∧ code e2422377477366 = 11218470499574 := by decide
theorem cert_e2422377477366 : check e2422377477366 [[],[]] .smaller = true := by decide
def e2422377477370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422377477370 : Closed e2422377477370 ∧ code e2422377477370 = 11218470499578 := by decide
theorem cert_e2422377477370 : check e2422377477370 [[],[]] .three = true := by decide
def e2422377477646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422377477646 : Closed e2422377477646 ∧ code e2422377477646 = 11218470499854 := by decide
theorem cert_e2422377477646 : check e2422377477646 [[],[]] .smaller = true := by decide
def e2422377477694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2422377477694 : Closed e2422377477694 ∧ code e2422377477694 = 11218470499902 := by decide
theorem cert_e2422377477694 : check e2422377477694 [[],[]] .three = true := by decide
def e2422377477730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422377477730 : Closed e2422377477730 ∧ code e2422377477730 = 11218470499938 := by decide
theorem cert_e2422377477730 : check e2422377477730 [[],[]] .smaller = true := by decide
def e2422377477742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377477742 : Closed e2422377477742 ∧ code e2422377477742 = 11218470499950 := by decide
theorem cert_e2422377477742 : check e2422377477742 [[],[]] .smaller = true := by decide
end Blc.Floor43
