import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756097456666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097456666 : Closed e756097456666 ∧ code e756097456666 = 9552190478874 := by decide
theorem cert_e756097456666 : check e756097456666 [] .sourceHead = true := by decide
def e756097458202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756097458202 : Closed e756097458202 ∧ code e756097458202 = 9552190480410 := by decide
theorem cert_e756097458202 : check e756097458202 [] .sourceHead = true := by decide
def e756097458294 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756097458294 : Closed e756097458294 ∧ code e756097458294 = 9552190480502 := by decide
theorem cert_e756097458294 : check e756097458294 [] .sourceHead = true := by decide
def e756097458538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756097458538 : Closed e756097458538 ∧ code e756097458538 = 9552190480746 := by decide
theorem cert_e756097458538 : check e756097458538 [] .sourceHead = true := by decide
def e756097458586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756097458586 : Closed e756097458586 ∧ code e756097458586 = 9552190480794 := by decide
theorem cert_e756097458586 : check e756097458586 [] .sourceHead = true := by decide
def e756097459738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756097459738 : Closed e756097459738 ∧ code e756097459738 = 9552190481946 := by decide
theorem cert_e756097459738 : check e756097459738 [] .sourceHead = true := by decide
def e756097462470 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756097462470 : Closed e756097462470 ∧ code e756097462470 = 9552190484678 := by decide
theorem cert_e756097462470 : check e756097462470 [] .sourceHead = true := by decide
def e756097464346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756097464346 : Closed e756097464346 ∧ code e756097464346 = 9552190486554 := by decide
theorem cert_e756097464346 : check e756097464346 [] .sourceHead = true := by decide
def e756097510938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097510938 : Closed e756097510938 ∧ code e756097510938 = 9552190533146 := by decide
theorem cert_e756097510938 : check e756097510938 [] .sourceHead = true := by decide
def e756097514010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097514010 : Closed e756097514010 ∧ code e756097514010 = 9552190536218 := by decide
theorem cert_e756097514010 : check e756097514010 [] .sourceHead = true := by decide
def e756097555994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097555994 : Closed e756097555994 ∧ code e756097555994 = 9552190578202 := by decide
theorem cert_e756097555994 : check e756097555994 [] .sourceHead = true := by decide
def e756097577158 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756097577158 : Closed e756097577158 ∧ code e756097577158 = 9552190599366 := by decide
theorem cert_e756097577158 : check e756097577158 [] .sourceHead = true := by decide
def e756097599002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097599002 : Closed e756097599002 ∧ code e756097599002 = 9552190621210 := by decide
theorem cert_e756097599002 : check e756097599002 [] .sourceHead = true := by decide
def e756097601734 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756097601734 : Closed e756097601734 ∧ code e756097601734 = 9552190623942 := by decide
theorem cert_e756097601734 : check e756097601734 [] .sourceHead = true := by decide
def e756097627674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097627674 : Closed e756097627674 ∧ code e756097627674 = 9552190649882 := by decide
theorem cert_e756097627674 : check e756097627674 [] .sourceHead = true := by decide
def e756097628698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097628698 : Closed e756097628698 ∧ code e756097628698 = 9552190650906 := by decide
theorem cert_e756097628698 : check e756097628698 [] .sourceHead = true := by decide
def e756097640986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097640986 : Closed e756097640986 ∧ code e756097640986 = 9552190663194 := by decide
theorem cert_e756097640986 : check e756097640986 [] .sourceHead = true := by decide
def e756097650202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097650202 : Closed e756097650202 ∧ code e756097650202 = 9552190672410 := by decide
theorem cert_e756097650202 : check e756097650202 [] .sourceHead = true := by decide
def e756097653274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097653274 : Closed e756097653274 ∧ code e756097653274 = 9552190675482 := by decide
theorem cert_e756097653274 : check e756097653274 [] .sourceHead = true := by decide
def e756097654810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756097654810 : Closed e756097654810 ∧ code e756097654810 = 9552190677018 := by decide
theorem cert_e756097654810 : check e756097654810 [] .sourceHead = true := by decide
def e756097654902 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756097654902 : Closed e756097654902 ∧ code e756097654902 = 9552190677110 := by decide
theorem cert_e756097654902 : check e756097654902 [] .sourceHead = true := by decide
def e756097655146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756097655146 : Closed e756097655146 ∧ code e756097655146 = 9552190677354 := by decide
theorem cert_e756097655146 : check e756097655146 [] .sourceHead = true := by decide
def e756097655194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756097655194 : Closed e756097655194 ∧ code e756097655194 = 9552190677402 := by decide
theorem cert_e756097655194 : check e756097655194 [] .sourceHead = true := by decide
def e756097656346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756097656346 : Closed e756097656346 ∧ code e756097656346 = 9552190678554 := by decide
theorem cert_e756097656346 : check e756097656346 [] .sourceHead = true := by decide
def e756097659078 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756097659078 : Closed e756097659078 ∧ code e756097659078 = 9552190681286 := by decide
theorem cert_e756097659078 : check e756097659078 [] .sourceHead = true := by decide
def e756097660954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756097660954 : Closed e756097660954 ∧ code e756097660954 = 9552190683162 := by decide
theorem cert_e756097660954 : check e756097660954 [] .sourceHead = true := by decide
def e756097664538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097664538 : Closed e756097664538 ∧ code e756097664538 = 9552190686746 := by decide
theorem cert_e756097664538 : check e756097664538 [] .sourceHead = true := by decide
def e756097667270 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756097667270 : Closed e756097667270 ∧ code e756097667270 = 9552190689478 := by decide
theorem cert_e756097667270 : check e756097667270 [] .sourceHead = true := by decide
def e756097673242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756097673242 : Closed e756097673242 ∧ code e756097673242 = 9552190695450 := by decide
theorem cert_e756097673242 : check e756097673242 [] .sourceHead = true := by decide
def e756097857050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097857050 : Closed e756097857050 ∧ code e756097857050 = 9552190879258 := by decide
theorem cert_e756097857050 : check e756097857050 [] .sourceHead = true := by decide
def e756097865242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097865242 : Closed e756097865242 ∧ code e756097865242 = 9552190887450 := by decide
theorem cert_e756097865242 : check e756097865242 [] .sourceHead = true := by decide
def e756097866266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097866266 : Closed e756097866266 ∧ code e756097866266 = 9552190888474 := by decide
theorem cert_e756097866266 : check e756097866266 [] .sourceHead = true := by decide
def e756097963546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097963546 : Closed e756097963546 ∧ code e756097963546 = 9552190985754 := by decide
theorem cert_e756097963546 : check e756097963546 [] .sourceHead = true := by decide
def e756097964570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097964570 : Closed e756097964570 ∧ code e756097964570 = 9552190986778 := by decide
theorem cert_e756097964570 : check e756097964570 [] .sourceHead = true := by decide
def e756097968666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097968666 : Closed e756097968666 ∧ code e756097968666 = 9552190990874 := by decide
theorem cert_e756097968666 : check e756097968666 [] .sourceHead = true := by decide
def e756097985050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097985050 : Closed e756097985050 ∧ code e756097985050 = 9552191007258 := by decide
theorem cert_e756097985050 : check e756097985050 [] .sourceHead = true := by decide
def e756098037274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098037274 : Closed e756098037274 ∧ code e756098037274 = 9552191059482 := by decide
theorem cert_e756098037274 : check e756098037274 [] .sourceHead = true := by decide
def e756098061850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098061850 : Closed e756098061850 ∧ code e756098061850 = 9552191084058 := by decide
theorem cert_e756098061850 : check e756098061850 [] .sourceHead = true := by decide
def e756098062874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098062874 : Closed e756098062874 ∧ code e756098062874 = 9552191085082 := by decide
theorem cert_e756098062874 : check e756098062874 [] .sourceHead = true := by decide
def e756098066970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098066970 : Closed e756098066970 ∧ code e756098066970 = 9552191089178 := by decide
theorem cert_e756098066970 : check e756098066970 [] .sourceHead = true := by decide
def e756098086426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098086426 : Closed e756098086426 ∧ code e756098086426 = 9552191108634 := by decide
theorem cert_e756098086426 : check e756098086426 [] .sourceHead = true := by decide
def e756098087450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098087450 : Closed e756098087450 ∧ code e756098087450 = 9552191109658 := by decide
theorem cert_e756098087450 : check e756098087450 [] .sourceHead = true := by decide
def e756098097178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756098097178 : Closed e756098097178 ∧ code e756098097178 = 9552191119386 := by decide
theorem cert_e756098097178 : check e756098097178 [] .sourceHead = true := by decide
def e756098097270 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756098097270 : Closed e756098097270 ∧ code e756098097270 = 9552191119478 := by decide
theorem cert_e756098097270 : check e756098097270 [] .sourceHead = true := by decide
def e756098097514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756098097514 : Closed e756098097514 ∧ code e756098097514 = 9552191119722 := by decide
theorem cert_e756098097514 : check e756098097514 [] .sourceHead = true := by decide
def e756098097562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756098097562 : Closed e756098097562 ∧ code e756098097562 = 9552191119770 := by decide
theorem cert_e756098097562 : check e756098097562 [] .sourceHead = true := by decide
def e756098098714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098098714 : Closed e756098098714 ∧ code e756098098714 = 9552191120922 := by decide
theorem cert_e756098098714 : check e756098098714 [] .sourceHead = true := by decide
def e756098108954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098108954 : Closed e756098108954 ∧ code e756098108954 = 9552191131162 := by decide
theorem cert_e756098108954 : check e756098108954 [] .sourceHead = true := by decide
def e756098112026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098112026 : Closed e756098112026 ∧ code e756098112026 = 9552191134234 := by decide
theorem cert_e756098112026 : check e756098112026 [] .sourceHead = true := by decide
def e756098113562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756098113562 : Closed e756098113562 ∧ code e756098113562 = 9552191135770 := by decide
theorem cert_e756098113562 : check e756098113562 [] .sourceHead = true := by decide
def e756098113654 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756098113654 : Closed e756098113654 ∧ code e756098113654 = 9552191135862 := by decide
theorem cert_e756098113654 : check e756098113654 [] .sourceHead = true := by decide
def e756098113898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756098113898 : Closed e756098113898 ∧ code e756098113898 = 9552191136106 := by decide
theorem cert_e756098113898 : check e756098113898 [] .sourceHead = true := by decide
def e756098113946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756098113946 : Closed e756098113946 ∧ code e756098113946 = 9552191136154 := by decide
theorem cert_e756098113946 : check e756098113946 [] .sourceHead = true := by decide
def e756098115098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098115098 : Closed e756098115098 ∧ code e756098115098 = 9552191137306 := by decide
theorem cert_e756098115098 : check e756098115098 [] .sourceHead = true := by decide
def e756098117830 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756098117830 : Closed e756098117830 ∧ code e756098117830 = 9552191140038 := by decide
theorem cert_e756098117830 : check e756098117830 [] .sourceHead = true := by decide
def e756098119706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098119706 : Closed e756098119706 ∧ code e756098119706 = 9552191141914 := by decide
theorem cert_e756098119706 : check e756098119706 [] .sourceHead = true := by decide
def e756098127898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098127898 : Closed e756098127898 ∧ code e756098127898 = 9552191150106 := by decide
theorem cert_e756098127898 : check e756098127898 [] .sourceHead = true := by decide
def e756098151962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098151962 : Closed e756098151962 ∧ code e756098151962 = 9552191174170 := by decide
theorem cert_e756098151962 : check e756098151962 [] .sourceHead = true := by decide
def e756098152986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098152986 : Closed e756098152986 ∧ code e756098152986 = 9552191175194 := by decide
theorem cert_e756098152986 : check e756098152986 [] .sourceHead = true := by decide
def e756098165274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098165274 : Closed e756098165274 ∧ code e756098165274 = 9552191187482 := by decide
theorem cert_e756098165274 : check e756098165274 [] .sourceHead = true := by decide
def e756098174490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098174490 : Closed e756098174490 ∧ code e756098174490 = 9552191196698 := by decide
theorem cert_e756098174490 : check e756098174490 [] .sourceHead = true := by decide
def e756098177562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098177562 : Closed e756098177562 ∧ code e756098177562 = 9552191199770 := by decide
theorem cert_e756098177562 : check e756098177562 [] .sourceHead = true := by decide
def e756098179098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756098179098 : Closed e756098179098 ∧ code e756098179098 = 9552191201306 := by decide
theorem cert_e756098179098 : check e756098179098 [] .sourceHead = true := by decide
def e756098179190 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756098179190 : Closed e756098179190 ∧ code e756098179190 = 9552191201398 := by decide
theorem cert_e756098179190 : check e756098179190 [] .sourceHead = true := by decide
def e756098179434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756098179434 : Closed e756098179434 ∧ code e756098179434 = 9552191201642 := by decide
theorem cert_e756098179434 : check e756098179434 [] .sourceHead = true := by decide
def e756098179482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756098179482 : Closed e756098179482 ∧ code e756098179482 = 9552191201690 := by decide
theorem cert_e756098179482 : check e756098179482 [] .sourceHead = true := by decide
def e756098180634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098180634 : Closed e756098180634 ∧ code e756098180634 = 9552191202842 := by decide
theorem cert_e756098180634 : check e756098180634 [] .sourceHead = true := by decide
def e756098183366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756098183366 : Closed e756098183366 ∧ code e756098183366 = 9552191205574 := by decide
theorem cert_e756098183366 : check e756098183366 [] .sourceHead = true := by decide
def e756098185242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098185242 : Closed e756098185242 ∧ code e756098185242 = 9552191207450 := by decide
theorem cert_e756098185242 : check e756098185242 [] .sourceHead = true := by decide
def e756098188826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756098188826 : Closed e756098188826 ∧ code e756098188826 = 9552191211034 := by decide
theorem cert_e756098188826 : check e756098188826 [] .sourceHead = true := by decide
def e756098191558 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756098191558 : Closed e756098191558 ∧ code e756098191558 = 9552191213766 := by decide
theorem cert_e756098191558 : check e756098191558 [] .sourceHead = true := by decide
def e756098197530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098197530 : Closed e756098197530 ∧ code e756098197530 = 9552191219738 := by decide
theorem cert_e756098197530 : check e756098197530 [] .sourceHead = true := by decide
def e756098226202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098226202 : Closed e756098226202 ∧ code e756098226202 = 9552191248410 := by decide
theorem cert_e756098226202 : check e756098226202 [] .sourceHead = true := by decide
def e756098230298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756098230298 : Closed e756098230298 ∧ code e756098230298 = 9552191252506 := by decide
theorem cert_e756098230298 : check e756098230298 [] .sourceHead = true := by decide
def e756099771930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756099771930 : Closed e756099771930 ∧ code e756099771930 = 9552192794138 := by decide
theorem cert_e756099771930 : check e756099771930 [] .sourceHead = true := by decide
def e756099773978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756099773978 : Closed e756099773978 ∧ code e756099773978 = 9552192796186 := by decide
theorem cert_e756099773978 : check e756099773978 [] .sourceHead = true := by decide
def e756099804698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756099804698 : Closed e756099804698 ∧ code e756099804698 = 9552192826906 := by decide
theorem cert_e756099804698 : check e756099804698 [] .sourceHead = true := by decide
def e756099807770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756099807770 : Closed e756099807770 ∧ code e756099807770 = 9552192829978 := by decide
theorem cert_e756099807770 : check e756099807770 [] .sourceHead = true := by decide
def e756099823130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756099823130 : Closed e756099823130 ∧ code e756099823130 = 9552192845338 := by decide
theorem cert_e756099823130 : check e756099823130 [] .sourceHead = true := by decide
def e756099824154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756099824154 : Closed e756099824154 ∧ code e756099824154 = 9552192846362 := by decide
theorem cert_e756099824154 : check e756099824154 [] .sourceHead = true := by decide
def e756100689434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756100689434 : Closed e756100689434 ∧ code e756100689434 = 9552193711642 := by decide
theorem cert_e756100689434 : check e756100689434 [] .sourceHead = true := by decide
def e756100691482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756100691482 : Closed e756100691482 ∧ code e756100691482 = 9552193713690 := by decide
theorem cert_e756100691482 : check e756100691482 [] .sourceHead = true := by decide
def e756100789786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756100789786 : Closed e756100789786 ∧ code e756100789786 = 9552193811994 := by decide
theorem cert_e756100789786 : check e756100789786 [] .sourceHead = true := by decide
def e756101770778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101770778 : Closed e756101770778 ∧ code e756101770778 = 9552194792986 := by decide
theorem cert_e756101770778 : check e756101770778 [] .sourceHead = true := by decide
def e756101772826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101772826 : Closed e756101772826 ∧ code e756101772826 = 9552194795034 := by decide
theorem cert_e756101772826 : check e756101772826 [] .sourceHead = true := by decide
def e756101787162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101787162 : Closed e756101787162 ∧ code e756101787162 = 9552194809370 := by decide
theorem cert_e756101787162 : check e756101787162 [] .sourceHead = true := by decide
def e756101790234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101790234 : Closed e756101790234 ∧ code e756101790234 = 9552194812442 := by decide
theorem cert_e756101790234 : check e756101790234 [] .sourceHead = true := by decide
def e756101797402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101797402 : Closed e756101797402 ∧ code e756101797402 = 9552194819610 := by decide
theorem cert_e756101797402 : check e756101797402 [] .sourceHead = true := by decide
def e756101798426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101798426 : Closed e756101798426 ∧ code e756101798426 = 9552194820634 := by decide
theorem cert_e756101798426 : check e756101798426 [] .sourceHead = true := by decide
def e756101852698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101852698 : Closed e756101852698 ∧ code e756101852698 = 9552194874906 := by decide
theorem cert_e756101852698 : check e756101852698 [] .sourceHead = true := by decide
def e756101855770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101855770 : Closed e756101855770 ∧ code e756101855770 = 9552194877978 := by decide
theorem cert_e756101855770 : check e756101855770 [] .sourceHead = true := by decide
def e756101868058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101868058 : Closed e756101868058 ∧ code e756101868058 = 9552194890266 := by decide
theorem cert_e756101868058 : check e756101868058 [] .sourceHead = true := by decide
def e756101895706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101895706 : Closed e756101895706 ∧ code e756101895706 = 9552194917914 := by decide
theorem cert_e756101895706 : check e756101895706 [] .sourceHead = true := by decide
def e756101896730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101896730 : Closed e756101896730 ∧ code e756101896730 = 9552194918938 := by decide
theorem cert_e756101896730 : check e756101896730 [] .sourceHead = true := by decide
def e756101900826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756101900826 : Closed e756101900826 ∧ code e756101900826 = 9552194923034 := by decide
theorem cert_e756101900826 : check e756101900826 [] .sourceHead = true := by decide
def e756102163994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102163994 : Closed e756102163994 ∧ code e756102163994 = 9552195186202 := by decide
theorem cert_e756102163994 : check e756102163994 [] .sourceHead = true := by decide
def e756102166042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102166042 : Closed e756102166042 ∧ code e756102166042 = 9552195188250 := by decide
theorem cert_e756102166042 : check e756102166042 [] .sourceHead = true := by decide
def e756102180378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102180378 : Closed e756102180378 ∧ code e756102180378 = 9552195202586 := by decide
theorem cert_e756102180378 : check e756102180378 [] .sourceHead = true := by decide
def e756102183450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102183450 : Closed e756102183450 ∧ code e756102183450 = 9552195205658 := by decide
theorem cert_e756102183450 : check e756102183450 [] .sourceHead = true := by decide
def e756102190618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102190618 : Closed e756102190618 ∧ code e756102190618 = 9552195212826 := by decide
theorem cert_e756102190618 : check e756102190618 [] .sourceHead = true := by decide
def e756102191642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102191642 : Closed e756102191642 ∧ code e756102191642 = 9552195213850 := by decide
theorem cert_e756102191642 : check e756102191642 [] .sourceHead = true := by decide
def e756102262298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102262298 : Closed e756102262298 ∧ code e756102262298 = 9552195284506 := by decide
theorem cert_e756102262298 : check e756102262298 [] .sourceHead = true := by decide
def e756102264346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102264346 : Closed e756102264346 ∧ code e756102264346 = 9552195286554 := by decide
theorem cert_e756102264346 : check e756102264346 [] .sourceHead = true := by decide
def e756102360602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102360602 : Closed e756102360602 ∧ code e756102360602 = 9552195382810 := by decide
theorem cert_e756102360602 : check e756102360602 [] .sourceHead = true := by decide
def e756102363674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102363674 : Closed e756102363674 ∧ code e756102363674 = 9552195385882 := by decide
theorem cert_e756102363674 : check e756102363674 [] .sourceHead = true := by decide
def e756102389786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756102389786 : Closed e756102389786 ∧ code e756102389786 = 9552195411994 := by decide
theorem cert_e756102389786 : check e756102389786 [] .sourceHead = true := by decide
def e756102389878 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756102389878 : Closed e756102389878 ∧ code e756102389878 = 9552195412086 := by decide
theorem cert_e756102389878 : check e756102389878 [] .sourceHead = true := by decide
def e756102390122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756102390122 : Closed e756102390122 ∧ code e756102390122 = 9552195412330 := by decide
theorem cert_e756102390122 : check e756102390122 [] .sourceHead = true := by decide
def e756102390170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756102390170 : Closed e756102390170 ∧ code e756102390170 = 9552195412378 := by decide
theorem cert_e756102390170 : check e756102390170 [] .sourceHead = true := by decide
def e756102391322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102391322 : Closed e756102391322 ∧ code e756102391322 = 9552195413530 := by decide
theorem cert_e756102391322 : check e756102391322 [] .sourceHead = true := by decide
def e756102411802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102411802 : Closed e756102411802 ∧ code e756102411802 = 9552195434010 := by decide
theorem cert_e756102411802 : check e756102411802 [] .sourceHead = true := by decide
def e756102412826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102412826 : Closed e756102412826 ∧ code e756102412826 = 9552195435034 := by decide
theorem cert_e756102412826 : check e756102412826 [] .sourceHead = true := by decide
def e756102422554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756102422554 : Closed e756102422554 ∧ code e756102422554 = 9552195444762 := by decide
theorem cert_e756102422554 : check e756102422554 [] .sourceHead = true := by decide
def e756102422646 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756102422646 : Closed e756102422646 ∧ code e756102422646 = 9552195444854 := by decide
theorem cert_e756102422646 : check e756102422646 [] .sourceHead = true := by decide
def e756102422890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756102422890 : Closed e756102422890 ∧ code e756102422890 = 9552195445098 := by decide
theorem cert_e756102422890 : check e756102422890 [] .sourceHead = true := by decide
def e756102422938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756102422938 : Closed e756102422938 ∧ code e756102422938 = 9552195445146 := by decide
theorem cert_e756102422938 : check e756102422938 [] .sourceHead = true := by decide
def e756102424090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102424090 : Closed e756102424090 ∧ code e756102424090 = 9552195446298 := by decide
theorem cert_e756102424090 : check e756102424090 [] .sourceHead = true := by decide
def e756102524442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102524442 : Closed e756102524442 ∧ code e756102524442 = 9552195546650 := by decide
theorem cert_e756102524442 : check e756102524442 [] .sourceHead = true := by decide
def e756102526490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102526490 : Closed e756102526490 ∧ code e756102526490 = 9552195548698 := by decide
theorem cert_e756102526490 : check e756102526490 [] .sourceHead = true := by decide
def e756102573594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102573594 : Closed e756102573594 ∧ code e756102573594 = 9552195595802 := by decide
theorem cert_e756102573594 : check e756102573594 [] .sourceHead = true := by decide
def e756102576666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102576666 : Closed e756102576666 ∧ code e756102576666 = 9552195598874 := by decide
theorem cert_e756102576666 : check e756102576666 [] .sourceHead = true := by decide
def e756102588954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102588954 : Closed e756102588954 ∧ code e756102588954 = 9552195611162 := by decide
theorem cert_e756102588954 : check e756102588954 [] .sourceHead = true := by decide
def e756102622746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102622746 : Closed e756102622746 ∧ code e756102622746 = 9552195644954 := by decide
theorem cert_e756102622746 : check e756102622746 [] .sourceHead = true := by decide
def e756102625818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102625818 : Closed e756102625818 ∧ code e756102625818 = 9552195648026 := by decide
theorem cert_e756102625818 : check e756102625818 [] .sourceHead = true := by decide
def e756102651930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756102651930 : Closed e756102651930 ∧ code e756102651930 = 9552195674138 := by decide
theorem cert_e756102651930 : check e756102651930 [] .sourceHead = true := by decide
def e756102652022 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756102652022 : Closed e756102652022 ∧ code e756102652022 = 9552195674230 := by decide
theorem cert_e756102652022 : check e756102652022 [] .sourceHead = true := by decide
def e756102652266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756102652266 : Closed e756102652266 ∧ code e756102652266 = 9552195674474 := by decide
theorem cert_e756102652266 : check e756102652266 [] .sourceHead = true := by decide
def e756102652314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756102652314 : Closed e756102652314 ∧ code e756102652314 = 9552195674522 := by decide
theorem cert_e756102652314 : check e756102652314 [] .sourceHead = true := by decide
def e756102653466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102653466 : Closed e756102653466 ∧ code e756102653466 = 9552195675674 := by decide
theorem cert_e756102653466 : check e756102653466 [] .sourceHead = true := by decide
def e756102667802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102667802 : Closed e756102667802 ∧ code e756102667802 = 9552195690010 := by decide
theorem cert_e756102667802 : check e756102667802 [] .sourceHead = true := by decide
def e756102688966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756102688966 : Closed e756102688966 ∧ code e756102688966 = 9552195711174 := by decide
theorem cert_e756102688966 : check e756102688966 [] .sourceHead = true := by decide
def e756102696474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102696474 : Closed e756102696474 ∧ code e756102696474 = 9552195718682 := by decide
theorem cert_e756102696474 : check e756102696474 [] .sourceHead = true := by decide
def e756102699546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102699546 : Closed e756102699546 ∧ code e756102699546 = 9552195721754 := by decide
theorem cert_e756102699546 : check e756102699546 [] .sourceHead = true := by decide
def e756102701082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756102701082 : Closed e756102701082 ∧ code e756102701082 = 9552195723290 := by decide
theorem cert_e756102701082 : check e756102701082 [] .sourceHead = true := by decide
def e756102701174 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756102701174 : Closed e756102701174 ∧ code e756102701174 = 9552195723382 := by decide
theorem cert_e756102701174 : check e756102701174 [] .sourceHead = true := by decide
def e756102701418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756102701418 : Closed e756102701418 ∧ code e756102701418 = 9552195723626 := by decide
theorem cert_e756102701418 : check e756102701418 [] .sourceHead = true := by decide
def e756102701466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756102701466 : Closed e756102701466 ∧ code e756102701466 = 9552195723674 := by decide
theorem cert_e756102701466 : check e756102701466 [] .sourceHead = true := by decide
def e756102702618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102702618 : Closed e756102702618 ∧ code e756102702618 = 9552195724826 := by decide
theorem cert_e756102702618 : check e756102702618 [] .sourceHead = true := by decide
def e756102705350 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756102705350 : Closed e756102705350 ∧ code e756102705350 = 9552195727558 := by decide
theorem cert_e756102705350 : check e756102705350 [] .sourceHead = true := by decide
def e756102707226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102707226 : Closed e756102707226 ∧ code e756102707226 = 9552195729434 := by decide
theorem cert_e756102707226 : check e756102707226 [] .sourceHead = true := by decide
def e756102755866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102755866 : Closed e756102755866 ∧ code e756102755866 = 9552195778074 := by decide
theorem cert_e756102755866 : check e756102755866 [] .sourceHead = true := by decide
def e756102780442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102780442 : Closed e756102780442 ∧ code e756102780442 = 9552195802650 := by decide
theorem cert_e756102780442 : check e756102780442 [] .sourceHead = true := by decide
def e756102781466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102781466 : Closed e756102781466 ∧ code e756102781466 = 9552195803674 := by decide
theorem cert_e756102781466 : check e756102781466 [] .sourceHead = true := by decide
def e756102785562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102785562 : Closed e756102785562 ∧ code e756102785562 = 9552195807770 := by decide
theorem cert_e756102785562 : check e756102785562 [] .sourceHead = true := by decide
def e756102805018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102805018 : Closed e756102805018 ∧ code e756102805018 = 9552195827226 := by decide
theorem cert_e756102805018 : check e756102805018 [] .sourceHead = true := by decide
def e756102806042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102806042 : Closed e756102806042 ∧ code e756102806042 = 9552195828250 := by decide
theorem cert_e756102806042 : check e756102806042 [] .sourceHead = true := by decide
def e756102815770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756102815770 : Closed e756102815770 ∧ code e756102815770 = 9552195837978 := by decide
theorem cert_e756102815770 : check e756102815770 [] .sourceHead = true := by decide
def e756102815862 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756102815862 : Closed e756102815862 ∧ code e756102815862 = 9552195838070 := by decide
theorem cert_e756102815862 : check e756102815862 [] .sourceHead = true := by decide
def e756102816106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756102816106 : Closed e756102816106 ∧ code e756102816106 = 9552195838314 := by decide
theorem cert_e756102816106 : check e756102816106 [] .sourceHead = true := by decide
def e756102816154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756102816154 : Closed e756102816154 ∧ code e756102816154 = 9552195838362 := by decide
theorem cert_e756102816154 : check e756102816154 [] .sourceHead = true := by decide
def e756102817306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102817306 : Closed e756102817306 ∧ code e756102817306 = 9552195839514 := by decide
theorem cert_e756102817306 : check e756102817306 [] .sourceHead = true := by decide
def e756102827546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102827546 : Closed e756102827546 ∧ code e756102827546 = 9552195849754 := by decide
theorem cert_e756102827546 : check e756102827546 [] .sourceHead = true := by decide
def e756102830618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756102830618 : Closed e756102830618 ∧ code e756102830618 = 9552195852826 := by decide
theorem cert_e756102830618 : check e756102830618 [] .sourceHead = true := by decide
def e756102832154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756102832154 : Closed e756102832154 ∧ code e756102832154 = 9552195854362 := by decide
theorem cert_e756102832154 : check e756102832154 [] .sourceHead = true := by decide
def e756102832246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756102832246 : Closed e756102832246 ∧ code e756102832246 = 9552195854454 := by decide
theorem cert_e756102832246 : check e756102832246 [] .sourceHead = true := by decide
def e756102832490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756102832490 : Closed e756102832490 ∧ code e756102832490 = 9552195854698 := by decide
theorem cert_e756102832490 : check e756102832490 [] .sourceHead = true := by decide
def e756102832538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756102832538 : Closed e756102832538 ∧ code e756102832538 = 9552195854746 := by decide
theorem cert_e756102832538 : check e756102832538 [] .sourceHead = true := by decide
def e756102833690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102833690 : Closed e756102833690 ∧ code e756102833690 = 9552195855898 := by decide
theorem cert_e756102833690 : check e756102833690 [] .sourceHead = true := by decide
def e756102836422 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756102836422 : Closed e756102836422 ∧ code e756102836422 = 9552195858630 := by decide
theorem cert_e756102836422 : check e756102836422 [] .sourceHead = true := by decide
def e756102838298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102838298 : Closed e756102838298 ∧ code e756102838298 = 9552195860506 := by decide
theorem cert_e756102838298 : check e756102838298 [] .sourceHead = true := by decide
end Blc.Floor43
