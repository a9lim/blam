import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405914543630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405914543630 : Closed e2405914543630 ∧ code e2405914543630 = 11202007565838 := by decide
theorem cert_e2405914543630 : check e2405914543630 [[]] .width = true := by decide
def e2405914543642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405914543642 : Closed e2405914543642 ∧ code e2405914543642 = 11202007565850 := by decide
theorem cert_e2405914543642 : check e2405914543642 [[]] .width = true := by decide
def e2405914543714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405914543714 : Closed e2405914543714 ∧ code e2405914543714 = 11202007565922 := by decide
theorem cert_e2405914543714 : check e2405914543714 [[]] .width = true := by decide
def e2405914558662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405914558662 : Closed e2405914558662 ∧ code e2405914558662 = 11202007580870 := by decide
theorem cert_e2405914558662 : check e2405914558662 [[]] .width = true := by decide
def e2405914566682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405914566682 : Closed e2405914566682 ∧ code e2405914566682 = 11202007588890 := by decide
theorem cert_e2405914566682 : check e2405914566682 [[]] .width = true := by decide
def e2405914566774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405914566774 : Closed e2405914566774 ∧ code e2405914566774 = 11202007588982 := by decide
theorem cert_e2405914566774 : check e2405914566774 [[]] .width = true := by decide
def e2405914567018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405914567018 : Closed e2405914567018 ∧ code e2405914567018 = 11202007589226 := by decide
theorem cert_e2405914567018 : check e2405914567018 [[]] .width = true := by decide
def e2405914567066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405914567066 : Closed e2405914567066 ∧ code e2405914567066 = 11202007589274 := by decide
theorem cert_e2405914567066 : check e2405914567066 [[]] .width = true := by decide
def e2405914753050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914753050 : Closed e2405914753050 ∧ code e2405914753050 = 11202007775258 := by decide
theorem cert_e2405914753050 : check e2405914753050 [[]] .width = true := by decide
def e2405915017414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405915017414 : Closed e2405915017414 ∧ code e2405915017414 = 11202008039622 := by decide
theorem cert_e2405915017414 : check e2405915017414 [[]] .width = true := by decide
def e2405915105306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915105306 : Closed e2405915105306 ∧ code e2405915105306 = 11202008127514 := by decide
theorem cert_e2405915105306 : check e2405915105306 [[]] .width = true := by decide
def e2405915115718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405915115718 : Closed e2405915115718 ∧ code e2405915115718 = 11202008137926 := by decide
theorem cert_e2405915115718 : check e2405915115718 [[]] .width = true := by decide
def e2405915174938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915174938 : Closed e2405915174938 ∧ code e2405915174938 = 11202008197146 := by decide
theorem cert_e2405915174938 : check e2405915174938 [[]] .width = true := by decide
def e2405915205658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405915205658 : Closed e2405915205658 ∧ code e2405915205658 = 11202008227866 := by decide
theorem cert_e2405915205658 : check e2405915205658 [[]] .width = true := by decide
def e2405915205750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405915205750 : Closed e2405915205750 ∧ code e2405915205750 = 11202008227958 := by decide
private def t_e2405915205750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405915205750 : ¬ IsSelfInterpreter e2405915205750 :=
  wSource (t := t_e2405915205750) (replay_sound (ps := []) (t := e2405915205750) (by decide)) (by decide)
def e2405915205994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405915205994 : Closed e2405915205994 ∧ code e2405915205994 = 11202008228202 := by decide
private def t_e2405915205994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405915205994 : ¬ IsSelfInterpreter e2405915205994 :=
  wSource (t := t_e2405915205994) (replay_sound (ps := []) (t := e2405915205994) (by decide)) (by decide)
def e2405915206042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405915206042 : Closed e2405915206042 ∧ code e2405915206042 = 11202008228250 := by decide
private def t_e2405915206042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405915206042 : ¬ IsSelfInterpreter e2405915206042 :=
  wSource (t := t_e2405915206042) (replay_sound (ps := []) (t := e2405915206042) (by decide)) (by decide)
def e2405915218118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405915218118 : Closed e2405915218118 ∧ code e2405915218118 = 11202008240326 := by decide
theorem cert_e2405915218118 : check e2405915218118 [[]] .width = true := by decide
def e2405915219994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915219994 : Closed e2405915219994 ∧ code e2405915219994 = 11202008242202 := by decide
theorem cert_e2405915219994 : check e2405915219994 [[]] .width = true := by decide
def e2405915224090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915224090 : Closed e2405915224090 ∧ code e2405915224090 = 11202008246298 := by decide
theorem cert_e2405915224090 : check e2405915224090 [[]] .width = true := by decide
def e2405915273242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915273242 : Closed e2405915273242 ∧ code e2405915273242 = 11202008295450 := by decide
theorem cert_e2405915273242 : check e2405915273242 [[]] .width = true := by decide
def e2405915274778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405915274778 : Closed e2405915274778 ∧ code e2405915274778 = 11202008296986 := by decide
private def t_e2405915274778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405915274778 : ¬ IsSelfInterpreter e2405915274778 :=
  wSource (t := t_e2405915274778) (replay_sound (ps := []) (t := e2405915274778) (by decide)) (by decide)
def e2405915277850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405915277850 : Closed e2405915277850 ∧ code e2405915277850 = 11202008300058 := by decide
private def t_e2405915277850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405915277850 : ¬ IsSelfInterpreter e2405915277850 :=
  wSource (t := t_e2405915277850) (replay_sound (ps := []) (t := e2405915277850) (by decide)) (by decide)
def e2405915290138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405915290138 : Closed e2405915290138 ∧ code e2405915290138 = 11202008312346 := by decide
private def t_e2405915290138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405915290138 : ¬ IsSelfInterpreter e2405915290138 :=
  wSource (t := t_e2405915290138) (replay_sound (ps := []) (t := e2405915290138) (by decide)) (by decide)
def e2405915297818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915297818 : Closed e2405915297818 ∧ code e2405915297818 = 11202008320026 := by decide
theorem cert_e2405915297818 : check e2405915297818 [[]] .width = true := by decide
def e2405915303962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405915303962 : Closed e2405915303962 ∧ code e2405915303962 = 11202008326170 := by decide
theorem cert_e2405915303962 : check e2405915303962 [[]] .width = true := by decide
def e2405915304054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405915304054 : Closed e2405915304054 ∧ code e2405915304054 = 11202008326262 := by decide
private def t_e2405915304054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405915304054 : ¬ IsSelfInterpreter e2405915304054 :=
  wSource (t := t_e2405915304054) (replay_sound (ps := []) (t := e2405915304054) (by decide)) (by decide)
def e2405915304298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405915304298 : Closed e2405915304298 ∧ code e2405915304298 = 11202008326506 := by decide
private def t_e2405915304298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405915304298 : ¬ IsSelfInterpreter e2405915304298 :=
  wSource (t := t_e2405915304298) (replay_sound (ps := []) (t := e2405915304298) (by decide)) (by decide)
def e2405915304346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405915304346 : Closed e2405915304346 ∧ code e2405915304346 = 11202008326554 := by decide
private def t_e2405915304346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405915304346 : ¬ IsSelfInterpreter e2405915304346 :=
  wSource (t := t_e2405915304346) (replay_sound (ps := []) (t := e2405915304346) (by decide)) (by decide)
def e2405915308230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405915308230 : Closed e2405915308230 ∧ code e2405915308230 = 11202008330438 := by decide
theorem cert_e2405915308230 : check e2405915308230 [[]] .width = true := by decide
def e2405915310106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915310106 : Closed e2405915310106 ∧ code e2405915310106 = 11202008332314 := by decide
theorem cert_e2405915310106 : check e2405915310106 [[]] .width = true := by decide
def e2405915322394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915322394 : Closed e2405915322394 ∧ code e2405915322394 = 11202008344602 := by decide
theorem cert_e2405915322394 : check e2405915322394 [[]] .width = true := by decide
def e2405915323930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405915323930 : Closed e2405915323930 ∧ code e2405915323930 = 11202008346138 := by decide
private def t_e2405915323930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405915323930 : ¬ IsSelfInterpreter e2405915323930 :=
  wSource (t := t_e2405915323930) (replay_sound (ps := []) (t := e2405915323930) (by decide)) (by decide)
def e2405915327002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405915327002 : Closed e2405915327002 ∧ code e2405915327002 = 11202008349210 := by decide
private def t_e2405915327002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405915327002 : ¬ IsSelfInterpreter e2405915327002 :=
  wSource (t := t_e2405915327002) (replay_sound (ps := []) (t := e2405915327002) (by decide)) (by decide)
def e2405915328538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405915328538 : Closed e2405915328538 ∧ code e2405915328538 = 11202008350746 := by decide
theorem cert_e2405915328538 : check e2405915328538 [[]] .width = true := by decide
def e2405915328630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405915328630 : Closed e2405915328630 ∧ code e2405915328630 = 11202008350838 := by decide
theorem cert_e2405915328630 : check e2405915328630 [[]] .width = true := by decide
def e2405915328874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405915328874 : Closed e2405915328874 ∧ code e2405915328874 = 11202008351082 := by decide
theorem cert_e2405915328874 : check e2405915328874 [[]] .width = true := by decide
def e2405915328922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405915328922 : Closed e2405915328922 ∧ code e2405915328922 = 11202008351130 := by decide
theorem cert_e2405915328922 : check e2405915328922 [[]] .width = true := by decide
def e2405915329930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405915329930 : Closed e2405915329930 ∧ code e2405915329930 = 11202008352138 := by decide
theorem cert_e2405915329930 : check e2405915329930 [[]] .width = true := by decide
def e2405915329954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405915329954 : Closed e2405915329954 ∧ code e2405915329954 = 11202008352162 := by decide
private def t_e2405915329954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405915329954 : ¬ IsSelfInterpreter e2405915329954 :=
  wSource (t := t_e2405915329954) (replay_sound (ps := []) (t := e2405915329954) (by decide)) (by decide)
def e2405915330062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405915330062 : Closed e2405915330062 ∧ code e2405915330062 = 11202008352270 := by decide
theorem cert_e2405915330062 : check e2405915330062 [[]] .width = true := by decide
def e2405915330074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405915330074 : Closed e2405915330074 ∧ code e2405915330074 = 11202008352282 := by decide
private def t_e2405915330074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405915330074 : ¬ IsSelfInterpreter e2405915330074 :=
  wSource (t := t_e2405915330074) (replay_sound (ps := []) (t := e2405915330074) (by decide)) (by decide)
def e2405915330146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405915330146 : Closed e2405915330146 ∧ code e2405915330146 = 11202008352354 := by decide
theorem cert_e2405915330146 : check e2405915330146 [[]] .width = true := by decide
def e2405915345094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405915345094 : Closed e2405915345094 ∧ code e2405915345094 = 11202008367302 := by decide
theorem cert_e2405915345094 : check e2405915345094 [[]] .width = true := by decide
def e2405915353114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405915353114 : Closed e2405915353114 ∧ code e2405915353114 = 11202008375322 := by decide
theorem cert_e2405915353114 : check e2405915353114 [[]] .width = true := by decide
def e2405915353206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405915353206 : Closed e2405915353206 ∧ code e2405915353206 = 11202008375414 := by decide
private def t_e2405915353206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405915353206 : ¬ IsSelfInterpreter e2405915353206 :=
  wSource (t := t_e2405915353206) (replay_sound (ps := []) (t := e2405915353206) (by decide)) (by decide)
def e2405915353450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405915353450 : Closed e2405915353450 ∧ code e2405915353450 = 11202008375658 := by decide
private def t_e2405915353450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405915353450 : ¬ IsSelfInterpreter e2405915353450 :=
  wSource (t := t_e2405915353450) (replay_sound (ps := []) (t := e2405915353450) (by decide)) (by decide)
def e2405915353498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405915353498 : Closed e2405915353498 ∧ code e2405915353498 = 11202008375706 := by decide
private def t_e2405915353498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405915353498 : ¬ IsSelfInterpreter e2405915353498 :=
  wSource (t := t_e2405915353498) (replay_sound (ps := []) (t := e2405915353498) (by decide)) (by decide)
def e2405915367450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915367450 : Closed e2405915367450 ∧ code e2405915367450 = 11202008389658 := by decide
theorem cert_e2405915367450 : check e2405915367450 [[]] .width = true := by decide
def e2405915377862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405915377862 : Closed e2405915377862 ∧ code e2405915377862 = 11202008400070 := by decide
theorem cert_e2405915377862 : check e2405915377862 [[]] .width = true := by decide
def e2405915400730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405915400730 : Closed e2405915400730 ∧ code e2405915400730 = 11202008422938 := by decide
private def t_e2405915400730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405915400730 : ¬ IsSelfInterpreter e2405915400730 :=
  wSource (t := t_e2405915400730) (replay_sound (ps := []) (t := e2405915400730) (by decide)) (by decide)
def e2405915402266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405915402266 : Closed e2405915402266 ∧ code e2405915402266 = 11202008424474 := by decide
theorem cert_e2405915402266 : check e2405915402266 [[]] .width = true := by decide
def e2405915402358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405915402358 : Closed e2405915402358 ∧ code e2405915402358 = 11202008424566 := by decide
private def t_e2405915402358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405915402358 : ¬ IsSelfInterpreter e2405915402358 :=
  wSource (t := t_e2405915402358) (replay_sound (ps := []) (t := e2405915402358) (by decide)) (by decide)
def e2405915402602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405915402602 : Closed e2405915402602 ∧ code e2405915402602 = 11202008424810 := by decide
private def t_e2405915402602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405915402602 : ¬ IsSelfInterpreter e2405915402602 :=
  wSource (t := t_e2405915402602) (replay_sound (ps := []) (t := e2405915402602) (by decide)) (by decide)
def e2405915402650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405915402650 : Closed e2405915402650 ∧ code e2405915402650 = 11202008424858 := by decide
private def t_e2405915402650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405915402650 : ¬ IsSelfInterpreter e2405915402650 :=
  wSource (t := t_e2405915402650) (replay_sound (ps := []) (t := e2405915402650) (by decide)) (by decide)
def e2405915777050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915777050 : Closed e2405915777050 ∧ code e2405915777050 = 11202008799258 := by decide
theorem cert_e2405915777050 : check e2405915777050 [[]] .width = true := by decide
def e2405915781146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405915781146 : Closed e2405915781146 ∧ code e2405915781146 = 11202008803354 := by decide
theorem cert_e2405915781146 : check e2405915781146 [[]] .width = true := by decide
def e2405916041242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405916041242 : Closed e2405916041242 ∧ code e2405916041242 = 11202009063450 := by decide
theorem cert_e2405916041242 : check e2405916041242 [[]] .width = true := by decide
def e2405916041334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405916041334 : Closed e2405916041334 ∧ code e2405916041334 = 11202009063542 := by decide
theorem cert_e2405916041334 : check e2405916041334 [[]] .width = true := by decide
def e2405916041578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405916041578 : Closed e2405916041578 ∧ code e2405916041578 = 11202009063786 := by decide
theorem cert_e2405916041578 : check e2405916041578 [[]] .width = true := by decide
def e2405916041626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405916041626 : Closed e2405916041626 ∧ code e2405916041626 = 11202009063834 := by decide
theorem cert_e2405916041626 : check e2405916041626 [[]] .width = true := by decide
def e2405916057626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405916057626 : Closed e2405916057626 ∧ code e2405916057626 = 11202009079834 := by decide
theorem cert_e2405916057626 : check e2405916057626 [[]] .width = true := by decide
def e2405916057718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405916057718 : Closed e2405916057718 ∧ code e2405916057718 = 11202009079926 := by decide
theorem cert_e2405916057718 : check e2405916057718 [[]] .width = true := by decide
def e2405916057962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405916057962 : Closed e2405916057962 ∧ code e2405916057962 = 11202009080170 := by decide
theorem cert_e2405916057962 : check e2405916057962 [[]] .width = true := by decide
def e2405916058010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405916058010 : Closed e2405916058010 ∧ code e2405916058010 = 11202009080218 := by decide
theorem cert_e2405916058010 : check e2405916058010 [[]] .width = true := by decide
def e2405916127430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405916127430 : Closed e2405916127430 ∧ code e2405916127430 = 11202009149638 := by decide
theorem cert_e2405916127430 : check e2405916127430 [[]] .width = true := by decide
def e2405916135622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405916135622 : Closed e2405916135622 ∧ code e2405916135622 = 11202009157830 := by decide
theorem cert_e2405916135622 : check e2405916135622 [[]] .width = true := by decide
def e2405916137498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916137498 : Closed e2405916137498 ∧ code e2405916137498 = 11202009159706 := by decide
theorem cert_e2405916137498 : check e2405916137498 [[]] .width = true := by decide
def e2405916168390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405916168390 : Closed e2405916168390 ∧ code e2405916168390 = 11202009190598 := by decide
theorem cert_e2405916168390 : check e2405916168390 [[]] .width = true := by decide
def e2405916170266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916170266 : Closed e2405916170266 ∧ code e2405916170266 = 11202009192474 := by decide
theorem cert_e2405916170266 : check e2405916170266 [[]] .width = true := by decide
def e2405916174362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916174362 : Closed e2405916174362 ∧ code e2405916174362 = 11202009196570 := by decide
theorem cert_e2405916174362 : check e2405916174362 [[]] .width = true := by decide
def e2405916563482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916563482 : Closed e2405916563482 ∧ code e2405916563482 = 11202009585690 := by decide
theorem cert_e2405916563482 : check e2405916563482 [[]] .width = true := by decide
def e2405916567578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916567578 : Closed e2405916567578 ∧ code e2405916567578 = 11202009589786 := by decide
theorem cert_e2405916567578 : check e2405916567578 [[]] .width = true := by decide
def e2405916569114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916569114 : Closed e2405916569114 ∧ code e2405916569114 = 11202009591322 := by decide
theorem cert_e2405916569114 : check e2405916569114 [[]] .width = true := by decide
def e2405916571162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916571162 : Closed e2405916571162 ∧ code e2405916571162 = 11202009593370 := by decide
theorem cert_e2405916571162 : check e2405916571162 [[]] .width = true := by decide
def e2405916583962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916583962 : Closed e2405916583962 ∧ code e2405916583962 = 11202009606170 := by decide
theorem cert_e2405916583962 : check e2405916583962 [[]] .width = true := by decide
def e2405916585498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916585498 : Closed e2405916585498 ∧ code e2405916585498 = 11202009607706 := by decide
theorem cert_e2405916585498 : check e2405916585498 [[]] .width = true := by decide
def e2405916588570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916588570 : Closed e2405916588570 ∧ code e2405916588570 = 11202009610778 := by decide
theorem cert_e2405916588570 : check e2405916588570 [[]] .width = true := by decide
def e2405916595738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916595738 : Closed e2405916595738 ∧ code e2405916595738 = 11202009617946 := by decide
theorem cert_e2405916595738 : check e2405916595738 [[]] .width = true := by decide
def e2405916596762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916596762 : Closed e2405916596762 ∧ code e2405916596762 = 11202009618970 := by decide
theorem cert_e2405916596762 : check e2405916596762 [[]] .width = true := by decide
def e2405916649498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916649498 : Closed e2405916649498 ∧ code e2405916649498 = 11202009671706 := by decide
theorem cert_e2405916649498 : check e2405916649498 [[]] .width = true := by decide
def e2405916651034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916651034 : Closed e2405916651034 ∧ code e2405916651034 = 11202009673242 := by decide
theorem cert_e2405916651034 : check e2405916651034 [[]] .width = true := by decide
def e2405916654106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916654106 : Closed e2405916654106 ∧ code e2405916654106 = 11202009676314 := by decide
theorem cert_e2405916654106 : check e2405916654106 [[]] .width = true := by decide
def e2405916666394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916666394 : Closed e2405916666394 ∧ code e2405916666394 = 11202009688602 := by decide
private def t_e2405916666394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405916666394 : ¬ IsSelfInterpreter e2405916666394 :=
  wSource (t := t_e2405916666394) (replay_sound (ps := []) (t := e2405916666394) (by decide)) (by decide)
def e2405916694042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916694042 : Closed e2405916694042 ∧ code e2405916694042 = 11202009716250 := by decide
theorem cert_e2405916694042 : check e2405916694042 [[]] .width = true := by decide
def e2405916695066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916695066 : Closed e2405916695066 ∧ code e2405916695066 = 11202009717274 := by decide
theorem cert_e2405916695066 : check e2405916695066 [[]] .width = true := by decide
def e2405916699162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916699162 : Closed e2405916699162 ∧ code e2405916699162 = 11202009721370 := by decide
private def t_e2405916699162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405916699162 : ¬ IsSelfInterpreter e2405916699162 :=
  wSource (t := t_e2405916699162) (replay_sound (ps := []) (t := e2405916699162) (by decide)) (by decide)
def e2405916760090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916760090 : Closed e2405916760090 ∧ code e2405916760090 = 11202009782298 := by decide
theorem cert_e2405916760090 : check e2405916760090 [[]] .width = true := by decide
def e2405916827674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405916827674 : Closed e2405916827674 ∧ code e2405916827674 = 11202009849882 := by decide
theorem cert_e2405916827674 : check e2405916827674 [[]] .width = true := by decide
def e2405916827766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405916827766 : Closed e2405916827766 ∧ code e2405916827766 = 11202009849974 := by decide
theorem cert_e2405916827766 : check e2405916827766 [[]] .width = true := by decide
def e2405916828010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405916828010 : Closed e2405916828010 ∧ code e2405916828010 = 11202009850218 := by decide
theorem cert_e2405916828010 : check e2405916828010 [[]] .width = true := by decide
def e2405916828058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405916828058 : Closed e2405916828058 ∧ code e2405916828058 = 11202009850266 := by decide
theorem cert_e2405916828058 : check e2405916828058 [[]] .width = true := by decide
def e2405916848326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405916848326 : Closed e2405916848326 ∧ code e2405916848326 = 11202009870534 := by decide
theorem cert_e2405916848326 : check e2405916848326 [[]] .width = true := by decide
def e2405916856518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405916856518 : Closed e2405916856518 ∧ code e2405916856518 = 11202009878726 := by decide
theorem cert_e2405916856518 : check e2405916856518 [[]] .width = true := by decide
def e2405916858394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916858394 : Closed e2405916858394 ∧ code e2405916858394 = 11202009880602 := by decide
theorem cert_e2405916858394 : check e2405916858394 [[]] .width = true := by decide
def e2405916956698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916956698 : Closed e2405916956698 ∧ code e2405916956698 = 11202009978906 := by decide
theorem cert_e2405916956698 : check e2405916956698 [[]] .width = true := by decide
def e2405916960794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916960794 : Closed e2405916960794 ∧ code e2405916960794 = 11202009983002 := by decide
theorem cert_e2405916960794 : check e2405916960794 [[]] .width = true := by decide
def e2405916962330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916962330 : Closed e2405916962330 ∧ code e2405916962330 = 11202009984538 := by decide
theorem cert_e2405916962330 : check e2405916962330 [[]] .width = true := by decide
def e2405916964378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916964378 : Closed e2405916964378 ∧ code e2405916964378 = 11202009986586 := by decide
theorem cert_e2405916964378 : check e2405916964378 [[]] .width = true := by decide
def e2405916977178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405916977178 : Closed e2405916977178 ∧ code e2405916977178 = 11202009999386 := by decide
theorem cert_e2405916977178 : check e2405916977178 [[]] .width = true := by decide
def e2405916978714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916978714 : Closed e2405916978714 ∧ code e2405916978714 = 11202010000922 := by decide
theorem cert_e2405916978714 : check e2405916978714 [[]] .width = true := by decide
def e2405916981786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916981786 : Closed e2405916981786 ∧ code e2405916981786 = 11202010003994 := by decide
theorem cert_e2405916981786 : check e2405916981786 [[]] .width = true := by decide
def e2405916988954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916988954 : Closed e2405916988954 ∧ code e2405916988954 = 11202010011162 := by decide
theorem cert_e2405916988954 : check e2405916988954 [[]] .width = true := by decide
def e2405916989978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405916989978 : Closed e2405916989978 ∧ code e2405916989978 = 11202010012186 := by decide
theorem cert_e2405916989978 : check e2405916989978 [[]] .width = true := by decide
def e2405917028550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405917028550 : Closed e2405917028550 ∧ code e2405917028550 = 11202010050758 := by decide
theorem cert_e2405917028550 : check e2405917028550 [[]] .width = true := by decide
def e2405917055002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917055002 : Closed e2405917055002 ∧ code e2405917055002 = 11202010077210 := by decide
theorem cert_e2405917055002 : check e2405917055002 [[]] .width = true := by decide
def e2405917059098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917059098 : Closed e2405917059098 ∧ code e2405917059098 = 11202010081306 := by decide
theorem cert_e2405917059098 : check e2405917059098 [[]] .width = true := by decide
def e2405917060634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917060634 : Closed e2405917060634 ∧ code e2405917060634 = 11202010082842 := by decide
theorem cert_e2405917060634 : check e2405917060634 [[]] .width = true := by decide
def e2405917062682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917062682 : Closed e2405917062682 ∧ code e2405917062682 = 11202010084890 := by decide
theorem cert_e2405917062682 : check e2405917062682 [[]] .width = true := by decide
def e2405917098010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405917098010 : Closed e2405917098010 ∧ code e2405917098010 = 11202010120218 := by decide
theorem cert_e2405917098010 : check e2405917098010 [[]] .width = true := by decide
def e2405917098102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405917098102 : Closed e2405917098102 ∧ code e2405917098102 = 11202010120310 := by decide
theorem cert_e2405917098102 : check e2405917098102 [[]] .width = true := by decide
def e2405917098346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405917098346 : Closed e2405917098346 ∧ code e2405917098346 = 11202010120554 := by decide
theorem cert_e2405917098346 : check e2405917098346 [[]] .width = true := by decide
def e2405917098394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405917098394 : Closed e2405917098394 ∧ code e2405917098394 = 11202010120602 := by decide
theorem cert_e2405917098394 : check e2405917098394 [[]] .width = true := by decide
def e2405917099402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405917099402 : Closed e2405917099402 ∧ code e2405917099402 = 11202010121610 := by decide
theorem cert_e2405917099402 : check e2405917099402 [[]] .width = true := by decide
def e2405917099426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405917099426 : Closed e2405917099426 ∧ code e2405917099426 = 11202010121634 := by decide
theorem cert_e2405917099426 : check e2405917099426 [[]] .width = true := by decide
def e2405917099534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405917099534 : Closed e2405917099534 ∧ code e2405917099534 = 11202010121742 := by decide
theorem cert_e2405917099534 : check e2405917099534 [[]] .width = true := by decide
def e2405917099546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917099546 : Closed e2405917099546 ∧ code e2405917099546 = 11202010121754 := by decide
theorem cert_e2405917099546 : check e2405917099546 [[]] .width = true := by decide
def e2405917099618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405917099618 : Closed e2405917099618 ∧ code e2405917099618 = 11202010121826 := by decide
theorem cert_e2405917099618 : check e2405917099618 [[]] .width = true := by decide
def e2405917132826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917132826 : Closed e2405917132826 ∧ code e2405917132826 = 11202010155034 := by decide
theorem cert_e2405917132826 : check e2405917132826 [[]] .width = true := by decide
def e2405917138970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917138970 : Closed e2405917138970 ∧ code e2405917138970 = 11202010161178 := by decide
theorem cert_e2405917138970 : check e2405917138970 [[]] .width = true := by decide
def e2405917139062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917139062 : Closed e2405917139062 ∧ code e2405917139062 = 11202010161270 := by decide
theorem cert_e2405917139062 : check e2405917139062 [[]] .width = true := by decide
def e2405917139306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917139306 : Closed e2405917139306 ∧ code e2405917139306 = 11202010161514 := by decide
theorem cert_e2405917139306 : check e2405917139306 [[]] .width = true := by decide
def e2405917139354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917139354 : Closed e2405917139354 ∧ code e2405917139354 = 11202010161562 := by decide
theorem cert_e2405917139354 : check e2405917139354 [[]] .width = true := by decide
def e2405917143238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405917143238 : Closed e2405917143238 ∧ code e2405917143238 = 11202010165446 := by decide
theorem cert_e2405917143238 : check e2405917143238 [[]] .width = true := by decide
def e2405917145114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917145114 : Closed e2405917145114 ∧ code e2405917145114 = 11202010167322 := by decide
theorem cert_e2405917145114 : check e2405917145114 [[]] .width = true := by decide
def e2405917157402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917157402 : Closed e2405917157402 ∧ code e2405917157402 = 11202010179610 := by decide
theorem cert_e2405917157402 : check e2405917157402 [[]] .width = true := by decide
def e2405917158938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917158938 : Closed e2405917158938 ∧ code e2405917158938 = 11202010181146 := by decide
theorem cert_e2405917158938 : check e2405917158938 [[]] .width = true := by decide
def e2405917162010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917162010 : Closed e2405917162010 ∧ code e2405917162010 = 11202010184218 := by decide
theorem cert_e2405917162010 : check e2405917162010 [[]] .width = true := by decide
def e2405917163546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405917163546 : Closed e2405917163546 ∧ code e2405917163546 = 11202010185754 := by decide
theorem cert_e2405917163546 : check e2405917163546 [[]] .width = true := by decide
def e2405917163638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405917163638 : Closed e2405917163638 ∧ code e2405917163638 = 11202010185846 := by decide
theorem cert_e2405917163638 : check e2405917163638 [[]] .width = true := by decide
def e2405917163882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405917163882 : Closed e2405917163882 ∧ code e2405917163882 = 11202010186090 := by decide
theorem cert_e2405917163882 : check e2405917163882 [[]] .width = true := by decide
def e2405917163930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405917163930 : Closed e2405917163930 ∧ code e2405917163930 = 11202010186138 := by decide
theorem cert_e2405917163930 : check e2405917163930 [[]] .width = true := by decide
def e2405917164938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405917164938 : Closed e2405917164938 ∧ code e2405917164938 = 11202010187146 := by decide
theorem cert_e2405917164938 : check e2405917164938 [[]] .width = true := by decide
def e2405917164962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405917164962 : Closed e2405917164962 ∧ code e2405917164962 = 11202010187170 := by decide
theorem cert_e2405917164962 : check e2405917164962 [[]] .width = true := by decide
def e2405917165070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405917165070 : Closed e2405917165070 ∧ code e2405917165070 = 11202010187278 := by decide
theorem cert_e2405917165070 : check e2405917165070 [[]] .width = true := by decide
def e2405917165082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917165082 : Closed e2405917165082 ∧ code e2405917165082 = 11202010187290 := by decide
theorem cert_e2405917165082 : check e2405917165082 [[]] .width = true := by decide
def e2405917165154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405917165154 : Closed e2405917165154 ∧ code e2405917165154 = 11202010187362 := by decide
theorem cert_e2405917165154 : check e2405917165154 [[]] .width = true := by decide
def e2405917180102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405917180102 : Closed e2405917180102 ∧ code e2405917180102 = 11202010202310 := by decide
theorem cert_e2405917180102 : check e2405917180102 [[]] .width = true := by decide
def e2405917188122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917188122 : Closed e2405917188122 ∧ code e2405917188122 = 11202010210330 := by decide
theorem cert_e2405917188122 : check e2405917188122 [[]] .width = true := by decide
def e2405917188214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917188214 : Closed e2405917188214 ∧ code e2405917188214 = 11202010210422 := by decide
theorem cert_e2405917188214 : check e2405917188214 [[]] .width = true := by decide
def e2405917188458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917188458 : Closed e2405917188458 ∧ code e2405917188458 = 11202010210666 := by decide
theorem cert_e2405917188458 : check e2405917188458 [[]] .width = true := by decide
def e2405917188506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917188506 : Closed e2405917188506 ∧ code e2405917188506 = 11202010210714 := by decide
theorem cert_e2405917188506 : check e2405917188506 [[]] .width = true := by decide
def e2405917210138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917210138 : Closed e2405917210138 ∧ code e2405917210138 = 11202010232346 := by decide
theorem cert_e2405917210138 : check e2405917210138 [[]] .width = true := by decide
def e2405917211162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917211162 : Closed e2405917211162 ∧ code e2405917211162 = 11202010233370 := by decide
theorem cert_e2405917211162 : check e2405917211162 [[]] .width = true := by decide
def e2405917220890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917220890 : Closed e2405917220890 ∧ code e2405917220890 = 11202010243098 := by decide
theorem cert_e2405917220890 : check e2405917220890 [[]] .width = true := by decide
def e2405917220982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917220982 : Closed e2405917220982 ∧ code e2405917220982 = 11202010243190 := by decide
theorem cert_e2405917220982 : check e2405917220982 [[]] .width = true := by decide
def e2405917221226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917221226 : Closed e2405917221226 ∧ code e2405917221226 = 11202010243434 := by decide
theorem cert_e2405917221226 : check e2405917221226 [[]] .width = true := by decide
def e2405917221274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917221274 : Closed e2405917221274 ∧ code e2405917221274 = 11202010243482 := by decide
theorem cert_e2405917221274 : check e2405917221274 [[]] .width = true := by decide
def e2405917272090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917272090 : Closed e2405917272090 ∧ code e2405917272090 = 11202010294298 := by decide
theorem cert_e2405917272090 : check e2405917272090 [[]] .width = true := by decide
def e2405917302810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917302810 : Closed e2405917302810 ∧ code e2405917302810 = 11202010325018 := by decide
theorem cert_e2405917302810 : check e2405917302810 [[]] .width = true := by decide
def e2405917302902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917302902 : Closed e2405917302902 ∧ code e2405917302902 = 11202010325110 := by decide
private def t_e2405917302902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405917302902 : ¬ IsSelfInterpreter e2405917302902 :=
  wSource (t := t_e2405917302902) (replay_sound (ps := []) (t := e2405917302902) (by decide)) (by decide)
def e2405917303146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917303146 : Closed e2405917303146 ∧ code e2405917303146 = 11202010325354 := by decide
private def t_e2405917303146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405917303146 : ¬ IsSelfInterpreter e2405917303146 :=
  wSource (t := t_e2405917303146) (replay_sound (ps := []) (t := e2405917303146) (by decide)) (by decide)
def e2405917303194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917303194 : Closed e2405917303194 ∧ code e2405917303194 = 11202010325402 := by decide
private def t_e2405917303194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405917303194 : ¬ IsSelfInterpreter e2405917303194 :=
  wSource (t := t_e2405917303194) (replay_sound (ps := []) (t := e2405917303194) (by decide)) (by decide)
def e2405917315270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405917315270 : Closed e2405917315270 ∧ code e2405917315270 = 11202010337478 := by decide
theorem cert_e2405917315270 : check e2405917315270 [[]] .width = true := by decide
def e2405917317146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917317146 : Closed e2405917317146 ∧ code e2405917317146 = 11202010339354 := by decide
theorem cert_e2405917317146 : check e2405917317146 [[]] .width = true := by decide
def e2405917321242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917321242 : Closed e2405917321242 ∧ code e2405917321242 = 11202010343450 := by decide
theorem cert_e2405917321242 : check e2405917321242 [[]] .width = true := by decide
def e2405917370394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917370394 : Closed e2405917370394 ∧ code e2405917370394 = 11202010392602 := by decide
theorem cert_e2405917370394 : check e2405917370394 [[]] .width = true := by decide
def e2405917371930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917371930 : Closed e2405917371930 ∧ code e2405917371930 = 11202010394138 := by decide
private def t_e2405917371930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917371930 : ¬ IsSelfInterpreter e2405917371930 :=
  wSource (t := t_e2405917371930) (replay_sound (ps := []) (t := e2405917371930) (by decide)) (by decide)
def e2405917375002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917375002 : Closed e2405917375002 ∧ code e2405917375002 = 11202010397210 := by decide
private def t_e2405917375002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917375002 : ¬ IsSelfInterpreter e2405917375002 :=
  wSource (t := t_e2405917375002) (replay_sound (ps := []) (t := e2405917375002) (by decide)) (by decide)
def e2405917387290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917387290 : Closed e2405917387290 ∧ code e2405917387290 = 11202010409498 := by decide
private def t_e2405917387290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917387290 : ¬ IsSelfInterpreter e2405917387290 :=
  wSource (t := t_e2405917387290) (replay_sound (ps := []) (t := e2405917387290) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405915205750
#print axioms Blc.Floor43.cert_e2405915205994
#print axioms Blc.Floor43.cert_e2405915206042
#print axioms Blc.Floor43.cert_e2405915274778
#print axioms Blc.Floor43.cert_e2405915277850
#print axioms Blc.Floor43.cert_e2405915290138
#print axioms Blc.Floor43.cert_e2405915304054
#print axioms Blc.Floor43.cert_e2405915304298
#print axioms Blc.Floor43.cert_e2405915304346
#print axioms Blc.Floor43.cert_e2405915323930
#print axioms Blc.Floor43.cert_e2405915327002
#print axioms Blc.Floor43.cert_e2405915329954
#print axioms Blc.Floor43.cert_e2405915330074
#print axioms Blc.Floor43.cert_e2405915353206
#print axioms Blc.Floor43.cert_e2405915353450
#print axioms Blc.Floor43.cert_e2405915353498
#print axioms Blc.Floor43.cert_e2405915400730
#print axioms Blc.Floor43.cert_e2405915402358
#print axioms Blc.Floor43.cert_e2405915402602
#print axioms Blc.Floor43.cert_e2405915402650
#print axioms Blc.Floor43.cert_e2405916666394
#print axioms Blc.Floor43.cert_e2405916699162
#print axioms Blc.Floor43.cert_e2405917302902
#print axioms Blc.Floor43.cert_e2405917303146
#print axioms Blc.Floor43.cert_e2405917303194
#print axioms Blc.Floor43.cert_e2405917371930
#print axioms Blc.Floor43.cert_e2405917375002
#print axioms Blc.Floor43.cert_e2405917387290
