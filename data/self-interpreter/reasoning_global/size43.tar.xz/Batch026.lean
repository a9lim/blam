import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605605580398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605605580398 : Closed e605605580398 ∧ code e605605580398 = 9401698602606 := by decide
theorem cert_e605605580398 : check e605605580398 [[.under],[.under]] .three = true := by decide
def e605605580410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605605580410 : Closed e605605580410 ∧ code e605605580410 = 9401698602618 := by decide
theorem cert_e605605580410 : check e605605580410 [[.under],[.under]] .three = true := by decide
def e605605580598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605580598 : Closed e605605580598 ∧ code e605605580598 = 9401698602806 := by decide
theorem cert_e605605580598 : check e605605580598 [[.under],[.under]] .three = true := by decide
def e605605580602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605580602 : Closed e605605580602 ∧ code e605605580602 = 9401698602810 := by decide
theorem cert_e605605580602 : check e605605580602 [[.under],[.under]] .three = true := by decide
def e605606295262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e605606295262 : Closed e605606295262 ∧ code e605606295262 = 9401699317470 := by decide
theorem cert_e605606295262 : check e605606295262 [[.under],[.under]] .three = true := by decide
def e605606295286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e605606295286 : Closed e605606295286 ∧ code e605606295286 = 9401699317494 := by decide
theorem cert_e605606295286 : check e605606295286 [[.under],[.under]] .three = true := by decide
def e605606295478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e605606295478 : Closed e605606295478 ∧ code e605606295478 = 9401699317686 := by decide
theorem cert_e605606295478 : check e605606295478 [[.under],[.under]] .three = true := by decide
def e605606296286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605606296286 : Closed e605606296286 ∧ code e605606296286 = 9401699318494 := by decide
theorem cert_e605606296286 : check e605606296286 [[.under],[.under]] .three = true := by decide
def e605606296310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605606296310 : Closed e605606296310 ∧ code e605606296310 = 9401699318518 := by decide
theorem cert_e605606296310 : check e605606296310 [[.under],[.under]] .three = true := by decide
def e605606296414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605606296414 : Closed e605606296414 ∧ code e605606296414 = 9401699318622 := by decide
theorem cert_e605606296414 : check e605606296414 [[.under],[.under]] .three = true := by decide
def e605606296442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605606296442 : Closed e605606296442 ∧ code e605606296442 = 9401699318650 := by decide
theorem cert_e605606296442 : check e605606296442 [[.under],[.under]] .three = true := by decide
def e605606296534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605606296534 : Closed e605606296534 ∧ code e605606296534 = 9401699318742 := by decide
theorem cert_e605606296534 : check e605606296534 [[.under],[.under]] .three = true := by decide
def e605606296538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605606296538 : Closed e605606296538 ∧ code e605606296538 = 9401699318746 := by decide
theorem cert_e605606296538 : check e605606296538 [[.under],[.under]] .three = true := by decide
def e605606297270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605606297270 : Closed e605606297270 ∧ code e605606297270 = 9401699319478 := by decide
theorem cert_e605606297270 : check e605606297270 [[.under],[.under]] .three = true := by decide
def e605606297302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605606297302 : Closed e605606297302 ∧ code e605606297302 = 9401699319510 := by decide
theorem cert_e605606297302 : check e605606297302 [[.under],[.under]] .three = true := by decide
def e605606297306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605606297306 : Closed e605606297306 ∧ code e605606297306 = 9401699319514 := by decide
theorem cert_e605606297306 : check e605606297306 [[.under],[.under]] .three = true := by decide
def e605606301406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e605606301406 : Closed e605606301406 ∧ code e605606301406 = 9401699323614 := by decide
theorem cert_e605606301406 : check e605606301406 [[.under],[.under]] .three = true := by decide
def e605606301430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e605606301430 : Closed e605606301430 ∧ code e605606301430 = 9401699323638 := by decide
theorem cert_e605606301430 : check e605606301430 [[.under],[.under]] .three = true := by decide
def e605606301622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e605606301622 : Closed e605606301622 ∧ code e605606301622 = 9401699323830 := by decide
theorem cert_e605606301622 : check e605606301622 [[.under],[.under]] .three = true := by decide
def e605606304222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605606304222 : Closed e605606304222 ∧ code e605606304222 = 9401699326430 := by decide
theorem cert_e605606304222 : check e605606304222 [[.under],[.under]] .three = true := by decide
def e605606304246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605606304246 : Closed e605606304246 ∧ code e605606304246 = 9401699326454 := by decide
theorem cert_e605606304246 : check e605606304246 [[.under],[.under]] .three = true := by decide
def e605606305398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605606305398 : Closed e605606305398 ∧ code e605606305398 = 9401699327606 := by decide
theorem cert_e605606305398 : check e605606305398 [[.under],[.under]] .three = true := by decide
def e605606307550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605606307550 : Closed e605606307550 ∧ code e605606307550 = 9401699329758 := by decide
theorem cert_e605606307550 : check e605606307550 [[.under],[.under]] .three = true := by decide
def e605606307574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605606307574 : Closed e605606307574 ∧ code e605606307574 = 9401699329782 := by decide
theorem cert_e605606307574 : check e605606307574 [[.under],[.under]] .three = true := by decide
def e605606307678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605606307678 : Closed e605606307678 ∧ code e605606307678 = 9401699329886 := by decide
theorem cert_e605606307678 : check e605606307678 [[.under],[.under]] .three = true := by decide
def e605606307706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605606307706 : Closed e605606307706 ∧ code e605606307706 = 9401699329914 := by decide
theorem cert_e605606307706 : check e605606307706 [[.under],[.under]] .three = true := by decide
def e605606307798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605606307798 : Closed e605606307798 ∧ code e605606307798 = 9401699330006 := by decide
theorem cert_e605606307798 : check e605606307798 [[.under],[.under]] .three = true := by decide
def e605606307802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605606307802 : Closed e605606307802 ∧ code e605606307802 = 9401699330010 := by decide
theorem cert_e605606307802 : check e605606307802 [[.under],[.under]] .three = true := by decide
def e605606308318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605606308318 : Closed e605606308318 ∧ code e605606308318 = 9401699330526 := by decide
theorem cert_e605606308318 : check e605606308318 [[.under],[.under]] .three = true := by decide
def e605606308342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605606308342 : Closed e605606308342 ∧ code e605606308342 = 9401699330550 := by decide
theorem cert_e605606308342 : check e605606308342 [[.under],[.under]] .three = true := by decide
def e605606309086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605606309086 : Closed e605606309086 ∧ code e605606309086 = 9401699331294 := by decide
theorem cert_e605606309086 : check e605606309086 [[.under],[.under]] .three = true := by decide
def e605606309114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605606309114 : Closed e605606309114 ∧ code e605606309114 = 9401699331322 := by decide
theorem cert_e605606309114 : check e605606309114 [[.under],[.under]] .three = true := by decide
def e605606309686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606309686 : Closed e605606309686 ∧ code e605606309686 = 9401699331894 := by decide
theorem cert_e605606309686 : check e605606309686 [[.under],[.under]] .three = true := by decide
def e605606309690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606309690 : Closed e605606309690 ∧ code e605606309690 = 9401699331898 := by decide
theorem cert_e605606309690 : check e605606309690 [[.under],[.under]] .three = true := by decide
def e605606312374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605606312374 : Closed e605606312374 ∧ code e605606312374 = 9401699334582 := by decide
theorem cert_e605606312374 : check e605606312374 [[.under],[.under]] .three = true := by decide
def e605606312406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605606312406 : Closed e605606312406 ∧ code e605606312406 = 9401699334614 := by decide
theorem cert_e605606312406 : check e605606312406 [[.under],[.under]] .three = true := by decide
def e605606312410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605606312410 : Closed e605606312410 ∧ code e605606312410 = 9401699334618 := by decide
theorem cert_e605606312410 : check e605606312410 [[.under],[.under]] .three = true := by decide
def e605606312566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605606312566 : Closed e605606312566 ∧ code e605606312566 = 9401699334774 := by decide
theorem cert_e605606312566 : check e605606312566 [[.under],[.under]] .three = true := by decide
def e605606312758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606312758 : Closed e605606312758 ∧ code e605606312758 = 9401699334966 := by decide
theorem cert_e605606312758 : check e605606312758 [[.under],[.under]] .three = true := by decide
def e605606312762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606312762 : Closed e605606312762 ∧ code e605606312762 = 9401699334970 := by decide
theorem cert_e605606312762 : check e605606312762 [[.under],[.under]] .three = true := by decide
def e605606325982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e605606325982 : Closed e605606325982 ∧ code e605606325982 = 9401699348190 := by decide
theorem cert_e605606325982 : check e605606325982 [[.under],[.under]] .three = true := by decide
def e605606326006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e605606326006 : Closed e605606326006 ∧ code e605606326006 = 9401699348214 := by decide
theorem cert_e605606326006 : check e605606326006 [[.under],[.under]] .three = true := by decide
def e605606326198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e605606326198 : Closed e605606326198 ∧ code e605606326198 = 9401699348406 := by decide
theorem cert_e605606326198 : check e605606326198 [[.under],[.under]] .three = true := by decide
def e605606328798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e605606328798 : Closed e605606328798 ∧ code e605606328798 = 9401699351006 := by decide
theorem cert_e605606328798 : check e605606328798 [[.under],[.under]] .three = true := by decide
def e605606328822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e605606328822 : Closed e605606328822 ∧ code e605606328822 = 9401699351030 := by decide
theorem cert_e605606328822 : check e605606328822 [[.under],[.under]] .three = true := by decide
def e605606329974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e605606329974 : Closed e605606329974 ∧ code e605606329974 = 9401699352182 := by decide
theorem cert_e605606329974 : check e605606329974 [[.under],[.under]] .three = true := by decide
def e605606352606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605606352606 : Closed e605606352606 ∧ code e605606352606 = 9401699374814 := by decide
theorem cert_e605606352606 : check e605606352606 [[.under],[.under]] .three = true := by decide
def e605606352630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605606352630 : Closed e605606352630 ∧ code e605606352630 = 9401699374838 := by decide
theorem cert_e605606352630 : check e605606352630 [[.under],[.under]] .three = true := by decide
def e605606352734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605606352734 : Closed e605606352734 ∧ code e605606352734 = 9401699374942 := by decide
theorem cert_e605606352734 : check e605606352734 [[.under],[.under]] .three = true := by decide
def e605606352762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605606352762 : Closed e605606352762 ∧ code e605606352762 = 9401699374970 := by decide
theorem cert_e605606352762 : check e605606352762 [[.under],[.under]] .three = true := by decide
def e605606352854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605606352854 : Closed e605606352854 ∧ code e605606352854 = 9401699375062 := by decide
theorem cert_e605606352854 : check e605606352854 [[.under],[.under]] .three = true := by decide
def e605606352858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605606352858 : Closed e605606352858 ∧ code e605606352858 = 9401699375066 := by decide
theorem cert_e605606352858 : check e605606352858 [[.under],[.under]] .three = true := by decide
def e605606353374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605606353374 : Closed e605606353374 ∧ code e605606353374 = 9401699375582 := by decide
theorem cert_e605606353374 : check e605606353374 [[.under],[.under]] .three = true := by decide
def e605606353398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605606353398 : Closed e605606353398 ∧ code e605606353398 = 9401699375606 := by decide
theorem cert_e605606353398 : check e605606353398 [[.under],[.under]] .three = true := by decide
def e605606354142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605606354142 : Closed e605606354142 ∧ code e605606354142 = 9401699376350 := by decide
theorem cert_e605606354142 : check e605606354142 [[.under],[.under]] .three = true := by decide
def e605606354170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605606354170 : Closed e605606354170 ∧ code e605606354170 = 9401699376378 := by decide
theorem cert_e605606354170 : check e605606354170 [[.under],[.under]] .three = true := by decide
def e605606354742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606354742 : Closed e605606354742 ∧ code e605606354742 = 9401699376950 := by decide
theorem cert_e605606354742 : check e605606354742 [[.under],[.under]] .three = true := by decide
def e605606354746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606354746 : Closed e605606354746 ∧ code e605606354746 = 9401699376954 := by decide
theorem cert_e605606354746 : check e605606354746 [[.under],[.under]] .three = true := by decide
def e605606372790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605606372790 : Closed e605606372790 ∧ code e605606372790 = 9401699394998 := by decide
theorem cert_e605606372790 : check e605606372790 [[.under],[.under]] .three = true := by decide
def e605606372822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605606372822 : Closed e605606372822 ∧ code e605606372822 = 9401699395030 := by decide
theorem cert_e605606372822 : check e605606372822 [[.under],[.under]] .three = true := by decide
def e605606372826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605606372826 : Closed e605606372826 ∧ code e605606372826 = 9401699395034 := by decide
theorem cert_e605606372826 : check e605606372826 [[.under],[.under]] .three = true := by decide
def e605606372982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605606372982 : Closed e605606372982 ∧ code e605606372982 = 9401699395190 := by decide
theorem cert_e605606372982 : check e605606372982 [[.under],[.under]] .three = true := by decide
def e605606373174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606373174 : Closed e605606373174 ∧ code e605606373174 = 9401699395382 := by decide
theorem cert_e605606373174 : check e605606373174 [[.under],[.under]] .three = true := by decide
def e605606373178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606373178 : Closed e605606373178 ∧ code e605606373178 = 9401699395386 := by decide
theorem cert_e605606373178 : check e605606373178 [[.under],[.under]] .three = true := by decide
def e605606730606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605606730606 : Closed e605606730606 ∧ code e605606730606 = 9401699752814 := by decide
theorem cert_e605606730606 : check e605606730606 [[.under],[.under]] .three = true := by decide
def e605606730614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605606730614 : Closed e605606730614 ∧ code e605606730614 = 9401699752822 := by decide
theorem cert_e605606730614 : check e605606730614 [[.under],[.under]] .three = true := by decide
def e605606730678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605606730678 : Closed e605606730678 ∧ code e605606730678 = 9401699752886 := by decide
theorem cert_e605606730678 : check e605606730678 [[.under],[.under]] .three = true := by decide
def e605606731118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605606731118 : Closed e605606731118 ∧ code e605606731118 = 9401699753326 := by decide
theorem cert_e605606731118 : check e605606731118 [[.under],[.under]] .three = true := by decide
def e605606731126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605606731126 : Closed e605606731126 ∧ code e605606731126 = 9401699753334 := by decide
theorem cert_e605606731126 : check e605606731126 [[.under],[.under]] .three = true := by decide
def e605606731182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605606731182 : Closed e605606731182 ∧ code e605606731182 = 9401699753390 := by decide
theorem cert_e605606731182 : check e605606731182 [[.under],[.under]] .three = true := by decide
def e605606731194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605606731194 : Closed e605606731194 ∧ code e605606731194 = 9401699753402 := by decide
theorem cert_e605606731194 : check e605606731194 [[.under],[.under]] .three = true := by decide
def e605606731222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605606731222 : Closed e605606731222 ∧ code e605606731222 = 9401699753430 := by decide
theorem cert_e605606731222 : check e605606731222 [[.under],[.under]] .three = true := by decide
def e605606731226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605606731226 : Closed e605606731226 ∧ code e605606731226 = 9401699753434 := by decide
theorem cert_e605606731226 : check e605606731226 [[.under],[.under]] .three = true := by decide
def e605606731446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605606731446 : Closed e605606731446 ∧ code e605606731446 = 9401699753654 := by decide
theorem cert_e605606731446 : check e605606731446 [[.under],[.under]] .three = true := by decide
def e605606731478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605606731478 : Closed e605606731478 ∧ code e605606731478 = 9401699753686 := by decide
theorem cert_e605606731478 : check e605606731478 [[.under],[.under]] .three = true := by decide
def e605606731482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605606731482 : Closed e605606731482 ∧ code e605606731482 = 9401699753690 := by decide
theorem cert_e605606731482 : check e605606731482 [[.under],[.under]] .three = true := by decide
def e605606733678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605606733678 : Closed e605606733678 ∧ code e605606733678 = 9401699755886 := by decide
theorem cert_e605606733678 : check e605606733678 [[.under],[.under]] .three = true := by decide
def e605606733686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605606733686 : Closed e605606733686 ∧ code e605606733686 = 9401699755894 := by decide
theorem cert_e605606733686 : check e605606733686 [[.under],[.under]] .three = true := by decide
def e605606733750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605606733750 : Closed e605606733750 ∧ code e605606733750 = 9401699755958 := by decide
theorem cert_e605606733750 : check e605606733750 [[.under],[.under]] .three = true := by decide
def e605606735086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605606735086 : Closed e605606735086 ∧ code e605606735086 = 9401699757294 := by decide
theorem cert_e605606735086 : check e605606735086 [[.under],[.under]] .three = true := by decide
def e605606735094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605606735094 : Closed e605606735094 ∧ code e605606735094 = 9401699757302 := by decide
theorem cert_e605606735094 : check e605606735094 [[.under],[.under]] .three = true := by decide
def e605606735478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605606735478 : Closed e605606735478 ∧ code e605606735478 = 9401699757686 := by decide
theorem cert_e605606735478 : check e605606735478 [[.under],[.under]] .three = true := by decide
def e605606736750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605606736750 : Closed e605606736750 ∧ code e605606736750 = 9401699758958 := by decide
theorem cert_e605606736750 : check e605606736750 [[.under],[.under]] .three = true := by decide
def e605606736758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605606736758 : Closed e605606736758 ∧ code e605606736758 = 9401699758966 := by decide
theorem cert_e605606736758 : check e605606736758 [[.under],[.under]] .three = true := by decide
def e605606736814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605606736814 : Closed e605606736814 ∧ code e605606736814 = 9401699759022 := by decide
theorem cert_e605606736814 : check e605606736814 [[.under],[.under]] .three = true := by decide
def e605606736826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605606736826 : Closed e605606736826 ∧ code e605606736826 = 9401699759034 := by decide
theorem cert_e605606736826 : check e605606736826 [[.under],[.under]] .three = true := by decide
def e605606736854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605606736854 : Closed e605606736854 ∧ code e605606736854 = 9401699759062 := by decide
theorem cert_e605606736854 : check e605606736854 [[.under],[.under]] .three = true := by decide
def e605606736858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605606736858 : Closed e605606736858 ∧ code e605606736858 = 9401699759066 := by decide
theorem cert_e605606736858 : check e605606736858 [[.under],[.under]] .three = true := by decide
def e605606737134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605606737134 : Closed e605606737134 ∧ code e605606737134 = 9401699759342 := by decide
theorem cert_e605606737134 : check e605606737134 [[.under],[.under]] .three = true := by decide
def e605606737142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605606737142 : Closed e605606737142 ∧ code e605606737142 = 9401699759350 := by decide
theorem cert_e605606737142 : check e605606737142 [[.under],[.under]] .three = true := by decide
def e605606737518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605606737518 : Closed e605606737518 ∧ code e605606737518 = 9401699759726 := by decide
theorem cert_e605606737518 : check e605606737518 [[.under],[.under]] .three = true := by decide
def e605606737530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605606737530 : Closed e605606737530 ∧ code e605606737530 = 9401699759738 := by decide
theorem cert_e605606737530 : check e605606737530 [[.under],[.under]] .three = true := by decide
def e605606737718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606737718 : Closed e605606737718 ∧ code e605606737718 = 9401699759926 := by decide
theorem cert_e605606737718 : check e605606737718 [[.under],[.under]] .three = true := by decide
def e605606737722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606737722 : Closed e605606737722 ∧ code e605606737722 = 9401699759930 := by decide
theorem cert_e605606737722 : check e605606737722 [[.under],[.under]] .three = true := by decide
def e605606738358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605606738358 : Closed e605606738358 ∧ code e605606738358 = 9401699760566 := by decide
theorem cert_e605606738358 : check e605606738358 [[.under],[.under]] .three = true := by decide
def e605606738390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605606738390 : Closed e605606738390 ∧ code e605606738390 = 9401699760598 := by decide
theorem cert_e605606738390 : check e605606738390 [[.under],[.under]] .three = true := by decide
def e605606738394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605606738394 : Closed e605606738394 ∧ code e605606738394 = 9401699760602 := by decide
theorem cert_e605606738394 : check e605606738394 [[.under],[.under]] .three = true := by decide
def e605606738550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605606738550 : Closed e605606738550 ∧ code e605606738550 = 9401699760758 := by decide
theorem cert_e605606738550 : check e605606738550 [[.under],[.under]] .three = true := by decide
def e605606738742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606738742 : Closed e605606738742 ∧ code e605606738742 = 9401699760950 := by decide
theorem cert_e605606738742 : check e605606738742 [[.under],[.under]] .three = true := by decide
def e605606738746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606738746 : Closed e605606738746 ∧ code e605606738746 = 9401699760954 := by decide
theorem cert_e605606738746 : check e605606738746 [[.under],[.under]] .three = true := by decide
def e605606745966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605606745966 : Closed e605606745966 ∧ code e605606745966 = 9401699768174 := by decide
theorem cert_e605606745966 : check e605606745966 [[.under],[.under]] .three = true := by decide
def e605606745974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605606745974 : Closed e605606745974 ∧ code e605606745974 = 9401699768182 := by decide
theorem cert_e605606745974 : check e605606745974 [[.under],[.under]] .three = true := by decide
def e605606746038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605606746038 : Closed e605606746038 ∧ code e605606746038 = 9401699768246 := by decide
theorem cert_e605606746038 : check e605606746038 [[.under],[.under]] .three = true := by decide
def e605606747374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605606747374 : Closed e605606747374 ∧ code e605606747374 = 9401699769582 := by decide
theorem cert_e605606747374 : check e605606747374 [[.under],[.under]] .three = true := by decide
def e605606747382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605606747382 : Closed e605606747382 ∧ code e605606747382 = 9401699769590 := by decide
theorem cert_e605606747382 : check e605606747382 [[.under],[.under]] .three = true := by decide
def e605606747766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605606747766 : Closed e605606747766 ∧ code e605606747766 = 9401699769974 := by decide
theorem cert_e605606747766 : check e605606747766 [[.under],[.under]] .three = true := by decide
def e605606759278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605606759278 : Closed e605606759278 ∧ code e605606759278 = 9401699781486 := by decide
theorem cert_e605606759278 : check e605606759278 [[.under],[.under]] .three = true := by decide
def e605606759286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605606759286 : Closed e605606759286 ∧ code e605606759286 = 9401699781494 := by decide
theorem cert_e605606759286 : check e605606759286 [[.under],[.under]] .three = true := by decide
def e605606759342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605606759342 : Closed e605606759342 ∧ code e605606759342 = 9401699781550 := by decide
theorem cert_e605606759342 : check e605606759342 [[.under],[.under]] .three = true := by decide
def e605606759354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605606759354 : Closed e605606759354 ∧ code e605606759354 = 9401699781562 := by decide
theorem cert_e605606759354 : check e605606759354 [[.under],[.under]] .three = true := by decide
def e605606759382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605606759382 : Closed e605606759382 ∧ code e605606759382 = 9401699781590 := by decide
theorem cert_e605606759382 : check e605606759382 [[.under],[.under]] .three = true := by decide
def e605606759386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605606759386 : Closed e605606759386 ∧ code e605606759386 = 9401699781594 := by decide
theorem cert_e605606759386 : check e605606759386 [[.under],[.under]] .three = true := by decide
def e605606759662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605606759662 : Closed e605606759662 ∧ code e605606759662 = 9401699781870 := by decide
theorem cert_e605606759662 : check e605606759662 [[.under],[.under]] .three = true := by decide
def e605606759670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605606759670 : Closed e605606759670 ∧ code e605606759670 = 9401699781878 := by decide
theorem cert_e605606759670 : check e605606759670 [[.under],[.under]] .three = true := by decide
def e605606760046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605606760046 : Closed e605606760046 ∧ code e605606760046 = 9401699782254 := by decide
theorem cert_e605606760046 : check e605606760046 [[.under],[.under]] .three = true := by decide
def e605606760058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605606760058 : Closed e605606760058 ∧ code e605606760058 = 9401699782266 := by decide
theorem cert_e605606760058 : check e605606760058 [[.under],[.under]] .three = true := by decide
def e605606760246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606760246 : Closed e605606760246 ∧ code e605606760246 = 9401699782454 := by decide
theorem cert_e605606760246 : check e605606760246 [[.under],[.under]] .three = true := by decide
def e605606760250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606760250 : Closed e605606760250 ∧ code e605606760250 = 9401699782458 := by decide
theorem cert_e605606760250 : check e605606760250 [[.under],[.under]] .three = true := by decide
def e605606766006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605606766006 : Closed e605606766006 ∧ code e605606766006 = 9401699788214 := by decide
theorem cert_e605606766006 : check e605606766006 [[.under],[.under]] .three = true := by decide
def e605606766038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605606766038 : Closed e605606766038 ∧ code e605606766038 = 9401699788246 := by decide
theorem cert_e605606766038 : check e605606766038 [[.under],[.under]] .three = true := by decide
def e605606766042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605606766042 : Closed e605606766042 ∧ code e605606766042 = 9401699788250 := by decide
theorem cert_e605606766042 : check e605606766042 [[.under],[.under]] .three = true := by decide
def e605606766198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605606766198 : Closed e605606766198 ∧ code e605606766198 = 9401699788406 := by decide
theorem cert_e605606766198 : check e605606766198 [[.under],[.under]] .three = true := by decide
def e605606766390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606766390 : Closed e605606766390 ∧ code e605606766390 = 9401699788598 := by decide
theorem cert_e605606766390 : check e605606766390 [[.under],[.under]] .three = true := by decide
def e605606766394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606766394 : Closed e605606766394 ∧ code e605606766394 = 9401699788602 := by decide
theorem cert_e605606766394 : check e605606766394 [[.under],[.under]] .three = true := by decide
def e605636572910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 2))))))
theorem wire_e605636572910 : Closed e605636572910 ∧ code e605636572910 = 9401729595118 := by decide
theorem cert_e605636572910 : check e605636572910 [[.under],[.under]] .smaller = true := by decide
def e605636573038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 2))))))
theorem wire_e605636573038 : Closed e605636573038 ∧ code e605636573038 = 9401729595246 := by decide
theorem cert_e605636573038 : check e605636573038 [[.under],[.under]] .smaller = true := by decide
def e605636573934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 2))))))
theorem wire_e605636573934 : Closed e605636573934 ∧ code e605636573934 = 9401729596142 := by decide
theorem cert_e605636573934 : check e605636573934 [[.under],[.under]] .smaller = true := by decide
def e605636574126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 2))))))
theorem wire_e605636574126 : Closed e605636574126 ∧ code e605636574126 = 9401729596334 := by decide
theorem cert_e605636574126 : check e605636574126 [[.under],[.under]] .smaller = true := by decide
def e605636574574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 2))))))
theorem wire_e605636574574 : Closed e605636574574 ∧ code e605636574574 = 9401729596782 := by decide
theorem cert_e605636574574 : check e605636574574 [[.under],[.under]] .smaller = true := by decide
def e605636574638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 2))))))
theorem wire_e605636574638 : Closed e605636574638 ∧ code e605636574638 = 9401729596846 := by decide
theorem cert_e605636574638 : check e605636574638 [[.under],[.under]] .smaller = true := by decide
def e605636579054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 2))))))
theorem wire_e605636579054 : Closed e605636579054 ∧ code e605636579054 = 9401729601262 := by decide
theorem cert_e605636579054 : check e605636579054 [[.under],[.under]] .smaller = true := by decide
def e605636579182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 2))))))
theorem wire_e605636579182 : Closed e605636579182 ∧ code e605636579182 = 9401729601390 := by decide
theorem cert_e605636579182 : check e605636579182 [[.under],[.under]] .smaller = true := by decide
def e605636585198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 2))))))
theorem wire_e605636585198 : Closed e605636585198 ∧ code e605636585198 = 9401729607406 := by decide
theorem cert_e605636585198 : check e605636585198 [[.under],[.under]] .smaller = true := by decide
def e605636585390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 2))))))
theorem wire_e605636585390 : Closed e605636585390 ∧ code e605636585390 = 9401729607598 := by decide
theorem cert_e605636585390 : check e605636585390 [[.under],[.under]] .smaller = true := by decide
def e605636588398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 2))))))
theorem wire_e605636588398 : Closed e605636588398 ∧ code e605636588398 = 9401729610606 := by decide
theorem cert_e605636588398 : check e605636588398 [[.under],[.under]] .smaller = true := by decide
def e605636588462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 2))))))
theorem wire_e605636588462 : Closed e605636588462 ∧ code e605636588462 = 9401729610670 := by decide
theorem cert_e605636588462 : check e605636588462 [[.under],[.under]] .smaller = true := by decide
def e605638364014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605638364014 : Closed e605638364014 ∧ code e605638364014 = 9401731386222 := by decide
theorem cert_e605638364014 : check e605638364014 [[.under],[.under]] .smaller = true := by decide
def e605638364022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605638364022 : Closed e605638364022 ∧ code e605638364022 = 9401731386230 := by decide
theorem cert_e605638364022 : check e605638364022 [[.under],[.under]] .smaller = true := by decide
def e605638364078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605638364078 : Closed e605638364078 ∧ code e605638364078 = 9401731386286 := by decide
theorem cert_e605638364078 : check e605638364078 [[.under],[.under]] .smaller = true := by decide
def e605638364090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605638364090 : Closed e605638364090 ∧ code e605638364090 = 9401731386298 := by decide
theorem cert_e605638364090 : check e605638364090 [[.under],[.under]] .smaller = true := by decide
def e605638364118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605638364118 : Closed e605638364118 ∧ code e605638364118 = 9401731386326 := by decide
theorem cert_e605638364118 : check e605638364118 [[.under],[.under]] .smaller = true := by decide
def e605638364122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605638364122 : Closed e605638364122 ∧ code e605638364122 = 9401731386330 := by decide
theorem cert_e605638364122 : check e605638364122 [[.under],[.under]] .smaller = true := by decide
def e605638364398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605638364398 : Closed e605638364398 ∧ code e605638364398 = 9401731386606 := by decide
theorem cert_e605638364398 : check e605638364398 [[.under],[.under]] .smaller = true := by decide
def e605638364406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605638364406 : Closed e605638364406 ∧ code e605638364406 = 9401731386614 := by decide
theorem cert_e605638364406 : check e605638364406 [[.under],[.under]] .smaller = true := by decide
def e605638364782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605638364782 : Closed e605638364782 ∧ code e605638364782 = 9401731386990 := by decide
theorem cert_e605638364782 : check e605638364782 [[.under],[.under]] .smaller = true := by decide
def e605638364794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605638364794 : Closed e605638364794 ∧ code e605638364794 = 9401731387002 := by decide
theorem cert_e605638364794 : check e605638364794 [[.under],[.under]] .smaller = true := by decide
def e605638364982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605638364982 : Closed e605638364982 ∧ code e605638364982 = 9401731387190 := by decide
theorem cert_e605638364982 : check e605638364982 [[.under],[.under]] .smaller = true := by decide
def e605638364986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605638364986 : Closed e605638364986 ∧ code e605638364986 = 9401731387194 := by decide
theorem cert_e605638364986 : check e605638364986 [[.under],[.under]] .smaller = true := by decide
def e605639683514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e605639683514 : Closed e605639683514 ∧ code e605639683514 = 9401732705722 := by decide
theorem cert_e605639683514 : check e605639683514 [[.under],[.under]] .smaller = true := by decide
def e605639683546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e605639683546 : Closed e605639683546 ∧ code e605639683546 = 9401732705754 := by decide
theorem cert_e605639683546 : check e605639683546 [[.under],[.under]] .smaller = true := by decide
def e605639683770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e605639683770 : Closed e605639683770 ∧ code e605639683770 = 9401732705978 := by decide
theorem cert_e605639683770 : check e605639683770 [[.under],[.under]] .smaller = true := by decide
def e605639683818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e605639683818 : Closed e605639683818 ∧ code e605639683818 = 9401732706026 := by decide
theorem cert_e605639683818 : check e605639683818 [[.under],[.under]] .smaller = true := by decide
def e605639683930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e605639683930 : Closed e605639683930 ∧ code e605639683930 = 9401732706138 := by decide
theorem cert_e605639683930 : check e605639683930 [[.under],[.under]] .smaller = true := by decide
def e605639683946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e605639683946 : Closed e605639683946 ∧ code e605639683946 = 9401732706154 := by decide
theorem cert_e605639683946 : check e605639683946 [[.under],[.under]] .smaller = true := by decide
def e605639685050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e605639685050 : Closed e605639685050 ∧ code e605639685050 = 9401732707258 := by decide
theorem cert_e605639685050 : check e605639685050 [[.under],[.under]] .smaller = true := by decide
def e605639685082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e605639685082 : Closed e605639685082 ∧ code e605639685082 = 9401732707290 := by decide
theorem cert_e605639685082 : check e605639685082 [[.under],[.under]] .smaller = true := by decide
def e605639686586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e605639686586 : Closed e605639686586 ∧ code e605639686586 = 9401732708794 := by decide
theorem cert_e605639686586 : check e605639686586 [[.under],[.under]] .smaller = true := by decide
def e605639686634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e605639686634 : Closed e605639686634 ∧ code e605639686634 = 9401732708842 := by decide
theorem cert_e605639686634 : check e605639686634 [[.under],[.under]] .smaller = true := by decide
def e605639687386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e605639687386 : Closed e605639687386 ∧ code e605639687386 = 9401732709594 := by decide
theorem cert_e605639687386 : check e605639687386 [[.under],[.under]] .smaller = true := by decide
def e605639687402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e605639687402 : Closed e605639687402 ∧ code e605639687402 = 9401732709610 := by decide
theorem cert_e605639687402 : check e605639687402 [[.under],[.under]] .smaller = true := by decide
end Blc.Floor43
