import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422365642394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365642394 : Closed e2422365642394 ∧ code e2422365642394 = 11218458664602 := by decide
theorem cert_e2422365642394 : check e2422365642394 [[],[]] .smaller = true := by decide
def e2422365642462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e2422365642462 : Closed e2422365642462 ∧ code e2422365642462 = 11218458664670 := by decide
theorem cert_e2422365642462 : check e2422365642462 [[],[]] .smaller = true := by decide
def e2422365642486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e2422365642486 : Closed e2422365642486 ∧ code e2422365642486 = 11218458664694 := by decide
theorem cert_e2422365642486 : check e2422365642486 [[],[]] .smaller = true := by decide
def e2422365642606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e2422365642606 : Closed e2422365642606 ∧ code e2422365642606 = 11218458664814 := by decide
theorem cert_e2422365642606 : check e2422365642606 [[],[]] .smaller = true := by decide
def e2422365642614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e2422365642614 : Closed e2422365642614 ∧ code e2422365642614 = 11218458664822 := by decide
theorem cert_e2422365642614 : check e2422365642614 [[],[]] .smaller = true := by decide
def e2422365642678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 4) (.var 1)) (.var 1)))))))))
theorem wire_e2422365642678 : Closed e2422365642678 ∧ code e2422365642678 = 11218458664886 := by decide
theorem cert_e2422365642678 : check e2422365642678 [[],[]] .three = true := by decide
def e2422365643230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422365643230 : Closed e2422365643230 ∧ code e2422365643230 = 11218458665438 := by decide
theorem cert_e2422365643230 : check e2422365643230 [[],[]] .smaller = true := by decide
def e2422365643246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422365643246 : Closed e2422365643246 ∧ code e2422365643246 = 11218458665454 := by decide
theorem cert_e2422365643246 : check e2422365643246 [[],[]] .smaller = true := by decide
def e2422365643254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422365643254 : Closed e2422365643254 ∧ code e2422365643254 = 11218458665462 := by decide
theorem cert_e2422365643254 : check e2422365643254 [[],[]] .smaller = true := by decide
def e2422365644206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422365644206 : Closed e2422365644206 ∧ code e2422365644206 = 11218458666414 := by decide
theorem cert_e2422365644206 : check e2422365644206 [[],[]] .smaller = true := by decide
def e2422365644214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422365644214 : Closed e2422365644214 ∧ code e2422365644214 = 11218458666422 := by decide
theorem cert_e2422365644214 : check e2422365644214 [[],[]] .smaller = true := by decide
def e2422365644218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422365644218 : Closed e2422365644218 ∧ code e2422365644218 = 11218458666426 := by decide
theorem cert_e2422365644218 : check e2422365644218 [[],[]] .smaller = true := by decide
def e2422365644246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422365644246 : Closed e2422365644246 ∧ code e2422365644246 = 11218458666454 := by decide
theorem cert_e2422365644246 : check e2422365644246 [[],[]] .smaller = true := by decide
def e2422365644250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422365644250 : Closed e2422365644250 ∧ code e2422365644250 = 11218458666458 := by decide
theorem cert_e2422365644250 : check e2422365644250 [[],[]] .smaller = true := by decide
def e2422365644266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422365644266 : Closed e2422365644266 ∧ code e2422365644266 = 11218458666474 := by decide
theorem cert_e2422365644266 : check e2422365644266 [[],[]] .smaller = true := by decide
def e2422365644398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365644398 : Closed e2422365644398 ∧ code e2422365644398 = 11218458666606 := by decide
theorem cert_e2422365644398 : check e2422365644398 [[],[]] .smaller = true := by decide
def e2422365644406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365644406 : Closed e2422365644406 ∧ code e2422365644406 = 11218458666614 := by decide
theorem cert_e2422365644406 : check e2422365644406 [[],[]] .smaller = true := by decide
def e2422365644410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365644410 : Closed e2422365644410 ∧ code e2422365644410 = 11218458666618 := by decide
theorem cert_e2422365644410 : check e2422365644410 [[],[]] .smaller = true := by decide
def e2422365644598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365644598 : Closed e2422365644598 ∧ code e2422365644598 = 11218458666806 := by decide
theorem cert_e2422365644598 : check e2422365644598 [[],[]] .smaller = true := by decide
def e2422365644602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365644602 : Closed e2422365644602 ∧ code e2422365644602 = 11218458666810 := by decide
theorem cert_e2422365644602 : check e2422365644602 [[],[]] .smaller = true := by decide
def e2422365644698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365644698 : Closed e2422365644698 ∧ code e2422365644698 = 11218458666906 := by decide
theorem cert_e2422365644698 : check e2422365644698 [[],[]] .smaller = true := by decide
def e2422365647086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365647086 : Closed e2422365647086 ∧ code e2422365647086 = 11218458669294 := by decide
theorem cert_e2422365647086 : check e2422365647086 [[],[]] .smaller = true := by decide
def e2422365647094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365647094 : Closed e2422365647094 ∧ code e2422365647094 = 11218458669302 := by decide
theorem cert_e2422365647094 : check e2422365647094 [[],[]] .smaller = true := by decide
def e2422365647574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422365647574 : Closed e2422365647574 ∧ code e2422365647574 = 11218458669782 := by decide
theorem cert_e2422365647574 : check e2422365647574 [[],[]] .smaller = true := by decide
def e2422365647578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422365647578 : Closed e2422365647578 ∧ code e2422365647578 = 11218458669786 := by decide
theorem cert_e2422365647578 : check e2422365647578 [[],[]] .smaller = true := by decide
def e2422365647594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422365647594 : Closed e2422365647594 ∧ code e2422365647594 = 11218458669802 := by decide
theorem cert_e2422365647594 : check e2422365647594 [[],[]] .smaller = true := by decide
def e2422365647670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365647670 : Closed e2422365647670 ∧ code e2422365647670 = 11218458669878 := by decide
theorem cert_e2422365647670 : check e2422365647670 [[],[]] .smaller = true := by decide
def e2422365647674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365647674 : Closed e2422365647674 ∧ code e2422365647674 = 11218458669882 := by decide
theorem cert_e2422365647674 : check e2422365647674 [[],[]] .smaller = true := by decide
def e2422365647770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365647770 : Closed e2422365647770 ∧ code e2422365647770 = 11218458669978 := by decide
theorem cert_e2422365647770 : check e2422365647770 [[],[]] .smaller = true := by decide
def e2422365647806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422365647806 : Closed e2422365647806 ∧ code e2422365647806 = 11218458670014 := by decide
theorem cert_e2422365647806 : check e2422365647806 [[],[]] .three = true := by decide
def e2422365647838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422365647838 : Closed e2422365647838 ∧ code e2422365647838 = 11218458670046 := by decide
theorem cert_e2422365647838 : check e2422365647838 [[],[]] .smaller = true := by decide
def e2422365647854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422365647854 : Closed e2422365647854 ∧ code e2422365647854 = 11218458670062 := by decide
theorem cert_e2422365647854 : check e2422365647854 [[],[]] .smaller = true := by decide
def e2422365647862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422365647862 : Closed e2422365647862 ∧ code e2422365647862 = 11218458670070 := by decide
theorem cert_e2422365647862 : check e2422365647862 [[],[]] .three = true := by decide
def e2422365649014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365649014 : Closed e2422365649014 ∧ code e2422365649014 = 11218458671222 := by decide
theorem cert_e2422365649014 : check e2422365649014 [[],[]] .smaller = true := by decide
def e2422365649258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422365649258 : Closed e2422365649258 ∧ code e2422365649258 = 11218458671466 := by decide
theorem cert_e2422365649258 : check e2422365649258 [[],[]] .smaller = true := by decide
def e2422365649306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365649306 : Closed e2422365649306 ∧ code e2422365649306 = 11218458671514 := by decide
theorem cert_e2422365649306 : check e2422365649306 [[],[]] .smaller = true := by decide
def e2422365649374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422365649374 : Closed e2422365649374 ∧ code e2422365649374 = 11218458671582 := by decide
theorem cert_e2422365649374 : check e2422365649374 [[],[]] .smaller = true := by decide
def e2422365649398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422365649398 : Closed e2422365649398 ∧ code e2422365649398 = 11218458671606 := by decide
theorem cert_e2422365649398 : check e2422365649398 [[],[]] .smaller = true := by decide
def e2422365650158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422365650158 : Closed e2422365650158 ∧ code e2422365650158 = 11218458672366 := by decide
theorem cert_e2422365650158 : check e2422365650158 [[],[]] .smaller = true := by decide
def e2422365650166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422365650166 : Closed e2422365650166 ∧ code e2422365650166 = 11218458672374 := by decide
theorem cert_e2422365650166 : check e2422365650166 [[],[]] .smaller = true := by decide
def e2422365650550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422365650550 : Closed e2422365650550 ∧ code e2422365650550 = 11218458672758 := by decide
theorem cert_e2422365650550 : check e2422365650550 [[],[]] .three = true := by decide
def e2422365694806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365694806 : Closed e2422365694806 ∧ code e2422365694806 = 11218458717014 := by decide
theorem cert_e2422365694806 : check e2422365694806 [[],[]] .three = true := by decide
def e2422365694810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365694810 : Closed e2422365694810 ∧ code e2422365694810 = 11218458717018 := by decide
theorem cert_e2422365694810 : check e2422365694810 [[],[]] .three = true := by decide
def e2422365694826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365694826 : Closed e2422365694826 ∧ code e2422365694826 = 11218458717034 := by decide
theorem cert_e2422365694826 : check e2422365694826 [[],[]] .three = true := by decide
def e2422365694890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365694890 : Closed e2422365694890 ∧ code e2422365694890 = 11218458717098 := by decide
theorem cert_e2422365694890 : check e2422365694890 [[],[]] .three = true := by decide
def e2422365695086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2422365695086 : Closed e2422365695086 ∧ code e2422365695086 = 11218458717294 := by decide
theorem cert_e2422365695086 : check e2422365695086 [[],[]] .three = true := by decide
def e2422365695094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422365695094 : Closed e2422365695094 ∧ code e2422365695094 = 11218458717302 := by decide
theorem cert_e2422365695094 : check e2422365695094 [[],[]] .three = true := by decide
def e2422365695098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2422365695098 : Closed e2422365695098 ∧ code e2422365695098 = 11218458717306 := by decide
theorem cert_e2422365695098 : check e2422365695098 [[],[]] .three = true := by decide
def e2422365695190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422365695190 : Closed e2422365695190 ∧ code e2422365695190 = 11218458717398 := by decide
theorem cert_e2422365695190 : check e2422365695190 [[],[]] .three = true := by decide
def e2422365695194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422365695194 : Closed e2422365695194 ∧ code e2422365695194 = 11218458717402 := by decide
theorem cert_e2422365695194 : check e2422365695194 [[],[]] .three = true := by decide
def e2422365695210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422365695210 : Closed e2422365695210 ∧ code e2422365695210 = 11218458717418 := by decide
theorem cert_e2422365695210 : check e2422365695210 [[],[]] .three = true := by decide
def e2422365695262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2422365695262 : Closed e2422365695262 ∧ code e2422365695262 = 11218458717470 := by decide
theorem cert_e2422365695262 : check e2422365695262 [[],[]] .three = true := by decide
def e2422365695286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365695286 : Closed e2422365695286 ∧ code e2422365695286 = 11218458717494 := by decide
theorem cert_e2422365695286 : check e2422365695286 [[],[]] .three = true := by decide
def e2422365695290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365695290 : Closed e2422365695290 ∧ code e2422365695290 = 11218458717498 := by decide
theorem cert_e2422365695290 : check e2422365695290 [[],[]] .three = true := by decide
def e2422365695374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422365695374 : Closed e2422365695374 ∧ code e2422365695374 = 11218458717582 := by decide
theorem cert_e2422365695374 : check e2422365695374 [[],[]] .three = true := by decide
def e2422365695386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365695386 : Closed e2422365695386 ∧ code e2422365695386 = 11218458717594 := by decide
theorem cert_e2422365695386 : check e2422365695386 [[],[]] .three = true := by decide
def e2422365695422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2422365695422 : Closed e2422365695422 ∧ code e2422365695422 = 11218458717630 := by decide
theorem cert_e2422365695422 : check e2422365695422 [[],[]] .three = true := by decide
def e2422365695430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2422365695430 : Closed e2422365695430 ∧ code e2422365695430 = 11218458717638 := by decide
theorem cert_e2422365695430 : check e2422365695430 [[],[]] .three = true := by decide
def e2422365695478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2422365695478 : Closed e2422365695478 ∧ code e2422365695478 = 11218458717686 := by decide
theorem cert_e2422365695478 : check e2422365695478 [[],[]] .three = true := by decide
def e2422365695542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422365695542 : Closed e2422365695542 ∧ code e2422365695542 = 11218458717750 := by decide
theorem cert_e2422365695542 : check e2422365695542 [[],[]] .three = true := by decide
def e2422365695546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422365695546 : Closed e2422365695546 ∧ code e2422365695546 = 11218458717754 := by decide
theorem cert_e2422365695546 : check e2422365695546 [[],[]] .three = true := by decide
def e2422365695594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422365695594 : Closed e2422365695594 ∧ code e2422365695594 = 11218458717802 := by decide
theorem cert_e2422365695594 : check e2422365695594 [[],[]] .three = true := by decide
def e2422365695630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422365695630 : Closed e2422365695630 ∧ code e2422365695630 = 11218458717838 := by decide
theorem cert_e2422365695630 : check e2422365695630 [[],[]] .three = true := by decide
def e2422365695642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365695642 : Closed e2422365695642 ∧ code e2422365695642 = 11218458717850 := by decide
theorem cert_e2422365695642 : check e2422365695642 [[],[]] .three = true := by decide
def e2422365695678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2422365695678 : Closed e2422365695678 ∧ code e2422365695678 = 11218458717886 := by decide
theorem cert_e2422365695678 : check e2422365695678 [[],[]] .three = true := by decide
def e2422365695686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422365695686 : Closed e2422365695686 ∧ code e2422365695686 = 11218458717894 := by decide
theorem cert_e2422365695686 : check e2422365695686 [[],[]] .three = true := by decide
def e2422365695710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2422365695710 : Closed e2422365695710 ∧ code e2422365695710 = 11218458717918 := by decide
theorem cert_e2422365695710 : check e2422365695710 [[],[]] .three = true := by decide
def e2422365695726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e2422365695726 : Closed e2422365695726 ∧ code e2422365695726 = 11218458717934 := by decide
theorem cert_e2422365695726 : check e2422365695726 [[],[]] .three = true := by decide
def e2422365695734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2422365695734 : Closed e2422365695734 ∧ code e2422365695734 = 11218458717942 := by decide
theorem cert_e2422365695734 : check e2422365695734 [[],[]] .three = true := by decide
def e2422365695738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2422365695738 : Closed e2422365695738 ∧ code e2422365695738 = 11218458717946 := by decide
theorem cert_e2422365695738 : check e2422365695738 [[],[]] .three = true := by decide
def e2422365695770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422365695770 : Closed e2422365695770 ∧ code e2422365695770 = 11218458717978 := by decide
theorem cert_e2422365695770 : check e2422365695770 [[],[]] .three = true := by decide
def e2422365695814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422365695814 : Closed e2422365695814 ∧ code e2422365695814 = 11218458718022 := by decide
theorem cert_e2422365695814 : check e2422365695814 [[],[]] .three = true := by decide
def e2422365695854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e2422365695854 : Closed e2422365695854 ∧ code e2422365695854 = 11218458718062 := by decide
theorem cert_e2422365695854 : check e2422365695854 [[],[]] .three = true := by decide
def e2422365695862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e2422365695862 : Closed e2422365695862 ∧ code e2422365695862 = 11218458718070 := by decide
theorem cert_e2422365695862 : check e2422365695862 [[],[]] .three = true := by decide
def e2422365695926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2422365695926 : Closed e2422365695926 ∧ code e2422365695926 = 11218458718134 := by decide
theorem cert_e2422365695926 : check e2422365695926 [[],[]] .three = true := by decide
def e2422365695958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2422365695958 : Closed e2422365695958 ∧ code e2422365695958 = 11218458718166 := by decide
theorem cert_e2422365695958 : check e2422365695958 [[],[]] .three = true := by decide
def e2422365695962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2422365695962 : Closed e2422365695962 ∧ code e2422365695962 = 11218458718170 := by decide
theorem cert_e2422365695962 : check e2422365695962 [[],[]] .three = true := by decide
def e2422365696238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365696238 : Closed e2422365696238 ∧ code e2422365696238 = 11218458718446 := by decide
theorem cert_e2422365696238 : check e2422365696238 [[],[]] .three = true := by decide
def e2422365696246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365696246 : Closed e2422365696246 ∧ code e2422365696246 = 11218458718454 := by decide
theorem cert_e2422365696246 : check e2422365696246 [[],[]] .three = true := by decide
def e2422365696726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422365696726 : Closed e2422365696726 ∧ code e2422365696726 = 11218458718934 := by decide
theorem cert_e2422365696726 : check e2422365696726 [[],[]] .three = true := by decide
def e2422365696730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422365696730 : Closed e2422365696730 ∧ code e2422365696730 = 11218458718938 := by decide
theorem cert_e2422365696730 : check e2422365696730 [[],[]] .three = true := by decide
def e2422365696746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422365696746 : Closed e2422365696746 ∧ code e2422365696746 = 11218458718954 := by decide
theorem cert_e2422365696746 : check e2422365696746 [[],[]] .three = true := by decide
def e2422365696798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2422365696798 : Closed e2422365696798 ∧ code e2422365696798 = 11218458719006 := by decide
theorem cert_e2422365696798 : check e2422365696798 [[],[]] .three = true := by decide
def e2422365696822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365696822 : Closed e2422365696822 ∧ code e2422365696822 = 11218458719030 := by decide
theorem cert_e2422365696822 : check e2422365696822 [[],[]] .three = true := by decide
def e2422365696826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365696826 : Closed e2422365696826 ∧ code e2422365696826 = 11218458719034 := by decide
theorem cert_e2422365696826 : check e2422365696826 [[],[]] .three = true := by decide
def e2422365696910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422365696910 : Closed e2422365696910 ∧ code e2422365696910 = 11218458719118 := by decide
theorem cert_e2422365696910 : check e2422365696910 [[],[]] .three = true := by decide
def e2422365696922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365696922 : Closed e2422365696922 ∧ code e2422365696922 = 11218458719130 := by decide
theorem cert_e2422365696922 : check e2422365696922 [[],[]] .three = true := by decide
def e2422365696958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422365696958 : Closed e2422365696958 ∧ code e2422365696958 = 11218458719166 := by decide
theorem cert_e2422365696958 : check e2422365696958 [[],[]] .three = true := by decide
def e2422365696966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2422365696966 : Closed e2422365696966 ∧ code e2422365696966 = 11218458719174 := by decide
theorem cert_e2422365696966 : check e2422365696966 [[],[]] .three = true := by decide
def e2422365697014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422365697014 : Closed e2422365697014 ∧ code e2422365697014 = 11218458719222 := by decide
theorem cert_e2422365697014 : check e2422365697014 [[],[]] .three = true := by decide
def e2422365698166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365698166 : Closed e2422365698166 ∧ code e2422365698166 = 11218458720374 := by decide
theorem cert_e2422365698166 : check e2422365698166 [[],[]] .three = true := by decide
def e2422365698410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422365698410 : Closed e2422365698410 ∧ code e2422365698410 = 11218458720618 := by decide
theorem cert_e2422365698410 : check e2422365698410 [[],[]] .three = true := by decide
def e2422365698446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422365698446 : Closed e2422365698446 ∧ code e2422365698446 = 11218458720654 := by decide
theorem cert_e2422365698446 : check e2422365698446 [[],[]] .three = true := by decide
def e2422365698458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365698458 : Closed e2422365698458 ∧ code e2422365698458 = 11218458720666 := by decide
theorem cert_e2422365698458 : check e2422365698458 [[],[]] .three = true := by decide
def e2422365698494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422365698494 : Closed e2422365698494 ∧ code e2422365698494 = 11218458720702 := by decide
theorem cert_e2422365698494 : check e2422365698494 [[],[]] .three = true := by decide
def e2422365698502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422365698502 : Closed e2422365698502 ∧ code e2422365698502 = 11218458720710 := by decide
theorem cert_e2422365698502 : check e2422365698502 [[],[]] .three = true := by decide
def e2422365698526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422365698526 : Closed e2422365698526 ∧ code e2422365698526 = 11218458720734 := by decide
theorem cert_e2422365698526 : check e2422365698526 [[],[]] .three = true := by decide
def e2422365698542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422365698542 : Closed e2422365698542 ∧ code e2422365698542 = 11218458720750 := by decide
theorem cert_e2422365698542 : check e2422365698542 [[],[]] .three = true := by decide
def e2422365698550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422365698550 : Closed e2422365698550 ∧ code e2422365698550 = 11218458720758 := by decide
theorem cert_e2422365698550 : check e2422365698550 [[],[]] .three = true := by decide
def e2422365698554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422365698554 : Closed e2422365698554 ∧ code e2422365698554 = 11218458720762 := by decide
theorem cert_e2422365698554 : check e2422365698554 [[],[]] .three = true := by decide
def e2422365699270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422365699270 : Closed e2422365699270 ∧ code e2422365699270 = 11218458721478 := by decide
theorem cert_e2422365699270 : check e2422365699270 [[],[]] .three = true := by decide
def e2422365699310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422365699310 : Closed e2422365699310 ∧ code e2422365699310 = 11218458721518 := by decide
theorem cert_e2422365699310 : check e2422365699310 [[],[]] .three = true := by decide
def e2422365699318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422365699318 : Closed e2422365699318 ∧ code e2422365699318 = 11218458721526 := by decide
theorem cert_e2422365699318 : check e2422365699318 [[],[]] .three = true := by decide
def e2422365699702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422365699702 : Closed e2422365699702 ∧ code e2422365699702 = 11218458721910 := by decide
theorem cert_e2422365699702 : check e2422365699702 [[],[]] .three = true := by decide
def e2422365699894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365699894 : Closed e2422365699894 ∧ code e2422365699894 = 11218458722102 := by decide
theorem cert_e2422365699894 : check e2422365699894 [[],[]] .three = true := by decide
def e2422365699898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365699898 : Closed e2422365699898 ∧ code e2422365699898 = 11218458722106 := by decide
theorem cert_e2422365699898 : check e2422365699898 [[],[]] .three = true := by decide
def e2422370687454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422370687454 : Closed e2422370687454 ∧ code e2422370687454 = 11218463709662 := by decide
theorem cert_e2422370687454 : check e2422370687454 [[],[]] .three = true := by decide
def e2422370687478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422370687478 : Closed e2422370687478 ∧ code e2422370687478 = 11218463709686 := by decide
theorem cert_e2422370687478 : check e2422370687478 [[],[]] .three = true := by decide
def e2422370688222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422370688222 : Closed e2422370688222 ∧ code e2422370688222 = 11218463710430 := by decide
theorem cert_e2422370688222 : check e2422370688222 [[],[]] .three = true := by decide
def e2422370688250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422370688250 : Closed e2422370688250 ∧ code e2422370688250 = 11218463710458 := by decide
theorem cert_e2422370688250 : check e2422370688250 [[],[]] .three = true := by decide
def e2422370691550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422370691550 : Closed e2422370691550 ∧ code e2422370691550 = 11218463713758 := by decide
theorem cert_e2422370691550 : check e2422370691550 [[],[]] .three = true := by decide
def e2422370691574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422370691574 : Closed e2422370691574 ∧ code e2422370691574 = 11218463713782 := by decide
theorem cert_e2422370691574 : check e2422370691574 [[],[]] .three = true := by decide
def e2422370694366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422370694366 : Closed e2422370694366 ∧ code e2422370694366 = 11218463716574 := by decide
theorem cert_e2422370694366 : check e2422370694366 [[],[]] .three = true := by decide
def e2422370694394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422370694394 : Closed e2422370694394 ∧ code e2422370694394 = 11218463716602 := by decide
theorem cert_e2422370694394 : check e2422370694394 [[],[]] .three = true := by decide
def e2422370707934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422370707934 : Closed e2422370707934 ∧ code e2422370707934 = 11218463730142 := by decide
theorem cert_e2422370707934 : check e2422370707934 [[],[]] .three = true := by decide
def e2422370707958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422370707958 : Closed e2422370707958 ∧ code e2422370707958 = 11218463730166 := by decide
theorem cert_e2422370707958 : check e2422370707958 [[],[]] .three = true := by decide
def e2422370718942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422370718942 : Closed e2422370718942 ∧ code e2422370718942 = 11218463741150 := by decide
theorem cert_e2422370718942 : check e2422370718942 [[],[]] .three = true := by decide
def e2422370718970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422370718970 : Closed e2422370718970 ∧ code e2422370718970 = 11218463741178 := by decide
theorem cert_e2422370718970 : check e2422370718970 [[],[]] .three = true := by decide
def e2422370785758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422370785758 : Closed e2422370785758 ∧ code e2422370785758 = 11218463807966 := by decide
theorem cert_e2422370785758 : check e2422370785758 [[],[]] .three = true := by decide
def e2422370785782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422370785782 : Closed e2422370785782 ∧ code e2422370785782 = 11218463807990 := by decide
theorem cert_e2422370785782 : check e2422370785782 [[],[]] .three = true := by decide
def e2422370786526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422370786526 : Closed e2422370786526 ∧ code e2422370786526 = 11218463808734 := by decide
theorem cert_e2422370786526 : check e2422370786526 [[],[]] .three = true := by decide
def e2422370786554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422370786554 : Closed e2422370786554 ∧ code e2422370786554 = 11218463808762 := by decide
theorem cert_e2422370786554 : check e2422370786554 [[],[]] .three = true := by decide
def e2422370789854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422370789854 : Closed e2422370789854 ∧ code e2422370789854 = 11218463812062 := by decide
theorem cert_e2422370789854 : check e2422370789854 [[],[]] .three = true := by decide
def e2422370789878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422370789878 : Closed e2422370789878 ∧ code e2422370789878 = 11218463812086 := by decide
theorem cert_e2422370789878 : check e2422370789878 [[],[]] .three = true := by decide
def e2422370792670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422370792670 : Closed e2422370792670 ∧ code e2422370792670 = 11218463814878 := by decide
theorem cert_e2422370792670 : check e2422370792670 [[],[]] .three = true := by decide
def e2422370792698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422370792698 : Closed e2422370792698 ∧ code e2422370792698 = 11218463814906 := by decide
theorem cert_e2422370792698 : check e2422370792698 [[],[]] .three = true := by decide
def e2422370798446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422370798446 : Closed e2422370798446 ∧ code e2422370798446 = 11218463820654 := by decide
theorem cert_e2422370798446 : check e2422370798446 [[],[]] .smaller = true := by decide
def e2422370798454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422370798454 : Closed e2422370798454 ∧ code e2422370798454 = 11218463820662 := by decide
theorem cert_e2422370798454 : check e2422370798454 [[],[]] .smaller = true := by decide
def e2422370798510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422370798510 : Closed e2422370798510 ∧ code e2422370798510 = 11218463820718 := by decide
theorem cert_e2422370798510 : check e2422370798510 [[],[]] .smaller = true := by decide
def e2422370798522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422370798522 : Closed e2422370798522 ∧ code e2422370798522 = 11218463820730 := by decide
theorem cert_e2422370798522 : check e2422370798522 [[],[]] .smaller = true := by decide
def e2422370798550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422370798550 : Closed e2422370798550 ∧ code e2422370798550 = 11218463820758 := by decide
theorem cert_e2422370798550 : check e2422370798550 [[],[]] .smaller = true := by decide
def e2422370798554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422370798554 : Closed e2422370798554 ∧ code e2422370798554 = 11218463820762 := by decide
theorem cert_e2422370798554 : check e2422370798554 [[],[]] .smaller = true := by decide
def e2422370798830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422370798830 : Closed e2422370798830 ∧ code e2422370798830 = 11218463821038 := by decide
theorem cert_e2422370798830 : check e2422370798830 [[],[]] .smaller = true := by decide
def e2422370798838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422370798838 : Closed e2422370798838 ∧ code e2422370798838 = 11218463821046 := by decide
theorem cert_e2422370798838 : check e2422370798838 [[],[]] .smaller = true := by decide
def e2422370799214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422370799214 : Closed e2422370799214 ∧ code e2422370799214 = 11218463821422 := by decide
theorem cert_e2422370799214 : check e2422370799214 [[],[]] .smaller = true := by decide
def e2422370799226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422370799226 : Closed e2422370799226 ∧ code e2422370799226 = 11218463821434 := by decide
theorem cert_e2422370799226 : check e2422370799226 [[],[]] .smaller = true := by decide
def e2422370799414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422370799414 : Closed e2422370799414 ∧ code e2422370799414 = 11218463821622 := by decide
theorem cert_e2422370799414 : check e2422370799414 [[],[]] .smaller = true := by decide
def e2422370799418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422370799418 : Closed e2422370799418 ∧ code e2422370799418 = 11218463821626 := by decide
theorem cert_e2422370799418 : check e2422370799418 [[],[]] .smaller = true := by decide
def e2422370807262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2422370807262 : Closed e2422370807262 ∧ code e2422370807262 = 11218463829470 := by decide
theorem cert_e2422370807262 : check e2422370807262 [[],[]] .three = true := by decide
def e2422370807278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2422370807278 : Closed e2422370807278 ∧ code e2422370807278 = 11218463829486 := by decide
theorem cert_e2422370807278 : check e2422370807278 [[],[]] .three = true := by decide
def e2422370807646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2422370807646 : Closed e2422370807646 ∧ code e2422370807646 = 11218463829854 := by decide
theorem cert_e2422370807646 : check e2422370807646 [[],[]] .three = true := by decide
def e2422370807674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2422370807674 : Closed e2422370807674 ∧ code e2422370807674 = 11218463829882 := by decide
theorem cert_e2422370807674 : check e2422370807674 [[],[]] .three = true := by decide
def e2422370807726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2422370807726 : Closed e2422370807726 ∧ code e2422370807726 = 11218463829934 := by decide
theorem cert_e2422370807726 : check e2422370807726 [[],[]] .three = true := by decide
def e2422370807738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2422370807738 : Closed e2422370807738 ∧ code e2422370807738 = 11218463829946 := by decide
theorem cert_e2422370807738 : check e2422370807738 [[],[]] .three = true := by decide
def e2422370808798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422370808798 : Closed e2422370808798 ∧ code e2422370808798 = 11218463831006 := by decide
theorem cert_e2422370808798 : check e2422370808798 [[],[]] .three = true := by decide
def e2422370808814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422370808814 : Closed e2422370808814 ∧ code e2422370808814 = 11218463831022 := by decide
theorem cert_e2422370808814 : check e2422370808814 [[],[]] .three = true := by decide
def e2422370811102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422370811102 : Closed e2422370811102 ∧ code e2422370811102 = 11218463833310 := by decide
theorem cert_e2422370811102 : check e2422370811102 [[],[]] .three = true := by decide
def e2422370811130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422370811130 : Closed e2422370811130 ∧ code e2422370811130 = 11218463833338 := by decide
theorem cert_e2422370811130 : check e2422370811130 [[],[]] .three = true := by decide
def e2422370811502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422370811502 : Closed e2422370811502 ∧ code e2422370811502 = 11218463833710 := by decide
theorem cert_e2422370811502 : check e2422370811502 [[],[]] .three = true := by decide
def e2422370811514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422370811514 : Closed e2422370811514 ∧ code e2422370811514 = 11218463833722 := by decide
theorem cert_e2422370811514 : check e2422370811514 [[],[]] .three = true := by decide
def e2422370888158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422370888158 : Closed e2422370888158 ∧ code e2422370888158 = 11218463910366 := by decide
theorem cert_e2422370888158 : check e2422370888158 [[],[]] .three = true := by decide
def e2422370888182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422370888182 : Closed e2422370888182 ∧ code e2422370888182 = 11218463910390 := by decide
theorem cert_e2422370888182 : check e2422370888182 [[],[]] .three = true := by decide
def e2422370940126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422370940126 : Closed e2422370940126 ∧ code e2422370940126 = 11218463962334 := by decide
theorem cert_e2422370940126 : check e2422370940126 [[],[]] .three = true := by decide
def e2422370940154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422370940154 : Closed e2422370940154 ∧ code e2422370940154 = 11218463962362 := by decide
theorem cert_e2422370940154 : check e2422370940154 [[],[]] .three = true := by decide
def e2422372257246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2422372257246 : Closed e2422372257246 ∧ code e2422372257246 = 11218465279454 := by decide
theorem cert_e2422372257246 : check e2422372257246 [[],[]] .three = true := by decide
def e2422372257262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2422372257262 : Closed e2422372257262 ∧ code e2422372257262 = 11218465279470 := by decide
theorem cert_e2422372257262 : check e2422372257262 [[],[]] .three = true := by decide
def e2422372257630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2422372257630 : Closed e2422372257630 ∧ code e2422372257630 = 11218465279838 := by decide
theorem cert_e2422372257630 : check e2422372257630 [[],[]] .three = true := by decide
def e2422372257658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2422372257658 : Closed e2422372257658 ∧ code e2422372257658 = 11218465279866 := by decide
theorem cert_e2422372257658 : check e2422372257658 [[],[]] .three = true := by decide
def e2422372257710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2422372257710 : Closed e2422372257710 ∧ code e2422372257710 = 11218465279918 := by decide
theorem cert_e2422372257710 : check e2422372257710 [[],[]] .three = true := by decide
def e2422372257722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2422372257722 : Closed e2422372257722 ∧ code e2422372257722 = 11218465279930 := by decide
theorem cert_e2422372257722 : check e2422372257722 [[],[]] .three = true := by decide
end Blc.Floor43
