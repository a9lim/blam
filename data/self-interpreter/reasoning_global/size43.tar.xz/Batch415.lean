import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373398970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422373398970 : Closed e2422373398970 ∧ code e2422373398970 = 11218466421178 := by decide
theorem cert_e2422373398970 : check e2422373398970 [[],[]] .smaller = true := by decide
def e2422373399018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422373399018 : Closed e2422373399018 ∧ code e2422373399018 = 11218466421226 := by decide
theorem cert_e2422373399018 : check e2422373399018 [[],[]] .smaller = true := by decide
def e2422373399102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422373399102 : Closed e2422373399102 ∧ code e2422373399102 = 11218466421310 := by decide
theorem cert_e2422373399102 : check e2422373399102 [[],[]] .three = true := by decide
def e2422373399150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373399150 : Closed e2422373399150 ∧ code e2422373399150 = 11218466421358 := by decide
theorem cert_e2422373399150 : check e2422373399150 [[],[]] .smaller = true := by decide
def e2422373399162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373399162 : Closed e2422373399162 ∧ code e2422373399162 = 11218466421370 := by decide
theorem cert_e2422373399162 : check e2422373399162 [[],[]] .smaller = true := by decide
def e2422373399326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422373399326 : Closed e2422373399326 ∧ code e2422373399326 = 11218466421534 := by decide
theorem cert_e2422373399326 : check e2422373399326 [[],[]] .smaller = true := by decide
def e2422373399426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373399426 : Closed e2422373399426 ∧ code e2422373399426 = 11218466421634 := by decide
theorem cert_e2422373399426 : check e2422373399426 [[],[]] .smaller = true := by decide
def e2422373399438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422373399438 : Closed e2422373399438 ∧ code e2422373399438 = 11218466421646 := by decide
theorem cert_e2422373399438 : check e2422373399438 [[],[]] .smaller = true := by decide
def e2422373399450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373399450 : Closed e2422373399450 ∧ code e2422373399450 = 11218466421658 := by decide
theorem cert_e2422373399450 : check e2422373399450 [[],[]] .smaller = true := by decide
def e2422373399494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422373399494 : Closed e2422373399494 ∧ code e2422373399494 = 11218466421702 := by decide
theorem cert_e2422373399494 : check e2422373399494 [[],[]] .three = true := by decide
def e2422373399518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e2422373399518 : Closed e2422373399518 ∧ code e2422373399518 = 11218466421726 := by decide
theorem cert_e2422373399518 : check e2422373399518 [[],[]] .three = true := by decide
def e2422373399574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422373399574 : Closed e2422373399574 ∧ code e2422373399574 = 11218466421782 := by decide
theorem cert_e2422373399574 : check e2422373399574 [[],[]] .smaller = true := by decide
def e2422373399646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422373399646 : Closed e2422373399646 ∧ code e2422373399646 = 11218466421854 := by decide
theorem cert_e2422373399646 : check e2422373399646 [[],[]] .three = true := by decide
def e2422373399670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422373399670 : Closed e2422373399670 ∧ code e2422373399670 = 11218466421878 := by decide
theorem cert_e2422373399670 : check e2422373399670 [[],[]] .smaller = true := by decide
def e2422373399766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422373399766 : Closed e2422373399766 ∧ code e2422373399766 = 11218466421974 := by decide
theorem cert_e2422373399766 : check e2422373399766 [[],[]] .smaller = true := by decide
def e2422373399770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422373399770 : Closed e2422373399770 ∧ code e2422373399770 = 11218466421978 := by decide
theorem cert_e2422373399770 : check e2422373399770 [[],[]] .smaller = true := by decide
def e2422373399786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422373399786 : Closed e2422373399786 ∧ code e2422373399786 = 11218466421994 := by decide
theorem cert_e2422373399786 : check e2422373399786 [[],[]] .smaller = true := by decide
def e2422373399862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373399862 : Closed e2422373399862 ∧ code e2422373399862 = 11218466422070 := by decide
theorem cert_e2422373399862 : check e2422373399862 [[],[]] .smaller = true := by decide
def e2422373399866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373399866 : Closed e2422373399866 ∧ code e2422373399866 = 11218466422074 := by decide
theorem cert_e2422373399866 : check e2422373399866 [[],[]] .smaller = true := by decide
def e2422373399938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373399938 : Closed e2422373399938 ∧ code e2422373399938 = 11218466422146 := by decide
theorem cert_e2422373399938 : check e2422373399938 [[],[]] .smaller = true := by decide
def e2422373399950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422373399950 : Closed e2422373399950 ∧ code e2422373399950 = 11218466422158 := by decide
theorem cert_e2422373399950 : check e2422373399950 [[],[]] .smaller = true := by decide
def e2422373399962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373399962 : Closed e2422373399962 ∧ code e2422373399962 = 11218466422170 := by decide
theorem cert_e2422373399962 : check e2422373399962 [[],[]] .smaller = true := by decide
def e2422373400030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2422373400030 : Closed e2422373400030 ∧ code e2422373400030 = 11218466422238 := by decide
theorem cert_e2422373400030 : check e2422373400030 [[],[]] .three = true := by decide
def e2422373400034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422373400034 : Closed e2422373400034 ∧ code e2422373400034 = 11218466422242 := by decide
theorem cert_e2422373400034 : check e2422373400034 [[],[]] .three = true := by decide
def e2422373400046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2422373400046 : Closed e2422373400046 ∧ code e2422373400046 = 11218466422254 := by decide
theorem cert_e2422373400046 : check e2422373400046 [[],[]] .three = true := by decide
def e2422373400110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373400110 : Closed e2422373400110 ∧ code e2422373400110 = 11218466422318 := by decide
theorem cert_e2422373400110 : check e2422373400110 [[],[]] .three = true := by decide
def e2422373400118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373400118 : Closed e2422373400118 ∧ code e2422373400118 = 11218466422326 := by decide
theorem cert_e2422373400118 : check e2422373400118 [[],[]] .three = true := by decide
def e2422373400122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373400122 : Closed e2422373400122 ∧ code e2422373400122 = 11218466422330 := by decide
theorem cert_e2422373400122 : check e2422373400122 [[],[]] .three = true := by decide
def e2422373400206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373400206 : Closed e2422373400206 ∧ code e2422373400206 = 11218466422414 := by decide
theorem cert_e2422373400206 : check e2422373400206 [[],[]] .three = true := by decide
def e2422373400262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373400262 : Closed e2422373400262 ∧ code e2422373400262 = 11218466422470 := by decide
theorem cert_e2422373400262 : check e2422373400262 [[],[]] .three = true := by decide
def e2422373400286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e2422373400286 : Closed e2422373400286 ∧ code e2422373400286 = 11218466422494 := by decide
theorem cert_e2422373400286 : check e2422373400286 [[],[]] .three = true := by decide
def e2422373400290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373400290 : Closed e2422373400290 ∧ code e2422373400290 = 11218466422498 := by decide
theorem cert_e2422373400290 : check e2422373400290 [[],[]] .three = true := by decide
def e2422373400302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2422373400302 : Closed e2422373400302 ∧ code e2422373400302 = 11218466422510 := by decide
theorem cert_e2422373400302 : check e2422373400302 [[],[]] .three = true := by decide
def e2422373400310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e2422373400310 : Closed e2422373400310 ∧ code e2422373400310 = 11218466422518 := by decide
theorem cert_e2422373400310 : check e2422373400310 [[],[]] .three = true := by decide
def e2422373401566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422373401566 : Closed e2422373401566 ∧ code e2422373401566 = 11218466423774 := by decide
theorem cert_e2422373401566 : check e2422373401566 [[],[]] .smaller = true := by decide
def e2422373401582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422373401582 : Closed e2422373401582 ∧ code e2422373401582 = 11218466423790 := by decide
theorem cert_e2422373401582 : check e2422373401582 [[],[]] .smaller = true := by decide
def e2422373403502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422373403502 : Closed e2422373403502 ∧ code e2422373403502 = 11218466425710 := by decide
theorem cert_e2422373403502 : check e2422373403502 [[],[]] .smaller = true := by decide
def e2422373403510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422373403510 : Closed e2422373403510 ∧ code e2422373403510 = 11218466425718 := by decide
theorem cert_e2422373403510 : check e2422373403510 [[],[]] .smaller = true := by decide
def e2422373403566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422373403566 : Closed e2422373403566 ∧ code e2422373403566 = 11218466425774 := by decide
theorem cert_e2422373403566 : check e2422373403566 [[],[]] .smaller = true := by decide
def e2422373403578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422373403578 : Closed e2422373403578 ∧ code e2422373403578 = 11218466425786 := by decide
theorem cert_e2422373403578 : check e2422373403578 [[],[]] .smaller = true := by decide
def e2422373403606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422373403606 : Closed e2422373403606 ∧ code e2422373403606 = 11218466425814 := by decide
theorem cert_e2422373403606 : check e2422373403606 [[],[]] .smaller = true := by decide
def e2422373403610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422373403610 : Closed e2422373403610 ∧ code e2422373403610 = 11218466425818 := by decide
theorem cert_e2422373403610 : check e2422373403610 [[],[]] .smaller = true := by decide
def e2422373403886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373403886 : Closed e2422373403886 ∧ code e2422373403886 = 11218466426094 := by decide
theorem cert_e2422373403886 : check e2422373403886 [[],[]] .smaller = true := by decide
def e2422373403894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373403894 : Closed e2422373403894 ∧ code e2422373403894 = 11218466426102 := by decide
theorem cert_e2422373403894 : check e2422373403894 [[],[]] .smaller = true := by decide
def e2422373404222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2422373404222 : Closed e2422373404222 ∧ code e2422373404222 = 11218466426430 := by decide
theorem cert_e2422373404222 : check e2422373404222 [[],[]] .three = true := by decide
def e2422373404270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373404270 : Closed e2422373404270 ∧ code e2422373404270 = 11218466426478 := by decide
theorem cert_e2422373404270 : check e2422373404270 [[],[]] .smaller = true := by decide
def e2422373404282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373404282 : Closed e2422373404282 ∧ code e2422373404282 = 11218466426490 := by decide
theorem cert_e2422373404282 : check e2422373404282 [[],[]] .smaller = true := by decide
def e2422373404470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373404470 : Closed e2422373404470 ∧ code e2422373404470 = 11218466426678 := by decide
theorem cert_e2422373404470 : check e2422373404470 [[],[]] .smaller = true := by decide
def e2422373404474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373404474 : Closed e2422373404474 ∧ code e2422373404474 = 11218466426682 := by decide
theorem cert_e2422373404474 : check e2422373404474 [[],[]] .smaller = true := by decide
def e2422373404558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2422373404558 : Closed e2422373404558 ∧ code e2422373404558 = 11218466426766 := by decide
theorem cert_e2422373404558 : check e2422373404558 [[],[]] .three = true := by decide
def e2422373409214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 4))))))))))
theorem wire_e2422373409214 : Closed e2422373409214 ∧ code e2422373409214 = 11218466431422 := by decide
theorem cert_e2422373409214 : check e2422373409214 [[],[]] .three = true := by decide
def e2422373409246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422373409246 : Closed e2422373409246 ∧ code e2422373409246 = 11218466431454 := by decide
theorem cert_e2422373409246 : check e2422373409246 [[],[]] .smaller = true := by decide
def e2422373409270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422373409270 : Closed e2422373409270 ∧ code e2422373409270 = 11218466431478 := by decide
theorem cert_e2422373409270 : check e2422373409270 [[],[]] .smaller = true := by decide
def e2422373409274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 4) (.var 0))))))))))
theorem wire_e2422373409274 : Closed e2422373409274 ∧ code e2422373409274 = 11218466431482 := by decide
theorem cert_e2422373409274 : check e2422373409274 [[],[]] .three = true := by decide
def e2422373410222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422373410222 : Closed e2422373410222 ∧ code e2422373410222 = 11218466432430 := by decide
theorem cert_e2422373410222 : check e2422373410222 [[],[]] .smaller = true := by decide
def e2422373410234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422373410234 : Closed e2422373410234 ∧ code e2422373410234 = 11218466432442 := by decide
theorem cert_e2422373410234 : check e2422373410234 [[],[]] .smaller = true := by decide
def e2422373410282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422373410282 : Closed e2422373410282 ∧ code e2422373410282 = 11218466432490 := by decide
theorem cert_e2422373410282 : check e2422373410282 [[],[]] .smaller = true := by decide
def e2422373410366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422373410366 : Closed e2422373410366 ∧ code e2422373410366 = 11218466432574 := by decide
theorem cert_e2422373410366 : check e2422373410366 [[],[]] .three = true := by decide
def e2422373410414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373410414 : Closed e2422373410414 ∧ code e2422373410414 = 11218466432622 := by decide
theorem cert_e2422373410414 : check e2422373410414 [[],[]] .smaller = true := by decide
def e2422373410426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373410426 : Closed e2422373410426 ∧ code e2422373410426 = 11218466432634 := by decide
theorem cert_e2422373410426 : check e2422373410426 [[],[]] .smaller = true := by decide
def e2422373410590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422373410590 : Closed e2422373410590 ∧ code e2422373410590 = 11218466432798 := by decide
theorem cert_e2422373410590 : check e2422373410590 [[],[]] .smaller = true := by decide
def e2422373410690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373410690 : Closed e2422373410690 ∧ code e2422373410690 = 11218466432898 := by decide
theorem cert_e2422373410690 : check e2422373410690 [[],[]] .smaller = true := by decide
def e2422373410702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422373410702 : Closed e2422373410702 ∧ code e2422373410702 = 11218466432910 := by decide
theorem cert_e2422373410702 : check e2422373410702 [[],[]] .smaller = true := by decide
def e2422373410714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373410714 : Closed e2422373410714 ∧ code e2422373410714 = 11218466432922 := by decide
theorem cert_e2422373410714 : check e2422373410714 [[],[]] .smaller = true := by decide
def e2422373410758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422373410758 : Closed e2422373410758 ∧ code e2422373410758 = 11218466432966 := by decide
theorem cert_e2422373410758 : check e2422373410758 [[],[]] .three = true := by decide
def e2422373410782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422373410782 : Closed e2422373410782 ∧ code e2422373410782 = 11218466432990 := by decide
theorem cert_e2422373410782 : check e2422373410782 [[],[]] .three = true := by decide
def e2422373412990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 5))))))))))
theorem wire_e2422373412990 : Closed e2422373412990 ∧ code e2422373412990 = 11218466435198 := by decide
theorem cert_e2422373412990 : check e2422373412990 [[],[]] .three = true := by decide
def e2422373413102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373413102 : Closed e2422373413102 ∧ code e2422373413102 = 11218466435310 := by decide
theorem cert_e2422373413102 : check e2422373413102 [[],[]] .smaller = true := by decide
def e2422373413110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373413110 : Closed e2422373413110 ∧ code e2422373413110 = 11218466435318 := by decide
theorem cert_e2422373413110 : check e2422373413110 [[],[]] .smaller = true := by decide
def e2422373413590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422373413590 : Closed e2422373413590 ∧ code e2422373413590 = 11218466435798 := by decide
theorem cert_e2422373413590 : check e2422373413590 [[],[]] .smaller = true := by decide
def e2422373413594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422373413594 : Closed e2422373413594 ∧ code e2422373413594 = 11218466435802 := by decide
theorem cert_e2422373413594 : check e2422373413594 [[],[]] .smaller = true := by decide
def e2422373413610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422373413610 : Closed e2422373413610 ∧ code e2422373413610 = 11218466435818 := by decide
theorem cert_e2422373413610 : check e2422373413610 [[],[]] .smaller = true := by decide
def e2422373413686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373413686 : Closed e2422373413686 ∧ code e2422373413686 = 11218466435894 := by decide
theorem cert_e2422373413686 : check e2422373413686 [[],[]] .smaller = true := by decide
def e2422373413690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373413690 : Closed e2422373413690 ∧ code e2422373413690 = 11218466435898 := by decide
theorem cert_e2422373413690 : check e2422373413690 [[],[]] .smaller = true := by decide
def e2422373413762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373413762 : Closed e2422373413762 ∧ code e2422373413762 = 11218466435970 := by decide
theorem cert_e2422373413762 : check e2422373413762 [[],[]] .smaller = true := by decide
def e2422373413774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422373413774 : Closed e2422373413774 ∧ code e2422373413774 = 11218466435982 := by decide
theorem cert_e2422373413774 : check e2422373413774 [[],[]] .smaller = true := by decide
def e2422373413786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373413786 : Closed e2422373413786 ∧ code e2422373413786 = 11218466435994 := by decide
theorem cert_e2422373413786 : check e2422373413786 [[],[]] .smaller = true := by decide
def e2422373413854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373413854 : Closed e2422373413854 ∧ code e2422373413854 = 11218466436062 := by decide
theorem cert_e2422373413854 : check e2422373413854 [[],[]] .three = true := by decide
def e2422373413858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422373413858 : Closed e2422373413858 ∧ code e2422373413858 = 11218466436066 := by decide
theorem cert_e2422373413858 : check e2422373413858 [[],[]] .three = true := by decide
def e2422373413870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373413870 : Closed e2422373413870 ∧ code e2422373413870 = 11218466436078 := by decide
theorem cert_e2422373413870 : check e2422373413870 [[],[]] .three = true := by decide
def e2422373414974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373414974 : Closed e2422373414974 ∧ code e2422373414974 = 11218466437182 := by decide
theorem cert_e2422373414974 : check e2422373414974 [[],[]] .three = true := by decide
def e2422373415022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373415022 : Closed e2422373415022 ∧ code e2422373415022 = 11218466437230 := by decide
theorem cert_e2422373415022 : check e2422373415022 [[],[]] .three = true := by decide
def e2422373415034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373415034 : Closed e2422373415034 ∧ code e2422373415034 = 11218466437242 := by decide
theorem cert_e2422373415034 : check e2422373415034 [[],[]] .three = true := by decide
def e2422373415310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373415310 : Closed e2422373415310 ∧ code e2422373415310 = 11218466437518 := by decide
theorem cert_e2422373415310 : check e2422373415310 [[],[]] .three = true := by decide
def e2422373415366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373415366 : Closed e2422373415366 ∧ code e2422373415366 = 11218466437574 := by decide
theorem cert_e2422373415366 : check e2422373415366 [[],[]] .three = true := by decide
def e2422373415390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373415390 : Closed e2422373415390 ∧ code e2422373415390 = 11218466437598 := by decide
theorem cert_e2422373415390 : check e2422373415390 [[],[]] .three = true := by decide
def e2422373415394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373415394 : Closed e2422373415394 ∧ code e2422373415394 = 11218466437602 := by decide
theorem cert_e2422373415394 : check e2422373415394 [[],[]] .three = true := by decide
def e2422373415406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373415406 : Closed e2422373415406 ∧ code e2422373415406 = 11218466437614 := by decide
theorem cert_e2422373415406 : check e2422373415406 [[],[]] .three = true := by decide
def e2422373415414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373415414 : Closed e2422373415414 ∧ code e2422373415414 = 11218466437622 := by decide
theorem cert_e2422373415414 : check e2422373415414 [[],[]] .three = true := by decide
def e2422373484478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422373484478 : Closed e2422373484478 ∧ code e2422373484478 = 11218466506686 := by decide
theorem cert_e2422373484478 : check e2422373484478 [[],[]] .smaller = true := by decide
def e2422373484526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422373484526 : Closed e2422373484526 ∧ code e2422373484526 = 11218466506734 := by decide
theorem cert_e2422373484526 : check e2422373484526 [[],[]] .smaller = true := by decide
def e2422373488318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2422373488318 : Closed e2422373488318 ∧ code e2422373488318 = 11218466510526 := by decide
theorem cert_e2422373488318 : check e2422373488318 [[],[]] .three = true := by decide
def e2422373488350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422373488350 : Closed e2422373488350 ∧ code e2422373488350 = 11218466510558 := by decide
theorem cert_e2422373488350 : check e2422373488350 [[],[]] .smaller = true := by decide
def e2422373488374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422373488374 : Closed e2422373488374 ∧ code e2422373488374 = 11218466510582 := by decide
theorem cert_e2422373488374 : check e2422373488374 [[],[]] .smaller = true := by decide
def e2422373488378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2422373488378 : Closed e2422373488378 ∧ code e2422373488378 = 11218466510586 := by decide
theorem cert_e2422373488378 : check e2422373488378 [[],[]] .three = true := by decide
def e2422373488478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422373488478 : Closed e2422373488478 ∧ code e2422373488478 = 11218466510686 := by decide
theorem cert_e2422373488478 : check e2422373488478 [[],[]] .smaller = true := by decide
def e2422373488506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422373488506 : Closed e2422373488506 ∧ code e2422373488506 = 11218466510714 := by decide
theorem cert_e2422373488506 : check e2422373488506 [[],[]] .smaller = true := by decide
def e2422373488598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422373488598 : Closed e2422373488598 ∧ code e2422373488598 = 11218466510806 := by decide
theorem cert_e2422373488598 : check e2422373488598 [[],[]] .smaller = true := by decide
def e2422373488602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422373488602 : Closed e2422373488602 ∧ code e2422373488602 = 11218466510810 := by decide
theorem cert_e2422373488602 : check e2422373488602 [[],[]] .smaller = true := by decide
def e2422373488618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2422373488618 : Closed e2422373488618 ∧ code e2422373488618 = 11218466510826 := by decide
theorem cert_e2422373488618 : check e2422373488618 [[],[]] .three = true := by decide
def e2422373489086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422373489086 : Closed e2422373489086 ∧ code e2422373489086 = 11218466511294 := by decide
theorem cert_e2422373489086 : check e2422373489086 [[],[]] .three = true := by decide
def e2422373489118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422373489118 : Closed e2422373489118 ∧ code e2422373489118 = 11218466511326 := by decide
theorem cert_e2422373489118 : check e2422373489118 [[],[]] .smaller = true := by decide
def e2422373489142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422373489142 : Closed e2422373489142 ∧ code e2422373489142 = 11218466511350 := by decide
theorem cert_e2422373489142 : check e2422373489142 [[],[]] .smaller = true := by decide
def e2422373489146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422373489146 : Closed e2422373489146 ∧ code e2422373489146 = 11218466511354 := by decide
theorem cert_e2422373489146 : check e2422373489146 [[],[]] .three = true := by decide
def e2422373489790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 5))))))))))
theorem wire_e2422373489790 : Closed e2422373489790 ∧ code e2422373489790 = 11218466511998 := by decide
theorem cert_e2422373489790 : check e2422373489790 [[],[]] .three = true := by decide
def e2422373489886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422373489886 : Closed e2422373489886 ∧ code e2422373489886 = 11218466512094 := by decide
theorem cert_e2422373489886 : check e2422373489886 [[],[]] .smaller = true := by decide
def e2422373489914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422373489914 : Closed e2422373489914 ∧ code e2422373489914 = 11218466512122 := by decide
theorem cert_e2422373489914 : check e2422373489914 [[],[]] .smaller = true := by decide
def e2422373490238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2422373490238 : Closed e2422373490238 ∧ code e2422373490238 = 11218466512446 := by decide
theorem cert_e2422373490238 : check e2422373490238 [[],[]] .smaller = true := by decide
def e2422373490462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2422373490462 : Closed e2422373490462 ∧ code e2422373490462 = 11218466512670 := by decide
theorem cert_e2422373490462 : check e2422373490462 [[],[]] .smaller = true := by decide
def e2422373490486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373490486 : Closed e2422373490486 ∧ code e2422373490486 = 11218466512694 := by decide
theorem cert_e2422373490486 : check e2422373490486 [[],[]] .smaller = true := by decide
def e2422373490490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373490490 : Closed e2422373490490 ∧ code e2422373490490 = 11218466512698 := by decide
theorem cert_e2422373490490 : check e2422373490490 [[],[]] .smaller = true := by decide
def e2422373490574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.lam (.var 2))))))))))
theorem wire_e2422373490574 : Closed e2422373490574 ∧ code e2422373490574 = 11218466512782 := by decide
theorem cert_e2422373490574 : check e2422373490574 [[],[]] .three = true := by decide
def e2422373490586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373490586 : Closed e2422373490586 ∧ code e2422373490586 = 11218466512794 := by decide
theorem cert_e2422373490586 : check e2422373490586 [[],[]] .three = true := by decide
def e2422373490622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 4)))))))))
theorem wire_e2422373490622 : Closed e2422373490622 ∧ code e2422373490622 = 11218466512830 := by decide
theorem cert_e2422373490622 : check e2422373490622 [[],[]] .three = true := by decide
def e2422373504686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422373504686 : Closed e2422373504686 ∧ code e2422373504686 = 11218466526894 := by decide
theorem cert_e2422373504686 : check e2422373504686 [[],[]] .smaller = true := by decide
def e2422373504698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422373504698 : Closed e2422373504698 ∧ code e2422373504698 = 11218466526906 := by decide
theorem cert_e2422373504698 : check e2422373504698 [[],[]] .smaller = true := by decide
def e2422373504746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422373504746 : Closed e2422373504746 ∧ code e2422373504746 = 11218466526954 := by decide
theorem cert_e2422373504746 : check e2422373504746 [[],[]] .smaller = true := by decide
def e2422373504938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422373504938 : Closed e2422373504938 ∧ code e2422373504938 = 11218466527146 := by decide
theorem cert_e2422373504938 : check e2422373504938 [[],[]] .smaller = true := by decide
def e2422373505070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422373505070 : Closed e2422373505070 ∧ code e2422373505070 = 11218466527278 := by decide
theorem cert_e2422373505070 : check e2422373505070 [[],[]] .smaller = true := by decide
def e2422373505246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422373505246 : Closed e2422373505246 ∧ code e2422373505246 = 11218466527454 := by decide
theorem cert_e2422373505246 : check e2422373505246 [[],[]] .three = true := by decide
def e2422373505262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422373505262 : Closed e2422373505262 ∧ code e2422373505262 = 11218466527470 := by decide
theorem cert_e2422373505262 : check e2422373505262 [[],[]] .smaller = true := by decide
def e2422373505270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422373505270 : Closed e2422373505270 ∧ code e2422373505270 = 11218466527478 := by decide
theorem cert_e2422373505270 : check e2422373505270 [[],[]] .smaller = true := by decide
def e2422373505274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422373505274 : Closed e2422373505274 ∧ code e2422373505274 = 11218466527482 := by decide
theorem cert_e2422373505274 : check e2422373505274 [[],[]] .three = true := by decide
def e2422373505454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422373505454 : Closed e2422373505454 ∧ code e2422373505454 = 11218466527662 := by decide
theorem cert_e2422373505454 : check e2422373505454 [[],[]] .smaller = true := by decide
def e2422373505466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422373505466 : Closed e2422373505466 ∧ code e2422373505466 = 11218466527674 := by decide
theorem cert_e2422373505466 : check e2422373505466 [[],[]] .smaller = true := by decide
def e2422373505514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422373505514 : Closed e2422373505514 ∧ code e2422373505514 = 11218466527722 := by decide
theorem cert_e2422373505514 : check e2422373505514 [[],[]] .smaller = true := by decide
def e2422373505598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422373505598 : Closed e2422373505598 ∧ code e2422373505598 = 11218466527806 := by decide
theorem cert_e2422373505598 : check e2422373505598 [[],[]] .three = true := by decide
def e2422373505646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373505646 : Closed e2422373505646 ∧ code e2422373505646 = 11218466527854 := by decide
theorem cert_e2422373505646 : check e2422373505646 [[],[]] .smaller = true := by decide
def e2422373505658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373505658 : Closed e2422373505658 ∧ code e2422373505658 = 11218466527866 := by decide
theorem cert_e2422373505658 : check e2422373505658 [[],[]] .smaller = true := by decide
def e2422373505822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422373505822 : Closed e2422373505822 ∧ code e2422373505822 = 11218466528030 := by decide
theorem cert_e2422373505822 : check e2422373505822 [[],[]] .smaller = true := by decide
def e2422373505922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373505922 : Closed e2422373505922 ∧ code e2422373505922 = 11218466528130 := by decide
theorem cert_e2422373505922 : check e2422373505922 [[],[]] .smaller = true := by decide
def e2422373505934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422373505934 : Closed e2422373505934 ∧ code e2422373505934 = 11218466528142 := by decide
theorem cert_e2422373505934 : check e2422373505934 [[],[]] .smaller = true := by decide
def e2422373505946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373505946 : Closed e2422373505946 ∧ code e2422373505946 = 11218466528154 := by decide
theorem cert_e2422373505946 : check e2422373505946 [[],[]] .smaller = true := by decide
def e2422373505990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422373505990 : Closed e2422373505990 ∧ code e2422373505990 = 11218466528198 := by decide
theorem cert_e2422373505990 : check e2422373505990 [[],[]] .three = true := by decide
def e2422373506014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e2422373506014 : Closed e2422373506014 ∧ code e2422373506014 = 11218466528222 := by decide
theorem cert_e2422373506014 : check e2422373506014 [[],[]] .three = true := by decide
def e2422373506142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422373506142 : Closed e2422373506142 ∧ code e2422373506142 = 11218466528350 := by decide
theorem cert_e2422373506142 : check e2422373506142 [[],[]] .three = true := by decide
def e2422373506158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422373506158 : Closed e2422373506158 ∧ code e2422373506158 = 11218466528366 := by decide
theorem cert_e2422373506158 : check e2422373506158 [[],[]] .smaller = true := by decide
def e2422373506170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422373506170 : Closed e2422373506170 ∧ code e2422373506170 = 11218466528378 := by decide
theorem cert_e2422373506170 : check e2422373506170 [[],[]] .smaller = true := by decide
def e2422373506334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422373506334 : Closed e2422373506334 ∧ code e2422373506334 = 11218466528542 := by decide
theorem cert_e2422373506334 : check e2422373506334 [[],[]] .smaller = true := by decide
def e2422373506502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422373506502 : Closed e2422373506502 ∧ code e2422373506502 = 11218466528710 := by decide
theorem cert_e2422373506502 : check e2422373506502 [[],[]] .smaller = true := by decide
def e2422373506526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2422373506526 : Closed e2422373506526 ∧ code e2422373506526 = 11218466528734 := by decide
theorem cert_e2422373506526 : check e2422373506526 [[],[]] .three = true := by decide
def e2422373506530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422373506530 : Closed e2422373506530 ∧ code e2422373506530 = 11218466528738 := by decide
theorem cert_e2422373506530 : check e2422373506530 [[],[]] .three = true := by decide
def e2422373506542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2422373506542 : Closed e2422373506542 ∧ code e2422373506542 = 11218466528750 := by decide
theorem cert_e2422373506542 : check e2422373506542 [[],[]] .three = true := by decide
def e2422373506570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422373506570 : Closed e2422373506570 ∧ code e2422373506570 = 11218466528778 := by decide
theorem cert_e2422373506570 : check e2422373506570 [[],[]] .smaller = true := by decide
def e2422373506606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373506606 : Closed e2422373506606 ∧ code e2422373506606 = 11218466528814 := by decide
theorem cert_e2422373506606 : check e2422373506606 [[],[]] .smaller = true := by decide
def e2422373506614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373506614 : Closed e2422373506614 ∧ code e2422373506614 = 11218466528822 := by decide
theorem cert_e2422373506614 : check e2422373506614 [[],[]] .smaller = true := by decide
def e2422373506618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373506618 : Closed e2422373506618 ∧ code e2422373506618 = 11218466528826 := by decide
theorem cert_e2422373506618 : check e2422373506618 [[],[]] .smaller = true := by decide
def e2422373506666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422373506666 : Closed e2422373506666 ∧ code e2422373506666 = 11218466528874 := by decide
theorem cert_e2422373506666 : check e2422373506666 [[],[]] .smaller = true := by decide
def e2422373506690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373506690 : Closed e2422373506690 ∧ code e2422373506690 = 11218466528898 := by decide
theorem cert_e2422373506690 : check e2422373506690 [[],[]] .smaller = true := by decide
def e2422373506702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373506702 : Closed e2422373506702 ∧ code e2422373506702 = 11218466528910 := by decide
theorem cert_e2422373506702 : check e2422373506702 [[],[]] .smaller = true := by decide
def e2422373506714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373506714 : Closed e2422373506714 ∧ code e2422373506714 = 11218466528922 := by decide
theorem cert_e2422373506714 : check e2422373506714 [[],[]] .smaller = true := by decide
def e2422373506758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373506758 : Closed e2422373506758 ∧ code e2422373506758 = 11218466528966 := by decide
theorem cert_e2422373506758 : check e2422373506758 [[],[]] .smaller = true := by decide
def e2422373506782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2422373506782 : Closed e2422373506782 ∧ code e2422373506782 = 11218466528990 := by decide
theorem cert_e2422373506782 : check e2422373506782 [[],[]] .three = true := by decide
def e2422373506786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373506786 : Closed e2422373506786 ∧ code e2422373506786 = 11218466528994 := by decide
theorem cert_e2422373506786 : check e2422373506786 [[],[]] .smaller = true := by decide
def e2422373506798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 2))))))))
theorem wire_e2422373506798 : Closed e2422373506798 ∧ code e2422373506798 = 11218466529006 := by decide
theorem cert_e2422373506798 : check e2422373506798 [[],[]] .smaller = true := by decide
def e2422373506806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2422373506806 : Closed e2422373506806 ∧ code e2422373506806 = 11218466529014 := by decide
theorem cert_e2422373506806 : check e2422373506806 [[],[]] .three = true := by decide
def e2422373506838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422373506838 : Closed e2422373506838 ∧ code e2422373506838 = 11218466529046 := by decide
theorem cert_e2422373506838 : check e2422373506838 [[],[]] .three = true := by decide
def e2422373506842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422373506842 : Closed e2422373506842 ∧ code e2422373506842 = 11218466529050 := by decide
theorem cert_e2422373506842 : check e2422373506842 [[],[]] .three = true := by decide
def e2422373506886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422373506886 : Closed e2422373506886 ∧ code e2422373506886 = 11218466529094 := by decide
theorem cert_e2422373506886 : check e2422373506886 [[],[]] .three = true := by decide
def e2422373506910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e2422373506910 : Closed e2422373506910 ∧ code e2422373506910 = 11218466529118 := by decide
theorem cert_e2422373506910 : check e2422373506910 [[],[]] .three = true := by decide
end Blc.Floor43
