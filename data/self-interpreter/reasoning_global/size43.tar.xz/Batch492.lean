import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408408494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422408408494 : Closed e2422408408494 ∧ code e2422408408494 = 11218501430702 := by decide
theorem cert_e2422408408494 : check e2422408408494 [[],[]] .chain = true := by decide
def e2422408408506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422408408506 : Closed e2422408408506 ∧ code e2422408408506 = 11218501430714 := by decide
theorem cert_e2422408408506 : check e2422408408506 [[],[]] .chain = true := by decide
def e2422408408534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422408408534 : Closed e2422408408534 ∧ code e2422408408534 = 11218501430742 := by decide
theorem cert_e2422408408534 : check e2422408408534 [[],[]] .chain = true := by decide
def e2422408408538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422408408538 : Closed e2422408408538 ∧ code e2422408408538 = 11218501430746 := by decide
theorem cert_e2422408408538 : check e2422408408538 [[],[]] .chain = true := by decide
def e2422408408618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422408408618 : Closed e2422408408618 ∧ code e2422408408618 = 11218501430826 := by decide
theorem cert_e2422408408618 : check e2422408408618 [[],[]] .chain = true := by decide
def e2422408408714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408408714 : Closed e2422408408714 ∧ code e2422408408714 = 11218501430922 := by decide
theorem cert_e2422408408714 : check e2422408408714 [[],[]] .chain = true := by decide
def e2422408408738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408408738 : Closed e2422408408738 ∧ code e2422408408738 = 11218501430946 := by decide
theorem cert_e2422408408738 : check e2422408408738 [[],[]] .chain = true := by decide
def e2422408408750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422408408750 : Closed e2422408408750 ∧ code e2422408408750 = 11218501430958 := by decide
theorem cert_e2422408408750 : check e2422408408750 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408408758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422408408758 : Closed e2422408408758 ∧ code e2422408408758 = 11218501430966 := by decide
theorem cert_e2422408408758 : check e2422408408758 [[],[]] .chain = true := by decide
def e2422408408762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422408408762 : Closed e2422408408762 ∧ code e2422408408762 = 11218501430970 := by decide
theorem cert_e2422408408762 : check e2422408408762 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408408790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422408408790 : Closed e2422408408790 ∧ code e2422408408790 = 11218501430998 := by decide
theorem cert_e2422408408790 : check e2422408408790 [[],[]] .chain = true := by decide
def e2422408408794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422408408794 : Closed e2422408408794 ∧ code e2422408408794 = 11218501431002 := by decide
theorem cert_e2422408408794 : check e2422408408794 [[],[]] .chain = true := by decide
def e2422408408810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422408408810 : Closed e2422408408810 ∧ code e2422408408810 = 11218501431018 := by decide
theorem cert_e2422408408810 : check e2422408408810 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408409430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422408409430 : Closed e2422408409430 ∧ code e2422408409430 = 11218501431638 := by decide
theorem cert_e2422408409430 : check e2422408409430 [[],[]] .chain = true := by decide
def e2422408409434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422408409434 : Closed e2422408409434 ∧ code e2422408409434 = 11218501431642 := by decide
theorem cert_e2422408409434 : check e2422408409434 [[],[]] .chain = true := by decide
def e2422408409450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422408409450 : Closed e2422408409450 ∧ code e2422408409450 = 11218501431658 := by decide
theorem cert_e2422408409450 : check e2422408409450 [[],[]] .chain = true := by decide
def e2422408410198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2422408410198 : Closed e2422408410198 ∧ code e2422408410198 = 11218501432406 := by decide
theorem cert_e2422408410198 : check e2422408410198 [[],[]] .chain = true := by decide
def e2422408410202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2422408410202 : Closed e2422408410202 ∧ code e2422408410202 = 11218501432410 := by decide
theorem cert_e2422408410202 : check e2422408410202 [[],[]] .chain = true := by decide
def e2422408410390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408410390 : Closed e2422408410390 ∧ code e2422408410390 = 11218501432598 := by decide
theorem cert_e2422408410390 : check e2422408410390 [[],[]] .chain = true := by decide
def e2422408410466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408410466 : Closed e2422408410466 ∧ code e2422408410466 = 11218501432674 := by decide
theorem cert_e2422408410466 : check e2422408410466 [[],[]] .chain = true := by decide
def e2422408410478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422408410478 : Closed e2422408410478 ∧ code e2422408410478 = 11218501432686 := by decide
theorem cert_e2422408410478 : check e2422408410478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408410486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422408410486 : Closed e2422408410486 ∧ code e2422408410486 = 11218501432694 := by decide
def e2422408410506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408410506 : Closed e2422408410506 ∧ code e2422408410506 = 11218501432714 := by decide
theorem cert_e2422408410506 : check e2422408410506 [[],[]] .chain = true := by decide
def e2422408410530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408410530 : Closed e2422408410530 ∧ code e2422408410530 = 11218501432738 := by decide
theorem cert_e2422408410530 : check e2422408410530 [[],[]] .chain = true := by decide
def e2422408410542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422408410542 : Closed e2422408410542 ∧ code e2422408410542 = 11218501432750 := by decide
theorem cert_e2422408410542 : check e2422408410542 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408410550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2422408410550 : Closed e2422408410550 ∧ code e2422408410550 = 11218501432758 := by decide
theorem cert_e2422408410550 : check e2422408410550 [[],[]] .chain = true := by decide
def e2422408410554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422408410554 : Closed e2422408410554 ∧ code e2422408410554 = 11218501432762 := by decide
theorem cert_e2422408410554 : check e2422408410554 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408410582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422408410582 : Closed e2422408410582 ∧ code e2422408410582 = 11218501432790 := by decide
theorem cert_e2422408410582 : check e2422408410582 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408410586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422408410586 : Closed e2422408410586 ∧ code e2422408410586 = 11218501432794 := by decide
theorem cert_e2422408410586 : check e2422408410586 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408410666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422408410666 : Closed e2422408410666 ∧ code e2422408410666 = 11218501432874 := by decide
theorem cert_e2422408410666 : check e2422408410666 [[],[]] .chain = true := by decide
def e2422408410762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408410762 : Closed e2422408410762 ∧ code e2422408410762 = 11218501432970 := by decide
theorem cert_e2422408410762 : check e2422408410762 [[],[]] .chain = true := by decide
def e2422408410786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408410786 : Closed e2422408410786 ∧ code e2422408410786 = 11218501432994 := by decide
theorem cert_e2422408410786 : check e2422408410786 [[],[]] .chain = true := by decide
def e2422408410798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422408410798 : Closed e2422408410798 ∧ code e2422408410798 = 11218501433006 := by decide
theorem cert_e2422408410798 : check e2422408410798 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408410806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422408410806 : Closed e2422408410806 ∧ code e2422408410806 = 11218501433014 := by decide
theorem cert_e2422408410806 : check e2422408410806 [[],[]] .chain = true := by decide
def e2422408410810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422408410810 : Closed e2422408410810 ∧ code e2422408410810 = 11218501433018 := by decide
theorem cert_e2422408410810 : check e2422408410810 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408410838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422408410838 : Closed e2422408410838 ∧ code e2422408410838 = 11218501433046 := by decide
theorem cert_e2422408410838 : check e2422408410838 [[],[]] .chain = true := by decide
def e2422408410842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422408410842 : Closed e2422408410842 ∧ code e2422408410842 = 11218501433050 := by decide
theorem cert_e2422408410842 : check e2422408410842 [[],[]] .chain = true := by decide
def e2422408410858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422408410858 : Closed e2422408410858 ∧ code e2422408410858 = 11218501433066 := by decide
theorem cert_e2422408410858 : check e2422408410858 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408410966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422408410966 : Closed e2422408410966 ∧ code e2422408410966 = 11218501433174 := by decide
def e2422408410970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422408410970 : Closed e2422408410970 ∧ code e2422408410970 = 11218501433178 := by decide
theorem cert_e2422408410970 : check e2422408410970 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408410986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422408410986 : Closed e2422408410986 ∧ code e2422408410986 = 11218501433194 := by decide
def e2422408413550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 1))) (.var 2))))))
theorem wire_e2422408413550 : Closed e2422408413550 ∧ code e2422408413550 = 11218501435758 := by decide
theorem cert_e2422408413550 : check e2422408413550 [[],[]] .chain = true := by decide
def e2422408413558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 2))) (.var 1))))))
theorem wire_e2422408413558 : Closed e2422408413558 ∧ code e2422408413558 = 11218501435766 := by decide
theorem cert_e2422408413558 : check e2422408413558 [[],[]] .chain = true := by decide
def e2422408415086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1))) (.var 2))))))
theorem wire_e2422408415086 : Closed e2422408415086 ∧ code e2422408415086 = 11218501437294 := by decide
theorem cert_e2422408415086 : check e2422408415086 [[],[]] .chain = true := by decide
def e2422408415094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2))) (.var 1))))))
theorem wire_e2422408415094 : Closed e2422408415094 ∧ code e2422408415094 = 11218501437302 := by decide
theorem cert_e2422408415094 : check e2422408415094 [[],[]] .chain = true := by decide
def e2422408415150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.var 2))))))
theorem wire_e2422408415150 : Closed e2422408415150 ∧ code e2422408415150 = 11218501437358 := by decide
theorem cert_e2422408415150 : check e2422408415150 [[],[]] .chain = true := by decide
def e2422408415162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))) (.var 0))))))
theorem wire_e2422408415162 : Closed e2422408415162 ∧ code e2422408415162 = 11218501437370 := by decide
theorem cert_e2422408415162 : check e2422408415162 [[],[]] .chain = true := by decide
def e2422408415190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))) (.var 1))))))
theorem wire_e2422408415190 : Closed e2422408415190 ∧ code e2422408415190 = 11218501437398 := by decide
theorem cert_e2422408415190 : check e2422408415190 [[],[]] .chain = true := by decide
def e2422408415194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))) (.var 0))))))
theorem wire_e2422408415194 : Closed e2422408415194 ∧ code e2422408415194 = 11218501437402 := by decide
theorem cert_e2422408415194 : check e2422408415194 [[],[]] .chain = true := by decide
def e2422408416622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1))) (.var 2))))))
theorem wire_e2422408416622 : Closed e2422408416622 ∧ code e2422408416622 = 11218501438830 := by decide
theorem cert_e2422408416622 : checkPay e2422408416622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422408416630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2))) (.var 1))))))
theorem wire_e2422408416630 : Closed e2422408416630 ∧ code e2422408416630 = 11218501438838 := by decide
theorem cert_e2422408416630 : check e2422408416630 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408418158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422408418158 : Closed e2422408418158 ∧ code e2422408418158 = 11218501440366 := by decide
theorem cert_e2422408418158 : check e2422408418158 [[],[]] .chain = true := by decide
def e2422408418166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422408418166 : Closed e2422408418166 ∧ code e2422408418166 = 11218501440374 := by decide
theorem cert_e2422408418166 : check e2422408418166 [[],[]] .chain = true := by decide
def e2422408418222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422408418222 : Closed e2422408418222 ∧ code e2422408418222 = 11218501440430 := by decide
theorem cert_e2422408418222 : check e2422408418222 [[],[]] .chain = true := by decide
def e2422408418234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422408418234 : Closed e2422408418234 ∧ code e2422408418234 = 11218501440442 := by decide
theorem cert_e2422408418234 : check e2422408418234 [[],[]] .chain = true := by decide
def e2422408418262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422408418262 : Closed e2422408418262 ∧ code e2422408418262 = 11218501440470 := by decide
theorem cert_e2422408418262 : check e2422408418262 [[],[]] .chain = true := by decide
def e2422408418266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422408418266 : Closed e2422408418266 ∧ code e2422408418266 = 11218501440474 := by decide
theorem cert_e2422408418266 : check e2422408418266 [[],[]] .chain = true := by decide
def e2422408418542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408418542 : Closed e2422408418542 ∧ code e2422408418542 = 11218501440750 := by decide
theorem cert_e2422408418542 : check e2422408418542 [[],[]] .chain = true := by decide
def e2422408418550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408418550 : Closed e2422408418550 ∧ code e2422408418550 = 11218501440758 := by decide
theorem cert_e2422408418550 : check e2422408418550 [[],[]] .chain = true := by decide
def e2422408418926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408418926 : Closed e2422408418926 ∧ code e2422408418926 = 11218501441134 := by decide
theorem cert_e2422408418926 : check e2422408418926 [[],[]] .chain = true := by decide
def e2422408418938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408418938 : Closed e2422408418938 ∧ code e2422408418938 = 11218501441146 := by decide
theorem cert_e2422408418938 : check e2422408418938 [[],[]] .chain = true := by decide
def e2422408419126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408419126 : Closed e2422408419126 ∧ code e2422408419126 = 11218501441334 := by decide
theorem cert_e2422408419126 : check e2422408419126 [[],[]] .chain = true := by decide
def e2422408419130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408419130 : Closed e2422408419130 ∧ code e2422408419130 = 11218501441338 := by decide
theorem cert_e2422408419130 : check e2422408419130 [[],[]] .chain = true := by decide
def e2422408419566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422408419566 : Closed e2422408419566 ∧ code e2422408419566 = 11218501441774 := by decide
theorem cert_e2422408419566 : check e2422408419566 [[],[]] .chain = true := by decide
def e2422408419574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422408419574 : Closed e2422408419574 ∧ code e2422408419574 = 11218501441782 := by decide
theorem cert_e2422408419574 : check e2422408419574 [[],[]] .chain = true := by decide
def e2422408420126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422408420126 : Closed e2422408420126 ∧ code e2422408420126 = 11218501442334 := by decide
theorem cert_e2422408420126 : check e2422408420126 [[],[]] .chain = true := by decide
def e2422408420238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422408420238 : Closed e2422408420238 ∧ code e2422408420238 = 11218501442446 := by decide
theorem cert_e2422408420238 : check e2422408420238 [[],[]] .chain = true := by decide
def e2422408420462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422408420462 : Closed e2422408420462 ∧ code e2422408420462 = 11218501442670 := by decide
theorem cert_e2422408420462 : check e2422408420462 [[],[]] .chain = true := by decide
def e2422408420474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422408420474 : Closed e2422408420474 ∧ code e2422408420474 = 11218501442682 := by decide
theorem cert_e2422408420474 : check e2422408420474 [[],[]] .chain = true := by decide
def e2422408420638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422408420638 : Closed e2422408420638 ∧ code e2422408420638 = 11218501442846 := by decide
theorem cert_e2422408420638 : check e2422408420638 [[],[]] .chain = true := by decide
def e2422408420806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422408420806 : Closed e2422408420806 ∧ code e2422408420806 = 11218501443014 := by decide
theorem cert_e2422408420806 : check e2422408420806 [[],[]] .chain = true := by decide
def e2422408420918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422408420918 : Closed e2422408420918 ∧ code e2422408420918 = 11218501443126 := by decide
theorem cert_e2422408420918 : check e2422408420918 [[],[]] .chain = true := by decide
def e2422408420922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422408420922 : Closed e2422408420922 ∧ code e2422408420922 = 11218501443130 := by decide
theorem cert_e2422408420922 : check e2422408420922 [[],[]] .chain = true := by decide
def e2422408421006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422408421006 : Closed e2422408421006 ∧ code e2422408421006 = 11218501443214 := by decide
theorem cert_e2422408421006 : check e2422408421006 [[],[]] .chain = true := by decide
def e2422408421062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422408421062 : Closed e2422408421062 ∧ code e2422408421062 = 11218501443270 := by decide
theorem cert_e2422408421062 : check e2422408421062 [[],[]] .chain = true := by decide
def e2422408425838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1))) (.var 2))))))
theorem wire_e2422408425838 : Closed e2422408425838 ∧ code e2422408425838 = 11218501448046 := by decide
theorem cert_e2422408425838 : check e2422408425838 [[],[]] .chain = true := by decide
def e2422408425846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2))) (.var 1))))))
theorem wire_e2422408425846 : Closed e2422408425846 ∧ code e2422408425846 = 11218501448054 := by decide
theorem cert_e2422408425846 : check e2422408425846 [[],[]] .chain = true := by decide
def e2422408427054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422408427054 : Closed e2422408427054 ∧ code e2422408427054 = 11218501449262 := by decide
theorem cert_e2422408427054 : check e2422408427054 [[],[]] .chain = true := by decide
def e2422408427234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422408427234 : Closed e2422408427234 ∧ code e2422408427234 = 11218501449442 := by decide
theorem cert_e2422408427234 : check e2422408427234 [[],[]] .chain = true := by decide
def e2422408427246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.var 2))))))
theorem wire_e2422408427246 : Closed e2422408427246 ∧ code e2422408427246 = 11218501449454 := by decide
theorem cert_e2422408427246 : check e2422408427246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408427286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408427286 : Closed e2422408427286 ∧ code e2422408427286 = 11218501449494 := by decide
theorem cert_e2422408427286 : check e2422408427286 [[],[]] .chain = true := by decide
def e2422408427362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408427362 : Closed e2422408427362 ∧ code e2422408427362 = 11218501449570 := by decide
theorem cert_e2422408427362 : check e2422408427362 [[],[]] .chain = true := by decide
def e2422408427374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.var 2))))))
theorem wire_e2422408427374 : Closed e2422408427374 ∧ code e2422408427374 = 11218501449582 := by decide
theorem cert_e2422408427374 : checkPay e2422408427374 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422408427382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2))) (.var 1))))))
theorem wire_e2422408427382 : Closed e2422408427382 ∧ code e2422408427382 = 11218501449590 := by decide
theorem cert_e2422408427382 : check e2422408427382 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408427694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0))) (.var 2))))))
theorem wire_e2422408427694 : Closed e2422408427694 ∧ code e2422408427694 = 11218501449902 := by decide
theorem cert_e2422408427694 : check e2422408427694 [[],[]] .chain = true := by decide
def e2422408427706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))) (.var 0))))))
theorem wire_e2422408427706 : Closed e2422408427706 ∧ code e2422408427706 = 11218501449914 := by decide
theorem cert_e2422408427706 : check e2422408427706 [[],[]] .chain = true := by decide
def e2422408428078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422408428078 : Closed e2422408428078 ∧ code e2422408428078 = 11218501450286 := by decide
theorem cert_e2422408428078 : check e2422408428078 [[],[]] .chain = true := by decide
def e2422408428258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422408428258 : Closed e2422408428258 ∧ code e2422408428258 = 11218501450466 := by decide
theorem cert_e2422408428258 : check e2422408428258 [[],[]] .chain = true := by decide
def e2422408428270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.var 2))))))
theorem wire_e2422408428270 : Closed e2422408428270 ∧ code e2422408428270 = 11218501450478 := by decide
theorem cert_e2422408428270 : check e2422408428270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408428398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e2422408428398 : Closed e2422408428398 ∧ code e2422408428398 = 11218501450606 := by decide
theorem cert_e2422408428398 : check e2422408428398 [[],[]] .chain = true := by decide
def e2422408428406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e2422408428406 : Closed e2422408428406 ∧ code e2422408428406 = 11218501450614 := by decide
theorem cert_e2422408428406 : check e2422408428406 [[],[]] .chain = true := by decide
def e2422408428426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408428426 : Closed e2422408428426 ∧ code e2422408428426 = 11218501450634 := by decide
theorem cert_e2422408428426 : check e2422408428426 [[],[]] .chain = true := by decide
def e2422408428450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408428450 : Closed e2422408428450 ∧ code e2422408428450 = 11218501450658 := by decide
theorem cert_e2422408428450 : check e2422408428450 [[],[]] .chain = true := by decide
def e2422408428462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e2422408428462 : Closed e2422408428462 ∧ code e2422408428462 = 11218501450670 := by decide
theorem cert_e2422408428462 : check e2422408428462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408428470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))) (.var 1))))))
theorem wire_e2422408428470 : Closed e2422408428470 ∧ code e2422408428470 = 11218501450678 := by decide
theorem cert_e2422408428470 : check e2422408428470 [[],[]] .chain = true := by decide
def e2422408428474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e2422408428474 : Closed e2422408428474 ∧ code e2422408428474 = 11218501450682 := by decide
theorem cert_e2422408428474 : check e2422408428474 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408428630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0))) (.var 1))))))
theorem wire_e2422408428630 : Closed e2422408428630 ∧ code e2422408428630 = 11218501450838 := by decide
theorem cert_e2422408428630 : check e2422408428630 [[],[]] .chain = true := by decide
def e2422408428634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))) (.var 0))))))
theorem wire_e2422408428634 : Closed e2422408428634 ∧ code e2422408428634 = 11218501450842 := by decide
theorem cert_e2422408428634 : check e2422408428634 [[],[]] .chain = true := by decide
def e2422408428822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408428822 : Closed e2422408428822 ∧ code e2422408428822 = 11218501451030 := by decide
theorem cert_e2422408428822 : check e2422408428822 [[],[]] .chain = true := by decide
def e2422408428898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408428898 : Closed e2422408428898 ∧ code e2422408428898 = 11218501451106 := by decide
theorem cert_e2422408428898 : check e2422408428898 [[],[]] .chain = true := by decide
def e2422408428910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2422408428910 : Closed e2422408428910 ∧ code e2422408428910 = 11218501451118 := by decide
theorem cert_e2422408428910 : check e2422408428910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408428918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2422408428918 : Closed e2422408428918 ∧ code e2422408428918 = 11218501451126 := by decide
theorem cert_e2422408428918 : checkPay e2422408428918 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422408428938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408428938 : Closed e2422408428938 ∧ code e2422408428938 = 11218501451146 := by decide
theorem cert_e2422408428938 : check e2422408428938 [[],[]] .chain = true := by decide
def e2422408428962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408428962 : Closed e2422408428962 ∧ code e2422408428962 = 11218501451170 := by decide
theorem cert_e2422408428962 : check e2422408428962 [[],[]] .chain = true := by decide
def e2422408428974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e2422408428974 : Closed e2422408428974 ∧ code e2422408428974 = 11218501451182 := by decide
theorem cert_e2422408428974 : check e2422408428974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408428982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))) (.var 1))))))
theorem wire_e2422408428982 : Closed e2422408428982 ∧ code e2422408428982 = 11218501451190 := by decide
theorem cert_e2422408428982 : check e2422408428982 [[],[]] .chain = true := by decide
def e2422408428986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e2422408428986 : Closed e2422408428986 ∧ code e2422408428986 = 11218501451194 := by decide
theorem cert_e2422408428986 : check e2422408428986 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408429014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e2422408429014 : Closed e2422408429014 ∧ code e2422408429014 = 11218501451222 := by decide
theorem cert_e2422408429014 : check e2422408429014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408429018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e2422408429018 : Closed e2422408429018 ∧ code e2422408429018 = 11218501451226 := by decide
theorem cert_e2422408429018 : check e2422408429018 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408430062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2422408430062 : Closed e2422408430062 ∧ code e2422408430062 = 11218501452270 := by decide
theorem cert_e2422408430062 : check e2422408430062 [[],[]] .chain = true := by decide
def e2422408430070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2422408430070 : Closed e2422408430070 ∧ code e2422408430070 = 11218501452278 := by decide
theorem cert_e2422408430070 : check e2422408430070 [[],[]] .chain = true := by decide
def e2422408430830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408430830 : Closed e2422408430830 ∧ code e2422408430830 = 11218501453038 := by decide
theorem cert_e2422408430830 : check e2422408430830 [[],[]] .chain = true := by decide
def e2422408430838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408430838 : Closed e2422408430838 ∧ code e2422408430838 = 11218501453046 := by decide
theorem cert_e2422408430838 : check e2422408430838 [[],[]] .chain = true := by decide
def e2422408431390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2422408431390 : Closed e2422408431390 ∧ code e2422408431390 = 11218501453598 := by decide
theorem cert_e2422408431390 : check e2422408431390 [[],[]] .chain = true := by decide
def e2422408431502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2422408431502 : Closed e2422408431502 ∧ code e2422408431502 = 11218501453710 := by decide
theorem cert_e2422408431502 : check e2422408431502 [[],[]] .chain = true := by decide
def e2422408433198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408433198 : Closed e2422408433198 ∧ code e2422408433198 = 11218501455406 := by decide
theorem cert_e2422408433198 : check e2422408433198 [[],[]] .chain = true := by decide
def e2422408433378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408433378 : Closed e2422408433378 ∧ code e2422408433378 = 11218501455586 := by decide
theorem cert_e2422408433378 : check e2422408433378 [[],[]] .chain = true := by decide
def e2422408433390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2422408433390 : Closed e2422408433390 ∧ code e2422408433390 = 11218501455598 := by decide
theorem cert_e2422408433390 : check e2422408433390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408433430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422408433430 : Closed e2422408433430 ∧ code e2422408433430 = 11218501455638 := by decide
theorem cert_e2422408433430 : check e2422408433430 [[],[]] .chain = true := by decide
def e2422408433506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422408433506 : Closed e2422408433506 ∧ code e2422408433506 = 11218501455714 := by decide
theorem cert_e2422408433506 : check e2422408433506 [[],[]] .chain = true := by decide
def e2422408433518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2422408433518 : Closed e2422408433518 ∧ code e2422408433518 = 11218501455726 := by decide
theorem cert_e2422408433518 : check e2422408433518 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408433526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2422408433526 : Closed e2422408433526 ∧ code e2422408433526 = 11218501455734 := by decide
theorem cert_e2422408433526 : check e2422408433526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408435774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2422408435774 : Closed e2422408435774 ∧ code e2422408435774 = 11218501457982 := by decide
theorem cert_e2422408435774 : check e2422408435774 [[],[]] .chain = true := by decide
def e2422408436194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422408436194 : Closed e2422408436194 ∧ code e2422408436194 = 11218501458402 := by decide
theorem cert_e2422408436194 : check e2422408436194 [[],[]] .chain = true := by decide
def e2422408436206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408436206 : Closed e2422408436206 ∧ code e2422408436206 = 11218501458414 := by decide
theorem cert_e2422408436206 : check e2422408436206 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408436766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408436766 : Closed e2422408436766 ∧ code e2422408436766 = 11218501458974 := by decide
theorem cert_e2422408436766 : check e2422408436766 [[],[]] .chain = true := by decide
def e2422408436962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408436962 : Closed e2422408436962 ∧ code e2422408436962 = 11218501459170 := by decide
theorem cert_e2422408436962 : check e2422408436962 [[],[]] .chain = true := by decide
def e2422408436974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408436974 : Closed e2422408436974 ∧ code e2422408436974 = 11218501459182 := by decide
theorem cert_e2422408436974 : check e2422408436974 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408436982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408436982 : Closed e2422408436982 ∧ code e2422408436982 = 11218501459190 := by decide
theorem cert_e2422408436982 : check e2422408436982 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408437806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408437806 : Closed e2422408437806 ∧ code e2422408437806 = 11218501460014 := by decide
theorem cert_e2422408437806 : check e2422408437806 [[],[]] .chain = true := by decide
def e2422408437998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422408437998 : Closed e2422408437998 ∧ code e2422408437998 = 11218501460206 := by decide
theorem cert_e2422408437998 : check e2422408437998 [[],[]] .chain = true := by decide
def e2422408438010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422408438010 : Closed e2422408438010 ∧ code e2422408438010 = 11218501460218 := by decide
theorem cert_e2422408438010 : check e2422408438010 [[],[]] .chain = true := by decide
def e2422408438190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422408438190 : Closed e2422408438190 ∧ code e2422408438190 = 11218501460398 := by decide
theorem cert_e2422408438190 : check e2422408438190 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408438382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408438382 : Closed e2422408438382 ∧ code e2422408438382 = 11218501460590 := by decide
theorem cert_e2422408438382 : check e2422408438382 [[],[]] .chain = true := by decide
def e2422408438394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408438394 : Closed e2422408438394 ∧ code e2422408438394 = 11218501460602 := by decide
theorem cert_e2422408438394 : check e2422408438394 [[],[]] .chain = true := by decide
def e2422408438558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422408438558 : Closed e2422408438558 ∧ code e2422408438558 = 11218501460766 := by decide
theorem cert_e2422408438558 : check e2422408438558 [[],[]] .chain = true := by decide
def e2422408438726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422408438726 : Closed e2422408438726 ∧ code e2422408438726 = 11218501460934 := by decide
theorem cert_e2422408438726 : check e2422408438726 [[],[]] .chain = true := by decide
def e2422408439342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408439342 : Closed e2422408439342 ∧ code e2422408439342 = 11218501461550 := by decide
theorem cert_e2422408439342 : check e2422408439342 [[],[]] .chain = true := by decide
def e2422408439522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408439522 : Closed e2422408439522 ∧ code e2422408439522 = 11218501461730 := by decide
theorem cert_e2422408439522 : check e2422408439522 [[],[]] .chain = true := by decide
def e2422408439534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2422408439534 : Closed e2422408439534 ∧ code e2422408439534 = 11218501461742 := by decide
theorem cert_e2422408439534 : check e2422408439534 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408439662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422408439662 : Closed e2422408439662 ∧ code e2422408439662 = 11218501461870 := by decide
theorem cert_e2422408439662 : check e2422408439662 [[],[]] .chain = true := by decide
def e2422408439670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2422408439670 : Closed e2422408439670 ∧ code e2422408439670 = 11218501461878 := by decide
theorem cert_e2422408439670 : check e2422408439670 [[],[]] .chain = true := by decide
def e2422408439690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408439690 : Closed e2422408439690 ∧ code e2422408439690 = 11218501461898 := by decide
theorem cert_e2422408439690 : check e2422408439690 [[],[]] .chain = true := by decide
def e2422408439714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408439714 : Closed e2422408439714 ∧ code e2422408439714 = 11218501461922 := by decide
theorem cert_e2422408439714 : check e2422408439714 [[],[]] .chain = true := by decide
def e2422408439726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2422408439726 : Closed e2422408439726 ∧ code e2422408439726 = 11218501461934 := by decide
theorem cert_e2422408439726 : check e2422408439726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408439734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2422408439734 : Closed e2422408439734 ∧ code e2422408439734 = 11218501461942 := by decide
theorem cert_e2422408439734 : check e2422408439734 [[],[]] .chain = true := by decide
def e2422408439738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2422408439738 : Closed e2422408439738 ∧ code e2422408439738 = 11218501461946 := by decide
theorem cert_e2422408439738 : check e2422408439738 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408439870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2422408439870 : Closed e2422408439870 ∧ code e2422408439870 = 11218501462078 := by decide
theorem cert_e2422408439870 : check e2422408439870 [[],[]] .chain = true := by decide
def e2422408440290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422408440290 : Closed e2422408440290 ∧ code e2422408440290 = 11218501462498 := by decide
theorem cert_e2422408440290 : check e2422408440290 [[],[]] .chain = true := by decide
def e2422408440302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408440302 : Closed e2422408440302 ∧ code e2422408440302 = 11218501462510 := by decide
theorem cert_e2422408440302 : check e2422408440302 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408441070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408441070 : Closed e2422408441070 ∧ code e2422408441070 = 11218501463278 := by decide
theorem cert_e2422408441070 : check e2422408441070 [[],[]] .chain = true := by decide
def e2422408441078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408441078 : Closed e2422408441078 ∧ code e2422408441078 = 11218501463286 := by decide
theorem cert_e2422408441078 : check e2422408441078 [[],[]] .chain = true := by decide
def e2422408441346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408441346 : Closed e2422408441346 ∧ code e2422408441346 = 11218501463554 := by decide
theorem cert_e2422408441346 : check e2422408441346 [[],[]] .chain = true := by decide
def e2422408441358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408441358 : Closed e2422408441358 ∧ code e2422408441358 = 11218501463566 := by decide
theorem cert_e2422408441358 : check e2422408441358 [[],[]] .chain = true := by decide
def e2422408441370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408441370 : Closed e2422408441370 ∧ code e2422408441370 = 11218501463578 := by decide
theorem cert_e2422408441370 : check e2422408441370 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408441442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408441442 : Closed e2422408441442 ∧ code e2422408441442 = 11218501463650 := by decide
theorem cert_e2422408441442 : check e2422408441442 [[],[]] .chain = true := by decide
def e2422408441454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408441454 : Closed e2422408441454 ∧ code e2422408441454 = 11218501463662 := by decide
theorem cert_e2422408441454 : check e2422408441454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408441462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408441462 : Closed e2422408441462 ∧ code e2422408441462 = 11218501463670 := by decide
theorem cert_e2422408441462 : check e2422408441462 [[],[]] .chain = true := by decide
def e2422408441466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408441466 : Closed e2422408441466 ∧ code e2422408441466 = 11218501463674 := by decide
theorem cert_e2422408441466 : check e2422408441466 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408441878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408441878 : Closed e2422408441878 ∧ code e2422408441878 = 11218501464086 := by decide
theorem cert_e2422408441878 : check e2422408441878 [[],[]] .chain = true := by decide
end Blc.Floor43
