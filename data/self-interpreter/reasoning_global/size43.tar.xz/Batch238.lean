import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373720206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2393373720206 : Closed e2393373720206 ∧ code e2393373720206 = 11189466742414 := by decide
theorem cert_e2393373720206 : check e2393373720206 [[],[.left],[]] .chain = true := by decide
def e2393373720262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2393373720262 : Closed e2393373720262 ∧ code e2393373720262 = 11189466742470 := by decide
theorem cert_e2393373720262 : check e2393373720262 [[],[.left],[]] .chain = true := by decide
def e2393373720302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2393373720302 : Closed e2393373720302 ∧ code e2393373720302 = 11189466742510 := by decide
theorem cert_e2393373720302 : check e2393373720302 [[],[.left],[]] .sourceHead = true := by decide
def e2393373721566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2393373721566 : Closed e2393373721566 ∧ code e2393373721566 = 11189466743774 := by decide
theorem cert_e2393373721566 : check e2393373721566 [[],[.left],[]] .chain = true := by decide
def e2393373721582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2393373721582 : Closed e2393373721582 ∧ code e2393373721582 = 11189466743790 := by decide
theorem cert_e2393373721582 : check e2393373721582 [[],[.left],[]] .chain = true := by decide
def e2393373723502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393373723502 : Closed e2393373723502 ∧ code e2393373723502 = 11189466745710 := by decide
theorem cert_e2393373723502 : check e2393373723502 [[],[.left],[]] .chain = true := by decide
def e2393373723510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393373723510 : Closed e2393373723510 ∧ code e2393373723510 = 11189466745718 := by decide
theorem cert_e2393373723510 : check e2393373723510 [[],[.left],[]] .chain = true := by decide
def e2393373723566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393373723566 : Closed e2393373723566 ∧ code e2393373723566 = 11189466745774 := by decide
theorem cert_e2393373723566 : check e2393373723566 [[],[.left],[]] .chain = true := by decide
def e2393373723578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393373723578 : Closed e2393373723578 ∧ code e2393373723578 = 11189466745786 := by decide
theorem cert_e2393373723578 : check e2393373723578 [[],[.left],[]] .chain = true := by decide
def e2393373723606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393373723606 : Closed e2393373723606 ∧ code e2393373723606 = 11189466745814 := by decide
theorem cert_e2393373723606 : check e2393373723606 [[],[.left],[]] .chain = true := by decide
def e2393373723610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393373723610 : Closed e2393373723610 ∧ code e2393373723610 = 11189466745818 := by decide
theorem cert_e2393373723610 : check e2393373723610 [[],[.left],[]] .chain = true := by decide
def e2393373723886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393373723886 : Closed e2393373723886 ∧ code e2393373723886 = 11189466746094 := by decide
theorem cert_e2393373723886 : check e2393373723886 [[],[.left],[]] .chain = true := by decide
def e2393373723894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393373723894 : Closed e2393373723894 ∧ code e2393373723894 = 11189466746102 := by decide
theorem cert_e2393373723894 : check e2393373723894 [[],[.left],[]] .chain = true := by decide
def e2393373724222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2393373724222 : Closed e2393373724222 ∧ code e2393373724222 = 11189466746430 := by decide
theorem cert_e2393373724222 : check e2393373724222 [[],[.left],[]] .chain = true := by decide
def e2393373724270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393373724270 : Closed e2393373724270 ∧ code e2393373724270 = 11189466746478 := by decide
theorem cert_e2393373724270 : check e2393373724270 [[],[.left],[]] .chain = true := by decide
def e2393373724282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393373724282 : Closed e2393373724282 ∧ code e2393373724282 = 11189466746490 := by decide
theorem cert_e2393373724282 : check e2393373724282 [[],[.left],[]] .chain = true := by decide
def e2393373724470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393373724470 : Closed e2393373724470 ∧ code e2393373724470 = 11189466746678 := by decide
theorem cert_e2393373724470 : check e2393373724470 [[],[.left],[]] .chain = true := by decide
def e2393373724474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393373724474 : Closed e2393373724474 ∧ code e2393373724474 = 11189466746682 := by decide
theorem cert_e2393373724474 : check e2393373724474 [[],[.left],[]] .chain = true := by decide
def e2393373724558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2393373724558 : Closed e2393373724558 ∧ code e2393373724558 = 11189466746766 := by decide
theorem cert_e2393373724558 : check e2393373724558 [[],[.left],[]] .chain = true := by decide
def e2393373729246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2393373729246 : Closed e2393373729246 ∧ code e2393373729246 = 11189466751454 := by decide
theorem cert_e2393373729246 : check e2393373729246 [[],[.left],[]] .chain = true := by decide
def e2393373729270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2393373729270 : Closed e2393373729270 ∧ code e2393373729270 = 11189466751478 := by decide
theorem cert_e2393373729270 : check e2393373729270 [[],[.left],[]] .chain = true := by decide
def e2393373730222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2393373730222 : Closed e2393373730222 ∧ code e2393373730222 = 11189466752430 := by decide
theorem cert_e2393373730222 : check e2393373730222 [[],[.left],[]] .chain = true := by decide
def e2393373730234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2393373730234 : Closed e2393373730234 ∧ code e2393373730234 = 11189466752442 := by decide
theorem cert_e2393373730234 : check e2393373730234 [[],[.left],[]] .chain = true := by decide
def e2393373730282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2393373730282 : Closed e2393373730282 ∧ code e2393373730282 = 11189466752490 := by decide
theorem cert_e2393373730282 : check e2393373730282 [[],[.left],[]] .chain = true := by decide
def e2393373730366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2393373730366 : Closed e2393373730366 ∧ code e2393373730366 = 11189466752574 := by decide
theorem cert_e2393373730366 : check e2393373730366 [[],[.left],[]] .chain = true := by decide
def e2393373730414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393373730414 : Closed e2393373730414 ∧ code e2393373730414 = 11189466752622 := by decide
theorem cert_e2393373730414 : check e2393373730414 [[],[.left],[]] .chain = true := by decide
def e2393373730426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393373730426 : Closed e2393373730426 ∧ code e2393373730426 = 11189466752634 := by decide
theorem cert_e2393373730426 : check e2393373730426 [[],[.left],[]] .chain = true := by decide
def e2393373730714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393373730714 : Closed e2393373730714 ∧ code e2393373730714 = 11189466752922 := by decide
theorem cert_e2393373730714 : check e2393373730714 [[],[.left],[]] .chain = true := by decide
def e2393373730758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2393373730758 : Closed e2393373730758 ∧ code e2393373730758 = 11189466752966 := by decide
theorem cert_e2393373730758 : check e2393373730758 [[],[.left],[]] .chain = true := by decide
def e2393373733102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2393373733102 : Closed e2393373733102 ∧ code e2393373733102 = 11189466755310 := by decide
theorem cert_e2393373733102 : check e2393373733102 [[],[.left],[]] .chain = true := by decide
def e2393373733110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2393373733110 : Closed e2393373733110 ∧ code e2393373733110 = 11189466755318 := by decide
theorem cert_e2393373733110 : check e2393373733110 [[],[.left],[]] .chain = true := by decide
def e2393373733590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2393373733590 : Closed e2393373733590 ∧ code e2393373733590 = 11189466755798 := by decide
theorem cert_e2393373733590 : check e2393373733590 [[],[.left],[]] .chain = true := by decide
def e2393373733594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2393373733594 : Closed e2393373733594 ∧ code e2393373733594 = 11189466755802 := by decide
theorem cert_e2393373733594 : check e2393373733594 [[],[.left],[]] .chain = true := by decide
def e2393373733610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2393373733610 : Closed e2393373733610 ∧ code e2393373733610 = 11189466755818 := by decide
theorem cert_e2393373733610 : check e2393373733610 [[],[.left],[]] .chain = true := by decide
def e2393373733686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393373733686 : Closed e2393373733686 ∧ code e2393373733686 = 11189466755894 := by decide
theorem cert_e2393373733686 : check e2393373733686 [[],[.left],[]] .chain = true := by decide
def e2393373733690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393373733690 : Closed e2393373733690 ∧ code e2393373733690 = 11189466755898 := by decide
theorem cert_e2393373733690 : check e2393373733690 [[],[.left],[]] .chain = true := by decide
def e2393373733786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393373733786 : Closed e2393373733786 ∧ code e2393373733786 = 11189466755994 := by decide
theorem cert_e2393373733786 : check e2393373733786 [[],[.left],[]] .chain = true := by decide
def e2393373733854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393373733854 : Closed e2393373733854 ∧ code e2393373733854 = 11189466756062 := by decide
theorem cert_e2393373733854 : check e2393373733854 [[],[.left],[]] .sourceHead = true := by decide
def e2393373733870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393373733870 : Closed e2393373733870 ∧ code e2393373733870 = 11189466756078 := by decide
theorem cert_e2393373733870 : check e2393373733870 [[],[.left],[]] .sourceHead = true := by decide
def e2393373735310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2393373735310 : Closed e2393373735310 ∧ code e2393373735310 = 11189466757518 := by decide
theorem cert_e2393373735310 : check e2393373735310 [[],[.left],[]] .chain = true := by decide
def e2393373735366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2393373735366 : Closed e2393373735366 ∧ code e2393373735366 = 11189466757574 := by decide
theorem cert_e2393373735366 : check e2393373735366 [[],[.left],[]] .chain = true := by decide
def e2393373735406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393373735406 : Closed e2393373735406 ∧ code e2393373735406 = 11189466757614 := by decide
theorem cert_e2393373735406 : check e2393373735406 [[],[.left],[]] .sourceHead = true := by decide
def e2393373816046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373816046 : Closed e2393373816046 ∧ code e2393373816046 = 11189466838254 := by decide
theorem cert_e2393373816046 : check e2393373816046 [[],[.left],[]] .sourceHead = true := by decide
def e2393373816054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373816054 : Closed e2393373816054 ∧ code e2393373816054 = 11189466838262 := by decide
theorem cert_e2393373816054 : check e2393373816054 [[],[.left],[]] .sourceHead = true := by decide
def e2393373847918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2393373847918 : Closed e2393373847918 ∧ code e2393373847918 = 11189466870126 := by decide
theorem cert_e2393373847918 : check e2393373847918 [[],[.left],[]] .sourceHead = true := by decide
def e2393373847926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2393373847926 : Closed e2393373847926 ∧ code e2393373847926 = 11189466870134 := by decide
theorem cert_e2393373847926 : check e2393373847926 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393373849134 : Closed e2393373849134 ∧ code e2393373849134 = 11189466871342 := by decide
theorem cert_e2393373849134 : check e2393373849134 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393373849314 : Closed e2393373849314 ∧ code e2393373849314 = 11189466871522 := by decide
theorem cert_e2393373849314 : check e2393373849314 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2393373849326 : Closed e2393373849326 ∧ code e2393373849326 = 11189466871534 := by decide
theorem cert_e2393373849326 : check e2393373849326 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393373849366 : Closed e2393373849366 ∧ code e2393373849366 = 11189466871574 := by decide
theorem cert_e2393373849366 : check e2393373849366 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393373849442 : Closed e2393373849442 ∧ code e2393373849442 = 11189466871650 := by decide
theorem cert_e2393373849442 : check e2393373849442 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2393373849454 : Closed e2393373849454 ∧ code e2393373849454 = 11189466871662 := by decide
theorem cert_e2393373849454 : check e2393373849454 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2393373849462 : Closed e2393373849462 ∧ code e2393373849462 = 11189466871670 := by decide
theorem cert_e2393373849462 : check e2393373849462 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2393373849774 : Closed e2393373849774 ∧ code e2393373849774 = 11189466871982 := by decide
theorem cert_e2393373849774 : check e2393373849774 [[],[.left],[]] .sourceHead = true := by decide
def e2393373849786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2393373849786 : Closed e2393373849786 ∧ code e2393373849786 = 11189466871994 := by decide
theorem cert_e2393373849786 : check e2393373849786 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393373850158 : Closed e2393373850158 ∧ code e2393373850158 = 11189466872366 := by decide
theorem cert_e2393373850158 : check e2393373850158 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393373850338 : Closed e2393373850338 ∧ code e2393373850338 = 11189466872546 := by decide
theorem cert_e2393373850338 : check e2393373850338 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2393373850350 : Closed e2393373850350 ∧ code e2393373850350 = 11189466872558 := by decide
theorem cert_e2393373850350 : check e2393373850350 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2393373850478 : Closed e2393373850478 ∧ code e2393373850478 = 11189466872686 := by decide
theorem cert_e2393373850478 : check e2393373850478 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2393373850486 : Closed e2393373850486 ∧ code e2393373850486 = 11189466872694 := by decide
theorem cert_e2393373850486 : check e2393373850486 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373850506 : Closed e2393373850506 ∧ code e2393373850506 = 11189466872714 := by decide
theorem cert_e2393373850506 : check e2393373850506 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373850530 : Closed e2393373850530 ∧ code e2393373850530 = 11189466872738 := by decide
theorem cert_e2393373850530 : check e2393373850530 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2393373850542 : Closed e2393373850542 ∧ code e2393373850542 = 11189466872750 := by decide
theorem cert_e2393373850542 : check e2393373850542 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2393373850550 : Closed e2393373850550 ∧ code e2393373850550 = 11189466872758 := by decide
theorem cert_e2393373850550 : check e2393373850550 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2393373850554 : Closed e2393373850554 ∧ code e2393373850554 = 11189466872762 := by decide
theorem cert_e2393373850554 : check e2393373850554 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2393373850710 : Closed e2393373850710 ∧ code e2393373850710 = 11189466872918 := by decide
theorem cert_e2393373850710 : check e2393373850710 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2393373850714 : Closed e2393373850714 ∧ code e2393373850714 = 11189466872922 := by decide
theorem cert_e2393373850714 : check e2393373850714 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393373850902 : Closed e2393373850902 ∧ code e2393373850902 = 11189466873110 := by decide
theorem cert_e2393373850902 : check e2393373850902 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393373850978 : Closed e2393373850978 ∧ code e2393373850978 = 11189466873186 := by decide
theorem cert_e2393373850978 : check e2393373850978 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393373850990 : Closed e2393373850990 ∧ code e2393373850990 = 11189466873198 := by decide
theorem cert_e2393373850990 : check e2393373850990 [[],[.left],[]] .sourceHead = true := by decide
def e2393373850998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393373850998 : Closed e2393373850998 ∧ code e2393373850998 = 11189466873206 := by decide
theorem cert_e2393373850998 : check e2393373850998 [[],[.left],[]] .sourceHead = true := by decide
def e2393373851018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373851018 : Closed e2393373851018 ∧ code e2393373851018 = 11189466873226 := by decide
theorem cert_e2393373851018 : check e2393373851018 [[],[.left],[]] .sourceHead = true := by decide
def e2393373851042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373851042 : Closed e2393373851042 ∧ code e2393373851042 = 11189466873250 := by decide
theorem cert_e2393373851042 : check e2393373851042 [[],[.left],[]] .sourceHead = true := by decide
def e2393373851054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393373851054 : Closed e2393373851054 ∧ code e2393373851054 = 11189466873262 := by decide
theorem cert_e2393373851054 : check e2393373851054 [[],[.left],[]] .sourceHead = true := by decide
def e2393373851062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e2393373851062 : Closed e2393373851062 ∧ code e2393373851062 = 11189466873270 := by decide
theorem cert_e2393373851062 : check e2393373851062 [[],[.left],[]] .sourceHead = true := by decide
def e2393373851066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393373851066 : Closed e2393373851066 ∧ code e2393373851066 = 11189466873274 := by decide
theorem cert_e2393373851066 : check e2393373851066 [[],[.left],[]] .sourceHead = true := by decide
def e2393373851094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393373851094 : Closed e2393373851094 ∧ code e2393373851094 = 11189466873302 := by decide
theorem cert_e2393373851094 : check e2393373851094 [[],[.left],[]] .sourceHead = true := by decide
def e2393373851098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393373851098 : Closed e2393373851098 ∧ code e2393373851098 = 11189466873306 := by decide
theorem cert_e2393373851098 : check e2393373851098 [[],[.left],[]] .sourceHead = true := by decide
def e2393373852142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2393373852142 : Closed e2393373852142 ∧ code e2393373852142 = 11189466874350 := by decide
theorem cert_e2393373852142 : check e2393373852142 [[],[.left],[]] .sourceHead = true := by decide
def e2393373852150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2393373852150 : Closed e2393373852150 ∧ code e2393373852150 = 11189466874358 := by decide
theorem cert_e2393373852150 : check e2393373852150 [[],[.left],[]] .sourceHead = true := by decide
def e2393373852910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373852910 : Closed e2393373852910 ∧ code e2393373852910 = 11189466875118 := by decide
theorem cert_e2393373852910 : check e2393373852910 [[],[.left],[]] .sourceHead = true := by decide
def e2393373852918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373852918 : Closed e2393373852918 ∧ code e2393373852918 = 11189466875126 := by decide
theorem cert_e2393373852918 : check e2393373852918 [[],[.left],[]] .sourceHead = true := by decide
def e2393373853470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2393373853470 : Closed e2393373853470 ∧ code e2393373853470 = 11189466875678 := by decide
theorem cert_e2393373853470 : check e2393373853470 [[],[.left],[]] .sourceHead = true := by decide
def e2393373853582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2393373853582 : Closed e2393373853582 ∧ code e2393373853582 = 11189466875790 := by decide
theorem cert_e2393373853582 : check e2393373853582 [[],[.left],[]] .sourceHead = true := by decide
def e2393373855278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2393373855278 : Closed e2393373855278 ∧ code e2393373855278 = 11189466877486 := by decide
theorem cert_e2393373855278 : check e2393373855278 [[],[.left],[]] .sourceHead = true := by decide
def e2393373855458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2393373855458 : Closed e2393373855458 ∧ code e2393373855458 = 11189466877666 := by decide
theorem cert_e2393373855458 : check e2393373855458 [[],[.left],[]] .sourceHead = true := by decide
def e2393373855470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2393373855470 : Closed e2393373855470 ∧ code e2393373855470 = 11189466877678 := by decide
theorem cert_e2393373855470 : check e2393373855470 [[],[.left],[]] .sourceHead = true := by decide
def e2393373855510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2393373855510 : Closed e2393373855510 ∧ code e2393373855510 = 11189466877718 := by decide
theorem cert_e2393373855510 : check e2393373855510 [[],[.left],[]] .sourceHead = true := by decide
def e2393373855586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2393373855586 : Closed e2393373855586 ∧ code e2393373855586 = 11189466877794 := by decide
theorem cert_e2393373855586 : check e2393373855586 [[],[.left],[]] .sourceHead = true := by decide
def e2393373855598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2393373855598 : Closed e2393373855598 ∧ code e2393373855598 = 11189466877806 := by decide
theorem cert_e2393373855598 : check e2393373855598 [[],[.left],[]] .sourceHead = true := by decide
def e2393373855606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2393373855606 : Closed e2393373855606 ∧ code e2393373855606 = 11189466877814 := by decide
theorem cert_e2393373855606 : check e2393373855606 [[],[.left],[]] .sourceHead = true := by decide
def e2393373857854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2393373857854 : Closed e2393373857854 ∧ code e2393373857854 = 11189466880062 := by decide
theorem cert_e2393373857854 : check e2393373857854 [[],[.left],[]] .sourceHead = true := by decide
def e2393373858274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393373858274 : Closed e2393373858274 ∧ code e2393373858274 = 11189466880482 := by decide
theorem cert_e2393373858274 : check e2393373858274 [[],[.left],[]] .sourceHead = true := by decide
def e2393373858286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393373858286 : Closed e2393373858286 ∧ code e2393373858286 = 11189466880494 := by decide
theorem cert_e2393373858286 : check e2393373858286 [[],[.left],[]] .sourceHead = true := by decide
def e2393373858846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2393373858846 : Closed e2393373858846 ∧ code e2393373858846 = 11189466881054 := by decide
theorem cert_e2393373858846 : check e2393373858846 [[],[.left],[]] .sourceHead = true := by decide
def e2393373859042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393373859042 : Closed e2393373859042 ∧ code e2393373859042 = 11189466881250 := by decide
theorem cert_e2393373859042 : check e2393373859042 [[],[.left],[]] .sourceHead = true := by decide
def e2393373859054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373859054 : Closed e2393373859054 ∧ code e2393373859054 = 11189466881262 := by decide
theorem cert_e2393373859054 : check e2393373859054 [[],[.left],[]] .sourceHead = true := by decide
def e2393373859062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373859062 : Closed e2393373859062 ∧ code e2393373859062 = 11189466881270 := by decide
theorem cert_e2393373859062 : check e2393373859062 [[],[.left],[]] .sourceHead = true := by decide
def e2393373860078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2393373860078 : Closed e2393373860078 ∧ code e2393373860078 = 11189466882286 := by decide
theorem cert_e2393373860078 : check e2393373860078 [[],[.left],[]] .sourceHead = true := by decide
def e2393373860090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2393373860090 : Closed e2393373860090 ∧ code e2393373860090 = 11189466882298 := by decide
theorem cert_e2393373860090 : check e2393373860090 [[],[.left],[]] .sourceHead = true := by decide
def e2393373860270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2393373860270 : Closed e2393373860270 ∧ code e2393373860270 = 11189466882478 := by decide
theorem cert_e2393373860270 : check e2393373860270 [[],[.left],[]] .sourceHead = true := by decide
def e2393373860462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373860462 : Closed e2393373860462 ∧ code e2393373860462 = 11189466882670 := by decide
theorem cert_e2393373860462 : check e2393373860462 [[],[.left],[]] .sourceHead = true := by decide
def e2393373860474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373860474 : Closed e2393373860474 ∧ code e2393373860474 = 11189466882682 := by decide
theorem cert_e2393373860474 : check e2393373860474 [[],[.left],[]] .sourceHead = true := by decide
def e2393373860638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2393373860638 : Closed e2393373860638 ∧ code e2393373860638 = 11189466882846 := by decide
theorem cert_e2393373860638 : check e2393373860638 [[],[.left],[]] .sourceHead = true := by decide
def e2393373860806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2393373860806 : Closed e2393373860806 ∧ code e2393373860806 = 11189466883014 := by decide
theorem cert_e2393373860806 : check e2393373860806 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2393373861422 : Closed e2393373861422 ∧ code e2393373861422 = 11189466883630 := by decide
theorem cert_e2393373861422 : check e2393373861422 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2393373861602 : Closed e2393373861602 ∧ code e2393373861602 = 11189466883810 := by decide
theorem cert_e2393373861602 : check e2393373861602 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2393373861614 : Closed e2393373861614 ∧ code e2393373861614 = 11189466883822 := by decide
theorem cert_e2393373861614 : check e2393373861614 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2393373861742 : Closed e2393373861742 ∧ code e2393373861742 = 11189466883950 := by decide
theorem cert_e2393373861742 : check e2393373861742 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2393373861750 : Closed e2393373861750 ∧ code e2393373861750 = 11189466883958 := by decide
theorem cert_e2393373861750 : check e2393373861750 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393373861770 : Closed e2393373861770 ∧ code e2393373861770 = 11189466883978 := by decide
theorem cert_e2393373861770 : check e2393373861770 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393373861794 : Closed e2393373861794 ∧ code e2393373861794 = 11189466884002 := by decide
theorem cert_e2393373861794 : check e2393373861794 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2393373861806 : Closed e2393373861806 ∧ code e2393373861806 = 11189466884014 := by decide
theorem cert_e2393373861806 : check e2393373861806 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2393373861814 : Closed e2393373861814 ∧ code e2393373861814 = 11189466884022 := by decide
theorem cert_e2393373861814 : check e2393373861814 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2393373861818 : Closed e2393373861818 ∧ code e2393373861818 = 11189466884026 := by decide
theorem cert_e2393373861818 : check e2393373861818 [[],[.left],[]] .sourceHead = true := by decide
def e2393373861950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2393373861950 : Closed e2393373861950 ∧ code e2393373861950 = 11189466884158 := by decide
theorem cert_e2393373861950 : check e2393373861950 [[],[.left],[]] .sourceHead = true := by decide
def e2393373862370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393373862370 : Closed e2393373862370 ∧ code e2393373862370 = 11189466884578 := by decide
theorem cert_e2393373862370 : check e2393373862370 [[],[.left],[]] .sourceHead = true := by decide
def e2393373862382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393373862382 : Closed e2393373862382 ∧ code e2393373862382 = 11189466884590 := by decide
theorem cert_e2393373862382 : check e2393373862382 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373863150 : Closed e2393373863150 ∧ code e2393373863150 = 11189466885358 := by decide
theorem cert_e2393373863150 : check e2393373863150 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373863158 : Closed e2393373863158 ∧ code e2393373863158 = 11189466885366 := by decide
theorem cert_e2393373863158 : check e2393373863158 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373863438 : Closed e2393373863438 ∧ code e2393373863438 = 11189466885646 := by decide
theorem cert_e2393373863438 : check e2393373863438 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373863450 : Closed e2393373863450 ∧ code e2393373863450 = 11189466885658 := by decide
theorem cert_e2393373863450 : check e2393373863450 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373863522 : Closed e2393373863522 ∧ code e2393373863522 = 11189466885730 := by decide
theorem cert_e2393373863522 : check e2393373863522 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373863534 : Closed e2393373863534 ∧ code e2393373863534 = 11189466885742 := by decide
theorem cert_e2393373863534 : check e2393373863534 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373863542 : Closed e2393373863542 ∧ code e2393373863542 = 11189466885750 := by decide
theorem cert_e2393373863542 : check e2393373863542 [[],[.left],[]] .sourceHead = true := by decide
def e2393373863546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373863546 : Closed e2393373863546 ∧ code e2393373863546 = 11189466885754 := by decide
theorem cert_e2393373863546 : check e2393373863546 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2393373864054 : Closed e2393373864054 ∧ code e2393373864054 = 11189466886262 := by decide
theorem cert_e2393373864054 : check e2393373864054 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2393373864058 : Closed e2393373864058 ∧ code e2393373864058 = 11189466886266 := by decide
theorem cert_e2393373864058 : check e2393373864058 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2393373864150 : Closed e2393373864150 ∧ code e2393373864150 = 11189466886358 := by decide
theorem cert_e2393373864150 : check e2393373864150 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373864246 : Closed e2393373864246 ∧ code e2393373864246 = 11189466886454 := by decide
theorem cert_e2393373864246 : check e2393373864246 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373864250 : Closed e2393373864250 ∧ code e2393373864250 = 11189466886458 := by decide
theorem cert_e2393373864250 : check e2393373864250 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2393373864334 : Closed e2393373864334 ∧ code e2393373864334 = 11189466886542 := by decide
theorem cert_e2393373864334 : check e2393373864334 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2393373864390 : Closed e2393373864390 ∧ code e2393373864390 = 11189466886598 := by decide
theorem cert_e2393373864390 : check e2393373864390 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2393373864726 : Closed e2393373864726 ∧ code e2393373864726 = 11189466886934 := by decide
theorem cert_e2393373864726 : check e2393373864726 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2393373864802 : Closed e2393373864802 ∧ code e2393373864802 = 11189466887010 := by decide
theorem cert_e2393373864802 : check e2393373864802 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393373864814 : Closed e2393373864814 ∧ code e2393373864814 = 11189466887022 := by decide
theorem cert_e2393373864814 : check e2393373864814 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393373864822 : Closed e2393373864822 ∧ code e2393373864822 = 11189466887030 := by decide
theorem cert_e2393373864822 : check e2393373864822 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393373864842 : Closed e2393373864842 ∧ code e2393373864842 = 11189466887050 := by decide
theorem cert_e2393373864842 : check e2393373864842 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393373864866 : Closed e2393373864866 ∧ code e2393373864866 = 11189466887074 := by decide
theorem cert_e2393373864866 : check e2393373864866 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393373864878 : Closed e2393373864878 ∧ code e2393373864878 = 11189466887086 := by decide
theorem cert_e2393373864878 : check e2393373864878 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e2393373864886 : Closed e2393373864886 ∧ code e2393373864886 = 11189466887094 := by decide
theorem cert_e2393373864886 : check e2393373864886 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393373864890 : Closed e2393373864890 ∧ code e2393373864890 = 11189466887098 := by decide
theorem cert_e2393373864890 : check e2393373864890 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393373864918 : Closed e2393373864918 ∧ code e2393373864918 = 11189466887126 := by decide
theorem cert_e2393373864918 : check e2393373864918 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393373864922 : Closed e2393373864922 ∧ code e2393373864922 = 11189466887130 := by decide
theorem cert_e2393373864922 : check e2393373864922 [[],[.left],[]] .sourceHead = true := by decide
def e2393373864990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2393373864990 : Closed e2393373864990 ∧ code e2393373864990 = 11189466887198 := by decide
theorem cert_e2393373864990 : check e2393373864990 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393373865186 : Closed e2393373865186 ∧ code e2393373865186 = 11189466887394 := by decide
theorem cert_e2393373865186 : check e2393373865186 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373865198 : Closed e2393373865198 ∧ code e2393373865198 = 11189466887406 := by decide
theorem cert_e2393373865198 : check e2393373865198 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373865206 : Closed e2393373865206 ∧ code e2393373865206 = 11189466887414 := by decide
theorem cert_e2393373865206 : check e2393373865206 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373865486 : Closed e2393373865486 ∧ code e2393373865486 = 11189466887694 := by decide
theorem cert_e2393373865486 : check e2393373865486 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373865498 : Closed e2393373865498 ∧ code e2393373865498 = 11189466887706 := by decide
theorem cert_e2393373865498 : check e2393373865498 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373865570 : Closed e2393373865570 ∧ code e2393373865570 = 11189466887778 := by decide
theorem cert_e2393373865570 : check e2393373865570 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373865582 : Closed e2393373865582 ∧ code e2393373865582 = 11189466887790 := by decide
theorem cert_e2393373865582 : check e2393373865582 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373865590 : Closed e2393373865590 ∧ code e2393373865590 = 11189466887798 := by decide
theorem cert_e2393373865590 : check e2393373865590 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373865594 : Closed e2393373865594 ∧ code e2393373865594 = 11189466887802 := by decide
theorem cert_e2393373865594 : check e2393373865594 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373865782 : Closed e2393373865782 ∧ code e2393373865782 = 11189466887990 := by decide
theorem cert_e2393373865782 : check e2393373865782 [[],[.left],[]] .sourceHead = true := by decide
def e2393373865786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373865786 : Closed e2393373865786 ∧ code e2393373865786 = 11189466887994 := by decide
theorem cert_e2393373865786 : check e2393373865786 [[],[.left],[]] .sourceHead = true := by decide
def e2393373870958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393373870958 : Closed e2393373870958 ∧ code e2393373870958 = 11189466893166 := by decide
theorem cert_e2393373870958 : check e2393373870958 [[],[.left],[]] .chain = true := by decide
def e2393373870966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393373870966 : Closed e2393373870966 ∧ code e2393373870966 = 11189466893174 := by decide
theorem cert_e2393373870966 : check e2393373870966 [[],[.left],[]] .chain = true := by decide
def e2393373871022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393373871022 : Closed e2393373871022 ∧ code e2393373871022 = 11189466893230 := by decide
theorem cert_e2393373871022 : check e2393373871022 [[],[.left],[]] .chain = true := by decide
def e2393373871034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393373871034 : Closed e2393373871034 ∧ code e2393373871034 = 11189466893242 := by decide
theorem cert_e2393373871034 : check e2393373871034 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
