import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262374742906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2262374742906 : Closed e2262374742906 ∧ code e2262374742906 = 11058467765114 := by decide
theorem cert_e2262374742906 : check e2262374742906 [[],[.under]] .three = true := by decide
def e2262374742958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2262374742958 : Closed e2262374742958 ∧ code e2262374742958 = 11058467765166 := by decide
theorem cert_e2262374742958 : check e2262374742958 [[],[.under]] .three = true := by decide
def e2262374742966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2262374742966 : Closed e2262374742966 ∧ code e2262374742966 = 11058467765174 := by decide
theorem cert_e2262374742966 : check e2262374742966 [[],[.under]] .three = true := by decide
def e2262374742970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2262374742970 : Closed e2262374742970 ∧ code e2262374742970 = 11058467765178 := by decide
theorem cert_e2262374742970 : check e2262374742970 [[],[.under]] .three = true := by decide
def e2262374742998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2262374742998 : Closed e2262374742998 ∧ code e2262374742998 = 11058467765206 := by decide
private def t_e2262374742998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))
theorem cert_e2262374742998 : ¬ IsSelfInterpreter e2262374742998 :=
  wSource (t := t_e2262374742998) (replay_sound (ps := []) (t := e2262374742998) (by decide)) (by decide)
def e2262374743002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2262374743002 : Closed e2262374743002 ∧ code e2262374743002 = 11058467765210 := by decide
private def t_e2262374743002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))
theorem cert_e2262374743002 : ¬ IsSelfInterpreter e2262374743002 :=
  wSource (t := t_e2262374743002) (replay_sound (ps := []) (t := e2262374743002) (by decide)) (by decide)
def e2262374747886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e2262374747886 : Closed e2262374747886 ∧ code e2262374747886 = 11058467770094 := by decide
theorem cert_e2262374747886 : check e2262374747886 [[],[.under]] .smaller = true := by decide
def e2262374747894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e2262374747894 : Closed e2262374747894 ∧ code e2262374747894 = 11058467770102 := by decide
theorem cert_e2262374747894 : check e2262374747894 [[],[.under]] .smaller = true := by decide
def e2262374748014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e2262374748014 : Closed e2262374748014 ∧ code e2262374748014 = 11058467770222 := by decide
theorem cert_e2262374748014 : check e2262374748014 [[],[.under]] .smaller = true := by decide
def e2262374748026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2262374748026 : Closed e2262374748026 ∧ code e2262374748026 = 11058467770234 := by decide
theorem cert_e2262374748026 : check e2262374748026 [[],[.under]] .smaller = true := by decide
def e2262374748086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e2262374748086 : Closed e2262374748086 ∧ code e2262374748086 = 11058467770294 := by decide
theorem cert_e2262374748086 : check e2262374748086 [[],[.under]] .smaller = true := by decide
def e2262374748090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2262374748090 : Closed e2262374748090 ∧ code e2262374748090 = 11058467770298 := by decide
theorem cert_e2262374748090 : check e2262374748090 [[],[.under]] .smaller = true := by decide
def e2262374750686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2262374750686 : Closed e2262374750686 ∧ code e2262374750686 = 11058467772894 := by decide
theorem cert_e2262374750686 : check e2262374750686 [[],[.under]] .three = true := by decide
def e2262374750710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2262374750710 : Closed e2262374750710 ∧ code e2262374750710 = 11058467772918 := by decide
theorem cert_e2262374750710 : check e2262374750710 [[],[.under]] .three = true := by decide
def e2262374751454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2262374751454 : Closed e2262374751454 ∧ code e2262374751454 = 11058467773662 := by decide
theorem cert_e2262374751454 : check e2262374751454 [[],[.under]] .three = true := by decide
def e2262374751470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e2262374751470 : Closed e2262374751470 ∧ code e2262374751470 = 11058467773678 := by decide
theorem cert_e2262374751470 : check e2262374751470 [[],[.under]] .smaller = true := by decide
def e2262374751478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e2262374751478 : Closed e2262374751478 ∧ code e2262374751478 = 11058467773686 := by decide
theorem cert_e2262374751478 : check e2262374751478 [[],[.under]] .smaller = true := by decide
def e2262374751482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2262374751482 : Closed e2262374751482 ∧ code e2262374751482 = 11058467773690 := by decide
theorem cert_e2262374751482 : check e2262374751482 [[],[.under]] .three = true := by decide
def e2262374751862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e2262374751862 : Closed e2262374751862 ∧ code e2262374751862 = 11058467774070 := by decide
theorem cert_e2262374751862 : check e2262374751862 [[],[.under]] .smaller = true := by decide
def e2262374752054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374752054 : Closed e2262374752054 ∧ code e2262374752054 = 11058467774262 := by decide
theorem cert_e2262374752054 : check e2262374752054 [[],[.under]] .three = true := by decide
def e2262374752058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374752058 : Closed e2262374752058 ∧ code e2262374752058 = 11058467774266 := by decide
theorem cert_e2262374752058 : check e2262374752058 [[],[.under]] .three = true := by decide
def e2262374755694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2262374755694 : Closed e2262374755694 ∧ code e2262374755694 = 11058467777902 := by decide
theorem cert_e2262374755694 : check e2262374755694 [[],[.under]] .smaller = true := by decide
def e2262374755702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2262374755702 : Closed e2262374755702 ∧ code e2262374755702 = 11058467777910 := by decide
theorem cert_e2262374755702 : check e2262374755702 [[],[.under]] .smaller = true := by decide
def e2262374755758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2262374755758 : Closed e2262374755758 ∧ code e2262374755758 = 11058467777966 := by decide
theorem cert_e2262374755758 : check e2262374755758 [[],[.under]] .smaller = true := by decide
def e2262374755770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2262374755770 : Closed e2262374755770 ∧ code e2262374755770 = 11058467777978 := by decide
theorem cert_e2262374755770 : check e2262374755770 [[],[.under]] .smaller = true := by decide
def e2262374755798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2262374755798 : Closed e2262374755798 ∧ code e2262374755798 = 11058467778006 := by decide
theorem cert_e2262374755798 : check e2262374755798 [[],[.under]] .smaller = true := by decide
def e2262374755802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2262374755802 : Closed e2262374755802 ∧ code e2262374755802 = 11058467778010 := by decide
theorem cert_e2262374755802 : check e2262374755802 [[],[.under]] .smaller = true := by decide
def e2262374756014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2262374756014 : Closed e2262374756014 ∧ code e2262374756014 = 11058467778222 := by decide
theorem cert_e2262374756014 : check e2262374756014 [[],[.under]] .smaller = true := by decide
def e2262374756026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2262374756026 : Closed e2262374756026 ∧ code e2262374756026 = 11058467778234 := by decide
theorem cert_e2262374756026 : check e2262374756026 [[],[.under]] .smaller = true := by decide
def e2262374756074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2262374756074 : Closed e2262374756074 ∧ code e2262374756074 = 11058467778282 := by decide
theorem cert_e2262374756074 : check e2262374756074 [[],[.under]] .smaller = true := by decide
def e2262374756182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2262374756182 : Closed e2262374756182 ∧ code e2262374756182 = 11058467778390 := by decide
theorem cert_e2262374756182 : check e2262374756182 [[],[.under]] .smaller = true := by decide
def e2262374756186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2262374756186 : Closed e2262374756186 ∧ code e2262374756186 = 11058467778394 := by decide
theorem cert_e2262374756186 : check e2262374756186 [[],[.under]] .smaller = true := by decide
def e2262374756202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2262374756202 : Closed e2262374756202 ∧ code e2262374756202 = 11058467778410 := by decide
theorem cert_e2262374756202 : check e2262374756202 [[],[.under]] .smaller = true := by decide
def e2262374756830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2262374756830 : Closed e2262374756830 ∧ code e2262374756830 = 11058467779038 := by decide
theorem cert_e2262374756830 : check e2262374756830 [[],[.under]] .three = true := by decide
def e2262374756854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2262374756854 : Closed e2262374756854 ∧ code e2262374756854 = 11058467779062 := by decide
theorem cert_e2262374756854 : check e2262374756854 [[],[.under]] .three = true := by decide
def e2262374757230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2262374757230 : Closed e2262374757230 ∧ code e2262374757230 = 11058467779438 := by decide
theorem cert_e2262374757230 : check e2262374757230 [[],[.under]] .smaller = true := by decide
def e2262374757238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2262374757238 : Closed e2262374757238 ∧ code e2262374757238 = 11058467779446 := by decide
theorem cert_e2262374757238 : check e2262374757238 [[],[.under]] .smaller = true := by decide
def e2262374757294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2262374757294 : Closed e2262374757294 ∧ code e2262374757294 = 11058467779502 := by decide
theorem cert_e2262374757294 : check e2262374757294 [[],[.under]] .smaller = true := by decide
def e2262374757306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2262374757306 : Closed e2262374757306 ∧ code e2262374757306 = 11058467779514 := by decide
theorem cert_e2262374757306 : check e2262374757306 [[],[.under]] .smaller = true := by decide
def e2262374757334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2262374757334 : Closed e2262374757334 ∧ code e2262374757334 = 11058467779542 := by decide
theorem cert_e2262374757334 : check e2262374757334 [[],[.under]] .smaller = true := by decide
def e2262374757338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2262374757338 : Closed e2262374757338 ∧ code e2262374757338 = 11058467779546 := by decide
theorem cert_e2262374757338 : check e2262374757338 [[],[.under]] .smaller = true := by decide
def e2262374757614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2262374757614 : Closed e2262374757614 ∧ code e2262374757614 = 11058467779822 := by decide
theorem cert_e2262374757614 : check e2262374757614 [[],[.under]] .smaller = true := by decide
def e2262374757622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2262374757622 : Closed e2262374757622 ∧ code e2262374757622 = 11058467779830 := by decide
theorem cert_e2262374757622 : check e2262374757622 [[],[.under]] .smaller = true := by decide
def e2262374757950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2262374757950 : Closed e2262374757950 ∧ code e2262374757950 = 11058467780158 := by decide
theorem cert_e2262374757950 : check e2262374757950 [[],[.under]] .three = true := by decide
def e2262374757998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374757998 : Closed e2262374757998 ∧ code e2262374757998 = 11058467780206 := by decide
theorem cert_e2262374757998 : check e2262374757998 [[],[.under]] .smaller = true := by decide
def e2262374758010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374758010 : Closed e2262374758010 ∧ code e2262374758010 = 11058467780218 := by decide
theorem cert_e2262374758010 : check e2262374758010 [[],[.under]] .smaller = true := by decide
def e2262374758198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374758198 : Closed e2262374758198 ∧ code e2262374758198 = 11058467780406 := by decide
theorem cert_e2262374758198 : check e2262374758198 [[],[.under]] .smaller = true := by decide
def e2262374758202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374758202 : Closed e2262374758202 ∧ code e2262374758202 = 11058467780410 := by decide
theorem cert_e2262374758202 : check e2262374758202 [[],[.under]] .smaller = true := by decide
def e2262374758286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2262374758286 : Closed e2262374758286 ∧ code e2262374758286 = 11058467780494 := by decide
theorem cert_e2262374758286 : check e2262374758286 [[],[.under]] .three = true := by decide
def e2262374758622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2262374758622 : Closed e2262374758622 ∧ code e2262374758622 = 11058467780830 := by decide
theorem cert_e2262374758622 : check e2262374758622 [[],[.under]] .three = true := by decide
def e2262374758638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2262374758638 : Closed e2262374758638 ∧ code e2262374758638 = 11058467780846 := by decide
theorem cert_e2262374758638 : check e2262374758638 [[],[.under]] .smaller = true := by decide
def e2262374758646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2262374758646 : Closed e2262374758646 ∧ code e2262374758646 = 11058467780854 := by decide
theorem cert_e2262374758646 : check e2262374758646 [[],[.under]] .smaller = true := by decide
def e2262374758650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2262374758650 : Closed e2262374758650 ∧ code e2262374758650 = 11058467780858 := by decide
theorem cert_e2262374758650 : check e2262374758650 [[],[.under]] .three = true := by decide
def e2262374758830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2262374758830 : Closed e2262374758830 ∧ code e2262374758830 = 11058467781038 := by decide
theorem cert_e2262374758830 : check e2262374758830 [[],[.under]] .smaller = true := by decide
def e2262374758842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2262374758842 : Closed e2262374758842 ∧ code e2262374758842 = 11058467781050 := by decide
theorem cert_e2262374758842 : check e2262374758842 [[],[.under]] .smaller = true := by decide
def e2262374758890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2262374758890 : Closed e2262374758890 ∧ code e2262374758890 = 11058467781098 := by decide
theorem cert_e2262374758890 : check e2262374758890 [[],[.under]] .smaller = true := by decide
def e2262374758974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2262374758974 : Closed e2262374758974 ∧ code e2262374758974 = 11058467781182 := by decide
theorem cert_e2262374758974 : check e2262374758974 [[],[.under]] .three = true := by decide
def e2262374759022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374759022 : Closed e2262374759022 ∧ code e2262374759022 = 11058467781230 := by decide
theorem cert_e2262374759022 : check e2262374759022 [[],[.under]] .smaller = true := by decide
def e2262374759034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374759034 : Closed e2262374759034 ∧ code e2262374759034 = 11058467781242 := by decide
theorem cert_e2262374759034 : check e2262374759034 [[],[.under]] .smaller = true := by decide
def e2262374759198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2262374759198 : Closed e2262374759198 ∧ code e2262374759198 = 11058467781406 := by decide
theorem cert_e2262374759198 : check e2262374759198 [[],[.under]] .smaller = true := by decide
def e2262374759310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2262374759310 : Closed e2262374759310 ∧ code e2262374759310 = 11058467781518 := by decide
theorem cert_e2262374759310 : check e2262374759310 [[],[.under]] .smaller = true := by decide
def e2262374759322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374759322 : Closed e2262374759322 ∧ code e2262374759322 = 11058467781530 := by decide
theorem cert_e2262374759322 : check e2262374759322 [[],[.under]] .smaller = true := by decide
def e2262374759366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2262374759366 : Closed e2262374759366 ∧ code e2262374759366 = 11058467781574 := by decide
theorem cert_e2262374759366 : check e2262374759366 [[],[.under]] .three = true := by decide
def e2262374759390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3)))))))
theorem wire_e2262374759390 : Closed e2262374759390 ∧ code e2262374759390 = 11058467781598 := by decide
theorem cert_e2262374759390 : check e2262374759390 [[],[.under]] .three = true := by decide
def e2262374759542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2262374759542 : Closed e2262374759542 ∧ code e2262374759542 = 11058467781750 := by decide
theorem cert_e2262374759542 : check e2262374759542 [[],[.under]] .smaller = true := by decide
def e2262374759638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2262374759638 : Closed e2262374759638 ∧ code e2262374759638 = 11058467781846 := by decide
theorem cert_e2262374759638 : check e2262374759638 [[],[.under]] .smaller = true := by decide
def e2262374759642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2262374759642 : Closed e2262374759642 ∧ code e2262374759642 = 11058467781850 := by decide
theorem cert_e2262374759642 : check e2262374759642 [[],[.under]] .smaller = true := by decide
def e2262374759658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2262374759658 : Closed e2262374759658 ∧ code e2262374759658 = 11058467781866 := by decide
theorem cert_e2262374759658 : check e2262374759658 [[],[.under]] .smaller = true := by decide
def e2262374759734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374759734 : Closed e2262374759734 ∧ code e2262374759734 = 11058467781942 := by decide
theorem cert_e2262374759734 : check e2262374759734 [[],[.under]] .smaller = true := by decide
def e2262374759738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374759738 : Closed e2262374759738 ∧ code e2262374759738 = 11058467781946 := by decide
theorem cert_e2262374759738 : check e2262374759738 [[],[.under]] .smaller = true := by decide
def e2262374759822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2262374759822 : Closed e2262374759822 ∧ code e2262374759822 = 11058467782030 := by decide
theorem cert_e2262374759822 : check e2262374759822 [[],[.under]] .smaller = true := by decide
def e2262374759834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374759834 : Closed e2262374759834 ∧ code e2262374759834 = 11058467782042 := by decide
theorem cert_e2262374759834 : check e2262374759834 [[],[.under]] .smaller = true := by decide
def e2262374759902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3)))))))
theorem wire_e2262374759902 : Closed e2262374759902 ∧ code e2262374759902 = 11058467782110 := by decide
theorem cert_e2262374759902 : check e2262374759902 [[],[.under]] .three = true := by decide
def e2262374759918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2)))))))
theorem wire_e2262374759918 : Closed e2262374759918 ∧ code e2262374759918 = 11058467782126 := by decide
theorem cert_e2262374759918 : check e2262374759918 [[],[.under]] .three = true := by decide
def e2262374759990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2262374759990 : Closed e2262374759990 ∧ code e2262374759990 = 11058467782198 := by decide
theorem cert_e2262374759990 : check e2262374759990 [[],[.under]] .three = true := by decide
def e2262374759994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2262374759994 : Closed e2262374759994 ∧ code e2262374759994 = 11058467782202 := by decide
theorem cert_e2262374759994 : check e2262374759994 [[],[.under]] .three = true := by decide
def e2262374760078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2262374760078 : Closed e2262374760078 ∧ code e2262374760078 = 11058467782286 := by decide
theorem cert_e2262374760078 : check e2262374760078 [[],[.under]] .three = true := by decide
def e2262374760134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2262374760134 : Closed e2262374760134 ∧ code e2262374760134 = 11058467782342 := by decide
theorem cert_e2262374760134 : check e2262374760134 [[],[.under]] .three = true := by decide
def e2262374760158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3)))))))
theorem wire_e2262374760158 : Closed e2262374760158 ∧ code e2262374760158 = 11058467782366 := by decide
theorem cert_e2262374760158 : check e2262374760158 [[],[.under]] .three = true := by decide
def e2262374760174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2)))))))
theorem wire_e2262374760174 : Closed e2262374760174 ∧ code e2262374760174 = 11058467782382 := by decide
theorem cert_e2262374760174 : check e2262374760174 [[],[.under]] .three = true := by decide
def e2262374760182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1)))))))
theorem wire_e2262374760182 : Closed e2262374760182 ∧ code e2262374760182 = 11058467782390 := by decide
theorem cert_e2262374760182 : check e2262374760182 [[],[.under]] .three = true := by decide
def e2262374761438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2262374761438 : Closed e2262374761438 ∧ code e2262374761438 = 11058467783646 := by decide
theorem cert_e2262374761438 : check e2262374761438 [[],[.under]] .smaller = true := by decide
def e2262374761454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2262374761454 : Closed e2262374761454 ∧ code e2262374761454 = 11058467783662 := by decide
theorem cert_e2262374761454 : check e2262374761454 [[],[.under]] .smaller = true := by decide
def e2262374763374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262374763374 : Closed e2262374763374 ∧ code e2262374763374 = 11058467785582 := by decide
theorem cert_e2262374763374 : check e2262374763374 [[],[.under]] .smaller = true := by decide
def e2262374763382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262374763382 : Closed e2262374763382 ∧ code e2262374763382 = 11058467785590 := by decide
theorem cert_e2262374763382 : check e2262374763382 [[],[.under]] .smaller = true := by decide
def e2262374763438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262374763438 : Closed e2262374763438 ∧ code e2262374763438 = 11058467785646 := by decide
theorem cert_e2262374763438 : check e2262374763438 [[],[.under]] .smaller = true := by decide
def e2262374763450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262374763450 : Closed e2262374763450 ∧ code e2262374763450 = 11058467785658 := by decide
theorem cert_e2262374763450 : check e2262374763450 [[],[.under]] .smaller = true := by decide
def e2262374763478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262374763478 : Closed e2262374763478 ∧ code e2262374763478 = 11058467785686 := by decide
theorem cert_e2262374763478 : check e2262374763478 [[],[.under]] .smaller = true := by decide
def e2262374763482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262374763482 : Closed e2262374763482 ∧ code e2262374763482 = 11058467785690 := by decide
theorem cert_e2262374763482 : check e2262374763482 [[],[.under]] .smaller = true := by decide
def e2262374763758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262374763758 : Closed e2262374763758 ∧ code e2262374763758 = 11058467785966 := by decide
theorem cert_e2262374763758 : check e2262374763758 [[],[.under]] .smaller = true := by decide
def e2262374763766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262374763766 : Closed e2262374763766 ∧ code e2262374763766 = 11058467785974 := by decide
theorem cert_e2262374763766 : check e2262374763766 [[],[.under]] .smaller = true := by decide
def e2262374764094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2262374764094 : Closed e2262374764094 ∧ code e2262374764094 = 11058467786302 := by decide
theorem cert_e2262374764094 : check e2262374764094 [[],[.under]] .three = true := by decide
def e2262374764142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374764142 : Closed e2262374764142 ∧ code e2262374764142 = 11058467786350 := by decide
theorem cert_e2262374764142 : check e2262374764142 [[],[.under]] .smaller = true := by decide
def e2262374764154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374764154 : Closed e2262374764154 ∧ code e2262374764154 = 11058467786362 := by decide
theorem cert_e2262374764154 : check e2262374764154 [[],[.under]] .smaller = true := by decide
def e2262374764342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374764342 : Closed e2262374764342 ∧ code e2262374764342 = 11058467786550 := by decide
theorem cert_e2262374764342 : check e2262374764342 [[],[.under]] .smaller = true := by decide
def e2262374764346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374764346 : Closed e2262374764346 ∧ code e2262374764346 = 11058467786554 := by decide
theorem cert_e2262374764346 : check e2262374764346 [[],[.under]] .smaller = true := by decide
def e2262374764430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2262374764430 : Closed e2262374764430 ∧ code e2262374764430 = 11058467786638 := by decide
theorem cert_e2262374764430 : check e2262374764430 [[],[.under]] .three = true := by decide
def e2262374769118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2262374769118 : Closed e2262374769118 ∧ code e2262374769118 = 11058467791326 := by decide
theorem cert_e2262374769118 : check e2262374769118 [[],[.under]] .smaller = true := by decide
def e2262374769142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2262374769142 : Closed e2262374769142 ∧ code e2262374769142 = 11058467791350 := by decide
theorem cert_e2262374769142 : check e2262374769142 [[],[.under]] .smaller = true := by decide
def e2262374770094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2262374770094 : Closed e2262374770094 ∧ code e2262374770094 = 11058467792302 := by decide
theorem cert_e2262374770094 : check e2262374770094 [[],[.under]] .smaller = true := by decide
def e2262374770106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2262374770106 : Closed e2262374770106 ∧ code e2262374770106 = 11058467792314 := by decide
theorem cert_e2262374770106 : check e2262374770106 [[],[.under]] .smaller = true := by decide
def e2262374770154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2262374770154 : Closed e2262374770154 ∧ code e2262374770154 = 11058467792362 := by decide
theorem cert_e2262374770154 : check e2262374770154 [[],[.under]] .smaller = true := by decide
def e2262374770238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2262374770238 : Closed e2262374770238 ∧ code e2262374770238 = 11058467792446 := by decide
theorem cert_e2262374770238 : check e2262374770238 [[],[.under]] .three = true := by decide
def e2262374770286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374770286 : Closed e2262374770286 ∧ code e2262374770286 = 11058467792494 := by decide
theorem cert_e2262374770286 : check e2262374770286 [[],[.under]] .smaller = true := by decide
def e2262374770298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374770298 : Closed e2262374770298 ∧ code e2262374770298 = 11058467792506 := by decide
theorem cert_e2262374770298 : check e2262374770298 [[],[.under]] .smaller = true := by decide
def e2262374770462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2262374770462 : Closed e2262374770462 ∧ code e2262374770462 = 11058467792670 := by decide
theorem cert_e2262374770462 : check e2262374770462 [[],[.under]] .smaller = true := by decide
def e2262374770574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2262374770574 : Closed e2262374770574 ∧ code e2262374770574 = 11058467792782 := by decide
theorem cert_e2262374770574 : check e2262374770574 [[],[.under]] .smaller = true := by decide
def e2262374770586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374770586 : Closed e2262374770586 ∧ code e2262374770586 = 11058467792794 := by decide
theorem cert_e2262374770586 : check e2262374770586 [[],[.under]] .smaller = true := by decide
def e2262374770630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2262374770630 : Closed e2262374770630 ∧ code e2262374770630 = 11058467792838 := by decide
theorem cert_e2262374770630 : check e2262374770630 [[],[.under]] .three = true := by decide
def e2262374770654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3))))))))
theorem wire_e2262374770654 : Closed e2262374770654 ∧ code e2262374770654 = 11058467792862 := by decide
theorem cert_e2262374770654 : check e2262374770654 [[],[.under]] .three = true := by decide
def e2262374772974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2262374772974 : Closed e2262374772974 ∧ code e2262374772974 = 11058467795182 := by decide
theorem cert_e2262374772974 : check e2262374772974 [[],[.under]] .smaller = true := by decide
def e2262374772982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2262374772982 : Closed e2262374772982 ∧ code e2262374772982 = 11058467795190 := by decide
theorem cert_e2262374772982 : check e2262374772982 [[],[.under]] .smaller = true := by decide
def e2262374773462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2262374773462 : Closed e2262374773462 ∧ code e2262374773462 = 11058467795670 := by decide
theorem cert_e2262374773462 : check e2262374773462 [[],[.under]] .smaller = true := by decide
def e2262374773466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2262374773466 : Closed e2262374773466 ∧ code e2262374773466 = 11058467795674 := by decide
theorem cert_e2262374773466 : check e2262374773466 [[],[.under]] .smaller = true := by decide
def e2262374773482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2262374773482 : Closed e2262374773482 ∧ code e2262374773482 = 11058467795690 := by decide
theorem cert_e2262374773482 : check e2262374773482 [[],[.under]] .smaller = true := by decide
def e2262374773558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374773558 : Closed e2262374773558 ∧ code e2262374773558 = 11058467795766 := by decide
theorem cert_e2262374773558 : check e2262374773558 [[],[.under]] .smaller = true := by decide
def e2262374773562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374773562 : Closed e2262374773562 ∧ code e2262374773562 = 11058467795770 := by decide
theorem cert_e2262374773562 : check e2262374773562 [[],[.under]] .smaller = true := by decide
def e2262374773646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2262374773646 : Closed e2262374773646 ∧ code e2262374773646 = 11058467795854 := by decide
theorem cert_e2262374773646 : check e2262374773646 [[],[.under]] .smaller = true := by decide
def e2262374773658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374773658 : Closed e2262374773658 ∧ code e2262374773658 = 11058467795866 := by decide
theorem cert_e2262374773658 : check e2262374773658 [[],[.under]] .smaller = true := by decide
def e2262374773726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3))))))))
theorem wire_e2262374773726 : Closed e2262374773726 ∧ code e2262374773726 = 11058467795934 := by decide
theorem cert_e2262374773726 : check e2262374773726 [[],[.under]] .three = true := by decide
def e2262374773742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2))))))))
theorem wire_e2262374773742 : Closed e2262374773742 ∧ code e2262374773742 = 11058467795950 := by decide
theorem cert_e2262374773742 : check e2262374773742 [[],[.under]] .three = true := by decide
def e2262374775182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2262374775182 : Closed e2262374775182 ∧ code e2262374775182 = 11058467797390 := by decide
theorem cert_e2262374775182 : check e2262374775182 [[],[.under]] .three = true := by decide
def e2262374775238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2262374775238 : Closed e2262374775238 ∧ code e2262374775238 = 11058467797446 := by decide
theorem cert_e2262374775238 : check e2262374775238 [[],[.under]] .three = true := by decide
def e2262374775262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3))))))))
theorem wire_e2262374775262 : Closed e2262374775262 ∧ code e2262374775262 = 11058467797470 := by decide
theorem cert_e2262374775262 : check e2262374775262 [[],[.under]] .three = true := by decide
def e2262374775278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262374775278 : Closed e2262374775278 ∧ code e2262374775278 = 11058467797486 := by decide
theorem cert_e2262374775278 : check e2262374775278 [[],[.under]] .three = true := by decide
def e2262374775286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1))))))))
theorem wire_e2262374775286 : Closed e2262374775286 ∧ code e2262374775286 = 11058467797494 := by decide
theorem cert_e2262374775286 : check e2262374775286 [[],[.under]] .three = true := by decide
def e2262374778734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2262374778734 : Closed e2262374778734 ∧ code e2262374778734 = 11058467800942 := by decide
theorem cert_e2262374778734 : check e2262374778734 [[],[.under]] .smaller = true := by decide
def e2262374778746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2262374778746 : Closed e2262374778746 ∧ code e2262374778746 = 11058467800954 := by decide
theorem cert_e2262374778746 : check e2262374778746 [[],[.under]] .smaller = true := by decide
def e2262374778842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2262374778842 : Closed e2262374778842 ∧ code e2262374778842 = 11058467801050 := by decide
theorem cert_e2262374778842 : check e2262374778842 [[],[.under]] .smaller = true := by decide
def e2262374780126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2262374780126 : Closed e2262374780126 ∧ code e2262374780126 = 11058467802334 := by decide
theorem cert_e2262374780126 : check e2262374780126 [[],[.under]] .three = true := by decide
def e2262374780142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2262374780142 : Closed e2262374780142 ∧ code e2262374780142 = 11058467802350 := by decide
theorem cert_e2262374780142 : check e2262374780142 [[],[.under]] .smaller = true := by decide
def e2262374780150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2262374780150 : Closed e2262374780150 ∧ code e2262374780150 = 11058467802358 := by decide
theorem cert_e2262374780150 : check e2262374780150 [[],[.under]] .smaller = true := by decide
def e2262374780154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2262374780154 : Closed e2262374780154 ∧ code e2262374780154 = 11058467802362 := by decide
theorem cert_e2262374780154 : check e2262374780154 [[],[.under]] .three = true := by decide
def e2262374780526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374780526 : Closed e2262374780526 ∧ code e2262374780526 = 11058467802734 := by decide
theorem cert_e2262374780526 : check e2262374780526 [[],[.under]] .smaller = true := by decide
def e2262374780538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374780538 : Closed e2262374780538 ∧ code e2262374780538 = 11058467802746 := by decide
theorem cert_e2262374780538 : check e2262374780538 [[],[.under]] .smaller = true := by decide
def e2262374780726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374780726 : Closed e2262374780726 ∧ code e2262374780726 = 11058467802934 := by decide
theorem cert_e2262374780726 : check e2262374780726 [[],[.under]] .smaller = true := by decide
def e2262374780730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374780730 : Closed e2262374780730 ∧ code e2262374780730 = 11058467802938 := by decide
theorem cert_e2262374780730 : check e2262374780730 [[],[.under]] .smaller = true := by decide
def e2262374780826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374780826 : Closed e2262374780826 ∧ code e2262374780826 = 11058467803034 := by decide
theorem cert_e2262374780826 : check e2262374780826 [[],[.under]] .three = true := by decide
def e2262374782638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2262374782638 : Closed e2262374782638 ∧ code e2262374782638 = 11058467804846 := by decide
theorem cert_e2262374782638 : check e2262374782638 [[],[.under]] .smaller = true := by decide
def e2262374782650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2262374782650 : Closed e2262374782650 ∧ code e2262374782650 = 11058467804858 := by decide
theorem cert_e2262374782650 : check e2262374782650 [[],[.under]] .smaller = true := by decide
def e2262374782698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2262374782698 : Closed e2262374782698 ∧ code e2262374782698 = 11058467804906 := by decide
theorem cert_e2262374782698 : check e2262374782698 [[],[.under]] .smaller = true := by decide
def e2262374782890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2262374782890 : Closed e2262374782890 ∧ code e2262374782890 = 11058467805098 := by decide
theorem cert_e2262374782890 : check e2262374782890 [[],[.under]] .smaller = true := by decide
def e2262374783198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2262374783198 : Closed e2262374783198 ∧ code e2262374783198 = 11058467805406 := by decide
theorem cert_e2262374783198 : check e2262374783198 [[],[.under]] .three = true := by decide
def e2262374783214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2262374783214 : Closed e2262374783214 ∧ code e2262374783214 = 11058467805422 := by decide
theorem cert_e2262374783214 : check e2262374783214 [[],[.under]] .smaller = true := by decide
def e2262374783222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2262374783222 : Closed e2262374783222 ∧ code e2262374783222 = 11058467805430 := by decide
theorem cert_e2262374783222 : check e2262374783222 [[],[.under]] .smaller = true := by decide
def e2262374783226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2262374783226 : Closed e2262374783226 ∧ code e2262374783226 = 11058467805434 := by decide
theorem cert_e2262374783226 : check e2262374783226 [[],[.under]] .three = true := by decide
def e2262374783406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2262374783406 : Closed e2262374783406 ∧ code e2262374783406 = 11058467805614 := by decide
theorem cert_e2262374783406 : check e2262374783406 [[],[.under]] .smaller = true := by decide
def e2262374783418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2262374783418 : Closed e2262374783418 ∧ code e2262374783418 = 11058467805626 := by decide
theorem cert_e2262374783418 : check e2262374783418 [[],[.under]] .smaller = true := by decide
def e2262374783466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2262374783466 : Closed e2262374783466 ∧ code e2262374783466 = 11058467805674 := by decide
theorem cert_e2262374783466 : check e2262374783466 [[],[.under]] .smaller = true := by decide
def e2262374783550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2262374783550 : Closed e2262374783550 ∧ code e2262374783550 = 11058467805758 := by decide
theorem cert_e2262374783550 : check e2262374783550 [[],[.under]] .three = true := by decide
def e2262374783598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374783598 : Closed e2262374783598 ∧ code e2262374783598 = 11058467805806 := by decide
theorem cert_e2262374783598 : check e2262374783598 [[],[.under]] .smaller = true := by decide
def e2262374783610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374783610 : Closed e2262374783610 ∧ code e2262374783610 = 11058467805818 := by decide
theorem cert_e2262374783610 : check e2262374783610 [[],[.under]] .smaller = true := by decide
def e2262374783774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2262374783774 : Closed e2262374783774 ∧ code e2262374783774 = 11058467805982 := by decide
theorem cert_e2262374783774 : check e2262374783774 [[],[.under]] .smaller = true := by decide
def e2262374783886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2262374783886 : Closed e2262374783886 ∧ code e2262374783886 = 11058467806094 := by decide
theorem cert_e2262374783886 : check e2262374783886 [[],[.under]] .smaller = true := by decide
def e2262374783898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374783898 : Closed e2262374783898 ∧ code e2262374783898 = 11058467806106 := by decide
theorem cert_e2262374783898 : check e2262374783898 [[],[.under]] .smaller = true := by decide
def e2262374783942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2262374783942 : Closed e2262374783942 ∧ code e2262374783942 = 11058467806150 := by decide
theorem cert_e2262374783942 : check e2262374783942 [[],[.under]] .three = true := by decide
def e2262374783966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e2262374783966 : Closed e2262374783966 ∧ code e2262374783966 = 11058467806174 := by decide
theorem cert_e2262374783966 : check e2262374783966 [[],[.under]] .three = true := by decide
def e2262374784110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2262374784110 : Closed e2262374784110 ∧ code e2262374784110 = 11058467806318 := by decide
theorem cert_e2262374784110 : check e2262374784110 [[],[.under]] .smaller = true := by decide
def e2262374784122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2262374784122 : Closed e2262374784122 ∧ code e2262374784122 = 11058467806330 := by decide
theorem cert_e2262374784122 : check e2262374784122 [[],[.under]] .smaller = true := by decide
def e2262374784286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2262374784286 : Closed e2262374784286 ∧ code e2262374784286 = 11058467806494 := by decide
theorem cert_e2262374784286 : check e2262374784286 [[],[.under]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262374742998
#print axioms Blc.Floor43.cert_e2262374743002
