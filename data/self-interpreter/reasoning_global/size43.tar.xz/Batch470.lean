import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406956830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2422406956830 : Closed e2422406956830 ∧ code e2422406956830 = 11218499979038 := by decide
theorem cert_e2422406956830 : check e2422406956830 [[],[]] .chain = true := by decide
def e2422406956942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2422406956942 : Closed e2422406956942 ∧ code e2422406956942 = 11218499979150 := by decide
theorem cert_e2422406956942 : check e2422406956942 [[],[]] .chain = true := by decide
def e2422406958638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422406958638 : Closed e2422406958638 ∧ code e2422406958638 = 11218499980846 := by decide
theorem cert_e2422406958638 : check e2422406958638 [[],[]] .chain = true := by decide
def e2422406958818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422406958818 : Closed e2422406958818 ∧ code e2422406958818 = 11218499981026 := by decide
theorem cert_e2422406958818 : check e2422406958818 [[],[]] .chain = true := by decide
def e2422406958830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2422406958830 : Closed e2422406958830 ∧ code e2422406958830 = 11218499981038 := by decide
theorem cert_e2422406958830 : check e2422406958830 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406958870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422406958870 : Closed e2422406958870 ∧ code e2422406958870 = 11218499981078 := by decide
theorem cert_e2422406958870 : check e2422406958870 [[],[]] .chain = true := by decide
def e2422406958946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422406958946 : Closed e2422406958946 ∧ code e2422406958946 = 11218499981154 := by decide
theorem cert_e2422406958946 : check e2422406958946 [[],[]] .chain = true := by decide
def e2422406958958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2422406958958 : Closed e2422406958958 ∧ code e2422406958958 = 11218499981166 := by decide
theorem cert_e2422406958958 : check e2422406958958 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406958966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2422406958966 : Closed e2422406958966 ∧ code e2422406958966 = 11218499981174 := by decide
theorem cert_e2422406958966 : checkPay e2422406958966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406961214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2422406961214 : Closed e2422406961214 ∧ code e2422406961214 = 11218499983422 := by decide
theorem cert_e2422406961214 : check e2422406961214 [[],[]] .chain = true := by decide
def e2422406961634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406961634 : Closed e2422406961634 ∧ code e2422406961634 = 11218499983842 := by decide
theorem cert_e2422406961634 : check e2422406961634 [[],[]] .chain = true := by decide
def e2422406961646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406961646 : Closed e2422406961646 ∧ code e2422406961646 = 11218499983854 := by decide
theorem cert_e2422406961646 : check e2422406961646 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406962206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2422406962206 : Closed e2422406962206 ∧ code e2422406962206 = 11218499984414 := by decide
theorem cert_e2422406962206 : check e2422406962206 [[],[]] .chain = true := by decide
def e2422406962402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406962402 : Closed e2422406962402 ∧ code e2422406962402 = 11218499984610 := by decide
theorem cert_e2422406962402 : check e2422406962402 [[],[]] .chain = true := by decide
def e2422406962414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406962414 : Closed e2422406962414 ∧ code e2422406962414 = 11218499984622 := by decide
theorem cert_e2422406962414 : check e2422406962414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406962422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406962422 : Closed e2422406962422 ∧ code e2422406962422 = 11218499984630 := by decide
theorem cert_e2422406962422 : check e2422406962422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406963246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422406963246 : Closed e2422406963246 ∧ code e2422406963246 = 11218499985454 := by decide
theorem cert_e2422406963246 : check e2422406963246 [[],[]] .chain = true := by decide
def e2422406963438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422406963438 : Closed e2422406963438 ∧ code e2422406963438 = 11218499985646 := by decide
theorem cert_e2422406963438 : check e2422406963438 [[],[]] .chain = true := by decide
def e2422406963450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422406963450 : Closed e2422406963450 ∧ code e2422406963450 = 11218499985658 := by decide
theorem cert_e2422406963450 : check e2422406963450 [[],[]] .chain = true := by decide
def e2422406963630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422406963630 : Closed e2422406963630 ∧ code e2422406963630 = 11218499985838 := by decide
theorem cert_e2422406963630 : check e2422406963630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406963822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406963822 : Closed e2422406963822 ∧ code e2422406963822 = 11218499986030 := by decide
theorem cert_e2422406963822 : check e2422406963822 [[],[]] .chain = true := by decide
def e2422406963834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406963834 : Closed e2422406963834 ∧ code e2422406963834 = 11218499986042 := by decide
theorem cert_e2422406963834 : check e2422406963834 [[],[]] .chain = true := by decide
def e2422406963998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422406963998 : Closed e2422406963998 ∧ code e2422406963998 = 11218499986206 := by decide
theorem cert_e2422406963998 : check e2422406963998 [[],[]] .chain = true := by decide
def e2422406964166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422406964166 : Closed e2422406964166 ∧ code e2422406964166 = 11218499986374 := by decide
theorem cert_e2422406964166 : check e2422406964166 [[],[]] .chain = true := by decide
def e2422406964782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422406964782 : Closed e2422406964782 ∧ code e2422406964782 = 11218499986990 := by decide
theorem cert_e2422406964782 : check e2422406964782 [[],[]] .chain = true := by decide
def e2422406964962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422406964962 : Closed e2422406964962 ∧ code e2422406964962 = 11218499987170 := by decide
theorem cert_e2422406964962 : check e2422406964962 [[],[]] .chain = true := by decide
def e2422406964974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2422406964974 : Closed e2422406964974 ∧ code e2422406964974 = 11218499987182 := by decide
theorem cert_e2422406964974 : check e2422406964974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406965102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422406965102 : Closed e2422406965102 ∧ code e2422406965102 = 11218499987310 := by decide
theorem cert_e2422406965102 : check e2422406965102 [[],[]] .chain = true := by decide
def e2422406965110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2422406965110 : Closed e2422406965110 ∧ code e2422406965110 = 11218499987318 := by decide
theorem cert_e2422406965110 : check e2422406965110 [[],[]] .chain = true := by decide
def e2422406965130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406965130 : Closed e2422406965130 ∧ code e2422406965130 = 11218499987338 := by decide
theorem cert_e2422406965130 : check e2422406965130 [[],[]] .chain = true := by decide
def e2422406965154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422406965154 : Closed e2422406965154 ∧ code e2422406965154 = 11218499987362 := by decide
theorem cert_e2422406965154 : check e2422406965154 [[],[]] .chain = true := by decide
def e2422406965166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2422406965166 : Closed e2422406965166 ∧ code e2422406965166 = 11218499987374 := by decide
theorem cert_e2422406965166 : check e2422406965166 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406965174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2422406965174 : Closed e2422406965174 ∧ code e2422406965174 = 11218499987382 := by decide
theorem cert_e2422406965174 : check e2422406965174 [[],[]] .chain = true := by decide
def e2422406965178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2422406965178 : Closed e2422406965178 ∧ code e2422406965178 = 11218499987386 := by decide
theorem cert_e2422406965178 : check e2422406965178 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406965310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2422406965310 : Closed e2422406965310 ∧ code e2422406965310 = 11218499987518 := by decide
theorem cert_e2422406965310 : check e2422406965310 [[],[]] .chain = true := by decide
def e2422406965730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406965730 : Closed e2422406965730 ∧ code e2422406965730 = 11218499987938 := by decide
theorem cert_e2422406965730 : check e2422406965730 [[],[]] .chain = true := by decide
def e2422406965742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406965742 : Closed e2422406965742 ∧ code e2422406965742 = 11218499987950 := by decide
theorem cert_e2422406965742 : check e2422406965742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406966510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406966510 : Closed e2422406966510 ∧ code e2422406966510 = 11218499988718 := by decide
theorem cert_e2422406966510 : check e2422406966510 [[],[]] .chain = true := by decide
def e2422406966518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406966518 : Closed e2422406966518 ∧ code e2422406966518 = 11218499988726 := by decide
theorem cert_e2422406966518 : check e2422406966518 [[],[]] .chain = true := by decide
def e2422406966786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406966786 : Closed e2422406966786 ∧ code e2422406966786 = 11218499988994 := by decide
theorem cert_e2422406966786 : check e2422406966786 [[],[]] .chain = true := by decide
def e2422406966798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2422406966798 : Closed e2422406966798 ∧ code e2422406966798 = 11218499989006 := by decide
theorem cert_e2422406966798 : check e2422406966798 [[],[]] .chain = true := by decide
def e2422406966810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406966810 : Closed e2422406966810 ∧ code e2422406966810 = 11218499989018 := by decide
theorem cert_e2422406966810 : check e2422406966810 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2422406966882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406966882 : Closed e2422406966882 ∧ code e2422406966882 = 11218499989090 := by decide
theorem cert_e2422406966882 : check e2422406966882 [[],[]] .chain = true := by decide
def e2422406966894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406966894 : Closed e2422406966894 ∧ code e2422406966894 = 11218499989102 := by decide
theorem cert_e2422406966894 : check e2422406966894 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422406966902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406966902 : Closed e2422406966902 ∧ code e2422406966902 = 11218499989110 := by decide
theorem cert_e2422406966902 : check e2422406966902 [[],[]] .chain = true := by decide
def e2422406966906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406966906 : Closed e2422406966906 ∧ code e2422406966906 = 11218499989114 := by decide
theorem cert_e2422406966906 : check e2422406966906 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406967318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422406967318 : Closed e2422406967318 ∧ code e2422406967318 = 11218499989526 := by decide
theorem cert_e2422406967318 : check e2422406967318 [[],[]] .chain = true := by decide
def e2422406967414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422406967414 : Closed e2422406967414 ∧ code e2422406967414 = 11218499989622 := by decide
theorem cert_e2422406967414 : check e2422406967414 [[],[]] .chain = true := by decide
def e2422406967418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2422406967418 : Closed e2422406967418 ∧ code e2422406967418 = 11218499989626 := by decide
theorem cert_e2422406967418 : check e2422406967418 [[],[]] .chain = true := by decide
def e2422406967510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422406967510 : Closed e2422406967510 ∧ code e2422406967510 = 11218499989718 := by decide
theorem cert_e2422406967510 : checkPay e2422406967510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406967606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406967606 : Closed e2422406967606 ∧ code e2422406967606 = 11218499989814 := by decide
theorem cert_e2422406967606 : check e2422406967606 [[],[]] .chain = true := by decide
def e2422406967610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406967610 : Closed e2422406967610 ∧ code e2422406967610 = 11218499989818 := by decide
theorem cert_e2422406967610 : check e2422406967610 [[],[]] .chain = true := by decide
def e2422406967694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422406967694 : Closed e2422406967694 ∧ code e2422406967694 = 11218499989902 := by decide
theorem cert_e2422406967694 : check e2422406967694 [[],[]] .chain = true := by decide
def e2422406967750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2422406967750 : Closed e2422406967750 ∧ code e2422406967750 = 11218499989958 := by decide
theorem cert_e2422406967750 : check e2422406967750 [[],[]] .chain = true := by decide
def e2422406968086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422406968086 : Closed e2422406968086 ∧ code e2422406968086 = 11218499990294 := by decide
theorem cert_e2422406968086 : check e2422406968086 [[],[]] .chain = true := by decide
def e2422406968162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422406968162 : Closed e2422406968162 ∧ code e2422406968162 = 11218499990370 := by decide
theorem cert_e2422406968162 : check e2422406968162 [[],[]] .chain = true := by decide
def e2422406968174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422406968174 : Closed e2422406968174 ∧ code e2422406968174 = 11218499990382 := by decide
theorem cert_e2422406968174 : check e2422406968174 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406968182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422406968182 : Closed e2422406968182 ∧ code e2422406968182 = 11218499990390 := by decide
theorem cert_e2422406968182 : checkPay e2422406968182 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406968202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406968202 : Closed e2422406968202 ∧ code e2422406968202 = 11218499990410 := by decide
theorem cert_e2422406968202 : check e2422406968202 [[],[]] .chain = true := by decide
def e2422406968226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422406968226 : Closed e2422406968226 ∧ code e2422406968226 = 11218499990434 := by decide
theorem cert_e2422406968226 : check e2422406968226 [[],[]] .chain = true := by decide
def e2422406968238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422406968238 : Closed e2422406968238 ∧ code e2422406968238 = 11218499990446 := by decide
theorem cert_e2422406968238 : check e2422406968238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406968246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2422406968246 : Closed e2422406968246 ∧ code e2422406968246 = 11218499990454 := by decide
theorem cert_e2422406968246 : check e2422406968246 [[],[]] .chain = true := by decide
def e2422406968250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422406968250 : Closed e2422406968250 ∧ code e2422406968250 = 11218499990458 := by decide
theorem cert_e2422406968250 : check e2422406968250 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406968278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422406968278 : Closed e2422406968278 ∧ code e2422406968278 = 11218499990486 := by decide
theorem cert_e2422406968278 : checkPay e2422406968278 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406968282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422406968282 : Closed e2422406968282 ∧ code e2422406968282 = 11218499990490 := by decide
theorem cert_e2422406968282 : check e2422406968282 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406968350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2422406968350 : Closed e2422406968350 ∧ code e2422406968350 = 11218499990558 := by decide
theorem cert_e2422406968350 : check e2422406968350 [[],[]] .chain = true := by decide
def e2422406968546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406968546 : Closed e2422406968546 ∧ code e2422406968546 = 11218499990754 := by decide
theorem cert_e2422406968546 : check e2422406968546 [[],[]] .chain = true := by decide
def e2422406968558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406968558 : Closed e2422406968558 ∧ code e2422406968558 = 11218499990766 := by decide
theorem cert_e2422406968558 : check e2422406968558 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406968566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406968566 : Closed e2422406968566 ∧ code e2422406968566 = 11218499990774 := by decide
theorem cert_e2422406968566 : check e2422406968566 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406968834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406968834 : Closed e2422406968834 ∧ code e2422406968834 = 11218499991042 := by decide
theorem cert_e2422406968834 : check e2422406968834 [[],[]] .chain = true := by decide
def e2422406968846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2422406968846 : Closed e2422406968846 ∧ code e2422406968846 = 11218499991054 := by decide
theorem cert_e2422406968846 : check e2422406968846 [[],[]] .chain = true := by decide
def e2422406968858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406968858 : Closed e2422406968858 ∧ code e2422406968858 = 11218499991066 := by decide
theorem cert_e2422406968858 : check e2422406968858 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2422406968930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406968930 : Closed e2422406968930 ∧ code e2422406968930 = 11218499991138 := by decide
theorem cert_e2422406968930 : check e2422406968930 [[],[]] .chain = true := by decide
def e2422406968942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406968942 : Closed e2422406968942 ∧ code e2422406968942 = 11218499991150 := by decide
theorem cert_e2422406968942 : check e2422406968942 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422406968950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406968950 : Closed e2422406968950 ∧ code e2422406968950 = 11218499991158 := by decide
theorem cert_e2422406968950 : check e2422406968950 [[],[]] .chain = true := by decide
def e2422406968954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406968954 : Closed e2422406968954 ∧ code e2422406968954 = 11218499991162 := by decide
theorem cert_e2422406968954 : check e2422406968954 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406969142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406969142 : Closed e2422406969142 ∧ code e2422406969142 = 11218499991350 := by decide
theorem cert_e2422406969142 : check e2422406969142 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406969146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406969146 : Closed e2422406969146 ∧ code e2422406969146 = 11218499991354 := by decide
theorem cert_e2422406969146 : check e2422406969146 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406974318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422406974318 : Closed e2422406974318 ∧ code e2422406974318 = 11218499996526 := by decide
theorem cert_e2422406974318 : check e2422406974318 [[],[]] .smaller = true := by decide
def e2422406974326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422406974326 : Closed e2422406974326 ∧ code e2422406974326 = 11218499996534 := by decide
theorem cert_e2422406974326 : check e2422406974326 [[],[]] .smaller = true := by decide
def e2422406974382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422406974382 : Closed e2422406974382 ∧ code e2422406974382 = 11218499996590 := by decide
theorem cert_e2422406974382 : check e2422406974382 [[],[]] .smaller = true := by decide
def e2422406974394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422406974394 : Closed e2422406974394 ∧ code e2422406974394 = 11218499996602 := by decide
theorem cert_e2422406974394 : check e2422406974394 [[],[]] .smaller = true := by decide
def e2422406974422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422406974422 : Closed e2422406974422 ∧ code e2422406974422 = 11218499996630 := by decide
theorem cert_e2422406974422 : check e2422406974422 [[],[]] .smaller = true := by decide
def e2422406974426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422406974426 : Closed e2422406974426 ∧ code e2422406974426 = 11218499996634 := by decide
theorem cert_e2422406974426 : check e2422406974426 [[],[]] .smaller = true := by decide
def e2422406974702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422406974702 : Closed e2422406974702 ∧ code e2422406974702 = 11218499996910 := by decide
theorem cert_e2422406974702 : check e2422406974702 [[],[]] .smaller = true := by decide
def e2422406974710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422406974710 : Closed e2422406974710 ∧ code e2422406974710 = 11218499996918 := by decide
theorem cert_e2422406974710 : check e2422406974710 [[],[]] .smaller = true := by decide
def e2422406975086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422406975086 : Closed e2422406975086 ∧ code e2422406975086 = 11218499997294 := by decide
theorem cert_e2422406975086 : check e2422406975086 [[],[]] .smaller = true := by decide
def e2422406975098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422406975098 : Closed e2422406975098 ∧ code e2422406975098 = 11218499997306 := by decide
theorem cert_e2422406975098 : check e2422406975098 [[],[]] .smaller = true := by decide
def e2422406975286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422406975286 : Closed e2422406975286 ∧ code e2422406975286 = 11218499997494 := by decide
theorem cert_e2422406975286 : check e2422406975286 [[],[]] .smaller = true := by decide
def e2422406975290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422406975290 : Closed e2422406975290 ∧ code e2422406975290 = 11218499997498 := by decide
theorem cert_e2422406975290 : check e2422406975290 [[],[]] .smaller = true := by decide
def e2422406983214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422406983214 : Closed e2422406983214 ∧ code e2422406983214 = 11218500005422 := by decide
theorem cert_e2422406983214 : check e2422406983214 [[],[]] .chain = true := by decide
def e2422406983394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422406983394 : Closed e2422406983394 ∧ code e2422406983394 = 11218500005602 := by decide
theorem cert_e2422406983394 : check e2422406983394 [[],[]] .chain = true := by decide
def e2422406983406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2422406983406 : Closed e2422406983406 ∧ code e2422406983406 = 11218500005614 := by decide
theorem cert_e2422406983406 : check e2422406983406 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406983446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422406983446 : Closed e2422406983446 ∧ code e2422406983446 = 11218500005654 := by decide
theorem cert_e2422406983446 : check e2422406983446 [[],[]] .chain = true := by decide
def e2422406983522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422406983522 : Closed e2422406983522 ∧ code e2422406983522 = 11218500005730 := by decide
theorem cert_e2422406983522 : check e2422406983522 [[],[]] .chain = true := by decide
def e2422406983534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2422406983534 : Closed e2422406983534 ∧ code e2422406983534 = 11218500005742 := by decide
theorem cert_e2422406983534 : checkPay e2422406983534 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406983542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2422406983542 : Closed e2422406983542 ∧ code e2422406983542 = 11218500005750 := by decide
theorem cert_e2422406983542 : check e2422406983542 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406985790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2422406985790 : Closed e2422406985790 ∧ code e2422406985790 = 11218500007998 := by decide
theorem cert_e2422406985790 : check e2422406985790 [[],[]] .chain = true := by decide
def e2422406986210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422406986210 : Closed e2422406986210 ∧ code e2422406986210 = 11218500008418 := by decide
theorem cert_e2422406986210 : check e2422406986210 [[],[]] .chain = true := by decide
def e2422406986222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2422406986222 : Closed e2422406986222 ∧ code e2422406986222 = 11218500008430 := by decide
theorem cert_e2422406986222 : check e2422406986222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406986782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2422406986782 : Closed e2422406986782 ∧ code e2422406986782 = 11218500008990 := by decide
theorem cert_e2422406986782 : check e2422406986782 [[],[]] .chain = true := by decide
def e2422406986978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422406986978 : Closed e2422406986978 ∧ code e2422406986978 = 11218500009186 := by decide
theorem cert_e2422406986978 : check e2422406986978 [[],[]] .chain = true := by decide
def e2422406986990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2422406986990 : Closed e2422406986990 ∧ code e2422406986990 = 11218500009198 := by decide
theorem cert_e2422406986990 : check e2422406986990 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406986998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2422406986998 : Closed e2422406986998 ∧ code e2422406986998 = 11218500009206 := by decide
theorem cert_e2422406986998 : check e2422406986998 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407004606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422407004606 : Closed e2422407004606 ∧ code e2422407004606 = 11218500026814 := by decide
theorem cert_e2422407004606 : check e2422407004606 [[],[]] .chain = true := by decide
def e2422407004666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422407004666 : Closed e2422407004666 ∧ code e2422407004666 = 11218500026874 := by decide
theorem cert_e2422407004666 : check e2422407004666 [[],[]] .chain = true := by decide
def e2422407005758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422407005758 : Closed e2422407005758 ∧ code e2422407005758 = 11218500027966 := by decide
theorem cert_e2422407005758 : check e2422407005758 [[],[]] .chain = true := by decide
def e2422407006150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422407006150 : Closed e2422407006150 ∧ code e2422407006150 = 11218500028358 := by decide
theorem cert_e2422407006150 : check e2422407006150 [[],[]] .chain = true := by decide
def e2422407006174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2422407006174 : Closed e2422407006174 ∧ code e2422407006174 = 11218500028382 := by decide
theorem cert_e2422407006174 : check e2422407006174 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2422407009838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422407009838 : Closed e2422407009838 ∧ code e2422407009838 = 11218500032046 := by decide
theorem cert_e2422407009838 : check e2422407009838 [[],[]] .chain = true := by decide
def e2422407010018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422407010018 : Closed e2422407010018 ∧ code e2422407010018 = 11218500032226 := by decide
theorem cert_e2422407010018 : check e2422407010018 [[],[]] .chain = true := by decide
def e2422407010030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2422407010030 : Closed e2422407010030 ∧ code e2422407010030 = 11218500032238 := by decide
def e2422407010158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2422407010158 : Closed e2422407010158 ∧ code e2422407010158 = 11218500032366 := by decide
theorem cert_e2422407010158 : check e2422407010158 [[],[]] .chain = true := by decide
def e2422407010166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2422407010166 : Closed e2422407010166 ∧ code e2422407010166 = 11218500032374 := by decide
theorem cert_e2422407010166 : check e2422407010166 [[],[]] .chain = true := by decide
def e2422407010186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407010186 : Closed e2422407010186 ∧ code e2422407010186 = 11218500032394 := by decide
theorem cert_e2422407010186 : check e2422407010186 [[],[]] .chain = true := by decide
def e2422407010210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407010210 : Closed e2422407010210 ∧ code e2422407010210 = 11218500032418 := by decide
theorem cert_e2422407010210 : check e2422407010210 [[],[]] .chain = true := by decide
def e2422407010222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2422407010222 : Closed e2422407010222 ∧ code e2422407010222 = 11218500032430 := by decide
theorem cert_e2422407010222 : check e2422407010222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407010230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2422407010230 : Closed e2422407010230 ∧ code e2422407010230 = 11218500032438 := by decide
theorem cert_e2422407010230 : check e2422407010230 [[],[]] .chain = true := by decide
def e2422407010234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2422407010234 : Closed e2422407010234 ∧ code e2422407010234 = 11218500032442 := by decide
theorem cert_e2422407010234 : check e2422407010234 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422407010366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2422407010366 : Closed e2422407010366 ∧ code e2422407010366 = 11218500032574 := by decide
theorem cert_e2422407010366 : check e2422407010366 [[],[]] .chain = true := by decide
def e2422407010786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407010786 : Closed e2422407010786 ∧ code e2422407010786 = 11218500032994 := by decide
theorem cert_e2422407010786 : check e2422407010786 [[],[]] .chain = true := by decide
def e2422407010798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2422407010798 : Closed e2422407010798 ∧ code e2422407010798 = 11218500033006 := by decide
theorem cert_e2422407010798 : check e2422407010798 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407011566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407011566 : Closed e2422407011566 ∧ code e2422407011566 = 11218500033774 := by decide
theorem cert_e2422407011566 : check e2422407011566 [[],[]] .chain = true := by decide
def e2422407011574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407011574 : Closed e2422407011574 ∧ code e2422407011574 = 11218500033782 := by decide
theorem cert_e2422407011574 : check e2422407011574 [[],[]] .chain = true := by decide
def e2422407011842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407011842 : Closed e2422407011842 ∧ code e2422407011842 = 11218500034050 := by decide
theorem cert_e2422407011842 : check e2422407011842 [[],[]] .chain = true := by decide
def e2422407011854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407011854 : Closed e2422407011854 ∧ code e2422407011854 = 11218500034062 := by decide
theorem cert_e2422407011854 : check e2422407011854 [[],[]] .chain = true := by decide
def e2422407011866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407011866 : Closed e2422407011866 ∧ code e2422407011866 = 11218500034074 := by decide
theorem cert_e2422407011866 : check e2422407011866 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407011938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407011938 : Closed e2422407011938 ∧ code e2422407011938 = 11218500034146 := by decide
theorem cert_e2422407011938 : check e2422407011938 [[],[]] .chain = true := by decide
def e2422407011950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407011950 : Closed e2422407011950 ∧ code e2422407011950 = 11218500034158 := by decide
theorem cert_e2422407011950 : check e2422407011950 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407011958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407011958 : Closed e2422407011958 ∧ code e2422407011958 = 11218500034166 := by decide
theorem cert_e2422407011958 : check e2422407011958 [[],[]] .chain = true := by decide
def e2422407011962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407011962 : Closed e2422407011962 ∧ code e2422407011962 = 11218500034170 := by decide
theorem cert_e2422407011962 : check e2422407011962 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407020766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422407020766 : Closed e2422407020766 ∧ code e2422407020766 = 11218500042974 := by decide
theorem cert_e2422407020766 : check e2422407020766 [[],[]] .chain = true := by decide
def e2422407020794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422407020794 : Closed e2422407020794 ∧ code e2422407020794 = 11218500043002 := by decide
theorem cert_e2422407020794 : check e2422407020794 [[],[]] .chain = true := by decide
def e2422407021342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422407021342 : Closed e2422407021342 ∧ code e2422407021342 = 11218500043550 := by decide
theorem cert_e2422407021342 : check e2422407021342 [[],[]] .chain = true := by decide
def e2422407021510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422407021510 : Closed e2422407021510 ∧ code e2422407021510 = 11218500043718 := by decide
theorem cert_e2422407021510 : check e2422407021510 [[],[]] .chain = true := by decide
def e2422407021534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407021534 : Closed e2422407021534 ∧ code e2422407021534 = 11218500043742 := by decide
theorem cert_e2422407021534 : checkPay e2422407021534 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e2422407021550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407021550 : Closed e2422407021550 ∧ code e2422407021550 = 11218500043758 := by decide
theorem cert_e2422407021550 : check e2422407021550 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2422407023382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422407023382 : Closed e2422407023382 ∧ code e2422407023382 = 11218500045590 := by decide
theorem cert_e2422407023382 : check e2422407023382 [[],[]] .chain = true := by decide
def e2422407023458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422407023458 : Closed e2422407023458 ∧ code e2422407023458 = 11218500045666 := by decide
theorem cert_e2422407023458 : check e2422407023458 [[],[]] .chain = true := by decide
def e2422407023470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407023470 : Closed e2422407023470 ∧ code e2422407023470 = 11218500045678 := by decide
theorem cert_e2422407023470 : check e2422407023470 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407023478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407023478 : Closed e2422407023478 ∧ code e2422407023478 = 11218500045686 := by decide
theorem cert_e2422407023478 : check e2422407023478 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422407023498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407023498 : Closed e2422407023498 ∧ code e2422407023498 = 11218500045706 := by decide
theorem cert_e2422407023498 : check e2422407023498 [[],[]] .chain = true := by decide
def e2422407023522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407023522 : Closed e2422407023522 ∧ code e2422407023522 = 11218500045730 := by decide
theorem cert_e2422407023522 : check e2422407023522 [[],[]] .chain = true := by decide
def e2422407023534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407023534 : Closed e2422407023534 ∧ code e2422407023534 = 11218500045742 := by decide
theorem cert_e2422407023534 : check e2422407023534 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407023542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2422407023542 : Closed e2422407023542 ∧ code e2422407023542 = 11218500045750 := by decide
theorem cert_e2422407023542 : check e2422407023542 [[],[]] .chain = true := by decide
def e2422407023546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407023546 : Closed e2422407023546 ∧ code e2422407023546 = 11218500045754 := by decide
theorem cert_e2422407023546 : check e2422407023546 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407023574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407023574 : Closed e2422407023574 ∧ code e2422407023574 = 11218500045782 := by decide
theorem cert_e2422407023574 : check e2422407023574 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407023578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407023578 : Closed e2422407023578 ∧ code e2422407023578 = 11218500045786 := by decide
theorem cert_e2422407023578 : checkPay e2422407023578 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422407023646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2422407023646 : Closed e2422407023646 ∧ code e2422407023646 = 11218500045854 := by decide
theorem cert_e2422407023646 : check e2422407023646 [[],[]] .chain = true := by decide
def e2422407023842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422407023842 : Closed e2422407023842 ∧ code e2422407023842 = 11218500046050 := by decide
theorem cert_e2422407023842 : check e2422407023842 [[],[]] .chain = true := by decide
def e2422407023854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407023854 : Closed e2422407023854 ∧ code e2422407023854 = 11218500046062 := by decide
theorem cert_e2422407023854 : check e2422407023854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407023862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407023862 : Closed e2422407023862 ∧ code e2422407023862 = 11218500046070 := by decide
theorem cert_e2422407023862 : check e2422407023862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407024130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407024130 : Closed e2422407024130 ∧ code e2422407024130 = 11218500046338 := by decide
theorem cert_e2422407024130 : check e2422407024130 [[],[]] .chain = true := by decide
def e2422407024142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407024142 : Closed e2422407024142 ∧ code e2422407024142 = 11218500046350 := by decide
theorem cert_e2422407024142 : check e2422407024142 [[],[]] .chain = true := by decide
def e2422407024154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407024154 : Closed e2422407024154 ∧ code e2422407024154 = 11218500046362 := by decide
theorem cert_e2422407024154 : check e2422407024154 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407024226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407024226 : Closed e2422407024226 ∧ code e2422407024226 = 11218500046434 := by decide
theorem cert_e2422407024226 : check e2422407024226 [[],[]] .chain = true := by decide
def e2422407024238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407024238 : Closed e2422407024238 ∧ code e2422407024238 = 11218500046446 := by decide
theorem cert_e2422407024238 : check e2422407024238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407024246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407024246 : Closed e2422407024246 ∧ code e2422407024246 = 11218500046454 := by decide
theorem cert_e2422407024246 : check e2422407024246 [[],[]] .chain = true := by decide
def e2422407024250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407024250 : Closed e2422407024250 ∧ code e2422407024250 = 11218500046458 := by decide
theorem cert_e2422407024250 : check e2422407024250 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407024438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407024438 : Closed e2422407024438 ∧ code e2422407024438 = 11218500046646 := by decide
theorem cert_e2422407024438 : check e2422407024438 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
end Blc.Floor43
