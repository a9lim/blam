import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393382783918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393382783918 : Closed e2393382783918 ∧ code e2393382783918 = 11189475806126 := by decide
private def t_e2393382783918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e2393382783918 : ¬ IsSelfInterpreter e2393382783918 :=
  wSource (t := t_e2393382783918) (replay_sound (ps := []) (t := e2393382783918) (by decide)) (by decide)
def e2393382783930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393382783930 : Closed e2393382783930 ∧ code e2393382783930 = 11189475806138 := by decide
private def t_e2393382783930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2393382783930 : ¬ IsSelfInterpreter e2393382783930 :=
  wSource (t := t_e2393382783930) (replay_sound (ps := []) (t := e2393382783930) (by decide)) (by decide)
def e2393382783958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393382783958 : Closed e2393382783958 ∧ code e2393382783958 = 11189475806166 := by decide
private def t_e2393382783958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2393382783958 : ¬ IsSelfInterpreter e2393382783958 :=
  wSource (t := t_e2393382783958) (replay_sound (ps := []) (t := e2393382783958) (by decide)) (by decide)
def e2393382783962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393382783962 : Closed e2393382783962 ∧ code e2393382783962 = 11189475806170 := by decide
private def t_e2393382783962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2393382783962 : ¬ IsSelfInterpreter e2393382783962 :=
  wSource (t := t_e2393382783962) (replay_sound (ps := []) (t := e2393382783962) (by decide)) (by decide)
def e2393382784238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393382784238 : Closed e2393382784238 ∧ code e2393382784238 = 11189475806446 := by decide
private def t_e2393382784238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e2393382784238 : ¬ IsSelfInterpreter e2393382784238 :=
  wSource (t := t_e2393382784238) (replay_sound (ps := []) (t := e2393382784238) (by decide)) (by decide)
def e2393382784246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393382784246 : Closed e2393382784246 ∧ code e2393382784246 = 11189475806454 := by decide
private def t_e2393382784246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e2393382784246 : ¬ IsSelfInterpreter e2393382784246 :=
  wSource (t := t_e2393382784246) (replay_sound (ps := []) (t := e2393382784246) (by decide)) (by decide)
def e2393382784622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393382784622 : Closed e2393382784622 ∧ code e2393382784622 = 11189475806830 := by decide
private def t_e2393382784622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e2393382784622 : ¬ IsSelfInterpreter e2393382784622 :=
  wSource (t := t_e2393382784622) (replay_sound (ps := []) (t := e2393382784622) (by decide)) (by decide)
def e2393382784634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393382784634 : Closed e2393382784634 ∧ code e2393382784634 = 11189475806842 := by decide
private def t_e2393382784634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e2393382784634 : ¬ IsSelfInterpreter e2393382784634 :=
  wSource (t := t_e2393382784634) (replay_sound (ps := []) (t := e2393382784634) (by decide)) (by decide)
def e2393382784822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393382784822 : Closed e2393382784822 ∧ code e2393382784822 = 11189475807030 := by decide
private def t_e2393382784822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e2393382784822 : ¬ IsSelfInterpreter e2393382784822 :=
  wSource (t := t_e2393382784822) (replay_sound (ps := []) (t := e2393382784822) (by decide)) (by decide)
def e2393382784826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393382784826 : Closed e2393382784826 ∧ code e2393382784826 = 11189475807034 := by decide
private def t_e2393382784826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e2393382784826 : ¬ IsSelfInterpreter e2393382784826 :=
  wSource (t := t_e2393382784826) (replay_sound (ps := []) (t := e2393382784826) (by decide)) (by decide)
def e2393383120350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2393383120350 : Closed e2393383120350 ∧ code e2393383120350 = 11189476142558 := by decide
theorem cert_e2393383120350 : check e2393383120350 [[],[.left],[],[]] .smaller = true := by decide
def e2393383120366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2393383120366 : Closed e2393383120366 ∧ code e2393383120366 = 11189476142574 := by decide
theorem cert_e2393383120366 : check e2393383120366 [[],[.left],[],[]] .smaller = true := by decide
def e2393383120734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2393383120734 : Closed e2393383120734 ∧ code e2393383120734 = 11189476142942 := by decide
theorem cert_e2393383120734 : check e2393383120734 [[],[.left],[],[]] .smaller = true := by decide
def e2393383120762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2393383120762 : Closed e2393383120762 ∧ code e2393383120762 = 11189476142970 := by decide
theorem cert_e2393383120762 : check e2393383120762 [[],[.left],[],[]] .smaller = true := by decide
def e2393383120814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2393383120814 : Closed e2393383120814 ∧ code e2393383120814 = 11189476143022 := by decide
theorem cert_e2393383120814 : check e2393383120814 [[],[.left],[],[]] .smaller = true := by decide
def e2393383120826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2393383120826 : Closed e2393383120826 ∧ code e2393383120826 = 11189476143034 := by decide
theorem cert_e2393383120826 : check e2393383120826 [[],[.left],[],[]] .smaller = true := by decide
def e2393383121886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2393383121886 : Closed e2393383121886 ∧ code e2393383121886 = 11189476144094 := by decide
theorem cert_e2393383121886 : check e2393383121886 [[],[.left],[],[]] .smaller = true := by decide
def e2393383121902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2393383121902 : Closed e2393383121902 ∧ code e2393383121902 = 11189476144110 := by decide
theorem cert_e2393383121902 : check e2393383121902 [[],[.left],[],[]] .smaller = true := by decide
def e2393383124190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2393383124190 : Closed e2393383124190 ∧ code e2393383124190 = 11189476146398 := by decide
theorem cert_e2393383124190 : check e2393383124190 [[],[.left],[],[]] .smaller = true := by decide
def e2393383124218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2393383124218 : Closed e2393383124218 ∧ code e2393383124218 = 11189476146426 := by decide
theorem cert_e2393383124218 : check e2393383124218 [[],[.left],[],[]] .smaller = true := by decide
def e2393383124590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393383124590 : Closed e2393383124590 ∧ code e2393383124590 = 11189476146798 := by decide
theorem cert_e2393383124590 : check e2393383124590 [[],[.left],[],[]] .smaller = true := by decide
def e2393383124602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393383124602 : Closed e2393383124602 ∧ code e2393383124602 = 11189476146810 := by decide
theorem cert_e2393383124602 : check e2393383124602 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2393383153006 : Closed e2393383153006 ∧ code e2393383153006 = 11189476175214 := by decide
theorem cert_e2393383153006 : check e2393383153006 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2393383153014 : Closed e2393383153014 ∧ code e2393383153014 = 11189476175222 := by decide
theorem cert_e2393383153014 : check e2393383153014 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2393383153070 : Closed e2393383153070 ∧ code e2393383153070 = 11189476175278 := by decide
theorem cert_e2393383153070 : check e2393383153070 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2393383153082 : Closed e2393383153082 ∧ code e2393383153082 = 11189476175290 := by decide
theorem cert_e2393383153082 : check e2393383153082 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2393383153110 : Closed e2393383153110 ∧ code e2393383153110 = 11189476175318 := by decide
theorem cert_e2393383153110 : check e2393383153110 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2393383153114 : Closed e2393383153114 ∧ code e2393383153114 = 11189476175322 := by decide
theorem cert_e2393383153114 : check e2393383153114 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2393383153326 : Closed e2393383153326 ∧ code e2393383153326 = 11189476175534 := by decide
theorem cert_e2393383153326 : check e2393383153326 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2393383153338 : Closed e2393383153338 ∧ code e2393383153338 = 11189476175546 := by decide
theorem cert_e2393383153338 : check e2393383153338 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2393383153386 : Closed e2393383153386 ∧ code e2393383153386 = 11189476175594 := by decide
theorem cert_e2393383153386 : check e2393383153386 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2393383153494 : Closed e2393383153494 ∧ code e2393383153494 = 11189476175702 := by decide
theorem cert_e2393383153494 : check e2393383153494 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2393383153498 : Closed e2393383153498 ∧ code e2393383153498 = 11189476175706 := by decide
theorem cert_e2393383153498 : check e2393383153498 [[],[.left],[],[]] .smaller = true := by decide
def e2393383153514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2393383153514 : Closed e2393383153514 ∧ code e2393383153514 = 11189476175722 := by decide
theorem cert_e2393383153514 : check e2393383153514 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2393383154542 : Closed e2393383154542 ∧ code e2393383154542 = 11189476176750 := by decide
theorem cert_e2393383154542 : check e2393383154542 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2393383154550 : Closed e2393383154550 ∧ code e2393383154550 = 11189476176758 := by decide
theorem cert_e2393383154550 : check e2393383154550 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2393383154606 : Closed e2393383154606 ∧ code e2393383154606 = 11189476176814 := by decide
theorem cert_e2393383154606 : check e2393383154606 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2393383154618 : Closed e2393383154618 ∧ code e2393383154618 = 11189476176826 := by decide
theorem cert_e2393383154618 : check e2393383154618 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2393383154646 : Closed e2393383154646 ∧ code e2393383154646 = 11189476176854 := by decide
theorem cert_e2393383154646 : check e2393383154646 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2393383154650 : Closed e2393383154650 ∧ code e2393383154650 = 11189476176858 := by decide
theorem cert_e2393383154650 : check e2393383154650 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393383154926 : Closed e2393383154926 ∧ code e2393383154926 = 11189476177134 := by decide
theorem cert_e2393383154926 : check e2393383154926 [[],[.left],[],[]] .smaller = true := by decide
def e2393383154934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393383154934 : Closed e2393383154934 ∧ code e2393383154934 = 11189476177142 := by decide
theorem cert_e2393383154934 : check e2393383154934 [[],[.left],[],[]] .smaller = true := by decide
def e2393383155310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393383155310 : Closed e2393383155310 ∧ code e2393383155310 = 11189476177518 := by decide
theorem cert_e2393383155310 : check e2393383155310 [[],[.left],[],[]] .smaller = true := by decide
def e2393383155322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393383155322 : Closed e2393383155322 ∧ code e2393383155322 = 11189476177530 := by decide
theorem cert_e2393383155322 : check e2393383155322 [[],[.left],[],[]] .smaller = true := by decide
def e2393383155510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393383155510 : Closed e2393383155510 ∧ code e2393383155510 = 11189476177718 := by decide
theorem cert_e2393383155510 : check e2393383155510 [[],[.left],[],[]] .smaller = true := by decide
def e2393383155514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393383155514 : Closed e2393383155514 ∧ code e2393383155514 = 11189476177722 := by decide
theorem cert_e2393383155514 : check e2393383155514 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2393383156142 : Closed e2393383156142 ∧ code e2393383156142 = 11189476178350 := by decide
theorem cert_e2393383156142 : check e2393383156142 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2393383156154 : Closed e2393383156154 ∧ code e2393383156154 = 11189476178362 := by decide
theorem cert_e2393383156154 : check e2393383156154 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2393383156202 : Closed e2393383156202 ∧ code e2393383156202 = 11189476178410 := by decide
theorem cert_e2393383156202 : check e2393383156202 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393383156334 : Closed e2393383156334 ∧ code e2393383156334 = 11189476178542 := by decide
theorem cert_e2393383156334 : check e2393383156334 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393383156346 : Closed e2393383156346 ∧ code e2393383156346 = 11189476178554 := by decide
theorem cert_e2393383156346 : check e2393383156346 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393383156634 : Closed e2393383156634 ∧ code e2393383156634 = 11189476178842 := by decide
theorem cert_e2393383156634 : check e2393383156634 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2393383156950 : Closed e2393383156950 ∧ code e2393383156950 = 11189476179158 := by decide
theorem cert_e2393383156950 : check e2393383156950 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2393383156954 : Closed e2393383156954 ∧ code e2393383156954 = 11189476179162 := by decide
theorem cert_e2393383156954 : check e2393383156954 [[],[.left],[],[]] .smaller = true := by decide
def e2393383156970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2393383156970 : Closed e2393383156970 ∧ code e2393383156970 = 11189476179178 := by decide
theorem cert_e2393383156970 : check e2393383156970 [[],[.left],[],[]] .smaller = true := by decide
def e2393383157046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393383157046 : Closed e2393383157046 ∧ code e2393383157046 = 11189476179254 := by decide
theorem cert_e2393383157046 : check e2393383157046 [[],[.left],[],[]] .smaller = true := by decide
def e2393383157050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393383157050 : Closed e2393383157050 ∧ code e2393383157050 = 11189476179258 := by decide
theorem cert_e2393383157050 : check e2393383157050 [[],[.left],[],[]] .smaller = true := by decide
def e2393383157146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393383157146 : Closed e2393383157146 ∧ code e2393383157146 = 11189476179354 := by decide
theorem cert_e2393383157146 : check e2393383157146 [[],[.left],[],[]] .smaller = true := by decide
def e2393383158750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2393383158750 : Closed e2393383158750 ∧ code e2393383158750 = 11189476180958 := by decide
theorem cert_e2393383158750 : check e2393383158750 [[],[.left],[],[]] .smaller = true := by decide
def e2393383158766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2393383158766 : Closed e2393383158766 ∧ code e2393383158766 = 11189476180974 := by decide
theorem cert_e2393383158766 : check e2393383158766 [[],[.left],[],[]] .smaller = true := by decide
def e2393383160686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393383160686 : Closed e2393383160686 ∧ code e2393383160686 = 11189476182894 := by decide
theorem cert_e2393383160686 : check e2393383160686 [[],[.left],[],[]] .smaller = true := by decide
def e2393383160694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393383160694 : Closed e2393383160694 ∧ code e2393383160694 = 11189476182902 := by decide
theorem cert_e2393383160694 : check e2393383160694 [[],[.left],[],[]] .smaller = true := by decide
def e2393383160750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393383160750 : Closed e2393383160750 ∧ code e2393383160750 = 11189476182958 := by decide
theorem cert_e2393383160750 : check e2393383160750 [[],[.left],[],[]] .smaller = true := by decide
def e2393383160762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393383160762 : Closed e2393383160762 ∧ code e2393383160762 = 11189476182970 := by decide
theorem cert_e2393383160762 : check e2393383160762 [[],[.left],[],[]] .smaller = true := by decide
def e2393383160790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393383160790 : Closed e2393383160790 ∧ code e2393383160790 = 11189476182998 := by decide
theorem cert_e2393383160790 : check e2393383160790 [[],[.left],[],[]] .smaller = true := by decide
def e2393383160794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393383160794 : Closed e2393383160794 ∧ code e2393383160794 = 11189476183002 := by decide
theorem cert_e2393383160794 : check e2393383160794 [[],[.left],[],[]] .smaller = true := by decide
def e2393383161070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393383161070 : Closed e2393383161070 ∧ code e2393383161070 = 11189476183278 := by decide
theorem cert_e2393383161070 : check e2393383161070 [[],[.left],[],[]] .smaller = true := by decide
def e2393383161078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393383161078 : Closed e2393383161078 ∧ code e2393383161078 = 11189476183286 := by decide
theorem cert_e2393383161078 : check e2393383161078 [[],[.left],[],[]] .smaller = true := by decide
def e2393383161454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393383161454 : Closed e2393383161454 ∧ code e2393383161454 = 11189476183662 := by decide
theorem cert_e2393383161454 : check e2393383161454 [[],[.left],[],[]] .smaller = true := by decide
def e2393383161466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393383161466 : Closed e2393383161466 ∧ code e2393383161466 = 11189476183674 := by decide
theorem cert_e2393383161466 : check e2393383161466 [[],[.left],[],[]] .smaller = true := by decide
def e2393383161654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393383161654 : Closed e2393383161654 ∧ code e2393383161654 = 11189476183862 := by decide
theorem cert_e2393383161654 : check e2393383161654 [[],[.left],[],[]] .smaller = true := by decide
def e2393383161658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393383161658 : Closed e2393383161658 ∧ code e2393383161658 = 11189476183866 := by decide
theorem cert_e2393383161658 : check e2393383161658 [[],[.left],[],[]] .smaller = true := by decide
def e2393383166430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2393383166430 : Closed e2393383166430 ∧ code e2393383166430 = 11189476188638 := by decide
theorem cert_e2393383166430 : check e2393383166430 [[],[.left],[],[]] .smaller = true := by decide
def e2393383166454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2393383166454 : Closed e2393383166454 ∧ code e2393383166454 = 11189476188662 := by decide
theorem cert_e2393383166454 : check e2393383166454 [[],[.left],[],[]] .smaller = true := by decide
def e2393383167406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2393383167406 : Closed e2393383167406 ∧ code e2393383167406 = 11189476189614 := by decide
theorem cert_e2393383167406 : check e2393383167406 [[],[.left],[],[]] .smaller = true := by decide
def e2393383167418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2393383167418 : Closed e2393383167418 ∧ code e2393383167418 = 11189476189626 := by decide
theorem cert_e2393383167418 : check e2393383167418 [[],[.left],[],[]] .smaller = true := by decide
def e2393383167466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2393383167466 : Closed e2393383167466 ∧ code e2393383167466 = 11189476189674 := by decide
theorem cert_e2393383167466 : check e2393383167466 [[],[.left],[],[]] .smaller = true := by decide
def e2393383167598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393383167598 : Closed e2393383167598 ∧ code e2393383167598 = 11189476189806 := by decide
theorem cert_e2393383167598 : check e2393383167598 [[],[.left],[],[]] .smaller = true := by decide
def e2393383167610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393383167610 : Closed e2393383167610 ∧ code e2393383167610 = 11189476189818 := by decide
theorem cert_e2393383167610 : check e2393383167610 [[],[.left],[],[]] .smaller = true := by decide
def e2393383167898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393383167898 : Closed e2393383167898 ∧ code e2393383167898 = 11189476190106 := by decide
theorem cert_e2393383167898 : check e2393383167898 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2393383170286 : Closed e2393383170286 ∧ code e2393383170286 = 11189476192494 := by decide
theorem cert_e2393383170286 : check e2393383170286 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2393383170294 : Closed e2393383170294 ∧ code e2393383170294 = 11189476192502 := by decide
theorem cert_e2393383170294 : check e2393383170294 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2393383170774 : Closed e2393383170774 ∧ code e2393383170774 = 11189476192982 := by decide
theorem cert_e2393383170774 : check e2393383170774 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2393383170778 : Closed e2393383170778 ∧ code e2393383170778 = 11189476192986 := by decide
theorem cert_e2393383170778 : check e2393383170778 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2393383170794 : Closed e2393383170794 ∧ code e2393383170794 = 11189476193002 := by decide
theorem cert_e2393383170794 : check e2393383170794 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393383170870 : Closed e2393383170870 ∧ code e2393383170870 = 11189476193078 := by decide
theorem cert_e2393383170870 : check e2393383170870 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393383170874 : Closed e2393383170874 ∧ code e2393383170874 = 11189476193082 := by decide
theorem cert_e2393383170874 : check e2393383170874 [[],[.left],[],[]] .smaller = true := by decide
def e2393383170970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393383170970 : Closed e2393383170970 ∧ code e2393383170970 = 11189476193178 := by decide
theorem cert_e2393383170970 : check e2393383170970 [[],[.left],[],[]] .smaller = true := by decide
def e2393383285102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2393383285102 : Closed e2393383285102 ∧ code e2393383285102 = 11189476307310 := by decide
theorem cert_e2393383285102 : check e2393383285102 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383285110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2393383285110 : Closed e2393383285110 ∧ code e2393383285110 = 11189476307318 := by decide
theorem cert_e2393383285110 : check e2393383285110 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393383286318 : Closed e2393383286318 ∧ code e2393383286318 = 11189476308526 := by decide
theorem cert_e2393383286318 : check e2393383286318 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393383286498 : Closed e2393383286498 ∧ code e2393383286498 = 11189476308706 := by decide
theorem cert_e2393383286498 : check e2393383286498 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2393383286510 : Closed e2393383286510 ∧ code e2393383286510 = 11189476308718 := by decide
theorem cert_e2393383286510 : check e2393383286510 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393383286550 : Closed e2393383286550 ∧ code e2393383286550 = 11189476308758 := by decide
theorem cert_e2393383286550 : check e2393383286550 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393383286626 : Closed e2393383286626 ∧ code e2393383286626 = 11189476308834 := by decide
theorem cert_e2393383286626 : check e2393383286626 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2393383286638 : Closed e2393383286638 ∧ code e2393383286638 = 11189476308846 := by decide
theorem cert_e2393383286638 : check e2393383286638 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2393383286646 : Closed e2393383286646 ∧ code e2393383286646 = 11189476308854 := by decide
theorem cert_e2393383286646 : check e2393383286646 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2393383286958 : Closed e2393383286958 ∧ code e2393383286958 = 11189476309166 := by decide
theorem cert_e2393383286958 : check e2393383286958 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383286970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2393383286970 : Closed e2393383286970 ∧ code e2393383286970 = 11189476309178 := by decide
theorem cert_e2393383286970 : check e2393383286970 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393383287342 : Closed e2393383287342 ∧ code e2393383287342 = 11189476309550 := by decide
theorem cert_e2393383287342 : check e2393383287342 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393383287522 : Closed e2393383287522 ∧ code e2393383287522 = 11189476309730 := by decide
theorem cert_e2393383287522 : check e2393383287522 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2393383287534 : Closed e2393383287534 ∧ code e2393383287534 = 11189476309742 := by decide
theorem cert_e2393383287534 : check e2393383287534 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393383287690 : Closed e2393383287690 ∧ code e2393383287690 = 11189476309898 := by decide
theorem cert_e2393383287690 : check e2393383287690 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393383287714 : Closed e2393383287714 ∧ code e2393383287714 = 11189476309922 := by decide
theorem cert_e2393383287714 : check e2393383287714 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2393383287726 : Closed e2393383287726 ∧ code e2393383287726 = 11189476309934 := by decide
theorem cert_e2393383287726 : check e2393383287726 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2393383287738 : Closed e2393383287738 ∧ code e2393383287738 = 11189476309946 := by decide
theorem cert_e2393383287738 : check e2393383287738 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2393383287894 : Closed e2393383287894 ∧ code e2393383287894 = 11189476310102 := by decide
theorem cert_e2393383287894 : check e2393383287894 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383287898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2393383287898 : Closed e2393383287898 ∧ code e2393383287898 = 11189476310106 := by decide
theorem cert_e2393383287898 : check e2393383287898 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393383288086 : Closed e2393383288086 ∧ code e2393383288086 = 11189476310294 := by decide
theorem cert_e2393383288086 : check e2393383288086 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393383288162 : Closed e2393383288162 ∧ code e2393383288162 = 11189476310370 := by decide
theorem cert_e2393383288162 : check e2393383288162 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393383288174 : Closed e2393383288174 ∧ code e2393383288174 = 11189476310382 := by decide
theorem cert_e2393383288174 : check e2393383288174 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393383288182 : Closed e2393383288182 ∧ code e2393383288182 = 11189476310390 := by decide
theorem cert_e2393383288182 : check e2393383288182 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393383288202 : Closed e2393383288202 ∧ code e2393383288202 = 11189476310410 := by decide
theorem cert_e2393383288202 : check e2393383288202 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393383288226 : Closed e2393383288226 ∧ code e2393383288226 = 11189476310434 := by decide
theorem cert_e2393383288226 : check e2393383288226 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393383288238 : Closed e2393383288238 ∧ code e2393383288238 = 11189476310446 := by decide
theorem cert_e2393383288238 : check e2393383288238 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393383288250 : Closed e2393383288250 ∧ code e2393383288250 = 11189476310458 := by decide
theorem cert_e2393383288250 : check e2393383288250 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393383288278 : Closed e2393383288278 ∧ code e2393383288278 = 11189476310486 := by decide
theorem cert_e2393383288278 : check e2393383288278 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383288282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393383288282 : Closed e2393383288282 ∧ code e2393383288282 = 11189476310490 := by decide
theorem cert_e2393383288282 : check e2393383288282 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383289326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2393383289326 : Closed e2393383289326 ∧ code e2393383289326 = 11189476311534 := by decide
theorem cert_e2393383289326 : check e2393383289326 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383289334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2393383289334 : Closed e2393383289334 ∧ code e2393383289334 = 11189476311542 := by decide
theorem cert_e2393383289334 : check e2393383289334 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383290094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2393383290094 : Closed e2393383290094 ∧ code e2393383290094 = 11189476312302 := by decide
theorem cert_e2393383290094 : check e2393383290094 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383290102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2393383290102 : Closed e2393383290102 ∧ code e2393383290102 = 11189476312310 := by decide
theorem cert_e2393383290102 : check e2393383290102 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383290654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2393383290654 : Closed e2393383290654 ∧ code e2393383290654 = 11189476312862 := by decide
theorem cert_e2393383290654 : check e2393383290654 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383290766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2393383290766 : Closed e2393383290766 ∧ code e2393383290766 = 11189476312974 := by decide
theorem cert_e2393383290766 : check e2393383290766 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383292462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2393383292462 : Closed e2393383292462 ∧ code e2393383292462 = 11189476314670 := by decide
theorem cert_e2393383292462 : check e2393383292462 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383292642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2393383292642 : Closed e2393383292642 ∧ code e2393383292642 = 11189476314850 := by decide
theorem cert_e2393383292642 : check e2393383292642 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383292654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2393383292654 : Closed e2393383292654 ∧ code e2393383292654 = 11189476314862 := by decide
theorem cert_e2393383292654 : check e2393383292654 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383292694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2393383292694 : Closed e2393383292694 ∧ code e2393383292694 = 11189476314902 := by decide
theorem cert_e2393383292694 : check e2393383292694 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383292770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2393383292770 : Closed e2393383292770 ∧ code e2393383292770 = 11189476314978 := by decide
theorem cert_e2393383292770 : check e2393383292770 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383292782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2393383292782 : Closed e2393383292782 ∧ code e2393383292782 = 11189476314990 := by decide
theorem cert_e2393383292782 : check e2393383292782 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383292790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2393383292790 : Closed e2393383292790 ∧ code e2393383292790 = 11189476314998 := by decide
theorem cert_e2393383292790 : check e2393383292790 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383295038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2393383295038 : Closed e2393383295038 ∧ code e2393383295038 = 11189476317246 := by decide
theorem cert_e2393383295038 : check e2393383295038 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383295458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393383295458 : Closed e2393383295458 ∧ code e2393383295458 = 11189476317666 := by decide
theorem cert_e2393383295458 : check e2393383295458 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383295470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393383295470 : Closed e2393383295470 ∧ code e2393383295470 = 11189476317678 := by decide
theorem cert_e2393383295470 : check e2393383295470 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383296030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2393383296030 : Closed e2393383296030 ∧ code e2393383296030 = 11189476318238 := by decide
theorem cert_e2393383296030 : check e2393383296030 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383296226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393383296226 : Closed e2393383296226 ∧ code e2393383296226 = 11189476318434 := by decide
theorem cert_e2393383296226 : check e2393383296226 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383296238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393383296238 : Closed e2393383296238 ∧ code e2393383296238 = 11189476318446 := by decide
theorem cert_e2393383296238 : check e2393383296238 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383296246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393383296246 : Closed e2393383296246 ∧ code e2393383296246 = 11189476318454 := by decide
theorem cert_e2393383296246 : check e2393383296246 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383297262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2393383297262 : Closed e2393383297262 ∧ code e2393383297262 = 11189476319470 := by decide
theorem cert_e2393383297262 : check e2393383297262 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383297274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2393383297274 : Closed e2393383297274 ∧ code e2393383297274 = 11189476319482 := by decide
theorem cert_e2393383297274 : check e2393383297274 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383297646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393383297646 : Closed e2393383297646 ∧ code e2393383297646 = 11189476319854 := by decide
theorem cert_e2393383297646 : check e2393383297646 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383297658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393383297658 : Closed e2393383297658 ∧ code e2393383297658 = 11189476319866 := by decide
theorem cert_e2393383297658 : check e2393383297658 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383297822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2393383297822 : Closed e2393383297822 ∧ code e2393383297822 = 11189476320030 := by decide
theorem cert_e2393383297822 : check e2393383297822 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383297990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2393383297990 : Closed e2393383297990 ∧ code e2393383297990 = 11189476320198 := by decide
theorem cert_e2393383297990 : check e2393383297990 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383298606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2393383298606 : Closed e2393383298606 ∧ code e2393383298606 = 11189476320814 := by decide
theorem cert_e2393383298606 : check e2393383298606 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383298786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2393383298786 : Closed e2393383298786 ∧ code e2393383298786 = 11189476320994 := by decide
theorem cert_e2393383298786 : check e2393383298786 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383298798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2393383298798 : Closed e2393383298798 ∧ code e2393383298798 = 11189476321006 := by decide
theorem cert_e2393383298798 : check e2393383298798 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383298954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393383298954 : Closed e2393383298954 ∧ code e2393383298954 = 11189476321162 := by decide
theorem cert_e2393383298954 : check e2393383298954 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383298978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393383298978 : Closed e2393383298978 ∧ code e2393383298978 = 11189476321186 := by decide
theorem cert_e2393383298978 : check e2393383298978 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383298990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2393383298990 : Closed e2393383298990 ∧ code e2393383298990 = 11189476321198 := by decide
theorem cert_e2393383298990 : check e2393383298990 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383299002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2393383299002 : Closed e2393383299002 ∧ code e2393383299002 = 11189476321210 := by decide
theorem cert_e2393383299002 : check e2393383299002 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383299134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2393383299134 : Closed e2393383299134 ∧ code e2393383299134 = 11189476321342 := by decide
theorem cert_e2393383299134 : check e2393383299134 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383299554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393383299554 : Closed e2393383299554 ∧ code e2393383299554 = 11189476321762 := by decide
theorem cert_e2393383299554 : check e2393383299554 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383299566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393383299566 : Closed e2393383299566 ∧ code e2393383299566 = 11189476321774 := by decide
theorem cert_e2393383299566 : check e2393383299566 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383300622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393383300622 : Closed e2393383300622 ∧ code e2393383300622 = 11189476322830 := by decide
theorem cert_e2393383300622 : check e2393383300622 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383300706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393383300706 : Closed e2393383300706 ∧ code e2393383300706 = 11189476322914 := by decide
theorem cert_e2393383300706 : check e2393383300706 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383300718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393383300718 : Closed e2393383300718 ∧ code e2393383300718 = 11189476322926 := by decide
theorem cert_e2393383300718 : check e2393383300718 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383300730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393383300730 : Closed e2393383300730 ∧ code e2393383300730 = 11189476322938 := by decide
theorem cert_e2393383300730 : check e2393383300730 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2393383301238 : Closed e2393383301238 ∧ code e2393383301238 = 11189476323446 := by decide
theorem cert_e2393383301238 : check e2393383301238 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2393383301242 : Closed e2393383301242 ∧ code e2393383301242 = 11189476323450 := by decide
theorem cert_e2393383301242 : check e2393383301242 [[],[.left],[],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393382783918
#print axioms Blc.Floor43.cert_e2393382783930
#print axioms Blc.Floor43.cert_e2393382783958
#print axioms Blc.Floor43.cert_e2393382783962
#print axioms Blc.Floor43.cert_e2393382784238
#print axioms Blc.Floor43.cert_e2393382784246
#print axioms Blc.Floor43.cert_e2393382784622
#print axioms Blc.Floor43.cert_e2393382784634
#print axioms Blc.Floor43.cert_e2393382784822
#print axioms Blc.Floor43.cert_e2393382784826
