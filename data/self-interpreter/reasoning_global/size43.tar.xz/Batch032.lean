import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606177782682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177782682 : Closed e606177782682 ∧ code e606177782682 = 9402270804890 := by decide
theorem cert_e606177782682 : check e606177782682 [[.under],[.under,.left]] .chain = true := by decide
def e606177783450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177783450 : Closed e606177783450 ∧ code e606177783450 = 9402270805658 := by decide
theorem cert_e606177783450 : check e606177783450 [[.under],[.under,.left]] .chain = true := by decide
def e606177785242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177785242 : Closed e606177785242 ∧ code e606177785242 = 9402270807450 := by decide
theorem cert_e606177785242 : check e606177785242 [[.under],[.under,.left]] .chain = true := by decide
def e606177785498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177785498 : Closed e606177785498 ∧ code e606177785498 = 9402270807706 := by decide
theorem cert_e606177785498 : check e606177785498 [[.under],[.under,.left]] .chain = true := by decide
def e606177803162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177803162 : Closed e606177803162 ∧ code e606177803162 = 9402270825370 := by decide
theorem cert_e606177803162 : check e606177803162 [[.under],[.under,.left]] .chain = true := by decide
def e606177803674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177803674 : Closed e606177803674 ∧ code e606177803674 = 9402270825882 := by decide
theorem cert_e606177803674 : check e606177803674 [[.under],[.under,.left]] .chain = true := by decide
def e606177827738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177827738 : Closed e606177827738 ∧ code e606177827738 = 9402270849946 := by decide
theorem cert_e606177827738 : check e606177827738 [[.under],[.under,.left]] .chain = true := by decide
def e606177828506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177828506 : Closed e606177828506 ∧ code e606177828506 = 9402270850714 := by decide
theorem cert_e606177828506 : check e606177828506 [[.under],[.under,.left]] .chain = true := by decide
def e606177840538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177840538 : Closed e606177840538 ∧ code e606177840538 = 9402270862746 := by decide
theorem cert_e606177840538 : check e606177840538 [[.under],[.under,.left]] .chain = true := by decide
def e606177840794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.var 0)))))
theorem wire_e606177840794 : Closed e606177840794 ∧ code e606177840794 = 9402270863002 := by decide
theorem cert_e606177840794 : check e606177840794 [[.under],[.under,.left]] .chain = true := by decide
def e606328763834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e606328763834 : Closed e606328763834 ∧ code e606328763834 = 9402421786042 := by decide
theorem cert_e606328763834 : check e606328763834 [[.under]] .sourceHead = true := by decide
def e606328763866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e606328763866 : Closed e606328763866 ∧ code e606328763866 = 9402421786074 := by decide
theorem cert_e606328763866 : check e606328763866 [[.under]] .sourceHead = true := by decide
def e606328764090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e606328764090 : Closed e606328764090 ∧ code e606328764090 = 9402421786298 := by decide
theorem cert_e606328764090 : check e606328764090 [[.under]] .sourceHead = true := by decide
def e606328764138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e606328764138 : Closed e606328764138 ∧ code e606328764138 = 9402421786346 := by decide
theorem cert_e606328764138 : check e606328764138 [[.under]] .sourceHead = true := by decide
def e606328764250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e606328764250 : Closed e606328764250 ∧ code e606328764250 = 9402421786458 := by decide
theorem cert_e606328764250 : check e606328764250 [[.under]] .sourceHead = true := by decide
def e606328764266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e606328764266 : Closed e606328764266 ∧ code e606328764266 = 9402421786474 := by decide
theorem cert_e606328764266 : check e606328764266 [[.under]] .sourceHead = true := by decide
def e606328765114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e606328765114 : Closed e606328765114 ∧ code e606328765114 = 9402421787322 := by decide
theorem cert_e606328765114 : check e606328765114 [[.under]] .sourceHead = true := by decide
def e606328765162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e606328765162 : Closed e606328765162 ∧ code e606328765162 = 9402421787370 := by decide
theorem cert_e606328765162 : check e606328765162 [[.under]] .sourceHead = true := by decide
def e606328765354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0))))
theorem wire_e606328765354 : Closed e606328765354 ∧ code e606328765354 = 9402421787562 := by decide
theorem cert_e606328765354 : check e606328765354 [[.under]] .sourceHead = true := by decide
def e606328765786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e606328765786 : Closed e606328765786 ∧ code e606328765786 = 9402421787994 := by decide
theorem cert_e606328765786 : check e606328765786 [[.under]] .sourceHead = true := by decide
def e606328765802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e606328765802 : Closed e606328765802 ∧ code e606328765802 = 9402421788010 := by decide
theorem cert_e606328765802 : check e606328765802 [[.under]] .sourceHead = true := by decide
def e606328765866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0))))
theorem wire_e606328765866 : Closed e606328765866 ∧ code e606328765866 = 9402421788074 := by decide
theorem cert_e606328765866 : check e606328765866 [[.under]] .sourceHead = true := by decide
def e606328769978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0))))
theorem wire_e606328769978 : Closed e606328769978 ∧ code e606328769978 = 9402421792186 := by decide
theorem cert_e606328769978 : check e606328769978 [[.under]] .sourceHead = true := by decide
def e606328770010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0))))
theorem wire_e606328770010 : Closed e606328770010 ∧ code e606328770010 = 9402421792218 := by decide
theorem cert_e606328770010 : check e606328770010 [[.under]] .sourceHead = true := by decide
def e606328770234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0))))
theorem wire_e606328770234 : Closed e606328770234 ∧ code e606328770234 = 9402421792442 := by decide
theorem cert_e606328770234 : check e606328770234 [[.under]] .sourceHead = true := by decide
def e606328770282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0))))
theorem wire_e606328770282 : Closed e606328770282 ∧ code e606328770282 = 9402421792490 := by decide
theorem cert_e606328770282 : check e606328770282 [[.under]] .sourceHead = true := by decide
def e606328770394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0))))
theorem wire_e606328770394 : Closed e606328770394 ∧ code e606328770394 = 9402421792602 := by decide
theorem cert_e606328770394 : check e606328770394 [[.under]] .sourceHead = true := by decide
def e606328770410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0))))
theorem wire_e606328770410 : Closed e606328770410 ∧ code e606328770410 = 9402421792618 := by decide
theorem cert_e606328770410 : check e606328770410 [[.under]] .sourceHead = true := by decide
def e606328771514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e606328771514 : Closed e606328771514 ∧ code e606328771514 = 9402421793722 := by decide
theorem cert_e606328771514 : check e606328771514 [[.under]] .sourceHead = true := by decide
def e606328771546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e606328771546 : Closed e606328771546 ∧ code e606328771546 = 9402421793754 := by decide
theorem cert_e606328771546 : check e606328771546 [[.under]] .sourceHead = true := by decide
def e606328773050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e606328773050 : Closed e606328773050 ∧ code e606328773050 = 9402421795258 := by decide
theorem cert_e606328773050 : check e606328773050 [[.under]] .sourceHead = true := by decide
def e606328773098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e606328773098 : Closed e606328773098 ∧ code e606328773098 = 9402421795306 := by decide
theorem cert_e606328773098 : check e606328773098 [[.under]] .sourceHead = true := by decide
def e606328773850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e606328773850 : Closed e606328773850 ∧ code e606328773850 = 9402421796058 := by decide
theorem cert_e606328773850 : check e606328773850 [[.under]] .sourceHead = true := by decide
def e606328773866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e606328773866 : Closed e606328773866 ∧ code e606328773866 = 9402421796074 := by decide
theorem cert_e606328773866 : check e606328773866 [[.under]] .sourceHead = true := by decide
def e606328776378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0))))
theorem wire_e606328776378 : Closed e606328776378 ∧ code e606328776378 = 9402421798586 := by decide
theorem cert_e606328776378 : check e606328776378 [[.under]] .sourceHead = true := by decide
def e606328776426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0))))
theorem wire_e606328776426 : Closed e606328776426 ∧ code e606328776426 = 9402421798634 := by decide
theorem cert_e606328776426 : check e606328776426 [[.under]] .sourceHead = true := by decide
def e606328776618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0))))
theorem wire_e606328776618 : Closed e606328776618 ∧ code e606328776618 = 9402421798826 := by decide
theorem cert_e606328776618 : check e606328776618 [[.under]] .sourceHead = true := by decide
def e606328777146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e606328777146 : Closed e606328777146 ∧ code e606328777146 = 9402421799354 := by decide
theorem cert_e606328777146 : check e606328777146 [[.under]] .sourceHead = true := by decide
def e606328777194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e606328777194 : Closed e606328777194 ∧ code e606328777194 = 9402421799402 := by decide
theorem cert_e606328777194 : check e606328777194 [[.under]] .sourceHead = true := by decide
def e606328778346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0))))
theorem wire_e606328778346 : Closed e606328778346 ∧ code e606328778346 = 9402421800554 := by decide
theorem cert_e606328778346 : check e606328778346 [[.under]] .sourceHead = true := by decide
def e606328779610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0))))
theorem wire_e606328779610 : Closed e606328779610 ∧ code e606328779610 = 9402421801818 := by decide
theorem cert_e606328779610 : check e606328779610 [[.under]] .sourceHead = true := by decide
def e606328779626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0))))
theorem wire_e606328779626 : Closed e606328779626 ∧ code e606328779626 = 9402421801834 := by decide
theorem cert_e606328779626 : check e606328779626 [[.under]] .sourceHead = true := by decide
def e606328779690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0))))
theorem wire_e606328779690 : Closed e606328779690 ∧ code e606328779690 = 9402421801898 := by decide
theorem cert_e606328779690 : check e606328779690 [[.under]] .sourceHead = true := by decide
def e606328779994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e606328779994 : Closed e606328779994 ∧ code e606328779994 = 9402421802202 := by decide
theorem cert_e606328779994 : check e606328779994 [[.under]] .sourceHead = true := by decide
def e606328780010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e606328780010 : Closed e606328780010 ∧ code e606328780010 = 9402421802218 := by decide
theorem cert_e606328780010 : check e606328780010 [[.under]] .sourceHead = true := by decide
def e606328780394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0))))
theorem wire_e606328780394 : Closed e606328780394 ∧ code e606328780394 = 9402421802602 := by decide
theorem cert_e606328780394 : check e606328780394 [[.under]] .sourceHead = true := by decide
def e606328794554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))))
theorem wire_e606328794554 : Closed e606328794554 ∧ code e606328794554 = 9402421816762 := by decide
theorem cert_e606328794554 : check e606328794554 [[.under]] .sourceHead = true := by decide
def e606328794586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))))
theorem wire_e606328794586 : Closed e606328794586 ∧ code e606328794586 = 9402421816794 := by decide
theorem cert_e606328794586 : check e606328794586 [[.under]] .sourceHead = true := by decide
def e606328794810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e606328794810 : Closed e606328794810 ∧ code e606328794810 = 9402421817018 := by decide
theorem cert_e606328794810 : check e606328794810 [[.under]] .sourceHead = true := by decide
def e606328794858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e606328794858 : Closed e606328794858 ∧ code e606328794858 = 9402421817066 := by decide
theorem cert_e606328794858 : check e606328794858 [[.under]] .sourceHead = true := by decide
def e606328794970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e606328794970 : Closed e606328794970 ∧ code e606328794970 = 9402421817178 := by decide
theorem cert_e606328794970 : check e606328794970 [[.under]] .sourceHead = true := by decide
def e606328794986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e606328794986 : Closed e606328794986 ∧ code e606328794986 = 9402421817194 := by decide
theorem cert_e606328794986 : check e606328794986 [[.under]] .sourceHead = true := by decide
def e606328796090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))))
theorem wire_e606328796090 : Closed e606328796090 ∧ code e606328796090 = 9402421818298 := by decide
theorem cert_e606328796090 : check e606328796090 [[.under]] .sourceHead = true := by decide
def e606328796122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))))
theorem wire_e606328796122 : Closed e606328796122 ∧ code e606328796122 = 9402421818330 := by decide
theorem cert_e606328796122 : check e606328796122 [[.under]] .sourceHead = true := by decide
def e606328797626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e606328797626 : Closed e606328797626 ∧ code e606328797626 = 9402421819834 := by decide
theorem cert_e606328797626 : check e606328797626 [[.under]] .sourceHead = true := by decide
def e606328797674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e606328797674 : Closed e606328797674 ∧ code e606328797674 = 9402421819882 := by decide
theorem cert_e606328797674 : check e606328797674 [[.under]] .sourceHead = true := by decide
def e606328798426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e606328798426 : Closed e606328798426 ∧ code e606328798426 = 9402421820634 := by decide
theorem cert_e606328798426 : check e606328798426 [[.under]] .sourceHead = true := by decide
def e606328798442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e606328798442 : Closed e606328798442 ∧ code e606328798442 = 9402421820650 := by decide
theorem cert_e606328798442 : check e606328798442 [[.under]] .sourceHead = true := by decide
def e606328821434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e606328821434 : Closed e606328821434 ∧ code e606328821434 = 9402421843642 := by decide
theorem cert_e606328821434 : check e606328821434 [[.under]] .sourceHead = true := by decide
def e606328821482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e606328821482 : Closed e606328821482 ∧ code e606328821482 = 9402421843690 := by decide
theorem cert_e606328821482 : check e606328821482 [[.under]] .sourceHead = true := by decide
def e606328821674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0))))
theorem wire_e606328821674 : Closed e606328821674 ∧ code e606328821674 = 9402421843882 := by decide
theorem cert_e606328821674 : check e606328821674 [[.under]] .sourceHead = true := by decide
def e606328822202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e606328822202 : Closed e606328822202 ∧ code e606328822202 = 9402421844410 := by decide
theorem cert_e606328822202 : check e606328822202 [[.under]] .sourceHead = true := by decide
def e606328822250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e606328822250 : Closed e606328822250 ∧ code e606328822250 = 9402421844458 := by decide
theorem cert_e606328822250 : check e606328822250 [[.under]] .sourceHead = true := by decide
def e606328823402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0))))
theorem wire_e606328823402 : Closed e606328823402 ∧ code e606328823402 = 9402421845610 := by decide
theorem cert_e606328823402 : check e606328823402 [[.under]] .sourceHead = true := by decide
def e606328834906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e606328834906 : Closed e606328834906 ∧ code e606328834906 = 9402421857114 := by decide
theorem cert_e606328834906 : check e606328834906 [[.under]] .sourceHead = true := by decide
def e606328834922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e606328834922 : Closed e606328834922 ∧ code e606328834922 = 9402421857130 := by decide
theorem cert_e606328834922 : check e606328834922 [[.under]] .sourceHead = true := by decide
def e606328834986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0))))
theorem wire_e606328834986 : Closed e606328834986 ∧ code e606328834986 = 9402421857194 := by decide
theorem cert_e606328834986 : check e606328834986 [[.under]] .sourceHead = true := by decide
def e606328835290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e606328835290 : Closed e606328835290 ∧ code e606328835290 = 9402421857498 := by decide
theorem cert_e606328835290 : check e606328835290 [[.under]] .sourceHead = true := by decide
def e606328835306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e606328835306 : Closed e606328835306 ∧ code e606328835306 = 9402421857514 := by decide
theorem cert_e606328835306 : check e606328835306 [[.under]] .sourceHead = true := by decide
def e606328835690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0))))
theorem wire_e606328835690 : Closed e606328835690 ∧ code e606328835690 = 9402421857898 := by decide
theorem cert_e606328835690 : check e606328835690 [[.under]] .sourceHead = true := by decide
def e606329384378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))))
theorem wire_e606329384378 : Closed e606329384378 ∧ code e606329384378 = 9402422406586 := by decide
theorem cert_e606329384378 : check e606329384378 [[.under]] .sourceHead = true := by decide
def e606329384410 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))))
theorem wire_e606329384410 : Closed e606329384410 ∧ code e606329384410 = 9402422406618 := by decide
theorem cert_e606329384410 : check e606329384410 [[.under]] .sourceHead = true := by decide
def e606329384634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e606329384634 : Closed e606329384634 ∧ code e606329384634 = 9402422406842 := by decide
theorem cert_e606329384634 : check e606329384634 [[.under]] .sourceHead = true := by decide
def e606329384682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e606329384682 : Closed e606329384682 ∧ code e606329384682 = 9402422406890 := by decide
theorem cert_e606329384682 : check e606329384682 [[.under]] .sourceHead = true := by decide
def e606329384794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e606329384794 : Closed e606329384794 ∧ code e606329384794 = 9402422407002 := by decide
theorem cert_e606329384794 : check e606329384794 [[.under]] .sourceHead = true := by decide
def e606329384810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e606329384810 : Closed e606329384810 ∧ code e606329384810 = 9402422407018 := by decide
theorem cert_e606329384810 : check e606329384810 [[.under]] .sourceHead = true := by decide
def e606329385914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))))
theorem wire_e606329385914 : Closed e606329385914 ∧ code e606329385914 = 9402422408122 := by decide
theorem cert_e606329385914 : check e606329385914 [[.under]] .sourceHead = true := by decide
def e606329385946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))))
theorem wire_e606329385946 : Closed e606329385946 ∧ code e606329385946 = 9402422408154 := by decide
theorem cert_e606329385946 : check e606329385946 [[.under]] .sourceHead = true := by decide
def e606329387450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e606329387450 : Closed e606329387450 ∧ code e606329387450 = 9402422409658 := by decide
theorem cert_e606329387450 : check e606329387450 [[.under]] .sourceHead = true := by decide
def e606329387498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e606329387498 : Closed e606329387498 ∧ code e606329387498 = 9402422409706 := by decide
theorem cert_e606329387498 : check e606329387498 [[.under]] .sourceHead = true := by decide
def e606329388250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e606329388250 : Closed e606329388250 ∧ code e606329388250 = 9402422410458 := by decide
theorem cert_e606329388250 : check e606329388250 [[.under]] .sourceHead = true := by decide
def e606329388266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e606329388266 : Closed e606329388266 ∧ code e606329388266 = 9402422410474 := by decide
theorem cert_e606329388266 : check e606329388266 [[.under]] .sourceHead = true := by decide
def e606331743674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))))
theorem wire_e606331743674 : Closed e606331743674 ∧ code e606331743674 = 9402424765882 := by decide
theorem cert_e606331743674 : check e606331743674 [[.under]] .sourceHead = true := by decide
def e606331743706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))))
theorem wire_e606331743706 : Closed e606331743706 ∧ code e606331743706 = 9402424765914 := by decide
theorem cert_e606331743706 : check e606331743706 [[.under]] .sourceHead = true := by decide
def e606331743930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e606331743930 : Closed e606331743930 ∧ code e606331743930 = 9402424766138 := by decide
theorem cert_e606331743930 : check e606331743930 [[.under]] .sourceHead = true := by decide
def e606331743978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e606331743978 : Closed e606331743978 ∧ code e606331743978 = 9402424766186 := by decide
theorem cert_e606331743978 : check e606331743978 [[.under]] .sourceHead = true := by decide
def e606331744090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e606331744090 : Closed e606331744090 ∧ code e606331744090 = 9402424766298 := by decide
theorem cert_e606331744090 : check e606331744090 [[.under]] .sourceHead = true := by decide
def e606331744106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e606331744106 : Closed e606331744106 ∧ code e606331744106 = 9402424766314 := by decide
theorem cert_e606331744106 : check e606331744106 [[.under]] .sourceHead = true := by decide
def e606331745210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))))
theorem wire_e606331745210 : Closed e606331745210 ∧ code e606331745210 = 9402424767418 := by decide
theorem cert_e606331745210 : check e606331745210 [[.under]] .sourceHead = true := by decide
def e606331745242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))))
theorem wire_e606331745242 : Closed e606331745242 ∧ code e606331745242 = 9402424767450 := by decide
theorem cert_e606331745242 : check e606331745242 [[.under]] .sourceHead = true := by decide
def e606331746746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e606331746746 : Closed e606331746746 ∧ code e606331746746 = 9402424768954 := by decide
theorem cert_e606331746746 : check e606331746746 [[.under]] .sourceHead = true := by decide
def e606331746794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e606331746794 : Closed e606331746794 ∧ code e606331746794 = 9402424769002 := by decide
theorem cert_e606331746794 : check e606331746794 [[.under]] .sourceHead = true := by decide
def e606331747546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e606331747546 : Closed e606331747546 ∧ code e606331747546 = 9402424769754 := by decide
theorem cert_e606331747546 : check e606331747546 [[.under]] .sourceHead = true := by decide
def e606331747562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e606331747562 : Closed e606331747562 ∧ code e606331747562 = 9402424769770 := by decide
theorem cert_e606331747562 : check e606331747562 [[.under]] .sourceHead = true := by decide
def e606345407854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e606345407854 : Closed e606345407854 ∧ code e606345407854 = 9402438430062 := by decide
theorem cert_e606345407854 : check e606345407854 [[.under]] .sourceHead = true := by decide
def e606345407862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e606345407862 : Closed e606345407862 ∧ code e606345407862 = 9402438430070 := by decide
theorem cert_e606345407862 : check e606345407862 [[.under]] .sourceHead = true := by decide
def e606345407918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e606345407918 : Closed e606345407918 ∧ code e606345407918 = 9402438430126 := by decide
theorem cert_e606345407918 : check e606345407918 [[.under]] .sourceHead = true := by decide
def e606345407930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e606345407930 : Closed e606345407930 ∧ code e606345407930 = 9402438430138 := by decide
theorem cert_e606345407930 : check e606345407930 [[.under]] .sourceHead = true := by decide
def e606345407958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e606345407958 : Closed e606345407958 ∧ code e606345407958 = 9402438430166 := by decide
theorem cert_e606345407958 : check e606345407958 [[.under]] .sourceHead = true := by decide
def e606345407962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e606345407962 : Closed e606345407962 ∧ code e606345407962 = 9402438430170 := by decide
theorem cert_e606345407962 : check e606345407962 [[.under]] .sourceHead = true := by decide
def e606345408174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e606345408174 : Closed e606345408174 ∧ code e606345408174 = 9402438430382 := by decide
theorem cert_e606345408174 : check e606345408174 [[.under]] .sourceHead = true := by decide
def e606345408186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e606345408186 : Closed e606345408186 ∧ code e606345408186 = 9402438430394 := by decide
theorem cert_e606345408186 : check e606345408186 [[.under]] .sourceHead = true := by decide
def e606345408234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e606345408234 : Closed e606345408234 ∧ code e606345408234 = 9402438430442 := by decide
theorem cert_e606345408234 : check e606345408234 [[.under]] .sourceHead = true := by decide
def e606345408342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e606345408342 : Closed e606345408342 ∧ code e606345408342 = 9402438430550 := by decide
theorem cert_e606345408342 : check e606345408342 [[.under]] .sourceHead = true := by decide
def e606345408346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e606345408346 : Closed e606345408346 ∧ code e606345408346 = 9402438430554 := by decide
theorem cert_e606345408346 : check e606345408346 [[.under]] .sourceHead = true := by decide
def e606345408362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e606345408362 : Closed e606345408362 ∧ code e606345408362 = 9402438430570 := by decide
theorem cert_e606345408362 : check e606345408362 [[.under]] .sourceHead = true := by decide
def e606345409390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e606345409390 : Closed e606345409390 ∧ code e606345409390 = 9402438431598 := by decide
theorem cert_e606345409390 : check e606345409390 [[.under]] .sourceHead = true := by decide
def e606345409398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e606345409398 : Closed e606345409398 ∧ code e606345409398 = 9402438431606 := by decide
theorem cert_e606345409398 : check e606345409398 [[.under]] .sourceHead = true := by decide
def e606345409454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e606345409454 : Closed e606345409454 ∧ code e606345409454 = 9402438431662 := by decide
theorem cert_e606345409454 : check e606345409454 [[.under]] .sourceHead = true := by decide
def e606345409466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e606345409466 : Closed e606345409466 ∧ code e606345409466 = 9402438431674 := by decide
theorem cert_e606345409466 : check e606345409466 [[.under]] .sourceHead = true := by decide
def e606345409494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e606345409494 : Closed e606345409494 ∧ code e606345409494 = 9402438431702 := by decide
theorem cert_e606345409494 : check e606345409494 [[.under]] .sourceHead = true := by decide
def e606345409498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e606345409498 : Closed e606345409498 ∧ code e606345409498 = 9402438431706 := by decide
theorem cert_e606345409498 : check e606345409498 [[.under]] .sourceHead = true := by decide
def e606345409774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e606345409774 : Closed e606345409774 ∧ code e606345409774 = 9402438431982 := by decide
theorem cert_e606345409774 : check e606345409774 [[.under]] .sourceHead = true := by decide
def e606345409782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e606345409782 : Closed e606345409782 ∧ code e606345409782 = 9402438431990 := by decide
theorem cert_e606345409782 : check e606345409782 [[.under]] .sourceHead = true := by decide
def e606345410158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e606345410158 : Closed e606345410158 ∧ code e606345410158 = 9402438432366 := by decide
theorem cert_e606345410158 : check e606345410158 [[.under]] .sourceHead = true := by decide
def e606345410170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e606345410170 : Closed e606345410170 ∧ code e606345410170 = 9402438432378 := by decide
theorem cert_e606345410170 : check e606345410170 [[.under]] .sourceHead = true := by decide
def e606345410358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e606345410358 : Closed e606345410358 ∧ code e606345410358 = 9402438432566 := by decide
theorem cert_e606345410358 : check e606345410358 [[.under]] .sourceHead = true := by decide
def e606345410362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e606345410362 : Closed e606345410362 ∧ code e606345410362 = 9402438432570 := by decide
theorem cert_e606345410362 : check e606345410362 [[.under]] .sourceHead = true := by decide
def e606345410990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e606345410990 : Closed e606345410990 ∧ code e606345410990 = 9402438433198 := by decide
theorem cert_e606345410990 : check e606345410990 [[.under]] .sourceHead = true := by decide
def e606345411002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e606345411002 : Closed e606345411002 ∧ code e606345411002 = 9402438433210 := by decide
theorem cert_e606345411002 : check e606345411002 [[.under]] .sourceHead = true := by decide
def e606345411050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e606345411050 : Closed e606345411050 ∧ code e606345411050 = 9402438433258 := by decide
theorem cert_e606345411050 : check e606345411050 [[.under]] .sourceHead = true := by decide
def e606345411182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e606345411182 : Closed e606345411182 ∧ code e606345411182 = 9402438433390 := by decide
theorem cert_e606345411182 : check e606345411182 [[.under]] .sourceHead = true := by decide
def e606345411194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e606345411194 : Closed e606345411194 ∧ code e606345411194 = 9402438433402 := by decide
theorem cert_e606345411194 : check e606345411194 [[.under]] .sourceHead = true := by decide
def e606345411482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606345411482 : Closed e606345411482 ∧ code e606345411482 = 9402438433690 := by decide
theorem cert_e606345411482 : check e606345411482 [[.under]] .sourceHead = true := by decide
def e606345411798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e606345411798 : Closed e606345411798 ∧ code e606345411798 = 9402438434006 := by decide
theorem cert_e606345411798 : check e606345411798 [[.under]] .sourceHead = true := by decide
def e606345411802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e606345411802 : Closed e606345411802 ∧ code e606345411802 = 9402438434010 := by decide
theorem cert_e606345411802 : check e606345411802 [[.under]] .sourceHead = true := by decide
def e606345411818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e606345411818 : Closed e606345411818 ∧ code e606345411818 = 9402438434026 := by decide
theorem cert_e606345411818 : check e606345411818 [[.under]] .sourceHead = true := by decide
def e606345411894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e606345411894 : Closed e606345411894 ∧ code e606345411894 = 9402438434102 := by decide
theorem cert_e606345411894 : check e606345411894 [[.under]] .sourceHead = true := by decide
def e606345411898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e606345411898 : Closed e606345411898 ∧ code e606345411898 = 9402438434106 := by decide
theorem cert_e606345411898 : check e606345411898 [[.under]] .sourceHead = true := by decide
def e606345411994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606345411994 : Closed e606345411994 ∧ code e606345411994 = 9402438434202 := by decide
theorem cert_e606345411994 : check e606345411994 [[.under]] .sourceHead = true := by decide
def e606345415534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e606345415534 : Closed e606345415534 ∧ code e606345415534 = 9402438437742 := by decide
theorem cert_e606345415534 : check e606345415534 [[.under]] .sourceHead = true := by decide
def e606345415542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e606345415542 : Closed e606345415542 ∧ code e606345415542 = 9402438437750 := by decide
theorem cert_e606345415542 : check e606345415542 [[.under]] .sourceHead = true := by decide
def e606345415598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e606345415598 : Closed e606345415598 ∧ code e606345415598 = 9402438437806 := by decide
theorem cert_e606345415598 : check e606345415598 [[.under]] .sourceHead = true := by decide
def e606345415610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e606345415610 : Closed e606345415610 ∧ code e606345415610 = 9402438437818 := by decide
theorem cert_e606345415610 : check e606345415610 [[.under]] .sourceHead = true := by decide
def e606345415638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e606345415638 : Closed e606345415638 ∧ code e606345415638 = 9402438437846 := by decide
theorem cert_e606345415638 : check e606345415638 [[.under]] .sourceHead = true := by decide
def e606345415642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e606345415642 : Closed e606345415642 ∧ code e606345415642 = 9402438437850 := by decide
theorem cert_e606345415642 : check e606345415642 [[.under]] .sourceHead = true := by decide
def e606345415918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e606345415918 : Closed e606345415918 ∧ code e606345415918 = 9402438438126 := by decide
theorem cert_e606345415918 : check e606345415918 [[.under]] .sourceHead = true := by decide
def e606345415926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e606345415926 : Closed e606345415926 ∧ code e606345415926 = 9402438438134 := by decide
theorem cert_e606345415926 : check e606345415926 [[.under]] .sourceHead = true := by decide
def e606345416302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e606345416302 : Closed e606345416302 ∧ code e606345416302 = 9402438438510 := by decide
theorem cert_e606345416302 : check e606345416302 [[.under]] .sourceHead = true := by decide
def e606345416314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e606345416314 : Closed e606345416314 ∧ code e606345416314 = 9402438438522 := by decide
theorem cert_e606345416314 : check e606345416314 [[.under]] .sourceHead = true := by decide
def e606345416502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e606345416502 : Closed e606345416502 ∧ code e606345416502 = 9402438438710 := by decide
theorem cert_e606345416502 : check e606345416502 [[.under]] .sourceHead = true := by decide
def e606345416506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e606345416506 : Closed e606345416506 ∧ code e606345416506 = 9402438438714 := by decide
theorem cert_e606345416506 : check e606345416506 [[.under]] .sourceHead = true := by decide
def e606345422254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e606345422254 : Closed e606345422254 ∧ code e606345422254 = 9402438444462 := by decide
theorem cert_e606345422254 : check e606345422254 [[.under]] .sourceHead = true := by decide
def e606345422266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e606345422266 : Closed e606345422266 ∧ code e606345422266 = 9402438444474 := by decide
theorem cert_e606345422266 : check e606345422266 [[.under]] .sourceHead = true := by decide
def e606345422314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e606345422314 : Closed e606345422314 ∧ code e606345422314 = 9402438444522 := by decide
theorem cert_e606345422314 : check e606345422314 [[.under]] .sourceHead = true := by decide
def e606345422446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e606345422446 : Closed e606345422446 ∧ code e606345422446 = 9402438444654 := by decide
theorem cert_e606345422446 : check e606345422446 [[.under]] .sourceHead = true := by decide
def e606345422458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e606345422458 : Closed e606345422458 ∧ code e606345422458 = 9402438444666 := by decide
theorem cert_e606345422458 : check e606345422458 [[.under]] .sourceHead = true := by decide
def e606345422746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e606345422746 : Closed e606345422746 ∧ code e606345422746 = 9402438444954 := by decide
theorem cert_e606345422746 : check e606345422746 [[.under]] .sourceHead = true := by decide
def e606345425622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e606345425622 : Closed e606345425622 ∧ code e606345425622 = 9402438447830 := by decide
theorem cert_e606345425622 : check e606345425622 [[.under]] .sourceHead = true := by decide
def e606345425626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e606345425626 : Closed e606345425626 ∧ code e606345425626 = 9402438447834 := by decide
theorem cert_e606345425626 : check e606345425626 [[.under]] .sourceHead = true := by decide
def e606345425642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e606345425642 : Closed e606345425642 ∧ code e606345425642 = 9402438447850 := by decide
theorem cert_e606345425642 : check e606345425642 [[.under]] .sourceHead = true := by decide
def e606345425718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e606345425718 : Closed e606345425718 ∧ code e606345425718 = 9402438447926 := by decide
theorem cert_e606345425718 : check e606345425718 [[.under]] .sourceHead = true := by decide
def e606345425722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e606345425722 : Closed e606345425722 ∧ code e606345425722 = 9402438447930 := by decide
theorem cert_e606345425722 : check e606345425722 [[.under]] .sourceHead = true := by decide
def e606345425818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e606345425818 : Closed e606345425818 ∧ code e606345425818 = 9402438448026 := by decide
theorem cert_e606345425818 : check e606345425818 [[.under]] .sourceHead = true := by decide
def e606345562990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e606345562990 : Closed e606345562990 ∧ code e606345562990 = 9402438585198 := by decide
theorem cert_e606345562990 : check e606345562990 [[.under]] .sourceHead = true := by decide
def e606345562998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e606345562998 : Closed e606345562998 ∧ code e606345562998 = 9402438585206 := by decide
theorem cert_e606345562998 : check e606345562998 [[.under]] .sourceHead = true := by decide
def e606345563054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e606345563054 : Closed e606345563054 ∧ code e606345563054 = 9402438585262 := by decide
theorem cert_e606345563054 : check e606345563054 [[.under]] .sourceHead = true := by decide
def e606345563066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e606345563066 : Closed e606345563066 ∧ code e606345563066 = 9402438585274 := by decide
theorem cert_e606345563066 : check e606345563066 [[.under]] .sourceHead = true := by decide
def e606345563094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e606345563094 : Closed e606345563094 ∧ code e606345563094 = 9402438585302 := by decide
theorem cert_e606345563094 : check e606345563094 [[.under]] .sourceHead = true := by decide
def e606345563098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e606345563098 : Closed e606345563098 ∧ code e606345563098 = 9402438585306 := by decide
theorem cert_e606345563098 : check e606345563098 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
