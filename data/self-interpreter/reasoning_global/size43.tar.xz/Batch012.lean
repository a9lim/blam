import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601487181290 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601487181290 : Closed e601487181290 ∧ code e601487181290 = 9397580203498 := by decide
theorem cert_e601487181290 : check e601487181290 [[.under]] .width = true := by decide
def e601487181422 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601487181422 : Closed e601487181422 ∧ code e601487181422 = 9397580203630 := by decide
theorem cert_e601487181422 : check e601487181422 [[.under]] .width = true := by decide
def e601487181434 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601487181434 : Closed e601487181434 ∧ code e601487181434 = 9397580203642 := by decide
theorem cert_e601487181434 : check e601487181434 [[.under]] .width = true := by decide
def e601487181722 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601487181722 : Closed e601487181722 ∧ code e601487181722 = 9397580203930 := by decide
theorem cert_e601487181722 : check e601487181722 [[.under]] .width = true := by decide
def e601487185462 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601487185462 : Closed e601487185462 ∧ code e601487185462 = 9397580207670 := by decide
theorem cert_e601487185462 : check e601487185462 [[.under]] .width = true := by decide
def e601487185466 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601487185466 : Closed e601487185466 ∧ code e601487185466 = 9397580207674 := by decide
theorem cert_e601487185466 : check e601487185466 [[.under]] .width = true := by decide
def e601487185550 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601487185550 : Closed e601487185550 ∧ code e601487185550 = 9397580207758 := by decide
theorem cert_e601487185550 : check e601487185550 [[.under]] .width = true := by decide
def e601487185606 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601487185606 : Closed e601487185606 ∧ code e601487185606 = 9397580207814 := by decide
theorem cert_e601487185606 : check e601487185606 [[.under]] .width = true := by decide
def e601487185690 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601487185690 : Closed e601487185690 ∧ code e601487185690 = 9397580207898 := by decide
theorem cert_e601487185690 : check e601487185690 [[.under]] .width = true := by decide
def e601487185734 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601487185734 : Closed e601487185734 ∧ code e601487185734 = 9397580207942 := by decide
theorem cert_e601487185734 : check e601487185734 [[.under]] .width = true := by decide
def e601487186318 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601487186318 : Closed e601487186318 ∧ code e601487186318 = 9397580208526 := by decide
theorem cert_e601487186318 : check e601487186318 [[.under]] .width = true := by decide
def e601487186374 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601487186374 : Closed e601487186374 ∧ code e601487186374 = 9397580208582 := by decide
theorem cert_e601487186374 : check e601487186374 [[.under]] .width = true := by decide
def e601487187142 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601487187142 : Closed e601487187142 ∧ code e601487187142 = 9397580209350 := by decide
theorem cert_e601487187142 : check e601487187142 [[.under]] .width = true := by decide
def e601487202410 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601487202410 : Closed e601487202410 ∧ code e601487202410 = 9397580224618 := by decide
theorem cert_e601487202410 : check e601487202410 [[.under]] .width = true := by decide
def e601487202842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601487202842 : Closed e601487202842 ∧ code e601487202842 = 9397580225050 := by decide
theorem cert_e601487202842 : check e601487202842 [[.under]] .width = true := by decide
def e601487204378 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601487204378 : Closed e601487204378 ∧ code e601487204378 = 9397580226586 := by decide
theorem cert_e601487204378 : check e601487204378 [[.under]] .width = true := by decide
def e601487204470 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601487204470 : Closed e601487204470 ∧ code e601487204470 = 9397580226678 := by decide
theorem cert_e601487204470 : check e601487204470 [[.under]] .width = true := by decide
def e601487204714 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601487204714 : Closed e601487204714 ∧ code e601487204714 = 9397580226922 := by decide
theorem cert_e601487204714 : check e601487204714 [[.under]] .width = true := by decide
def e601487204762 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601487204762 : Closed e601487204762 ∧ code e601487204762 = 9397580226970 := by decide
theorem cert_e601487204762 : check e601487204762 [[.under]] .width = true := by decide
def e601487205914 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601487205914 : Closed e601487205914 ∧ code e601487205914 = 9397580228122 := by decide
theorem cert_e601487205914 : check e601487205914 [[.under]] .width = true := by decide
def e601487426262 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601487426262 : Closed e601487426262 ∧ code e601487426262 = 9397580448470 := by decide
theorem cert_e601487426262 : check e601487426262 [[.under]] .width = true := by decide
def e601487426266 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601487426266 : Closed e601487426266 ∧ code e601487426266 = 9397580448474 := by decide
theorem cert_e601487426266 : check e601487426266 [[.under]] .width = true := by decide
def e601487426282 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601487426282 : Closed e601487426282 ∧ code e601487426282 = 9397580448490 := by decide
theorem cert_e601487426282 : check e601487426282 [[.under]] .width = true := by decide
def e601487426358 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601487426358 : Closed e601487426358 ∧ code e601487426358 = 9397580448566 := by decide
theorem cert_e601487426358 : check e601487426358 [[.under]] .width = true := by decide
def e601487426362 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601487426362 : Closed e601487426362 ∧ code e601487426362 = 9397580448570 := by decide
theorem cert_e601487426362 : check e601487426362 [[.under]] .width = true := by decide
def e601487426458 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601487426458 : Closed e601487426458 ∧ code e601487426458 = 9397580448666 := by decide
theorem cert_e601487426458 : check e601487426458 [[.under]] .width = true := by decide
def e601487533594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601487533594 : Closed e601487533594 ∧ code e601487533594 = 9397580555802 := by decide
theorem cert_e601487533594 : check e601487533594 [[.under]] .width = true := by decide
def e601487549978 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601487549978 : Closed e601487549978 ∧ code e601487549978 = 9397580572186 := by decide
theorem cert_e601487549978 : check e601487549978 [[.under]] .width = true := by decide
def e601487705518 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601487705518 : Closed e601487705518 ∧ code e601487705518 = 9397580727726 := by decide
theorem cert_e601487705518 : check e601487705518 [[.under]] .width = true := by decide
def e601487705530 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601487705530 : Closed e601487705530 ∧ code e601487705530 = 9397580727738 := by decide
theorem cert_e601487705530 : check e601487705530 [[.under]] .width = true := by decide
def e601487705578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601487705578 : Closed e601487705578 ∧ code e601487705578 = 9397580727786 := by decide
theorem cert_e601487705578 : check e601487705578 [[.under]] .width = true := by decide
def e601487705710 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601487705710 : Closed e601487705710 ∧ code e601487705710 = 9397580727918 := by decide
theorem cert_e601487705710 : check e601487705710 [[.under]] .width = true := by decide
def e601487705722 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601487705722 : Closed e601487705722 ∧ code e601487705722 = 9397580727930 := by decide
theorem cert_e601487705722 : check e601487705722 [[.under]] .width = true := by decide
def e601487706010 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601487706010 : Closed e601487706010 ∧ code e601487706010 = 9397580728218 := by decide
theorem cert_e601487706010 : check e601487706010 [[.under]] .width = true := by decide
def e601487709750 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601487709750 : Closed e601487709750 ∧ code e601487709750 = 9397580731958 := by decide
theorem cert_e601487709750 : check e601487709750 [[.under]] .width = true := by decide
def e601487709754 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601487709754 : Closed e601487709754 ∧ code e601487709754 = 9397580731962 := by decide
theorem cert_e601487709754 : check e601487709754 [[.under]] .width = true := by decide
def e601487709838 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601487709838 : Closed e601487709838 ∧ code e601487709838 = 9397580732046 := by decide
theorem cert_e601487709838 : check e601487709838 [[.under]] .width = true := by decide
def e601487709894 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601487709894 : Closed e601487709894 ∧ code e601487709894 = 9397580732102 := by decide
theorem cert_e601487709894 : check e601487709894 [[.under]] .width = true := by decide
def e601487709978 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601487709978 : Closed e601487709978 ∧ code e601487709978 = 9397580732186 := by decide
theorem cert_e601487709978 : check e601487709978 [[.under]] .width = true := by decide
def e601487710022 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601487710022 : Closed e601487710022 ∧ code e601487710022 = 9397580732230 := by decide
theorem cert_e601487710022 : check e601487710022 [[.under]] .width = true := by decide
def e601487710606 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601487710606 : Closed e601487710606 ∧ code e601487710606 = 9397580732814 := by decide
theorem cert_e601487710606 : check e601487710606 [[.under]] .width = true := by decide
def e601487710662 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601487710662 : Closed e601487710662 ∧ code e601487710662 = 9397580732870 := by decide
theorem cert_e601487710662 : check e601487710662 [[.under]] .width = true := by decide
def e601487711430 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601487711430 : Closed e601487711430 ∧ code e601487711430 = 9397580733638 := by decide
theorem cert_e601487711430 : check e601487711430 [[.under]] .width = true := by decide
def e601487726698 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601487726698 : Closed e601487726698 ∧ code e601487726698 = 9397580748906 := by decide
theorem cert_e601487726698 : check e601487726698 [[.under]] .width = true := by decide
def e601487727130 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601487727130 : Closed e601487727130 ∧ code e601487727130 = 9397580749338 := by decide
theorem cert_e601487727130 : check e601487727130 [[.under]] .width = true := by decide
def e601487728666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601487728666 : Closed e601487728666 ∧ code e601487728666 = 9397580750874 := by decide
theorem cert_e601487728666 : check e601487728666 [[.under]] .width = true := by decide
def e601487728758 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601487728758 : Closed e601487728758 ∧ code e601487728758 = 9397580750966 := by decide
theorem cert_e601487728758 : check e601487728758 [[.under]] .width = true := by decide
def e601487729002 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601487729002 : Closed e601487729002 ∧ code e601487729002 = 9397580751210 := by decide
theorem cert_e601487729002 : check e601487729002 [[.under]] .width = true := by decide
def e601487729050 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601487729050 : Closed e601487729050 ∧ code e601487729050 = 9397580751258 := by decide
theorem cert_e601487729050 : check e601487729050 [[.under]] .width = true := by decide
def e601487730202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601487730202 : Closed e601487730202 ∧ code e601487730202 = 9397580752410 := by decide
theorem cert_e601487730202 : check e601487730202 [[.under]] .width = true := by decide
def e601489261270 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601489261270 : Closed e601489261270 ∧ code e601489261270 = 9397582283478 := by decide
theorem cert_e601489261270 : check e601489261270 [[.under]] .width = true := by decide
def e601489261274 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601489261274 : Closed e601489261274 ∧ code e601489261274 = 9397582283482 := by decide
theorem cert_e601489261274 : check e601489261274 [[.under]] .width = true := by decide
def e601489261290 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601489261290 : Closed e601489261290 ∧ code e601489261290 = 9397582283498 := by decide
theorem cert_e601489261290 : check e601489261290 [[.under]] .width = true := by decide
def e601489261366 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601489261366 : Closed e601489261366 ∧ code e601489261366 = 9397582283574 := by decide
theorem cert_e601489261366 : check e601489261366 [[.under]] .width = true := by decide
def e601489261370 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601489261370 : Closed e601489261370 ∧ code e601489261370 = 9397582283578 := by decide
theorem cert_e601489261370 : check e601489261370 [[.under]] .width = true := by decide
def e601489261466 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601489261466 : Closed e601489261466 ∧ code e601489261466 = 9397582283674 := by decide
theorem cert_e601489261466 : check e601489261466 [[.under]] .width = true := by decide
def e601489359574 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601489359574 : Closed e601489359574 ∧ code e601489359574 = 9397582381782 := by decide
theorem cert_e601489359574 : check e601489359574 [[.under]] .width = true := by decide
def e601489359578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601489359578 : Closed e601489359578 ∧ code e601489359578 = 9397582381786 := by decide
theorem cert_e601489359578 : check e601489359578 [[.under]] .width = true := by decide
def e601489359594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601489359594 : Closed e601489359594 ∧ code e601489359594 = 9397582381802 := by decide
theorem cert_e601489359594 : check e601489359594 [[.under]] .width = true := by decide
def e601489359670 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601489359670 : Closed e601489359670 ∧ code e601489359670 = 9397582381878 := by decide
theorem cert_e601489359670 : check e601489359670 [[.under]] .width = true := by decide
def e601489359674 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601489359674 : Closed e601489359674 ∧ code e601489359674 = 9397582381882 := by decide
theorem cert_e601489359674 : check e601489359674 [[.under]] .width = true := by decide
def e601489359770 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601489359770 : Closed e601489359770 ∧ code e601489359770 = 9397582381978 := by decide
theorem cert_e601489359770 : check e601489359770 [[.under]] .width = true := by decide
def e601490122266 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490122266 : Closed e601490122266 ∧ code e601490122266 = 9397583144474 := by decide
theorem cert_e601490122266 : check e601490122266 [[.under]] .width = true := by decide
def e601490171418 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490171418 : Closed e601490171418 ∧ code e601490171418 = 9397583193626 := by decide
theorem cert_e601490171418 : check e601490171418 [[.under]] .width = true := by decide
def e601490368026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490368026 : Closed e601490368026 ∧ code e601490368026 = 9397583390234 := by decide
theorem cert_e601490368026 : check e601490368026 [[.under]] .width = true := by decide
def e601490703062 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601490703062 : Closed e601490703062 ∧ code e601490703062 = 9397583725270 := by decide
theorem cert_e601490703062 : check e601490703062 [[.under]] .width = true := by decide
def e601490703066 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601490703066 : Closed e601490703066 ∧ code e601490703066 = 9397583725274 := by decide
theorem cert_e601490703066 : check e601490703066 [[.under]] .width = true := by decide
def e601490703082 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601490703082 : Closed e601490703082 ∧ code e601490703082 = 9397583725290 := by decide
theorem cert_e601490703082 : check e601490703082 [[.under]] .width = true := by decide
def e601490703158 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601490703158 : Closed e601490703158 ∧ code e601490703158 = 9397583725366 := by decide
theorem cert_e601490703158 : check e601490703158 [[.under]] .width = true := by decide
def e601490703162 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601490703162 : Closed e601490703162 ∧ code e601490703162 = 9397583725370 := by decide
theorem cert_e601490703162 : check e601490703162 [[.under]] .width = true := by decide
def e601490703258 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601490703258 : Closed e601490703258 ∧ code e601490703258 = 9397583725466 := by decide
theorem cert_e601490703258 : check e601490703258 [[.under]] .width = true := by decide
def e601490908698 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490908698 : Closed e601490908698 ∧ code e601490908698 = 9397583930906 := by decide
theorem cert_e601490908698 : check e601490908698 [[.under]] .width = true := by decide
def e601490957850 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490957850 : Closed e601490957850 ∧ code e601490957850 = 9397583980058 := by decide
theorem cert_e601490957850 : check e601490957850 [[.under]] .width = true := by decide
def e601491375534 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601491375534 : Closed e601491375534 ∧ code e601491375534 = 9397584397742 := by decide
theorem cert_e601491375534 : check e601491375534 [[.under]] .width = true := by decide
def e601491375546 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601491375546 : Closed e601491375546 ∧ code e601491375546 = 9397584397754 := by decide
theorem cert_e601491375546 : check e601491375546 [[.under]] .width = true := by decide
def e601491375594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601491375594 : Closed e601491375594 ∧ code e601491375594 = 9397584397802 := by decide
theorem cert_e601491375594 : check e601491375594 [[.under]] .width = true := by decide
def e601491375726 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601491375726 : Closed e601491375726 ∧ code e601491375726 = 9397584397934 := by decide
theorem cert_e601491375726 : check e601491375726 [[.under]] .width = true := by decide
def e601491375738 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601491375738 : Closed e601491375738 ∧ code e601491375738 = 9397584397946 := by decide
theorem cert_e601491375738 : check e601491375738 [[.under]] .width = true := by decide
def e601491376026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601491376026 : Closed e601491376026 ∧ code e601491376026 = 9397584398234 := by decide
theorem cert_e601491376026 : check e601491376026 [[.under]] .width = true := by decide
def e601491379766 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601491379766 : Closed e601491379766 ∧ code e601491379766 = 9397584401974 := by decide
theorem cert_e601491379766 : check e601491379766 [[.under]] .width = true := by decide
def e601491379770 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601491379770 : Closed e601491379770 ∧ code e601491379770 = 9397584401978 := by decide
theorem cert_e601491379770 : check e601491379770 [[.under]] .width = true := by decide
def e601491379854 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601491379854 : Closed e601491379854 ∧ code e601491379854 = 9397584402062 := by decide
theorem cert_e601491379854 : check e601491379854 [[.under]] .width = true := by decide
def e601491379910 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601491379910 : Closed e601491379910 ∧ code e601491379910 = 9397584402118 := by decide
theorem cert_e601491379910 : check e601491379910 [[.under]] .width = true := by decide
def e601491379994 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601491379994 : Closed e601491379994 ∧ code e601491379994 = 9397584402202 := by decide
theorem cert_e601491379994 : check e601491379994 [[.under]] .width = true := by decide
def e601491380038 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601491380038 : Closed e601491380038 ∧ code e601491380038 = 9397584402246 := by decide
theorem cert_e601491380038 : check e601491380038 [[.under]] .width = true := by decide
def e601491380622 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601491380622 : Closed e601491380622 ∧ code e601491380622 = 9397584402830 := by decide
theorem cert_e601491380622 : check e601491380622 [[.under]] .width = true := by decide
def e601491380678 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601491380678 : Closed e601491380678 ∧ code e601491380678 = 9397584402886 := by decide
theorem cert_e601491380678 : check e601491380678 [[.under]] .width = true := by decide
def e601491381446 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601491381446 : Closed e601491381446 ∧ code e601491381446 = 9397584403654 := by decide
theorem cert_e601491381446 : check e601491381446 [[.under]] .width = true := by decide
def e601491396714 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601491396714 : Closed e601491396714 ∧ code e601491396714 = 9397584418922 := by decide
theorem cert_e601491396714 : check e601491396714 [[.under]] .width = true := by decide
def e601491397146 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601491397146 : Closed e601491397146 ∧ code e601491397146 = 9397584419354 := by decide
theorem cert_e601491397146 : check e601491397146 [[.under]] .width = true := by decide
def e601491398682 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601491398682 : Closed e601491398682 ∧ code e601491398682 = 9397584420890 := by decide
theorem cert_e601491398682 : check e601491398682 [[.under]] .width = true := by decide
def e601491398774 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601491398774 : Closed e601491398774 ∧ code e601491398774 = 9397584420982 := by decide
theorem cert_e601491398774 : check e601491398774 [[.under]] .width = true := by decide
def e601491399018 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601491399018 : Closed e601491399018 ∧ code e601491399018 = 9397584421226 := by decide
theorem cert_e601491399018 : check e601491399018 [[.under]] .width = true := by decide
def e601491399066 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601491399066 : Closed e601491399066 ∧ code e601491399066 = 9397584421274 := by decide
theorem cert_e601491399066 : check e601491399066 [[.under]] .width = true := by decide
def e601491400218 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601491400218 : Closed e601491400218 ∧ code e601491400218 = 9397584422426 := by decide
theorem cert_e601491400218 : check e601491400218 [[.under]] .width = true := by decide
def e601492079318 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601492079318 : Closed e601492079318 ∧ code e601492079318 = 9397585101526 := by decide
private def t_e601492079318 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e601492079318 : ¬ IsSelfInterpreter e601492079318 :=
  wSource (t := t_e601492079318) (replay_sound (ps := []) (t := e601492079318) (by decide)) (by decide)
def e601492079322 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601492079322 : Closed e601492079322 ∧ code e601492079322 = 9397585101530 := by decide
theorem cert_e601492079322 : check e601492079322 [[.under]] .width = true := by decide
def e601492079338 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601492079338 : Closed e601492079338 ∧ code e601492079338 = 9397585101546 := by decide
theorem cert_e601492079338 : check e601492079338 [[.under]] .width = true := by decide
def e601492079414 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601492079414 : Closed e601492079414 ∧ code e601492079414 = 9397585101622 := by decide
theorem cert_e601492079414 : check e601492079414 [[.under]] .width = true := by decide
def e601492079418 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601492079418 : Closed e601492079418 ∧ code e601492079418 = 9397585101626 := by decide
theorem cert_e601492079418 : check e601492079418 [[.under]] .width = true := by decide
def e601492079514 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601492079514 : Closed e601492079514 ∧ code e601492079514 = 9397585101722 := by decide
theorem cert_e601492079514 : check e601492079514 [[.under]] .width = true := by decide
def e601492137498 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601492137498 : Closed e601492137498 ∧ code e601492137498 = 9397585159706 := by decide
theorem cert_e601492137498 : check e601492137498 [[.under]] .width = true := by decide
def e601492161966 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601492161966 : Closed e601492161966 ∧ code e601492161966 = 9397585184174 := by decide
theorem cert_e601492161966 : check e601492161966 [[.under]] .width = true := by decide
def e601492161978 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601492161978 : Closed e601492161978 ∧ code e601492161978 = 9397585184186 := by decide
theorem cert_e601492161978 : check e601492161978 [[.under]] .width = true := by decide
def e601492162026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601492162026 : Closed e601492162026 ∧ code e601492162026 = 9397585184234 := by decide
theorem cert_e601492162026 : check e601492162026 [[.under]] .width = true := by decide
def e601492162158 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601492162158 : Closed e601492162158 ∧ code e601492162158 = 9397585184366 := by decide
theorem cert_e601492162158 : check e601492162158 [[.under]] .width = true := by decide
def e601492162170 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601492162170 : Closed e601492162170 ∧ code e601492162170 = 9397585184378 := by decide
theorem cert_e601492162170 : check e601492162170 [[.under]] .width = true := by decide
def e601492162458 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601492162458 : Closed e601492162458 ∧ code e601492162458 = 9397585184666 := by decide
theorem cert_e601492162458 : check e601492162458 [[.under]] .width = true := by decide
def e601492166198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601492166198 : Closed e601492166198 ∧ code e601492166198 = 9397585188406 := by decide
theorem cert_e601492166198 : check e601492166198 [[.under]] .width = true := by decide
def e601492166202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601492166202 : Closed e601492166202 ∧ code e601492166202 = 9397585188410 := by decide
theorem cert_e601492166202 : check e601492166202 [[.under]] .width = true := by decide
def e601492166286 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601492166286 : Closed e601492166286 ∧ code e601492166286 = 9397585188494 := by decide
private def t_e601492166286 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem cert_e601492166286 : ¬ IsSelfInterpreter e601492166286 :=
  wSource (t := t_e601492166286) (replay_sound (ps := []) (t := e601492166286) (by decide)) (by decide)
def e601492166342 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601492166342 : Closed e601492166342 ∧ code e601492166342 = 9397585188550 := by decide
theorem cert_e601492166342 : check e601492166342 [[.under]] .width = true := by decide
def e601492166426 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601492166426 : Closed e601492166426 ∧ code e601492166426 = 9397585188634 := by decide
theorem cert_e601492166426 : check e601492166426 [[.under]] .width = true := by decide
def e601492166470 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601492166470 : Closed e601492166470 ∧ code e601492166470 = 9397585188678 := by decide
theorem cert_e601492166470 : check e601492166470 [[.under]] .width = true := by decide
def e601492167054 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601492167054 : Closed e601492167054 ∧ code e601492167054 = 9397585189262 := by decide
theorem cert_e601492167054 : check e601492167054 [[.under]] .width = true := by decide
def e601492167110 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601492167110 : Closed e601492167110 ∧ code e601492167110 = 9397585189318 := by decide
theorem cert_e601492167110 : check e601492167110 [[.under]] .width = true := by decide
def e601492167878 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601492167878 : Closed e601492167878 ∧ code e601492167878 = 9397585190086 := by decide
theorem cert_e601492167878 : check e601492167878 [[.under]] .width = true := by decide
def e601492183146 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601492183146 : Closed e601492183146 ∧ code e601492183146 = 9397585205354 := by decide
theorem cert_e601492183146 : check e601492183146 [[.under]] .width = true := by decide
def e601492183578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601492183578 : Closed e601492183578 ∧ code e601492183578 = 9397585205786 := by decide
theorem cert_e601492183578 : check e601492183578 [[.under]] .width = true := by decide
def e601492185114 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601492185114 : Closed e601492185114 ∧ code e601492185114 = 9397585207322 := by decide
theorem cert_e601492185114 : check e601492185114 [[.under]] .width = true := by decide
def e601492185206 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601492185206 : Closed e601492185206 ∧ code e601492185206 = 9397585207414 := by decide
theorem cert_e601492185206 : check e601492185206 [[.under]] .width = true := by decide
def e601492185450 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601492185450 : Closed e601492185450 ∧ code e601492185450 = 9397585207658 := by decide
theorem cert_e601492185450 : check e601492185450 [[.under]] .width = true := by decide
def e601492185498 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601492185498 : Closed e601492185498 ∧ code e601492185498 = 9397585207706 := by decide
theorem cert_e601492185498 : check e601492185498 [[.under]] .width = true := by decide
def e601492186650 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601492186650 : Closed e601492186650 ∧ code e601492186650 = 9397585208858 := by decide
theorem cert_e601492186650 : check e601492186650 [[.under]] .width = true := by decide
def e601492996822 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601492996822 : Closed e601492996822 ∧ code e601492996822 = 9397586019030 := by decide
theorem cert_e601492996822 : check e601492996822 [[.under]] .width = true := by decide
def e601492996826 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601492996826 : Closed e601492996826 ∧ code e601492996826 = 9397586019034 := by decide
theorem cert_e601492996826 : check e601492996826 [[.under]] .width = true := by decide
def e601492996842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601492996842 : Closed e601492996842 ∧ code e601492996842 = 9397586019050 := by decide
theorem cert_e601492996842 : check e601492996842 [[.under]] .width = true := by decide
def e601492996918 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601492996918 : Closed e601492996918 ∧ code e601492996918 = 9397586019126 := by decide
theorem cert_e601492996918 : check e601492996918 [[.under]] .width = true := by decide
def e601492996922 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601492996922 : Closed e601492996922 ∧ code e601492996922 = 9397586019130 := by decide
theorem cert_e601492996922 : check e601492996922 [[.under]] .width = true := by decide
def e601492997018 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601492997018 : Closed e601492997018 ∧ code e601492997018 = 9397586019226 := by decide
theorem cert_e601492997018 : check e601492997018 [[.under]] .width = true := by decide
def e601493029590 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601493029590 : Closed e601493029590 ∧ code e601493029590 = 9397586051798 := by decide
theorem cert_e601493029590 : check e601493029590 [[.under]] .width = true := by decide
def e601493029594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601493029594 : Closed e601493029594 ∧ code e601493029594 = 9397586051802 := by decide
theorem cert_e601493029594 : check e601493029594 [[.under]] .width = true := by decide
def e601493029610 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601493029610 : Closed e601493029610 ∧ code e601493029610 = 9397586051818 := by decide
theorem cert_e601493029610 : check e601493029610 [[.under]] .width = true := by decide
def e601493029686 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601493029686 : Closed e601493029686 ∧ code e601493029686 = 9397586051894 := by decide
theorem cert_e601493029686 : check e601493029686 [[.under]] .width = true := by decide
def e601493029690 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601493029690 : Closed e601493029690 ∧ code e601493029690 = 9397586051898 := by decide
theorem cert_e601493029690 : check e601493029690 [[.under]] .width = true := by decide
def e601493029786 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601493029786 : Closed e601493029786 ∧ code e601493029786 = 9397586051994 := by decide
theorem cert_e601493029786 : check e601493029786 [[.under]] .width = true := by decide
def e601493431834 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493431834 : Closed e601493431834 ∧ code e601493431834 = 9397586454042 := by decide
theorem cert_e601493431834 : check e601493431834 [[.under]] .width = true := by decide
def e601493448218 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493448218 : Closed e601493448218 ∧ code e601493448218 = 9397586470426 := by decide
theorem cert_e601493448218 : check e601493448218 [[.under]] .width = true := by decide
def e601493513754 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493513754 : Closed e601493513754 ∧ code e601493513754 = 9397586535962 := by decide
theorem cert_e601493513754 : check e601493513754 [[.under]] .width = true := by decide
def e601493717718 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601493717718 : Closed e601493717718 ∧ code e601493717718 = 9397586739926 := by decide
theorem cert_e601493717718 : check e601493717718 [[.under]] .width = true := by decide
def e601493717722 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601493717722 : Closed e601493717722 ∧ code e601493717722 = 9397586739930 := by decide
theorem cert_e601493717722 : check e601493717722 [[.under]] .width = true := by decide
def e601493717738 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601493717738 : Closed e601493717738 ∧ code e601493717738 = 9397586739946 := by decide
theorem cert_e601493717738 : check e601493717738 [[.under]] .width = true := by decide
def e601493717814 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601493717814 : Closed e601493717814 ∧ code e601493717814 = 9397586740022 := by decide
theorem cert_e601493717814 : check e601493717814 [[.under]] .width = true := by decide
def e601493717818 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601493717818 : Closed e601493717818 ∧ code e601493717818 = 9397586740026 := by decide
theorem cert_e601493717818 : check e601493717818 [[.under]] .width = true := by decide
def e601493717914 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601493717914 : Closed e601493717914 ∧ code e601493717914 = 9397586740122 := by decide
theorem cert_e601493717914 : check e601493717914 [[.under]] .width = true := by decide
def e601493825050 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493825050 : Closed e601493825050 ∧ code e601493825050 = 9397586847258 := by decide
theorem cert_e601493825050 : check e601493825050 [[.under]] .width = true := by decide
def e601493841434 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493841434 : Closed e601493841434 ∧ code e601493841434 = 9397586863642 := by decide
theorem cert_e601493841434 : check e601493841434 [[.under]] .width = true := by decide
def e601493996974 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601493996974 : Closed e601493996974 ∧ code e601493996974 = 9397587019182 := by decide
theorem cert_e601493996974 : check e601493996974 [[.under]] .width = true := by decide
def e601493996986 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601493996986 : Closed e601493996986 ∧ code e601493996986 = 9397587019194 := by decide
theorem cert_e601493996986 : check e601493996986 [[.under]] .width = true := by decide
def e601493997034 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601493997034 : Closed e601493997034 ∧ code e601493997034 = 9397587019242 := by decide
theorem cert_e601493997034 : check e601493997034 [[.under]] .width = true := by decide
def e601493997166 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601493997166 : Closed e601493997166 ∧ code e601493997166 = 9397587019374 := by decide
theorem cert_e601493997166 : check e601493997166 [[.under]] .width = true := by decide
def e601493997178 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601493997178 : Closed e601493997178 ∧ code e601493997178 = 9397587019386 := by decide
theorem cert_e601493997178 : check e601493997178 [[.under]] .width = true := by decide
def e601493997466 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601493997466 : Closed e601493997466 ∧ code e601493997466 = 9397587019674 := by decide
theorem cert_e601493997466 : check e601493997466 [[.under]] .width = true := by decide
def e601494001206 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601494001206 : Closed e601494001206 ∧ code e601494001206 = 9397587023414 := by decide
theorem cert_e601494001206 : check e601494001206 [[.under]] .width = true := by decide
def e601494001210 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601494001210 : Closed e601494001210 ∧ code e601494001210 = 9397587023418 := by decide
theorem cert_e601494001210 : check e601494001210 [[.under]] .width = true := by decide
def e601494001294 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601494001294 : Closed e601494001294 ∧ code e601494001294 = 9397587023502 := by decide
theorem cert_e601494001294 : check e601494001294 [[.under]] .width = true := by decide
def e601494001350 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601494001350 : Closed e601494001350 ∧ code e601494001350 = 9397587023558 := by decide
theorem cert_e601494001350 : check e601494001350 [[.under]] .width = true := by decide
def e601494001434 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601494001434 : Closed e601494001434 ∧ code e601494001434 = 9397587023642 := by decide
theorem cert_e601494001434 : check e601494001434 [[.under]] .width = true := by decide
def e601494001478 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601494001478 : Closed e601494001478 ∧ code e601494001478 = 9397587023686 := by decide
theorem cert_e601494001478 : check e601494001478 [[.under]] .width = true := by decide
def e601494002062 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601494002062 : Closed e601494002062 ∧ code e601494002062 = 9397587024270 := by decide
theorem cert_e601494002062 : check e601494002062 [[.under]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e601492079318
#print axioms Blc.Floor43.cert_e601492166286
