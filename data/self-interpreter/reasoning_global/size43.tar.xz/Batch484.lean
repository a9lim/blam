import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407490006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422407490006 : Closed e2422407490006 ∧ code e2422407490006 = 11218500512214 := by decide
theorem cert_e2422407490006 : check e2422407490006 [[],[]] .chain = true := by decide
def e2422407490010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422407490010 : Closed e2422407490010 ∧ code e2422407490010 = 11218500512218 := by decide
theorem cert_e2422407490010 : check e2422407490010 [[],[]] .chain = true := by decide
def e2422407490026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407490026 : Closed e2422407490026 ∧ code e2422407490026 = 11218500512234 := by decide
theorem cert_e2422407490026 : check e2422407490026 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407490050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407490050 : Closed e2422407490050 ∧ code e2422407490050 = 11218500512258 := by decide
theorem cert_e2422407490050 : check e2422407490050 [[],[]] .chain = true := by decide
def e2422407490062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407490062 : Closed e2422407490062 ∧ code e2422407490062 = 11218500512270 := by decide
theorem cert_e2422407490062 : check e2422407490062 [[],[]] .chain = true := by decide
def e2422407490074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407490074 : Closed e2422407490074 ∧ code e2422407490074 = 11218500512282 := by decide
theorem cert_e2422407490074 : check e2422407490074 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407490146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407490146 : Closed e2422407490146 ∧ code e2422407490146 = 11218500512354 := by decide
theorem cert_e2422407490146 : check e2422407490146 [[],[]] .chain = true := by decide
def e2422407490158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407490158 : Closed e2422407490158 ∧ code e2422407490158 = 11218500512366 := by decide
theorem cert_e2422407490158 : check e2422407490158 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407490166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407490166 : Closed e2422407490166 ∧ code e2422407490166 = 11218500512374 := by decide
theorem cert_e2422407490166 : check e2422407490166 [[],[]] .chain = true := by decide
def e2422407490170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407490170 : Closed e2422407490170 ∧ code e2422407490170 = 11218500512378 := by decide
theorem cert_e2422407490170 : check e2422407490170 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407490310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407490310 : Closed e2422407490310 ∧ code e2422407490310 = 11218500512518 := by decide
theorem cert_e2422407490310 : check e2422407490310 [[],[]] .chain = true := by decide
def e2422407490334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422407490334 : Closed e2422407490334 ∧ code e2422407490334 = 11218500512542 := by decide
theorem cert_e2422407490334 : check e2422407490334 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407490358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407490358 : Closed e2422407490358 ∧ code e2422407490358 = 11218500512566 := by decide
theorem cert_e2422407490358 : check e2422407490358 [[],[]] .chain = true := by decide
def e2422407490362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407490362 : Closed e2422407490362 ∧ code e2422407490362 = 11218500512570 := by decide
theorem cert_e2422407490362 : check e2422407490362 [[],[]] .chain = true := by decide
def e2422407490434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407490434 : Closed e2422407490434 ∧ code e2422407490434 = 11218500512642 := by decide
theorem cert_e2422407490434 : check e2422407490434 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407490446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422407490446 : Closed e2422407490446 ∧ code e2422407490446 = 11218500512654 := by decide
theorem cert_e2422407490446 : check e2422407490446 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407490458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407490458 : Closed e2422407490458 ∧ code e2422407490458 = 11218500512666 := by decide
theorem cert_e2422407490458 : check e2422407490458 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407490586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422407490586 : Closed e2422407490586 ∧ code e2422407490586 = 11218500512794 := by decide
theorem cert_e2422407490586 : check e2422407490586 [[],[]] .chain = true := by decide
def e2422407490630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422407490630 : Closed e2422407490630 ∧ code e2422407490630 = 11218500512838 := by decide
theorem cert_e2422407490630 : check e2422407490630 [[],[]] .chain = true := by decide
def e2422407490658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407490658 : Closed e2422407490658 ∧ code e2422407490658 = 11218500512866 := by decide
theorem cert_e2422407490658 : check e2422407490658 [[],[]] .chain = true := by decide
def e2422407490670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407490670 : Closed e2422407490670 ∧ code e2422407490670 = 11218500512878 := by decide
theorem cert_e2422407490670 : check e2422407490670 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407490682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407490682 : Closed e2422407490682 ∧ code e2422407490682 = 11218500512890 := by decide
theorem cert_e2422407490682 : check e2422407490682 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407490774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407490774 : Closed e2422407490774 ∧ code e2422407490774 = 11218500512982 := by decide
theorem cert_e2422407490774 : check e2422407490774 [[],[]] .chain = true := by decide
def e2422407490778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407490778 : Closed e2422407490778 ∧ code e2422407490778 = 11218500512986 := by decide
theorem cert_e2422407490778 : check e2422407490778 [[],[]] .chain = true := by decide
def e2422407490794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407490794 : Closed e2422407490794 ∧ code e2422407490794 = 11218500513002 := by decide
theorem cert_e2422407490794 : check e2422407490794 [[],[]] .chain = true := by decide
def e2422407490822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407490822 : Closed e2422407490822 ∧ code e2422407490822 = 11218500513030 := by decide
theorem cert_e2422407490822 : check e2422407490822 [[],[]] .chain = true := by decide
def e2422407490846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407490846 : Closed e2422407490846 ∧ code e2422407490846 = 11218500513054 := by decide
theorem cert_e2422407490846 : check e2422407490846 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407490870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407490870 : Closed e2422407490870 ∧ code e2422407490870 = 11218500513078 := by decide
theorem cert_e2422407490870 : check e2422407490870 [[],[]] .chain = true := by decide
def e2422407490874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407490874 : Closed e2422407490874 ∧ code e2422407490874 = 11218500513082 := by decide
theorem cert_e2422407490874 : check e2422407490874 [[],[]] .chain = true := by decide
def e2422407490970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407490970 : Closed e2422407490970 ∧ code e2422407490970 = 11218500513178 := by decide
theorem cert_e2422407490970 : check e2422407490970 [[],[]] .chain = true := by decide
def e2422407491014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407491014 : Closed e2422407491014 ∧ code e2422407491014 = 11218500513222 := by decide
theorem cert_e2422407491014 : check e2422407491014 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407491082 : Closed e2422407491082 ∧ code e2422407491082 = 11218500513290 := by decide
theorem cert_e2422407491082 : check e2422407491082 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407491126 : Closed e2422407491126 ∧ code e2422407491126 = 11218500513334 := by decide
theorem cert_e2422407491126 : check e2422407491126 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407491130 : Closed e2422407491130 ∧ code e2422407491130 = 11218500513338 := by decide
theorem cert_e2422407491130 : check e2422407491130 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422407491178 : Closed e2422407491178 ∧ code e2422407491178 = 11218500513386 := by decide
theorem cert_e2422407491178 : check e2422407491178 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407491202 : Closed e2422407491202 ∧ code e2422407491202 = 11218500513410 := by decide
theorem cert_e2422407491202 : check e2422407491202 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407491214 : Closed e2422407491214 ∧ code e2422407491214 = 11218500513422 := by decide
theorem cert_e2422407491214 : check e2422407491214 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407491226 : Closed e2422407491226 ∧ code e2422407491226 = 11218500513434 := by decide
theorem cert_e2422407491226 : check e2422407491226 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407491270 : Closed e2422407491270 ∧ code e2422407491270 = 11218500513478 := by decide
theorem cert_e2422407491270 : check e2422407491270 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407491670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422407491670 : Closed e2422407491670 ∧ code e2422407491670 = 11218500513878 := by decide
theorem cert_e2422407491670 : check e2422407491670 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407491674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422407491674 : Closed e2422407491674 ∧ code e2422407491674 = 11218500513882 := by decide
theorem cert_e2422407491674 : check e2422407491674 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407492022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422407492022 : Closed e2422407492022 ∧ code e2422407492022 = 11218500514230 := by decide
theorem cert_e2422407492022 : check e2422407492022 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407492054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422407492054 : Closed e2422407492054 ∧ code e2422407492054 = 11218500514262 := by decide
theorem cert_e2422407492054 : check e2422407492054 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407492058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422407492058 : Closed e2422407492058 ∧ code e2422407492058 = 11218500514266 := by decide
theorem cert_e2422407492058 : check e2422407492058 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407492438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422407492438 : Closed e2422407492438 ∧ code e2422407492438 = 11218500514646 := by decide
theorem cert_e2422407492438 : check e2422407492438 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422407492442 : Closed e2422407492442 ∧ code e2422407492442 = 11218500514650 := by decide
theorem cert_e2422407492442 : check e2422407492442 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422407492458 : Closed e2422407492458 ∧ code e2422407492458 = 11218500514666 := by decide
theorem cert_e2422407492458 : check e2422407492458 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422407492522 : Closed e2422407492522 ∧ code e2422407492522 = 11218500514730 := by decide
theorem cert_e2422407492522 : check e2422407492522 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407492630 : Closed e2422407492630 ∧ code e2422407492630 = 11218500514838 := by decide
theorem cert_e2422407492630 : check e2422407492630 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407492726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422407492726 : Closed e2422407492726 ∧ code e2422407492726 = 11218500514934 := by decide
theorem cert_e2422407492726 : check e2422407492726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407492822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407492822 : Closed e2422407492822 ∧ code e2422407492822 = 11218500515030 := by decide
theorem cert_e2422407492822 : check e2422407492822 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407492826 : Closed e2422407492826 ∧ code e2422407492826 = 11218500515034 := by decide
theorem cert_e2422407492826 : check e2422407492826 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407492842 : Closed e2422407492842 ∧ code e2422407492842 = 11218500515050 := by decide
theorem cert_e2422407492842 : check e2422407492842 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407492918 : Closed e2422407492918 ∧ code e2422407492918 = 11218500515126 := by decide
theorem cert_e2422407492918 : check e2422407492918 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407492922 : Closed e2422407492922 ∧ code e2422407492922 = 11218500515130 := by decide
theorem cert_e2422407492922 : check e2422407492922 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407492994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407492994 : Closed e2422407492994 ∧ code e2422407492994 = 11218500515202 := by decide
theorem cert_e2422407492994 : check e2422407492994 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407493006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422407493006 : Closed e2422407493006 ∧ code e2422407493006 = 11218500515214 := by decide
theorem cert_e2422407493006 : check e2422407493006 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407493018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407493018 : Closed e2422407493018 ∧ code e2422407493018 = 11218500515226 := by decide
theorem cert_e2422407493018 : check e2422407493018 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407493130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407493130 : Closed e2422407493130 ∧ code e2422407493130 = 11218500515338 := by decide
theorem cert_e2422407493130 : check e2422407493130 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407493174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407493174 : Closed e2422407493174 ∧ code e2422407493174 = 11218500515382 := by decide
theorem cert_e2422407493174 : check e2422407493174 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422407493178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407493178 : Closed e2422407493178 ∧ code e2422407493178 = 11218500515386 := by decide
theorem cert_e2422407493178 : check e2422407493178 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422407493226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422407493226 : Closed e2422407493226 ∧ code e2422407493226 = 11218500515434 := by decide
theorem cert_e2422407493226 : check e2422407493226 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407493250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407493250 : Closed e2422407493250 ∧ code e2422407493250 = 11218500515458 := by decide
theorem cert_e2422407493250 : check e2422407493250 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422407493262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407493262 : Closed e2422407493262 ∧ code e2422407493262 = 11218500515470 := by decide
theorem cert_e2422407493262 : check e2422407493262 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422407493274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407493274 : Closed e2422407493274 ∧ code e2422407493274 = 11218500515482 := by decide
theorem cert_e2422407493274 : check e2422407493274 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407493318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407493318 : Closed e2422407493318 ∧ code e2422407493318 = 11218500515526 := by decide
theorem cert_e2422407493318 : check e2422407493318 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422407495894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e2422407495894 : Closed e2422407495894 ∧ code e2422407495894 = 11218500518102 := by decide
theorem cert_e2422407495894 : check e2422407495894 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407495990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407495990 : Closed e2422407495990 ∧ code e2422407495990 = 11218500518198 := by decide
theorem cert_e2422407495990 : check e2422407495990 [[],[]] .chain = true := by decide
def e2422407495994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407495994 : Closed e2422407495994 ∧ code e2422407495994 = 11218500518202 := by decide
theorem cert_e2422407495994 : check e2422407495994 [[],[]] .chain = true := by decide
def e2422407496182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2422407496182 : Closed e2422407496182 ∧ code e2422407496182 = 11218500518390 := by decide
theorem cert_e2422407496182 : check e2422407496182 [[],[]] .chain = true := by decide
def e2422407496566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e2422407496566 : Closed e2422407496566 ∧ code e2422407496566 = 11218500518774 := by decide
theorem cert_e2422407496566 : check e2422407496566 [[],[]] .chain = true := by decide
def e2422407496570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e2422407496570 : Closed e2422407496570 ∧ code e2422407496570 = 11218500518778 := by decide
theorem cert_e2422407496570 : check e2422407496570 [[],[]] .chain = true := by decide
def e2422407496630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e2422407496630 : Closed e2422407496630 ∧ code e2422407496630 = 11218500518838 := by decide
theorem cert_e2422407496630 : check e2422407496630 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407496662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e2422407496662 : Closed e2422407496662 ∧ code e2422407496662 = 11218500518870 := by decide
theorem cert_e2422407496662 : check e2422407496662 [[],[]] .chain = true := by decide
def e2422407496682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e2422407496682 : Closed e2422407496682 ∧ code e2422407496682 = 11218500518890 := by decide
theorem cert_e2422407496682 : check e2422407496682 [[],[]] .chain = true := by decide
def e2422407496942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407496942 : Closed e2422407496942 ∧ code e2422407496942 = 11218500519150 := by decide
theorem cert_e2422407496942 : check e2422407496942 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407496950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407496950 : Closed e2422407496950 ∧ code e2422407496950 = 11218500519158 := by decide
theorem cert_e2422407496950 : check e2422407496950 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407497334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407497334 : Closed e2422407497334 ∧ code e2422407497334 = 11218500519542 := by decide
theorem cert_e2422407497334 : check e2422407497334 [[],[]] .chain = true := by decide
def e2422407497526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407497526 : Closed e2422407497526 ∧ code e2422407497526 = 11218500519734 := by decide
theorem cert_e2422407497526 : check e2422407497526 [[],[]] .chain = true := by decide
def e2422407497530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407497530 : Closed e2422407497530 ∧ code e2422407497530 = 11218500519738 := by decide
theorem cert_e2422407497530 : check e2422407497530 [[],[]] .chain = true := by decide
def e2422407497614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2422407497614 : Closed e2422407497614 ∧ code e2422407497614 = 11218500519822 := by decide
theorem cert_e2422407497614 : check e2422407497614 [[],[]] .chain = true := by decide
def e2422407497626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407497626 : Closed e2422407497626 ∧ code e2422407497626 = 11218500519834 := by decide
theorem cert_e2422407497626 : check e2422407497626 [[],[]] .chain = true := by decide
def e2422407498582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e2422407498582 : Closed e2422407498582 ∧ code e2422407498582 = 11218500520790 := by decide
theorem cert_e2422407498582 : check e2422407498582 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407498870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422407498870 : Closed e2422407498870 ∧ code e2422407498870 = 11218500521078 := by decide
theorem cert_e2422407498870 : check e2422407498870 [[],[]] .chain = true := by decide
def e2422407498874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e2422407498874 : Closed e2422407498874 ∧ code e2422407498874 = 11218500521082 := by decide
theorem cert_e2422407498874 : check e2422407498874 [[],[]] .chain = true := by decide
def e2422407498966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422407498966 : Closed e2422407498966 ∧ code e2422407498966 = 11218500521174 := by decide
theorem cert_e2422407498966 : check e2422407498966 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407499062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407499062 : Closed e2422407499062 ∧ code e2422407499062 = 11218500521270 := by decide
theorem cert_e2422407499062 : check e2422407499062 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407499066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407499066 : Closed e2422407499066 ∧ code e2422407499066 = 11218500521274 := by decide
theorem cert_e2422407499066 : check e2422407499066 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407499150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422407499150 : Closed e2422407499150 ∧ code e2422407499150 = 11218500521358 := by decide
theorem cert_e2422407499150 : check e2422407499150 [[],[]] .chain = true := by decide
def e2422407499206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2422407499206 : Closed e2422407499206 ∧ code e2422407499206 = 11218500521414 := by decide
theorem cert_e2422407499206 : check e2422407499206 [[],[]] .chain = true := by decide
def e2422407499318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407499318 : Closed e2422407499318 ∧ code e2422407499318 = 11218500521526 := by decide
theorem cert_e2422407499318 : check e2422407499318 [[],[]] .chain = true := by decide
def e2422407499406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407499406 : Closed e2422407499406 ∧ code e2422407499406 = 11218500521614 := by decide
theorem cert_e2422407499406 : check e2422407499406 [[],[]] .chain = true := by decide
def e2422407499490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407499490 : Closed e2422407499490 ∧ code e2422407499490 = 11218500521698 := by decide
theorem cert_e2422407499490 : check e2422407499490 [[],[]] .chain = true := by decide
def e2422407499502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2422407499502 : Closed e2422407499502 ∧ code e2422407499502 = 11218500521710 := by decide
theorem cert_e2422407499502 : check e2422407499502 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left]] .identityHead = true := by decide
def e2422407499510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2422407499510 : Closed e2422407499510 ∧ code e2422407499510 = 11218500521718 := by decide
theorem cert_e2422407499510 : check e2422407499510 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407499542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407499542 : Closed e2422407499542 ∧ code e2422407499542 = 11218500521750 := by decide
theorem cert_e2422407499542 : check e2422407499542 [[],[]] .chain = true := by decide
def e2422407499546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407499546 : Closed e2422407499546 ∧ code e2422407499546 = 11218500521754 := by decide
theorem cert_e2422407499546 : check e2422407499546 [[],[]] .chain = true := by decide
def e2422407499590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407499590 : Closed e2422407499590 ∧ code e2422407499590 = 11218500521798 := by decide
theorem cert_e2422407499590 : check e2422407499590 [[],[]] .chain = true := by decide
def e2422407499618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407499618 : Closed e2422407499618 ∧ code e2422407499618 = 11218500521826 := by decide
theorem cert_e2422407499618 : check e2422407499618 [[],[]] .chain = true := by decide
def e2422407499630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2422407499630 : Closed e2422407499630 ∧ code e2422407499630 = 11218500521838 := by decide
theorem cert_e2422407499630 : checkPay e2422407499630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left]] 0 [] = true := by decide
def e2422407499638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2422407499638 : Closed e2422407499638 ∧ code e2422407499638 = 11218500521846 := by decide
theorem cert_e2422407499638 : check e2422407499638 [[],[]] .chain = true := by decide
def e2422407499642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2422407499642 : Closed e2422407499642 ∧ code e2422407499642 = 11218500521850 := by decide
theorem cert_e2422407499642 : check e2422407499642 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407499702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2422407499702 : Closed e2422407499702 ∧ code e2422407499702 = 11218500521910 := by decide
theorem cert_e2422407499702 : check e2422407499702 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407499706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2422407499706 : Closed e2422407499706 ∧ code e2422407499706 = 11218500521914 := by decide
theorem cert_e2422407499706 : check e2422407499706 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407500014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407500014 : Closed e2422407500014 ∧ code e2422407500014 = 11218500522222 := by decide
theorem cert_e2422407500014 : check e2422407500014 [[],[]] .chain = true := by decide
def e2422407500022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407500022 : Closed e2422407500022 ∧ code e2422407500022 = 11218500522230 := by decide
theorem cert_e2422407500022 : check e2422407500022 [[],[]] .chain = true := by decide
def e2422407500502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407500502 : Closed e2422407500502 ∧ code e2422407500502 = 11218500522710 := by decide
theorem cert_e2422407500502 : check e2422407500502 [[],[]] .chain = true := by decide
def e2422407500506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407500506 : Closed e2422407500506 ∧ code e2422407500506 = 11218500522714 := by decide
theorem cert_e2422407500506 : check e2422407500506 [[],[]] .chain = true := by decide
def e2422407500522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407500522 : Closed e2422407500522 ∧ code e2422407500522 = 11218500522730 := by decide
theorem cert_e2422407500522 : check e2422407500522 [[],[]] .chain = true := by decide
def e2422407500598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407500598 : Closed e2422407500598 ∧ code e2422407500598 = 11218500522806 := by decide
theorem cert_e2422407500598 : check e2422407500598 [[],[]] .chain = true := by decide
def e2422407500602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407500602 : Closed e2422407500602 ∧ code e2422407500602 = 11218500522810 := by decide
theorem cert_e2422407500602 : check e2422407500602 [[],[]] .chain = true := by decide
def e2422407500686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422407500686 : Closed e2422407500686 ∧ code e2422407500686 = 11218500522894 := by decide
theorem cert_e2422407500686 : check e2422407500686 [[],[]] .chain = true := by decide
def e2422407500698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407500698 : Closed e2422407500698 ∧ code e2422407500698 = 11218500522906 := by decide
theorem cert_e2422407500698 : check e2422407500698 [[],[]] .chain = true := by decide
def e2422407501934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422407501934 : Closed e2422407501934 ∧ code e2422407501934 = 11218500524142 := by decide
theorem cert_e2422407501934 : check e2422407501934 [[],[]] .chain = true := by decide
def e2422407501946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422407501946 : Closed e2422407501946 ∧ code e2422407501946 = 11218500524154 := by decide
theorem cert_e2422407501946 : check e2422407501946 [[],[]] .chain = true := by decide
def e2422407502222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407502222 : Closed e2422407502222 ∧ code e2422407502222 = 11218500524430 := by decide
theorem cert_e2422407502222 : check e2422407502222 [[],[]] .chain = true := by decide
def e2422407502278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407502278 : Closed e2422407502278 ∧ code e2422407502278 = 11218500524486 := by decide
theorem cert_e2422407502278 : check e2422407502278 [[],[]] .chain = true := by decide
def e2422407502878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407502878 : Closed e2422407502878 ∧ code e2422407502878 = 11218500525086 := by decide
theorem cert_e2422407502878 : check e2422407502878 [[],[]] .chain = true := by decide
def e2422407502902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407502902 : Closed e2422407502902 ∧ code e2422407502902 = 11218500525110 := by decide
theorem cert_e2422407502902 : check e2422407502902 [[],[]] .chain = true := by decide
def e2422407502906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407502906 : Closed e2422407502906 ∧ code e2422407502906 = 11218500525114 := by decide
theorem cert_e2422407502906 : check e2422407502906 [[],[]] .chain = true := by decide
def e2422407503046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407503046 : Closed e2422407503046 ∧ code e2422407503046 = 11218500525254 := by decide
theorem cert_e2422407503046 : check e2422407503046 [[],[]] .chain = true := by decide
def e2422407503074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407503074 : Closed e2422407503074 ∧ code e2422407503074 = 11218500525282 := by decide
theorem cert_e2422407503074 : check e2422407503074 [[],[]] .chain = true := by decide
def e2422407503086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407503086 : Closed e2422407503086 ∧ code e2422407503086 = 11218500525294 := by decide
theorem cert_e2422407503086 : check e2422407503086 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407503094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407503094 : Closed e2422407503094 ∧ code e2422407503094 = 11218500525302 := by decide
theorem cert_e2422407503094 : check e2422407503094 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407503478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407503478 : Closed e2422407503478 ∧ code e2422407503478 = 11218500525686 := by decide
theorem cert_e2422407503478 : check e2422407503478 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407507030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2422407507030 : Closed e2422407507030 ∧ code e2422407507030 = 11218500529238 := by decide
theorem cert_e2422407507030 : check e2422407507030 [[],[]] .chain = true := by decide
def e2422407507034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2422407507034 : Closed e2422407507034 ∧ code e2422407507034 = 11218500529242 := by decide
theorem cert_e2422407507034 : check e2422407507034 [[],[]] .chain = true := by decide
def e2422407507222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407507222 : Closed e2422407507222 ∧ code e2422407507222 = 11218500529430 := by decide
theorem cert_e2422407507222 : check e2422407507222 [[],[]] .chain = true := by decide
def e2422407507298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407507298 : Closed e2422407507298 ∧ code e2422407507298 = 11218500529506 := by decide
theorem cert_e2422407507298 : check e2422407507298 [[],[]] .chain = true := by decide
def e2422407507310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422407507310 : Closed e2422407507310 ∧ code e2422407507310 = 11218500529518 := by decide
def e2422407507318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422407507318 : Closed e2422407507318 ∧ code e2422407507318 = 11218500529526 := by decide
theorem cert_e2422407507318 : check e2422407507318 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407507338 : Closed e2422407507338 ∧ code e2422407507338 = 11218500529546 := by decide
theorem cert_e2422407507338 : check e2422407507338 [[],[]] .chain = true := by decide
def e2422407507362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407507362 : Closed e2422407507362 ∧ code e2422407507362 = 11218500529570 := by decide
theorem cert_e2422407507362 : check e2422407507362 [[],[]] .chain = true := by decide
def e2422407507374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422407507374 : Closed e2422407507374 ∧ code e2422407507374 = 11218500529582 := by decide
def e2422407507382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2422407507382 : Closed e2422407507382 ∧ code e2422407507382 = 11218500529590 := by decide
theorem cert_e2422407507382 : check e2422407507382 [[],[]] .chain = true := by decide
def e2422407507386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422407507386 : Closed e2422407507386 ∧ code e2422407507386 = 11218500529594 := by decide
theorem cert_e2422407507386 : check e2422407507386 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422407507414 : Closed e2422407507414 ∧ code e2422407507414 = 11218500529622 := by decide
theorem cert_e2422407507414 : check e2422407507414 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422407507418 : Closed e2422407507418 ∧ code e2422407507418 = 11218500529626 := by decide
theorem cert_e2422407507418 : check e2422407507418 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422407507498 : Closed e2422407507498 ∧ code e2422407507498 = 11218500529706 := by decide
theorem cert_e2422407507498 : check e2422407507498 [[],[]] .chain = true := by decide
def e2422407507594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407507594 : Closed e2422407507594 ∧ code e2422407507594 = 11218500529802 := by decide
theorem cert_e2422407507594 : check e2422407507594 [[],[]] .chain = true := by decide
def e2422407507618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407507618 : Closed e2422407507618 ∧ code e2422407507618 = 11218500529826 := by decide
theorem cert_e2422407507618 : check e2422407507618 [[],[]] .chain = true := by decide
def e2422407507630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407507630 : Closed e2422407507630 ∧ code e2422407507630 = 11218500529838 := by decide
def e2422407507638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422407507638 : Closed e2422407507638 ∧ code e2422407507638 = 11218500529846 := by decide
theorem cert_e2422407507638 : check e2422407507638 [[],[]] .chain = true := by decide
def e2422407507642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407507642 : Closed e2422407507642 ∧ code e2422407507642 = 11218500529850 := by decide
theorem cert_e2422407507642 : check e2422407507642 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422407507670 : Closed e2422407507670 ∧ code e2422407507670 = 11218500529878 := by decide
theorem cert_e2422407507670 : check e2422407507670 [[],[]] .chain = true := by decide
def e2422407507674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422407507674 : Closed e2422407507674 ∧ code e2422407507674 = 11218500529882 := by decide
theorem cert_e2422407507674 : check e2422407507674 [[],[]] .chain = true := by decide
def e2422407507690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407507690 : Closed e2422407507690 ∧ code e2422407507690 = 11218500529898 := by decide
theorem cert_e2422407507690 : check e2422407507690 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422407507798 : Closed e2422407507798 ∧ code e2422407507798 = 11218500530006 := by decide
theorem cert_e2422407507798 : check e2422407507798 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422407507802 : Closed e2422407507802 ∧ code e2422407507802 = 11218500530010 := by decide
theorem cert_e2422407507802 : check e2422407507802 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422407507818 : Closed e2422407507818 ∧ code e2422407507818 = 11218500530026 := by decide
theorem cert_e2422407507818 : check e2422407507818 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407507990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422407507990 : Closed e2422407507990 ∧ code e2422407507990 = 11218500530198 := by decide
theorem cert_e2422407507990 : check e2422407507990 [[],[]] .chain = true := by decide
def e2422407508086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422407508086 : Closed e2422407508086 ∧ code e2422407508086 = 11218500530294 := by decide
theorem cert_e2422407508086 : check e2422407508086 [[],[]] .chain = true := by decide
def e2422407508090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2422407508090 : Closed e2422407508090 ∧ code e2422407508090 = 11218500530298 := by decide
theorem cert_e2422407508090 : check e2422407508090 [[],[]] .chain = true := by decide
def e2422407508182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422407508182 : Closed e2422407508182 ∧ code e2422407508182 = 11218500530390 := by decide
theorem cert_e2422407508182 : check e2422407508182 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407508278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407508278 : Closed e2422407508278 ∧ code e2422407508278 = 11218500530486 := by decide
theorem cert_e2422407508278 : check e2422407508278 [[],[]] .chain = true := by decide
def e2422407508282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407508282 : Closed e2422407508282 ∧ code e2422407508282 = 11218500530490 := by decide
theorem cert_e2422407508282 : check e2422407508282 [[],[]] .chain = true := by decide
def e2422407508366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422407508366 : Closed e2422407508366 ∧ code e2422407508366 = 11218500530574 := by decide
theorem cert_e2422407508366 : check e2422407508366 [[],[]] .chain = true := by decide
def e2422407508422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2422407508422 : Closed e2422407508422 ∧ code e2422407508422 = 11218500530630 := by decide
theorem cert_e2422407508422 : check e2422407508422 [[],[]] .chain = true := by decide
def e2422407508758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407508758 : Closed e2422407508758 ∧ code e2422407508758 = 11218500530966 := by decide
theorem cert_e2422407508758 : check e2422407508758 [[],[]] .chain = true := by decide
def e2422407508834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407508834 : Closed e2422407508834 ∧ code e2422407508834 = 11218500531042 := by decide
theorem cert_e2422407508834 : check e2422407508834 [[],[]] .chain = true := by decide
end Blc.Floor43
