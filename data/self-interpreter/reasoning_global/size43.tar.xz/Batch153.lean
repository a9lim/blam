import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259546261018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259546261018 : Closed e2259546261018 ∧ code e2259546261018 = 11055639283226 := by decide
theorem cert_e2259546261018 : check e2259546261018 [[]] .width = true := by decide
def e2259546263750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259546263750 : Closed e2259546263750 ∧ code e2259546263750 = 11055639285958 := by decide
theorem cert_e2259546263750 : check e2259546263750 [[]] .width = true := by decide
def e2259546276038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259546276038 : Closed e2259546276038 ∧ code e2259546276038 = 11055639298246 := by decide
theorem cert_e2259546276038 : check e2259546276038 [[]] .width = true := by decide
def e2259546276566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259546276566 : Closed e2259546276566 ∧ code e2259546276566 = 11055639298774 := by decide
theorem cert_e2259546276566 : check e2259546276566 [[]] .width = true := by decide
def e2259546276570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259546276570 : Closed e2259546276570 ∧ code e2259546276570 = 11055639298778 := by decide
theorem cert_e2259546276570 : check e2259546276570 [[]] .width = true := by decide
def e2259546276586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259546276586 : Closed e2259546276586 ∧ code e2259546276586 = 11055639298794 := by decide
theorem cert_e2259546276586 : check e2259546276586 [[]] .width = true := by decide
def e2259546276662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259546276662 : Closed e2259546276662 ∧ code e2259546276662 = 11055639298870 := by decide
theorem cert_e2259546276662 : check e2259546276662 [[]] .width = true := by decide
def e2259546276666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259546276666 : Closed e2259546276666 ∧ code e2259546276666 = 11055639298874 := by decide
theorem cert_e2259546276666 : check e2259546276666 [[]] .width = true := by decide
def e2259546276750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259546276750 : Closed e2259546276750 ∧ code e2259546276750 = 11055639298958 := by decide
theorem cert_e2259546276750 : check e2259546276750 [[]] .width = true := by decide
def e2259546276762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259546276762 : Closed e2259546276762 ∧ code e2259546276762 = 11055639298970 := by decide
theorem cert_e2259546276762 : check e2259546276762 [[]] .width = true := by decide
def e2259546278682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259546278682 : Closed e2259546278682 ∧ code e2259546278682 = 11055639300890 := by decide
theorem cert_e2259546278682 : check e2259546278682 [[]] .width = true := by decide
def e2259546278726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259546278726 : Closed e2259546278726 ∧ code e2259546278726 = 11055639300934 := by decide
theorem cert_e2259546278726 : check e2259546278726 [[]] .width = true := by decide
def e2259546278838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259546278838 : Closed e2259546278838 ∧ code e2259546278838 = 11055639301046 := by decide
theorem cert_e2259546278838 : check e2259546278838 [[]] .width = true := by decide
def e2259546278966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259546278966 : Closed e2259546278966 ∧ code e2259546278966 = 11055639301174 := by decide
theorem cert_e2259546278966 : check e2259546278966 [[]] .width = true := by decide
def e2259546278970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259546278970 : Closed e2259546278970 ∧ code e2259546278970 = 11055639301178 := by decide
theorem cert_e2259546278970 : check e2259546278970 [[]] .width = true := by decide
def e2259546279110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259546279110 : Closed e2259546279110 ∧ code e2259546279110 = 11055639301318 := by decide
theorem cert_e2259546279110 : check e2259546279110 [[]] .width = true := by decide
def e2259546279450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259546279450 : Closed e2259546279450 ∧ code e2259546279450 = 11055639301658 := by decide
theorem cert_e2259546279450 : check e2259546279450 [[]] .width = true := by decide
def e2259546279542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259546279542 : Closed e2259546279542 ∧ code e2259546279542 = 11055639301750 := by decide
theorem cert_e2259546279542 : check e2259546279542 [[]] .width = true := by decide
def e2259546287130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259546287130 : Closed e2259546287130 ∧ code e2259546287130 = 11055639309338 := by decide
theorem cert_e2259546287130 : check e2259546287130 [[]] .width = true := by decide
def e2259546287174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259546287174 : Closed e2259546287174 ∧ code e2259546287174 = 11055639309382 := by decide
theorem cert_e2259546287174 : check e2259546287174 [[]] .width = true := by decide
def e2259546287202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259546287202 : Closed e2259546287202 ∧ code e2259546287202 = 11055639309410 := by decide
theorem cert_e2259546287202 : check e2259546287202 [[]] .width = true := by decide
def e2259546287366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259546287366 : Closed e2259546287366 ∧ code e2259546287366 = 11055639309574 := by decide
theorem cert_e2259546287366 : check e2259546287366 [[]] .width = true := by decide
def e2259546288158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259546288158 : Closed e2259546288158 ∧ code e2259546288158 = 11055639310366 := by decide
theorem cert_e2259546288158 : check e2259546288158 [[]] .width = true := by decide
def e2259546288326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259546288326 : Closed e2259546288326 ∧ code e2259546288326 = 11055639310534 := by decide
theorem cert_e2259546288326 : check e2259546288326 [[]] .width = true := by decide
def e2259546288354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259546288354 : Closed e2259546288354 ∧ code e2259546288354 = 11055639310562 := by decide
theorem cert_e2259546288354 : check e2259546288354 [[]] .width = true := by decide
def e2259546288902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259546288902 : Closed e2259546288902 ∧ code e2259546288902 = 11055639311110 := by decide
theorem cert_e2259546288902 : check e2259546288902 [[]] .width = true := by decide
def e2259547304134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259547304134 : Closed e2259547304134 ∧ code e2259547304134 = 11055640326342 := by decide
theorem cert_e2259547304134 : check e2259547304134 [[]] .width = true := by decide
def e2259547312326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259547312326 : Closed e2259547312326 ∧ code e2259547312326 = 11055640334534 := by decide
theorem cert_e2259547312326 : check e2259547312326 [[]] .width = true := by decide
def e2259547697350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259547697350 : Closed e2259547697350 ∧ code e2259547697350 = 11055640719558 := by decide
theorem cert_e2259547697350 : check e2259547697350 [[]] .width = true := by decide
def e2259547705542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259547705542 : Closed e2259547705542 ∧ code e2259547705542 = 11055640727750 := by decide
theorem cert_e2259547705542 : check e2259547705542 [[]] .width = true := by decide
def e2259547877574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259547877574 : Closed e2259547877574 ∧ code e2259547877574 = 11055640899782 := by decide
theorem cert_e2259547877574 : check e2259547877574 [[]] .width = true := by decide
def e2259547909658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259547909658 : Closed e2259547909658 ∧ code e2259547909658 = 11055640931866 := by decide
theorem cert_e2259547909658 : check e2259547909658 [[]] .width = true := by decide
def e2259547911706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259547911706 : Closed e2259547911706 ∧ code e2259547911706 = 11055640933914 := by decide
theorem cert_e2259547911706 : check e2259547911706 [[]] .width = true := by decide
def e2259547947034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259547947034 : Closed e2259547947034 ∧ code e2259547947034 = 11055640969242 := by decide
theorem cert_e2259547947034 : check e2259547947034 [[]] .width = true := by decide
def e2259547947126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259547947126 : Closed e2259547947126 ∧ code e2259547947126 = 11055640969334 := by decide
theorem cert_e2259547947126 : check e2259547947126 [[]] .width = true := by decide
def e2259547947370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259547947370 : Closed e2259547947370 ∧ code e2259547947370 = 11055640969578 := by decide
theorem cert_e2259547947370 : check e2259547947370 [[]] .width = true := by decide
def e2259547947418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259547947418 : Closed e2259547947418 ∧ code e2259547947418 = 11055640969626 := by decide
theorem cert_e2259547947418 : check e2259547947418 [[]] .width = true := by decide
def e2259547948426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259547948426 : Closed e2259547948426 ∧ code e2259547948426 = 11055640970634 := by decide
theorem cert_e2259547948426 : check e2259547948426 [[]] .width = true := by decide
def e2259547948450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259547948450 : Closed e2259547948450 ∧ code e2259547948450 = 11055640970658 := by decide
theorem cert_e2259547948450 : check e2259547948450 [[]] .width = true := by decide
def e2259547948558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259547948558 : Closed e2259547948558 ∧ code e2259547948558 = 11055640970766 := by decide
theorem cert_e2259547948558 : check e2259547948558 [[]] .width = true := by decide
def e2259547948570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259547948570 : Closed e2259547948570 ∧ code e2259547948570 = 11055640970778 := by decide
theorem cert_e2259547948570 : check e2259547948570 [[]] .width = true := by decide
def e2259547948642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259547948642 : Closed e2259547948642 ∧ code e2259547948642 = 11055640970850 := by decide
theorem cert_e2259547948642 : check e2259547948642 [[]] .width = true := by decide
def e2259547992262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259547992262 : Closed e2259547992262 ∧ code e2259547992262 = 11055641014470 := by decide
theorem cert_e2259547992262 : check e2259547992262 [[]] .width = true := by decide
def e2259548007962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548007962 : Closed e2259548007962 ∧ code e2259548007962 = 11055641030170 := by decide
theorem cert_e2259548007962 : check e2259548007962 [[]] .width = true := by decide
def e2259548011034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548011034 : Closed e2259548011034 ∧ code e2259548011034 = 11055641033242 := by decide
theorem cert_e2259548011034 : check e2259548011034 [[]] .width = true := by decide
def e2259548012570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259548012570 : Closed e2259548012570 ∧ code e2259548012570 = 11055641034778 := by decide
theorem cert_e2259548012570 : check e2259548012570 [[]] .width = true := by decide
def e2259548012662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259548012662 : Closed e2259548012662 ∧ code e2259548012662 = 11055641034870 := by decide
theorem cert_e2259548012662 : check e2259548012662 [[]] .width = true := by decide
def e2259548012906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259548012906 : Closed e2259548012906 ∧ code e2259548012906 = 11055641035114 := by decide
theorem cert_e2259548012906 : check e2259548012906 [[]] .width = true := by decide
def e2259548012954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259548012954 : Closed e2259548012954 ∧ code e2259548012954 = 11055641035162 := by decide
theorem cert_e2259548012954 : check e2259548012954 [[]] .width = true := by decide
def e2259548013962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259548013962 : Closed e2259548013962 ∧ code e2259548013962 = 11055641036170 := by decide
theorem cert_e2259548013962 : check e2259548013962 [[]] .width = true := by decide
def e2259548013986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259548013986 : Closed e2259548013986 ∧ code e2259548013986 = 11055641036194 := by decide
theorem cert_e2259548013986 : check e2259548013986 [[]] .width = true := by decide
def e2259548014094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259548014094 : Closed e2259548014094 ∧ code e2259548014094 = 11055641036302 := by decide
theorem cert_e2259548014094 : check e2259548014094 [[]] .width = true := by decide
def e2259548014106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259548014106 : Closed e2259548014106 ∧ code e2259548014106 = 11055641036314 := by decide
theorem cert_e2259548014106 : check e2259548014106 [[]] .width = true := by decide
def e2259548014178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259548014178 : Closed e2259548014178 ∧ code e2259548014178 = 11055641036386 := by decide
theorem cert_e2259548014178 : check e2259548014178 [[]] .width = true := by decide
def e2259548059162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548059162 : Closed e2259548059162 ∧ code e2259548059162 = 11055641081370 := by decide
theorem cert_e2259548059162 : check e2259548059162 [[]] .width = true := by decide
def e2259548060186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548060186 : Closed e2259548060186 ∧ code e2259548060186 = 11055641082394 := by decide
theorem cert_e2259548060186 : check e2259548060186 [[]] .width = true := by decide
def e2259548680390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259548680390 : Closed e2259548680390 ∧ code e2259548680390 = 11055641702598 := by decide
theorem cert_e2259548680390 : check e2259548680390 [[]] .width = true := by decide
def e2259548696090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548696090 : Closed e2259548696090 ∧ code e2259548696090 = 11055641718298 := by decide
theorem cert_e2259548696090 : check e2259548696090 [[]] .width = true := by decide
def e2259548698138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548698138 : Closed e2259548698138 ∧ code e2259548698138 = 11055641720346 := by decide
theorem cert_e2259548698138 : check e2259548698138 [[]] .width = true := by decide
def e2259548815558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259548815558 : Closed e2259548815558 ∧ code e2259548815558 = 11055641837766 := by decide
theorem cert_e2259548815558 : check e2259548815558 [[]] .width = true := by decide
def e2259548836038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259548836038 : Closed e2259548836038 ∧ code e2259548836038 = 11055641858246 := by decide
theorem cert_e2259548836038 : check e2259548836038 [[]] .width = true := by decide
def e2259548839450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548839450 : Closed e2259548839450 ∧ code e2259548839450 = 11055641861658 := by decide
theorem cert_e2259548839450 : check e2259548839450 [[]] .width = true := by decide
def e2259548848326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259548848326 : Closed e2259548848326 ∧ code e2259548848326 = 11055641870534 := by decide
theorem cert_e2259548848326 : check e2259548848326 [[]] .width = true := by decide
def e2259548856346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259548856346 : Closed e2259548856346 ∧ code e2259548856346 = 11055641878554 := by decide
theorem cert_e2259548856346 : check e2259548856346 [[]] .width = true := by decide
def e2259548856438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259548856438 : Closed e2259548856438 ∧ code e2259548856438 = 11055641878646 := by decide
theorem cert_e2259548856438 : check e2259548856438 [[]] .width = true := by decide
def e2259548856682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259548856682 : Closed e2259548856682 ∧ code e2259548856682 = 11055641878890 := by decide
theorem cert_e2259548856682 : check e2259548856682 [[]] .width = true := by decide
def e2259548856730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259548856730 : Closed e2259548856730 ∧ code e2259548856730 = 11055641878938 := by decide
theorem cert_e2259548856730 : check e2259548856730 [[]] .width = true := by decide
def e2259548860614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259548860614 : Closed e2259548860614 ∧ code e2259548860614 = 11055641882822 := by decide
theorem cert_e2259548860614 : check e2259548860614 [[]] .width = true := by decide
def e2259548868122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548868122 : Closed e2259548868122 ∧ code e2259548868122 = 11055641890330 := by decide
private def t_e2259548868122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259548868122 : ¬ IsSelfInterpreter e2259548868122 :=
  wSource (t := t_e2259548868122) (replay_sound (ps := []) (t := e2259548868122) (by decide)) (by decide)
def e2259548876998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259548876998 : Closed e2259548876998 ∧ code e2259548876998 = 11055641899206 := by decide
theorem cert_e2259548876998 : check e2259548876998 [[]] .width = true := by decide
def e2259548917958 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259548917958 : Closed e2259548917958 ∧ code e2259548917958 = 11055641940166 := by decide
theorem cert_e2259548917958 : check e2259548917958 [[]] .width = true := by decide
def e2259548925466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548925466 : Closed e2259548925466 ∧ code e2259548925466 = 11055641947674 := by decide
theorem cert_e2259548925466 : check e2259548925466 [[]] .width = true := by decide
def e2259548928538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548928538 : Closed e2259548928538 ∧ code e2259548928538 = 11055641950746 := by decide
theorem cert_e2259548928538 : check e2259548928538 [[]] .width = true := by decide
def e2259548967110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259548967110 : Closed e2259548967110 ∧ code e2259548967110 = 11055641989318 := by decide
theorem cert_e2259548967110 : check e2259548967110 [[]] .width = true := by decide
def e2259548970522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259548970522 : Closed e2259548970522 ∧ code e2259548970522 = 11055641992730 := by decide
theorem cert_e2259548970522 : check e2259548970522 [[]] .width = true := by decide
def e2259548979398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259548979398 : Closed e2259548979398 ∧ code e2259548979398 = 11055642001606 := by decide
theorem cert_e2259548979398 : check e2259548979398 [[]] .width = true := by decide
def e2259548987418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259548987418 : Closed e2259548987418 ∧ code e2259548987418 = 11055642009626 := by decide
theorem cert_e2259548987418 : check e2259548987418 [[]] .width = true := by decide
def e2259548987510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259548987510 : Closed e2259548987510 ∧ code e2259548987510 = 11055642009718 := by decide
theorem cert_e2259548987510 : check e2259548987510 [[]] .width = true := by decide
def e2259548987754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259548987754 : Closed e2259548987754 ∧ code e2259548987754 = 11055642009962 := by decide
theorem cert_e2259548987754 : check e2259548987754 [[]] .width = true := by decide
def e2259548987802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259548987802 : Closed e2259548987802 ∧ code e2259548987802 = 11055642010010 := by decide
theorem cert_e2259548987802 : check e2259548987802 [[]] .width = true := by decide
def e2259548991686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259548991686 : Closed e2259548991686 ∧ code e2259548991686 = 11055642013894 := by decide
theorem cert_e2259548991686 : check e2259548991686 [[]] .width = true := by decide
def e2259549003802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259549003802 : Closed e2259549003802 ∧ code e2259549003802 = 11055642026010 := by decide
theorem cert_e2259549003802 : check e2259549003802 [[]] .width = true := by decide
def e2259549003894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259549003894 : Closed e2259549003894 ∧ code e2259549003894 = 11055642026102 := by decide
theorem cert_e2259549003894 : check e2259549003894 [[]] .width = true := by decide
def e2259549004138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259549004138 : Closed e2259549004138 ∧ code e2259549004138 = 11055642026346 := by decide
theorem cert_e2259549004138 : check e2259549004138 [[]] .width = true := by decide
def e2259549004186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259549004186 : Closed e2259549004186 ∧ code e2259549004186 = 11055642026394 := by decide
theorem cert_e2259549004186 : check e2259549004186 [[]] .width = true := by decide
def e2259549013530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259549013530 : Closed e2259549013530 ∧ code e2259549013530 = 11055642035738 := by decide
theorem cert_e2259549013530 : check e2259549013530 [[]] .width = true := by decide
def e2259549016262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259549016262 : Closed e2259549016262 ∧ code e2259549016262 = 11055642038470 := by decide
theorem cert_e2259549016262 : check e2259549016262 [[]] .width = true := by decide
def e2259549042202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259549042202 : Closed e2259549042202 ∧ code e2259549042202 = 11055642064410 := by decide
theorem cert_e2259549042202 : check e2259549042202 [[]] .width = true := by decide
def e2259549043226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259549043226 : Closed e2259549043226 ∧ code e2259549043226 = 11055642065434 := by decide
theorem cert_e2259549043226 : check e2259549043226 [[]] .width = true := by decide
def e2259549064730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259549064730 : Closed e2259549064730 ∧ code e2259549064730 = 11055642086938 := by decide
private def t_e2259549064730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259549064730 : ¬ IsSelfInterpreter e2259549064730 :=
  wSource (t := t_e2259549064730) (replay_sound (ps := []) (t := e2259549064730) (by decide)) (by decide)
def e2259549073606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259549073606 : Closed e2259549073606 ∧ code e2259549073606 = 11055642095814 := by decide
theorem cert_e2259549073606 : check e2259549073606 [[]] .width = true := by decide
def e2259549079066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259549079066 : Closed e2259549079066 ∧ code e2259549079066 = 11055642101274 := by decide
theorem cert_e2259549079066 : check e2259549079066 [[]] .width = true := by decide
def e2259549081798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259549081798 : Closed e2259549081798 ∧ code e2259549081798 = 11055642104006 := by decide
theorem cert_e2259549081798 : check e2259549081798 [[]] .width = true := by decide
def e2259549221062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259549221062 : Closed e2259549221062 ∧ code e2259549221062 = 11055642243270 := by decide
theorem cert_e2259549221062 : check e2259549221062 [[]] .width = true := by decide
def e2259549388826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259549388826 : Closed e2259549388826 ∧ code e2259549388826 = 11055642411034 := by decide
theorem cert_e2259549388826 : check e2259549388826 [[]] .width = true := by decide
def e2259549388918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259549388918 : Closed e2259549388918 ∧ code e2259549388918 = 11055642411126 := by decide
theorem cert_e2259549388918 : check e2259549388918 [[]] .width = true := by decide
def e2259549389162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259549389162 : Closed e2259549389162 ∧ code e2259549389162 = 11055642411370 := by decide
theorem cert_e2259549389162 : check e2259549389162 [[]] .width = true := by decide
def e2259549389210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259549389210 : Closed e2259549389210 ∧ code e2259549389210 = 11055642411418 := by decide
theorem cert_e2259549389210 : check e2259549389210 [[]] .width = true := by decide
def e2259549390218 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259549390218 : Closed e2259549390218 ∧ code e2259549390218 = 11055642412426 := by decide
theorem cert_e2259549390218 : check e2259549390218 [[]] .width = true := by decide
def e2259549390242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259549390242 : Closed e2259549390242 ∧ code e2259549390242 = 11055642412450 := by decide
private def t_e2259549390242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2259549390242 : ¬ IsSelfInterpreter e2259549390242 :=
  wSource (t := t_e2259549390242) (replay_sound (ps := []) (t := e2259549390242) (by decide)) (by decide)
def e2259549390350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259549390350 : Closed e2259549390350 ∧ code e2259549390350 = 11055642412558 := by decide
theorem cert_e2259549390350 : check e2259549390350 [[]] .width = true := by decide
def e2259549390362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259549390362 : Closed e2259549390362 ∧ code e2259549390362 = 11055642412570 := by decide
private def t_e2259549390362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2259549390362 : ¬ IsSelfInterpreter e2259549390362 :=
  wSource (t := t_e2259549390362) (replay_sound (ps := []) (t := e2259549390362) (by decide)) (by decide)
def e2259549390434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259549390434 : Closed e2259549390434 ∧ code e2259549390434 = 11055642412642 := by decide
theorem cert_e2259549390434 : check e2259549390434 [[]] .width = true := by decide
def e2259549601990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259549601990 : Closed e2259549601990 ∧ code e2259549601990 = 11055642624198 := by decide
theorem cert_e2259549601990 : check e2259549601990 [[]] .width = true := by decide
def e2259549622470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259549622470 : Closed e2259549622470 ∧ code e2259549622470 = 11055642644678 := by decide
theorem cert_e2259549622470 : check e2259549622470 [[]] .width = true := by decide
def e2259549625882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259549625882 : Closed e2259549625882 ∧ code e2259549625882 = 11055642648090 := by decide
private def t_e2259549625882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259549625882 : ¬ IsSelfInterpreter e2259549625882 :=
  wSource (t := t_e2259549625882) (replay_sound (ps := []) (t := e2259549625882) (by decide)) (by decide)
def e2259549634758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259549634758 : Closed e2259549634758 ∧ code e2259549634758 = 11055642656966 := by decide
theorem cert_e2259549634758 : check e2259549634758 [[]] .width = true := by decide
def e2259549642778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259549642778 : Closed e2259549642778 ∧ code e2259549642778 = 11055642664986 := by decide
theorem cert_e2259549642778 : check e2259549642778 [[]] .width = true := by decide
def e2259549642870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259549642870 : Closed e2259549642870 ∧ code e2259549642870 = 11055642665078 := by decide
private def t_e2259549642870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2259549642870 : ¬ IsSelfInterpreter e2259549642870 :=
  wSource (t := t_e2259549642870) (replay_sound (ps := []) (t := e2259549642870) (by decide)) (by decide)
def e2259549643114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259549643114 : Closed e2259549643114 ∧ code e2259549643114 = 11055642665322 := by decide
private def t_e2259549643114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2259549643114 : ¬ IsSelfInterpreter e2259549643114 :=
  wSource (t := t_e2259549643114) (replay_sound (ps := []) (t := e2259549643114) (by decide)) (by decide)
def e2259549643162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259549643162 : Closed e2259549643162 ∧ code e2259549643162 = 11055642665370 := by decide
private def t_e2259549643162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2259549643162 : ¬ IsSelfInterpreter e2259549643162 :=
  wSource (t := t_e2259549643162) (replay_sound (ps := []) (t := e2259549643162) (by decide)) (by decide)
def e2259549647046 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259549647046 : Closed e2259549647046 ∧ code e2259549647046 = 11055642669254 := by decide
theorem cert_e2259549647046 : check e2259549647046 [[]] .width = true := by decide
def e2259549654554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259549654554 : Closed e2259549654554 ∧ code e2259549654554 = 11055642676762 := by decide
private def t_e2259549654554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259549654554 : ¬ IsSelfInterpreter e2259549654554 :=
  wSource (t := t_e2259549654554) (replay_sound (ps := []) (t := e2259549654554) (by decide)) (by decide)
def e2259549663430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259549663430 : Closed e2259549663430 ∧ code e2259549663430 = 11055642685638 := by decide
theorem cert_e2259549663430 : check e2259549663430 [[]] .width = true := by decide
def e2259549946054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259549946054 : Closed e2259549946054 ∧ code e2259549946054 = 11055642968262 := by decide
theorem cert_e2259549946054 : check e2259549946054 [[]] .width = true := by decide
def e2259549946582 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259549946582 : Closed e2259549946582 ∧ code e2259549946582 = 11055642968790 := by decide
theorem cert_e2259549946582 : check e2259549946582 [[]] .width = true := by decide
def e2259549946586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259549946586 : Closed e2259549946586 ∧ code e2259549946586 = 11055642968794 := by decide
theorem cert_e2259549946586 : check e2259549946586 [[]] .width = true := by decide
def e2259549946602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259549946602 : Closed e2259549946602 ∧ code e2259549946602 = 11055642968810 := by decide
theorem cert_e2259549946602 : check e2259549946602 [[]] .width = true := by decide
def e2259549946678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259549946678 : Closed e2259549946678 ∧ code e2259549946678 = 11055642968886 := by decide
theorem cert_e2259549946678 : check e2259549946678 [[]] .width = true := by decide
def e2259549946682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259549946682 : Closed e2259549946682 ∧ code e2259549946682 = 11055642968890 := by decide
theorem cert_e2259549946682 : check e2259549946682 [[]] .width = true := by decide
def e2259549946766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259549946766 : Closed e2259549946766 ∧ code e2259549946766 = 11055642968974 := by decide
theorem cert_e2259549946766 : check e2259549946766 [[]] .width = true := by decide
def e2259549946778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259549946778 : Closed e2259549946778 ∧ code e2259549946778 = 11055642968986 := by decide
theorem cert_e2259549946778 : check e2259549946778 [[]] .width = true := by decide
def e2259549948698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259549948698 : Closed e2259549948698 ∧ code e2259549948698 = 11055642970906 := by decide
theorem cert_e2259549948698 : check e2259549948698 [[]] .width = true := by decide
def e2259549948742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259549948742 : Closed e2259549948742 ∧ code e2259549948742 = 11055642970950 := by decide
theorem cert_e2259549948742 : check e2259549948742 [[]] .width = true := by decide
def e2259549948854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259549948854 : Closed e2259549948854 ∧ code e2259549948854 = 11055642971062 := by decide
private def t_e2259549948854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem cert_e2259549948854 : ¬ IsSelfInterpreter e2259549948854 :=
  wSource (t := t_e2259549948854) (replay_sound (ps := []) (t := e2259549948854) (by decide)) (by decide)
def e2259549948982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259549948982 : Closed e2259549948982 ∧ code e2259549948982 = 11055642971190 := by decide
theorem cert_e2259549948982 : check e2259549948982 [[]] .width = true := by decide
def e2259549948986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259549948986 : Closed e2259549948986 ∧ code e2259549948986 = 11055642971194 := by decide
theorem cert_e2259549948986 : check e2259549948986 [[]] .width = true := by decide
def e2259549949126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259549949126 : Closed e2259549949126 ∧ code e2259549949126 = 11055642971334 := by decide
theorem cert_e2259549949126 : check e2259549949126 [[]] .width = true := by decide
def e2259549949466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259549949466 : Closed e2259549949466 ∧ code e2259549949466 = 11055642971674 := by decide
private def t_e2259549949466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem cert_e2259549949466 : ¬ IsSelfInterpreter e2259549949466 :=
  wSource (t := t_e2259549949466) (replay_sound (ps := []) (t := e2259549949466) (by decide)) (by decide)
def e2259549949558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259549949558 : Closed e2259549949558 ∧ code e2259549949558 = 11055642971766 := by decide
private def t_e2259549949558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem cert_e2259549949558 : ¬ IsSelfInterpreter e2259549949558 :=
  wSource (t := t_e2259549949558) (replay_sound (ps := []) (t := e2259549949558) (by decide)) (by decide)
def e2259549957146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259549957146 : Closed e2259549957146 ∧ code e2259549957146 = 11055642979354 := by decide
theorem cert_e2259549957146 : check e2259549957146 [[]] .width = true := by decide
def e2259549957190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259549957190 : Closed e2259549957190 ∧ code e2259549957190 = 11055642979398 := by decide
theorem cert_e2259549957190 : check e2259549957190 [[]] .width = true := by decide
def e2259549957218 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259549957218 : Closed e2259549957218 ∧ code e2259549957218 = 11055642979426 := by decide
theorem cert_e2259549957218 : check e2259549957218 [[]] .width = true := by decide
def e2259549957382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259549957382 : Closed e2259549957382 ∧ code e2259549957382 = 11055642979590 := by decide
private def t_e2259549957382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem cert_e2259549957382 : ¬ IsSelfInterpreter e2259549957382 :=
  wSource (t := t_e2259549957382) (replay_sound (ps := []) (t := e2259549957382) (by decide)) (by decide)
def e2259549958174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259549958174 : Closed e2259549958174 ∧ code e2259549958174 = 11055642980382 := by decide
theorem cert_e2259549958174 : check e2259549958174 [[]] .width = true := by decide
def e2259549958342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259549958342 : Closed e2259549958342 ∧ code e2259549958342 = 11055642980550 := by decide
theorem cert_e2259549958342 : check e2259549958342 [[]] .width = true := by decide
def e2259549958370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259549958370 : Closed e2259549958370 ∧ code e2259549958370 = 11055642980578 := by decide
theorem cert_e2259549958370 : check e2259549958370 [[]] .width = true := by decide
def e2259549958918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259549958918 : Closed e2259549958918 ∧ code e2259549958918 = 11055642981126 := by decide
theorem cert_e2259549958918 : check e2259549958918 [[]] .width = true := by decide
def e2259550236870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259550236870 : Closed e2259550236870 ∧ code e2259550236870 = 11055643259078 := by decide
theorem cert_e2259550236870 : check e2259550236870 [[]] .width = true := by decide
def e2259550306330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259550306330 : Closed e2259550306330 ∧ code e2259550306330 = 11055643328538 := by decide
theorem cert_e2259550306330 : check e2259550306330 [[]] .width = true := by decide
def e2259550306422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259550306422 : Closed e2259550306422 ∧ code e2259550306422 = 11055643328630 := by decide
theorem cert_e2259550306422 : check e2259550306422 [[]] .width = true := by decide
def e2259550306666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259550306666 : Closed e2259550306666 ∧ code e2259550306666 = 11055643328874 := by decide
theorem cert_e2259550306666 : check e2259550306666 [[]] .width = true := by decide
def e2259550306714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259550306714 : Closed e2259550306714 ∧ code e2259550306714 = 11055643328922 := by decide
theorem cert_e2259550306714 : check e2259550306714 [[]] .width = true := by decide
def e2259550307722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259550307722 : Closed e2259550307722 ∧ code e2259550307722 = 11055643329930 := by decide
theorem cert_e2259550307722 : check e2259550307722 [[]] .width = true := by decide
def e2259550307746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259550307746 : Closed e2259550307746 ∧ code e2259550307746 = 11055643329954 := by decide
theorem cert_e2259550307746 : check e2259550307746 [[]] .width = true := by decide
def e2259550307854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259550307854 : Closed e2259550307854 ∧ code e2259550307854 = 11055643330062 := by decide
theorem cert_e2259550307854 : check e2259550307854 [[]] .width = true := by decide
def e2259550307866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259550307866 : Closed e2259550307866 ∧ code e2259550307866 = 11055643330074 := by decide
theorem cert_e2259550307866 : check e2259550307866 [[]] .width = true := by decide
def e2259550307938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259550307938 : Closed e2259550307938 ∧ code e2259550307938 = 11055643330146 := by decide
theorem cert_e2259550307938 : check e2259550307938 [[]] .width = true := by decide
def e2259550408902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259550408902 : Closed e2259550408902 ∧ code e2259550408902 = 11055643431110 := by decide
theorem cert_e2259550408902 : check e2259550408902 [[]] .width = true := by decide
def e2259550412314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259550412314 : Closed e2259550412314 ∧ code e2259550412314 = 11055643434522 := by decide
theorem cert_e2259550412314 : check e2259550412314 [[]] .width = true := by decide
def e2259550421190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259550421190 : Closed e2259550421190 ∧ code e2259550421190 = 11055643443398 := by decide
theorem cert_e2259550421190 : check e2259550421190 [[]] .width = true := by decide
def e2259550429210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259550429210 : Closed e2259550429210 ∧ code e2259550429210 = 11055643451418 := by decide
theorem cert_e2259550429210 : check e2259550429210 [[]] .width = true := by decide
def e2259550429302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259550429302 : Closed e2259550429302 ∧ code e2259550429302 = 11055643451510 := by decide
theorem cert_e2259550429302 : check e2259550429302 [[]] .width = true := by decide
def e2259550429546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259550429546 : Closed e2259550429546 ∧ code e2259550429546 = 11055643451754 := by decide
theorem cert_e2259550429546 : check e2259550429546 [[]] .width = true := by decide
def e2259550429594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259550429594 : Closed e2259550429594 ∧ code e2259550429594 = 11055643451802 := by decide
theorem cert_e2259550429594 : check e2259550429594 [[]] .width = true := by decide
def e2259550433478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259550433478 : Closed e2259550433478 ∧ code e2259550433478 = 11055643455686 := by decide
theorem cert_e2259550433478 : check e2259550433478 [[]] .width = true := by decide
def e2259550445594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259550445594 : Closed e2259550445594 ∧ code e2259550445594 = 11055643467802 := by decide
theorem cert_e2259550445594 : check e2259550445594 [[]] .width = true := by decide
def e2259550445686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259550445686 : Closed e2259550445686 ∧ code e2259550445686 = 11055643467894 := by decide
theorem cert_e2259550445686 : check e2259550445686 [[]] .width = true := by decide
def e2259550445930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259550445930 : Closed e2259550445930 ∧ code e2259550445930 = 11055643468138 := by decide
theorem cert_e2259550445930 : check e2259550445930 [[]] .width = true := by decide
def e2259550445978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259550445978 : Closed e2259550445978 ∧ code e2259550445978 = 11055643468186 := by decide
theorem cert_e2259550445978 : check e2259550445978 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259548868122
#print axioms Blc.Floor43.cert_e2259549064730
#print axioms Blc.Floor43.cert_e2259549390242
#print axioms Blc.Floor43.cert_e2259549390362
#print axioms Blc.Floor43.cert_e2259549625882
#print axioms Blc.Floor43.cert_e2259549642870
#print axioms Blc.Floor43.cert_e2259549643114
#print axioms Blc.Floor43.cert_e2259549643162
#print axioms Blc.Floor43.cert_e2259549654554
#print axioms Blc.Floor43.cert_e2259549948854
#print axioms Blc.Floor43.cert_e2259549949466
#print axioms Blc.Floor43.cert_e2259549949558
#print axioms Blc.Floor43.cert_e2259549957382
