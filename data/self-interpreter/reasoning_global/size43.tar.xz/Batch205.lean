import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389747001582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2389747001582 : Closed e2389747001582 ∧ code e2389747001582 = 11185840023790 := by decide
theorem cert_e2389747001582 : check e2389747001582 [[],[.left],[]] .sourceHead = true := by decide
def e2389747001590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2389747001590 : Closed e2389747001590 ∧ code e2389747001590 = 11185840023798 := by decide
theorem cert_e2389747001590 : check e2389747001590 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2389747002142 : Closed e2389747002142 ∧ code e2389747002142 = 11185840024350 := by decide
theorem cert_e2389747002142 : check e2389747002142 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2389747002254 : Closed e2389747002254 ∧ code e2389747002254 = 11185840024462 := by decide
theorem cert_e2389747002254 : check e2389747002254 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2389747002478 : Closed e2389747002478 ∧ code e2389747002478 = 11185840024686 := by decide
theorem cert_e2389747002478 : check e2389747002478 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2389747002490 : Closed e2389747002490 ∧ code e2389747002490 = 11185840024698 := by decide
theorem cert_e2389747002490 : check e2389747002490 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2389747002654 : Closed e2389747002654 ∧ code e2389747002654 = 11185840024862 := by decide
theorem cert_e2389747002654 : check e2389747002654 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2389747002822 : Closed e2389747002822 ∧ code e2389747002822 = 11185840025030 := by decide
theorem cert_e2389747002822 : check e2389747002822 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2389747002934 : Closed e2389747002934 ∧ code e2389747002934 = 11185840025142 := by decide
theorem cert_e2389747002934 : check e2389747002934 [[],[.left],[]] .sourceHead = true := by decide
def e2389747002938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2389747002938 : Closed e2389747002938 ∧ code e2389747002938 = 11185840025146 := by decide
theorem cert_e2389747002938 : check e2389747002938 [[],[.left],[]] .sourceHead = true := by decide
def e2389747003022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2389747003022 : Closed e2389747003022 ∧ code e2389747003022 = 11185840025230 := by decide
theorem cert_e2389747003022 : check e2389747003022 [[],[.left],[]] .sourceHead = true := by decide
def e2389747003078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2389747003078 : Closed e2389747003078 ∧ code e2389747003078 = 11185840025286 := by decide
theorem cert_e2389747003078 : check e2389747003078 [[],[.left],[]] .sourceHead = true := by decide
def e2389747003822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2389747003822 : Closed e2389747003822 ∧ code e2389747003822 = 11185840026030 := by decide
theorem cert_e2389747003822 : check e2389747003822 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2389747003834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2389747003834 : Closed e2389747003834 ∧ code e2389747003834 = 11185840026042 := by decide
theorem cert_e2389747003834 : check e2389747003834 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389747003882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2389747003882 : Closed e2389747003882 ∧ code e2389747003882 = 11185840026090 := by decide
theorem cert_e2389747003882 : check e2389747003882 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389747004526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2389747004526 : Closed e2389747004526 ∧ code e2389747004526 = 11185840026734 := by decide
theorem cert_e2389747004526 : check e2389747004526 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e2389747004538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2389747004538 : Closed e2389747004538 ∧ code e2389747004538 = 11185840026746 := by decide
theorem cert_e2389747004538 : check e2389747004538 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389747004702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2389747004702 : Closed e2389747004702 ∧ code e2389747004702 = 11185840026910 := by decide
theorem cert_e2389747004702 : check e2389747004702 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2389747004870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2389747004870 : Closed e2389747004870 ∧ code e2389747004870 = 11185840027078 := by decide
theorem cert_e2389747004870 : check e2389747004870 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389747005210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2389747005210 : Closed e2389747005210 ∧ code e2389747005210 = 11185840027418 := by decide
theorem cert_e2389747005210 : check e2389747005210 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389747005254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2389747005254 : Closed e2389747005254 ∧ code e2389747005254 = 11185840027462 := by decide
theorem cert_e2389747005254 : check e2389747005254 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389747005654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2389747005654 : Closed e2389747005654 ∧ code e2389747005654 = 11185840027862 := by decide
theorem cert_e2389747005654 : check e2389747005654 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2389747005658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2389747005658 : Closed e2389747005658 ∧ code e2389747005658 = 11185840027866 := by decide
theorem cert_e2389747005658 : check e2389747005658 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389747005674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2389747005674 : Closed e2389747005674 ∧ code e2389747005674 = 11185840027882 := by decide
theorem cert_e2389747005674 : check e2389747005674 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2389747006006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2389747006006 : Closed e2389747006006 ∧ code e2389747006006 = 11185840028214 := by decide
theorem cert_e2389747006006 : check e2389747006006 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2389747006010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2389747006010 : Closed e2389747006010 ∧ code e2389747006010 = 11185840028218 := by decide
theorem cert_e2389747006010 : check e2389747006010 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389747006094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2389747006094 : Closed e2389747006094 ∧ code e2389747006094 = 11185840028302 := by decide
theorem cert_e2389747006094 : check e2389747006094 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2389747006150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2389747006150 : Closed e2389747006150 ∧ code e2389747006150 = 11185840028358 := by decide
theorem cert_e2389747006150 : check e2389747006150 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389747006234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2389747006234 : Closed e2389747006234 ∧ code e2389747006234 = 11185840028442 := by decide
theorem cert_e2389747006234 : check e2389747006234 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2389747006278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2389747006278 : Closed e2389747006278 ∧ code e2389747006278 = 11185840028486 := by decide
theorem cert_e2389747006278 : check e2389747006278 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2389747010798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2389747010798 : Closed e2389747010798 ∧ code e2389747010798 = 11185840033006 := by decide
theorem cert_e2389747010798 : check e2389747010798 [[],[.left],[]] .sourceHead = true := by decide
def e2389747010806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2389747010806 : Closed e2389747010806 ∧ code e2389747010806 = 11185840033014 := by decide
theorem cert_e2389747010806 : check e2389747010806 [[],[.left],[]] .sourceHead = true := by decide
def e2389747011182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2389747011182 : Closed e2389747011182 ∧ code e2389747011182 = 11185840033390 := by decide
theorem cert_e2389747011182 : check e2389747011182 [[],[.left],[]] .sourceHead = true := by decide
def e2389747011194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2389747011194 : Closed e2389747011194 ∧ code e2389747011194 = 11185840033402 := by decide
theorem cert_e2389747011194 : check e2389747011194 [[],[.left],[]] .sourceHead = true := by decide
def e2389747011382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2389747011382 : Closed e2389747011382 ∧ code e2389747011382 = 11185840033590 := by decide
theorem cert_e2389747011382 : check e2389747011382 [[],[.left],[]] .sourceHead = true := by decide
def e2389747011386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2389747011386 : Closed e2389747011386 ∧ code e2389747011386 = 11185840033594 := by decide
theorem cert_e2389747011386 : check e2389747011386 [[],[.left],[]] .sourceHead = true := by decide
def e2389747013870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2389747013870 : Closed e2389747013870 ∧ code e2389747013870 = 11185840036078 := by decide
theorem cert_e2389747013870 : check e2389747013870 [[],[.left],[]] .sourceHead = true := by decide
def e2389747013878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2389747013878 : Closed e2389747013878 ∧ code e2389747013878 = 11185840036086 := by decide
theorem cert_e2389747013878 : check e2389747013878 [[],[.left],[]] .sourceHead = true := by decide
def e2389747014430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2389747014430 : Closed e2389747014430 ∧ code e2389747014430 = 11185840036638 := by decide
theorem cert_e2389747014430 : check e2389747014430 [[],[.left],[]] .sourceHead = true := by decide
def e2389747014542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2389747014542 : Closed e2389747014542 ∧ code e2389747014542 = 11185840036750 := by decide
theorem cert_e2389747014542 : check e2389747014542 [[],[.left],[]] .sourceHead = true := by decide
def e2389747014766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2389747014766 : Closed e2389747014766 ∧ code e2389747014766 = 11185840036974 := by decide
theorem cert_e2389747014766 : check e2389747014766 [[],[.left],[]] .sourceHead = true := by decide
def e2389747014778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2389747014778 : Closed e2389747014778 ∧ code e2389747014778 = 11185840036986 := by decide
theorem cert_e2389747014778 : check e2389747014778 [[],[.left],[]] .sourceHead = true := by decide
def e2389747014942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2389747014942 : Closed e2389747014942 ∧ code e2389747014942 = 11185840037150 := by decide
theorem cert_e2389747014942 : check e2389747014942 [[],[.left],[]] .sourceHead = true := by decide
def e2389747015110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2389747015110 : Closed e2389747015110 ∧ code e2389747015110 = 11185840037318 := by decide
theorem cert_e2389747015110 : check e2389747015110 [[],[.left],[]] .sourceHead = true := by decide
def e2389747015222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2389747015222 : Closed e2389747015222 ∧ code e2389747015222 = 11185840037430 := by decide
theorem cert_e2389747015222 : check e2389747015222 [[],[.left],[]] .sourceHead = true := by decide
def e2389747015226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2389747015226 : Closed e2389747015226 ∧ code e2389747015226 = 11185840037434 := by decide
theorem cert_e2389747015226 : check e2389747015226 [[],[.left],[]] .sourceHead = true := by decide
def e2389747015310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2389747015310 : Closed e2389747015310 ∧ code e2389747015310 = 11185840037518 := by decide
theorem cert_e2389747015310 : check e2389747015310 [[],[.left],[]] .sourceHead = true := by decide
def e2389747015366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2389747015366 : Closed e2389747015366 ∧ code e2389747015366 = 11185840037574 := by decide
theorem cert_e2389747015366 : check e2389747015366 [[],[.left],[]] .sourceHead = true := by decide
def e2389747017502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2389747017502 : Closed e2389747017502 ∧ code e2389747017502 = 11185840039710 := by decide
theorem cert_e2389747017502 : check e2389747017502 [[],[.left],[]] .sourceHead = true := by decide
def e2389747017614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2389747017614 : Closed e2389747017614 ∧ code e2389747017614 = 11185840039822 := by decide
theorem cert_e2389747017614 : check e2389747017614 [[],[.left],[]] .sourceHead = true := by decide
def e2389747020574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2389747020574 : Closed e2389747020574 ∧ code e2389747020574 = 11185840042782 := by decide
theorem cert_e2389747020574 : check e2389747020574 [[],[.left],[]] .sourceHead = true := by decide
def e2389747020742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2389747020742 : Closed e2389747020742 ∧ code e2389747020742 = 11185840042950 := by decide
theorem cert_e2389747020742 : check e2389747020742 [[],[.left],[]] .sourceHead = true := by decide
def e2389747022222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2389747022222 : Closed e2389747022222 ∧ code e2389747022222 = 11185840044430 := by decide
theorem cert_e2389747022222 : check e2389747022222 [[],[.left],[]] .sourceHead = true := by decide
def e2389747022278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2389747022278 : Closed e2389747022278 ∧ code e2389747022278 = 11185840044486 := by decide
theorem cert_e2389747022278 : check e2389747022278 [[],[.left],[]] .sourceHead = true := by decide
def e2389747025518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2389747025518 : Closed e2389747025518 ∧ code e2389747025518 = 11185840047726 := by decide
theorem cert_e2389747025518 : check e2389747025518 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2389747025530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2389747025530 : Closed e2389747025530 ∧ code e2389747025530 = 11185840047738 := by decide
theorem cert_e2389747025530 : check e2389747025530 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2389747025818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389747025818 : Closed e2389747025818 ∧ code e2389747025818 = 11185840048026 := by decide
theorem cert_e2389747025818 : check e2389747025818 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389747027054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2389747027054 : Closed e2389747027054 ∧ code e2389747027054 = 11185840049262 := by decide
theorem cert_e2389747027054 : check e2389747027054 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2389747027066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2389747027066 : Closed e2389747027066 ∧ code e2389747027066 = 11185840049274 := by decide
theorem cert_e2389747027066 : check e2389747027066 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389747027230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2389747027230 : Closed e2389747027230 ∧ code e2389747027230 = 11185840049438 := by decide
theorem cert_e2389747027230 : check e2389747027230 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2389747027398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2389747027398 : Closed e2389747027398 ∧ code e2389747027398 = 11185840049606 := by decide
theorem cert_e2389747027398 : check e2389747027398 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389747027738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2389747027738 : Closed e2389747027738 ∧ code e2389747027738 = 11185840049946 := by decide
theorem cert_e2389747027738 : check e2389747027738 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389747027782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2389747027782 : Closed e2389747027782 ∧ code e2389747027782 = 11185840049990 := by decide
theorem cert_e2389747027782 : check e2389747027782 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389747028766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2389747028766 : Closed e2389747028766 ∧ code e2389747028766 = 11185840050974 := by decide
theorem cert_e2389747028766 : check e2389747028766 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2389747028934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2389747028934 : Closed e2389747028934 ∧ code e2389747028934 = 11185840051142 := by decide
theorem cert_e2389747028934 : check e2389747028934 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2389747031238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2389747031238 : Closed e2389747031238 ∧ code e2389747031238 = 11185840053446 := by decide
theorem cert_e2389747031238 : check e2389747031238 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389747032886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2389747032886 : Closed e2389747032886 ∧ code e2389747032886 = 11185840055094 := by decide
theorem cert_e2389747032886 : check e2389747032886 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389747032890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2389747032890 : Closed e2389747032890 ∧ code e2389747032890 = 11185840055098 := by decide
theorem cert_e2389747032890 : check e2389747032890 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389747032986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389747032986 : Closed e2389747032986 ∧ code e2389747032986 = 11185840055194 := by decide
theorem cert_e2389747032986 : check e2389747032986 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389747033654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2389747033654 : Closed e2389747033654 ∧ code e2389747033654 = 11185840055862 := by decide
theorem cert_e2389747033654 : check e2389747033654 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389747033658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2389747033658 : Closed e2389747033658 ∧ code e2389747033658 = 11185840055866 := by decide
theorem cert_e2389747033658 : check e2389747033658 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389747033742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2389747033742 : Closed e2389747033742 ∧ code e2389747033742 = 11185840055950 := by decide
theorem cert_e2389747033742 : check e2389747033742 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389747033798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2389747033798 : Closed e2389747033798 ∧ code e2389747033798 = 11185840056006 := by decide
theorem cert_e2389747033798 : check e2389747033798 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389747033882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2389747033882 : Closed e2389747033882 ∧ code e2389747033882 = 11185840056090 := by decide
theorem cert_e2389747033882 : check e2389747033882 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389747033926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2389747033926 : Closed e2389747033926 ∧ code e2389747033926 = 11185840056134 := by decide
theorem cert_e2389747033926 : check e2389747033926 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389747034510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2389747034510 : Closed e2389747034510 ∧ code e2389747034510 = 11185840056718 := by decide
theorem cert_e2389747034510 : check e2389747034510 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389747034566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2389747034566 : Closed e2389747034566 ∧ code e2389747034566 = 11185840056774 := by decide
theorem cert_e2389747034566 : check e2389747034566 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389747035334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2389747035334 : Closed e2389747035334 ∧ code e2389747035334 = 11185840057542 := by decide
theorem cert_e2389747035334 : check e2389747035334 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389747046110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2389747046110 : Closed e2389747046110 ∧ code e2389747046110 = 11185840068318 := by decide
theorem cert_e2389747046110 : check e2389747046110 [[],[.left],[]] .chain = true := by decide
def e2389747046134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2389747046134 : Closed e2389747046134 ∧ code e2389747046134 = 11185840068342 := by decide
theorem cert_e2389747046134 : check e2389747046134 [[],[.left],[]] .chain = true := by decide
def e2389747046238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2389747046238 : Closed e2389747046238 ∧ code e2389747046238 = 11185840068446 := by decide
theorem cert_e2389747046238 : check e2389747046238 [[],[.left],[]] .chain = true := by decide
def e2389747046266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2389747046266 : Closed e2389747046266 ∧ code e2389747046266 = 11185840068474 := by decide
theorem cert_e2389747046266 : check e2389747046266 [[],[.left],[]] .chain = true := by decide
def e2389747046358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2389747046358 : Closed e2389747046358 ∧ code e2389747046358 = 11185840068566 := by decide
theorem cert_e2389747046358 : check e2389747046358 [[],[.left],[]] .chain = true := by decide
def e2389747046362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2389747046362 : Closed e2389747046362 ∧ code e2389747046362 = 11185840068570 := by decide
theorem cert_e2389747046362 : check e2389747046362 [[],[.left],[]] .chain = true := by decide
def e2389747046878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2389747046878 : Closed e2389747046878 ∧ code e2389747046878 = 11185840069086 := by decide
theorem cert_e2389747046878 : check e2389747046878 [[],[.left],[]] .chain = true := by decide
def e2389747046902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2389747046902 : Closed e2389747046902 ∧ code e2389747046902 = 11185840069110 := by decide
theorem cert_e2389747046902 : check e2389747046902 [[],[.left],[]] .chain = true := by decide
def e2389747047646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389747047646 : Closed e2389747047646 ∧ code e2389747047646 = 11185840069854 := by decide
theorem cert_e2389747047646 : check e2389747047646 [[],[.left],[]] .chain = true := by decide
def e2389747047674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389747047674 : Closed e2389747047674 ∧ code e2389747047674 = 11185840069882 := by decide
theorem cert_e2389747047674 : check e2389747047674 [[],[.left],[]] .chain = true := by decide
def e2389747048246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389747048246 : Closed e2389747048246 ∧ code e2389747048246 = 11185840070454 := by decide
theorem cert_e2389747048246 : check e2389747048246 [[],[.left],[]] .chain = true := by decide
def e2389747048250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389747048250 : Closed e2389747048250 ∧ code e2389747048250 = 11185840070458 := by decide
theorem cert_e2389747048250 : check e2389747048250 [[],[.left],[]] .chain = true := by decide
def e2389747063022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2389747063022 : Closed e2389747063022 ∧ code e2389747063022 = 11185840085230 := by decide
theorem cert_e2389747063022 : check e2389747063022 [[],[.left],[]] .sourceHead = true := by decide
def e2389747063030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2389747063030 : Closed e2389747063030 ∧ code e2389747063030 = 11185840085238 := by decide
theorem cert_e2389747063030 : check e2389747063030 [[],[.left],[]] .sourceHead = true := by decide
def e2389747063582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2389747063582 : Closed e2389747063582 ∧ code e2389747063582 = 11185840085790 := by decide
theorem cert_e2389747063582 : check e2389747063582 [[],[.left],[]] .sourceHead = true := by decide
def e2389747063694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2389747063694 : Closed e2389747063694 ∧ code e2389747063694 = 11185840085902 := by decide
theorem cert_e2389747063694 : check e2389747063694 [[],[.left],[]] .sourceHead = true := by decide
def e2389747063918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2389747063918 : Closed e2389747063918 ∧ code e2389747063918 = 11185840086126 := by decide
theorem cert_e2389747063918 : check e2389747063918 [[],[.left],[]] .sourceHead = true := by decide
def e2389747063930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2389747063930 : Closed e2389747063930 ∧ code e2389747063930 = 11185840086138 := by decide
theorem cert_e2389747063930 : check e2389747063930 [[],[.left],[]] .sourceHead = true := by decide
def e2389747064094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2389747064094 : Closed e2389747064094 ∧ code e2389747064094 = 11185840086302 := by decide
theorem cert_e2389747064094 : check e2389747064094 [[],[.left],[]] .sourceHead = true := by decide
def e2389747064262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2389747064262 : Closed e2389747064262 ∧ code e2389747064262 = 11185840086470 := by decide
theorem cert_e2389747064262 : check e2389747064262 [[],[.left],[]] .sourceHead = true := by decide
def e2389747064374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2389747064374 : Closed e2389747064374 ∧ code e2389747064374 = 11185840086582 := by decide
theorem cert_e2389747064374 : check e2389747064374 [[],[.left],[]] .sourceHead = true := by decide
def e2389747064378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2389747064378 : Closed e2389747064378 ∧ code e2389747064378 = 11185840086586 := by decide
theorem cert_e2389747064378 : check e2389747064378 [[],[.left],[]] .sourceHead = true := by decide
def e2389747064462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2389747064462 : Closed e2389747064462 ∧ code e2389747064462 = 11185840086670 := by decide
theorem cert_e2389747064462 : check e2389747064462 [[],[.left],[]] .sourceHead = true := by decide
def e2389747064518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2389747064518 : Closed e2389747064518 ∧ code e2389747064518 = 11185840086726 := by decide
theorem cert_e2389747064518 : check e2389747064518 [[],[.left],[]] .sourceHead = true := by decide
def e2389747066654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2389747066654 : Closed e2389747066654 ∧ code e2389747066654 = 11185840088862 := by decide
theorem cert_e2389747066654 : check e2389747066654 [[],[.left],[]] .sourceHead = true := by decide
def e2389747066766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2389747066766 : Closed e2389747066766 ∧ code e2389747066766 = 11185840088974 := by decide
theorem cert_e2389747066766 : check e2389747066766 [[],[.left],[]] .sourceHead = true := by decide
def e2389747069726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2389747069726 : Closed e2389747069726 ∧ code e2389747069726 = 11185840091934 := by decide
theorem cert_e2389747069726 : check e2389747069726 [[],[.left],[]] .sourceHead = true := by decide
def e2389747069894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2389747069894 : Closed e2389747069894 ∧ code e2389747069894 = 11185840092102 := by decide
theorem cert_e2389747069894 : check e2389747069894 [[],[.left],[]] .sourceHead = true := by decide
def e2389747071374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2389747071374 : Closed e2389747071374 ∧ code e2389747071374 = 11185840093582 := by decide
theorem cert_e2389747071374 : check e2389747071374 [[],[.left],[]] .sourceHead = true := by decide
def e2389747071430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2389747071430 : Closed e2389747071430 ∧ code e2389747071430 = 11185840093638 := by decide
theorem cert_e2389747071430 : check e2389747071430 [[],[.left],[]] .sourceHead = true := by decide
def e2389747108718 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389747108718 : Closed e2389747108718 ∧ code e2389747108718 = 11185840130926 := by decide
theorem cert_e2389747108718 : check e2389747108718 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747108726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389747108726 : Closed e2389747108726 ∧ code e2389747108726 = 11185840130934 := by decide
theorem cert_e2389747108726 : check e2389747108726 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747108782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389747108782 : Closed e2389747108782 ∧ code e2389747108782 = 11185840130990 := by decide
theorem cert_e2389747108782 : check e2389747108782 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747108794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389747108794 : Closed e2389747108794 ∧ code e2389747108794 = 11185840131002 := by decide
theorem cert_e2389747108794 : check e2389747108794 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747108822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389747108822 : Closed e2389747108822 ∧ code e2389747108822 = 11185840131030 := by decide
theorem cert_e2389747108822 : check e2389747108822 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747108826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389747108826 : Closed e2389747108826 ∧ code e2389747108826 = 11185840131034 := by decide
theorem cert_e2389747108826 : check e2389747108826 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747109102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389747109102 : Closed e2389747109102 ∧ code e2389747109102 = 11185840131310 := by decide
theorem cert_e2389747109102 : check e2389747109102 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747109110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389747109110 : Closed e2389747109110 ∧ code e2389747109110 = 11185840131318 := by decide
theorem cert_e2389747109110 : check e2389747109110 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747109486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389747109486 : Closed e2389747109486 ∧ code e2389747109486 = 11185840131694 := by decide
theorem cert_e2389747109486 : check e2389747109486 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747109498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389747109498 : Closed e2389747109498 ∧ code e2389747109498 = 11185840131706 := by decide
theorem cert_e2389747109498 : check e2389747109498 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747109686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389747109686 : Closed e2389747109686 ∧ code e2389747109686 = 11185840131894 := by decide
theorem cert_e2389747109686 : check e2389747109686 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747109690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389747109690 : Closed e2389747109690 ∧ code e2389747109690 = 11185840131898 := by decide
theorem cert_e2389747109690 : check e2389747109690 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747117166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2389747117166 : Closed e2389747117166 ∧ code e2389747117166 = 11185840139374 := by decide
theorem cert_e2389747117166 : check e2389747117166 [[],[.left],[],[.under]] .three = true := by decide
def e2389747117178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2389747117178 : Closed e2389747117178 ∧ code e2389747117178 = 11185840139386 := by decide
theorem cert_e2389747117178 : check e2389747117178 [[],[.left],[],[.under]] .three = true := by decide
def e2389747117342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2389747117342 : Closed e2389747117342 ∧ code e2389747117342 = 11185840139550 := by decide
theorem cert_e2389747117342 : check e2389747117342 [[],[.left],[],[.under]] .three = true := by decide
def e2389747117510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2389747117510 : Closed e2389747117510 ∧ code e2389747117510 = 11185840139718 := by decide
theorem cert_e2389747117510 : check e2389747117510 [[],[.left],[],[.under]] .three = true := by decide
def e2389747117850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2389747117850 : Closed e2389747117850 ∧ code e2389747117850 = 11185840140058 := by decide
theorem cert_e2389747117850 : check e2389747117850 [[],[.left],[],[.under]] .three = true := by decide
def e2389747117894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2389747117894 : Closed e2389747117894 ∧ code e2389747117894 = 11185840140102 := by decide
theorem cert_e2389747117894 : check e2389747117894 [[],[.left],[],[.under]] .three = true := by decide
def e2389747118878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2389747118878 : Closed e2389747118878 ∧ code e2389747118878 = 11185840141086 := by decide
theorem cert_e2389747118878 : check e2389747118878 [[],[.left],[],[.under]] .three = true := by decide
def e2389747119046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2389747119046 : Closed e2389747119046 ∧ code e2389747119046 = 11185840141254 := by decide
theorem cert_e2389747119046 : check e2389747119046 [[],[.left],[],[.under]] .three = true := by decide
def e2389747121350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2389747121350 : Closed e2389747121350 ∧ code e2389747121350 = 11185840143558 := by decide
theorem cert_e2389747121350 : check e2389747121350 [[],[.left],[],[.under]] .three = true := by decide
def e2389747144246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2389747144246 : Closed e2389747144246 ∧ code e2389747144246 = 11185840166454 := by decide
theorem cert_e2389747144246 : check e2389747144246 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747144250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2389747144250 : Closed e2389747144250 ∧ code e2389747144250 = 11185840166458 := by decide
theorem cert_e2389747144250 : check e2389747144250 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747144334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2389747144334 : Closed e2389747144334 ∧ code e2389747144334 = 11185840166542 := by decide
theorem cert_e2389747144334 : check e2389747144334 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747144390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2389747144390 : Closed e2389747144390 ∧ code e2389747144390 = 11185840166598 := by decide
theorem cert_e2389747144390 : check e2389747144390 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747144474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2389747144474 : Closed e2389747144474 ∧ code e2389747144474 = 11185840166682 := by decide
theorem cert_e2389747144474 : check e2389747144474 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747144518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2389747144518 : Closed e2389747144518 ∧ code e2389747144518 = 11185840166726 := by decide
theorem cert_e2389747144518 : check e2389747144518 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747145102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2389747145102 : Closed e2389747145102 ∧ code e2389747145102 = 11185840167310 := by decide
theorem cert_e2389747145102 : check e2389747145102 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747145158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2389747145158 : Closed e2389747145158 ∧ code e2389747145158 = 11185840167366 := by decide
theorem cert_e2389747145158 : check e2389747145158 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389747145926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2389747145926 : Closed e2389747145926 ∧ code e2389747145926 = 11185840168134 := by decide
theorem cert_e2389747145926 : check e2389747145926 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389748242670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2389748242670 : Closed e2389748242670 ∧ code e2389748242670 = 11185841264878 := by decide
theorem cert_e2389748242670 : check e2389748242670 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748242678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2389748242678 : Closed e2389748242678 ∧ code e2389748242678 = 11185841264886 := by decide
theorem cert_e2389748242678 : check e2389748242678 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748243230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2389748243230 : Closed e2389748243230 ∧ code e2389748243230 = 11185841265438 := by decide
theorem cert_e2389748243230 : check e2389748243230 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748243342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2389748243342 : Closed e2389748243342 ∧ code e2389748243342 = 11185841265550 := by decide
theorem cert_e2389748243342 : check e2389748243342 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748243566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2389748243566 : Closed e2389748243566 ∧ code e2389748243566 = 11185841265774 := by decide
theorem cert_e2389748243566 : check e2389748243566 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748243578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2389748243578 : Closed e2389748243578 ∧ code e2389748243578 = 11185841265786 := by decide
theorem cert_e2389748243578 : check e2389748243578 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748243742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2389748243742 : Closed e2389748243742 ∧ code e2389748243742 = 11185841265950 := by decide
theorem cert_e2389748243742 : check e2389748243742 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748243910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2389748243910 : Closed e2389748243910 ∧ code e2389748243910 = 11185841266118 := by decide
theorem cert_e2389748243910 : check e2389748243910 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748244022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2389748244022 : Closed e2389748244022 ∧ code e2389748244022 = 11185841266230 := by decide
theorem cert_e2389748244022 : check e2389748244022 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748244026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2389748244026 : Closed e2389748244026 ∧ code e2389748244026 = 11185841266234 := by decide
theorem cert_e2389748244026 : check e2389748244026 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748244110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2389748244110 : Closed e2389748244110 ∧ code e2389748244110 = 11185841266318 := by decide
theorem cert_e2389748244110 : check e2389748244110 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748244166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2389748244166 : Closed e2389748244166 ∧ code e2389748244166 = 11185841266374 := by decide
theorem cert_e2389748244166 : check e2389748244166 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748246302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2389748246302 : Closed e2389748246302 ∧ code e2389748246302 = 11185841268510 := by decide
theorem cert_e2389748246302 : check e2389748246302 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748246414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2389748246414 : Closed e2389748246414 ∧ code e2389748246414 = 11185841268622 := by decide
theorem cert_e2389748246414 : check e2389748246414 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748249374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2389748249374 : Closed e2389748249374 ∧ code e2389748249374 = 11185841271582 := by decide
theorem cert_e2389748249374 : check e2389748249374 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748249542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2389748249542 : Closed e2389748249542 ∧ code e2389748249542 = 11185841271750 := by decide
theorem cert_e2389748249542 : check e2389748249542 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748251022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2389748251022 : Closed e2389748251022 ∧ code e2389748251022 = 11185841273230 := by decide
theorem cert_e2389748251022 : check e2389748251022 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389748251078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2389748251078 : Closed e2389748251078 ∧ code e2389748251078 = 11185841273286 := by decide
theorem cert_e2389748251078 : check e2389748251078 [[],[.left],[],[]] .sourceHead = true := by decide
def e2389752944350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2389752944350 : Closed e2389752944350 ∧ code e2389752944350 = 11185845966558 := by decide
theorem cert_e2389752944350 : check e2389752944350 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752944374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2389752944374 : Closed e2389752944374 ∧ code e2389752944374 = 11185845966582 := by decide
theorem cert_e2389752944374 : check e2389752944374 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752944478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2389752944478 : Closed e2389752944478 ∧ code e2389752944478 = 11185845966686 := by decide
theorem cert_e2389752944478 : check e2389752944478 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752944506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2389752944506 : Closed e2389752944506 ∧ code e2389752944506 = 11185845966714 := by decide
theorem cert_e2389752944506 : check e2389752944506 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
end Blc.Floor43
