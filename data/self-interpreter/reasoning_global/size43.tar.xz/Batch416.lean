import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373506914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422373506914 : Closed e2422373506914 ∧ code e2422373506914 = 11218466529122 := by decide
theorem cert_e2422373506914 : check e2422373506914 [[],[]] .three = true := by decide
def e2422373506926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2422373506926 : Closed e2422373506926 ∧ code e2422373506926 = 11218466529134 := by decide
theorem cert_e2422373506926 : check e2422373506926 [[],[]] .three = true := by decide
def e2422373506934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2422373506934 : Closed e2422373506934 ∧ code e2422373506934 = 11218466529142 := by decide
theorem cert_e2422373506934 : check e2422373506934 [[],[]] .three = true := by decide
def e2422373506938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e2422373506938 : Closed e2422373506938 ∧ code e2422373506938 = 11218466529146 := by decide
theorem cert_e2422373506938 : check e2422373506938 [[],[]] .three = true := by decide
def e2422373507518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 4))))))))))
theorem wire_e2422373507518 : Closed e2422373507518 ∧ code e2422373507518 = 11218466529726 := by decide
theorem cert_e2422373507518 : check e2422373507518 [[],[]] .three = true := by decide
def e2422373507550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422373507550 : Closed e2422373507550 ∧ code e2422373507550 = 11218466529758 := by decide
theorem cert_e2422373507550 : check e2422373507550 [[],[]] .smaller = true := by decide
def e2422373507574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422373507574 : Closed e2422373507574 ∧ code e2422373507574 = 11218466529782 := by decide
theorem cert_e2422373507574 : check e2422373507574 [[],[]] .smaller = true := by decide
def e2422373507578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 4) (.var 0))))))))))
theorem wire_e2422373507578 : Closed e2422373507578 ∧ code e2422373507578 = 11218466529786 := by decide
theorem cert_e2422373507578 : check e2422373507578 [[],[]] .three = true := by decide
def e2422373508526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422373508526 : Closed e2422373508526 ∧ code e2422373508526 = 11218466530734 := by decide
theorem cert_e2422373508526 : check e2422373508526 [[],[]] .smaller = true := by decide
def e2422373508538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422373508538 : Closed e2422373508538 ∧ code e2422373508538 = 11218466530746 := by decide
theorem cert_e2422373508538 : check e2422373508538 [[],[]] .smaller = true := by decide
def e2422373508586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422373508586 : Closed e2422373508586 ∧ code e2422373508586 = 11218466530794 := by decide
theorem cert_e2422373508586 : check e2422373508586 [[],[]] .smaller = true := by decide
def e2422373508670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422373508670 : Closed e2422373508670 ∧ code e2422373508670 = 11218466530878 := by decide
theorem cert_e2422373508670 : check e2422373508670 [[],[]] .three = true := by decide
def e2422373508718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373508718 : Closed e2422373508718 ∧ code e2422373508718 = 11218466530926 := by decide
theorem cert_e2422373508718 : check e2422373508718 [[],[]] .smaller = true := by decide
def e2422373508730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373508730 : Closed e2422373508730 ∧ code e2422373508730 = 11218466530938 := by decide
theorem cert_e2422373508730 : check e2422373508730 [[],[]] .smaller = true := by decide
def e2422373508894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422373508894 : Closed e2422373508894 ∧ code e2422373508894 = 11218466531102 := by decide
theorem cert_e2422373508894 : check e2422373508894 [[],[]] .smaller = true := by decide
def e2422373508994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373508994 : Closed e2422373508994 ∧ code e2422373508994 = 11218466531202 := by decide
theorem cert_e2422373508994 : check e2422373508994 [[],[]] .smaller = true := by decide
def e2422373509006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422373509006 : Closed e2422373509006 ∧ code e2422373509006 = 11218466531214 := by decide
theorem cert_e2422373509006 : check e2422373509006 [[],[]] .smaller = true := by decide
def e2422373509018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373509018 : Closed e2422373509018 ∧ code e2422373509018 = 11218466531226 := by decide
theorem cert_e2422373509018 : check e2422373509018 [[],[]] .smaller = true := by decide
def e2422373509062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422373509062 : Closed e2422373509062 ∧ code e2422373509062 = 11218466531270 := by decide
theorem cert_e2422373509062 : check e2422373509062 [[],[]] .three = true := by decide
def e2422373509086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422373509086 : Closed e2422373509086 ∧ code e2422373509086 = 11218466531294 := by decide
theorem cert_e2422373509086 : check e2422373509086 [[],[]] .three = true := by decide
def e2422373511294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 5))))))))))
theorem wire_e2422373511294 : Closed e2422373511294 ∧ code e2422373511294 = 11218466533502 := by decide
theorem cert_e2422373511294 : check e2422373511294 [[],[]] .three = true := by decide
def e2422373511390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2422373511390 : Closed e2422373511390 ∧ code e2422373511390 = 11218466533598 := by decide
theorem cert_e2422373511390 : check e2422373511390 [[],[]] .smaller = true := by decide
def e2422373511418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2422373511418 : Closed e2422373511418 ∧ code e2422373511418 = 11218466533626 := by decide
theorem cert_e2422373511418 : check e2422373511418 [[],[]] .smaller = true := by decide
def e2422373511966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422373511966 : Closed e2422373511966 ∧ code e2422373511966 = 11218466534174 := by decide
theorem cert_e2422373511966 : check e2422373511966 [[],[]] .smaller = true := by decide
def e2422373512134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422373512134 : Closed e2422373512134 ∧ code e2422373512134 = 11218466534342 := by decide
theorem cert_e2422373512134 : check e2422373512134 [[],[]] .smaller = true := by decide
def e2422373512158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373512158 : Closed e2422373512158 ∧ code e2422373512158 = 11218466534366 := by decide
theorem cert_e2422373512158 : check e2422373512158 [[],[]] .three = true := by decide
def e2422373512162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422373512162 : Closed e2422373512162 ∧ code e2422373512162 = 11218466534370 := by decide
theorem cert_e2422373512162 : check e2422373512162 [[],[]] .three = true := by decide
def e2422373512174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373512174 : Closed e2422373512174 ∧ code e2422373512174 = 11218466534382 := by decide
theorem cert_e2422373512174 : check e2422373512174 [[],[]] .three = true := by decide
def e2422373513242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422373513242 : Closed e2422373513242 ∧ code e2422373513242 = 11218466535450 := by decide
theorem cert_e2422373513242 : check e2422373513242 [[],[]] .smaller = true := by decide
def e2422373513278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373513278 : Closed e2422373513278 ∧ code e2422373513278 = 11218466535486 := by decide
theorem cert_e2422373513278 : check e2422373513278 [[],[]] .smaller = true := by decide
def e2422373513326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373513326 : Closed e2422373513326 ∧ code e2422373513326 = 11218466535534 := by decide
theorem cert_e2422373513326 : check e2422373513326 [[],[]] .smaller = true := by decide
def e2422373513334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373513334 : Closed e2422373513334 ∧ code e2422373513334 = 11218466535542 := by decide
theorem cert_e2422373513334 : check e2422373513334 [[],[]] .smaller = true := by decide
def e2422373513338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373513338 : Closed e2422373513338 ∧ code e2422373513338 = 11218466535546 := by decide
theorem cert_e2422373513338 : check e2422373513338 [[],[]] .smaller = true := by decide
def e2422373513578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422373513578 : Closed e2422373513578 ∧ code e2422373513578 = 11218466535786 := by decide
theorem cert_e2422373513578 : check e2422373513578 [[],[]] .smaller = true := by decide
def e2422373513602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373513602 : Closed e2422373513602 ∧ code e2422373513602 = 11218466535810 := by decide
theorem cert_e2422373513602 : check e2422373513602 [[],[]] .smaller = true := by decide
def e2422373513614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373513614 : Closed e2422373513614 ∧ code e2422373513614 = 11218466535822 := by decide
theorem cert_e2422373513614 : check e2422373513614 [[],[]] .smaller = true := by decide
def e2422373513626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373513626 : Closed e2422373513626 ∧ code e2422373513626 = 11218466535834 := by decide
theorem cert_e2422373513626 : check e2422373513626 [[],[]] .smaller = true := by decide
def e2422373513670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373513670 : Closed e2422373513670 ∧ code e2422373513670 = 11218466535878 := by decide
theorem cert_e2422373513670 : check e2422373513670 [[],[]] .smaller = true := by decide
def e2422373513694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373513694 : Closed e2422373513694 ∧ code e2422373513694 = 11218466535902 := by decide
theorem cert_e2422373513694 : check e2422373513694 [[],[]] .three = true := by decide
def e2422373513698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373513698 : Closed e2422373513698 ∧ code e2422373513698 = 11218466535906 := by decide
theorem cert_e2422373513698 : check e2422373513698 [[],[]] .smaller = true := by decide
def e2422373513710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373513710 : Closed e2422373513710 ∧ code e2422373513710 = 11218466535918 := by decide
theorem cert_e2422373513710 : check e2422373513710 [[],[]] .smaller = true := by decide
def e2422373513718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373513718 : Closed e2422373513718 ∧ code e2422373513718 = 11218466535926 := by decide
theorem cert_e2422373513718 : check e2422373513718 [[],[]] .three = true := by decide
def e2422373514270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.lam (.var 3))))))))))
theorem wire_e2422373514270 : Closed e2422373514270 ∧ code e2422373514270 = 11218466536478 := by decide
theorem cert_e2422373514270 : check e2422373514270 [[],[]] .three = true := by decide
def e2422373514294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373514294 : Closed e2422373514294 ∧ code e2422373514294 = 11218466536502 := by decide
theorem cert_e2422373514294 : check e2422373514294 [[],[]] .three = true := by decide
def e2422373514298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373514298 : Closed e2422373514298 ∧ code e2422373514298 = 11218466536506 := by decide
theorem cert_e2422373514298 : check e2422373514298 [[],[]] .three = true := by decide
def e2422373514438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422373514438 : Closed e2422373514438 ∧ code e2422373514438 = 11218466536646 := by decide
theorem cert_e2422373514438 : check e2422373514438 [[],[]] .three = true := by decide
def e2422373514462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373514462 : Closed e2422373514462 ∧ code e2422373514462 = 11218466536670 := by decide
theorem cert_e2422373514462 : check e2422373514462 [[],[]] .three = true := by decide
def e2422373514466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422373514466 : Closed e2422373514466 ∧ code e2422373514466 = 11218466536674 := by decide
theorem cert_e2422373514466 : check e2422373514466 [[],[]] .three = true := by decide
def e2422373514478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373514478 : Closed e2422373514478 ∧ code e2422373514478 = 11218466536686 := by decide
theorem cert_e2422373514478 : check e2422373514478 [[],[]] .three = true := by decide
def e2422373514486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373514486 : Closed e2422373514486 ∧ code e2422373514486 = 11218466536694 := by decide
theorem cert_e2422373514486 : check e2422373514486 [[],[]] .three = true := by decide
def e2422373514490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373514490 : Closed e2422373514490 ∧ code e2422373514490 = 11218466536698 := by decide
theorem cert_e2422373514490 : check e2422373514490 [[],[]] .three = true := by decide
def e2422373549022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422373549022 : Closed e2422373549022 ∧ code e2422373549022 = 11218466571230 := by decide
theorem cert_e2422373549022 : check e2422373549022 [[],[]] .smaller = true := by decide
def e2422373549038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422373549038 : Closed e2422373549038 ∧ code e2422373549038 = 11218466571246 := by decide
theorem cert_e2422373549038 : check e2422373549038 [[],[]] .smaller = true := by decide
def e2422373550958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422373550958 : Closed e2422373550958 ∧ code e2422373550958 = 11218466573166 := by decide
theorem cert_e2422373550958 : check e2422373550958 [[],[]] .smaller = true := by decide
def e2422373550966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422373550966 : Closed e2422373550966 ∧ code e2422373550966 = 11218466573174 := by decide
theorem cert_e2422373550966 : check e2422373550966 [[],[]] .smaller = true := by decide
def e2422373551022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422373551022 : Closed e2422373551022 ∧ code e2422373551022 = 11218466573230 := by decide
theorem cert_e2422373551022 : check e2422373551022 [[],[]] .smaller = true := by decide
def e2422373551034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422373551034 : Closed e2422373551034 ∧ code e2422373551034 = 11218466573242 := by decide
theorem cert_e2422373551034 : check e2422373551034 [[],[]] .smaller = true := by decide
def e2422373551062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422373551062 : Closed e2422373551062 ∧ code e2422373551062 = 11218466573270 := by decide
theorem cert_e2422373551062 : check e2422373551062 [[],[]] .smaller = true := by decide
def e2422373551066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422373551066 : Closed e2422373551066 ∧ code e2422373551066 = 11218466573274 := by decide
theorem cert_e2422373551066 : check e2422373551066 [[],[]] .smaller = true := by decide
def e2422373551342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373551342 : Closed e2422373551342 ∧ code e2422373551342 = 11218466573550 := by decide
theorem cert_e2422373551342 : check e2422373551342 [[],[]] .smaller = true := by decide
def e2422373551350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373551350 : Closed e2422373551350 ∧ code e2422373551350 = 11218466573558 := by decide
theorem cert_e2422373551350 : check e2422373551350 [[],[]] .smaller = true := by decide
def e2422373551726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373551726 : Closed e2422373551726 ∧ code e2422373551726 = 11218466573934 := by decide
theorem cert_e2422373551726 : check e2422373551726 [[],[]] .smaller = true := by decide
def e2422373551738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373551738 : Closed e2422373551738 ∧ code e2422373551738 = 11218466573946 := by decide
theorem cert_e2422373551738 : check e2422373551738 [[],[]] .smaller = true := by decide
def e2422373551902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e2422373551902 : Closed e2422373551902 ∧ code e2422373551902 = 11218466574110 := by decide
theorem cert_e2422373551902 : check e2422373551902 [[],[]] .smaller = true := by decide
def e2422373551926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373551926 : Closed e2422373551926 ∧ code e2422373551926 = 11218466574134 := by decide
theorem cert_e2422373551926 : check e2422373551926 [[],[]] .smaller = true := by decide
def e2422373551930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373551930 : Closed e2422373551930 ∧ code e2422373551930 = 11218466574138 := by decide
theorem cert_e2422373551930 : check e2422373551930 [[],[]] .smaller = true := by decide
def e2422373552062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 4)))))))))
theorem wire_e2422373552062 : Closed e2422373552062 ∧ code e2422373552062 = 11218466574270 := by decide
theorem cert_e2422373552062 : check e2422373552062 [[],[]] .three = true := by decide
def e2422373552094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 4) (.var 3)))))))))
theorem wire_e2422373552094 : Closed e2422373552094 ∧ code e2422373552094 = 11218466574302 := by decide
theorem cert_e2422373552094 : check e2422373552094 [[],[]] .three = true := by decide
def e2422373559126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422373559126 : Closed e2422373559126 ∧ code e2422373559126 = 11218466581334 := by decide
theorem cert_e2422373559126 : check e2422373559126 [[],[]] .smaller = true := by decide
def e2422373559130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422373559130 : Closed e2422373559130 ∧ code e2422373559130 = 11218466581338 := by decide
theorem cert_e2422373559130 : check e2422373559130 [[],[]] .smaller = true := by decide
def e2422373559146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422373559146 : Closed e2422373559146 ∧ code e2422373559146 = 11218466581354 := by decide
theorem cert_e2422373559146 : check e2422373559146 [[],[]] .smaller = true := by decide
def e2422373559210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422373559210 : Closed e2422373559210 ∧ code e2422373559210 = 11218466581418 := by decide
theorem cert_e2422373559210 : check e2422373559210 [[],[]] .smaller = true := by decide
def e2422373559318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422373559318 : Closed e2422373559318 ∧ code e2422373559318 = 11218466581526 := by decide
theorem cert_e2422373559318 : check e2422373559318 [[],[]] .smaller = true := by decide
def e2422373559390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422373559390 : Closed e2422373559390 ∧ code e2422373559390 = 11218466581598 := by decide
theorem cert_e2422373559390 : check e2422373559390 [[],[]] .three = true := by decide
def e2422373559414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422373559414 : Closed e2422373559414 ∧ code e2422373559414 = 11218466581622 := by decide
theorem cert_e2422373559414 : check e2422373559414 [[],[]] .smaller = true := by decide
def e2422373559510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422373559510 : Closed e2422373559510 ∧ code e2422373559510 = 11218466581718 := by decide
theorem cert_e2422373559510 : check e2422373559510 [[],[]] .smaller = true := by decide
def e2422373559514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422373559514 : Closed e2422373559514 ∧ code e2422373559514 = 11218466581722 := by decide
theorem cert_e2422373559514 : check e2422373559514 [[],[]] .smaller = true := by decide
def e2422373559530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422373559530 : Closed e2422373559530 ∧ code e2422373559530 = 11218466581738 := by decide
theorem cert_e2422373559530 : check e2422373559530 [[],[]] .smaller = true := by decide
def e2422373559606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373559606 : Closed e2422373559606 ∧ code e2422373559606 = 11218466581814 := by decide
theorem cert_e2422373559606 : check e2422373559606 [[],[]] .smaller = true := by decide
def e2422373559610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373559610 : Closed e2422373559610 ∧ code e2422373559610 = 11218466581818 := by decide
theorem cert_e2422373559610 : check e2422373559610 [[],[]] .smaller = true := by decide
def e2422373559682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373559682 : Closed e2422373559682 ∧ code e2422373559682 = 11218466581890 := by decide
theorem cert_e2422373559682 : check e2422373559682 [[],[]] .smaller = true := by decide
def e2422373559694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422373559694 : Closed e2422373559694 ∧ code e2422373559694 = 11218466581902 := by decide
theorem cert_e2422373559694 : check e2422373559694 [[],[]] .smaller = true := by decide
def e2422373559706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373559706 : Closed e2422373559706 ∧ code e2422373559706 = 11218466581914 := by decide
theorem cert_e2422373559706 : check e2422373559706 [[],[]] .smaller = true := by decide
def e2422373559774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2422373559774 : Closed e2422373559774 ∧ code e2422373559774 = 11218466581982 := by decide
theorem cert_e2422373559774 : check e2422373559774 [[],[]] .three = true := by decide
def e2422373559778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422373559778 : Closed e2422373559778 ∧ code e2422373559778 = 11218466581986 := by decide
theorem cert_e2422373559778 : check e2422373559778 [[],[]] .three = true := by decide
def e2422373559790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2422373559790 : Closed e2422373559790 ∧ code e2422373559790 = 11218466581998 := by decide
theorem cert_e2422373559790 : check e2422373559790 [[],[]] .three = true := by decide
def e2422373559818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422373559818 : Closed e2422373559818 ∧ code e2422373559818 = 11218466582026 := by decide
theorem cert_e2422373559818 : check e2422373559818 [[],[]] .smaller = true := by decide
def e2422373559854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373559854 : Closed e2422373559854 ∧ code e2422373559854 = 11218466582062 := by decide
theorem cert_e2422373559854 : check e2422373559854 [[],[]] .smaller = true := by decide
def e2422373559862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373559862 : Closed e2422373559862 ∧ code e2422373559862 = 11218466582070 := by decide
theorem cert_e2422373559862 : check e2422373559862 [[],[]] .smaller = true := by decide
def e2422373559866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373559866 : Closed e2422373559866 ∧ code e2422373559866 = 11218466582074 := by decide
theorem cert_e2422373559866 : check e2422373559866 [[],[]] .smaller = true := by decide
def e2422373559914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422373559914 : Closed e2422373559914 ∧ code e2422373559914 = 11218466582122 := by decide
theorem cert_e2422373559914 : check e2422373559914 [[],[]] .smaller = true := by decide
def e2422373559938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373559938 : Closed e2422373559938 ∧ code e2422373559938 = 11218466582146 := by decide
theorem cert_e2422373559938 : check e2422373559938 [[],[]] .smaller = true := by decide
def e2422373559950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373559950 : Closed e2422373559950 ∧ code e2422373559950 = 11218466582158 := by decide
theorem cert_e2422373559950 : check e2422373559950 [[],[]] .smaller = true := by decide
def e2422373559962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373559962 : Closed e2422373559962 ∧ code e2422373559962 = 11218466582170 := by decide
theorem cert_e2422373559962 : check e2422373559962 [[],[]] .smaller = true := by decide
def e2422373560006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373560006 : Closed e2422373560006 ∧ code e2422373560006 = 11218466582214 := by decide
theorem cert_e2422373560006 : check e2422373560006 [[],[]] .smaller = true := by decide
def e2422373560030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2422373560030 : Closed e2422373560030 ∧ code e2422373560030 = 11218466582238 := by decide
theorem cert_e2422373560030 : check e2422373560030 [[],[]] .three = true := by decide
def e2422373560034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373560034 : Closed e2422373560034 ∧ code e2422373560034 = 11218466582242 := by decide
theorem cert_e2422373560034 : check e2422373560034 [[],[]] .smaller = true := by decide
def e2422373560046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2422373560046 : Closed e2422373560046 ∧ code e2422373560046 = 11218466582254 := by decide
theorem cert_e2422373560046 : check e2422373560046 [[],[]] .smaller = true := by decide
def e2422373560054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2422373560054 : Closed e2422373560054 ∧ code e2422373560054 = 11218466582262 := by decide
theorem cert_e2422373560054 : check e2422373560054 [[],[]] .three = true := by decide
def e2422373560086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422373560086 : Closed e2422373560086 ∧ code e2422373560086 = 11218466582294 := by decide
theorem cert_e2422373560086 : check e2422373560086 [[],[]] .smaller = true := by decide
def e2422373560158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2422373560158 : Closed e2422373560158 ∧ code e2422373560158 = 11218466582366 := by decide
theorem cert_e2422373560158 : check e2422373560158 [[],[]] .three = true := by decide
def e2422373560162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422373560162 : Closed e2422373560162 ∧ code e2422373560162 = 11218466582370 := by decide
theorem cert_e2422373560162 : check e2422373560162 [[],[]] .smaller = true := by decide
def e2422373560174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2422373560174 : Closed e2422373560174 ∧ code e2422373560174 = 11218466582382 := by decide
theorem cert_e2422373560174 : check e2422373560174 [[],[]] .smaller = true := by decide
def e2422373560182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2422373560182 : Closed e2422373560182 ∧ code e2422373560182 = 11218466582390 := by decide
theorem cert_e2422373560182 : check e2422373560182 [[],[]] .smaller = true := by decide
def e2422373560186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2422373560186 : Closed e2422373560186 ∧ code e2422373560186 = 11218466582394 := by decide
theorem cert_e2422373560186 : check e2422373560186 [[],[]] .three = true := by decide
def e2422373560202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373560202 : Closed e2422373560202 ∧ code e2422373560202 = 11218466582410 := by decide
theorem cert_e2422373560202 : check e2422373560202 [[],[]] .three = true := by decide
def e2422373560226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373560226 : Closed e2422373560226 ∧ code e2422373560226 = 11218466582434 := by decide
theorem cert_e2422373560226 : check e2422373560226 [[],[]] .three = true := by decide
def e2422373560238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2422373560238 : Closed e2422373560238 ∧ code e2422373560238 = 11218466582446 := by decide
theorem cert_e2422373560238 : check e2422373560238 [[],[]] .three = true := by decide
def e2422373560246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2422373560246 : Closed e2422373560246 ∧ code e2422373560246 = 11218466582454 := by decide
theorem cert_e2422373560246 : check e2422373560246 [[],[]] .three = true := by decide
def e2422373560250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2422373560250 : Closed e2422373560250 ∧ code e2422373560250 = 11218466582458 := by decide
theorem cert_e2422373560250 : check e2422373560250 [[],[]] .three = true := by decide
def e2422373560446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 5))))))))))
theorem wire_e2422373560446 : Closed e2422373560446 ∧ code e2422373560446 = 11218466582654 := by decide
theorem cert_e2422373560446 : check e2422373560446 [[],[]] .three = true := by decide
def e2422373560558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373560558 : Closed e2422373560558 ∧ code e2422373560558 = 11218466582766 := by decide
theorem cert_e2422373560558 : check e2422373560558 [[],[]] .smaller = true := by decide
def e2422373560566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373560566 : Closed e2422373560566 ∧ code e2422373560566 = 11218466582774 := by decide
theorem cert_e2422373560566 : check e2422373560566 [[],[]] .smaller = true := by decide
def e2422373561046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422373561046 : Closed e2422373561046 ∧ code e2422373561046 = 11218466583254 := by decide
theorem cert_e2422373561046 : check e2422373561046 [[],[]] .smaller = true := by decide
def e2422373561050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422373561050 : Closed e2422373561050 ∧ code e2422373561050 = 11218466583258 := by decide
theorem cert_e2422373561050 : check e2422373561050 [[],[]] .smaller = true := by decide
def e2422373561066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422373561066 : Closed e2422373561066 ∧ code e2422373561066 = 11218466583274 := by decide
theorem cert_e2422373561066 : check e2422373561066 [[],[]] .smaller = true := by decide
def e2422373561142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373561142 : Closed e2422373561142 ∧ code e2422373561142 = 11218466583350 := by decide
theorem cert_e2422373561142 : check e2422373561142 [[],[]] .smaller = true := by decide
def e2422373561146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373561146 : Closed e2422373561146 ∧ code e2422373561146 = 11218466583354 := by decide
theorem cert_e2422373561146 : check e2422373561146 [[],[]] .smaller = true := by decide
def e2422373561218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373561218 : Closed e2422373561218 ∧ code e2422373561218 = 11218466583426 := by decide
theorem cert_e2422373561218 : check e2422373561218 [[],[]] .smaller = true := by decide
def e2422373561230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422373561230 : Closed e2422373561230 ∧ code e2422373561230 = 11218466583438 := by decide
theorem cert_e2422373561230 : check e2422373561230 [[],[]] .smaller = true := by decide
def e2422373561242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373561242 : Closed e2422373561242 ∧ code e2422373561242 = 11218466583450 := by decide
theorem cert_e2422373561242 : check e2422373561242 [[],[]] .smaller = true := by decide
def e2422373561310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373561310 : Closed e2422373561310 ∧ code e2422373561310 = 11218466583518 := by decide
theorem cert_e2422373561310 : check e2422373561310 [[],[]] .three = true := by decide
def e2422373561314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422373561314 : Closed e2422373561314 ∧ code e2422373561314 = 11218466583522 := by decide
theorem cert_e2422373561314 : check e2422373561314 [[],[]] .three = true := by decide
def e2422373561326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373561326 : Closed e2422373561326 ∧ code e2422373561326 = 11218466583534 := by decide
theorem cert_e2422373561326 : check e2422373561326 [[],[]] .three = true := by decide
def e2422373562394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422373562394 : Closed e2422373562394 ∧ code e2422373562394 = 11218466584602 := by decide
theorem cert_e2422373562394 : check e2422373562394 [[],[]] .smaller = true := by decide
def e2422373562430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373562430 : Closed e2422373562430 ∧ code e2422373562430 = 11218466584638 := by decide
theorem cert_e2422373562430 : check e2422373562430 [[],[]] .smaller = true := by decide
def e2422373562478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373562478 : Closed e2422373562478 ∧ code e2422373562478 = 11218466584686 := by decide
theorem cert_e2422373562478 : check e2422373562478 [[],[]] .smaller = true := by decide
def e2422373562486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373562486 : Closed e2422373562486 ∧ code e2422373562486 = 11218466584694 := by decide
theorem cert_e2422373562486 : check e2422373562486 [[],[]] .smaller = true := by decide
def e2422373562490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373562490 : Closed e2422373562490 ∧ code e2422373562490 = 11218466584698 := by decide
theorem cert_e2422373562490 : check e2422373562490 [[],[]] .smaller = true := by decide
def e2422373562730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422373562730 : Closed e2422373562730 ∧ code e2422373562730 = 11218466584938 := by decide
theorem cert_e2422373562730 : check e2422373562730 [[],[]] .smaller = true := by decide
def e2422373562754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373562754 : Closed e2422373562754 ∧ code e2422373562754 = 11218466584962 := by decide
theorem cert_e2422373562754 : check e2422373562754 [[],[]] .smaller = true := by decide
def e2422373562766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373562766 : Closed e2422373562766 ∧ code e2422373562766 = 11218466584974 := by decide
theorem cert_e2422373562766 : check e2422373562766 [[],[]] .smaller = true := by decide
def e2422373562778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373562778 : Closed e2422373562778 ∧ code e2422373562778 = 11218466584986 := by decide
theorem cert_e2422373562778 : check e2422373562778 [[],[]] .smaller = true := by decide
def e2422373562822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373562822 : Closed e2422373562822 ∧ code e2422373562822 = 11218466585030 := by decide
theorem cert_e2422373562822 : check e2422373562822 [[],[]] .smaller = true := by decide
def e2422373562846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373562846 : Closed e2422373562846 ∧ code e2422373562846 = 11218466585054 := by decide
theorem cert_e2422373562846 : check e2422373562846 [[],[]] .three = true := by decide
def e2422373562850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373562850 : Closed e2422373562850 ∧ code e2422373562850 = 11218466585058 := by decide
theorem cert_e2422373562850 : check e2422373562850 [[],[]] .smaller = true := by decide
def e2422373562862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373562862 : Closed e2422373562862 ∧ code e2422373562862 = 11218466585070 := by decide
theorem cert_e2422373562862 : check e2422373562862 [[],[]] .smaller = true := by decide
def e2422373562870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373562870 : Closed e2422373562870 ∧ code e2422373562870 = 11218466585078 := by decide
theorem cert_e2422373562870 : check e2422373562870 [[],[]] .three = true := by decide
def e2422373563422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2422373563422 : Closed e2422373563422 ∧ code e2422373563422 = 11218466585630 := by decide
theorem cert_e2422373563422 : check e2422373563422 [[],[]] .smaller = true := by decide
def e2422373563614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373563614 : Closed e2422373563614 ∧ code e2422373563614 = 11218466585822 := by decide
theorem cert_e2422373563614 : check e2422373563614 [[],[]] .three = true := by decide
def e2422373563618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422373563618 : Closed e2422373563618 ∧ code e2422373563618 = 11218466585826 := by decide
theorem cert_e2422373563618 : check e2422373563618 [[],[]] .smaller = true := by decide
def e2422373563630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373563630 : Closed e2422373563630 ∧ code e2422373563630 = 11218466585838 := by decide
theorem cert_e2422373563630 : check e2422373563630 [[],[]] .smaller = true := by decide
def e2422373563638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373563638 : Closed e2422373563638 ∧ code e2422373563638 = 11218466585846 := by decide
theorem cert_e2422373563638 : check e2422373563638 [[],[]] .smaller = true := by decide
def e2422373563642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373563642 : Closed e2422373563642 ∧ code e2422373563642 = 11218466585850 := by decide
theorem cert_e2422373563642 : check e2422373563642 [[],[]] .three = true := by decide
def e2422373563918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373563918 : Closed e2422373563918 ∧ code e2422373563918 = 11218466586126 := by decide
theorem cert_e2422373563918 : check e2422373563918 [[],[]] .three = true := by decide
def e2422373563930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373563930 : Closed e2422373563930 ∧ code e2422373563930 = 11218466586138 := by decide
theorem cert_e2422373563930 : check e2422373563930 [[],[]] .three = true := by decide
def e2422373563966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.var 4)))))))))
theorem wire_e2422373563966 : Closed e2422373563966 ∧ code e2422373563966 = 11218466586174 := by decide
theorem cert_e2422373563966 : check e2422373563966 [[],[]] .three = true := by decide
def e2422373564002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373564002 : Closed e2422373564002 ∧ code e2422373564002 = 11218466586210 := by decide
theorem cert_e2422373564002 : check e2422373564002 [[],[]] .three = true := by decide
def e2422373564014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373564014 : Closed e2422373564014 ∧ code e2422373564014 = 11218466586222 := by decide
theorem cert_e2422373564014 : check e2422373564014 [[],[]] .three = true := by decide
def e2422373564022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373564022 : Closed e2422373564022 ∧ code e2422373564022 = 11218466586230 := by decide
theorem cert_e2422373564022 : check e2422373564022 [[],[]] .three = true := by decide
def e2422373564026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373564026 : Closed e2422373564026 ∧ code e2422373564026 = 11218466586234 := by decide
theorem cert_e2422373564026 : check e2422373564026 [[],[]] .three = true := by decide
def e2422373582254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422373582254 : Closed e2422373582254 ∧ code e2422373582254 = 11218466604462 := by decide
theorem cert_e2422373582254 : check e2422373582254 [[],[]] .three = true := by decide
def e2422373582266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422373582266 : Closed e2422373582266 ∧ code e2422373582266 = 11218466604474 := by decide
theorem cert_e2422373582266 : check e2422373582266 [[],[]] .three = true := by decide
def e2422373582314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422373582314 : Closed e2422373582314 ∧ code e2422373582314 = 11218466604522 := by decide
theorem cert_e2422373582314 : check e2422373582314 [[],[]] .three = true := by decide
def e2422373582446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373582446 : Closed e2422373582446 ∧ code e2422373582446 = 11218466604654 := by decide
theorem cert_e2422373582446 : check e2422373582446 [[],[]] .three = true := by decide
def e2422373582458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373582458 : Closed e2422373582458 ∧ code e2422373582458 = 11218466604666 := by decide
theorem cert_e2422373582458 : check e2422373582458 [[],[]] .three = true := by decide
def e2422373582622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422373582622 : Closed e2422373582622 ∧ code e2422373582622 = 11218466604830 := by decide
theorem cert_e2422373582622 : check e2422373582622 [[],[]] .three = true := by decide
def e2422373582734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422373582734 : Closed e2422373582734 ∧ code e2422373582734 = 11218466604942 := by decide
theorem cert_e2422373582734 : check e2422373582734 [[],[]] .three = true := by decide
def e2422373582746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373582746 : Closed e2422373582746 ∧ code e2422373582746 = 11218466604954 := by decide
theorem cert_e2422373582746 : check e2422373582746 [[],[]] .three = true := by decide
def e2422373582782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e2422373582782 : Closed e2422373582782 ∧ code e2422373582782 = 11218466604990 := by decide
theorem cert_e2422373582782 : check e2422373582782 [[],[]] .three = true := by decide
end Blc.Floor43
