import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405685464686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2405685464686 : Closed e2405685464686 ∧ code e2405685464686 = 11201778486894 := by decide
theorem cert_e2405685464686 : check e2405685464686 [[],[],[.under]] .smaller = true := by decide
def e2405685464698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2405685464698 : Closed e2405685464698 ∧ code e2405685464698 = 11201778486906 := by decide
theorem cert_e2405685464698 : check e2405685464698 [[],[],[.under]] .smaller = true := by decide
def e2405685464886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2405685464886 : Closed e2405685464886 ∧ code e2405685464886 = 11201778487094 := by decide
theorem cert_e2405685464886 : check e2405685464886 [[],[],[.under]] .smaller = true := by decide
def e2405685464890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2405685464890 : Closed e2405685464890 ∧ code e2405685464890 = 11201778487098 := by decide
theorem cert_e2405685464890 : check e2405685464890 [[],[],[.under]] .smaller = true := by decide
def e2405900335130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900335130 : Closed e2405900335130 ∧ code e2405900335130 = 11201993357338 := by decide
theorem cert_e2405900335130 : check e2405900335130 [[]] .width = true := by decide
def e2405900343322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900343322 : Closed e2405900343322 ∧ code e2405900343322 = 11201993365530 := by decide
theorem cert_e2405900343322 : check e2405900343322 [[]] .width = true := by decide
def e2405900400666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900400666 : Closed e2405900400666 ∧ code e2405900400666 = 11201993422874 := by decide
theorem cert_e2405900400666 : check e2405900400666 [[]] .width = true := by decide
def e2405900412954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900412954 : Closed e2405900412954 ∧ code e2405900412954 = 11201993435162 := by decide
theorem cert_e2405900412954 : check e2405900412954 [[]] .width = true := by decide
def e2405900414490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900414490 : Closed e2405900414490 ∧ code e2405900414490 = 11201993436698 := by decide
theorem cert_e2405900414490 : check e2405900414490 [[]] .width = true := by decide
def e2405900441626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900441626 : Closed e2405900441626 ∧ code e2405900441626 = 11201993463834 := by decide
theorem cert_e2405900441626 : check e2405900441626 [[]] .width = true := by decide
def e2405900445722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900445722 : Closed e2405900445722 ∧ code e2405900445722 = 11201993467930 := by decide
theorem cert_e2405900445722 : check e2405900445722 [[]] .width = true := by decide
def e2405900447258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900447258 : Closed e2405900447258 ∧ code e2405900447258 = 11201993469466 := by decide
theorem cert_e2405900447258 : check e2405900447258 [[]] .width = true := by decide
def e2405900449306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900449306 : Closed e2405900449306 ∧ code e2405900449306 = 11201993471514 := by decide
theorem cert_e2405900449306 : check e2405900449306 [[]] .width = true := by decide
def e2405900662810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900662810 : Closed e2405900662810 ∧ code e2405900662810 = 11201993685018 := by decide
theorem cert_e2405900662810 : check e2405900662810 [[]] .width = true := by decide
def e2405900675098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900675098 : Closed e2405900675098 ∧ code e2405900675098 = 11201993697306 := by decide
theorem cert_e2405900675098 : check e2405900675098 [[]] .width = true := by decide
def e2405900676634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900676634 : Closed e2405900676634 ∧ code e2405900676634 = 11201993698842 := by decide
theorem cert_e2405900676634 : check e2405900676634 [[]] .width = true := by decide
def e2405900724250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900724250 : Closed e2405900724250 ∧ code e2405900724250 = 11201993746458 := by decide
theorem cert_e2405900724250 : check e2405900724250 [[]] .width = true := by decide
def e2405900725786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900725786 : Closed e2405900725786 ∧ code e2405900725786 = 11201993747994 := by decide
theorem cert_e2405900725786 : check e2405900725786 [[]] .width = true := by decide
def e2405900728858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900728858 : Closed e2405900728858 ∧ code e2405900728858 = 11201993751066 := by decide
theorem cert_e2405900728858 : check e2405900728858 [[]] .width = true := by decide
def e2405900834842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900834842 : Closed e2405900834842 ∧ code e2405900834842 = 11201993857050 := by decide
theorem cert_e2405900834842 : check e2405900834842 [[]] .width = true := by decide
def e2405900838938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900838938 : Closed e2405900838938 ∧ code e2405900838938 = 11201993861146 := by decide
theorem cert_e2405900838938 : check e2405900838938 [[]] .width = true := by decide
def e2405900840474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900840474 : Closed e2405900840474 ∧ code e2405900840474 = 11201993862682 := by decide
theorem cert_e2405900840474 : check e2405900840474 [[]] .width = true := by decide
def e2405900842522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900842522 : Closed e2405900842522 ∧ code e2405900842522 = 11201993864730 := by decide
theorem cert_e2405900842522 : check e2405900842522 [[]] .width = true := by decide
def e2405900855322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405900855322 : Closed e2405900855322 ∧ code e2405900855322 = 11201993877530 := by decide
theorem cert_e2405900855322 : check e2405900855322 [[]] .width = true := by decide
def e2405900856858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900856858 : Closed e2405900856858 ∧ code e2405900856858 = 11201993879066 := by decide
theorem cert_e2405900856858 : check e2405900856858 [[]] .width = true := by decide
def e2405900859930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900859930 : Closed e2405900859930 ∧ code e2405900859930 = 11201993882138 := by decide
theorem cert_e2405900859930 : check e2405900859930 [[]] .width = true := by decide
def e2405900867098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900867098 : Closed e2405900867098 ∧ code e2405900867098 = 11201993889306 := by decide
theorem cert_e2405900867098 : check e2405900867098 [[]] .width = true := by decide
def e2405900868122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405900868122 : Closed e2405900868122 ∧ code e2405900868122 = 11201993890330 := by decide
theorem cert_e2405900868122 : check e2405900868122 [[]] .width = true := by decide
def e2405901711386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405901711386 : Closed e2405901711386 ∧ code e2405901711386 = 11201994733594 := by decide
theorem cert_e2405901711386 : check e2405901711386 [[]] .width = true := by decide
def e2405901723674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405901723674 : Closed e2405901723674 ∧ code e2405901723674 = 11201994745882 := by decide
theorem cert_e2405901723674 : check e2405901723674 [[]] .width = true := by decide
def e2405901725210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405901725210 : Closed e2405901725210 ∧ code e2405901725210 = 11201994747418 := by decide
theorem cert_e2405901725210 : check e2405901725210 [[]] .width = true := by decide
def e2405901772826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405901772826 : Closed e2405901772826 ∧ code e2405901772826 = 11201994795034 := by decide
theorem cert_e2405901772826 : check e2405901772826 [[]] .width = true := by decide
def e2405901774362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405901774362 : Closed e2405901774362 ∧ code e2405901774362 = 11201994796570 := by decide
theorem cert_e2405901774362 : check e2405901774362 [[]] .width = true := by decide
def e2405901777434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405901777434 : Closed e2405901777434 ∧ code e2405901777434 = 11201994799642 := by decide
theorem cert_e2405901777434 : check e2405901777434 [[]] .width = true := by decide
def e2405901969434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405901969434 : Closed e2405901969434 ∧ code e2405901969434 = 11201994991642 := by decide
theorem cert_e2405901969434 : check e2405901969434 [[]] .width = true := by decide
def e2405901970970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405901970970 : Closed e2405901970970 ∧ code e2405901970970 = 11201994993178 := by decide
private def t_e2405901970970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405901970970 : ¬ IsSelfInterpreter e2405901970970 :=
  wSource (t := t_e2405901970970) (replay_sound (ps := []) (t := e2405901970970) (by decide)) (by decide)
def e2405901974042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405901974042 : Closed e2405901974042 ∧ code e2405901974042 = 11201994996250 := by decide
private def t_e2405901974042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405901974042 : ¬ IsSelfInterpreter e2405901974042 :=
  wSource (t := t_e2405901974042) (replay_sound (ps := []) (t := e2405901974042) (by decide)) (by decide)
def e2405901986330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405901986330 : Closed e2405901986330 ∧ code e2405901986330 = 11201995008538 := by decide
private def t_e2405901986330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405901986330 : ¬ IsSelfInterpreter e2405901986330 :=
  wSource (t := t_e2405901986330) (replay_sound (ps := []) (t := e2405901986330) (by decide)) (by decide)
def e2405902407706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405902407706 : Closed e2405902407706 ∧ code e2405902407706 = 11201995429914 := by decide
theorem cert_e2405902407706 : check e2405902407706 [[]] .width = true := by decide
def e2405902411802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405902411802 : Closed e2405902411802 ∧ code e2405902411802 = 11201995434010 := by decide
theorem cert_e2405902411802 : check e2405902411802 [[]] .width = true := by decide
def e2405902413338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902413338 : Closed e2405902413338 ∧ code e2405902413338 = 11201995435546 := by decide
theorem cert_e2405902413338 : check e2405902413338 [[]] .width = true := by decide
def e2405902415386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902415386 : Closed e2405902415386 ∧ code e2405902415386 = 11201995437594 := by decide
theorem cert_e2405902415386 : check e2405902415386 [[]] .width = true := by decide
def e2405902428186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405902428186 : Closed e2405902428186 ∧ code e2405902428186 = 11201995450394 := by decide
theorem cert_e2405902428186 : check e2405902428186 [[]] .width = true := by decide
def e2405902429722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902429722 : Closed e2405902429722 ∧ code e2405902429722 = 11201995451930 := by decide
theorem cert_e2405902429722 : check e2405902429722 [[]] .width = true := by decide
def e2405902432794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902432794 : Closed e2405902432794 ∧ code e2405902432794 = 11201995455002 := by decide
theorem cert_e2405902432794 : check e2405902432794 [[]] .width = true := by decide
def e2405902439962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902439962 : Closed e2405902439962 ∧ code e2405902439962 = 11201995462170 := by decide
theorem cert_e2405902439962 : check e2405902439962 [[]] .width = true := by decide
def e2405902440986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902440986 : Closed e2405902440986 ∧ code e2405902440986 = 11201995463194 := by decide
theorem cert_e2405902440986 : check e2405902440986 [[]] .width = true := by decide
def e2405902493722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405902493722 : Closed e2405902493722 ∧ code e2405902493722 = 11201995515930 := by decide
theorem cert_e2405902493722 : check e2405902493722 [[]] .width = true := by decide
def e2405902495258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902495258 : Closed e2405902495258 ∧ code e2405902495258 = 11201995517466 := by decide
private def t_e2405902495258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405902495258 : ¬ IsSelfInterpreter e2405902495258 :=
  wSource (t := t_e2405902495258) (replay_sound (ps := []) (t := e2405902495258) (by decide)) (by decide)
def e2405902498330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902498330 : Closed e2405902498330 ∧ code e2405902498330 = 11201995520538 := by decide
private def t_e2405902498330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405902498330 : ¬ IsSelfInterpreter e2405902498330 :=
  wSource (t := t_e2405902498330) (replay_sound (ps := []) (t := e2405902498330) (by decide)) (by decide)
def e2405902510618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902510618 : Closed e2405902510618 ∧ code e2405902510618 = 11201995532826 := by decide
private def t_e2405902510618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405902510618 : ¬ IsSelfInterpreter e2405902510618 :=
  wSource (t := t_e2405902510618) (replay_sound (ps := []) (t := e2405902510618) (by decide)) (by decide)
def e2405902538266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902538266 : Closed e2405902538266 ∧ code e2405902538266 = 11201995560474 := by decide
private def t_e2405902538266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405902538266 : ¬ IsSelfInterpreter e2405902538266 :=
  wSource (t := t_e2405902538266) (replay_sound (ps := []) (t := e2405902538266) (by decide)) (by decide)
def e2405902539290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902539290 : Closed e2405902539290 ∧ code e2405902539290 = 11201995561498 := by decide
private def t_e2405902539290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405902539290 : ¬ IsSelfInterpreter e2405902539290 :=
  wSource (t := t_e2405902539290) (replay_sound (ps := []) (t := e2405902539290) (by decide)) (by decide)
def e2405902543386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405902543386 : Closed e2405902543386 ∧ code e2405902543386 = 11201995565594 := by decide
private def t_e2405902543386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405902543386 : ¬ IsSelfInterpreter e2405902543386 :=
  wSource (t := t_e2405902543386) (replay_sound (ps := []) (t := e2405902543386) (by decide)) (by decide)
def e2405903480858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405903480858 : Closed e2405903480858 ∧ code e2405903480858 = 11201996503066 := by decide
theorem cert_e2405903480858 : check e2405903480858 [[]] .width = true := by decide
def e2405903489050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405903489050 : Closed e2405903489050 ∧ code e2405903489050 = 11201996511258 := by decide
theorem cert_e2405903489050 : check e2405903489050 [[]] .width = true := by decide
def e2405904605210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405904605210 : Closed e2405904605210 ∧ code e2405904605210 = 11201997627418 := by decide
theorem cert_e2405904605210 : check e2405904605210 [[]] .width = true := by decide
def e2405904605302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405904605302 : Closed e2405904605302 ∧ code e2405904605302 = 11201997627510 := by decide
theorem cert_e2405904605302 : check e2405904605302 [[]] .width = true := by decide
def e2405904605546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405904605546 : Closed e2405904605546 ∧ code e2405904605546 = 11201997627754 := by decide
theorem cert_e2405904605546 : check e2405904605546 [[]] .width = true := by decide
def e2405904605594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405904605594 : Closed e2405904605594 ∧ code e2405904605594 = 11201997627802 := by decide
theorem cert_e2405904605594 : check e2405904605594 [[]] .width = true := by decide
def e2405904637978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405904637978 : Closed e2405904637978 ∧ code e2405904637978 = 11201997660186 := by decide
theorem cert_e2405904637978 : check e2405904637978 [[]] .width = true := by decide
def e2405904638070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405904638070 : Closed e2405904638070 ∧ code e2405904638070 = 11201997660278 := by decide
theorem cert_e2405904638070 : check e2405904638070 [[]] .width = true := by decide
def e2405904638314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405904638314 : Closed e2405904638314 ∧ code e2405904638314 = 11201997660522 := by decide
theorem cert_e2405904638314 : check e2405904638314 [[]] .width = true := by decide
def e2405904638362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405904638362 : Closed e2405904638362 ∧ code e2405904638362 = 11201997660570 := by decide
theorem cert_e2405904638362 : check e2405904638362 [[]] .width = true := by decide
def e2405904904390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405904904390 : Closed e2405904904390 ∧ code e2405904904390 = 11201997926598 := by decide
theorem cert_e2405904904390 : check e2405904904390 [[]] .width = true := by decide
def e2405904920774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405904920774 : Closed e2405904920774 ∧ code e2405904920774 = 11201997942982 := by decide
theorem cert_e2405904920774 : check e2405904920774 [[]] .width = true := by decide
def e2405905035462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405905035462 : Closed e2405905035462 ∧ code e2405905035462 = 11201998057670 := by decide
theorem cert_e2405905035462 : check e2405905035462 [[]] .width = true := by decide
def e2405905053722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405905053722 : Closed e2405905053722 ∧ code e2405905053722 = 11201998075930 := by decide
theorem cert_e2405905053722 : check e2405905053722 [[]] .width = true := by decide
def e2405905060038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405905060038 : Closed e2405905060038 ∧ code e2405905060038 = 11201998082246 := by decide
theorem cert_e2405905060038 : check e2405905060038 [[]] .width = true := by decide
def e2405905061914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405905061914 : Closed e2405905061914 ∧ code e2405905061914 = 11201998084122 := by decide
theorem cert_e2405905061914 : check e2405905061914 [[]] .width = true := by decide
def e2405905117382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405905117382 : Closed e2405905117382 ∧ code e2405905117382 = 11201998139590 := by decide
theorem cert_e2405905117382 : check e2405905117382 [[]] .width = true := by decide
def e2405905125574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405905125574 : Closed e2405905125574 ∧ code e2405905125574 = 11201998147782 := by decide
theorem cert_e2405905125574 : check e2405905125574 [[]] .width = true := by decide
def e2405906626586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906626586 : Closed e2405906626586 ∧ code e2405906626586 = 11201999648794 := by decide
theorem cert_e2405906626586 : check e2405906626586 [[]] .width = true := by decide
def e2405906634778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906634778 : Closed e2405906634778 ∧ code e2405906634778 = 11201999656986 := by decide
theorem cert_e2405906634778 : check e2405906634778 [[]] .width = true := by decide
def e2405906692122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906692122 : Closed e2405906692122 ∧ code e2405906692122 = 11201999714330 := by decide
theorem cert_e2405906692122 : check e2405906692122 [[]] .width = true := by decide
def e2405906704410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906704410 : Closed e2405906704410 ∧ code e2405906704410 = 11201999726618 := by decide
theorem cert_e2405906704410 : check e2405906704410 [[]] .width = true := by decide
def e2405906705946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405906705946 : Closed e2405906705946 ∧ code e2405906705946 = 11201999728154 := by decide
theorem cert_e2405906705946 : check e2405906705946 [[]] .width = true := by decide
def e2405906733082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906733082 : Closed e2405906733082 ∧ code e2405906733082 = 11201999755290 := by decide
theorem cert_e2405906733082 : check e2405906733082 [[]] .width = true := by decide
def e2405906737178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906737178 : Closed e2405906737178 ∧ code e2405906737178 = 11201999759386 := by decide
theorem cert_e2405906737178 : check e2405906737178 [[]] .width = true := by decide
def e2405906738714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405906738714 : Closed e2405906738714 ∧ code e2405906738714 = 11201999760922 := by decide
theorem cert_e2405906738714 : check e2405906738714 [[]] .width = true := by decide
def e2405906740762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405906740762 : Closed e2405906740762 ∧ code e2405906740762 = 11201999762970 := by decide
theorem cert_e2405906740762 : check e2405906740762 [[]] .width = true := by decide
def e2405906954266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906954266 : Closed e2405906954266 ∧ code e2405906954266 = 11201999976474 := by decide
theorem cert_e2405906954266 : check e2405906954266 [[]] .width = true := by decide
def e2405906966554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405906966554 : Closed e2405906966554 ∧ code e2405906966554 = 11201999988762 := by decide
theorem cert_e2405906966554 : check e2405906966554 [[]] .width = true := by decide
def e2405906968090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405906968090 : Closed e2405906968090 ∧ code e2405906968090 = 11201999990298 := by decide
theorem cert_e2405906968090 : check e2405906968090 [[]] .width = true := by decide
def e2405907015706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405907015706 : Closed e2405907015706 ∧ code e2405907015706 = 11202000037914 := by decide
theorem cert_e2405907015706 : check e2405907015706 [[]] .width = true := by decide
def e2405907017242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907017242 : Closed e2405907017242 ∧ code e2405907017242 = 11202000039450 := by decide
theorem cert_e2405907017242 : check e2405907017242 [[]] .width = true := by decide
def e2405907020314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907020314 : Closed e2405907020314 ∧ code e2405907020314 = 11202000042522 := by decide
theorem cert_e2405907020314 : check e2405907020314 [[]] .width = true := by decide
def e2405907126298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405907126298 : Closed e2405907126298 ∧ code e2405907126298 = 11202000148506 := by decide
theorem cert_e2405907126298 : check e2405907126298 [[]] .width = true := by decide
def e2405907130394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405907130394 : Closed e2405907130394 ∧ code e2405907130394 = 11202000152602 := by decide
theorem cert_e2405907130394 : check e2405907130394 [[]] .width = true := by decide
def e2405907131930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907131930 : Closed e2405907131930 ∧ code e2405907131930 = 11202000154138 := by decide
theorem cert_e2405907131930 : check e2405907131930 [[]] .width = true := by decide
def e2405907133978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907133978 : Closed e2405907133978 ∧ code e2405907133978 = 11202000156186 := by decide
theorem cert_e2405907133978 : check e2405907133978 [[]] .width = true := by decide
def e2405907146778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405907146778 : Closed e2405907146778 ∧ code e2405907146778 = 11202000168986 := by decide
theorem cert_e2405907146778 : check e2405907146778 [[]] .width = true := by decide
def e2405907148314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907148314 : Closed e2405907148314 ∧ code e2405907148314 = 11202000170522 := by decide
theorem cert_e2405907148314 : check e2405907148314 [[]] .width = true := by decide
def e2405907151386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907151386 : Closed e2405907151386 ∧ code e2405907151386 = 11202000173594 := by decide
theorem cert_e2405907151386 : check e2405907151386 [[]] .width = true := by decide
def e2405907158554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907158554 : Closed e2405907158554 ∧ code e2405907158554 = 11202000180762 := by decide
theorem cert_e2405907158554 : check e2405907158554 [[]] .width = true := by decide
def e2405907159578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405907159578 : Closed e2405907159578 ∧ code e2405907159578 = 11202000181786 := by decide
theorem cert_e2405907159578 : check e2405907159578 [[]] .width = true := by decide
def e2405907787974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405907787974 : Closed e2405907787974 ∧ code e2405907787974 = 11202000810182 := by decide
theorem cert_e2405907787974 : check e2405907787974 [[]] .width = true := by decide
def e2405907804358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405907804358 : Closed e2405907804358 ∧ code e2405907804358 = 11202000826566 := by decide
theorem cert_e2405907804358 : check e2405907804358 [[]] .width = true := by decide
def e2405908199450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908199450 : Closed e2405908199450 ∧ code e2405908199450 = 11202001221658 := by decide
theorem cert_e2405908199450 : check e2405908199450 [[]] .width = true := by decide
def e2405908207642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908207642 : Closed e2405908207642 ∧ code e2405908207642 = 11202001229850 := by decide
theorem cert_e2405908207642 : check e2405908207642 [[]] .width = true := by decide
def e2405908264986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908264986 : Closed e2405908264986 ∧ code e2405908264986 = 11202001287194 := by decide
theorem cert_e2405908264986 : check e2405908264986 [[]] .width = true := by decide
def e2405908277274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908277274 : Closed e2405908277274 ∧ code e2405908277274 = 11202001299482 := by decide
theorem cert_e2405908277274 : check e2405908277274 [[]] .width = true := by decide
def e2405908278810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405908278810 : Closed e2405908278810 ∧ code e2405908278810 = 11202001301018 := by decide
theorem cert_e2405908278810 : check e2405908278810 [[]] .width = true := by decide
def e2405908305946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908305946 : Closed e2405908305946 ∧ code e2405908305946 = 11202001328154 := by decide
theorem cert_e2405908305946 : check e2405908305946 [[]] .width = true := by decide
def e2405908310042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908310042 : Closed e2405908310042 ∧ code e2405908310042 = 11202001332250 := by decide
theorem cert_e2405908310042 : check e2405908310042 [[]] .width = true := by decide
def e2405908311578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405908311578 : Closed e2405908311578 ∧ code e2405908311578 = 11202001333786 := by decide
theorem cert_e2405908311578 : check e2405908311578 [[]] .width = true := by decide
def e2405908313626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405908313626 : Closed e2405908313626 ∧ code e2405908313626 = 11202001335834 := by decide
theorem cert_e2405908313626 : check e2405908313626 [[]] .width = true := by decide
def e2405908592666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908592666 : Closed e2405908592666 ∧ code e2405908592666 = 11202001614874 := by decide
theorem cert_e2405908592666 : check e2405908592666 [[]] .width = true := by decide
def e2405908600858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908600858 : Closed e2405908600858 ∧ code e2405908600858 = 11202001623066 := by decide
theorem cert_e2405908600858 : check e2405908600858 [[]] .width = true := by decide
def e2405908934854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405908934854 : Closed e2405908934854 ∧ code e2405908934854 = 11202001957062 := by decide
theorem cert_e2405908934854 : check e2405908934854 [[]] .width = true := by decide
def e2405908985882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908985882 : Closed e2405908985882 ∧ code e2405908985882 = 11202002008090 := by decide
theorem cert_e2405908985882 : check e2405908985882 [[]] .width = true := by decide
def e2405908998170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405908998170 : Closed e2405908998170 ∧ code e2405908998170 = 11202002020378 := by decide
theorem cert_e2405908998170 : check e2405908998170 [[]] .width = true := by decide
def e2405908999706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405908999706 : Closed e2405908999706 ∧ code e2405908999706 = 11202002021914 := by decide
theorem cert_e2405908999706 : check e2405908999706 [[]] .width = true := by decide
def e2405909102618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405909102618 : Closed e2405909102618 ∧ code e2405909102618 = 11202002124826 := by decide
theorem cert_e2405909102618 : check e2405909102618 [[]] .width = true := by decide
def e2405909102710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405909102710 : Closed e2405909102710 ∧ code e2405909102710 = 11202002124918 := by decide
theorem cert_e2405909102710 : check e2405909102710 [[]] .width = true := by decide
def e2405909102954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405909102954 : Closed e2405909102954 ∧ code e2405909102954 = 11202002125162 := by decide
theorem cert_e2405909102954 : check e2405909102954 [[]] .width = true := by decide
def e2405909103002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405909103002 : Closed e2405909103002 ∧ code e2405909103002 = 11202002125210 := by decide
theorem cert_e2405909103002 : check e2405909103002 [[]] .width = true := by decide
def e2405909104010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405909104010 : Closed e2405909104010 ∧ code e2405909104010 = 11202002126218 := by decide
theorem cert_e2405909104010 : check e2405909104010 [[]] .width = true := by decide
def e2405909104034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405909104034 : Closed e2405909104034 ∧ code e2405909104034 = 11202002126242 := by decide
theorem cert_e2405909104034 : check e2405909104034 [[]] .width = true := by decide
def e2405909104142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405909104142 : Closed e2405909104142 ∧ code e2405909104142 = 11202002126350 := by decide
theorem cert_e2405909104142 : check e2405909104142 [[]] .width = true := by decide
def e2405909104154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405909104154 : Closed e2405909104154 ∧ code e2405909104154 = 11202002126362 := by decide
theorem cert_e2405909104154 : check e2405909104154 [[]] .width = true := by decide
def e2405909104226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405909104226 : Closed e2405909104226 ∧ code e2405909104226 = 11202002126434 := by decide
theorem cert_e2405909104226 : check e2405909104226 [[]] .width = true := by decide
def e2405909164230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405909164230 : Closed e2405909164230 ∧ code e2405909164230 = 11202002186438 := by decide
theorem cert_e2405909164230 : check e2405909164230 [[]] .width = true := by decide
def e2405909190682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405909190682 : Closed e2405909190682 ∧ code e2405909190682 = 11202002212890 := by decide
theorem cert_e2405909190682 : check e2405909190682 [[]] .width = true := by decide
def e2405909194778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405909194778 : Closed e2405909194778 ∧ code e2405909194778 = 11202002216986 := by decide
theorem cert_e2405909194778 : check e2405909194778 [[]] .width = true := by decide
def e2405909196314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405909196314 : Closed e2405909196314 ∧ code e2405909196314 = 11202002218522 := by decide
theorem cert_e2405909196314 : check e2405909196314 [[]] .width = true := by decide
def e2405909198362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405909198362 : Closed e2405909198362 ∧ code e2405909198362 = 11202002220570 := by decide
theorem cert_e2405909198362 : check e2405909198362 [[]] .width = true := by decide
def e2405909233690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405909233690 : Closed e2405909233690 ∧ code e2405909233690 = 11202002255898 := by decide
theorem cert_e2405909233690 : check e2405909233690 [[]] .width = true := by decide
def e2405909233782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405909233782 : Closed e2405909233782 ∧ code e2405909233782 = 11202002255990 := by decide
theorem cert_e2405909233782 : check e2405909233782 [[]] .width = true := by decide
def e2405909234026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405909234026 : Closed e2405909234026 ∧ code e2405909234026 = 11202002256234 := by decide
theorem cert_e2405909234026 : check e2405909234026 [[]] .width = true := by decide
def e2405909234074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405909234074 : Closed e2405909234074 ∧ code e2405909234074 = 11202002256282 := by decide
theorem cert_e2405909234074 : check e2405909234074 [[]] .width = true := by decide
def e2405909235082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405909235082 : Closed e2405909235082 ∧ code e2405909235082 = 11202002257290 := by decide
theorem cert_e2405909235082 : check e2405909235082 [[]] .width = true := by decide
def e2405909235106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405909235106 : Closed e2405909235106 ∧ code e2405909235106 = 11202002257314 := by decide
theorem cert_e2405909235106 : check e2405909235106 [[]] .width = true := by decide
def e2405909235214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405909235214 : Closed e2405909235214 ∧ code e2405909235214 = 11202002257422 := by decide
theorem cert_e2405909235214 : check e2405909235214 [[]] .width = true := by decide
def e2405909235226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405909235226 : Closed e2405909235226 ∧ code e2405909235226 = 11202002257434 := by decide
theorem cert_e2405909235226 : check e2405909235226 [[]] .width = true := by decide
def e2405909235298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405909235298 : Closed e2405909235298 ∧ code e2405909235298 = 11202002257506 := by decide
theorem cert_e2405909235298 : check e2405909235298 [[]] .width = true := by decide
def e2405909444634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405909444634 : Closed e2405909444634 ∧ code e2405909444634 = 11202002466842 := by decide
theorem cert_e2405909444634 : check e2405909444634 [[]] .width = true := by decide
def e2405909585946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405909585946 : Closed e2405909585946 ∧ code e2405909585946 = 11202002608154 := by decide
theorem cert_e2405909585946 : check e2405909585946 [[]] .width = true := by decide
def e2405909586038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405909586038 : Closed e2405909586038 ∧ code e2405909586038 = 11202002608246 := by decide
theorem cert_e2405909586038 : check e2405909586038 [[]] .width = true := by decide
def e2405909586282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405909586282 : Closed e2405909586282 ∧ code e2405909586282 = 11202002608490 := by decide
theorem cert_e2405909586282 : check e2405909586282 [[]] .width = true := by decide
def e2405909586330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405909586330 : Closed e2405909586330 ∧ code e2405909586330 = 11202002608538 := by decide
theorem cert_e2405909586330 : check e2405909586330 [[]] .width = true := by decide
def e2405909622982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405909622982 : Closed e2405909622982 ∧ code e2405909622982 = 11202002645190 := by decide
theorem cert_e2405909622982 : check e2405909622982 [[]] .width = true := by decide
def e2405909641242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405909641242 : Closed e2405909641242 ∧ code e2405909641242 = 11202002663450 := by decide
theorem cert_e2405909641242 : check e2405909641242 [[]] .width = true := by decide
def e2405909647558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405909647558 : Closed e2405909647558 ∧ code e2405909647558 = 11202002669766 := by decide
theorem cert_e2405909647558 : check e2405909647558 [[]] .width = true := by decide
def e2405909837850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405909837850 : Closed e2405909837850 ∧ code e2405909837850 = 11202002860058 := by decide
theorem cert_e2405909837850 : check e2405909837850 [[]] .width = true := by decide
def e2405909850138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405909850138 : Closed e2405909850138 ∧ code e2405909850138 = 11202002872346 := by decide
theorem cert_e2405909850138 : check e2405909850138 [[]] .width = true := by decide
def e2405909851674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405909851674 : Closed e2405909851674 ∧ code e2405909851674 = 11202002873882 := by decide
theorem cert_e2405909851674 : check e2405909851674 [[]] .width = true := by decide
def e2405909899290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405909899290 : Closed e2405909899290 ∧ code e2405909899290 = 11202002921498 := by decide
theorem cert_e2405909899290 : check e2405909899290 [[]] .width = true := by decide
def e2405909900826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405909900826 : Closed e2405909900826 ∧ code e2405909900826 = 11202002923034 := by decide
theorem cert_e2405909900826 : check e2405909900826 [[]] .width = true := by decide
def e2405909903898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405909903898 : Closed e2405909903898 ∧ code e2405909903898 = 11202002926106 := by decide
theorem cert_e2405909903898 : check e2405909903898 [[]] .width = true := by decide
def e2405909983430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405909983430 : Closed e2405909983430 ∧ code e2405909983430 = 11202003005638 := by decide
theorem cert_e2405909983430 : check e2405909983430 [[]] .width = true := by decide
def e2405910034458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910034458 : Closed e2405910034458 ∧ code e2405910034458 = 11202003056666 := by decide
theorem cert_e2405910034458 : check e2405910034458 [[]] .width = true := by decide
def e2405910046746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910046746 : Closed e2405910046746 ∧ code e2405910046746 = 11202003068954 := by decide
theorem cert_e2405910046746 : check e2405910046746 [[]] .width = true := by decide
def e2405910048282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910048282 : Closed e2405910048282 ∧ code e2405910048282 = 11202003070490 := by decide
theorem cert_e2405910048282 : check e2405910048282 [[]] .width = true := by decide
def e2405910151194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405910151194 : Closed e2405910151194 ∧ code e2405910151194 = 11202003173402 := by decide
theorem cert_e2405910151194 : check e2405910151194 [[]] .width = true := by decide
def e2405910151286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405910151286 : Closed e2405910151286 ∧ code e2405910151286 = 11202003173494 := by decide
theorem cert_e2405910151286 : check e2405910151286 [[]] .width = true := by decide
def e2405910151530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405910151530 : Closed e2405910151530 ∧ code e2405910151530 = 11202003173738 := by decide
theorem cert_e2405910151530 : check e2405910151530 [[]] .width = true := by decide
def e2405910151578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405910151578 : Closed e2405910151578 ∧ code e2405910151578 = 11202003173786 := by decide
theorem cert_e2405910151578 : check e2405910151578 [[]] .width = true := by decide
def e2405910152586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405910152586 : Closed e2405910152586 ∧ code e2405910152586 = 11202003174794 := by decide
theorem cert_e2405910152586 : check e2405910152586 [[]] .width = true := by decide
def e2405910152610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405910152610 : Closed e2405910152610 ∧ code e2405910152610 = 11202003174818 := by decide
theorem cert_e2405910152610 : check e2405910152610 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405901970970
#print axioms Blc.Floor43.cert_e2405901974042
#print axioms Blc.Floor43.cert_e2405901986330
#print axioms Blc.Floor43.cert_e2405902495258
#print axioms Blc.Floor43.cert_e2405902498330
#print axioms Blc.Floor43.cert_e2405902510618
#print axioms Blc.Floor43.cert_e2405902538266
#print axioms Blc.Floor43.cert_e2405902539290
#print axioms Blc.Floor43.cert_e2405902543386
