import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2246523385370 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246523385370 : Closed e2246523385370 ∧ code e2246523385370 = 11042616407578 := by decide
theorem cert_e2246523385370 : check e2246523385370 [[]] .width = true := by decide
def e2246523404486 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246523404486 : Closed e2246523404486 ∧ code e2246523404486 = 11042616426694 := by decide
theorem cert_e2246523404486 : check e2246523404486 [[]] .width = true := by decide
def e2247213413914 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247213413914 : Closed e2247213413914 ∧ code e2247213413914 = 11043306436122 := by decide
theorem cert_e2247213413914 : check e2247213413914 [[]] .width = true := by decide
def e2247213430298 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247213430298 : Closed e2247213430298 ∧ code e2247213430298 = 11043306452506 := by decide
theorem cert_e2247213430298 : check e2247213430298 [[]] .width = true := by decide
def e2247213544986 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247213544986 : Closed e2247213544986 ∧ code e2247213544986 = 11043306567194 := by decide
theorem cert_e2247213544986 : check e2247213544986 [[]] .width = true := by decide
def e2247213569562 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247213569562 : Closed e2247213569562 ∧ code e2247213569562 = 11043306591770 := by decide
theorem cert_e2247213569562 : check e2247213569562 [[]] .width = true := by decide
def e2247213626906 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247213626906 : Closed e2247213626906 ∧ code e2247213626906 = 11043306649114 := by decide
theorem cert_e2247213626906 : check e2247213626906 [[]] .width = true := by decide
def e2247213635098 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247213635098 : Closed e2247213635098 ∧ code e2247213635098 = 11043306657306 := by decide
theorem cert_e2247213635098 : check e2247213635098 [[]] .width = true := by decide
def e2247214200346 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247214200346 : Closed e2247214200346 ∧ code e2247214200346 = 11043307222554 := by decide
theorem cert_e2247214200346 : check e2247214200346 [[]] .width = true := by decide
def e2247214216730 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247214216730 : Closed e2247214216730 ∧ code e2247214216730 = 11043307238938 := by decide
theorem cert_e2247214216730 : check e2247214216730 [[]] .width = true := by decide
def e2247214986778 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247214986778 : Closed e2247214986778 ∧ code e2247214986778 = 11043308008986 := by decide
theorem cert_e2247214986778 : check e2247214986778 [[]] .width = true := by decide
def e2247215011354 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247215011354 : Closed e2247215011354 ∧ code e2247215011354 = 11043308033562 := by decide
theorem cert_e2247215011354 : check e2247215011354 [[]] .width = true := by decide
def e2247215396378 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247215396378 : Closed e2247215396378 ∧ code e2247215396378 = 11043308418586 := by decide
theorem cert_e2247215396378 : check e2247215396378 [[]] .width = true := by decide
def e2247215404570 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247215404570 : Closed e2247215404570 ∧ code e2247215404570 = 11043308426778 := by decide
theorem cert_e2247215404570 : check e2247215404570 [[]] .width = true := by decide
def e2247258500634 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258500634 : Closed e2247258500634 ∧ code e2247258500634 = 11043351522842 := by decide
theorem cert_e2247258500634 : check e2247258500634 [[]] .width = true := by decide
def e2247258502682 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258502682 : Closed e2247258502682 ∧ code e2247258502682 = 11043351524890 := by decide
theorem cert_e2247258502682 : check e2247258502682 [[]] .width = true := by decide
def e2247258517018 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258517018 : Closed e2247258517018 ∧ code e2247258517018 = 11043351539226 := by decide
theorem cert_e2247258517018 : check e2247258517018 [[]] .width = true := by decide
def e2247258520090 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258520090 : Closed e2247258520090 ∧ code e2247258520090 = 11043351542298 := by decide
theorem cert_e2247258520090 : check e2247258520090 [[]] .width = true := by decide
def e2247258527258 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258527258 : Closed e2247258527258 ∧ code e2247258527258 = 11043351549466 := by decide
theorem cert_e2247258527258 : check e2247258527258 [[]] .width = true := by decide
def e2247258528282 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258528282 : Closed e2247258528282 ∧ code e2247258528282 = 11043351550490 := by decide
theorem cert_e2247258528282 : check e2247258528282 [[]] .width = true := by decide
def e2247258598938 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258598938 : Closed e2247258598938 ∧ code e2247258598938 = 11043351621146 := by decide
theorem cert_e2247258598938 : check e2247258598938 [[]] .width = true := by decide
def e2247258600986 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258600986 : Closed e2247258600986 ∧ code e2247258600986 = 11043351623194 := by decide
theorem cert_e2247258600986 : check e2247258600986 [[]] .width = true := by decide
def e2247258697242 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258697242 : Closed e2247258697242 ∧ code e2247258697242 = 11043351719450 := by decide
theorem cert_e2247258697242 : check e2247258697242 [[]] .width = true := by decide
def e2247258700314 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258700314 : Closed e2247258700314 ∧ code e2247258700314 = 11043351722522 := by decide
theorem cert_e2247258700314 : check e2247258700314 [[]] .width = true := by decide
def e2247258748442 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258748442 : Closed e2247258748442 ∧ code e2247258748442 = 11043351770650 := by decide
theorem cert_e2247258748442 : check e2247258748442 [[]] .width = true := by decide
def e2247258749466 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247258749466 : Closed e2247258749466 ∧ code e2247258749466 = 11043351771674 := by decide
theorem cert_e2247258749466 : check e2247258749466 [[]] .width = true := by decide
def e2247902478534 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247902478534 : Closed e2247902478534 ∧ code e2247902478534 = 11043995500742 := by decide
theorem cert_e2247902478534 : check e2247902478534 [[]] .width = true := by decide
def e2247902544070 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247902544070 : Closed e2247902544070 ∧ code e2247902544070 = 11043995566278 := by decide
theorem cert_e2247902544070 : check e2247902544070 [[]] .width = true := by decide
def e2247903002822 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247903002822 : Closed e2247903002822 ∧ code e2247903002822 = 11043996025030 := by decide
theorem cert_e2247903002822 : check e2247903002822 [[]] .width = true := by decide
def e2247903101126 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247903101126 : Closed e2247903101126 ∧ code e2247903101126 = 11043996123334 := by decide
theorem cert_e2247903101126 : check e2247903101126 [[]] .width = true := by decide
def e2247903330502 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247903330502 : Closed e2247903330502 ∧ code e2247903330502 = 11043996352710 := by decide
theorem cert_e2247903330502 : check e2247903330502 [[]] .width = true := by decide
def e2247903363270 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247903363270 : Closed e2247903363270 ∧ code e2247903363270 = 11043996385478 := by decide
theorem cert_e2247903363270 : check e2247903363270 [[]] .width = true := by decide
def e2247905624262 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247905624262 : Closed e2247905624262 ∧ code e2247905624262 = 11043998646470 := by decide
theorem cert_e2247905624262 : check e2247905624262 [[]] .width = true := by decide
def e2247905689798 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247905689798 : Closed e2247905689798 ∧ code e2247905689798 = 11043998712006 := by decide
theorem cert_e2247905689798 : check e2247905689798 [[]] .width = true := by decide
def e2247908769990 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247908769990 : Closed e2247908769990 ∧ code e2247908769990 = 11044001792198 := by decide
theorem cert_e2247908769990 : check e2247908769990 [[]] .width = true := by decide
def e2247908868294 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247908868294 : Closed e2247908868294 ∧ code e2247908868294 = 11044001890502 := by decide
theorem cert_e2247908868294 : check e2247908868294 [[]] .width = true := by decide
def e2247910408390 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247910408390 : Closed e2247910408390 ∧ code e2247910408390 = 11044003430598 := by decide
theorem cert_e2247910408390 : check e2247910408390 [[]] .width = true := by decide
def e2247910441158 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2247910441158 : Closed e2247910441158 ∧ code e2247910441158 = 11044003463366 := by decide
theorem cert_e2247910441158 : check e2247910441158 [[]] .width = true := by decide
def e2247996698138 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996698138 : Closed e2247996698138 ∧ code e2247996698138 = 11044089720346 := by decide
theorem cert_e2247996698138 : check e2247996698138 [[]] .width = true := by decide
def e2247996700186 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996700186 : Closed e2247996700186 ∧ code e2247996700186 = 11044089722394 := by decide
theorem cert_e2247996700186 : check e2247996700186 [[]] .width = true := by decide
def e2247996714522 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996714522 : Closed e2247996714522 ∧ code e2247996714522 = 11044089736730 := by decide
theorem cert_e2247996714522 : check e2247996714522 [[]] .width = true := by decide
def e2247996717594 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996717594 : Closed e2247996717594 ∧ code e2247996717594 = 11044089739802 := by decide
theorem cert_e2247996717594 : check e2247996717594 [[]] .width = true := by decide
def e2247996724762 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996724762 : Closed e2247996724762 ∧ code e2247996724762 = 11044089746970 := by decide
theorem cert_e2247996724762 : check e2247996724762 [[]] .width = true := by decide
def e2247996725786 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996725786 : Closed e2247996725786 ∧ code e2247996725786 = 11044089747994 := by decide
theorem cert_e2247996725786 : check e2247996725786 [[]] .width = true := by decide
def e2247996796442 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996796442 : Closed e2247996796442 ∧ code e2247996796442 = 11044089818650 := by decide
theorem cert_e2247996796442 : check e2247996796442 [[]] .width = true := by decide
def e2247996798490 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996798490 : Closed e2247996798490 ∧ code e2247996798490 = 11044089820698 := by decide
theorem cert_e2247996798490 : check e2247996798490 [[]] .width = true := by decide
def e2247996894746 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996894746 : Closed e2247996894746 ∧ code e2247996894746 = 11044089916954 := by decide
theorem cert_e2247996894746 : check e2247996894746 [[]] .width = true := by decide
def e2247996897818 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996897818 : Closed e2247996897818 ∧ code e2247996897818 = 11044089920026 := by decide
theorem cert_e2247996897818 : check e2247996897818 [[]] .width = true := by decide
def e2247996945946 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996945946 : Closed e2247996945946 ∧ code e2247996945946 = 11044089968154 := by decide
theorem cert_e2247996945946 : check e2247996945946 [[]] .width = true := by decide
def e2247996946970 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2247996946970 : Closed e2247996946970 ∧ code e2247996946970 = 11044089969178 := by decide
theorem cert_e2247996946970 : check e2247996946970 [[]] .width = true := by decide
def e2248079879534 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2248079879534 : Closed e2248079879534 ∧ code e2248079879534 = 11044172901742 := by decide
theorem cert_e2248079879534 : check e2248079879534 [[]] .sourceHead = true := by decide
def e2248079879542 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2248079879542 : Closed e2248079879542 ∧ code e2248079879542 = 11044172901750 := by decide
theorem cert_e2248079879542 : check e2248079879542 [[]] .sourceHead = true := by decide
def e2248079879598 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2248079879598 : Closed e2248079879598 ∧ code e2248079879598 = 11044172901806 := by decide
theorem cert_e2248079879598 : check e2248079879598 [[]] .sourceHead = true := by decide
def e2248079879610 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2248079879610 : Closed e2248079879610 ∧ code e2248079879610 = 11044172901818 := by decide
theorem cert_e2248079879610 : check e2248079879610 [[]] .sourceHead = true := by decide
def e2248079879638 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2248079879638 : Closed e2248079879638 ∧ code e2248079879638 = 11044172901846 := by decide
theorem cert_e2248079879638 : check e2248079879638 [[]] .sourceHead = true := by decide
def e2248079879642 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2248079879642 : Closed e2248079879642 ∧ code e2248079879642 = 11044172901850 := by decide
theorem cert_e2248079879642 : check e2248079879642 [[]] .sourceHead = true := by decide
def e2248079879854 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2248079879854 : Closed e2248079879854 ∧ code e2248079879854 = 11044172902062 := by decide
theorem cert_e2248079879854 : check e2248079879854 [[]] .sourceHead = true := by decide
def e2248079879866 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2248079879866 : Closed e2248079879866 ∧ code e2248079879866 = 11044172902074 := by decide
theorem cert_e2248079879866 : check e2248079879866 [[]] .sourceHead = true := by decide
def e2248079879914 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2248079879914 : Closed e2248079879914 ∧ code e2248079879914 = 11044172902122 := by decide
theorem cert_e2248079879914 : check e2248079879914 [[]] .sourceHead = true := by decide
def e2248079880022 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2248079880022 : Closed e2248079880022 ∧ code e2248079880022 = 11044172902230 := by decide
theorem cert_e2248079880022 : check e2248079880022 [[]] .sourceHead = true := by decide
def e2248079880026 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2248079880026 : Closed e2248079880026 ∧ code e2248079880026 = 11044172902234 := by decide
theorem cert_e2248079880026 : check e2248079880026 [[]] .sourceHead = true := by decide
def e2248079880042 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2248079880042 : Closed e2248079880042 ∧ code e2248079880042 = 11044172902250 := by decide
theorem cert_e2248079880042 : check e2248079880042 [[]] .sourceHead = true := by decide
def e2248079881070 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2248079881070 : Closed e2248079881070 ∧ code e2248079881070 = 11044172903278 := by decide
theorem cert_e2248079881070 : check e2248079881070 [[]] .sourceHead = true := by decide
def e2248079881078 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2248079881078 : Closed e2248079881078 ∧ code e2248079881078 = 11044172903286 := by decide
theorem cert_e2248079881078 : check e2248079881078 [[]] .sourceHead = true := by decide
def e2248079881134 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2248079881134 : Closed e2248079881134 ∧ code e2248079881134 = 11044172903342 := by decide
theorem cert_e2248079881134 : check e2248079881134 [[]] .sourceHead = true := by decide
def e2248079881146 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2248079881146 : Closed e2248079881146 ∧ code e2248079881146 = 11044172903354 := by decide
theorem cert_e2248079881146 : check e2248079881146 [[]] .sourceHead = true := by decide
def e2248079881174 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2248079881174 : Closed e2248079881174 ∧ code e2248079881174 = 11044172903382 := by decide
theorem cert_e2248079881174 : check e2248079881174 [[]] .sourceHead = true := by decide
def e2248079881178 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2248079881178 : Closed e2248079881178 ∧ code e2248079881178 = 11044172903386 := by decide
theorem cert_e2248079881178 : check e2248079881178 [[]] .sourceHead = true := by decide
def e2248079881454 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2248079881454 : Closed e2248079881454 ∧ code e2248079881454 = 11044172903662 := by decide
theorem cert_e2248079881454 : check e2248079881454 [[]] .sourceHead = true := by decide
def e2248079881462 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2248079881462 : Closed e2248079881462 ∧ code e2248079881462 = 11044172903670 := by decide
theorem cert_e2248079881462 : check e2248079881462 [[]] .sourceHead = true := by decide
def e2248079881838 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2248079881838 : Closed e2248079881838 ∧ code e2248079881838 = 11044172904046 := by decide
theorem cert_e2248079881838 : check e2248079881838 [[]] .sourceHead = true := by decide
def e2248079881850 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2248079881850 : Closed e2248079881850 ∧ code e2248079881850 = 11044172904058 := by decide
theorem cert_e2248079881850 : check e2248079881850 [[]] .sourceHead = true := by decide
def e2248079882038 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2248079882038 : Closed e2248079882038 ∧ code e2248079882038 = 11044172904246 := by decide
theorem cert_e2248079882038 : check e2248079882038 [[]] .sourceHead = true := by decide
def e2248079882042 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2248079882042 : Closed e2248079882042 ∧ code e2248079882042 = 11044172904250 := by decide
theorem cert_e2248079882042 : check e2248079882042 [[]] .sourceHead = true := by decide
def e2248079882670 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2248079882670 : Closed e2248079882670 ∧ code e2248079882670 = 11044172904878 := by decide
theorem cert_e2248079882670 : check e2248079882670 [[]] .sourceHead = true := by decide
def e2248079882682 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2248079882682 : Closed e2248079882682 ∧ code e2248079882682 = 11044172904890 := by decide
theorem cert_e2248079882682 : check e2248079882682 [[]] .sourceHead = true := by decide
def e2248079882730 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2248079882730 : Closed e2248079882730 ∧ code e2248079882730 = 11044172904938 := by decide
theorem cert_e2248079882730 : check e2248079882730 [[]] .sourceHead = true := by decide
def e2248079882862 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2248079882862 : Closed e2248079882862 ∧ code e2248079882862 = 11044172905070 := by decide
theorem cert_e2248079882862 : check e2248079882862 [[]] .sourceHead = true := by decide
def e2248079882874 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2248079882874 : Closed e2248079882874 ∧ code e2248079882874 = 11044172905082 := by decide
theorem cert_e2248079882874 : check e2248079882874 [[]] .sourceHead = true := by decide
def e2248079883162 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2248079883162 : Closed e2248079883162 ∧ code e2248079883162 = 11044172905370 := by decide
theorem cert_e2248079883162 : check e2248079883162 [[]] .sourceHead = true := by decide
def e2248079883478 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2248079883478 : Closed e2248079883478 ∧ code e2248079883478 = 11044172905686 := by decide
theorem cert_e2248079883478 : check e2248079883478 [[]] .sourceHead = true := by decide
def e2248079883482 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2248079883482 : Closed e2248079883482 ∧ code e2248079883482 = 11044172905690 := by decide
theorem cert_e2248079883482 : check e2248079883482 [[]] .sourceHead = true := by decide
def e2248079883498 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2248079883498 : Closed e2248079883498 ∧ code e2248079883498 = 11044172905706 := by decide
theorem cert_e2248079883498 : check e2248079883498 [[]] .sourceHead = true := by decide
def e2248079883574 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2248079883574 : Closed e2248079883574 ∧ code e2248079883574 = 11044172905782 := by decide
theorem cert_e2248079883574 : check e2248079883574 [[]] .sourceHead = true := by decide
def e2248079883578 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2248079883578 : Closed e2248079883578 ∧ code e2248079883578 = 11044172905786 := by decide
theorem cert_e2248079883578 : check e2248079883578 [[]] .sourceHead = true := by decide
def e2248079883674 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2248079883674 : Closed e2248079883674 ∧ code e2248079883674 = 11044172905882 := by decide
theorem cert_e2248079883674 : check e2248079883674 [[]] .sourceHead = true := by decide
def e2248079887214 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2248079887214 : Closed e2248079887214 ∧ code e2248079887214 = 11044172909422 := by decide
theorem cert_e2248079887214 : check e2248079887214 [[]] .sourceHead = true := by decide
def e2248079887222 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2248079887222 : Closed e2248079887222 ∧ code e2248079887222 = 11044172909430 := by decide
theorem cert_e2248079887222 : check e2248079887222 [[]] .sourceHead = true := by decide
def e2248079887278 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2248079887278 : Closed e2248079887278 ∧ code e2248079887278 = 11044172909486 := by decide
theorem cert_e2248079887278 : check e2248079887278 [[]] .sourceHead = true := by decide
def e2248079887290 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2248079887290 : Closed e2248079887290 ∧ code e2248079887290 = 11044172909498 := by decide
theorem cert_e2248079887290 : check e2248079887290 [[]] .sourceHead = true := by decide
def e2248079887318 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2248079887318 : Closed e2248079887318 ∧ code e2248079887318 = 11044172909526 := by decide
theorem cert_e2248079887318 : check e2248079887318 [[]] .sourceHead = true := by decide
def e2248079887322 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2248079887322 : Closed e2248079887322 ∧ code e2248079887322 = 11044172909530 := by decide
theorem cert_e2248079887322 : check e2248079887322 [[]] .sourceHead = true := by decide
def e2248079887598 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2248079887598 : Closed e2248079887598 ∧ code e2248079887598 = 11044172909806 := by decide
theorem cert_e2248079887598 : check e2248079887598 [[]] .sourceHead = true := by decide
def e2248079887606 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2248079887606 : Closed e2248079887606 ∧ code e2248079887606 = 11044172909814 := by decide
theorem cert_e2248079887606 : check e2248079887606 [[]] .sourceHead = true := by decide
def e2248079887982 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2248079887982 : Closed e2248079887982 ∧ code e2248079887982 = 11044172910190 := by decide
theorem cert_e2248079887982 : check e2248079887982 [[]] .sourceHead = true := by decide
def e2248079887994 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2248079887994 : Closed e2248079887994 ∧ code e2248079887994 = 11044172910202 := by decide
theorem cert_e2248079887994 : check e2248079887994 [[]] .sourceHead = true := by decide
def e2248079888182 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2248079888182 : Closed e2248079888182 ∧ code e2248079888182 = 11044172910390 := by decide
theorem cert_e2248079888182 : check e2248079888182 [[]] .sourceHead = true := by decide
def e2248079888186 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2248079888186 : Closed e2248079888186 ∧ code e2248079888186 = 11044172910394 := by decide
theorem cert_e2248079888186 : check e2248079888186 [[]] .sourceHead = true := by decide
def e2248079893934 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2248079893934 : Closed e2248079893934 ∧ code e2248079893934 = 11044172916142 := by decide
theorem cert_e2248079893934 : check e2248079893934 [[]] .sourceHead = true := by decide
def e2248079893946 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2248079893946 : Closed e2248079893946 ∧ code e2248079893946 = 11044172916154 := by decide
theorem cert_e2248079893946 : check e2248079893946 [[]] .sourceHead = true := by decide
def e2248079893994 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2248079893994 : Closed e2248079893994 ∧ code e2248079893994 = 11044172916202 := by decide
theorem cert_e2248079893994 : check e2248079893994 [[]] .sourceHead = true := by decide
def e2248079894126 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2248079894126 : Closed e2248079894126 ∧ code e2248079894126 = 11044172916334 := by decide
theorem cert_e2248079894126 : check e2248079894126 [[]] .sourceHead = true := by decide
def e2248079894138 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2248079894138 : Closed e2248079894138 ∧ code e2248079894138 = 11044172916346 := by decide
theorem cert_e2248079894138 : check e2248079894138 [[]] .sourceHead = true := by decide
def e2248079894426 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2248079894426 : Closed e2248079894426 ∧ code e2248079894426 = 11044172916634 := by decide
theorem cert_e2248079894426 : check e2248079894426 [[]] .sourceHead = true := by decide
def e2248079897302 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2248079897302 : Closed e2248079897302 ∧ code e2248079897302 = 11044172919510 := by decide
theorem cert_e2248079897302 : check e2248079897302 [[]] .sourceHead = true := by decide
def e2248079897306 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2248079897306 : Closed e2248079897306 ∧ code e2248079897306 = 11044172919514 := by decide
theorem cert_e2248079897306 : check e2248079897306 [[]] .sourceHead = true := by decide
def e2248079897322 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2248079897322 : Closed e2248079897322 ∧ code e2248079897322 = 11044172919530 := by decide
theorem cert_e2248079897322 : check e2248079897322 [[]] .sourceHead = true := by decide
def e2248079897398 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2248079897398 : Closed e2248079897398 ∧ code e2248079897398 = 11044172919606 := by decide
theorem cert_e2248079897398 : check e2248079897398 [[]] .sourceHead = true := by decide
def e2248079897402 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2248079897402 : Closed e2248079897402 ∧ code e2248079897402 = 11044172919610 := by decide
theorem cert_e2248079897402 : check e2248079897402 [[]] .sourceHead = true := by decide
def e2248079897498 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2248079897498 : Closed e2248079897498 ∧ code e2248079897498 = 11044172919706 := by decide
theorem cert_e2248079897498 : check e2248079897498 [[]] .sourceHead = true := by decide
def e2248080013038 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2248080013038 : Closed e2248080013038 ∧ code e2248080013038 = 11044173035246 := by decide
theorem cert_e2248080013038 : check e2248080013038 [[]] .sourceHead = true := by decide
def e2248080013166 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2248080013166 : Closed e2248080013166 ∧ code e2248080013166 = 11044173035374 := by decide
theorem cert_e2248080013166 : check e2248080013166 [[]] .sourceHead = true := by decide
def e2248080013174 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2248080013174 : Closed e2248080013174 ∧ code e2248080013174 = 11044173035382 := by decide
theorem cert_e2248080013174 : check e2248080013174 [[]] .sourceHead = true := by decide
def e2248080014062 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2248080014062 : Closed e2248080014062 ∧ code e2248080014062 = 11044173036270 := by decide
theorem cert_e2248080014062 : check e2248080014062 [[]] .sourceHead = true := by decide
def e2248080014254 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2248080014254 : Closed e2248080014254 ∧ code e2248080014254 = 11044173036462 := by decide
theorem cert_e2248080014254 : check e2248080014254 [[]] .sourceHead = true := by decide
def e2248080014266 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2248080014266 : Closed e2248080014266 ∧ code e2248080014266 = 11044173036474 := by decide
theorem cert_e2248080014266 : check e2248080014266 [[]] .sourceHead = true := by decide
def e2248080014702 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2248080014702 : Closed e2248080014702 ∧ code e2248080014702 = 11044173036910 := by decide
theorem cert_e2248080014702 : check e2248080014702 [[]] .sourceHead = true := by decide
def e2248080014710 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2248080014710 : Closed e2248080014710 ∧ code e2248080014710 = 11044173036918 := by decide
theorem cert_e2248080014710 : check e2248080014710 [[]] .sourceHead = true := by decide
def e2248080014766 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2248080014766 : Closed e2248080014766 ∧ code e2248080014766 = 11044173036974 := by decide
theorem cert_e2248080014766 : check e2248080014766 [[]] .sourceHead = true := by decide
def e2248080014778 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2248080014778 : Closed e2248080014778 ∧ code e2248080014778 = 11044173036986 := by decide
theorem cert_e2248080014778 : check e2248080014778 [[]] .sourceHead = true := by decide
def e2248080014806 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2248080014806 : Closed e2248080014806 ∧ code e2248080014806 = 11044173037014 := by decide
theorem cert_e2248080014806 : check e2248080014806 [[]] .sourceHead = true := by decide
def e2248080014810 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2248080014810 : Closed e2248080014810 ∧ code e2248080014810 = 11044173037018 := by decide
theorem cert_e2248080014810 : check e2248080014810 [[]] .sourceHead = true := by decide
def e2248080019182 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2248080019182 : Closed e2248080019182 ∧ code e2248080019182 = 11044173041390 := by decide
theorem cert_e2248080019182 : check e2248080019182 [[]] .sourceHead = true := by decide
def e2248080019310 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2248080019310 : Closed e2248080019310 ∧ code e2248080019310 = 11044173041518 := by decide
theorem cert_e2248080019310 : check e2248080019310 [[]] .sourceHead = true := by decide
def e2248080019318 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2248080019318 : Closed e2248080019318 ∧ code e2248080019318 = 11044173041526 := by decide
theorem cert_e2248080019318 : check e2248080019318 [[]] .sourceHead = true := by decide
def e2248080021998 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2248080021998 : Closed e2248080021998 ∧ code e2248080021998 = 11044173044206 := by decide
theorem cert_e2248080021998 : check e2248080021998 [[]] .sourceHead = true := by decide
def e2248080022766 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2248080022766 : Closed e2248080022766 ∧ code e2248080022766 = 11044173044974 := by decide
theorem cert_e2248080022766 : check e2248080022766 [[]] .sourceHead = true := by decide
def e2248080022774 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2248080022774 : Closed e2248080022774 ∧ code e2248080022774 = 11044173044982 := by decide
theorem cert_e2248080022774 : check e2248080022774 [[]] .sourceHead = true := by decide
def e2248080025326 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2248080025326 : Closed e2248080025326 ∧ code e2248080025326 = 11044173047534 := by decide
theorem cert_e2248080025326 : check e2248080025326 [[]] .sourceHead = true := by decide
def e2248080025518 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2248080025518 : Closed e2248080025518 ∧ code e2248080025518 = 11044173047726 := by decide
theorem cert_e2248080025518 : check e2248080025518 [[]] .sourceHead = true := by decide
def e2248080025530 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2248080025530 : Closed e2248080025530 ∧ code e2248080025530 = 11044173047738 := by decide
theorem cert_e2248080025530 : check e2248080025530 [[]] .sourceHead = true := by decide
def e2248080026094 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2248080026094 : Closed e2248080026094 ∧ code e2248080026094 = 11044173048302 := by decide
theorem cert_e2248080026094 : check e2248080026094 [[]] .sourceHead = true := by decide
def e2248080027246 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2248080027246 : Closed e2248080027246 ∧ code e2248080027246 = 11044173049454 := by decide
theorem cert_e2248080027246 : check e2248080027246 [[]] .sourceHead = true := by decide
def e2248080027258 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2248080027258 : Closed e2248080027258 ∧ code e2248080027258 = 11044173049466 := by decide
theorem cert_e2248080027258 : check e2248080027258 [[]] .sourceHead = true := by decide
def e2248080028526 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2248080028526 : Closed e2248080028526 ∧ code e2248080028526 = 11044173050734 := by decide
theorem cert_e2248080028526 : check e2248080028526 [[]] .sourceHead = true := by decide
def e2248080028534 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2248080028534 : Closed e2248080028534 ∧ code e2248080028534 = 11044173050742 := by decide
theorem cert_e2248080028534 : check e2248080028534 [[]] .sourceHead = true := by decide
def e2248080028590 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2248080028590 : Closed e2248080028590 ∧ code e2248080028590 = 11044173050798 := by decide
theorem cert_e2248080028590 : check e2248080028590 [[]] .sourceHead = true := by decide
def e2248080028602 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2248080028602 : Closed e2248080028602 ∧ code e2248080028602 = 11044173050810 := by decide
theorem cert_e2248080028602 : check e2248080028602 [[]] .sourceHead = true := by decide
def e2248080028630 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2248080028630 : Closed e2248080028630 ∧ code e2248080028630 = 11044173050838 := by decide
theorem cert_e2248080028630 : check e2248080028630 [[]] .sourceHead = true := by decide
def e2248080028634 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2248080028634 : Closed e2248080028634 ∧ code e2248080028634 = 11044173050842 := by decide
theorem cert_e2248080028634 : check e2248080028634 [[]] .sourceHead = true := by decide
def e2248080028910 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2248080028910 : Closed e2248080028910 ∧ code e2248080028910 = 11044173051118 := by decide
theorem cert_e2248080028910 : check e2248080028910 [[]] .sourceHead = true := by decide
def e2248080028918 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2248080028918 : Closed e2248080028918 ∧ code e2248080028918 = 11044173051126 := by decide
theorem cert_e2248080028918 : check e2248080028918 [[]] .sourceHead = true := by decide
def e2248080029294 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2248080029294 : Closed e2248080029294 ∧ code e2248080029294 = 11044173051502 := by decide
theorem cert_e2248080029294 : check e2248080029294 [[]] .sourceHead = true := by decide
def e2248080029306 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2248080029306 : Closed e2248080029306 ∧ code e2248080029306 = 11044173051514 := by decide
theorem cert_e2248080029306 : check e2248080029306 [[]] .sourceHead = true := by decide
def e2248080029494 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2248080029494 : Closed e2248080029494 ∧ code e2248080029494 = 11044173051702 := by decide
theorem cert_e2248080029494 : check e2248080029494 [[]] .sourceHead = true := by decide
def e2248080029498 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2248080029498 : Closed e2248080029498 ∧ code e2248080029498 = 11044173051706 := by decide
theorem cert_e2248080029498 : check e2248080029498 [[]] .sourceHead = true := by decide
def e2248080034670 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2248080034670 : Closed e2248080034670 ∧ code e2248080034670 = 11044173056878 := by decide
theorem cert_e2248080034670 : check e2248080034670 [[]] .sourceHead = true := by decide
def e2248080034678 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2248080034678 : Closed e2248080034678 ∧ code e2248080034678 = 11044173056886 := by decide
theorem cert_e2248080034678 : check e2248080034678 [[]] .sourceHead = true := by decide
def e2248080034734 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2248080034734 : Closed e2248080034734 ∧ code e2248080034734 = 11044173056942 := by decide
theorem cert_e2248080034734 : check e2248080034734 [[]] .sourceHead = true := by decide
def e2248080034746 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2248080034746 : Closed e2248080034746 ∧ code e2248080034746 = 11044173056954 := by decide
theorem cert_e2248080034746 : check e2248080034746 [[]] .sourceHead = true := by decide
def e2248080034774 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2248080034774 : Closed e2248080034774 ∧ code e2248080034774 = 11044173056982 := by decide
theorem cert_e2248080034774 : check e2248080034774 [[]] .sourceHead = true := by decide
def e2248080034778 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2248080034778 : Closed e2248080034778 ∧ code e2248080034778 = 11044173056986 := by decide
theorem cert_e2248080034778 : check e2248080034778 [[]] .sourceHead = true := by decide
def e2248080035054 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2248080035054 : Closed e2248080035054 ∧ code e2248080035054 = 11044173057262 := by decide
theorem cert_e2248080035054 : check e2248080035054 [[]] .sourceHead = true := by decide
def e2248080035062 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2248080035062 : Closed e2248080035062 ∧ code e2248080035062 = 11044173057270 := by decide
theorem cert_e2248080035062 : check e2248080035062 [[]] .sourceHead = true := by decide
def e2248080035438 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2248080035438 : Closed e2248080035438 ∧ code e2248080035438 = 11044173057646 := by decide
theorem cert_e2248080035438 : check e2248080035438 [[]] .sourceHead = true := by decide
def e2248080035450 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2248080035450 : Closed e2248080035450 ∧ code e2248080035450 = 11044173057658 := by decide
theorem cert_e2248080035450 : check e2248080035450 [[]] .sourceHead = true := by decide
def e2248080035638 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2248080035638 : Closed e2248080035638 ∧ code e2248080035638 = 11044173057846 := by decide
theorem cert_e2248080035638 : check e2248080035638 [[]] .sourceHead = true := by decide
def e2248080035642 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2248080035642 : Closed e2248080035642 ∧ code e2248080035642 = 11044173057850 := by decide
theorem cert_e2248080035642 : check e2248080035642 [[]] .sourceHead = true := by decide
def e2248080043758 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2248080043758 : Closed e2248080043758 ∧ code e2248080043758 = 11044173065966 := by decide
theorem cert_e2248080043758 : check e2248080043758 [[]] .sourceHead = true := by decide
def e2248080043886 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2248080043886 : Closed e2248080043886 ∧ code e2248080043886 = 11044173066094 := by decide
theorem cert_e2248080043886 : check e2248080043886 [[]] .sourceHead = true := by decide
end Blc.Floor43
