import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2248080043894 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2248080043894 : Closed e2248080043894 ∧ code e2248080043894 = 11044173066102 := by decide
theorem cert_e2248080043894 : check e2248080043894 [[]] .sourceHead = true := by decide
def e2248080046574 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2248080046574 : Closed e2248080046574 ∧ code e2248080046574 = 11044173068782 := by decide
theorem cert_e2248080046574 : check e2248080046574 [[]] .sourceHead = true := by decide
def e2248080047342 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2248080047342 : Closed e2248080047342 ∧ code e2248080047342 = 11044173069550 := by decide
theorem cert_e2248080047342 : check e2248080047342 [[]] .sourceHead = true := by decide
def e2248080047350 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2248080047350 : Closed e2248080047350 ∧ code e2248080047350 = 11044173069558 := by decide
theorem cert_e2248080047350 : check e2248080047350 [[]] .sourceHead = true := by decide
def e2248080070382 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2248080070382 : Closed e2248080070382 ∧ code e2248080070382 = 11044173092590 := by decide
theorem cert_e2248080070382 : check e2248080070382 [[]] .sourceHead = true := by decide
def e2248080070574 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2248080070574 : Closed e2248080070574 ∧ code e2248080070574 = 11044173092782 := by decide
theorem cert_e2248080070574 : check e2248080070574 [[]] .sourceHead = true := by decide
def e2248080070586 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2248080070586 : Closed e2248080070586 ∧ code e2248080070586 = 11044173092794 := by decide
theorem cert_e2248080070586 : check e2248080070586 [[]] .sourceHead = true := by decide
def e2248080071150 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2248080071150 : Closed e2248080071150 ∧ code e2248080071150 = 11044173093358 := by decide
theorem cert_e2248080071150 : check e2248080071150 [[]] .sourceHead = true := by decide
def e2248080072302 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2248080072302 : Closed e2248080072302 ∧ code e2248080072302 = 11044173094510 := by decide
theorem cert_e2248080072302 : check e2248080072302 [[]] .sourceHead = true := by decide
def e2248080072314 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2248080072314 : Closed e2248080072314 ∧ code e2248080072314 = 11044173094522 := by decide
theorem cert_e2248080072314 : check e2248080072314 [[]] .sourceHead = true := by decide
def e2248080083822 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2248080083822 : Closed e2248080083822 ∧ code e2248080083822 = 11044173106030 := by decide
theorem cert_e2248080083822 : check e2248080083822 [[]] .sourceHead = true := by decide
def e2248080083830 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2248080083830 : Closed e2248080083830 ∧ code e2248080083830 = 11044173106038 := by decide
theorem cert_e2248080083830 : check e2248080083830 [[]] .sourceHead = true := by decide
def e2248080083886 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2248080083886 : Closed e2248080083886 ∧ code e2248080083886 = 11044173106094 := by decide
theorem cert_e2248080083886 : check e2248080083886 [[]] .sourceHead = true := by decide
def e2248080083898 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2248080083898 : Closed e2248080083898 ∧ code e2248080083898 = 11044173106106 := by decide
theorem cert_e2248080083898 : check e2248080083898 [[]] .sourceHead = true := by decide
def e2248080083926 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2248080083926 : Closed e2248080083926 ∧ code e2248080083926 = 11044173106134 := by decide
theorem cert_e2248080083926 : check e2248080083926 [[]] .sourceHead = true := by decide
def e2248080083930 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2248080083930 : Closed e2248080083930 ∧ code e2248080083930 = 11044173106138 := by decide
theorem cert_e2248080083930 : check e2248080083930 [[]] .sourceHead = true := by decide
def e2248080084206 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2248080084206 : Closed e2248080084206 ∧ code e2248080084206 = 11044173106414 := by decide
theorem cert_e2248080084206 : check e2248080084206 [[]] .sourceHead = true := by decide
def e2248080084214 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2248080084214 : Closed e2248080084214 ∧ code e2248080084214 = 11044173106422 := by decide
theorem cert_e2248080084214 : check e2248080084214 [[]] .sourceHead = true := by decide
def e2248080084590 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2248080084590 : Closed e2248080084590 ∧ code e2248080084590 = 11044173106798 := by decide
theorem cert_e2248080084590 : check e2248080084590 [[]] .sourceHead = true := by decide
def e2248080084602 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2248080084602 : Closed e2248080084602 ∧ code e2248080084602 = 11044173106810 := by decide
theorem cert_e2248080084602 : check e2248080084602 [[]] .sourceHead = true := by decide
def e2248080084790 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2248080084790 : Closed e2248080084790 ∧ code e2248080084790 = 11044173106998 := by decide
theorem cert_e2248080084790 : check e2248080084790 [[]] .sourceHead = true := by decide
def e2248080084794 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2248080084794 : Closed e2248080084794 ∧ code e2248080084794 = 11044173107002 := by decide
theorem cert_e2248080084794 : check e2248080084794 [[]] .sourceHead = true := by decide
def e2248080624494 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2248080624494 : Closed e2248080624494 ∧ code e2248080624494 = 11044173646702 := by decide
theorem cert_e2248080624494 : check e2248080624494 [[]] .sourceHead = true := by decide
def e2248080624502 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2248080624502 : Closed e2248080624502 ∧ code e2248080624502 = 11044173646710 := by decide
theorem cert_e2248080624502 : check e2248080624502 [[]] .sourceHead = true := by decide
def e2248080624558 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2248080624558 : Closed e2248080624558 ∧ code e2248080624558 = 11044173646766 := by decide
theorem cert_e2248080624558 : check e2248080624558 [[]] .sourceHead = true := by decide
def e2248080624570 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2248080624570 : Closed e2248080624570 ∧ code e2248080624570 = 11044173646778 := by decide
theorem cert_e2248080624570 : check e2248080624570 [[]] .sourceHead = true := by decide
def e2248080624598 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2248080624598 : Closed e2248080624598 ∧ code e2248080624598 = 11044173646806 := by decide
theorem cert_e2248080624598 : check e2248080624598 [[]] .sourceHead = true := by decide
def e2248080624602 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2248080624602 : Closed e2248080624602 ∧ code e2248080624602 = 11044173646810 := by decide
theorem cert_e2248080624602 : check e2248080624602 [[]] .sourceHead = true := by decide
def e2248080624878 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2248080624878 : Closed e2248080624878 ∧ code e2248080624878 = 11044173647086 := by decide
theorem cert_e2248080624878 : check e2248080624878 [[]] .sourceHead = true := by decide
def e2248080624886 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2248080624886 : Closed e2248080624886 ∧ code e2248080624886 = 11044173647094 := by decide
theorem cert_e2248080624886 : check e2248080624886 [[]] .sourceHead = true := by decide
def e2248080625262 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2248080625262 : Closed e2248080625262 ∧ code e2248080625262 = 11044173647470 := by decide
theorem cert_e2248080625262 : check e2248080625262 [[]] .sourceHead = true := by decide
def e2248080625274 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2248080625274 : Closed e2248080625274 ∧ code e2248080625274 = 11044173647482 := by decide
theorem cert_e2248080625274 : check e2248080625274 [[]] .sourceHead = true := by decide
def e2248080625462 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2248080625462 : Closed e2248080625462 ∧ code e2248080625462 = 11044173647670 := by decide
theorem cert_e2248080625462 : check e2248080625462 [[]] .sourceHead = true := by decide
def e2248080625466 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2248080625466 : Closed e2248080625466 ∧ code e2248080625466 = 11044173647674 := by decide
theorem cert_e2248080625466 : check e2248080625466 [[]] .sourceHead = true := by decide
def e2248439355418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248439355418 : Closed e2248439355418 ∧ code e2248439355418 = 11044532377626 := by decide
theorem cert_e2248439355418 : check e2248439355418 [[]] .width = true := by decide
def e2248439420954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248439420954 : Closed e2248439420954 ∧ code e2248439420954 = 11044532443162 := by decide
theorem cert_e2248439420954 : check e2248439420954 [[]] .width = true := by decide
def e2248439428634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248439428634 : Closed e2248439428634 ∧ code e2248439428634 = 11044532450842 := by decide
theorem cert_e2248439428634 : check e2248439428634 [[]] .width = true := by decide
def e2248439461402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248439461402 : Closed e2248439461402 ∧ code e2248439461402 = 11044532483610 := by decide
theorem cert_e2248439461402 : check e2248439461402 [[]] .width = true := by decide
def e2248439879706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248439879706 : Closed e2248439879706 ∧ code e2248439879706 = 11044532901914 := by decide
theorem cert_e2248439879706 : check e2248439879706 [[]] .width = true := by decide
def e2248439978010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248439978010 : Closed e2248439978010 ∧ code e2248439978010 = 11044533000218 := by decide
theorem cert_e2248439978010 : check e2248439978010 [[]] .width = true := by decide
def e2248440207386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248440207386 : Closed e2248440207386 ∧ code e2248440207386 = 11044533229594 := by decide
theorem cert_e2248440207386 : check e2248440207386 [[]] .width = true := by decide
def e2248440215066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248440215066 : Closed e2248440215066 ∧ code e2248440215066 = 11044533237274 := by decide
theorem cert_e2248440215066 : check e2248440215066 [[]] .width = true := by decide
def e2248440240154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248440240154 : Closed e2248440240154 ∧ code e2248440240154 = 11044533262362 := by decide
theorem cert_e2248440240154 : check e2248440240154 [[]] .width = true := by decide
def e2248440272410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248440272410 : Closed e2248440272410 ∧ code e2248440272410 = 11044533294618 := by decide
theorem cert_e2248440272410 : check e2248440272410 [[]] .width = true := by decide
def e2248440378906 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248440378906 : Closed e2248440378906 ∧ code e2248440378906 = 11044533401114 := by decide
theorem cert_e2248440378906 : check e2248440378906 [[]] .width = true := by decide
def e2248440403482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248440403482 : Closed e2248440403482 ∧ code e2248440403482 = 11044533425690 := by decide
theorem cert_e2248440403482 : check e2248440403482 [[]] .width = true := by decide
def e2248442501146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248442501146 : Closed e2248442501146 ∧ code e2248442501146 = 11044535523354 := by decide
theorem cert_e2248442501146 : check e2248442501146 [[]] .width = true := by decide
def e2248442566682 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248442566682 : Closed e2248442566682 ∧ code e2248442566682 = 11044535588890 := by decide
theorem cert_e2248442566682 : check e2248442566682 [[]] .width = true := by decide
def e2248442574362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248442574362 : Closed e2248442574362 ∧ code e2248442574362 = 11044535596570 := by decide
theorem cert_e2248442574362 : check e2248442574362 [[]] .width = true := by decide
def e2248442607130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248442607130 : Closed e2248442607130 ∧ code e2248442607130 = 11044535629338 := by decide
theorem cert_e2248442607130 : check e2248442607130 [[]] .width = true := by decide
def e2248445646874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248445646874 : Closed e2248445646874 ∧ code e2248445646874 = 11044538669082 := by decide
theorem cert_e2248445646874 : check e2248445646874 [[]] .width = true := by decide
def e2248445745178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248445745178 : Closed e2248445745178 ∧ code e2248445745178 = 11044538767386 := by decide
theorem cert_e2248445745178 : check e2248445745178 [[]] .width = true := by decide
def e2248447285274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248447285274 : Closed e2248447285274 ∧ code e2248447285274 = 11044540307482 := by decide
theorem cert_e2248447285274 : check e2248447285274 [[]] .width = true := by decide
def e2248447292954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248447292954 : Closed e2248447292954 ∧ code e2248447292954 = 11044540315162 := by decide
theorem cert_e2248447292954 : check e2248447292954 [[]] .width = true := by decide
def e2248447318042 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2248447318042 : Closed e2248447318042 ∧ code e2248447318042 = 11044540340250 := by decide
theorem cert_e2248447318042 : check e2248447318042 [[]] .width = true := by decide
def e2248447350298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248447350298 : Closed e2248447350298 ∧ code e2248447350298 = 11044540372506 := by decide
theorem cert_e2248447350298 : check e2248447350298 [[]] .width = true := by decide
def e2248448112154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248448112154 : Closed e2248448112154 ∧ code e2248448112154 = 11044541134362 := by decide
theorem cert_e2248448112154 : check e2248448112154 [[]] .width = true := by decide
def e2248448136730 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248448136730 : Closed e2248448136730 ∧ code e2248448136730 = 11044541158938 := by decide
theorem cert_e2248448136730 : check e2248448136730 [[]] .width = true := by decide
def e2248506308122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506308122 : Closed e2248506308122 ∧ code e2248506308122 = 11044599330330 := by decide
private def t_e2248506308122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248506308122 : ¬ IsSelfInterpreter e2248506308122 :=
  wSource (t := t_e2248506308122) (replay_sound (ps := []) (t := e2248506308122) (by decide)) (by decide)
def e2248506324506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506324506 : Closed e2248506324506 ∧ code e2248506324506 = 11044599346714 := by decide
private def t_e2248506324506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248506324506 : ¬ IsSelfInterpreter e2248506324506 :=
  wSource (t := t_e2248506324506) (replay_sound (ps := []) (t := e2248506324506) (by decide)) (by decide)
def e2248506439194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506439194 : Closed e2248506439194 ∧ code e2248506439194 = 11044599461402 := by decide
theorem cert_e2248506439194 : check e2248506439194 [[]] .width = true := by decide
def e2248506463770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506463770 : Closed e2248506463770 ∧ code e2248506463770 = 11044599485978 := by decide
theorem cert_e2248506463770 : check e2248506463770 [[]] .width = true := by decide
def e2248506521114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506521114 : Closed e2248506521114 ∧ code e2248506521114 = 11044599543322 := by decide
private def t_e2248506521114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248506521114 : ¬ IsSelfInterpreter e2248506521114 :=
  wSource (t := t_e2248506521114) (replay_sound (ps := []) (t := e2248506521114) (by decide)) (by decide)
def e2248506529306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506529306 : Closed e2248506529306 ∧ code e2248506529306 = 11044599551514 := by decide
private def t_e2248506529306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248506529306 : ¬ IsSelfInterpreter e2248506529306 :=
  wSource (t := t_e2248506529306) (replay_sound (ps := []) (t := e2248506529306) (by decide)) (by decide)
def e2248506963482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506963482 : Closed e2248506963482 ∧ code e2248506963482 = 11044599985690 := by decide
theorem cert_e2248506963482 : check e2248506963482 [[]] .width = true := by decide
def e2248506988058 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248506988058 : Closed e2248506988058 ∧ code e2248506988058 = 11044600010266 := by decide
theorem cert_e2248506988058 : check e2248506988058 [[]] .width = true := by decide
def e2248507086362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248507086362 : Closed e2248507086362 ∧ code e2248507086362 = 11044600108570 := by decide
theorem cert_e2248507086362 : check e2248507086362 [[]] .width = true := by decide
def e2248507307546 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248507307546 : Closed e2248507307546 ∧ code e2248507307546 = 11044600329754 := by decide
private def t_e2248507307546 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248507307546 : ¬ IsSelfInterpreter e2248507307546 :=
  wSource (t := t_e2248507307546) (replay_sound (ps := []) (t := e2248507307546) (by decide)) (by decide)
def e2248507315738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248507315738 : Closed e2248507315738 ∧ code e2248507315738 = 11044600337946 := by decide
private def t_e2248507315738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248507315738 : ¬ IsSelfInterpreter e2248507315738 :=
  wSource (t := t_e2248507315738) (replay_sound (ps := []) (t := e2248507315738) (by decide)) (by decide)
def e2248507348506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248507348506 : Closed e2248507348506 ∧ code e2248507348506 = 11044600370714 := by decide
theorem cert_e2248507348506 : check e2248507348506 [[]] .width = true := by decide
def e2248509453850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248509453850 : Closed e2248509453850 ∧ code e2248509453850 = 11044602476058 := by decide
theorem cert_e2248509453850 : check e2248509453850 [[]] .width = true := by decide
def e2248509470234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248509470234 : Closed e2248509470234 ∧ code e2248509470234 = 11044602492442 := by decide
private def t_e2248509470234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248509470234 : ¬ IsSelfInterpreter e2248509470234 :=
  wSource (t := t_e2248509470234) (replay_sound (ps := []) (t := e2248509470234) (by decide)) (by decide)
def e2248509584922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248509584922 : Closed e2248509584922 ∧ code e2248509584922 = 11044602607130 := by decide
theorem cert_e2248509584922 : check e2248509584922 [[]] .width = true := by decide
def e2248509609498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248509609498 : Closed e2248509609498 ∧ code e2248509609498 = 11044602631706 := by decide
theorem cert_e2248509609498 : check e2248509609498 [[]] .width = true := by decide
def e2248509666842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248509666842 : Closed e2248509666842 ∧ code e2248509666842 = 11044602689050 := by decide
private def t_e2248509666842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248509666842 : ¬ IsSelfInterpreter e2248509666842 :=
  wSource (t := t_e2248509666842) (replay_sound (ps := []) (t := e2248509666842) (by decide)) (by decide)
def e2248509675034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248509675034 : Closed e2248509675034 ∧ code e2248509675034 = 11044602697242 := by decide
theorem cert_e2248509675034 : check e2248509675034 [[]] .width = true := by decide
def e2248510240282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248510240282 : Closed e2248510240282 ∧ code e2248510240282 = 11044603262490 := by decide
private def t_e2248510240282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248510240282 : ¬ IsSelfInterpreter e2248510240282 :=
  wSource (t := t_e2248510240282) (replay_sound (ps := []) (t := e2248510240282) (by decide)) (by decide)
def e2248510256666 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248510256666 : Closed e2248510256666 ∧ code e2248510256666 = 11044603278874 := by decide
private def t_e2248510256666 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248510256666 : ¬ IsSelfInterpreter e2248510256666 :=
  wSource (t := t_e2248510256666) (replay_sound (ps := []) (t := e2248510256666) (by decide)) (by decide)
def e2248511026714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511026714 : Closed e2248511026714 ∧ code e2248511026714 = 11044604048922 := by decide
theorem cert_e2248511026714 : check e2248511026714 [[]] .width = true := by decide
def e2248511051290 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511051290 : Closed e2248511051290 ∧ code e2248511051290 = 11044604073498 := by decide
theorem cert_e2248511051290 : check e2248511051290 [[]] .width = true := by decide
def e2248511262918 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248511262918 : Closed e2248511262918 ∧ code e2248511262918 = 11044604285126 := by decide
theorem cert_e2248511262918 : check e2248511262918 [[]] .width = true := by decide
def e2248511272474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511272474 : Closed e2248511272474 ∧ code e2248511272474 = 11044604294682 := by decide
theorem cert_e2248511272474 : check e2248511272474 [[]] .width = true := by decide
def e2248511273498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511273498 : Closed e2248511273498 ∧ code e2248511273498 = 11044604295706 := by decide
theorem cert_e2248511273498 : check e2248511273498 [[]] .width = true := by decide
def e2248511275206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248511275206 : Closed e2248511275206 ∧ code e2248511275206 = 11044604297414 := by decide
theorem cert_e2248511275206 : check e2248511275206 [[]] .width = true := by decide
def e2248511283226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248511283226 : Closed e2248511283226 ∧ code e2248511283226 = 11044604305434 := by decide
theorem cert_e2248511283226 : check e2248511283226 [[]] .width = true := by decide
def e2248511283318 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248511283318 : Closed e2248511283318 ∧ code e2248511283318 = 11044604305526 := by decide
theorem cert_e2248511283318 : check e2248511283318 [[]] .width = true := by decide
def e2248511283562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248511283562 : Closed e2248511283562 ∧ code e2248511283562 = 11044604305770 := by decide
theorem cert_e2248511283562 : check e2248511283562 [[]] .width = true := by decide
def e2248511283610 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248511283610 : Closed e2248511283610 ∧ code e2248511283610 = 11044604305818 := by decide
theorem cert_e2248511283610 : check e2248511283610 [[]] .width = true := by decide
def e2248511436314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511436314 : Closed e2248511436314 ∧ code e2248511436314 = 11044604458522 := by decide
private def t_e2248511436314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248511436314 : ¬ IsSelfInterpreter e2248511436314 :=
  wSource (t := t_e2248511436314) (replay_sound (ps := []) (t := e2248511436314) (by decide)) (by decide)
def e2248511444506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511444506 : Closed e2248511444506 ∧ code e2248511444506 = 11044604466714 := by decide
private def t_e2248511444506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248511444506 : ¬ IsSelfInterpreter e2248511444506 :=
  wSource (t := t_e2248511444506) (replay_sound (ps := []) (t := e2248511444506) (by decide)) (by decide)
def e2248511525062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248511525062 : Closed e2248511525062 ∧ code e2248511525062 = 11044604547270 := by decide
theorem cert_e2248511525062 : check e2248511525062 [[]] .width = true := by decide
def e2248511534618 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511534618 : Closed e2248511534618 ∧ code e2248511534618 = 11044604556826 := by decide
private def t_e2248511534618 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248511534618 : ¬ IsSelfInterpreter e2248511534618 :=
  wSource (t := t_e2248511534618) (replay_sound (ps := []) (t := e2248511534618) (by decide)) (by decide)
def e2248511535642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248511535642 : Closed e2248511535642 ∧ code e2248511535642 = 11044604557850 := by decide
private def t_e2248511535642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248511535642 : ¬ IsSelfInterpreter e2248511535642 :=
  wSource (t := t_e2248511535642) (replay_sound (ps := []) (t := e2248511535642) (by decide)) (by decide)
def e2248511537350 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248511537350 : Closed e2248511537350 ∧ code e2248511537350 = 11044604559558 := by decide
theorem cert_e2248511537350 : check e2248511537350 [[]] .width = true := by decide
def e2248511545370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248511545370 : Closed e2248511545370 ∧ code e2248511545370 = 11044604567578 := by decide
theorem cert_e2248511545370 : check e2248511545370 [[]] .width = true := by decide
def e2248511545462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248511545462 : Closed e2248511545462 ∧ code e2248511545462 = 11044604567670 := by decide
private def t_e2248511545462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2248511545462 : ¬ IsSelfInterpreter e2248511545462 :=
  wSource (t := t_e2248511545462) (replay_sound (ps := []) (t := e2248511545462) (by decide)) (by decide)
def e2248511545706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248511545706 : Closed e2248511545706 ∧ code e2248511545706 = 11044604567914 := by decide
private def t_e2248511545706 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2248511545706 : ¬ IsSelfInterpreter e2248511545706 :=
  wSource (t := t_e2248511545706) (replay_sound (ps := []) (t := e2248511545706) (by decide)) (by decide)
def e2248511545754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248511545754 : Closed e2248511545754 ∧ code e2248511545754 = 11044604567962 := by decide
private def t_e2248511545754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2248511545754 : ¬ IsSelfInterpreter e2248511545754 :=
  wSource (t := t_e2248511545754) (replay_sound (ps := []) (t := e2248511545754) (by decide)) (by decide)
def e2248512730650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248512730650 : Closed e2248512730650 ∧ code e2248512730650 = 11044605752858 := by decide
theorem cert_e2248512730650 : check e2248512730650 [[]] .width = true := by decide
def e2248512755226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248512755226 : Closed e2248512755226 ∧ code e2248512755226 = 11044605777434 := by decide
theorem cert_e2248512755226 : check e2248512755226 [[]] .width = true := by decide
def e2248512853530 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248512853530 : Closed e2248512853530 ∧ code e2248512853530 = 11044605875738 := by decide
theorem cert_e2248512853530 : check e2248512853530 [[]] .width = true := by decide
def e2248513123866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248513123866 : Closed e2248513123866 ∧ code e2248513123866 = 11044606146074 := by decide
theorem cert_e2248513123866 : check e2248513123866 [[]] .width = true := by decide
def e2248513148442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248513148442 : Closed e2248513148442 ∧ code e2248513148442 = 11044606170650 := by decide
theorem cert_e2248513148442 : check e2248513148442 [[]] .width = true := by decide
def e2248513360070 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248513360070 : Closed e2248513360070 ∧ code e2248513360070 = 11044606382278 := by decide
theorem cert_e2248513360070 : check e2248513360070 [[]] .width = true := by decide
def e2248513369626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248513369626 : Closed e2248513369626 ∧ code e2248513369626 = 11044606391834 := by decide
theorem cert_e2248513369626 : check e2248513369626 [[]] .width = true := by decide
def e2248513370650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248513370650 : Closed e2248513370650 ∧ code e2248513370650 = 11044606392858 := by decide
theorem cert_e2248513370650 : check e2248513370650 [[]] .width = true := by decide
def e2248513372358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248513372358 : Closed e2248513372358 ∧ code e2248513372358 = 11044606394566 := by decide
theorem cert_e2248513372358 : check e2248513372358 [[]] .width = true := by decide
def e2248513380378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248513380378 : Closed e2248513380378 ∧ code e2248513380378 = 11044606402586 := by decide
theorem cert_e2248513380378 : check e2248513380378 [[]] .width = true := by decide
def e2248513380470 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248513380470 : Closed e2248513380470 ∧ code e2248513380470 = 11044606402678 := by decide
theorem cert_e2248513380470 : check e2248513380470 [[]] .width = true := by decide
def e2248513380714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248513380714 : Closed e2248513380714 ∧ code e2248513380714 = 11044606402922 := by decide
theorem cert_e2248513380714 : check e2248513380714 [[]] .width = true := by decide
def e2248513380762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248513380762 : Closed e2248513380762 ∧ code e2248513380762 = 11044606402970 := by decide
theorem cert_e2248513380762 : check e2248513380762 [[]] .width = true := by decide
def e2248513738266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248513738266 : Closed e2248513738266 ∧ code e2248513738266 = 11044606760474 := by decide
theorem cert_e2248513738266 : check e2248513738266 [[]] .width = true := by decide
def e2248513753286 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248513753286 : Closed e2248513753286 ∧ code e2248513753286 = 11044606775494 := by decide
theorem cert_e2248513753286 : check e2248513753286 [[]] .width = true := by decide
def e2248513762842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248513762842 : Closed e2248513762842 ∧ code e2248513762842 = 11044606785050 := by decide
theorem cert_e2248513762842 : check e2248513762842 [[]] .width = true := by decide
def e2248513763866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248513763866 : Closed e2248513763866 ∧ code e2248513763866 = 11044606786074 := by decide
theorem cert_e2248513763866 : check e2248513763866 [[]] .width = true := by decide
def e2248513765574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248513765574 : Closed e2248513765574 ∧ code e2248513765574 = 11044606787782 := by decide
theorem cert_e2248513765574 : check e2248513765574 [[]] .width = true := by decide
def e2248513773594 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248513773594 : Closed e2248513773594 ∧ code e2248513773594 = 11044606795802 := by decide
theorem cert_e2248513773594 : check e2248513773594 [[]] .width = true := by decide
def e2248513773686 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248513773686 : Closed e2248513773686 ∧ code e2248513773686 = 11044606795894 := by decide
theorem cert_e2248513773686 : check e2248513773686 [[]] .width = true := by decide
def e2248513773930 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248513773930 : Closed e2248513773930 ∧ code e2248513773930 = 11044606796138 := by decide
theorem cert_e2248513773930 : check e2248513773930 [[]] .width = true := by decide
def e2248513773978 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248513773978 : Closed e2248513773978 ∧ code e2248513773978 = 11044606796186 := by decide
theorem cert_e2248513773978 : check e2248513773978 [[]] .width = true := by decide
def e2248514385434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514385434 : Closed e2248514385434 ∧ code e2248514385434 = 11044607407642 := by decide
private def t_e2248514385434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248514385434 : ¬ IsSelfInterpreter e2248514385434 :=
  wSource (t := t_e2248514385434) (replay_sound (ps := []) (t := e2248514385434) (by decide)) (by decide)
def e2248514393626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514393626 : Closed e2248514393626 ∧ code e2248514393626 = 11044607415834 := by decide
theorem cert_e2248514393626 : check e2248514393626 [[]] .width = true := by decide
def e2248514426394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514426394 : Closed e2248514426394 ∧ code e2248514426394 = 11044607448602 := by decide
theorem cert_e2248514426394 : check e2248514426394 [[]] .width = true := by decide
def e2248514582042 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514582042 : Closed e2248514582042 ∧ code e2248514582042 = 11044607604250 := by decide
private def t_e2248514582042 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248514582042 : ¬ IsSelfInterpreter e2248514582042 :=
  wSource (t := t_e2248514582042) (replay_sound (ps := []) (t := e2248514582042) (by decide)) (by decide)
def e2248514590234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514590234 : Closed e2248514590234 ∧ code e2248514590234 = 11044607612442 := by decide
private def t_e2248514590234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248514590234 : ¬ IsSelfInterpreter e2248514590234 :=
  wSource (t := t_e2248514590234) (replay_sound (ps := []) (t := e2248514590234) (by decide)) (by decide)
def e2248514670790 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248514670790 : Closed e2248514670790 ∧ code e2248514670790 = 11044607692998 := by decide
theorem cert_e2248514670790 : check e2248514670790 [[]] .width = true := by decide
def e2248514680346 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514680346 : Closed e2248514680346 ∧ code e2248514680346 = 11044607702554 := by decide
private def t_e2248514680346 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248514680346 : ¬ IsSelfInterpreter e2248514680346 :=
  wSource (t := t_e2248514680346) (replay_sound (ps := []) (t := e2248514680346) (by decide)) (by decide)
def e2248514681370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514681370 : Closed e2248514681370 ∧ code e2248514681370 = 11044607703578 := by decide
private def t_e2248514681370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248514681370 : ¬ IsSelfInterpreter e2248514681370 :=
  wSource (t := t_e2248514681370) (replay_sound (ps := []) (t := e2248514681370) (by decide)) (by decide)
def e2248514683078 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248514683078 : Closed e2248514683078 ∧ code e2248514683078 = 11044607705286 := by decide
theorem cert_e2248514683078 : check e2248514683078 [[]] .width = true := by decide
def e2248514691098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248514691098 : Closed e2248514691098 ∧ code e2248514691098 = 11044607713306 := by decide
theorem cert_e2248514691098 : check e2248514691098 [[]] .width = true := by decide
def e2248514691190 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248514691190 : Closed e2248514691190 ∧ code e2248514691190 = 11044607713398 := by decide
private def t_e2248514691190 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2248514691190 : ¬ IsSelfInterpreter e2248514691190 :=
  wSource (t := t_e2248514691190) (replay_sound (ps := []) (t := e2248514691190) (by decide)) (by decide)
def e2248514691434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248514691434 : Closed e2248514691434 ∧ code e2248514691434 = 11044607713642 := by decide
private def t_e2248514691434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2248514691434 : ¬ IsSelfInterpreter e2248514691434 :=
  wSource (t := t_e2248514691434) (replay_sound (ps := []) (t := e2248514691434) (by decide)) (by decide)
def e2248514691482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248514691482 : Closed e2248514691482 ∧ code e2248514691482 = 11044607713690 := by decide
private def t_e2248514691482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2248514691482 : ¬ IsSelfInterpreter e2248514691482 :=
  wSource (t := t_e2248514691482) (replay_sound (ps := []) (t := e2248514691482) (by decide)) (by decide)
def e2248514786842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514786842 : Closed e2248514786842 ∧ code e2248514786842 = 11044607809050 := by decide
theorem cert_e2248514786842 : check e2248514786842 [[]] .width = true := by decide
def e2248514801862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248514801862 : Closed e2248514801862 ∧ code e2248514801862 = 11044607824070 := by decide
theorem cert_e2248514801862 : check e2248514801862 [[]] .width = true := by decide
def e2248514811418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514811418 : Closed e2248514811418 ∧ code e2248514811418 = 11044607833626 := by decide
theorem cert_e2248514811418 : check e2248514811418 [[]] .width = true := by decide
def e2248514812442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248514812442 : Closed e2248514812442 ∧ code e2248514812442 = 11044607834650 := by decide
theorem cert_e2248514812442 : check e2248514812442 [[]] .width = true := by decide
def e2248514814150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248514814150 : Closed e2248514814150 ∧ code e2248514814150 = 11044607836358 := by decide
theorem cert_e2248514814150 : check e2248514814150 [[]] .width = true := by decide
def e2248514822170 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248514822170 : Closed e2248514822170 ∧ code e2248514822170 = 11044607844378 := by decide
theorem cert_e2248514822170 : check e2248514822170 [[]] .width = true := by decide
def e2248514822262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248514822262 : Closed e2248514822262 ∧ code e2248514822262 = 11044607844470 := by decide
theorem cert_e2248514822262 : check e2248514822262 [[]] .width = true := by decide
def e2248514822506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248514822506 : Closed e2248514822506 ∧ code e2248514822506 = 11044607844714 := by decide
theorem cert_e2248514822506 : check e2248514822506 [[]] .width = true := by decide
def e2248514822554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248514822554 : Closed e2248514822554 ∧ code e2248514822554 = 11044607844762 := by decide
theorem cert_e2248514822554 : check e2248514822554 [[]] .width = true := by decide
def e2248518071834 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248518071834 : Closed e2248518071834 ∧ code e2248518071834 = 11044611094042 := by decide
theorem cert_e2248518071834 : check e2248518071834 [[]] .width = true := by decide
def e2248518104602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248518104602 : Closed e2248518104602 ∧ code e2248518104602 = 11044611126810 := by decide
theorem cert_e2248518104602 : check e2248518104602 [[]] .width = true := by decide
def e2248522036762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522036762 : Closed e2248522036762 ∧ code e2248522036762 = 11044615058970 := by decide
theorem cert_e2248522036762 : check e2248522036762 [[]] .width = true := by decide
def e2248522053146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522053146 : Closed e2248522053146 ∧ code e2248522053146 = 11044615075354 := by decide
private def t_e2248522053146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248522053146 : ¬ IsSelfInterpreter e2248522053146 :=
  wSource (t := t_e2248522053146) (replay_sound (ps := []) (t := e2248522053146) (by decide)) (by decide)
def e2248522167834 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522167834 : Closed e2248522167834 ∧ code e2248522167834 = 11044615190042 := by decide
theorem cert_e2248522167834 : check e2248522167834 [[]] .width = true := by decide
def e2248522192410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522192410 : Closed e2248522192410 ∧ code e2248522192410 = 11044615214618 := by decide
theorem cert_e2248522192410 : check e2248522192410 [[]] .width = true := by decide
def e2248522249754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522249754 : Closed e2248522249754 ∧ code e2248522249754 = 11044615271962 := by decide
private def t_e2248522249754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248522249754 : ¬ IsSelfInterpreter e2248522249754 :=
  wSource (t := t_e2248522249754) (replay_sound (ps := []) (t := e2248522249754) (by decide)) (by decide)
def e2248522257946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522257946 : Closed e2248522257946 ∧ code e2248522257946 = 11044615280154 := by decide
theorem cert_e2248522257946 : check e2248522257946 [[]] .width = true := by decide
def e2248522823194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522823194 : Closed e2248522823194 ∧ code e2248522823194 = 11044615845402 := by decide
theorem cert_e2248522823194 : check e2248522823194 [[]] .width = true := by decide
def e2248522839578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248522839578 : Closed e2248522839578 ∧ code e2248522839578 = 11044615861786 := by decide
theorem cert_e2248522839578 : check e2248522839578 [[]] .width = true := by decide
def e2248523609626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248523609626 : Closed e2248523609626 ∧ code e2248523609626 = 11044616631834 := by decide
theorem cert_e2248523609626 : check e2248523609626 [[]] .width = true := by decide
def e2248523634202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248523634202 : Closed e2248523634202 ∧ code e2248523634202 = 11044616656410 := by decide
theorem cert_e2248523634202 : check e2248523634202 [[]] .width = true := by decide
def e2248523845830 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248523845830 : Closed e2248523845830 ∧ code e2248523845830 = 11044616868038 := by decide
theorem cert_e2248523845830 : check e2248523845830 [[]] .width = true := by decide
def e2248523855386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248523855386 : Closed e2248523855386 ∧ code e2248523855386 = 11044616877594 := by decide
theorem cert_e2248523855386 : check e2248523855386 [[]] .width = true := by decide
def e2248523856410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248523856410 : Closed e2248523856410 ∧ code e2248523856410 = 11044616878618 := by decide
theorem cert_e2248523856410 : check e2248523856410 [[]] .width = true := by decide
def e2248523858118 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248523858118 : Closed e2248523858118 ∧ code e2248523858118 = 11044616880326 := by decide
theorem cert_e2248523858118 : check e2248523858118 [[]] .width = true := by decide
def e2248523866138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248523866138 : Closed e2248523866138 ∧ code e2248523866138 = 11044616888346 := by decide
theorem cert_e2248523866138 : check e2248523866138 [[]] .width = true := by decide
def e2248523866230 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248523866230 : Closed e2248523866230 ∧ code e2248523866230 = 11044616888438 := by decide
theorem cert_e2248523866230 : check e2248523866230 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2248506308122
#print axioms Blc.Floor43.cert_e2248506324506
#print axioms Blc.Floor43.cert_e2248506521114
#print axioms Blc.Floor43.cert_e2248506529306
#print axioms Blc.Floor43.cert_e2248507307546
#print axioms Blc.Floor43.cert_e2248507315738
#print axioms Blc.Floor43.cert_e2248509470234
#print axioms Blc.Floor43.cert_e2248509666842
#print axioms Blc.Floor43.cert_e2248510240282
#print axioms Blc.Floor43.cert_e2248510256666
#print axioms Blc.Floor43.cert_e2248511436314
#print axioms Blc.Floor43.cert_e2248511444506
#print axioms Blc.Floor43.cert_e2248511534618
#print axioms Blc.Floor43.cert_e2248511535642
#print axioms Blc.Floor43.cert_e2248511545462
#print axioms Blc.Floor43.cert_e2248511545706
#print axioms Blc.Floor43.cert_e2248511545754
#print axioms Blc.Floor43.cert_e2248514385434
#print axioms Blc.Floor43.cert_e2248514582042
#print axioms Blc.Floor43.cert_e2248514590234
#print axioms Blc.Floor43.cert_e2248514680346
#print axioms Blc.Floor43.cert_e2248514681370
#print axioms Blc.Floor43.cert_e2248514691190
#print axioms Blc.Floor43.cert_e2248514691434
#print axioms Blc.Floor43.cert_e2248514691482
#print axioms Blc.Floor43.cert_e2248522053146
#print axioms Blc.Floor43.cert_e2248522249754
