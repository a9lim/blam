import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389344757658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344757658 : Closed e2389344757658 ∧ code e2389344757658 = 11185437779866 := by decide
theorem cert_e2389344757658 : check e2389344757658 [[],[.left],[]] .chain = true := by decide
def e2389344760606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2389344760606 : Closed e2389344760606 ∧ code e2389344760606 = 11185437782814 := by decide
theorem cert_e2389344760606 : check e2389344760606 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344760774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2389344760774 : Closed e2389344760774 ∧ code e2389344760774 = 11185437782982 := by decide
theorem cert_e2389344760774 : check e2389344760774 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389344761974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2389344761974 : Closed e2389344761974 ∧ code e2389344761974 = 11185437784182 := by decide
theorem cert_e2389344761974 : check e2389344761974 [[],[.left],[]] .chain = true := by decide
def e2389344762218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2389344762218 : Closed e2389344762218 ∧ code e2389344762218 = 11185437784426 := by decide
theorem cert_e2389344762218 : check e2389344762218 [[],[.left],[]] .chain = true := by decide
def e2389344762254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2389344762254 : Closed e2389344762254 ∧ code e2389344762254 = 11185437784462 := by decide
theorem cert_e2389344762254 : check e2389344762254 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2389344762266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344762266 : Closed e2389344762266 ∧ code e2389344762266 = 11185437784474 := by decide
theorem cert_e2389344762266 : check e2389344762266 [[],[.left],[]] .chain = true := by decide
def e2389344762310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2389344762310 : Closed e2389344762310 ∧ code e2389344762310 = 11185437784518 := by decide
theorem cert_e2389344762310 : check e2389344762310 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2389344764854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2389344764854 : Closed e2389344764854 ∧ code e2389344764854 = 11185437787062 := by decide
theorem cert_e2389344764854 : check e2389344764854 [[],[.left],[]] .chain = true := by decide
def e2389344764858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2389344764858 : Closed e2389344764858 ∧ code e2389344764858 = 11185437787066 := by decide
theorem cert_e2389344764858 : check e2389344764858 [[],[.left],[]] .chain = true := by decide
def e2389344764890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2389344764890 : Closed e2389344764890 ∧ code e2389344764890 = 11185437787098 := by decide
theorem cert_e2389344764890 : check e2389344764890 [[],[.left],[]] .chain = true := by decide
def e2389344765558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2389344765558 : Closed e2389344765558 ∧ code e2389344765558 = 11185437787766 := by decide
theorem cert_e2389344765558 : check e2389344765558 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2389344765750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344765750 : Closed e2389344765750 ∧ code e2389344765750 = 11185437787958 := by decide
theorem cert_e2389344765750 : check e2389344765750 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2389344765754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344765754 : Closed e2389344765754 ∧ code e2389344765754 = 11185437787962 := by decide
theorem cert_e2389344765754 : check e2389344765754 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2389344766806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2389344766806 : Closed e2389344766806 ∧ code e2389344766806 = 11185437789014 := by decide
theorem cert_e2389344766806 : check e2389344766806 [[],[.left],[]] .chain = true := by decide
def e2389344766810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2389344766810 : Closed e2389344766810 ∧ code e2389344766810 = 11185437789018 := by decide
theorem cert_e2389344766810 : check e2389344766810 [[],[.left],[]] .chain = true := by decide
def e2389344766826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2389344766826 : Closed e2389344766826 ∧ code e2389344766826 = 11185437789034 := by decide
theorem cert_e2389344766826 : check e2389344766826 [[],[.left],[]] .chain = true := by decide
def e2389344766890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2389344766890 : Closed e2389344766890 ∧ code e2389344766890 = 11185437789098 := by decide
theorem cert_e2389344766890 : check e2389344766890 [[],[.left],[]] .chain = true := by decide
def e2389344767094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2389344767094 : Closed e2389344767094 ∧ code e2389344767094 = 11185437789302 := by decide
theorem cert_e2389344767094 : check e2389344767094 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389344767190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2389344767190 : Closed e2389344767190 ∧ code e2389344767190 = 11185437789398 := by decide
theorem cert_e2389344767190 : check e2389344767190 [[],[.left],[]] .chain = true := by decide
def e2389344767194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2389344767194 : Closed e2389344767194 ∧ code e2389344767194 = 11185437789402 := by decide
theorem cert_e2389344767194 : check e2389344767194 [[],[.left],[]] .chain = true := by decide
def e2389344767210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2389344767210 : Closed e2389344767210 ∧ code e2389344767210 = 11185437789418 := by decide
theorem cert_e2389344767210 : check e2389344767210 [[],[.left],[]] .chain = true := by decide
def e2389344767286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344767286 : Closed e2389344767286 ∧ code e2389344767286 = 11185437789494 := by decide
theorem cert_e2389344767286 : check e2389344767286 [[],[.left],[]] .chain = true := by decide
def e2389344767290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344767290 : Closed e2389344767290 ∧ code e2389344767290 = 11185437789498 := by decide
theorem cert_e2389344767290 : check e2389344767290 [[],[.left],[]] .chain = true := by decide
def e2389344767374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2389344767374 : Closed e2389344767374 ∧ code e2389344767374 = 11185437789582 := by decide
theorem cert_e2389344767374 : check e2389344767374 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389344767386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344767386 : Closed e2389344767386 ∧ code e2389344767386 = 11185437789594 := by decide
theorem cert_e2389344767386 : check e2389344767386 [[],[.left],[]] .chain = true := by decide
def e2389344767542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2389344767542 : Closed e2389344767542 ∧ code e2389344767542 = 11185437789750 := by decide
theorem cert_e2389344767542 : check e2389344767542 [[],[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .smaller = true := by decide
def e2389344767546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2389344767546 : Closed e2389344767546 ∧ code e2389344767546 = 11185437789754 := by decide
theorem cert_e2389344767546 : check e2389344767546 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2389344767594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2389344767594 : Closed e2389344767594 ∧ code e2389344767594 = 11185437789802 := by decide
theorem cert_e2389344767594 : check e2389344767594 [[],[.left],[]] .chain = true := by decide
def e2389344767630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2389344767630 : Closed e2389344767630 ∧ code e2389344767630 = 11185437789838 := by decide
theorem cert_e2389344767630 : checkPay e2389344767630 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2389344767642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344767642 : Closed e2389344767642 ∧ code e2389344767642 = 11185437789850 := by decide
theorem cert_e2389344767642 : check e2389344767642 [[],[.left],[]] .chain = true := by decide
def e2389344767686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2389344767686 : Closed e2389344767686 ∧ code e2389344767686 = 11185437789894 := by decide
theorem cert_e2389344767686 : check e2389344767686 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2389344768238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2389344768238 : Closed e2389344768238 ∧ code e2389344768238 = 11185437790446 := by decide
theorem cert_e2389344768238 : check e2389344768238 [[],[.left],[]] .chain = true := by decide
def e2389344768246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2389344768246 : Closed e2389344768246 ∧ code e2389344768246 = 11185437790454 := by decide
theorem cert_e2389344768246 : check e2389344768246 [[],[.left],[]] .chain = true := by decide
def e2389344768726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2389344768726 : Closed e2389344768726 ∧ code e2389344768726 = 11185437790934 := by decide
theorem cert_e2389344768726 : check e2389344768726 [[],[.left],[]] .chain = true := by decide
def e2389344768730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2389344768730 : Closed e2389344768730 ∧ code e2389344768730 = 11185437790938 := by decide
theorem cert_e2389344768730 : check e2389344768730 [[],[.left],[]] .chain = true := by decide
def e2389344768746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2389344768746 : Closed e2389344768746 ∧ code e2389344768746 = 11185437790954 := by decide
theorem cert_e2389344768746 : check e2389344768746 [[],[.left],[]] .chain = true := by decide
def e2389344768822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344768822 : Closed e2389344768822 ∧ code e2389344768822 = 11185437791030 := by decide
theorem cert_e2389344768822 : check e2389344768822 [[],[.left],[]] .chain = true := by decide
def e2389344768826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344768826 : Closed e2389344768826 ∧ code e2389344768826 = 11185437791034 := by decide
theorem cert_e2389344768826 : check e2389344768826 [[],[.left],[]] .chain = true := by decide
def e2389344768910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2389344768910 : Closed e2389344768910 ∧ code e2389344768910 = 11185437791118 := by decide
theorem cert_e2389344768910 : check e2389344768910 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389344768922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344768922 : Closed e2389344768922 ∧ code e2389344768922 = 11185437791130 := by decide
theorem cert_e2389344768922 : check e2389344768922 [[],[.left],[]] .chain = true := by decide
def e2389344770166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2389344770166 : Closed e2389344770166 ∧ code e2389344770166 = 11185437792374 := by decide
theorem cert_e2389344770166 : check e2389344770166 [[],[.left],[]] .chain = true := by decide
def e2389344770410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2389344770410 : Closed e2389344770410 ∧ code e2389344770410 = 11185437792618 := by decide
theorem cert_e2389344770410 : check e2389344770410 [[],[.left],[]] .chain = true := by decide
def e2389344770446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2389344770446 : Closed e2389344770446 ∧ code e2389344770446 = 11185437792654 := by decide
theorem cert_e2389344770446 : check e2389344770446 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389344770458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344770458 : Closed e2389344770458 ∧ code e2389344770458 = 11185437792666 := by decide
theorem cert_e2389344770458 : check e2389344770458 [[],[.left],[]] .chain = true := by decide
def e2389344770502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2389344770502 : Closed e2389344770502 ∧ code e2389344770502 = 11185437792710 := by decide
theorem cert_e2389344770502 : check e2389344770502 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389344783214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2389344783214 : Closed e2389344783214 ∧ code e2389344783214 = 11185437805422 := by decide
theorem cert_e2389344783214 : check e2389344783214 [[],[.left],[]] .smaller = true := by decide
def e2389344783222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2389344783222 : Closed e2389344783222 ∧ code e2389344783222 = 11185437805430 := by decide
theorem cert_e2389344783222 : check e2389344783222 [[],[.left],[]] .smaller = true := by decide
def e2389344783278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2389344783278 : Closed e2389344783278 ∧ code e2389344783278 = 11185437805486 := by decide
theorem cert_e2389344783278 : check e2389344783278 [[],[.left],[]] .smaller = true := by decide
def e2389344783290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2389344783290 : Closed e2389344783290 ∧ code e2389344783290 = 11185437805498 := by decide
theorem cert_e2389344783290 : check e2389344783290 [[],[.left],[]] .smaller = true := by decide
def e2389344783318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2389344783318 : Closed e2389344783318 ∧ code e2389344783318 = 11185437805526 := by decide
theorem cert_e2389344783318 : check e2389344783318 [[],[.left],[]] .smaller = true := by decide
def e2389344783322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2389344783322 : Closed e2389344783322 ∧ code e2389344783322 = 11185437805530 := by decide
theorem cert_e2389344783322 : check e2389344783322 [[],[.left],[]] .smaller = true := by decide
def e2389344783598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2389344783598 : Closed e2389344783598 ∧ code e2389344783598 = 11185437805806 := by decide
theorem cert_e2389344783598 : check e2389344783598 [[],[.left],[]] .smaller = true := by decide
def e2389344783606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2389344783606 : Closed e2389344783606 ∧ code e2389344783606 = 11185437805814 := by decide
theorem cert_e2389344783606 : check e2389344783606 [[],[.left],[]] .smaller = true := by decide
def e2389344783982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2389344783982 : Closed e2389344783982 ∧ code e2389344783982 = 11185437806190 := by decide
theorem cert_e2389344783982 : check e2389344783982 [[],[.left],[]] .smaller = true := by decide
def e2389344783994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2389344783994 : Closed e2389344783994 ∧ code e2389344783994 = 11185437806202 := by decide
theorem cert_e2389344783994 : check e2389344783994 [[],[.left],[]] .smaller = true := by decide
def e2389344784182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2389344784182 : Closed e2389344784182 ∧ code e2389344784182 = 11185437806390 := by decide
theorem cert_e2389344784182 : check e2389344784182 [[],[.left],[]] .smaller = true := by decide
def e2389344784186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2389344784186 : Closed e2389344784186 ∧ code e2389344784186 = 11185437806394 := by decide
theorem cert_e2389344784186 : check e2389344784186 [[],[.left],[]] .smaller = true := by decide
def e2389344824686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2389344824686 : Closed e2389344824686 ∧ code e2389344824686 = 11185437846894 := by decide
theorem cert_e2389344824686 : check e2389344824686 [[],[.left],[]] .chain = true := by decide
def e2389344824694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2389344824694 : Closed e2389344824694 ∧ code e2389344824694 = 11185437846902 := by decide
theorem cert_e2389344824694 : check e2389344824694 [[],[.left],[]] .chain = true := by decide
def e2389344824750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2389344824750 : Closed e2389344824750 ∧ code e2389344824750 = 11185437846958 := by decide
theorem cert_e2389344824750 : check e2389344824750 [[],[.left],[]] .chain = true := by decide
def e2389344824762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2389344824762 : Closed e2389344824762 ∧ code e2389344824762 = 11185437846970 := by decide
theorem cert_e2389344824762 : check e2389344824762 [[],[.left],[]] .chain = true := by decide
def e2389344824790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2389344824790 : Closed e2389344824790 ∧ code e2389344824790 = 11185437846998 := by decide
theorem cert_e2389344824790 : check e2389344824790 [[],[.left],[]] .chain = true := by decide
def e2389344824794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2389344824794 : Closed e2389344824794 ∧ code e2389344824794 = 11185437847002 := by decide
theorem cert_e2389344824794 : check e2389344824794 [[],[.left],[]] .chain = true := by decide
def e2389344825006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2389344825006 : Closed e2389344825006 ∧ code e2389344825006 = 11185437847214 := by decide
theorem cert_e2389344825006 : check e2389344825006 [[],[.left],[]] .chain = true := by decide
def e2389344825018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2389344825018 : Closed e2389344825018 ∧ code e2389344825018 = 11185437847226 := by decide
theorem cert_e2389344825018 : check e2389344825018 [[],[.left],[]] .chain = true := by decide
def e2389344825066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2389344825066 : Closed e2389344825066 ∧ code e2389344825066 = 11185437847274 := by decide
theorem cert_e2389344825066 : check e2389344825066 [[],[.left],[]] .chain = true := by decide
def e2389344825174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2389344825174 : Closed e2389344825174 ∧ code e2389344825174 = 11185437847382 := by decide
theorem cert_e2389344825174 : check e2389344825174 [[],[.left],[]] .chain = true := by decide
def e2389344825178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2389344825178 : Closed e2389344825178 ∧ code e2389344825178 = 11185437847386 := by decide
theorem cert_e2389344825178 : check e2389344825178 [[],[.left],[]] .chain = true := by decide
def e2389344825194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2389344825194 : Closed e2389344825194 ∧ code e2389344825194 = 11185437847402 := by decide
theorem cert_e2389344825194 : check e2389344825194 [[],[.left],[]] .chain = true := by decide
def e2389344826222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2389344826222 : Closed e2389344826222 ∧ code e2389344826222 = 11185437848430 := by decide
theorem cert_e2389344826222 : check e2389344826222 [[],[.left],[]] .chain = true := by decide
def e2389344826230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2389344826230 : Closed e2389344826230 ∧ code e2389344826230 = 11185437848438 := by decide
theorem cert_e2389344826230 : check e2389344826230 [[],[.left],[]] .chain = true := by decide
def e2389344826286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2389344826286 : Closed e2389344826286 ∧ code e2389344826286 = 11185437848494 := by decide
theorem cert_e2389344826286 : check e2389344826286 [[],[.left],[]] .chain = true := by decide
def e2389344826298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2389344826298 : Closed e2389344826298 ∧ code e2389344826298 = 11185437848506 := by decide
theorem cert_e2389344826298 : check e2389344826298 [[],[.left],[]] .chain = true := by decide
def e2389344826326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2389344826326 : Closed e2389344826326 ∧ code e2389344826326 = 11185437848534 := by decide
theorem cert_e2389344826326 : check e2389344826326 [[],[.left],[]] .chain = true := by decide
def e2389344826330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2389344826330 : Closed e2389344826330 ∧ code e2389344826330 = 11185437848538 := by decide
theorem cert_e2389344826330 : check e2389344826330 [[],[.left],[]] .chain = true := by decide
def e2389344826606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2389344826606 : Closed e2389344826606 ∧ code e2389344826606 = 11185437848814 := by decide
theorem cert_e2389344826606 : check e2389344826606 [[],[.left],[]] .chain = true := by decide
def e2389344826614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2389344826614 : Closed e2389344826614 ∧ code e2389344826614 = 11185437848822 := by decide
theorem cert_e2389344826614 : check e2389344826614 [[],[.left],[]] .chain = true := by decide
def e2389344826990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344826990 : Closed e2389344826990 ∧ code e2389344826990 = 11185437849198 := by decide
theorem cert_e2389344826990 : check e2389344826990 [[],[.left],[]] .chain = true := by decide
def e2389344827002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344827002 : Closed e2389344827002 ∧ code e2389344827002 = 11185437849210 := by decide
theorem cert_e2389344827002 : check e2389344827002 [[],[.left],[]] .chain = true := by decide
def e2389344827190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344827190 : Closed e2389344827190 ∧ code e2389344827190 = 11185437849398 := by decide
theorem cert_e2389344827190 : check e2389344827190 [[],[.left],[]] .chain = true := by decide
def e2389344827194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344827194 : Closed e2389344827194 ∧ code e2389344827194 = 11185437849402 := by decide
theorem cert_e2389344827194 : check e2389344827194 [[],[.left],[]] .chain = true := by decide
def e2389344827630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2389344827630 : Closed e2389344827630 ∧ code e2389344827630 = 11185437849838 := by decide
theorem cert_e2389344827630 : check e2389344827630 [[],[.left],[]] .sourceHead = true := by decide
def e2389344827638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2389344827638 : Closed e2389344827638 ∧ code e2389344827638 = 11185437849846 := by decide
theorem cert_e2389344827638 : check e2389344827638 [[],[.left],[]] .sourceHead = true := by decide
def e2389344827822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2389344827822 : Closed e2389344827822 ∧ code e2389344827822 = 11185437850030 := by decide
theorem cert_e2389344827822 : check e2389344827822 [[],[.left],[]] .chain = true := by decide
def e2389344827834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2389344827834 : Closed e2389344827834 ∧ code e2389344827834 = 11185437850042 := by decide
theorem cert_e2389344827834 : check e2389344827834 [[],[.left],[]] .chain = true := by decide
def e2389344827882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2389344827882 : Closed e2389344827882 ∧ code e2389344827882 = 11185437850090 := by decide
theorem cert_e2389344827882 : check e2389344827882 [[],[.left],[]] .chain = true := by decide
def e2389344828014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344828014 : Closed e2389344828014 ∧ code e2389344828014 = 11185437850222 := by decide
theorem cert_e2389344828014 : check e2389344828014 [[],[.left],[]] .chain = true := by decide
def e2389344828026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344828026 : Closed e2389344828026 ∧ code e2389344828026 = 11185437850234 := by decide
theorem cert_e2389344828026 : check e2389344828026 [[],[.left],[]] .chain = true := by decide
def e2389344828190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2389344828190 : Closed e2389344828190 ∧ code e2389344828190 = 11185437850398 := by decide
theorem cert_e2389344828190 : check e2389344828190 [[],[.left],[]] .sourceHead = true := by decide
def e2389344828302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2389344828302 : Closed e2389344828302 ∧ code e2389344828302 = 11185437850510 := by decide
theorem cert_e2389344828302 : check e2389344828302 [[],[.left],[]] .sourceHead = true := by decide
def e2389344828314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344828314 : Closed e2389344828314 ∧ code e2389344828314 = 11185437850522 := by decide
theorem cert_e2389344828314 : check e2389344828314 [[],[.left],[]] .chain = true := by decide
def e2389344828534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2389344828534 : Closed e2389344828534 ∧ code e2389344828534 = 11185437850742 := by decide
theorem cert_e2389344828534 : check e2389344828534 [[],[.left],[]] .sourceHead = true := by decide
def e2389344828630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2389344828630 : Closed e2389344828630 ∧ code e2389344828630 = 11185437850838 := by decide
theorem cert_e2389344828630 : check e2389344828630 [[],[.left],[]] .chain = true := by decide
def e2389344828634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2389344828634 : Closed e2389344828634 ∧ code e2389344828634 = 11185437850842 := by decide
theorem cert_e2389344828634 : check e2389344828634 [[],[.left],[]] .chain = true := by decide
def e2389344828650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2389344828650 : Closed e2389344828650 ∧ code e2389344828650 = 11185437850858 := by decide
theorem cert_e2389344828650 : check e2389344828650 [[],[.left],[]] .chain = true := by decide
def e2389344828726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344828726 : Closed e2389344828726 ∧ code e2389344828726 = 11185437850934 := by decide
theorem cert_e2389344828726 : check e2389344828726 [[],[.left],[]] .chain = true := by decide
def e2389344828730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344828730 : Closed e2389344828730 ∧ code e2389344828730 = 11185437850938 := by decide
theorem cert_e2389344828730 : check e2389344828730 [[],[.left],[]] .chain = true := by decide
def e2389344828814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2389344828814 : Closed e2389344828814 ∧ code e2389344828814 = 11185437851022 := by decide
theorem cert_e2389344828814 : check e2389344828814 [[],[.left],[]] .sourceHead = true := by decide
def e2389344828826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344828826 : Closed e2389344828826 ∧ code e2389344828826 = 11185437851034 := by decide
theorem cert_e2389344828826 : check e2389344828826 [[],[.left],[]] .chain = true := by decide
def e2389344830430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2389344830430 : Closed e2389344830430 ∧ code e2389344830430 = 11185437852638 := by decide
theorem cert_e2389344830430 : check e2389344830430 [[],[.left],[]] .chain = true := by decide
def e2389344830446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2389344830446 : Closed e2389344830446 ∧ code e2389344830446 = 11185437852654 := by decide
theorem cert_e2389344830446 : check e2389344830446 [[],[.left],[]] .chain = true := by decide
def e2389344832366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389344832366 : Closed e2389344832366 ∧ code e2389344832366 = 11185437854574 := by decide
theorem cert_e2389344832366 : check e2389344832366 [[],[.left],[]] .chain = true := by decide
def e2389344832374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389344832374 : Closed e2389344832374 ∧ code e2389344832374 = 11185437854582 := by decide
theorem cert_e2389344832374 : check e2389344832374 [[],[.left],[]] .chain = true := by decide
def e2389344832430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389344832430 : Closed e2389344832430 ∧ code e2389344832430 = 11185437854638 := by decide
theorem cert_e2389344832430 : check e2389344832430 [[],[.left],[]] .chain = true := by decide
def e2389344832442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389344832442 : Closed e2389344832442 ∧ code e2389344832442 = 11185437854650 := by decide
theorem cert_e2389344832442 : check e2389344832442 [[],[.left],[]] .chain = true := by decide
def e2389344832470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389344832470 : Closed e2389344832470 ∧ code e2389344832470 = 11185437854678 := by decide
theorem cert_e2389344832470 : check e2389344832470 [[],[.left],[]] .chain = true := by decide
def e2389344832474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389344832474 : Closed e2389344832474 ∧ code e2389344832474 = 11185437854682 := by decide
theorem cert_e2389344832474 : check e2389344832474 [[],[.left],[]] .chain = true := by decide
def e2389344832750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389344832750 : Closed e2389344832750 ∧ code e2389344832750 = 11185437854958 := by decide
theorem cert_e2389344832750 : check e2389344832750 [[],[.left],[]] .chain = true := by decide
def e2389344832758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389344832758 : Closed e2389344832758 ∧ code e2389344832758 = 11185437854966 := by decide
theorem cert_e2389344832758 : check e2389344832758 [[],[.left],[]] .chain = true := by decide
def e2389344833134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344833134 : Closed e2389344833134 ∧ code e2389344833134 = 11185437855342 := by decide
theorem cert_e2389344833134 : check e2389344833134 [[],[.left],[]] .chain = true := by decide
def e2389344833146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344833146 : Closed e2389344833146 ∧ code e2389344833146 = 11185437855354 := by decide
theorem cert_e2389344833146 : check e2389344833146 [[],[.left],[]] .chain = true := by decide
def e2389344833334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344833334 : Closed e2389344833334 ∧ code e2389344833334 = 11185437855542 := by decide
theorem cert_e2389344833334 : check e2389344833334 [[],[.left],[]] .chain = true := by decide
def e2389344833338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344833338 : Closed e2389344833338 ∧ code e2389344833338 = 11185437855546 := by decide
theorem cert_e2389344833338 : check e2389344833338 [[],[.left],[]] .chain = true := by decide
def e2389344838110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2389344838110 : Closed e2389344838110 ∧ code e2389344838110 = 11185437860318 := by decide
theorem cert_e2389344838110 : check e2389344838110 [[],[.left],[]] .chain = true := by decide
def e2389344838134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2389344838134 : Closed e2389344838134 ∧ code e2389344838134 = 11185437860342 := by decide
theorem cert_e2389344838134 : check e2389344838134 [[],[.left],[]] .chain = true := by decide
def e2389344839086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2389344839086 : Closed e2389344839086 ∧ code e2389344839086 = 11185437861294 := by decide
theorem cert_e2389344839086 : check e2389344839086 [[],[.left],[]] .chain = true := by decide
def e2389344839098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2389344839098 : Closed e2389344839098 ∧ code e2389344839098 = 11185437861306 := by decide
theorem cert_e2389344839098 : check e2389344839098 [[],[.left],[]] .chain = true := by decide
def e2389344839146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2389344839146 : Closed e2389344839146 ∧ code e2389344839146 = 11185437861354 := by decide
theorem cert_e2389344839146 : check e2389344839146 [[],[.left],[]] .chain = true := by decide
def e2389344839278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344839278 : Closed e2389344839278 ∧ code e2389344839278 = 11185437861486 := by decide
theorem cert_e2389344839278 : check e2389344839278 [[],[.left],[]] .chain = true := by decide
def e2389344839290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344839290 : Closed e2389344839290 ∧ code e2389344839290 = 11185437861498 := by decide
theorem cert_e2389344839290 : check e2389344839290 [[],[.left],[]] .chain = true := by decide
def e2389344839454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2389344839454 : Closed e2389344839454 ∧ code e2389344839454 = 11185437861662 := by decide
theorem cert_e2389344839454 : check e2389344839454 [[],[.left],[]] .sourceHead = true := by decide
def e2389344839566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2389344839566 : Closed e2389344839566 ∧ code e2389344839566 = 11185437861774 := by decide
theorem cert_e2389344839566 : check e2389344839566 [[],[.left],[]] .sourceHead = true := by decide
def e2389344839578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344839578 : Closed e2389344839578 ∧ code e2389344839578 = 11185437861786 := by decide
theorem cert_e2389344839578 : check e2389344839578 [[],[.left],[]] .chain = true := by decide
def e2389344841966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2389344841966 : Closed e2389344841966 ∧ code e2389344841966 = 11185437864174 := by decide
theorem cert_e2389344841966 : check e2389344841966 [[],[.left],[]] .chain = true := by decide
def e2389344841974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2389344841974 : Closed e2389344841974 ∧ code e2389344841974 = 11185437864182 := by decide
theorem cert_e2389344841974 : check e2389344841974 [[],[.left],[]] .chain = true := by decide
def e2389344842454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2389344842454 : Closed e2389344842454 ∧ code e2389344842454 = 11185437864662 := by decide
theorem cert_e2389344842454 : check e2389344842454 [[],[.left],[]] .chain = true := by decide
def e2389344842458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2389344842458 : Closed e2389344842458 ∧ code e2389344842458 = 11185437864666 := by decide
theorem cert_e2389344842458 : check e2389344842458 [[],[.left],[]] .chain = true := by decide
def e2389344842474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2389344842474 : Closed e2389344842474 ∧ code e2389344842474 = 11185437864682 := by decide
theorem cert_e2389344842474 : check e2389344842474 [[],[.left],[]] .chain = true := by decide
def e2389344842550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344842550 : Closed e2389344842550 ∧ code e2389344842550 = 11185437864758 := by decide
theorem cert_e2389344842550 : check e2389344842550 [[],[.left],[]] .chain = true := by decide
def e2389344842554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344842554 : Closed e2389344842554 ∧ code e2389344842554 = 11185437864762 := by decide
theorem cert_e2389344842554 : check e2389344842554 [[],[.left],[]] .chain = true := by decide
def e2389344842638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2389344842638 : Closed e2389344842638 ∧ code e2389344842638 = 11185437864846 := by decide
theorem cert_e2389344842638 : check e2389344842638 [[],[.left],[]] .sourceHead = true := by decide
def e2389344842650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344842650 : Closed e2389344842650 ∧ code e2389344842650 = 11185437864858 := by decide
theorem cert_e2389344842650 : check e2389344842650 [[],[.left],[]] .chain = true := by decide
def e2389344933550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2389344933550 : Closed e2389344933550 ∧ code e2389344933550 = 11185437955758 := by decide
theorem cert_e2389344933550 : check e2389344933550 [[],[.left],[]] .chain = true := by decide
def e2389344933562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2389344933562 : Closed e2389344933562 ∧ code e2389344933562 = 11185437955770 := by decide
theorem cert_e2389344933562 : check e2389344933562 [[],[.left],[]] .chain = true := by decide
def e2389344933610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2389344933610 : Closed e2389344933610 ∧ code e2389344933610 = 11185437955818 := by decide
theorem cert_e2389344933610 : check e2389344933610 [[],[.left],[]] .chain = true := by decide
def e2389344933802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2389344933802 : Closed e2389344933802 ∧ code e2389344933802 = 11185437956010 := by decide
theorem cert_e2389344933802 : check e2389344933802 [[],[.left],[]] .chain = true := by decide
def e2389344934126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2389344934126 : Closed e2389344934126 ∧ code e2389344934126 = 11185437956334 := by decide
theorem cert_e2389344934126 : check e2389344934126 [[],[.left],[],[.under]] .three = true := by decide
def e2389344934134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2389344934134 : Closed e2389344934134 ∧ code e2389344934134 = 11185437956342 := by decide
theorem cert_e2389344934134 : check e2389344934134 [[],[.left],[],[.under]] .three = true := by decide
def e2389344934318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2389344934318 : Closed e2389344934318 ∧ code e2389344934318 = 11185437956526 := by decide
theorem cert_e2389344934318 : check e2389344934318 [[],[.left],[]] .chain = true := by decide
def e2389344934330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2389344934330 : Closed e2389344934330 ∧ code e2389344934330 = 11185437956538 := by decide
theorem cert_e2389344934330 : check e2389344934330 [[],[.left],[]] .chain = true := by decide
def e2389344934378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2389344934378 : Closed e2389344934378 ∧ code e2389344934378 = 11185437956586 := by decide
theorem cert_e2389344934378 : check e2389344934378 [[],[.left],[]] .chain = true := by decide
def e2389344934510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344934510 : Closed e2389344934510 ∧ code e2389344934510 = 11185437956718 := by decide
theorem cert_e2389344934510 : check e2389344934510 [[],[.left],[]] .chain = true := by decide
def e2389344934522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344934522 : Closed e2389344934522 ∧ code e2389344934522 = 11185437956730 := by decide
theorem cert_e2389344934522 : check e2389344934522 [[],[.left],[]] .chain = true := by decide
def e2389344934686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2389344934686 : Closed e2389344934686 ∧ code e2389344934686 = 11185437956894 := by decide
theorem cert_e2389344934686 : check e2389344934686 [[],[.left],[],[.under]] .three = true := by decide
def e2389344934798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2389344934798 : Closed e2389344934798 ∧ code e2389344934798 = 11185437957006 := by decide
theorem cert_e2389344934798 : check e2389344934798 [[],[.left],[],[.under]] .three = true := by decide
def e2389344934810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344934810 : Closed e2389344934810 ∧ code e2389344934810 = 11185437957018 := by decide
theorem cert_e2389344934810 : check e2389344934810 [[],[.left],[]] .chain = true := by decide
def e2389344935022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2389344935022 : Closed e2389344935022 ∧ code e2389344935022 = 11185437957230 := by decide
theorem cert_e2389344935022 : check e2389344935022 [[],[.left],[],[.under]] .three = true := by decide
def e2389344935034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2389344935034 : Closed e2389344935034 ∧ code e2389344935034 = 11185437957242 := by decide
theorem cert_e2389344935034 : check e2389344935034 [[],[.left],[],[.under]] .three = true := by decide
def e2389344935198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2389344935198 : Closed e2389344935198 ∧ code e2389344935198 = 11185437957406 := by decide
theorem cert_e2389344935198 : check e2389344935198 [[],[.left],[],[.under]] .three = true := by decide
def e2389344935366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2389344935366 : Closed e2389344935366 ∧ code e2389344935366 = 11185437957574 := by decide
theorem cert_e2389344935366 : check e2389344935366 [[],[.left],[],[.under]] .three = true := by decide
def e2389344935478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2389344935478 : Closed e2389344935478 ∧ code e2389344935478 = 11185437957686 := by decide
theorem cert_e2389344935478 : check e2389344935478 [[],[.left],[],[.under]] .three = true := by decide
def e2389344935482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2389344935482 : Closed e2389344935482 ∧ code e2389344935482 = 11185437957690 := by decide
theorem cert_e2389344935482 : check e2389344935482 [[],[.left],[],[.under]] .three = true := by decide
def e2389344935530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2389344935530 : Closed e2389344935530 ∧ code e2389344935530 = 11185437957738 := by decide
theorem cert_e2389344935530 : check e2389344935530 [[],[.left],[]] .chain = true := by decide
def e2389344935566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2389344935566 : Closed e2389344935566 ∧ code e2389344935566 = 11185437957774 := by decide
theorem cert_e2389344935566 : check e2389344935566 [[],[.left],[],[.under]] .three = true := by decide
def e2389344935578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344935578 : Closed e2389344935578 ∧ code e2389344935578 = 11185437957786 := by decide
theorem cert_e2389344935578 : check e2389344935578 [[],[.left],[]] .chain = true := by decide
def e2389344935622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2389344935622 : Closed e2389344935622 ∧ code e2389344935622 = 11185437957830 := by decide
theorem cert_e2389344935622 : check e2389344935622 [[],[.left],[],[.under]] .three = true := by decide
def e2389344936414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2389344936414 : Closed e2389344936414 ∧ code e2389344936414 = 11185437958622 := by decide
theorem cert_e2389344936414 : check e2389344936414 [[],[.left],[]] .chain = true := by decide
def e2389344936438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2389344936438 : Closed e2389344936438 ∧ code e2389344936438 = 11185437958646 := by decide
theorem cert_e2389344936438 : check e2389344936438 [[],[.left],[]] .chain = true := by decide
def e2389344937390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2389344937390 : Closed e2389344937390 ∧ code e2389344937390 = 11185437959598 := by decide
theorem cert_e2389344937390 : check e2389344937390 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
