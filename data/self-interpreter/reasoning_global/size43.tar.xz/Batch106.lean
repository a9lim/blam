import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862483330014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e862483330014 : Closed e862483330014 ∧ code e862483330014 = 9658576352222 := by decide
theorem cert_e862483330014 : check e862483330014 [] .sourceHead = true := by decide
def e862483330030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e862483330030 : Closed e862483330030 ∧ code e862483330030 = 9658576352238 := by decide
theorem cert_e862483330030 : check e862483330030 [] .sourceHead = true := by decide
def e862483331550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e862483331550 : Closed e862483331550 ∧ code e862483331550 = 9658576353758 := by decide
theorem cert_e862483331550 : check e862483331550 [] .sourceHead = true := by decide
def e862483331566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))))
theorem wire_e862483331566 : Closed e862483331566 ∧ code e862483331566 = 9658576353774 := by decide
theorem cert_e862483331566 : check e862483331566 [] .sourceHead = true := by decide
def e862483331574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e862483331574 : Closed e862483331574 ∧ code e862483331574 = 9658576353782 := by decide
theorem cert_e862483331574 : check e862483331574 [] .sourceHead = true := by decide
def e862483332318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e862483332318 : Closed e862483332318 ∧ code e862483332318 = 9658576354526 := by decide
theorem cert_e862483332318 : check e862483332318 [] .sourceHead = true := by decide
def e862483332334 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862483332334 : Closed e862483332334 ∧ code e862483332334 = 9658576354542 := by decide
theorem cert_e862483332334 : check e862483332334 [] .sourceHead = true := by decide
def e862483332342 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862483332342 : Closed e862483332342 ∧ code e862483332342 = 9658576354550 := by decide
theorem cert_e862483332342 : check e862483332342 [] .sourceHead = true := by decide
def e862483332346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e862483332346 : Closed e862483332346 ∧ code e862483332346 = 9658576354554 := by decide
theorem cert_e862483332346 : check e862483332346 [] .sourceHead = true := by decide
def e862483332718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483332718 : Closed e862483332718 ∧ code e862483332718 = 9658576354926 := by decide
theorem cert_e862483332718 : check e862483332718 [] .sourceHead = true := by decide
def e862483332726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e862483332726 : Closed e862483332726 ∧ code e862483332726 = 9658576354934 := by decide
theorem cert_e862483332726 : check e862483332726 [] .sourceHead = true := by decide
def e862483332730 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483332730 : Closed e862483332730 ∧ code e862483332730 = 9658576354938 := by decide
theorem cert_e862483332730 : check e862483332730 [] .sourceHead = true := by decide
def e862483355358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e862483355358 : Closed e862483355358 ∧ code e862483355358 = 9658576377566 := by decide
theorem cert_e862483355358 : check e862483355358 [] .sourceHead = true := by decide
def e862483355374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e862483355374 : Closed e862483355374 ∧ code e862483355374 = 9658576377582 := by decide
theorem cert_e862483355374 : check e862483355374 [] .sourceHead = true := by decide
def e862483355382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e862483355382 : Closed e862483355382 ∧ code e862483355382 = 9658576377590 := by decide
theorem cert_e862483355382 : check e862483355382 [] .sourceHead = true := by decide
def e862483355486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e862483355486 : Closed e862483355486 ∧ code e862483355486 = 9658576377694 := by decide
theorem cert_e862483355486 : check e862483355486 [] .sourceHead = true := by decide
def e862483355514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e862483355514 : Closed e862483355514 ∧ code e862483355514 = 9658576377722 := by decide
theorem cert_e862483355514 : check e862483355514 [] .sourceHead = true := by decide
def e862483355566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e862483355566 : Closed e862483355566 ∧ code e862483355566 = 9658576377774 := by decide
theorem cert_e862483355566 : check e862483355566 [] .sourceHead = true := by decide
def e862483355578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e862483355578 : Closed e862483355578 ∧ code e862483355578 = 9658576377786 := by decide
theorem cert_e862483355578 : check e862483355578 [] .sourceHead = true := by decide
def e862483355606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e862483355606 : Closed e862483355606 ∧ code e862483355606 = 9658576377814 := by decide
theorem cert_e862483355606 : check e862483355606 [] .sourceHead = true := by decide
def e862483355610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e862483355610 : Closed e862483355610 ∧ code e862483355610 = 9658576377818 := by decide
theorem cert_e862483355610 : check e862483355610 [] .sourceHead = true := by decide
def e862483356126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e862483356126 : Closed e862483356126 ∧ code e862483356126 = 9658576378334 := by decide
theorem cert_e862483356126 : check e862483356126 [] .sourceHead = true := by decide
def e862483356142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e862483356142 : Closed e862483356142 ∧ code e862483356142 = 9658576378350 := by decide
theorem cert_e862483356142 : check e862483356142 [] .sourceHead = true := by decide
def e862483356150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e862483356150 : Closed e862483356150 ∧ code e862483356150 = 9658576378358 := by decide
theorem cert_e862483356150 : check e862483356150 [] .sourceHead = true := by decide
def e862483356894 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e862483356894 : Closed e862483356894 ∧ code e862483356894 = 9658576379102 := by decide
theorem cert_e862483356894 : check e862483356894 [] .sourceHead = true := by decide
def e862483356922 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e862483356922 : Closed e862483356922 ∧ code e862483356922 = 9658576379130 := by decide
theorem cert_e862483356922 : check e862483356922 [] .sourceHead = true := by decide
def e862483357294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483357294 : Closed e862483357294 ∧ code e862483357294 = 9658576379502 := by decide
theorem cert_e862483357294 : check e862483357294 [] .sourceHead = true := by decide
def e862483357306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483357306 : Closed e862483357306 ∧ code e862483357306 = 9658576379514 := by decide
theorem cert_e862483357306 : check e862483357306 [] .sourceHead = true := by decide
def e862483357494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862483357494 : Closed e862483357494 ∧ code e862483357494 = 9658576379702 := by decide
theorem cert_e862483357494 : check e862483357494 [] .sourceHead = true := by decide
def e862483357498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862483357498 : Closed e862483357498 ∧ code e862483357498 = 9658576379706 := by decide
theorem cert_e862483357498 : check e862483357498 [] .sourceHead = true := by decide
def e862483368798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e862483368798 : Closed e862483368798 ∧ code e862483368798 = 9658576391006 := by decide
theorem cert_e862483368798 : check e862483368798 [] .sourceHead = true := by decide
def e862483368814 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862483368814 : Closed e862483368814 ∧ code e862483368814 = 9658576391022 := by decide
theorem cert_e862483368814 : check e862483368814 [] .sourceHead = true := by decide
def e862483368822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862483368822 : Closed e862483368822 ∧ code e862483368822 = 9658576391030 := by decide
theorem cert_e862483368822 : check e862483368822 [] .sourceHead = true := by decide
def e862483368826 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e862483368826 : Closed e862483368826 ∧ code e862483368826 = 9658576391034 := by decide
theorem cert_e862483368826 : check e862483368826 [] .sourceHead = true := by decide
def e862483368878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862483368878 : Closed e862483368878 ∧ code e862483368878 = 9658576391086 := by decide
theorem cert_e862483368878 : check e862483368878 [] .sourceHead = true := by decide
def e862483368890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862483368890 : Closed e862483368890 ∧ code e862483368890 = 9658576391098 := by decide
theorem cert_e862483368890 : check e862483368890 [] .sourceHead = true := by decide
def e862483368918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862483368918 : Closed e862483368918 ∧ code e862483368918 = 9658576391126 := by decide
theorem cert_e862483368918 : check e862483368918 [] .sourceHead = true := by decide
def e862483368922 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862483368922 : Closed e862483368922 ∧ code e862483368922 = 9658576391130 := by decide
theorem cert_e862483368922 : check e862483368922 [] .sourceHead = true := by decide
def e862483368938 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e862483368938 : Closed e862483368938 ∧ code e862483368938 = 9658576391146 := by decide
theorem cert_e862483368938 : check e862483368938 [] .sourceHead = true := by decide
def e862483369182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e862483369182 : Closed e862483369182 ∧ code e862483369182 = 9658576391390 := by decide
theorem cert_e862483369182 : check e862483369182 [] .sourceHead = true := by decide
def e862483369198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862483369198 : Closed e862483369198 ∧ code e862483369198 = 9658576391406 := by decide
theorem cert_e862483369198 : check e862483369198 [] .sourceHead = true := by decide
def e862483369206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862483369206 : Closed e862483369206 ∧ code e862483369206 = 9658576391414 := by decide
theorem cert_e862483369206 : check e862483369206 [] .sourceHead = true := by decide
def e862483369210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e862483369210 : Closed e862483369210 ∧ code e862483369210 = 9658576391418 := by decide
theorem cert_e862483369210 : check e862483369210 [] .sourceHead = true := by decide
def e862483369582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483369582 : Closed e862483369582 ∧ code e862483369582 = 9658576391790 := by decide
theorem cert_e862483369582 : check e862483369582 [] .sourceHead = true := by decide
def e862483369594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483369594 : Closed e862483369594 ∧ code e862483369594 = 9658576391802 := by decide
theorem cert_e862483369594 : check e862483369594 [] .sourceHead = true := by decide
def e862483369782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862483369782 : Closed e862483369782 ∧ code e862483369782 = 9658576391990 := by decide
theorem cert_e862483369782 : check e862483369782 [] .sourceHead = true := by decide
def e862483369786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862483369786 : Closed e862483369786 ∧ code e862483369786 = 9658576391994 := by decide
theorem cert_e862483369786 : check e862483369786 [] .sourceHead = true := by decide
def e862483369882 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862483369882 : Closed e862483369882 ∧ code e862483369882 = 9658576392090 := by decide
theorem cert_e862483369882 : check e862483369882 [] .sourceHead = true := by decide
def e862483375534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e862483375534 : Closed e862483375534 ∧ code e862483375534 = 9658576397742 := by decide
theorem cert_e862483375534 : check e862483375534 [] .sourceHead = true := by decide
def e862483375542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e862483375542 : Closed e862483375542 ∧ code e862483375542 = 9658576397750 := by decide
theorem cert_e862483375542 : check e862483375542 [] .sourceHead = true := by decide
def e862483375546 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e862483375546 : Closed e862483375546 ∧ code e862483375546 = 9658576397754 := by decide
theorem cert_e862483375546 : check e862483375546 [] .sourceHead = true := by decide
def e862483375574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e862483375574 : Closed e862483375574 ∧ code e862483375574 = 9658576397782 := by decide
theorem cert_e862483375574 : check e862483375574 [] .sourceHead = true := by decide
def e862483375578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e862483375578 : Closed e862483375578 ∧ code e862483375578 = 9658576397786 := by decide
theorem cert_e862483375578 : check e862483375578 [] .sourceHead = true := by decide
def e862483375594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e862483375594 : Closed e862483375594 ∧ code e862483375594 = 9658576397802 := by decide
theorem cert_e862483375594 : check e862483375594 [] .sourceHead = true := by decide
def e862483375726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483375726 : Closed e862483375726 ∧ code e862483375726 = 9658576397934 := by decide
theorem cert_e862483375726 : check e862483375726 [] .sourceHead = true := by decide
def e862483375734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e862483375734 : Closed e862483375734 ∧ code e862483375734 = 9658576397942 := by decide
theorem cert_e862483375734 : check e862483375734 [] .sourceHead = true := by decide
def e862483375738 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483375738 : Closed e862483375738 ∧ code e862483375738 = 9658576397946 := by decide
theorem cert_e862483375738 : check e862483375738 [] .sourceHead = true := by decide
def e862483375926 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862483375926 : Closed e862483375926 ∧ code e862483375926 = 9658576398134 := by decide
theorem cert_e862483375926 : check e862483375926 [] .sourceHead = true := by decide
def e862483375930 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862483375930 : Closed e862483375930 ∧ code e862483375930 = 9658576398138 := by decide
theorem cert_e862483375930 : check e862483375930 [] .sourceHead = true := by decide
def e862483376026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862483376026 : Closed e862483376026 ∧ code e862483376026 = 9658576398234 := by decide
theorem cert_e862483376026 : check e862483376026 [] .sourceHead = true := by decide
def e862483821934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e862483821934 : Closed e862483821934 ∧ code e862483821934 = 9658576844142 := by decide
theorem cert_e862483821934 : check e862483821934 [] .sourceHead = true := by decide
def e862483821942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e862483821942 : Closed e862483821942 ∧ code e862483821942 = 9658576844150 := by decide
theorem cert_e862483821942 : check e862483821942 [] .sourceHead = true := by decide
def e862483821998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e862483821998 : Closed e862483821998 ∧ code e862483821998 = 9658576844206 := by decide
theorem cert_e862483821998 : check e862483821998 [] .sourceHead = true := by decide
def e862483822010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e862483822010 : Closed e862483822010 ∧ code e862483822010 = 9658576844218 := by decide
theorem cert_e862483822010 : check e862483822010 [] .sourceHead = true := by decide
def e862483822038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e862483822038 : Closed e862483822038 ∧ code e862483822038 = 9658576844246 := by decide
theorem cert_e862483822038 : check e862483822038 [] .sourceHead = true := by decide
def e862483822042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e862483822042 : Closed e862483822042 ∧ code e862483822042 = 9658576844250 := by decide
theorem cert_e862483822042 : check e862483822042 [] .sourceHead = true := by decide
def e862483822254 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e862483822254 : Closed e862483822254 ∧ code e862483822254 = 9658576844462 := by decide
theorem cert_e862483822254 : check e862483822254 [] .sourceHead = true := by decide
def e862483822266 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e862483822266 : Closed e862483822266 ∧ code e862483822266 = 9658576844474 := by decide
theorem cert_e862483822266 : check e862483822266 [] .sourceHead = true := by decide
def e862483822314 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e862483822314 : Closed e862483822314 ∧ code e862483822314 = 9658576844522 := by decide
theorem cert_e862483822314 : check e862483822314 [] .sourceHead = true := by decide
def e862483822422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e862483822422 : Closed e862483822422 ∧ code e862483822422 = 9658576844630 := by decide
theorem cert_e862483822422 : check e862483822422 [] .sourceHead = true := by decide
def e862483822426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e862483822426 : Closed e862483822426 ∧ code e862483822426 = 9658576844634 := by decide
theorem cert_e862483822426 : check e862483822426 [] .sourceHead = true := by decide
def e862483822442 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e862483822442 : Closed e862483822442 ∧ code e862483822442 = 9658576844650 := by decide
theorem cert_e862483822442 : check e862483822442 [] .sourceHead = true := by decide
def e862483823278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e862483823278 : Closed e862483823278 ∧ code e862483823278 = 9658576845486 := by decide
theorem cert_e862483823278 : check e862483823278 [] .sourceHead = true := by decide
def e862483823290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e862483823290 : Closed e862483823290 ∧ code e862483823290 = 9658576845498 := by decide
theorem cert_e862483823290 : check e862483823290 [] .sourceHead = true := by decide
def e862483823338 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e862483823338 : Closed e862483823338 ∧ code e862483823338 = 9658576845546 := by decide
theorem cert_e862483823338 : check e862483823338 [] .sourceHead = true := by decide
def e862483823530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e862483823530 : Closed e862483823530 ∧ code e862483823530 = 9658576845738 := by decide
theorem cert_e862483823530 : check e862483823530 [] .sourceHead = true := by decide
def e862483823958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e862483823958 : Closed e862483823958 ∧ code e862483823958 = 9658576846166 := by decide
theorem cert_e862483823958 : check e862483823958 [] .sourceHead = true := by decide
def e862483823962 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e862483823962 : Closed e862483823962 ∧ code e862483823962 = 9658576846170 := by decide
theorem cert_e862483823962 : check e862483823962 [] .sourceHead = true := by decide
def e862483823978 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e862483823978 : Closed e862483823978 ∧ code e862483823978 = 9658576846186 := by decide
theorem cert_e862483823978 : check e862483823978 [] .sourceHead = true := by decide
def e862483824042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e862483824042 : Closed e862483824042 ∧ code e862483824042 = 9658576846250 := by decide
theorem cert_e862483824042 : check e862483824042 [] .sourceHead = true := by decide
def e862483826542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))))
theorem wire_e862483826542 : Closed e862483826542 ∧ code e862483826542 = 9658576848750 := by decide
theorem cert_e862483826542 : check e862483826542 [] .sourceHead = true := by decide
def e862483826550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))))
theorem wire_e862483826550 : Closed e862483826550 ∧ code e862483826550 = 9658576848758 := by decide
theorem cert_e862483826550 : check e862483826550 [] .sourceHead = true := by decide
def e862483826614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))))
theorem wire_e862483826614 : Closed e862483826614 ∧ code e862483826614 = 9658576848822 := by decide
theorem cert_e862483826614 : check e862483826614 [] .sourceHead = true := by decide
def e862483828078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e862483828078 : Closed e862483828078 ∧ code e862483828078 = 9658576850286 := by decide
theorem cert_e862483828078 : check e862483828078 [] .sourceHead = true := by decide
def e862483828086 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e862483828086 : Closed e862483828086 ∧ code e862483828086 = 9658576850294 := by decide
theorem cert_e862483828086 : check e862483828086 [] .sourceHead = true := by decide
def e862483828142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e862483828142 : Closed e862483828142 ∧ code e862483828142 = 9658576850350 := by decide
theorem cert_e862483828142 : check e862483828142 [] .sourceHead = true := by decide
def e862483828154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e862483828154 : Closed e862483828154 ∧ code e862483828154 = 9658576850362 := by decide
theorem cert_e862483828154 : check e862483828154 [] .sourceHead = true := by decide
def e862483828182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e862483828182 : Closed e862483828182 ∧ code e862483828182 = 9658576850390 := by decide
theorem cert_e862483828182 : check e862483828182 [] .sourceHead = true := by decide
def e862483828186 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e862483828186 : Closed e862483828186 ∧ code e862483828186 = 9658576850394 := by decide
theorem cert_e862483828186 : check e862483828186 [] .sourceHead = true := by decide
def e862483828398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e862483828398 : Closed e862483828398 ∧ code e862483828398 = 9658576850606 := by decide
theorem cert_e862483828398 : check e862483828398 [] .sourceHead = true := by decide
def e862483828410 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e862483828410 : Closed e862483828410 ∧ code e862483828410 = 9658576850618 := by decide
theorem cert_e862483828410 : check e862483828410 [] .sourceHead = true := by decide
def e862483828458 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e862483828458 : Closed e862483828458 ∧ code e862483828458 = 9658576850666 := by decide
theorem cert_e862483828458 : check e862483828458 [] .sourceHead = true := by decide
def e862483828566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e862483828566 : Closed e862483828566 ∧ code e862483828566 = 9658576850774 := by decide
theorem cert_e862483828566 : check e862483828566 [] .sourceHead = true := by decide
def e862483828570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e862483828570 : Closed e862483828570 ∧ code e862483828570 = 9658576850778 := by decide
theorem cert_e862483828570 : check e862483828570 [] .sourceHead = true := by decide
def e862483828586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e862483828586 : Closed e862483828586 ∧ code e862483828586 = 9658576850794 := by decide
theorem cert_e862483828586 : check e862483828586 [] .sourceHead = true := by decide
def e862483829614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e862483829614 : Closed e862483829614 ∧ code e862483829614 = 9658576851822 := by decide
theorem cert_e862483829614 : check e862483829614 [] .sourceHead = true := by decide
def e862483829622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e862483829622 : Closed e862483829622 ∧ code e862483829622 = 9658576851830 := by decide
theorem cert_e862483829622 : check e862483829622 [] .sourceHead = true := by decide
def e862483829678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e862483829678 : Closed e862483829678 ∧ code e862483829678 = 9658576851886 := by decide
theorem cert_e862483829678 : check e862483829678 [] .sourceHead = true := by decide
def e862483829690 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e862483829690 : Closed e862483829690 ∧ code e862483829690 = 9658576851898 := by decide
theorem cert_e862483829690 : check e862483829690 [] .sourceHead = true := by decide
def e862483829718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e862483829718 : Closed e862483829718 ∧ code e862483829718 = 9658576851926 := by decide
theorem cert_e862483829718 : check e862483829718 [] .sourceHead = true := by decide
def e862483829722 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e862483829722 : Closed e862483829722 ∧ code e862483829722 = 9658576851930 := by decide
theorem cert_e862483829722 : check e862483829722 [] .sourceHead = true := by decide
def e862483829998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e862483829998 : Closed e862483829998 ∧ code e862483829998 = 9658576852206 := by decide
theorem cert_e862483829998 : check e862483829998 [] .sourceHead = true := by decide
def e862483830006 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e862483830006 : Closed e862483830006 ∧ code e862483830006 = 9658576852214 := by decide
theorem cert_e862483830006 : check e862483830006 [] .sourceHead = true := by decide
def e862483830382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862483830382 : Closed e862483830382 ∧ code e862483830382 = 9658576852590 := by decide
theorem cert_e862483830382 : check e862483830382 [] .sourceHead = true := by decide
def e862483830394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862483830394 : Closed e862483830394 ∧ code e862483830394 = 9658576852602 := by decide
theorem cert_e862483830394 : check e862483830394 [] .sourceHead = true := by decide
def e862483830582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483830582 : Closed e862483830582 ∧ code e862483830582 = 9658576852790 := by decide
theorem cert_e862483830582 : check e862483830582 [] .sourceHead = true := by decide
def e862483830586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483830586 : Closed e862483830586 ∧ code e862483830586 = 9658576852794 := by decide
theorem cert_e862483830586 : check e862483830586 [] .sourceHead = true := by decide
def e862483831022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e862483831022 : Closed e862483831022 ∧ code e862483831022 = 9658576853230 := by decide
theorem cert_e862483831022 : check e862483831022 [] .sourceHead = true := by decide
def e862483831030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e862483831030 : Closed e862483831030 ∧ code e862483831030 = 9658576853238 := by decide
theorem cert_e862483831030 : check e862483831030 [] .sourceHead = true := by decide
def e862483831214 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e862483831214 : Closed e862483831214 ∧ code e862483831214 = 9658576853422 := by decide
theorem cert_e862483831214 : check e862483831214 [] .sourceHead = true := by decide
def e862483831226 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e862483831226 : Closed e862483831226 ∧ code e862483831226 = 9658576853434 := by decide
theorem cert_e862483831226 : check e862483831226 [] .sourceHead = true := by decide
def e862483831274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e862483831274 : Closed e862483831274 ∧ code e862483831274 = 9658576853482 := by decide
theorem cert_e862483831274 : check e862483831274 [] .sourceHead = true := by decide
def e862483831406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862483831406 : Closed e862483831406 ∧ code e862483831406 = 9658576853614 := by decide
theorem cert_e862483831406 : check e862483831406 [] .sourceHead = true := by decide
def e862483831418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862483831418 : Closed e862483831418 ∧ code e862483831418 = 9658576853626 := by decide
theorem cert_e862483831418 : check e862483831418 [] .sourceHead = true := by decide
def e862483831582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e862483831582 : Closed e862483831582 ∧ code e862483831582 = 9658576853790 := by decide
theorem cert_e862483831582 : check e862483831582 [] .sourceHead = true := by decide
def e862483831694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e862483831694 : Closed e862483831694 ∧ code e862483831694 = 9658576853902 := by decide
theorem cert_e862483831694 : check e862483831694 [] .sourceHead = true := by decide
def e862483831706 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483831706 : Closed e862483831706 ∧ code e862483831706 = 9658576853914 := by decide
theorem cert_e862483831706 : check e862483831706 [] .sourceHead = true := by decide
def e862483831926 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e862483831926 : Closed e862483831926 ∧ code e862483831926 = 9658576854134 := by decide
theorem cert_e862483831926 : check e862483831926 [] .sourceHead = true := by decide
def e862483832022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e862483832022 : Closed e862483832022 ∧ code e862483832022 = 9658576854230 := by decide
theorem cert_e862483832022 : check e862483832022 [] .sourceHead = true := by decide
def e862483832026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e862483832026 : Closed e862483832026 ∧ code e862483832026 = 9658576854234 := by decide
theorem cert_e862483832026 : check e862483832026 [] .sourceHead = true := by decide
def e862483832042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e862483832042 : Closed e862483832042 ∧ code e862483832042 = 9658576854250 := by decide
theorem cert_e862483832042 : check e862483832042 [] .sourceHead = true := by decide
def e862483832118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483832118 : Closed e862483832118 ∧ code e862483832118 = 9658576854326 := by decide
theorem cert_e862483832118 : check e862483832118 [] .sourceHead = true := by decide
def e862483832122 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483832122 : Closed e862483832122 ∧ code e862483832122 = 9658576854330 := by decide
theorem cert_e862483832122 : check e862483832122 [] .sourceHead = true := by decide
def e862483832206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e862483832206 : Closed e862483832206 ∧ code e862483832206 = 9658576854414 := by decide
theorem cert_e862483832206 : check e862483832206 [] .sourceHead = true := by decide
def e862483832218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483832218 : Closed e862483832218 ∧ code e862483832218 = 9658576854426 := by decide
theorem cert_e862483832218 : check e862483832218 [] .sourceHead = true := by decide
def e862483833710 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e862483833710 : Closed e862483833710 ∧ code e862483833710 = 9658576855918 := by decide
theorem cert_e862483833710 : check e862483833710 [] .sourceHead = true := by decide
def e862483833718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e862483833718 : Closed e862483833718 ∧ code e862483833718 = 9658576855926 := by decide
theorem cert_e862483833718 : check e862483833718 [] .sourceHead = true := by decide
def e862483833774 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e862483833774 : Closed e862483833774 ∧ code e862483833774 = 9658576855982 := by decide
theorem cert_e862483833774 : check e862483833774 [] .sourceHead = true := by decide
def e862483833786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e862483833786 : Closed e862483833786 ∧ code e862483833786 = 9658576855994 := by decide
theorem cert_e862483833786 : check e862483833786 [] .sourceHead = true := by decide
def e862483833814 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e862483833814 : Closed e862483833814 ∧ code e862483833814 = 9658576856022 := by decide
theorem cert_e862483833814 : check e862483833814 [] .sourceHead = true := by decide
def e862483833818 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e862483833818 : Closed e862483833818 ∧ code e862483833818 = 9658576856026 := by decide
theorem cert_e862483833818 : check e862483833818 [] .sourceHead = true := by decide
def e862483834542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e862483834542 : Closed e862483834542 ∧ code e862483834542 = 9658576856750 := by decide
theorem cert_e862483834542 : check e862483834542 [] .sourceHead = true := by decide
def e862483834554 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e862483834554 : Closed e862483834554 ∧ code e862483834554 = 9658576856762 := by decide
theorem cert_e862483834554 : check e862483834554 [] .sourceHead = true := by decide
def e862483834602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e862483834602 : Closed e862483834602 ∧ code e862483834602 = 9658576856810 := by decide
theorem cert_e862483834602 : check e862483834602 [] .sourceHead = true := by decide
def e862483834794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e862483834794 : Closed e862483834794 ∧ code e862483834794 = 9658576857002 := by decide
theorem cert_e862483834794 : check e862483834794 [] .sourceHead = true := by decide
def e862483835118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e862483835118 : Closed e862483835118 ∧ code e862483835118 = 9658576857326 := by decide
theorem cert_e862483835118 : check e862483835118 [] .sourceHead = true := by decide
def e862483835126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e862483835126 : Closed e862483835126 ∧ code e862483835126 = 9658576857334 := by decide
theorem cert_e862483835126 : check e862483835126 [] .sourceHead = true := by decide
def e862483835310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e862483835310 : Closed e862483835310 ∧ code e862483835310 = 9658576857518 := by decide
theorem cert_e862483835310 : check e862483835310 [] .sourceHead = true := by decide
def e862483835322 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e862483835322 : Closed e862483835322 ∧ code e862483835322 = 9658576857530 := by decide
theorem cert_e862483835322 : check e862483835322 [] .sourceHead = true := by decide
def e862483835370 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e862483835370 : Closed e862483835370 ∧ code e862483835370 = 9658576857578 := by decide
theorem cert_e862483835370 : check e862483835370 [] .sourceHead = true := by decide
def e862483835502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862483835502 : Closed e862483835502 ∧ code e862483835502 = 9658576857710 := by decide
theorem cert_e862483835502 : check e862483835502 [] .sourceHead = true := by decide
def e862483835514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862483835514 : Closed e862483835514 ∧ code e862483835514 = 9658576857722 := by decide
theorem cert_e862483835514 : check e862483835514 [] .sourceHead = true := by decide
def e862483835678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e862483835678 : Closed e862483835678 ∧ code e862483835678 = 9658576857886 := by decide
theorem cert_e862483835678 : check e862483835678 [] .sourceHead = true := by decide
def e862483835790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e862483835790 : Closed e862483835790 ∧ code e862483835790 = 9658576857998 := by decide
theorem cert_e862483835790 : check e862483835790 [] .sourceHead = true := by decide
def e862483835802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483835802 : Closed e862483835802 ∧ code e862483835802 = 9658576858010 := by decide
theorem cert_e862483835802 : check e862483835802 [] .sourceHead = true := by decide
def e862483836014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e862483836014 : Closed e862483836014 ∧ code e862483836014 = 9658576858222 := by decide
theorem cert_e862483836014 : check e862483836014 [] .sourceHead = true := by decide
def e862483836026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e862483836026 : Closed e862483836026 ∧ code e862483836026 = 9658576858234 := by decide
theorem cert_e862483836026 : check e862483836026 [] .sourceHead = true := by decide
def e862483836190 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e862483836190 : Closed e862483836190 ∧ code e862483836190 = 9658576858398 := by decide
theorem cert_e862483836190 : check e862483836190 [] .sourceHead = true := by decide
def e862483836358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e862483836358 : Closed e862483836358 ∧ code e862483836358 = 9658576858566 := by decide
theorem cert_e862483836358 : check e862483836358 [] .sourceHead = true := by decide
def e862483836470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e862483836470 : Closed e862483836470 ∧ code e862483836470 = 9658576858678 := by decide
theorem cert_e862483836470 : check e862483836470 [] .sourceHead = true := by decide
def e862483836474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e862483836474 : Closed e862483836474 ∧ code e862483836474 = 9658576858682 := by decide
theorem cert_e862483836474 : check e862483836474 [] .sourceHead = true := by decide
def e862483836522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e862483836522 : Closed e862483836522 ∧ code e862483836522 = 9658576858730 := by decide
theorem cert_e862483836522 : check e862483836522 [] .sourceHead = true := by decide
def e862483836558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e862483836558 : Closed e862483836558 ∧ code e862483836558 = 9658576858766 := by decide
theorem cert_e862483836558 : check e862483836558 [] .sourceHead = true := by decide
def e862483836570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483836570 : Closed e862483836570 ∧ code e862483836570 = 9658576858778 := by decide
theorem cert_e862483836570 : check e862483836570 [] .sourceHead = true := by decide
def e862483836614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e862483836614 : Closed e862483836614 ∧ code e862483836614 = 9658576858822 := by decide
theorem cert_e862483836614 : check e862483836614 [] .sourceHead = true := by decide
def e862483837366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e862483837366 : Closed e862483837366 ∧ code e862483837366 = 9658576859574 := by decide
theorem cert_e862483837366 : check e862483837366 [] .sourceHead = true := by decide
def e862483837398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e862483837398 : Closed e862483837398 ∧ code e862483837398 = 9658576859606 := by decide
theorem cert_e862483837398 : check e862483837398 [] .sourceHead = true := by decide
def e862483837402 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e862483837402 : Closed e862483837402 ∧ code e862483837402 = 9658576859610 := by decide
theorem cert_e862483837402 : check e862483837402 [] .sourceHead = true := by decide
def e862483837782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e862483837782 : Closed e862483837782 ∧ code e862483837782 = 9658576859990 := by decide
theorem cert_e862483837782 : check e862483837782 [] .sourceHead = true := by decide
def e862483837786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e862483837786 : Closed e862483837786 ∧ code e862483837786 = 9658576859994 := by decide
theorem cert_e862483837786 : check e862483837786 [] .sourceHead = true := by decide
end Blc.Floor43
