import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419151875514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e2419151875514 : Closed e2419151875514 ∧ code e2419151875514 = 11215244897722 := by decide
theorem cert_e2419151875514 : check e2419151875514 [[],[]] .smaller = true := by decide
def e2419151875546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e2419151875546 : Closed e2419151875546 ∧ code e2419151875546 = 11215244897754 := by decide
theorem cert_e2419151875546 : check e2419151875546 [[],[]] .smaller = true := by decide
def e2419151875770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e2419151875770 : Closed e2419151875770 ∧ code e2419151875770 = 11215244897978 := by decide
theorem cert_e2419151875770 : check e2419151875770 [[],[]] .smaller = true := by decide
def e2419151875818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e2419151875818 : Closed e2419151875818 ∧ code e2419151875818 = 11215244898026 := by decide
theorem cert_e2419151875818 : check e2419151875818 [[],[]] .smaller = true := by decide
def e2419151875930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e2419151875930 : Closed e2419151875930 ∧ code e2419151875930 = 11215244898138 := by decide
theorem cert_e2419151875930 : check e2419151875930 [[],[]] .smaller = true := by decide
def e2419151875946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e2419151875946 : Closed e2419151875946 ∧ code e2419151875946 = 11215244898154 := by decide
theorem cert_e2419151875946 : check e2419151875946 [[],[]] .smaller = true := by decide
def e2419151877050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e2419151877050 : Closed e2419151877050 ∧ code e2419151877050 = 11215244899258 := by decide
theorem cert_e2419151877050 : check e2419151877050 [[],[]] .smaller = true := by decide
def e2419151877082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e2419151877082 : Closed e2419151877082 ∧ code e2419151877082 = 11215244899290 := by decide
theorem cert_e2419151877082 : check e2419151877082 [[],[]] .smaller = true := by decide
def e2419151878586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e2419151878586 : Closed e2419151878586 ∧ code e2419151878586 = 11215244900794 := by decide
theorem cert_e2419151878586 : check e2419151878586 [[],[]] .smaller = true := by decide
def e2419151878634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e2419151878634 : Closed e2419151878634 ∧ code e2419151878634 = 11215244900842 := by decide
theorem cert_e2419151878634 : check e2419151878634 [[],[]] .smaller = true := by decide
def e2419151879386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e2419151879386 : Closed e2419151879386 ∧ code e2419151879386 = 11215244901594 := by decide
theorem cert_e2419151879386 : check e2419151879386 [[],[]] .smaller = true := by decide
def e2419151879402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e2419151879402 : Closed e2419151879402 ∧ code e2419151879402 = 11215244901610 := by decide
theorem cert_e2419151879402 : check e2419151879402 [[],[]] .smaller = true := by decide
def e2419151910626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2419151910626 : Closed e2419151910626 ∧ code e2419151910626 = 11215244932834 := by decide
theorem cert_e2419151910626 : check e2419151910626 [[],[]] .sourceHead = true := by decide
def e2419151910754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2419151910754 : Closed e2419151910754 ∧ code e2419151910754 = 11215244932962 := by decide
theorem cert_e2419151910754 : check e2419151910754 [[],[]] .sourceHead = true := by decide
def e2419151911650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2419151911650 : Closed e2419151911650 ∧ code e2419151911650 = 11215244933858 := by decide
theorem cert_e2419151911650 : check e2419151911650 [[],[]] .sourceHead = true := by decide
def e2419151911842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2419151911842 : Closed e2419151911842 ∧ code e2419151911842 = 11215244934050 := by decide
theorem cert_e2419151911842 : check e2419151911842 [[],[]] .sourceHead = true := by decide
def e2419151912290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2419151912290 : Closed e2419151912290 ∧ code e2419151912290 = 11215244934498 := by decide
theorem cert_e2419151912290 : check e2419151912290 [[],[]] .sourceHead = true := by decide
def e2419151912354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2419151912354 : Closed e2419151912354 ∧ code e2419151912354 = 11215244934562 := by decide
theorem cert_e2419151912354 : check e2419151912354 [[],[]] .sourceHead = true := by decide
def e2419151916770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2419151916770 : Closed e2419151916770 ∧ code e2419151916770 = 11215244938978 := by decide
theorem cert_e2419151916770 : check e2419151916770 [[],[]] .sourceHead = true := by decide
def e2419151916898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2419151916898 : Closed e2419151916898 ∧ code e2419151916898 = 11215244939106 := by decide
theorem cert_e2419151916898 : check e2419151916898 [[],[]] .sourceHead = true := by decide
def e2419151922914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2419151922914 : Closed e2419151922914 ∧ code e2419151922914 = 11215244945122 := by decide
theorem cert_e2419151922914 : check e2419151922914 [[],[]] .sourceHead = true := by decide
def e2419151923106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2419151923106 : Closed e2419151923106 ∧ code e2419151923106 = 11215244945314 := by decide
theorem cert_e2419151923106 : check e2419151923106 [[],[]] .sourceHead = true := by decide
def e2419151926114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2419151926114 : Closed e2419151926114 ∧ code e2419151926114 = 11215244948322 := by decide
theorem cert_e2419151926114 : check e2419151926114 [[],[]] .sourceHead = true := by decide
def e2419151926178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2419151926178 : Closed e2419151926178 ∧ code e2419151926178 = 11215244948386 := by decide
theorem cert_e2419151926178 : check e2419151926178 [[],[]] .sourceHead = true := by decide
def e2419151932270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419151932270 : Closed e2419151932270 ∧ code e2419151932270 = 11215244954478 := by decide
theorem cert_e2419151932270 : check e2419151932270 [[],[]] .sourceHead = true := by decide
def e2419151932278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419151932278 : Closed e2419151932278 ∧ code e2419151932278 = 11215244954486 := by decide
theorem cert_e2419151932278 : check e2419151932278 [[],[]] .sourceHead = true := by decide
def e2419151932334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419151932334 : Closed e2419151932334 ∧ code e2419151932334 = 11215244954542 := by decide
theorem cert_e2419151932334 : check e2419151932334 [[],[]] .sourceHead = true := by decide
def e2419151932346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419151932346 : Closed e2419151932346 ∧ code e2419151932346 = 11215244954554 := by decide
theorem cert_e2419151932346 : check e2419151932346 [[],[]] .sourceHead = true := by decide
def e2419151932374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419151932374 : Closed e2419151932374 ∧ code e2419151932374 = 11215244954582 := by decide
theorem cert_e2419151932374 : check e2419151932374 [[],[]] .sourceHead = true := by decide
def e2419151932378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419151932378 : Closed e2419151932378 ∧ code e2419151932378 = 11215244954586 := by decide
theorem cert_e2419151932378 : check e2419151932378 [[],[]] .sourceHead = true := by decide
def e2419151932654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419151932654 : Closed e2419151932654 ∧ code e2419151932654 = 11215244954862 := by decide
theorem cert_e2419151932654 : check e2419151932654 [[],[]] .sourceHead = true := by decide
def e2419151932662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419151932662 : Closed e2419151932662 ∧ code e2419151932662 = 11215244954870 := by decide
theorem cert_e2419151932662 : check e2419151932662 [[],[]] .sourceHead = true := by decide
def e2419151933038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419151933038 : Closed e2419151933038 ∧ code e2419151933038 = 11215244955246 := by decide
theorem cert_e2419151933038 : check e2419151933038 [[],[]] .sourceHead = true := by decide
def e2419151933050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419151933050 : Closed e2419151933050 ∧ code e2419151933050 = 11215244955258 := by decide
theorem cert_e2419151933050 : check e2419151933050 [[],[]] .sourceHead = true := by decide
def e2419151933238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419151933238 : Closed e2419151933238 ∧ code e2419151933238 = 11215244955446 := by decide
theorem cert_e2419151933238 : check e2419151933238 [[],[]] .sourceHead = true := by decide
def e2419151933242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419151933242 : Closed e2419151933242 ∧ code e2419151933242 = 11215244955450 := by decide
theorem cert_e2419151933242 : check e2419151933242 [[],[]] .sourceHead = true := by decide
def e2419152128878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419152128878 : Closed e2419152128878 ∧ code e2419152128878 = 11215245151086 := by decide
theorem cert_e2419152128878 : check e2419152128878 [[],[]] .smaller = true := by decide
def e2419152128886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419152128886 : Closed e2419152128886 ∧ code e2419152128886 = 11215245151094 := by decide
theorem cert_e2419152128886 : check e2419152128886 [[],[]] .smaller = true := by decide
def e2419152128942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419152128942 : Closed e2419152128942 ∧ code e2419152128942 = 11215245151150 := by decide
theorem cert_e2419152128942 : check e2419152128942 [[],[]] .smaller = true := by decide
def e2419152128954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419152128954 : Closed e2419152128954 ∧ code e2419152128954 = 11215245151162 := by decide
theorem cert_e2419152128954 : check e2419152128954 [[],[]] .smaller = true := by decide
def e2419152128982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419152128982 : Closed e2419152128982 ∧ code e2419152128982 = 11215245151190 := by decide
theorem cert_e2419152128982 : check e2419152128982 [[],[]] .smaller = true := by decide
def e2419152128986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419152128986 : Closed e2419152128986 ∧ code e2419152128986 = 11215245151194 := by decide
theorem cert_e2419152128986 : check e2419152128986 [[],[]] .smaller = true := by decide
def e2419152129262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419152129262 : Closed e2419152129262 ∧ code e2419152129262 = 11215245151470 := by decide
theorem cert_e2419152129262 : check e2419152129262 [[],[]] .smaller = true := by decide
def e2419152129270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419152129270 : Closed e2419152129270 ∧ code e2419152129270 = 11215245151478 := by decide
theorem cert_e2419152129270 : check e2419152129270 [[],[]] .smaller = true := by decide
def e2419152129646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419152129646 : Closed e2419152129646 ∧ code e2419152129646 = 11215245151854 := by decide
theorem cert_e2419152129646 : check e2419152129646 [[],[]] .smaller = true := by decide
def e2419152129658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419152129658 : Closed e2419152129658 ∧ code e2419152129658 = 11215245151866 := by decide
theorem cert_e2419152129658 : check e2419152129658 [[],[]] .smaller = true := by decide
def e2419152129846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419152129846 : Closed e2419152129846 ∧ code e2419152129846 = 11215245152054 := by decide
theorem cert_e2419152129846 : check e2419152129846 [[],[]] .smaller = true := by decide
def e2419152129850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419152129850 : Closed e2419152129850 ∧ code e2419152129850 = 11215245152058 := by decide
theorem cert_e2419152129850 : check e2419152129850 [[],[]] .smaller = true := by decide
def e2419152411510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e2419152411510 : Closed e2419152411510 ∧ code e2419152411510 = 11215245433718 := by decide
theorem cert_e2419152411510 : check e2419152411510 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e2419152411574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e2419152411574 : Closed e2419152411574 ∧ code e2419152411574 = 11215245433782 := by decide
private def t_e2419152411574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem cert_e2419152411574 : ¬ IsSelfInterpreter e2419152411574 :=
  wSource (t := t_e2419152411574) (replay_sound (ps := []) (t := e2419152411574) (by decide)) (by decide)
def e2419152412022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e2419152412022 : Closed e2419152412022 ∧ code e2419152412022 = 11215245434230 := by decide
theorem cert_e2419152412022 : check e2419152412022 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2419152412118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e2419152412118 : Closed e2419152412118 ∧ code e2419152412118 = 11215245434326 := by decide
theorem cert_e2419152412118 : check e2419152412118 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2419152412342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e2419152412342 : Closed e2419152412342 ∧ code e2419152412342 = 11215245434550 := by decide
private def t_e2419152412342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem cert_e2419152412342 : ¬ IsSelfInterpreter e2419152412342 :=
  wSource (t := t_e2419152412342) (replay_sound (ps := []) (t := e2419152412342) (by decide)) (by decide)
def e2419152412374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e2419152412374 : Closed e2419152412374 ∧ code e2419152412374 = 11215245434582 := by decide
def e2419152414582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e2419152414582 : Closed e2419152414582 ∧ code e2419152414582 = 11215245436790 := by decide
theorem cert_e2419152414582 : check e2419152414582 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2419152414646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e2419152414646 : Closed e2419152414646 ∧ code e2419152414646 = 11215245436854 := by decide
def e2419152417654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e2419152417654 : Closed e2419152417654 ∧ code e2419152417654 = 11215245439862 := by decide
theorem cert_e2419152417654 : check e2419152417654 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2419152417750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e2419152417750 : Closed e2419152417750 ∧ code e2419152417750 = 11215245439958 := by decide
theorem cert_e2419152417750 : check e2419152417750 [[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2419152419254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e2419152419254 : Closed e2419152419254 ∧ code e2419152419254 = 11215245441462 := by decide
def e2419152419286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e2419152419286 : Closed e2419152419286 ∧ code e2419152419286 = 11215245441494 := by decide
def e2419152587630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419152587630 : Closed e2419152587630 ∧ code e2419152587630 = 11215245609838 := by decide
private def t_e2419152587630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e2419152587630 : ¬ IsSelfInterpreter e2419152587630 :=
  wSource (t := t_e2419152587630) (replay_sound (ps := []) (t := e2419152587630) (by decide)) (by decide)
def e2419152587638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419152587638 : Closed e2419152587638 ∧ code e2419152587638 = 11215245609846 := by decide
private def t_e2419152587638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2419152587638 : ¬ IsSelfInterpreter e2419152587638 :=
  wSource (t := t_e2419152587638) (replay_sound (ps := []) (t := e2419152587638) (by decide)) (by decide)
def e2419152587694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419152587694 : Closed e2419152587694 ∧ code e2419152587694 = 11215245609902 := by decide
private def t_e2419152587694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e2419152587694 : ¬ IsSelfInterpreter e2419152587694 :=
  wSource (t := t_e2419152587694) (replay_sound (ps := []) (t := e2419152587694) (by decide)) (by decide)
def e2419152587706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419152587706 : Closed e2419152587706 ∧ code e2419152587706 = 11215245609914 := by decide
private def t_e2419152587706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2419152587706 : ¬ IsSelfInterpreter e2419152587706 :=
  wSource (t := t_e2419152587706) (replay_sound (ps := []) (t := e2419152587706) (by decide)) (by decide)
def e2419152587734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419152587734 : Closed e2419152587734 ∧ code e2419152587734 = 11215245609942 := by decide
private def t_e2419152587734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2419152587734 : ¬ IsSelfInterpreter e2419152587734 :=
  wSource (t := t_e2419152587734) (replay_sound (ps := []) (t := e2419152587734) (by decide)) (by decide)
def e2419152587738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419152587738 : Closed e2419152587738 ∧ code e2419152587738 = 11215245609946 := by decide
private def t_e2419152587738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2419152587738 : ¬ IsSelfInterpreter e2419152587738 :=
  wSource (t := t_e2419152587738) (replay_sound (ps := []) (t := e2419152587738) (by decide)) (by decide)
def e2419152588014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419152588014 : Closed e2419152588014 ∧ code e2419152588014 = 11215245610222 := by decide
private def t_e2419152588014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e2419152588014 : ¬ IsSelfInterpreter e2419152588014 :=
  wSource (t := t_e2419152588014) (replay_sound (ps := []) (t := e2419152588014) (by decide)) (by decide)
def e2419152588022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419152588022 : Closed e2419152588022 ∧ code e2419152588022 = 11215245610230 := by decide
private def t_e2419152588022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e2419152588022 : ¬ IsSelfInterpreter e2419152588022 :=
  wSource (t := t_e2419152588022) (replay_sound (ps := []) (t := e2419152588022) (by decide)) (by decide)
def e2419152588398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419152588398 : Closed e2419152588398 ∧ code e2419152588398 = 11215245610606 := by decide
private def t_e2419152588398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e2419152588398 : ¬ IsSelfInterpreter e2419152588398 :=
  wSource (t := t_e2419152588398) (replay_sound (ps := []) (t := e2419152588398) (by decide)) (by decide)
def e2419152588410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419152588410 : Closed e2419152588410 ∧ code e2419152588410 = 11215245610618 := by decide
private def t_e2419152588410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e2419152588410 : ¬ IsSelfInterpreter e2419152588410 :=
  wSource (t := t_e2419152588410) (replay_sound (ps := []) (t := e2419152588410) (by decide)) (by decide)
def e2419152588598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419152588598 : Closed e2419152588598 ∧ code e2419152588598 = 11215245610806 := by decide
private def t_e2419152588598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e2419152588598 : ¬ IsSelfInterpreter e2419152588598 :=
  wSource (t := t_e2419152588598) (replay_sound (ps := []) (t := e2419152588598) (by decide)) (by decide)
def e2419152588602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419152588602 : Closed e2419152588602 ∧ code e2419152588602 = 11215245610810 := by decide
private def t_e2419152588602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e2419152588602 : ¬ IsSelfInterpreter e2419152588602 :=
  wSource (t := t_e2419152588602) (replay_sound (ps := []) (t := e2419152588602) (by decide)) (by decide)
def e2419152924126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2419152924126 : Closed e2419152924126 ∧ code e2419152924126 = 11215245946334 := by decide
theorem cert_e2419152924126 : check e2419152924126 [[],[]] .smaller = true := by decide
def e2419152924142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2419152924142 : Closed e2419152924142 ∧ code e2419152924142 = 11215245946350 := by decide
theorem cert_e2419152924142 : check e2419152924142 [[],[]] .smaller = true := by decide
def e2419152924510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2419152924510 : Closed e2419152924510 ∧ code e2419152924510 = 11215245946718 := by decide
theorem cert_e2419152924510 : check e2419152924510 [[],[]] .smaller = true := by decide
def e2419152924538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2419152924538 : Closed e2419152924538 ∧ code e2419152924538 = 11215245946746 := by decide
theorem cert_e2419152924538 : check e2419152924538 [[],[]] .smaller = true := by decide
def e2419152924590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2419152924590 : Closed e2419152924590 ∧ code e2419152924590 = 11215245946798 := by decide
theorem cert_e2419152924590 : check e2419152924590 [[],[]] .smaller = true := by decide
def e2419152924602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2419152924602 : Closed e2419152924602 ∧ code e2419152924602 = 11215245946810 := by decide
theorem cert_e2419152924602 : check e2419152924602 [[],[]] .smaller = true := by decide
def e2419152925662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2419152925662 : Closed e2419152925662 ∧ code e2419152925662 = 11215245947870 := by decide
theorem cert_e2419152925662 : check e2419152925662 [[],[]] .smaller = true := by decide
def e2419152925678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2419152925678 : Closed e2419152925678 ∧ code e2419152925678 = 11215245947886 := by decide
theorem cert_e2419152925678 : check e2419152925678 [[],[]] .smaller = true := by decide
def e2419152927966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2419152927966 : Closed e2419152927966 ∧ code e2419152927966 = 11215245950174 := by decide
theorem cert_e2419152927966 : check e2419152927966 [[],[]] .smaller = true := by decide
def e2419152927994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2419152927994 : Closed e2419152927994 ∧ code e2419152927994 = 11215245950202 := by decide
theorem cert_e2419152927994 : check e2419152927994 [[],[]] .smaller = true := by decide
def e2419152928366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419152928366 : Closed e2419152928366 ∧ code e2419152928366 = 11215245950574 := by decide
theorem cert_e2419152928366 : check e2419152928366 [[],[]] .smaller = true := by decide
def e2419152928378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419152928378 : Closed e2419152928378 ∧ code e2419152928378 = 11215245950586 := by decide
theorem cert_e2419152928378 : check e2419152928378 [[],[]] .smaller = true := by decide
def e2419152956782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2419152956782 : Closed e2419152956782 ∧ code e2419152956782 = 11215245978990 := by decide
theorem cert_e2419152956782 : check e2419152956782 [[],[]] .smaller = true := by decide
def e2419152956790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2419152956790 : Closed e2419152956790 ∧ code e2419152956790 = 11215245978998 := by decide
theorem cert_e2419152956790 : check e2419152956790 [[],[]] .smaller = true := by decide
def e2419152956846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2419152956846 : Closed e2419152956846 ∧ code e2419152956846 = 11215245979054 := by decide
theorem cert_e2419152956846 : check e2419152956846 [[],[]] .smaller = true := by decide
def e2419152956858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2419152956858 : Closed e2419152956858 ∧ code e2419152956858 = 11215245979066 := by decide
theorem cert_e2419152956858 : check e2419152956858 [[],[]] .smaller = true := by decide
def e2419152956886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2419152956886 : Closed e2419152956886 ∧ code e2419152956886 = 11215245979094 := by decide
theorem cert_e2419152956886 : check e2419152956886 [[],[]] .smaller = true := by decide
def e2419152956890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2419152956890 : Closed e2419152956890 ∧ code e2419152956890 = 11215245979098 := by decide
theorem cert_e2419152956890 : check e2419152956890 [[],[]] .smaller = true := by decide
def e2419152957102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2419152957102 : Closed e2419152957102 ∧ code e2419152957102 = 11215245979310 := by decide
theorem cert_e2419152957102 : check e2419152957102 [[],[]] .smaller = true := by decide
def e2419152957114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2419152957114 : Closed e2419152957114 ∧ code e2419152957114 = 11215245979322 := by decide
theorem cert_e2419152957114 : check e2419152957114 [[],[]] .smaller = true := by decide
def e2419152957162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2419152957162 : Closed e2419152957162 ∧ code e2419152957162 = 11215245979370 := by decide
theorem cert_e2419152957162 : check e2419152957162 [[],[]] .smaller = true := by decide
def e2419152957270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2419152957270 : Closed e2419152957270 ∧ code e2419152957270 = 11215245979478 := by decide
theorem cert_e2419152957270 : check e2419152957270 [[],[]] .smaller = true := by decide
def e2419152957274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2419152957274 : Closed e2419152957274 ∧ code e2419152957274 = 11215245979482 := by decide
theorem cert_e2419152957274 : check e2419152957274 [[],[]] .smaller = true := by decide
def e2419152957290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2419152957290 : Closed e2419152957290 ∧ code e2419152957290 = 11215245979498 := by decide
theorem cert_e2419152957290 : check e2419152957290 [[],[]] .smaller = true := by decide
def e2419152958318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2419152958318 : Closed e2419152958318 ∧ code e2419152958318 = 11215245980526 := by decide
theorem cert_e2419152958318 : check e2419152958318 [[],[]] .smaller = true := by decide
def e2419152958326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2419152958326 : Closed e2419152958326 ∧ code e2419152958326 = 11215245980534 := by decide
theorem cert_e2419152958326 : check e2419152958326 [[],[]] .smaller = true := by decide
def e2419152958382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2419152958382 : Closed e2419152958382 ∧ code e2419152958382 = 11215245980590 := by decide
theorem cert_e2419152958382 : check e2419152958382 [[],[]] .smaller = true := by decide
def e2419152958394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2419152958394 : Closed e2419152958394 ∧ code e2419152958394 = 11215245980602 := by decide
theorem cert_e2419152958394 : check e2419152958394 [[],[]] .smaller = true := by decide
def e2419152958422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2419152958422 : Closed e2419152958422 ∧ code e2419152958422 = 11215245980630 := by decide
theorem cert_e2419152958422 : check e2419152958422 [[],[]] .smaller = true := by decide
def e2419152958426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2419152958426 : Closed e2419152958426 ∧ code e2419152958426 = 11215245980634 := by decide
theorem cert_e2419152958426 : check e2419152958426 [[],[]] .smaller = true := by decide
def e2419152958702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419152958702 : Closed e2419152958702 ∧ code e2419152958702 = 11215245980910 := by decide
theorem cert_e2419152958702 : check e2419152958702 [[],[]] .smaller = true := by decide
def e2419152958710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419152958710 : Closed e2419152958710 ∧ code e2419152958710 = 11215245980918 := by decide
theorem cert_e2419152958710 : check e2419152958710 [[],[]] .smaller = true := by decide
def e2419152959086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419152959086 : Closed e2419152959086 ∧ code e2419152959086 = 11215245981294 := by decide
theorem cert_e2419152959086 : check e2419152959086 [[],[]] .smaller = true := by decide
def e2419152959098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419152959098 : Closed e2419152959098 ∧ code e2419152959098 = 11215245981306 := by decide
theorem cert_e2419152959098 : check e2419152959098 [[],[]] .smaller = true := by decide
def e2419152959286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419152959286 : Closed e2419152959286 ∧ code e2419152959286 = 11215245981494 := by decide
theorem cert_e2419152959286 : check e2419152959286 [[],[]] .smaller = true := by decide
def e2419152959290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419152959290 : Closed e2419152959290 ∧ code e2419152959290 = 11215245981498 := by decide
theorem cert_e2419152959290 : check e2419152959290 [[],[]] .smaller = true := by decide
def e2419152959918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2419152959918 : Closed e2419152959918 ∧ code e2419152959918 = 11215245982126 := by decide
theorem cert_e2419152959918 : check e2419152959918 [[],[]] .smaller = true := by decide
def e2419152959930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2419152959930 : Closed e2419152959930 ∧ code e2419152959930 = 11215245982138 := by decide
theorem cert_e2419152959930 : check e2419152959930 [[],[]] .smaller = true := by decide
def e2419152959978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2419152959978 : Closed e2419152959978 ∧ code e2419152959978 = 11215245982186 := by decide
theorem cert_e2419152959978 : check e2419152959978 [[],[]] .smaller = true := by decide
def e2419152960110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419152960110 : Closed e2419152960110 ∧ code e2419152960110 = 11215245982318 := by decide
theorem cert_e2419152960110 : check e2419152960110 [[],[]] .smaller = true := by decide
def e2419152960122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419152960122 : Closed e2419152960122 ∧ code e2419152960122 = 11215245982330 := by decide
theorem cert_e2419152960122 : check e2419152960122 [[],[]] .smaller = true := by decide
def e2419152960410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419152960410 : Closed e2419152960410 ∧ code e2419152960410 = 11215245982618 := by decide
theorem cert_e2419152960410 : check e2419152960410 [[],[]] .smaller = true := by decide
def e2419152960726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2419152960726 : Closed e2419152960726 ∧ code e2419152960726 = 11215245982934 := by decide
theorem cert_e2419152960726 : check e2419152960726 [[],[]] .smaller = true := by decide
def e2419152960730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2419152960730 : Closed e2419152960730 ∧ code e2419152960730 = 11215245982938 := by decide
theorem cert_e2419152960730 : check e2419152960730 [[],[]] .smaller = true := by decide
def e2419152960746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2419152960746 : Closed e2419152960746 ∧ code e2419152960746 = 11215245982954 := by decide
theorem cert_e2419152960746 : check e2419152960746 [[],[]] .smaller = true := by decide
def e2419152960822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419152960822 : Closed e2419152960822 ∧ code e2419152960822 = 11215245983030 := by decide
theorem cert_e2419152960822 : check e2419152960822 [[],[]] .smaller = true := by decide
def e2419152960826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419152960826 : Closed e2419152960826 ∧ code e2419152960826 = 11215245983034 := by decide
theorem cert_e2419152960826 : check e2419152960826 [[],[]] .smaller = true := by decide
def e2419152960922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419152960922 : Closed e2419152960922 ∧ code e2419152960922 = 11215245983130 := by decide
theorem cert_e2419152960922 : check e2419152960922 [[],[]] .smaller = true := by decide
def e2419152962526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2419152962526 : Closed e2419152962526 ∧ code e2419152962526 = 11215245984734 := by decide
theorem cert_e2419152962526 : check e2419152962526 [[],[]] .smaller = true := by decide
def e2419152962542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2419152962542 : Closed e2419152962542 ∧ code e2419152962542 = 11215245984750 := by decide
theorem cert_e2419152962542 : check e2419152962542 [[],[]] .smaller = true := by decide
def e2419152964462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419152964462 : Closed e2419152964462 ∧ code e2419152964462 = 11215245986670 := by decide
theorem cert_e2419152964462 : check e2419152964462 [[],[]] .smaller = true := by decide
def e2419152964470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419152964470 : Closed e2419152964470 ∧ code e2419152964470 = 11215245986678 := by decide
theorem cert_e2419152964470 : check e2419152964470 [[],[]] .smaller = true := by decide
def e2419152964526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419152964526 : Closed e2419152964526 ∧ code e2419152964526 = 11215245986734 := by decide
theorem cert_e2419152964526 : check e2419152964526 [[],[]] .smaller = true := by decide
def e2419152964538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419152964538 : Closed e2419152964538 ∧ code e2419152964538 = 11215245986746 := by decide
theorem cert_e2419152964538 : check e2419152964538 [[],[]] .smaller = true := by decide
def e2419152964566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419152964566 : Closed e2419152964566 ∧ code e2419152964566 = 11215245986774 := by decide
theorem cert_e2419152964566 : check e2419152964566 [[],[]] .smaller = true := by decide
def e2419152964570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419152964570 : Closed e2419152964570 ∧ code e2419152964570 = 11215245986778 := by decide
theorem cert_e2419152964570 : check e2419152964570 [[],[]] .smaller = true := by decide
def e2419152964846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419152964846 : Closed e2419152964846 ∧ code e2419152964846 = 11215245987054 := by decide
theorem cert_e2419152964846 : check e2419152964846 [[],[]] .smaller = true := by decide
def e2419152964854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419152964854 : Closed e2419152964854 ∧ code e2419152964854 = 11215245987062 := by decide
theorem cert_e2419152964854 : check e2419152964854 [[],[]] .smaller = true := by decide
def e2419152965230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419152965230 : Closed e2419152965230 ∧ code e2419152965230 = 11215245987438 := by decide
theorem cert_e2419152965230 : check e2419152965230 [[],[]] .smaller = true := by decide
def e2419152965242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419152965242 : Closed e2419152965242 ∧ code e2419152965242 = 11215245987450 := by decide
theorem cert_e2419152965242 : check e2419152965242 [[],[]] .smaller = true := by decide
def e2419152965430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419152965430 : Closed e2419152965430 ∧ code e2419152965430 = 11215245987638 := by decide
theorem cert_e2419152965430 : check e2419152965430 [[],[]] .smaller = true := by decide
def e2419152965434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419152965434 : Closed e2419152965434 ∧ code e2419152965434 = 11215245987642 := by decide
theorem cert_e2419152965434 : check e2419152965434 [[],[]] .smaller = true := by decide
def e2419152970206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2419152970206 : Closed e2419152970206 ∧ code e2419152970206 = 11215245992414 := by decide
theorem cert_e2419152970206 : check e2419152970206 [[],[]] .smaller = true := by decide
def e2419152970230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2419152970230 : Closed e2419152970230 ∧ code e2419152970230 = 11215245992438 := by decide
theorem cert_e2419152970230 : check e2419152970230 [[],[]] .smaller = true := by decide
def e2419152971182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2419152971182 : Closed e2419152971182 ∧ code e2419152971182 = 11215245993390 := by decide
theorem cert_e2419152971182 : check e2419152971182 [[],[]] .smaller = true := by decide
def e2419152971194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2419152971194 : Closed e2419152971194 ∧ code e2419152971194 = 11215245993402 := by decide
theorem cert_e2419152971194 : check e2419152971194 [[],[]] .smaller = true := by decide
def e2419152971242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2419152971242 : Closed e2419152971242 ∧ code e2419152971242 = 11215245993450 := by decide
theorem cert_e2419152971242 : check e2419152971242 [[],[]] .smaller = true := by decide
def e2419152971374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419152971374 : Closed e2419152971374 ∧ code e2419152971374 = 11215245993582 := by decide
theorem cert_e2419152971374 : check e2419152971374 [[],[]] .smaller = true := by decide
def e2419152971386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419152971386 : Closed e2419152971386 ∧ code e2419152971386 = 11215245993594 := by decide
theorem cert_e2419152971386 : check e2419152971386 [[],[]] .smaller = true := by decide
def e2419152971674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419152971674 : Closed e2419152971674 ∧ code e2419152971674 = 11215245993882 := by decide
theorem cert_e2419152971674 : check e2419152971674 [[],[]] .smaller = true := by decide
def e2419152974062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2419152974062 : Closed e2419152974062 ∧ code e2419152974062 = 11215245996270 := by decide
theorem cert_e2419152974062 : check e2419152974062 [[],[]] .smaller = true := by decide
def e2419152974070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2419152974070 : Closed e2419152974070 ∧ code e2419152974070 = 11215245996278 := by decide
theorem cert_e2419152974070 : check e2419152974070 [[],[]] .smaller = true := by decide
def e2419152974550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2419152974550 : Closed e2419152974550 ∧ code e2419152974550 = 11215245996758 := by decide
theorem cert_e2419152974550 : check e2419152974550 [[],[]] .smaller = true := by decide
def e2419152974554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2419152974554 : Closed e2419152974554 ∧ code e2419152974554 = 11215245996762 := by decide
theorem cert_e2419152974554 : check e2419152974554 [[],[]] .smaller = true := by decide
def e2419152974570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2419152974570 : Closed e2419152974570 ∧ code e2419152974570 = 11215245996778 := by decide
theorem cert_e2419152974570 : check e2419152974570 [[],[]] .smaller = true := by decide
def e2419152974646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419152974646 : Closed e2419152974646 ∧ code e2419152974646 = 11215245996854 := by decide
theorem cert_e2419152974646 : check e2419152974646 [[],[]] .smaller = true := by decide
def e2419152974650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419152974650 : Closed e2419152974650 ∧ code e2419152974650 = 11215245996858 := by decide
theorem cert_e2419152974650 : check e2419152974650 [[],[]] .smaller = true := by decide
def e2419152974746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419152974746 : Closed e2419152974746 ∧ code e2419152974746 = 11215245996954 := by decide
theorem cert_e2419152974746 : check e2419152974746 [[],[]] .smaller = true := by decide
def e2419153088878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2419153088878 : Closed e2419153088878 ∧ code e2419153088878 = 11215246111086 := by decide
theorem cert_e2419153088878 : check e2419153088878 [[],[]] .sourceHead = true := by decide
def e2419153088886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2419153088886 : Closed e2419153088886 ∧ code e2419153088886 = 11215246111094 := by decide
theorem cert_e2419153088886 : check e2419153088886 [[],[]] .sourceHead = true := by decide
def e2419153090094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419153090094 : Closed e2419153090094 ∧ code e2419153090094 = 11215246112302 := by decide
theorem cert_e2419153090094 : check e2419153090094 [[],[]] .sourceHead = true := by decide
def e2419153090274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419153090274 : Closed e2419153090274 ∧ code e2419153090274 = 11215246112482 := by decide
theorem cert_e2419153090274 : check e2419153090274 [[],[]] .sourceHead = true := by decide
def e2419153090286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2419153090286 : Closed e2419153090286 ∧ code e2419153090286 = 11215246112494 := by decide
theorem cert_e2419153090286 : check e2419153090286 [[],[]] .sourceHead = true := by decide
def e2419153090326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419153090326 : Closed e2419153090326 ∧ code e2419153090326 = 11215246112534 := by decide
theorem cert_e2419153090326 : check e2419153090326 [[],[]] .sourceHead = true := by decide
def e2419153090402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419153090402 : Closed e2419153090402 ∧ code e2419153090402 = 11215246112610 := by decide
theorem cert_e2419153090402 : check e2419153090402 [[],[]] .sourceHead = true := by decide
def e2419153090414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2419153090414 : Closed e2419153090414 ∧ code e2419153090414 = 11215246112622 := by decide
theorem cert_e2419153090414 : check e2419153090414 [[],[]] .sourceHead = true := by decide
def e2419153090422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2419153090422 : Closed e2419153090422 ∧ code e2419153090422 = 11215246112630 := by decide
theorem cert_e2419153090422 : check e2419153090422 [[],[]] .sourceHead = true := by decide
def e2419153090734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2419153090734 : Closed e2419153090734 ∧ code e2419153090734 = 11215246112942 := by decide
theorem cert_e2419153090734 : check e2419153090734 [[],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419152411574
#print axioms Blc.Floor43.cert_e2419152412342
#print axioms Blc.Floor43.cert_e2419152587630
#print axioms Blc.Floor43.cert_e2419152587638
#print axioms Blc.Floor43.cert_e2419152587694
#print axioms Blc.Floor43.cert_e2419152587706
#print axioms Blc.Floor43.cert_e2419152587734
#print axioms Blc.Floor43.cert_e2419152587738
#print axioms Blc.Floor43.cert_e2419152588014
#print axioms Blc.Floor43.cert_e2419152588022
#print axioms Blc.Floor43.cert_e2419152588398
#print axioms Blc.Floor43.cert_e2419152588410
#print axioms Blc.Floor43.cert_e2419152588598
#print axioms Blc.Floor43.cert_e2419152588602
