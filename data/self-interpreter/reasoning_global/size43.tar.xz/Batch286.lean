import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2409074357370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2409074357370 : Closed e2409074357370 ∧ code e2409074357370 = 11205167379578 := by decide
theorem cert_e2409074357370 : check e2409074357370 [[],[]] .chain = true := by decide
def e2409074357534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2409074357534 : Closed e2409074357534 ∧ code e2409074357534 = 11205167379742 := by decide
theorem cert_e2409074357534 : check e2409074357534 [[],[]] .chain = true := by decide
def e2409074357702 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2409074357702 : Closed e2409074357702 ∧ code e2409074357702 = 11205167379910 := by decide
theorem cert_e2409074357702 : check e2409074357702 [[],[]] .chain = true := by decide
def e2409074358042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2409074358042 : Closed e2409074358042 ∧ code e2409074358042 = 11205167380250 := by decide
theorem cert_e2409074358042 : check e2409074358042 [[],[]] .chain = true := by decide
def e2409074358086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2409074358086 : Closed e2409074358086 ∧ code e2409074358086 = 11205167380294 := by decide
theorem cert_e2409074358086 : check e2409074358086 [[],[]] .chain = true := by decide
def e2409074358486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2409074358486 : Closed e2409074358486 ∧ code e2409074358486 = 11205167380694 := by decide
theorem cert_e2409074358486 : check e2409074358486 [[],[]] .chain = true := by decide
def e2409074358490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2409074358490 : Closed e2409074358490 ∧ code e2409074358490 = 11205167380698 := by decide
theorem cert_e2409074358490 : check e2409074358490 [[],[]] .chain = true := by decide
def e2409074358506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2409074358506 : Closed e2409074358506 ∧ code e2409074358506 = 11205167380714 := by decide
theorem cert_e2409074358506 : check e2409074358506 [[],[]] .chain = true := by decide
def e2409074358838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2409074358838 : Closed e2409074358838 ∧ code e2409074358838 = 11205167381046 := by decide
theorem cert_e2409074358838 : check e2409074358838 [[],[]] .chain = true := by decide
def e2409074358842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2409074358842 : Closed e2409074358842 ∧ code e2409074358842 = 11205167381050 := by decide
theorem cert_e2409074358842 : check e2409074358842 [[],[]] .chain = true := by decide
def e2409074358926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2409074358926 : Closed e2409074358926 ∧ code e2409074358926 = 11205167381134 := by decide
theorem cert_e2409074358926 : check e2409074358926 [[],[]] .chain = true := by decide
def e2409074358982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2409074358982 : Closed e2409074358982 ∧ code e2409074358982 = 11205167381190 := by decide
theorem cert_e2409074358982 : check e2409074358982 [[],[]] .chain = true := by decide
def e2409074359066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2409074359066 : Closed e2409074359066 ∧ code e2409074359066 = 11205167381274 := by decide
theorem cert_e2409074359066 : check e2409074359066 [[],[]] .chain = true := by decide
def e2409074359110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2409074359110 : Closed e2409074359110 ∧ code e2409074359110 = 11205167381318 := by decide
theorem cert_e2409074359110 : check e2409074359110 [[],[]] .chain = true := by decide
def e2409074363630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2409074363630 : Closed e2409074363630 ∧ code e2409074363630 = 11205167385838 := by decide
theorem cert_e2409074363630 : check e2409074363630 [[],[]] .chain = true := by decide
def e2409074363638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2409074363638 : Closed e2409074363638 ∧ code e2409074363638 = 11205167385846 := by decide
theorem cert_e2409074363638 : check e2409074363638 [[],[]] .chain = true := by decide
def e2409074364014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2409074364014 : Closed e2409074364014 ∧ code e2409074364014 = 11205167386222 := by decide
theorem cert_e2409074364014 : check e2409074364014 [[],[]] .chain = true := by decide
def e2409074364026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2409074364026 : Closed e2409074364026 ∧ code e2409074364026 = 11205167386234 := by decide
theorem cert_e2409074364026 : check e2409074364026 [[],[]] .chain = true := by decide
def e2409074364214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2409074364214 : Closed e2409074364214 ∧ code e2409074364214 = 11205167386422 := by decide
theorem cert_e2409074364214 : check e2409074364214 [[],[]] .chain = true := by decide
def e2409074364218 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2409074364218 : Closed e2409074364218 ∧ code e2409074364218 = 11205167386426 := by decide
theorem cert_e2409074364218 : check e2409074364218 [[],[]] .chain = true := by decide
def e2409074366702 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2409074366702 : Closed e2409074366702 ∧ code e2409074366702 = 11205167388910 := by decide
theorem cert_e2409074366702 : check e2409074366702 [[],[]] .chain = true := by decide
def e2409074366710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2409074366710 : Closed e2409074366710 ∧ code e2409074366710 = 11205167388918 := by decide
theorem cert_e2409074366710 : check e2409074366710 [[],[]] .chain = true := by decide
def e2409074367262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2409074367262 : Closed e2409074367262 ∧ code e2409074367262 = 11205167389470 := by decide
theorem cert_e2409074367262 : check e2409074367262 [[],[]] .chain = true := by decide
def e2409074367374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2409074367374 : Closed e2409074367374 ∧ code e2409074367374 = 11205167389582 := by decide
theorem cert_e2409074367374 : check e2409074367374 [[],[]] .chain = true := by decide
def e2409074367598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2409074367598 : Closed e2409074367598 ∧ code e2409074367598 = 11205167389806 := by decide
theorem cert_e2409074367598 : check e2409074367598 [[],[]] .chain = true := by decide
def e2409074367610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2409074367610 : Closed e2409074367610 ∧ code e2409074367610 = 11205167389818 := by decide
theorem cert_e2409074367610 : check e2409074367610 [[],[]] .chain = true := by decide
def e2409074367774 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2409074367774 : Closed e2409074367774 ∧ code e2409074367774 = 11205167389982 := by decide
theorem cert_e2409074367774 : check e2409074367774 [[],[]] .chain = true := by decide
def e2409074367942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2409074367942 : Closed e2409074367942 ∧ code e2409074367942 = 11205167390150 := by decide
theorem cert_e2409074367942 : check e2409074367942 [[],[]] .chain = true := by decide
def e2409074368054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2409074368054 : Closed e2409074368054 ∧ code e2409074368054 = 11205167390262 := by decide
theorem cert_e2409074368054 : check e2409074368054 [[],[]] .chain = true := by decide
def e2409074368058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2409074368058 : Closed e2409074368058 ∧ code e2409074368058 = 11205167390266 := by decide
theorem cert_e2409074368058 : check e2409074368058 [[],[]] .chain = true := by decide
def e2409074368142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2409074368142 : Closed e2409074368142 ∧ code e2409074368142 = 11205167390350 := by decide
theorem cert_e2409074368142 : check e2409074368142 [[],[]] .chain = true := by decide
def e2409074368198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2409074368198 : Closed e2409074368198 ∧ code e2409074368198 = 11205167390406 := by decide
theorem cert_e2409074368198 : check e2409074368198 [[],[]] .chain = true := by decide
def e2409074370334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2409074370334 : Closed e2409074370334 ∧ code e2409074370334 = 11205167392542 := by decide
theorem cert_e2409074370334 : check e2409074370334 [[],[]] .chain = true := by decide
def e2409074370446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2409074370446 : Closed e2409074370446 ∧ code e2409074370446 = 11205167392654 := by decide
theorem cert_e2409074370446 : check e2409074370446 [[],[]] .chain = true := by decide
def e2409074373406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2409074373406 : Closed e2409074373406 ∧ code e2409074373406 = 11205167395614 := by decide
theorem cert_e2409074373406 : check e2409074373406 [[],[]] .chain = true := by decide
def e2409074373574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2409074373574 : Closed e2409074373574 ∧ code e2409074373574 = 11205167395782 := by decide
theorem cert_e2409074373574 : check e2409074373574 [[],[]] .chain = true := by decide
def e2409074375054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2409074375054 : Closed e2409074375054 ∧ code e2409074375054 = 11205167397262 := by decide
theorem cert_e2409074375054 : check e2409074375054 [[],[]] .chain = true := by decide
def e2409074375110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2409074375110 : Closed e2409074375110 ∧ code e2409074375110 = 11205167397318 := by decide
theorem cert_e2409074375110 : check e2409074375110 [[],[]] .chain = true := by decide
def e2409074378350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2409074378350 : Closed e2409074378350 ∧ code e2409074378350 = 11205167400558 := by decide
theorem cert_e2409074378350 : check e2409074378350 [[],[]] .chain = true := by decide
def e2409074378362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2409074378362 : Closed e2409074378362 ∧ code e2409074378362 = 11205167400570 := by decide
theorem cert_e2409074378362 : check e2409074378362 [[],[]] .chain = true := by decide
def e2409074378650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2409074378650 : Closed e2409074378650 ∧ code e2409074378650 = 11205167400858 := by decide
theorem cert_e2409074378650 : check e2409074378650 [[],[]] .chain = true := by decide
def e2409074379886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2409074379886 : Closed e2409074379886 ∧ code e2409074379886 = 11205167402094 := by decide
theorem cert_e2409074379886 : check e2409074379886 [[],[]] .chain = true := by decide
def e2409074379898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2409074379898 : Closed e2409074379898 ∧ code e2409074379898 = 11205167402106 := by decide
theorem cert_e2409074379898 : check e2409074379898 [[],[]] .chain = true := by decide
def e2409074380062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2409074380062 : Closed e2409074380062 ∧ code e2409074380062 = 11205167402270 := by decide
theorem cert_e2409074380062 : check e2409074380062 [[],[]] .chain = true := by decide
def e2409074380230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2409074380230 : Closed e2409074380230 ∧ code e2409074380230 = 11205167402438 := by decide
theorem cert_e2409074380230 : check e2409074380230 [[],[]] .chain = true := by decide
def e2409074380570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2409074380570 : Closed e2409074380570 ∧ code e2409074380570 = 11205167402778 := by decide
theorem cert_e2409074380570 : check e2409074380570 [[],[]] .chain = true := by decide
def e2409074380614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2409074380614 : Closed e2409074380614 ∧ code e2409074380614 = 11205167402822 := by decide
theorem cert_e2409074380614 : check e2409074380614 [[],[]] .chain = true := by decide
def e2409074381598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2409074381598 : Closed e2409074381598 ∧ code e2409074381598 = 11205167403806 := by decide
theorem cert_e2409074381598 : check e2409074381598 [[],[]] .chain = true := by decide
def e2409074381766 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2409074381766 : Closed e2409074381766 ∧ code e2409074381766 = 11205167403974 := by decide
theorem cert_e2409074381766 : check e2409074381766 [[],[]] .chain = true := by decide
def e2409074384070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2409074384070 : Closed e2409074384070 ∧ code e2409074384070 = 11205167406278 := by decide
theorem cert_e2409074384070 : check e2409074384070 [[],[]] .chain = true := by decide
def e2409074385718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2409074385718 : Closed e2409074385718 ∧ code e2409074385718 = 11205167407926 := by decide
theorem cert_e2409074385718 : check e2409074385718 [[],[]] .chain = true := by decide
def e2409074385722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2409074385722 : Closed e2409074385722 ∧ code e2409074385722 = 11205167407930 := by decide
theorem cert_e2409074385722 : check e2409074385722 [[],[]] .chain = true := by decide
def e2409074385818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2409074385818 : Closed e2409074385818 ∧ code e2409074385818 = 11205167408026 := by decide
theorem cert_e2409074385818 : check e2409074385818 [[],[]] .chain = true := by decide
def e2409074386486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2409074386486 : Closed e2409074386486 ∧ code e2409074386486 = 11205167408694 := by decide
theorem cert_e2409074386486 : check e2409074386486 [[],[]] .chain = true := by decide
def e2409074386490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2409074386490 : Closed e2409074386490 ∧ code e2409074386490 = 11205167408698 := by decide
theorem cert_e2409074386490 : check e2409074386490 [[],[]] .chain = true := by decide
def e2409074386574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2409074386574 : Closed e2409074386574 ∧ code e2409074386574 = 11205167408782 := by decide
theorem cert_e2409074386574 : check e2409074386574 [[],[]] .chain = true := by decide
def e2409074386630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2409074386630 : Closed e2409074386630 ∧ code e2409074386630 = 11205167408838 := by decide
theorem cert_e2409074386630 : check e2409074386630 [[],[]] .chain = true := by decide
def e2409074386714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2409074386714 : Closed e2409074386714 ∧ code e2409074386714 = 11205167408922 := by decide
theorem cert_e2409074386714 : check e2409074386714 [[],[]] .chain = true := by decide
def e2409074386758 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2409074386758 : Closed e2409074386758 ∧ code e2409074386758 = 11205167408966 := by decide
theorem cert_e2409074386758 : check e2409074386758 [[],[]] .chain = true := by decide
def e2409074387342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2409074387342 : Closed e2409074387342 ∧ code e2409074387342 = 11205167409550 := by decide
theorem cert_e2409074387342 : check e2409074387342 [[],[]] .chain = true := by decide
def e2409074387398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2409074387398 : Closed e2409074387398 ∧ code e2409074387398 = 11205167409606 := by decide
theorem cert_e2409074387398 : check e2409074387398 [[],[]] .chain = true := by decide
def e2409074388166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2409074388166 : Closed e2409074388166 ∧ code e2409074388166 = 11205167410374 := by decide
theorem cert_e2409074388166 : check e2409074388166 [[],[]] .chain = true := by decide
def e2409074398942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2409074398942 : Closed e2409074398942 ∧ code e2409074398942 = 11205167421150 := by decide
theorem cert_e2409074398942 : check e2409074398942 [[],[]] .chain = true := by decide
def e2409074398966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2409074398966 : Closed e2409074398966 ∧ code e2409074398966 = 11205167421174 := by decide
theorem cert_e2409074398966 : check e2409074398966 [[],[]] .chain = true := by decide
def e2409074399070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2409074399070 : Closed e2409074399070 ∧ code e2409074399070 = 11205167421278 := by decide
theorem cert_e2409074399070 : check e2409074399070 [[],[]] .chain = true := by decide
def e2409074399098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2409074399098 : Closed e2409074399098 ∧ code e2409074399098 = 11205167421306 := by decide
theorem cert_e2409074399098 : check e2409074399098 [[],[]] .chain = true := by decide
def e2409074399190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2409074399190 : Closed e2409074399190 ∧ code e2409074399190 = 11205167421398 := by decide
theorem cert_e2409074399190 : check e2409074399190 [[],[]] .chain = true := by decide
def e2409074399194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2409074399194 : Closed e2409074399194 ∧ code e2409074399194 = 11205167421402 := by decide
theorem cert_e2409074399194 : check e2409074399194 [[],[]] .chain = true := by decide
def e2409074399710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2409074399710 : Closed e2409074399710 ∧ code e2409074399710 = 11205167421918 := by decide
theorem cert_e2409074399710 : check e2409074399710 [[],[]] .chain = true := by decide
def e2409074399734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2409074399734 : Closed e2409074399734 ∧ code e2409074399734 = 11205167421942 := by decide
theorem cert_e2409074399734 : check e2409074399734 [[],[]] .chain = true := by decide
def e2409074400478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2409074400478 : Closed e2409074400478 ∧ code e2409074400478 = 11205167422686 := by decide
theorem cert_e2409074400478 : check e2409074400478 [[],[]] .chain = true := by decide
def e2409074400506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2409074400506 : Closed e2409074400506 ∧ code e2409074400506 = 11205167422714 := by decide
theorem cert_e2409074400506 : check e2409074400506 [[],[]] .chain = true := by decide
def e2409074401078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409074401078 : Closed e2409074401078 ∧ code e2409074401078 = 11205167423286 := by decide
theorem cert_e2409074401078 : check e2409074401078 [[],[]] .chain = true := by decide
def e2409074401082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409074401082 : Closed e2409074401082 ∧ code e2409074401082 = 11205167423290 := by decide
theorem cert_e2409074401082 : check e2409074401082 [[],[]] .chain = true := by decide
def e2409074415854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2409074415854 : Closed e2409074415854 ∧ code e2409074415854 = 11205167438062 := by decide
theorem cert_e2409074415854 : check e2409074415854 [[],[]] .chain = true := by decide
def e2409074415862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2409074415862 : Closed e2409074415862 ∧ code e2409074415862 = 11205167438070 := by decide
theorem cert_e2409074415862 : check e2409074415862 [[],[]] .chain = true := by decide
def e2409074416414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2409074416414 : Closed e2409074416414 ∧ code e2409074416414 = 11205167438622 := by decide
theorem cert_e2409074416414 : check e2409074416414 [[],[]] .chain = true := by decide
def e2409074416526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2409074416526 : Closed e2409074416526 ∧ code e2409074416526 = 11205167438734 := by decide
theorem cert_e2409074416526 : check e2409074416526 [[],[]] .chain = true := by decide
def e2409074416750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2409074416750 : Closed e2409074416750 ∧ code e2409074416750 = 11205167438958 := by decide
theorem cert_e2409074416750 : check e2409074416750 [[],[]] .chain = true := by decide
def e2409074416762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2409074416762 : Closed e2409074416762 ∧ code e2409074416762 = 11205167438970 := by decide
theorem cert_e2409074416762 : check e2409074416762 [[],[]] .chain = true := by decide
def e2409074416926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2409074416926 : Closed e2409074416926 ∧ code e2409074416926 = 11205167439134 := by decide
theorem cert_e2409074416926 : check e2409074416926 [[],[]] .chain = true := by decide
def e2409074417094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2409074417094 : Closed e2409074417094 ∧ code e2409074417094 = 11205167439302 := by decide
theorem cert_e2409074417094 : check e2409074417094 [[],[]] .chain = true := by decide
def e2409074417206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2409074417206 : Closed e2409074417206 ∧ code e2409074417206 = 11205167439414 := by decide
theorem cert_e2409074417206 : check e2409074417206 [[],[]] .chain = true := by decide
def e2409074417210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2409074417210 : Closed e2409074417210 ∧ code e2409074417210 = 11205167439418 := by decide
theorem cert_e2409074417210 : check e2409074417210 [[],[]] .chain = true := by decide
def e2409074417294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2409074417294 : Closed e2409074417294 ∧ code e2409074417294 = 11205167439502 := by decide
theorem cert_e2409074417294 : check e2409074417294 [[],[]] .chain = true := by decide
def e2409074417350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2409074417350 : Closed e2409074417350 ∧ code e2409074417350 = 11205167439558 := by decide
theorem cert_e2409074417350 : check e2409074417350 [[],[]] .chain = true := by decide
def e2409074419486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2409074419486 : Closed e2409074419486 ∧ code e2409074419486 = 11205167441694 := by decide
theorem cert_e2409074419486 : check e2409074419486 [[],[]] .chain = true := by decide
def e2409074419598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2409074419598 : Closed e2409074419598 ∧ code e2409074419598 = 11205167441806 := by decide
theorem cert_e2409074419598 : check e2409074419598 [[],[]] .chain = true := by decide
def e2409074422558 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2409074422558 : Closed e2409074422558 ∧ code e2409074422558 = 11205167444766 := by decide
theorem cert_e2409074422558 : check e2409074422558 [[],[]] .chain = true := by decide
def e2409074422726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2409074422726 : Closed e2409074422726 ∧ code e2409074422726 = 11205167444934 := by decide
theorem cert_e2409074422726 : check e2409074422726 [[],[]] .chain = true := by decide
def e2409074424206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2409074424206 : Closed e2409074424206 ∧ code e2409074424206 = 11205167446414 := by decide
theorem cert_e2409074424206 : check e2409074424206 [[],[]] .chain = true := by decide
def e2409074424262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2409074424262 : Closed e2409074424262 ∧ code e2409074424262 = 11205167446470 := by decide
theorem cert_e2409074424262 : check e2409074424262 [[],[]] .chain = true := by decide
def e2409074461550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2409074461550 : Closed e2409074461550 ∧ code e2409074461550 = 11205167483758 := by decide
theorem cert_e2409074461550 : check e2409074461550 [[],[]] .smaller = true := by decide
def e2409074461558 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2409074461558 : Closed e2409074461558 ∧ code e2409074461558 = 11205167483766 := by decide
theorem cert_e2409074461558 : check e2409074461558 [[],[]] .smaller = true := by decide
def e2409074461614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2409074461614 : Closed e2409074461614 ∧ code e2409074461614 = 11205167483822 := by decide
theorem cert_e2409074461614 : check e2409074461614 [[],[]] .smaller = true := by decide
def e2409074461626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2409074461626 : Closed e2409074461626 ∧ code e2409074461626 = 11205167483834 := by decide
theorem cert_e2409074461626 : check e2409074461626 [[],[]] .smaller = true := by decide
def e2409074461654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2409074461654 : Closed e2409074461654 ∧ code e2409074461654 = 11205167483862 := by decide
theorem cert_e2409074461654 : check e2409074461654 [[],[]] .smaller = true := by decide
def e2409074461658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2409074461658 : Closed e2409074461658 ∧ code e2409074461658 = 11205167483866 := by decide
theorem cert_e2409074461658 : check e2409074461658 [[],[]] .smaller = true := by decide
def e2409074461934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2409074461934 : Closed e2409074461934 ∧ code e2409074461934 = 11205167484142 := by decide
theorem cert_e2409074461934 : check e2409074461934 [[],[]] .smaller = true := by decide
def e2409074461942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2409074461942 : Closed e2409074461942 ∧ code e2409074461942 = 11205167484150 := by decide
theorem cert_e2409074461942 : check e2409074461942 [[],[]] .smaller = true := by decide
def e2409074462318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2409074462318 : Closed e2409074462318 ∧ code e2409074462318 = 11205167484526 := by decide
theorem cert_e2409074462318 : check e2409074462318 [[],[]] .smaller = true := by decide
def e2409074462330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2409074462330 : Closed e2409074462330 ∧ code e2409074462330 = 11205167484538 := by decide
theorem cert_e2409074462330 : check e2409074462330 [[],[]] .smaller = true := by decide
def e2409074462518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409074462518 : Closed e2409074462518 ∧ code e2409074462518 = 11205167484726 := by decide
theorem cert_e2409074462518 : check e2409074462518 [[],[]] .smaller = true := by decide
def e2409074462522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409074462522 : Closed e2409074462522 ∧ code e2409074462522 = 11205167484730 := by decide
theorem cert_e2409074462522 : check e2409074462522 [[],[]] .smaller = true := by decide
def e2409074469998 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2409074469998 : Closed e2409074469998 ∧ code e2409074469998 = 11205167492206 := by decide
theorem cert_e2409074469998 : check e2409074469998 [[],[]] .chain = true := by decide
def e2409074470010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2409074470010 : Closed e2409074470010 ∧ code e2409074470010 = 11205167492218 := by decide
theorem cert_e2409074470010 : check e2409074470010 [[],[]] .chain = true := by decide
def e2409074470174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2409074470174 : Closed e2409074470174 ∧ code e2409074470174 = 11205167492382 := by decide
theorem cert_e2409074470174 : check e2409074470174 [[],[]] .chain = true := by decide
def e2409074470342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2409074470342 : Closed e2409074470342 ∧ code e2409074470342 = 11205167492550 := by decide
theorem cert_e2409074470342 : check e2409074470342 [[],[]] .chain = true := by decide
def e2409074470682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2409074470682 : Closed e2409074470682 ∧ code e2409074470682 = 11205167492890 := by decide
theorem cert_e2409074470682 : check e2409074470682 [[],[]] .chain = true := by decide
def e2409074470726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2409074470726 : Closed e2409074470726 ∧ code e2409074470726 = 11205167492934 := by decide
theorem cert_e2409074470726 : check e2409074470726 [[],[]] .chain = true := by decide
def e2409074471710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2409074471710 : Closed e2409074471710 ∧ code e2409074471710 = 11205167493918 := by decide
theorem cert_e2409074471710 : check e2409074471710 [[],[]] .chain = true := by decide
def e2409074471878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2409074471878 : Closed e2409074471878 ∧ code e2409074471878 = 11205167494086 := by decide
theorem cert_e2409074471878 : check e2409074471878 [[],[]] .chain = true := by decide
def e2409074474182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2409074474182 : Closed e2409074474182 ∧ code e2409074474182 = 11205167496390 := by decide
theorem cert_e2409074474182 : check e2409074474182 [[],[]] .chain = true := by decide
def e2409074497078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2409074497078 : Closed e2409074497078 ∧ code e2409074497078 = 11205167519286 := by decide
theorem cert_e2409074497078 : check e2409074497078 [[],[]] .chain = true := by decide
def e2409074497082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2409074497082 : Closed e2409074497082 ∧ code e2409074497082 = 11205167519290 := by decide
theorem cert_e2409074497082 : check e2409074497082 [[],[]] .chain = true := by decide
def e2409074497166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2409074497166 : Closed e2409074497166 ∧ code e2409074497166 = 11205167519374 := by decide
theorem cert_e2409074497166 : check e2409074497166 [[],[]] .chain = true := by decide
def e2409074497222 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2409074497222 : Closed e2409074497222 ∧ code e2409074497222 = 11205167519430 := by decide
theorem cert_e2409074497222 : check e2409074497222 [[],[]] .chain = true := by decide
def e2409074497306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2409074497306 : Closed e2409074497306 ∧ code e2409074497306 = 11205167519514 := by decide
theorem cert_e2409074497306 : check e2409074497306 [[],[]] .chain = true := by decide
def e2409074497350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2409074497350 : Closed e2409074497350 ∧ code e2409074497350 = 11205167519558 := by decide
theorem cert_e2409074497350 : check e2409074497350 [[],[]] .chain = true := by decide
def e2409074497934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2409074497934 : Closed e2409074497934 ∧ code e2409074497934 = 11205167520142 := by decide
theorem cert_e2409074497934 : check e2409074497934 [[],[]] .chain = true := by decide
def e2409074497990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2409074497990 : Closed e2409074497990 ∧ code e2409074497990 = 11205167520198 := by decide
theorem cert_e2409074497990 : check e2409074497990 [[],[]] .chain = true := by decide
def e2409074498758 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2409074498758 : Closed e2409074498758 ∧ code e2409074498758 = 11205167520966 := by decide
theorem cert_e2409074498758 : check e2409074498758 [[],[]] .chain = true := by decide
def e2409075595502 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2409075595502 : Closed e2409075595502 ∧ code e2409075595502 = 11205168617710 := by decide
theorem cert_e2409075595502 : check e2409075595502 [[],[]] .chain = true := by decide
def e2409075595510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2409075595510 : Closed e2409075595510 ∧ code e2409075595510 = 11205168617718 := by decide
theorem cert_e2409075595510 : check e2409075595510 [[],[]] .chain = true := by decide
def e2409075596062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2409075596062 : Closed e2409075596062 ∧ code e2409075596062 = 11205168618270 := by decide
theorem cert_e2409075596062 : check e2409075596062 [[],[]] .chain = true := by decide
def e2409075596174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2409075596174 : Closed e2409075596174 ∧ code e2409075596174 = 11205168618382 := by decide
theorem cert_e2409075596174 : check e2409075596174 [[],[]] .chain = true := by decide
def e2409075596398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2409075596398 : Closed e2409075596398 ∧ code e2409075596398 = 11205168618606 := by decide
theorem cert_e2409075596398 : check e2409075596398 [[],[]] .chain = true := by decide
def e2409075596410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2409075596410 : Closed e2409075596410 ∧ code e2409075596410 = 11205168618618 := by decide
theorem cert_e2409075596410 : check e2409075596410 [[],[]] .chain = true := by decide
def e2409075596574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2409075596574 : Closed e2409075596574 ∧ code e2409075596574 = 11205168618782 := by decide
theorem cert_e2409075596574 : check e2409075596574 [[],[]] .chain = true := by decide
def e2409075596742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2409075596742 : Closed e2409075596742 ∧ code e2409075596742 = 11205168618950 := by decide
theorem cert_e2409075596742 : check e2409075596742 [[],[]] .chain = true := by decide
def e2409075596854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2409075596854 : Closed e2409075596854 ∧ code e2409075596854 = 11205168619062 := by decide
theorem cert_e2409075596854 : check e2409075596854 [[],[]] .chain = true := by decide
def e2409075596858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2409075596858 : Closed e2409075596858 ∧ code e2409075596858 = 11205168619066 := by decide
theorem cert_e2409075596858 : check e2409075596858 [[],[]] .chain = true := by decide
def e2409075596942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2409075596942 : Closed e2409075596942 ∧ code e2409075596942 = 11205168619150 := by decide
theorem cert_e2409075596942 : check e2409075596942 [[],[]] .chain = true := by decide
def e2409075596998 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2409075596998 : Closed e2409075596998 ∧ code e2409075596998 = 11205168619206 := by decide
theorem cert_e2409075596998 : check e2409075596998 [[],[]] .chain = true := by decide
def e2409075599134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2409075599134 : Closed e2409075599134 ∧ code e2409075599134 = 11205168621342 := by decide
theorem cert_e2409075599134 : check e2409075599134 [[],[]] .chain = true := by decide
def e2409075599246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2409075599246 : Closed e2409075599246 ∧ code e2409075599246 = 11205168621454 := by decide
theorem cert_e2409075599246 : check e2409075599246 [[],[]] .chain = true := by decide
def e2409075602206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2409075602206 : Closed e2409075602206 ∧ code e2409075602206 = 11205168624414 := by decide
theorem cert_e2409075602206 : check e2409075602206 [[],[]] .chain = true := by decide
def e2409075602374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2409075602374 : Closed e2409075602374 ∧ code e2409075602374 = 11205168624582 := by decide
theorem cert_e2409075602374 : check e2409075602374 [[],[]] .chain = true := by decide
def e2409075603854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2409075603854 : Closed e2409075603854 ∧ code e2409075603854 = 11205168626062 := by decide
theorem cert_e2409075603854 : check e2409075603854 [[],[]] .chain = true := by decide
def e2409075603910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2409075603910 : Closed e2409075603910 ∧ code e2409075603910 = 11205168626118 := by decide
theorem cert_e2409075603910 : check e2409075603910 [[],[]] .chain = true := by decide
def e2409080297182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2409080297182 : Closed e2409080297182 ∧ code e2409080297182 = 11205173319390 := by decide
theorem cert_e2409080297182 : check e2409080297182 [[],[],[],[],[]] .chain = true := by decide
def e2409080297206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2409080297206 : Closed e2409080297206 ∧ code e2409080297206 = 11205173319414 := by decide
theorem cert_e2409080297206 : check e2409080297206 [[],[],[],[],[]] .chain = true := by decide
def e2409080297310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2409080297310 : Closed e2409080297310 ∧ code e2409080297310 = 11205173319518 := by decide
theorem cert_e2409080297310 : check e2409080297310 [[],[],[],[],[]] .chain = true := by decide
def e2409080297338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2409080297338 : Closed e2409080297338 ∧ code e2409080297338 = 11205173319546 := by decide
theorem cert_e2409080297338 : check e2409080297338 [[],[],[],[],[]] .chain = true := by decide
def e2409080297430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2409080297430 : Closed e2409080297430 ∧ code e2409080297430 = 11205173319638 := by decide
theorem cert_e2409080297430 : check e2409080297430 [[],[],[],[],[]] .chain = true := by decide
def e2409080297434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2409080297434 : Closed e2409080297434 ∧ code e2409080297434 = 11205173319642 := by decide
theorem cert_e2409080297434 : check e2409080297434 [[],[],[],[],[]] .chain = true := by decide
def e2409080297950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2409080297950 : Closed e2409080297950 ∧ code e2409080297950 = 11205173320158 := by decide
theorem cert_e2409080297950 : check e2409080297950 [[],[],[],[],[]] .chain = true := by decide
def e2409080297974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2409080297974 : Closed e2409080297974 ∧ code e2409080297974 = 11205173320182 := by decide
theorem cert_e2409080297974 : check e2409080297974 [[],[],[],[],[]] .chain = true := by decide
def e2409080298718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2409080298718 : Closed e2409080298718 ∧ code e2409080298718 = 11205173320926 := by decide
theorem cert_e2409080298718 : check e2409080298718 [[],[],[],[],[]] .chain = true := by decide
def e2409080298746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2409080298746 : Closed e2409080298746 ∧ code e2409080298746 = 11205173320954 := by decide
theorem cert_e2409080298746 : check e2409080298746 [[],[],[],[],[]] .chain = true := by decide
def e2409080299318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409080299318 : Closed e2409080299318 ∧ code e2409080299318 = 11205173321526 := by decide
theorem cert_e2409080299318 : check e2409080299318 [[],[],[],[],[]] .chain = true := by decide
def e2409080299322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409080299322 : Closed e2409080299322 ∧ code e2409080299322 = 11205173321530 := by decide
theorem cert_e2409080299322 : check e2409080299322 [[],[],[],[],[]] .chain = true := by decide
def e2409080314094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2409080314094 : Closed e2409080314094 ∧ code e2409080314094 = 11205173336302 := by decide
theorem cert_e2409080314094 : check e2409080314094 [[],[],[],[],[]] .sourceHead = true := by decide
def e2409080314102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2409080314102 : Closed e2409080314102 ∧ code e2409080314102 = 11205173336310 := by decide
theorem cert_e2409080314102 : check e2409080314102 [[],[],[],[],[]] .sourceHead = true := by decide
def e2409080314654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2409080314654 : Closed e2409080314654 ∧ code e2409080314654 = 11205173336862 := by decide
theorem cert_e2409080314654 : check e2409080314654 [[],[],[],[],[]] .sourceHead = true := by decide
def e2409080314766 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2409080314766 : Closed e2409080314766 ∧ code e2409080314766 = 11205173336974 := by decide
theorem cert_e2409080314766 : check e2409080314766 [[],[],[],[],[]] .sourceHead = true := by decide
def e2409080314990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2409080314990 : Closed e2409080314990 ∧ code e2409080314990 = 11205173337198 := by decide
theorem cert_e2409080314990 : check e2409080314990 [[],[],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2409080315002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2409080315002 : Closed e2409080315002 ∧ code e2409080315002 = 11205173337210 := by decide
theorem cert_e2409080315002 : check e2409080315002 [[],[],[],[],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e2409080315166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2409080315166 : Closed e2409080315166 ∧ code e2409080315166 = 11205173337374 := by decide
theorem cert_e2409080315166 : check e2409080315166 [[],[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2409080315334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2409080315334 : Closed e2409080315334 ∧ code e2409080315334 = 11205173337542 := by decide
private def t_e2409080315334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e2409080315334 : ¬ IsSelfInterpreter e2409080315334 :=
  wSource (t := t_e2409080315334) (replay_sound (ps := []) (t := e2409080315334) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2409080315334
