import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862030182830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e862030182830 : Closed e862030182830 ∧ code e862030182830 = 9658123205038 := by decide
theorem cert_e862030182830 : check e862030182830 [] .sourceHead = true := by decide
def e862030182842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e862030182842 : Closed e862030182842 ∧ code e862030182842 = 9658123205050 := by decide
theorem cert_e862030182842 : check e862030182842 [] .sourceHead = true := by decide
def e862030182890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e862030182890 : Closed e862030182890 ∧ code e862030182890 = 9658123205098 := by decide
theorem cert_e862030182890 : check e862030182890 [] .sourceHead = true := by decide
def e862030183022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862030183022 : Closed e862030183022 ∧ code e862030183022 = 9658123205230 := by decide
theorem cert_e862030183022 : check e862030183022 [] .sourceHead = true := by decide
def e862030183034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862030183034 : Closed e862030183034 ∧ code e862030183034 = 9658123205242 := by decide
theorem cert_e862030183034 : check e862030183034 [] .sourceHead = true := by decide
def e862030183322 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862030183322 : Closed e862030183322 ∧ code e862030183322 = 9658123205530 := by decide
theorem cert_e862030183322 : check e862030183322 [] .sourceHead = true := by decide
def e862030183638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e862030183638 : Closed e862030183638 ∧ code e862030183638 = 9658123205846 := by decide
theorem cert_e862030183638 : check e862030183638 [] .sourceHead = true := by decide
def e862030183642 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e862030183642 : Closed e862030183642 ∧ code e862030183642 = 9658123205850 := by decide
theorem cert_e862030183642 : check e862030183642 [] .sourceHead = true := by decide
def e862030183658 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e862030183658 : Closed e862030183658 ∧ code e862030183658 = 9658123205866 := by decide
theorem cert_e862030183658 : check e862030183658 [] .sourceHead = true := by decide
def e862030183734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862030183734 : Closed e862030183734 ∧ code e862030183734 = 9658123205942 := by decide
theorem cert_e862030183734 : check e862030183734 [] .sourceHead = true := by decide
def e862030183738 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862030183738 : Closed e862030183738 ∧ code e862030183738 = 9658123205946 := by decide
theorem cert_e862030183738 : check e862030183738 [] .sourceHead = true := by decide
def e862030183834 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862030183834 : Closed e862030183834 ∧ code e862030183834 = 9658123206042 := by decide
theorem cert_e862030183834 : check e862030183834 [] .sourceHead = true := by decide
def e862030187374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862030187374 : Closed e862030187374 ∧ code e862030187374 = 9658123209582 := by decide
theorem cert_e862030187374 : check e862030187374 [] .sourceHead = true := by decide
def e862030187382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862030187382 : Closed e862030187382 ∧ code e862030187382 = 9658123209590 := by decide
theorem cert_e862030187382 : check e862030187382 [] .sourceHead = true := by decide
def e862030187438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862030187438 : Closed e862030187438 ∧ code e862030187438 = 9658123209646 := by decide
theorem cert_e862030187438 : check e862030187438 [] .sourceHead = true := by decide
def e862030187450 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862030187450 : Closed e862030187450 ∧ code e862030187450 = 9658123209658 := by decide
theorem cert_e862030187450 : check e862030187450 [] .sourceHead = true := by decide
def e862030187478 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862030187478 : Closed e862030187478 ∧ code e862030187478 = 9658123209686 := by decide
theorem cert_e862030187478 : check e862030187478 [] .sourceHead = true := by decide
def e862030187482 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862030187482 : Closed e862030187482 ∧ code e862030187482 = 9658123209690 := by decide
theorem cert_e862030187482 : check e862030187482 [] .sourceHead = true := by decide
def e862030187758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862030187758 : Closed e862030187758 ∧ code e862030187758 = 9658123209966 := by decide
theorem cert_e862030187758 : check e862030187758 [] .sourceHead = true := by decide
def e862030187766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862030187766 : Closed e862030187766 ∧ code e862030187766 = 9658123209974 := by decide
theorem cert_e862030187766 : check e862030187766 [] .sourceHead = true := by decide
def e862030188142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862030188142 : Closed e862030188142 ∧ code e862030188142 = 9658123210350 := by decide
theorem cert_e862030188142 : check e862030188142 [] .sourceHead = true := by decide
def e862030188154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862030188154 : Closed e862030188154 ∧ code e862030188154 = 9658123210362 := by decide
theorem cert_e862030188154 : check e862030188154 [] .sourceHead = true := by decide
def e862030188342 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862030188342 : Closed e862030188342 ∧ code e862030188342 = 9658123210550 := by decide
theorem cert_e862030188342 : check e862030188342 [] .sourceHead = true := by decide
def e862030188346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862030188346 : Closed e862030188346 ∧ code e862030188346 = 9658123210554 := by decide
theorem cert_e862030188346 : check e862030188346 [] .sourceHead = true := by decide
def e862030194094 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e862030194094 : Closed e862030194094 ∧ code e862030194094 = 9658123216302 := by decide
theorem cert_e862030194094 : check e862030194094 [] .sourceHead = true := by decide
def e862030194106 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e862030194106 : Closed e862030194106 ∧ code e862030194106 = 9658123216314 := by decide
theorem cert_e862030194106 : check e862030194106 [] .sourceHead = true := by decide
def e862030194154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e862030194154 : Closed e862030194154 ∧ code e862030194154 = 9658123216362 := by decide
theorem cert_e862030194154 : check e862030194154 [] .sourceHead = true := by decide
def e862030194286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e862030194286 : Closed e862030194286 ∧ code e862030194286 = 9658123216494 := by decide
theorem cert_e862030194286 : check e862030194286 [] .sourceHead = true := by decide
def e862030194298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e862030194298 : Closed e862030194298 ∧ code e862030194298 = 9658123216506 := by decide
theorem cert_e862030194298 : check e862030194298 [] .sourceHead = true := by decide
def e862030194586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e862030194586 : Closed e862030194586 ∧ code e862030194586 = 9658123216794 := by decide
theorem cert_e862030194586 : check e862030194586 [] .sourceHead = true := by decide
def e862030197462 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e862030197462 : Closed e862030197462 ∧ code e862030197462 = 9658123219670 := by decide
theorem cert_e862030197462 : check e862030197462 [] .sourceHead = true := by decide
def e862030197466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e862030197466 : Closed e862030197466 ∧ code e862030197466 = 9658123219674 := by decide
theorem cert_e862030197466 : check e862030197466 [] .sourceHead = true := by decide
def e862030197482 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e862030197482 : Closed e862030197482 ∧ code e862030197482 = 9658123219690 := by decide
theorem cert_e862030197482 : check e862030197482 [] .sourceHead = true := by decide
def e862030197558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e862030197558 : Closed e862030197558 ∧ code e862030197558 = 9658123219766 := by decide
theorem cert_e862030197558 : check e862030197558 [] .sourceHead = true := by decide
def e862030197562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e862030197562 : Closed e862030197562 ∧ code e862030197562 = 9658123219770 := by decide
theorem cert_e862030197562 : check e862030197562 [] .sourceHead = true := by decide
def e862030197658 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e862030197658 : Closed e862030197658 ∧ code e862030197658 = 9658123219866 := by decide
theorem cert_e862030197658 : check e862030197658 [] .sourceHead = true := by decide
def e862030334830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862030334830 : Closed e862030334830 ∧ code e862030334830 = 9658123357038 := by decide
theorem cert_e862030334830 : check e862030334830 [] .sourceHead = true := by decide
def e862030334838 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862030334838 : Closed e862030334838 ∧ code e862030334838 = 9658123357046 := by decide
theorem cert_e862030334838 : check e862030334838 [] .sourceHead = true := by decide
def e862030334894 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862030334894 : Closed e862030334894 ∧ code e862030334894 = 9658123357102 := by decide
theorem cert_e862030334894 : check e862030334894 [] .sourceHead = true := by decide
def e862030334906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862030334906 : Closed e862030334906 ∧ code e862030334906 = 9658123357114 := by decide
theorem cert_e862030334906 : check e862030334906 [] .sourceHead = true := by decide
def e862030334934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862030334934 : Closed e862030334934 ∧ code e862030334934 = 9658123357142 := by decide
theorem cert_e862030334934 : check e862030334934 [] .sourceHead = true := by decide
def e862030334938 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862030334938 : Closed e862030334938 ∧ code e862030334938 = 9658123357146 := by decide
theorem cert_e862030334938 : check e862030334938 [] .sourceHead = true := by decide
def e862030335214 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862030335214 : Closed e862030335214 ∧ code e862030335214 = 9658123357422 := by decide
theorem cert_e862030335214 : check e862030335214 [] .sourceHead = true := by decide
def e862030335222 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862030335222 : Closed e862030335222 ∧ code e862030335222 = 9658123357430 := by decide
theorem cert_e862030335222 : check e862030335222 [] .sourceHead = true := by decide
def e862030335598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862030335598 : Closed e862030335598 ∧ code e862030335598 = 9658123357806 := by decide
theorem cert_e862030335598 : check e862030335598 [] .sourceHead = true := by decide
def e862030335610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862030335610 : Closed e862030335610 ∧ code e862030335610 = 9658123357818 := by decide
theorem cert_e862030335610 : check e862030335610 [] .sourceHead = true := by decide
def e862030335798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862030335798 : Closed e862030335798 ∧ code e862030335798 = 9658123358006 := by decide
theorem cert_e862030335798 : check e862030335798 [] .sourceHead = true := by decide
def e862030335802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862030335802 : Closed e862030335802 ∧ code e862030335802 = 9658123358010 := by decide
theorem cert_e862030335802 : check e862030335802 [] .sourceHead = true := by decide
def e862030924654 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862030924654 : Closed e862030924654 ∧ code e862030924654 = 9658123946862 := by decide
theorem cert_e862030924654 : check e862030924654 [] .sourceHead = true := by decide
def e862030924662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862030924662 : Closed e862030924662 ∧ code e862030924662 = 9658123946870 := by decide
theorem cert_e862030924662 : check e862030924662 [] .sourceHead = true := by decide
def e862030924718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862030924718 : Closed e862030924718 ∧ code e862030924718 = 9658123946926 := by decide
theorem cert_e862030924718 : check e862030924718 [] .sourceHead = true := by decide
def e862030924730 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862030924730 : Closed e862030924730 ∧ code e862030924730 = 9658123946938 := by decide
theorem cert_e862030924730 : check e862030924730 [] .sourceHead = true := by decide
def e862030924758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862030924758 : Closed e862030924758 ∧ code e862030924758 = 9658123946966 := by decide
theorem cert_e862030924758 : check e862030924758 [] .sourceHead = true := by decide
def e862030924762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862030924762 : Closed e862030924762 ∧ code e862030924762 = 9658123946970 := by decide
theorem cert_e862030924762 : check e862030924762 [] .sourceHead = true := by decide
def e862030925038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862030925038 : Closed e862030925038 ∧ code e862030925038 = 9658123947246 := by decide
theorem cert_e862030925038 : check e862030925038 [] .sourceHead = true := by decide
def e862030925046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862030925046 : Closed e862030925046 ∧ code e862030925046 = 9658123947254 := by decide
theorem cert_e862030925046 : check e862030925046 [] .sourceHead = true := by decide
def e862030925422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862030925422 : Closed e862030925422 ∧ code e862030925422 = 9658123947630 := by decide
theorem cert_e862030925422 : check e862030925422 [] .sourceHead = true := by decide
def e862030925434 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862030925434 : Closed e862030925434 ∧ code e862030925434 = 9658123947642 := by decide
theorem cert_e862030925434 : check e862030925434 [] .sourceHead = true := by decide
def e862030925622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862030925622 : Closed e862030925622 ∧ code e862030925622 = 9658123947830 := by decide
theorem cert_e862030925622 : check e862030925622 [] .sourceHead = true := by decide
def e862030925626 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862030925626 : Closed e862030925626 ∧ code e862030925626 = 9658123947834 := by decide
theorem cert_e862030925626 : check e862030925626 [] .sourceHead = true := by decide
def e862226669594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862226669594 : Closed e862226669594 ∧ code e862226669594 = 9658319691802 := by decide
theorem cert_e862226669594 : check e862226669594 [] .sourceHead = true := by decide
def e862226669686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862226669686 : Closed e862226669686 ∧ code e862226669686 = 9658319691894 := by decide
theorem cert_e862226669686 : check e862226669686 [] .sourceHead = true := by decide
def e862226669930 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862226669930 : Closed e862226669930 ∧ code e862226669930 = 9658319692138 := by decide
theorem cert_e862226669930 : check e862226669930 [] .sourceHead = true := by decide
def e862226669978 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862226669978 : Closed e862226669978 ∧ code e862226669978 = 9658319692186 := by decide
theorem cert_e862226669978 : check e862226669978 [] .sourceHead = true := by decide
def e862226671130 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862226671130 : Closed e862226671130 ∧ code e862226671130 = 9658319693338 := by decide
theorem cert_e862226671130 : check e862226671130 [] .sourceHead = true := by decide
def e862226702362 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862226702362 : Closed e862226702362 ∧ code e862226702362 = 9658319724570 := by decide
theorem cert_e862226702362 : check e862226702362 [] .sourceHead = true := by decide
def e862226702454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862226702454 : Closed e862226702454 ∧ code e862226702454 = 9658319724662 := by decide
theorem cert_e862226702454 : check e862226702454 [] .sourceHead = true := by decide
def e862226702698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862226702698 : Closed e862226702698 ∧ code e862226702698 = 9658319724906 := by decide
theorem cert_e862226702698 : check e862226702698 [] .sourceHead = true := by decide
def e862226702746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862226702746 : Closed e862226702746 ∧ code e862226702746 = 9658319724954 := by decide
theorem cert_e862226702746 : check e862226702746 [] .sourceHead = true := by decide
def e862226703898 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862226703898 : Closed e862226703898 ∧ code e862226703898 = 9658319726106 := by decide
theorem cert_e862226703898 : check e862226703898 [] .sourceHead = true := by decide
def e862226931738 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862226931738 : Closed e862226931738 ∧ code e862226931738 = 9658319953946 := by decide
theorem cert_e862226931738 : check e862226931738 [] .sourceHead = true := by decide
def e862226931830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862226931830 : Closed e862226931830 ∧ code e862226931830 = 9658319954038 := by decide
theorem cert_e862226931830 : check e862226931830 [] .sourceHead = true := by decide
def e862226932074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862226932074 : Closed e862226932074 ∧ code e862226932074 = 9658319954282 := by decide
theorem cert_e862226932074 : check e862226932074 [] .sourceHead = true := by decide
def e862226932122 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862226932122 : Closed e862226932122 ∧ code e862226932122 = 9658319954330 := by decide
theorem cert_e862226932122 : check e862226932122 [] .sourceHead = true := by decide
def e862226933274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862226933274 : Closed e862226933274 ∧ code e862226933274 = 9658319955482 := by decide
theorem cert_e862226933274 : check e862226933274 [] .sourceHead = true := by decide
def e862226980890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862226980890 : Closed e862226980890 ∧ code e862226980890 = 9658320003098 := by decide
theorem cert_e862226980890 : check e862226980890 [] .sourceHead = true := by decide
def e862226980982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862226980982 : Closed e862226980982 ∧ code e862226980982 = 9658320003190 := by decide
theorem cert_e862226980982 : check e862226980982 [] .sourceHead = true := by decide
def e862226981226 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862226981226 : Closed e862226981226 ∧ code e862226981226 = 9658320003434 := by decide
theorem cert_e862226981226 : check e862226981226 [] .sourceHead = true := by decide
def e862226981274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862226981274 : Closed e862226981274 ∧ code e862226981274 = 9658320003482 := by decide
theorem cert_e862226981274 : check e862226981274 [] .sourceHead = true := by decide
def e862226982426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862226982426 : Closed e862226982426 ∧ code e862226982426 = 9658320004634 := by decide
theorem cert_e862226982426 : check e862226982426 [] .sourceHead = true := by decide
def e862227095578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862227095578 : Closed e862227095578 ∧ code e862227095578 = 9658320117786 := by decide
theorem cert_e862227095578 : check e862227095578 [] .sourceHead = true := by decide
def e862227095670 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862227095670 : Closed e862227095670 ∧ code e862227095670 = 9658320117878 := by decide
theorem cert_e862227095670 : check e862227095670 [] .sourceHead = true := by decide
def e862227095914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862227095914 : Closed e862227095914 ∧ code e862227095914 = 9658320118122 := by decide
theorem cert_e862227095914 : check e862227095914 [] .sourceHead = true := by decide
def e862227095962 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862227095962 : Closed e862227095962 ∧ code e862227095962 = 9658320118170 := by decide
theorem cert_e862227095962 : check e862227095962 [] .sourceHead = true := by decide
def e862227097114 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862227097114 : Closed e862227097114 ∧ code e862227097114 = 9658320119322 := by decide
theorem cert_e862227097114 : check e862227097114 [] .sourceHead = true := by decide
def e862227111962 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862227111962 : Closed e862227111962 ∧ code e862227111962 = 9658320134170 := by decide
theorem cert_e862227111962 : check e862227111962 [] .sourceHead = true := by decide
def e862227112054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862227112054 : Closed e862227112054 ∧ code e862227112054 = 9658320134262 := by decide
theorem cert_e862227112054 : check e862227112054 [] .sourceHead = true := by decide
def e862227112298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862227112298 : Closed e862227112298 ∧ code e862227112298 = 9658320134506 := by decide
theorem cert_e862227112298 : check e862227112298 [] .sourceHead = true := by decide
def e862227112346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862227112346 : Closed e862227112346 ∧ code e862227112346 = 9658320134554 := by decide
theorem cert_e862227112346 : check e862227112346 [] .sourceHead = true := by decide
def e862227113498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862227113498 : Closed e862227113498 ∧ code e862227113498 = 9658320135706 := by decide
theorem cert_e862227113498 : check e862227113498 [] .sourceHead = true := by decide
def e862228242458 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862228242458 : Closed e862228242458 ∧ code e862228242458 = 9658321264666 := by decide
theorem cert_e862228242458 : check e862228242458 [] .sourceHead = true := by decide
def e862228242550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862228242550 : Closed e862228242550 ∧ code e862228242550 = 9658321264758 := by decide
theorem cert_e862228242550 : check e862228242550 [] .sourceHead = true := by decide
def e862228242794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862228242794 : Closed e862228242794 ∧ code e862228242794 = 9658321265002 := by decide
theorem cert_e862228242794 : check e862228242794 [] .sourceHead = true := by decide
def e862228242842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862228242842 : Closed e862228242842 ∧ code e862228242842 = 9658321265050 := by decide
theorem cert_e862228242842 : check e862228242842 [] .sourceHead = true := by decide
def e862228243994 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862228243994 : Closed e862228243994 ∧ code e862228243994 = 9658321266202 := by decide
theorem cert_e862228243994 : check e862228243994 [] .sourceHead = true := by decide
def e862228275226 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862228275226 : Closed e862228275226 ∧ code e862228275226 = 9658321297434 := by decide
theorem cert_e862228275226 : check e862228275226 [] .sourceHead = true := by decide
def e862228275318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862228275318 : Closed e862228275318 ∧ code e862228275318 = 9658321297526 := by decide
theorem cert_e862228275318 : check e862228275318 [] .sourceHead = true := by decide
def e862228275562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862228275562 : Closed e862228275562 ∧ code e862228275562 = 9658321297770 := by decide
theorem cert_e862228275562 : check e862228275562 [] .sourceHead = true := by decide
def e862228275610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862228275610 : Closed e862228275610 ∧ code e862228275610 = 9658321297818 := by decide
theorem cert_e862228275610 : check e862228275610 [] .sourceHead = true := by decide
def e862228276762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862228276762 : Closed e862228276762 ∧ code e862228276762 = 9658321298970 := by decide
theorem cert_e862228276762 : check e862228276762 [] .sourceHead = true := by decide
def e862229815322 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862229815322 : Closed e862229815322 ∧ code e862229815322 = 9658322837530 := by decide
theorem cert_e862229815322 : check e862229815322 [] .sourceHead = true := by decide
def e862229815414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862229815414 : Closed e862229815414 ∧ code e862229815414 = 9658322837622 := by decide
theorem cert_e862229815414 : check e862229815414 [] .sourceHead = true := by decide
def e862229815658 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862229815658 : Closed e862229815658 ∧ code e862229815658 = 9658322837866 := by decide
theorem cert_e862229815658 : check e862229815658 [] .sourceHead = true := by decide
def e862229815706 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862229815706 : Closed e862229815706 ∧ code e862229815706 = 9658322837914 := by decide
theorem cert_e862229815706 : check e862229815706 [] .sourceHead = true := by decide
def e862229816858 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862229816858 : Closed e862229816858 ∧ code e862229816858 = 9658322839066 := by decide
theorem cert_e862229816858 : check e862229816858 [] .sourceHead = true := by decide
def e862229864474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862229864474 : Closed e862229864474 ∧ code e862229864474 = 9658322886682 := by decide
theorem cert_e862229864474 : check e862229864474 [] .sourceHead = true := by decide
def e862229864566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862229864566 : Closed e862229864566 ∧ code e862229864566 = 9658322886774 := by decide
theorem cert_e862229864566 : check e862229864566 [] .sourceHead = true := by decide
def e862229864810 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862229864810 : Closed e862229864810 ∧ code e862229864810 = 9658322887018 := by decide
theorem cert_e862229864810 : check e862229864810 [] .sourceHead = true := by decide
def e862229864858 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862229864858 : Closed e862229864858 ∧ code e862229864858 = 9658322887066 := by decide
theorem cert_e862229864858 : check e862229864858 [] .sourceHead = true := by decide
def e862229866010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862229866010 : Closed e862229866010 ∧ code e862229866010 = 9658322888218 := by decide
theorem cert_e862229866010 : check e862229866010 [] .sourceHead = true := by decide
def e862230634522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862230634522 : Closed e862230634522 ∧ code e862230634522 = 9658323656730 := by decide
theorem cert_e862230634522 : check e862230634522 [] .sourceHead = true := by decide
def e862230634614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862230634614 : Closed e862230634614 ∧ code e862230634614 = 9658323656822 := by decide
theorem cert_e862230634614 : check e862230634614 [] .sourceHead = true := by decide
def e862230634858 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862230634858 : Closed e862230634858 ∧ code e862230634858 = 9658323657066 := by decide
theorem cert_e862230634858 : check e862230634858 [] .sourceHead = true := by decide
def e862230634906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862230634906 : Closed e862230634906 ∧ code e862230634906 = 9658323657114 := by decide
theorem cert_e862230634906 : check e862230634906 [] .sourceHead = true := by decide
def e862230636058 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862230636058 : Closed e862230636058 ∧ code e862230636058 = 9658323658266 := by decide
theorem cert_e862230636058 : check e862230636058 [] .sourceHead = true := by decide
def e862230650906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e862230650906 : Closed e862230650906 ∧ code e862230650906 = 9658323673114 := by decide
theorem cert_e862230650906 : check e862230650906 [] .sourceHead = true := by decide
def e862230650998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e862230650998 : Closed e862230650998 ∧ code e862230650998 = 9658323673206 := by decide
theorem cert_e862230650998 : check e862230650998 [] .sourceHead = true := by decide
def e862230651242 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e862230651242 : Closed e862230651242 ∧ code e862230651242 = 9658323673450 := by decide
theorem cert_e862230651242 : check e862230651242 [] .sourceHead = true := by decide
def e862230651290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e862230651290 : Closed e862230651290 ∧ code e862230651290 = 9658323673498 := by decide
theorem cert_e862230651290 : check e862230651290 [] .sourceHead = true := by decide
def e862230652442 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e862230652442 : Closed e862230652442 ∧ code e862230652442 = 9658323674650 := by decide
theorem cert_e862230652442 : check e862230652442 [] .sourceHead = true := by decide
def e862315436910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e862315436910 : Closed e862315436910 ∧ code e862315436910 = 9658408459118 := by decide
theorem cert_e862315436910 : check e862315436910 [] .sourceHead = true := by decide
def e862315436918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e862315436918 : Closed e862315436918 ∧ code e862315436918 = 9658408459126 := by decide
theorem cert_e862315436918 : check e862315436918 [] .sourceHead = true := by decide
def e862315436982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e862315436982 : Closed e862315436982 ∧ code e862315436982 = 9658408459190 := by decide
theorem cert_e862315436982 : check e862315436982 [] .sourceHead = true := by decide
def e862315437422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e862315437422 : Closed e862315437422 ∧ code e862315437422 = 9658408459630 := by decide
theorem cert_e862315437422 : check e862315437422 [] .sourceHead = true := by decide
def e862315437430 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e862315437430 : Closed e862315437430 ∧ code e862315437430 = 9658408459638 := by decide
theorem cert_e862315437430 : check e862315437430 [] .sourceHead = true := by decide
def e862315437486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e862315437486 : Closed e862315437486 ∧ code e862315437486 = 9658408459694 := by decide
theorem cert_e862315437486 : check e862315437486 [] .sourceHead = true := by decide
def e862315437498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e862315437498 : Closed e862315437498 ∧ code e862315437498 = 9658408459706 := by decide
theorem cert_e862315437498 : check e862315437498 [] .sourceHead = true := by decide
def e862315437526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e862315437526 : Closed e862315437526 ∧ code e862315437526 = 9658408459734 := by decide
theorem cert_e862315437526 : check e862315437526 [] .sourceHead = true := by decide
def e862315437530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e862315437530 : Closed e862315437530 ∧ code e862315437530 = 9658408459738 := by decide
theorem cert_e862315437530 : check e862315437530 [] .sourceHead = true := by decide
def e862315437750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e862315437750 : Closed e862315437750 ∧ code e862315437750 = 9658408459958 := by decide
theorem cert_e862315437750 : check e862315437750 [] .sourceHead = true := by decide
def e862315437782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e862315437782 : Closed e862315437782 ∧ code e862315437782 = 9658408459990 := by decide
theorem cert_e862315437782 : check e862315437782 [] .sourceHead = true := by decide
def e862315437786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e862315437786 : Closed e862315437786 ∧ code e862315437786 = 9658408459994 := by decide
theorem cert_e862315437786 : check e862315437786 [] .sourceHead = true := by decide
def e862315439982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e862315439982 : Closed e862315439982 ∧ code e862315439982 = 9658408462190 := by decide
theorem cert_e862315439982 : check e862315439982 [] .sourceHead = true := by decide
def e862315439990 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e862315439990 : Closed e862315439990 ∧ code e862315439990 = 9658408462198 := by decide
theorem cert_e862315439990 : check e862315439990 [] .sourceHead = true := by decide
def e862315440054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e862315440054 : Closed e862315440054 ∧ code e862315440054 = 9658408462262 := by decide
theorem cert_e862315440054 : check e862315440054 [] .sourceHead = true := by decide
def e862315441390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e862315441390 : Closed e862315441390 ∧ code e862315441390 = 9658408463598 := by decide
theorem cert_e862315441390 : check e862315441390 [] .sourceHead = true := by decide
def e862315441398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e862315441398 : Closed e862315441398 ∧ code e862315441398 = 9658408463606 := by decide
theorem cert_e862315441398 : check e862315441398 [] .sourceHead = true := by decide
def e862315441782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e862315441782 : Closed e862315441782 ∧ code e862315441782 = 9658408463990 := by decide
theorem cert_e862315441782 : check e862315441782 [] .sourceHead = true := by decide
def e862315443054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e862315443054 : Closed e862315443054 ∧ code e862315443054 = 9658408465262 := by decide
theorem cert_e862315443054 : check e862315443054 [] .sourceHead = true := by decide
def e862315443062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e862315443062 : Closed e862315443062 ∧ code e862315443062 = 9658408465270 := by decide
theorem cert_e862315443062 : check e862315443062 [] .sourceHead = true := by decide
def e862315443118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e862315443118 : Closed e862315443118 ∧ code e862315443118 = 9658408465326 := by decide
theorem cert_e862315443118 : check e862315443118 [] .sourceHead = true := by decide
def e862315443130 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e862315443130 : Closed e862315443130 ∧ code e862315443130 = 9658408465338 := by decide
theorem cert_e862315443130 : check e862315443130 [] .sourceHead = true := by decide
def e862315443158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e862315443158 : Closed e862315443158 ∧ code e862315443158 = 9658408465366 := by decide
theorem cert_e862315443158 : check e862315443158 [] .sourceHead = true := by decide
def e862315443162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e862315443162 : Closed e862315443162 ∧ code e862315443162 = 9658408465370 := by decide
theorem cert_e862315443162 : check e862315443162 [] .sourceHead = true := by decide
def e862315443438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e862315443438 : Closed e862315443438 ∧ code e862315443438 = 9658408465646 := by decide
theorem cert_e862315443438 : check e862315443438 [] .sourceHead = true := by decide
def e862315443446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e862315443446 : Closed e862315443446 ∧ code e862315443446 = 9658408465654 := by decide
theorem cert_e862315443446 : check e862315443446 [] .sourceHead = true := by decide
def e862315443822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862315443822 : Closed e862315443822 ∧ code e862315443822 = 9658408466030 := by decide
theorem cert_e862315443822 : check e862315443822 [] .sourceHead = true := by decide
def e862315443834 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862315443834 : Closed e862315443834 ∧ code e862315443834 = 9658408466042 := by decide
theorem cert_e862315443834 : check e862315443834 [] .sourceHead = true := by decide
def e862315444022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862315444022 : Closed e862315444022 ∧ code e862315444022 = 9658408466230 := by decide
theorem cert_e862315444022 : check e862315444022 [] .sourceHead = true := by decide
def e862315444026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862315444026 : Closed e862315444026 ∧ code e862315444026 = 9658408466234 := by decide
theorem cert_e862315444026 : check e862315444026 [] .sourceHead = true := by decide
def e862315444662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e862315444662 : Closed e862315444662 ∧ code e862315444662 = 9658408466870 := by decide
theorem cert_e862315444662 : check e862315444662 [] .sourceHead = true := by decide
def e862315444694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e862315444694 : Closed e862315444694 ∧ code e862315444694 = 9658408466902 := by decide
theorem cert_e862315444694 : check e862315444694 [] .sourceHead = true := by decide
def e862315444698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e862315444698 : Closed e862315444698 ∧ code e862315444698 = 9658408466906 := by decide
theorem cert_e862315444698 : check e862315444698 [] .sourceHead = true := by decide
def e862315444854 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e862315444854 : Closed e862315444854 ∧ code e862315444854 = 9658408467062 := by decide
theorem cert_e862315444854 : check e862315444854 [] .sourceHead = true := by decide
def e862315445046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862315445046 : Closed e862315445046 ∧ code e862315445046 = 9658408467254 := by decide
theorem cert_e862315445046 : check e862315445046 [] .sourceHead = true := by decide
def e862315445050 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862315445050 : Closed e862315445050 ∧ code e862315445050 = 9658408467258 := by decide
theorem cert_e862315445050 : check e862315445050 [] .sourceHead = true := by decide
def e862315452270 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e862315452270 : Closed e862315452270 ∧ code e862315452270 = 9658408474478 := by decide
theorem cert_e862315452270 : check e862315452270 [] .sourceHead = true := by decide
def e862315452278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e862315452278 : Closed e862315452278 ∧ code e862315452278 = 9658408474486 := by decide
theorem cert_e862315452278 : check e862315452278 [] .sourceHead = true := by decide
def e862315452342 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e862315452342 : Closed e862315452342 ∧ code e862315452342 = 9658408474550 := by decide
theorem cert_e862315452342 : check e862315452342 [] .sourceHead = true := by decide
def e862315453678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e862315453678 : Closed e862315453678 ∧ code e862315453678 = 9658408475886 := by decide
theorem cert_e862315453678 : check e862315453678 [] .sourceHead = true := by decide
end Blc.Floor43
