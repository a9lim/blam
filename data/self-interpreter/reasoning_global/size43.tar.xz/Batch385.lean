import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364894138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422364894138 : Closed e2422364894138 ∧ code e2422364894138 = 11218457916346 := by decide
theorem cert_e2422364894138 : check e2422364894138 [[],[]] .smaller = true := by decide
def e2422364894166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422364894166 : Closed e2422364894166 ∧ code e2422364894166 = 11218457916374 := by decide
theorem cert_e2422364894166 : check e2422364894166 [[],[]] .smaller = true := by decide
def e2422364894170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422364894170 : Closed e2422364894170 ∧ code e2422364894170 = 11218457916378 := by decide
theorem cert_e2422364894170 : check e2422364894170 [[],[]] .smaller = true := by decide
def e2422364894186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e2422364894186 : Closed e2422364894186 ∧ code e2422364894186 = 11218457916394 := by decide
theorem cert_e2422364894186 : check e2422364894186 [[],[]] .smaller = true := by decide
def e2422364894238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422364894238 : Closed e2422364894238 ∧ code e2422364894238 = 11218457916446 := by decide
theorem cert_e2422364894238 : check e2422364894238 [[],[]] .smaller = true := by decide
def e2422364894334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 5))))))))))
theorem wire_e2422364894334 : Closed e2422364894334 ∧ code e2422364894334 = 11218457916542 := by decide
theorem cert_e2422364894334 : check e2422364894334 [[],[]] .three = true := by decide
def e2422364894430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364894430 : Closed e2422364894430 ∧ code e2422364894430 = 11218457916638 := by decide
theorem cert_e2422364894430 : check e2422364894430 [[],[]] .smaller = true := by decide
def e2422364894434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422364894434 : Closed e2422364894434 ∧ code e2422364894434 = 11218457916642 := by decide
theorem cert_e2422364894434 : check e2422364894434 [[],[]] .smaller = true := by decide
def e2422364894446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364894446 : Closed e2422364894446 ∧ code e2422364894446 = 11218457916654 := by decide
theorem cert_e2422364894446 : check e2422364894446 [[],[]] .smaller = true := by decide
def e2422364894454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364894454 : Closed e2422364894454 ∧ code e2422364894454 = 11218457916662 := by decide
theorem cert_e2422364894454 : check e2422364894454 [[],[]] .smaller = true := by decide
def e2422364894458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364894458 : Closed e2422364894458 ∧ code e2422364894458 = 11218457916666 := by decide
theorem cert_e2422364894458 : check e2422364894458 [[],[]] .smaller = true := by decide
def e2422364894734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364894734 : Closed e2422364894734 ∧ code e2422364894734 = 11218457916942 := by decide
theorem cert_e2422364894734 : check e2422364894734 [[],[]] .smaller = true := by decide
def e2422364894746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364894746 : Closed e2422364894746 ∧ code e2422364894746 = 11218457916954 := by decide
theorem cert_e2422364894746 : check e2422364894746 [[],[]] .smaller = true := by decide
def e2422364894818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364894818 : Closed e2422364894818 ∧ code e2422364894818 = 11218457917026 := by decide
theorem cert_e2422364894818 : check e2422364894818 [[],[]] .smaller = true := by decide
def e2422364894830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364894830 : Closed e2422364894830 ∧ code e2422364894830 = 11218457917038 := by decide
theorem cert_e2422364894830 : check e2422364894830 [[],[]] .smaller = true := by decide
def e2422364894838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364894838 : Closed e2422364894838 ∧ code e2422364894838 = 11218457917046 := by decide
theorem cert_e2422364894838 : check e2422364894838 [[],[]] .smaller = true := by decide
def e2422364894842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364894842 : Closed e2422364894842 ∧ code e2422364894842 = 11218457917050 := by decide
theorem cert_e2422364894842 : check e2422364894842 [[],[]] .smaller = true := by decide
def e2422364895030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364895030 : Closed e2422364895030 ∧ code e2422364895030 = 11218457917238 := by decide
theorem cert_e2422364895030 : check e2422364895030 [[],[]] .smaller = true := by decide
def e2422364895034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364895034 : Closed e2422364895034 ∧ code e2422364895034 = 11218457917242 := by decide
theorem cert_e2422364895034 : check e2422364895034 [[],[]] .smaller = true := by decide
def e2422364895130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364895130 : Closed e2422364895130 ∧ code e2422364895130 = 11218457917338 := by decide
theorem cert_e2422364895130 : check e2422364895130 [[],[]] .smaller = true := by decide
def e2422364895174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 4)) (.lam (.var 1))))))))))
theorem wire_e2422364895174 : Closed e2422364895174 ∧ code e2422364895174 = 11218457917382 := by decide
theorem cert_e2422364895174 : check e2422364895174 [[],[]] .three = true := by decide
def e2422364895662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422364895662 : Closed e2422364895662 ∧ code e2422364895662 = 11218457917870 := by decide
theorem cert_e2422364895662 : check e2422364895662 [[],[]] .smaller = true := by decide
def e2422364895670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2422364895670 : Closed e2422364895670 ∧ code e2422364895670 = 11218457917878 := by decide
theorem cert_e2422364895670 : check e2422364895670 [[],[]] .smaller = true := by decide
def e2422364895674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422364895674 : Closed e2422364895674 ∧ code e2422364895674 = 11218457917882 := by decide
theorem cert_e2422364895674 : check e2422364895674 [[],[]] .smaller = true := by decide
def e2422364895702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2422364895702 : Closed e2422364895702 ∧ code e2422364895702 = 11218457917910 := by decide
theorem cert_e2422364895702 : check e2422364895702 [[],[]] .smaller = true := by decide
def e2422364895706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2422364895706 : Closed e2422364895706 ∧ code e2422364895706 = 11218457917914 := by decide
theorem cert_e2422364895706 : check e2422364895706 [[],[]] .smaller = true := by decide
def e2422364895722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422364895722 : Closed e2422364895722 ∧ code e2422364895722 = 11218457917930 := by decide
theorem cert_e2422364895722 : check e2422364895722 [[],[]] .smaller = true := by decide
def e2422364895854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364895854 : Closed e2422364895854 ∧ code e2422364895854 = 11218457918062 := by decide
theorem cert_e2422364895854 : check e2422364895854 [[],[]] .smaller = true := by decide
def e2422364895862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364895862 : Closed e2422364895862 ∧ code e2422364895862 = 11218457918070 := by decide
theorem cert_e2422364895862 : check e2422364895862 [[],[]] .smaller = true := by decide
def e2422364895866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364895866 : Closed e2422364895866 ∧ code e2422364895866 = 11218457918074 := by decide
theorem cert_e2422364895866 : check e2422364895866 [[],[]] .smaller = true := by decide
def e2422364896054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364896054 : Closed e2422364896054 ∧ code e2422364896054 = 11218457918262 := by decide
theorem cert_e2422364896054 : check e2422364896054 [[],[]] .smaller = true := by decide
def e2422364896058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364896058 : Closed e2422364896058 ∧ code e2422364896058 = 11218457918266 := by decide
theorem cert_e2422364896058 : check e2422364896058 [[],[]] .smaller = true := by decide
def e2422364896154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364896154 : Closed e2422364896154 ∧ code e2422364896154 = 11218457918362 := by decide
theorem cert_e2422364896154 : check e2422364896154 [[],[]] .smaller = true := by decide
def e2422364896366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2422364896366 : Closed e2422364896366 ∧ code e2422364896366 = 11218457918574 := by decide
theorem cert_e2422364896366 : check e2422364896366 [[],[]] .three = true := by decide
def e2422364896374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422364896374 : Closed e2422364896374 ∧ code e2422364896374 = 11218457918582 := by decide
theorem cert_e2422364896374 : check e2422364896374 [[],[]] .three = true := by decide
def e2422364896378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2422364896378 : Closed e2422364896378 ∧ code e2422364896378 = 11218457918586 := by decide
theorem cert_e2422364896378 : check e2422364896378 [[],[]] .three = true := by decide
def e2422364896470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422364896470 : Closed e2422364896470 ∧ code e2422364896470 = 11218457918678 := by decide
theorem cert_e2422364896470 : check e2422364896470 [[],[]] .three = true := by decide
def e2422364896474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422364896474 : Closed e2422364896474 ∧ code e2422364896474 = 11218457918682 := by decide
theorem cert_e2422364896474 : check e2422364896474 [[],[]] .three = true := by decide
def e2422364896490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422364896490 : Closed e2422364896490 ∧ code e2422364896490 = 11218457918698 := by decide
theorem cert_e2422364896490 : check e2422364896490 [[],[]] .three = true := by decide
def e2422364896542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2422364896542 : Closed e2422364896542 ∧ code e2422364896542 = 11218457918750 := by decide
theorem cert_e2422364896542 : check e2422364896542 [[],[]] .three = true := by decide
def e2422364896566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364896566 : Closed e2422364896566 ∧ code e2422364896566 = 11218457918774 := by decide
theorem cert_e2422364896566 : check e2422364896566 [[],[]] .three = true := by decide
def e2422364896570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364896570 : Closed e2422364896570 ∧ code e2422364896570 = 11218457918778 := by decide
theorem cert_e2422364896570 : check e2422364896570 [[],[]] .three = true := by decide
def e2422364896654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422364896654 : Closed e2422364896654 ∧ code e2422364896654 = 11218457918862 := by decide
theorem cert_e2422364896654 : check e2422364896654 [[],[]] .three = true := by decide
def e2422364896666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364896666 : Closed e2422364896666 ∧ code e2422364896666 = 11218457918874 := by decide
theorem cert_e2422364896666 : check e2422364896666 [[],[]] .three = true := by decide
def e2422364896702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 4)))))))))
theorem wire_e2422364896702 : Closed e2422364896702 ∧ code e2422364896702 = 11218457918910 := by decide
theorem cert_e2422364896702 : check e2422364896702 [[],[]] .three = true := by decide
def e2422364896710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2422364896710 : Closed e2422364896710 ∧ code e2422364896710 = 11218457918918 := by decide
theorem cert_e2422364896710 : check e2422364896710 [[],[]] .three = true := by decide
def e2422364896758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 4)) (.var 1)))))))))
theorem wire_e2422364896758 : Closed e2422364896758 ∧ code e2422364896758 = 11218457918966 := by decide
theorem cert_e2422364896758 : check e2422364896758 [[],[]] .three = true := by decide
def e2422364900206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e2422364900206 : Closed e2422364900206 ∧ code e2422364900206 = 11218457922414 := by decide
theorem cert_e2422364900206 : check e2422364900206 [[],[]] .smaller = true := by decide
def e2422364900214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e2422364900214 : Closed e2422364900214 ∧ code e2422364900214 = 11218457922422 := by decide
theorem cert_e2422364900214 : check e2422364900214 [[],[]] .smaller = true := by decide
def e2422364900270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e2422364900270 : Closed e2422364900270 ∧ code e2422364900270 = 11218457922478 := by decide
theorem cert_e2422364900270 : check e2422364900270 [[],[]] .smaller = true := by decide
def e2422364900282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e2422364900282 : Closed e2422364900282 ∧ code e2422364900282 = 11218457922490 := by decide
theorem cert_e2422364900282 : check e2422364900282 [[],[]] .smaller = true := by decide
def e2422364900310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e2422364900310 : Closed e2422364900310 ∧ code e2422364900310 = 11218457922518 := by decide
theorem cert_e2422364900310 : check e2422364900310 [[],[]] .smaller = true := by decide
def e2422364900314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e2422364900314 : Closed e2422364900314 ∧ code e2422364900314 = 11218457922522 := by decide
theorem cert_e2422364900314 : check e2422364900314 [[],[]] .smaller = true := by decide
def e2422364900590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422364900590 : Closed e2422364900590 ∧ code e2422364900590 = 11218457922798 := by decide
theorem cert_e2422364900590 : check e2422364900590 [[],[]] .smaller = true := by decide
def e2422364900598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422364900598 : Closed e2422364900598 ∧ code e2422364900598 = 11218457922806 := by decide
theorem cert_e2422364900598 : check e2422364900598 [[],[]] .smaller = true := by decide
def e2422364900974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422364900974 : Closed e2422364900974 ∧ code e2422364900974 = 11218457923182 := by decide
theorem cert_e2422364900974 : check e2422364900974 [[],[]] .smaller = true := by decide
def e2422364900986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422364900986 : Closed e2422364900986 ∧ code e2422364900986 = 11218457923194 := by decide
theorem cert_e2422364900986 : check e2422364900986 [[],[]] .smaller = true := by decide
def e2422364901174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422364901174 : Closed e2422364901174 ∧ code e2422364901174 = 11218457923382 := by decide
theorem cert_e2422364901174 : check e2422364901174 [[],[]] .smaller = true := by decide
def e2422364901178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422364901178 : Closed e2422364901178 ∧ code e2422364901178 = 11218457923386 := by decide
theorem cert_e2422364901178 : check e2422364901178 [[],[]] .smaller = true := by decide
def e2422364901246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 5)))))))))))
theorem wire_e2422364901246 : Closed e2422364901246 ∧ code e2422364901246 = 11218457923454 := by decide
theorem cert_e2422364901246 : check e2422364901246 [[],[]] .three = true := by decide
def e2422364901310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 4)))))))))))
theorem wire_e2422364901310 : Closed e2422364901310 ∧ code e2422364901310 = 11218457923518 := by decide
theorem cert_e2422364901310 : check e2422364901310 [[],[]] .smaller = true := by decide
def e2422364901342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.var 3)))))))))))
theorem wire_e2422364901342 : Closed e2422364901342 ∧ code e2422364901342 = 11218457923550 := by decide
theorem cert_e2422364901342 : check e2422364901342 [[],[]] .smaller = true := by decide
def e2422364901358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 5) (.var 2)))))))))))
theorem wire_e2422364901358 : Closed e2422364901358 ∧ code e2422364901358 = 11218457923566 := by decide
theorem cert_e2422364901358 : check e2422364901358 [[],[]] .three = true := by decide
def e2422364908990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e2422364908990 : Closed e2422364908990 ∧ code e2422364908990 = 11218457931198 := by decide
theorem cert_e2422364908990 : check e2422364908990 [[],[]] .three = true := by decide
def e2422364909022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e2422364909022 : Closed e2422364909022 ∧ code e2422364909022 = 11218457931230 := by decide
theorem cert_e2422364909022 : check e2422364909022 [[],[]] .smaller = true := by decide
def e2422364909038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e2422364909038 : Closed e2422364909038 ∧ code e2422364909038 = 11218457931246 := by decide
theorem cert_e2422364909038 : check e2422364909038 [[],[]] .smaller = true := by decide
def e2422364909046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e2422364909046 : Closed e2422364909046 ∧ code e2422364909046 = 11218457931254 := by decide
theorem cert_e2422364909046 : check e2422364909046 [[],[]] .three = true := by decide
def e2422364909102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))))
theorem wire_e2422364909102 : Closed e2422364909102 ∧ code e2422364909102 = 11218457931310 := by decide
theorem cert_e2422364909102 : check e2422364909102 [[],[]] .smaller = true := by decide
def e2422364909246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e2422364909246 : Closed e2422364909246 ∧ code e2422364909246 = 11218457931454 := by decide
theorem cert_e2422364909246 : check e2422364909246 [[],[]] .three = true := by decide
def e2422364909278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e2422364909278 : Closed e2422364909278 ∧ code e2422364909278 = 11218457931486 := by decide
theorem cert_e2422364909278 : check e2422364909278 [[],[]] .smaller = true := by decide
def e2422364909282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))))
theorem wire_e2422364909282 : Closed e2422364909282 ∧ code e2422364909282 = 11218457931490 := by decide
theorem cert_e2422364909282 : check e2422364909282 [[],[]] .smaller = true := by decide
def e2422364909294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))))
theorem wire_e2422364909294 : Closed e2422364909294 ∧ code e2422364909294 = 11218457931502 := by decide
theorem cert_e2422364909294 : check e2422364909294 [[],[]] .smaller = true := by decide
def e2422364909302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e2422364909302 : Closed e2422364909302 ∧ code e2422364909302 = 11218457931510 := by decide
theorem cert_e2422364909302 : check e2422364909302 [[],[]] .smaller = true := by decide
def e2422364909306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e2422364909306 : Closed e2422364909306 ∧ code e2422364909306 = 11218457931514 := by decide
theorem cert_e2422364909306 : check e2422364909306 [[],[]] .three = true := by decide
def e2422364909334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))))
theorem wire_e2422364909334 : Closed e2422364909334 ∧ code e2422364909334 = 11218457931542 := by decide
theorem cert_e2422364909334 : check e2422364909334 [[],[]] .smaller = true := by decide
def e2422364909406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e2422364909406 : Closed e2422364909406 ∧ code e2422364909406 = 11218457931614 := by decide
theorem cert_e2422364909406 : check e2422364909406 [[],[]] .smaller = true := by decide
def e2422364909410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))))
theorem wire_e2422364909410 : Closed e2422364909410 ∧ code e2422364909410 = 11218457931618 := by decide
theorem cert_e2422364909410 : check e2422364909410 [[],[]] .smaller = true := by decide
def e2422364909422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))))
theorem wire_e2422364909422 : Closed e2422364909422 ∧ code e2422364909422 = 11218457931630 := by decide
theorem cert_e2422364909422 : check e2422364909422 [[],[]] .smaller = true := by decide
def e2422364909430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))))
theorem wire_e2422364909430 : Closed e2422364909430 ∧ code e2422364909430 = 11218457931638 := by decide
theorem cert_e2422364909430 : check e2422364909430 [[],[]] .smaller = true := by decide
def e2422364909434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e2422364909434 : Closed e2422364909434 ∧ code e2422364909434 = 11218457931642 := by decide
theorem cert_e2422364909434 : check e2422364909434 [[],[]] .smaller = true := by decide
def e2422364909486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e2422364909486 : Closed e2422364909486 ∧ code e2422364909486 = 11218457931694 := by decide
theorem cert_e2422364909486 : check e2422364909486 [[],[]] .smaller = true := by decide
def e2422364909494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e2422364909494 : Closed e2422364909494 ∧ code e2422364909494 = 11218457931702 := by decide
theorem cert_e2422364909494 : check e2422364909494 [[],[]] .smaller = true := by decide
def e2422364909498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e2422364909498 : Closed e2422364909498 ∧ code e2422364909498 = 11218457931706 := by decide
theorem cert_e2422364909498 : check e2422364909498 [[],[]] .smaller = true := by decide
def e2422364909526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e2422364909526 : Closed e2422364909526 ∧ code e2422364909526 = 11218457931734 := by decide
theorem cert_e2422364909526 : check e2422364909526 [[],[]] .three = true := by decide
def e2422364909530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e2422364909530 : Closed e2422364909530 ∧ code e2422364909530 = 11218457931738 := by decide
theorem cert_e2422364909530 : check e2422364909530 [[],[]] .three = true := by decide
def e2422364910526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422364910526 : Closed e2422364910526 ∧ code e2422364910526 = 11218457932734 := by decide
theorem cert_e2422364910526 : check e2422364910526 [[],[]] .three = true := by decide
def e2422364910558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422364910558 : Closed e2422364910558 ∧ code e2422364910558 = 11218457932766 := by decide
theorem cert_e2422364910558 : check e2422364910558 [[],[]] .smaller = true := by decide
def e2422364910574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422364910574 : Closed e2422364910574 ∧ code e2422364910574 = 11218457932782 := by decide
theorem cert_e2422364910574 : check e2422364910574 [[],[]] .smaller = true := by decide
def e2422364910582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422364910582 : Closed e2422364910582 ∧ code e2422364910582 = 11218457932790 := by decide
theorem cert_e2422364910582 : check e2422364910582 [[],[]] .three = true := by decide
def e2422364911678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))))
theorem wire_e2422364911678 : Closed e2422364911678 ∧ code e2422364911678 = 11218457933886 := by decide
theorem cert_e2422364911678 : check e2422364911678 [[],[]] .smaller = true := by decide
def e2422364912062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422364912062 : Closed e2422364912062 ∧ code e2422364912062 = 11218457934270 := by decide
theorem cert_e2422364912062 : check e2422364912062 [[],[]] .three = true := by decide
def e2422364912094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422364912094 : Closed e2422364912094 ∧ code e2422364912094 = 11218457934302 := by decide
theorem cert_e2422364912094 : check e2422364912094 [[],[]] .smaller = true := by decide
def e2422364912098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))))
theorem wire_e2422364912098 : Closed e2422364912098 ∧ code e2422364912098 = 11218457934306 := by decide
theorem cert_e2422364912098 : check e2422364912098 [[],[]] .smaller = true := by decide
def e2422364912110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422364912110 : Closed e2422364912110 ∧ code e2422364912110 = 11218457934318 := by decide
theorem cert_e2422364912110 : check e2422364912110 [[],[]] .smaller = true := by decide
def e2422364912118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422364912118 : Closed e2422364912118 ∧ code e2422364912118 = 11218457934326 := by decide
theorem cert_e2422364912118 : check e2422364912118 [[],[]] .smaller = true := by decide
def e2422364912122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422364912122 : Closed e2422364912122 ∧ code e2422364912122 = 11218457934330 := by decide
theorem cert_e2422364912122 : check e2422364912122 [[],[]] .three = true := by decide
def e2422364912670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))))
theorem wire_e2422364912670 : Closed e2422364912670 ∧ code e2422364912670 = 11218457934878 := by decide
theorem cert_e2422364912670 : check e2422364912670 [[],[]] .smaller = true := by decide
def e2422364912766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 5)))))))))))
theorem wire_e2422364912766 : Closed e2422364912766 ∧ code e2422364912766 = 11218457934974 := by decide
theorem cert_e2422364912766 : check e2422364912766 [[],[]] .three = true := by decide
def e2422364912862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422364912862 : Closed e2422364912862 ∧ code e2422364912862 = 11218457935070 := by decide
theorem cert_e2422364912862 : check e2422364912862 [[],[]] .smaller = true := by decide
def e2422364912866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))))
theorem wire_e2422364912866 : Closed e2422364912866 ∧ code e2422364912866 = 11218457935074 := by decide
theorem cert_e2422364912866 : check e2422364912866 [[],[]] .smaller = true := by decide
def e2422364912878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422364912878 : Closed e2422364912878 ∧ code e2422364912878 = 11218457935086 := by decide
theorem cert_e2422364912878 : check e2422364912878 [[],[]] .smaller = true := by decide
def e2422364912886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422364912886 : Closed e2422364912886 ∧ code e2422364912886 = 11218457935094 := by decide
theorem cert_e2422364912886 : check e2422364912886 [[],[]] .smaller = true := by decide
def e2422364912890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422364912890 : Closed e2422364912890 ∧ code e2422364912890 = 11218457935098 := by decide
theorem cert_e2422364912890 : check e2422364912890 [[],[]] .smaller = true := by decide
def e2422364913262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422364913262 : Closed e2422364913262 ∧ code e2422364913262 = 11218457935470 := by decide
theorem cert_e2422364913262 : check e2422364913262 [[],[]] .smaller = true := by decide
def e2422364913270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422364913270 : Closed e2422364913270 ∧ code e2422364913270 = 11218457935478 := by decide
theorem cert_e2422364913270 : check e2422364913270 [[],[]] .smaller = true := by decide
def e2422364913274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422364913274 : Closed e2422364913274 ∧ code e2422364913274 = 11218457935482 := by decide
theorem cert_e2422364913274 : check e2422364913274 [[],[]] .smaller = true := by decide
def e2422364913438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.lam (.var 3)))))))))))
theorem wire_e2422364913438 : Closed e2422364913438 ∧ code e2422364913438 = 11218457935646 := by decide
theorem cert_e2422364913438 : check e2422364913438 [[],[]] .three = true := by decide
def e2422364913462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364913462 : Closed e2422364913462 ∧ code e2422364913462 = 11218457935670 := by decide
theorem cert_e2422364913462 : check e2422364913462 [[],[]] .three = true := by decide
def e2422364913466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364913466 : Closed e2422364913466 ∧ code e2422364913466 = 11218457935674 := by decide
theorem cert_e2422364913466 : check e2422364913466 [[],[]] .three = true := by decide
def e2422364931966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 5)))))))))))
theorem wire_e2422364931966 : Closed e2422364931966 ∧ code e2422364931966 = 11218457954174 := by decide
theorem cert_e2422364931966 : check e2422364931966 [[],[]] .three = true := by decide
def e2422364932030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 4)))))))))))
theorem wire_e2422364932030 : Closed e2422364932030 ∧ code e2422364932030 = 11218457954238 := by decide
theorem cert_e2422364932030 : check e2422364932030 [[],[]] .smaller = true := by decide
def e2422364932062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3)))))))))))
theorem wire_e2422364932062 : Closed e2422364932062 ∧ code e2422364932062 = 11218457954270 := by decide
theorem cert_e2422364932062 : check e2422364932062 [[],[]] .smaller = true := by decide
def e2422364932078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 2)))))))))))
theorem wire_e2422364932078 : Closed e2422364932078 ∧ code e2422364932078 = 11218457954286 := by decide
theorem cert_e2422364932078 : check e2422364932078 [[],[]] .smaller = true := by decide
def e2422364932086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 5) (.var 1)))))))))))
theorem wire_e2422364932086 : Closed e2422364932086 ∧ code e2422364932086 = 11218457954294 := by decide
theorem cert_e2422364932086 : check e2422364932086 [[],[]] .three = true := by decide
def e2422364935726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))))
theorem wire_e2422364935726 : Closed e2422364935726 ∧ code e2422364935726 = 11218457957934 := by decide
theorem cert_e2422364935726 : check e2422364935726 [[],[]] .smaller = true := by decide
def e2422364935870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e2422364935870 : Closed e2422364935870 ∧ code e2422364935870 = 11218457958078 := by decide
theorem cert_e2422364935870 : check e2422364935870 [[],[]] .three = true := by decide
def e2422364935902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2422364935902 : Closed e2422364935902 ∧ code e2422364935902 = 11218457958110 := by decide
theorem cert_e2422364935902 : check e2422364935902 [[],[]] .smaller = true := by decide
def e2422364935906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))))
theorem wire_e2422364935906 : Closed e2422364935906 ∧ code e2422364935906 = 11218457958114 := by decide
theorem cert_e2422364935906 : check e2422364935906 [[],[]] .smaller = true := by decide
def e2422364935918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e2422364935918 : Closed e2422364935918 ∧ code e2422364935918 = 11218457958126 := by decide
theorem cert_e2422364935918 : check e2422364935918 [[],[]] .smaller = true := by decide
def e2422364935926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2422364935926 : Closed e2422364935926 ∧ code e2422364935926 = 11218457958134 := by decide
theorem cert_e2422364935926 : check e2422364935926 [[],[]] .smaller = true := by decide
def e2422364935930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e2422364935930 : Closed e2422364935930 ∧ code e2422364935930 = 11218457958138 := by decide
theorem cert_e2422364935930 : check e2422364935930 [[],[]] .three = true := by decide
def e2422364936030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2422364936030 : Closed e2422364936030 ∧ code e2422364936030 = 11218457958238 := by decide
theorem cert_e2422364936030 : check e2422364936030 [[],[]] .smaller = true := by decide
def e2422364936046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e2422364936046 : Closed e2422364936046 ∧ code e2422364936046 = 11218457958254 := by decide
theorem cert_e2422364936046 : check e2422364936046 [[],[]] .smaller = true := by decide
def e2422364936054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e2422364936054 : Closed e2422364936054 ∧ code e2422364936054 = 11218457958262 := by decide
theorem cert_e2422364936054 : check e2422364936054 [[],[]] .smaller = true := by decide
def e2422364936058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2422364936058 : Closed e2422364936058 ∧ code e2422364936058 = 11218457958266 := by decide
theorem cert_e2422364936058 : check e2422364936058 [[],[]] .smaller = true := by decide
def e2422364936074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422364936074 : Closed e2422364936074 ∧ code e2422364936074 = 11218457958282 := by decide
theorem cert_e2422364936074 : check e2422364936074 [[],[]] .smaller = true := by decide
def e2422364936098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422364936098 : Closed e2422364936098 ∧ code e2422364936098 = 11218457958306 := by decide
theorem cert_e2422364936098 : check e2422364936098 [[],[]] .smaller = true := by decide
def e2422364936110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e2422364936110 : Closed e2422364936110 ∧ code e2422364936110 = 11218457958318 := by decide
theorem cert_e2422364936110 : check e2422364936110 [[],[]] .smaller = true := by decide
def e2422364936118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e2422364936118 : Closed e2422364936118 ∧ code e2422364936118 = 11218457958326 := by decide
theorem cert_e2422364936118 : check e2422364936118 [[],[]] .smaller = true := by decide
def e2422364936122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e2422364936122 : Closed e2422364936122 ∧ code e2422364936122 = 11218457958330 := by decide
theorem cert_e2422364936122 : check e2422364936122 [[],[]] .smaller = true := by decide
def e2422364936150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2422364936150 : Closed e2422364936150 ∧ code e2422364936150 = 11218457958358 := by decide
theorem cert_e2422364936150 : check e2422364936150 [[],[]] .smaller = true := by decide
def e2422364936154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2422364936154 : Closed e2422364936154 ∧ code e2422364936154 = 11218457958362 := by decide
theorem cert_e2422364936154 : check e2422364936154 [[],[]] .smaller = true := by decide
def e2422364936170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e2422364936170 : Closed e2422364936170 ∧ code e2422364936170 = 11218457958378 := by decide
theorem cert_e2422364936170 : check e2422364936170 [[],[]] .three = true := by decide
def e2422364936254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))))
theorem wire_e2422364936254 : Closed e2422364936254 ∧ code e2422364936254 = 11218457958462 := by decide
theorem cert_e2422364936254 : check e2422364936254 [[],[]] .smaller = true := by decide
def e2422364936638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422364936638 : Closed e2422364936638 ∧ code e2422364936638 = 11218457958846 := by decide
theorem cert_e2422364936638 : check e2422364936638 [[],[]] .three = true := by decide
def e2422364936670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422364936670 : Closed e2422364936670 ∧ code e2422364936670 = 11218457958878 := by decide
theorem cert_e2422364936670 : check e2422364936670 [[],[]] .smaller = true := by decide
def e2422364936674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))))
theorem wire_e2422364936674 : Closed e2422364936674 ∧ code e2422364936674 = 11218457958882 := by decide
theorem cert_e2422364936674 : check e2422364936674 [[],[]] .smaller = true := by decide
def e2422364936686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422364936686 : Closed e2422364936686 ∧ code e2422364936686 = 11218457958894 := by decide
theorem cert_e2422364936686 : check e2422364936686 [[],[]] .smaller = true := by decide
def e2422364936694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422364936694 : Closed e2422364936694 ∧ code e2422364936694 = 11218457958902 := by decide
theorem cert_e2422364936694 : check e2422364936694 [[],[]] .smaller = true := by decide
def e2422364936698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422364936698 : Closed e2422364936698 ∧ code e2422364936698 = 11218457958906 := by decide
theorem cert_e2422364936698 : check e2422364936698 [[],[]] .three = true := by decide
def e2422364937342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 5)))))))))))
theorem wire_e2422364937342 : Closed e2422364937342 ∧ code e2422364937342 = 11218457959550 := by decide
theorem cert_e2422364937342 : check e2422364937342 [[],[]] .three = true := by decide
def e2422364937438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422364937438 : Closed e2422364937438 ∧ code e2422364937438 = 11218457959646 := by decide
theorem cert_e2422364937438 : check e2422364937438 [[],[]] .smaller = true := by decide
def e2422364937454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422364937454 : Closed e2422364937454 ∧ code e2422364937454 = 11218457959662 := by decide
theorem cert_e2422364937454 : check e2422364937454 [[],[]] .smaller = true := by decide
def e2422364937462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422364937462 : Closed e2422364937462 ∧ code e2422364937462 = 11218457959670 := by decide
theorem cert_e2422364937462 : check e2422364937462 [[],[]] .smaller = true := by decide
def e2422364937466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422364937466 : Closed e2422364937466 ∧ code e2422364937466 = 11218457959674 := by decide
theorem cert_e2422364937466 : check e2422364937466 [[],[]] .smaller = true := by decide
def e2422364937742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422364937742 : Closed e2422364937742 ∧ code e2422364937742 = 11218457959950 := by decide
theorem cert_e2422364937742 : check e2422364937742 [[],[]] .smaller = true := by decide
def e2422364937754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422364937754 : Closed e2422364937754 ∧ code e2422364937754 = 11218457959962 := by decide
theorem cert_e2422364937754 : check e2422364937754 [[],[]] .smaller = true := by decide
def e2422364937826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422364937826 : Closed e2422364937826 ∧ code e2422364937826 = 11218457960034 := by decide
theorem cert_e2422364937826 : check e2422364937826 [[],[]] .smaller = true := by decide
def e2422364937838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422364937838 : Closed e2422364937838 ∧ code e2422364937838 = 11218457960046 := by decide
theorem cert_e2422364937838 : check e2422364937838 [[],[]] .smaller = true := by decide
def e2422364937846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422364937846 : Closed e2422364937846 ∧ code e2422364937846 = 11218457960054 := by decide
theorem cert_e2422364937846 : check e2422364937846 [[],[]] .smaller = true := by decide
def e2422364937850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422364937850 : Closed e2422364937850 ∧ code e2422364937850 = 11218457960058 := by decide
theorem cert_e2422364937850 : check e2422364937850 [[],[]] .smaller = true := by decide
def e2422364938038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364938038 : Closed e2422364938038 ∧ code e2422364938038 = 11218457960246 := by decide
theorem cert_e2422364938038 : check e2422364938038 [[],[]] .smaller = true := by decide
def e2422364938042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364938042 : Closed e2422364938042 ∧ code e2422364938042 = 11218457960250 := by decide
theorem cert_e2422364938042 : check e2422364938042 [[],[]] .smaller = true := by decide
def e2422364938126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.lam (.var 2)))))))))))
theorem wire_e2422364938126 : Closed e2422364938126 ∧ code e2422364938126 = 11218457960334 := by decide
theorem cert_e2422364938126 : check e2422364938126 [[],[]] .three = true := by decide
def e2422364938138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364938138 : Closed e2422364938138 ∧ code e2422364938138 = 11218457960346 := by decide
theorem cert_e2422364938138 : check e2422364938138 [[],[]] .three = true := by decide
def e2422364938174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 4))))))))))
theorem wire_e2422364938174 : Closed e2422364938174 ∧ code e2422364938174 = 11218457960382 := by decide
theorem cert_e2422364938174 : check e2422364938174 [[],[]] .three = true := by decide
def e2422364947390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422364947390 : Closed e2422364947390 ∧ code e2422364947390 = 11218457969598 := by decide
theorem cert_e2422364947390 : check e2422364947390 [[],[]] .smaller = true := by decide
def e2422364947422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422364947422 : Closed e2422364947422 ∧ code e2422364947422 = 11218457969630 := by decide
theorem cert_e2422364947422 : check e2422364947422 [[],[]] .smaller = true := by decide
def e2422364947438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422364947438 : Closed e2422364947438 ∧ code e2422364947438 = 11218457969646 := by decide
theorem cert_e2422364947438 : check e2422364947438 [[],[]] .smaller = true := by decide
def e2422364947446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422364947446 : Closed e2422364947446 ∧ code e2422364947446 = 11218457969654 := by decide
theorem cert_e2422364947446 : check e2422364947446 [[],[]] .smaller = true := by decide
end Blc.Floor43
