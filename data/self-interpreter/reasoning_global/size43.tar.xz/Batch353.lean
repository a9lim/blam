import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419143403034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143403034 : Closed e2419143403034 ∧ code e2419143403034 = 11215236425242 := by decide
theorem cert_e2419143403034 : checkPay e2419143403034 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143403106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143403106 : Closed e2419143403106 ∧ code e2419143403106 = 11215236425314 := by decide
theorem cert_e2419143403106 : checkPay e2419143403106 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143403118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143403118 : Closed e2419143403118 ∧ code e2419143403118 = 11215236425326 := by decide
theorem cert_e2419143403118 : checkPay e2419143403118 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143403126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143403126 : Closed e2419143403126 ∧ code e2419143403126 = 11215236425334 := by decide
theorem cert_e2419143403126 : checkPay e2419143403126 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143403130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143403130 : Closed e2419143403130 ∧ code e2419143403130 = 11215236425338 := by decide
theorem cert_e2419143403130 : checkPay e2419143403130 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right,.right]] = true := by decide
def e2419143403318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143403318 : Closed e2419143403318 ∧ code e2419143403318 = 11215236425526 := by decide
theorem cert_e2419143403318 : checkPay e2419143403318 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143403322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143403322 : Closed e2419143403322 ∧ code e2419143403322 = 11215236425530 := by decide
theorem cert_e2419143403322 : checkPay e2419143403322 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143403418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2419143403418 : Closed e2419143403418 ∧ code e2419143403418 = 11215236425626 := by decide
theorem cert_e2419143403418 : checkPay e2419143403418 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right]] = true := by decide
def e2419143411510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143411510 : Closed e2419143411510 ∧ code e2419143411510 = 11215236433718 := by decide
theorem cert_e2419143411510 : check e2419143411510 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143411514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143411514 : Closed e2419143411514 ∧ code e2419143411514 = 11215236433722 := by decide
theorem cert_e2419143411514 : check e2419143411514 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143411610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143411610 : Closed e2419143411610 ∧ code e2419143411610 = 11215236433818 := by decide
theorem cert_e2419143411610 : check e2419143411610 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143413046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143413046 : Closed e2419143413046 ∧ code e2419143413046 = 11215236435254 := by decide
private def t_e2419143413046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem cert_e2419143413046 : ¬ IsSelfInterpreter e2419143413046 :=
  wSource (t := t_e2419143413046) (replay_sound (ps := []) (t := e2419143413046) (by decide)) (by decide)
def e2419143413050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143413050 : Closed e2419143413050 ∧ code e2419143413050 = 11215236435258 := by decide
private def t_e2419143413050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem cert_e2419143413050 : ¬ IsSelfInterpreter e2419143413050 :=
  wSource (t := t_e2419143413050) (replay_sound (ps := []) (t := e2419143413050) (by decide)) (by decide)
def e2419143413486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2419143413486 : Closed e2419143413486 ∧ code e2419143413486 = 11215236435694 := by decide
theorem cert_e2419143413486 : check e2419143413486 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143413494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2419143413494 : Closed e2419143413494 ∧ code e2419143413494 = 11215236435702 := by decide
theorem cert_e2419143413494 : check e2419143413494 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143413614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2419143413614 : Closed e2419143413614 ∧ code e2419143413614 = 11215236435822 := by decide
theorem cert_e2419143413614 : check e2419143413614 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143413626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2419143413626 : Closed e2419143413626 ∧ code e2419143413626 = 11215236435834 := by decide
theorem cert_e2419143413626 : check e2419143413626 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143413686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2419143413686 : Closed e2419143413686 ∧ code e2419143413686 = 11215236435894 := by decide
theorem cert_e2419143413686 : check e2419143413686 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143413690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2419143413690 : Closed e2419143413690 ∧ code e2419143413690 = 11215236435898 := by decide
theorem cert_e2419143413690 : check e2419143413690 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143414486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2419143414486 : Closed e2419143414486 ∧ code e2419143414486 = 11215236436694 := by decide
theorem cert_e2419143414486 : check e2419143414486 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143414490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2419143414490 : Closed e2419143414490 ∧ code e2419143414490 = 11215236436698 := by decide
theorem cert_e2419143414490 : check e2419143414490 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143414506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2419143414506 : Closed e2419143414506 ∧ code e2419143414506 = 11215236436714 := by decide
theorem cert_e2419143414506 : check e2419143414506 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143414582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143414582 : Closed e2419143414582 ∧ code e2419143414582 = 11215236436790 := by decide
theorem cert_e2419143414582 : check e2419143414582 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143414586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143414586 : Closed e2419143414586 ∧ code e2419143414586 = 11215236436794 := by decide
theorem cert_e2419143414586 : check e2419143414586 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143414682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2419143414682 : Closed e2419143414682 ∧ code e2419143414682 = 11215236436890 := by decide
theorem cert_e2419143414682 : check e2419143414682 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143416206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2419143416206 : Closed e2419143416206 ∧ code e2419143416206 = 11215236438414 := by decide
theorem cert_e2419143416206 : check e2419143416206 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143416262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2419143416262 : Closed e2419143416262 ∧ code e2419143416262 = 11215236438470 := by decide
theorem cert_e2419143416262 : check e2419143416262 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143417030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2419143417030 : Closed e2419143417030 ∧ code e2419143417030 = 11215236439238 := by decide
theorem cert_e2419143417030 : check e2419143417030 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2419143421014 : Closed e2419143421014 ∧ code e2419143421014 = 11215236443222 := by decide
theorem cert_e2419143421014 : check e2419143421014 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2419143421018 : Closed e2419143421018 ∧ code e2419143421018 = 11215236443226 := by decide
theorem cert_e2419143421018 : check e2419143421018 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2419143421206 : Closed e2419143421206 ∧ code e2419143421206 = 11215236443414 := by decide
theorem cert_e2419143421206 : check e2419143421206 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2419143421282 : Closed e2419143421282 ∧ code e2419143421282 = 11215236443490 := by decide
theorem cert_e2419143421282 : check e2419143421282 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2419143421294 : Closed e2419143421294 ∧ code e2419143421294 = 11215236443502 := by decide
theorem cert_e2419143421294 : check e2419143421294 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2419143421302 : Closed e2419143421302 ∧ code e2419143421302 = 11215236443510 := by decide
theorem cert_e2419143421302 : check e2419143421302 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143421322 : Closed e2419143421322 ∧ code e2419143421322 = 11215236443530 := by decide
theorem cert_e2419143421322 : check e2419143421322 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143421346 : Closed e2419143421346 ∧ code e2419143421346 = 11215236443554 := by decide
theorem cert_e2419143421346 : check e2419143421346 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2419143421358 : Closed e2419143421358 ∧ code e2419143421358 = 11215236443566 := by decide
theorem cert_e2419143421358 : check e2419143421358 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2419143421366 : Closed e2419143421366 ∧ code e2419143421366 = 11215236443574 := by decide
theorem cert_e2419143421366 : check e2419143421366 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2419143421370 : Closed e2419143421370 ∧ code e2419143421370 = 11215236443578 := by decide
theorem cert_e2419143421370 : check e2419143421370 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2419143421398 : Closed e2419143421398 ∧ code e2419143421398 = 11215236443606 := by decide
theorem cert_e2419143421398 : check e2419143421398 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2419143421402 : Closed e2419143421402 ∧ code e2419143421402 = 11215236443610 := by decide
theorem cert_e2419143421402 : check e2419143421402 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2419143421482 : Closed e2419143421482 ∧ code e2419143421482 = 11215236443690 := by decide
theorem cert_e2419143421482 : check e2419143421482 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143421578 : Closed e2419143421578 ∧ code e2419143421578 = 11215236443786 := by decide
theorem cert_e2419143421578 : check e2419143421578 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143421602 : Closed e2419143421602 ∧ code e2419143421602 = 11215236443810 := by decide
theorem cert_e2419143421602 : check e2419143421602 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2419143421614 : Closed e2419143421614 ∧ code e2419143421614 = 11215236443822 := by decide
theorem cert_e2419143421614 : check e2419143421614 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2419143421622 : Closed e2419143421622 ∧ code e2419143421622 = 11215236443830 := by decide
theorem cert_e2419143421622 : check e2419143421622 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2419143421626 : Closed e2419143421626 ∧ code e2419143421626 = 11215236443834 := by decide
theorem cert_e2419143421626 : check e2419143421626 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2419143421654 : Closed e2419143421654 ∧ code e2419143421654 = 11215236443862 := by decide
theorem cert_e2419143421654 : check e2419143421654 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2419143421658 : Closed e2419143421658 ∧ code e2419143421658 = 11215236443866 := by decide
theorem cert_e2419143421658 : check e2419143421658 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143421674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2419143421674 : Closed e2419143421674 ∧ code e2419143421674 = 11215236443882 := by decide
theorem cert_e2419143421674 : check e2419143421674 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2419143421782 : Closed e2419143421782 ∧ code e2419143421782 = 11215236443990 := by decide
theorem cert_e2419143421782 : check e2419143421782 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2419143421786 : Closed e2419143421786 ∧ code e2419143421786 = 11215236443994 := by decide
theorem cert_e2419143421786 : check e2419143421786 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143421802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2419143421802 : Closed e2419143421802 ∧ code e2419143421802 = 11215236444010 := by decide
theorem cert_e2419143421802 : check e2419143421802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143422070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2419143422070 : Closed e2419143422070 ∧ code e2419143422070 = 11215236444278 := by decide
theorem cert_e2419143422070 : check e2419143422070 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2419143422074 : Closed e2419143422074 ∧ code e2419143422074 = 11215236444282 := by decide
theorem cert_e2419143422074 : check e2419143422074 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2419143422166 : Closed e2419143422166 ∧ code e2419143422166 = 11215236444374 := by decide
theorem cert_e2419143422166 : check e2419143422166 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .width = true := by decide
def e2419143422262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143422262 : Closed e2419143422262 ∧ code e2419143422262 = 11215236444470 := by decide
theorem cert_e2419143422262 : check e2419143422262 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143422266 : Closed e2419143422266 ∧ code e2419143422266 = 11215236444474 := by decide
theorem cert_e2419143422266 : check e2419143422266 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2419143422350 : Closed e2419143422350 ∧ code e2419143422350 = 11215236444558 := by decide
theorem cert_e2419143422350 : check e2419143422350 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2419143422406 : Closed e2419143422406 ∧ code e2419143422406 = 11215236444614 := by decide
theorem cert_e2419143422406 : check e2419143422406 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2419143422742 : Closed e2419143422742 ∧ code e2419143422742 = 11215236444950 := by decide
theorem cert_e2419143422742 : check e2419143422742 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2419143422818 : Closed e2419143422818 ∧ code e2419143422818 = 11215236445026 := by decide
theorem cert_e2419143422818 : check e2419143422818 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2419143422830 : Closed e2419143422830 ∧ code e2419143422830 = 11215236445038 := by decide
theorem cert_e2419143422830 : check e2419143422830 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143422838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2419143422838 : Closed e2419143422838 ∧ code e2419143422838 = 11215236445046 := by decide
theorem cert_e2419143422838 : check e2419143422838 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143422858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2419143422858 : Closed e2419143422858 ∧ code e2419143422858 = 11215236445066 := by decide
theorem cert_e2419143422858 : check e2419143422858 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2419143422882 : Closed e2419143422882 ∧ code e2419143422882 = 11215236445090 := by decide
theorem cert_e2419143422882 : check e2419143422882 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2419143422894 : Closed e2419143422894 ∧ code e2419143422894 = 11215236445102 := by decide
theorem cert_e2419143422894 : check e2419143422894 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143422902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2419143422902 : Closed e2419143422902 ∧ code e2419143422902 = 11215236445110 := by decide
theorem cert_e2419143422902 : check e2419143422902 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143422906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2419143422906 : Closed e2419143422906 ∧ code e2419143422906 = 11215236445114 := by decide
theorem cert_e2419143422906 : check e2419143422906 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143422934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2419143422934 : Closed e2419143422934 ∧ code e2419143422934 = 11215236445142 := by decide
theorem cert_e2419143422934 : check e2419143422934 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143422938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2419143422938 : Closed e2419143422938 ∧ code e2419143422938 = 11215236445146 := by decide
theorem cert_e2419143422938 : check e2419143422938 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143423006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2419143423006 : Closed e2419143423006 ∧ code e2419143423006 = 11215236445214 := by decide
theorem cert_e2419143423006 : check e2419143423006 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143423202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2419143423202 : Closed e2419143423202 ∧ code e2419143423202 = 11215236445410 := by decide
theorem cert_e2419143423202 : check e2419143423202 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143423214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143423214 : Closed e2419143423214 ∧ code e2419143423214 = 11215236445422 := by decide
theorem cert_e2419143423214 : check e2419143423214 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143423222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143423222 : Closed e2419143423222 ∧ code e2419143423222 = 11215236445430 := by decide
theorem cert_e2419143423222 : check e2419143423222 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143423502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2419143423502 : Closed e2419143423502 ∧ code e2419143423502 = 11215236445710 := by decide
theorem cert_e2419143423502 : check e2419143423502 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143423514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143423514 : Closed e2419143423514 ∧ code e2419143423514 = 11215236445722 := by decide
theorem cert_e2419143423514 : check e2419143423514 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .width = true := by decide
def e2419143423586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143423586 : Closed e2419143423586 ∧ code e2419143423586 = 11215236445794 := by decide
theorem cert_e2419143423586 : check e2419143423586 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143423598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143423598 : Closed e2419143423598 ∧ code e2419143423598 = 11215236445806 := by decide
theorem cert_e2419143423598 : check e2419143423598 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143423606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143423606 : Closed e2419143423606 ∧ code e2419143423606 = 11215236445814 := by decide
theorem cert_e2419143423606 : check e2419143423606 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143423610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143423610 : Closed e2419143423610 ∧ code e2419143423610 = 11215236445818 := by decide
theorem cert_e2419143423610 : check e2419143423610 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143423798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143423798 : Closed e2419143423798 ∧ code e2419143423798 = 11215236446006 := by decide
theorem cert_e2419143423798 : check e2419143423798 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143423802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143423802 : Closed e2419143423802 ∧ code e2419143423802 = 11215236446010 := by decide
theorem cert_e2419143423802 : check e2419143423802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143424058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2419143424058 : Closed e2419143424058 ∧ code e2419143424058 = 11215236446266 := by decide
theorem cert_e2419143424058 : check e2419143424058 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2419143424106 : Closed e2419143424106 ∧ code e2419143424106 = 11215236446314 := by decide
theorem cert_e2419143424106 : check e2419143424106 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .width = true := by decide
def e2419143424154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143424154 : Closed e2419143424154 ∧ code e2419143424154 = 11215236446362 := by decide
theorem cert_e2419143424154 : check e2419143424154 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2419143424198 : Closed e2419143424198 ∧ code e2419143424198 = 11215236446406 := by decide
theorem cert_e2419143424198 : check e2419143424198 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2419143424394 : Closed e2419143424394 ∧ code e2419143424394 = 11215236446602 := by decide
theorem cert_e2419143424394 : check e2419143424394 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2419143424418 : Closed e2419143424418 ∧ code e2419143424418 = 11215236446626 := by decide
theorem cert_e2419143424418 : check e2419143424418 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2419143424430 : Closed e2419143424430 ∧ code e2419143424430 = 11215236446638 := by decide
theorem cert_e2419143424430 : check e2419143424430 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143424438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2419143424438 : Closed e2419143424438 ∧ code e2419143424438 = 11215236446646 := by decide
theorem cert_e2419143424438 : check e2419143424438 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2419143424442 : Closed e2419143424442 ∧ code e2419143424442 = 11215236446650 := by decide
theorem cert_e2419143424442 : check e2419143424442 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143424470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2419143424470 : Closed e2419143424470 ∧ code e2419143424470 = 11215236446678 := by decide
theorem cert_e2419143424470 : check e2419143424470 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2419143424474 : Closed e2419143424474 ∧ code e2419143424474 = 11215236446682 := by decide
theorem cert_e2419143424474 : check e2419143424474 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2419143424490 : Closed e2419143424490 ∧ code e2419143424490 = 11215236446698 := by decide
theorem cert_e2419143424490 : check e2419143424490 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143424526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2419143424526 : Closed e2419143424526 ∧ code e2419143424526 = 11215236446734 := by decide
theorem cert_e2419143424526 : check e2419143424526 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143424538 : Closed e2419143424538 ∧ code e2419143424538 = 11215236446746 := by decide
theorem cert_e2419143424538 : check e2419143424538 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .width = true := by decide
def e2419143424610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143424610 : Closed e2419143424610 ∧ code e2419143424610 = 11215236446818 := by decide
theorem cert_e2419143424610 : check e2419143424610 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143424622 : Closed e2419143424622 ∧ code e2419143424622 = 11215236446830 := by decide
theorem cert_e2419143424622 : check e2419143424622 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143424630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143424630 : Closed e2419143424630 ∧ code e2419143424630 = 11215236446838 := by decide
theorem cert_e2419143424630 : check e2419143424630 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143424634 : Closed e2419143424634 ∧ code e2419143424634 = 11215236446842 := by decide
theorem cert_e2419143424634 : check e2419143424634 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143424822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143424822 : Closed e2419143424822 ∧ code e2419143424822 = 11215236447030 := by decide
theorem cert_e2419143424822 : check e2419143424822 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143424826 : Closed e2419143424826 ∧ code e2419143424826 = 11215236447034 := by decide
theorem cert_e2419143424826 : check e2419143424826 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143424922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143424922 : Closed e2419143424922 ∧ code e2419143424922 = 11215236447130 := by decide
theorem cert_e2419143424922 : check e2419143424922 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143425238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2419143425238 : Closed e2419143425238 ∧ code e2419143425238 = 11215236447446 := by decide
theorem cert_e2419143425238 : check e2419143425238 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143425242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2419143425242 : Closed e2419143425242 ∧ code e2419143425242 = 11215236447450 := by decide
theorem cert_e2419143425242 : check e2419143425242 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143425258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2419143425258 : Closed e2419143425258 ∧ code e2419143425258 = 11215236447466 := by decide
theorem cert_e2419143425258 : check e2419143425258 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143425334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143425334 : Closed e2419143425334 ∧ code e2419143425334 = 11215236447542 := by decide
theorem cert_e2419143425334 : check e2419143425334 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143425338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143425338 : Closed e2419143425338 ∧ code e2419143425338 = 11215236447546 := by decide
theorem cert_e2419143425338 : check e2419143425338 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143425434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143425434 : Closed e2419143425434 ∧ code e2419143425434 = 11215236447642 := by decide
theorem cert_e2419143425434 : check e2419143425434 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143427038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2419143427038 : Closed e2419143427038 ∧ code e2419143427038 = 11215236449246 := by decide
theorem cert_e2419143427038 : check e2419143427038 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143427054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2419143427054 : Closed e2419143427054 ∧ code e2419143427054 = 11215236449262 := by decide
theorem cert_e2419143427054 : check e2419143427054 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143428886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419143428886 : Closed e2419143428886 ∧ code e2419143428886 = 11215236451094 := by decide
theorem cert_e2419143428886 : check e2419143428886 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143428962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419143428962 : Closed e2419143428962 ∧ code e2419143428962 = 11215236451170 := by decide
theorem cert_e2419143428962 : check e2419143428962 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143428974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419143428974 : Closed e2419143428974 ∧ code e2419143428974 = 11215236451182 := by decide
theorem cert_e2419143428974 : check e2419143428974 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143428982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419143428982 : Closed e2419143428982 ∧ code e2419143428982 = 11215236451190 := by decide
theorem cert_e2419143428982 : check e2419143428982 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143429002 : Closed e2419143429002 ∧ code e2419143429002 = 11215236451210 := by decide
theorem cert_e2419143429002 : check e2419143429002 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143429026 : Closed e2419143429026 ∧ code e2419143429026 = 11215236451234 := by decide
theorem cert_e2419143429026 : check e2419143429026 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419143429038 : Closed e2419143429038 ∧ code e2419143429038 = 11215236451246 := by decide
theorem cert_e2419143429038 : check e2419143429038 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2419143429046 : Closed e2419143429046 ∧ code e2419143429046 = 11215236451254 := by decide
theorem cert_e2419143429046 : check e2419143429046 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419143429050 : Closed e2419143429050 ∧ code e2419143429050 = 11215236451258 := by decide
theorem cert_e2419143429050 : check e2419143429050 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419143429078 : Closed e2419143429078 ∧ code e2419143429078 = 11215236451286 := by decide
theorem cert_e2419143429078 : check e2419143429078 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419143429082 : Closed e2419143429082 ∧ code e2419143429082 = 11215236451290 := by decide
theorem cert_e2419143429082 : check e2419143429082 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2419143429150 : Closed e2419143429150 ∧ code e2419143429150 = 11215236451358 := by decide
theorem cert_e2419143429150 : check e2419143429150 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419143429346 : Closed e2419143429346 ∧ code e2419143429346 = 11215236451554 := by decide
theorem cert_e2419143429346 : check e2419143429346 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143429358 : Closed e2419143429358 ∧ code e2419143429358 = 11215236451566 := by decide
theorem cert_e2419143429358 : check e2419143429358 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143429366 : Closed e2419143429366 ∧ code e2419143429366 = 11215236451574 := by decide
theorem cert_e2419143429366 : check e2419143429366 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143429646 : Closed e2419143429646 ∧ code e2419143429646 = 11215236451854 := by decide
theorem cert_e2419143429646 : check e2419143429646 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143429658 : Closed e2419143429658 ∧ code e2419143429658 = 11215236451866 := by decide
theorem cert_e2419143429658 : check e2419143429658 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .width = true := by decide
def e2419143429730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143429730 : Closed e2419143429730 ∧ code e2419143429730 = 11215236451938 := by decide
theorem cert_e2419143429730 : check e2419143429730 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143429742 : Closed e2419143429742 ∧ code e2419143429742 = 11215236451950 := by decide
theorem cert_e2419143429742 : check e2419143429742 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143429750 : Closed e2419143429750 ∧ code e2419143429750 = 11215236451958 := by decide
theorem cert_e2419143429750 : check e2419143429750 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143429754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143429754 : Closed e2419143429754 ∧ code e2419143429754 = 11215236451962 := by decide
theorem cert_e2419143429754 : check e2419143429754 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143429942 : Closed e2419143429942 ∧ code e2419143429942 = 11215236452150 := by decide
theorem cert_e2419143429942 : check e2419143429942 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143429946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143429946 : Closed e2419143429946 ∧ code e2419143429946 = 11215236452154 := by decide
theorem cert_e2419143429946 : check e2419143429946 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143434718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2419143434718 : Closed e2419143434718 ∧ code e2419143434718 = 11215236456926 := by decide
theorem cert_e2419143434718 : check e2419143434718 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143434742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2419143434742 : Closed e2419143434742 ∧ code e2419143434742 = 11215236456950 := by decide
theorem cert_e2419143434742 : check e2419143434742 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143435658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143435658 : Closed e2419143435658 ∧ code e2419143435658 = 11215236457866 := by decide
theorem cert_e2419143435658 : check e2419143435658 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143435682 : Closed e2419143435682 ∧ code e2419143435682 = 11215236457890 := by decide
theorem cert_e2419143435682 : check e2419143435682 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2419143435694 : Closed e2419143435694 ∧ code e2419143435694 = 11215236457902 := by decide
theorem cert_e2419143435694 : check e2419143435694 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143435702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2419143435702 : Closed e2419143435702 ∧ code e2419143435702 = 11215236457910 := by decide
theorem cert_e2419143435702 : check e2419143435702 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2419143435706 : Closed e2419143435706 ∧ code e2419143435706 = 11215236457914 := by decide
theorem cert_e2419143435706 : check e2419143435706 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143435734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2419143435734 : Closed e2419143435734 ∧ code e2419143435734 = 11215236457942 := by decide
theorem cert_e2419143435734 : check e2419143435734 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2419143435738 : Closed e2419143435738 ∧ code e2419143435738 = 11215236457946 := by decide
theorem cert_e2419143435738 : check e2419143435738 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2419143435754 : Closed e2419143435754 ∧ code e2419143435754 = 11215236457962 := by decide
theorem cert_e2419143435754 : check e2419143435754 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143435790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143435790 : Closed e2419143435790 ∧ code e2419143435790 = 11215236457998 := by decide
theorem cert_e2419143435790 : check e2419143435790 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143435802 : Closed e2419143435802 ∧ code e2419143435802 = 11215236458010 := by decide
theorem cert_e2419143435802 : check e2419143435802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .width = true := by decide
def e2419143435874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143435874 : Closed e2419143435874 ∧ code e2419143435874 = 11215236458082 := by decide
theorem cert_e2419143435874 : check e2419143435874 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143435886 : Closed e2419143435886 ∧ code e2419143435886 = 11215236458094 := by decide
theorem cert_e2419143435886 : check e2419143435886 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143435894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143435894 : Closed e2419143435894 ∧ code e2419143435894 = 11215236458102 := by decide
theorem cert_e2419143435894 : check e2419143435894 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143435898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143435898 : Closed e2419143435898 ∧ code e2419143435898 = 11215236458106 := by decide
theorem cert_e2419143435898 : check e2419143435898 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143436086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143436086 : Closed e2419143436086 ∧ code e2419143436086 = 11215236458294 := by decide
theorem cert_e2419143436086 : check e2419143436086 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143436090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143436090 : Closed e2419143436090 ∧ code e2419143436090 = 11215236458298 := by decide
theorem cert_e2419143436090 : check e2419143436090 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2419143436186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2419143436186 : Closed e2419143436186 ∧ code e2419143436186 = 11215236458394 := by decide
theorem cert_e2419143436186 : check e2419143436186 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143438574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2419143438574 : Closed e2419143438574 ∧ code e2419143438574 = 11215236460782 := by decide
private def t_e2419143438574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem cert_e2419143438574 : ¬ IsSelfInterpreter e2419143438574 :=
  wSource (t := t_e2419143438574) (replay_sound (ps := []) (t := e2419143438574) (by decide)) (by decide)
def e2419143438582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2419143438582 : Closed e2419143438582 ∧ code e2419143438582 = 11215236460790 := by decide
private def t_e2419143438582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem cert_e2419143438582 : ¬ IsSelfInterpreter e2419143438582 :=
  wSource (t := t_e2419143438582) (replay_sound (ps := []) (t := e2419143438582) (by decide)) (by decide)
def e2419143439062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2419143439062 : Closed e2419143439062 ∧ code e2419143439062 = 11215236461270 := by decide
private def t_e2419143439062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem cert_e2419143439062 : ¬ IsSelfInterpreter e2419143439062 :=
  wSource (t := t_e2419143439062) (replay_sound (ps := []) (t := e2419143439062) (by decide)) (by decide)
def e2419143439066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2419143439066 : Closed e2419143439066 ∧ code e2419143439066 = 11215236461274 := by decide
private def t_e2419143439066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem cert_e2419143439066 : ¬ IsSelfInterpreter e2419143439066 :=
  wSource (t := t_e2419143439066) (replay_sound (ps := []) (t := e2419143439066) (by decide)) (by decide)
def e2419143439082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2419143439082 : Closed e2419143439082 ∧ code e2419143439082 = 11215236461290 := by decide
private def t_e2419143439082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem cert_e2419143439082 : ¬ IsSelfInterpreter e2419143439082 :=
  wSource (t := t_e2419143439082) (replay_sound (ps := []) (t := e2419143439082) (by decide)) (by decide)
def e2419143439158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143439158 : Closed e2419143439158 ∧ code e2419143439158 = 11215236461366 := by decide
private def t_e2419143439158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem cert_e2419143439158 : ¬ IsSelfInterpreter e2419143439158 :=
  wSource (t := t_e2419143439158) (replay_sound (ps := []) (t := e2419143439158) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419143413046
#print axioms Blc.Floor43.cert_e2419143413050
#print axioms Blc.Floor43.cert_e2419143438574
#print axioms Blc.Floor43.cert_e2419143438582
#print axioms Blc.Floor43.cert_e2419143439062
#print axioms Blc.Floor43.cert_e2419143439066
#print axioms Blc.Floor43.cert_e2419143439082
#print axioms Blc.Floor43.cert_e2419143439158
