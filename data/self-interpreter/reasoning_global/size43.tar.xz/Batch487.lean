import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407547754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422407547754 : Closed e2422407547754 ∧ code e2422407547754 = 11218500569962 := by decide
private def t_e2422407547754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem cert_e2422407547754 : ¬ IsSelfInterpreter e2422407547754 :=
  wSource (t := t_e2422407547754) (replay_sound (ps := []) (t := e2422407547754) (by decide)) (by decide)
def e2422407547818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2422407547818 : Closed e2422407547818 ∧ code e2422407547818 = 11218500570026 := by decide
private def t_e2422407547818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem cert_e2422407547818 : ¬ IsSelfInterpreter e2422407547818 :=
  wSource (t := t_e2422407547818) (replay_sound (ps := []) (t := e2422407547818) (by decide)) (by decide)
def e2422407547926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407547926 : Closed e2422407547926 ∧ code e2422407547926 = 11218500570134 := by decide
private def t_e2422407547926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))
theorem cert_e2422407547926 : ¬ IsSelfInterpreter e2422407547926 :=
  wSource (t := t_e2422407547926) (replay_sound (ps := []) (t := e2422407547926) (by decide)) (by decide)
def e2422407548022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422407548022 : Closed e2422407548022 ∧ code e2422407548022 = 11218500570230 := by decide
private def t_e2422407548022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem cert_e2422407548022 : ¬ IsSelfInterpreter e2422407548022 :=
  wSource (t := t_e2422407548022) (replay_sound (ps := []) (t := e2422407548022) (by decide)) (by decide)
def e2422407548118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407548118 : Closed e2422407548118 ∧ code e2422407548118 = 11218500570326 := by decide
private def t_e2422407548118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem cert_e2422407548118 : ¬ IsSelfInterpreter e2422407548118 :=
  wSource (t := t_e2422407548118) (replay_sound (ps := []) (t := e2422407548118) (by decide)) (by decide)
def e2422407548122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407548122 : Closed e2422407548122 ∧ code e2422407548122 = 11218500570330 := by decide
private def t_e2422407548122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem cert_e2422407548122 : ¬ IsSelfInterpreter e2422407548122 :=
  wSource (t := t_e2422407548122) (replay_sound (ps := []) (t := e2422407548122) (by decide)) (by decide)
def e2422407548138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407548138 : Closed e2422407548138 ∧ code e2422407548138 = 11218500570346 := by decide
private def t_e2422407548138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem cert_e2422407548138 : ¬ IsSelfInterpreter e2422407548138 :=
  wSource (t := t_e2422407548138) (replay_sound (ps := []) (t := e2422407548138) (by decide)) (by decide)
def e2422407548214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407548214 : Closed e2422407548214 ∧ code e2422407548214 = 11218500570422 := by decide
private def t_e2422407548214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem cert_e2422407548214 : ¬ IsSelfInterpreter e2422407548214 :=
  wSource (t := t_e2422407548214) (replay_sound (ps := []) (t := e2422407548214) (by decide)) (by decide)
def e2422407548218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407548218 : Closed e2422407548218 ∧ code e2422407548218 = 11218500570426 := by decide
private def t_e2422407548218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem cert_e2422407548218 : ¬ IsSelfInterpreter e2422407548218 :=
  wSource (t := t_e2422407548218) (replay_sound (ps := []) (t := e2422407548218) (by decide)) (by decide)
def e2422407548290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407548290 : Closed e2422407548290 ∧ code e2422407548290 = 11218500570498 := by decide
private def t_e2422407548290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))
theorem cert_e2422407548290 : ¬ IsSelfInterpreter e2422407548290 :=
  wSource (t := t_e2422407548290) (replay_sound (ps := []) (t := e2422407548290) (by decide)) (by decide)
def e2422407548302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422407548302 : Closed e2422407548302 ∧ code e2422407548302 = 11218500570510 := by decide
private def t_e2422407548302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem cert_e2422407548302 : ¬ IsSelfInterpreter e2422407548302 :=
  wSource (t := t_e2422407548302) (replay_sound (ps := []) (t := e2422407548302) (by decide)) (by decide)
def e2422407548314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407548314 : Closed e2422407548314 ∧ code e2422407548314 = 11218500570522 := by decide
private def t_e2422407548314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem cert_e2422407548314 : ¬ IsSelfInterpreter e2422407548314 :=
  wSource (t := t_e2422407548314) (replay_sound (ps := []) (t := e2422407548314) (by decide)) (by decide)
def e2422407548426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407548426 : Closed e2422407548426 ∧ code e2422407548426 = 11218500570634 := by decide
private def t_e2422407548426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))
theorem cert_e2422407548426 : ¬ IsSelfInterpreter e2422407548426 :=
  wSource (t := t_e2422407548426) (replay_sound (ps := []) (t := e2422407548426) (by decide)) (by decide)
def e2422407548470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407548470 : Closed e2422407548470 ∧ code e2422407548470 = 11218500570678 := by decide
private def t_e2422407548470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem cert_e2422407548470 : ¬ IsSelfInterpreter e2422407548470 :=
  wSource (t := t_e2422407548470) (replay_sound (ps := []) (t := e2422407548470) (by decide)) (by decide)
def e2422407548474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407548474 : Closed e2422407548474 ∧ code e2422407548474 = 11218500570682 := by decide
private def t_e2422407548474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem cert_e2422407548474 : ¬ IsSelfInterpreter e2422407548474 :=
  wSource (t := t_e2422407548474) (replay_sound (ps := []) (t := e2422407548474) (by decide)) (by decide)
def e2422407548522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407548522 : Closed e2422407548522 ∧ code e2422407548522 = 11218500570730 := by decide
private def t_e2422407548522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem cert_e2422407548522 : ¬ IsSelfInterpreter e2422407548522 :=
  wSource (t := t_e2422407548522) (replay_sound (ps := []) (t := e2422407548522) (by decide)) (by decide)
def e2422407548546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407548546 : Closed e2422407548546 ∧ code e2422407548546 = 11218500570754 := by decide
private def t_e2422407548546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))
theorem cert_e2422407548546 : ¬ IsSelfInterpreter e2422407548546 :=
  wSource (t := t_e2422407548546) (replay_sound (ps := []) (t := e2422407548546) (by decide)) (by decide)
def e2422407548558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407548558 : Closed e2422407548558 ∧ code e2422407548558 = 11218500570766 := by decide
private def t_e2422407548558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem cert_e2422407548558 : ¬ IsSelfInterpreter e2422407548558 :=
  wSource (t := t_e2422407548558) (replay_sound (ps := []) (t := e2422407548558) (by decide)) (by decide)
def e2422407548570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407548570 : Closed e2422407548570 ∧ code e2422407548570 = 11218500570778 := by decide
private def t_e2422407548570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem cert_e2422407548570 : ¬ IsSelfInterpreter e2422407548570 :=
  wSource (t := t_e2422407548570) (replay_sound (ps := []) (t := e2422407548570) (by decide)) (by decide)
def e2422407548614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407548614 : Closed e2422407548614 ∧ code e2422407548614 = 11218500570822 := by decide
private def t_e2422407548614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem cert_e2422407548614 : ¬ IsSelfInterpreter e2422407548614 :=
  wSource (t := t_e2422407548614) (replay_sound (ps := []) (t := e2422407548614) (by decide)) (by decide)
def e2422407549166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407549166 : Closed e2422407549166 ∧ code e2422407549166 = 11218500571374 := by decide
private def t_e2422407549166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem cert_e2422407549166 : ¬ IsSelfInterpreter e2422407549166 :=
  wSource (t := t_e2422407549166) (replay_sound (ps := []) (t := e2422407549166) (by decide)) (by decide)
def e2422407549174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407549174 : Closed e2422407549174 ∧ code e2422407549174 = 11218500571382 := by decide
private def t_e2422407549174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem cert_e2422407549174 : ¬ IsSelfInterpreter e2422407549174 :=
  wSource (t := t_e2422407549174) (replay_sound (ps := []) (t := e2422407549174) (by decide)) (by decide)
def e2422407549654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407549654 : Closed e2422407549654 ∧ code e2422407549654 = 11218500571862 := by decide
private def t_e2422407549654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem cert_e2422407549654 : ¬ IsSelfInterpreter e2422407549654 :=
  wSource (t := t_e2422407549654) (replay_sound (ps := []) (t := e2422407549654) (by decide)) (by decide)
def e2422407549658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407549658 : Closed e2422407549658 ∧ code e2422407549658 = 11218500571866 := by decide
private def t_e2422407549658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem cert_e2422407549658 : ¬ IsSelfInterpreter e2422407549658 :=
  wSource (t := t_e2422407549658) (replay_sound (ps := []) (t := e2422407549658) (by decide)) (by decide)
def e2422407549674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407549674 : Closed e2422407549674 ∧ code e2422407549674 = 11218500571882 := by decide
private def t_e2422407549674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem cert_e2422407549674 : ¬ IsSelfInterpreter e2422407549674 :=
  wSource (t := t_e2422407549674) (replay_sound (ps := []) (t := e2422407549674) (by decide)) (by decide)
def e2422407549750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407549750 : Closed e2422407549750 ∧ code e2422407549750 = 11218500571958 := by decide
private def t_e2422407549750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem cert_e2422407549750 : ¬ IsSelfInterpreter e2422407549750 :=
  wSource (t := t_e2422407549750) (replay_sound (ps := []) (t := e2422407549750) (by decide)) (by decide)
def e2422407549754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407549754 : Closed e2422407549754 ∧ code e2422407549754 = 11218500571962 := by decide
private def t_e2422407549754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem cert_e2422407549754 : ¬ IsSelfInterpreter e2422407549754 :=
  wSource (t := t_e2422407549754) (replay_sound (ps := []) (t := e2422407549754) (by decide)) (by decide)
def e2422407549826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407549826 : Closed e2422407549826 ∧ code e2422407549826 = 11218500572034 := by decide
private def t_e2422407549826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem cert_e2422407549826 : ¬ IsSelfInterpreter e2422407549826 :=
  wSource (t := t_e2422407549826) (replay_sound (ps := []) (t := e2422407549826) (by decide)) (by decide)
def e2422407549838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422407549838 : Closed e2422407549838 ∧ code e2422407549838 = 11218500572046 := by decide
private def t_e2422407549838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem cert_e2422407549838 : ¬ IsSelfInterpreter e2422407549838 :=
  wSource (t := t_e2422407549838) (replay_sound (ps := []) (t := e2422407549838) (by decide)) (by decide)
def e2422407549850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407549850 : Closed e2422407549850 ∧ code e2422407549850 = 11218500572058 := by decide
private def t_e2422407549850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem cert_e2422407549850 : ¬ IsSelfInterpreter e2422407549850 :=
  wSource (t := t_e2422407549850) (replay_sound (ps := []) (t := e2422407549850) (by decide)) (by decide)
def e2422407551094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2422407551094 : Closed e2422407551094 ∧ code e2422407551094 = 11218500573302 := by decide
private def t_e2422407551094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem cert_e2422407551094 : ¬ IsSelfInterpreter e2422407551094 :=
  wSource (t := t_e2422407551094) (replay_sound (ps := []) (t := e2422407551094) (by decide)) (by decide)
def e2422407551338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2422407551338 : Closed e2422407551338 ∧ code e2422407551338 = 11218500573546 := by decide
private def t_e2422407551338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem cert_e2422407551338 : ¬ IsSelfInterpreter e2422407551338 :=
  wSource (t := t_e2422407551338) (replay_sound (ps := []) (t := e2422407551338) (by decide)) (by decide)
def e2422407551362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407551362 : Closed e2422407551362 ∧ code e2422407551362 = 11218500573570 := by decide
private def t_e2422407551362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem cert_e2422407551362 : ¬ IsSelfInterpreter e2422407551362 :=
  wSource (t := t_e2422407551362) (replay_sound (ps := []) (t := e2422407551362) (by decide)) (by decide)
def e2422407551374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407551374 : Closed e2422407551374 ∧ code e2422407551374 = 11218500573582 := by decide
private def t_e2422407551374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem cert_e2422407551374 : ¬ IsSelfInterpreter e2422407551374 :=
  wSource (t := t_e2422407551374) (replay_sound (ps := []) (t := e2422407551374) (by decide)) (by decide)
def e2422407551386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407551386 : Closed e2422407551386 ∧ code e2422407551386 = 11218500573594 := by decide
private def t_e2422407551386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem cert_e2422407551386 : ¬ IsSelfInterpreter e2422407551386 :=
  wSource (t := t_e2422407551386) (replay_sound (ps := []) (t := e2422407551386) (by decide)) (by decide)
def e2422407551430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407551430 : Closed e2422407551430 ∧ code e2422407551430 = 11218500573638 := by decide
private def t_e2422407551430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem cert_e2422407551430 : ¬ IsSelfInterpreter e2422407551430 :=
  wSource (t := t_e2422407551430) (replay_sound (ps := []) (t := e2422407551430) (by decide)) (by decide)
def e2422407703994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))))
theorem wire_e2422407703994 : Closed e2422407703994 ∧ code e2422407703994 = 11218500726202 := by decide
theorem cert_e2422407703994 : check e2422407703994 [[],[]] .smaller = true := by decide
def e2422407704026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))))
theorem wire_e2422407704026 : Closed e2422407704026 ∧ code e2422407704026 = 11218500726234 := by decide
theorem cert_e2422407704026 : check e2422407704026 [[],[]] .smaller = true := by decide
def e2422407704250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))))
theorem wire_e2422407704250 : Closed e2422407704250 ∧ code e2422407704250 = 11218500726458 := by decide
theorem cert_e2422407704250 : check e2422407704250 [[],[]] .smaller = true := by decide
def e2422407704298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))))
theorem wire_e2422407704298 : Closed e2422407704298 ∧ code e2422407704298 = 11218500726506 := by decide
theorem cert_e2422407704298 : check e2422407704298 [[],[]] .smaller = true := by decide
def e2422407704410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))))
theorem wire_e2422407704410 : Closed e2422407704410 ∧ code e2422407704410 = 11218500726618 := by decide
theorem cert_e2422407704410 : check e2422407704410 [[],[]] .smaller = true := by decide
def e2422407704426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))))
theorem wire_e2422407704426 : Closed e2422407704426 ∧ code e2422407704426 = 11218500726634 := by decide
theorem cert_e2422407704426 : check e2422407704426 [[],[]] .smaller = true := by decide
def e2422407705530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))))
theorem wire_e2422407705530 : Closed e2422407705530 ∧ code e2422407705530 = 11218500727738 := by decide
theorem cert_e2422407705530 : check e2422407705530 [[],[]] .smaller = true := by decide
def e2422407705562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))))
theorem wire_e2422407705562 : Closed e2422407705562 ∧ code e2422407705562 = 11218500727770 := by decide
theorem cert_e2422407705562 : check e2422407705562 [[],[]] .smaller = true := by decide
def e2422407705838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407705838 : Closed e2422407705838 ∧ code e2422407705838 = 11218500728046 := by decide
theorem cert_e2422407705838 : checkPay e2422407705838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422407705846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407705846 : Closed e2422407705846 ∧ code e2422407705846 = 11218500728054 := by decide
theorem cert_e2422407705846 : check e2422407705846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422407707066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))))
theorem wire_e2422407707066 : Closed e2422407707066 ∧ code e2422407707066 = 11218500729274 := by decide
theorem cert_e2422407707066 : check e2422407707066 [[],[]] .smaller = true := by decide
def e2422407707114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))))
theorem wire_e2422407707114 : Closed e2422407707114 ∧ code e2422407707114 = 11218500729322 := by decide
theorem cert_e2422407707114 : check e2422407707114 [[],[]] .smaller = true := by decide
def e2422407707866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))))
theorem wire_e2422407707866 : Closed e2422407707866 ∧ code e2422407707866 = 11218500730074 := by decide
theorem cert_e2422407707866 : check e2422407707866 [[],[]] .smaller = true := by decide
def e2422407707882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))))
theorem wire_e2422407707882 : Closed e2422407707882 ∧ code e2422407707882 = 11218500730090 := by decide
theorem cert_e2422407707882 : check e2422407707882 [[],[]] .smaller = true := by decide
def e2422407711598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407711598 : Closed e2422407711598 ∧ code e2422407711598 = 11218500733806 := by decide
theorem cert_e2422407711598 : check e2422407711598 [[],[]] .chain = true := by decide
def e2422407711606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407711606 : Closed e2422407711606 ∧ code e2422407711606 = 11218500733814 := by decide
theorem cert_e2422407711606 : check e2422407711606 [[],[]] .chain = true := by decide
def e2422407711662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407711662 : Closed e2422407711662 ∧ code e2422407711662 = 11218500733870 := by decide
theorem cert_e2422407711662 : check e2422407711662 [[],[]] .chain = true := by decide
def e2422407711674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407711674 : Closed e2422407711674 ∧ code e2422407711674 = 11218500733882 := by decide
theorem cert_e2422407711674 : check e2422407711674 [[],[]] .chain = true := by decide
def e2422407711702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407711702 : Closed e2422407711702 ∧ code e2422407711702 = 11218500733910 := by decide
theorem cert_e2422407711702 : check e2422407711702 [[],[]] .chain = true := by decide
def e2422407711706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407711706 : Closed e2422407711706 ∧ code e2422407711706 = 11218500733914 := by decide
theorem cert_e2422407711706 : check e2422407711706 [[],[]] .chain = true := by decide
def e2422407711982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407711982 : Closed e2422407711982 ∧ code e2422407711982 = 11218500734190 := by decide
theorem cert_e2422407711982 : check e2422407711982 [[],[]] .chain = true := by decide
def e2422407711990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407711990 : Closed e2422407711990 ∧ code e2422407711990 = 11218500734198 := by decide
theorem cert_e2422407711990 : check e2422407711990 [[],[]] .chain = true := by decide
def e2422407712366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407712366 : Closed e2422407712366 ∧ code e2422407712366 = 11218500734574 := by decide
theorem cert_e2422407712366 : check e2422407712366 [[],[]] .chain = true := by decide
def e2422407712378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407712378 : Closed e2422407712378 ∧ code e2422407712378 = 11218500734586 := by decide
theorem cert_e2422407712378 : check e2422407712378 [[],[]] .chain = true := by decide
def e2422407712566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407712566 : Closed e2422407712566 ∧ code e2422407712566 = 11218500734774 := by decide
theorem cert_e2422407712566 : check e2422407712566 [[],[]] .chain = true := by decide
def e2422407712570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407712570 : Closed e2422407712570 ∧ code e2422407712570 = 11218500734778 := by decide
theorem cert_e2422407712570 : check e2422407712570 [[],[]] .chain = true := by decide
def e2422407724270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407724270 : Closed e2422407724270 ∧ code e2422407724270 = 11218500746478 := by decide
theorem cert_e2422407724270 : check e2422407724270 [[],[]] .chain = true := by decide
def e2422407724278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407724278 : Closed e2422407724278 ∧ code e2422407724278 = 11218500746486 := by decide
theorem cert_e2422407724278 : check e2422407724278 [[],[]] .chain = true := by decide
def e2422407724662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407724662 : Closed e2422407724662 ∧ code e2422407724662 = 11218500746870 := by decide
theorem cert_e2422407724662 : check e2422407724662 [[],[]] .chain = true := by decide
def e2422407738862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))) (.var 2))))))
theorem wire_e2422407738862 : Closed e2422407738862 ∧ code e2422407738862 = 11218500761070 := by decide
theorem cert_e2422407738862 : check e2422407738862 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422407738870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 4))))) (.var 1))))))
theorem wire_e2422407738870 : Closed e2422407738870 ∧ code e2422407738870 = 11218500761078 := by decide
theorem cert_e2422407738870 : check e2422407738870 [[],[]] .chain = true := by decide
def e2422407739106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422407739106 : Closed e2422407739106 ∧ code e2422407739106 = 11218500761314 := by decide
theorem cert_e2422407739106 : check e2422407739106 [[],[]] .smaller = true := by decide
def e2422407739118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 2))))))
theorem wire_e2422407739118 : Closed e2422407739118 ∧ code e2422407739118 = 11218500761326 := by decide
theorem cert_e2422407739118 : check e2422407739118 [[],[]] .chain = true := by decide
def e2422407739126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 1))))))
theorem wire_e2422407739126 : Closed e2422407739126 ∧ code e2422407739126 = 11218500761334 := by decide
theorem cert_e2422407739126 : check e2422407739126 [[],[]] .smaller = true := by decide
def e2422407739130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))) (.var 0))))))
theorem wire_e2422407739130 : Closed e2422407739130 ∧ code e2422407739130 = 11218500761338 := by decide
theorem cert_e2422407739130 : check e2422407739130 [[],[]] .chain = true := by decide
def e2422407739234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e2422407739234 : Closed e2422407739234 ∧ code e2422407739234 = 11218500761442 := by decide
theorem cert_e2422407739234 : check e2422407739234 [[],[]] .smaller = true := by decide
def e2422407739246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 2))))))
theorem wire_e2422407739246 : Closed e2422407739246 ∧ code e2422407739246 = 11218500761454 := by decide
theorem cert_e2422407739246 : check e2422407739246 [[],[]] .chain = true := by decide
def e2422407739258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))) (.var 0))))))
theorem wire_e2422407739258 : Closed e2422407739258 ∧ code e2422407739258 = 11218500761466 := by decide
theorem cert_e2422407739258 : check e2422407739258 [[],[]] .smaller = true := by decide
def e2422407739310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))) (.var 2))))))
theorem wire_e2422407739310 : Closed e2422407739310 ∧ code e2422407739310 = 11218500761518 := by decide
theorem cert_e2422407739310 : check e2422407739310 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422407739318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 1))))))
theorem wire_e2422407739318 : Closed e2422407739318 ∧ code e2422407739318 = 11218500761526 := by decide
theorem cert_e2422407739318 : check e2422407739318 [[],[]] .smaller = true := by decide
def e2422407739322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))) (.var 0))))))
theorem wire_e2422407739322 : Closed e2422407739322 ∧ code e2422407739322 = 11218500761530 := by decide
theorem cert_e2422407739322 : check e2422407739322 [[],[]] .smaller = true := by decide
def e2422407739350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 0))))) (.var 1))))))
theorem wire_e2422407739350 : Closed e2422407739350 ∧ code e2422407739350 = 11218500761558 := by decide
theorem cert_e2422407739350 : check e2422407739350 [[],[]] .chain = true := by decide
def e2422407739354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))) (.var 0))))))
theorem wire_e2422407739354 : Closed e2422407739354 ∧ code e2422407739354 = 11218500761562 := by decide
theorem cert_e2422407739354 : check e2422407739354 [[],[]] .chain = true := by decide
def e2422407740130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422407740130 : Closed e2422407740130 ∧ code e2422407740130 = 11218500762338 := by decide
theorem cert_e2422407740130 : check e2422407740130 [[],[]] .smaller = true := by decide
def e2422407740142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 2))))))
theorem wire_e2422407740142 : Closed e2422407740142 ∧ code e2422407740142 = 11218500762350 := by decide
theorem cert_e2422407740142 : check e2422407740142 [[],[]] .chain = true := by decide
def e2422407740150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 1))))))
theorem wire_e2422407740150 : Closed e2422407740150 ∧ code e2422407740150 = 11218500762358 := by decide
theorem cert_e2422407740150 : check e2422407740150 [[],[]] .smaller = true := by decide
def e2422407740154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))) (.var 0))))))
theorem wire_e2422407740154 : Closed e2422407740154 ∧ code e2422407740154 = 11218500762362 := by decide
theorem cert_e2422407740154 : check e2422407740154 [[],[]] .chain = true := by decide
def e2422407740322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422407740322 : Closed e2422407740322 ∧ code e2422407740322 = 11218500762530 := by decide
theorem cert_e2422407740322 : check e2422407740322 [[],[]] .smaller = true := by decide
def e2422407740334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 2))))))
theorem wire_e2422407740334 : Closed e2422407740334 ∧ code e2422407740334 = 11218500762542 := by decide
theorem cert_e2422407740334 : check e2422407740334 [[],[]] .chain = true := by decide
def e2422407740374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 1))))))
theorem wire_e2422407740374 : Closed e2422407740374 ∧ code e2422407740374 = 11218500762582 := by decide
theorem cert_e2422407740374 : check e2422407740374 [[],[]] .smaller = true := by decide
def e2422407740394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))) (.var 0))))))
theorem wire_e2422407740394 : Closed e2422407740394 ∧ code e2422407740394 = 11218500762602 := by decide
theorem cert_e2422407740394 : check e2422407740394 [[],[]] .chain = true := by decide
def e2422407740770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e2422407740770 : Closed e2422407740770 ∧ code e2422407740770 = 11218500762978 := by decide
theorem cert_e2422407740770 : check e2422407740770 [[],[]] .smaller = true := by decide
def e2422407740782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 2))))))
theorem wire_e2422407740782 : Closed e2422407740782 ∧ code e2422407740782 = 11218500762990 := by decide
theorem cert_e2422407740782 : check e2422407740782 [[],[]] .chain = true := by decide
def e2422407740794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))) (.var 0))))))
theorem wire_e2422407740794 : Closed e2422407740794 ∧ code e2422407740794 = 11218500763002 := by decide
theorem cert_e2422407740794 : check e2422407740794 [[],[]] .smaller = true := by decide
def e2422407740834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422407740834 : Closed e2422407740834 ∧ code e2422407740834 = 11218500763042 := by decide
theorem cert_e2422407740834 : check e2422407740834 [[],[]] .smaller = true := by decide
def e2422407740846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 2))))))
theorem wire_e2422407740846 : Closed e2422407740846 ∧ code e2422407740846 = 11218500763054 := by decide
theorem cert_e2422407740846 : check e2422407740846 [[],[]] .chain = true := by decide
def e2422407740906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))) (.var 0))))))
theorem wire_e2422407740906 : Closed e2422407740906 ∧ code e2422407740906 = 11218500763114 := by decide
theorem cert_e2422407740906 : check e2422407740906 [[],[]] .smaller = true := by decide
def e2422407741102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))) (.var 2))))))
theorem wire_e2422407741102 : Closed e2422407741102 ∧ code e2422407741102 = 11218500763310 := by decide
theorem cert_e2422407741102 : check e2422407741102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407741110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 1))))))
theorem wire_e2422407741110 : Closed e2422407741110 ∧ code e2422407741110 = 11218500763318 := by decide
theorem cert_e2422407741110 : check e2422407741110 [[],[]] .smaller = true := by decide
def e2422407741114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e2422407741114 : Closed e2422407741114 ∧ code e2422407741114 = 11218500763322 := by decide
theorem cert_e2422407741114 : check e2422407741114 [[],[]] .smaller = true := by decide
def e2422407741142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 1))))))
theorem wire_e2422407741142 : Closed e2422407741142 ∧ code e2422407741142 = 11218500763350 := by decide
theorem cert_e2422407741142 : check e2422407741142 [[],[]] .smaller = true := by decide
def e2422407741162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e2422407741162 : Closed e2422407741162 ∧ code e2422407741162 = 11218500763370 := by decide
theorem cert_e2422407741162 : check e2422407741162 [[],[]] .smaller = true := by decide
def e2422407741270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 0))))) (.var 1))))))
theorem wire_e2422407741270 : Closed e2422407741270 ∧ code e2422407741270 = 11218500763478 := by decide
theorem cert_e2422407741270 : check e2422407741270 [[],[]] .chain = true := by decide
def e2422407741274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e2422407741274 : Closed e2422407741274 ∧ code e2422407741274 = 11218500763482 := by decide
theorem cert_e2422407741274 : check e2422407741274 [[],[]] .chain = true := by decide
def e2422407741290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e2422407741290 : Closed e2422407741290 ∧ code e2422407741290 = 11218500763498 := by decide
theorem cert_e2422407741290 : check e2422407741290 [[],[]] .chain = true := by decide
def e2422407745006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))) (.var 2))))))
theorem wire_e2422407745006 : Closed e2422407745006 ∧ code e2422407745006 = 11218500767214 := by decide
theorem cert_e2422407745006 : check e2422407745006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407745014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 4)))))) (.var 1))))))
theorem wire_e2422407745014 : Closed e2422407745014 ∧ code e2422407745014 = 11218500767222 := by decide
theorem cert_e2422407745014 : check e2422407745014 [[],[]] .chain = true := by decide
def e2422407745250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))))))
theorem wire_e2422407745250 : Closed e2422407745250 ∧ code e2422407745250 = 11218500767458 := by decide
theorem cert_e2422407745250 : check e2422407745250 [[],[]] .smaller = true := by decide
def e2422407745262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 2))))))
theorem wire_e2422407745262 : Closed e2422407745262 ∧ code e2422407745262 = 11218500767470 := by decide
theorem cert_e2422407745262 : check e2422407745262 [[],[]] .chain = true := by decide
def e2422407745270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 1))))))
theorem wire_e2422407745270 : Closed e2422407745270 ∧ code e2422407745270 = 11218500767478 := by decide
theorem cert_e2422407745270 : check e2422407745270 [[],[]] .smaller = true := by decide
def e2422407745274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))) (.var 0))))))
theorem wire_e2422407745274 : Closed e2422407745274 ∧ code e2422407745274 = 11218500767482 := by decide
theorem cert_e2422407745274 : check e2422407745274 [[],[]] .chain = true := by decide
def e2422407745378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))))))
theorem wire_e2422407745378 : Closed e2422407745378 ∧ code e2422407745378 = 11218500767586 := by decide
theorem cert_e2422407745378 : check e2422407745378 [[],[]] .smaller = true := by decide
def e2422407745390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 2))))))
theorem wire_e2422407745390 : Closed e2422407745390 ∧ code e2422407745390 = 11218500767598 := by decide
theorem cert_e2422407745390 : check e2422407745390 [[],[]] .chain = true := by decide
def e2422407745402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))) (.var 0))))))
theorem wire_e2422407745402 : Closed e2422407745402 ∧ code e2422407745402 = 11218500767610 := by decide
theorem cert_e2422407745402 : check e2422407745402 [[],[]] .smaller = true := by decide
def e2422407745454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))) (.var 2))))))
theorem wire_e2422407745454 : Closed e2422407745454 ∧ code e2422407745454 = 11218500767662 := by decide
theorem cert_e2422407745454 : check e2422407745454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2422407745462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 1))))))
theorem wire_e2422407745462 : Closed e2422407745462 ∧ code e2422407745462 = 11218500767670 := by decide
theorem cert_e2422407745462 : check e2422407745462 [[],[]] .smaller = true := by decide
def e2422407745466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))) (.var 0))))))
theorem wire_e2422407745466 : Closed e2422407745466 ∧ code e2422407745466 = 11218500767674 := by decide
theorem cert_e2422407745466 : check e2422407745466 [[],[]] .smaller = true := by decide
def e2422407745494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 0)))))) (.var 1))))))
theorem wire_e2422407745494 : Closed e2422407745494 ∧ code e2422407745494 = 11218500767702 := by decide
theorem cert_e2422407745494 : check e2422407745494 [[],[]] .chain = true := by decide
def e2422407745498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))) (.var 0))))))
theorem wire_e2422407745498 : Closed e2422407745498 ∧ code e2422407745498 = 11218500767706 := by decide
theorem cert_e2422407745498 : check e2422407745498 [[],[]] .chain = true := by decide
def e2422407748846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407748846 : Closed e2422407748846 ∧ code e2422407748846 = 11218500771054 := by decide
theorem cert_e2422407748846 : check e2422407748846 [[],[]] .chain = true := by decide
def e2422407748854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407748854 : Closed e2422407748854 ∧ code e2422407748854 = 11218500771062 := by decide
theorem cert_e2422407748854 : check e2422407748854 [[],[]] .chain = true := by decide
def e2422407749230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 3))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407749230 : Closed e2422407749230 ∧ code e2422407749230 = 11218500771438 := by decide
theorem cert_e2422407749230 : check e2422407749230 [[],[]] .chain = true := by decide
def e2422407749242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 3))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407749242 : Closed e2422407749242 ∧ code e2422407749242 = 11218500771450 := by decide
theorem cert_e2422407749242 : check e2422407749242 [[],[]] .chain = true := by decide
def e2422407749430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 4))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407749430 : Closed e2422407749430 ∧ code e2422407749430 = 11218500771638 := by decide
theorem cert_e2422407749430 : check e2422407749430 [[],[]] .chain = true := by decide
def e2422407749434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 4))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407749434 : Closed e2422407749434 ∧ code e2422407749434 = 11218500771642 := by decide
theorem cert_e2422407749434 : check e2422407749434 [[],[]] .chain = true := by decide
def e2422407751394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))))))
theorem wire_e2422407751394 : Closed e2422407751394 ∧ code e2422407751394 = 11218500773602 := by decide
theorem cert_e2422407751394 : check e2422407751394 [[],[]] .smaller = true := by decide
def e2422407751406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 2))))))
theorem wire_e2422407751406 : Closed e2422407751406 ∧ code e2422407751406 = 11218500773614 := by decide
theorem cert_e2422407751406 : check e2422407751406 [[],[]] .chain = true := by decide
def e2422407751414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 1))))))
theorem wire_e2422407751414 : Closed e2422407751414 ∧ code e2422407751414 = 11218500773622 := by decide
theorem cert_e2422407751414 : check e2422407751414 [[],[]] .smaller = true := by decide
def e2422407751418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))) (.var 0))))))
theorem wire_e2422407751418 : Closed e2422407751418 ∧ code e2422407751418 = 11218500773626 := by decide
theorem cert_e2422407751418 : check e2422407751418 [[],[]] .chain = true := by decide
def e2422407751586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))))))
theorem wire_e2422407751586 : Closed e2422407751586 ∧ code e2422407751586 = 11218500773794 := by decide
theorem cert_e2422407751586 : check e2422407751586 [[],[]] .smaller = true := by decide
def e2422407751598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 2))))))
theorem wire_e2422407751598 : Closed e2422407751598 ∧ code e2422407751598 = 11218500773806 := by decide
theorem cert_e2422407751598 : check e2422407751598 [[],[]] .chain = true := by decide
def e2422407751638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 1))))))
theorem wire_e2422407751638 : Closed e2422407751638 ∧ code e2422407751638 = 11218500773846 := by decide
theorem cert_e2422407751638 : check e2422407751638 [[],[]] .smaller = true := by decide
def e2422407751658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))) (.var 0))))))
theorem wire_e2422407751658 : Closed e2422407751658 ∧ code e2422407751658 = 11218500773866 := by decide
theorem cert_e2422407751658 : check e2422407751658 [[],[]] .chain = true := by decide
def e2422407752942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407752942 : Closed e2422407752942 ∧ code e2422407752942 = 11218500775150 := by decide
theorem cert_e2422407752942 : check e2422407752942 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407752950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407752950 : Closed e2422407752950 ∧ code e2422407752950 = 11218500775158 := by decide
theorem cert_e2422407752950 : check e2422407752950 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407754594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))))))
theorem wire_e2422407754594 : Closed e2422407754594 ∧ code e2422407754594 = 11218500776802 := by decide
theorem cert_e2422407754594 : check e2422407754594 [[],[]] .smaller = true := by decide
def e2422407754606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 2))))))
theorem wire_e2422407754606 : Closed e2422407754606 ∧ code e2422407754606 = 11218500776814 := by decide
theorem cert_e2422407754606 : check e2422407754606 [[],[]] .chain = true := by decide
def e2422407754618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))) (.var 0))))))
theorem wire_e2422407754618 : Closed e2422407754618 ∧ code e2422407754618 = 11218500776826 := by decide
theorem cert_e2422407754618 : check e2422407754618 [[],[]] .smaller = true := by decide
def e2422407754658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))))))
theorem wire_e2422407754658 : Closed e2422407754658 ∧ code e2422407754658 = 11218500776866 := by decide
theorem cert_e2422407754658 : check e2422407754658 [[],[]] .smaller = true := by decide
def e2422407754670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 2))))))
theorem wire_e2422407754670 : Closed e2422407754670 ∧ code e2422407754670 = 11218500776878 := by decide
theorem cert_e2422407754670 : check e2422407754670 [[],[]] .chain = true := by decide
def e2422407754730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))) (.var 0))))))
theorem wire_e2422407754730 : Closed e2422407754730 ∧ code e2422407754730 = 11218500776938 := by decide
theorem cert_e2422407754730 : check e2422407754730 [[],[]] .smaller = true := by decide
def e2422407754990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407754990 : Closed e2422407754990 ∧ code e2422407754990 = 11218500777198 := by decide
theorem cert_e2422407754990 : check e2422407754990 [[],[]] .chain = true := by decide
def e2422407754998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407754998 : Closed e2422407754998 ∧ code e2422407754998 = 11218500777206 := by decide
theorem cert_e2422407754998 : check e2422407754998 [[],[]] .chain = true := by decide
def e2422407756206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e2422407756206 : Closed e2422407756206 ∧ code e2422407756206 = 11218500778414 := by decide
theorem cert_e2422407756206 : checkPay e2422407756206 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2422407756214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1))))))
theorem wire_e2422407756214 : Closed e2422407756214 ∧ code e2422407756214 = 11218500778422 := by decide
theorem cert_e2422407756214 : check e2422407756214 [[],[]] .smaller = true := by decide
def e2422407756218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e2422407756218 : Closed e2422407756218 ∧ code e2422407756218 = 11218500778426 := by decide
theorem cert_e2422407756218 : check e2422407756218 [[],[]] .smaller = true := by decide
def e2422407756246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1))))))
theorem wire_e2422407756246 : Closed e2422407756246 ∧ code e2422407756246 = 11218500778454 := by decide
theorem cert_e2422407756246 : check e2422407756246 [[],[]] .smaller = true := by decide
def e2422407756266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e2422407756266 : Closed e2422407756266 ∧ code e2422407756266 = 11218500778474 := by decide
theorem cert_e2422407756266 : check e2422407756266 [[],[]] .smaller = true := by decide
def e2422407756398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407756398 : Closed e2422407756398 ∧ code e2422407756398 = 11218500778606 := by decide
theorem cert_e2422407756398 : check e2422407756398 [[],[]] .chain = true := by decide
def e2422407756410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407756410 : Closed e2422407756410 ∧ code e2422407756410 = 11218500778618 := by decide
theorem cert_e2422407756410 : check e2422407756410 [[],[]] .chain = true := by decide
def e2422407756782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))) (.var 2))))))
theorem wire_e2422407756782 : Closed e2422407756782 ∧ code e2422407756782 = 11218500778990 := by decide
theorem cert_e2422407756782 : checkPay e2422407756782 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2422407757014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e2422407757014 : Closed e2422407757014 ∧ code e2422407757014 = 11218500779222 := by decide
theorem cert_e2422407757014 : check e2422407757014 [[],[]] .chain = true := by decide
def e2422407757018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e2422407757018 : Closed e2422407757018 ∧ code e2422407757018 = 11218500779226 := by decide
theorem cert_e2422407757018 : check e2422407757018 [[],[]] .chain = true := by decide
def e2422407757034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e2422407757034 : Closed e2422407757034 ∧ code e2422407757034 = 11218500779242 := by decide
theorem cert_e2422407757034 : check e2422407757034 [[],[]] .chain = true := by decide
def e2422407757110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407757110 : Closed e2422407757110 ∧ code e2422407757110 = 11218500779318 := by decide
theorem cert_e2422407757110 : check e2422407757110 [[],[]] .chain = true := by decide
def e2422407757114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407757114 : Closed e2422407757114 ∧ code e2422407757114 = 11218500779322 := by decide
theorem cert_e2422407757114 : check e2422407757114 [[],[]] .chain = true := by decide
def e2422407757294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))) (.var 2))))))
theorem wire_e2422407757294 : Closed e2422407757294 ∧ code e2422407757294 = 11218500779502 := by decide
theorem cert_e2422407757294 : check e2422407757294 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407757302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 4))))) (.var 1))))))
theorem wire_e2422407757302 : Closed e2422407757302 ∧ code e2422407757302 = 11218500779510 := by decide
theorem cert_e2422407757302 : check e2422407757302 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407760750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422407760750 : Closed e2422407760750 ∧ code e2422407760750 = 11218500782958 := by decide
theorem cert_e2422407760750 : check e2422407760750 [[],[]] .smaller = true := by decide
def e2422407760758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422407760758 : Closed e2422407760758 ∧ code e2422407760758 = 11218500782966 := by decide
theorem cert_e2422407760758 : check e2422407760758 [[],[]] .smaller = true := by decide
def e2422407760814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422407760814 : Closed e2422407760814 ∧ code e2422407760814 = 11218500783022 := by decide
theorem cert_e2422407760814 : check e2422407760814 [[],[]] .smaller = true := by decide
def e2422407760826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422407760826 : Closed e2422407760826 ∧ code e2422407760826 = 11218500783034 := by decide
theorem cert_e2422407760826 : check e2422407760826 [[],[]] .smaller = true := by decide
def e2422407760854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422407760854 : Closed e2422407760854 ∧ code e2422407760854 = 11218500783062 := by decide
theorem cert_e2422407760854 : check e2422407760854 [[],[]] .smaller = true := by decide
def e2422407760858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422407760858 : Closed e2422407760858 ∧ code e2422407760858 = 11218500783066 := by decide
theorem cert_e2422407760858 : check e2422407760858 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422407547754
#print axioms Blc.Floor43.cert_e2422407547818
#print axioms Blc.Floor43.cert_e2422407547926
#print axioms Blc.Floor43.cert_e2422407548022
#print axioms Blc.Floor43.cert_e2422407548118
#print axioms Blc.Floor43.cert_e2422407548122
#print axioms Blc.Floor43.cert_e2422407548138
#print axioms Blc.Floor43.cert_e2422407548214
#print axioms Blc.Floor43.cert_e2422407548218
#print axioms Blc.Floor43.cert_e2422407548290
#print axioms Blc.Floor43.cert_e2422407548302
#print axioms Blc.Floor43.cert_e2422407548314
#print axioms Blc.Floor43.cert_e2422407548426
#print axioms Blc.Floor43.cert_e2422407548470
#print axioms Blc.Floor43.cert_e2422407548474
#print axioms Blc.Floor43.cert_e2422407548522
#print axioms Blc.Floor43.cert_e2422407548546
#print axioms Blc.Floor43.cert_e2422407548558
#print axioms Blc.Floor43.cert_e2422407548570
#print axioms Blc.Floor43.cert_e2422407548614
#print axioms Blc.Floor43.cert_e2422407549166
#print axioms Blc.Floor43.cert_e2422407549174
#print axioms Blc.Floor43.cert_e2422407549654
#print axioms Blc.Floor43.cert_e2422407549658
#print axioms Blc.Floor43.cert_e2422407549674
#print axioms Blc.Floor43.cert_e2422407549750
#print axioms Blc.Floor43.cert_e2422407549754
#print axioms Blc.Floor43.cert_e2422407549826
#print axioms Blc.Floor43.cert_e2422407549838
#print axioms Blc.Floor43.cert_e2422407549850
#print axioms Blc.Floor43.cert_e2422407551094
#print axioms Blc.Floor43.cert_e2422407551338
#print axioms Blc.Floor43.cert_e2422407551362
#print axioms Blc.Floor43.cert_e2422407551374
#print axioms Blc.Floor43.cert_e2422407551386
#print axioms Blc.Floor43.cert_e2422407551430
