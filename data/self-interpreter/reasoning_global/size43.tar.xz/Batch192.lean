import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388219297910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388219297910 : Closed e2388219297910 ∧ code e2388219297910 = 11184312320118 := by decide
theorem cert_e2388219297910 : check e2388219297910 [[]] .width = true := by decide
def e2388219298154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388219298154 : Closed e2388219298154 ∧ code e2388219298154 = 11184312320362 := by decide
theorem cert_e2388219298154 : check e2388219298154 [[]] .width = true := by decide
def e2388219298202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388219298202 : Closed e2388219298202 ∧ code e2388219298202 = 11184312320410 := by decide
theorem cert_e2388219298202 : check e2388219298202 [[]] .width = true := by decide
def e2388219299210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388219299210 : Closed e2388219299210 ∧ code e2388219299210 = 11184312321418 := by decide
theorem cert_e2388219299210 : check e2388219299210 [[]] .width = true := by decide
def e2388219299234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388219299234 : Closed e2388219299234 ∧ code e2388219299234 = 11184312321442 := by decide
theorem cert_e2388219299234 : check e2388219299234 [[]] .width = true := by decide
def e2388219299342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388219299342 : Closed e2388219299342 ∧ code e2388219299342 = 11184312321550 := by decide
theorem cert_e2388219299342 : check e2388219299342 [[]] .width = true := by decide
def e2388219299354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388219299354 : Closed e2388219299354 ∧ code e2388219299354 = 11184312321562 := by decide
theorem cert_e2388219299354 : check e2388219299354 [[]] .width = true := by decide
def e2388219299426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388219299426 : Closed e2388219299426 ∧ code e2388219299426 = 11184312321634 := by decide
theorem cert_e2388219299426 : check e2388219299426 [[]] .width = true := by decide
def e2388238657562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388238657562 : Closed e2388238657562 ∧ code e2388238657562 = 11184331679770 := by decide
theorem cert_e2388238657562 : check e2388238657562 [[]] .width = true := by decide
def e2388238755866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388238755866 : Closed e2388238755866 ∧ code e2388238755866 = 11184331778074 := by decide
theorem cert_e2388238755866 : check e2388238755866 [[]] .width = true := by decide
def e2388242512410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388242512410 : Closed e2388242512410 ∧ code e2388242512410 = 11184335534618 := by decide
theorem cert_e2388242512410 : check e2388242512410 [[]] .width = true := by decide
def e2388242655258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388242655258 : Closed e2388242655258 ∧ code e2388242655258 = 11184335677466 := by decide
theorem cert_e2388242655258 : check e2388242655258 [[]] .width = true := by decide
def e2388242696730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388242696730 : Closed e2388242696730 ∧ code e2388242696730 = 11184335718938 := by decide
theorem cert_e2388242696730 : check e2388242696730 [[]] .width = true := by decide
def e2388242704410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388242704410 : Closed e2388242704410 ∧ code e2388242704410 = 11184335726618 := by decide
theorem cert_e2388242704410 : check e2388242704410 [[]] .width = true := by decide
def e2388242709018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388242709018 : Closed e2388242709018 ∧ code e2388242709018 = 11184335731226 := by decide
theorem cert_e2388242709018 : check e2388242709018 [[]] .width = true := by decide
def e2388242868762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388242868762 : Closed e2388242868762 ∧ code e2388242868762 = 11184335890970 := by decide
theorem cert_e2388242868762 : check e2388242868762 [[]] .width = true := by decide
def e2388242893338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388242893338 : Closed e2388242893338 ∧ code e2388242893338 = 11184335915546 := by decide
theorem cert_e2388242893338 : check e2388242893338 [[]] .width = true := by decide
def e2388242901018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388242901018 : Closed e2388242901018 ∧ code e2388242901018 = 11184335923226 := by decide
theorem cert_e2388242901018 : check e2388242901018 [[]] .width = true := by decide
def e2388242905626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388242905626 : Closed e2388242905626 ∧ code e2388242905626 = 11184335927834 := by decide
theorem cert_e2388242905626 : check e2388242905626 [[]] .width = true := by decide
def e2388242917914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388242917914 : Closed e2388242917914 ∧ code e2388242917914 = 11184335940122 := by decide
private def t_e2388242917914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388242917914 : ¬ IsSelfInterpreter e2388242917914 :=
  wSource (t := t_e2388242917914) (replay_sound (ps := []) (t := e2388242917914) (by decide)) (by decide)
def e2388243053082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388243053082 : Closed e2388243053082 ∧ code e2388243053082 = 11184336075290 := by decide
theorem cert_e2388243053082 : check e2388243053082 [[]] .width = true := by decide
def e2388243236378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388243236378 : Closed e2388243236378 ∧ code e2388243236378 = 11184336258586 := by decide
theorem cert_e2388243236378 : check e2388243236378 [[]] .width = true := by decide
def e2388243239110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388243239110 : Closed e2388243239110 ∧ code e2388243239110 = 11184336261318 := by decide
theorem cert_e2388243239110 : check e2388243239110 [[]] .width = true := by decide
def e2388243441690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388243441690 : Closed e2388243441690 ∧ code e2388243441690 = 11184336463898 := by decide
theorem cert_e2388243441690 : check e2388243441690 [[]] .width = true := by decide
def e2388243483162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388243483162 : Closed e2388243483162 ∧ code e2388243483162 = 11184336505370 := by decide
theorem cert_e2388243483162 : check e2388243483162 [[]] .width = true := by decide
def e2388243490842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388243490842 : Closed e2388243490842 ∧ code e2388243490842 = 11184336513050 := by decide
theorem cert_e2388243490842 : check e2388243490842 [[]] .width = true := by decide
def e2388243495450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388243495450 : Closed e2388243495450 ∧ code e2388243495450 = 11184336517658 := by decide
theorem cert_e2388243495450 : check e2388243495450 [[]] .width = true := by decide
def e2388243908634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388243908634 : Closed e2388243908634 ∧ code e2388243908634 = 11184336930842 := by decide
theorem cert_e2388243908634 : check e2388243908634 [[]] .width = true := by decide
def e2388243910170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388243910170 : Closed e2388243910170 ∧ code e2388243910170 = 11184336932378 := by decide
theorem cert_e2388243910170 : check e2388243910170 [[]] .width = true := by decide
def e2388243914778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388243914778 : Closed e2388243914778 ∧ code e2388243914778 = 11184336936986 := by decide
theorem cert_e2388243914778 : check e2388243914778 [[]] .width = true := by decide
def e2388243914870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388243914870 : Closed e2388243914870 ∧ code e2388243914870 = 11184336937078 := by decide
theorem cert_e2388243914870 : check e2388243914870 [[]] .width = true := by decide
def e2388243915114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388243915114 : Closed e2388243915114 ∧ code e2388243915114 = 11184336937322 := by decide
theorem cert_e2388243915114 : check e2388243915114 [[]] .width = true := by decide
def e2388243915162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388243915162 : Closed e2388243915162 ∧ code e2388243915162 = 11184336937370 := by decide
theorem cert_e2388243915162 : check e2388243915162 [[]] .width = true := by decide
def e2388243919046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388243919046 : Closed e2388243919046 ∧ code e2388243919046 = 11184336941254 := by decide
theorem cert_e2388243919046 : check e2388243919046 [[]] .width = true := by decide
def e2388243931674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388243931674 : Closed e2388243931674 ∧ code e2388243931674 = 11184336953882 := by decide
theorem cert_e2388243931674 : check e2388243931674 [[]] .width = true := by decide
def e2388243933210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388243933210 : Closed e2388243933210 ∧ code e2388243933210 = 11184336955418 := by decide
theorem cert_e2388243933210 : check e2388243933210 [[]] .width = true := by decide
def e2388243939354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388243939354 : Closed e2388243939354 ∧ code e2388243939354 = 11184336961562 := by decide
theorem cert_e2388243939354 : check e2388243939354 [[]] .width = true := by decide
def e2388243939446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388243939446 : Closed e2388243939446 ∧ code e2388243939446 = 11184336961654 := by decide
theorem cert_e2388243939446 : check e2388243939446 [[]] .width = true := by decide
def e2388243939690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388243939690 : Closed e2388243939690 ∧ code e2388243939690 = 11184336961898 := by decide
theorem cert_e2388243939690 : check e2388243939690 [[]] .width = true := by decide
def e2388243939738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388243939738 : Closed e2388243939738 ∧ code e2388243939738 = 11184336961946 := by decide
theorem cert_e2388243939738 : check e2388243939738 [[]] .width = true := by decide
def e2388243940746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388243940746 : Closed e2388243940746 ∧ code e2388243940746 = 11184336962954 := by decide
theorem cert_e2388243940746 : check e2388243940746 [[]] .width = true := by decide
def e2388243940770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388243940770 : Closed e2388243940770 ∧ code e2388243940770 = 11184336962978 := by decide
theorem cert_e2388243940770 : check e2388243940770 [[]] .width = true := by decide
def e2388243940878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388243940878 : Closed e2388243940878 ∧ code e2388243940878 = 11184336963086 := by decide
theorem cert_e2388243940878 : check e2388243940878 [[]] .width = true := by decide
def e2388243940890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388243940890 : Closed e2388243940890 ∧ code e2388243940890 = 11184336963098 := by decide
theorem cert_e2388243940890 : check e2388243940890 [[]] .width = true := by decide
def e2388243940962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388243940962 : Closed e2388243940962 ∧ code e2388243940962 = 11184336963170 := by decide
theorem cert_e2388243940962 : check e2388243940962 [[]] .width = true := by decide
def e2388244576794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388244576794 : Closed e2388244576794 ∧ code e2388244576794 = 11184337599002 := by decide
theorem cert_e2388244576794 : check e2388244576794 [[]] .width = true := by decide
def e2388244612634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388244612634 : Closed e2388244612634 ∧ code e2388244612634 = 11184337634842 := by decide
theorem cert_e2388244612634 : check e2388244612634 [[]] .width = true := by decide
def e2388244615366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388244615366 : Closed e2388244615366 ∧ code e2388244615366 = 11184337637574 := by decide
theorem cert_e2388244615366 : check e2388244615366 [[]] .width = true := by decide
def e2388244662810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388244662810 : Closed e2388244662810 ∧ code e2388244662810 = 11184337685018 := by decide
theorem cert_e2388244662810 : check e2388244662810 [[]] .width = true := by decide
def e2388244670490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388244670490 : Closed e2388244670490 ∧ code e2388244670490 = 11184337692698 := by decide
theorem cert_e2388244670490 : check e2388244670490 [[]] .width = true := by decide
def e2388244675098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388244675098 : Closed e2388244675098 ∧ code e2388244675098 = 11184337697306 := by decide
theorem cert_e2388244675098 : check e2388244675098 [[]] .width = true := by decide
def e2388244687386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388244687386 : Closed e2388244687386 ∧ code e2388244687386 = 11184337709594 := by decide
theorem cert_e2388244687386 : check e2388244687386 [[]] .width = true := by decide
def e2388244695066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388244695066 : Closed e2388244695066 ∧ code e2388244695066 = 11184337717274 := by decide
theorem cert_e2388244695066 : check e2388244695066 [[]] .width = true := by decide
def e2388244696602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388244696602 : Closed e2388244696602 ∧ code e2388244696602 = 11184337718810 := by decide
theorem cert_e2388244696602 : check e2388244696602 [[]] .width = true := by decide
def e2388244701210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388244701210 : Closed e2388244701210 ∧ code e2388244701210 = 11184337723418 := by decide
theorem cert_e2388244701210 : check e2388244701210 [[]] .width = true := by decide
def e2388244701302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388244701302 : Closed e2388244701302 ∧ code e2388244701302 = 11184337723510 := by decide
theorem cert_e2388244701302 : check e2388244701302 [[]] .width = true := by decide
def e2388244701546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388244701546 : Closed e2388244701546 ∧ code e2388244701546 = 11184337723754 := by decide
theorem cert_e2388244701546 : check e2388244701546 [[]] .width = true := by decide
def e2388244701594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388244701594 : Closed e2388244701594 ∧ code e2388244701594 = 11184337723802 := by decide
theorem cert_e2388244701594 : check e2388244701594 [[]] .width = true := by decide
def e2388244705478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388244705478 : Closed e2388244705478 ∧ code e2388244705478 = 11184337727686 := by decide
theorem cert_e2388244705478 : check e2388244705478 [[]] .width = true := by decide
def e2388244718106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388244718106 : Closed e2388244718106 ∧ code e2388244718106 = 11184337740314 := by decide
theorem cert_e2388244718106 : check e2388244718106 [[]] .width = true := by decide
def e2388244719642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388244719642 : Closed e2388244719642 ∧ code e2388244719642 = 11184337741850 := by decide
theorem cert_e2388244719642 : check e2388244719642 [[]] .width = true := by decide
def e2388244725786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388244725786 : Closed e2388244725786 ∧ code e2388244725786 = 11184337747994 := by decide
theorem cert_e2388244725786 : check e2388244725786 [[]] .width = true := by decide
def e2388244725878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388244725878 : Closed e2388244725878 ∧ code e2388244725878 = 11184337748086 := by decide
theorem cert_e2388244725878 : check e2388244725878 [[]] .width = true := by decide
def e2388244726122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388244726122 : Closed e2388244726122 ∧ code e2388244726122 = 11184337748330 := by decide
theorem cert_e2388244726122 : check e2388244726122 [[]] .width = true := by decide
def e2388244726170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388244726170 : Closed e2388244726170 ∧ code e2388244726170 = 11184337748378 := by decide
theorem cert_e2388244726170 : check e2388244726170 [[]] .width = true := by decide
def e2388244727178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388244727178 : Closed e2388244727178 ∧ code e2388244727178 = 11184337749386 := by decide
theorem cert_e2388244727178 : check e2388244727178 [[]] .width = true := by decide
def e2388244727202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388244727202 : Closed e2388244727202 ∧ code e2388244727202 = 11184337749410 := by decide
theorem cert_e2388244727202 : check e2388244727202 [[]] .width = true := by decide
def e2388244727310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388244727310 : Closed e2388244727310 ∧ code e2388244727310 = 11184337749518 := by decide
theorem cert_e2388244727310 : check e2388244727310 [[]] .width = true := by decide
def e2388244727322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388244727322 : Closed e2388244727322 ∧ code e2388244727322 = 11184337749530 := by decide
theorem cert_e2388244727322 : check e2388244727322 [[]] .width = true := by decide
def e2388244727394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388244727394 : Closed e2388244727394 ∧ code e2388244727394 = 11184337749602 := by decide
theorem cert_e2388244727394 : check e2388244727394 [[]] .width = true := by decide
def e2388254451738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388254451738 : Closed e2388254451738 ∧ code e2388254451738 = 11184347473946 := by decide
theorem cert_e2388254451738 : check e2388254451738 [[]] .width = true := by decide
def e2388254484506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388254484506 : Closed e2388254484506 ∧ code e2388254484506 = 11184347506714 := by decide
theorem cert_e2388254484506 : check e2388254484506 [[]] .width = true := by decide
def e2388256381466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256381466 : Closed e2388256381466 ∧ code e2388256381466 = 11184349403674 := by decide
theorem cert_e2388256381466 : check e2388256381466 [[]] .width = true := by decide
def e2388256450586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388256450586 : Closed e2388256450586 ∧ code e2388256450586 = 11184349472794 := by decide
theorem cert_e2388256450586 : check e2388256450586 [[]] .width = true := by decide
def e2388256459290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256459290 : Closed e2388256459290 ∧ code e2388256459290 = 11184349481498 := by decide
theorem cert_e2388256459290 : check e2388256459290 [[]] .width = true := by decide
def e2388256466970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388256466970 : Closed e2388256466970 ∧ code e2388256466970 = 11184349489178 := by decide
theorem cert_e2388256466970 : check e2388256466970 [[]] .width = true := by decide
def e2388256471578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256471578 : Closed e2388256471578 ∧ code e2388256471578 = 11184349493786 := by decide
theorem cert_e2388256471578 : check e2388256471578 [[]] .width = true := by decide
def e2388256479770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256479770 : Closed e2388256479770 ∧ code e2388256479770 = 11184349501978 := by decide
theorem cert_e2388256479770 : check e2388256479770 [[]] .width = true := by decide
def e2388256500250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256500250 : Closed e2388256500250 ∧ code e2388256500250 = 11184349522458 := by decide
theorem cert_e2388256500250 : check e2388256500250 [[]] .width = true := by decide
def e2388256524826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256524826 : Closed e2388256524826 ∧ code e2388256524826 = 11184349547034 := by decide
theorem cert_e2388256524826 : check e2388256524826 [[]] .width = true := by decide
def e2388256532506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388256532506 : Closed e2388256532506 ∧ code e2388256532506 = 11184349554714 := by decide
theorem cert_e2388256532506 : check e2388256532506 [[]] .width = true := by decide
def e2388256537114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256537114 : Closed e2388256537114 ∧ code e2388256537114 = 11184349559322 := by decide
theorem cert_e2388256537114 : check e2388256537114 [[]] .width = true := by decide
def e2388256549402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256549402 : Closed e2388256549402 ∧ code e2388256549402 = 11184349571610 := by decide
private def t_e2388256549402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388256549402 : ¬ IsSelfInterpreter e2388256549402 :=
  wSource (t := t_e2388256549402) (replay_sound (ps := []) (t := e2388256549402) (by decide)) (by decide)
def e2388256578074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256578074 : Closed e2388256578074 ∧ code e2388256578074 = 11184349600282 := by decide
theorem cert_e2388256578074 : check e2388256578074 [[]] .width = true := by decide
def e2388256582170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256582170 : Closed e2388256582170 ∧ code e2388256582170 = 11184349604378 := by decide
private def t_e2388256582170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388256582170 : ¬ IsSelfInterpreter e2388256582170 :=
  wSource (t := t_e2388256582170) (replay_sound (ps := []) (t := e2388256582170) (by decide)) (by decide)
def e2388256651802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256651802 : Closed e2388256651802 ∧ code e2388256651802 = 11184349674010 := by decide
theorem cert_e2388256651802 : check e2388256651802 [[]] .width = true := by decide
def e2388256736794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256736794 : Closed e2388256736794 ∧ code e2388256736794 = 11184349759002 := by decide
theorem cert_e2388256736794 : check e2388256736794 [[]] .width = true := by decide
def e2388256739526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388256739526 : Closed e2388256739526 ∧ code e2388256739526 = 11184349761734 := by decide
theorem cert_e2388256739526 : check e2388256739526 [[]] .width = true := by decide
def e2388256843802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388256843802 : Closed e2388256843802 ∧ code e2388256843802 = 11184349866010 := by decide
theorem cert_e2388256843802 : check e2388256843802 [[]] .width = true := by decide
def e2388256852506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256852506 : Closed e2388256852506 ∧ code e2388256852506 = 11184349874714 := by decide
theorem cert_e2388256852506 : check e2388256852506 [[]] .width = true := by decide
def e2388256860186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388256860186 : Closed e2388256860186 ∧ code e2388256860186 = 11184349882394 := by decide
theorem cert_e2388256860186 : check e2388256860186 [[]] .width = true := by decide
def e2388256864794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256864794 : Closed e2388256864794 ∧ code e2388256864794 = 11184349887002 := by decide
theorem cert_e2388256864794 : check e2388256864794 [[]] .width = true := by decide
def e2388256872986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388256872986 : Closed e2388256872986 ∧ code e2388256872986 = 11184349895194 := by decide
theorem cert_e2388256872986 : check e2388256872986 [[]] .width = true := by decide
def e2388257015834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388257015834 : Closed e2388257015834 ∧ code e2388257015834 = 11184350038042 := by decide
theorem cert_e2388257015834 : check e2388257015834 [[]] .width = true := by decide
def e2388257017370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257017370 : Closed e2388257017370 ∧ code e2388257017370 = 11184350039578 := by decide
theorem cert_e2388257017370 : check e2388257017370 [[]] .width = true := by decide
def e2388257021978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388257021978 : Closed e2388257021978 ∧ code e2388257021978 = 11184350044186 := by decide
theorem cert_e2388257021978 : check e2388257021978 [[]] .width = true := by decide
def e2388257022070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388257022070 : Closed e2388257022070 ∧ code e2388257022070 = 11184350044278 := by decide
theorem cert_e2388257022070 : check e2388257022070 [[]] .width = true := by decide
def e2388257022314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388257022314 : Closed e2388257022314 ∧ code e2388257022314 = 11184350044522 := by decide
theorem cert_e2388257022314 : check e2388257022314 [[]] .width = true := by decide
def e2388257022362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388257022362 : Closed e2388257022362 ∧ code e2388257022362 = 11184350044570 := by decide
theorem cert_e2388257022362 : check e2388257022362 [[]] .width = true := by decide
def e2388257026246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388257026246 : Closed e2388257026246 ∧ code e2388257026246 = 11184350048454 := by decide
theorem cert_e2388257026246 : check e2388257026246 [[]] .width = true := by decide
def e2388257038874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257038874 : Closed e2388257038874 ∧ code e2388257038874 = 11184350061082 := by decide
theorem cert_e2388257038874 : check e2388257038874 [[]] .width = true := by decide
def e2388257040410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388257040410 : Closed e2388257040410 ∧ code e2388257040410 = 11184350062618 := by decide
theorem cert_e2388257040410 : check e2388257040410 [[]] .width = true := by decide
def e2388257046554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388257046554 : Closed e2388257046554 ∧ code e2388257046554 = 11184350068762 := by decide
theorem cert_e2388257046554 : check e2388257046554 [[]] .width = true := by decide
def e2388257046646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388257046646 : Closed e2388257046646 ∧ code e2388257046646 = 11184350068854 := by decide
theorem cert_e2388257046646 : check e2388257046646 [[]] .width = true := by decide
def e2388257046890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388257046890 : Closed e2388257046890 ∧ code e2388257046890 = 11184350069098 := by decide
theorem cert_e2388257046890 : check e2388257046890 [[]] .width = true := by decide
def e2388257046938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388257046938 : Closed e2388257046938 ∧ code e2388257046938 = 11184350069146 := by decide
theorem cert_e2388257046938 : check e2388257046938 [[]] .width = true := by decide
def e2388257047946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388257047946 : Closed e2388257047946 ∧ code e2388257047946 = 11184350070154 := by decide
theorem cert_e2388257047946 : check e2388257047946 [[]] .width = true := by decide
def e2388257047970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388257047970 : Closed e2388257047970 ∧ code e2388257047970 = 11184350070178 := by decide
theorem cert_e2388257047970 : check e2388257047970 [[]] .width = true := by decide
def e2388257048078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388257048078 : Closed e2388257048078 ∧ code e2388257048078 = 11184350070286 := by decide
theorem cert_e2388257048078 : check e2388257048078 [[]] .width = true := by decide
def e2388257048090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388257048090 : Closed e2388257048090 ∧ code e2388257048090 = 11184350070298 := by decide
theorem cert_e2388257048090 : check e2388257048090 [[]] .width = true := by decide
def e2388257048162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388257048162 : Closed e2388257048162 ∧ code e2388257048162 = 11184350070370 := by decide
theorem cert_e2388257048162 : check e2388257048162 [[]] .width = true := by decide
def e2388257159706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257159706 : Closed e2388257159706 ∧ code e2388257159706 = 11184350181914 := by decide
theorem cert_e2388257159706 : check e2388257159706 [[]] .width = true := by decide
def e2388257195546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257195546 : Closed e2388257195546 ∧ code e2388257195546 = 11184350217754 := by decide
theorem cert_e2388257195546 : check e2388257195546 [[]] .width = true := by decide
def e2388257198278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388257198278 : Closed e2388257198278 ∧ code e2388257198278 = 11184350220486 := by decide
theorem cert_e2388257198278 : check e2388257198278 [[]] .width = true := by decide
def e2388257245722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257245722 : Closed e2388257245722 ∧ code e2388257245722 = 11184350267930 := by decide
theorem cert_e2388257245722 : check e2388257245722 [[]] .width = true := by decide
def e2388257253402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388257253402 : Closed e2388257253402 ∧ code e2388257253402 = 11184350275610 := by decide
theorem cert_e2388257253402 : check e2388257253402 [[]] .width = true := by decide
def e2388257258010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257258010 : Closed e2388257258010 ∧ code e2388257258010 = 11184350280218 := by decide
theorem cert_e2388257258010 : check e2388257258010 [[]] .width = true := by decide
def e2388257270298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257270298 : Closed e2388257270298 ∧ code e2388257270298 = 11184350292506 := by decide
theorem cert_e2388257270298 : check e2388257270298 [[]] .width = true := by decide
def e2388257277978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388257277978 : Closed e2388257277978 ∧ code e2388257277978 = 11184350300186 := by decide
theorem cert_e2388257277978 : check e2388257277978 [[]] .width = true := by decide
def e2388257279514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257279514 : Closed e2388257279514 ∧ code e2388257279514 = 11184350301722 := by decide
theorem cert_e2388257279514 : check e2388257279514 [[]] .width = true := by decide
def e2388257284122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388257284122 : Closed e2388257284122 ∧ code e2388257284122 = 11184350306330 := by decide
theorem cert_e2388257284122 : check e2388257284122 [[]] .width = true := by decide
def e2388257284214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388257284214 : Closed e2388257284214 ∧ code e2388257284214 = 11184350306422 := by decide
theorem cert_e2388257284214 : check e2388257284214 [[]] .width = true := by decide
def e2388257284458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388257284458 : Closed e2388257284458 ∧ code e2388257284458 = 11184350306666 := by decide
theorem cert_e2388257284458 : check e2388257284458 [[]] .width = true := by decide
def e2388257284506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388257284506 : Closed e2388257284506 ∧ code e2388257284506 = 11184350306714 := by decide
theorem cert_e2388257284506 : check e2388257284506 [[]] .width = true := by decide
def e2388257288390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388257288390 : Closed e2388257288390 ∧ code e2388257288390 = 11184350310598 := by decide
theorem cert_e2388257288390 : check e2388257288390 [[]] .width = true := by decide
def e2388257301018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257301018 : Closed e2388257301018 ∧ code e2388257301018 = 11184350323226 := by decide
theorem cert_e2388257301018 : check e2388257301018 [[]] .width = true := by decide
def e2388257302554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388257302554 : Closed e2388257302554 ∧ code e2388257302554 = 11184350324762 := by decide
theorem cert_e2388257302554 : check e2388257302554 [[]] .width = true := by decide
def e2388257308698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388257308698 : Closed e2388257308698 ∧ code e2388257308698 = 11184350330906 := by decide
theorem cert_e2388257308698 : check e2388257308698 [[]] .width = true := by decide
def e2388257308790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388257308790 : Closed e2388257308790 ∧ code e2388257308790 = 11184350330998 := by decide
theorem cert_e2388257308790 : check e2388257308790 [[]] .width = true := by decide
def e2388257309034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388257309034 : Closed e2388257309034 ∧ code e2388257309034 = 11184350331242 := by decide
theorem cert_e2388257309034 : check e2388257309034 [[]] .width = true := by decide
def e2388257309082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388257309082 : Closed e2388257309082 ∧ code e2388257309082 = 11184350331290 := by decide
theorem cert_e2388257309082 : check e2388257309082 [[]] .width = true := by decide
def e2388257310090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388257310090 : Closed e2388257310090 ∧ code e2388257310090 = 11184350332298 := by decide
theorem cert_e2388257310090 : check e2388257310090 [[]] .width = true := by decide
def e2388257310114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388257310114 : Closed e2388257310114 ∧ code e2388257310114 = 11184350332322 := by decide
theorem cert_e2388257310114 : check e2388257310114 [[]] .width = true := by decide
def e2388257310222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388257310222 : Closed e2388257310222 ∧ code e2388257310222 = 11184350332430 := by decide
theorem cert_e2388257310222 : check e2388257310222 [[]] .width = true := by decide
def e2388257310234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388257310234 : Closed e2388257310234 ∧ code e2388257310234 = 11184350332442 := by decide
theorem cert_e2388257310234 : check e2388257310234 [[]] .width = true := by decide
def e2388257310306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388257310306 : Closed e2388257310306 ∧ code e2388257310306 = 11184350332514 := by decide
theorem cert_e2388257310306 : check e2388257310306 [[]] .width = true := by decide
def e2388257462810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257462810 : Closed e2388257462810 ∧ code e2388257462810 = 11184350485018 := by decide
theorem cert_e2388257462810 : check e2388257462810 [[]] .width = true := by decide
def e2388257466906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388257466906 : Closed e2388257466906 ∧ code e2388257466906 = 11184350489114 := by decide
theorem cert_e2388257466906 : check e2388257466906 [[]] .width = true := by decide
def e2388273248282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273248282 : Closed e2388273248282 ∧ code e2388273248282 = 11184366270490 := by decide
theorem cert_e2388273248282 : check e2388273248282 [[]] .width = true := by decide
def e2388273256474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273256474 : Closed e2388273256474 ∧ code e2388273256474 = 11184366278682 := by decide
theorem cert_e2388273256474 : check e2388273256474 [[]] .width = true := by decide
def e2388273313818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273313818 : Closed e2388273313818 ∧ code e2388273313818 = 11184366336026 := by decide
theorem cert_e2388273313818 : check e2388273313818 [[]] .width = true := by decide
def e2388273326106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273326106 : Closed e2388273326106 ∧ code e2388273326106 = 11184366348314 := by decide
theorem cert_e2388273326106 : check e2388273326106 [[]] .width = true := by decide
def e2388273354778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273354778 : Closed e2388273354778 ∧ code e2388273354778 = 11184366376986 := by decide
theorem cert_e2388273354778 : check e2388273354778 [[]] .width = true := by decide
def e2388273358874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273358874 : Closed e2388273358874 ∧ code e2388273358874 = 11184366381082 := by decide
theorem cert_e2388273358874 : check e2388273358874 [[]] .width = true := by decide
def e2388273641498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273641498 : Closed e2388273641498 ∧ code e2388273641498 = 11184366663706 := by decide
theorem cert_e2388273641498 : check e2388273641498 [[]] .width = true := by decide
def e2388273649690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388273649690 : Closed e2388273649690 ∧ code e2388273649690 = 11184366671898 := by decide
theorem cert_e2388273649690 : check e2388273649690 [[]] .width = true := by decide
def e2388274034714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388274034714 : Closed e2388274034714 ∧ code e2388274034714 = 11184367056922 := by decide
theorem cert_e2388274034714 : check e2388274034714 [[]] .width = true := by decide
def e2388274047002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388274047002 : Closed e2388274047002 ∧ code e2388274047002 = 11184367069210 := by decide
theorem cert_e2388274047002 : check e2388274047002 [[]] .width = true := by decide
def e2388274239514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388274239514 : Closed e2388274239514 ∧ code e2388274239514 = 11184367261722 := by decide
theorem cert_e2388274239514 : check e2388274239514 [[]] .width = true := by decide
def e2388274243610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388274243610 : Closed e2388274243610 ∧ code e2388274243610 = 11184367265818 := by decide
theorem cert_e2388274243610 : check e2388274243610 [[]] .width = true := by decide
def e2388337405294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2388337405294 : Closed e2388337405294 ∧ code e2388337405294 = 11184430427502 := by decide
theorem cert_e2388337405294 : check e2388337405294 [[],[.left],[]] .smaller = true := by decide
def e2388337405302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2388337405302 : Closed e2388337405302 ∧ code e2388337405302 = 11184430427510 := by decide
theorem cert_e2388337405302 : check e2388337405302 [[],[.left],[]] .smaller = true := by decide
def e2388337405358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2388337405358 : Closed e2388337405358 ∧ code e2388337405358 = 11184430427566 := by decide
theorem cert_e2388337405358 : check e2388337405358 [[],[.left],[]] .smaller = true := by decide
def e2388337405370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2388337405370 : Closed e2388337405370 ∧ code e2388337405370 = 11184430427578 := by decide
theorem cert_e2388337405370 : check e2388337405370 [[],[.left],[]] .smaller = true := by decide
def e2388337405398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2388337405398 : Closed e2388337405398 ∧ code e2388337405398 = 11184430427606 := by decide
theorem cert_e2388337405398 : check e2388337405398 [[],[.left],[]] .smaller = true := by decide
def e2388337405402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2388337405402 : Closed e2388337405402 ∧ code e2388337405402 = 11184430427610 := by decide
theorem cert_e2388337405402 : check e2388337405402 [[],[.left],[]] .smaller = true := by decide
def e2388337405614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2388337405614 : Closed e2388337405614 ∧ code e2388337405614 = 11184430427822 := by decide
theorem cert_e2388337405614 : check e2388337405614 [[],[.left],[]] .smaller = true := by decide
def e2388337405626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2388337405626 : Closed e2388337405626 ∧ code e2388337405626 = 11184430427834 := by decide
theorem cert_e2388337405626 : check e2388337405626 [[],[.left],[]] .smaller = true := by decide
def e2388337405674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2388337405674 : Closed e2388337405674 ∧ code e2388337405674 = 11184430427882 := by decide
theorem cert_e2388337405674 : check e2388337405674 [[],[.left],[]] .smaller = true := by decide
def e2388337405782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2388337405782 : Closed e2388337405782 ∧ code e2388337405782 = 11184430427990 := by decide
theorem cert_e2388337405782 : check e2388337405782 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2388242917914
#print axioms Blc.Floor43.cert_e2388256549402
#print axioms Blc.Floor43.cert_e2388256582170
