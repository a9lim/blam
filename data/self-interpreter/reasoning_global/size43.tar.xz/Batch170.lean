import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262376835810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2262376835810 : Closed e2262376835810 ∧ code e2262376835810 = 11058469858018 := by decide
theorem cert_e2262376835810 : check e2262376835810 [[],[.under]] .three = true := by decide
def e2262376835822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2262376835822 : Closed e2262376835822 ∧ code e2262376835822 = 11058469858030 := by decide
theorem cert_e2262376835822 : check e2262376835822 [[],[.under]] .three = true := by decide
def e2262376835950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2262376835950 : Closed e2262376835950 ∧ code e2262376835950 = 11058469858158 := by decide
theorem cert_e2262376835950 : check e2262376835950 [[],[.under]] .three = true := by decide
def e2262376835958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2262376835958 : Closed e2262376835958 ∧ code e2262376835958 = 11058469858166 := by decide
theorem cert_e2262376835958 : check e2262376835958 [[],[.under]] .three = true := by decide
def e2262376835978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376835978 : Closed e2262376835978 ∧ code e2262376835978 = 11058469858186 := by decide
theorem cert_e2262376835978 : check e2262376835978 [[],[.under]] .three = true := by decide
def e2262376836002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376836002 : Closed e2262376836002 ∧ code e2262376836002 = 11058469858210 := by decide
theorem cert_e2262376836002 : check e2262376836002 [[],[.under]] .three = true := by decide
def e2262376836014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2262376836014 : Closed e2262376836014 ∧ code e2262376836014 = 11058469858222 := by decide
theorem cert_e2262376836014 : check e2262376836014 [[],[.under]] .three = true := by decide
def e2262376836022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2262376836022 : Closed e2262376836022 ∧ code e2262376836022 = 11058469858230 := by decide
theorem cert_e2262376836022 : check e2262376836022 [[],[.under]] .three = true := by decide
def e2262376836026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2262376836026 : Closed e2262376836026 ∧ code e2262376836026 = 11058469858234 := by decide
theorem cert_e2262376836026 : check e2262376836026 [[],[.under]] .three = true := by decide
def e2262376836462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2262376836462 : Closed e2262376836462 ∧ code e2262376836462 = 11058469858670 := by decide
theorem cert_e2262376836462 : check e2262376836462 [[],[.under]] .three = true := by decide
def e2262376836470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2262376836470 : Closed e2262376836470 ∧ code e2262376836470 = 11058469858678 := by decide
theorem cert_e2262376836470 : check e2262376836470 [[],[.under]] .three = true := by decide
def e2262376836526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2262376836526 : Closed e2262376836526 ∧ code e2262376836526 = 11058469858734 := by decide
theorem cert_e2262376836526 : check e2262376836526 [[],[.under]] .three = true := by decide
def e2262376836538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2262376836538 : Closed e2262376836538 ∧ code e2262376836538 = 11058469858746 := by decide
theorem cert_e2262376836538 : check e2262376836538 [[],[.under]] .three = true := by decide
def e2262376836566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2262376836566 : Closed e2262376836566 ∧ code e2262376836566 = 11058469858774 := by decide
theorem cert_e2262376836566 : check e2262376836566 [[],[.under]] .three = true := by decide
def e2262376836570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2262376836570 : Closed e2262376836570 ∧ code e2262376836570 = 11058469858778 := by decide
theorem cert_e2262376836570 : check e2262376836570 [[],[.under]] .three = true := by decide
def e2262376836650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2262376836650 : Closed e2262376836650 ∧ code e2262376836650 = 11058469858858 := by decide
theorem cert_e2262376836650 : check e2262376836650 [[],[.under]] .three = true := by decide
def e2262376836746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376836746 : Closed e2262376836746 ∧ code e2262376836746 = 11058469858954 := by decide
theorem cert_e2262376836746 : check e2262376836746 [[],[.under]] .three = true := by decide
def e2262376836770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376836770 : Closed e2262376836770 ∧ code e2262376836770 = 11058469858978 := by decide
theorem cert_e2262376836770 : check e2262376836770 [[],[.under]] .three = true := by decide
def e2262376836782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2262376836782 : Closed e2262376836782 ∧ code e2262376836782 = 11058469858990 := by decide
theorem cert_e2262376836782 : check e2262376836782 [[],[.under]] .three = true := by decide
def e2262376836790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2262376836790 : Closed e2262376836790 ∧ code e2262376836790 = 11058469858998 := by decide
theorem cert_e2262376836790 : check e2262376836790 [[],[.under]] .three = true := by decide
def e2262376836794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2262376836794 : Closed e2262376836794 ∧ code e2262376836794 = 11058469859002 := by decide
theorem cert_e2262376836794 : check e2262376836794 [[],[.under]] .three = true := by decide
def e2262376836822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2262376836822 : Closed e2262376836822 ∧ code e2262376836822 = 11058469859030 := by decide
theorem cert_e2262376836822 : check e2262376836822 [[],[.under]] .three = true := by decide
def e2262376836826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2262376836826 : Closed e2262376836826 ∧ code e2262376836826 = 11058469859034 := by decide
theorem cert_e2262376836826 : check e2262376836826 [[],[.under]] .three = true := by decide
def e2262376836842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2262376836842 : Closed e2262376836842 ∧ code e2262376836842 = 11058469859050 := by decide
theorem cert_e2262376836842 : check e2262376836842 [[],[.under]] .three = true := by decide
def e2262376837462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2262376837462 : Closed e2262376837462 ∧ code e2262376837462 = 11058469859670 := by decide
theorem cert_e2262376837462 : check e2262376837462 [[],[.under]] .three = true := by decide
def e2262376837466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2262376837466 : Closed e2262376837466 ∧ code e2262376837466 = 11058469859674 := by decide
theorem cert_e2262376837466 : check e2262376837466 [[],[.under]] .three = true := by decide
def e2262376837482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2262376837482 : Closed e2262376837482 ∧ code e2262376837482 = 11058469859690 := by decide
theorem cert_e2262376837482 : check e2262376837482 [[],[.under]] .three = true := by decide
def e2262376838230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2262376838230 : Closed e2262376838230 ∧ code e2262376838230 = 11058469860438 := by decide
theorem cert_e2262376838230 : check e2262376838230 [[],[.under]] .three = true := by decide
def e2262376838234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2262376838234 : Closed e2262376838234 ∧ code e2262376838234 = 11058469860442 := by decide
theorem cert_e2262376838234 : check e2262376838234 [[],[.under]] .three = true := by decide
def e2262376838422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2262376838422 : Closed e2262376838422 ∧ code e2262376838422 = 11058469860630 := by decide
theorem cert_e2262376838422 : check e2262376838422 [[],[.under]] .three = true := by decide
def e2262376838498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2262376838498 : Closed e2262376838498 ∧ code e2262376838498 = 11058469860706 := by decide
theorem cert_e2262376838498 : check e2262376838498 [[],[.under]] .three = true := by decide
def e2262376838510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2262376838510 : Closed e2262376838510 ∧ code e2262376838510 = 11058469860718 := by decide
theorem cert_e2262376838510 : check e2262376838510 [[],[.under]] .three = true := by decide
def e2262376838518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2262376838518 : Closed e2262376838518 ∧ code e2262376838518 = 11058469860726 := by decide
theorem cert_e2262376838518 : check e2262376838518 [[],[.under]] .three = true := by decide
def e2262376838538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376838538 : Closed e2262376838538 ∧ code e2262376838538 = 11058469860746 := by decide
theorem cert_e2262376838538 : check e2262376838538 [[],[.under]] .three = true := by decide
def e2262376838562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376838562 : Closed e2262376838562 ∧ code e2262376838562 = 11058469860770 := by decide
theorem cert_e2262376838562 : check e2262376838562 [[],[.under]] .three = true := by decide
def e2262376838574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2262376838574 : Closed e2262376838574 ∧ code e2262376838574 = 11058469860782 := by decide
theorem cert_e2262376838574 : check e2262376838574 [[],[.under]] .three = true := by decide
def e2262376838582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2262376838582 : Closed e2262376838582 ∧ code e2262376838582 = 11058469860790 := by decide
theorem cert_e2262376838582 : check e2262376838582 [[],[.under]] .three = true := by decide
def e2262376838586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2262376838586 : Closed e2262376838586 ∧ code e2262376838586 = 11058469860794 := by decide
theorem cert_e2262376838586 : check e2262376838586 [[],[.under]] .three = true := by decide
def e2262376838614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2262376838614 : Closed e2262376838614 ∧ code e2262376838614 = 11058469860822 := by decide
theorem cert_e2262376838614 : check e2262376838614 [[],[.under]] .three = true := by decide
def e2262376838618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2262376838618 : Closed e2262376838618 ∧ code e2262376838618 = 11058469860826 := by decide
theorem cert_e2262376838618 : check e2262376838618 [[],[.under]] .three = true := by decide
def e2262376838698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2262376838698 : Closed e2262376838698 ∧ code e2262376838698 = 11058469860906 := by decide
theorem cert_e2262376838698 : check e2262376838698 [[],[.under]] .three = true := by decide
def e2262376838794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376838794 : Closed e2262376838794 ∧ code e2262376838794 = 11058469861002 := by decide
theorem cert_e2262376838794 : check e2262376838794 [[],[.under]] .three = true := by decide
def e2262376838818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376838818 : Closed e2262376838818 ∧ code e2262376838818 = 11058469861026 := by decide
theorem cert_e2262376838818 : check e2262376838818 [[],[.under]] .three = true := by decide
def e2262376838830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2262376838830 : Closed e2262376838830 ∧ code e2262376838830 = 11058469861038 := by decide
theorem cert_e2262376838830 : check e2262376838830 [[],[.under]] .three = true := by decide
def e2262376838838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2262376838838 : Closed e2262376838838 ∧ code e2262376838838 = 11058469861046 := by decide
theorem cert_e2262376838838 : check e2262376838838 [[],[.under]] .three = true := by decide
def e2262376838842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2262376838842 : Closed e2262376838842 ∧ code e2262376838842 = 11058469861050 := by decide
theorem cert_e2262376838842 : check e2262376838842 [[],[.under]] .three = true := by decide
def e2262376838870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2262376838870 : Closed e2262376838870 ∧ code e2262376838870 = 11058469861078 := by decide
theorem cert_e2262376838870 : check e2262376838870 [[],[.under]] .three = true := by decide
def e2262376838874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2262376838874 : Closed e2262376838874 ∧ code e2262376838874 = 11058469861082 := by decide
theorem cert_e2262376838874 : check e2262376838874 [[],[.under]] .three = true := by decide
def e2262376838890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2262376838890 : Closed e2262376838890 ∧ code e2262376838890 = 11058469861098 := by decide
theorem cert_e2262376838890 : check e2262376838890 [[],[.under]] .three = true := by decide
def e2262376838998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2262376838998 : Closed e2262376838998 ∧ code e2262376838998 = 11058469861206 := by decide
private def t_e2262376838998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem cert_e2262376838998 : ¬ IsSelfInterpreter e2262376838998 :=
  wSource (t := t_e2262376838998) (replay_sound (ps := []) (t := e2262376838998) (by decide)) (by decide)
def e2262376839002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2262376839002 : Closed e2262376839002 ∧ code e2262376839002 = 11058469861210 := by decide
private def t_e2262376839002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem cert_e2262376839002 : ¬ IsSelfInterpreter e2262376839002 :=
  wSource (t := t_e2262376839002) (replay_sound (ps := []) (t := e2262376839002) (by decide)) (by decide)
def e2262376839018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2262376839018 : Closed e2262376839018 ∧ code e2262376839018 = 11058469861226 := by decide
private def t_e2262376839018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem cert_e2262376839018 : ¬ IsSelfInterpreter e2262376839018 :=
  wSource (t := t_e2262376839018) (replay_sound (ps := []) (t := e2262376839018) (by decide)) (by decide)
def e2262376843118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2262376843118 : Closed e2262376843118 ∧ code e2262376843118 = 11058469865326 := by decide
theorem cert_e2262376843118 : check e2262376843118 [[],[.under]] .three = true := by decide
def e2262376843126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2262376843126 : Closed e2262376843126 ∧ code e2262376843126 = 11058469865334 := by decide
theorem cert_e2262376843126 : check e2262376843126 [[],[.under]] .three = true := by decide
def e2262376843182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e2262376843182 : Closed e2262376843182 ∧ code e2262376843182 = 11058469865390 := by decide
theorem cert_e2262376843182 : check e2262376843182 [[],[.under]] .three = true := by decide
def e2262376843194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e2262376843194 : Closed e2262376843194 ∧ code e2262376843194 = 11058469865402 := by decide
theorem cert_e2262376843194 : check e2262376843194 [[],[.under]] .three = true := by decide
def e2262376843222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))
theorem wire_e2262376843222 : Closed e2262376843222 ∧ code e2262376843222 = 11058469865430 := by decide
theorem cert_e2262376843222 : check e2262376843222 [[],[.under]] .three = true := by decide
def e2262376843226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))
theorem wire_e2262376843226 : Closed e2262376843226 ∧ code e2262376843226 = 11058469865434 := by decide
theorem cert_e2262376843226 : check e2262376843226 [[],[.under]] .three = true := by decide
def e2262376844654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2262376844654 : Closed e2262376844654 ∧ code e2262376844654 = 11058469866862 := by decide
theorem cert_e2262376844654 : check e2262376844654 [[],[.under]] .three = true := by decide
def e2262376844662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2262376844662 : Closed e2262376844662 ∧ code e2262376844662 = 11058469866870 := by decide
theorem cert_e2262376844662 : check e2262376844662 [[],[.under]] .three = true := by decide
def e2262376846190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2262376846190 : Closed e2262376846190 ∧ code e2262376846190 = 11058469868398 := by decide
theorem cert_e2262376846190 : check e2262376846190 [[],[.under]] .three = true := by decide
def e2262376846198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2262376846198 : Closed e2262376846198 ∧ code e2262376846198 = 11058469868406 := by decide
theorem cert_e2262376846198 : check e2262376846198 [[],[.under]] .three = true := by decide
def e2262376846254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2262376846254 : Closed e2262376846254 ∧ code e2262376846254 = 11058469868462 := by decide
theorem cert_e2262376846254 : check e2262376846254 [[],[.under]] .three = true := by decide
def e2262376846266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2262376846266 : Closed e2262376846266 ∧ code e2262376846266 = 11058469868474 := by decide
theorem cert_e2262376846266 : check e2262376846266 [[],[.under]] .three = true := by decide
def e2262376846294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2262376846294 : Closed e2262376846294 ∧ code e2262376846294 = 11058469868502 := by decide
theorem cert_e2262376846294 : check e2262376846294 [[],[.under]] .three = true := by decide
def e2262376846298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2262376846298 : Closed e2262376846298 ∧ code e2262376846298 = 11058469868506 := by decide
theorem cert_e2262376846298 : check e2262376846298 [[],[.under]] .three = true := by decide
def e2262376846574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376846574 : Closed e2262376846574 ∧ code e2262376846574 = 11058469868782 := by decide
theorem cert_e2262376846574 : check e2262376846574 [[],[.under]] .three = true := by decide
def e2262376846582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376846582 : Closed e2262376846582 ∧ code e2262376846582 = 11058469868790 := by decide
theorem cert_e2262376846582 : check e2262376846582 [[],[.under]] .three = true := by decide
def e2262376846958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376846958 : Closed e2262376846958 ∧ code e2262376846958 = 11058469869166 := by decide
theorem cert_e2262376846958 : check e2262376846958 [[],[.under]] .three = true := by decide
def e2262376846970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376846970 : Closed e2262376846970 ∧ code e2262376846970 = 11058469869178 := by decide
theorem cert_e2262376846970 : check e2262376846970 [[],[.under]] .three = true := by decide
def e2262376847158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376847158 : Closed e2262376847158 ∧ code e2262376847158 = 11058469869366 := by decide
theorem cert_e2262376847158 : check e2262376847158 [[],[.under]] .three = true := by decide
def e2262376847162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376847162 : Closed e2262376847162 ∧ code e2262376847162 = 11058469869370 := by decide
theorem cert_e2262376847162 : check e2262376847162 [[],[.under]] .three = true := by decide
def e2262376847598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2262376847598 : Closed e2262376847598 ∧ code e2262376847598 = 11058469869806 := by decide
theorem cert_e2262376847598 : check e2262376847598 [[],[.under]] .three = true := by decide
def e2262376847606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2262376847606 : Closed e2262376847606 ∧ code e2262376847606 = 11058469869814 := by decide
theorem cert_e2262376847606 : check e2262376847606 [[],[.under]] .three = true := by decide
def e2262376848158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2262376848158 : Closed e2262376848158 ∧ code e2262376848158 = 11058469870366 := by decide
theorem cert_e2262376848158 : check e2262376848158 [[],[.under]] .three = true := by decide
def e2262376848270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2262376848270 : Closed e2262376848270 ∧ code e2262376848270 = 11058469870478 := by decide
theorem cert_e2262376848270 : check e2262376848270 [[],[.under]] .three = true := by decide
def e2262376848494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2262376848494 : Closed e2262376848494 ∧ code e2262376848494 = 11058469870702 := by decide
theorem cert_e2262376848494 : check e2262376848494 [[],[.under]] .three = true := by decide
def e2262376848506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2262376848506 : Closed e2262376848506 ∧ code e2262376848506 = 11058469870714 := by decide
theorem cert_e2262376848506 : check e2262376848506 [[],[.under]] .three = true := by decide
def e2262376848670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2262376848670 : Closed e2262376848670 ∧ code e2262376848670 = 11058469870878 := by decide
theorem cert_e2262376848670 : check e2262376848670 [[],[.under]] .three = true := by decide
def e2262376848838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2262376848838 : Closed e2262376848838 ∧ code e2262376848838 = 11058469871046 := by decide
theorem cert_e2262376848838 : check e2262376848838 [[],[.under]] .three = true := by decide
def e2262376848950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2262376848950 : Closed e2262376848950 ∧ code e2262376848950 = 11058469871158 := by decide
theorem cert_e2262376848950 : check e2262376848950 [[],[.under]] .three = true := by decide
def e2262376848954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2262376848954 : Closed e2262376848954 ∧ code e2262376848954 = 11058469871162 := by decide
theorem cert_e2262376848954 : check e2262376848954 [[],[.under]] .three = true := by decide
def e2262376849038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2262376849038 : Closed e2262376849038 ∧ code e2262376849038 = 11058469871246 := by decide
theorem cert_e2262376849038 : check e2262376849038 [[],[.under]] .three = true := by decide
def e2262376849094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2262376849094 : Closed e2262376849094 ∧ code e2262376849094 = 11058469871302 := by decide
theorem cert_e2262376849094 : check e2262376849094 [[],[.under]] .three = true := by decide
def e2262376853870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2262376853870 : Closed e2262376853870 ∧ code e2262376853870 = 11058469876078 := by decide
theorem cert_e2262376853870 : check e2262376853870 [[],[.under]] .three = true := by decide
def e2262376853878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2262376853878 : Closed e2262376853878 ∧ code e2262376853878 = 11058469876086 := by decide
theorem cert_e2262376853878 : check e2262376853878 [[],[.under]] .three = true := by decide
def e2262376855086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2262376855086 : Closed e2262376855086 ∧ code e2262376855086 = 11058469877294 := by decide
theorem cert_e2262376855086 : check e2262376855086 [[],[.under]] .three = true := by decide
def e2262376855266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2262376855266 : Closed e2262376855266 ∧ code e2262376855266 = 11058469877474 := by decide
theorem cert_e2262376855266 : check e2262376855266 [[],[.under]] .three = true := by decide
def e2262376855278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e2262376855278 : Closed e2262376855278 ∧ code e2262376855278 = 11058469877486 := by decide
theorem cert_e2262376855278 : check e2262376855278 [[],[.under]] .three = true := by decide
def e2262376855318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2262376855318 : Closed e2262376855318 ∧ code e2262376855318 = 11058469877526 := by decide
theorem cert_e2262376855318 : check e2262376855318 [[],[.under]] .three = true := by decide
def e2262376855394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2262376855394 : Closed e2262376855394 ∧ code e2262376855394 = 11058469877602 := by decide
theorem cert_e2262376855394 : check e2262376855394 [[],[.under]] .three = true := by decide
def e2262376855406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2262376855406 : Closed e2262376855406 ∧ code e2262376855406 = 11058469877614 := by decide
theorem cert_e2262376855406 : check e2262376855406 [[],[.under]] .three = true := by decide
def e2262376855414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2262376855414 : Closed e2262376855414 ∧ code e2262376855414 = 11058469877622 := by decide
theorem cert_e2262376855414 : check e2262376855414 [[],[.under]] .three = true := by decide
def e2262376855726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2262376855726 : Closed e2262376855726 ∧ code e2262376855726 = 11058469877934 := by decide
theorem cert_e2262376855726 : check e2262376855726 [[],[.under]] .three = true := by decide
def e2262376855738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2262376855738 : Closed e2262376855738 ∧ code e2262376855738 = 11058469877946 := by decide
theorem cert_e2262376855738 : check e2262376855738 [[],[.under]] .three = true := by decide
def e2262376856110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2262376856110 : Closed e2262376856110 ∧ code e2262376856110 = 11058469878318 := by decide
theorem cert_e2262376856110 : check e2262376856110 [[],[.under]] .three = true := by decide
def e2262376856290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2262376856290 : Closed e2262376856290 ∧ code e2262376856290 = 11058469878498 := by decide
theorem cert_e2262376856290 : check e2262376856290 [[],[.under]] .three = true := by decide
def e2262376856302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2262376856302 : Closed e2262376856302 ∧ code e2262376856302 = 11058469878510 := by decide
theorem cert_e2262376856302 : check e2262376856302 [[],[.under]] .three = true := by decide
def e2262376856430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2262376856430 : Closed e2262376856430 ∧ code e2262376856430 = 11058469878638 := by decide
theorem cert_e2262376856430 : check e2262376856430 [[],[.under]] .three = true := by decide
def e2262376856438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2262376856438 : Closed e2262376856438 ∧ code e2262376856438 = 11058469878646 := by decide
theorem cert_e2262376856438 : check e2262376856438 [[],[.under]] .three = true := by decide
def e2262376856458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376856458 : Closed e2262376856458 ∧ code e2262376856458 = 11058469878666 := by decide
theorem cert_e2262376856458 : check e2262376856458 [[],[.under]] .three = true := by decide
def e2262376856482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376856482 : Closed e2262376856482 ∧ code e2262376856482 = 11058469878690 := by decide
theorem cert_e2262376856482 : check e2262376856482 [[],[.under]] .three = true := by decide
def e2262376856494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2262376856494 : Closed e2262376856494 ∧ code e2262376856494 = 11058469878702 := by decide
theorem cert_e2262376856494 : check e2262376856494 [[],[.under]] .three = true := by decide
def e2262376856502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2262376856502 : Closed e2262376856502 ∧ code e2262376856502 = 11058469878710 := by decide
theorem cert_e2262376856502 : check e2262376856502 [[],[.under]] .three = true := by decide
def e2262376856506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2262376856506 : Closed e2262376856506 ∧ code e2262376856506 = 11058469878714 := by decide
theorem cert_e2262376856506 : check e2262376856506 [[],[.under]] .three = true := by decide
def e2262376856662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2262376856662 : Closed e2262376856662 ∧ code e2262376856662 = 11058469878870 := by decide
theorem cert_e2262376856662 : check e2262376856662 [[],[.under]] .three = true := by decide
def e2262376856666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2262376856666 : Closed e2262376856666 ∧ code e2262376856666 = 11058469878874 := by decide
theorem cert_e2262376856666 : check e2262376856666 [[],[.under]] .three = true := by decide
def e2262376856854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2262376856854 : Closed e2262376856854 ∧ code e2262376856854 = 11058469879062 := by decide
theorem cert_e2262376856854 : check e2262376856854 [[],[.under]] .three = true := by decide
def e2262376856930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2262376856930 : Closed e2262376856930 ∧ code e2262376856930 = 11058469879138 := by decide
theorem cert_e2262376856930 : check e2262376856930 [[],[.under]] .three = true := by decide
def e2262376856942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2262376856942 : Closed e2262376856942 ∧ code e2262376856942 = 11058469879150 := by decide
theorem cert_e2262376856942 : check e2262376856942 [[],[.under]] .three = true := by decide
def e2262376856950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2262376856950 : Closed e2262376856950 ∧ code e2262376856950 = 11058469879158 := by decide
theorem cert_e2262376856950 : check e2262376856950 [[],[.under]] .three = true := by decide
def e2262376856970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376856970 : Closed e2262376856970 ∧ code e2262376856970 = 11058469879178 := by decide
theorem cert_e2262376856970 : check e2262376856970 [[],[.under]] .three = true := by decide
def e2262376856994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376856994 : Closed e2262376856994 ∧ code e2262376856994 = 11058469879202 := by decide
theorem cert_e2262376856994 : check e2262376856994 [[],[.under]] .three = true := by decide
def e2262376857006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2262376857006 : Closed e2262376857006 ∧ code e2262376857006 = 11058469879214 := by decide
theorem cert_e2262376857006 : check e2262376857006 [[],[.under]] .three = true := by decide
def e2262376857014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2262376857014 : Closed e2262376857014 ∧ code e2262376857014 = 11058469879222 := by decide
theorem cert_e2262376857014 : check e2262376857014 [[],[.under]] .three = true := by decide
def e2262376857018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2262376857018 : Closed e2262376857018 ∧ code e2262376857018 = 11058469879226 := by decide
theorem cert_e2262376857018 : check e2262376857018 [[],[.under]] .three = true := by decide
def e2262376857046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2262376857046 : Closed e2262376857046 ∧ code e2262376857046 = 11058469879254 := by decide
theorem cert_e2262376857046 : check e2262376857046 [[],[.under]] .three = true := by decide
def e2262376857050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2262376857050 : Closed e2262376857050 ∧ code e2262376857050 = 11058469879258 := by decide
theorem cert_e2262376857050 : check e2262376857050 [[],[.under]] .three = true := by decide
def e2262376858094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2262376858094 : Closed e2262376858094 ∧ code e2262376858094 = 11058469880302 := by decide
theorem cert_e2262376858094 : check e2262376858094 [[],[.under]] .three = true := by decide
def e2262376858102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2262376858102 : Closed e2262376858102 ∧ code e2262376858102 = 11058469880310 := by decide
theorem cert_e2262376858102 : check e2262376858102 [[],[.under]] .three = true := by decide
def e2262376858862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376858862 : Closed e2262376858862 ∧ code e2262376858862 = 11058469881070 := by decide
theorem cert_e2262376858862 : check e2262376858862 [[],[.under]] .three = true := by decide
def e2262376858870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376858870 : Closed e2262376858870 ∧ code e2262376858870 = 11058469881078 := by decide
theorem cert_e2262376858870 : check e2262376858870 [[],[.under]] .three = true := by decide
def e2262376859422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2262376859422 : Closed e2262376859422 ∧ code e2262376859422 = 11058469881630 := by decide
theorem cert_e2262376859422 : check e2262376859422 [[],[.under]] .three = true := by decide
def e2262376859534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2262376859534 : Closed e2262376859534 ∧ code e2262376859534 = 11058469881742 := by decide
theorem cert_e2262376859534 : check e2262376859534 [[],[.under]] .three = true := by decide
def e2262376861230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2262376861230 : Closed e2262376861230 ∧ code e2262376861230 = 11058469883438 := by decide
theorem cert_e2262376861230 : check e2262376861230 [[],[.under]] .three = true := by decide
def e2262376861410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2262376861410 : Closed e2262376861410 ∧ code e2262376861410 = 11058469883618 := by decide
theorem cert_e2262376861410 : check e2262376861410 [[],[.under]] .three = true := by decide
def e2262376861422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2262376861422 : Closed e2262376861422 ∧ code e2262376861422 = 11058469883630 := by decide
theorem cert_e2262376861422 : check e2262376861422 [[],[.under]] .three = true := by decide
def e2262376861462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2262376861462 : Closed e2262376861462 ∧ code e2262376861462 = 11058469883670 := by decide
theorem cert_e2262376861462 : check e2262376861462 [[],[.under]] .three = true := by decide
def e2262376861538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2262376861538 : Closed e2262376861538 ∧ code e2262376861538 = 11058469883746 := by decide
theorem cert_e2262376861538 : check e2262376861538 [[],[.under]] .three = true := by decide
def e2262376861550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2262376861550 : Closed e2262376861550 ∧ code e2262376861550 = 11058469883758 := by decide
theorem cert_e2262376861550 : check e2262376861550 [[],[.under]] .three = true := by decide
def e2262376861558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2262376861558 : Closed e2262376861558 ∧ code e2262376861558 = 11058469883766 := by decide
theorem cert_e2262376861558 : check e2262376861558 [[],[.under]] .three = true := by decide
def e2262376863806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2262376863806 : Closed e2262376863806 ∧ code e2262376863806 = 11058469886014 := by decide
theorem cert_e2262376863806 : check e2262376863806 [[],[.under]] .three = true := by decide
def e2262376864226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2262376864226 : Closed e2262376864226 ∧ code e2262376864226 = 11058469886434 := by decide
theorem cert_e2262376864226 : check e2262376864226 [[],[.under]] .three = true := by decide
def e2262376864238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2262376864238 : Closed e2262376864238 ∧ code e2262376864238 = 11058469886446 := by decide
theorem cert_e2262376864238 : check e2262376864238 [[],[.under]] .three = true := by decide
def e2262376864798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2262376864798 : Closed e2262376864798 ∧ code e2262376864798 = 11058469887006 := by decide
theorem cert_e2262376864798 : check e2262376864798 [[],[.under]] .three = true := by decide
def e2262376864994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2262376864994 : Closed e2262376864994 ∧ code e2262376864994 = 11058469887202 := by decide
theorem cert_e2262376864994 : check e2262376864994 [[],[.under]] .three = true := by decide
def e2262376865006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376865006 : Closed e2262376865006 ∧ code e2262376865006 = 11058469887214 := by decide
theorem cert_e2262376865006 : check e2262376865006 [[],[.under]] .three = true := by decide
def e2262376865014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376865014 : Closed e2262376865014 ∧ code e2262376865014 = 11058469887222 := by decide
theorem cert_e2262376865014 : check e2262376865014 [[],[.under]] .three = true := by decide
def e2262376866030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2262376866030 : Closed e2262376866030 ∧ code e2262376866030 = 11058469888238 := by decide
theorem cert_e2262376866030 : check e2262376866030 [[],[.under]] .three = true := by decide
def e2262376866042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2262376866042 : Closed e2262376866042 ∧ code e2262376866042 = 11058469888250 := by decide
theorem cert_e2262376866042 : check e2262376866042 [[],[.under]] .three = true := by decide
def e2262376866222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2262376866222 : Closed e2262376866222 ∧ code e2262376866222 = 11058469888430 := by decide
theorem cert_e2262376866222 : check e2262376866222 [[],[.under]] .three = true := by decide
def e2262376866414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376866414 : Closed e2262376866414 ∧ code e2262376866414 = 11058469888622 := by decide
theorem cert_e2262376866414 : check e2262376866414 [[],[.under]] .three = true := by decide
def e2262376866426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376866426 : Closed e2262376866426 ∧ code e2262376866426 = 11058469888634 := by decide
theorem cert_e2262376866426 : check e2262376866426 [[],[.under]] .three = true := by decide
def e2262376866590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2262376866590 : Closed e2262376866590 ∧ code e2262376866590 = 11058469888798 := by decide
theorem cert_e2262376866590 : check e2262376866590 [[],[.under]] .three = true := by decide
def e2262376866758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2262376866758 : Closed e2262376866758 ∧ code e2262376866758 = 11058469888966 := by decide
theorem cert_e2262376866758 : check e2262376866758 [[],[.under]] .three = true := by decide
def e2262376867374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2262376867374 : Closed e2262376867374 ∧ code e2262376867374 = 11058469889582 := by decide
theorem cert_e2262376867374 : check e2262376867374 [[],[.under]] .three = true := by decide
def e2262376867554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2262376867554 : Closed e2262376867554 ∧ code e2262376867554 = 11058469889762 := by decide
theorem cert_e2262376867554 : check e2262376867554 [[],[.under]] .three = true := by decide
def e2262376867566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2262376867566 : Closed e2262376867566 ∧ code e2262376867566 = 11058469889774 := by decide
theorem cert_e2262376867566 : check e2262376867566 [[],[.under]] .three = true := by decide
def e2262376867694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2262376867694 : Closed e2262376867694 ∧ code e2262376867694 = 11058469889902 := by decide
theorem cert_e2262376867694 : check e2262376867694 [[],[.under]] .three = true := by decide
def e2262376867702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2262376867702 : Closed e2262376867702 ∧ code e2262376867702 = 11058469889910 := by decide
theorem cert_e2262376867702 : check e2262376867702 [[],[.under]] .three = true := by decide
def e2262376867722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376867722 : Closed e2262376867722 ∧ code e2262376867722 = 11058469889930 := by decide
theorem cert_e2262376867722 : check e2262376867722 [[],[.under]] .three = true := by decide
def e2262376867746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376867746 : Closed e2262376867746 ∧ code e2262376867746 = 11058469889954 := by decide
theorem cert_e2262376867746 : check e2262376867746 [[],[.under]] .three = true := by decide
def e2262376867758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2262376867758 : Closed e2262376867758 ∧ code e2262376867758 = 11058469889966 := by decide
theorem cert_e2262376867758 : check e2262376867758 [[],[.under]] .three = true := by decide
def e2262376867766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2262376867766 : Closed e2262376867766 ∧ code e2262376867766 = 11058469889974 := by decide
theorem cert_e2262376867766 : check e2262376867766 [[],[.under]] .three = true := by decide
def e2262376867770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2262376867770 : Closed e2262376867770 ∧ code e2262376867770 = 11058469889978 := by decide
theorem cert_e2262376867770 : check e2262376867770 [[],[.under]] .three = true := by decide
def e2262376867902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2262376867902 : Closed e2262376867902 ∧ code e2262376867902 = 11058469890110 := by decide
theorem cert_e2262376867902 : check e2262376867902 [[],[.under]] .three = true := by decide
def e2262376868322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2262376868322 : Closed e2262376868322 ∧ code e2262376868322 = 11058469890530 := by decide
theorem cert_e2262376868322 : check e2262376868322 [[],[.under]] .three = true := by decide
def e2262376868334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2262376868334 : Closed e2262376868334 ∧ code e2262376868334 = 11058469890542 := by decide
theorem cert_e2262376868334 : check e2262376868334 [[],[.under]] .three = true := by decide
def e2262376869102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376869102 : Closed e2262376869102 ∧ code e2262376869102 = 11058469891310 := by decide
theorem cert_e2262376869102 : check e2262376869102 [[],[.under]] .three = true := by decide
def e2262376869110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376869110 : Closed e2262376869110 ∧ code e2262376869110 = 11058469891318 := by decide
theorem cert_e2262376869110 : check e2262376869110 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262376838998
#print axioms Blc.Floor43.cert_e2262376839002
#print axioms Blc.Floor43.cert_e2262376839018
