import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406552482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406552482 : Closed e2422406552482 ∧ code e2422406552482 = 11218499574690 := by decide
theorem cert_e2422406552482 : check e2422406552482 [[],[]] .chain = true := by decide
def e2422406552494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406552494 : Closed e2422406552494 ∧ code e2422406552494 = 11218499574702 := by decide
theorem cert_e2422406552494 : check e2422406552494 [[],[]] .sourceHead = true := by decide
def e2422406552502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2422406552502 : Closed e2422406552502 ∧ code e2422406552502 = 11218499574710 := by decide
theorem cert_e2422406552502 : check e2422406552502 [[],[]] .chain = true := by decide
def e2422406552506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406552506 : Closed e2422406552506 ∧ code e2422406552506 = 11218499574714 := by decide
theorem cert_e2422406552506 : check e2422406552506 [[],[]] .sourceHead = true := by decide
def e2422406552942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406552942 : Closed e2422406552942 ∧ code e2422406552942 = 11218499575150 := by decide
theorem cert_e2422406552942 : check e2422406552942 [[],[]] .chain = true := by decide
def e2422406552950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406552950 : Closed e2422406552950 ∧ code e2422406552950 = 11218499575158 := by decide
theorem cert_e2422406552950 : check e2422406552950 [[],[]] .chain = true := by decide
def e2422406553006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406553006 : Closed e2422406553006 ∧ code e2422406553006 = 11218499575214 := by decide
theorem cert_e2422406553006 : check e2422406553006 [[],[]] .chain = true := by decide
def e2422406553018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406553018 : Closed e2422406553018 ∧ code e2422406553018 = 11218499575226 := by decide
theorem cert_e2422406553018 : check e2422406553018 [[],[]] .chain = true := by decide
def e2422406553046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406553046 : Closed e2422406553046 ∧ code e2422406553046 = 11218499575254 := by decide
theorem cert_e2422406553046 : check e2422406553046 [[],[]] .chain = true := by decide
def e2422406553050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406553050 : Closed e2422406553050 ∧ code e2422406553050 = 11218499575258 := by decide
theorem cert_e2422406553050 : check e2422406553050 [[],[]] .chain = true := by decide
def e2422406553130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406553130 : Closed e2422406553130 ∧ code e2422406553130 = 11218499575338 := by decide
theorem cert_e2422406553130 : check e2422406553130 [[],[]] .chain = true := by decide
def e2422406553226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406553226 : Closed e2422406553226 ∧ code e2422406553226 = 11218499575434 := by decide
theorem cert_e2422406553226 : check e2422406553226 [[],[]] .chain = true := by decide
def e2422406553250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406553250 : Closed e2422406553250 ∧ code e2422406553250 = 11218499575458 := by decide
theorem cert_e2422406553250 : check e2422406553250 [[],[]] .chain = true := by decide
def e2422406553262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406553262 : Closed e2422406553262 ∧ code e2422406553262 = 11218499575470 := by decide
theorem cert_e2422406553262 : check e2422406553262 [[],[]] .sourceHead = true := by decide
def e2422406553270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406553270 : Closed e2422406553270 ∧ code e2422406553270 = 11218499575478 := by decide
theorem cert_e2422406553270 : check e2422406553270 [[],[]] .chain = true := by decide
def e2422406553274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406553274 : Closed e2422406553274 ∧ code e2422406553274 = 11218499575482 := by decide
theorem cert_e2422406553274 : check e2422406553274 [[],[]] .sourceHead = true := by decide
def e2422406553302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406553302 : Closed e2422406553302 ∧ code e2422406553302 = 11218499575510 := by decide
theorem cert_e2422406553302 : check e2422406553302 [[],[]] .chain = true := by decide
def e2422406553306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406553306 : Closed e2422406553306 ∧ code e2422406553306 = 11218499575514 := by decide
theorem cert_e2422406553306 : check e2422406553306 [[],[]] .chain = true := by decide
def e2422406553322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406553322 : Closed e2422406553322 ∧ code e2422406553322 = 11218499575530 := by decide
theorem cert_e2422406553322 : check e2422406553322 [[],[]] .sourceHead = true := by decide
def e2422406553646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422406553646 : Closed e2422406553646 ∧ code e2422406553646 = 11218499575854 := by decide
theorem cert_e2422406553646 : check e2422406553646 [[],[]] .chain = true := by decide
def e2422406553838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422406553838 : Closed e2422406553838 ∧ code e2422406553838 = 11218499576046 := by decide
theorem cert_e2422406553838 : check e2422406553838 [[],[]] .chain = true := by decide
def e2422406553850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2422406553850 : Closed e2422406553850 ∧ code e2422406553850 = 11218499576058 := by decide
theorem cert_e2422406553850 : check e2422406553850 [[],[]] .chain = true := by decide
def e2422406554030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422406554030 : Closed e2422406554030 ∧ code e2422406554030 = 11218499576238 := by decide
theorem cert_e2422406554030 : check e2422406554030 [[],[]] .sourceHead = true := by decide
def e2422406554222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406554222 : Closed e2422406554222 ∧ code e2422406554222 = 11218499576430 := by decide
theorem cert_e2422406554222 : check e2422406554222 [[],[]] .chain = true := by decide
def e2422406554234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406554234 : Closed e2422406554234 ∧ code e2422406554234 = 11218499576442 := by decide
theorem cert_e2422406554234 : check e2422406554234 [[],[]] .chain = true := by decide
def e2422406554398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422406554398 : Closed e2422406554398 ∧ code e2422406554398 = 11218499576606 := by decide
theorem cert_e2422406554398 : check e2422406554398 [[],[]] .chain = true := by decide
def e2422406554566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2422406554566 : Closed e2422406554566 ∧ code e2422406554566 = 11218499576774 := by decide
theorem cert_e2422406554566 : check e2422406554566 [[],[]] .chain = true := by decide
def e2422406555182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406555182 : Closed e2422406555182 ∧ code e2422406555182 = 11218499577390 := by decide
theorem cert_e2422406555182 : check e2422406555182 [[],[]] .chain = true := by decide
def e2422406555362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406555362 : Closed e2422406555362 ∧ code e2422406555362 = 11218499577570 := by decide
theorem cert_e2422406555362 : check e2422406555362 [[],[]] .chain = true := by decide
def e2422406555374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422406555374 : Closed e2422406555374 ∧ code e2422406555374 = 11218499577582 := by decide
theorem cert_e2422406555374 : check e2422406555374 [[],[]] .sourceHead = true := by decide
def e2422406555502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422406555502 : Closed e2422406555502 ∧ code e2422406555502 = 11218499577710 := by decide
theorem cert_e2422406555502 : check e2422406555502 [[],[]] .chain = true := by decide
def e2422406555510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422406555510 : Closed e2422406555510 ∧ code e2422406555510 = 11218499577718 := by decide
theorem cert_e2422406555510 : check e2422406555510 [[],[]] .chain = true := by decide
def e2422406555530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406555530 : Closed e2422406555530 ∧ code e2422406555530 = 11218499577738 := by decide
theorem cert_e2422406555530 : check e2422406555530 [[],[]] .chain = true := by decide
def e2422406555554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406555554 : Closed e2422406555554 ∧ code e2422406555554 = 11218499577762 := by decide
theorem cert_e2422406555554 : check e2422406555554 [[],[]] .chain = true := by decide
def e2422406555566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422406555566 : Closed e2422406555566 ∧ code e2422406555566 = 11218499577774 := by decide
theorem cert_e2422406555566 : check e2422406555566 [[],[]] .sourceHead = true := by decide
def e2422406555574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422406555574 : Closed e2422406555574 ∧ code e2422406555574 = 11218499577782 := by decide
theorem cert_e2422406555574 : check e2422406555574 [[],[]] .chain = true := by decide
def e2422406555578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422406555578 : Closed e2422406555578 ∧ code e2422406555578 = 11218499577786 := by decide
theorem cert_e2422406555578 : check e2422406555578 [[],[]] .sourceHead = true := by decide
def e2422406555710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406555710 : Closed e2422406555710 ∧ code e2422406555710 = 11218499577918 := by decide
theorem cert_e2422406555710 : check e2422406555710 [[],[]] .chain = true := by decide
def e2422406556130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406556130 : Closed e2422406556130 ∧ code e2422406556130 = 11218499578338 := by decide
theorem cert_e2422406556130 : check e2422406556130 [[],[]] .chain = true := by decide
def e2422406556142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406556142 : Closed e2422406556142 ∧ code e2422406556142 = 11218499578350 := by decide
theorem cert_e2422406556142 : check e2422406556142 [[],[]] .sourceHead = true := by decide
def e2422406556910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406556910 : Closed e2422406556910 ∧ code e2422406556910 = 11218499579118 := by decide
theorem cert_e2422406556910 : check e2422406556910 [[],[]] .chain = true := by decide
def e2422406556918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406556918 : Closed e2422406556918 ∧ code e2422406556918 = 11218499579126 := by decide
theorem cert_e2422406556918 : check e2422406556918 [[],[]] .chain = true := by decide
def e2422406557186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406557186 : Closed e2422406557186 ∧ code e2422406557186 = 11218499579394 := by decide
theorem cert_e2422406557186 : check e2422406557186 [[],[]] .chain = true := by decide
def e2422406557198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406557198 : Closed e2422406557198 ∧ code e2422406557198 = 11218499579406 := by decide
theorem cert_e2422406557198 : check e2422406557198 [[],[]] .chain = true := by decide
def e2422406557210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406557210 : Closed e2422406557210 ∧ code e2422406557210 = 11218499579418 := by decide
theorem cert_e2422406557210 : check e2422406557210 [[],[]] .sourceHead = true := by decide
def e2422406557282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406557282 : Closed e2422406557282 ∧ code e2422406557282 = 11218499579490 := by decide
theorem cert_e2422406557282 : check e2422406557282 [[],[]] .chain = true := by decide
def e2422406557294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406557294 : Closed e2422406557294 ∧ code e2422406557294 = 11218499579502 := by decide
theorem cert_e2422406557294 : check e2422406557294 [[],[]] .sourceHead = true := by decide
def e2422406557302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406557302 : Closed e2422406557302 ∧ code e2422406557302 = 11218499579510 := by decide
theorem cert_e2422406557302 : check e2422406557302 [[],[]] .chain = true := by decide
def e2422406557306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406557306 : Closed e2422406557306 ∧ code e2422406557306 = 11218499579514 := by decide
theorem cert_e2422406557306 : check e2422406557306 [[],[]] .sourceHead = true := by decide
def e2422406557806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422406557806 : Closed e2422406557806 ∧ code e2422406557806 = 11218499580014 := by decide
theorem cert_e2422406557806 : check e2422406557806 [[],[]] .chain = true := by decide
def e2422406557982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422406557982 : Closed e2422406557982 ∧ code e2422406557982 = 11218499580190 := by decide
theorem cert_e2422406557982 : check e2422406557982 [[],[]] .chain = true := by decide
def e2422406558178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e2422406558178 : Closed e2422406558178 ∧ code e2422406558178 = 11218499580386 := by decide
theorem cert_e2422406558178 : check e2422406558178 [[],[]] .chain = true := by decide
def e2422406558190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 2))))))
theorem wire_e2422406558190 : Closed e2422406558190 ∧ code e2422406558190 = 11218499580398 := by decide
theorem cert_e2422406558190 : check e2422406558190 [[],[]] .sourceHead = true := by decide
def e2422406558574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406558574 : Closed e2422406558574 ∧ code e2422406558574 = 11218499580782 := by decide
theorem cert_e2422406558574 : check e2422406558574 [[],[]] .chain = true := by decide
def e2422406558582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406558582 : Closed e2422406558582 ∧ code e2422406558582 = 11218499580790 := by decide
theorem cert_e2422406558582 : check e2422406558582 [[],[]] .chain = true := by decide
def e2422406558638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406558638 : Closed e2422406558638 ∧ code e2422406558638 = 11218499580846 := by decide
theorem cert_e2422406558638 : check e2422406558638 [[],[]] .chain = true := by decide
def e2422406558650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406558650 : Closed e2422406558650 ∧ code e2422406558650 = 11218499580858 := by decide
theorem cert_e2422406558650 : check e2422406558650 [[],[]] .chain = true := by decide
def e2422406558678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406558678 : Closed e2422406558678 ∧ code e2422406558678 = 11218499580886 := by decide
theorem cert_e2422406558678 : check e2422406558678 [[],[]] .chain = true := by decide
def e2422406558682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406558682 : Closed e2422406558682 ∧ code e2422406558682 = 11218499580890 := by decide
theorem cert_e2422406558682 : check e2422406558682 [[],[]] .chain = true := by decide
def e2422406558958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406558958 : Closed e2422406558958 ∧ code e2422406558958 = 11218499581166 := by decide
theorem cert_e2422406558958 : check e2422406558958 [[],[]] .chain = true := by decide
def e2422406558966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406558966 : Closed e2422406558966 ∧ code e2422406558966 = 11218499581174 := by decide
theorem cert_e2422406558966 : check e2422406558966 [[],[]] .chain = true := by decide
def e2422406559342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406559342 : Closed e2422406559342 ∧ code e2422406559342 = 11218499581550 := by decide
theorem cert_e2422406559342 : check e2422406559342 [[],[]] .chain = true := by decide
def e2422406559354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406559354 : Closed e2422406559354 ∧ code e2422406559354 = 11218499581562 := by decide
theorem cert_e2422406559354 : check e2422406559354 [[],[]] .chain = true := by decide
def e2422406559494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406559494 : Closed e2422406559494 ∧ code e2422406559494 = 11218499581702 := by decide
theorem cert_e2422406559494 : check e2422406559494 [[],[]] .chain = true := by decide
def e2422406559518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e2422406559518 : Closed e2422406559518 ∧ code e2422406559518 = 11218499581726 := by decide
theorem cert_e2422406559518 : check e2422406559518 [[],[]] .sourceHead = true := by decide
def e2422406559542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406559542 : Closed e2422406559542 ∧ code e2422406559542 = 11218499581750 := by decide
theorem cert_e2422406559542 : check e2422406559542 [[],[]] .chain = true := by decide
def e2422406559546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406559546 : Closed e2422406559546 ∧ code e2422406559546 = 11218499581754 := by decide
theorem cert_e2422406559546 : check e2422406559546 [[],[]] .chain = true := by decide
def e2422406559754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406559754 : Closed e2422406559754 ∧ code e2422406559754 = 11218499581962 := by decide
theorem cert_e2422406559754 : check e2422406559754 [[],[]] .chain = true := by decide
def e2422406559790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406559790 : Closed e2422406559790 ∧ code e2422406559790 = 11218499581998 := by decide
theorem cert_e2422406559790 : check e2422406559790 [[],[]] .sourceHead = true := by decide
def e2422406559798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406559798 : Closed e2422406559798 ∧ code e2422406559798 = 11218499582006 := by decide
theorem cert_e2422406559798 : check e2422406559798 [[],[]] .chain = true := by decide
def e2422406559802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406559802 : Closed e2422406559802 ∧ code e2422406559802 = 11218499582010 := by decide
theorem cert_e2422406559802 : check e2422406559802 [[],[]] .chain = true := by decide
def e2422406559850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406559850 : Closed e2422406559850 ∧ code e2422406559850 = 11218499582058 := by decide
theorem cert_e2422406559850 : check e2422406559850 [[],[]] .sourceHead = true := by decide
def e2422406559886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406559886 : Closed e2422406559886 ∧ code e2422406559886 = 11218499582094 := by decide
theorem cert_e2422406559886 : check e2422406559886 [[],[]] .chain = true := by decide
def e2422406559898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406559898 : Closed e2422406559898 ∧ code e2422406559898 = 11218499582106 := by decide
theorem cert_e2422406559898 : check e2422406559898 [[],[]] .chain = true := by decide
def e2422406559942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406559942 : Closed e2422406559942 ∧ code e2422406559942 = 11218499582150 := by decide
theorem cert_e2422406559942 : check e2422406559942 [[],[]] .chain = true := by decide
def e2422406559970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406559970 : Closed e2422406559970 ∧ code e2422406559970 = 11218499582178 := by decide
theorem cert_e2422406559970 : check e2422406559970 [[],[]] .chain = true := by decide
def e2422406559982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406559982 : Closed e2422406559982 ∧ code e2422406559982 = 11218499582190 := by decide
theorem cert_e2422406559982 : check e2422406559982 [[],[]] .sourceHead = true := by decide
def e2422406559990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406559990 : Closed e2422406559990 ∧ code e2422406559990 = 11218499582198 := by decide
theorem cert_e2422406559990 : check e2422406559990 [[],[]] .sourceHead = true := by decide
def e2422406560138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406560138 : Closed e2422406560138 ∧ code e2422406560138 = 11218499582346 := by decide
theorem cert_e2422406560138 : check e2422406560138 [[],[]] .chain = true := by decide
def e2422406560162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406560162 : Closed e2422406560162 ∧ code e2422406560162 = 11218499582370 := by decide
theorem cert_e2422406560162 : check e2422406560162 [[],[]] .chain = true := by decide
def e2422406560174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406560174 : Closed e2422406560174 ∧ code e2422406560174 = 11218499582382 := by decide
theorem cert_e2422406560174 : check e2422406560174 [[],[]] .sourceHead = true := by decide
def e2422406560182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406560182 : Closed e2422406560182 ∧ code e2422406560182 = 11218499582390 := by decide
theorem cert_e2422406560182 : check e2422406560182 [[],[]] .chain = true := by decide
def e2422406560186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406560186 : Closed e2422406560186 ∧ code e2422406560186 = 11218499582394 := by decide
theorem cert_e2422406560186 : check e2422406560186 [[],[]] .sourceHead = true := by decide
def e2422406560214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406560214 : Closed e2422406560214 ∧ code e2422406560214 = 11218499582422 := by decide
theorem cert_e2422406560214 : check e2422406560214 [[],[]] .chain = true := by decide
def e2422406560218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406560218 : Closed e2422406560218 ∧ code e2422406560218 = 11218499582426 := by decide
theorem cert_e2422406560218 : check e2422406560218 [[],[]] .chain = true := by decide
def e2422406560234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406560234 : Closed e2422406560234 ∧ code e2422406560234 = 11218499582442 := by decide
theorem cert_e2422406560234 : check e2422406560234 [[],[]] .sourceHead = true := by decide
def e2422406560258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406560258 : Closed e2422406560258 ∧ code e2422406560258 = 11218499582466 := by decide
theorem cert_e2422406560258 : check e2422406560258 [[],[]] .chain = true := by decide
def e2422406560270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406560270 : Closed e2422406560270 ∧ code e2422406560270 = 11218499582478 := by decide
theorem cert_e2422406560270 : check e2422406560270 [[],[]] .chain = true := by decide
def e2422406560282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406560282 : Closed e2422406560282 ∧ code e2422406560282 = 11218499582490 := by decide
theorem cert_e2422406560282 : check e2422406560282 [[],[]] .sourceHead = true := by decide
def e2422406560354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406560354 : Closed e2422406560354 ∧ code e2422406560354 = 11218499582562 := by decide
theorem cert_e2422406560354 : check e2422406560354 [[],[]] .chain = true := by decide
def e2422406560366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406560366 : Closed e2422406560366 ∧ code e2422406560366 = 11218499582574 := by decide
theorem cert_e2422406560366 : check e2422406560366 [[],[]] .sourceHead = true := by decide
def e2422406560374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406560374 : Closed e2422406560374 ∧ code e2422406560374 = 11218499582582 := by decide
theorem cert_e2422406560374 : check e2422406560374 [[],[]] .chain = true := by decide
def e2422406560378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406560378 : Closed e2422406560378 ∧ code e2422406560378 = 11218499582586 := by decide
theorem cert_e2422406560378 : check e2422406560378 [[],[]] .sourceHead = true := by decide
def e2422406560518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406560518 : Closed e2422406560518 ∧ code e2422406560518 = 11218499582726 := by decide
theorem cert_e2422406560518 : check e2422406560518 [[],[]] .chain = true := by decide
def e2422406560542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406560542 : Closed e2422406560542 ∧ code e2422406560542 = 11218499582750 := by decide
theorem cert_e2422406560542 : check e2422406560542 [[],[]] .sourceHead = true := by decide
def e2422406560566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406560566 : Closed e2422406560566 ∧ code e2422406560566 = 11218499582774 := by decide
theorem cert_e2422406560566 : check e2422406560566 [[],[]] .chain = true := by decide
def e2422406560570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406560570 : Closed e2422406560570 ∧ code e2422406560570 = 11218499582778 := by decide
theorem cert_e2422406560570 : check e2422406560570 [[],[]] .chain = true := by decide
def e2422406560642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406560642 : Closed e2422406560642 ∧ code e2422406560642 = 11218499582850 := by decide
theorem cert_e2422406560642 : check e2422406560642 [[],[]] .sourceHead = true := by decide
def e2422406560654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406560654 : Closed e2422406560654 ∧ code e2422406560654 = 11218499582862 := by decide
theorem cert_e2422406560654 : check e2422406560654 [[],[]] .sourceHead = true := by decide
def e2422406560666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406560666 : Closed e2422406560666 ∧ code e2422406560666 = 11218499582874 := by decide
theorem cert_e2422406560666 : check e2422406560666 [[],[]] .sourceHead = true := by decide
def e2422406562222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422406562222 : Closed e2422406562222 ∧ code e2422406562222 = 11218499584430 := by decide
theorem cert_e2422406562222 : check e2422406562222 [[],[]] .chain = true := by decide
def e2422406562234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422406562234 : Closed e2422406562234 ∧ code e2422406562234 = 11218499584442 := by decide
theorem cert_e2422406562234 : check e2422406562234 [[],[]] .chain = true := by decide
def e2422406562926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406562926 : Closed e2422406562926 ∧ code e2422406562926 = 11218499585134 := by decide
theorem cert_e2422406562926 : check e2422406562926 [[],[]] .chain = true := by decide
def e2422406562938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406562938 : Closed e2422406562938 ∧ code e2422406562938 = 11218499585146 := by decide
theorem cert_e2422406562938 : check e2422406562938 [[],[]] .chain = true := by decide
def e2422406563102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406563102 : Closed e2422406563102 ∧ code e2422406563102 = 11218499585310 := by decide
theorem cert_e2422406563102 : check e2422406563102 [[],[]] .chain = true := by decide
def e2422406563270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406563270 : Closed e2422406563270 ∧ code e2422406563270 = 11218499585478 := by decide
theorem cert_e2422406563270 : check e2422406563270 [[],[]] .chain = true := by decide
def e2422406563374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406563374 : Closed e2422406563374 ∧ code e2422406563374 = 11218499585582 := by decide
theorem cert_e2422406563374 : check e2422406563374 [[],[]] .chain = true := by decide
def e2422406563554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406563554 : Closed e2422406563554 ∧ code e2422406563554 = 11218499585762 := by decide
theorem cert_e2422406563554 : check e2422406563554 [[],[]] .chain = true := by decide
def e2422406563566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e2422406563566 : Closed e2422406563566 ∧ code e2422406563566 = 11218499585774 := by decide
theorem cert_e2422406563566 : check e2422406563566 [[],[]] .sourceHead = true := by decide
def e2422406563722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406563722 : Closed e2422406563722 ∧ code e2422406563722 = 11218499585930 := by decide
theorem cert_e2422406563722 : check e2422406563722 [[],[]] .chain = true := by decide
def e2422406563746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406563746 : Closed e2422406563746 ∧ code e2422406563746 = 11218499585954 := by decide
theorem cert_e2422406563746 : check e2422406563746 [[],[]] .chain = true := by decide
def e2422406563758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 2))))))
theorem wire_e2422406563758 : Closed e2422406563758 ∧ code e2422406563758 = 11218499585966 := by decide
theorem cert_e2422406563758 : check e2422406563758 [[],[]] .sourceHead = true := by decide
def e2422406563770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 2)) (.var 0))))))
theorem wire_e2422406563770 : Closed e2422406563770 ∧ code e2422406563770 = 11218499585978 := by decide
theorem cert_e2422406563770 : check e2422406563770 [[],[]] .sourceHead = true := by decide
def e2422406565230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406565230 : Closed e2422406565230 ∧ code e2422406565230 = 11218499587438 := by decide
theorem cert_e2422406565230 : check e2422406565230 [[],[]] .chain = true := by decide
def e2422406565238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406565238 : Closed e2422406565238 ∧ code e2422406565238 = 11218499587446 := by decide
theorem cert_e2422406565238 : check e2422406565238 [[],[]] .chain = true := by decide
def e2422406565294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406565294 : Closed e2422406565294 ∧ code e2422406565294 = 11218499587502 := by decide
theorem cert_e2422406565294 : check e2422406565294 [[],[]] .chain = true := by decide
def e2422406565306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406565306 : Closed e2422406565306 ∧ code e2422406565306 = 11218499587514 := by decide
theorem cert_e2422406565306 : check e2422406565306 [[],[]] .chain = true := by decide
def e2422406565334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406565334 : Closed e2422406565334 ∧ code e2422406565334 = 11218499587542 := by decide
theorem cert_e2422406565334 : check e2422406565334 [[],[]] .chain = true := by decide
def e2422406565338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406565338 : Closed e2422406565338 ∧ code e2422406565338 = 11218499587546 := by decide
theorem cert_e2422406565338 : check e2422406565338 [[],[]] .chain = true := by decide
def e2422406565550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406565550 : Closed e2422406565550 ∧ code e2422406565550 = 11218499587758 := by decide
theorem cert_e2422406565550 : check e2422406565550 [[],[]] .chain = true := by decide
def e2422406565562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406565562 : Closed e2422406565562 ∧ code e2422406565562 = 11218499587770 := by decide
theorem cert_e2422406565562 : check e2422406565562 [[],[]] .chain = true := by decide
def e2422406565610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406565610 : Closed e2422406565610 ∧ code e2422406565610 = 11218499587818 := by decide
theorem cert_e2422406565610 : check e2422406565610 [[],[]] .chain = true := by decide
def e2422406565718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406565718 : Closed e2422406565718 ∧ code e2422406565718 = 11218499587926 := by decide
theorem cert_e2422406565718 : check e2422406565718 [[],[]] .chain = true := by decide
def e2422406565722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406565722 : Closed e2422406565722 ∧ code e2422406565722 = 11218499587930 := by decide
theorem cert_e2422406565722 : check e2422406565722 [[],[]] .chain = true := by decide
def e2422406565738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406565738 : Closed e2422406565738 ∧ code e2422406565738 = 11218499587946 := by decide
theorem cert_e2422406565738 : check e2422406565738 [[],[]] .chain = true := by decide
def e2422406565998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422406565998 : Closed e2422406565998 ∧ code e2422406565998 = 11218499588206 := by decide
theorem cert_e2422406565998 : check e2422406565998 [[],[]] .chain = true := by decide
def e2422406566174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422406566174 : Closed e2422406566174 ∧ code e2422406566174 = 11218499588382 := by decide
theorem cert_e2422406566174 : check e2422406566174 [[],[]] .chain = true := by decide
def e2422406566370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e2422406566370 : Closed e2422406566370 ∧ code e2422406566370 = 11218499588578 := by decide
theorem cert_e2422406566370 : check e2422406566370 [[],[]] .chain = true := by decide
def e2422406566382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 2))))))
theorem wire_e2422406566382 : Closed e2422406566382 ∧ code e2422406566382 = 11218499588590 := by decide
theorem cert_e2422406566382 : check e2422406566382 [[],[]] .sourceHead = true := by decide
def e2422406566766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406566766 : Closed e2422406566766 ∧ code e2422406566766 = 11218499588974 := by decide
theorem cert_e2422406566766 : check e2422406566766 [[],[]] .chain = true := by decide
def e2422406566774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406566774 : Closed e2422406566774 ∧ code e2422406566774 = 11218499588982 := by decide
theorem cert_e2422406566774 : check e2422406566774 [[],[]] .chain = true := by decide
def e2422406566830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406566830 : Closed e2422406566830 ∧ code e2422406566830 = 11218499589038 := by decide
theorem cert_e2422406566830 : check e2422406566830 [[],[]] .chain = true := by decide
def e2422406566842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406566842 : Closed e2422406566842 ∧ code e2422406566842 = 11218499589050 := by decide
theorem cert_e2422406566842 : check e2422406566842 [[],[]] .chain = true := by decide
def e2422406566870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406566870 : Closed e2422406566870 ∧ code e2422406566870 = 11218499589078 := by decide
theorem cert_e2422406566870 : check e2422406566870 [[],[]] .chain = true := by decide
def e2422406566874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406566874 : Closed e2422406566874 ∧ code e2422406566874 = 11218499589082 := by decide
theorem cert_e2422406566874 : check e2422406566874 [[],[]] .chain = true := by decide
def e2422406567150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406567150 : Closed e2422406567150 ∧ code e2422406567150 = 11218499589358 := by decide
theorem cert_e2422406567150 : check e2422406567150 [[],[]] .chain = true := by decide
def e2422406567158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406567158 : Closed e2422406567158 ∧ code e2422406567158 = 11218499589366 := by decide
theorem cert_e2422406567158 : check e2422406567158 [[],[]] .chain = true := by decide
def e2422406567534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406567534 : Closed e2422406567534 ∧ code e2422406567534 = 11218499589742 := by decide
theorem cert_e2422406567534 : check e2422406567534 [[],[]] .chain = true := by decide
def e2422406567546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406567546 : Closed e2422406567546 ∧ code e2422406567546 = 11218499589754 := by decide
theorem cert_e2422406567546 : check e2422406567546 [[],[]] .chain = true := by decide
def e2422406567686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406567686 : Closed e2422406567686 ∧ code e2422406567686 = 11218499589894 := by decide
theorem cert_e2422406567686 : check e2422406567686 [[],[]] .chain = true := by decide
def e2422406567710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e2422406567710 : Closed e2422406567710 ∧ code e2422406567710 = 11218499589918 := by decide
theorem cert_e2422406567710 : check e2422406567710 [[],[]] .sourceHead = true := by decide
def e2422406567734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406567734 : Closed e2422406567734 ∧ code e2422406567734 = 11218499589942 := by decide
theorem cert_e2422406567734 : check e2422406567734 [[],[]] .chain = true := by decide
def e2422406567738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406567738 : Closed e2422406567738 ∧ code e2422406567738 = 11218499589946 := by decide
theorem cert_e2422406567738 : check e2422406567738 [[],[]] .chain = true := by decide
def e2422406568366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406568366 : Closed e2422406568366 ∧ code e2422406568366 = 11218499590574 := by decide
theorem cert_e2422406568366 : check e2422406568366 [[],[]] .chain = true := by decide
def e2422406568378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406568378 : Closed e2422406568378 ∧ code e2422406568378 = 11218499590586 := by decide
theorem cert_e2422406568378 : check e2422406568378 [[],[]] .chain = true := by decide
def e2422406568426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406568426 : Closed e2422406568426 ∧ code e2422406568426 = 11218499590634 := by decide
theorem cert_e2422406568426 : check e2422406568426 [[],[]] .chain = true := by decide
def e2422406568558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406568558 : Closed e2422406568558 ∧ code e2422406568558 = 11218499590766 := by decide
theorem cert_e2422406568558 : check e2422406568558 [[],[]] .chain = true := by decide
def e2422406568570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406568570 : Closed e2422406568570 ∧ code e2422406568570 = 11218499590778 := by decide
theorem cert_e2422406568570 : check e2422406568570 [[],[]] .chain = true := by decide
def e2422406568858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406568858 : Closed e2422406568858 ∧ code e2422406568858 = 11218499591066 := by decide
theorem cert_e2422406568858 : check e2422406568858 [[],[]] .chain = true := by decide
def e2422406568986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422406568986 : Closed e2422406568986 ∧ code e2422406568986 = 11218499591194 := by decide
theorem cert_e2422406568986 : check e2422406568986 [[],[]] .chain = true := by decide
def e2422406569030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422406569030 : Closed e2422406569030 ∧ code e2422406569030 = 11218499591238 := by decide
theorem cert_e2422406569030 : check e2422406569030 [[],[]] .chain = true := by decide
def e2422406569058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406569058 : Closed e2422406569058 ∧ code e2422406569058 = 11218499591266 := by decide
theorem cert_e2422406569058 : check e2422406569058 [[],[]] .chain = true := by decide
def e2422406569070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406569070 : Closed e2422406569070 ∧ code e2422406569070 = 11218499591278 := by decide
theorem cert_e2422406569070 : check e2422406569070 [[],[]] .sourceHead = true := by decide
def e2422406569082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406569082 : Closed e2422406569082 ∧ code e2422406569082 = 11218499591290 := by decide
theorem cert_e2422406569082 : check e2422406569082 [[],[]] .sourceHead = true := by decide
def e2422406569174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406569174 : Closed e2422406569174 ∧ code e2422406569174 = 11218499591382 := by decide
theorem cert_e2422406569174 : check e2422406569174 [[],[]] .chain = true := by decide
def e2422406569178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406569178 : Closed e2422406569178 ∧ code e2422406569178 = 11218499591386 := by decide
theorem cert_e2422406569178 : check e2422406569178 [[],[]] .chain = true := by decide
def e2422406569194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406569194 : Closed e2422406569194 ∧ code e2422406569194 = 11218499591402 := by decide
theorem cert_e2422406569194 : check e2422406569194 [[],[]] .chain = true := by decide
def e2422406569222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406569222 : Closed e2422406569222 ∧ code e2422406569222 = 11218499591430 := by decide
theorem cert_e2422406569222 : check e2422406569222 [[],[]] .chain = true := by decide
def e2422406569246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406569246 : Closed e2422406569246 ∧ code e2422406569246 = 11218499591454 := by decide
theorem cert_e2422406569246 : check e2422406569246 [[],[]] .sourceHead = true := by decide
def e2422406569270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406569270 : Closed e2422406569270 ∧ code e2422406569270 = 11218499591478 := by decide
theorem cert_e2422406569270 : check e2422406569270 [[],[]] .chain = true := by decide
end Blc.Floor43
