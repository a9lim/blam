import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373741526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2422373741526 : Closed e2422373741526 ∧ code e2422373741526 = 11218466763734 := by decide
theorem cert_e2422373741526 : check e2422373741526 [[],[]] .three = true := by decide
def e2422373741530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2422373741530 : Closed e2422373741530 ∧ code e2422373741530 = 11218466763738 := by decide
theorem cert_e2422373741530 : check e2422373741530 [[],[]] .three = true := by decide
def e2422373741546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2422373741546 : Closed e2422373741546 ∧ code e2422373741546 = 11218466763754 := by decide
theorem cert_e2422373741546 : check e2422373741546 [[],[]] .three = true := by decide
def e2422373741598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373741598 : Closed e2422373741598 ∧ code e2422373741598 = 11218466763806 := by decide
theorem cert_e2422373741598 : check e2422373741598 [[],[]] .three = true := by decide
def e2422373741622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373741622 : Closed e2422373741622 ∧ code e2422373741622 = 11218466763830 := by decide
theorem cert_e2422373741622 : check e2422373741622 [[],[]] .three = true := by decide
def e2422373741626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373741626 : Closed e2422373741626 ∧ code e2422373741626 = 11218466763834 := by decide
theorem cert_e2422373741626 : check e2422373741626 [[],[]] .three = true := by decide
def e2422373741766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373741766 : Closed e2422373741766 ∧ code e2422373741766 = 11218466763974 := by decide
theorem cert_e2422373741766 : check e2422373741766 [[],[]] .three = true := by decide
def e2422373741790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373741790 : Closed e2422373741790 ∧ code e2422373741790 = 11218466763998 := by decide
theorem cert_e2422373741790 : check e2422373741790 [[],[]] .three = true := by decide
def e2422373741794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373741794 : Closed e2422373741794 ∧ code e2422373741794 = 11218466764002 := by decide
theorem cert_e2422373741794 : check e2422373741794 [[],[]] .three = true := by decide
def e2422373741806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373741806 : Closed e2422373741806 ∧ code e2422373741806 = 11218466764014 := by decide
theorem cert_e2422373741806 : check e2422373741806 [[],[]] .three = true := by decide
def e2422373741814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373741814 : Closed e2422373741814 ∧ code e2422373741814 = 11218466764022 := by decide
theorem cert_e2422373741814 : check e2422373741814 [[],[]] .three = true := by decide
def e2422373741818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373741818 : Closed e2422373741818 ∧ code e2422373741818 = 11218466764026 := by decide
theorem cert_e2422373741818 : check e2422373741818 [[],[]] .three = true := by decide
def e2422373742094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373742094 : Closed e2422373742094 ∧ code e2422373742094 = 11218466764302 := by decide
theorem cert_e2422373742094 : check e2422373742094 [[],[]] .three = true := by decide
def e2422373742178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373742178 : Closed e2422373742178 ∧ code e2422373742178 = 11218466764386 := by decide
theorem cert_e2422373742178 : check e2422373742178 [[],[]] .three = true := by decide
def e2422373742190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373742190 : Closed e2422373742190 ∧ code e2422373742190 = 11218466764398 := by decide
theorem cert_e2422373742190 : check e2422373742190 [[],[]] .three = true := by decide
def e2422373742202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373742202 : Closed e2422373742202 ∧ code e2422373742202 = 11218466764410 := by decide
theorem cert_e2422373742202 : check e2422373742202 [[],[]] .three = true := by decide
def e2422373742366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.lam (.var 3))))))))
theorem wire_e2422373742366 : Closed e2422373742366 ∧ code e2422373742366 = 11218466764574 := by decide
theorem cert_e2422373742366 : check e2422373742366 [[],[]] .three = true := by decide
def e2422373742390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373742390 : Closed e2422373742390 ∧ code e2422373742390 = 11218466764598 := by decide
theorem cert_e2422373742390 : check e2422373742390 [[],[]] .three = true := by decide
def e2422373742394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373742394 : Closed e2422373742394 ∧ code e2422373742394 = 11218466764602 := by decide
theorem cert_e2422373742394 : check e2422373742394 [[],[]] .three = true := by decide
def e2422373742490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373742490 : Closed e2422373742490 ∧ code e2422373742490 = 11218466764698 := by decide
theorem cert_e2422373742490 : check e2422373742490 [[],[]] .three = true := by decide
def e2422373746622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422373746622 : Closed e2422373746622 ∧ code e2422373746622 = 11218466768830 := by decide
theorem cert_e2422373746622 : check e2422373746622 [[],[]] .smaller = true := by decide
def e2422373746670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422373746670 : Closed e2422373746670 ∧ code e2422373746670 = 11218466768878 := by decide
theorem cert_e2422373746670 : check e2422373746670 [[],[]] .smaller = true := by decide
def e2422373750462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2422373750462 : Closed e2422373750462 ∧ code e2422373750462 = 11218466772670 := by decide
theorem cert_e2422373750462 : check e2422373750462 [[],[]] .three = true := by decide
def e2422373750494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422373750494 : Closed e2422373750494 ∧ code e2422373750494 = 11218466772702 := by decide
theorem cert_e2422373750494 : check e2422373750494 [[],[]] .smaller = true := by decide
def e2422373750518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422373750518 : Closed e2422373750518 ∧ code e2422373750518 = 11218466772726 := by decide
theorem cert_e2422373750518 : check e2422373750518 [[],[]] .smaller = true := by decide
def e2422373750522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2422373750522 : Closed e2422373750522 ∧ code e2422373750522 = 11218466772730 := by decide
theorem cert_e2422373750522 : check e2422373750522 [[],[]] .three = true := by decide
def e2422373750622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422373750622 : Closed e2422373750622 ∧ code e2422373750622 = 11218466772830 := by decide
theorem cert_e2422373750622 : check e2422373750622 [[],[]] .smaller = true := by decide
def e2422373750650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422373750650 : Closed e2422373750650 ∧ code e2422373750650 = 11218466772858 := by decide
theorem cert_e2422373750650 : check e2422373750650 [[],[]] .smaller = true := by decide
def e2422373750742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422373750742 : Closed e2422373750742 ∧ code e2422373750742 = 11218466772950 := by decide
theorem cert_e2422373750742 : check e2422373750742 [[],[]] .smaller = true := by decide
def e2422373750746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422373750746 : Closed e2422373750746 ∧ code e2422373750746 = 11218466772954 := by decide
theorem cert_e2422373750746 : check e2422373750746 [[],[]] .smaller = true := by decide
def e2422373750762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2422373750762 : Closed e2422373750762 ∧ code e2422373750762 = 11218466772970 := by decide
theorem cert_e2422373750762 : check e2422373750762 [[],[]] .three = true := by decide
def e2422373751230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422373751230 : Closed e2422373751230 ∧ code e2422373751230 = 11218466773438 := by decide
theorem cert_e2422373751230 : check e2422373751230 [[],[]] .three = true := by decide
def e2422373751262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422373751262 : Closed e2422373751262 ∧ code e2422373751262 = 11218466773470 := by decide
theorem cert_e2422373751262 : check e2422373751262 [[],[]] .smaller = true := by decide
def e2422373751286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422373751286 : Closed e2422373751286 ∧ code e2422373751286 = 11218466773494 := by decide
theorem cert_e2422373751286 : check e2422373751286 [[],[]] .smaller = true := by decide
def e2422373751290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422373751290 : Closed e2422373751290 ∧ code e2422373751290 = 11218466773498 := by decide
theorem cert_e2422373751290 : check e2422373751290 [[],[]] .three = true := by decide
def e2422373751934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 5))))))))))
theorem wire_e2422373751934 : Closed e2422373751934 ∧ code e2422373751934 = 11218466774142 := by decide
theorem cert_e2422373751934 : check e2422373751934 [[],[]] .three = true := by decide
def e2422373752030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422373752030 : Closed e2422373752030 ∧ code e2422373752030 = 11218466774238 := by decide
theorem cert_e2422373752030 : check e2422373752030 [[],[]] .smaller = true := by decide
def e2422373752058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422373752058 : Closed e2422373752058 ∧ code e2422373752058 = 11218466774266 := by decide
theorem cert_e2422373752058 : check e2422373752058 [[],[]] .smaller = true := by decide
def e2422373752382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2422373752382 : Closed e2422373752382 ∧ code e2422373752382 = 11218466774590 := by decide
theorem cert_e2422373752382 : check e2422373752382 [[],[]] .smaller = true := by decide
def e2422373752606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2422373752606 : Closed e2422373752606 ∧ code e2422373752606 = 11218466774814 := by decide
theorem cert_e2422373752606 : check e2422373752606 [[],[]] .smaller = true := by decide
def e2422373752630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373752630 : Closed e2422373752630 ∧ code e2422373752630 = 11218466774838 := by decide
theorem cert_e2422373752630 : check e2422373752630 [[],[]] .smaller = true := by decide
def e2422373752634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373752634 : Closed e2422373752634 ∧ code e2422373752634 = 11218466774842 := by decide
theorem cert_e2422373752634 : check e2422373752634 [[],[]] .smaller = true := by decide
def e2422373752718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.lam (.var 2))))))))))
theorem wire_e2422373752718 : Closed e2422373752718 ∧ code e2422373752718 = 11218466774926 := by decide
theorem cert_e2422373752718 : check e2422373752718 [[],[]] .three = true := by decide
def e2422373752730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373752730 : Closed e2422373752730 ∧ code e2422373752730 = 11218466774938 := by decide
theorem cert_e2422373752730 : check e2422373752730 [[],[]] .three = true := by decide
def e2422373752766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 4)))))))))
theorem wire_e2422373752766 : Closed e2422373752766 ∧ code e2422373752766 = 11218466774974 := by decide
theorem cert_e2422373752766 : check e2422373752766 [[],[]] .three = true := by decide
def e2422373766830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422373766830 : Closed e2422373766830 ∧ code e2422373766830 = 11218466789038 := by decide
theorem cert_e2422373766830 : check e2422373766830 [[],[]] .smaller = true := by decide
def e2422373766842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422373766842 : Closed e2422373766842 ∧ code e2422373766842 = 11218466789050 := by decide
theorem cert_e2422373766842 : check e2422373766842 [[],[]] .smaller = true := by decide
def e2422373766890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422373766890 : Closed e2422373766890 ∧ code e2422373766890 = 11218466789098 := by decide
theorem cert_e2422373766890 : check e2422373766890 [[],[]] .smaller = true := by decide
def e2422373767082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422373767082 : Closed e2422373767082 ∧ code e2422373767082 = 11218466789290 := by decide
theorem cert_e2422373767082 : check e2422373767082 [[],[]] .smaller = true := by decide
def e2422373767214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422373767214 : Closed e2422373767214 ∧ code e2422373767214 = 11218466789422 := by decide
theorem cert_e2422373767214 : check e2422373767214 [[],[]] .smaller = true := by decide
def e2422373767390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422373767390 : Closed e2422373767390 ∧ code e2422373767390 = 11218466789598 := by decide
theorem cert_e2422373767390 : check e2422373767390 [[],[]] .three = true := by decide
def e2422373767406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422373767406 : Closed e2422373767406 ∧ code e2422373767406 = 11218466789614 := by decide
theorem cert_e2422373767406 : check e2422373767406 [[],[]] .smaller = true := by decide
def e2422373767414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422373767414 : Closed e2422373767414 ∧ code e2422373767414 = 11218466789622 := by decide
theorem cert_e2422373767414 : check e2422373767414 [[],[]] .smaller = true := by decide
def e2422373767418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422373767418 : Closed e2422373767418 ∧ code e2422373767418 = 11218466789626 := by decide
theorem cert_e2422373767418 : check e2422373767418 [[],[]] .three = true := by decide
def e2422373767598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422373767598 : Closed e2422373767598 ∧ code e2422373767598 = 11218466789806 := by decide
theorem cert_e2422373767598 : check e2422373767598 [[],[]] .smaller = true := by decide
def e2422373767610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422373767610 : Closed e2422373767610 ∧ code e2422373767610 = 11218466789818 := by decide
theorem cert_e2422373767610 : check e2422373767610 [[],[]] .smaller = true := by decide
def e2422373767658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422373767658 : Closed e2422373767658 ∧ code e2422373767658 = 11218466789866 := by decide
theorem cert_e2422373767658 : check e2422373767658 [[],[]] .smaller = true := by decide
def e2422373767742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422373767742 : Closed e2422373767742 ∧ code e2422373767742 = 11218466789950 := by decide
theorem cert_e2422373767742 : check e2422373767742 [[],[]] .three = true := by decide
def e2422373767790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373767790 : Closed e2422373767790 ∧ code e2422373767790 = 11218466789998 := by decide
theorem cert_e2422373767790 : check e2422373767790 [[],[]] .smaller = true := by decide
def e2422373767802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373767802 : Closed e2422373767802 ∧ code e2422373767802 = 11218466790010 := by decide
theorem cert_e2422373767802 : check e2422373767802 [[],[]] .smaller = true := by decide
def e2422373767966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422373767966 : Closed e2422373767966 ∧ code e2422373767966 = 11218466790174 := by decide
theorem cert_e2422373767966 : check e2422373767966 [[],[]] .smaller = true := by decide
def e2422373768066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373768066 : Closed e2422373768066 ∧ code e2422373768066 = 11218466790274 := by decide
theorem cert_e2422373768066 : check e2422373768066 [[],[]] .smaller = true := by decide
def e2422373768078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422373768078 : Closed e2422373768078 ∧ code e2422373768078 = 11218466790286 := by decide
theorem cert_e2422373768078 : check e2422373768078 [[],[]] .smaller = true := by decide
def e2422373768090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373768090 : Closed e2422373768090 ∧ code e2422373768090 = 11218466790298 := by decide
theorem cert_e2422373768090 : check e2422373768090 [[],[]] .smaller = true := by decide
def e2422373768134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422373768134 : Closed e2422373768134 ∧ code e2422373768134 = 11218466790342 := by decide
theorem cert_e2422373768134 : check e2422373768134 [[],[]] .three = true := by decide
def e2422373768158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e2422373768158 : Closed e2422373768158 ∧ code e2422373768158 = 11218466790366 := by decide
theorem cert_e2422373768158 : check e2422373768158 [[],[]] .three = true := by decide
def e2422373768286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422373768286 : Closed e2422373768286 ∧ code e2422373768286 = 11218466790494 := by decide
theorem cert_e2422373768286 : check e2422373768286 [[],[]] .three = true := by decide
def e2422373768302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422373768302 : Closed e2422373768302 ∧ code e2422373768302 = 11218466790510 := by decide
theorem cert_e2422373768302 : check e2422373768302 [[],[]] .smaller = true := by decide
def e2422373768314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422373768314 : Closed e2422373768314 ∧ code e2422373768314 = 11218466790522 := by decide
theorem cert_e2422373768314 : check e2422373768314 [[],[]] .smaller = true := by decide
def e2422373768478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422373768478 : Closed e2422373768478 ∧ code e2422373768478 = 11218466790686 := by decide
theorem cert_e2422373768478 : check e2422373768478 [[],[]] .smaller = true := by decide
def e2422373768646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422373768646 : Closed e2422373768646 ∧ code e2422373768646 = 11218466790854 := by decide
theorem cert_e2422373768646 : check e2422373768646 [[],[]] .smaller = true := by decide
def e2422373768670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2422373768670 : Closed e2422373768670 ∧ code e2422373768670 = 11218466790878 := by decide
theorem cert_e2422373768670 : check e2422373768670 [[],[]] .three = true := by decide
def e2422373768674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422373768674 : Closed e2422373768674 ∧ code e2422373768674 = 11218466790882 := by decide
theorem cert_e2422373768674 : check e2422373768674 [[],[]] .three = true := by decide
def e2422373768686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2422373768686 : Closed e2422373768686 ∧ code e2422373768686 = 11218466790894 := by decide
theorem cert_e2422373768686 : check e2422373768686 [[],[]] .three = true := by decide
def e2422373768714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422373768714 : Closed e2422373768714 ∧ code e2422373768714 = 11218466790922 := by decide
theorem cert_e2422373768714 : check e2422373768714 [[],[]] .smaller = true := by decide
def e2422373768750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373768750 : Closed e2422373768750 ∧ code e2422373768750 = 11218466790958 := by decide
theorem cert_e2422373768750 : check e2422373768750 [[],[]] .smaller = true := by decide
def e2422373768758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373768758 : Closed e2422373768758 ∧ code e2422373768758 = 11218466790966 := by decide
theorem cert_e2422373768758 : check e2422373768758 [[],[]] .smaller = true := by decide
def e2422373768762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373768762 : Closed e2422373768762 ∧ code e2422373768762 = 11218466790970 := by decide
theorem cert_e2422373768762 : check e2422373768762 [[],[]] .smaller = true := by decide
def e2422373768810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422373768810 : Closed e2422373768810 ∧ code e2422373768810 = 11218466791018 := by decide
theorem cert_e2422373768810 : check e2422373768810 [[],[]] .smaller = true := by decide
def e2422373768834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373768834 : Closed e2422373768834 ∧ code e2422373768834 = 11218466791042 := by decide
theorem cert_e2422373768834 : check e2422373768834 [[],[]] .smaller = true := by decide
def e2422373768846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373768846 : Closed e2422373768846 ∧ code e2422373768846 = 11218466791054 := by decide
theorem cert_e2422373768846 : check e2422373768846 [[],[]] .smaller = true := by decide
def e2422373768858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373768858 : Closed e2422373768858 ∧ code e2422373768858 = 11218466791066 := by decide
theorem cert_e2422373768858 : check e2422373768858 [[],[]] .smaller = true := by decide
def e2422373768902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373768902 : Closed e2422373768902 ∧ code e2422373768902 = 11218466791110 := by decide
theorem cert_e2422373768902 : check e2422373768902 [[],[]] .smaller = true := by decide
def e2422373768926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2422373768926 : Closed e2422373768926 ∧ code e2422373768926 = 11218466791134 := by decide
theorem cert_e2422373768926 : check e2422373768926 [[],[]] .three = true := by decide
def e2422373768930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373768930 : Closed e2422373768930 ∧ code e2422373768930 = 11218466791138 := by decide
theorem cert_e2422373768930 : check e2422373768930 [[],[]] .smaller = true := by decide
def e2422373768942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 2))))))))
theorem wire_e2422373768942 : Closed e2422373768942 ∧ code e2422373768942 = 11218466791150 := by decide
theorem cert_e2422373768942 : check e2422373768942 [[],[]] .smaller = true := by decide
def e2422373768950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2422373768950 : Closed e2422373768950 ∧ code e2422373768950 = 11218466791158 := by decide
theorem cert_e2422373768950 : check e2422373768950 [[],[]] .three = true := by decide
def e2422373768982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422373768982 : Closed e2422373768982 ∧ code e2422373768982 = 11218466791190 := by decide
theorem cert_e2422373768982 : check e2422373768982 [[],[]] .three = true := by decide
def e2422373768986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422373768986 : Closed e2422373768986 ∧ code e2422373768986 = 11218466791194 := by decide
theorem cert_e2422373768986 : check e2422373768986 [[],[]] .three = true := by decide
def e2422373769030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422373769030 : Closed e2422373769030 ∧ code e2422373769030 = 11218466791238 := by decide
theorem cert_e2422373769030 : check e2422373769030 [[],[]] .three = true := by decide
def e2422373769054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e2422373769054 : Closed e2422373769054 ∧ code e2422373769054 = 11218466791262 := by decide
theorem cert_e2422373769054 : check e2422373769054 [[],[]] .three = true := by decide
def e2422373769058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422373769058 : Closed e2422373769058 ∧ code e2422373769058 = 11218466791266 := by decide
theorem cert_e2422373769058 : check e2422373769058 [[],[]] .three = true := by decide
def e2422373769070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2422373769070 : Closed e2422373769070 ∧ code e2422373769070 = 11218466791278 := by decide
theorem cert_e2422373769070 : check e2422373769070 [[],[]] .three = true := by decide
def e2422373769078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2422373769078 : Closed e2422373769078 ∧ code e2422373769078 = 11218466791286 := by decide
theorem cert_e2422373769078 : check e2422373769078 [[],[]] .three = true := by decide
def e2422373769082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e2422373769082 : Closed e2422373769082 ∧ code e2422373769082 = 11218466791290 := by decide
theorem cert_e2422373769082 : check e2422373769082 [[],[]] .three = true := by decide
def e2422373769662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 4))))))))))
theorem wire_e2422373769662 : Closed e2422373769662 ∧ code e2422373769662 = 11218466791870 := by decide
theorem cert_e2422373769662 : check e2422373769662 [[],[]] .three = true := by decide
def e2422373769694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422373769694 : Closed e2422373769694 ∧ code e2422373769694 = 11218466791902 := by decide
theorem cert_e2422373769694 : check e2422373769694 [[],[]] .smaller = true := by decide
def e2422373769718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422373769718 : Closed e2422373769718 ∧ code e2422373769718 = 11218466791926 := by decide
theorem cert_e2422373769718 : check e2422373769718 [[],[]] .smaller = true := by decide
def e2422373769722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 4) (.var 0))))))))))
theorem wire_e2422373769722 : Closed e2422373769722 ∧ code e2422373769722 = 11218466791930 := by decide
theorem cert_e2422373769722 : check e2422373769722 [[],[]] .three = true := by decide
def e2422373770670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422373770670 : Closed e2422373770670 ∧ code e2422373770670 = 11218466792878 := by decide
theorem cert_e2422373770670 : check e2422373770670 [[],[]] .smaller = true := by decide
def e2422373770682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422373770682 : Closed e2422373770682 ∧ code e2422373770682 = 11218466792890 := by decide
theorem cert_e2422373770682 : check e2422373770682 [[],[]] .smaller = true := by decide
def e2422373770730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422373770730 : Closed e2422373770730 ∧ code e2422373770730 = 11218466792938 := by decide
theorem cert_e2422373770730 : check e2422373770730 [[],[]] .smaller = true := by decide
def e2422373770814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422373770814 : Closed e2422373770814 ∧ code e2422373770814 = 11218466793022 := by decide
theorem cert_e2422373770814 : check e2422373770814 [[],[]] .three = true := by decide
def e2422373770862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373770862 : Closed e2422373770862 ∧ code e2422373770862 = 11218466793070 := by decide
theorem cert_e2422373770862 : check e2422373770862 [[],[]] .smaller = true := by decide
def e2422373770874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373770874 : Closed e2422373770874 ∧ code e2422373770874 = 11218466793082 := by decide
theorem cert_e2422373770874 : check e2422373770874 [[],[]] .smaller = true := by decide
def e2422373771038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422373771038 : Closed e2422373771038 ∧ code e2422373771038 = 11218466793246 := by decide
theorem cert_e2422373771038 : check e2422373771038 [[],[]] .smaller = true := by decide
def e2422373771138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373771138 : Closed e2422373771138 ∧ code e2422373771138 = 11218466793346 := by decide
theorem cert_e2422373771138 : check e2422373771138 [[],[]] .smaller = true := by decide
def e2422373771150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422373771150 : Closed e2422373771150 ∧ code e2422373771150 = 11218466793358 := by decide
theorem cert_e2422373771150 : check e2422373771150 [[],[]] .smaller = true := by decide
def e2422373771162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373771162 : Closed e2422373771162 ∧ code e2422373771162 = 11218466793370 := by decide
theorem cert_e2422373771162 : check e2422373771162 [[],[]] .smaller = true := by decide
def e2422373771206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422373771206 : Closed e2422373771206 ∧ code e2422373771206 = 11218466793414 := by decide
theorem cert_e2422373771206 : check e2422373771206 [[],[]] .three = true := by decide
def e2422373771230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422373771230 : Closed e2422373771230 ∧ code e2422373771230 = 11218466793438 := by decide
theorem cert_e2422373771230 : check e2422373771230 [[],[]] .three = true := by decide
def e2422373773438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 5))))))))))
theorem wire_e2422373773438 : Closed e2422373773438 ∧ code e2422373773438 = 11218466795646 := by decide
theorem cert_e2422373773438 : check e2422373773438 [[],[]] .three = true := by decide
def e2422373773534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2422373773534 : Closed e2422373773534 ∧ code e2422373773534 = 11218466795742 := by decide
theorem cert_e2422373773534 : check e2422373773534 [[],[]] .smaller = true := by decide
def e2422373773562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2422373773562 : Closed e2422373773562 ∧ code e2422373773562 = 11218466795770 := by decide
theorem cert_e2422373773562 : check e2422373773562 [[],[]] .smaller = true := by decide
def e2422373774110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422373774110 : Closed e2422373774110 ∧ code e2422373774110 = 11218466796318 := by decide
theorem cert_e2422373774110 : check e2422373774110 [[],[]] .smaller = true := by decide
def e2422373774278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422373774278 : Closed e2422373774278 ∧ code e2422373774278 = 11218466796486 := by decide
theorem cert_e2422373774278 : check e2422373774278 [[],[]] .smaller = true := by decide
def e2422373774302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373774302 : Closed e2422373774302 ∧ code e2422373774302 = 11218466796510 := by decide
theorem cert_e2422373774302 : check e2422373774302 [[],[]] .three = true := by decide
def e2422373774306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422373774306 : Closed e2422373774306 ∧ code e2422373774306 = 11218466796514 := by decide
theorem cert_e2422373774306 : check e2422373774306 [[],[]] .three = true := by decide
def e2422373774318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373774318 : Closed e2422373774318 ∧ code e2422373774318 = 11218466796526 := by decide
theorem cert_e2422373774318 : check e2422373774318 [[],[]] .three = true := by decide
def e2422373775386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422373775386 : Closed e2422373775386 ∧ code e2422373775386 = 11218466797594 := by decide
theorem cert_e2422373775386 : check e2422373775386 [[],[]] .smaller = true := by decide
def e2422373775422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373775422 : Closed e2422373775422 ∧ code e2422373775422 = 11218466797630 := by decide
theorem cert_e2422373775422 : check e2422373775422 [[],[]] .smaller = true := by decide
def e2422373775470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373775470 : Closed e2422373775470 ∧ code e2422373775470 = 11218466797678 := by decide
theorem cert_e2422373775470 : check e2422373775470 [[],[]] .smaller = true := by decide
def e2422373775478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373775478 : Closed e2422373775478 ∧ code e2422373775478 = 11218466797686 := by decide
theorem cert_e2422373775478 : check e2422373775478 [[],[]] .smaller = true := by decide
def e2422373775482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373775482 : Closed e2422373775482 ∧ code e2422373775482 = 11218466797690 := by decide
theorem cert_e2422373775482 : check e2422373775482 [[],[]] .smaller = true := by decide
def e2422373775722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422373775722 : Closed e2422373775722 ∧ code e2422373775722 = 11218466797930 := by decide
theorem cert_e2422373775722 : check e2422373775722 [[],[]] .smaller = true := by decide
def e2422373775746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373775746 : Closed e2422373775746 ∧ code e2422373775746 = 11218466797954 := by decide
theorem cert_e2422373775746 : check e2422373775746 [[],[]] .smaller = true := by decide
def e2422373775758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373775758 : Closed e2422373775758 ∧ code e2422373775758 = 11218466797966 := by decide
theorem cert_e2422373775758 : check e2422373775758 [[],[]] .smaller = true := by decide
def e2422373775770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373775770 : Closed e2422373775770 ∧ code e2422373775770 = 11218466797978 := by decide
theorem cert_e2422373775770 : check e2422373775770 [[],[]] .smaller = true := by decide
def e2422373775814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373775814 : Closed e2422373775814 ∧ code e2422373775814 = 11218466798022 := by decide
theorem cert_e2422373775814 : check e2422373775814 [[],[]] .smaller = true := by decide
def e2422373775838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373775838 : Closed e2422373775838 ∧ code e2422373775838 = 11218466798046 := by decide
theorem cert_e2422373775838 : check e2422373775838 [[],[]] .three = true := by decide
def e2422373775842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373775842 : Closed e2422373775842 ∧ code e2422373775842 = 11218466798050 := by decide
theorem cert_e2422373775842 : check e2422373775842 [[],[]] .smaller = true := by decide
def e2422373775854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373775854 : Closed e2422373775854 ∧ code e2422373775854 = 11218466798062 := by decide
theorem cert_e2422373775854 : check e2422373775854 [[],[]] .smaller = true := by decide
def e2422373775862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373775862 : Closed e2422373775862 ∧ code e2422373775862 = 11218466798070 := by decide
theorem cert_e2422373775862 : check e2422373775862 [[],[]] .three = true := by decide
def e2422373776414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.lam (.var 3))))))))))
theorem wire_e2422373776414 : Closed e2422373776414 ∧ code e2422373776414 = 11218466798622 := by decide
theorem cert_e2422373776414 : check e2422373776414 [[],[]] .three = true := by decide
def e2422373776438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373776438 : Closed e2422373776438 ∧ code e2422373776438 = 11218466798646 := by decide
theorem cert_e2422373776438 : check e2422373776438 [[],[]] .three = true := by decide
def e2422373776442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373776442 : Closed e2422373776442 ∧ code e2422373776442 = 11218466798650 := by decide
theorem cert_e2422373776442 : check e2422373776442 [[],[]] .three = true := by decide
def e2422373776582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422373776582 : Closed e2422373776582 ∧ code e2422373776582 = 11218466798790 := by decide
theorem cert_e2422373776582 : check e2422373776582 [[],[]] .three = true := by decide
def e2422373776606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373776606 : Closed e2422373776606 ∧ code e2422373776606 = 11218466798814 := by decide
theorem cert_e2422373776606 : check e2422373776606 [[],[]] .three = true := by decide
def e2422373776610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422373776610 : Closed e2422373776610 ∧ code e2422373776610 = 11218466798818 := by decide
theorem cert_e2422373776610 : check e2422373776610 [[],[]] .three = true := by decide
def e2422373776622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373776622 : Closed e2422373776622 ∧ code e2422373776622 = 11218466798830 := by decide
theorem cert_e2422373776622 : check e2422373776622 [[],[]] .three = true := by decide
def e2422373776630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373776630 : Closed e2422373776630 ∧ code e2422373776630 = 11218466798838 := by decide
theorem cert_e2422373776630 : check e2422373776630 [[],[]] .three = true := by decide
def e2422373776634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373776634 : Closed e2422373776634 ∧ code e2422373776634 = 11218466798842 := by decide
theorem cert_e2422373776634 : check e2422373776634 [[],[]] .three = true := by decide
def e2422373813102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422373813102 : Closed e2422373813102 ∧ code e2422373813102 = 11218466835310 := by decide
theorem cert_e2422373813102 : check e2422373813102 [[],[]] .smaller = true := by decide
def e2422373813110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422373813110 : Closed e2422373813110 ∧ code e2422373813110 = 11218466835318 := by decide
theorem cert_e2422373813110 : check e2422373813110 [[],[]] .smaller = true := by decide
def e2422373813166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422373813166 : Closed e2422373813166 ∧ code e2422373813166 = 11218466835374 := by decide
theorem cert_e2422373813166 : check e2422373813166 [[],[]] .smaller = true := by decide
def e2422373813178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422373813178 : Closed e2422373813178 ∧ code e2422373813178 = 11218466835386 := by decide
theorem cert_e2422373813178 : check e2422373813178 [[],[]] .smaller = true := by decide
def e2422373813206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422373813206 : Closed e2422373813206 ∧ code e2422373813206 = 11218466835414 := by decide
theorem cert_e2422373813206 : check e2422373813206 [[],[]] .smaller = true := by decide
def e2422373813210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422373813210 : Closed e2422373813210 ∧ code e2422373813210 = 11218466835418 := by decide
theorem cert_e2422373813210 : check e2422373813210 [[],[]] .smaller = true := by decide
def e2422373813486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373813486 : Closed e2422373813486 ∧ code e2422373813486 = 11218466835694 := by decide
theorem cert_e2422373813486 : check e2422373813486 [[],[]] .smaller = true := by decide
def e2422373813494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373813494 : Closed e2422373813494 ∧ code e2422373813494 = 11218466835702 := by decide
theorem cert_e2422373813494 : check e2422373813494 [[],[]] .smaller = true := by decide
def e2422373813822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2422373813822 : Closed e2422373813822 ∧ code e2422373813822 = 11218466836030 := by decide
theorem cert_e2422373813822 : check e2422373813822 [[],[]] .smaller = true := by decide
def e2422373813870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373813870 : Closed e2422373813870 ∧ code e2422373813870 = 11218466836078 := by decide
theorem cert_e2422373813870 : check e2422373813870 [[],[]] .smaller = true := by decide
def e2422373813882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373813882 : Closed e2422373813882 ∧ code e2422373813882 = 11218466836090 := by decide
theorem cert_e2422373813882 : check e2422373813882 [[],[]] .smaller = true := by decide
def e2422373814070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373814070 : Closed e2422373814070 ∧ code e2422373814070 = 11218466836278 := by decide
theorem cert_e2422373814070 : check e2422373814070 [[],[]] .smaller = true := by decide
def e2422373814074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373814074 : Closed e2422373814074 ∧ code e2422373814074 = 11218466836282 := by decide
theorem cert_e2422373814074 : check e2422373814074 [[],[]] .smaller = true := by decide
def e2422373814158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2422373814158 : Closed e2422373814158 ∧ code e2422373814158 = 11218466836366 := by decide
theorem cert_e2422373814158 : check e2422373814158 [[],[]] .smaller = true := by decide
def e2422373814206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 4)))))))))
theorem wire_e2422373814206 : Closed e2422373814206 ∧ code e2422373814206 = 11218466836414 := by decide
theorem cert_e2422373814206 : check e2422373814206 [[],[]] .three = true := by decide
def e2422373814238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 4) (.var 3)))))))))
theorem wire_e2422373814238 : Closed e2422373814238 ∧ code e2422373814238 = 11218466836446 := by decide
theorem cert_e2422373814238 : check e2422373814238 [[],[]] .three = true := by decide
def e2422373821534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422373821534 : Closed e2422373821534 ∧ code e2422373821534 = 11218466843742 := by decide
theorem cert_e2422373821534 : check e2422373821534 [[],[]] .three = true := by decide
def e2422373821550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422373821550 : Closed e2422373821550 ∧ code e2422373821550 = 11218466843758 := by decide
theorem cert_e2422373821550 : check e2422373821550 [[],[]] .smaller = true := by decide
end Blc.Floor43
