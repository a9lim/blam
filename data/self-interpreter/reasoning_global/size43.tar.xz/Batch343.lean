import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419140588346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419140588346 : Closed e2419140588346 ∧ code e2419140588346 = 11215233610554 := by decide
theorem cert_e2419140588346 : check e2419140588346 [[],[]] .three = true := by decide
def e2419140588442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419140588442 : Closed e2419140588442 ∧ code e2419140588442 = 11215233610650 := by decide
theorem cert_e2419140588442 : check e2419140588442 [[],[]] .three = true := by decide
def e2419141031278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2419141031278 : Closed e2419141031278 ∧ code e2419141031278 = 11215234053486 := by decide
theorem cert_e2419141031278 : check e2419141031278 [[],[]] .smaller = true := by decide
def e2419141031286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2419141031286 : Closed e2419141031286 ∧ code e2419141031286 = 11215234053494 := by decide
theorem cert_e2419141031286 : check e2419141031286 [[],[]] .smaller = true := by decide
def e2419141031342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2419141031342 : Closed e2419141031342 ∧ code e2419141031342 = 11215234053550 := by decide
theorem cert_e2419141031342 : check e2419141031342 [[],[]] .smaller = true := by decide
def e2419141031354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2419141031354 : Closed e2419141031354 ∧ code e2419141031354 = 11215234053562 := by decide
theorem cert_e2419141031354 : check e2419141031354 [[],[]] .smaller = true := by decide
def e2419141031382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2419141031382 : Closed e2419141031382 ∧ code e2419141031382 = 11215234053590 := by decide
theorem cert_e2419141031382 : check e2419141031382 [[],[]] .smaller = true := by decide
def e2419141031386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2419141031386 : Closed e2419141031386 ∧ code e2419141031386 = 11215234053594 := by decide
theorem cert_e2419141031386 : check e2419141031386 [[],[]] .smaller = true := by decide
def e2419141031598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2419141031598 : Closed e2419141031598 ∧ code e2419141031598 = 11215234053806 := by decide
theorem cert_e2419141031598 : check e2419141031598 [[],[]] .smaller = true := by decide
def e2419141031610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2419141031610 : Closed e2419141031610 ∧ code e2419141031610 = 11215234053818 := by decide
theorem cert_e2419141031610 : check e2419141031610 [[],[]] .smaller = true := by decide
def e2419141031658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2419141031658 : Closed e2419141031658 ∧ code e2419141031658 = 11215234053866 := by decide
theorem cert_e2419141031658 : check e2419141031658 [[],[]] .smaller = true := by decide
def e2419141031766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2419141031766 : Closed e2419141031766 ∧ code e2419141031766 = 11215234053974 := by decide
theorem cert_e2419141031766 : check e2419141031766 [[],[]] .smaller = true := by decide
def e2419141031770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2419141031770 : Closed e2419141031770 ∧ code e2419141031770 = 11215234053978 := by decide
theorem cert_e2419141031770 : check e2419141031770 [[],[]] .smaller = true := by decide
def e2419141031786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2419141031786 : Closed e2419141031786 ∧ code e2419141031786 = 11215234053994 := by decide
theorem cert_e2419141031786 : check e2419141031786 [[],[]] .smaller = true := by decide
def e2419141032622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2419141032622 : Closed e2419141032622 ∧ code e2419141032622 = 11215234054830 := by decide
theorem cert_e2419141032622 : check e2419141032622 [[],[]] .smaller = true := by decide
def e2419141032634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2419141032634 : Closed e2419141032634 ∧ code e2419141032634 = 11215234054842 := by decide
theorem cert_e2419141032634 : check e2419141032634 [[],[]] .smaller = true := by decide
def e2419141032682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2419141032682 : Closed e2419141032682 ∧ code e2419141032682 = 11215234054890 := by decide
theorem cert_e2419141032682 : check e2419141032682 [[],[]] .smaller = true := by decide
def e2419141032874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2419141032874 : Closed e2419141032874 ∧ code e2419141032874 = 11215234055082 := by decide
theorem cert_e2419141032874 : check e2419141032874 [[],[]] .smaller = true := by decide
def e2419141033302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2419141033302 : Closed e2419141033302 ∧ code e2419141033302 = 11215234055510 := by decide
theorem cert_e2419141033302 : check e2419141033302 [[],[]] .smaller = true := by decide
def e2419141033306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2419141033306 : Closed e2419141033306 ∧ code e2419141033306 = 11215234055514 := by decide
theorem cert_e2419141033306 : check e2419141033306 [[],[]] .smaller = true := by decide
def e2419141033322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2419141033322 : Closed e2419141033322 ∧ code e2419141033322 = 11215234055530 := by decide
theorem cert_e2419141033322 : check e2419141033322 [[],[]] .smaller = true := by decide
def e2419141033386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2419141033386 : Closed e2419141033386 ∧ code e2419141033386 = 11215234055594 := by decide
theorem cert_e2419141033386 : check e2419141033386 [[],[]] .smaller = true := by decide
def e2419141035742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e2419141035742 : Closed e2419141035742 ∧ code e2419141035742 = 11215234057950 := by decide
theorem cert_e2419141035742 : check e2419141035742 [[],[]] .three = true := by decide
def e2419141035766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e2419141035766 : Closed e2419141035766 ∧ code e2419141035766 = 11215234057974 := by decide
theorem cert_e2419141035766 : check e2419141035766 [[],[]] .three = true := by decide
def e2419141035870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2419141035870 : Closed e2419141035870 ∧ code e2419141035870 = 11215234058078 := by decide
theorem cert_e2419141035870 : check e2419141035870 [[],[]] .three = true := by decide
def e2419141035886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e2419141035886 : Closed e2419141035886 ∧ code e2419141035886 = 11215234058094 := by decide
theorem cert_e2419141035886 : check e2419141035886 [[],[]] .smaller = true := by decide
def e2419141035894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e2419141035894 : Closed e2419141035894 ∧ code e2419141035894 = 11215234058102 := by decide
theorem cert_e2419141035894 : check e2419141035894 [[],[]] .smaller = true := by decide
def e2419141035898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2419141035898 : Closed e2419141035898 ∧ code e2419141035898 = 11215234058106 := by decide
theorem cert_e2419141035898 : check e2419141035898 [[],[]] .three = true := by decide
def e2419141035958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e2419141035958 : Closed e2419141035958 ∧ code e2419141035958 = 11215234058166 := by decide
theorem cert_e2419141035958 : check e2419141035958 [[],[]] .smaller = true := by decide
def e2419141035990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e2419141035990 : Closed e2419141035990 ∧ code e2419141035990 = 11215234058198 := by decide
theorem cert_e2419141035990 : check e2419141035990 [[],[]] .three = true := by decide
def e2419141035994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e2419141035994 : Closed e2419141035994 ∧ code e2419141035994 = 11215234058202 := by decide
theorem cert_e2419141035994 : check e2419141035994 [[],[]] .three = true := by decide
def e2419141037422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2419141037422 : Closed e2419141037422 ∧ code e2419141037422 = 11215234059630 := by decide
theorem cert_e2419141037422 : check e2419141037422 [[],[]] .smaller = true := by decide
def e2419141037430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2419141037430 : Closed e2419141037430 ∧ code e2419141037430 = 11215234059638 := by decide
theorem cert_e2419141037430 : check e2419141037430 [[],[]] .smaller = true := by decide
def e2419141037486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2419141037486 : Closed e2419141037486 ∧ code e2419141037486 = 11215234059694 := by decide
theorem cert_e2419141037486 : check e2419141037486 [[],[]] .smaller = true := by decide
def e2419141037498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2419141037498 : Closed e2419141037498 ∧ code e2419141037498 = 11215234059706 := by decide
theorem cert_e2419141037498 : check e2419141037498 [[],[]] .smaller = true := by decide
def e2419141037526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2419141037526 : Closed e2419141037526 ∧ code e2419141037526 = 11215234059734 := by decide
theorem cert_e2419141037526 : check e2419141037526 [[],[]] .smaller = true := by decide
def e2419141037530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2419141037530 : Closed e2419141037530 ∧ code e2419141037530 = 11215234059738 := by decide
theorem cert_e2419141037530 : check e2419141037530 [[],[]] .smaller = true := by decide
def e2419141037742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2419141037742 : Closed e2419141037742 ∧ code e2419141037742 = 11215234059950 := by decide
theorem cert_e2419141037742 : check e2419141037742 [[],[]] .smaller = true := by decide
def e2419141037754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2419141037754 : Closed e2419141037754 ∧ code e2419141037754 = 11215234059962 := by decide
theorem cert_e2419141037754 : check e2419141037754 [[],[]] .smaller = true := by decide
def e2419141037802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2419141037802 : Closed e2419141037802 ∧ code e2419141037802 = 11215234060010 := by decide
theorem cert_e2419141037802 : check e2419141037802 [[],[]] .smaller = true := by decide
def e2419141037910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2419141037910 : Closed e2419141037910 ∧ code e2419141037910 = 11215234060118 := by decide
theorem cert_e2419141037910 : check e2419141037910 [[],[]] .smaller = true := by decide
def e2419141037914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2419141037914 : Closed e2419141037914 ∧ code e2419141037914 = 11215234060122 := by decide
theorem cert_e2419141037914 : check e2419141037914 [[],[]] .smaller = true := by decide
def e2419141037930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2419141037930 : Closed e2419141037930 ∧ code e2419141037930 = 11215234060138 := by decide
theorem cert_e2419141037930 : check e2419141037930 [[],[]] .smaller = true := by decide
def e2419141038558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2419141038558 : Closed e2419141038558 ∧ code e2419141038558 = 11215234060766 := by decide
theorem cert_e2419141038558 : check e2419141038558 [[],[]] .three = true := by decide
def e2419141038582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2419141038582 : Closed e2419141038582 ∧ code e2419141038582 = 11215234060790 := by decide
theorem cert_e2419141038582 : check e2419141038582 [[],[]] .three = true := by decide
def e2419141038958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2419141038958 : Closed e2419141038958 ∧ code e2419141038958 = 11215234061166 := by decide
theorem cert_e2419141038958 : check e2419141038958 [[],[]] .smaller = true := by decide
def e2419141038966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2419141038966 : Closed e2419141038966 ∧ code e2419141038966 = 11215234061174 := by decide
theorem cert_e2419141038966 : check e2419141038966 [[],[]] .smaller = true := by decide
def e2419141039022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2419141039022 : Closed e2419141039022 ∧ code e2419141039022 = 11215234061230 := by decide
theorem cert_e2419141039022 : check e2419141039022 [[],[]] .smaller = true := by decide
def e2419141039034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2419141039034 : Closed e2419141039034 ∧ code e2419141039034 = 11215234061242 := by decide
theorem cert_e2419141039034 : check e2419141039034 [[],[]] .smaller = true := by decide
def e2419141039062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2419141039062 : Closed e2419141039062 ∧ code e2419141039062 = 11215234061270 := by decide
theorem cert_e2419141039062 : check e2419141039062 [[],[]] .smaller = true := by decide
def e2419141039066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2419141039066 : Closed e2419141039066 ∧ code e2419141039066 = 11215234061274 := by decide
theorem cert_e2419141039066 : check e2419141039066 [[],[]] .smaller = true := by decide
def e2419141039342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419141039342 : Closed e2419141039342 ∧ code e2419141039342 = 11215234061550 := by decide
theorem cert_e2419141039342 : check e2419141039342 [[],[]] .smaller = true := by decide
def e2419141039350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419141039350 : Closed e2419141039350 ∧ code e2419141039350 = 11215234061558 := by decide
theorem cert_e2419141039350 : check e2419141039350 [[],[]] .smaller = true := by decide
def e2419141039678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2419141039678 : Closed e2419141039678 ∧ code e2419141039678 = 11215234061886 := by decide
theorem cert_e2419141039678 : check e2419141039678 [[],[]] .three = true := by decide
def e2419141039726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141039726 : Closed e2419141039726 ∧ code e2419141039726 = 11215234061934 := by decide
theorem cert_e2419141039726 : check e2419141039726 [[],[]] .smaller = true := by decide
def e2419141039738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141039738 : Closed e2419141039738 ∧ code e2419141039738 = 11215234061946 := by decide
theorem cert_e2419141039738 : check e2419141039738 [[],[]] .smaller = true := by decide
def e2419141039926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141039926 : Closed e2419141039926 ∧ code e2419141039926 = 11215234062134 := by decide
theorem cert_e2419141039926 : check e2419141039926 [[],[]] .smaller = true := by decide
def e2419141039930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141039930 : Closed e2419141039930 ∧ code e2419141039930 = 11215234062138 := by decide
theorem cert_e2419141039930 : check e2419141039930 [[],[]] .smaller = true := by decide
def e2419141040014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2419141040014 : Closed e2419141040014 ∧ code e2419141040014 = 11215234062222 := by decide
theorem cert_e2419141040014 : check e2419141040014 [[],[]] .three = true := by decide
def e2419141040350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2419141040350 : Closed e2419141040350 ∧ code e2419141040350 = 11215234062558 := by decide
theorem cert_e2419141040350 : check e2419141040350 [[],[]] .three = true := by decide
def e2419141040366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2419141040366 : Closed e2419141040366 ∧ code e2419141040366 = 11215234062574 := by decide
theorem cert_e2419141040366 : check e2419141040366 [[],[]] .smaller = true := by decide
def e2419141040374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2419141040374 : Closed e2419141040374 ∧ code e2419141040374 = 11215234062582 := by decide
theorem cert_e2419141040374 : check e2419141040374 [[],[]] .smaller = true := by decide
def e2419141040378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2419141040378 : Closed e2419141040378 ∧ code e2419141040378 = 11215234062586 := by decide
theorem cert_e2419141040378 : check e2419141040378 [[],[]] .three = true := by decide
def e2419141040558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2419141040558 : Closed e2419141040558 ∧ code e2419141040558 = 11215234062766 := by decide
theorem cert_e2419141040558 : check e2419141040558 [[],[]] .smaller = true := by decide
def e2419141040570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2419141040570 : Closed e2419141040570 ∧ code e2419141040570 = 11215234062778 := by decide
theorem cert_e2419141040570 : check e2419141040570 [[],[]] .smaller = true := by decide
def e2419141040618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2419141040618 : Closed e2419141040618 ∧ code e2419141040618 = 11215234062826 := by decide
theorem cert_e2419141040618 : check e2419141040618 [[],[]] .smaller = true := by decide
def e2419141040702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2419141040702 : Closed e2419141040702 ∧ code e2419141040702 = 11215234062910 := by decide
theorem cert_e2419141040702 : check e2419141040702 [[],[]] .three = true := by decide
def e2419141040750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141040750 : Closed e2419141040750 ∧ code e2419141040750 = 11215234062958 := by decide
theorem cert_e2419141040750 : check e2419141040750 [[],[]] .smaller = true := by decide
def e2419141040762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141040762 : Closed e2419141040762 ∧ code e2419141040762 = 11215234062970 := by decide
theorem cert_e2419141040762 : check e2419141040762 [[],[]] .smaller = true := by decide
def e2419141040926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2419141040926 : Closed e2419141040926 ∧ code e2419141040926 = 11215234063134 := by decide
theorem cert_e2419141040926 : check e2419141040926 [[],[]] .smaller = true := by decide
def e2419141041038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2419141041038 : Closed e2419141041038 ∧ code e2419141041038 = 11215234063246 := by decide
theorem cert_e2419141041038 : check e2419141041038 [[],[]] .smaller = true := by decide
def e2419141041050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141041050 : Closed e2419141041050 ∧ code e2419141041050 = 11215234063258 := by decide
theorem cert_e2419141041050 : check e2419141041050 [[],[]] .smaller = true := by decide
def e2419141041094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2419141041094 : Closed e2419141041094 ∧ code e2419141041094 = 11215234063302 := by decide
theorem cert_e2419141041094 : check e2419141041094 [[],[]] .three = true := by decide
def e2419141041118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3)))))))
theorem wire_e2419141041118 : Closed e2419141041118 ∧ code e2419141041118 = 11215234063326 := by decide
theorem cert_e2419141041118 : check e2419141041118 [[],[]] .three = true := by decide
def e2419141041270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2419141041270 : Closed e2419141041270 ∧ code e2419141041270 = 11215234063478 := by decide
theorem cert_e2419141041270 : check e2419141041270 [[],[]] .smaller = true := by decide
def e2419141041366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2419141041366 : Closed e2419141041366 ∧ code e2419141041366 = 11215234063574 := by decide
theorem cert_e2419141041366 : check e2419141041366 [[],[]] .smaller = true := by decide
def e2419141041370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2419141041370 : Closed e2419141041370 ∧ code e2419141041370 = 11215234063578 := by decide
theorem cert_e2419141041370 : check e2419141041370 [[],[]] .smaller = true := by decide
def e2419141041386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2419141041386 : Closed e2419141041386 ∧ code e2419141041386 = 11215234063594 := by decide
theorem cert_e2419141041386 : check e2419141041386 [[],[]] .smaller = true := by decide
def e2419141041462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141041462 : Closed e2419141041462 ∧ code e2419141041462 = 11215234063670 := by decide
theorem cert_e2419141041462 : check e2419141041462 [[],[]] .smaller = true := by decide
def e2419141041466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141041466 : Closed e2419141041466 ∧ code e2419141041466 = 11215234063674 := by decide
theorem cert_e2419141041466 : check e2419141041466 [[],[]] .smaller = true := by decide
def e2419141041550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2419141041550 : Closed e2419141041550 ∧ code e2419141041550 = 11215234063758 := by decide
theorem cert_e2419141041550 : check e2419141041550 [[],[]] .smaller = true := by decide
def e2419141041562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141041562 : Closed e2419141041562 ∧ code e2419141041562 = 11215234063770 := by decide
theorem cert_e2419141041562 : check e2419141041562 [[],[]] .smaller = true := by decide
def e2419141041630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3)))))))
theorem wire_e2419141041630 : Closed e2419141041630 ∧ code e2419141041630 = 11215234063838 := by decide
theorem cert_e2419141041630 : check e2419141041630 [[],[]] .three = true := by decide
def e2419141041646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2)))))))
theorem wire_e2419141041646 : Closed e2419141041646 ∧ code e2419141041646 = 11215234063854 := by decide
theorem cert_e2419141041646 : check e2419141041646 [[],[]] .three = true := by decide
def e2419141041718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2419141041718 : Closed e2419141041718 ∧ code e2419141041718 = 11215234063926 := by decide
theorem cert_e2419141041718 : check e2419141041718 [[],[]] .three = true := by decide
def e2419141041722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2419141041722 : Closed e2419141041722 ∧ code e2419141041722 = 11215234063930 := by decide
theorem cert_e2419141041722 : check e2419141041722 [[],[]] .three = true := by decide
def e2419141041806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2419141041806 : Closed e2419141041806 ∧ code e2419141041806 = 11215234064014 := by decide
theorem cert_e2419141041806 : check e2419141041806 [[],[]] .three = true := by decide
def e2419141041862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2419141041862 : Closed e2419141041862 ∧ code e2419141041862 = 11215234064070 := by decide
theorem cert_e2419141041862 : check e2419141041862 [[],[]] .three = true := by decide
def e2419141041886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3)))))))
theorem wire_e2419141041886 : Closed e2419141041886 ∧ code e2419141041886 = 11215234064094 := by decide
theorem cert_e2419141041886 : check e2419141041886 [[],[]] .three = true := by decide
def e2419141041902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2)))))))
theorem wire_e2419141041902 : Closed e2419141041902 ∧ code e2419141041902 = 11215234064110 := by decide
theorem cert_e2419141041902 : check e2419141041902 [[],[]] .three = true := by decide
def e2419141041910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1)))))))
theorem wire_e2419141041910 : Closed e2419141041910 ∧ code e2419141041910 = 11215234064118 := by decide
theorem cert_e2419141041910 : check e2419141041910 [[],[]] .three = true := by decide
def e2419141043038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2419141043038 : Closed e2419141043038 ∧ code e2419141043038 = 11215234065246 := by decide
theorem cert_e2419141043038 : check e2419141043038 [[],[]] .three = true := by decide
def e2419141043054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2419141043054 : Closed e2419141043054 ∧ code e2419141043054 = 11215234065262 := by decide
theorem cert_e2419141043054 : check e2419141043054 [[],[]] .smaller = true := by decide
def e2419141043062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2419141043062 : Closed e2419141043062 ∧ code e2419141043062 = 11215234065270 := by decide
theorem cert_e2419141043062 : check e2419141043062 [[],[]] .smaller = true := by decide
def e2419141043066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2419141043066 : Closed e2419141043066 ∧ code e2419141043066 = 11215234065274 := by decide
theorem cert_e2419141043066 : check e2419141043066 [[],[]] .three = true := by decide
def e2419141043118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2419141043118 : Closed e2419141043118 ∧ code e2419141043118 = 11215234065326 := by decide
theorem cert_e2419141043118 : check e2419141043118 [[],[]] .smaller = true := by decide
def e2419141043130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2419141043130 : Closed e2419141043130 ∧ code e2419141043130 = 11215234065338 := by decide
theorem cert_e2419141043130 : check e2419141043130 [[],[]] .smaller = true := by decide
def e2419141043158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2419141043158 : Closed e2419141043158 ∧ code e2419141043158 = 11215234065366 := by decide
theorem cert_e2419141043158 : check e2419141043158 [[],[]] .smaller = true := by decide
def e2419141043162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2419141043162 : Closed e2419141043162 ∧ code e2419141043162 = 11215234065370 := by decide
theorem cert_e2419141043162 : check e2419141043162 [[],[]] .smaller = true := by decide
def e2419141043178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e2419141043178 : Closed e2419141043178 ∧ code e2419141043178 = 11215234065386 := by decide
theorem cert_e2419141043178 : check e2419141043178 [[],[]] .three = true := by decide
def e2419141043886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2419141043886 : Closed e2419141043886 ∧ code e2419141043886 = 11215234066094 := by decide
theorem cert_e2419141043886 : check e2419141043886 [[],[]] .smaller = true := by decide
def e2419141043898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2419141043898 : Closed e2419141043898 ∧ code e2419141043898 = 11215234066106 := by decide
theorem cert_e2419141043898 : check e2419141043898 [[],[]] .smaller = true := by decide
def e2419141043946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2419141043946 : Closed e2419141043946 ∧ code e2419141043946 = 11215234066154 := by decide
theorem cert_e2419141043946 : check e2419141043946 [[],[]] .smaller = true := by decide
def e2419141044138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2419141044138 : Closed e2419141044138 ∧ code e2419141044138 = 11215234066346 := by decide
theorem cert_e2419141044138 : check e2419141044138 [[],[]] .smaller = true := by decide
def e2419141044446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2419141044446 : Closed e2419141044446 ∧ code e2419141044446 = 11215234066654 := by decide
theorem cert_e2419141044446 : check e2419141044446 [[],[]] .three = true := by decide
def e2419141044462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2419141044462 : Closed e2419141044462 ∧ code e2419141044462 = 11215234066670 := by decide
theorem cert_e2419141044462 : check e2419141044462 [[],[]] .smaller = true := by decide
def e2419141044470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2419141044470 : Closed e2419141044470 ∧ code e2419141044470 = 11215234066678 := by decide
theorem cert_e2419141044470 : check e2419141044470 [[],[]] .smaller = true := by decide
def e2419141044474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2419141044474 : Closed e2419141044474 ∧ code e2419141044474 = 11215234066682 := by decide
theorem cert_e2419141044474 : check e2419141044474 [[],[]] .three = true := by decide
def e2419141044654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2419141044654 : Closed e2419141044654 ∧ code e2419141044654 = 11215234066862 := by decide
theorem cert_e2419141044654 : check e2419141044654 [[],[]] .smaller = true := by decide
def e2419141044666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2419141044666 : Closed e2419141044666 ∧ code e2419141044666 = 11215234066874 := by decide
theorem cert_e2419141044666 : check e2419141044666 [[],[]] .smaller = true := by decide
def e2419141044714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2419141044714 : Closed e2419141044714 ∧ code e2419141044714 = 11215234066922 := by decide
theorem cert_e2419141044714 : check e2419141044714 [[],[]] .smaller = true := by decide
def e2419141044798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2419141044798 : Closed e2419141044798 ∧ code e2419141044798 = 11215234067006 := by decide
theorem cert_e2419141044798 : check e2419141044798 [[],[]] .three = true := by decide
def e2419141044846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141044846 : Closed e2419141044846 ∧ code e2419141044846 = 11215234067054 := by decide
theorem cert_e2419141044846 : check e2419141044846 [[],[]] .smaller = true := by decide
def e2419141044858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141044858 : Closed e2419141044858 ∧ code e2419141044858 = 11215234067066 := by decide
theorem cert_e2419141044858 : check e2419141044858 [[],[]] .smaller = true := by decide
def e2419141045022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2419141045022 : Closed e2419141045022 ∧ code e2419141045022 = 11215234067230 := by decide
theorem cert_e2419141045022 : check e2419141045022 [[],[]] .smaller = true := by decide
def e2419141045134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2419141045134 : Closed e2419141045134 ∧ code e2419141045134 = 11215234067342 := by decide
theorem cert_e2419141045134 : check e2419141045134 [[],[]] .smaller = true := by decide
def e2419141045146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141045146 : Closed e2419141045146 ∧ code e2419141045146 = 11215234067354 := by decide
theorem cert_e2419141045146 : check e2419141045146 [[],[]] .smaller = true := by decide
def e2419141045190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2419141045190 : Closed e2419141045190 ∧ code e2419141045190 = 11215234067398 := by decide
theorem cert_e2419141045190 : check e2419141045190 [[],[]] .three = true := by decide
def e2419141045214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e2419141045214 : Closed e2419141045214 ∧ code e2419141045214 = 11215234067422 := by decide
theorem cert_e2419141045214 : check e2419141045214 [[],[]] .three = true := by decide
def e2419141045358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2419141045358 : Closed e2419141045358 ∧ code e2419141045358 = 11215234067566 := by decide
theorem cert_e2419141045358 : check e2419141045358 [[],[]] .smaller = true := by decide
def e2419141045370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2419141045370 : Closed e2419141045370 ∧ code e2419141045370 = 11215234067578 := by decide
theorem cert_e2419141045370 : check e2419141045370 [[],[]] .smaller = true := by decide
def e2419141045534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2419141045534 : Closed e2419141045534 ∧ code e2419141045534 = 11215234067742 := by decide
theorem cert_e2419141045534 : check e2419141045534 [[],[]] .smaller = true := by decide
def e2419141045702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2419141045702 : Closed e2419141045702 ∧ code e2419141045702 = 11215234067910 := by decide
theorem cert_e2419141045702 : check e2419141045702 [[],[]] .smaller = true := by decide
def e2419141045726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e2419141045726 : Closed e2419141045726 ∧ code e2419141045726 = 11215234067934 := by decide
theorem cert_e2419141045726 : check e2419141045726 [[],[]] .three = true := by decide
def e2419141045742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e2419141045742 : Closed e2419141045742 ∧ code e2419141045742 = 11215234067950 := by decide
theorem cert_e2419141045742 : check e2419141045742 [[],[]] .three = true := by decide
def e2419141045814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2419141045814 : Closed e2419141045814 ∧ code e2419141045814 = 11215234068022 := by decide
theorem cert_e2419141045814 : check e2419141045814 [[],[]] .smaller = true := by decide
def e2419141045818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2419141045818 : Closed e2419141045818 ∧ code e2419141045818 = 11215234068026 := by decide
theorem cert_e2419141045818 : check e2419141045818 [[],[]] .smaller = true := by decide
def e2419141045866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2419141045866 : Closed e2419141045866 ∧ code e2419141045866 = 11215234068074 := by decide
theorem cert_e2419141045866 : check e2419141045866 [[],[]] .smaller = true := by decide
def e2419141045902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2419141045902 : Closed e2419141045902 ∧ code e2419141045902 = 11215234068110 := by decide
theorem cert_e2419141045902 : check e2419141045902 [[],[]] .smaller = true := by decide
def e2419141045914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141045914 : Closed e2419141045914 ∧ code e2419141045914 = 11215234068122 := by decide
theorem cert_e2419141045914 : check e2419141045914 [[],[]] .smaller = true := by decide
def e2419141045958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2419141045958 : Closed e2419141045958 ∧ code e2419141045958 = 11215234068166 := by decide
theorem cert_e2419141045958 : check e2419141045958 [[],[]] .smaller = true := by decide
def e2419141045982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e2419141045982 : Closed e2419141045982 ∧ code e2419141045982 = 11215234068190 := by decide
theorem cert_e2419141045982 : check e2419141045982 [[],[]] .three = true := by decide
def e2419141046006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e2419141046006 : Closed e2419141046006 ∧ code e2419141046006 = 11215234068214 := by decide
theorem cert_e2419141046006 : check e2419141046006 [[],[]] .three = true := by decide
def e2419141046042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2419141046042 : Closed e2419141046042 ∧ code e2419141046042 = 11215234068250 := by decide
theorem cert_e2419141046042 : check e2419141046042 [[],[]] .three = true := by decide
def e2419141046086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2419141046086 : Closed e2419141046086 ∧ code e2419141046086 = 11215234068294 := by decide
theorem cert_e2419141046086 : check e2419141046086 [[],[]] .three = true := by decide
def e2419141046110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e2419141046110 : Closed e2419141046110 ∧ code e2419141046110 = 11215234068318 := by decide
theorem cert_e2419141046110 : check e2419141046110 [[],[]] .three = true := by decide
def e2419141046126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e2419141046126 : Closed e2419141046126 ∧ code e2419141046126 = 11215234068334 := by decide
theorem cert_e2419141046126 : check e2419141046126 [[],[]] .three = true := by decide
def e2419141046134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e2419141046134 : Closed e2419141046134 ∧ code e2419141046134 = 11215234068342 := by decide
theorem cert_e2419141046134 : check e2419141046134 [[],[]] .three = true := by decide
def e2419141046138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e2419141046138 : Closed e2419141046138 ∧ code e2419141046138 = 11215234068346 := by decide
theorem cert_e2419141046138 : check e2419141046138 [[],[]] .three = true := by decide
def e2419141046710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e2419141046710 : Closed e2419141046710 ∧ code e2419141046710 = 11215234068918 := by decide
theorem cert_e2419141046710 : check e2419141046710 [[],[]] .smaller = true := by decide
def e2419141046742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2419141046742 : Closed e2419141046742 ∧ code e2419141046742 = 11215234068950 := by decide
theorem cert_e2419141046742 : check e2419141046742 [[],[]] .smaller = true := by decide
def e2419141046746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2419141046746 : Closed e2419141046746 ∧ code e2419141046746 = 11215234068954 := by decide
theorem cert_e2419141046746 : check e2419141046746 [[],[]] .smaller = true := by decide
def e2419141047126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2419141047126 : Closed e2419141047126 ∧ code e2419141047126 = 11215234069334 := by decide
theorem cert_e2419141047126 : check e2419141047126 [[],[]] .smaller = true := by decide
def e2419141047130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2419141047130 : Closed e2419141047130 ∧ code e2419141047130 = 11215234069338 := by decide
theorem cert_e2419141047130 : check e2419141047130 [[],[]] .smaller = true := by decide
def e2419141047146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2419141047146 : Closed e2419141047146 ∧ code e2419141047146 = 11215234069354 := by decide
theorem cert_e2419141047146 : check e2419141047146 [[],[]] .smaller = true := by decide
def e2419141047210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2419141047210 : Closed e2419141047210 ∧ code e2419141047210 = 11215234069418 := by decide
theorem cert_e2419141047210 : check e2419141047210 [[],[]] .smaller = true := by decide
def e2419141047414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2419141047414 : Closed e2419141047414 ∧ code e2419141047414 = 11215234069622 := by decide
theorem cert_e2419141047414 : check e2419141047414 [[],[]] .smaller = true := by decide
def e2419141047510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2419141047510 : Closed e2419141047510 ∧ code e2419141047510 = 11215234069718 := by decide
theorem cert_e2419141047510 : check e2419141047510 [[],[]] .smaller = true := by decide
def e2419141047514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2419141047514 : Closed e2419141047514 ∧ code e2419141047514 = 11215234069722 := by decide
theorem cert_e2419141047514 : check e2419141047514 [[],[]] .smaller = true := by decide
def e2419141047530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2419141047530 : Closed e2419141047530 ∧ code e2419141047530 = 11215234069738 := by decide
theorem cert_e2419141047530 : check e2419141047530 [[],[]] .smaller = true := by decide
def e2419141047606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141047606 : Closed e2419141047606 ∧ code e2419141047606 = 11215234069814 := by decide
theorem cert_e2419141047606 : check e2419141047606 [[],[]] .smaller = true := by decide
def e2419141047610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141047610 : Closed e2419141047610 ∧ code e2419141047610 = 11215234069818 := by decide
theorem cert_e2419141047610 : check e2419141047610 [[],[]] .smaller = true := by decide
def e2419141047694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2419141047694 : Closed e2419141047694 ∧ code e2419141047694 = 11215234069902 := by decide
theorem cert_e2419141047694 : check e2419141047694 [[],[]] .smaller = true := by decide
def e2419141047706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141047706 : Closed e2419141047706 ∧ code e2419141047706 = 11215234069914 := by decide
theorem cert_e2419141047706 : check e2419141047706 [[],[]] .smaller = true := by decide
def e2419141047774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2419141047774 : Closed e2419141047774 ∧ code e2419141047774 = 11215234069982 := by decide
theorem cert_e2419141047774 : check e2419141047774 [[],[]] .three = true := by decide
def e2419141047790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2419141047790 : Closed e2419141047790 ∧ code e2419141047790 = 11215234069998 := by decide
theorem cert_e2419141047790 : check e2419141047790 [[],[]] .three = true := by decide
def e2419141047862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2419141047862 : Closed e2419141047862 ∧ code e2419141047862 = 11215234070070 := by decide
theorem cert_e2419141047862 : check e2419141047862 [[],[]] .smaller = true := by decide
def e2419141047866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2419141047866 : Closed e2419141047866 ∧ code e2419141047866 = 11215234070074 := by decide
theorem cert_e2419141047866 : check e2419141047866 [[],[]] .smaller = true := by decide
def e2419141047914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2419141047914 : Closed e2419141047914 ∧ code e2419141047914 = 11215234070122 := by decide
theorem cert_e2419141047914 : check e2419141047914 [[],[]] .smaller = true := by decide
def e2419141047950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2419141047950 : Closed e2419141047950 ∧ code e2419141047950 = 11215234070158 := by decide
theorem cert_e2419141047950 : check e2419141047950 [[],[]] .smaller = true := by decide
end Blc.Floor43
