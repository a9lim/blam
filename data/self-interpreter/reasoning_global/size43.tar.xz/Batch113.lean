import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e876321222318 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e876321222318 : Closed e876321222318 ∧ code e876321222318 = 9672414244526 := by decide
theorem cert_e876321222318 : check e876321222318 [] .sourceHead = true := by decide
def e876321222330 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e876321222330 : Closed e876321222330 ∧ code e876321222330 = 9672414244538 := by decide
theorem cert_e876321222330 : check e876321222330 [] .sourceHead = true := by decide
def e876321222378 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e876321222378 : Closed e876321222378 ∧ code e876321222378 = 9672414244586 := by decide
theorem cert_e876321222378 : check e876321222378 [] .sourceHead = true := by decide
def e876321222486 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e876321222486 : Closed e876321222486 ∧ code e876321222486 = 9672414244694 := by decide
theorem cert_e876321222486 : check e876321222486 [] .sourceHead = true := by decide
def e876321222490 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e876321222490 : Closed e876321222490 ∧ code e876321222490 = 9672414244698 := by decide
theorem cert_e876321222490 : check e876321222490 [] .sourceHead = true := by decide
def e876321222506 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e876321222506 : Closed e876321222506 ∧ code e876321222506 = 9672414244714 := by decide
theorem cert_e876321222506 : check e876321222506 [] .sourceHead = true := by decide
def e876321223534 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e876321223534 : Closed e876321223534 ∧ code e876321223534 = 9672414245742 := by decide
theorem cert_e876321223534 : check e876321223534 [] .sourceHead = true := by decide
def e876321223542 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e876321223542 : Closed e876321223542 ∧ code e876321223542 = 9672414245750 := by decide
theorem cert_e876321223542 : check e876321223542 [] .sourceHead = true := by decide
def e876321223598 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e876321223598 : Closed e876321223598 ∧ code e876321223598 = 9672414245806 := by decide
theorem cert_e876321223598 : check e876321223598 [] .sourceHead = true := by decide
def e876321223610 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e876321223610 : Closed e876321223610 ∧ code e876321223610 = 9672414245818 := by decide
theorem cert_e876321223610 : check e876321223610 [] .sourceHead = true := by decide
def e876321223638 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e876321223638 : Closed e876321223638 ∧ code e876321223638 = 9672414245846 := by decide
theorem cert_e876321223638 : check e876321223638 [] .sourceHead = true := by decide
def e876321223642 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e876321223642 : Closed e876321223642 ∧ code e876321223642 = 9672414245850 := by decide
theorem cert_e876321223642 : check e876321223642 [] .sourceHead = true := by decide
def e876321223918 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e876321223918 : Closed e876321223918 ∧ code e876321223918 = 9672414246126 := by decide
theorem cert_e876321223918 : check e876321223918 [] .sourceHead = true := by decide
def e876321223926 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e876321223926 : Closed e876321223926 ∧ code e876321223926 = 9672414246134 := by decide
theorem cert_e876321223926 : check e876321223926 [] .sourceHead = true := by decide
def e876321224302 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e876321224302 : Closed e876321224302 ∧ code e876321224302 = 9672414246510 := by decide
theorem cert_e876321224302 : check e876321224302 [] .sourceHead = true := by decide
def e876321224314 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e876321224314 : Closed e876321224314 ∧ code e876321224314 = 9672414246522 := by decide
theorem cert_e876321224314 : check e876321224314 [] .sourceHead = true := by decide
def e876321224502 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e876321224502 : Closed e876321224502 ∧ code e876321224502 = 9672414246710 := by decide
theorem cert_e876321224502 : check e876321224502 [] .sourceHead = true := by decide
def e876321224506 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e876321224506 : Closed e876321224506 ∧ code e876321224506 = 9672414246714 := by decide
theorem cert_e876321224506 : check e876321224506 [] .sourceHead = true := by decide
def e876321225134 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e876321225134 : Closed e876321225134 ∧ code e876321225134 = 9672414247342 := by decide
theorem cert_e876321225134 : check e876321225134 [] .sourceHead = true := by decide
def e876321225146 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e876321225146 : Closed e876321225146 ∧ code e876321225146 = 9672414247354 := by decide
theorem cert_e876321225146 : check e876321225146 [] .sourceHead = true := by decide
def e876321225194 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e876321225194 : Closed e876321225194 ∧ code e876321225194 = 9672414247402 := by decide
theorem cert_e876321225194 : check e876321225194 [] .sourceHead = true := by decide
def e876321225326 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e876321225326 : Closed e876321225326 ∧ code e876321225326 = 9672414247534 := by decide
theorem cert_e876321225326 : check e876321225326 [] .sourceHead = true := by decide
def e876321225338 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e876321225338 : Closed e876321225338 ∧ code e876321225338 = 9672414247546 := by decide
theorem cert_e876321225338 : check e876321225338 [] .sourceHead = true := by decide
def e876321225626 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e876321225626 : Closed e876321225626 ∧ code e876321225626 = 9672414247834 := by decide
theorem cert_e876321225626 : check e876321225626 [] .sourceHead = true := by decide
def e876321225942 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e876321225942 : Closed e876321225942 ∧ code e876321225942 = 9672414248150 := by decide
theorem cert_e876321225942 : check e876321225942 [] .sourceHead = true := by decide
def e876321225946 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e876321225946 : Closed e876321225946 ∧ code e876321225946 = 9672414248154 := by decide
theorem cert_e876321225946 : check e876321225946 [] .sourceHead = true := by decide
def e876321225962 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e876321225962 : Closed e876321225962 ∧ code e876321225962 = 9672414248170 := by decide
theorem cert_e876321225962 : check e876321225962 [] .sourceHead = true := by decide
def e876321226038 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e876321226038 : Closed e876321226038 ∧ code e876321226038 = 9672414248246 := by decide
theorem cert_e876321226038 : check e876321226038 [] .sourceHead = true := by decide
def e876321226042 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e876321226042 : Closed e876321226042 ∧ code e876321226042 = 9672414248250 := by decide
theorem cert_e876321226042 : check e876321226042 [] .sourceHead = true := by decide
def e876321226138 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e876321226138 : Closed e876321226138 ∧ code e876321226138 = 9672414248346 := by decide
theorem cert_e876321226138 : check e876321226138 [] .sourceHead = true := by decide
def e876321229678 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e876321229678 : Closed e876321229678 ∧ code e876321229678 = 9672414251886 := by decide
theorem cert_e876321229678 : check e876321229678 [] .sourceHead = true := by decide
def e876321229686 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e876321229686 : Closed e876321229686 ∧ code e876321229686 = 9672414251894 := by decide
theorem cert_e876321229686 : check e876321229686 [] .sourceHead = true := by decide
def e876321229742 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e876321229742 : Closed e876321229742 ∧ code e876321229742 = 9672414251950 := by decide
theorem cert_e876321229742 : check e876321229742 [] .sourceHead = true := by decide
def e876321229754 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e876321229754 : Closed e876321229754 ∧ code e876321229754 = 9672414251962 := by decide
theorem cert_e876321229754 : check e876321229754 [] .sourceHead = true := by decide
def e876321229782 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e876321229782 : Closed e876321229782 ∧ code e876321229782 = 9672414251990 := by decide
theorem cert_e876321229782 : check e876321229782 [] .sourceHead = true := by decide
def e876321229786 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e876321229786 : Closed e876321229786 ∧ code e876321229786 = 9672414251994 := by decide
theorem cert_e876321229786 : check e876321229786 [] .sourceHead = true := by decide
def e876321230062 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e876321230062 : Closed e876321230062 ∧ code e876321230062 = 9672414252270 := by decide
theorem cert_e876321230062 : check e876321230062 [] .sourceHead = true := by decide
def e876321230070 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e876321230070 : Closed e876321230070 ∧ code e876321230070 = 9672414252278 := by decide
theorem cert_e876321230070 : check e876321230070 [] .sourceHead = true := by decide
def e876321230446 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e876321230446 : Closed e876321230446 ∧ code e876321230446 = 9672414252654 := by decide
theorem cert_e876321230446 : check e876321230446 [] .sourceHead = true := by decide
def e876321230458 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e876321230458 : Closed e876321230458 ∧ code e876321230458 = 9672414252666 := by decide
theorem cert_e876321230458 : check e876321230458 [] .sourceHead = true := by decide
def e876321230646 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e876321230646 : Closed e876321230646 ∧ code e876321230646 = 9672414252854 := by decide
theorem cert_e876321230646 : check e876321230646 [] .sourceHead = true := by decide
def e876321230650 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e876321230650 : Closed e876321230650 ∧ code e876321230650 = 9672414252858 := by decide
theorem cert_e876321230650 : check e876321230650 [] .sourceHead = true := by decide
def e876321236398 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e876321236398 : Closed e876321236398 ∧ code e876321236398 = 9672414258606 := by decide
theorem cert_e876321236398 : check e876321236398 [] .sourceHead = true := by decide
def e876321236410 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e876321236410 : Closed e876321236410 ∧ code e876321236410 = 9672414258618 := by decide
theorem cert_e876321236410 : check e876321236410 [] .sourceHead = true := by decide
def e876321236458 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e876321236458 : Closed e876321236458 ∧ code e876321236458 = 9672414258666 := by decide
theorem cert_e876321236458 : check e876321236458 [] .sourceHead = true := by decide
def e876321236590 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e876321236590 : Closed e876321236590 ∧ code e876321236590 = 9672414258798 := by decide
theorem cert_e876321236590 : check e876321236590 [] .sourceHead = true := by decide
def e876321236602 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e876321236602 : Closed e876321236602 ∧ code e876321236602 = 9672414258810 := by decide
theorem cert_e876321236602 : check e876321236602 [] .sourceHead = true := by decide
def e876321236890 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e876321236890 : Closed e876321236890 ∧ code e876321236890 = 9672414259098 := by decide
theorem cert_e876321236890 : check e876321236890 [] .sourceHead = true := by decide
def e876321239766 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e876321239766 : Closed e876321239766 ∧ code e876321239766 = 9672414261974 := by decide
theorem cert_e876321239766 : check e876321239766 [] .sourceHead = true := by decide
def e876321239770 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e876321239770 : Closed e876321239770 ∧ code e876321239770 = 9672414261978 := by decide
theorem cert_e876321239770 : check e876321239770 [] .sourceHead = true := by decide
def e876321239786 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e876321239786 : Closed e876321239786 ∧ code e876321239786 = 9672414261994 := by decide
theorem cert_e876321239786 : check e876321239786 [] .sourceHead = true := by decide
def e876321239862 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e876321239862 : Closed e876321239862 ∧ code e876321239862 = 9672414262070 := by decide
theorem cert_e876321239862 : check e876321239862 [] .sourceHead = true := by decide
def e876321239866 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e876321239866 : Closed e876321239866 ∧ code e876321239866 = 9672414262074 := by decide
theorem cert_e876321239866 : check e876321239866 [] .sourceHead = true := by decide
def e876321239962 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e876321239962 : Closed e876321239962 ∧ code e876321239962 = 9672414262170 := by decide
theorem cert_e876321239962 : check e876321239962 [] .sourceHead = true := by decide
def e876764769646 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e876764769646 : Closed e876764769646 ∧ code e876764769646 = 9672857791854 := by decide
theorem cert_e876764769646 : check e876764769646 [] .sourceHead = true := by decide
def e876764769654 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e876764769654 : Closed e876764769654 ∧ code e876764769654 = 9672857791862 := by decide
theorem cert_e876764769654 : check e876764769654 [] .sourceHead = true := by decide
def e876764769710 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e876764769710 : Closed e876764769710 ∧ code e876764769710 = 9672857791918 := by decide
theorem cert_e876764769710 : check e876764769710 [] .sourceHead = true := by decide
def e876764769722 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e876764769722 : Closed e876764769722 ∧ code e876764769722 = 9672857791930 := by decide
theorem cert_e876764769722 : check e876764769722 [] .sourceHead = true := by decide
def e876764769750 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e876764769750 : Closed e876764769750 ∧ code e876764769750 = 9672857791958 := by decide
theorem cert_e876764769750 : check e876764769750 [] .sourceHead = true := by decide
def e876764769754 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e876764769754 : Closed e876764769754 ∧ code e876764769754 = 9672857791962 := by decide
theorem cert_e876764769754 : check e876764769754 [] .sourceHead = true := by decide
def e876764769966 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e876764769966 : Closed e876764769966 ∧ code e876764769966 = 9672857792174 := by decide
theorem cert_e876764769966 : check e876764769966 [] .sourceHead = true := by decide
def e876764769978 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e876764769978 : Closed e876764769978 ∧ code e876764769978 = 9672857792186 := by decide
theorem cert_e876764769978 : check e876764769978 [] .sourceHead = true := by decide
def e876764770026 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e876764770026 : Closed e876764770026 ∧ code e876764770026 = 9672857792234 := by decide
theorem cert_e876764770026 : check e876764770026 [] .sourceHead = true := by decide
def e876764770134 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e876764770134 : Closed e876764770134 ∧ code e876764770134 = 9672857792342 := by decide
theorem cert_e876764770134 : check e876764770134 [] .sourceHead = true := by decide
def e876764770138 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e876764770138 : Closed e876764770138 ∧ code e876764770138 = 9672857792346 := by decide
theorem cert_e876764770138 : check e876764770138 [] .sourceHead = true := by decide
def e876764770154 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e876764770154 : Closed e876764770154 ∧ code e876764770154 = 9672857792362 := by decide
theorem cert_e876764770154 : check e876764770154 [] .sourceHead = true := by decide
def e876764771182 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e876764771182 : Closed e876764771182 ∧ code e876764771182 = 9672857793390 := by decide
theorem cert_e876764771182 : check e876764771182 [] .sourceHead = true := by decide
def e876764771190 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e876764771190 : Closed e876764771190 ∧ code e876764771190 = 9672857793398 := by decide
theorem cert_e876764771190 : check e876764771190 [] .sourceHead = true := by decide
def e876764771246 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e876764771246 : Closed e876764771246 ∧ code e876764771246 = 9672857793454 := by decide
theorem cert_e876764771246 : check e876764771246 [] .sourceHead = true := by decide
def e876764771258 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e876764771258 : Closed e876764771258 ∧ code e876764771258 = 9672857793466 := by decide
theorem cert_e876764771258 : check e876764771258 [] .sourceHead = true := by decide
def e876764771286 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e876764771286 : Closed e876764771286 ∧ code e876764771286 = 9672857793494 := by decide
theorem cert_e876764771286 : check e876764771286 [] .sourceHead = true := by decide
def e876764771290 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e876764771290 : Closed e876764771290 ∧ code e876764771290 = 9672857793498 := by decide
theorem cert_e876764771290 : check e876764771290 [] .sourceHead = true := by decide
def e876764771566 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e876764771566 : Closed e876764771566 ∧ code e876764771566 = 9672857793774 := by decide
theorem cert_e876764771566 : check e876764771566 [] .sourceHead = true := by decide
def e876764771574 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e876764771574 : Closed e876764771574 ∧ code e876764771574 = 9672857793782 := by decide
theorem cert_e876764771574 : check e876764771574 [] .sourceHead = true := by decide
def e876764771950 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e876764771950 : Closed e876764771950 ∧ code e876764771950 = 9672857794158 := by decide
theorem cert_e876764771950 : check e876764771950 [] .sourceHead = true := by decide
def e876764771962 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e876764771962 : Closed e876764771962 ∧ code e876764771962 = 9672857794170 := by decide
theorem cert_e876764771962 : check e876764771962 [] .sourceHead = true := by decide
def e876764772150 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e876764772150 : Closed e876764772150 ∧ code e876764772150 = 9672857794358 := by decide
theorem cert_e876764772150 : check e876764772150 [] .sourceHead = true := by decide
def e876764772154 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e876764772154 : Closed e876764772154 ∧ code e876764772154 = 9672857794362 := by decide
theorem cert_e876764772154 : check e876764772154 [] .sourceHead = true := by decide
def e876764772782 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e876764772782 : Closed e876764772782 ∧ code e876764772782 = 9672857794990 := by decide
theorem cert_e876764772782 : check e876764772782 [] .sourceHead = true := by decide
def e876764772794 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e876764772794 : Closed e876764772794 ∧ code e876764772794 = 9672857795002 := by decide
theorem cert_e876764772794 : check e876764772794 [] .sourceHead = true := by decide
def e876764772842 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e876764772842 : Closed e876764772842 ∧ code e876764772842 = 9672857795050 := by decide
theorem cert_e876764772842 : check e876764772842 [] .sourceHead = true := by decide
def e876764772974 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e876764772974 : Closed e876764772974 ∧ code e876764772974 = 9672857795182 := by decide
theorem cert_e876764772974 : check e876764772974 [] .sourceHead = true := by decide
def e876764772986 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e876764772986 : Closed e876764772986 ∧ code e876764772986 = 9672857795194 := by decide
theorem cert_e876764772986 : check e876764772986 [] .sourceHead = true := by decide
def e876764773274 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e876764773274 : Closed e876764773274 ∧ code e876764773274 = 9672857795482 := by decide
theorem cert_e876764773274 : check e876764773274 [] .sourceHead = true := by decide
def e876764773590 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e876764773590 : Closed e876764773590 ∧ code e876764773590 = 9672857795798 := by decide
theorem cert_e876764773590 : check e876764773590 [] .sourceHead = true := by decide
def e876764773594 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e876764773594 : Closed e876764773594 ∧ code e876764773594 = 9672857795802 := by decide
theorem cert_e876764773594 : check e876764773594 [] .sourceHead = true := by decide
def e876764773610 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e876764773610 : Closed e876764773610 ∧ code e876764773610 = 9672857795818 := by decide
theorem cert_e876764773610 : check e876764773610 [] .sourceHead = true := by decide
def e876764773686 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e876764773686 : Closed e876764773686 ∧ code e876764773686 = 9672857795894 := by decide
theorem cert_e876764773686 : check e876764773686 [] .sourceHead = true := by decide
def e876764773690 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e876764773690 : Closed e876764773690 ∧ code e876764773690 = 9672857795898 := by decide
theorem cert_e876764773690 : check e876764773690 [] .sourceHead = true := by decide
def e876764773786 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e876764773786 : Closed e876764773786 ∧ code e876764773786 = 9672857795994 := by decide
theorem cert_e876764773786 : check e876764773786 [] .sourceHead = true := by decide
def e876764777326 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e876764777326 : Closed e876764777326 ∧ code e876764777326 = 9672857799534 := by decide
theorem cert_e876764777326 : check e876764777326 [] .sourceHead = true := by decide
def e876764777334 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e876764777334 : Closed e876764777334 ∧ code e876764777334 = 9672857799542 := by decide
theorem cert_e876764777334 : check e876764777334 [] .sourceHead = true := by decide
def e876764777390 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e876764777390 : Closed e876764777390 ∧ code e876764777390 = 9672857799598 := by decide
theorem cert_e876764777390 : check e876764777390 [] .sourceHead = true := by decide
def e876764777402 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e876764777402 : Closed e876764777402 ∧ code e876764777402 = 9672857799610 := by decide
theorem cert_e876764777402 : check e876764777402 [] .sourceHead = true := by decide
def e876764777430 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e876764777430 : Closed e876764777430 ∧ code e876764777430 = 9672857799638 := by decide
theorem cert_e876764777430 : check e876764777430 [] .sourceHead = true := by decide
def e876764777434 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e876764777434 : Closed e876764777434 ∧ code e876764777434 = 9672857799642 := by decide
theorem cert_e876764777434 : check e876764777434 [] .sourceHead = true := by decide
def e876764777710 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e876764777710 : Closed e876764777710 ∧ code e876764777710 = 9672857799918 := by decide
theorem cert_e876764777710 : check e876764777710 [] .sourceHead = true := by decide
def e876764777718 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e876764777718 : Closed e876764777718 ∧ code e876764777718 = 9672857799926 := by decide
theorem cert_e876764777718 : check e876764777718 [] .sourceHead = true := by decide
def e876764778094 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e876764778094 : Closed e876764778094 ∧ code e876764778094 = 9672857800302 := by decide
theorem cert_e876764778094 : check e876764778094 [] .sourceHead = true := by decide
def e876764778106 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e876764778106 : Closed e876764778106 ∧ code e876764778106 = 9672857800314 := by decide
theorem cert_e876764778106 : check e876764778106 [] .sourceHead = true := by decide
def e876764778294 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e876764778294 : Closed e876764778294 ∧ code e876764778294 = 9672857800502 := by decide
theorem cert_e876764778294 : check e876764778294 [] .sourceHead = true := by decide
def e876764778298 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e876764778298 : Closed e876764778298 ∧ code e876764778298 = 9672857800506 := by decide
theorem cert_e876764778298 : check e876764778298 [] .sourceHead = true := by decide
def e876764784046 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e876764784046 : Closed e876764784046 ∧ code e876764784046 = 9672857806254 := by decide
theorem cert_e876764784046 : check e876764784046 [] .sourceHead = true := by decide
def e876764784058 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e876764784058 : Closed e876764784058 ∧ code e876764784058 = 9672857806266 := by decide
theorem cert_e876764784058 : check e876764784058 [] .sourceHead = true := by decide
def e876764784106 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e876764784106 : Closed e876764784106 ∧ code e876764784106 = 9672857806314 := by decide
theorem cert_e876764784106 : check e876764784106 [] .sourceHead = true := by decide
def e876764784238 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e876764784238 : Closed e876764784238 ∧ code e876764784238 = 9672857806446 := by decide
theorem cert_e876764784238 : check e876764784238 [] .sourceHead = true := by decide
def e876764784250 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e876764784250 : Closed e876764784250 ∧ code e876764784250 = 9672857806458 := by decide
theorem cert_e876764784250 : check e876764784250 [] .sourceHead = true := by decide
def e876764784538 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e876764784538 : Closed e876764784538 ∧ code e876764784538 = 9672857806746 := by decide
theorem cert_e876764784538 : check e876764784538 [] .sourceHead = true := by decide
def e876764787414 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e876764787414 : Closed e876764787414 ∧ code e876764787414 = 9672857809622 := by decide
theorem cert_e876764787414 : check e876764787414 [] .sourceHead = true := by decide
def e876764787418 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e876764787418 : Closed e876764787418 ∧ code e876764787418 = 9672857809626 := by decide
theorem cert_e876764787418 : check e876764787418 [] .sourceHead = true := by decide
def e876764787434 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e876764787434 : Closed e876764787434 ∧ code e876764787434 = 9672857809642 := by decide
theorem cert_e876764787434 : check e876764787434 [] .sourceHead = true := by decide
def e876764787510 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e876764787510 : Closed e876764787510 ∧ code e876764787510 = 9672857809718 := by decide
theorem cert_e876764787510 : check e876764787510 [] .sourceHead = true := by decide
def e876764787514 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e876764787514 : Closed e876764787514 ∧ code e876764787514 = 9672857809722 := by decide
theorem cert_e876764787514 : check e876764787514 [] .sourceHead = true := by decide
def e876764787610 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e876764787610 : Closed e876764787610 ∧ code e876764787610 = 9672857809818 := by decide
theorem cert_e876764787610 : check e876764787610 [] .sourceHead = true := by decide
def e876764924782 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e876764924782 : Closed e876764924782 ∧ code e876764924782 = 9672857946990 := by decide
theorem cert_e876764924782 : check e876764924782 [] .sourceHead = true := by decide
def e876764924790 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e876764924790 : Closed e876764924790 ∧ code e876764924790 = 9672857946998 := by decide
theorem cert_e876764924790 : check e876764924790 [] .sourceHead = true := by decide
def e876764924846 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e876764924846 : Closed e876764924846 ∧ code e876764924846 = 9672857947054 := by decide
theorem cert_e876764924846 : check e876764924846 [] .sourceHead = true := by decide
def e876764924858 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e876764924858 : Closed e876764924858 ∧ code e876764924858 = 9672857947066 := by decide
theorem cert_e876764924858 : check e876764924858 [] .sourceHead = true := by decide
def e876764924886 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e876764924886 : Closed e876764924886 ∧ code e876764924886 = 9672857947094 := by decide
theorem cert_e876764924886 : check e876764924886 [] .sourceHead = true := by decide
def e876764924890 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e876764924890 : Closed e876764924890 ∧ code e876764924890 = 9672857947098 := by decide
theorem cert_e876764924890 : check e876764924890 [] .sourceHead = true := by decide
def e876764925166 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e876764925166 : Closed e876764925166 ∧ code e876764925166 = 9672857947374 := by decide
theorem cert_e876764925166 : check e876764925166 [] .sourceHead = true := by decide
def e876764925174 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e876764925174 : Closed e876764925174 ∧ code e876764925174 = 9672857947382 := by decide
theorem cert_e876764925174 : check e876764925174 [] .sourceHead = true := by decide
def e876764925550 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e876764925550 : Closed e876764925550 ∧ code e876764925550 = 9672857947758 := by decide
theorem cert_e876764925550 : check e876764925550 [] .sourceHead = true := by decide
def e876764925562 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e876764925562 : Closed e876764925562 ∧ code e876764925562 = 9672857947770 := by decide
theorem cert_e876764925562 : check e876764925562 [] .sourceHead = true := by decide
def e876764925750 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e876764925750 : Closed e876764925750 ∧ code e876764925750 = 9672857947958 := by decide
theorem cert_e876764925750 : check e876764925750 [] .sourceHead = true := by decide
def e876764925754 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e876764925754 : Closed e876764925754 ∧ code e876764925754 = 9672857947962 := by decide
theorem cert_e876764925754 : check e876764925754 [] .sourceHead = true := by decide
def e878538960238 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e878538960238 : Closed e878538960238 ∧ code e878538960238 = 9674631982446 := by decide
theorem cert_e878538960238 : check e878538960238 [] .sourceHead = true := by decide
def e878538960246 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e878538960246 : Closed e878538960246 ∧ code e878538960246 = 9674631982454 := by decide
theorem cert_e878538960246 : check e878538960246 [] .sourceHead = true := by decide
def e878538960302 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e878538960302 : Closed e878538960302 ∧ code e878538960302 = 9674631982510 := by decide
theorem cert_e878538960302 : check e878538960302 [] .sourceHead = true := by decide
def e878538960314 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e878538960314 : Closed e878538960314 ∧ code e878538960314 = 9674631982522 := by decide
theorem cert_e878538960314 : check e878538960314 [] .sourceHead = true := by decide
def e878538960342 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e878538960342 : Closed e878538960342 ∧ code e878538960342 = 9674631982550 := by decide
theorem cert_e878538960342 : check e878538960342 [] .sourceHead = true := by decide
def e878538960346 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e878538960346 : Closed e878538960346 ∧ code e878538960346 = 9674631982554 := by decide
theorem cert_e878538960346 : check e878538960346 [] .sourceHead = true := by decide
def e878538960558 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e878538960558 : Closed e878538960558 ∧ code e878538960558 = 9674631982766 := by decide
theorem cert_e878538960558 : check e878538960558 [] .sourceHead = true := by decide
def e878538960570 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e878538960570 : Closed e878538960570 ∧ code e878538960570 = 9674631982778 := by decide
theorem cert_e878538960570 : check e878538960570 [] .sourceHead = true := by decide
def e878538960618 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e878538960618 : Closed e878538960618 ∧ code e878538960618 = 9674631982826 := by decide
theorem cert_e878538960618 : check e878538960618 [] .sourceHead = true := by decide
def e878538960726 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e878538960726 : Closed e878538960726 ∧ code e878538960726 = 9674631982934 := by decide
theorem cert_e878538960726 : check e878538960726 [] .sourceHead = true := by decide
def e878538960730 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e878538960730 : Closed e878538960730 ∧ code e878538960730 = 9674631982938 := by decide
theorem cert_e878538960730 : check e878538960730 [] .sourceHead = true := by decide
def e878538960746 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e878538960746 : Closed e878538960746 ∧ code e878538960746 = 9674631982954 := by decide
theorem cert_e878538960746 : check e878538960746 [] .sourceHead = true := by decide
def e878538961774 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e878538961774 : Closed e878538961774 ∧ code e878538961774 = 9674631983982 := by decide
theorem cert_e878538961774 : check e878538961774 [] .sourceHead = true := by decide
def e878538961782 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e878538961782 : Closed e878538961782 ∧ code e878538961782 = 9674631983990 := by decide
theorem cert_e878538961782 : check e878538961782 [] .sourceHead = true := by decide
def e878538961838 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e878538961838 : Closed e878538961838 ∧ code e878538961838 = 9674631984046 := by decide
theorem cert_e878538961838 : check e878538961838 [] .sourceHead = true := by decide
def e878538961850 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e878538961850 : Closed e878538961850 ∧ code e878538961850 = 9674631984058 := by decide
theorem cert_e878538961850 : check e878538961850 [] .sourceHead = true := by decide
def e878538961878 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e878538961878 : Closed e878538961878 ∧ code e878538961878 = 9674631984086 := by decide
theorem cert_e878538961878 : check e878538961878 [] .sourceHead = true := by decide
def e878538961882 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e878538961882 : Closed e878538961882 ∧ code e878538961882 = 9674631984090 := by decide
theorem cert_e878538961882 : check e878538961882 [] .sourceHead = true := by decide
def e878538962158 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e878538962158 : Closed e878538962158 ∧ code e878538962158 = 9674631984366 := by decide
theorem cert_e878538962158 : check e878538962158 [] .sourceHead = true := by decide
def e878538962166 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e878538962166 : Closed e878538962166 ∧ code e878538962166 = 9674631984374 := by decide
theorem cert_e878538962166 : check e878538962166 [] .sourceHead = true := by decide
def e878538962542 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e878538962542 : Closed e878538962542 ∧ code e878538962542 = 9674631984750 := by decide
theorem cert_e878538962542 : check e878538962542 [] .sourceHead = true := by decide
def e878538962554 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e878538962554 : Closed e878538962554 ∧ code e878538962554 = 9674631984762 := by decide
theorem cert_e878538962554 : check e878538962554 [] .sourceHead = true := by decide
def e878538962742 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e878538962742 : Closed e878538962742 ∧ code e878538962742 = 9674631984950 := by decide
theorem cert_e878538962742 : check e878538962742 [] .sourceHead = true := by decide
def e878538962746 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e878538962746 : Closed e878538962746 ∧ code e878538962746 = 9674631984954 := by decide
theorem cert_e878538962746 : check e878538962746 [] .sourceHead = true := by decide
def e878538963374 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e878538963374 : Closed e878538963374 ∧ code e878538963374 = 9674631985582 := by decide
theorem cert_e878538963374 : check e878538963374 [] .sourceHead = true := by decide
def e878538963386 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e878538963386 : Closed e878538963386 ∧ code e878538963386 = 9674631985594 := by decide
theorem cert_e878538963386 : check e878538963386 [] .sourceHead = true := by decide
def e878538963434 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e878538963434 : Closed e878538963434 ∧ code e878538963434 = 9674631985642 := by decide
theorem cert_e878538963434 : check e878538963434 [] .sourceHead = true := by decide
def e878538963566 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e878538963566 : Closed e878538963566 ∧ code e878538963566 = 9674631985774 := by decide
theorem cert_e878538963566 : check e878538963566 [] .sourceHead = true := by decide
def e878538963578 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e878538963578 : Closed e878538963578 ∧ code e878538963578 = 9674631985786 := by decide
theorem cert_e878538963578 : check e878538963578 [] .sourceHead = true := by decide
def e878538963866 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e878538963866 : Closed e878538963866 ∧ code e878538963866 = 9674631986074 := by decide
theorem cert_e878538963866 : check e878538963866 [] .sourceHead = true := by decide
def e878538964182 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e878538964182 : Closed e878538964182 ∧ code e878538964182 = 9674631986390 := by decide
theorem cert_e878538964182 : check e878538964182 [] .sourceHead = true := by decide
def e878538964186 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e878538964186 : Closed e878538964186 ∧ code e878538964186 = 9674631986394 := by decide
theorem cert_e878538964186 : check e878538964186 [] .sourceHead = true := by decide
def e878538964202 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e878538964202 : Closed e878538964202 ∧ code e878538964202 = 9674631986410 := by decide
theorem cert_e878538964202 : check e878538964202 [] .sourceHead = true := by decide
def e878538964278 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e878538964278 : Closed e878538964278 ∧ code e878538964278 = 9674631986486 := by decide
theorem cert_e878538964278 : check e878538964278 [] .sourceHead = true := by decide
end Blc.Floor43
