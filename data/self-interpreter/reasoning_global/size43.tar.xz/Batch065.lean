import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756731325978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731325978 : Closed e756731325978 ∧ code e756731325978 = 9552824348186 := by decide
theorem cert_e756731325978 : check e756731325978 [] .sourceHead = true := by decide
def e756731329050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731329050 : Closed e756731329050 ∧ code e756731329050 = 9552824351258 := by decide
theorem cert_e756731329050 : check e756731329050 [] .sourceHead = true := by decide
def e756731336218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731336218 : Closed e756731336218 ∧ code e756731336218 = 9552824358426 := by decide
theorem cert_e756731336218 : check e756731336218 [] .sourceHead = true := by decide
def e756731337242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731337242 : Closed e756731337242 ∧ code e756731337242 = 9552824359450 := by decide
theorem cert_e756731337242 : check e756731337242 [] .sourceHead = true := by decide
def e756731407898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731407898 : Closed e756731407898 ∧ code e756731407898 = 9552824430106 := by decide
theorem cert_e756731407898 : check e756731407898 [] .sourceHead = true := by decide
def e756731409946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731409946 : Closed e756731409946 ∧ code e756731409946 = 9552824432154 := by decide
theorem cert_e756731409946 : check e756731409946 [] .sourceHead = true := by decide
def e756731506202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731506202 : Closed e756731506202 ∧ code e756731506202 = 9552824528410 := by decide
theorem cert_e756731506202 : check e756731506202 [] .sourceHead = true := by decide
def e756731509274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731509274 : Closed e756731509274 ∧ code e756731509274 = 9552824531482 := by decide
theorem cert_e756731509274 : check e756731509274 [] .sourceHead = true := by decide
def e756731535386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756731535386 : Closed e756731535386 ∧ code e756731535386 = 9552824557594 := by decide
theorem cert_e756731535386 : check e756731535386 [] .sourceHead = true := by decide
def e756731535478 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756731535478 : Closed e756731535478 ∧ code e756731535478 = 9552824557686 := by decide
theorem cert_e756731535478 : check e756731535478 [] .sourceHead = true := by decide
def e756731535722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756731535722 : Closed e756731535722 ∧ code e756731535722 = 9552824557930 := by decide
theorem cert_e756731535722 : check e756731535722 [] .sourceHead = true := by decide
def e756731535770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756731535770 : Closed e756731535770 ∧ code e756731535770 = 9552824557978 := by decide
theorem cert_e756731535770 : check e756731535770 [] .sourceHead = true := by decide
def e756731536922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756731536922 : Closed e756731536922 ∧ code e756731536922 = 9552824559130 := by decide
theorem cert_e756731536922 : check e756731536922 [] .sourceHead = true := by decide
def e756731557402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731557402 : Closed e756731557402 ∧ code e756731557402 = 9552824579610 := by decide
theorem cert_e756731557402 : check e756731557402 [] .sourceHead = true := by decide
def e756731558426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731558426 : Closed e756731558426 ∧ code e756731558426 = 9552824580634 := by decide
theorem cert_e756731558426 : check e756731558426 [] .sourceHead = true := by decide
def e756731568154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756731568154 : Closed e756731568154 ∧ code e756731568154 = 9552824590362 := by decide
theorem cert_e756731568154 : check e756731568154 [] .sourceHead = true := by decide
def e756731568246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756731568246 : Closed e756731568246 ∧ code e756731568246 = 9552824590454 := by decide
theorem cert_e756731568246 : check e756731568246 [] .sourceHead = true := by decide
def e756731568490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756731568490 : Closed e756731568490 ∧ code e756731568490 = 9552824590698 := by decide
theorem cert_e756731568490 : check e756731568490 [] .sourceHead = true := by decide
def e756731568538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756731568538 : Closed e756731568538 ∧ code e756731568538 = 9552824590746 := by decide
theorem cert_e756731568538 : check e756731568538 [] .sourceHead = true := by decide
def e756731569690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756731569690 : Closed e756731569690 ∧ code e756731569690 = 9552824591898 := by decide
theorem cert_e756731569690 : check e756731569690 [] .sourceHead = true := by decide
def e756731719194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731719194 : Closed e756731719194 ∧ code e756731719194 = 9552824741402 := by decide
theorem cert_e756731719194 : check e756731719194 [] .sourceHead = true := by decide
def e756731722266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731722266 : Closed e756731722266 ∧ code e756731722266 = 9552824744474 := by decide
theorem cert_e756731722266 : check e756731722266 [] .sourceHead = true := by decide
def e756731734554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731734554 : Closed e756731734554 ∧ code e756731734554 = 9552824756762 := by decide
theorem cert_e756731734554 : check e756731734554 [] .sourceHead = true := by decide
def e756731768346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731768346 : Closed e756731768346 ∧ code e756731768346 = 9552824790554 := by decide
theorem cert_e756731768346 : check e756731768346 [] .sourceHead = true := by decide
def e756731771418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731771418 : Closed e756731771418 ∧ code e756731771418 = 9552824793626 := by decide
theorem cert_e756731771418 : check e756731771418 [] .sourceHead = true := by decide
def e756731797530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756731797530 : Closed e756731797530 ∧ code e756731797530 = 9552824819738 := by decide
theorem cert_e756731797530 : check e756731797530 [] .sourceHead = true := by decide
def e756731797622 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756731797622 : Closed e756731797622 ∧ code e756731797622 = 9552824819830 := by decide
theorem cert_e756731797622 : check e756731797622 [] .sourceHead = true := by decide
def e756731797866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756731797866 : Closed e756731797866 ∧ code e756731797866 = 9552824820074 := by decide
theorem cert_e756731797866 : check e756731797866 [] .sourceHead = true := by decide
def e756731797914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756731797914 : Closed e756731797914 ∧ code e756731797914 = 9552824820122 := by decide
theorem cert_e756731797914 : check e756731797914 [] .sourceHead = true := by decide
def e756731799066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756731799066 : Closed e756731799066 ∧ code e756731799066 = 9552824821274 := by decide
theorem cert_e756731799066 : check e756731799066 [] .sourceHead = true := by decide
def e756731845146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731845146 : Closed e756731845146 ∧ code e756731845146 = 9552824867354 := by decide
theorem cert_e756731845146 : check e756731845146 [] .sourceHead = true := by decide
def e756731846682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756731846682 : Closed e756731846682 ∧ code e756731846682 = 9552824868890 := by decide
theorem cert_e756731846682 : check e756731846682 [] .sourceHead = true := by decide
def e756731846774 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756731846774 : Closed e756731846774 ∧ code e756731846774 = 9552824868982 := by decide
theorem cert_e756731846774 : check e756731846774 [] .sourceHead = true := by decide
def e756731847018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756731847018 : Closed e756731847018 ∧ code e756731847018 = 9552824869226 := by decide
theorem cert_e756731847018 : check e756731847018 [] .sourceHead = true := by decide
def e756731847066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756731847066 : Closed e756731847066 ∧ code e756731847066 = 9552824869274 := by decide
theorem cert_e756731847066 : check e756731847066 [] .sourceHead = true := by decide
def e756731848218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756731848218 : Closed e756731848218 ∧ code e756731848218 = 9552824870426 := by decide
theorem cert_e756731848218 : check e756731848218 [] .sourceHead = true := by decide
def e756731926042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731926042 : Closed e756731926042 ∧ code e756731926042 = 9552824948250 := by decide
theorem cert_e756731926042 : check e756731926042 [] .sourceHead = true := by decide
def e756731927066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731927066 : Closed e756731927066 ∧ code e756731927066 = 9552824949274 := by decide
theorem cert_e756731927066 : check e756731927066 [] .sourceHead = true := by decide
def e756731931162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731931162 : Closed e756731931162 ∧ code e756731931162 = 9552824953370 := by decide
theorem cert_e756731931162 : check e756731931162 [] .sourceHead = true := by decide
def e756731950618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731950618 : Closed e756731950618 ∧ code e756731950618 = 9552824972826 := by decide
theorem cert_e756731950618 : check e756731950618 [] .sourceHead = true := by decide
def e756731951642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731951642 : Closed e756731951642 ∧ code e756731951642 = 9552824973850 := by decide
theorem cert_e756731951642 : check e756731951642 [] .sourceHead = true := by decide
def e756731961370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756731961370 : Closed e756731961370 ∧ code e756731961370 = 9552824983578 := by decide
theorem cert_e756731961370 : check e756731961370 [] .sourceHead = true := by decide
def e756731961462 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756731961462 : Closed e756731961462 ∧ code e756731961462 = 9552824983670 := by decide
theorem cert_e756731961462 : check e756731961462 [] .sourceHead = true := by decide
def e756731961706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756731961706 : Closed e756731961706 ∧ code e756731961706 = 9552824983914 := by decide
theorem cert_e756731961706 : check e756731961706 [] .sourceHead = true := by decide
def e756731961754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756731961754 : Closed e756731961754 ∧ code e756731961754 = 9552824983962 := by decide
theorem cert_e756731961754 : check e756731961754 [] .sourceHead = true := by decide
def e756731962906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756731962906 : Closed e756731962906 ∧ code e756731962906 = 9552824985114 := by decide
theorem cert_e756731962906 : check e756731962906 [] .sourceHead = true := by decide
def e756731976218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731976218 : Closed e756731976218 ∧ code e756731976218 = 9552824998426 := by decide
theorem cert_e756731976218 : check e756731976218 [] .sourceHead = true := by decide
def e756731977754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756731977754 : Closed e756731977754 ∧ code e756731977754 = 9552824999962 := by decide
theorem cert_e756731977754 : check e756731977754 [] .sourceHead = true := by decide
def e756731977846 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756731977846 : Closed e756731977846 ∧ code e756731977846 = 9552825000054 := by decide
theorem cert_e756731977846 : check e756731977846 [] .sourceHead = true := by decide
def e756731978090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756731978090 : Closed e756731978090 ∧ code e756731978090 = 9552825000298 := by decide
theorem cert_e756731978090 : check e756731978090 [] .sourceHead = true := by decide
def e756731978138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756731978138 : Closed e756731978138 ∧ code e756731978138 = 9552825000346 := by decide
theorem cert_e756731978138 : check e756731978138 [] .sourceHead = true := by decide
def e756731979290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756731979290 : Closed e756731979290 ∧ code e756731979290 = 9552825001498 := by decide
theorem cert_e756731979290 : check e756731979290 [] .sourceHead = true := by decide
def e756732386842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732386842 : Closed e756732386842 ∧ code e756732386842 = 9552825409050 := by decide
theorem cert_e756732386842 : check e756732386842 [] .sourceHead = true := by decide
def e756732390938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732390938 : Closed e756732390938 ∧ code e756732390938 = 9552825413146 := by decide
theorem cert_e756732390938 : check e756732390938 [] .sourceHead = true := by decide
def e756732882458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732882458 : Closed e756732882458 ∧ code e756732882458 = 9552825904666 := by decide
theorem cert_e756732882458 : check e756732882458 [] .sourceHead = true := by decide
def e756732884506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732884506 : Closed e756732884506 ∧ code e756732884506 = 9552825906714 := by decide
theorem cert_e756732884506 : check e756732884506 [] .sourceHead = true := by decide
def e756732898842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732898842 : Closed e756732898842 ∧ code e756732898842 = 9552825921050 := by decide
theorem cert_e756732898842 : check e756732898842 [] .sourceHead = true := by decide
def e756732901914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732901914 : Closed e756732901914 ∧ code e756732901914 = 9552825924122 := by decide
theorem cert_e756732901914 : check e756732901914 [] .sourceHead = true := by decide
def e756732909082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732909082 : Closed e756732909082 ∧ code e756732909082 = 9552825931290 := by decide
theorem cert_e756732909082 : check e756732909082 [] .sourceHead = true := by decide
def e756732910106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732910106 : Closed e756732910106 ∧ code e756732910106 = 9552825932314 := by decide
theorem cert_e756732910106 : check e756732910106 [] .sourceHead = true := by decide
def e756732980762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732980762 : Closed e756732980762 ∧ code e756732980762 = 9552826002970 := by decide
theorem cert_e756732980762 : check e756732980762 [] .sourceHead = true := by decide
def e756732982810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756732982810 : Closed e756732982810 ∧ code e756732982810 = 9552826005018 := by decide
theorem cert_e756732982810 : check e756732982810 [] .sourceHead = true := by decide
def e756733079066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756733079066 : Closed e756733079066 ∧ code e756733079066 = 9552826101274 := by decide
theorem cert_e756733079066 : check e756733079066 [] .sourceHead = true := by decide
def e756733082138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756733082138 : Closed e756733082138 ∧ code e756733082138 = 9552826104346 := by decide
theorem cert_e756733082138 : check e756733082138 [] .sourceHead = true := by decide
def e756733108250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756733108250 : Closed e756733108250 ∧ code e756733108250 = 9552826130458 := by decide
theorem cert_e756733108250 : check e756733108250 [] .sourceHead = true := by decide
def e756733108342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756733108342 : Closed e756733108342 ∧ code e756733108342 = 9552826130550 := by decide
theorem cert_e756733108342 : check e756733108342 [] .sourceHead = true := by decide
def e756733108586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756733108586 : Closed e756733108586 ∧ code e756733108586 = 9552826130794 := by decide
theorem cert_e756733108586 : check e756733108586 [] .sourceHead = true := by decide
def e756733108634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756733108634 : Closed e756733108634 ∧ code e756733108634 = 9552826130842 := by decide
theorem cert_e756733108634 : check e756733108634 [] .sourceHead = true := by decide
def e756733109786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756733109786 : Closed e756733109786 ∧ code e756733109786 = 9552826131994 := by decide
theorem cert_e756733109786 : check e756733109786 [] .sourceHead = true := by decide
def e756733130266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756733130266 : Closed e756733130266 ∧ code e756733130266 = 9552826152474 := by decide
theorem cert_e756733130266 : check e756733130266 [] .sourceHead = true := by decide
def e756733131290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756733131290 : Closed e756733131290 ∧ code e756733131290 = 9552826153498 := by decide
theorem cert_e756733131290 : check e756733131290 [] .sourceHead = true := by decide
def e756733141018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756733141018 : Closed e756733141018 ∧ code e756733141018 = 9552826163226 := by decide
theorem cert_e756733141018 : check e756733141018 [] .sourceHead = true := by decide
def e756733141110 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756733141110 : Closed e756733141110 ∧ code e756733141110 = 9552826163318 := by decide
theorem cert_e756733141110 : check e756733141110 [] .sourceHead = true := by decide
def e756733141354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756733141354 : Closed e756733141354 ∧ code e756733141354 = 9552826163562 := by decide
theorem cert_e756733141354 : check e756733141354 [] .sourceHead = true := by decide
def e756733141402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756733141402 : Closed e756733141402 ∧ code e756733141402 = 9552826163610 := by decide
theorem cert_e756733141402 : check e756733141402 [] .sourceHead = true := by decide
def e756733142554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756733142554 : Closed e756733142554 ∧ code e756733142554 = 9552826164762 := by decide
theorem cert_e756733142554 : check e756733142554 [] .sourceHead = true := by decide
def e756734352922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734352922 : Closed e756734352922 ∧ code e756734352922 = 9552827375130 := by decide
theorem cert_e756734352922 : check e756734352922 [] .sourceHead = true := by decide
def e756734359066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734359066 : Closed e756734359066 ∧ code e756734359066 = 9552827381274 := by decide
theorem cert_e756734359066 : check e756734359066 [] .sourceHead = true := by decide
def e756734602778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734602778 : Closed e756734602778 ∧ code e756734602778 = 9552827624986 := by decide
theorem cert_e756734602778 : check e756734602778 [] .sourceHead = true := by decide
def e756734605850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734605850 : Closed e756734605850 ∧ code e756734605850 = 9552827628058 := by decide
theorem cert_e756734605850 : check e756734605850 [] .sourceHead = true := by decide
def e756734618138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734618138 : Closed e756734618138 ∧ code e756734618138 = 9552827640346 := by decide
theorem cert_e756734618138 : check e756734618138 [] .sourceHead = true := by decide
def e756734651930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734651930 : Closed e756734651930 ∧ code e756734651930 = 9552827674138 := by decide
theorem cert_e756734651930 : check e756734651930 [] .sourceHead = true := by decide
def e756734655002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734655002 : Closed e756734655002 ∧ code e756734655002 = 9552827677210 := by decide
theorem cert_e756734655002 : check e756734655002 [] .sourceHead = true := by decide
def e756734681114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756734681114 : Closed e756734681114 ∧ code e756734681114 = 9552827703322 := by decide
theorem cert_e756734681114 : check e756734681114 [] .sourceHead = true := by decide
def e756734681206 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756734681206 : Closed e756734681206 ∧ code e756734681206 = 9552827703414 := by decide
theorem cert_e756734681206 : check e756734681206 [] .sourceHead = true := by decide
def e756734681450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756734681450 : Closed e756734681450 ∧ code e756734681450 = 9552827703658 := by decide
theorem cert_e756734681450 : check e756734681450 [] .sourceHead = true := by decide
def e756734681498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756734681498 : Closed e756734681498 ∧ code e756734681498 = 9552827703706 := by decide
theorem cert_e756734681498 : check e756734681498 [] .sourceHead = true := by decide
def e756734682650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756734682650 : Closed e756734682650 ∧ code e756734682650 = 9552827704858 := by decide
theorem cert_e756734682650 : check e756734682650 [] .sourceHead = true := by decide
def e756734728730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756734728730 : Closed e756734728730 ∧ code e756734728730 = 9552827750938 := by decide
theorem cert_e756734728730 : check e756734728730 [] .sourceHead = true := by decide
def e756734730266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756734730266 : Closed e756734730266 ∧ code e756734730266 = 9552827752474 := by decide
theorem cert_e756734730266 : check e756734730266 [] .sourceHead = true := by decide
def e756734730358 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756734730358 : Closed e756734730358 ∧ code e756734730358 = 9552827752566 := by decide
theorem cert_e756734730358 : check e756734730358 [] .sourceHead = true := by decide
def e756734730602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756734730602 : Closed e756734730602 ∧ code e756734730602 = 9552827752810 := by decide
theorem cert_e756734730602 : check e756734730602 [] .sourceHead = true := by decide
def e756734730650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756734730650 : Closed e756734730650 ∧ code e756734730650 = 9552827752858 := by decide
theorem cert_e756734730650 : check e756734730650 [] .sourceHead = true := by decide
def e756734731802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756734731802 : Closed e756734731802 ∧ code e756734731802 = 9552827754010 := by decide
theorem cert_e756734731802 : check e756734731802 [] .sourceHead = true := by decide
def e756735340058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735340058 : Closed e756735340058 ∧ code e756735340058 = 9552828362266 := by decide
theorem cert_e756735340058 : check e756735340058 [] .sourceHead = true := by decide
def e756735342106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735342106 : Closed e756735342106 ∧ code e756735342106 = 9552828364314 := by decide
theorem cert_e756735342106 : check e756735342106 [] .sourceHead = true := by decide
def e756735464986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735464986 : Closed e756735464986 ∧ code e756735464986 = 9552828487194 := by decide
theorem cert_e756735464986 : check e756735464986 [] .sourceHead = true := by decide
def e756735466010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735466010 : Closed e756735466010 ∧ code e756735466010 = 9552828488218 := by decide
theorem cert_e756735466010 : check e756735466010 [] .sourceHead = true := by decide
def e756735470106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735470106 : Closed e756735470106 ∧ code e756735470106 = 9552828492314 := by decide
theorem cert_e756735470106 : check e756735470106 [] .sourceHead = true := by decide
def e756735489562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735489562 : Closed e756735489562 ∧ code e756735489562 = 9552828511770 := by decide
theorem cert_e756735489562 : check e756735489562 [] .sourceHead = true := by decide
def e756735490586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735490586 : Closed e756735490586 ∧ code e756735490586 = 9552828512794 := by decide
theorem cert_e756735490586 : check e756735490586 [] .sourceHead = true := by decide
def e756735500314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756735500314 : Closed e756735500314 ∧ code e756735500314 = 9552828522522 := by decide
theorem cert_e756735500314 : check e756735500314 [] .sourceHead = true := by decide
def e756735500406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756735500406 : Closed e756735500406 ∧ code e756735500406 = 9552828522614 := by decide
theorem cert_e756735500406 : check e756735500406 [] .sourceHead = true := by decide
def e756735500650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756735500650 : Closed e756735500650 ∧ code e756735500650 = 9552828522858 := by decide
theorem cert_e756735500650 : check e756735500650 [] .sourceHead = true := by decide
def e756735500698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756735500698 : Closed e756735500698 ∧ code e756735500698 = 9552828522906 := by decide
theorem cert_e756735500698 : check e756735500698 [] .sourceHead = true := by decide
def e756735501850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756735501850 : Closed e756735501850 ∧ code e756735501850 = 9552828524058 := by decide
theorem cert_e756735501850 : check e756735501850 [] .sourceHead = true := by decide
def e756735515162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756735515162 : Closed e756735515162 ∧ code e756735515162 = 9552828537370 := by decide
theorem cert_e756735515162 : check e756735515162 [] .sourceHead = true := by decide
def e756735516698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756735516698 : Closed e756735516698 ∧ code e756735516698 = 9552828538906 := by decide
theorem cert_e756735516698 : check e756735516698 [] .sourceHead = true := by decide
def e756735516790 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756735516790 : Closed e756735516790 ∧ code e756735516790 = 9552828538998 := by decide
theorem cert_e756735516790 : check e756735516790 [] .sourceHead = true := by decide
def e756735517034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756735517034 : Closed e756735517034 ∧ code e756735517034 = 9552828539242 := by decide
theorem cert_e756735517034 : check e756735517034 [] .sourceHead = true := by decide
def e756735517082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756735517082 : Closed e756735517082 ∧ code e756735517082 = 9552828539290 := by decide
theorem cert_e756735517082 : check e756735517082 [] .sourceHead = true := by decide
def e756735518234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756735518234 : Closed e756735518234 ∧ code e756735518234 = 9552828540442 := by decide
theorem cert_e756735518234 : check e756735518234 [] .sourceHead = true := by decide
def e756770631194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770631194 : Closed e756770631194 ∧ code e756770631194 = 9552863653402 := by decide
theorem cert_e756770631194 : check e756770631194 [] .sourceHead = true := by decide
def e756770633242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770633242 : Closed e756770633242 ∧ code e756770633242 = 9552863655450 := by decide
theorem cert_e756770633242 : check e756770633242 [] .sourceHead = true := by decide
def e756770647578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770647578 : Closed e756770647578 ∧ code e756770647578 = 9552863669786 := by decide
theorem cert_e756770647578 : check e756770647578 [] .sourceHead = true := by decide
def e756770650650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770650650 : Closed e756770650650 ∧ code e756770650650 = 9552863672858 := by decide
theorem cert_e756770650650 : check e756770650650 [] .sourceHead = true := by decide
def e756770657818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770657818 : Closed e756770657818 ∧ code e756770657818 = 9552863680026 := by decide
theorem cert_e756770657818 : check e756770657818 [] .sourceHead = true := by decide
def e756770658842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770658842 : Closed e756770658842 ∧ code e756770658842 = 9552863681050 := by decide
theorem cert_e756770658842 : check e756770658842 [] .sourceHead = true := by decide
def e756770729498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770729498 : Closed e756770729498 ∧ code e756770729498 = 9552863751706 := by decide
theorem cert_e756770729498 : check e756770729498 [] .sourceHead = true := by decide
def e756770731546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770731546 : Closed e756770731546 ∧ code e756770731546 = 9552863753754 := by decide
theorem cert_e756770731546 : check e756770731546 [] .sourceHead = true := by decide
def e756770827802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770827802 : Closed e756770827802 ∧ code e756770827802 = 9552863850010 := by decide
theorem cert_e756770827802 : check e756770827802 [] .sourceHead = true := by decide
def e756770830874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770830874 : Closed e756770830874 ∧ code e756770830874 = 9552863853082 := by decide
theorem cert_e756770830874 : check e756770830874 [] .sourceHead = true := by decide
def e756770879002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770879002 : Closed e756770879002 ∧ code e756770879002 = 9552863901210 := by decide
theorem cert_e756770879002 : check e756770879002 [] .sourceHead = true := by decide
def e756770880026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756770880026 : Closed e756770880026 ∧ code e756770880026 = 9552863902234 := by decide
theorem cert_e756770880026 : check e756770880026 [] .sourceHead = true := by decide
def e756786703726 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e756786703726 : Closed e756786703726 ∧ code e756786703726 = 9552879725934 := by decide
theorem cert_e756786703726 : check e756786703726 [] .sourceHead = true := by decide
def e756786703734 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e756786703734 : Closed e756786703734 ∧ code e756786703734 = 9552879725942 := by decide
theorem cert_e756786703734 : check e756786703734 [] .sourceHead = true := by decide
def e756786703790 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e756786703790 : Closed e756786703790 ∧ code e756786703790 = 9552879725998 := by decide
theorem cert_e756786703790 : check e756786703790 [] .sourceHead = true := by decide
def e756786703802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e756786703802 : Closed e756786703802 ∧ code e756786703802 = 9552879726010 := by decide
theorem cert_e756786703802 : check e756786703802 [] .sourceHead = true := by decide
def e756786703830 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e756786703830 : Closed e756786703830 ∧ code e756786703830 = 9552879726038 := by decide
theorem cert_e756786703830 : check e756786703830 [] .sourceHead = true := by decide
def e756786703834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e756786703834 : Closed e756786703834 ∧ code e756786703834 = 9552879726042 := by decide
theorem cert_e756786703834 : check e756786703834 [] .sourceHead = true := by decide
def e756786704046 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e756786704046 : Closed e756786704046 ∧ code e756786704046 = 9552879726254 := by decide
theorem cert_e756786704046 : check e756786704046 [] .sourceHead = true := by decide
def e756786704058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e756786704058 : Closed e756786704058 ∧ code e756786704058 = 9552879726266 := by decide
theorem cert_e756786704058 : check e756786704058 [] .sourceHead = true := by decide
def e756786704106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e756786704106 : Closed e756786704106 ∧ code e756786704106 = 9552879726314 := by decide
theorem cert_e756786704106 : check e756786704106 [] .sourceHead = true := by decide
def e756786704214 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e756786704214 : Closed e756786704214 ∧ code e756786704214 = 9552879726422 := by decide
theorem cert_e756786704214 : check e756786704214 [] .sourceHead = true := by decide
def e756786704218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e756786704218 : Closed e756786704218 ∧ code e756786704218 = 9552879726426 := by decide
theorem cert_e756786704218 : check e756786704218 [] .sourceHead = true := by decide
def e756786704234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e756786704234 : Closed e756786704234 ∧ code e756786704234 = 9552879726442 := by decide
theorem cert_e756786704234 : check e756786704234 [] .sourceHead = true := by decide
def e756786705262 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e756786705262 : Closed e756786705262 ∧ code e756786705262 = 9552879727470 := by decide
theorem cert_e756786705262 : check e756786705262 [] .sourceHead = true := by decide
def e756786705270 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e756786705270 : Closed e756786705270 ∧ code e756786705270 = 9552879727478 := by decide
theorem cert_e756786705270 : check e756786705270 [] .sourceHead = true := by decide
def e756786705326 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e756786705326 : Closed e756786705326 ∧ code e756786705326 = 9552879727534 := by decide
theorem cert_e756786705326 : check e756786705326 [] .sourceHead = true := by decide
def e756786705338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e756786705338 : Closed e756786705338 ∧ code e756786705338 = 9552879727546 := by decide
theorem cert_e756786705338 : check e756786705338 [] .sourceHead = true := by decide
def e756786705366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e756786705366 : Closed e756786705366 ∧ code e756786705366 = 9552879727574 := by decide
theorem cert_e756786705366 : check e756786705366 [] .sourceHead = true := by decide
def e756786705370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e756786705370 : Closed e756786705370 ∧ code e756786705370 = 9552879727578 := by decide
theorem cert_e756786705370 : check e756786705370 [] .sourceHead = true := by decide
def e756786705646 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e756786705646 : Closed e756786705646 ∧ code e756786705646 = 9552879727854 := by decide
theorem cert_e756786705646 : check e756786705646 [] .sourceHead = true := by decide
def e756786705654 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e756786705654 : Closed e756786705654 ∧ code e756786705654 = 9552879727862 := by decide
theorem cert_e756786705654 : check e756786705654 [] .sourceHead = true := by decide
def e756786706030 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e756786706030 : Closed e756786706030 ∧ code e756786706030 = 9552879728238 := by decide
theorem cert_e756786706030 : check e756786706030 [] .sourceHead = true := by decide
def e756786706042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e756786706042 : Closed e756786706042 ∧ code e756786706042 = 9552879728250 := by decide
theorem cert_e756786706042 : check e756786706042 [] .sourceHead = true := by decide
def e756786706230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e756786706230 : Closed e756786706230 ∧ code e756786706230 = 9552879728438 := by decide
theorem cert_e756786706230 : check e756786706230 [] .sourceHead = true := by decide
def e756786706234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e756786706234 : Closed e756786706234 ∧ code e756786706234 = 9552879728442 := by decide
theorem cert_e756786706234 : check e756786706234 [] .sourceHead = true := by decide
def e756786706862 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e756786706862 : Closed e756786706862 ∧ code e756786706862 = 9552879729070 := by decide
theorem cert_e756786706862 : check e756786706862 [] .sourceHead = true := by decide
def e756786706874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e756786706874 : Closed e756786706874 ∧ code e756786706874 = 9552879729082 := by decide
theorem cert_e756786706874 : check e756786706874 [] .sourceHead = true := by decide
def e756786706922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e756786706922 : Closed e756786706922 ∧ code e756786706922 = 9552879729130 := by decide
theorem cert_e756786706922 : check e756786706922 [] .sourceHead = true := by decide
def e756786707054 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e756786707054 : Closed e756786707054 ∧ code e756786707054 = 9552879729262 := by decide
theorem cert_e756786707054 : check e756786707054 [] .sourceHead = true := by decide
def e756786707066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e756786707066 : Closed e756786707066 ∧ code e756786707066 = 9552879729274 := by decide
theorem cert_e756786707066 : check e756786707066 [] .sourceHead = true := by decide
def e756786707354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e756786707354 : Closed e756786707354 ∧ code e756786707354 = 9552879729562 := by decide
theorem cert_e756786707354 : check e756786707354 [] .sourceHead = true := by decide
def e756786707670 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e756786707670 : Closed e756786707670 ∧ code e756786707670 = 9552879729878 := by decide
theorem cert_e756786707670 : check e756786707670 [] .sourceHead = true := by decide
def e756786707674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e756786707674 : Closed e756786707674 ∧ code e756786707674 = 9552879729882 := by decide
theorem cert_e756786707674 : check e756786707674 [] .sourceHead = true := by decide
def e756786707690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e756786707690 : Closed e756786707690 ∧ code e756786707690 = 9552879729898 := by decide
theorem cert_e756786707690 : check e756786707690 [] .sourceHead = true := by decide
def e756786707766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e756786707766 : Closed e756786707766 ∧ code e756786707766 = 9552879729974 := by decide
theorem cert_e756786707766 : check e756786707766 [] .sourceHead = true := by decide
def e756786707770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e756786707770 : Closed e756786707770 ∧ code e756786707770 = 9552879729978 := by decide
theorem cert_e756786707770 : check e756786707770 [] .sourceHead = true := by decide
def e756786707866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e756786707866 : Closed e756786707866 ∧ code e756786707866 = 9552879730074 := by decide
theorem cert_e756786707866 : check e756786707866 [] .sourceHead = true := by decide
end Blc.Floor43
