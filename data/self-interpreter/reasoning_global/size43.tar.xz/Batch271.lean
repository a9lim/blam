import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406202480282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2406202480282 : Closed e2406202480282 ∧ code e2406202480282 = 11202295502490 := by decide
theorem cert_e2406202480282 : check e2406202480282 [[]] .width = true := by decide
def e2406202480326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2406202480326 : Closed e2406202480326 ∧ code e2406202480326 = 11202295502534 := by decide
theorem cert_e2406202480326 : check e2406202480326 [[]] .width = true := by decide
def e2406202480406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2406202480406 : Closed e2406202480406 ∧ code e2406202480406 = 11202295502614 := by decide
theorem cert_e2406202480406 : check e2406202480406 [[]] .width = true := by decide
def e2406202480410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2406202480410 : Closed e2406202480410 ∧ code e2406202480410 = 11202295502618 := by decide
theorem cert_e2406202480410 : check e2406202480410 [[]] .width = true := by decide
def e2406202480454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2406202480454 : Closed e2406202480454 ∧ code e2406202480454 = 11202295502662 := by decide
theorem cert_e2406202480454 : check e2406202480454 [[]] .width = true := by decide
def e2406202480482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2406202480482 : Closed e2406202480482 ∧ code e2406202480482 = 11202295502690 := by decide
theorem cert_e2406202480482 : check e2406202480482 [[]] .width = true := by decide
def e2406202480666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406202480666 : Closed e2406202480666 ∧ code e2406202480666 = 11202295502874 := by decide
theorem cert_e2406202480666 : check e2406202480666 [[]] .width = true := by decide
def e2406202480758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406202480758 : Closed e2406202480758 ∧ code e2406202480758 = 11202295502966 := by decide
theorem cert_e2406202480758 : check e2406202480758 [[]] .width = true := by decide
def e2406202481002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406202481002 : Closed e2406202481002 ∧ code e2406202481002 = 11202295503210 := by decide
theorem cert_e2406202481002 : check e2406202481002 [[]] .width = true := by decide
def e2406202481026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2406202481026 : Closed e2406202481026 ∧ code e2406202481026 = 11202295503234 := by decide
theorem cert_e2406202481026 : check e2406202481026 [[]] .width = true := by decide
def e2406202481038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406202481038 : Closed e2406202481038 ∧ code e2406202481038 = 11202295503246 := by decide
theorem cert_e2406202481038 : check e2406202481038 [[]] .width = true := by decide
def e2406202481050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406202481050 : Closed e2406202481050 ∧ code e2406202481050 = 11202295503258 := by decide
theorem cert_e2406202481050 : check e2406202481050 [[]] .width = true := by decide
def e2406202481094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406202481094 : Closed e2406202481094 ∧ code e2406202481094 = 11202295503302 := by decide
theorem cert_e2406202481094 : check e2406202481094 [[]] .width = true := by decide
def e2406202481694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2406202481694 : Closed e2406202481694 ∧ code e2406202481694 = 11202295503902 := by decide
theorem cert_e2406202481694 : check e2406202481694 [[]] .width = true := by decide
def e2406202481862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406202481862 : Closed e2406202481862 ∧ code e2406202481862 = 11202295504070 := by decide
theorem cert_e2406202481862 : check e2406202481862 [[]] .width = true := by decide
def e2406202481890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2406202481890 : Closed e2406202481890 ∧ code e2406202481890 = 11202295504098 := by decide
theorem cert_e2406202481890 : check e2406202481890 [[]] .width = true := by decide
def e2406202496554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2406202496554 : Closed e2406202496554 ∧ code e2406202496554 = 11202295518762 := by decide
theorem cert_e2406202496554 : check e2406202496554 [[]] .width = true := by decide
def e2406202496650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2406202496650 : Closed e2406202496650 ∧ code e2406202496650 = 11202295518858 := by decide
theorem cert_e2406202496650 : check e2406202496650 [[]] .width = true := by decide
def e2406202496674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406202496674 : Closed e2406202496674 ∧ code e2406202496674 = 11202295518882 := by decide
theorem cert_e2406202496674 : check e2406202496674 [[]] .width = true := by decide
def e2406202497034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2406202497034 : Closed e2406202497034 ∧ code e2406202497034 = 11202295519242 := by decide
theorem cert_e2406202497034 : check e2406202497034 [[]] .width = true := by decide
def e2406202497082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2406202497082 : Closed e2406202497082 ∧ code e2406202497082 = 11202295519290 := by decide
theorem cert_e2406202497082 : check e2406202497082 [[]] .width = true := by decide
def e2406202497130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2406202497130 : Closed e2406202497130 ∧ code e2406202497130 = 11202295519338 := by decide
theorem cert_e2406202497130 : check e2406202497130 [[]] .width = true := by decide
def e2406202497178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2406202497178 : Closed e2406202497178 ∧ code e2406202497178 = 11202295519386 := by decide
theorem cert_e2406202497178 : check e2406202497178 [[]] .width = true := by decide
def e2406202497222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2406202497222 : Closed e2406202497222 ∧ code e2406202497222 = 11202295519430 := by decide
theorem cert_e2406202497222 : check e2406202497222 [[]] .width = true := by decide
def e2406202497418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2406202497418 : Closed e2406202497418 ∧ code e2406202497418 = 11202295519626 := by decide
theorem cert_e2406202497418 : check e2406202497418 [[]] .width = true := by decide
def e2406202497442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2406202497442 : Closed e2406202497442 ∧ code e2406202497442 = 11202295519650 := by decide
theorem cert_e2406202497442 : check e2406202497442 [[]] .width = true := by decide
def e2406202497538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2406202497538 : Closed e2406202497538 ∧ code e2406202497538 = 11202295519746 := by decide
theorem cert_e2406202497538 : check e2406202497538 [[]] .width = true := by decide
def e2406202497550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2406202497550 : Closed e2406202497550 ∧ code e2406202497550 = 11202295519758 := by decide
theorem cert_e2406202497550 : check e2406202497550 [[]] .width = true := by decide
def e2406202497562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406202497562 : Closed e2406202497562 ∧ code e2406202497562 = 11202295519770 := by decide
theorem cert_e2406202497562 : check e2406202497562 [[]] .width = true := by decide
def e2406202497634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406202497634 : Closed e2406202497634 ∧ code e2406202497634 = 11202295519842 := by decide
theorem cert_e2406202497634 : check e2406202497634 [[]] .width = true := by decide
def e2406202499098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406202499098 : Closed e2406202499098 ∧ code e2406202499098 = 11202295521306 := by decide
theorem cert_e2406202499098 : check e2406202499098 [[]] .width = true := by decide
def e2406202499182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2406202499182 : Closed e2406202499182 ∧ code e2406202499182 = 11202295521390 := by decide
theorem cert_e2406202499182 : check e2406202499182 [[]] .width = true := by decide
def e2406202499190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406202499190 : Closed e2406202499190 ∧ code e2406202499190 = 11202295521398 := by decide
theorem cert_e2406202499190 : check e2406202499190 [[]] .width = true := by decide
def e2406202499194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2406202499194 : Closed e2406202499194 ∧ code e2406202499194 = 11202295521402 := by decide
theorem cert_e2406202499194 : check e2406202499194 [[]] .width = true := by decide
def e2406202499434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406202499434 : Closed e2406202499434 ∧ code e2406202499434 = 11202295521642 := by decide
theorem cert_e2406202499434 : check e2406202499434 [[]] .width = true := by decide
def e2406202499470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406202499470 : Closed e2406202499470 ∧ code e2406202499470 = 11202295521678 := by decide
theorem cert_e2406202499470 : check e2406202499470 [[]] .width = true := by decide
def e2406202499482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406202499482 : Closed e2406202499482 ∧ code e2406202499482 = 11202295521690 := by decide
theorem cert_e2406202499482 : check e2406202499482 [[]] .width = true := by decide
def e2406202499526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406202499526 : Closed e2406202499526 ∧ code e2406202499526 = 11202295521734 := by decide
theorem cert_e2406202499526 : check e2406202499526 [[]] .width = true := by decide
def e2406202500490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2406202500490 : Closed e2406202500490 ∧ code e2406202500490 = 11202295522698 := by decide
theorem cert_e2406202500490 : check e2406202500490 [[]] .width = true := by decide
def e2406202500514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2406202500514 : Closed e2406202500514 ∧ code e2406202500514 = 11202295522722 := by decide
theorem cert_e2406202500514 : check e2406202500514 [[]] .width = true := by decide
def e2406202500610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2406202500610 : Closed e2406202500610 ∧ code e2406202500610 = 11202295522818 := by decide
theorem cert_e2406202500610 : check e2406202500610 [[]] .width = true := by decide
def e2406202500622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2406202500622 : Closed e2406202500622 ∧ code e2406202500622 = 11202295522830 := by decide
theorem cert_e2406202500622 : check e2406202500622 [[]] .width = true := by decide
def e2406202500634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406202500634 : Closed e2406202500634 ∧ code e2406202500634 = 11202295522842 := by decide
theorem cert_e2406202500634 : check e2406202500634 [[]] .width = true := by decide
def e2406202500706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2406202500706 : Closed e2406202500706 ∧ code e2406202500706 = 11202295522914 := by decide
theorem cert_e2406202500706 : check e2406202500706 [[]] .width = true := by decide
def e2406202546690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2406202546690 : Closed e2406202546690 ∧ code e2406202546690 = 11202295568898 := by decide
theorem cert_e2406202546690 : check e2406202546690 [[]] .width = true := by decide
def e2406202546714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406202546714 : Closed e2406202546714 ∧ code e2406202546714 = 11202295568922 := by decide
theorem cert_e2406202546714 : check e2406202546714 [[]] .width = true := by decide
def e2406203056154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406203056154 : Closed e2406203056154 ∧ code e2406203056154 = 11202296078362 := by decide
theorem cert_e2406203056154 : check e2406203056154 [[]] .width = true := by decide
def e2406203056246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406203056246 : Closed e2406203056246 ∧ code e2406203056246 = 11202296078454 := by decide
theorem cert_e2406203056246 : check e2406203056246 [[]] .width = true := by decide
def e2406203056490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406203056490 : Closed e2406203056490 ∧ code e2406203056490 = 11202296078698 := by decide
theorem cert_e2406203056490 : check e2406203056490 [[]] .width = true := by decide
def e2406203056538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406203056538 : Closed e2406203056538 ∧ code e2406203056538 = 11202296078746 := by decide
theorem cert_e2406203056538 : check e2406203056538 [[]] .width = true := by decide
def e2406203109574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406203109574 : Closed e2406203109574 ∧ code e2406203109574 = 11202296131782 := by decide
theorem cert_e2406203109574 : check e2406203109574 [[]] .width = true := by decide
def e2406203117766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406203117766 : Closed e2406203117766 ∧ code e2406203117766 = 11202296139974 := by decide
theorem cert_e2406203117766 : check e2406203117766 [[]] .width = true := by decide
def e2406203119642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406203119642 : Closed e2406203119642 ∧ code e2406203119642 = 11202296141850 := by decide
theorem cert_e2406203119642 : check e2406203119642 [[]] .width = true := by decide
def e2406203121178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203121178 : Closed e2406203121178 ∧ code e2406203121178 = 11202296143386 := by decide
theorem cert_e2406203121178 : check e2406203121178 [[]] .width = true := by decide
def e2406203127322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203127322 : Closed e2406203127322 ∧ code e2406203127322 = 11202296149530 := by decide
theorem cert_e2406203127322 : check e2406203127322 [[]] .width = true := by decide
def e2406203195590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406203195590 : Closed e2406203195590 ∧ code e2406203195590 = 11202296217798 := by decide
theorem cert_e2406203195590 : check e2406203195590 [[]] .width = true := by decide
def e2406203196118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2406203196118 : Closed e2406203196118 ∧ code e2406203196118 = 11202296218326 := by decide
theorem cert_e2406203196118 : check e2406203196118 [[]] .width = true := by decide
def e2406203196122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2406203196122 : Closed e2406203196122 ∧ code e2406203196122 = 11202296218330 := by decide
theorem cert_e2406203196122 : check e2406203196122 [[]] .width = true := by decide
def e2406203196138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2406203196138 : Closed e2406203196138 ∧ code e2406203196138 = 11202296218346 := by decide
theorem cert_e2406203196138 : check e2406203196138 [[]] .width = true := by decide
def e2406203196214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2406203196214 : Closed e2406203196214 ∧ code e2406203196214 = 11202296218422 := by decide
theorem cert_e2406203196214 : check e2406203196214 [[]] .width = true := by decide
def e2406203196218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2406203196218 : Closed e2406203196218 ∧ code e2406203196218 = 11202296218426 := by decide
theorem cert_e2406203196218 : check e2406203196218 [[]] .width = true := by decide
def e2406203196302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2406203196302 : Closed e2406203196302 ∧ code e2406203196302 = 11202296218510 := by decide
theorem cert_e2406203196302 : check e2406203196302 [[]] .width = true := by decide
def e2406203196314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2406203196314 : Closed e2406203196314 ∧ code e2406203196314 = 11202296218522 := by decide
theorem cert_e2406203196314 : check e2406203196314 [[]] .width = true := by decide
def e2406203198234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2406203198234 : Closed e2406203198234 ∧ code e2406203198234 = 11202296220442 := by decide
theorem cert_e2406203198234 : check e2406203198234 [[]] .width = true := by decide
def e2406203198278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2406203198278 : Closed e2406203198278 ∧ code e2406203198278 = 11202296220486 := by decide
theorem cert_e2406203198278 : check e2406203198278 [[]] .width = true := by decide
def e2406203198518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2406203198518 : Closed e2406203198518 ∧ code e2406203198518 = 11202296220726 := by decide
theorem cert_e2406203198518 : check e2406203198518 [[]] .width = true := by decide
def e2406203198522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2406203198522 : Closed e2406203198522 ∧ code e2406203198522 = 11202296220730 := by decide
theorem cert_e2406203198522 : check e2406203198522 [[]] .width = true := by decide
def e2406203198662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406203198662 : Closed e2406203198662 ∧ code e2406203198662 = 11202296220870 := by decide
theorem cert_e2406203198662 : check e2406203198662 [[]] .width = true := by decide
def e2406203369498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406203369498 : Closed e2406203369498 ∧ code e2406203369498 = 11202296391706 := by decide
theorem cert_e2406203369498 : check e2406203369498 [[]] .width = true := by decide
def e2406203371034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203371034 : Closed e2406203371034 ∧ code e2406203371034 = 11202296393242 := by decide
theorem cert_e2406203371034 : check e2406203371034 [[]] .width = true := by decide
def e2406203374106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203374106 : Closed e2406203374106 ∧ code e2406203374106 = 11202296396314 := by decide
theorem cert_e2406203374106 : check e2406203374106 [[]] .width = true := by decide
def e2406203386394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203386394 : Closed e2406203386394 ∧ code e2406203386394 = 11202296408602 := by decide
theorem cert_e2406203386394 : check e2406203386394 [[]] .width = true := by decide
def e2406203394074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406203394074 : Closed e2406203394074 ∧ code e2406203394074 = 11202296416282 := by decide
theorem cert_e2406203394074 : check e2406203394074 [[]] .width = true := by decide
def e2406203400218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406203400218 : Closed e2406203400218 ∧ code e2406203400218 = 11202296422426 := by decide
theorem cert_e2406203400218 : check e2406203400218 [[]] .width = true := by decide
def e2406203400310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406203400310 : Closed e2406203400310 ∧ code e2406203400310 = 11202296422518 := by decide
theorem cert_e2406203400310 : check e2406203400310 [[]] .width = true := by decide
def e2406203400554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406203400554 : Closed e2406203400554 ∧ code e2406203400554 = 11202296422762 := by decide
theorem cert_e2406203400554 : check e2406203400554 [[]] .width = true := by decide
def e2406203400602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406203400602 : Closed e2406203400602 ∧ code e2406203400602 = 11202296422810 := by decide
theorem cert_e2406203400602 : check e2406203400602 [[]] .width = true := by decide
def e2406203404486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406203404486 : Closed e2406203404486 ∧ code e2406203404486 = 11202296426694 := by decide
theorem cert_e2406203404486 : check e2406203404486 [[]] .width = true := by decide
def e2406203406362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406203406362 : Closed e2406203406362 ∧ code e2406203406362 = 11202296428570 := by decide
theorem cert_e2406203406362 : check e2406203406362 [[]] .width = true := by decide
def e2406203418650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406203418650 : Closed e2406203418650 ∧ code e2406203418650 = 11202296440858 := by decide
theorem cert_e2406203418650 : check e2406203418650 [[]] .width = true := by decide
def e2406203420186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203420186 : Closed e2406203420186 ∧ code e2406203420186 = 11202296442394 := by decide
theorem cert_e2406203420186 : check e2406203420186 [[]] .width = true := by decide
def e2406203423258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203423258 : Closed e2406203423258 ∧ code e2406203423258 = 11202296445466 := by decide
theorem cert_e2406203423258 : check e2406203423258 [[]] .width = true := by decide
def e2406203424794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406203424794 : Closed e2406203424794 ∧ code e2406203424794 = 11202296447002 := by decide
theorem cert_e2406203424794 : check e2406203424794 [[]] .width = true := by decide
def e2406203424886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406203424886 : Closed e2406203424886 ∧ code e2406203424886 = 11202296447094 := by decide
theorem cert_e2406203424886 : check e2406203424886 [[]] .width = true := by decide
def e2406203425130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406203425130 : Closed e2406203425130 ∧ code e2406203425130 = 11202296447338 := by decide
theorem cert_e2406203425130 : check e2406203425130 [[]] .width = true := by decide
def e2406203425178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406203425178 : Closed e2406203425178 ∧ code e2406203425178 = 11202296447386 := by decide
theorem cert_e2406203425178 : check e2406203425178 [[]] .width = true := by decide
def e2406203426186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406203426186 : Closed e2406203426186 ∧ code e2406203426186 = 11202296448394 := by decide
theorem cert_e2406203426186 : check e2406203426186 [[]] .width = true := by decide
def e2406203426210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406203426210 : Closed e2406203426210 ∧ code e2406203426210 = 11202296448418 := by decide
theorem cert_e2406203426210 : check e2406203426210 [[]] .width = true := by decide
def e2406203426318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406203426318 : Closed e2406203426318 ∧ code e2406203426318 = 11202296448526 := by decide
theorem cert_e2406203426318 : check e2406203426318 [[]] .width = true := by decide
def e2406203426330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406203426330 : Closed e2406203426330 ∧ code e2406203426330 = 11202296448538 := by decide
theorem cert_e2406203426330 : check e2406203426330 [[]] .width = true := by decide
def e2406203426402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406203426402 : Closed e2406203426402 ∧ code e2406203426402 = 11202296448610 := by decide
theorem cert_e2406203426402 : check e2406203426402 [[]] .width = true := by decide
def e2406203441350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406203441350 : Closed e2406203441350 ∧ code e2406203441350 = 11202296463558 := by decide
theorem cert_e2406203441350 : check e2406203441350 [[]] .width = true := by decide
def e2406203449370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406203449370 : Closed e2406203449370 ∧ code e2406203449370 = 11202296471578 := by decide
theorem cert_e2406203449370 : check e2406203449370 [[]] .width = true := by decide
def e2406203449462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406203449462 : Closed e2406203449462 ∧ code e2406203449462 = 11202296471670 := by decide
theorem cert_e2406203449462 : check e2406203449462 [[]] .width = true := by decide
def e2406203449706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406203449706 : Closed e2406203449706 ∧ code e2406203449706 = 11202296471914 := by decide
theorem cert_e2406203449706 : check e2406203449706 [[]] .width = true := by decide
def e2406203449754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406203449754 : Closed e2406203449754 ∧ code e2406203449754 = 11202296471962 := by decide
theorem cert_e2406203449754 : check e2406203449754 [[]] .width = true := by decide
def e2406203463706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406203463706 : Closed e2406203463706 ∧ code e2406203463706 = 11202296485914 := by decide
theorem cert_e2406203463706 : check e2406203463706 [[]] .width = true := by decide
def e2406203474118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406203474118 : Closed e2406203474118 ∧ code e2406203474118 = 11202296496326 := by decide
theorem cert_e2406203474118 : check e2406203474118 [[]] .width = true := by decide
def e2406203496986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406203496986 : Closed e2406203496986 ∧ code e2406203496986 = 11202296519194 := by decide
theorem cert_e2406203496986 : check e2406203496986 [[]] .width = true := by decide
def e2406203498522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406203498522 : Closed e2406203498522 ∧ code e2406203498522 = 11202296520730 := by decide
theorem cert_e2406203498522 : check e2406203498522 [[]] .width = true := by decide
def e2406203498614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406203498614 : Closed e2406203498614 ∧ code e2406203498614 = 11202296520822 := by decide
theorem cert_e2406203498614 : check e2406203498614 [[]] .width = true := by decide
def e2406203498858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406203498858 : Closed e2406203498858 ∧ code e2406203498858 = 11202296521066 := by decide
theorem cert_e2406203498858 : check e2406203498858 [[]] .width = true := by decide
def e2406203498906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406203498906 : Closed e2406203498906 ∧ code e2406203498906 = 11202296521114 := by decide
theorem cert_e2406203498906 : check e2406203498906 [[]] .width = true := by decide
def e2406203523098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2406203523098 : Closed e2406203523098 ∧ code e2406203523098 = 11202296545306 := by decide
theorem cert_e2406203523098 : check e2406203523098 [[]] .width = true := by decide
def e2406203523190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2406203523190 : Closed e2406203523190 ∧ code e2406203523190 = 11202296545398 := by decide
theorem cert_e2406203523190 : check e2406203523190 [[]] .width = true := by decide
def e2406203523434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2406203523434 : Closed e2406203523434 ∧ code e2406203523434 = 11202296545642 := by decide
theorem cert_e2406203523434 : check e2406203523434 [[]] .width = true := by decide
def e2406203523482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2406203523482 : Closed e2406203523482 ∧ code e2406203523482 = 11202296545690 := by decide
theorem cert_e2406203523482 : check e2406203523482 [[]] .width = true := by decide
def e2406203523566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2406203523566 : Closed e2406203523566 ∧ code e2406203523566 = 11202296545774 := by decide
theorem cert_e2406203523566 : check e2406203523566 [[]] .width = true := by decide
def e2406203524490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2406203524490 : Closed e2406203524490 ∧ code e2406203524490 = 11202296546698 := by decide
theorem cert_e2406203524490 : check e2406203524490 [[]] .width = true := by decide
def e2406203524514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2406203524514 : Closed e2406203524514 ∧ code e2406203524514 = 11202296546722 := by decide
theorem cert_e2406203524514 : check e2406203524514 [[]] .width = true := by decide
def e2406203524526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2406203524526 : Closed e2406203524526 ∧ code e2406203524526 = 11202296546734 := by decide
theorem cert_e2406203524526 : check e2406203524526 [[]] .width = true := by decide
def e2406203524534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2406203524534 : Closed e2406203524534 ∧ code e2406203524534 = 11202296546742 := by decide
theorem cert_e2406203524534 : check e2406203524534 [[]] .width = true := by decide
def e2406203524538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2406203524538 : Closed e2406203524538 ∧ code e2406203524538 = 11202296546746 := by decide
theorem cert_e2406203524538 : check e2406203524538 [[]] .width = true := by decide
def e2406203524566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2406203524566 : Closed e2406203524566 ∧ code e2406203524566 = 11202296546774 := by decide
theorem cert_e2406203524566 : check e2406203524566 [[]] .width = true := by decide
def e2406203524570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2406203524570 : Closed e2406203524570 ∧ code e2406203524570 = 11202296546778 := by decide
theorem cert_e2406203524570 : check e2406203524570 [[]] .width = true := by decide
def e2406203524586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2406203524586 : Closed e2406203524586 ∧ code e2406203524586 = 11202296546794 := by decide
theorem cert_e2406203524586 : check e2406203524586 [[]] .width = true := by decide
def e2406203524622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2406203524622 : Closed e2406203524622 ∧ code e2406203524622 = 11202296546830 := by decide
theorem cert_e2406203524622 : check e2406203524622 [[]] .width = true := by decide
def e2406203524634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406203524634 : Closed e2406203524634 ∧ code e2406203524634 = 11202296546842 := by decide
theorem cert_e2406203524634 : check e2406203524634 [[]] .width = true := by decide
def e2406203524706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2406203524706 : Closed e2406203524706 ∧ code e2406203524706 = 11202296546914 := by decide
theorem cert_e2406203524706 : check e2406203524706 [[]] .width = true := by decide
def e2406203524718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2406203524718 : Closed e2406203524718 ∧ code e2406203524718 = 11202296546926 := by decide
theorem cert_e2406203524718 : check e2406203524718 [[]] .width = true := by decide
def e2406203524726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2406203524726 : Closed e2406203524726 ∧ code e2406203524726 = 11202296546934 := by decide
theorem cert_e2406203524726 : check e2406203524726 [[]] .width = true := by decide
def e2406203524730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2406203524730 : Closed e2406203524730 ∧ code e2406203524730 = 11202296546938 := by decide
theorem cert_e2406203524730 : check e2406203524730 [[]] .width = true := by decide
def e2406203524918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2406203524918 : Closed e2406203524918 ∧ code e2406203524918 = 11202296547126 := by decide
theorem cert_e2406203524918 : check e2406203524918 [[]] .width = true := by decide
def e2406203524922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2406203524922 : Closed e2406203524922 ∧ code e2406203524922 = 11202296547130 := by decide
theorem cert_e2406203524922 : check e2406203524922 [[]] .width = true := by decide
def e2406203525018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2406203525018 : Closed e2406203525018 ∧ code e2406203525018 = 11202296547226 := by decide
theorem cert_e2406203525018 : check e2406203525018 [[]] .width = true := by decide
def e2406203528618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2406203528618 : Closed e2406203528618 ∧ code e2406203528618 = 11202296550826 := by decide
theorem cert_e2406203528618 : check e2406203528618 [[]] .width = true := by decide
def e2406203528714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2406203528714 : Closed e2406203528714 ∧ code e2406203528714 = 11202296550922 := by decide
theorem cert_e2406203528714 : check e2406203528714 [[]] .width = true := by decide
def e2406203528758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2406203528758 : Closed e2406203528758 ∧ code e2406203528758 = 11202296550966 := by decide
theorem cert_e2406203528758 : check e2406203528758 [[]] .width = true := by decide
def e2406203528762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2406203528762 : Closed e2406203528762 ∧ code e2406203528762 = 11202296550970 := by decide
theorem cert_e2406203528762 : check e2406203528762 [[]] .width = true := by decide
def e2406203528810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2406203528810 : Closed e2406203528810 ∧ code e2406203528810 = 11202296551018 := by decide
theorem cert_e2406203528810 : check e2406203528810 [[]] .width = true := by decide
def e2406203528834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2406203528834 : Closed e2406203528834 ∧ code e2406203528834 = 11202296551042 := by decide
theorem cert_e2406203528834 : check e2406203528834 [[]] .width = true := by decide
def e2406203528846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2406203528846 : Closed e2406203528846 ∧ code e2406203528846 = 11202296551054 := by decide
theorem cert_e2406203528846 : check e2406203528846 [[]] .width = true := by decide
def e2406203528858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2406203528858 : Closed e2406203528858 ∧ code e2406203528858 = 11202296551066 := by decide
theorem cert_e2406203528858 : check e2406203528858 [[]] .width = true := by decide
def e2406203528902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2406203528902 : Closed e2406203528902 ∧ code e2406203528902 = 11202296551110 := by decide
theorem cert_e2406203528902 : check e2406203528902 [[]] .width = true := by decide
def e2406203528982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2406203528982 : Closed e2406203528982 ∧ code e2406203528982 = 11202296551190 := by decide
theorem cert_e2406203528982 : check e2406203528982 [[]] .width = true := by decide
def e2406203528986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2406203528986 : Closed e2406203528986 ∧ code e2406203528986 = 11202296551194 := by decide
theorem cert_e2406203528986 : check e2406203528986 [[]] .width = true := by decide
def e2406203529030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2406203529030 : Closed e2406203529030 ∧ code e2406203529030 = 11202296551238 := by decide
theorem cert_e2406203529030 : check e2406203529030 [[]] .width = true := by decide
def e2406203529058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2406203529058 : Closed e2406203529058 ∧ code e2406203529058 = 11202296551266 := by decide
theorem cert_e2406203529058 : check e2406203529058 [[]] .width = true := by decide
def e2406203529242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406203529242 : Closed e2406203529242 ∧ code e2406203529242 = 11202296551450 := by decide
theorem cert_e2406203529242 : check e2406203529242 [[]] .width = true := by decide
def e2406203529334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406203529334 : Closed e2406203529334 ∧ code e2406203529334 = 11202296551542 := by decide
theorem cert_e2406203529334 : check e2406203529334 [[]] .width = true := by decide
def e2406203529578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406203529578 : Closed e2406203529578 ∧ code e2406203529578 = 11202296551786 := by decide
theorem cert_e2406203529578 : check e2406203529578 [[]] .width = true := by decide
def e2406203529602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2406203529602 : Closed e2406203529602 ∧ code e2406203529602 = 11202296551810 := by decide
theorem cert_e2406203529602 : check e2406203529602 [[]] .width = true := by decide
def e2406203529614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406203529614 : Closed e2406203529614 ∧ code e2406203529614 = 11202296551822 := by decide
theorem cert_e2406203529614 : check e2406203529614 [[]] .width = true := by decide
def e2406203529626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406203529626 : Closed e2406203529626 ∧ code e2406203529626 = 11202296551834 := by decide
theorem cert_e2406203529626 : check e2406203529626 [[]] .width = true := by decide
def e2406203529670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406203529670 : Closed e2406203529670 ∧ code e2406203529670 = 11202296551878 := by decide
theorem cert_e2406203529670 : check e2406203529670 [[]] .width = true := by decide
def e2406203530270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2406203530270 : Closed e2406203530270 ∧ code e2406203530270 = 11202296552478 := by decide
theorem cert_e2406203530270 : check e2406203530270 [[]] .width = true := by decide
def e2406203530438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406203530438 : Closed e2406203530438 ∧ code e2406203530438 = 11202296552646 := by decide
theorem cert_e2406203530438 : check e2406203530438 [[]] .width = true := by decide
def e2406203530466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2406203530466 : Closed e2406203530466 ∧ code e2406203530466 = 11202296552674 := by decide
theorem cert_e2406203530466 : check e2406203530466 [[]] .width = true := by decide
def e2406203545130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2406203545130 : Closed e2406203545130 ∧ code e2406203545130 = 11202296567338 := by decide
theorem cert_e2406203545130 : check e2406203545130 [[]] .width = true := by decide
def e2406203545226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2406203545226 : Closed e2406203545226 ∧ code e2406203545226 = 11202296567434 := by decide
theorem cert_e2406203545226 : check e2406203545226 [[]] .width = true := by decide
def e2406203545250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406203545250 : Closed e2406203545250 ∧ code e2406203545250 = 11202296567458 := by decide
theorem cert_e2406203545250 : check e2406203545250 [[]] .width = true := by decide
def e2406203545610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2406203545610 : Closed e2406203545610 ∧ code e2406203545610 = 11202296567818 := by decide
theorem cert_e2406203545610 : check e2406203545610 [[]] .width = true := by decide
def e2406203545658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2406203545658 : Closed e2406203545658 ∧ code e2406203545658 = 11202296567866 := by decide
theorem cert_e2406203545658 : check e2406203545658 [[]] .width = true := by decide
def e2406203545706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2406203545706 : Closed e2406203545706 ∧ code e2406203545706 = 11202296567914 := by decide
theorem cert_e2406203545706 : check e2406203545706 [[]] .width = true := by decide
def e2406203545754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2406203545754 : Closed e2406203545754 ∧ code e2406203545754 = 11202296567962 := by decide
theorem cert_e2406203545754 : check e2406203545754 [[]] .width = true := by decide
def e2406203545798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2406203545798 : Closed e2406203545798 ∧ code e2406203545798 = 11202296568006 := by decide
theorem cert_e2406203545798 : check e2406203545798 [[]] .width = true := by decide
def e2406203545994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2406203545994 : Closed e2406203545994 ∧ code e2406203545994 = 11202296568202 := by decide
theorem cert_e2406203545994 : check e2406203545994 [[]] .width = true := by decide
def e2406203546018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2406203546018 : Closed e2406203546018 ∧ code e2406203546018 = 11202296568226 := by decide
theorem cert_e2406203546018 : check e2406203546018 [[]] .width = true := by decide
def e2406203546114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2406203546114 : Closed e2406203546114 ∧ code e2406203546114 = 11202296568322 := by decide
theorem cert_e2406203546114 : check e2406203546114 [[]] .width = true := by decide
def e2406203546126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2406203546126 : Closed e2406203546126 ∧ code e2406203546126 = 11202296568334 := by decide
theorem cert_e2406203546126 : check e2406203546126 [[]] .width = true := by decide
end Blc.Floor43
