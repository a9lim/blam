import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2408971613722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408971613722 : Closed e2408971613722 ∧ code e2408971613722 = 11205064635930 := by decide
private def t_e2408971613722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408971613722 : ¬ IsSelfInterpreter e2408971613722 :=
  wSource (t := t_e2408971613722) (replay_sound (ps := []) (t := e2408971613722) (by decide)) (by decide)
def e2408971621914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408971621914 : Closed e2408971621914 ∧ code e2408971621914 = 11205064644122 := by decide
private def t_e2408971621914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408971621914 : ¬ IsSelfInterpreter e2408971621914 :=
  wSource (t := t_e2408971621914) (replay_sound (ps := []) (t := e2408971621914) (by decide)) (by decide)
def e2408971622938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408971622938 : Closed e2408971622938 ∧ code e2408971622938 = 11205064645146 := by decide
private def t_e2408971622938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408971622938 : ¬ IsSelfInterpreter e2408971622938 :=
  wSource (t := t_e2408971622938) (replay_sound (ps := []) (t := e2408971622938) (by decide)) (by decide)
def e2408971647002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408971647002 : Closed e2408971647002 ∧ code e2408971647002 = 11205064669210 := by decide
theorem cert_e2408971647002 : check e2408971647002 [[]] .width = true := by decide
def e2408971662874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408971662874 : Closed e2408971662874 ∧ code e2408971662874 = 11205064685082 := by decide
private def t_e2408971662874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408971662874 : ¬ IsSelfInterpreter e2408971662874 :=
  wSource (t := t_e2408971662874) (replay_sound (ps := []) (t := e2408971662874) (by decide)) (by decide)
def e2408971681990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408971681990 : Closed e2408971681990 ∧ code e2408971681990 = 11205064704198 := by decide
theorem cert_e2408971681990 : check e2408971681990 [[]] .width = true := by decide
def e2408971704346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408971704346 : Closed e2408971704346 ∧ code e2408971704346 = 11205064726554 := by decide
theorem cert_e2408971704346 : check e2408971704346 [[]] .width = true := by decide
def e2408971712026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408971712026 : Closed e2408971712026 ∧ code e2408971712026 = 11205064734234 := by decide
private def t_e2408971712026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408971712026 : ¬ IsSelfInterpreter e2408971712026 :=
  wSource (t := t_e2408971712026) (replay_sound (ps := []) (t := e2408971712026) (by decide)) (by decide)
def e2408971713050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408971713050 : Closed e2408971713050 ∧ code e2408971713050 = 11205064735258 := by decide
private def t_e2408971713050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408971713050 : ¬ IsSelfInterpreter e2408971713050 :=
  wSource (t := t_e2408971713050) (replay_sound (ps := []) (t := e2408971713050) (by decide)) (by decide)
def e2408971714758 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408971714758 : Closed e2408971714758 ∧ code e2408971714758 = 11205064736966 := by decide
theorem cert_e2408971714758 : check e2408971714758 [[]] .width = true := by decide
def e2408973425518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2408973425518 : Closed e2408973425518 ∧ code e2408973425518 = 11205066447726 := by decide
theorem cert_e2408973425518 : check e2408973425518 [[],[]] .chain = true := by decide
def e2408973425526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2408973425526 : Closed e2408973425526 ∧ code e2408973425526 = 11205066447734 := by decide
theorem cert_e2408973425526 : check e2408973425526 [[],[]] .chain = true := by decide
def e2408973425590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2408973425590 : Closed e2408973425590 ∧ code e2408973425590 = 11205066447798 := by decide
theorem cert_e2408973425590 : check e2408973425590 [[],[]] .chain = true := by decide
def e2408973426030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2408973426030 : Closed e2408973426030 ∧ code e2408973426030 = 11205066448238 := by decide
theorem cert_e2408973426030 : check e2408973426030 [[],[]] .chain = true := by decide
def e2408973426038 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2408973426038 : Closed e2408973426038 ∧ code e2408973426038 = 11205066448246 := by decide
theorem cert_e2408973426038 : check e2408973426038 [[],[]] .chain = true := by decide
def e2408973426094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2408973426094 : Closed e2408973426094 ∧ code e2408973426094 = 11205066448302 := by decide
theorem cert_e2408973426094 : check e2408973426094 [[],[]] .chain = true := by decide
def e2408973426106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2408973426106 : Closed e2408973426106 ∧ code e2408973426106 = 11205066448314 := by decide
theorem cert_e2408973426106 : check e2408973426106 [[],[]] .chain = true := by decide
def e2408973426134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2408973426134 : Closed e2408973426134 ∧ code e2408973426134 = 11205066448342 := by decide
theorem cert_e2408973426134 : check e2408973426134 [[],[]] .chain = true := by decide
def e2408973426138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2408973426138 : Closed e2408973426138 ∧ code e2408973426138 = 11205066448346 := by decide
theorem cert_e2408973426138 : check e2408973426138 [[],[]] .chain = true := by decide
def e2408973426358 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2408973426358 : Closed e2408973426358 ∧ code e2408973426358 = 11205066448566 := by decide
theorem cert_e2408973426358 : check e2408973426358 [[],[]] .chain = true := by decide
def e2408973426390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2408973426390 : Closed e2408973426390 ∧ code e2408973426390 = 11205066448598 := by decide
theorem cert_e2408973426390 : check e2408973426390 [[],[]] .chain = true := by decide
def e2408973426394 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2408973426394 : Closed e2408973426394 ∧ code e2408973426394 = 11205066448602 := by decide
theorem cert_e2408973426394 : check e2408973426394 [[],[]] .chain = true := by decide
def e2408973428590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2408973428590 : Closed e2408973428590 ∧ code e2408973428590 = 11205066450798 := by decide
theorem cert_e2408973428590 : check e2408973428590 [[],[]] .chain = true := by decide
def e2408973428598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2408973428598 : Closed e2408973428598 ∧ code e2408973428598 = 11205066450806 := by decide
theorem cert_e2408973428598 : check e2408973428598 [[],[]] .chain = true := by decide
def e2408973428662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2408973428662 : Closed e2408973428662 ∧ code e2408973428662 = 11205066450870 := by decide
theorem cert_e2408973428662 : check e2408973428662 [[],[]] .chain = true := by decide
def e2408973429998 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2408973429998 : Closed e2408973429998 ∧ code e2408973429998 = 11205066452206 := by decide
theorem cert_e2408973429998 : check e2408973429998 [[],[]] .chain = true := by decide
def e2408973430006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2408973430006 : Closed e2408973430006 ∧ code e2408973430006 = 11205066452214 := by decide
theorem cert_e2408973430006 : check e2408973430006 [[],[]] .chain = true := by decide
def e2408973430390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2408973430390 : Closed e2408973430390 ∧ code e2408973430390 = 11205066452598 := by decide
theorem cert_e2408973430390 : check e2408973430390 [[],[]] .chain = true := by decide
def e2408973431662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2408973431662 : Closed e2408973431662 ∧ code e2408973431662 = 11205066453870 := by decide
theorem cert_e2408973431662 : check e2408973431662 [[],[]] .chain = true := by decide
def e2408973431670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2408973431670 : Closed e2408973431670 ∧ code e2408973431670 = 11205066453878 := by decide
theorem cert_e2408973431670 : check e2408973431670 [[],[]] .chain = true := by decide
def e2408973431726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2408973431726 : Closed e2408973431726 ∧ code e2408973431726 = 11205066453934 := by decide
theorem cert_e2408973431726 : check e2408973431726 [[],[]] .chain = true := by decide
def e2408973431738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2408973431738 : Closed e2408973431738 ∧ code e2408973431738 = 11205066453946 := by decide
theorem cert_e2408973431738 : check e2408973431738 [[],[]] .chain = true := by decide
def e2408973431766 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2408973431766 : Closed e2408973431766 ∧ code e2408973431766 = 11205066453974 := by decide
theorem cert_e2408973431766 : check e2408973431766 [[],[]] .chain = true := by decide
def e2408973431770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2408973431770 : Closed e2408973431770 ∧ code e2408973431770 = 11205066453978 := by decide
theorem cert_e2408973431770 : check e2408973431770 [[],[]] .chain = true := by decide
def e2408973432046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2408973432046 : Closed e2408973432046 ∧ code e2408973432046 = 11205066454254 := by decide
theorem cert_e2408973432046 : check e2408973432046 [[],[]] .chain = true := by decide
def e2408973432054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2408973432054 : Closed e2408973432054 ∧ code e2408973432054 = 11205066454262 := by decide
theorem cert_e2408973432054 : check e2408973432054 [[],[]] .chain = true := by decide
def e2408973432430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2408973432430 : Closed e2408973432430 ∧ code e2408973432430 = 11205066454638 := by decide
theorem cert_e2408973432430 : check e2408973432430 [[],[]] .chain = true := by decide
def e2408973432442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2408973432442 : Closed e2408973432442 ∧ code e2408973432442 = 11205066454650 := by decide
theorem cert_e2408973432442 : check e2408973432442 [[],[]] .chain = true := by decide
def e2408973432630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2408973432630 : Closed e2408973432630 ∧ code e2408973432630 = 11205066454838 := by decide
theorem cert_e2408973432630 : check e2408973432630 [[],[]] .chain = true := by decide
def e2408973432634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2408973432634 : Closed e2408973432634 ∧ code e2408973432634 = 11205066454842 := by decide
theorem cert_e2408973432634 : check e2408973432634 [[],[]] .chain = true := by decide
def e2408973433270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2408973433270 : Closed e2408973433270 ∧ code e2408973433270 = 11205066455478 := by decide
theorem cert_e2408973433270 : check e2408973433270 [[],[]] .chain = true := by decide
def e2408973433302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2408973433302 : Closed e2408973433302 ∧ code e2408973433302 = 11205066455510 := by decide
theorem cert_e2408973433302 : check e2408973433302 [[],[]] .chain = true := by decide
def e2408973433306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2408973433306 : Closed e2408973433306 ∧ code e2408973433306 = 11205066455514 := by decide
theorem cert_e2408973433306 : check e2408973433306 [[],[]] .chain = true := by decide
def e2408973433462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2408973433462 : Closed e2408973433462 ∧ code e2408973433462 = 11205066455670 := by decide
theorem cert_e2408973433462 : check e2408973433462 [[],[]] .chain = true := by decide
def e2408973433654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2408973433654 : Closed e2408973433654 ∧ code e2408973433654 = 11205066455862 := by decide
theorem cert_e2408973433654 : check e2408973433654 [[],[]] .chain = true := by decide
def e2408973433658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2408973433658 : Closed e2408973433658 ∧ code e2408973433658 = 11205066455866 := by decide
theorem cert_e2408973433658 : check e2408973433658 [[],[]] .chain = true := by decide
def e2408973440878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2408973440878 : Closed e2408973440878 ∧ code e2408973440878 = 11205066463086 := by decide
theorem cert_e2408973440878 : check e2408973440878 [[],[]] .chain = true := by decide
def e2408973440886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2408973440886 : Closed e2408973440886 ∧ code e2408973440886 = 11205066463094 := by decide
theorem cert_e2408973440886 : check e2408973440886 [[],[]] .chain = true := by decide
def e2408973440950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2408973440950 : Closed e2408973440950 ∧ code e2408973440950 = 11205066463158 := by decide
theorem cert_e2408973440950 : check e2408973440950 [[],[]] .chain = true := by decide
def e2408973442286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2408973442286 : Closed e2408973442286 ∧ code e2408973442286 = 11205066464494 := by decide
theorem cert_e2408973442286 : check e2408973442286 [[],[]] .chain = true := by decide
def e2408973442294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2408973442294 : Closed e2408973442294 ∧ code e2408973442294 = 11205066464502 := by decide
theorem cert_e2408973442294 : check e2408973442294 [[],[]] .chain = true := by decide
def e2408973442678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2408973442678 : Closed e2408973442678 ∧ code e2408973442678 = 11205066464886 := by decide
theorem cert_e2408973442678 : check e2408973442678 [[],[]] .chain = true := by decide
def e2408973454190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408973454190 : Closed e2408973454190 ∧ code e2408973454190 = 11205066476398 := by decide
theorem cert_e2408973454190 : check e2408973454190 [[],[]] .chain = true := by decide
def e2408973454198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408973454198 : Closed e2408973454198 ∧ code e2408973454198 = 11205066476406 := by decide
theorem cert_e2408973454198 : check e2408973454198 [[],[]] .chain = true := by decide
def e2408973454254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408973454254 : Closed e2408973454254 ∧ code e2408973454254 = 11205066476462 := by decide
theorem cert_e2408973454254 : check e2408973454254 [[],[]] .chain = true := by decide
def e2408973454266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408973454266 : Closed e2408973454266 ∧ code e2408973454266 = 11205066476474 := by decide
theorem cert_e2408973454266 : check e2408973454266 [[],[]] .chain = true := by decide
def e2408973454294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408973454294 : Closed e2408973454294 ∧ code e2408973454294 = 11205066476502 := by decide
theorem cert_e2408973454294 : check e2408973454294 [[],[]] .chain = true := by decide
def e2408973454298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408973454298 : Closed e2408973454298 ∧ code e2408973454298 = 11205066476506 := by decide
theorem cert_e2408973454298 : check e2408973454298 [[],[]] .chain = true := by decide
def e2408973454574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408973454574 : Closed e2408973454574 ∧ code e2408973454574 = 11205066476782 := by decide
theorem cert_e2408973454574 : check e2408973454574 [[],[]] .chain = true := by decide
def e2408973454582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408973454582 : Closed e2408973454582 ∧ code e2408973454582 = 11205066476790 := by decide
theorem cert_e2408973454582 : check e2408973454582 [[],[]] .chain = true := by decide
def e2408973454958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408973454958 : Closed e2408973454958 ∧ code e2408973454958 = 11205066477166 := by decide
theorem cert_e2408973454958 : check e2408973454958 [[],[]] .chain = true := by decide
def e2408973454970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408973454970 : Closed e2408973454970 ∧ code e2408973454970 = 11205066477178 := by decide
theorem cert_e2408973454970 : check e2408973454970 [[],[]] .chain = true := by decide
def e2408973455158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408973455158 : Closed e2408973455158 ∧ code e2408973455158 = 11205066477366 := by decide
theorem cert_e2408973455158 : check e2408973455158 [[],[]] .chain = true := by decide
def e2408973455162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408973455162 : Closed e2408973455162 ∧ code e2408973455162 = 11205066477370 := by decide
theorem cert_e2408973455162 : check e2408973455162 [[],[]] .chain = true := by decide
def e2408973460918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2408973460918 : Closed e2408973460918 ∧ code e2408973460918 = 11205066483126 := by decide
theorem cert_e2408973460918 : check e2408973460918 [[],[]] .chain = true := by decide
def e2408973460950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2408973460950 : Closed e2408973460950 ∧ code e2408973460950 = 11205066483158 := by decide
theorem cert_e2408973460950 : check e2408973460950 [[],[]] .chain = true := by decide
def e2408973460954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2408973460954 : Closed e2408973460954 ∧ code e2408973460954 = 11205066483162 := by decide
theorem cert_e2408973460954 : check e2408973460954 [[],[]] .chain = true := by decide
def e2408973461110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2408973461110 : Closed e2408973461110 ∧ code e2408973461110 = 11205066483318 := by decide
theorem cert_e2408973461110 : check e2408973461110 [[],[]] .chain = true := by decide
def e2408973461302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2408973461302 : Closed e2408973461302 ∧ code e2408973461302 = 11205066483510 := by decide
theorem cert_e2408973461302 : check e2408973461302 [[],[]] .chain = true := by decide
def e2408973461306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2408973461306 : Closed e2408973461306 ∧ code e2408973461306 = 11205066483514 := by decide
theorem cert_e2408973461306 : check e2408973461306 [[],[]] .chain = true := by decide
def e2408973798254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408973798254 : Closed e2408973798254 ∧ code e2408973798254 = 11205066820462 := by decide
theorem cert_e2408973798254 : check e2408973798254 [[],[],[.under]] .smaller = true := by decide
def e2408973798262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408973798262 : Closed e2408973798262 ∧ code e2408973798262 = 11205066820470 := by decide
theorem cert_e2408973798262 : check e2408973798262 [[],[],[.under]] .smaller = true := by decide
def e2408973798318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408973798318 : Closed e2408973798318 ∧ code e2408973798318 = 11205066820526 := by decide
theorem cert_e2408973798318 : check e2408973798318 [[],[],[.under]] .smaller = true := by decide
def e2408973798330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408973798330 : Closed e2408973798330 ∧ code e2408973798330 = 11205066820538 := by decide
theorem cert_e2408973798330 : check e2408973798330 [[],[],[.under]] .smaller = true := by decide
def e2408973798358 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408973798358 : Closed e2408973798358 ∧ code e2408973798358 = 11205066820566 := by decide
theorem cert_e2408973798358 : check e2408973798358 [[],[],[.under]] .smaller = true := by decide
def e2408973798362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408973798362 : Closed e2408973798362 ∧ code e2408973798362 = 11205066820570 := by decide
theorem cert_e2408973798362 : check e2408973798362 [[],[],[.under]] .smaller = true := by decide
def e2408973798638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408973798638 : Closed e2408973798638 ∧ code e2408973798638 = 11205066820846 := by decide
theorem cert_e2408973798638 : check e2408973798638 [[],[],[.under]] .smaller = true := by decide
def e2408973798646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408973798646 : Closed e2408973798646 ∧ code e2408973798646 = 11205066820854 := by decide
theorem cert_e2408973798646 : check e2408973798646 [[],[],[.under]] .smaller = true := by decide
def e2408973799022 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408973799022 : Closed e2408973799022 ∧ code e2408973799022 = 11205066821230 := by decide
theorem cert_e2408973799022 : check e2408973799022 [[],[],[.under]] .smaller = true := by decide
def e2408973799034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408973799034 : Closed e2408973799034 ∧ code e2408973799034 = 11205066821242 := by decide
theorem cert_e2408973799034 : check e2408973799034 [[],[],[.under]] .smaller = true := by decide
def e2408973799222 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408973799222 : Closed e2408973799222 ∧ code e2408973799222 = 11205066821430 := by decide
theorem cert_e2408973799222 : check e2408973799222 [[],[],[.under]] .smaller = true := by decide
def e2408973799226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408973799226 : Closed e2408973799226 ∧ code e2408973799226 = 11205066821434 := by decide
theorem cert_e2408973799226 : check e2408973799226 [[],[],[.under]] .smaller = true := by decide
def e2408990158190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2408990158190 : Closed e2408990158190 ∧ code e2408990158190 = 11205083180398 := by decide
theorem cert_e2408990158190 : check e2408990158190 [[],[]] .chain = true := by decide
def e2408990158198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2408990158198 : Closed e2408990158198 ∧ code e2408990158198 = 11205083180406 := by decide
theorem cert_e2408990158198 : check e2408990158198 [[],[]] .chain = true := by decide
def e2408990158254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2408990158254 : Closed e2408990158254 ∧ code e2408990158254 = 11205083180462 := by decide
theorem cert_e2408990158254 : check e2408990158254 [[],[]] .chain = true := by decide
def e2408990158266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2408990158266 : Closed e2408990158266 ∧ code e2408990158266 = 11205083180474 := by decide
theorem cert_e2408990158266 : check e2408990158266 [[],[]] .chain = true := by decide
def e2408990158294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2408990158294 : Closed e2408990158294 ∧ code e2408990158294 = 11205083180502 := by decide
theorem cert_e2408990158294 : check e2408990158294 [[],[]] .chain = true := by decide
def e2408990158298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2408990158298 : Closed e2408990158298 ∧ code e2408990158298 = 11205083180506 := by decide
theorem cert_e2408990158298 : check e2408990158298 [[],[]] .chain = true := by decide
def e2408990158510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2408990158510 : Closed e2408990158510 ∧ code e2408990158510 = 11205083180718 := by decide
theorem cert_e2408990158510 : check e2408990158510 [[],[]] .chain = true := by decide
def e2408990158522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2408990158522 : Closed e2408990158522 ∧ code e2408990158522 = 11205083180730 := by decide
theorem cert_e2408990158522 : check e2408990158522 [[],[]] .chain = true := by decide
def e2408990158570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2408990158570 : Closed e2408990158570 ∧ code e2408990158570 = 11205083180778 := by decide
theorem cert_e2408990158570 : check e2408990158570 [[],[]] .chain = true := by decide
def e2408990158678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2408990158678 : Closed e2408990158678 ∧ code e2408990158678 = 11205083180886 := by decide
theorem cert_e2408990158678 : check e2408990158678 [[],[]] .chain = true := by decide
def e2408990158682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2408990158682 : Closed e2408990158682 ∧ code e2408990158682 = 11205083180890 := by decide
theorem cert_e2408990158682 : check e2408990158682 [[],[]] .chain = true := by decide
def e2408990158698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2408990158698 : Closed e2408990158698 ∧ code e2408990158698 = 11205083180906 := by decide
theorem cert_e2408990158698 : check e2408990158698 [[],[]] .chain = true := by decide
def e2408990159726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2408990159726 : Closed e2408990159726 ∧ code e2408990159726 = 11205083181934 := by decide
theorem cert_e2408990159726 : check e2408990159726 [[],[]] .chain = true := by decide
def e2408990159734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2408990159734 : Closed e2408990159734 ∧ code e2408990159734 = 11205083181942 := by decide
theorem cert_e2408990159734 : check e2408990159734 [[],[]] .chain = true := by decide
def e2408990159790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2408990159790 : Closed e2408990159790 ∧ code e2408990159790 = 11205083181998 := by decide
theorem cert_e2408990159790 : check e2408990159790 [[],[]] .chain = true := by decide
def e2408990159802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2408990159802 : Closed e2408990159802 ∧ code e2408990159802 = 11205083182010 := by decide
theorem cert_e2408990159802 : check e2408990159802 [[],[]] .chain = true := by decide
def e2408990159830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2408990159830 : Closed e2408990159830 ∧ code e2408990159830 = 11205083182038 := by decide
theorem cert_e2408990159830 : check e2408990159830 [[],[]] .chain = true := by decide
def e2408990159834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2408990159834 : Closed e2408990159834 ∧ code e2408990159834 = 11205083182042 := by decide
theorem cert_e2408990159834 : check e2408990159834 [[],[]] .chain = true := by decide
def e2408990160110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2408990160110 : Closed e2408990160110 ∧ code e2408990160110 = 11205083182318 := by decide
theorem cert_e2408990160110 : check e2408990160110 [[],[]] .chain = true := by decide
def e2408990160118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2408990160118 : Closed e2408990160118 ∧ code e2408990160118 = 11205083182326 := by decide
theorem cert_e2408990160118 : check e2408990160118 [[],[]] .chain = true := by decide
def e2408990160494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2408990160494 : Closed e2408990160494 ∧ code e2408990160494 = 11205083182702 := by decide
theorem cert_e2408990160494 : check e2408990160494 [[],[]] .chain = true := by decide
def e2408990160506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2408990160506 : Closed e2408990160506 ∧ code e2408990160506 = 11205083182714 := by decide
theorem cert_e2408990160506 : check e2408990160506 [[],[]] .chain = true := by decide
def e2408990160694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2408990160694 : Closed e2408990160694 ∧ code e2408990160694 = 11205083182902 := by decide
theorem cert_e2408990160694 : check e2408990160694 [[],[]] .chain = true := by decide
def e2408990160698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2408990160698 : Closed e2408990160698 ∧ code e2408990160698 = 11205083182906 := by decide
theorem cert_e2408990160698 : check e2408990160698 [[],[]] .chain = true := by decide
def e2408990161326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2408990161326 : Closed e2408990161326 ∧ code e2408990161326 = 11205083183534 := by decide
theorem cert_e2408990161326 : check e2408990161326 [[],[]] .chain = true := by decide
def e2408990161338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2408990161338 : Closed e2408990161338 ∧ code e2408990161338 = 11205083183546 := by decide
theorem cert_e2408990161338 : check e2408990161338 [[],[]] .chain = true := by decide
def e2408990161386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2408990161386 : Closed e2408990161386 ∧ code e2408990161386 = 11205083183594 := by decide
theorem cert_e2408990161386 : check e2408990161386 [[],[]] .chain = true := by decide
def e2408990161518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2408990161518 : Closed e2408990161518 ∧ code e2408990161518 = 11205083183726 := by decide
theorem cert_e2408990161518 : check e2408990161518 [[],[]] .chain = true := by decide
def e2408990161530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2408990161530 : Closed e2408990161530 ∧ code e2408990161530 = 11205083183738 := by decide
theorem cert_e2408990161530 : check e2408990161530 [[],[]] .chain = true := by decide
def e2408990161818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2408990161818 : Closed e2408990161818 ∧ code e2408990161818 = 11205083184026 := by decide
theorem cert_e2408990161818 : check e2408990161818 [[],[]] .chain = true := by decide
def e2408990162134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2408990162134 : Closed e2408990162134 ∧ code e2408990162134 = 11205083184342 := by decide
theorem cert_e2408990162134 : check e2408990162134 [[],[]] .chain = true := by decide
def e2408990162138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2408990162138 : Closed e2408990162138 ∧ code e2408990162138 = 11205083184346 := by decide
theorem cert_e2408990162138 : check e2408990162138 [[],[]] .chain = true := by decide
def e2408990162154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2408990162154 : Closed e2408990162154 ∧ code e2408990162154 = 11205083184362 := by decide
theorem cert_e2408990162154 : check e2408990162154 [[],[]] .chain = true := by decide
def e2408990162230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2408990162230 : Closed e2408990162230 ∧ code e2408990162230 = 11205083184438 := by decide
theorem cert_e2408990162230 : check e2408990162230 [[],[]] .chain = true := by decide
def e2408990162234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2408990162234 : Closed e2408990162234 ∧ code e2408990162234 = 11205083184442 := by decide
theorem cert_e2408990162234 : check e2408990162234 [[],[]] .chain = true := by decide
def e2408990162330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2408990162330 : Closed e2408990162330 ∧ code e2408990162330 = 11205083184538 := by decide
theorem cert_e2408990162330 : check e2408990162330 [[],[]] .chain = true := by decide
def e2408990165870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408990165870 : Closed e2408990165870 ∧ code e2408990165870 = 11205083188078 := by decide
theorem cert_e2408990165870 : check e2408990165870 [[],[]] .chain = true := by decide
def e2408990165878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408990165878 : Closed e2408990165878 ∧ code e2408990165878 = 11205083188086 := by decide
theorem cert_e2408990165878 : check e2408990165878 [[],[]] .chain = true := by decide
def e2408990165934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408990165934 : Closed e2408990165934 ∧ code e2408990165934 = 11205083188142 := by decide
theorem cert_e2408990165934 : check e2408990165934 [[],[]] .chain = true := by decide
def e2408990165946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408990165946 : Closed e2408990165946 ∧ code e2408990165946 = 11205083188154 := by decide
theorem cert_e2408990165946 : check e2408990165946 [[],[]] .chain = true := by decide
def e2408990165974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408990165974 : Closed e2408990165974 ∧ code e2408990165974 = 11205083188182 := by decide
theorem cert_e2408990165974 : check e2408990165974 [[],[]] .chain = true := by decide
def e2408990165978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408990165978 : Closed e2408990165978 ∧ code e2408990165978 = 11205083188186 := by decide
theorem cert_e2408990165978 : check e2408990165978 [[],[]] .chain = true := by decide
def e2408990166254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408990166254 : Closed e2408990166254 ∧ code e2408990166254 = 11205083188462 := by decide
theorem cert_e2408990166254 : check e2408990166254 [[],[]] .chain = true := by decide
def e2408990166262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408990166262 : Closed e2408990166262 ∧ code e2408990166262 = 11205083188470 := by decide
theorem cert_e2408990166262 : check e2408990166262 [[],[]] .chain = true := by decide
def e2408990166638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408990166638 : Closed e2408990166638 ∧ code e2408990166638 = 11205083188846 := by decide
theorem cert_e2408990166638 : check e2408990166638 [[],[]] .chain = true := by decide
def e2408990166650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408990166650 : Closed e2408990166650 ∧ code e2408990166650 = 11205083188858 := by decide
theorem cert_e2408990166650 : check e2408990166650 [[],[]] .chain = true := by decide
def e2408990166838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408990166838 : Closed e2408990166838 ∧ code e2408990166838 = 11205083189046 := by decide
theorem cert_e2408990166838 : check e2408990166838 [[],[]] .chain = true := by decide
def e2408990166842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408990166842 : Closed e2408990166842 ∧ code e2408990166842 = 11205083189050 := by decide
theorem cert_e2408990166842 : check e2408990166842 [[],[]] .chain = true := by decide
def e2408990172590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2408990172590 : Closed e2408990172590 ∧ code e2408990172590 = 11205083194798 := by decide
theorem cert_e2408990172590 : check e2408990172590 [[],[]] .chain = true := by decide
def e2408990172602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2408990172602 : Closed e2408990172602 ∧ code e2408990172602 = 11205083194810 := by decide
theorem cert_e2408990172602 : check e2408990172602 [[],[]] .chain = true := by decide
def e2408990172650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2408990172650 : Closed e2408990172650 ∧ code e2408990172650 = 11205083194858 := by decide
theorem cert_e2408990172650 : check e2408990172650 [[],[]] .chain = true := by decide
def e2408990172782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2408990172782 : Closed e2408990172782 ∧ code e2408990172782 = 11205083194990 := by decide
theorem cert_e2408990172782 : check e2408990172782 [[],[]] .chain = true := by decide
def e2408990172794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2408990172794 : Closed e2408990172794 ∧ code e2408990172794 = 11205083195002 := by decide
theorem cert_e2408990172794 : check e2408990172794 [[],[]] .chain = true := by decide
def e2408990173082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2408990173082 : Closed e2408990173082 ∧ code e2408990173082 = 11205083195290 := by decide
theorem cert_e2408990173082 : check e2408990173082 [[],[]] .chain = true := by decide
def e2408990175958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2408990175958 : Closed e2408990175958 ∧ code e2408990175958 = 11205083198166 := by decide
theorem cert_e2408990175958 : check e2408990175958 [[],[]] .chain = true := by decide
def e2408990175962 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2408990175962 : Closed e2408990175962 ∧ code e2408990175962 = 11205083198170 := by decide
theorem cert_e2408990175962 : check e2408990175962 [[],[]] .chain = true := by decide
def e2408990175978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2408990175978 : Closed e2408990175978 ∧ code e2408990175978 = 11205083198186 := by decide
theorem cert_e2408990175978 : check e2408990175978 [[],[]] .chain = true := by decide
def e2408990176054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2408990176054 : Closed e2408990176054 ∧ code e2408990176054 = 11205083198262 := by decide
theorem cert_e2408990176054 : check e2408990176054 [[],[]] .chain = true := by decide
def e2408990176058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2408990176058 : Closed e2408990176058 ∧ code e2408990176058 = 11205083198266 := by decide
theorem cert_e2408990176058 : check e2408990176058 [[],[]] .chain = true := by decide
def e2408990176154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2408990176154 : Closed e2408990176154 ∧ code e2408990176154 = 11205083198362 := by decide
theorem cert_e2408990176154 : check e2408990176154 [[],[]] .chain = true := by decide
def e2408990313326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408990313326 : Closed e2408990313326 ∧ code e2408990313326 = 11205083335534 := by decide
theorem cert_e2408990313326 : check e2408990313326 [[],[]] .chain = true := by decide
def e2408990313334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408990313334 : Closed e2408990313334 ∧ code e2408990313334 = 11205083335542 := by decide
theorem cert_e2408990313334 : check e2408990313334 [[],[]] .chain = true := by decide
def e2408990313390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408990313390 : Closed e2408990313390 ∧ code e2408990313390 = 11205083335598 := by decide
theorem cert_e2408990313390 : check e2408990313390 [[],[]] .chain = true := by decide
def e2408990313402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408990313402 : Closed e2408990313402 ∧ code e2408990313402 = 11205083335610 := by decide
theorem cert_e2408990313402 : check e2408990313402 [[],[]] .chain = true := by decide
def e2408990313430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408990313430 : Closed e2408990313430 ∧ code e2408990313430 = 11205083335638 := by decide
theorem cert_e2408990313430 : check e2408990313430 [[],[]] .chain = true := by decide
def e2408990313434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408990313434 : Closed e2408990313434 ∧ code e2408990313434 = 11205083335642 := by decide
theorem cert_e2408990313434 : check e2408990313434 [[],[]] .chain = true := by decide
def e2408990313710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408990313710 : Closed e2408990313710 ∧ code e2408990313710 = 11205083335918 := by decide
theorem cert_e2408990313710 : check e2408990313710 [[],[]] .chain = true := by decide
def e2408990313718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408990313718 : Closed e2408990313718 ∧ code e2408990313718 = 11205083335926 := by decide
theorem cert_e2408990313718 : check e2408990313718 [[],[]] .chain = true := by decide
def e2408990314094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2408990314094 : Closed e2408990314094 ∧ code e2408990314094 = 11205083336302 := by decide
theorem cert_e2408990314094 : check e2408990314094 [[],[]] .chain = true := by decide
def e2408990314106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2408990314106 : Closed e2408990314106 ∧ code e2408990314106 = 11205083336314 := by decide
theorem cert_e2408990314106 : check e2408990314106 [[],[]] .chain = true := by decide
def e2408990314294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2408990314294 : Closed e2408990314294 ∧ code e2408990314294 = 11205083336502 := by decide
theorem cert_e2408990314294 : check e2408990314294 [[],[]] .chain = true := by decide
def e2408990314298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2408990314298 : Closed e2408990314298 ∧ code e2408990314298 = 11205083336506 := by decide
theorem cert_e2408990314298 : check e2408990314298 [[],[]] .chain = true := by decide
def e2408990903150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408990903150 : Closed e2408990903150 ∧ code e2408990903150 = 11205083925358 := by decide
theorem cert_e2408990903150 : check e2408990903150 [[],[],[],[],[]] .chain = true := by decide
def e2408990903158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408990903158 : Closed e2408990903158 ∧ code e2408990903158 = 11205083925366 := by decide
theorem cert_e2408990903158 : check e2408990903158 [[],[],[],[],[]] .chain = true := by decide
def e2408990903214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408990903214 : Closed e2408990903214 ∧ code e2408990903214 = 11205083925422 := by decide
theorem cert_e2408990903214 : check e2408990903214 [[],[],[],[],[]] .chain = true := by decide
def e2408990903226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408990903226 : Closed e2408990903226 ∧ code e2408990903226 = 11205083925434 := by decide
theorem cert_e2408990903226 : check e2408990903226 [[],[],[],[],[]] .chain = true := by decide
def e2408990903254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408990903254 : Closed e2408990903254 ∧ code e2408990903254 = 11205083925462 := by decide
theorem cert_e2408990903254 : check e2408990903254 [[],[],[],[],[]] .chain = true := by decide
def e2408990903258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408990903258 : Closed e2408990903258 ∧ code e2408990903258 = 11205083925466 := by decide
theorem cert_e2408990903258 : check e2408990903258 [[],[],[],[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2408971613722
#print axioms Blc.Floor43.cert_e2408971621914
#print axioms Blc.Floor43.cert_e2408971622938
#print axioms Blc.Floor43.cert_e2408971662874
#print axioms Blc.Floor43.cert_e2408971712026
#print axioms Blc.Floor43.cert_e2408971713050
