import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862483837802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e862483837802 : Closed e862483837802 ∧ code e862483837802 = 9658576860010 := by decide
theorem cert_e862483837802 : check e862483837802 [] .sourceHead = true := by decide
def e862483837866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e862483837866 : Closed e862483837866 ∧ code e862483837866 = 9658576860074 := by decide
theorem cert_e862483837866 : check e862483837866 [] .sourceHead = true := by decide
def e862483838070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e862483838070 : Closed e862483838070 ∧ code e862483838070 = 9658576860278 := by decide
theorem cert_e862483838070 : check e862483838070 [] .sourceHead = true := by decide
def e862483838166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e862483838166 : Closed e862483838166 ∧ code e862483838166 = 9658576860374 := by decide
theorem cert_e862483838166 : check e862483838166 [] .sourceHead = true := by decide
def e862483838170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e862483838170 : Closed e862483838170 ∧ code e862483838170 = 9658576860378 := by decide
theorem cert_e862483838170 : check e862483838170 [] .sourceHead = true := by decide
def e862483838186 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e862483838186 : Closed e862483838186 ∧ code e862483838186 = 9658576860394 := by decide
theorem cert_e862483838186 : check e862483838186 [] .sourceHead = true := by decide
def e862483838262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483838262 : Closed e862483838262 ∧ code e862483838262 = 9658576860470 := by decide
theorem cert_e862483838262 : check e862483838262 [] .sourceHead = true := by decide
def e862483838266 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483838266 : Closed e862483838266 ∧ code e862483838266 = 9658576860474 := by decide
theorem cert_e862483838266 : check e862483838266 [] .sourceHead = true := by decide
def e862483838350 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e862483838350 : Closed e862483838350 ∧ code e862483838350 = 9658576860558 := by decide
theorem cert_e862483838350 : check e862483838350 [] .sourceHead = true := by decide
def e862483838362 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483838362 : Closed e862483838362 ∧ code e862483838362 = 9658576860570 := by decide
theorem cert_e862483838362 : check e862483838362 [] .sourceHead = true := by decide
def e862483838518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e862483838518 : Closed e862483838518 ∧ code e862483838518 = 9658576860726 := by decide
theorem cert_e862483838518 : check e862483838518 [] .sourceHead = true := by decide
def e862483838522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e862483838522 : Closed e862483838522 ∧ code e862483838522 = 9658576860730 := by decide
theorem cert_e862483838522 : check e862483838522 [] .sourceHead = true := by decide
def e862483838570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e862483838570 : Closed e862483838570 ∧ code e862483838570 = 9658576860778 := by decide
theorem cert_e862483838570 : check e862483838570 [] .sourceHead = true := by decide
def e862483838606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e862483838606 : Closed e862483838606 ∧ code e862483838606 = 9658576860814 := by decide
theorem cert_e862483838606 : check e862483838606 [] .sourceHead = true := by decide
def e862483838618 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483838618 : Closed e862483838618 ∧ code e862483838618 = 9658576860826 := by decide
theorem cert_e862483838618 : check e862483838618 [] .sourceHead = true := by decide
def e862483838662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e862483838662 : Closed e862483838662 ∧ code e862483838662 = 9658576860870 := by decide
theorem cert_e862483838662 : check e862483838662 [] .sourceHead = true := by decide
def e862483844846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e862483844846 : Closed e862483844846 ∧ code e862483844846 = 9658576867054 := by decide
theorem cert_e862483844846 : check e862483844846 [] .sourceHead = true := by decide
def e862483844854 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e862483844854 : Closed e862483844854 ∧ code e862483844854 = 9658576867062 := by decide
theorem cert_e862483844854 : check e862483844854 [] .sourceHead = true := by decide
def e862483844974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e862483844974 : Closed e862483844974 ∧ code e862483844974 = 9658576867182 := by decide
theorem cert_e862483844974 : check e862483844974 [] .sourceHead = true := by decide
def e862483844986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e862483844986 : Closed e862483844986 ∧ code e862483844986 = 9658576867194 := by decide
theorem cert_e862483844986 : check e862483844986 [] .sourceHead = true := by decide
def e862483845046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e862483845046 : Closed e862483845046 ∧ code e862483845046 = 9658576867254 := by decide
theorem cert_e862483845046 : check e862483845046 [] .sourceHead = true := by decide
def e862483845050 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e862483845050 : Closed e862483845050 ∧ code e862483845050 = 9658576867258 := by decide
theorem cert_e862483845050 : check e862483845050 [] .sourceHead = true := by decide
def e862483848430 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))))
theorem wire_e862483848430 : Closed e862483848430 ∧ code e862483848430 = 9658576870638 := by decide
theorem cert_e862483848430 : check e862483848430 [] .sourceHead = true := by decide
def e862483848438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))))
theorem wire_e862483848438 : Closed e862483848438 ∧ code e862483848438 = 9658576870646 := by decide
theorem cert_e862483848438 : check e862483848438 [] .sourceHead = true := by decide
def e862483848822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))))
theorem wire_e862483848822 : Closed e862483848822 ∧ code e862483848822 = 9658576871030 := by decide
theorem cert_e862483848822 : check e862483848822 [] .sourceHead = true := by decide
def e862483852654 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e862483852654 : Closed e862483852654 ∧ code e862483852654 = 9658576874862 := by decide
theorem cert_e862483852654 : check e862483852654 [] .sourceHead = true := by decide
def e862483852662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e862483852662 : Closed e862483852662 ∧ code e862483852662 = 9658576874870 := by decide
theorem cert_e862483852662 : check e862483852662 [] .sourceHead = true := by decide
def e862483852718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e862483852718 : Closed e862483852718 ∧ code e862483852718 = 9658576874926 := by decide
theorem cert_e862483852718 : check e862483852718 [] .sourceHead = true := by decide
def e862483852730 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e862483852730 : Closed e862483852730 ∧ code e862483852730 = 9658576874938 := by decide
theorem cert_e862483852730 : check e862483852730 [] .sourceHead = true := by decide
def e862483852758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e862483852758 : Closed e862483852758 ∧ code e862483852758 = 9658576874966 := by decide
theorem cert_e862483852758 : check e862483852758 [] .sourceHead = true := by decide
def e862483852762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e862483852762 : Closed e862483852762 ∧ code e862483852762 = 9658576874970 := by decide
theorem cert_e862483852762 : check e862483852762 [] .sourceHead = true := by decide
def e862483852974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e862483852974 : Closed e862483852974 ∧ code e862483852974 = 9658576875182 := by decide
theorem cert_e862483852974 : check e862483852974 [] .sourceHead = true := by decide
def e862483852986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e862483852986 : Closed e862483852986 ∧ code e862483852986 = 9658576875194 := by decide
theorem cert_e862483852986 : check e862483852986 [] .sourceHead = true := by decide
def e862483853034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e862483853034 : Closed e862483853034 ∧ code e862483853034 = 9658576875242 := by decide
theorem cert_e862483853034 : check e862483853034 [] .sourceHead = true := by decide
def e862483853142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e862483853142 : Closed e862483853142 ∧ code e862483853142 = 9658576875350 := by decide
theorem cert_e862483853142 : check e862483853142 [] .sourceHead = true := by decide
def e862483853146 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e862483853146 : Closed e862483853146 ∧ code e862483853146 = 9658576875354 := by decide
theorem cert_e862483853146 : check e862483853146 [] .sourceHead = true := by decide
def e862483853162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e862483853162 : Closed e862483853162 ∧ code e862483853162 = 9658576875370 := by decide
theorem cert_e862483853162 : check e862483853162 [] .sourceHead = true := by decide
def e862483854190 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e862483854190 : Closed e862483854190 ∧ code e862483854190 = 9658576876398 := by decide
theorem cert_e862483854190 : check e862483854190 [] .sourceHead = true := by decide
def e862483854198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e862483854198 : Closed e862483854198 ∧ code e862483854198 = 9658576876406 := by decide
theorem cert_e862483854198 : check e862483854198 [] .sourceHead = true := by decide
def e862483854254 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e862483854254 : Closed e862483854254 ∧ code e862483854254 = 9658576876462 := by decide
theorem cert_e862483854254 : check e862483854254 [] .sourceHead = true := by decide
def e862483854266 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e862483854266 : Closed e862483854266 ∧ code e862483854266 = 9658576876474 := by decide
theorem cert_e862483854266 : check e862483854266 [] .sourceHead = true := by decide
def e862483854294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e862483854294 : Closed e862483854294 ∧ code e862483854294 = 9658576876502 := by decide
theorem cert_e862483854294 : check e862483854294 [] .sourceHead = true := by decide
def e862483854298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e862483854298 : Closed e862483854298 ∧ code e862483854298 = 9658576876506 := by decide
theorem cert_e862483854298 : check e862483854298 [] .sourceHead = true := by decide
def e862483854574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e862483854574 : Closed e862483854574 ∧ code e862483854574 = 9658576876782 := by decide
theorem cert_e862483854574 : check e862483854574 [] .sourceHead = true := by decide
def e862483854582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e862483854582 : Closed e862483854582 ∧ code e862483854582 = 9658576876790 := by decide
theorem cert_e862483854582 : check e862483854582 [] .sourceHead = true := by decide
def e862483854958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e862483854958 : Closed e862483854958 ∧ code e862483854958 = 9658576877166 := by decide
theorem cert_e862483854958 : check e862483854958 [] .sourceHead = true := by decide
def e862483854970 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e862483854970 : Closed e862483854970 ∧ code e862483854970 = 9658576877178 := by decide
theorem cert_e862483854970 : check e862483854970 [] .sourceHead = true := by decide
def e862483855158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483855158 : Closed e862483855158 ∧ code e862483855158 = 9658576877366 := by decide
theorem cert_e862483855158 : check e862483855158 [] .sourceHead = true := by decide
def e862483855162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483855162 : Closed e862483855162 ∧ code e862483855162 = 9658576877370 := by decide
theorem cert_e862483855162 : check e862483855162 [] .sourceHead = true := by decide
def e862483855598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e862483855598 : Closed e862483855598 ∧ code e862483855598 = 9658576877806 := by decide
theorem cert_e862483855598 : check e862483855598 [] .sourceHead = true := by decide
def e862483855606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e862483855606 : Closed e862483855606 ∧ code e862483855606 = 9658576877814 := by decide
theorem cert_e862483855606 : check e862483855606 [] .sourceHead = true := by decide
def e862483855790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e862483855790 : Closed e862483855790 ∧ code e862483855790 = 9658576877998 := by decide
theorem cert_e862483855790 : check e862483855790 [] .sourceHead = true := by decide
def e862483855802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e862483855802 : Closed e862483855802 ∧ code e862483855802 = 9658576878010 := by decide
theorem cert_e862483855802 : check e862483855802 [] .sourceHead = true := by decide
def e862483855850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e862483855850 : Closed e862483855850 ∧ code e862483855850 = 9658576878058 := by decide
theorem cert_e862483855850 : check e862483855850 [] .sourceHead = true := by decide
def e862483855982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e862483855982 : Closed e862483855982 ∧ code e862483855982 = 9658576878190 := by decide
theorem cert_e862483855982 : check e862483855982 [] .sourceHead = true := by decide
def e862483855994 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e862483855994 : Closed e862483855994 ∧ code e862483855994 = 9658576878202 := by decide
theorem cert_e862483855994 : check e862483855994 [] .sourceHead = true := by decide
def e862483856158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e862483856158 : Closed e862483856158 ∧ code e862483856158 = 9658576878366 := by decide
theorem cert_e862483856158 : check e862483856158 [] .sourceHead = true := by decide
def e862483856270 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e862483856270 : Closed e862483856270 ∧ code e862483856270 = 9658576878478 := by decide
theorem cert_e862483856270 : check e862483856270 [] .sourceHead = true := by decide
def e862483856282 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483856282 : Closed e862483856282 ∧ code e862483856282 = 9658576878490 := by decide
theorem cert_e862483856282 : check e862483856282 [] .sourceHead = true := by decide
def e862483856502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e862483856502 : Closed e862483856502 ∧ code e862483856502 = 9658576878710 := by decide
theorem cert_e862483856502 : check e862483856502 [] .sourceHead = true := by decide
def e862483856598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e862483856598 : Closed e862483856598 ∧ code e862483856598 = 9658576878806 := by decide
theorem cert_e862483856598 : check e862483856598 [] .sourceHead = true := by decide
def e862483856602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e862483856602 : Closed e862483856602 ∧ code e862483856602 = 9658576878810 := by decide
theorem cert_e862483856602 : check e862483856602 [] .sourceHead = true := by decide
def e862483856618 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e862483856618 : Closed e862483856618 ∧ code e862483856618 = 9658576878826 := by decide
theorem cert_e862483856618 : check e862483856618 [] .sourceHead = true := by decide
def e862483856694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483856694 : Closed e862483856694 ∧ code e862483856694 = 9658576878902 := by decide
theorem cert_e862483856694 : check e862483856694 [] .sourceHead = true := by decide
def e862483856698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483856698 : Closed e862483856698 ∧ code e862483856698 = 9658576878906 := by decide
theorem cert_e862483856698 : check e862483856698 [] .sourceHead = true := by decide
def e862483856782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e862483856782 : Closed e862483856782 ∧ code e862483856782 = 9658576878990 := by decide
theorem cert_e862483856782 : check e862483856782 [] .sourceHead = true := by decide
def e862483856794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483856794 : Closed e862483856794 ∧ code e862483856794 = 9658576879002 := by decide
theorem cert_e862483856794 : check e862483856794 [] .sourceHead = true := by decide
def e862483858398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e862483858398 : Closed e862483858398 ∧ code e862483858398 = 9658576880606 := by decide
theorem cert_e862483858398 : check e862483858398 [] .sourceHead = true := by decide
def e862483858414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e862483858414 : Closed e862483858414 ∧ code e862483858414 = 9658576880622 := by decide
theorem cert_e862483858414 : check e862483858414 [] .sourceHead = true := by decide
def e862483860334 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862483860334 : Closed e862483860334 ∧ code e862483860334 = 9658576882542 := by decide
theorem cert_e862483860334 : check e862483860334 [] .sourceHead = true := by decide
def e862483860342 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862483860342 : Closed e862483860342 ∧ code e862483860342 = 9658576882550 := by decide
theorem cert_e862483860342 : check e862483860342 [] .sourceHead = true := by decide
def e862483860398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862483860398 : Closed e862483860398 ∧ code e862483860398 = 9658576882606 := by decide
theorem cert_e862483860398 : check e862483860398 [] .sourceHead = true := by decide
def e862483860410 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862483860410 : Closed e862483860410 ∧ code e862483860410 = 9658576882618 := by decide
theorem cert_e862483860410 : check e862483860410 [] .sourceHead = true := by decide
def e862483860438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862483860438 : Closed e862483860438 ∧ code e862483860438 = 9658576882646 := by decide
theorem cert_e862483860438 : check e862483860438 [] .sourceHead = true := by decide
def e862483860442 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862483860442 : Closed e862483860442 ∧ code e862483860442 = 9658576882650 := by decide
theorem cert_e862483860442 : check e862483860442 [] .sourceHead = true := by decide
def e862483860718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862483860718 : Closed e862483860718 ∧ code e862483860718 = 9658576882926 := by decide
theorem cert_e862483860718 : check e862483860718 [] .sourceHead = true := by decide
def e862483860726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862483860726 : Closed e862483860726 ∧ code e862483860726 = 9658576882934 := by decide
theorem cert_e862483860726 : check e862483860726 [] .sourceHead = true := by decide
def e862483861102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483861102 : Closed e862483861102 ∧ code e862483861102 = 9658576883310 := by decide
theorem cert_e862483861102 : check e862483861102 [] .sourceHead = true := by decide
def e862483861114 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483861114 : Closed e862483861114 ∧ code e862483861114 = 9658576883322 := by decide
theorem cert_e862483861114 : check e862483861114 [] .sourceHead = true := by decide
def e862483861302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483861302 : Closed e862483861302 ∧ code e862483861302 = 9658576883510 := by decide
theorem cert_e862483861302 : check e862483861302 [] .sourceHead = true := by decide
def e862483861306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483861306 : Closed e862483861306 ∧ code e862483861306 = 9658576883514 := by decide
theorem cert_e862483861306 : check e862483861306 [] .sourceHead = true := by decide
def e862483866078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e862483866078 : Closed e862483866078 ∧ code e862483866078 = 9658576888286 := by decide
theorem cert_e862483866078 : check e862483866078 [] .sourceHead = true := by decide
def e862483866102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e862483866102 : Closed e862483866102 ∧ code e862483866102 = 9658576888310 := by decide
theorem cert_e862483866102 : check e862483866102 [] .sourceHead = true := by decide
def e862483867054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e862483867054 : Closed e862483867054 ∧ code e862483867054 = 9658576889262 := by decide
theorem cert_e862483867054 : check e862483867054 [] .sourceHead = true := by decide
def e862483867066 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e862483867066 : Closed e862483867066 ∧ code e862483867066 = 9658576889274 := by decide
theorem cert_e862483867066 : check e862483867066 [] .sourceHead = true := by decide
def e862483867114 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e862483867114 : Closed e862483867114 ∧ code e862483867114 = 9658576889322 := by decide
theorem cert_e862483867114 : check e862483867114 [] .sourceHead = true := by decide
def e862483867246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483867246 : Closed e862483867246 ∧ code e862483867246 = 9658576889454 := by decide
theorem cert_e862483867246 : check e862483867246 [] .sourceHead = true := by decide
def e862483867258 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483867258 : Closed e862483867258 ∧ code e862483867258 = 9658576889466 := by decide
theorem cert_e862483867258 : check e862483867258 [] .sourceHead = true := by decide
def e862483867422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e862483867422 : Closed e862483867422 ∧ code e862483867422 = 9658576889630 := by decide
theorem cert_e862483867422 : check e862483867422 [] .sourceHead = true := by decide
def e862483867534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e862483867534 : Closed e862483867534 ∧ code e862483867534 = 9658576889742 := by decide
theorem cert_e862483867534 : check e862483867534 [] .sourceHead = true := by decide
def e862483867546 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483867546 : Closed e862483867546 ∧ code e862483867546 = 9658576889754 := by decide
theorem cert_e862483867546 : check e862483867546 [] .sourceHead = true := by decide
def e862483869934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e862483869934 : Closed e862483869934 ∧ code e862483869934 = 9658576892142 := by decide
theorem cert_e862483869934 : check e862483869934 [] .sourceHead = true := by decide
def e862483869942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e862483869942 : Closed e862483869942 ∧ code e862483869942 = 9658576892150 := by decide
theorem cert_e862483869942 : check e862483869942 [] .sourceHead = true := by decide
def e862483870422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e862483870422 : Closed e862483870422 ∧ code e862483870422 = 9658576892630 := by decide
theorem cert_e862483870422 : check e862483870422 [] .sourceHead = true := by decide
def e862483870426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e862483870426 : Closed e862483870426 ∧ code e862483870426 = 9658576892634 := by decide
theorem cert_e862483870426 : check e862483870426 [] .sourceHead = true := by decide
def e862483870442 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e862483870442 : Closed e862483870442 ∧ code e862483870442 = 9658576892650 := by decide
theorem cert_e862483870442 : check e862483870442 [] .sourceHead = true := by decide
def e862483870518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483870518 : Closed e862483870518 ∧ code e862483870518 = 9658576892726 := by decide
theorem cert_e862483870518 : check e862483870518 [] .sourceHead = true := by decide
def e862483870522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483870522 : Closed e862483870522 ∧ code e862483870522 = 9658576892730 := by decide
theorem cert_e862483870522 : check e862483870522 [] .sourceHead = true := by decide
def e862483870606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e862483870606 : Closed e862483870606 ∧ code e862483870606 = 9658576892814 := by decide
theorem cert_e862483870606 : check e862483870606 [] .sourceHead = true := by decide
def e862483870618 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483870618 : Closed e862483870618 ∧ code e862483870618 = 9658576892826 := by decide
theorem cert_e862483870618 : check e862483870618 [] .sourceHead = true := by decide
def e862483875694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e862483875694 : Closed e862483875694 ∧ code e862483875694 = 9658576897902 := by decide
theorem cert_e862483875694 : check e862483875694 [] .sourceHead = true := by decide
def e862483875706 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e862483875706 : Closed e862483875706 ∧ code e862483875706 = 9658576897914 := by decide
theorem cert_e862483875706 : check e862483875706 [] .sourceHead = true := by decide
def e862483875802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e862483875802 : Closed e862483875802 ∧ code e862483875802 = 9658576898010 := by decide
theorem cert_e862483875802 : check e862483875802 [] .sourceHead = true := by decide
def e862483877102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e862483877102 : Closed e862483877102 ∧ code e862483877102 = 9658576899310 := by decide
theorem cert_e862483877102 : check e862483877102 [] .sourceHead = true := by decide
def e862483877110 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e862483877110 : Closed e862483877110 ∧ code e862483877110 = 9658576899318 := by decide
theorem cert_e862483877110 : check e862483877110 [] .sourceHead = true := by decide
def e862483877486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e862483877486 : Closed e862483877486 ∧ code e862483877486 = 9658576899694 := by decide
theorem cert_e862483877486 : check e862483877486 [] .sourceHead = true := by decide
def e862483877498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e862483877498 : Closed e862483877498 ∧ code e862483877498 = 9658576899706 := by decide
theorem cert_e862483877498 : check e862483877498 [] .sourceHead = true := by decide
def e862483877686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483877686 : Closed e862483877686 ∧ code e862483877686 = 9658576899894 := by decide
theorem cert_e862483877686 : check e862483877686 [] .sourceHead = true := by decide
def e862483877690 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483877690 : Closed e862483877690 ∧ code e862483877690 = 9658576899898 := by decide
theorem cert_e862483877690 : check e862483877690 [] .sourceHead = true := by decide
def e862483879598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e862483879598 : Closed e862483879598 ∧ code e862483879598 = 9658576901806 := by decide
theorem cert_e862483879598 : check e862483879598 [] .sourceHead = true := by decide
def e862483879610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e862483879610 : Closed e862483879610 ∧ code e862483879610 = 9658576901818 := by decide
theorem cert_e862483879610 : check e862483879610 [] .sourceHead = true := by decide
def e862483879658 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e862483879658 : Closed e862483879658 ∧ code e862483879658 = 9658576901866 := by decide
theorem cert_e862483879658 : check e862483879658 [] .sourceHead = true := by decide
def e862483879850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e862483879850 : Closed e862483879850 ∧ code e862483879850 = 9658576902058 := by decide
theorem cert_e862483879850 : check e862483879850 [] .sourceHead = true := by decide
def e862483880174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e862483880174 : Closed e862483880174 ∧ code e862483880174 = 9658576902382 := by decide
theorem cert_e862483880174 : check e862483880174 [] .sourceHead = true := by decide
def e862483880182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e862483880182 : Closed e862483880182 ∧ code e862483880182 = 9658576902390 := by decide
theorem cert_e862483880182 : check e862483880182 [] .sourceHead = true := by decide
def e862483880366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e862483880366 : Closed e862483880366 ∧ code e862483880366 = 9658576902574 := by decide
theorem cert_e862483880366 : check e862483880366 [] .sourceHead = true := by decide
def e862483880378 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e862483880378 : Closed e862483880378 ∧ code e862483880378 = 9658576902586 := by decide
theorem cert_e862483880378 : check e862483880378 [] .sourceHead = true := by decide
def e862483880426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e862483880426 : Closed e862483880426 ∧ code e862483880426 = 9658576902634 := by decide
theorem cert_e862483880426 : check e862483880426 [] .sourceHead = true := by decide
def e862483880558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e862483880558 : Closed e862483880558 ∧ code e862483880558 = 9658576902766 := by decide
theorem cert_e862483880558 : check e862483880558 [] .sourceHead = true := by decide
def e862483880570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e862483880570 : Closed e862483880570 ∧ code e862483880570 = 9658576902778 := by decide
theorem cert_e862483880570 : check e862483880570 [] .sourceHead = true := by decide
def e862483880734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e862483880734 : Closed e862483880734 ∧ code e862483880734 = 9658576902942 := by decide
theorem cert_e862483880734 : check e862483880734 [] .sourceHead = true := by decide
def e862483880846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e862483880846 : Closed e862483880846 ∧ code e862483880846 = 9658576903054 := by decide
theorem cert_e862483880846 : check e862483880846 [] .sourceHead = true := by decide
def e862483880858 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483880858 : Closed e862483880858 ∧ code e862483880858 = 9658576903066 := by decide
theorem cert_e862483880858 : check e862483880858 [] .sourceHead = true := by decide
def e862483881070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e862483881070 : Closed e862483881070 ∧ code e862483881070 = 9658576903278 := by decide
theorem cert_e862483881070 : check e862483881070 [] .sourceHead = true := by decide
def e862483881082 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e862483881082 : Closed e862483881082 ∧ code e862483881082 = 9658576903290 := by decide
theorem cert_e862483881082 : check e862483881082 [] .sourceHead = true := by decide
def e862483881246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e862483881246 : Closed e862483881246 ∧ code e862483881246 = 9658576903454 := by decide
theorem cert_e862483881246 : check e862483881246 [] .sourceHead = true := by decide
def e862483881414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e862483881414 : Closed e862483881414 ∧ code e862483881414 = 9658576903622 := by decide
theorem cert_e862483881414 : check e862483881414 [] .sourceHead = true := by decide
def e862483881526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e862483881526 : Closed e862483881526 ∧ code e862483881526 = 9658576903734 := by decide
theorem cert_e862483881526 : check e862483881526 [] .sourceHead = true := by decide
def e862483881530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e862483881530 : Closed e862483881530 ∧ code e862483881530 = 9658576903738 := by decide
theorem cert_e862483881530 : check e862483881530 [] .sourceHead = true := by decide
def e862483881578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e862483881578 : Closed e862483881578 ∧ code e862483881578 = 9658576903786 := by decide
theorem cert_e862483881578 : check e862483881578 [] .sourceHead = true := by decide
def e862483881614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e862483881614 : Closed e862483881614 ∧ code e862483881614 = 9658576903822 := by decide
theorem cert_e862483881614 : check e862483881614 [] .sourceHead = true := by decide
def e862483881626 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483881626 : Closed e862483881626 ∧ code e862483881626 = 9658576903834 := by decide
theorem cert_e862483881626 : check e862483881626 [] .sourceHead = true := by decide
def e862483881670 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e862483881670 : Closed e862483881670 ∧ code e862483881670 = 9658576903878 := by decide
theorem cert_e862483881670 : check e862483881670 [] .sourceHead = true := by decide
def e862483882462 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e862483882462 : Closed e862483882462 ∧ code e862483882462 = 9658576904670 := by decide
theorem cert_e862483882462 : check e862483882462 [] .sourceHead = true := by decide
def e862483882486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e862483882486 : Closed e862483882486 ∧ code e862483882486 = 9658576904694 := by decide
theorem cert_e862483882486 : check e862483882486 [] .sourceHead = true := by decide
def e862483883438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e862483883438 : Closed e862483883438 ∧ code e862483883438 = 9658576905646 := by decide
theorem cert_e862483883438 : check e862483883438 [] .sourceHead = true := by decide
def e862483883450 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e862483883450 : Closed e862483883450 ∧ code e862483883450 = 9658576905658 := by decide
theorem cert_e862483883450 : check e862483883450 [] .sourceHead = true := by decide
def e862483883498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e862483883498 : Closed e862483883498 ∧ code e862483883498 = 9658576905706 := by decide
theorem cert_e862483883498 : check e862483883498 [] .sourceHead = true := by decide
def e862483883630 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483883630 : Closed e862483883630 ∧ code e862483883630 = 9658576905838 := by decide
theorem cert_e862483883630 : check e862483883630 [] .sourceHead = true := by decide
def e862483883642 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483883642 : Closed e862483883642 ∧ code e862483883642 = 9658576905850 := by decide
theorem cert_e862483883642 : check e862483883642 [] .sourceHead = true := by decide
def e862483883806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e862483883806 : Closed e862483883806 ∧ code e862483883806 = 9658576906014 := by decide
theorem cert_e862483883806 : check e862483883806 [] .sourceHead = true := by decide
def e862483883918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e862483883918 : Closed e862483883918 ∧ code e862483883918 = 9658576906126 := by decide
theorem cert_e862483883918 : check e862483883918 [] .sourceHead = true := by decide
def e862483883930 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483883930 : Closed e862483883930 ∧ code e862483883930 = 9658576906138 := by decide
theorem cert_e862483883930 : check e862483883930 [] .sourceHead = true := by decide
def e862483886878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e862483886878 : Closed e862483886878 ∧ code e862483886878 = 9658576909086 := by decide
theorem cert_e862483886878 : check e862483886878 [] .sourceHead = true := by decide
def e862483887046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e862483887046 : Closed e862483887046 ∧ code e862483887046 = 9658576909254 := by decide
theorem cert_e862483887046 : check e862483887046 [] .sourceHead = true := by decide
def e862483888246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e862483888246 : Closed e862483888246 ∧ code e862483888246 = 9658576910454 := by decide
theorem cert_e862483888246 : check e862483888246 [] .sourceHead = true := by decide
def e862483888490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e862483888490 : Closed e862483888490 ∧ code e862483888490 = 9658576910698 := by decide
theorem cert_e862483888490 : check e862483888490 [] .sourceHead = true := by decide
def e862483888526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e862483888526 : Closed e862483888526 ∧ code e862483888526 = 9658576910734 := by decide
theorem cert_e862483888526 : check e862483888526 [] .sourceHead = true := by decide
def e862483888538 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483888538 : Closed e862483888538 ∧ code e862483888538 = 9658576910746 := by decide
theorem cert_e862483888538 : check e862483888538 [] .sourceHead = true := by decide
def e862483888582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e862483888582 : Closed e862483888582 ∧ code e862483888582 = 9658576910790 := by decide
theorem cert_e862483888582 : check e862483888582 [] .sourceHead = true := by decide
def e862483891126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e862483891126 : Closed e862483891126 ∧ code e862483891126 = 9658576913334 := by decide
theorem cert_e862483891126 : check e862483891126 [] .sourceHead = true := by decide
def e862483891130 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e862483891130 : Closed e862483891130 ∧ code e862483891130 = 9658576913338 := by decide
theorem cert_e862483891130 : check e862483891130 [] .sourceHead = true := by decide
def e862483891162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e862483891162 : Closed e862483891162 ∧ code e862483891162 = 9658576913370 := by decide
theorem cert_e862483891162 : check e862483891162 [] .sourceHead = true := by decide
def e862483891830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e862483891830 : Closed e862483891830 ∧ code e862483891830 = 9658576914038 := by decide
theorem cert_e862483891830 : check e862483891830 [] .sourceHead = true := by decide
def e862483892022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483892022 : Closed e862483892022 ∧ code e862483892022 = 9658576914230 := by decide
theorem cert_e862483892022 : check e862483892022 [] .sourceHead = true := by decide
def e862483892026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483892026 : Closed e862483892026 ∧ code e862483892026 = 9658576914234 := by decide
theorem cert_e862483892026 : check e862483892026 [] .sourceHead = true := by decide
def e862483893078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e862483893078 : Closed e862483893078 ∧ code e862483893078 = 9658576915286 := by decide
theorem cert_e862483893078 : check e862483893078 [] .sourceHead = true := by decide
def e862483893082 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e862483893082 : Closed e862483893082 ∧ code e862483893082 = 9658576915290 := by decide
theorem cert_e862483893082 : check e862483893082 [] .sourceHead = true := by decide
def e862483893098 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e862483893098 : Closed e862483893098 ∧ code e862483893098 = 9658576915306 := by decide
theorem cert_e862483893098 : check e862483893098 [] .sourceHead = true := by decide
def e862483893162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e862483893162 : Closed e862483893162 ∧ code e862483893162 = 9658576915370 := by decide
theorem cert_e862483893162 : check e862483893162 [] .sourceHead = true := by decide
end Blc.Floor43
