import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405934269858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405934269858 : Closed e2405934269858 ∧ code e2405934269858 = 11202027292066 := by decide
theorem cert_e2405934269858 : check e2405934269858 [[]] .width = true := by decide
def e2405934269966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405934269966 : Closed e2405934269966 ∧ code e2405934269966 = 11202027292174 := by decide
theorem cert_e2405934269966 : check e2405934269966 [[]] .width = true := by decide
def e2405934269978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405934269978 : Closed e2405934269978 ∧ code e2405934269978 = 11202027292186 := by decide
theorem cert_e2405934269978 : check e2405934269978 [[]] .width = true := by decide
def e2405934270050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405934270050 : Closed e2405934270050 ∧ code e2405934270050 = 11202027292258 := by decide
theorem cert_e2405934270050 : check e2405934270050 [[]] .width = true := by decide
def e2405934330054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405934330054 : Closed e2405934330054 ∧ code e2405934330054 = 11202027352262 := by decide
theorem cert_e2405934330054 : check e2405934330054 [[]] .width = true := by decide
def e2405934356506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405934356506 : Closed e2405934356506 ∧ code e2405934356506 = 11202027378714 := by decide
theorem cert_e2405934356506 : check e2405934356506 [[]] .width = true := by decide
def e2405934360602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405934360602 : Closed e2405934360602 ∧ code e2405934360602 = 11202027382810 := by decide
theorem cert_e2405934360602 : check e2405934360602 [[]] .width = true := by decide
def e2405934362138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405934362138 : Closed e2405934362138 ∧ code e2405934362138 = 11202027384346 := by decide
theorem cert_e2405934362138 : check e2405934362138 [[]] .width = true := by decide
def e2405934364186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405934364186 : Closed e2405934364186 ∧ code e2405934364186 = 11202027386394 := by decide
theorem cert_e2405934364186 : check e2405934364186 [[]] .width = true := by decide
def e2405934399514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405934399514 : Closed e2405934399514 ∧ code e2405934399514 = 11202027421722 := by decide
theorem cert_e2405934399514 : check e2405934399514 [[]] .width = true := by decide
def e2405934399606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405934399606 : Closed e2405934399606 ∧ code e2405934399606 = 11202027421814 := by decide
theorem cert_e2405934399606 : check e2405934399606 [[]] .width = true := by decide
def e2405934399850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405934399850 : Closed e2405934399850 ∧ code e2405934399850 = 11202027422058 := by decide
theorem cert_e2405934399850 : check e2405934399850 [[]] .width = true := by decide
def e2405934399898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405934399898 : Closed e2405934399898 ∧ code e2405934399898 = 11202027422106 := by decide
theorem cert_e2405934399898 : check e2405934399898 [[]] .width = true := by decide
def e2405934400906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405934400906 : Closed e2405934400906 ∧ code e2405934400906 = 11202027423114 := by decide
theorem cert_e2405934400906 : check e2405934400906 [[]] .width = true := by decide
def e2405934400930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405934400930 : Closed e2405934400930 ∧ code e2405934400930 = 11202027423138 := by decide
theorem cert_e2405934400930 : check e2405934400930 [[]] .width = true := by decide
def e2405934401038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405934401038 : Closed e2405934401038 ∧ code e2405934401038 = 11202027423246 := by decide
theorem cert_e2405934401038 : check e2405934401038 [[]] .width = true := by decide
def e2405934401050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405934401050 : Closed e2405934401050 ∧ code e2405934401050 = 11202027423258 := by decide
theorem cert_e2405934401050 : check e2405934401050 [[]] .width = true := by decide
def e2405934401122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405934401122 : Closed e2405934401122 ∧ code e2405934401122 = 11202027423330 := by decide
theorem cert_e2405934401122 : check e2405934401122 [[]] .width = true := by decide
def e2405934610458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405934610458 : Closed e2405934610458 ∧ code e2405934610458 = 11202027632666 := by decide
theorem cert_e2405934610458 : check e2405934610458 [[]] .width = true := by decide
def e2405934751770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405934751770 : Closed e2405934751770 ∧ code e2405934751770 = 11202027773978 := by decide
theorem cert_e2405934751770 : check e2405934751770 [[]] .width = true := by decide
def e2405934751862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405934751862 : Closed e2405934751862 ∧ code e2405934751862 = 11202027774070 := by decide
theorem cert_e2405934751862 : check e2405934751862 [[]] .width = true := by decide
def e2405934752106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405934752106 : Closed e2405934752106 ∧ code e2405934752106 = 11202027774314 := by decide
theorem cert_e2405934752106 : check e2405934752106 [[]] .width = true := by decide
def e2405934752154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405934752154 : Closed e2405934752154 ∧ code e2405934752154 = 11202027774362 := by decide
theorem cert_e2405934752154 : check e2405934752154 [[]] .width = true := by decide
def e2405934788806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405934788806 : Closed e2405934788806 ∧ code e2405934788806 = 11202027811014 := by decide
theorem cert_e2405934788806 : check e2405934788806 [[]] .width = true := by decide
def e2405934807066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405934807066 : Closed e2405934807066 ∧ code e2405934807066 = 11202027829274 := by decide
theorem cert_e2405934807066 : check e2405934807066 [[]] .width = true := by decide
def e2405934813382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405934813382 : Closed e2405934813382 ∧ code e2405934813382 = 11202027835590 := by decide
theorem cert_e2405934813382 : check e2405934813382 [[]] .width = true := by decide
def e2405935003674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935003674 : Closed e2405935003674 ∧ code e2405935003674 = 11202028025882 := by decide
theorem cert_e2405935003674 : check e2405935003674 [[]] .width = true := by decide
def e2405935015962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935015962 : Closed e2405935015962 ∧ code e2405935015962 = 11202028038170 := by decide
theorem cert_e2405935015962 : check e2405935015962 [[]] .width = true := by decide
def e2405935017498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935017498 : Closed e2405935017498 ∧ code e2405935017498 = 11202028039706 := by decide
theorem cert_e2405935017498 : check e2405935017498 [[]] .width = true := by decide
def e2405935065114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935065114 : Closed e2405935065114 ∧ code e2405935065114 = 11202028087322 := by decide
theorem cert_e2405935065114 : check e2405935065114 [[]] .width = true := by decide
def e2405935066650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935066650 : Closed e2405935066650 ∧ code e2405935066650 = 11202028088858 := by decide
theorem cert_e2405935066650 : check e2405935066650 [[]] .width = true := by decide
def e2405935069722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935069722 : Closed e2405935069722 ∧ code e2405935069722 = 11202028091930 := by decide
theorem cert_e2405935069722 : check e2405935069722 [[]] .width = true := by decide
def e2405935149254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405935149254 : Closed e2405935149254 ∧ code e2405935149254 = 11202028171462 := by decide
theorem cert_e2405935149254 : check e2405935149254 [[]] .width = true := by decide
def e2405935200282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935200282 : Closed e2405935200282 ∧ code e2405935200282 = 11202028222490 := by decide
theorem cert_e2405935200282 : check e2405935200282 [[]] .width = true := by decide
def e2405935212570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935212570 : Closed e2405935212570 ∧ code e2405935212570 = 11202028234778 := by decide
theorem cert_e2405935212570 : check e2405935212570 [[]] .width = true := by decide
def e2405935214106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935214106 : Closed e2405935214106 ∧ code e2405935214106 = 11202028236314 := by decide
theorem cert_e2405935214106 : check e2405935214106 [[]] .width = true := by decide
def e2405935317018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405935317018 : Closed e2405935317018 ∧ code e2405935317018 = 11202028339226 := by decide
theorem cert_e2405935317018 : check e2405935317018 [[]] .width = true := by decide
def e2405935317110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405935317110 : Closed e2405935317110 ∧ code e2405935317110 = 11202028339318 := by decide
theorem cert_e2405935317110 : check e2405935317110 [[]] .width = true := by decide
def e2405935317354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405935317354 : Closed e2405935317354 ∧ code e2405935317354 = 11202028339562 := by decide
theorem cert_e2405935317354 : check e2405935317354 [[]] .width = true := by decide
def e2405935317402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405935317402 : Closed e2405935317402 ∧ code e2405935317402 = 11202028339610 := by decide
theorem cert_e2405935317402 : check e2405935317402 [[]] .width = true := by decide
def e2405935318410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405935318410 : Closed e2405935318410 ∧ code e2405935318410 = 11202028340618 := by decide
theorem cert_e2405935318410 : check e2405935318410 [[]] .width = true := by decide
def e2405935318434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405935318434 : Closed e2405935318434 ∧ code e2405935318434 = 11202028340642 := by decide
theorem cert_e2405935318434 : check e2405935318434 [[]] .width = true := by decide
def e2405935318542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405935318542 : Closed e2405935318542 ∧ code e2405935318542 = 11202028340750 := by decide
theorem cert_e2405935318542 : check e2405935318542 [[]] .width = true := by decide
def e2405935318554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405935318554 : Closed e2405935318554 ∧ code e2405935318554 = 11202028340762 := by decide
theorem cert_e2405935318554 : check e2405935318554 [[]] .width = true := by decide
def e2405935318626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405935318626 : Closed e2405935318626 ∧ code e2405935318626 = 11202028340834 := by decide
theorem cert_e2405935318626 : check e2405935318626 [[]] .width = true := by decide
def e2405935464646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405935464646 : Closed e2405935464646 ∧ code e2405935464646 = 11202028486854 := by decide
theorem cert_e2405935464646 : check e2405935464646 [[]] .width = true := by decide
def e2405935482906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935482906 : Closed e2405935482906 ∧ code e2405935482906 = 11202028505114 := by decide
theorem cert_e2405935482906 : check e2405935482906 [[]] .width = true := by decide
def e2405935489050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405935489050 : Closed e2405935489050 ∧ code e2405935489050 = 11202028511258 := by decide
theorem cert_e2405935489050 : check e2405935489050 [[]] .width = true := by decide
def e2405935489142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405935489142 : Closed e2405935489142 ∧ code e2405935489142 = 11202028511350 := by decide
theorem cert_e2405935489142 : check e2405935489142 [[]] .width = true := by decide
def e2405935489386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405935489386 : Closed e2405935489386 ∧ code e2405935489386 = 11202028511594 := by decide
theorem cert_e2405935489386 : check e2405935489386 [[]] .width = true := by decide
def e2405935489434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405935489434 : Closed e2405935489434 ∧ code e2405935489434 = 11202028511642 := by decide
theorem cert_e2405935489434 : check e2405935489434 [[]] .width = true := by decide
def e2405935493318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405935493318 : Closed e2405935493318 ∧ code e2405935493318 = 11202028515526 := by decide
theorem cert_e2405935493318 : check e2405935493318 [[]] .width = true := by decide
def e2405935495194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935495194 : Closed e2405935495194 ∧ code e2405935495194 = 11202028517402 := by decide
theorem cert_e2405935495194 : check e2405935495194 [[]] .width = true := by decide
def e2405935507482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935507482 : Closed e2405935507482 ∧ code e2405935507482 = 11202028529690 := by decide
theorem cert_e2405935507482 : check e2405935507482 [[]] .width = true := by decide
def e2405935509018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935509018 : Closed e2405935509018 ∧ code e2405935509018 = 11202028531226 := by decide
theorem cert_e2405935509018 : check e2405935509018 [[]] .width = true := by decide
def e2405935512090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935512090 : Closed e2405935512090 ∧ code e2405935512090 = 11202028534298 := by decide
theorem cert_e2405935512090 : check e2405935512090 [[]] .width = true := by decide
def e2405935513626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405935513626 : Closed e2405935513626 ∧ code e2405935513626 = 11202028535834 := by decide
theorem cert_e2405935513626 : check e2405935513626 [[]] .width = true := by decide
def e2405935513718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405935513718 : Closed e2405935513718 ∧ code e2405935513718 = 11202028535926 := by decide
theorem cert_e2405935513718 : check e2405935513718 [[]] .width = true := by decide
def e2405935513962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405935513962 : Closed e2405935513962 ∧ code e2405935513962 = 11202028536170 := by decide
theorem cert_e2405935513962 : check e2405935513962 [[]] .width = true := by decide
def e2405935514010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405935514010 : Closed e2405935514010 ∧ code e2405935514010 = 11202028536218 := by decide
theorem cert_e2405935514010 : check e2405935514010 [[]] .width = true := by decide
def e2405935515018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405935515018 : Closed e2405935515018 ∧ code e2405935515018 = 11202028537226 := by decide
theorem cert_e2405935515018 : check e2405935515018 [[]] .width = true := by decide
def e2405935515042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405935515042 : Closed e2405935515042 ∧ code e2405935515042 = 11202028537250 := by decide
theorem cert_e2405935515042 : check e2405935515042 [[]] .width = true := by decide
def e2405935515150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405935515150 : Closed e2405935515150 ∧ code e2405935515150 = 11202028537358 := by decide
theorem cert_e2405935515150 : check e2405935515150 [[]] .width = true := by decide
def e2405935515162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405935515162 : Closed e2405935515162 ∧ code e2405935515162 = 11202028537370 := by decide
theorem cert_e2405935515162 : check e2405935515162 [[]] .width = true := by decide
def e2405935515234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405935515234 : Closed e2405935515234 ∧ code e2405935515234 = 11202028537442 := by decide
theorem cert_e2405935515234 : check e2405935515234 [[]] .width = true := by decide
def e2405935530182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405935530182 : Closed e2405935530182 ∧ code e2405935530182 = 11202028552390 := by decide
theorem cert_e2405935530182 : check e2405935530182 [[]] .width = true := by decide
def e2405935538202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405935538202 : Closed e2405935538202 ∧ code e2405935538202 = 11202028560410 := by decide
theorem cert_e2405935538202 : check e2405935538202 [[]] .width = true := by decide
def e2405935538294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405935538294 : Closed e2405935538294 ∧ code e2405935538294 = 11202028560502 := by decide
theorem cert_e2405935538294 : check e2405935538294 [[]] .width = true := by decide
def e2405935538538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405935538538 : Closed e2405935538538 ∧ code e2405935538538 = 11202028560746 := by decide
theorem cert_e2405935538538 : check e2405935538538 [[]] .width = true := by decide
def e2405935538586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405935538586 : Closed e2405935538586 ∧ code e2405935538586 = 11202028560794 := by decide
theorem cert_e2405935538586 : check e2405935538586 [[]] .width = true := by decide
def e2405935634458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935634458 : Closed e2405935634458 ∧ code e2405935634458 = 11202028656666 := by decide
theorem cert_e2405935634458 : check e2405935634458 [[]] .width = true := by decide
def e2405935702042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405935702042 : Closed e2405935702042 ∧ code e2405935702042 = 11202028724250 := by decide
theorem cert_e2405935702042 : check e2405935702042 [[]] .width = true := by decide
def e2405935702134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405935702134 : Closed e2405935702134 ∧ code e2405935702134 = 11202028724342 := by decide
theorem cert_e2405935702134 : check e2405935702134 [[]] .width = true := by decide
def e2405935702378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405935702378 : Closed e2405935702378 ∧ code e2405935702378 = 11202028724586 := by decide
theorem cert_e2405935702378 : check e2405935702378 [[]] .width = true := by decide
def e2405935702426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405935702426 : Closed e2405935702426 ∧ code e2405935702426 = 11202028724634 := by decide
theorem cert_e2405935702426 : check e2405935702426 [[]] .width = true := by decide
def e2405935722694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405935722694 : Closed e2405935722694 ∧ code e2405935722694 = 11202028744902 := by decide
theorem cert_e2405935722694 : check e2405935722694 [[]] .width = true := by decide
def e2405935730886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405935730886 : Closed e2405935730886 ∧ code e2405935730886 = 11202028753094 := by decide
theorem cert_e2405935730886 : check e2405935730886 [[]] .width = true := by decide
def e2405935732762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935732762 : Closed e2405935732762 ∧ code e2405935732762 = 11202028754970 := by decide
theorem cert_e2405935732762 : check e2405935732762 [[]] .width = true := by decide
def e2405935831066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935831066 : Closed e2405935831066 ∧ code e2405935831066 = 11202028853274 := by decide
theorem cert_e2405935831066 : check e2405935831066 [[]] .width = true := by decide
def e2405935835162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935835162 : Closed e2405935835162 ∧ code e2405935835162 = 11202028857370 := by decide
theorem cert_e2405935835162 : check e2405935835162 [[]] .width = true := by decide
def e2405935836698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935836698 : Closed e2405935836698 ∧ code e2405935836698 = 11202028858906 := by decide
theorem cert_e2405935836698 : check e2405935836698 [[]] .width = true := by decide
def e2405935838746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935838746 : Closed e2405935838746 ∧ code e2405935838746 = 11202028860954 := by decide
theorem cert_e2405935838746 : check e2405935838746 [[]] .width = true := by decide
def e2405935851546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935851546 : Closed e2405935851546 ∧ code e2405935851546 = 11202028873754 := by decide
theorem cert_e2405935851546 : check e2405935851546 [[]] .width = true := by decide
def e2405935853082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935853082 : Closed e2405935853082 ∧ code e2405935853082 = 11202028875290 := by decide
theorem cert_e2405935853082 : check e2405935853082 [[]] .width = true := by decide
def e2405935856154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935856154 : Closed e2405935856154 ∧ code e2405935856154 = 11202028878362 := by decide
theorem cert_e2405935856154 : check e2405935856154 [[]] .width = true := by decide
def e2405935863322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935863322 : Closed e2405935863322 ∧ code e2405935863322 = 11202028885530 := by decide
theorem cert_e2405935863322 : check e2405935863322 [[]] .width = true := by decide
def e2405935864346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935864346 : Closed e2405935864346 ∧ code e2405935864346 = 11202028886554 := by decide
theorem cert_e2405935864346 : check e2405935864346 [[]] .width = true := by decide
def e2405935902918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405935902918 : Closed e2405935902918 ∧ code e2405935902918 = 11202028925126 := by decide
theorem cert_e2405935902918 : check e2405935902918 [[]] .width = true := by decide
def e2405935929370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935929370 : Closed e2405935929370 ∧ code e2405935929370 = 11202028951578 := by decide
theorem cert_e2405935929370 : check e2405935929370 [[]] .width = true := by decide
def e2405935933466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405935933466 : Closed e2405935933466 ∧ code e2405935933466 = 11202028955674 := by decide
theorem cert_e2405935933466 : check e2405935933466 [[]] .width = true := by decide
def e2405935935002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935935002 : Closed e2405935935002 ∧ code e2405935935002 = 11202028957210 := by decide
theorem cert_e2405935935002 : check e2405935935002 [[]] .width = true := by decide
def e2405935937050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405935937050 : Closed e2405935937050 ∧ code e2405935937050 = 11202028959258 := by decide
theorem cert_e2405935937050 : check e2405935937050 [[]] .width = true := by decide
def e2405935972378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405935972378 : Closed e2405935972378 ∧ code e2405935972378 = 11202028994586 := by decide
theorem cert_e2405935972378 : check e2405935972378 [[]] .width = true := by decide
def e2405935972470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405935972470 : Closed e2405935972470 ∧ code e2405935972470 = 11202028994678 := by decide
theorem cert_e2405935972470 : check e2405935972470 [[]] .width = true := by decide
def e2405935972714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405935972714 : Closed e2405935972714 ∧ code e2405935972714 = 11202028994922 := by decide
theorem cert_e2405935972714 : check e2405935972714 [[]] .width = true := by decide
def e2405935972762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405935972762 : Closed e2405935972762 ∧ code e2405935972762 = 11202028994970 := by decide
theorem cert_e2405935972762 : check e2405935972762 [[]] .width = true := by decide
def e2405935973770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405935973770 : Closed e2405935973770 ∧ code e2405935973770 = 11202028995978 := by decide
theorem cert_e2405935973770 : check e2405935973770 [[]] .width = true := by decide
def e2405935973794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405935973794 : Closed e2405935973794 ∧ code e2405935973794 = 11202028996002 := by decide
theorem cert_e2405935973794 : check e2405935973794 [[]] .width = true := by decide
def e2405935973902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405935973902 : Closed e2405935973902 ∧ code e2405935973902 = 11202028996110 := by decide
theorem cert_e2405935973902 : check e2405935973902 [[]] .width = true := by decide
def e2405935973914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405935973914 : Closed e2405935973914 ∧ code e2405935973914 = 11202028996122 := by decide
theorem cert_e2405935973914 : check e2405935973914 [[]] .width = true := by decide
def e2405935973986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405935973986 : Closed e2405935973986 ∧ code e2405935973986 = 11202028996194 := by decide
theorem cert_e2405935973986 : check e2405935973986 [[]] .width = true := by decide
def e2405936007194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405936007194 : Closed e2405936007194 ∧ code e2405936007194 = 11202029029402 := by decide
theorem cert_e2405936007194 : check e2405936007194 [[]] .width = true := by decide
def e2405936013338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405936013338 : Closed e2405936013338 ∧ code e2405936013338 = 11202029035546 := by decide
theorem cert_e2405936013338 : check e2405936013338 [[]] .width = true := by decide
def e2405936013430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405936013430 : Closed e2405936013430 ∧ code e2405936013430 = 11202029035638 := by decide
theorem cert_e2405936013430 : check e2405936013430 [[]] .width = true := by decide
def e2405936013674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405936013674 : Closed e2405936013674 ∧ code e2405936013674 = 11202029035882 := by decide
theorem cert_e2405936013674 : check e2405936013674 [[]] .width = true := by decide
def e2405936013722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405936013722 : Closed e2405936013722 ∧ code e2405936013722 = 11202029035930 := by decide
theorem cert_e2405936013722 : check e2405936013722 [[]] .width = true := by decide
def e2405936017606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405936017606 : Closed e2405936017606 ∧ code e2405936017606 = 11202029039814 := by decide
theorem cert_e2405936017606 : check e2405936017606 [[]] .width = true := by decide
def e2405936019482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405936019482 : Closed e2405936019482 ∧ code e2405936019482 = 11202029041690 := by decide
theorem cert_e2405936019482 : check e2405936019482 [[]] .width = true := by decide
def e2405936031770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405936031770 : Closed e2405936031770 ∧ code e2405936031770 = 11202029053978 := by decide
theorem cert_e2405936031770 : check e2405936031770 [[]] .width = true := by decide
def e2405936033306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405936033306 : Closed e2405936033306 ∧ code e2405936033306 = 11202029055514 := by decide
theorem cert_e2405936033306 : check e2405936033306 [[]] .width = true := by decide
def e2405936036378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405936036378 : Closed e2405936036378 ∧ code e2405936036378 = 11202029058586 := by decide
theorem cert_e2405936036378 : check e2405936036378 [[]] .width = true := by decide
def e2405936037914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405936037914 : Closed e2405936037914 ∧ code e2405936037914 = 11202029060122 := by decide
theorem cert_e2405936037914 : check e2405936037914 [[]] .width = true := by decide
def e2405936038006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405936038006 : Closed e2405936038006 ∧ code e2405936038006 = 11202029060214 := by decide
theorem cert_e2405936038006 : check e2405936038006 [[]] .width = true := by decide
def e2405936038250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405936038250 : Closed e2405936038250 ∧ code e2405936038250 = 11202029060458 := by decide
theorem cert_e2405936038250 : check e2405936038250 [[]] .width = true := by decide
def e2405936038298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405936038298 : Closed e2405936038298 ∧ code e2405936038298 = 11202029060506 := by decide
theorem cert_e2405936038298 : check e2405936038298 [[]] .width = true := by decide
def e2405936039306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405936039306 : Closed e2405936039306 ∧ code e2405936039306 = 11202029061514 := by decide
theorem cert_e2405936039306 : check e2405936039306 [[]] .width = true := by decide
def e2405936039330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405936039330 : Closed e2405936039330 ∧ code e2405936039330 = 11202029061538 := by decide
theorem cert_e2405936039330 : check e2405936039330 [[]] .width = true := by decide
def e2405936039438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405936039438 : Closed e2405936039438 ∧ code e2405936039438 = 11202029061646 := by decide
theorem cert_e2405936039438 : check e2405936039438 [[]] .width = true := by decide
def e2405936039450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405936039450 : Closed e2405936039450 ∧ code e2405936039450 = 11202029061658 := by decide
theorem cert_e2405936039450 : check e2405936039450 [[]] .width = true := by decide
def e2405936039522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405936039522 : Closed e2405936039522 ∧ code e2405936039522 = 11202029061730 := by decide
theorem cert_e2405936039522 : check e2405936039522 [[]] .width = true := by decide
def e2405936054470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405936054470 : Closed e2405936054470 ∧ code e2405936054470 = 11202029076678 := by decide
theorem cert_e2405936054470 : check e2405936054470 [[]] .width = true := by decide
def e2405936062490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405936062490 : Closed e2405936062490 ∧ code e2405936062490 = 11202029084698 := by decide
theorem cert_e2405936062490 : check e2405936062490 [[]] .width = true := by decide
def e2405936062582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405936062582 : Closed e2405936062582 ∧ code e2405936062582 = 11202029084790 := by decide
theorem cert_e2405936062582 : check e2405936062582 [[]] .width = true := by decide
def e2405936062826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405936062826 : Closed e2405936062826 ∧ code e2405936062826 = 11202029085034 := by decide
theorem cert_e2405936062826 : check e2405936062826 [[]] .width = true := by decide
def e2405936062874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405936062874 : Closed e2405936062874 ∧ code e2405936062874 = 11202029085082 := by decide
theorem cert_e2405936062874 : check e2405936062874 [[]] .width = true := by decide
def e2405936084506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405936084506 : Closed e2405936084506 ∧ code e2405936084506 = 11202029106714 := by decide
theorem cert_e2405936084506 : check e2405936084506 [[]] .width = true := by decide
def e2405936085530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405936085530 : Closed e2405936085530 ∧ code e2405936085530 = 11202029107738 := by decide
theorem cert_e2405936085530 : check e2405936085530 [[]] .width = true := by decide
def e2405936095258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405936095258 : Closed e2405936095258 ∧ code e2405936095258 = 11202029117466 := by decide
theorem cert_e2405936095258 : check e2405936095258 [[]] .width = true := by decide
def e2405936095350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405936095350 : Closed e2405936095350 ∧ code e2405936095350 = 11202029117558 := by decide
theorem cert_e2405936095350 : check e2405936095350 [[]] .width = true := by decide
def e2405936095594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405936095594 : Closed e2405936095594 ∧ code e2405936095594 = 11202029117802 := by decide
theorem cert_e2405936095594 : check e2405936095594 [[]] .width = true := by decide
def e2405936095642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405936095642 : Closed e2405936095642 ∧ code e2405936095642 = 11202029117850 := by decide
theorem cert_e2405936095642 : check e2405936095642 [[]] .width = true := by decide
def e2405939656730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405939656730 : Closed e2405939656730 ∧ code e2405939656730 = 11202032678938 := by decide
theorem cert_e2405939656730 : check e2405939656730 [[]] .width = true := by decide
def e2405939664922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405939664922 : Closed e2405939664922 ∧ code e2405939664922 = 11202032687130 := by decide
theorem cert_e2405939664922 : check e2405939664922 [[]] .width = true := by decide
def e2405939722266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405939722266 : Closed e2405939722266 ∧ code e2405939722266 = 11202032744474 := by decide
theorem cert_e2405939722266 : check e2405939722266 [[]] .width = true := by decide
def e2405939734554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405939734554 : Closed e2405939734554 ∧ code e2405939734554 = 11202032756762 := by decide
theorem cert_e2405939734554 : check e2405939734554 [[]] .width = true := by decide
def e2405939736090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405939736090 : Closed e2405939736090 ∧ code e2405939736090 = 11202032758298 := by decide
theorem cert_e2405939736090 : check e2405939736090 [[]] .width = true := by decide
def e2405939763226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405939763226 : Closed e2405939763226 ∧ code e2405939763226 = 11202032785434 := by decide
theorem cert_e2405939763226 : check e2405939763226 [[]] .width = true := by decide
def e2405939767322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405939767322 : Closed e2405939767322 ∧ code e2405939767322 = 11202032789530 := by decide
theorem cert_e2405939767322 : check e2405939767322 [[]] .width = true := by decide
def e2405939768858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405939768858 : Closed e2405939768858 ∧ code e2405939768858 = 11202032791066 := by decide
theorem cert_e2405939768858 : check e2405939768858 [[]] .width = true := by decide
def e2405939770906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405939770906 : Closed e2405939770906 ∧ code e2405939770906 = 11202032793114 := by decide
theorem cert_e2405939770906 : check e2405939770906 [[]] .width = true := by decide
def e2405940049946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405940049946 : Closed e2405940049946 ∧ code e2405940049946 = 11202033072154 := by decide
theorem cert_e2405940049946 : check e2405940049946 [[]] .width = true := by decide
def e2405940058138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405940058138 : Closed e2405940058138 ∧ code e2405940058138 = 11202033080346 := by decide
theorem cert_e2405940058138 : check e2405940058138 [[]] .width = true := by decide
def e2405940392134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405940392134 : Closed e2405940392134 ∧ code e2405940392134 = 11202033414342 := by decide
theorem cert_e2405940392134 : check e2405940392134 [[]] .width = true := by decide
def e2405940443162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405940443162 : Closed e2405940443162 ∧ code e2405940443162 = 11202033465370 := by decide
theorem cert_e2405940443162 : check e2405940443162 [[]] .width = true := by decide
def e2405940455450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405940455450 : Closed e2405940455450 ∧ code e2405940455450 = 11202033477658 := by decide
theorem cert_e2405940455450 : check e2405940455450 [[]] .width = true := by decide
def e2405940456986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405940456986 : Closed e2405940456986 ∧ code e2405940456986 = 11202033479194 := by decide
theorem cert_e2405940456986 : check e2405940456986 [[]] .width = true := by decide
def e2405940559898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405940559898 : Closed e2405940559898 ∧ code e2405940559898 = 11202033582106 := by decide
theorem cert_e2405940559898 : check e2405940559898 [[]] .width = true := by decide
def e2405940559990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405940559990 : Closed e2405940559990 ∧ code e2405940559990 = 11202033582198 := by decide
theorem cert_e2405940559990 : check e2405940559990 [[]] .width = true := by decide
def e2405940560234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405940560234 : Closed e2405940560234 ∧ code e2405940560234 = 11202033582442 := by decide
theorem cert_e2405940560234 : check e2405940560234 [[]] .width = true := by decide
def e2405940560282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405940560282 : Closed e2405940560282 ∧ code e2405940560282 = 11202033582490 := by decide
theorem cert_e2405940560282 : check e2405940560282 [[]] .width = true := by decide
def e2405940561290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405940561290 : Closed e2405940561290 ∧ code e2405940561290 = 11202033583498 := by decide
theorem cert_e2405940561290 : check e2405940561290 [[]] .width = true := by decide
def e2405940561314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405940561314 : Closed e2405940561314 ∧ code e2405940561314 = 11202033583522 := by decide
theorem cert_e2405940561314 : check e2405940561314 [[]] .width = true := by decide
def e2405940561422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405940561422 : Closed e2405940561422 ∧ code e2405940561422 = 11202033583630 := by decide
theorem cert_e2405940561422 : check e2405940561422 [[]] .width = true := by decide
def e2405940561434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405940561434 : Closed e2405940561434 ∧ code e2405940561434 = 11202033583642 := by decide
theorem cert_e2405940561434 : check e2405940561434 [[]] .width = true := by decide
def e2405940561506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405940561506 : Closed e2405940561506 ∧ code e2405940561506 = 11202033583714 := by decide
theorem cert_e2405940561506 : check e2405940561506 [[]] .width = true := by decide
def e2405940621510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405940621510 : Closed e2405940621510 ∧ code e2405940621510 = 11202033643718 := by decide
theorem cert_e2405940621510 : check e2405940621510 [[]] .width = true := by decide
def e2405940647962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405940647962 : Closed e2405940647962 ∧ code e2405940647962 = 11202033670170 := by decide
theorem cert_e2405940647962 : check e2405940647962 [[]] .width = true := by decide
def e2405940652058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405940652058 : Closed e2405940652058 ∧ code e2405940652058 = 11202033674266 := by decide
theorem cert_e2405940652058 : check e2405940652058 [[]] .width = true := by decide
def e2405940653594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405940653594 : Closed e2405940653594 ∧ code e2405940653594 = 11202033675802 := by decide
theorem cert_e2405940653594 : check e2405940653594 [[]] .width = true := by decide
def e2405940655642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405940655642 : Closed e2405940655642 ∧ code e2405940655642 = 11202033677850 := by decide
theorem cert_e2405940655642 : check e2405940655642 [[]] .width = true := by decide
end Blc.Floor43
