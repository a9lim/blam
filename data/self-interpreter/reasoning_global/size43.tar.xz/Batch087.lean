import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e826999563706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e826999563706 : Closed e826999563706 ∧ code e826999563706 = 9623092585914 := by decide
theorem cert_e826999563706 : check e826999563706 [] .sourceHead = true := by decide
def e826999563734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e826999563734 : Closed e826999563734 ∧ code e826999563734 = 9623092585942 := by decide
theorem cert_e826999563734 : check e826999563734 [] .sourceHead = true := by decide
def e826999563738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e826999563738 : Closed e826999563738 ∧ code e826999563738 = 9623092585946 := by decide
theorem cert_e826999563738 : check e826999563738 [] .sourceHead = true := by decide
def e826999563754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e826999563754 : Closed e826999563754 ∧ code e826999563754 = 9623092585962 := by decide
theorem cert_e826999563754 : check e826999563754 [] .sourceHead = true := by decide
def e826999563886 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e826999563886 : Closed e826999563886 ∧ code e826999563886 = 9623092586094 := by decide
theorem cert_e826999563886 : check e826999563886 [] .sourceHead = true := by decide
def e826999563894 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e826999563894 : Closed e826999563894 ∧ code e826999563894 = 9623092586102 := by decide
theorem cert_e826999563894 : check e826999563894 [] .sourceHead = true := by decide
def e826999563898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e826999563898 : Closed e826999563898 ∧ code e826999563898 = 9623092586106 := by decide
theorem cert_e826999563898 : check e826999563898 [] .sourceHead = true := by decide
def e826999564086 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e826999564086 : Closed e826999564086 ∧ code e826999564086 = 9623092586294 := by decide
theorem cert_e826999564086 : check e826999564086 [] .sourceHead = true := by decide
def e826999564090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e826999564090 : Closed e826999564090 ∧ code e826999564090 = 9623092586298 := by decide
theorem cert_e826999564090 : check e826999564090 [] .sourceHead = true := by decide
def e826999564186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e826999564186 : Closed e826999564186 ∧ code e826999564186 = 9623092586394 := by decide
theorem cert_e826999564186 : check e826999564186 [] .sourceHead = true := by decide
def e827000010094 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e827000010094 : Closed e827000010094 ∧ code e827000010094 = 9623093032302 := by decide
theorem cert_e827000010094 : check e827000010094 [] .sourceHead = true := by decide
def e827000010102 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e827000010102 : Closed e827000010102 ∧ code e827000010102 = 9623093032310 := by decide
theorem cert_e827000010102 : check e827000010102 [] .sourceHead = true := by decide
def e827000010158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e827000010158 : Closed e827000010158 ∧ code e827000010158 = 9623093032366 := by decide
theorem cert_e827000010158 : check e827000010158 [] .sourceHead = true := by decide
def e827000010170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e827000010170 : Closed e827000010170 ∧ code e827000010170 = 9623093032378 := by decide
theorem cert_e827000010170 : check e827000010170 [] .sourceHead = true := by decide
def e827000010198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e827000010198 : Closed e827000010198 ∧ code e827000010198 = 9623093032406 := by decide
theorem cert_e827000010198 : check e827000010198 [] .sourceHead = true := by decide
def e827000010202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e827000010202 : Closed e827000010202 ∧ code e827000010202 = 9623093032410 := by decide
theorem cert_e827000010202 : check e827000010202 [] .sourceHead = true := by decide
def e827000010414 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e827000010414 : Closed e827000010414 ∧ code e827000010414 = 9623093032622 := by decide
theorem cert_e827000010414 : check e827000010414 [] .sourceHead = true := by decide
def e827000010426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e827000010426 : Closed e827000010426 ∧ code e827000010426 = 9623093032634 := by decide
theorem cert_e827000010426 : check e827000010426 [] .sourceHead = true := by decide
def e827000010474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e827000010474 : Closed e827000010474 ∧ code e827000010474 = 9623093032682 := by decide
theorem cert_e827000010474 : check e827000010474 [] .sourceHead = true := by decide
def e827000010582 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e827000010582 : Closed e827000010582 ∧ code e827000010582 = 9623093032790 := by decide
theorem cert_e827000010582 : check e827000010582 [] .sourceHead = true := by decide
def e827000010586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e827000010586 : Closed e827000010586 ∧ code e827000010586 = 9623093032794 := by decide
theorem cert_e827000010586 : check e827000010586 [] .sourceHead = true := by decide
def e827000010602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e827000010602 : Closed e827000010602 ∧ code e827000010602 = 9623093032810 := by decide
theorem cert_e827000010602 : check e827000010602 [] .sourceHead = true := by decide
def e827000011438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e827000011438 : Closed e827000011438 ∧ code e827000011438 = 9623093033646 := by decide
theorem cert_e827000011438 : check e827000011438 [] .sourceHead = true := by decide
def e827000011450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e827000011450 : Closed e827000011450 ∧ code e827000011450 = 9623093033658 := by decide
theorem cert_e827000011450 : check e827000011450 [] .sourceHead = true := by decide
def e827000011498 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e827000011498 : Closed e827000011498 ∧ code e827000011498 = 9623093033706 := by decide
theorem cert_e827000011498 : check e827000011498 [] .sourceHead = true := by decide
def e827000011690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e827000011690 : Closed e827000011690 ∧ code e827000011690 = 9623093033898 := by decide
theorem cert_e827000011690 : check e827000011690 [] .sourceHead = true := by decide
def e827000012118 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e827000012118 : Closed e827000012118 ∧ code e827000012118 = 9623093034326 := by decide
theorem cert_e827000012118 : check e827000012118 [] .sourceHead = true := by decide
def e827000012122 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e827000012122 : Closed e827000012122 ∧ code e827000012122 = 9623093034330 := by decide
theorem cert_e827000012122 : check e827000012122 [] .sourceHead = true := by decide
def e827000012138 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e827000012138 : Closed e827000012138 ∧ code e827000012138 = 9623093034346 := by decide
theorem cert_e827000012138 : check e827000012138 [] .sourceHead = true := by decide
def e827000012202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e827000012202 : Closed e827000012202 ∧ code e827000012202 = 9623093034410 := by decide
theorem cert_e827000012202 : check e827000012202 [] .sourceHead = true := by decide
def e827000016238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e827000016238 : Closed e827000016238 ∧ code e827000016238 = 9623093038446 := by decide
theorem cert_e827000016238 : check e827000016238 [] .sourceHead = true := by decide
def e827000016246 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e827000016246 : Closed e827000016246 ∧ code e827000016246 = 9623093038454 := by decide
theorem cert_e827000016246 : check e827000016246 [] .sourceHead = true := by decide
def e827000016302 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e827000016302 : Closed e827000016302 ∧ code e827000016302 = 9623093038510 := by decide
theorem cert_e827000016302 : check e827000016302 [] .sourceHead = true := by decide
def e827000016314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e827000016314 : Closed e827000016314 ∧ code e827000016314 = 9623093038522 := by decide
theorem cert_e827000016314 : check e827000016314 [] .sourceHead = true := by decide
def e827000016342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e827000016342 : Closed e827000016342 ∧ code e827000016342 = 9623093038550 := by decide
theorem cert_e827000016342 : check e827000016342 [] .sourceHead = true := by decide
def e827000016346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e827000016346 : Closed e827000016346 ∧ code e827000016346 = 9623093038554 := by decide
theorem cert_e827000016346 : check e827000016346 [] .sourceHead = true := by decide
def e827000016558 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e827000016558 : Closed e827000016558 ∧ code e827000016558 = 9623093038766 := by decide
theorem cert_e827000016558 : check e827000016558 [] .sourceHead = true := by decide
def e827000016570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e827000016570 : Closed e827000016570 ∧ code e827000016570 = 9623093038778 := by decide
theorem cert_e827000016570 : check e827000016570 [] .sourceHead = true := by decide
def e827000016618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e827000016618 : Closed e827000016618 ∧ code e827000016618 = 9623093038826 := by decide
theorem cert_e827000016618 : check e827000016618 [] .sourceHead = true := by decide
def e827000016726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e827000016726 : Closed e827000016726 ∧ code e827000016726 = 9623093038934 := by decide
theorem cert_e827000016726 : check e827000016726 [] .sourceHead = true := by decide
def e827000016730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e827000016730 : Closed e827000016730 ∧ code e827000016730 = 9623093038938 := by decide
theorem cert_e827000016730 : check e827000016730 [] .sourceHead = true := by decide
def e827000016746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e827000016746 : Closed e827000016746 ∧ code e827000016746 = 9623093038954 := by decide
theorem cert_e827000016746 : check e827000016746 [] .sourceHead = true := by decide
def e827000017774 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e827000017774 : Closed e827000017774 ∧ code e827000017774 = 9623093039982 := by decide
theorem cert_e827000017774 : check e827000017774 [] .sourceHead = true := by decide
def e827000017782 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e827000017782 : Closed e827000017782 ∧ code e827000017782 = 9623093039990 := by decide
theorem cert_e827000017782 : check e827000017782 [] .sourceHead = true := by decide
def e827000017838 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e827000017838 : Closed e827000017838 ∧ code e827000017838 = 9623093040046 := by decide
theorem cert_e827000017838 : check e827000017838 [] .sourceHead = true := by decide
def e827000017850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e827000017850 : Closed e827000017850 ∧ code e827000017850 = 9623093040058 := by decide
theorem cert_e827000017850 : check e827000017850 [] .sourceHead = true := by decide
def e827000017878 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e827000017878 : Closed e827000017878 ∧ code e827000017878 = 9623093040086 := by decide
theorem cert_e827000017878 : check e827000017878 [] .sourceHead = true := by decide
def e827000017882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e827000017882 : Closed e827000017882 ∧ code e827000017882 = 9623093040090 := by decide
theorem cert_e827000017882 : check e827000017882 [] .sourceHead = true := by decide
def e827000018158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e827000018158 : Closed e827000018158 ∧ code e827000018158 = 9623093040366 := by decide
theorem cert_e827000018158 : check e827000018158 [] .sourceHead = true := by decide
def e827000018166 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e827000018166 : Closed e827000018166 ∧ code e827000018166 = 9623093040374 := by decide
theorem cert_e827000018166 : check e827000018166 [] .sourceHead = true := by decide
def e827000018542 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e827000018542 : Closed e827000018542 ∧ code e827000018542 = 9623093040750 := by decide
theorem cert_e827000018542 : check e827000018542 [] .sourceHead = true := by decide
def e827000018554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e827000018554 : Closed e827000018554 ∧ code e827000018554 = 9623093040762 := by decide
theorem cert_e827000018554 : check e827000018554 [] .sourceHead = true := by decide
def e827000018742 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e827000018742 : Closed e827000018742 ∧ code e827000018742 = 9623093040950 := by decide
theorem cert_e827000018742 : check e827000018742 [] .sourceHead = true := by decide
def e827000018746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e827000018746 : Closed e827000018746 ∧ code e827000018746 = 9623093040954 := by decide
theorem cert_e827000018746 : check e827000018746 [] .sourceHead = true := by decide
def e827000019374 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e827000019374 : Closed e827000019374 ∧ code e827000019374 = 9623093041582 := by decide
theorem cert_e827000019374 : check e827000019374 [] .sourceHead = true := by decide
def e827000019386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e827000019386 : Closed e827000019386 ∧ code e827000019386 = 9623093041594 := by decide
theorem cert_e827000019386 : check e827000019386 [] .sourceHead = true := by decide
def e827000019434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e827000019434 : Closed e827000019434 ∧ code e827000019434 = 9623093041642 := by decide
theorem cert_e827000019434 : check e827000019434 [] .sourceHead = true := by decide
def e827000019566 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e827000019566 : Closed e827000019566 ∧ code e827000019566 = 9623093041774 := by decide
theorem cert_e827000019566 : check e827000019566 [] .sourceHead = true := by decide
def e827000019578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e827000019578 : Closed e827000019578 ∧ code e827000019578 = 9623093041786 := by decide
theorem cert_e827000019578 : check e827000019578 [] .sourceHead = true := by decide
def e827000019866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000019866 : Closed e827000019866 ∧ code e827000019866 = 9623093042074 := by decide
theorem cert_e827000019866 : check e827000019866 [] .sourceHead = true := by decide
def e827000020182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e827000020182 : Closed e827000020182 ∧ code e827000020182 = 9623093042390 := by decide
theorem cert_e827000020182 : check e827000020182 [] .sourceHead = true := by decide
def e827000020186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e827000020186 : Closed e827000020186 ∧ code e827000020186 = 9623093042394 := by decide
theorem cert_e827000020186 : check e827000020186 [] .sourceHead = true := by decide
def e827000020202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e827000020202 : Closed e827000020202 ∧ code e827000020202 = 9623093042410 := by decide
theorem cert_e827000020202 : check e827000020202 [] .sourceHead = true := by decide
def e827000020278 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e827000020278 : Closed e827000020278 ∧ code e827000020278 = 9623093042486 := by decide
theorem cert_e827000020278 : check e827000020278 [] .sourceHead = true := by decide
def e827000020282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e827000020282 : Closed e827000020282 ∧ code e827000020282 = 9623093042490 := by decide
theorem cert_e827000020282 : check e827000020282 [] .sourceHead = true := by decide
def e827000020378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000020378 : Closed e827000020378 ∧ code e827000020378 = 9623093042586 := by decide
theorem cert_e827000020378 : check e827000020378 [] .sourceHead = true := by decide
def e827000022702 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e827000022702 : Closed e827000022702 ∧ code e827000022702 = 9623093044910 := by decide
theorem cert_e827000022702 : check e827000022702 [] .sourceHead = true := by decide
def e827000022714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e827000022714 : Closed e827000022714 ∧ code e827000022714 = 9623093044922 := by decide
theorem cert_e827000022714 : check e827000022714 [] .sourceHead = true := by decide
def e827000022762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e827000022762 : Closed e827000022762 ∧ code e827000022762 = 9623093044970 := by decide
theorem cert_e827000022762 : check e827000022762 [] .sourceHead = true := by decide
def e827000022954 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e827000022954 : Closed e827000022954 ∧ code e827000022954 = 9623093045162 := by decide
theorem cert_e827000022954 : check e827000022954 [] .sourceHead = true := by decide
def e827000023470 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e827000023470 : Closed e827000023470 ∧ code e827000023470 = 9623093045678 := by decide
theorem cert_e827000023470 : check e827000023470 [] .sourceHead = true := by decide
def e827000023482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e827000023482 : Closed e827000023482 ∧ code e827000023482 = 9623093045690 := by decide
theorem cert_e827000023482 : check e827000023482 [] .sourceHead = true := by decide
def e827000023530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e827000023530 : Closed e827000023530 ∧ code e827000023530 = 9623093045738 := by decide
theorem cert_e827000023530 : check e827000023530 [] .sourceHead = true := by decide
def e827000023662 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e827000023662 : Closed e827000023662 ∧ code e827000023662 = 9623093045870 := by decide
theorem cert_e827000023662 : check e827000023662 [] .sourceHead = true := by decide
def e827000023674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e827000023674 : Closed e827000023674 ∧ code e827000023674 = 9623093045882 := by decide
theorem cert_e827000023674 : check e827000023674 [] .sourceHead = true := by decide
def e827000023962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000023962 : Closed e827000023962 ∧ code e827000023962 = 9623093046170 := by decide
theorem cert_e827000023962 : check e827000023962 [] .sourceHead = true := by decide
def e827000024682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e827000024682 : Closed e827000024682 ∧ code e827000024682 = 9623093046890 := by decide
theorem cert_e827000024682 : check e827000024682 [] .sourceHead = true := by decide
def e827000024730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000024730 : Closed e827000024730 ∧ code e827000024730 = 9623093046938 := by decide
theorem cert_e827000024730 : check e827000024730 [] .sourceHead = true := by decide
def e827000025942 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e827000025942 : Closed e827000025942 ∧ code e827000025942 = 9623093048150 := by decide
theorem cert_e827000025942 : check e827000025942 [] .sourceHead = true := by decide
def e827000025946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e827000025946 : Closed e827000025946 ∧ code e827000025946 = 9623093048154 := by decide
theorem cert_e827000025946 : check e827000025946 [] .sourceHead = true := by decide
def e827000025962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e827000025962 : Closed e827000025962 ∧ code e827000025962 = 9623093048170 := by decide
theorem cert_e827000025962 : check e827000025962 [] .sourceHead = true := by decide
def e827000026026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e827000026026 : Closed e827000026026 ∧ code e827000026026 = 9623093048234 := by decide
theorem cert_e827000026026 : check e827000026026 [] .sourceHead = true := by decide
def e827000026326 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e827000026326 : Closed e827000026326 ∧ code e827000026326 = 9623093048534 := by decide
theorem cert_e827000026326 : check e827000026326 [] .sourceHead = true := by decide
def e827000026330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e827000026330 : Closed e827000026330 ∧ code e827000026330 = 9623093048538 := by decide
theorem cert_e827000026330 : check e827000026330 [] .sourceHead = true := by decide
def e827000026346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e827000026346 : Closed e827000026346 ∧ code e827000026346 = 9623093048554 := by decide
theorem cert_e827000026346 : check e827000026346 [] .sourceHead = true := by decide
def e827000026422 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e827000026422 : Closed e827000026422 ∧ code e827000026422 = 9623093048630 := by decide
theorem cert_e827000026422 : check e827000026422 [] .sourceHead = true := by decide
def e827000026426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e827000026426 : Closed e827000026426 ∧ code e827000026426 = 9623093048634 := by decide
theorem cert_e827000026426 : check e827000026426 [] .sourceHead = true := by decide
def e827000026522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000026522 : Closed e827000026522 ∧ code e827000026522 = 9623093048730 := by decide
theorem cert_e827000026522 : check e827000026522 [] .sourceHead = true := by decide
def e827000026730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e827000026730 : Closed e827000026730 ∧ code e827000026730 = 9623093048938 := by decide
theorem cert_e827000026730 : check e827000026730 [] .sourceHead = true := by decide
def e827000026778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000026778 : Closed e827000026778 ∧ code e827000026778 = 9623093048986 := by decide
theorem cert_e827000026778 : check e827000026778 [] .sourceHead = true := by decide
def e827000033006 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e827000033006 : Closed e827000033006 ∧ code e827000033006 = 9623093055214 := by decide
theorem cert_e827000033006 : check e827000033006 [] .sourceHead = true := by decide
def e827000033014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e827000033014 : Closed e827000033014 ∧ code e827000033014 = 9623093055222 := by decide
theorem cert_e827000033014 : check e827000033014 [] .sourceHead = true := by decide
def e827000033134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e827000033134 : Closed e827000033134 ∧ code e827000033134 = 9623093055342 := by decide
theorem cert_e827000033134 : check e827000033134 [] .sourceHead = true := by decide
def e827000033146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e827000033146 : Closed e827000033146 ∧ code e827000033146 = 9623093055354 := by decide
theorem cert_e827000033146 : check e827000033146 [] .sourceHead = true := by decide
def e827000033206 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e827000033206 : Closed e827000033206 ∧ code e827000033206 = 9623093055414 := by decide
theorem cert_e827000033206 : check e827000033206 [] .sourceHead = true := by decide
def e827000033210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e827000033210 : Closed e827000033210 ∧ code e827000033210 = 9623093055418 := by decide
theorem cert_e827000033210 : check e827000033210 [] .sourceHead = true := by decide
def e827000040814 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e827000040814 : Closed e827000040814 ∧ code e827000040814 = 9623093063022 := by decide
theorem cert_e827000040814 : check e827000040814 [] .sourceHead = true := by decide
def e827000040822 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e827000040822 : Closed e827000040822 ∧ code e827000040822 = 9623093063030 := by decide
theorem cert_e827000040822 : check e827000040822 [] .sourceHead = true := by decide
def e827000040878 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e827000040878 : Closed e827000040878 ∧ code e827000040878 = 9623093063086 := by decide
theorem cert_e827000040878 : check e827000040878 [] .sourceHead = true := by decide
def e827000040890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e827000040890 : Closed e827000040890 ∧ code e827000040890 = 9623093063098 := by decide
theorem cert_e827000040890 : check e827000040890 [] .sourceHead = true := by decide
def e827000040918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e827000040918 : Closed e827000040918 ∧ code e827000040918 = 9623093063126 := by decide
theorem cert_e827000040918 : check e827000040918 [] .sourceHead = true := by decide
def e827000040922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e827000040922 : Closed e827000040922 ∧ code e827000040922 = 9623093063130 := by decide
theorem cert_e827000040922 : check e827000040922 [] .sourceHead = true := by decide
def e827000041134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e827000041134 : Closed e827000041134 ∧ code e827000041134 = 9623093063342 := by decide
theorem cert_e827000041134 : check e827000041134 [] .sourceHead = true := by decide
def e827000041146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e827000041146 : Closed e827000041146 ∧ code e827000041146 = 9623093063354 := by decide
theorem cert_e827000041146 : check e827000041146 [] .sourceHead = true := by decide
def e827000041194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e827000041194 : Closed e827000041194 ∧ code e827000041194 = 9623093063402 := by decide
theorem cert_e827000041194 : check e827000041194 [] .sourceHead = true := by decide
def e827000041302 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e827000041302 : Closed e827000041302 ∧ code e827000041302 = 9623093063510 := by decide
theorem cert_e827000041302 : check e827000041302 [] .sourceHead = true := by decide
def e827000041306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e827000041306 : Closed e827000041306 ∧ code e827000041306 = 9623093063514 := by decide
theorem cert_e827000041306 : check e827000041306 [] .sourceHead = true := by decide
def e827000041322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e827000041322 : Closed e827000041322 ∧ code e827000041322 = 9623093063530 := by decide
theorem cert_e827000041322 : check e827000041322 [] .sourceHead = true := by decide
def e827000042350 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e827000042350 : Closed e827000042350 ∧ code e827000042350 = 9623093064558 := by decide
theorem cert_e827000042350 : check e827000042350 [] .sourceHead = true := by decide
def e827000042358 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e827000042358 : Closed e827000042358 ∧ code e827000042358 = 9623093064566 := by decide
theorem cert_e827000042358 : check e827000042358 [] .sourceHead = true := by decide
def e827000042414 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e827000042414 : Closed e827000042414 ∧ code e827000042414 = 9623093064622 := by decide
theorem cert_e827000042414 : check e827000042414 [] .sourceHead = true := by decide
def e827000042426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e827000042426 : Closed e827000042426 ∧ code e827000042426 = 9623093064634 := by decide
theorem cert_e827000042426 : check e827000042426 [] .sourceHead = true := by decide
def e827000042454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e827000042454 : Closed e827000042454 ∧ code e827000042454 = 9623093064662 := by decide
theorem cert_e827000042454 : check e827000042454 [] .sourceHead = true := by decide
def e827000042458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e827000042458 : Closed e827000042458 ∧ code e827000042458 = 9623093064666 := by decide
theorem cert_e827000042458 : check e827000042458 [] .sourceHead = true := by decide
def e827000042734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e827000042734 : Closed e827000042734 ∧ code e827000042734 = 9623093064942 := by decide
theorem cert_e827000042734 : check e827000042734 [] .sourceHead = true := by decide
def e827000042742 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e827000042742 : Closed e827000042742 ∧ code e827000042742 = 9623093064950 := by decide
theorem cert_e827000042742 : check e827000042742 [] .sourceHead = true := by decide
def e827000043118 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e827000043118 : Closed e827000043118 ∧ code e827000043118 = 9623093065326 := by decide
theorem cert_e827000043118 : check e827000043118 [] .sourceHead = true := by decide
def e827000043130 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e827000043130 : Closed e827000043130 ∧ code e827000043130 = 9623093065338 := by decide
theorem cert_e827000043130 : check e827000043130 [] .sourceHead = true := by decide
def e827000043318 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e827000043318 : Closed e827000043318 ∧ code e827000043318 = 9623093065526 := by decide
theorem cert_e827000043318 : check e827000043318 [] .sourceHead = true := by decide
def e827000043322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e827000043322 : Closed e827000043322 ∧ code e827000043322 = 9623093065530 := by decide
theorem cert_e827000043322 : check e827000043322 [] .sourceHead = true := by decide
def e827000043950 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e827000043950 : Closed e827000043950 ∧ code e827000043950 = 9623093066158 := by decide
theorem cert_e827000043950 : check e827000043950 [] .sourceHead = true := by decide
def e827000043962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e827000043962 : Closed e827000043962 ∧ code e827000043962 = 9623093066170 := by decide
theorem cert_e827000043962 : check e827000043962 [] .sourceHead = true := by decide
def e827000044010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e827000044010 : Closed e827000044010 ∧ code e827000044010 = 9623093066218 := by decide
theorem cert_e827000044010 : check e827000044010 [] .sourceHead = true := by decide
def e827000044142 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e827000044142 : Closed e827000044142 ∧ code e827000044142 = 9623093066350 := by decide
theorem cert_e827000044142 : check e827000044142 [] .sourceHead = true := by decide
def e827000044154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e827000044154 : Closed e827000044154 ∧ code e827000044154 = 9623093066362 := by decide
theorem cert_e827000044154 : check e827000044154 [] .sourceHead = true := by decide
def e827000044442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000044442 : Closed e827000044442 ∧ code e827000044442 = 9623093066650 := by decide
theorem cert_e827000044442 : check e827000044442 [] .sourceHead = true := by decide
def e827000044758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e827000044758 : Closed e827000044758 ∧ code e827000044758 = 9623093066966 := by decide
theorem cert_e827000044758 : check e827000044758 [] .sourceHead = true := by decide
def e827000044762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e827000044762 : Closed e827000044762 ∧ code e827000044762 = 9623093066970 := by decide
theorem cert_e827000044762 : check e827000044762 [] .sourceHead = true := by decide
def e827000044778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e827000044778 : Closed e827000044778 ∧ code e827000044778 = 9623093066986 := by decide
theorem cert_e827000044778 : check e827000044778 [] .sourceHead = true := by decide
def e827000044854 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e827000044854 : Closed e827000044854 ∧ code e827000044854 = 9623093067062 := by decide
theorem cert_e827000044854 : check e827000044854 [] .sourceHead = true := by decide
def e827000044858 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e827000044858 : Closed e827000044858 ∧ code e827000044858 = 9623093067066 := by decide
theorem cert_e827000044858 : check e827000044858 [] .sourceHead = true := by decide
def e827000044954 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000044954 : Closed e827000044954 ∧ code e827000044954 = 9623093067162 := by decide
theorem cert_e827000044954 : check e827000044954 [] .sourceHead = true := by decide
def e827000046558 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e827000046558 : Closed e827000046558 ∧ code e827000046558 = 9623093068766 := by decide
theorem cert_e827000046558 : check e827000046558 [] .sourceHead = true := by decide
def e827000046574 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e827000046574 : Closed e827000046574 ∧ code e827000046574 = 9623093068782 := by decide
theorem cert_e827000046574 : check e827000046574 [] .sourceHead = true := by decide
def e827000048494 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e827000048494 : Closed e827000048494 ∧ code e827000048494 = 9623093070702 := by decide
theorem cert_e827000048494 : check e827000048494 [] .sourceHead = true := by decide
def e827000048502 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e827000048502 : Closed e827000048502 ∧ code e827000048502 = 9623093070710 := by decide
theorem cert_e827000048502 : check e827000048502 [] .sourceHead = true := by decide
def e827000048558 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e827000048558 : Closed e827000048558 ∧ code e827000048558 = 9623093070766 := by decide
theorem cert_e827000048558 : check e827000048558 [] .sourceHead = true := by decide
def e827000048570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e827000048570 : Closed e827000048570 ∧ code e827000048570 = 9623093070778 := by decide
theorem cert_e827000048570 : check e827000048570 [] .sourceHead = true := by decide
def e827000048598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e827000048598 : Closed e827000048598 ∧ code e827000048598 = 9623093070806 := by decide
theorem cert_e827000048598 : check e827000048598 [] .sourceHead = true := by decide
def e827000048602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e827000048602 : Closed e827000048602 ∧ code e827000048602 = 9623093070810 := by decide
theorem cert_e827000048602 : check e827000048602 [] .sourceHead = true := by decide
def e827000048878 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e827000048878 : Closed e827000048878 ∧ code e827000048878 = 9623093071086 := by decide
theorem cert_e827000048878 : check e827000048878 [] .sourceHead = true := by decide
def e827000048886 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e827000048886 : Closed e827000048886 ∧ code e827000048886 = 9623093071094 := by decide
theorem cert_e827000048886 : check e827000048886 [] .sourceHead = true := by decide
def e827000049262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e827000049262 : Closed e827000049262 ∧ code e827000049262 = 9623093071470 := by decide
theorem cert_e827000049262 : check e827000049262 [] .sourceHead = true := by decide
def e827000049274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e827000049274 : Closed e827000049274 ∧ code e827000049274 = 9623093071482 := by decide
theorem cert_e827000049274 : check e827000049274 [] .sourceHead = true := by decide
def e827000049462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e827000049462 : Closed e827000049462 ∧ code e827000049462 = 9623093071670 := by decide
theorem cert_e827000049462 : check e827000049462 [] .sourceHead = true := by decide
def e827000049466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e827000049466 : Closed e827000049466 ∧ code e827000049466 = 9623093071674 := by decide
theorem cert_e827000049466 : check e827000049466 [] .sourceHead = true := by decide
def e827000054238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e827000054238 : Closed e827000054238 ∧ code e827000054238 = 9623093076446 := by decide
theorem cert_e827000054238 : check e827000054238 [] .sourceHead = true := by decide
def e827000054262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e827000054262 : Closed e827000054262 ∧ code e827000054262 = 9623093076470 := by decide
theorem cert_e827000054262 : check e827000054262 [] .sourceHead = true := by decide
def e827000055214 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e827000055214 : Closed e827000055214 ∧ code e827000055214 = 9623093077422 := by decide
theorem cert_e827000055214 : check e827000055214 [] .sourceHead = true := by decide
def e827000055226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e827000055226 : Closed e827000055226 ∧ code e827000055226 = 9623093077434 := by decide
theorem cert_e827000055226 : check e827000055226 [] .sourceHead = true := by decide
def e827000055274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e827000055274 : Closed e827000055274 ∧ code e827000055274 = 9623093077482 := by decide
theorem cert_e827000055274 : check e827000055274 [] .sourceHead = true := by decide
def e827000055406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e827000055406 : Closed e827000055406 ∧ code e827000055406 = 9623093077614 := by decide
theorem cert_e827000055406 : check e827000055406 [] .sourceHead = true := by decide
def e827000055418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e827000055418 : Closed e827000055418 ∧ code e827000055418 = 9623093077626 := by decide
theorem cert_e827000055418 : check e827000055418 [] .sourceHead = true := by decide
def e827000055706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000055706 : Closed e827000055706 ∧ code e827000055706 = 9623093077914 := by decide
theorem cert_e827000055706 : check e827000055706 [] .sourceHead = true := by decide
def e827000058094 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e827000058094 : Closed e827000058094 ∧ code e827000058094 = 9623093080302 := by decide
theorem cert_e827000058094 : check e827000058094 [] .sourceHead = true := by decide
def e827000058102 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e827000058102 : Closed e827000058102 ∧ code e827000058102 = 9623093080310 := by decide
theorem cert_e827000058102 : check e827000058102 [] .sourceHead = true := by decide
def e827000058582 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e827000058582 : Closed e827000058582 ∧ code e827000058582 = 9623093080790 := by decide
theorem cert_e827000058582 : check e827000058582 [] .sourceHead = true := by decide
def e827000058586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e827000058586 : Closed e827000058586 ∧ code e827000058586 = 9623093080794 := by decide
theorem cert_e827000058586 : check e827000058586 [] .sourceHead = true := by decide
def e827000058602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e827000058602 : Closed e827000058602 ∧ code e827000058602 = 9623093080810 := by decide
theorem cert_e827000058602 : check e827000058602 [] .sourceHead = true := by decide
def e827000058678 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e827000058678 : Closed e827000058678 ∧ code e827000058678 = 9623093080886 := by decide
theorem cert_e827000058678 : check e827000058678 [] .sourceHead = true := by decide
end Blc.Floor43
