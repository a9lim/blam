import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701157391002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157391002 : Closed e701157391002 ∧ code e701157391002 = 9497250413210 := by decide
theorem cert_e701157391002 : check e701157391002 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157391046 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701157391046 : Closed e701157391046 ∧ code e701157391046 = 9497250413254 := by decide
theorem cert_e701157391046 : check e701157391046 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157391130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701157391130 : Closed e701157391130 ∧ code e701157391130 = 9497250413338 := by decide
theorem cert_e701157391130 : check e701157391130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157391174 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701157391174 : Closed e701157391174 ∧ code e701157391174 = 9497250413382 := by decide
theorem cert_e701157391174 : check e701157391174 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157393338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701157393338 : Closed e701157393338 ∧ code e701157393338 = 9497250415546 := by decide
theorem cert_e701157393338 : check e701157393338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157393370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701157393370 : Closed e701157393370 ∧ code e701157393370 = 9497250415578 := by decide
theorem cert_e701157393370 : check e701157393370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157395290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701157395290 : Closed e701157395290 ∧ code e701157395290 = 9497250417498 := by decide
theorem cert_e701157395290 : check e701157395290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157395306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701157395306 : Closed e701157395306 ∧ code e701157395306 = 9497250417514 := by decide
theorem cert_e701157395306 : check e701157395306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157395370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701157395370 : Closed e701157395370 ∧ code e701157395370 = 9497250417578 := by decide
theorem cert_e701157395370 : check e701157395370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157395674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701157395674 : Closed e701157395674 ∧ code e701157395674 = 9497250417882 := by decide
theorem cert_e701157395674 : check e701157395674 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157395690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701157395690 : Closed e701157395690 ∧ code e701157395690 = 9497250417898 := by decide
theorem cert_e701157395690 : check e701157395690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157395866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157395866 : Closed e701157395866 ∧ code e701157395866 = 9497250418074 := by decide
theorem cert_e701157395866 : check e701157395866 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157396026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701157396026 : Closed e701157396026 ∧ code e701157396026 = 9497250418234 := by decide
theorem cert_e701157396026 : check e701157396026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157396074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701157396074 : Closed e701157396074 ∧ code e701157396074 = 9497250418282 := by decide
theorem cert_e701157396074 : check e701157396074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157396122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157396122 : Closed e701157396122 ∧ code e701157396122 = 9497250418330 := by decide
theorem cert_e701157396122 : check e701157396122 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157396166 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701157396166 : Closed e701157396166 ∧ code e701157396166 = 9497250418374 := by decide
theorem cert_e701157396166 : check e701157396166 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157401050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))) (.var 0)))
theorem wire_e701157401050 : Closed e701157401050 ∧ code e701157401050 = 9497250423258 := by decide
theorem cert_e701157401050 : check e701157401050 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157402026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701157402026 : Closed e701157402026 ∧ code e701157402026 = 9497250424234 := by decide
theorem cert_e701157402026 : check e701157402026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157402170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701157402170 : Closed e701157402170 ∧ code e701157402170 = 9497250424378 := by decide
theorem cert_e701157402170 : check e701157402170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157402218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701157402218 : Closed e701157402218 ∧ code e701157402218 = 9497250424426 := by decide
theorem cert_e701157402218 : check e701157402218 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157402266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157402266 : Closed e701157402266 ∧ code e701157402266 = 9497250424474 := by decide
theorem cert_e701157402266 : check e701157402266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157402310 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701157402310 : Closed e701157402310 ∧ code e701157402310 = 9497250424518 := by decide
theorem cert_e701157402310 : check e701157402310 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157402394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e701157402394 : Closed e701157402394 ∧ code e701157402394 = 9497250424602 := by decide
theorem cert_e701157402394 : check e701157402394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157402438 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e701157402438 : Closed e701157402438 ∧ code e701157402438 = 9497250424646 := by decide
theorem cert_e701157402438 : check e701157402438 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164992234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.var 0)))
theorem wire_e701164992234 : Closed e701164992234 ∧ code e701164992234 = 9497258014442 := by decide
theorem cert_e701164992234 : check e701164992234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164992362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.var 0)))
theorem wire_e701164992362 : Closed e701164992362 ∧ code e701164992362 = 9497258014570 := by decide
theorem cert_e701164992362 : check e701164992362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164993258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.var 0)))
theorem wire_e701164993258 : Closed e701164993258 ∧ code e701164993258 = 9497258015466 := by decide
theorem cert_e701164993258 : check e701164993258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164993450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))) (.var 0)))
theorem wire_e701164993450 : Closed e701164993450 ∧ code e701164993450 = 9497258015658 := by decide
theorem cert_e701164993450 : check e701164993450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164993898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.var 0)))
theorem wire_e701164993898 : Closed e701164993898 ∧ code e701164993898 = 9497258016106 := by decide
theorem cert_e701164993898 : check e701164993898 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164993962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))) (.var 0)))
theorem wire_e701164993962 : Closed e701164993962 ∧ code e701164993962 = 9497258016170 := by decide
theorem cert_e701164993962 : check e701164993962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164998378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))) (.var 0)))
theorem wire_e701164998378 : Closed e701164998378 ∧ code e701164998378 = 9497258020586 := by decide
theorem cert_e701164998378 : check e701164998378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701164998506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))) (.var 0)))
theorem wire_e701164998506 : Closed e701164998506 ∧ code e701164998506 = 9497258020714 := by decide
theorem cert_e701164998506 : check e701164998506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165004522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.var 0)))
theorem wire_e701165004522 : Closed e701165004522 ∧ code e701165004522 = 9497258026730 := by decide
theorem cert_e701165004522 : check e701165004522 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165004714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.var 0)))
theorem wire_e701165004714 : Closed e701165004714 ∧ code e701165004714 = 9497258026922 := by decide
theorem cert_e701165004714 : check e701165004714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165007722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.var 0)))
theorem wire_e701165007722 : Closed e701165007722 ∧ code e701165007722 = 9497258029930 := by decide
theorem cert_e701165007722 : check e701165007722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165007786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.var 0)))
theorem wire_e701165007786 : Closed e701165007786 ∧ code e701165007786 = 9497258029994 := by decide
theorem cert_e701165007786 : check e701165007786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165219258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701165219258 : Closed e701165219258 ∧ code e701165219258 = 9497258241466 := by decide
theorem cert_e701165219258 : check e701165219258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165219290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701165219290 : Closed e701165219290 ∧ code e701165219290 = 9497258241498 := by decide
theorem cert_e701165219290 : check e701165219290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165219514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701165219514 : Closed e701165219514 ∧ code e701165219514 = 9497258241722 := by decide
theorem cert_e701165219514 : check e701165219514 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165219562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701165219562 : Closed e701165219562 ∧ code e701165219562 = 9497258241770 := by decide
theorem cert_e701165219562 : check e701165219562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165219674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701165219674 : Closed e701165219674 ∧ code e701165219674 = 9497258241882 := by decide
theorem cert_e701165219674 : check e701165219674 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165219690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701165219690 : Closed e701165219690 ∧ code e701165219690 = 9497258241898 := by decide
theorem cert_e701165219690 : check e701165219690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165220794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701165220794 : Closed e701165220794 ∧ code e701165220794 = 9497258243002 := by decide
theorem cert_e701165220794 : check e701165220794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165220826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701165220826 : Closed e701165220826 ∧ code e701165220826 = 9497258243034 := by decide
theorem cert_e701165220826 : check e701165220826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165222330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701165222330 : Closed e701165222330 ∧ code e701165222330 = 9497258244538 := by decide
theorem cert_e701165222330 : check e701165222330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165222378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701165222378 : Closed e701165222378 ∧ code e701165222378 = 9497258244586 := by decide
theorem cert_e701165222378 : check e701165222378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165223130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701165223130 : Closed e701165223130 ∧ code e701165223130 = 9497258245338 := by decide
theorem cert_e701165223130 : check e701165223130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701165223146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701165223146 : Closed e701165223146 ∧ code e701165223146 = 9497258245354 := by decide
theorem cert_e701165223146 : check e701165223146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166040954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.var 0)))
theorem wire_e701166040954 : Closed e701166040954 ∧ code e701166040954 = 9497259063162 := by decide
theorem cert_e701166040954 : check e701166040954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166041018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.var 0)))
theorem wire_e701166041018 : Closed e701166041018 ∧ code e701166041018 = 9497259063226 := by decide
theorem cert_e701166041018 : check e701166041018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166042490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e701166042490 : Closed e701166042490 ∧ code e701166042490 = 9497259064698 := by decide
theorem cert_e701166042490 : check e701166042490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166042602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e701166042602 : Closed e701166042602 ∧ code e701166042602 = 9497259064810 := by decide
theorem cert_e701166042602 : check e701166042602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166042810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701166042810 : Closed e701166042810 ∧ code e701166042810 = 9497259065018 := by decide
theorem cert_e701166042810 : check e701166042810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166042858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701166042858 : Closed e701166042858 ∧ code e701166042858 = 9497259065066 := by decide
theorem cert_e701166042858 : check e701166042858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166047098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.var 0)))
theorem wire_e701166047098 : Closed e701166047098 ∧ code e701166047098 = 9497259069306 := by decide
theorem cert_e701166047098 : check e701166047098 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166047162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.var 0)))
theorem wire_e701166047162 : Closed e701166047162 ∧ code e701166047162 = 9497259069370 := by decide
theorem cert_e701166047162 : check e701166047162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166056314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e701166056314 : Closed e701166056314 ∧ code e701166056314 = 9497259078522 := by decide
theorem cert_e701166056314 : check e701166056314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166056426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e701166056426 : Closed e701166056426 ∧ code e701166056426 = 9497259078634 := by decide
theorem cert_e701166056426 : check e701166056426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166057914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701166057914 : Closed e701166057914 ∧ code e701166057914 = 9497259080122 := by decide
theorem cert_e701166057914 : check e701166057914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166057962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701166057962 : Closed e701166057962 ∧ code e701166057962 = 9497259080170 := by decide
theorem cert_e701166057962 : check e701166057962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166171578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701166171578 : Closed e701166171578 ∧ code e701166171578 = 9497259193786 := by decide
theorem cert_e701166171578 : check e701166171578 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166171610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701166171610 : Closed e701166171610 ∧ code e701166171610 = 9497259193818 := by decide
theorem cert_e701166171610 : check e701166171610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166171834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701166171834 : Closed e701166171834 ∧ code e701166171834 = 9497259194042 := by decide
theorem cert_e701166171834 : check e701166171834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166171882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701166171882 : Closed e701166171882 ∧ code e701166171882 = 9497259194090 := by decide
theorem cert_e701166171882 : check e701166171882 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166171994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701166171994 : Closed e701166171994 ∧ code e701166171994 = 9497259194202 := by decide
theorem cert_e701166171994 : check e701166171994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166172010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701166172010 : Closed e701166172010 ∧ code e701166172010 = 9497259194218 := by decide
theorem cert_e701166172010 : check e701166172010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166172858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701166172858 : Closed e701166172858 ∧ code e701166172858 = 9497259195066 := by decide
theorem cert_e701166172858 : check e701166172858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166172906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701166172906 : Closed e701166172906 ∧ code e701166172906 = 9497259195114 := by decide
theorem cert_e701166172906 : check e701166172906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166173098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701166173098 : Closed e701166173098 ∧ code e701166173098 = 9497259195306 := by decide
theorem cert_e701166173098 : check e701166173098 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166173530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701166173530 : Closed e701166173530 ∧ code e701166173530 = 9497259195738 := by decide
theorem cert_e701166173530 : check e701166173530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166173546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701166173546 : Closed e701166173546 ∧ code e701166173546 = 9497259195754 := by decide
theorem cert_e701166173546 : check e701166173546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166173610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701166173610 : Closed e701166173610 ∧ code e701166173610 = 9497259195818 := by decide
theorem cert_e701166173610 : check e701166173610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166177722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701166177722 : Closed e701166177722 ∧ code e701166177722 = 9497259199930 := by decide
theorem cert_e701166177722 : check e701166177722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166177754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701166177754 : Closed e701166177754 ∧ code e701166177754 = 9497259199962 := by decide
theorem cert_e701166177754 : check e701166177754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166177978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701166177978 : Closed e701166177978 ∧ code e701166177978 = 9497259200186 := by decide
theorem cert_e701166177978 : check e701166177978 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166178026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701166178026 : Closed e701166178026 ∧ code e701166178026 = 9497259200234 := by decide
theorem cert_e701166178026 : check e701166178026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166178138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701166178138 : Closed e701166178138 ∧ code e701166178138 = 9497259200346 := by decide
theorem cert_e701166178138 : check e701166178138 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166178154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701166178154 : Closed e701166178154 ∧ code e701166178154 = 9497259200362 := by decide
theorem cert_e701166178154 : check e701166178154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166179258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701166179258 : Closed e701166179258 ∧ code e701166179258 = 9497259201466 := by decide
theorem cert_e701166179258 : check e701166179258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166179290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701166179290 : Closed e701166179290 ∧ code e701166179290 = 9497259201498 := by decide
theorem cert_e701166179290 : check e701166179290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166180794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701166180794 : Closed e701166180794 ∧ code e701166180794 = 9497259203002 := by decide
theorem cert_e701166180794 : check e701166180794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166180842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701166180842 : Closed e701166180842 ∧ code e701166180842 = 9497259203050 := by decide
theorem cert_e701166180842 : check e701166180842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166181274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166181274 : Closed e701166181274 ∧ code e701166181274 = 9497259203482 := by decide
theorem cert_e701166181274 : check e701166181274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166181594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701166181594 : Closed e701166181594 ∧ code e701166181594 = 9497259203802 := by decide
theorem cert_e701166181594 : check e701166181594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166181610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701166181610 : Closed e701166181610 ∧ code e701166181610 = 9497259203818 := by decide
theorem cert_e701166181610 : check e701166181610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166181786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166181786 : Closed e701166181786 ∧ code e701166181786 = 9497259203994 := by decide
theorem cert_e701166181786 : check e701166181786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166184122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701166184122 : Closed e701166184122 ∧ code e701166184122 = 9497259206330 := by decide
theorem cert_e701166184122 : check e701166184122 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166184170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701166184170 : Closed e701166184170 ∧ code e701166184170 = 9497259206378 := by decide
theorem cert_e701166184170 : check e701166184170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166184362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701166184362 : Closed e701166184362 ∧ code e701166184362 = 9497259206570 := by decide
theorem cert_e701166184362 : check e701166184362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166184890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701166184890 : Closed e701166184890 ∧ code e701166184890 = 9497259207098 := by decide
theorem cert_e701166184890 : check e701166184890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166184938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701166184938 : Closed e701166184938 ∧ code e701166184938 = 9497259207146 := by decide
theorem cert_e701166184938 : check e701166184938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166185370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166185370 : Closed e701166185370 ∧ code e701166185370 = 9497259207578 := by decide
theorem cert_e701166185370 : check e701166185370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166186090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701166186090 : Closed e701166186090 ∧ code e701166186090 = 9497259208298 := by decide
theorem cert_e701166186090 : check e701166186090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166186138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166186138 : Closed e701166186138 ∧ code e701166186138 = 9497259208346 := by decide
theorem cert_e701166186138 : check e701166186138 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166187354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701166187354 : Closed e701166187354 ∧ code e701166187354 = 9497259209562 := by decide
theorem cert_e701166187354 : check e701166187354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166187370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701166187370 : Closed e701166187370 ∧ code e701166187370 = 9497259209578 := by decide
theorem cert_e701166187370 : check e701166187370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166187434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701166187434 : Closed e701166187434 ∧ code e701166187434 = 9497259209642 := by decide
theorem cert_e701166187434 : check e701166187434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166187738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701166187738 : Closed e701166187738 ∧ code e701166187738 = 9497259209946 := by decide
theorem cert_e701166187738 : check e701166187738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166187754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701166187754 : Closed e701166187754 ∧ code e701166187754 = 9497259209962 := by decide
theorem cert_e701166187754 : check e701166187754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166187930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166187930 : Closed e701166187930 ∧ code e701166187930 = 9497259210138 := by decide
theorem cert_e701166187930 : check e701166187930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166188138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701166188138 : Closed e701166188138 ∧ code e701166188138 = 9497259210346 := by decide
theorem cert_e701166188138 : check e701166188138 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166188186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166188186 : Closed e701166188186 ∧ code e701166188186 = 9497259210394 := by decide
theorem cert_e701166188186 : check e701166188186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166194554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.var 0)))
theorem wire_e701166194554 : Closed e701166194554 ∧ code e701166194554 = 9497259216762 := by decide
theorem cert_e701166194554 : check e701166194554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166194618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.var 0)))
theorem wire_e701166194618 : Closed e701166194618 ∧ code e701166194618 = 9497259216826 := by decide
theorem cert_e701166194618 : check e701166194618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166202298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701166202298 : Closed e701166202298 ∧ code e701166202298 = 9497259224506 := by decide
theorem cert_e701166202298 : check e701166202298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166202330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701166202330 : Closed e701166202330 ∧ code e701166202330 = 9497259224538 := by decide
theorem cert_e701166202330 : check e701166202330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166202554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701166202554 : Closed e701166202554 ∧ code e701166202554 = 9497259224762 := by decide
theorem cert_e701166202554 : check e701166202554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166202602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701166202602 : Closed e701166202602 ∧ code e701166202602 = 9497259224810 := by decide
theorem cert_e701166202602 : check e701166202602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166202714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701166202714 : Closed e701166202714 ∧ code e701166202714 = 9497259224922 := by decide
theorem cert_e701166202714 : check e701166202714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166202730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701166202730 : Closed e701166202730 ∧ code e701166202730 = 9497259224938 := by decide
theorem cert_e701166202730 : check e701166202730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166203834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701166203834 : Closed e701166203834 ∧ code e701166203834 = 9497259226042 := by decide
theorem cert_e701166203834 : check e701166203834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166203866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701166203866 : Closed e701166203866 ∧ code e701166203866 = 9497259226074 := by decide
theorem cert_e701166203866 : check e701166203866 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166205370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701166205370 : Closed e701166205370 ∧ code e701166205370 = 9497259227578 := by decide
theorem cert_e701166205370 : check e701166205370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166205418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701166205418 : Closed e701166205418 ∧ code e701166205418 = 9497259227626 := by decide
theorem cert_e701166205418 : check e701166205418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166205850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166205850 : Closed e701166205850 ∧ code e701166205850 = 9497259228058 := by decide
theorem cert_e701166205850 : check e701166205850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166206170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701166206170 : Closed e701166206170 ∧ code e701166206170 = 9497259228378 := by decide
theorem cert_e701166206170 : check e701166206170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166206186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701166206186 : Closed e701166206186 ∧ code e701166206186 = 9497259228394 := by decide
theorem cert_e701166206186 : check e701166206186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166206362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166206362 : Closed e701166206362 ∧ code e701166206362 = 9497259228570 := by decide
theorem cert_e701166206362 : check e701166206362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166225274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e701166225274 : Closed e701166225274 ∧ code e701166225274 = 9497259247482 := by decide
theorem cert_e701166225274 : check e701166225274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166225370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e701166225370 : Closed e701166225370 ∧ code e701166225370 = 9497259247578 := by decide
theorem cert_e701166225370 : check e701166225370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166229178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701166229178 : Closed e701166229178 ∧ code e701166229178 = 9497259251386 := by decide
theorem cert_e701166229178 : check e701166229178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166229226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701166229226 : Closed e701166229226 ∧ code e701166229226 = 9497259251434 := by decide
theorem cert_e701166229226 : check e701166229226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166229418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701166229418 : Closed e701166229418 ∧ code e701166229418 = 9497259251626 := by decide
theorem cert_e701166229418 : check e701166229418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166229946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701166229946 : Closed e701166229946 ∧ code e701166229946 = 9497259252154 := by decide
theorem cert_e701166229946 : check e701166229946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166229994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701166229994 : Closed e701166229994 ∧ code e701166229994 = 9497259252202 := by decide
theorem cert_e701166229994 : check e701166229994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166230426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166230426 : Closed e701166230426 ∧ code e701166230426 = 9497259252634 := by decide
theorem cert_e701166230426 : check e701166230426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166231146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701166231146 : Closed e701166231146 ∧ code e701166231146 = 9497259253354 := by decide
theorem cert_e701166231146 : check e701166231146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166231194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166231194 : Closed e701166231194 ∧ code e701166231194 = 9497259253402 := by decide
theorem cert_e701166231194 : check e701166231194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166240698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701166240698 : Closed e701166240698 ∧ code e701166240698 = 9497259262906 := by decide
theorem cert_e701166240698 : check e701166240698 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166240730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701166240730 : Closed e701166240730 ∧ code e701166240730 = 9497259262938 := by decide
theorem cert_e701166240730 : check e701166240730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166242650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701166242650 : Closed e701166242650 ∧ code e701166242650 = 9497259264858 := by decide
theorem cert_e701166242650 : check e701166242650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166242666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701166242666 : Closed e701166242666 ∧ code e701166242666 = 9497259264874 := by decide
theorem cert_e701166242666 : check e701166242666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166242730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701166242730 : Closed e701166242730 ∧ code e701166242730 = 9497259264938 := by decide
theorem cert_e701166242730 : check e701166242730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166243034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701166243034 : Closed e701166243034 ∧ code e701166243034 = 9497259265242 := by decide
theorem cert_e701166243034 : check e701166243034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166243050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701166243050 : Closed e701166243050 ∧ code e701166243050 = 9497259265258 := by decide
theorem cert_e701166243050 : check e701166243050 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166243226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166243226 : Closed e701166243226 ∧ code e701166243226 = 9497259265434 := by decide
theorem cert_e701166243226 : check e701166243226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166243434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701166243434 : Closed e701166243434 ∧ code e701166243434 = 9497259265642 := by decide
theorem cert_e701166243434 : check e701166243434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166243482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701166243482 : Closed e701166243482 ∧ code e701166243482 = 9497259265690 := by decide
theorem cert_e701166243482 : check e701166243482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166792122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701166792122 : Closed e701166792122 ∧ code e701166792122 = 9497259814330 := by decide
theorem cert_e701166792122 : check e701166792122 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166792154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701166792154 : Closed e701166792154 ∧ code e701166792154 = 9497259814362 := by decide
theorem cert_e701166792154 : check e701166792154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166792378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701166792378 : Closed e701166792378 ∧ code e701166792378 = 9497259814586 := by decide
theorem cert_e701166792378 : check e701166792378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166792426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701166792426 : Closed e701166792426 ∧ code e701166792426 = 9497259814634 := by decide
theorem cert_e701166792426 : check e701166792426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166792538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701166792538 : Closed e701166792538 ∧ code e701166792538 = 9497259814746 := by decide
theorem cert_e701166792538 : check e701166792538 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166792554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701166792554 : Closed e701166792554 ∧ code e701166792554 = 9497259814762 := by decide
theorem cert_e701166792554 : check e701166792554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166793658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701166793658 : Closed e701166793658 ∧ code e701166793658 = 9497259815866 := by decide
theorem cert_e701166793658 : check e701166793658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166793690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701166793690 : Closed e701166793690 ∧ code e701166793690 = 9497259815898 := by decide
theorem cert_e701166793690 : check e701166793690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166795194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701166795194 : Closed e701166795194 ∧ code e701166795194 = 9497259817402 := by decide
theorem cert_e701166795194 : check e701166795194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166795242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701166795242 : Closed e701166795242 ∧ code e701166795242 = 9497259817450 := by decide
theorem cert_e701166795242 : check e701166795242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166795994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701166795994 : Closed e701166795994 ∧ code e701166795994 = 9497259818202 := by decide
theorem cert_e701166795994 : check e701166795994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701166796010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701166796010 : Closed e701166796010 ∧ code e701166796010 = 9497259818218 := by decide
theorem cert_e701166796010 : check e701166796010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701168114554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.var 0)))
theorem wire_e701168114554 : Closed e701168114554 ∧ code e701168114554 = 9497261136762 := by decide
theorem cert_e701168114554 : check e701168114554 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168114650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.var 0)))
theorem wire_e701168114650 : Closed e701168114650 ∧ code e701168114650 = 9497261136858 := by decide
theorem cert_e701168114650 : check e701168114650 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168115066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e701168115066 : Closed e701168115066 ∧ code e701168115066 = 9497261137274 := by decide
theorem cert_e701168115066 : check e701168115066 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168115178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e701168115178 : Closed e701168115178 ∧ code e701168115178 = 9497261137386 := by decide
private def t_e701168115178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.var 0)))
theorem cert_e701168115178 : ¬ IsSelfInterpreter e701168115178 :=
  wSource (t := t_e701168115178) (replay_sound (ps := []) (t := e701168115178) (by decide)) (by decide)
def e701168115546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701168115546 : Closed e701168115546 ∧ code e701168115546 = 9497261137754 := by decide
theorem cert_e701168115546 : check e701168115546 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168115562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701168115562 : Closed e701168115562 ∧ code e701168115562 = 9497261137770 := by decide
private def t_e701168115562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.var 0)))
theorem cert_e701168115562 : ¬ IsSelfInterpreter e701168115562 :=
  wSource (t := t_e701168115562) (replay_sound (ps := []) (t := e701168115562) (by decide)) (by decide)
def e701168117626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e701168117626 : Closed e701168117626 ∧ code e701168117626 = 9497261139834 := by decide
theorem cert_e701168117626 : check e701168117626 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168117722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e701168117722 : Closed e701168117722 ∧ code e701168117722 = 9497261139930 := by decide
theorem cert_e701168117722 : check e701168117722 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168120698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e701168120698 : Closed e701168120698 ∧ code e701168120698 = 9497261142906 := by decide
theorem cert_e701168120698 : check e701168120698 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168120810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e701168120810 : Closed e701168120810 ∧ code e701168120810 = 9497261143018 := by decide
theorem cert_e701168120810 : check e701168120810 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e701168115178
#print axioms Blc.Floor43.cert_e701168115562
