import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373470234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373470234 : Closed e2393373470234 ∧ code e2393373470234 = 11189466492442 := by decide
theorem cert_e2393373470234 : check e2393373470234 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373470306 : Closed e2393373470306 ∧ code e2393373470306 = 11189466492514 := by decide
theorem cert_e2393373470306 : check e2393373470306 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373470318 : Closed e2393373470318 ∧ code e2393373470318 = 11189466492526 := by decide
theorem cert_e2393373470318 : check e2393373470318 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373470326 : Closed e2393373470326 ∧ code e2393373470326 = 11189466492534 := by decide
theorem cert_e2393373470326 : check e2393373470326 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373470330 : Closed e2393373470330 ∧ code e2393373470330 = 11189466492538 := by decide
theorem cert_e2393373470330 : check e2393373470330 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2393373470838 : Closed e2393373470838 ∧ code e2393373470838 = 11189466493046 := by decide
theorem cert_e2393373470838 : check e2393373470838 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2393373470842 : Closed e2393373470842 ∧ code e2393373470842 = 11189466493050 := by decide
theorem cert_e2393373470842 : check e2393373470842 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2393373470934 : Closed e2393373470934 ∧ code e2393373470934 = 11189466493142 := by decide
theorem cert_e2393373470934 : check e2393373470934 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373471030 : Closed e2393373471030 ∧ code e2393373471030 = 11189466493238 := by decide
theorem cert_e2393373471030 : check e2393373471030 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373471034 : Closed e2393373471034 ∧ code e2393373471034 = 11189466493242 := by decide
theorem cert_e2393373471034 : check e2393373471034 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2393373471118 : Closed e2393373471118 ∧ code e2393373471118 = 11189466493326 := by decide
theorem cert_e2393373471118 : check e2393373471118 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2393373471174 : Closed e2393373471174 ∧ code e2393373471174 = 11189466493382 := by decide
theorem cert_e2393373471174 : check e2393373471174 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2393373471510 : Closed e2393373471510 ∧ code e2393373471510 = 11189466493718 := by decide
theorem cert_e2393373471510 : check e2393373471510 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2393373471586 : Closed e2393373471586 ∧ code e2393373471586 = 11189466493794 := by decide
theorem cert_e2393373471586 : check e2393373471586 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2393373471598 : Closed e2393373471598 ∧ code e2393373471598 = 11189466493806 := by decide
theorem cert_e2393373471598 : check e2393373471598 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2393373471606 : Closed e2393373471606 ∧ code e2393373471606 = 11189466493814 := by decide
theorem cert_e2393373471606 : check e2393373471606 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2393373471626 : Closed e2393373471626 ∧ code e2393373471626 = 11189466493834 := by decide
theorem cert_e2393373471626 : check e2393373471626 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2393373471650 : Closed e2393373471650 ∧ code e2393373471650 = 11189466493858 := by decide
theorem cert_e2393373471650 : check e2393373471650 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2393373471662 : Closed e2393373471662 ∧ code e2393373471662 = 11189466493870 := by decide
theorem cert_e2393373471662 : check e2393373471662 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2393373471670 : Closed e2393373471670 ∧ code e2393373471670 = 11189466493878 := by decide
theorem cert_e2393373471670 : check e2393373471670 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2393373471674 : Closed e2393373471674 ∧ code e2393373471674 = 11189466493882 := by decide
theorem cert_e2393373471674 : check e2393373471674 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2393373471702 : Closed e2393373471702 ∧ code e2393373471702 = 11189466493910 := by decide
theorem cert_e2393373471702 : check e2393373471702 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2393373471706 : Closed e2393373471706 ∧ code e2393373471706 = 11189466493914 := by decide
theorem cert_e2393373471706 : check e2393373471706 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2393373471774 : Closed e2393373471774 ∧ code e2393373471774 = 11189466493982 := by decide
theorem cert_e2393373471774 : check e2393373471774 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2393373471970 : Closed e2393373471970 ∧ code e2393373471970 = 11189466494178 := by decide
theorem cert_e2393373471970 : check e2393373471970 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373471982 : Closed e2393373471982 ∧ code e2393373471982 = 11189466494190 := by decide
theorem cert_e2393373471982 : check e2393373471982 [[],[.left],[]] .sourceHead = true := by decide
def e2393373471990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373471990 : Closed e2393373471990 ∧ code e2393373471990 = 11189466494198 := by decide
theorem cert_e2393373471990 : check e2393373471990 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2393373472270 : Closed e2393373472270 ∧ code e2393373472270 = 11189466494478 := by decide
theorem cert_e2393373472270 : check e2393373472270 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373472282 : Closed e2393373472282 ∧ code e2393373472282 = 11189466494490 := by decide
theorem cert_e2393373472282 : check e2393373472282 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373472354 : Closed e2393373472354 ∧ code e2393373472354 = 11189466494562 := by decide
theorem cert_e2393373472354 : check e2393373472354 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373472366 : Closed e2393373472366 ∧ code e2393373472366 = 11189466494574 := by decide
theorem cert_e2393373472366 : check e2393373472366 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373472374 : Closed e2393373472374 ∧ code e2393373472374 = 11189466494582 := by decide
theorem cert_e2393373472374 : check e2393373472374 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373472378 : Closed e2393373472378 ∧ code e2393373472378 = 11189466494586 := by decide
theorem cert_e2393373472378 : check e2393373472378 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373472566 : Closed e2393373472566 ∧ code e2393373472566 = 11189466494774 := by decide
theorem cert_e2393373472566 : check e2393373472566 [[],[.left],[]] .sourceHead = true := by decide
def e2393373472570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373472570 : Closed e2393373472570 ∧ code e2393373472570 = 11189466494778 := by decide
theorem cert_e2393373472570 : check e2393373472570 [[],[.left],[]] .sourceHead = true := by decide
def e2393373477742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393373477742 : Closed e2393373477742 ∧ code e2393373477742 = 11189466499950 := by decide
theorem cert_e2393373477742 : check e2393373477742 [[],[.left],[]] .chain = true := by decide
def e2393373477750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393373477750 : Closed e2393373477750 ∧ code e2393373477750 = 11189466499958 := by decide
theorem cert_e2393373477750 : check e2393373477750 [[],[.left],[]] .chain = true := by decide
def e2393373477806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393373477806 : Closed e2393373477806 ∧ code e2393373477806 = 11189466500014 := by decide
theorem cert_e2393373477806 : check e2393373477806 [[],[.left],[]] .chain = true := by decide
def e2393373477818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393373477818 : Closed e2393373477818 ∧ code e2393373477818 = 11189466500026 := by decide
theorem cert_e2393373477818 : check e2393373477818 [[],[.left],[]] .chain = true := by decide
def e2393373477846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393373477846 : Closed e2393373477846 ∧ code e2393373477846 = 11189466500054 := by decide
theorem cert_e2393373477846 : check e2393373477846 [[],[.left],[]] .chain = true := by decide
def e2393373477850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393373477850 : Closed e2393373477850 ∧ code e2393373477850 = 11189466500058 := by decide
theorem cert_e2393373477850 : check e2393373477850 [[],[.left],[]] .chain = true := by decide
def e2393373478126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393373478126 : Closed e2393373478126 ∧ code e2393373478126 = 11189466500334 := by decide
theorem cert_e2393373478126 : check e2393373478126 [[],[.left],[]] .chain = true := by decide
def e2393373478134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393373478134 : Closed e2393373478134 ∧ code e2393373478134 = 11189466500342 := by decide
theorem cert_e2393373478134 : check e2393373478134 [[],[.left],[]] .chain = true := by decide
def e2393373478510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393373478510 : Closed e2393373478510 ∧ code e2393373478510 = 11189466500718 := by decide
theorem cert_e2393373478510 : check e2393373478510 [[],[.left],[]] .chain = true := by decide
def e2393373478522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393373478522 : Closed e2393373478522 ∧ code e2393373478522 = 11189466500730 := by decide
theorem cert_e2393373478522 : check e2393373478522 [[],[.left],[]] .chain = true := by decide
def e2393373478710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393373478710 : Closed e2393373478710 ∧ code e2393373478710 = 11189466500918 := by decide
theorem cert_e2393373478710 : check e2393373478710 [[],[.left],[]] .chain = true := by decide
def e2393373478714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393373478714 : Closed e2393373478714 ∧ code e2393373478714 = 11189466500922 := by decide
theorem cert_e2393373478714 : check e2393373478714 [[],[.left],[]] .chain = true := by decide
def e2393373486638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393373486638 : Closed e2393373486638 ∧ code e2393373486638 = 11189466508846 := by decide
theorem cert_e2393373486638 : check e2393373486638 [[],[.left],[]] .sourceHead = true := by decide
def e2393373486818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393373486818 : Closed e2393373486818 ∧ code e2393373486818 = 11189466509026 := by decide
theorem cert_e2393373486818 : check e2393373486818 [[],[.left],[]] .sourceHead = true := by decide
def e2393373486830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2393373486830 : Closed e2393373486830 ∧ code e2393373486830 = 11189466509038 := by decide
theorem cert_e2393373486830 : check e2393373486830 [[],[.left],[]] .sourceHead = true := by decide
def e2393373486870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393373486870 : Closed e2393373486870 ∧ code e2393373486870 = 11189466509078 := by decide
theorem cert_e2393373486870 : check e2393373486870 [[],[.left],[]] .sourceHead = true := by decide
def e2393373486946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393373486946 : Closed e2393373486946 ∧ code e2393373486946 = 11189466509154 := by decide
theorem cert_e2393373486946 : check e2393373486946 [[],[.left],[]] .sourceHead = true := by decide
def e2393373486958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2393373486958 : Closed e2393373486958 ∧ code e2393373486958 = 11189466509166 := by decide
theorem cert_e2393373486958 : check e2393373486958 [[],[.left],[]] .sourceHead = true := by decide
def e2393373486966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2393373486966 : Closed e2393373486966 ∧ code e2393373486966 = 11189466509174 := by decide
theorem cert_e2393373486966 : check e2393373486966 [[],[.left],[]] .sourceHead = true := by decide
def e2393373489214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2393373489214 : Closed e2393373489214 ∧ code e2393373489214 = 11189466511422 := by decide
theorem cert_e2393373489214 : check e2393373489214 [[],[.left],[]] .sourceHead = true := by decide
def e2393373489634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393373489634 : Closed e2393373489634 ∧ code e2393373489634 = 11189466511842 := by decide
theorem cert_e2393373489634 : check e2393373489634 [[],[.left],[]] .sourceHead = true := by decide
def e2393373489646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2393373489646 : Closed e2393373489646 ∧ code e2393373489646 = 11189466511854 := by decide
theorem cert_e2393373489646 : check e2393373489646 [[],[.left],[]] .sourceHead = true := by decide
def e2393373490206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2393373490206 : Closed e2393373490206 ∧ code e2393373490206 = 11189466512414 := by decide
theorem cert_e2393373490206 : check e2393373490206 [[],[.left],[]] .sourceHead = true := by decide
def e2393373490402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393373490402 : Closed e2393373490402 ∧ code e2393373490402 = 11189466512610 := by decide
theorem cert_e2393373490402 : check e2393373490402 [[],[.left],[]] .sourceHead = true := by decide
def e2393373490414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373490414 : Closed e2393373490414 ∧ code e2393373490414 = 11189466512622 := by decide
theorem cert_e2393373490414 : check e2393373490414 [[],[.left],[]] .sourceHead = true := by decide
def e2393373490422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373490422 : Closed e2393373490422 ∧ code e2393373490422 = 11189466512630 := by decide
theorem cert_e2393373490422 : check e2393373490422 [[],[.left],[]] .sourceHead = true := by decide
def e2393373509598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2393373509598 : Closed e2393373509598 ∧ code e2393373509598 = 11189466531806 := by decide
theorem cert_e2393373509598 : check e2393373509598 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393373513262 : Closed e2393373513262 ∧ code e2393373513262 = 11189466535470 := by decide
theorem cert_e2393373513262 : check e2393373513262 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393373513442 : Closed e2393373513442 ∧ code e2393373513442 = 11189466535650 := by decide
theorem cert_e2393373513442 : check e2393373513442 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2393373513454 : Closed e2393373513454 ∧ code e2393373513454 = 11189466535662 := by decide
theorem cert_e2393373513454 : check e2393373513454 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2393373513582 : Closed e2393373513582 ∧ code e2393373513582 = 11189466535790 := by decide
theorem cert_e2393373513582 : check e2393373513582 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2393373513590 : Closed e2393373513590 ∧ code e2393373513590 = 11189466535798 := by decide
theorem cert_e2393373513590 : check e2393373513590 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373513610 : Closed e2393373513610 ∧ code e2393373513610 = 11189466535818 := by decide
theorem cert_e2393373513610 : check e2393373513610 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373513634 : Closed e2393373513634 ∧ code e2393373513634 = 11189466535842 := by decide
theorem cert_e2393373513634 : check e2393373513634 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2393373513646 : Closed e2393373513646 ∧ code e2393373513646 = 11189466535854 := by decide
theorem cert_e2393373513646 : check e2393373513646 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2393373513654 : Closed e2393373513654 ∧ code e2393373513654 = 11189466535862 := by decide
theorem cert_e2393373513654 : check e2393373513654 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2393373513658 : Closed e2393373513658 ∧ code e2393373513658 = 11189466535866 := by decide
theorem cert_e2393373513658 : check e2393373513658 [[],[.left],[]] .sourceHead = true := by decide
def e2393373513790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2393373513790 : Closed e2393373513790 ∧ code e2393373513790 = 11189466535998 := by decide
theorem cert_e2393373513790 : check e2393373513790 [[],[.left],[]] .sourceHead = true := by decide
def e2393373514210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393373514210 : Closed e2393373514210 ∧ code e2393373514210 = 11189466536418 := by decide
theorem cert_e2393373514210 : check e2393373514210 [[],[.left],[]] .sourceHead = true := by decide
def e2393373514222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2393373514222 : Closed e2393373514222 ∧ code e2393373514222 = 11189466536430 := by decide
theorem cert_e2393373514222 : check e2393373514222 [[],[.left],[]] .sourceHead = true := by decide
def e2393373514990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373514990 : Closed e2393373514990 ∧ code e2393373514990 = 11189466537198 := by decide
theorem cert_e2393373514990 : check e2393373514990 [[],[.left],[]] .sourceHead = true := by decide
def e2393373514998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373514998 : Closed e2393373514998 ∧ code e2393373514998 = 11189466537206 := by decide
theorem cert_e2393373514998 : check e2393373514998 [[],[.left],[]] .sourceHead = true := by decide
def e2393373515278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373515278 : Closed e2393373515278 ∧ code e2393373515278 = 11189466537486 := by decide
theorem cert_e2393373515278 : check e2393373515278 [[],[.left],[]] .sourceHead = true := by decide
def e2393373515290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373515290 : Closed e2393373515290 ∧ code e2393373515290 = 11189466537498 := by decide
theorem cert_e2393373515290 : check e2393373515290 [[],[.left],[]] .sourceHead = true := by decide
def e2393373515362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373515362 : Closed e2393373515362 ∧ code e2393373515362 = 11189466537570 := by decide
theorem cert_e2393373515362 : check e2393373515362 [[],[.left],[]] .sourceHead = true := by decide
def e2393373515374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373515374 : Closed e2393373515374 ∧ code e2393373515374 = 11189466537582 := by decide
theorem cert_e2393373515374 : check e2393373515374 [[],[.left],[]] .sourceHead = true := by decide
def e2393373515382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373515382 : Closed e2393373515382 ∧ code e2393373515382 = 11189466537590 := by decide
theorem cert_e2393373515382 : check e2393373515382 [[],[.left],[]] .sourceHead = true := by decide
def e2393373515386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373515386 : Closed e2393373515386 ∧ code e2393373515386 = 11189466537594 := by decide
theorem cert_e2393373515386 : check e2393373515386 [[],[.left],[]] .sourceHead = true := by decide
def e2393373524958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2393373524958 : Closed e2393373524958 ∧ code e2393373524958 = 11189466547166 := by decide
theorem cert_e2393373524958 : check e2393373524958 [[],[.left],[]] .sourceHead = true := by decide
def e2393373524974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2393373524974 : Closed e2393373524974 ∧ code e2393373524974 = 11189466547182 := by decide
theorem cert_e2393373524974 : check e2393373524974 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393373526806 : Closed e2393373526806 ∧ code e2393373526806 = 11189466549014 := by decide
theorem cert_e2393373526806 : check e2393373526806 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393373526882 : Closed e2393373526882 ∧ code e2393373526882 = 11189466549090 := by decide
theorem cert_e2393373526882 : check e2393373526882 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393373526894 : Closed e2393373526894 ∧ code e2393373526894 = 11189466549102 := by decide
theorem cert_e2393373526894 : check e2393373526894 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393373526902 : Closed e2393373526902 ∧ code e2393373526902 = 11189466549110 := by decide
theorem cert_e2393373526902 : check e2393373526902 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373526922 : Closed e2393373526922 ∧ code e2393373526922 = 11189466549130 := by decide
theorem cert_e2393373526922 : check e2393373526922 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373526946 : Closed e2393373526946 ∧ code e2393373526946 = 11189466549154 := by decide
theorem cert_e2393373526946 : check e2393373526946 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393373526958 : Closed e2393373526958 ∧ code e2393373526958 = 11189466549166 := by decide
theorem cert_e2393373526958 : check e2393373526958 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2393373526966 : Closed e2393373526966 ∧ code e2393373526966 = 11189466549174 := by decide
theorem cert_e2393373526966 : check e2393373526966 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393373526970 : Closed e2393373526970 ∧ code e2393373526970 = 11189466549178 := by decide
theorem cert_e2393373526970 : check e2393373526970 [[],[.left],[]] .sourceHead = true := by decide
def e2393373526998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393373526998 : Closed e2393373526998 ∧ code e2393373526998 = 11189466549206 := by decide
theorem cert_e2393373526998 : check e2393373526998 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393373527002 : Closed e2393373527002 ∧ code e2393373527002 = 11189466549210 := by decide
theorem cert_e2393373527002 : check e2393373527002 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2393373527070 : Closed e2393373527070 ∧ code e2393373527070 = 11189466549278 := by decide
theorem cert_e2393373527070 : check e2393373527070 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393373527266 : Closed e2393373527266 ∧ code e2393373527266 = 11189466549474 := by decide
theorem cert_e2393373527266 : check e2393373527266 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373527278 : Closed e2393373527278 ∧ code e2393373527278 = 11189466549486 := by decide
theorem cert_e2393373527278 : check e2393373527278 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373527286 : Closed e2393373527286 ∧ code e2393373527286 = 11189466549494 := by decide
theorem cert_e2393373527286 : check e2393373527286 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373527566 : Closed e2393373527566 ∧ code e2393373527566 = 11189466549774 := by decide
theorem cert_e2393373527566 : check e2393373527566 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373527578 : Closed e2393373527578 ∧ code e2393373527578 = 11189466549786 := by decide
theorem cert_e2393373527578 : check e2393373527578 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373527650 : Closed e2393373527650 ∧ code e2393373527650 = 11189466549858 := by decide
theorem cert_e2393373527650 : check e2393373527650 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373527662 : Closed e2393373527662 ∧ code e2393373527662 = 11189466549870 := by decide
theorem cert_e2393373527662 : check e2393373527662 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373527670 : Closed e2393373527670 ∧ code e2393373527670 = 11189466549878 := by decide
theorem cert_e2393373527670 : check e2393373527670 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373527674 : Closed e2393373527674 ∧ code e2393373527674 = 11189466549882 := by decide
theorem cert_e2393373527674 : check e2393373527674 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373527862 : Closed e2393373527862 ∧ code e2393373527862 = 11189466550070 := by decide
theorem cert_e2393373527862 : check e2393373527862 [[],[.left],[]] .sourceHead = true := by decide
def e2393373527866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373527866 : Closed e2393373527866 ∧ code e2393373527866 = 11189466550074 := by decide
theorem cert_e2393373527866 : check e2393373527866 [[],[.left],[]] .sourceHead = true := by decide
def e2393373544046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373544046 : Closed e2393373544046 ∧ code e2393373544046 = 11189466566254 := by decide
theorem cert_e2393373544046 : check e2393373544046 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373544058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373544058 : Closed e2393373544058 ∧ code e2393373544058 = 11189466566266 := by decide
theorem cert_e2393373544058 : check e2393373544058 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373544346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373544346 : Closed e2393373544346 ∧ code e2393373544346 = 11189466566554 := by decide
theorem cert_e2393373544346 : check e2393373544346 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373547118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373547118 : Closed e2393373547118 ∧ code e2393373547118 = 11189466569326 := by decide
theorem cert_e2393373547118 : check e2393373547118 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373547130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373547130 : Closed e2393373547130 ∧ code e2393373547130 = 11189466569338 := by decide
theorem cert_e2393373547130 : check e2393373547130 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .width = true := by decide
def e2393373548014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2))))))
theorem wire_e2393373548014 : Closed e2393373548014 ∧ code e2393373548014 = 11189466570222 := by decide
theorem cert_e2393373548014 : check e2393373548014 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373548398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2))))))
theorem wire_e2393373548398 : Closed e2393373548398 ∧ code e2393373548398 = 11189466570606 := by decide
theorem cert_e2393373548398 : check e2393373548398 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373548410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0))))))
theorem wire_e2393373548410 : Closed e2393373548410 ∧ code e2393373548410 = 11189466570618 := by decide
theorem cert_e2393373548410 : checkPay e2393373548410 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393373549998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2393373549998 : Closed e2393373549998 ∧ code e2393373549998 = 11189466572206 := by decide
theorem cert_e2393373549998 : check e2393373549998 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373550010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2393373550010 : Closed e2393373550010 ∧ code e2393373550010 = 11189466572218 := by decide
theorem cert_e2393373550010 : check e2393373550010 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373550058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2393373550058 : Closed e2393373550058 ∧ code e2393373550058 = 11189466572266 := by decide
theorem cert_e2393373550058 : check e2393373550058 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373550190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373550190 : Closed e2393373550190 ∧ code e2393373550190 = 11189466572398 := by decide
theorem cert_e2393373550190 : check e2393373550190 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373550202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373550202 : Closed e2393373550202 ∧ code e2393373550202 = 11189466572410 := by decide
theorem cert_e2393373550202 : check e2393373550202 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373550490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2393373550490 : Closed e2393373550490 ∧ code e2393373550490 = 11189466572698 := by decide
theorem cert_e2393373550490 : check e2393373550490 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373553438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2393373553438 : Closed e2393373553438 ∧ code e2393373553438 = 11189466575646 := by decide
theorem cert_e2393373553438 : check e2393373553438 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373553606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2393373553606 : Closed e2393373553606 ∧ code e2393373553606 = 11189466575814 := by decide
theorem cert_e2393373553606 : check e2393373553606 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373555910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2393373555910 : Closed e2393373555910 ∧ code e2393373555910 = 11189466578118 := by decide
theorem cert_e2393373555910 : check e2393373555910 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373563054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2393373563054 : Closed e2393373563054 ∧ code e2393373563054 = 11189466585262 := by decide
theorem cert_e2393373563054 : check e2393373563054 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373563066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2393373563066 : Closed e2393373563066 ∧ code e2393373563066 = 11189466585274 := by decide
theorem cert_e2393373563066 : check e2393373563066 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373563438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2393373563438 : Closed e2393373563438 ∧ code e2393373563438 = 11189466585646 := by decide
theorem cert_e2393373563438 : check e2393373563438 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373563618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2393373563618 : Closed e2393373563618 ∧ code e2393373563618 = 11189466585826 := by decide
theorem cert_e2393373563618 : check e2393373563618 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373563630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2393373563630 : Closed e2393373563630 ∧ code e2393373563630 = 11189466585838 := by decide
theorem cert_e2393373563630 : check e2393373563630 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373563758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2393373563758 : Closed e2393373563758 ∧ code e2393373563758 = 11189466585966 := by decide
theorem cert_e2393373563758 : check e2393373563758 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373563766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2393373563766 : Closed e2393373563766 ∧ code e2393373563766 = 11189466585974 := by decide
theorem cert_e2393373563766 : check e2393373563766 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373563786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373563786 : Closed e2393373563786 ∧ code e2393373563786 = 11189466585994 := by decide
theorem cert_e2393373563786 : check e2393373563786 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373563810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373563810 : Closed e2393373563810 ∧ code e2393373563810 = 11189466586018 := by decide
theorem cert_e2393373563810 : check e2393373563810 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373563822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2393373563822 : Closed e2393373563822 ∧ code e2393373563822 = 11189466586030 := by decide
theorem cert_e2393373563822 : check e2393373563822 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373563830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2393373563830 : Closed e2393373563830 ∧ code e2393373563830 = 11189466586038 := by decide
theorem cert_e2393373563830 : check e2393373563830 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373563834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2393373563834 : Closed e2393373563834 ∧ code e2393373563834 = 11189466586042 := by decide
theorem cert_e2393373563834 : checkPay e2393373563834 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left]] = true := by decide
def e2393373564270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2393373564270 : Closed e2393373564270 ∧ code e2393373564270 = 11189466586478 := by decide
theorem cert_e2393373564270 : check e2393373564270 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373564278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2393373564278 : Closed e2393373564278 ∧ code e2393373564278 = 11189466586486 := by decide
theorem cert_e2393373564278 : check e2393373564278 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373564334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2393373564334 : Closed e2393373564334 ∧ code e2393373564334 = 11189466586542 := by decide
theorem cert_e2393373564334 : check e2393373564334 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373564346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2393373564346 : Closed e2393373564346 ∧ code e2393373564346 = 11189466586554 := by decide
theorem cert_e2393373564346 : checkPay e2393373564346 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393373564374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2393373564374 : Closed e2393373564374 ∧ code e2393373564374 = 11189466586582 := by decide
theorem cert_e2393373564374 : check e2393373564374 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373564378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2393373564378 : Closed e2393373564378 ∧ code e2393373564378 = 11189466586586 := by decide
theorem cert_e2393373564378 : checkPay e2393373564378 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393373564458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2393373564458 : Closed e2393373564458 ∧ code e2393373564458 = 11189466586666 := by decide
theorem cert_e2393373564458 : check e2393373564458 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373564554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373564554 : Closed e2393373564554 ∧ code e2393373564554 = 11189466586762 := by decide
theorem cert_e2393373564554 : check e2393373564554 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373564578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373564578 : Closed e2393373564578 ∧ code e2393373564578 = 11189466586786 := by decide
theorem cert_e2393373564578 : check e2393373564578 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373564590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2393373564590 : Closed e2393373564590 ∧ code e2393373564590 = 11189466586798 := by decide
theorem cert_e2393373564590 : check e2393373564590 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373564598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2393373564598 : Closed e2393373564598 ∧ code e2393373564598 = 11189466586806 := by decide
theorem cert_e2393373564598 : check e2393373564598 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373564602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2393373564602 : Closed e2393373564602 ∧ code e2393373564602 = 11189466586810 := by decide
theorem cert_e2393373564602 : checkPay e2393373564602 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.right,.left],[.left,.left,.left,.left,.right],[.left,.left,.left,.left,.right,.under,.left],[.left,.left,.left,.left,.right,.under],[.right,.left],[.right],[.right,.under,.left],[.right,.under]] = true := by decide
def e2393373564630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2393373564630 : Closed e2393373564630 ∧ code e2393373564630 = 11189466586838 := by decide
theorem cert_e2393373564630 : check e2393373564630 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373564634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2393373564634 : Closed e2393373564634 ∧ code e2393373564634 = 11189466586842 := by decide
theorem cert_e2393373564634 : checkPay e2393373564634 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393373564650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2393373564650 : Closed e2393373564650 ∧ code e2393373564650 = 11189466586858 := by decide
theorem cert_e2393373564650 : checkPay e2393373564650 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393373565166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2393373565166 : Closed e2393373565166 ∧ code e2393373565166 = 11189466587374 := by decide
theorem cert_e2393373565166 : check e2393373565166 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373565178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2393373565178 : Closed e2393373565178 ∧ code e2393373565178 = 11189466587386 := by decide
theorem cert_e2393373565178 : check e2393373565178 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373565358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2393373565358 : Closed e2393373565358 ∧ code e2393373565358 = 11189466587566 := by decide
theorem cert_e2393373565358 : check e2393373565358 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .width = true := by decide
def e2393373565550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373565550 : Closed e2393373565550 ∧ code e2393373565550 = 11189466587758 := by decide
theorem cert_e2393373565550 : check e2393373565550 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373565562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373565562 : Closed e2393373565562 ∧ code e2393373565562 = 11189466587770 := by decide
theorem cert_e2393373565562 : check e2393373565562 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373565726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2393373565726 : Closed e2393373565726 ∧ code e2393373565726 = 11189466587934 := by decide
theorem cert_e2393373565726 : check e2393373565726 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373565894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2393373565894 : Closed e2393373565894 ∧ code e2393373565894 = 11189466588102 := by decide
theorem cert_e2393373565894 : check e2393373565894 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373566510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2393373566510 : Closed e2393373566510 ∧ code e2393373566510 = 11189466588718 := by decide
theorem cert_e2393373566510 : check e2393373566510 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
end Blc.Floor43
