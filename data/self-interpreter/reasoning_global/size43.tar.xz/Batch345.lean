import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419141087034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141087034 : Closed e2419141087034 ∧ code e2419141087034 = 11215234109242 := by decide
theorem cert_e2419141087034 : check e2419141087034 [[],[]] .smaller = true := by decide
def e2419141087130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141087130 : Closed e2419141087130 ∧ code e2419141087130 = 11215234109338 := by decide
theorem cert_e2419141087130 : check e2419141087130 [[],[]] .three = true := by decide
def e2419141088942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2419141088942 : Closed e2419141088942 ∧ code e2419141088942 = 11215234111150 := by decide
theorem cert_e2419141088942 : check e2419141088942 [[],[]] .smaller = true := by decide
def e2419141088954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2419141088954 : Closed e2419141088954 ∧ code e2419141088954 = 11215234111162 := by decide
theorem cert_e2419141088954 : check e2419141088954 [[],[]] .smaller = true := by decide
def e2419141089002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2419141089002 : Closed e2419141089002 ∧ code e2419141089002 = 11215234111210 := by decide
theorem cert_e2419141089002 : check e2419141089002 [[],[]] .smaller = true := by decide
def e2419141089194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2419141089194 : Closed e2419141089194 ∧ code e2419141089194 = 11215234111402 := by decide
theorem cert_e2419141089194 : check e2419141089194 [[],[]] .smaller = true := by decide
def e2419141089502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2419141089502 : Closed e2419141089502 ∧ code e2419141089502 = 11215234111710 := by decide
theorem cert_e2419141089502 : check e2419141089502 [[],[]] .three = true := by decide
def e2419141089518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2419141089518 : Closed e2419141089518 ∧ code e2419141089518 = 11215234111726 := by decide
theorem cert_e2419141089518 : check e2419141089518 [[],[]] .smaller = true := by decide
def e2419141089526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2419141089526 : Closed e2419141089526 ∧ code e2419141089526 = 11215234111734 := by decide
theorem cert_e2419141089526 : check e2419141089526 [[],[]] .smaller = true := by decide
def e2419141089530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2419141089530 : Closed e2419141089530 ∧ code e2419141089530 = 11215234111738 := by decide
theorem cert_e2419141089530 : check e2419141089530 [[],[]] .three = true := by decide
def e2419141089710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2419141089710 : Closed e2419141089710 ∧ code e2419141089710 = 11215234111918 := by decide
theorem cert_e2419141089710 : check e2419141089710 [[],[]] .smaller = true := by decide
def e2419141089722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2419141089722 : Closed e2419141089722 ∧ code e2419141089722 = 11215234111930 := by decide
theorem cert_e2419141089722 : check e2419141089722 [[],[]] .smaller = true := by decide
def e2419141089770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2419141089770 : Closed e2419141089770 ∧ code e2419141089770 = 11215234111978 := by decide
theorem cert_e2419141089770 : check e2419141089770 [[],[]] .smaller = true := by decide
def e2419141089854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2419141089854 : Closed e2419141089854 ∧ code e2419141089854 = 11215234112062 := by decide
theorem cert_e2419141089854 : check e2419141089854 [[],[]] .three = true := by decide
def e2419141089902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141089902 : Closed e2419141089902 ∧ code e2419141089902 = 11215234112110 := by decide
theorem cert_e2419141089902 : check e2419141089902 [[],[]] .smaller = true := by decide
def e2419141089914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141089914 : Closed e2419141089914 ∧ code e2419141089914 = 11215234112122 := by decide
theorem cert_e2419141089914 : check e2419141089914 [[],[]] .smaller = true := by decide
def e2419141090078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2419141090078 : Closed e2419141090078 ∧ code e2419141090078 = 11215234112286 := by decide
theorem cert_e2419141090078 : check e2419141090078 [[],[]] .smaller = true := by decide
def e2419141090190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2419141090190 : Closed e2419141090190 ∧ code e2419141090190 = 11215234112398 := by decide
theorem cert_e2419141090190 : check e2419141090190 [[],[]] .smaller = true := by decide
def e2419141090202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141090202 : Closed e2419141090202 ∧ code e2419141090202 = 11215234112410 := by decide
theorem cert_e2419141090202 : check e2419141090202 [[],[]] .smaller = true := by decide
def e2419141090246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2419141090246 : Closed e2419141090246 ∧ code e2419141090246 = 11215234112454 := by decide
theorem cert_e2419141090246 : check e2419141090246 [[],[]] .three = true := by decide
def e2419141090270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e2419141090270 : Closed e2419141090270 ∧ code e2419141090270 = 11215234112478 := by decide
theorem cert_e2419141090270 : check e2419141090270 [[],[]] .three = true := by decide
def e2419141090414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2419141090414 : Closed e2419141090414 ∧ code e2419141090414 = 11215234112622 := by decide
theorem cert_e2419141090414 : check e2419141090414 [[],[]] .smaller = true := by decide
def e2419141090426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2419141090426 : Closed e2419141090426 ∧ code e2419141090426 = 11215234112634 := by decide
theorem cert_e2419141090426 : check e2419141090426 [[],[]] .smaller = true := by decide
def e2419141090590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2419141090590 : Closed e2419141090590 ∧ code e2419141090590 = 11215234112798 := by decide
theorem cert_e2419141090590 : check e2419141090590 [[],[]] .smaller = true := by decide
def e2419141090758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2419141090758 : Closed e2419141090758 ∧ code e2419141090758 = 11215234112966 := by decide
theorem cert_e2419141090758 : check e2419141090758 [[],[]] .smaller = true := by decide
def e2419141090782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e2419141090782 : Closed e2419141090782 ∧ code e2419141090782 = 11215234112990 := by decide
theorem cert_e2419141090782 : check e2419141090782 [[],[]] .three = true := by decide
def e2419141090798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e2419141090798 : Closed e2419141090798 ∧ code e2419141090798 = 11215234113006 := by decide
theorem cert_e2419141090798 : check e2419141090798 [[],[]] .three = true := by decide
def e2419141090870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2419141090870 : Closed e2419141090870 ∧ code e2419141090870 = 11215234113078 := by decide
theorem cert_e2419141090870 : check e2419141090870 [[],[]] .smaller = true := by decide
def e2419141090874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2419141090874 : Closed e2419141090874 ∧ code e2419141090874 = 11215234113082 := by decide
theorem cert_e2419141090874 : check e2419141090874 [[],[]] .smaller = true := by decide
def e2419141090922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2419141090922 : Closed e2419141090922 ∧ code e2419141090922 = 11215234113130 := by decide
theorem cert_e2419141090922 : check e2419141090922 [[],[]] .smaller = true := by decide
def e2419141090958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2419141090958 : Closed e2419141090958 ∧ code e2419141090958 = 11215234113166 := by decide
theorem cert_e2419141090958 : check e2419141090958 [[],[]] .smaller = true := by decide
def e2419141090970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141090970 : Closed e2419141090970 ∧ code e2419141090970 = 11215234113178 := by decide
theorem cert_e2419141090970 : check e2419141090970 [[],[]] .smaller = true := by decide
def e2419141091014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2419141091014 : Closed e2419141091014 ∧ code e2419141091014 = 11215234113222 := by decide
theorem cert_e2419141091014 : check e2419141091014 [[],[]] .smaller = true := by decide
def e2419141091038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e2419141091038 : Closed e2419141091038 ∧ code e2419141091038 = 11215234113246 := by decide
theorem cert_e2419141091038 : check e2419141091038 [[],[]] .three = true := by decide
def e2419141091062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e2419141091062 : Closed e2419141091062 ∧ code e2419141091062 = 11215234113270 := by decide
theorem cert_e2419141091062 : check e2419141091062 [[],[]] .three = true := by decide
def e2419141091098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2419141091098 : Closed e2419141091098 ∧ code e2419141091098 = 11215234113306 := by decide
theorem cert_e2419141091098 : check e2419141091098 [[],[]] .three = true := by decide
def e2419141091142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2419141091142 : Closed e2419141091142 ∧ code e2419141091142 = 11215234113350 := by decide
theorem cert_e2419141091142 : check e2419141091142 [[],[]] .three = true := by decide
def e2419141091166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e2419141091166 : Closed e2419141091166 ∧ code e2419141091166 = 11215234113374 := by decide
theorem cert_e2419141091166 : check e2419141091166 [[],[]] .three = true := by decide
def e2419141091182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e2419141091182 : Closed e2419141091182 ∧ code e2419141091182 = 11215234113390 := by decide
theorem cert_e2419141091182 : check e2419141091182 [[],[]] .three = true := by decide
def e2419141091190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e2419141091190 : Closed e2419141091190 ∧ code e2419141091190 = 11215234113398 := by decide
theorem cert_e2419141091190 : check e2419141091190 [[],[]] .three = true := by decide
def e2419141091194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e2419141091194 : Closed e2419141091194 ∧ code e2419141091194 = 11215234113402 := by decide
theorem cert_e2419141091194 : check e2419141091194 [[],[]] .three = true := by decide
def e2419141091806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2419141091806 : Closed e2419141091806 ∧ code e2419141091806 = 11215234114014 := by decide
theorem cert_e2419141091806 : check e2419141091806 [[],[]] .smaller = true := by decide
def e2419141091830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2419141091830 : Closed e2419141091830 ∧ code e2419141091830 = 11215234114038 := by decide
theorem cert_e2419141091830 : check e2419141091830 [[],[]] .smaller = true := by decide
def e2419141092782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2419141092782 : Closed e2419141092782 ∧ code e2419141092782 = 11215234114990 := by decide
theorem cert_e2419141092782 : check e2419141092782 [[],[]] .smaller = true := by decide
def e2419141092794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2419141092794 : Closed e2419141092794 ∧ code e2419141092794 = 11215234115002 := by decide
theorem cert_e2419141092794 : check e2419141092794 [[],[]] .smaller = true := by decide
def e2419141092842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2419141092842 : Closed e2419141092842 ∧ code e2419141092842 = 11215234115050 := by decide
theorem cert_e2419141092842 : check e2419141092842 [[],[]] .smaller = true := by decide
def e2419141092926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2419141092926 : Closed e2419141092926 ∧ code e2419141092926 = 11215234115134 := by decide
theorem cert_e2419141092926 : check e2419141092926 [[],[]] .three = true := by decide
def e2419141092974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141092974 : Closed e2419141092974 ∧ code e2419141092974 = 11215234115182 := by decide
theorem cert_e2419141092974 : check e2419141092974 [[],[]] .smaller = true := by decide
def e2419141092986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141092986 : Closed e2419141092986 ∧ code e2419141092986 = 11215234115194 := by decide
theorem cert_e2419141092986 : check e2419141092986 [[],[]] .smaller = true := by decide
def e2419141093150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2419141093150 : Closed e2419141093150 ∧ code e2419141093150 = 11215234115358 := by decide
theorem cert_e2419141093150 : check e2419141093150 [[],[]] .smaller = true := by decide
def e2419141093262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2419141093262 : Closed e2419141093262 ∧ code e2419141093262 = 11215234115470 := by decide
theorem cert_e2419141093262 : check e2419141093262 [[],[]] .smaller = true := by decide
def e2419141093274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141093274 : Closed e2419141093274 ∧ code e2419141093274 = 11215234115482 := by decide
theorem cert_e2419141093274 : check e2419141093274 [[],[]] .smaller = true := by decide
def e2419141093318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2419141093318 : Closed e2419141093318 ∧ code e2419141093318 = 11215234115526 := by decide
theorem cert_e2419141093318 : check e2419141093318 [[],[]] .three = true := by decide
def e2419141093342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e2419141093342 : Closed e2419141093342 ∧ code e2419141093342 = 11215234115550 := by decide
theorem cert_e2419141093342 : check e2419141093342 [[],[]] .three = true := by decide
def e2419141096222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2419141096222 : Closed e2419141096222 ∧ code e2419141096222 = 11215234118430 := by decide
theorem cert_e2419141096222 : check e2419141096222 [[],[]] .smaller = true := by decide
def e2419141096390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2419141096390 : Closed e2419141096390 ∧ code e2419141096390 = 11215234118598 := by decide
theorem cert_e2419141096390 : check e2419141096390 [[],[]] .smaller = true := by decide
def e2419141096414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e2419141096414 : Closed e2419141096414 ∧ code e2419141096414 = 11215234118622 := by decide
theorem cert_e2419141096414 : check e2419141096414 [[],[]] .three = true := by decide
def e2419141096430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e2419141096430 : Closed e2419141096430 ∧ code e2419141096430 = 11215234118638 := by decide
theorem cert_e2419141096430 : check e2419141096430 [[],[]] .three = true := by decide
def e2419141097590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2419141097590 : Closed e2419141097590 ∧ code e2419141097590 = 11215234119798 := by decide
theorem cert_e2419141097590 : check e2419141097590 [[],[]] .smaller = true := by decide
def e2419141097834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2419141097834 : Closed e2419141097834 ∧ code e2419141097834 = 11215234120042 := by decide
theorem cert_e2419141097834 : check e2419141097834 [[],[]] .smaller = true := by decide
def e2419141097870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2419141097870 : Closed e2419141097870 ∧ code e2419141097870 = 11215234120078 := by decide
theorem cert_e2419141097870 : check e2419141097870 [[],[]] .smaller = true := by decide
def e2419141097882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141097882 : Closed e2419141097882 ∧ code e2419141097882 = 11215234120090 := by decide
theorem cert_e2419141097882 : check e2419141097882 [[],[]] .smaller = true := by decide
def e2419141097926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2419141097926 : Closed e2419141097926 ∧ code e2419141097926 = 11215234120134 := by decide
theorem cert_e2419141097926 : check e2419141097926 [[],[]] .smaller = true := by decide
def e2419141097950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e2419141097950 : Closed e2419141097950 ∧ code e2419141097950 = 11215234120158 := by decide
theorem cert_e2419141097950 : check e2419141097950 [[],[]] .three = true := by decide
def e2419141097974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e2419141097974 : Closed e2419141097974 ∧ code e2419141097974 = 11215234120182 := by decide
theorem cert_e2419141097974 : check e2419141097974 [[],[]] .three = true := by decide
def e2419141098694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2419141098694 : Closed e2419141098694 ∧ code e2419141098694 = 11215234120902 := by decide
theorem cert_e2419141098694 : check e2419141098694 [[],[]] .three = true := by decide
def e2419141098718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e2419141098718 : Closed e2419141098718 ∧ code e2419141098718 = 11215234120926 := by decide
theorem cert_e2419141098718 : check e2419141098718 [[],[]] .three = true := by decide
def e2419141098734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419141098734 : Closed e2419141098734 ∧ code e2419141098734 = 11215234120942 := by decide
theorem cert_e2419141098734 : check e2419141098734 [[],[]] .three = true := by decide
def e2419141098742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419141098742 : Closed e2419141098742 ∧ code e2419141098742 = 11215234120950 := by decide
theorem cert_e2419141098742 : check e2419141098742 [[],[]] .three = true := by decide
def e2419141098746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e2419141098746 : Closed e2419141098746 ∧ code e2419141098746 = 11215234120954 := by decide
theorem cert_e2419141098746 : check e2419141098746 [[],[]] .three = true := by decide
def e2419141100470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e2419141100470 : Closed e2419141100470 ∧ code e2419141100470 = 11215234122678 := by decide
theorem cert_e2419141100470 : check e2419141100470 [[],[]] .smaller = true := by decide
def e2419141100474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2419141100474 : Closed e2419141100474 ∧ code e2419141100474 = 11215234122682 := by decide
theorem cert_e2419141100474 : check e2419141100474 [[],[]] .smaller = true := by decide
def e2419141100506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2419141100506 : Closed e2419141100506 ∧ code e2419141100506 = 11215234122714 := by decide
theorem cert_e2419141100506 : check e2419141100506 [[],[]] .smaller = true := by decide
def e2419141101174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e2419141101174 : Closed e2419141101174 ∧ code e2419141101174 = 11215234123382 := by decide
theorem cert_e2419141101174 : check e2419141101174 [[],[]] .smaller = true := by decide
def e2419141101366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141101366 : Closed e2419141101366 ∧ code e2419141101366 = 11215234123574 := by decide
theorem cert_e2419141101366 : check e2419141101366 [[],[]] .smaller = true := by decide
def e2419141101370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141101370 : Closed e2419141101370 ∧ code e2419141101370 = 11215234123578 := by decide
theorem cert_e2419141101370 : check e2419141101370 [[],[]] .smaller = true := by decide
def e2419141102422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2419141102422 : Closed e2419141102422 ∧ code e2419141102422 = 11215234124630 := by decide
theorem cert_e2419141102422 : check e2419141102422 [[],[]] .smaller = true := by decide
def e2419141102426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2419141102426 : Closed e2419141102426 ∧ code e2419141102426 = 11215234124634 := by decide
theorem cert_e2419141102426 : check e2419141102426 [[],[]] .smaller = true := by decide
def e2419141102442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2419141102442 : Closed e2419141102442 ∧ code e2419141102442 = 11215234124650 := by decide
theorem cert_e2419141102442 : check e2419141102442 [[],[]] .smaller = true := by decide
def e2419141102506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2419141102506 : Closed e2419141102506 ∧ code e2419141102506 = 11215234124714 := by decide
theorem cert_e2419141102506 : check e2419141102506 [[],[]] .smaller = true := by decide
def e2419141102710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2419141102710 : Closed e2419141102710 ∧ code e2419141102710 = 11215234124918 := by decide
theorem cert_e2419141102710 : check e2419141102710 [[],[]] .smaller = true := by decide
def e2419141102806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2419141102806 : Closed e2419141102806 ∧ code e2419141102806 = 11215234125014 := by decide
theorem cert_e2419141102806 : check e2419141102806 [[],[]] .smaller = true := by decide
def e2419141102810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2419141102810 : Closed e2419141102810 ∧ code e2419141102810 = 11215234125018 := by decide
theorem cert_e2419141102810 : check e2419141102810 [[],[]] .smaller = true := by decide
def e2419141102826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2419141102826 : Closed e2419141102826 ∧ code e2419141102826 = 11215234125034 := by decide
theorem cert_e2419141102826 : check e2419141102826 [[],[]] .smaller = true := by decide
def e2419141102902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141102902 : Closed e2419141102902 ∧ code e2419141102902 = 11215234125110 := by decide
theorem cert_e2419141102902 : check e2419141102902 [[],[]] .smaller = true := by decide
def e2419141102906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141102906 : Closed e2419141102906 ∧ code e2419141102906 = 11215234125114 := by decide
theorem cert_e2419141102906 : check e2419141102906 [[],[]] .smaller = true := by decide
def e2419141102990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2419141102990 : Closed e2419141102990 ∧ code e2419141102990 = 11215234125198 := by decide
theorem cert_e2419141102990 : check e2419141102990 [[],[]] .smaller = true := by decide
def e2419141103002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141103002 : Closed e2419141103002 ∧ code e2419141103002 = 11215234125210 := by decide
theorem cert_e2419141103002 : check e2419141103002 [[],[]] .smaller = true := by decide
def e2419141103070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2419141103070 : Closed e2419141103070 ∧ code e2419141103070 = 11215234125278 := by decide
theorem cert_e2419141103070 : check e2419141103070 [[],[]] .three = true := by decide
def e2419141103086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2419141103086 : Closed e2419141103086 ∧ code e2419141103086 = 11215234125294 := by decide
theorem cert_e2419141103086 : check e2419141103086 [[],[]] .three = true := by decide
def e2419141103158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2419141103158 : Closed e2419141103158 ∧ code e2419141103158 = 11215234125366 := by decide
theorem cert_e2419141103158 : check e2419141103158 [[],[]] .smaller = true := by decide
def e2419141103162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2419141103162 : Closed e2419141103162 ∧ code e2419141103162 = 11215234125370 := by decide
theorem cert_e2419141103162 : check e2419141103162 [[],[]] .smaller = true := by decide
def e2419141103210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2419141103210 : Closed e2419141103210 ∧ code e2419141103210 = 11215234125418 := by decide
theorem cert_e2419141103210 : check e2419141103210 [[],[]] .smaller = true := by decide
def e2419141103246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2419141103246 : Closed e2419141103246 ∧ code e2419141103246 = 11215234125454 := by decide
theorem cert_e2419141103246 : check e2419141103246 [[],[]] .smaller = true := by decide
def e2419141103258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141103258 : Closed e2419141103258 ∧ code e2419141103258 = 11215234125466 := by decide
theorem cert_e2419141103258 : check e2419141103258 [[],[]] .smaller = true := by decide
def e2419141103302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2419141103302 : Closed e2419141103302 ∧ code e2419141103302 = 11215234125510 := by decide
theorem cert_e2419141103302 : check e2419141103302 [[],[]] .smaller = true := by decide
def e2419141103326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2419141103326 : Closed e2419141103326 ∧ code e2419141103326 = 11215234125534 := by decide
theorem cert_e2419141103326 : check e2419141103326 [[],[]] .three = true := by decide
def e2419141103350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2419141103350 : Closed e2419141103350 ∧ code e2419141103350 = 11215234125558 := by decide
theorem cert_e2419141103350 : check e2419141103350 [[],[]] .three = true := by decide
def e2419141103454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2419141103454 : Closed e2419141103454 ∧ code e2419141103454 = 11215234125662 := by decide
theorem cert_e2419141103454 : check e2419141103454 [[],[]] .three = true := by decide
def e2419141103482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2419141103482 : Closed e2419141103482 ∧ code e2419141103482 = 11215234125690 := by decide
theorem cert_e2419141103482 : check e2419141103482 [[],[]] .three = true := by decide
def e2419141103534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2419141103534 : Closed e2419141103534 ∧ code e2419141103534 = 11215234125742 := by decide
theorem cert_e2419141103534 : check e2419141103534 [[],[]] .three = true := by decide
def e2419141103542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2419141103542 : Closed e2419141103542 ∧ code e2419141103542 = 11215234125750 := by decide
theorem cert_e2419141103542 : check e2419141103542 [[],[]] .three = true := by decide
def e2419141103546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2419141103546 : Closed e2419141103546 ∧ code e2419141103546 = 11215234125754 := by decide
theorem cert_e2419141103546 : check e2419141103546 [[],[]] .three = true := by decide
def e2419141103854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2419141103854 : Closed e2419141103854 ∧ code e2419141103854 = 11215234126062 := by decide
theorem cert_e2419141103854 : check e2419141103854 [[],[]] .smaller = true := by decide
def e2419141103862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2419141103862 : Closed e2419141103862 ∧ code e2419141103862 = 11215234126070 := by decide
theorem cert_e2419141103862 : check e2419141103862 [[],[]] .smaller = true := by decide
def e2419141104342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2419141104342 : Closed e2419141104342 ∧ code e2419141104342 = 11215234126550 := by decide
theorem cert_e2419141104342 : check e2419141104342 [[],[]] .smaller = true := by decide
def e2419141104346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2419141104346 : Closed e2419141104346 ∧ code e2419141104346 = 11215234126554 := by decide
theorem cert_e2419141104346 : check e2419141104346 [[],[]] .smaller = true := by decide
def e2419141104362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2419141104362 : Closed e2419141104362 ∧ code e2419141104362 = 11215234126570 := by decide
theorem cert_e2419141104362 : check e2419141104362 [[],[]] .smaller = true := by decide
def e2419141104438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419141104438 : Closed e2419141104438 ∧ code e2419141104438 = 11215234126646 := by decide
theorem cert_e2419141104438 : check e2419141104438 [[],[]] .smaller = true := by decide
def e2419141104442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419141104442 : Closed e2419141104442 ∧ code e2419141104442 = 11215234126650 := by decide
theorem cert_e2419141104442 : check e2419141104442 [[],[]] .smaller = true := by decide
def e2419141104526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2419141104526 : Closed e2419141104526 ∧ code e2419141104526 = 11215234126734 := by decide
theorem cert_e2419141104526 : check e2419141104526 [[],[]] .smaller = true := by decide
def e2419141104538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141104538 : Closed e2419141104538 ∧ code e2419141104538 = 11215234126746 := by decide
theorem cert_e2419141104538 : check e2419141104538 [[],[]] .smaller = true := by decide
def e2419141104606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2419141104606 : Closed e2419141104606 ∧ code e2419141104606 = 11215234126814 := by decide
theorem cert_e2419141104606 : check e2419141104606 [[],[]] .three = true := by decide
def e2419141104622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2419141104622 : Closed e2419141104622 ∧ code e2419141104622 = 11215234126830 := by decide
theorem cert_e2419141104622 : check e2419141104622 [[],[]] .three = true := by decide
def e2419141105782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2419141105782 : Closed e2419141105782 ∧ code e2419141105782 = 11215234127990 := by decide
theorem cert_e2419141105782 : check e2419141105782 [[],[]] .smaller = true := by decide
def e2419141106026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2419141106026 : Closed e2419141106026 ∧ code e2419141106026 = 11215234128234 := by decide
theorem cert_e2419141106026 : check e2419141106026 [[],[]] .smaller = true := by decide
def e2419141106062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2419141106062 : Closed e2419141106062 ∧ code e2419141106062 = 11215234128270 := by decide
theorem cert_e2419141106062 : check e2419141106062 [[],[]] .smaller = true := by decide
def e2419141106074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141106074 : Closed e2419141106074 ∧ code e2419141106074 = 11215234128282 := by decide
theorem cert_e2419141106074 : check e2419141106074 [[],[]] .smaller = true := by decide
def e2419141106118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2419141106118 : Closed e2419141106118 ∧ code e2419141106118 = 11215234128326 := by decide
theorem cert_e2419141106118 : check e2419141106118 [[],[]] .smaller = true := by decide
def e2419141106142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2419141106142 : Closed e2419141106142 ∧ code e2419141106142 = 11215234128350 := by decide
theorem cert_e2419141106142 : check e2419141106142 [[],[]] .three = true := by decide
def e2419141106166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2419141106166 : Closed e2419141106166 ∧ code e2419141106166 = 11215234128374 := by decide
theorem cert_e2419141106166 : check e2419141106166 [[],[]] .three = true := by decide
def e2419141106910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2419141106910 : Closed e2419141106910 ∧ code e2419141106910 = 11215234129118 := by decide
theorem cert_e2419141106910 : check e2419141106910 [[],[]] .three = true := by decide
def e2419141106938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2419141106938 : Closed e2419141106938 ∧ code e2419141106938 = 11215234129146 := by decide
theorem cert_e2419141106938 : check e2419141106938 [[],[]] .three = true := by decide
def e2419141107310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141107310 : Closed e2419141107310 ∧ code e2419141107310 = 11215234129518 := by decide
theorem cert_e2419141107310 : check e2419141107310 [[],[]] .three = true := by decide
def e2419141107318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419141107318 : Closed e2419141107318 ∧ code e2419141107318 = 11215234129526 := by decide
theorem cert_e2419141107318 : check e2419141107318 [[],[]] .three = true := by decide
def e2419141107322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141107322 : Closed e2419141107322 ∧ code e2419141107322 = 11215234129530 := by decide
theorem cert_e2419141107322 : check e2419141107322 [[],[]] .three = true := by decide
def e2419141108534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141108534 : Closed e2419141108534 ∧ code e2419141108534 = 11215234130742 := by decide
theorem cert_e2419141108534 : check e2419141108534 [[],[]] .three = true := by decide
def e2419141108538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141108538 : Closed e2419141108538 ∧ code e2419141108538 = 11215234130746 := by decide
theorem cert_e2419141108538 : check e2419141108538 [[],[]] .three = true := by decide
def e2419141108634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419141108634 : Closed e2419141108634 ∧ code e2419141108634 = 11215234130842 := by decide
theorem cert_e2419141108634 : check e2419141108634 [[],[]] .three = true := by decide
def e2419141109302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2419141109302 : Closed e2419141109302 ∧ code e2419141109302 = 11215234131510 := by decide
theorem cert_e2419141109302 : check e2419141109302 [[],[]] .three = true := by decide
def e2419141109306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2419141109306 : Closed e2419141109306 ∧ code e2419141109306 = 11215234131514 := by decide
theorem cert_e2419141109306 : check e2419141109306 [[],[]] .three = true := by decide
def e2419141109390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2419141109390 : Closed e2419141109390 ∧ code e2419141109390 = 11215234131598 := by decide
theorem cert_e2419141109390 : check e2419141109390 [[],[]] .three = true := by decide
def e2419141109446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2419141109446 : Closed e2419141109446 ∧ code e2419141109446 = 11215234131654 := by decide
theorem cert_e2419141109446 : check e2419141109446 [[],[]] .three = true := by decide
def e2419141109470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2419141109470 : Closed e2419141109470 ∧ code e2419141109470 = 11215234131678 := by decide
theorem cert_e2419141109470 : check e2419141109470 [[],[]] .three = true := by decide
def e2419141109486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2419141109486 : Closed e2419141109486 ∧ code e2419141109486 = 11215234131694 := by decide
theorem cert_e2419141109486 : check e2419141109486 [[],[]] .three = true := by decide
def e2419141109494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2419141109494 : Closed e2419141109494 ∧ code e2419141109494 = 11215234131702 := by decide
theorem cert_e2419141109494 : check e2419141109494 [[],[]] .three = true := by decide
def e2419141109530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2419141109530 : Closed e2419141109530 ∧ code e2419141109530 = 11215234131738 := by decide
theorem cert_e2419141109530 : check e2419141109530 [[],[]] .three = true := by decide
def e2419141109574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2419141109574 : Closed e2419141109574 ∧ code e2419141109574 = 11215234131782 := by decide
theorem cert_e2419141109574 : check e2419141109574 [[],[]] .three = true := by decide
def e2419141109598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2419141109598 : Closed e2419141109598 ∧ code e2419141109598 = 11215234131806 := by decide
theorem cert_e2419141109598 : check e2419141109598 [[],[]] .three = true := by decide
def e2419141109614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2419141109614 : Closed e2419141109614 ∧ code e2419141109614 = 11215234131822 := by decide
theorem cert_e2419141109614 : check e2419141109614 [[],[]] .three = true := by decide
def e2419141109622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2419141109622 : Closed e2419141109622 ∧ code e2419141109622 = 11215234131830 := by decide
theorem cert_e2419141109622 : check e2419141109622 [[],[]] .three = true := by decide
def e2419141109626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2419141109626 : Closed e2419141109626 ∧ code e2419141109626 = 11215234131834 := by decide
theorem cert_e2419141109626 : check e2419141109626 [[],[]] .three = true := by decide
def e2419141109678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2419141109678 : Closed e2419141109678 ∧ code e2419141109678 = 11215234131886 := by decide
theorem cert_e2419141109678 : check e2419141109678 [[],[]] .three = true := by decide
def e2419141109686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2419141109686 : Closed e2419141109686 ∧ code e2419141109686 = 11215234131894 := by decide
theorem cert_e2419141109686 : check e2419141109686 [[],[]] .three = true := by decide
def e2419141109690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2419141109690 : Closed e2419141109690 ∧ code e2419141109690 = 11215234131898 := by decide
theorem cert_e2419141109690 : check e2419141109690 [[],[]] .three = true := by decide
def e2419141109718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2419141109718 : Closed e2419141109718 ∧ code e2419141109718 = 11215234131926 := by decide
theorem cert_e2419141109718 : check e2419141109718 [[],[]] .three = true := by decide
def e2419141109722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2419141109722 : Closed e2419141109722 ∧ code e2419141109722 = 11215234131930 := by decide
theorem cert_e2419141109722 : check e2419141109722 [[],[]] .three = true := by decide
def e2419141110158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2419141110158 : Closed e2419141110158 ∧ code e2419141110158 = 11215234132366 := by decide
theorem cert_e2419141110158 : check e2419141110158 [[],[]] .three = true := by decide
def e2419141110214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2419141110214 : Closed e2419141110214 ∧ code e2419141110214 = 11215234132422 := by decide
theorem cert_e2419141110214 : check e2419141110214 [[],[]] .three = true := by decide
def e2419141110238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2419141110238 : Closed e2419141110238 ∧ code e2419141110238 = 11215234132446 := by decide
theorem cert_e2419141110238 : check e2419141110238 [[],[]] .three = true := by decide
def e2419141110254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419141110254 : Closed e2419141110254 ∧ code e2419141110254 = 11215234132462 := by decide
theorem cert_e2419141110254 : check e2419141110254 [[],[]] .three = true := by decide
def e2419141110262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2419141110262 : Closed e2419141110262 ∧ code e2419141110262 = 11215234132470 := by decide
theorem cert_e2419141110262 : check e2419141110262 [[],[]] .three = true := by decide
def e2419141110982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2419141110982 : Closed e2419141110982 ∧ code e2419141110982 = 11215234133190 := by decide
theorem cert_e2419141110982 : check e2419141110982 [[],[]] .three = true := by decide
def e2419141111006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2419141111006 : Closed e2419141111006 ∧ code e2419141111006 = 11215234133214 := by decide
theorem cert_e2419141111006 : check e2419141111006 [[],[]] .three = true := by decide
def e2419141111022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419141111022 : Closed e2419141111022 ∧ code e2419141111022 = 11215234133230 := by decide
theorem cert_e2419141111022 : check e2419141111022 [[],[]] .three = true := by decide
def e2419141111030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419141111030 : Closed e2419141111030 ∧ code e2419141111030 = 11215234133238 := by decide
theorem cert_e2419141111030 : check e2419141111030 [[],[]] .three = true := by decide
def e2419141111034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2419141111034 : Closed e2419141111034 ∧ code e2419141111034 = 11215234133242 := by decide
theorem cert_e2419141111034 : check e2419141111034 [[],[]] .three = true := by decide
def e2419141111406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419141111406 : Closed e2419141111406 ∧ code e2419141111406 = 11215234133614 := by decide
theorem cert_e2419141111406 : check e2419141111406 [[],[]] .three = true := by decide
def e2419141111414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419141111414 : Closed e2419141111414 ∧ code e2419141111414 = 11215234133622 := by decide
theorem cert_e2419141111414 : check e2419141111414 [[],[]] .three = true := by decide
def e2419141111418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419141111418 : Closed e2419141111418 ∧ code e2419141111418 = 11215234133626 := by decide
theorem cert_e2419141111418 : check e2419141111418 [[],[]] .three = true := by decide
end Blc.Floor43
