import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e599819154234 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e599819154234 : Closed e599819154234 ∧ code e599819154234 = 9395912176442 := by decide
theorem cert_e599819154234 : check e599819154234 [[.under]] .sourceHead = true := by decide
def e599819154330 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e599819154330 : Closed e599819154330 ∧ code e599819154330 = 9395912176538 := by decide
theorem cert_e599819154330 : check e599819154330 [[.under]] .sourceHead = true := by decide
def e599819379566 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e599819379566 : Closed e599819379566 ∧ code e599819379566 = 9395912401774 := by decide
theorem cert_e599819379566 : check e599819379566 [[.under]] .sourceHead = true := by decide
def e599819379574 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e599819379574 : Closed e599819379574 ∧ code e599819379574 = 9395912401782 := by decide
theorem cert_e599819379574 : check e599819379574 [[.under]] .sourceHead = true := by decide
def e599819379630 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e599819379630 : Closed e599819379630 ∧ code e599819379630 = 9395912401838 := by decide
theorem cert_e599819379630 : check e599819379630 [[.under]] .sourceHead = true := by decide
def e599819379642 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e599819379642 : Closed e599819379642 ∧ code e599819379642 = 9395912401850 := by decide
theorem cert_e599819379642 : check e599819379642 [[.under]] .sourceHead = true := by decide
def e599819379670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e599819379670 : Closed e599819379670 ∧ code e599819379670 = 9395912401878 := by decide
theorem cert_e599819379670 : check e599819379670 [[.under]] .sourceHead = true := by decide
def e599819379674 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e599819379674 : Closed e599819379674 ∧ code e599819379674 = 9395912401882 := by decide
theorem cert_e599819379674 : check e599819379674 [[.under]] .sourceHead = true := by decide
def e599819380974 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e599819380974 : Closed e599819380974 ∧ code e599819380974 = 9395912403182 := by decide
theorem cert_e599819380974 : check e599819380974 [[.under]] .sourceHead = true := by decide
def e599819380982 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e599819380982 : Closed e599819380982 ∧ code e599819380982 = 9395912403190 := by decide
theorem cert_e599819380982 : check e599819380982 [[.under]] .sourceHead = true := by decide
def e599819381534 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e599819381534 : Closed e599819381534 ∧ code e599819381534 = 9395912403742 := by decide
theorem cert_e599819381534 : check e599819381534 [[.under]] .sourceHead = true := by decide
def e599819381646 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e599819381646 : Closed e599819381646 ∧ code e599819381646 = 9395912403854 := by decide
theorem cert_e599819381646 : check e599819381646 [[.under]] .sourceHead = true := by decide
def e599819381870 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e599819381870 : Closed e599819381870 ∧ code e599819381870 = 9395912404078 := by decide
theorem cert_e599819381870 : check e599819381870 [[.under]] .sourceHead = true := by decide
def e599819381882 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e599819381882 : Closed e599819381882 ∧ code e599819381882 = 9395912404090 := by decide
theorem cert_e599819381882 : check e599819381882 [[.under]] .sourceHead = true := by decide
def e599819382046 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e599819382046 : Closed e599819382046 ∧ code e599819382046 = 9395912404254 := by decide
theorem cert_e599819382046 : check e599819382046 [[.under]] .sourceHead = true := by decide
def e599819382214 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e599819382214 : Closed e599819382214 ∧ code e599819382214 = 9395912404422 := by decide
theorem cert_e599819382214 : check e599819382214 [[.under]] .sourceHead = true := by decide
def e599819382326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e599819382326 : Closed e599819382326 ∧ code e599819382326 = 9395912404534 := by decide
theorem cert_e599819382326 : check e599819382326 [[.under]] .sourceHead = true := by decide
def e599819382330 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e599819382330 : Closed e599819382330 ∧ code e599819382330 = 9395912404538 := by decide
theorem cert_e599819382330 : check e599819382330 [[.under]] .sourceHead = true := by decide
def e599819382414 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e599819382414 : Closed e599819382414 ∧ code e599819382414 = 9395912404622 := by decide
theorem cert_e599819382414 : check e599819382414 [[.under]] .sourceHead = true := by decide
def e599819382470 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e599819382470 : Closed e599819382470 ∧ code e599819382470 = 9395912404678 := by decide
theorem cert_e599819382470 : check e599819382470 [[.under]] .sourceHead = true := by decide
def e599819383214 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e599819383214 : Closed e599819383214 ∧ code e599819383214 = 9395912405422 := by decide
theorem cert_e599819383214 : check e599819383214 [[.under]] .sourceHead = true := by decide
def e599819383226 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e599819383226 : Closed e599819383226 ∧ code e599819383226 = 9395912405434 := by decide
theorem cert_e599819383226 : check e599819383226 [[.under]] .sourceHead = true := by decide
def e599819383274 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e599819383274 : Closed e599819383274 ∧ code e599819383274 = 9395912405482 := by decide
theorem cert_e599819383274 : check e599819383274 [[.under]] .sourceHead = true := by decide
def e599819383918 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e599819383918 : Closed e599819383918 ∧ code e599819383918 = 9395912406126 := by decide
theorem cert_e599819383918 : check e599819383918 [[.under]] .sourceHead = true := by decide
def e599819383930 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e599819383930 : Closed e599819383930 ∧ code e599819383930 = 9395912406138 := by decide
theorem cert_e599819383930 : check e599819383930 [[.under]] .sourceHead = true := by decide
def e599819384094 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e599819384094 : Closed e599819384094 ∧ code e599819384094 = 9395912406302 := by decide
theorem cert_e599819384094 : check e599819384094 [[.under]] .sourceHead = true := by decide
def e599819384262 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e599819384262 : Closed e599819384262 ∧ code e599819384262 = 9395912406470 := by decide
theorem cert_e599819384262 : check e599819384262 [[.under]] .sourceHead = true := by decide
def e599819384602 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e599819384602 : Closed e599819384602 ∧ code e599819384602 = 9395912406810 := by decide
theorem cert_e599819384602 : check e599819384602 [[.under]] .sourceHead = true := by decide
def e599819384646 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e599819384646 : Closed e599819384646 ∧ code e599819384646 = 9395912406854 := by decide
theorem cert_e599819384646 : check e599819384646 [[.under]] .sourceHead = true := by decide
def e599819385046 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e599819385046 : Closed e599819385046 ∧ code e599819385046 = 9395912407254 := by decide
theorem cert_e599819385046 : check e599819385046 [[.under]] .sourceHead = true := by decide
def e599819385050 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e599819385050 : Closed e599819385050 ∧ code e599819385050 = 9395912407258 := by decide
theorem cert_e599819385050 : check e599819385050 [[.under]] .sourceHead = true := by decide
def e599819385066 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e599819385066 : Closed e599819385066 ∧ code e599819385066 = 9395912407274 := by decide
theorem cert_e599819385066 : check e599819385066 [[.under]] .sourceHead = true := by decide
def e599819385398 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e599819385398 : Closed e599819385398 ∧ code e599819385398 = 9395912407606 := by decide
theorem cert_e599819385398 : check e599819385398 [[.under]] .sourceHead = true := by decide
def e599819385402 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e599819385402 : Closed e599819385402 ∧ code e599819385402 = 9395912407610 := by decide
theorem cert_e599819385402 : check e599819385402 [[.under]] .sourceHead = true := by decide
def e599819385486 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e599819385486 : Closed e599819385486 ∧ code e599819385486 = 9395912407694 := by decide
theorem cert_e599819385486 : check e599819385486 [[.under]] .sourceHead = true := by decide
def e599819385542 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e599819385542 : Closed e599819385542 ∧ code e599819385542 = 9395912407750 := by decide
theorem cert_e599819385542 : check e599819385542 [[.under]] .sourceHead = true := by decide
def e599819385626 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e599819385626 : Closed e599819385626 ∧ code e599819385626 = 9395912407834 := by decide
theorem cert_e599819385626 : check e599819385626 [[.under]] .sourceHead = true := by decide
def e599819385670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e599819385670 : Closed e599819385670 ∧ code e599819385670 = 9395912407878 := by decide
theorem cert_e599819385670 : check e599819385670 [[.under]] .sourceHead = true := by decide
def e599819390190 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e599819390190 : Closed e599819390190 ∧ code e599819390190 = 9395912412398 := by decide
theorem cert_e599819390190 : check e599819390190 [[.under]] .sourceHead = true := by decide
def e599819390198 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e599819390198 : Closed e599819390198 ∧ code e599819390198 = 9395912412406 := by decide
theorem cert_e599819390198 : check e599819390198 [[.under]] .sourceHead = true := by decide
def e599819390574 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e599819390574 : Closed e599819390574 ∧ code e599819390574 = 9395912412782 := by decide
theorem cert_e599819390574 : check e599819390574 [[.under]] .sourceHead = true := by decide
def e599819390586 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e599819390586 : Closed e599819390586 ∧ code e599819390586 = 9395912412794 := by decide
theorem cert_e599819390586 : check e599819390586 [[.under]] .sourceHead = true := by decide
def e599819390774 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e599819390774 : Closed e599819390774 ∧ code e599819390774 = 9395912412982 := by decide
theorem cert_e599819390774 : check e599819390774 [[.under]] .sourceHead = true := by decide
def e599819390778 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e599819390778 : Closed e599819390778 ∧ code e599819390778 = 9395912412986 := by decide
theorem cert_e599819390778 : check e599819390778 [[.under]] .sourceHead = true := by decide
def e599819393262 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e599819393262 : Closed e599819393262 ∧ code e599819393262 = 9395912415470 := by decide
theorem cert_e599819393262 : check e599819393262 [[.under]] .sourceHead = true := by decide
def e599819393270 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e599819393270 : Closed e599819393270 ∧ code e599819393270 = 9395912415478 := by decide
theorem cert_e599819393270 : check e599819393270 [[.under]] .sourceHead = true := by decide
def e599819393822 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e599819393822 : Closed e599819393822 ∧ code e599819393822 = 9395912416030 := by decide
theorem cert_e599819393822 : check e599819393822 [[.under]] .sourceHead = true := by decide
def e599819393934 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e599819393934 : Closed e599819393934 ∧ code e599819393934 = 9395912416142 := by decide
theorem cert_e599819393934 : check e599819393934 [[.under]] .sourceHead = true := by decide
def e599819394158 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e599819394158 : Closed e599819394158 ∧ code e599819394158 = 9395912416366 := by decide
theorem cert_e599819394158 : check e599819394158 [[.under]] .sourceHead = true := by decide
def e599819394170 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e599819394170 : Closed e599819394170 ∧ code e599819394170 = 9395912416378 := by decide
theorem cert_e599819394170 : check e599819394170 [[.under]] .sourceHead = true := by decide
def e599819394334 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e599819394334 : Closed e599819394334 ∧ code e599819394334 = 9395912416542 := by decide
theorem cert_e599819394334 : check e599819394334 [[.under]] .sourceHead = true := by decide
def e599819394502 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e599819394502 : Closed e599819394502 ∧ code e599819394502 = 9395912416710 := by decide
theorem cert_e599819394502 : check e599819394502 [[.under]] .sourceHead = true := by decide
def e599819394614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e599819394614 : Closed e599819394614 ∧ code e599819394614 = 9395912416822 := by decide
theorem cert_e599819394614 : check e599819394614 [[.under]] .sourceHead = true := by decide
def e599819394618 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e599819394618 : Closed e599819394618 ∧ code e599819394618 = 9395912416826 := by decide
theorem cert_e599819394618 : check e599819394618 [[.under]] .sourceHead = true := by decide
def e599819394702 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e599819394702 : Closed e599819394702 ∧ code e599819394702 = 9395912416910 := by decide
theorem cert_e599819394702 : check e599819394702 [[.under]] .sourceHead = true := by decide
def e599819394758 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e599819394758 : Closed e599819394758 ∧ code e599819394758 = 9395912416966 := by decide
theorem cert_e599819394758 : check e599819394758 [[.under]] .sourceHead = true := by decide
def e599819396894 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e599819396894 : Closed e599819396894 ∧ code e599819396894 = 9395912419102 := by decide
theorem cert_e599819396894 : check e599819396894 [[.under]] .sourceHead = true := by decide
def e599819397006 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e599819397006 : Closed e599819397006 ∧ code e599819397006 = 9395912419214 := by decide
theorem cert_e599819397006 : check e599819397006 [[.under]] .sourceHead = true := by decide
def e599819399966 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e599819399966 : Closed e599819399966 ∧ code e599819399966 = 9395912422174 := by decide
theorem cert_e599819399966 : check e599819399966 [[.under]] .sourceHead = true := by decide
def e599819400134 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e599819400134 : Closed e599819400134 ∧ code e599819400134 = 9395912422342 := by decide
theorem cert_e599819400134 : check e599819400134 [[.under]] .sourceHead = true := by decide
def e599819401614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e599819401614 : Closed e599819401614 ∧ code e599819401614 = 9395912423822 := by decide
theorem cert_e599819401614 : check e599819401614 [[.under]] .sourceHead = true := by decide
def e599819401670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e599819401670 : Closed e599819401670 ∧ code e599819401670 = 9395912423878 := by decide
theorem cert_e599819401670 : check e599819401670 [[.under]] .sourceHead = true := by decide
def e599819404910 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e599819404910 : Closed e599819404910 ∧ code e599819404910 = 9395912427118 := by decide
theorem cert_e599819404910 : check e599819404910 [[.under]] .sourceHead = true := by decide
def e599819404922 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e599819404922 : Closed e599819404922 ∧ code e599819404922 = 9395912427130 := by decide
theorem cert_e599819404922 : check e599819404922 [[.under]] .sourceHead = true := by decide
def e599819405210 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e599819405210 : Closed e599819405210 ∧ code e599819405210 = 9395912427418 := by decide
theorem cert_e599819405210 : check e599819405210 [[.under]] .sourceHead = true := by decide
def e599819406446 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e599819406446 : Closed e599819406446 ∧ code e599819406446 = 9395912428654 := by decide
theorem cert_e599819406446 : check e599819406446 [[.under]] .sourceHead = true := by decide
def e599819406458 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e599819406458 : Closed e599819406458 ∧ code e599819406458 = 9395912428666 := by decide
theorem cert_e599819406458 : check e599819406458 [[.under]] .sourceHead = true := by decide
def e599819406622 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e599819406622 : Closed e599819406622 ∧ code e599819406622 = 9395912428830 := by decide
theorem cert_e599819406622 : check e599819406622 [[.under]] .sourceHead = true := by decide
def e599819406790 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e599819406790 : Closed e599819406790 ∧ code e599819406790 = 9395912428998 := by decide
theorem cert_e599819406790 : check e599819406790 [[.under]] .sourceHead = true := by decide
def e599819407130 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e599819407130 : Closed e599819407130 ∧ code e599819407130 = 9395912429338 := by decide
theorem cert_e599819407130 : check e599819407130 [[.under]] .sourceHead = true := by decide
def e599819407174 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e599819407174 : Closed e599819407174 ∧ code e599819407174 = 9395912429382 := by decide
theorem cert_e599819407174 : check e599819407174 [[.under]] .sourceHead = true := by decide
def e599819408158 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e599819408158 : Closed e599819408158 ∧ code e599819408158 = 9395912430366 := by decide
theorem cert_e599819408158 : check e599819408158 [[.under]] .sourceHead = true := by decide
def e599819408326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e599819408326 : Closed e599819408326 ∧ code e599819408326 = 9395912430534 := by decide
theorem cert_e599819408326 : check e599819408326 [[.under]] .sourceHead = true := by decide
def e599819410630 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e599819410630 : Closed e599819410630 ∧ code e599819410630 = 9395912432838 := by decide
theorem cert_e599819410630 : check e599819410630 [[.under]] .sourceHead = true := by decide
def e599819412278 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e599819412278 : Closed e599819412278 ∧ code e599819412278 = 9395912434486 := by decide
theorem cert_e599819412278 : check e599819412278 [[.under]] .sourceHead = true := by decide
def e599819412282 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e599819412282 : Closed e599819412282 ∧ code e599819412282 = 9395912434490 := by decide
theorem cert_e599819412282 : check e599819412282 [[.under]] .sourceHead = true := by decide
def e599819412378 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e599819412378 : Closed e599819412378 ∧ code e599819412378 = 9395912434586 := by decide
theorem cert_e599819412378 : check e599819412378 [[.under]] .sourceHead = true := by decide
def e599819413046 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e599819413046 : Closed e599819413046 ∧ code e599819413046 = 9395912435254 := by decide
theorem cert_e599819413046 : check e599819413046 [[.under]] .sourceHead = true := by decide
def e599819413050 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e599819413050 : Closed e599819413050 ∧ code e599819413050 = 9395912435258 := by decide
theorem cert_e599819413050 : check e599819413050 [[.under]] .sourceHead = true := by decide
def e599819413134 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e599819413134 : Closed e599819413134 ∧ code e599819413134 = 9395912435342 := by decide
theorem cert_e599819413134 : check e599819413134 [[.under]] .sourceHead = true := by decide
def e599819413190 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e599819413190 : Closed e599819413190 ∧ code e599819413190 = 9395912435398 := by decide
theorem cert_e599819413190 : check e599819413190 [[.under]] .sourceHead = true := by decide
def e599819413274 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e599819413274 : Closed e599819413274 ∧ code e599819413274 = 9395912435482 := by decide
theorem cert_e599819413274 : check e599819413274 [[.under]] .sourceHead = true := by decide
def e599819413318 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e599819413318 : Closed e599819413318 ∧ code e599819413318 = 9395912435526 := by decide
theorem cert_e599819413318 : check e599819413318 [[.under]] .sourceHead = true := by decide
def e599819413902 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e599819413902 : Closed e599819413902 ∧ code e599819413902 = 9395912436110 := by decide
theorem cert_e599819413902 : check e599819413902 [[.under]] .sourceHead = true := by decide
def e599819413958 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e599819413958 : Closed e599819413958 ∧ code e599819413958 = 9395912436166 := by decide
theorem cert_e599819413958 : check e599819413958 [[.under]] .sourceHead = true := by decide
def e599819414726 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e599819414726 : Closed e599819414726 ∧ code e599819414726 = 9395912436934 := by decide
theorem cert_e599819414726 : check e599819414726 [[.under]] .sourceHead = true := by decide
def e599819425502 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e599819425502 : Closed e599819425502 ∧ code e599819425502 = 9395912447710 := by decide
theorem cert_e599819425502 : check e599819425502 [[.under]] .sourceHead = true := by decide
def e599819425526 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e599819425526 : Closed e599819425526 ∧ code e599819425526 = 9395912447734 := by decide
theorem cert_e599819425526 : check e599819425526 [[.under]] .sourceHead = true := by decide
def e599819425630 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e599819425630 : Closed e599819425630 ∧ code e599819425630 = 9395912447838 := by decide
theorem cert_e599819425630 : check e599819425630 [[.under]] .sourceHead = true := by decide
def e599819425658 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e599819425658 : Closed e599819425658 ∧ code e599819425658 = 9395912447866 := by decide
theorem cert_e599819425658 : check e599819425658 [[.under]] .sourceHead = true := by decide
def e599819425750 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e599819425750 : Closed e599819425750 ∧ code e599819425750 = 9395912447958 := by decide
theorem cert_e599819425750 : check e599819425750 [[.under]] .sourceHead = true := by decide
def e599819425754 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e599819425754 : Closed e599819425754 ∧ code e599819425754 = 9395912447962 := by decide
theorem cert_e599819425754 : check e599819425754 [[.under]] .sourceHead = true := by decide
def e599819426270 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e599819426270 : Closed e599819426270 ∧ code e599819426270 = 9395912448478 := by decide
theorem cert_e599819426270 : check e599819426270 [[.under]] .sourceHead = true := by decide
def e599819426294 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e599819426294 : Closed e599819426294 ∧ code e599819426294 = 9395912448502 := by decide
theorem cert_e599819426294 : check e599819426294 [[.under]] .sourceHead = true := by decide
def e599819427038 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e599819427038 : Closed e599819427038 ∧ code e599819427038 = 9395912449246 := by decide
theorem cert_e599819427038 : check e599819427038 [[.under]] .sourceHead = true := by decide
def e599819427066 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e599819427066 : Closed e599819427066 ∧ code e599819427066 = 9395912449274 := by decide
theorem cert_e599819427066 : check e599819427066 [[.under]] .sourceHead = true := by decide
def e599819427638 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e599819427638 : Closed e599819427638 ∧ code e599819427638 = 9395912449846 := by decide
theorem cert_e599819427638 : check e599819427638 [[.under]] .sourceHead = true := by decide
def e599819427642 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e599819427642 : Closed e599819427642 ∧ code e599819427642 = 9395912449850 := by decide
theorem cert_e599819427642 : check e599819427642 [[.under]] .sourceHead = true := by decide
def e599819442414 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e599819442414 : Closed e599819442414 ∧ code e599819442414 = 9395912464622 := by decide
theorem cert_e599819442414 : check e599819442414 [[.under]] .sourceHead = true := by decide
def e599819442422 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e599819442422 : Closed e599819442422 ∧ code e599819442422 = 9395912464630 := by decide
theorem cert_e599819442422 : check e599819442422 [[.under]] .sourceHead = true := by decide
def e599819442974 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e599819442974 : Closed e599819442974 ∧ code e599819442974 = 9395912465182 := by decide
theorem cert_e599819442974 : check e599819442974 [[.under]] .sourceHead = true := by decide
def e599819443086 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e599819443086 : Closed e599819443086 ∧ code e599819443086 = 9395912465294 := by decide
theorem cert_e599819443086 : check e599819443086 [[.under]] .sourceHead = true := by decide
def e599819443310 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e599819443310 : Closed e599819443310 ∧ code e599819443310 = 9395912465518 := by decide
theorem cert_e599819443310 : check e599819443310 [[.under]] .sourceHead = true := by decide
def e599819443322 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e599819443322 : Closed e599819443322 ∧ code e599819443322 = 9395912465530 := by decide
theorem cert_e599819443322 : check e599819443322 [[.under]] .sourceHead = true := by decide
def e599819443486 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e599819443486 : Closed e599819443486 ∧ code e599819443486 = 9395912465694 := by decide
theorem cert_e599819443486 : check e599819443486 [[.under]] .sourceHead = true := by decide
def e599819443654 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e599819443654 : Closed e599819443654 ∧ code e599819443654 = 9395912465862 := by decide
theorem cert_e599819443654 : check e599819443654 [[.under]] .sourceHead = true := by decide
def e599819443766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e599819443766 : Closed e599819443766 ∧ code e599819443766 = 9395912465974 := by decide
theorem cert_e599819443766 : check e599819443766 [[.under]] .sourceHead = true := by decide
def e599819443770 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e599819443770 : Closed e599819443770 ∧ code e599819443770 = 9395912465978 := by decide
theorem cert_e599819443770 : check e599819443770 [[.under]] .sourceHead = true := by decide
def e599819443854 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e599819443854 : Closed e599819443854 ∧ code e599819443854 = 9395912466062 := by decide
theorem cert_e599819443854 : check e599819443854 [[.under]] .sourceHead = true := by decide
def e599819443910 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e599819443910 : Closed e599819443910 ∧ code e599819443910 = 9395912466118 := by decide
theorem cert_e599819443910 : check e599819443910 [[.under]] .sourceHead = true := by decide
def e599819446046 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e599819446046 : Closed e599819446046 ∧ code e599819446046 = 9395912468254 := by decide
theorem cert_e599819446046 : check e599819446046 [[.under]] .sourceHead = true := by decide
def e599819446158 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e599819446158 : Closed e599819446158 ∧ code e599819446158 = 9395912468366 := by decide
theorem cert_e599819446158 : check e599819446158 [[.under]] .sourceHead = true := by decide
def e599819449118 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e599819449118 : Closed e599819449118 ∧ code e599819449118 = 9395912471326 := by decide
theorem cert_e599819449118 : check e599819449118 [[.under]] .sourceHead = true := by decide
def e599819449286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e599819449286 : Closed e599819449286 ∧ code e599819449286 = 9395912471494 := by decide
theorem cert_e599819449286 : check e599819449286 [[.under]] .sourceHead = true := by decide
def e599819450766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e599819450766 : Closed e599819450766 ∧ code e599819450766 = 9395912472974 := by decide
theorem cert_e599819450766 : check e599819450766 [[.under]] .sourceHead = true := by decide
def e599819450822 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e599819450822 : Closed e599819450822 ∧ code e599819450822 = 9395912473030 := by decide
theorem cert_e599819450822 : check e599819450822 [[.under]] .sourceHead = true := by decide
def e599819488110 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e599819488110 : Closed e599819488110 ∧ code e599819488110 = 9395912510318 := by decide
theorem cert_e599819488110 : check e599819488110 [[.under]] .sourceHead = true := by decide
def e599819488118 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e599819488118 : Closed e599819488118 ∧ code e599819488118 = 9395912510326 := by decide
theorem cert_e599819488118 : check e599819488118 [[.under]] .sourceHead = true := by decide
def e599819488174 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e599819488174 : Closed e599819488174 ∧ code e599819488174 = 9395912510382 := by decide
theorem cert_e599819488174 : check e599819488174 [[.under]] .sourceHead = true := by decide
def e599819488186 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e599819488186 : Closed e599819488186 ∧ code e599819488186 = 9395912510394 := by decide
theorem cert_e599819488186 : check e599819488186 [[.under]] .sourceHead = true := by decide
def e599819488214 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e599819488214 : Closed e599819488214 ∧ code e599819488214 = 9395912510422 := by decide
theorem cert_e599819488214 : check e599819488214 [[.under]] .sourceHead = true := by decide
def e599819488218 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e599819488218 : Closed e599819488218 ∧ code e599819488218 = 9395912510426 := by decide
theorem cert_e599819488218 : check e599819488218 [[.under]] .sourceHead = true := by decide
def e599819488494 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e599819488494 : Closed e599819488494 ∧ code e599819488494 = 9395912510702 := by decide
theorem cert_e599819488494 : check e599819488494 [[.under]] .sourceHead = true := by decide
def e599819488502 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e599819488502 : Closed e599819488502 ∧ code e599819488502 = 9395912510710 := by decide
theorem cert_e599819488502 : check e599819488502 [[.under]] .sourceHead = true := by decide
def e599819488878 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e599819488878 : Closed e599819488878 ∧ code e599819488878 = 9395912511086 := by decide
theorem cert_e599819488878 : check e599819488878 [[.under]] .sourceHead = true := by decide
def e599819488890 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e599819488890 : Closed e599819488890 ∧ code e599819488890 = 9395912511098 := by decide
theorem cert_e599819488890 : check e599819488890 [[.under]] .sourceHead = true := by decide
def e599819489078 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e599819489078 : Closed e599819489078 ∧ code e599819489078 = 9395912511286 := by decide
theorem cert_e599819489078 : check e599819489078 [[.under]] .sourceHead = true := by decide
def e599819489082 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e599819489082 : Closed e599819489082 ∧ code e599819489082 = 9395912511290 := by decide
theorem cert_e599819489082 : check e599819489082 [[.under]] .sourceHead = true := by decide
def e599819496558 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e599819496558 : Closed e599819496558 ∧ code e599819496558 = 9395912518766 := by decide
theorem cert_e599819496558 : check e599819496558 [[.under]] .sourceHead = true := by decide
def e599819496570 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e599819496570 : Closed e599819496570 ∧ code e599819496570 = 9395912518778 := by decide
theorem cert_e599819496570 : check e599819496570 [[.under]] .sourceHead = true := by decide
def e599819496734 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e599819496734 : Closed e599819496734 ∧ code e599819496734 = 9395912518942 := by decide
theorem cert_e599819496734 : check e599819496734 [[.under]] .sourceHead = true := by decide
def e599819496902 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e599819496902 : Closed e599819496902 ∧ code e599819496902 = 9395912519110 := by decide
theorem cert_e599819496902 : check e599819496902 [[.under]] .sourceHead = true := by decide
def e599819497242 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e599819497242 : Closed e599819497242 ∧ code e599819497242 = 9395912519450 := by decide
theorem cert_e599819497242 : check e599819497242 [[.under]] .sourceHead = true := by decide
def e599819497286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e599819497286 : Closed e599819497286 ∧ code e599819497286 = 9395912519494 := by decide
theorem cert_e599819497286 : check e599819497286 [[.under]] .sourceHead = true := by decide
def e599819498270 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e599819498270 : Closed e599819498270 ∧ code e599819498270 = 9395912520478 := by decide
theorem cert_e599819498270 : check e599819498270 [[.under]] .sourceHead = true := by decide
def e599819498438 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e599819498438 : Closed e599819498438 ∧ code e599819498438 = 9395912520646 := by decide
theorem cert_e599819498438 : check e599819498438 [[.under]] .sourceHead = true := by decide
def e599819500742 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e599819500742 : Closed e599819500742 ∧ code e599819500742 = 9395912522950 := by decide
theorem cert_e599819500742 : check e599819500742 [[.under]] .sourceHead = true := by decide
def e599819523638 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e599819523638 : Closed e599819523638 ∧ code e599819523638 = 9395912545846 := by decide
theorem cert_e599819523638 : check e599819523638 [[.under]] .sourceHead = true := by decide
def e599819523642 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e599819523642 : Closed e599819523642 ∧ code e599819523642 = 9395912545850 := by decide
theorem cert_e599819523642 : check e599819523642 [[.under]] .sourceHead = true := by decide
def e599819523726 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e599819523726 : Closed e599819523726 ∧ code e599819523726 = 9395912545934 := by decide
theorem cert_e599819523726 : check e599819523726 [[.under]] .sourceHead = true := by decide
def e599819523782 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e599819523782 : Closed e599819523782 ∧ code e599819523782 = 9395912545990 := by decide
theorem cert_e599819523782 : check e599819523782 [[.under]] .sourceHead = true := by decide
def e599819523866 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e599819523866 : Closed e599819523866 ∧ code e599819523866 = 9395912546074 := by decide
theorem cert_e599819523866 : check e599819523866 [[.under]] .sourceHead = true := by decide
def e599819523910 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e599819523910 : Closed e599819523910 ∧ code e599819523910 = 9395912546118 := by decide
theorem cert_e599819523910 : check e599819523910 [[.under]] .sourceHead = true := by decide
def e599819524494 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e599819524494 : Closed e599819524494 ∧ code e599819524494 = 9395912546702 := by decide
theorem cert_e599819524494 : check e599819524494 [[.under]] .sourceHead = true := by decide
def e599819524550 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e599819524550 : Closed e599819524550 ∧ code e599819524550 = 9395912546758 := by decide
theorem cert_e599819524550 : check e599819524550 [[.under]] .sourceHead = true := by decide
def e599819525318 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e599819525318 : Closed e599819525318 ∧ code e599819525318 = 9395912547526 := by decide
theorem cert_e599819525318 : check e599819525318 [[.under]] .sourceHead = true := by decide
def e599820622062 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e599820622062 : Closed e599820622062 ∧ code e599820622062 = 9395913644270 := by decide
theorem cert_e599820622062 : check e599820622062 [[.under]] .sourceHead = true := by decide
def e599820622070 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e599820622070 : Closed e599820622070 ∧ code e599820622070 = 9395913644278 := by decide
theorem cert_e599820622070 : check e599820622070 [[.under]] .sourceHead = true := by decide
def e599820622622 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e599820622622 : Closed e599820622622 ∧ code e599820622622 = 9395913644830 := by decide
theorem cert_e599820622622 : check e599820622622 [[.under]] .sourceHead = true := by decide
def e599820622734 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e599820622734 : Closed e599820622734 ∧ code e599820622734 = 9395913644942 := by decide
theorem cert_e599820622734 : check e599820622734 [[.under]] .sourceHead = true := by decide
def e599820622958 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e599820622958 : Closed e599820622958 ∧ code e599820622958 = 9395913645166 := by decide
theorem cert_e599820622958 : check e599820622958 [[.under]] .sourceHead = true := by decide
def e599820622970 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e599820622970 : Closed e599820622970 ∧ code e599820622970 = 9395913645178 := by decide
theorem cert_e599820622970 : check e599820622970 [[.under]] .sourceHead = true := by decide
def e599820623134 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e599820623134 : Closed e599820623134 ∧ code e599820623134 = 9395913645342 := by decide
theorem cert_e599820623134 : check e599820623134 [[.under]] .sourceHead = true := by decide
def e599820623302 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e599820623302 : Closed e599820623302 ∧ code e599820623302 = 9395913645510 := by decide
theorem cert_e599820623302 : check e599820623302 [[.under]] .sourceHead = true := by decide
def e599820623414 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e599820623414 : Closed e599820623414 ∧ code e599820623414 = 9395913645622 := by decide
theorem cert_e599820623414 : check e599820623414 [[.under]] .sourceHead = true := by decide
def e599820623418 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e599820623418 : Closed e599820623418 ∧ code e599820623418 = 9395913645626 := by decide
theorem cert_e599820623418 : check e599820623418 [[.under]] .sourceHead = true := by decide
def e599820623502 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e599820623502 : Closed e599820623502 ∧ code e599820623502 = 9395913645710 := by decide
theorem cert_e599820623502 : check e599820623502 [[.under]] .sourceHead = true := by decide
def e599820623558 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e599820623558 : Closed e599820623558 ∧ code e599820623558 = 9395913645766 := by decide
theorem cert_e599820623558 : check e599820623558 [[.under]] .sourceHead = true := by decide
def e599820625694 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e599820625694 : Closed e599820625694 ∧ code e599820625694 = 9395913647902 := by decide
theorem cert_e599820625694 : check e599820625694 [[.under]] .sourceHead = true := by decide
def e599820625806 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e599820625806 : Closed e599820625806 ∧ code e599820625806 = 9395913648014 := by decide
theorem cert_e599820625806 : check e599820625806 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
