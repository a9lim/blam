import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2408276260378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408276260378 : Closed e2408276260378 ∧ code e2408276260378 = 11204369282586 := by decide
private def t_e2408276260378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408276260378 : ¬ IsSelfInterpreter e2408276260378 :=
  wSource (t := t_e2408276260378) (replay_sound (ps := []) (t := e2408276260378) (by decide)) (by decide)
def e2408276284954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408276284954 : Closed e2408276284954 ∧ code e2408276284954 = 11204369307162 := by decide
private def t_e2408276284954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408276284954 : ¬ IsSelfInterpreter e2408276284954 :=
  wSource (t := t_e2408276284954) (replay_sound (ps := []) (t := e2408276284954) (by decide)) (by decide)
def e2408276669978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408276669978 : Closed e2408276669978 ∧ code e2408276669978 = 11204369692186 := by decide
private def t_e2408276669978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408276669978 : ¬ IsSelfInterpreter e2408276669978 :=
  wSource (t := t_e2408276669978) (replay_sound (ps := []) (t := e2408276669978) (by decide)) (by decide)
def e2408276678170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408276678170 : Closed e2408276678170 ∧ code e2408276678170 = 11204369700378 := by decide
private def t_e2408276678170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408276678170 : ¬ IsSelfInterpreter e2408276678170 :=
  wSource (t := t_e2408276678170) (replay_sound (ps := []) (t := e2408276678170) (by decide)) (by decide)
def e2408319774234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319774234 : Closed e2408319774234 ∧ code e2408319774234 = 11204412796442 := by decide
private def t_e2408319774234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319774234 : ¬ IsSelfInterpreter e2408319774234 :=
  wSource (t := t_e2408319774234) (replay_sound (ps := []) (t := e2408319774234) (by decide)) (by decide)
def e2408319776282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319776282 : Closed e2408319776282 ∧ code e2408319776282 = 11204412798490 := by decide
private def t_e2408319776282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319776282 : ¬ IsSelfInterpreter e2408319776282 :=
  wSource (t := t_e2408319776282) (replay_sound (ps := []) (t := e2408319776282) (by decide)) (by decide)
def e2408319790618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319790618 : Closed e2408319790618 ∧ code e2408319790618 = 11204412812826 := by decide
private def t_e2408319790618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319790618 : ¬ IsSelfInterpreter e2408319790618 :=
  wSource (t := t_e2408319790618) (replay_sound (ps := []) (t := e2408319790618) (by decide)) (by decide)
def e2408319793690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319793690 : Closed e2408319793690 ∧ code e2408319793690 = 11204412815898 := by decide
private def t_e2408319793690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319793690 : ¬ IsSelfInterpreter e2408319793690 :=
  wSource (t := t_e2408319793690) (replay_sound (ps := []) (t := e2408319793690) (by decide)) (by decide)
def e2408319800858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319800858 : Closed e2408319800858 ∧ code e2408319800858 = 11204412823066 := by decide
private def t_e2408319800858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319800858 : ¬ IsSelfInterpreter e2408319800858 :=
  wSource (t := t_e2408319800858) (replay_sound (ps := []) (t := e2408319800858) (by decide)) (by decide)
def e2408319801882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319801882 : Closed e2408319801882 ∧ code e2408319801882 = 11204412824090 := by decide
private def t_e2408319801882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319801882 : ¬ IsSelfInterpreter e2408319801882 :=
  wSource (t := t_e2408319801882) (replay_sound (ps := []) (t := e2408319801882) (by decide)) (by decide)
def e2408319872538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319872538 : Closed e2408319872538 ∧ code e2408319872538 = 11204412894746 := by decide
private def t_e2408319872538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319872538 : ¬ IsSelfInterpreter e2408319872538 :=
  wSource (t := t_e2408319872538) (replay_sound (ps := []) (t := e2408319872538) (by decide)) (by decide)
def e2408319874586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319874586 : Closed e2408319874586 ∧ code e2408319874586 = 11204412896794 := by decide
private def t_e2408319874586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319874586 : ¬ IsSelfInterpreter e2408319874586 :=
  wSource (t := t_e2408319874586) (replay_sound (ps := []) (t := e2408319874586) (by decide)) (by decide)
def e2408319970842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319970842 : Closed e2408319970842 ∧ code e2408319970842 = 11204412993050 := by decide
private def t_e2408319970842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319970842 : ¬ IsSelfInterpreter e2408319970842 :=
  wSource (t := t_e2408319970842) (replay_sound (ps := []) (t := e2408319970842) (by decide)) (by decide)
def e2408319973914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408319973914 : Closed e2408319973914 ∧ code e2408319973914 = 11204412996122 := by decide
private def t_e2408319973914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408319973914 : ¬ IsSelfInterpreter e2408319973914 :=
  wSource (t := t_e2408319973914) (replay_sound (ps := []) (t := e2408319973914) (by decide)) (by decide)
def e2408320022042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408320022042 : Closed e2408320022042 ∧ code e2408320022042 = 11204413044250 := by decide
private def t_e2408320022042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408320022042 : ¬ IsSelfInterpreter e2408320022042 :=
  wSource (t := t_e2408320022042) (replay_sound (ps := []) (t := e2408320022042) (by decide)) (by decide)
def e2408320023066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408320023066 : Closed e2408320023066 ∧ code e2408320023066 = 11204413045274 := by decide
private def t_e2408320023066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408320023066 : ¬ IsSelfInterpreter e2408320023066 :=
  wSource (t := t_e2408320023066) (replay_sound (ps := []) (t := e2408320023066) (by decide)) (by decide)
def e2408414900422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408414900422 : Closed e2408414900422 ∧ code e2408414900422 = 11204507922630 := by decide
theorem cert_e2408414900422 : check e2408414900422 [[]] .width = true := by decide
def e2408414949574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408414949574 : Closed e2408414949574 ∧ code e2408414949574 = 11204507971782 := by decide
theorem cert_e2408414949574 : check e2408414949574 [[]] .width = true := by decide
def e2408415162566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408415162566 : Closed e2408415162566 ∧ code e2408415162566 = 11204508184774 := by decide
theorem cert_e2408415162566 : check e2408415162566 [[]] .width = true := by decide
def e2408415219910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408415219910 : Closed e2408415219910 ∧ code e2408415219910 = 11204508242118 := by decide
theorem cert_e2408415219910 : check e2408415219910 [[]] .width = true := by decide
def e2408415408326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408415408326 : Closed e2408415408326 ∧ code e2408415408326 = 11204508430534 := by decide
theorem cert_e2408415408326 : check e2408415408326 [[]] .width = true := by decide
def e2408415416518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408415416518 : Closed e2408415416518 ∧ code e2408415416518 = 11204508438726 := by decide
theorem cert_e2408415416518 : check e2408415416518 [[]] .width = true := by decide
def e2408416473286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408416473286 : Closed e2408416473286 ∧ code e2408416473286 = 11204509495494 := by decide
theorem cert_e2408416473286 : check e2408416473286 [[]] .width = true := by decide
def e2408416522438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408416522438 : Closed e2408416522438 ∧ code e2408416522438 = 11204509544646 := by decide
theorem cert_e2408416522438 : check e2408416522438 [[]] .width = true := by decide
def e2408418046150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408418046150 : Closed e2408418046150 ∧ code e2408418046150 = 11204511068358 := by decide
theorem cert_e2408418046150 : check e2408418046150 [[]] .width = true := by decide
def e2408418103494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408418103494 : Closed e2408418103494 ∧ code e2408418103494 = 11204511125702 := by decide
theorem cert_e2408418103494 : check e2408418103494 [[]] .width = true := by decide
def e2408419274950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408419274950 : Closed e2408419274950 ∧ code e2408419274950 = 11204512297158 := by decide
theorem cert_e2408419274950 : check e2408419274950 [[]] .width = true := by decide
def e2408419283142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408419283142 : Closed e2408419283142 ∧ code e2408419283142 = 11204512305350 := by decide
theorem cert_e2408419283142 : check e2408419283142 [[]] .width = true := by decide
def e2408448374810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448374810 : Closed e2408448374810 ∧ code e2408448374810 = 11204541397018 := by decide
theorem cert_e2408448374810 : check e2408448374810 [[]] .width = true := by decide
def e2408448383002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448383002 : Closed e2408448383002 ∧ code e2408448383002 = 11204541405210 := by decide
theorem cert_e2408448383002 : check e2408448383002 [[]] .width = true := by decide
def e2408448440346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448440346 : Closed e2408448440346 ∧ code e2408448440346 = 11204541462554 := by decide
theorem cert_e2408448440346 : check e2408448440346 [[]] .width = true := by decide
def e2408448452634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448452634 : Closed e2408448452634 ∧ code e2408448452634 = 11204541474842 := by decide
theorem cert_e2408448452634 : check e2408448452634 [[]] .width = true := by decide
def e2408448454170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448454170 : Closed e2408448454170 ∧ code e2408448454170 = 11204541476378 := by decide
private def t_e2408448454170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448454170 : ¬ IsSelfInterpreter e2408448454170 :=
  wSource (t := t_e2408448454170) (replay_sound (ps := []) (t := e2408448454170) (by decide)) (by decide)
def e2408448481306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448481306 : Closed e2408448481306 ∧ code e2408448481306 = 11204541503514 := by decide
theorem cert_e2408448481306 : check e2408448481306 [[]] .width = true := by decide
def e2408448485402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448485402 : Closed e2408448485402 ∧ code e2408448485402 = 11204541507610 := by decide
theorem cert_e2408448485402 : check e2408448485402 [[]] .width = true := by decide
def e2408448486938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448486938 : Closed e2408448486938 ∧ code e2408448486938 = 11204541509146 := by decide
private def t_e2408448486938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448486938 : ¬ IsSelfInterpreter e2408448486938 :=
  wSource (t := t_e2408448486938) (replay_sound (ps := []) (t := e2408448486938) (by decide)) (by decide)
def e2408448488986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448488986 : Closed e2408448488986 ∧ code e2408448488986 = 11204541511194 := by decide
private def t_e2408448488986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448488986 : ¬ IsSelfInterpreter e2408448488986 :=
  wSource (t := t_e2408448488986) (replay_sound (ps := []) (t := e2408448488986) (by decide)) (by decide)
def e2408448702490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448702490 : Closed e2408448702490 ∧ code e2408448702490 = 11204541724698 := by decide
theorem cert_e2408448702490 : check e2408448702490 [[]] .width = true := by decide
def e2408448714778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448714778 : Closed e2408448714778 ∧ code e2408448714778 = 11204541736986 := by decide
theorem cert_e2408448714778 : check e2408448714778 [[]] .width = true := by decide
def e2408448716314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448716314 : Closed e2408448716314 ∧ code e2408448716314 = 11204541738522 := by decide
private def t_e2408448716314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448716314 : ¬ IsSelfInterpreter e2408448716314 :=
  wSource (t := t_e2408448716314) (replay_sound (ps := []) (t := e2408448716314) (by decide)) (by decide)
def e2408448763930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448763930 : Closed e2408448763930 ∧ code e2408448763930 = 11204541786138 := by decide
theorem cert_e2408448763930 : check e2408448763930 [[]] .width = true := by decide
def e2408448765466 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448765466 : Closed e2408448765466 ∧ code e2408448765466 = 11204541787674 := by decide
private def t_e2408448765466 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448765466 : ¬ IsSelfInterpreter e2408448765466 :=
  wSource (t := t_e2408448765466) (replay_sound (ps := []) (t := e2408448765466) (by decide)) (by decide)
def e2408448768538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448768538 : Closed e2408448768538 ∧ code e2408448768538 = 11204541790746 := by decide
private def t_e2408448768538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448768538 : ¬ IsSelfInterpreter e2408448768538 :=
  wSource (t := t_e2408448768538) (replay_sound (ps := []) (t := e2408448768538) (by decide)) (by decide)
def e2408448874522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448874522 : Closed e2408448874522 ∧ code e2408448874522 = 11204541896730 := by decide
theorem cert_e2408448874522 : check e2408448874522 [[]] .width = true := by decide
def e2408448878618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448878618 : Closed e2408448878618 ∧ code e2408448878618 = 11204541900826 := by decide
theorem cert_e2408448878618 : check e2408448878618 [[]] .width = true := by decide
def e2408448880154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448880154 : Closed e2408448880154 ∧ code e2408448880154 = 11204541902362 := by decide
private def t_e2408448880154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448880154 : ¬ IsSelfInterpreter e2408448880154 :=
  wSource (t := t_e2408448880154) (replay_sound (ps := []) (t := e2408448880154) (by decide)) (by decide)
def e2408448882202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448882202 : Closed e2408448882202 ∧ code e2408448882202 = 11204541904410 := by decide
private def t_e2408448882202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448882202 : ¬ IsSelfInterpreter e2408448882202 :=
  wSource (t := t_e2408448882202) (replay_sound (ps := []) (t := e2408448882202) (by decide)) (by decide)
def e2408448895002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408448895002 : Closed e2408448895002 ∧ code e2408448895002 = 11204541917210 := by decide
theorem cert_e2408448895002 : check e2408448895002 [[]] .width = true := by decide
def e2408448896538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448896538 : Closed e2408448896538 ∧ code e2408448896538 = 11204541918746 := by decide
private def t_e2408448896538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448896538 : ¬ IsSelfInterpreter e2408448896538 :=
  wSource (t := t_e2408448896538) (replay_sound (ps := []) (t := e2408448896538) (by decide)) (by decide)
def e2408448899610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448899610 : Closed e2408448899610 ∧ code e2408448899610 = 11204541921818 := by decide
private def t_e2408448899610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448899610 : ¬ IsSelfInterpreter e2408448899610 :=
  wSource (t := t_e2408448899610) (replay_sound (ps := []) (t := e2408448899610) (by decide)) (by decide)
def e2408448906778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448906778 : Closed e2408448906778 ∧ code e2408448906778 = 11204541928986 := by decide
private def t_e2408448906778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448906778 : ¬ IsSelfInterpreter e2408448906778 :=
  wSource (t := t_e2408448906778) (replay_sound (ps := []) (t := e2408448906778) (by decide)) (by decide)
def e2408448907802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408448907802 : Closed e2408448907802 ∧ code e2408448907802 = 11204541930010 := by decide
private def t_e2408448907802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408448907802 : ¬ IsSelfInterpreter e2408448907802 :=
  wSource (t := t_e2408448907802) (replay_sound (ps := []) (t := e2408448907802) (by decide)) (by decide)
def e2408449536198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408449536198 : Closed e2408449536198 ∧ code e2408449536198 = 11204542558406 := by decide
theorem cert_e2408449536198 : check e2408449536198 [[]] .width = true := by decide
def e2408449552582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408449552582 : Closed e2408449552582 ∧ code e2408449552582 = 11204542574790 := by decide
theorem cert_e2408449552582 : check e2408449552582 [[]] .width = true := by decide
def e2408449947674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408449947674 : Closed e2408449947674 ∧ code e2408449947674 = 11204542969882 := by decide
theorem cert_e2408449947674 : check e2408449947674 [[]] .width = true := by decide
def e2408449955866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408449955866 : Closed e2408449955866 ∧ code e2408449955866 = 11204542978074 := by decide
theorem cert_e2408449955866 : check e2408449955866 [[]] .width = true := by decide
def e2408450013210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450013210 : Closed e2408450013210 ∧ code e2408450013210 = 11204543035418 := by decide
theorem cert_e2408450013210 : check e2408450013210 [[]] .width = true := by decide
def e2408450025498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450025498 : Closed e2408450025498 ∧ code e2408450025498 = 11204543047706 := by decide
theorem cert_e2408450025498 : check e2408450025498 [[]] .width = true := by decide
def e2408450027034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408450027034 : Closed e2408450027034 ∧ code e2408450027034 = 11204543049242 := by decide
private def t_e2408450027034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408450027034 : ¬ IsSelfInterpreter e2408450027034 :=
  wSource (t := t_e2408450027034) (replay_sound (ps := []) (t := e2408450027034) (by decide)) (by decide)
def e2408450054170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450054170 : Closed e2408450054170 ∧ code e2408450054170 = 11204543076378 := by decide
theorem cert_e2408450054170 : check e2408450054170 [[]] .width = true := by decide
def e2408450058266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450058266 : Closed e2408450058266 ∧ code e2408450058266 = 11204543080474 := by decide
theorem cert_e2408450058266 : check e2408450058266 [[]] .width = true := by decide
def e2408450059802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408450059802 : Closed e2408450059802 ∧ code e2408450059802 = 11204543082010 := by decide
private def t_e2408450059802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408450059802 : ¬ IsSelfInterpreter e2408450059802 :=
  wSource (t := t_e2408450059802) (replay_sound (ps := []) (t := e2408450059802) (by decide)) (by decide)
def e2408450061850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408450061850 : Closed e2408450061850 ∧ code e2408450061850 = 11204543084058 := by decide
private def t_e2408450061850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408450061850 : ¬ IsSelfInterpreter e2408450061850 :=
  wSource (t := t_e2408450061850) (replay_sound (ps := []) (t := e2408450061850) (by decide)) (by decide)
def e2408450340890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450340890 : Closed e2408450340890 ∧ code e2408450340890 = 11204543363098 := by decide
theorem cert_e2408450340890 : check e2408450340890 [[]] .width = true := by decide
def e2408450349082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450349082 : Closed e2408450349082 ∧ code e2408450349082 = 11204543371290 := by decide
theorem cert_e2408450349082 : check e2408450349082 [[]] .width = true := by decide
def e2408450683078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408450683078 : Closed e2408450683078 ∧ code e2408450683078 = 11204543705286 := by decide
theorem cert_e2408450683078 : check e2408450683078 [[]] .width = true := by decide
def e2408450734106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450734106 : Closed e2408450734106 ∧ code e2408450734106 = 11204543756314 := by decide
theorem cert_e2408450734106 : check e2408450734106 [[]] .width = true := by decide
def e2408450746394 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450746394 : Closed e2408450746394 ∧ code e2408450746394 = 11204543768602 := by decide
theorem cert_e2408450746394 : check e2408450746394 [[]] .width = true := by decide
def e2408450747930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408450747930 : Closed e2408450747930 ∧ code e2408450747930 = 11204543770138 := by decide
private def t_e2408450747930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408450747930 : ¬ IsSelfInterpreter e2408450747930 :=
  wSource (t := t_e2408450747930) (replay_sound (ps := []) (t := e2408450747930) (by decide)) (by decide)
def e2408450850842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408450850842 : Closed e2408450850842 ∧ code e2408450850842 = 11204543873050 := by decide
theorem cert_e2408450850842 : check e2408450850842 [[]] .width = true := by decide
def e2408450850934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408450850934 : Closed e2408450850934 ∧ code e2408450850934 = 11204543873142 := by decide
theorem cert_e2408450850934 : check e2408450850934 [[]] .width = true := by decide
def e2408450851178 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408450851178 : Closed e2408450851178 ∧ code e2408450851178 = 11204543873386 := by decide
theorem cert_e2408450851178 : check e2408450851178 [[]] .width = true := by decide
def e2408450851226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408450851226 : Closed e2408450851226 ∧ code e2408450851226 = 11204543873434 := by decide
theorem cert_e2408450851226 : check e2408450851226 [[]] .width = true := by decide
def e2408450852234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408450852234 : Closed e2408450852234 ∧ code e2408450852234 = 11204543874442 := by decide
theorem cert_e2408450852234 : check e2408450852234 [[]] .width = true := by decide
def e2408450852258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408450852258 : Closed e2408450852258 ∧ code e2408450852258 = 11204543874466 := by decide
private def t_e2408450852258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408450852258 : ¬ IsSelfInterpreter e2408450852258 :=
  wSource (t := t_e2408450852258) (replay_sound (ps := []) (t := e2408450852258) (by decide)) (by decide)
def e2408450852366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408450852366 : Closed e2408450852366 ∧ code e2408450852366 = 11204543874574 := by decide
theorem cert_e2408450852366 : check e2408450852366 [[]] .width = true := by decide
def e2408450852378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408450852378 : Closed e2408450852378 ∧ code e2408450852378 = 11204543874586 := by decide
private def t_e2408450852378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408450852378 : ¬ IsSelfInterpreter e2408450852378 :=
  wSource (t := t_e2408450852378) (replay_sound (ps := []) (t := e2408450852378) (by decide)) (by decide)
def e2408450852450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408450852450 : Closed e2408450852450 ∧ code e2408450852450 = 11204543874658 := by decide
theorem cert_e2408450852450 : check e2408450852450 [[]] .width = true := by decide
def e2408450912454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408450912454 : Closed e2408450912454 ∧ code e2408450912454 = 11204543934662 := by decide
theorem cert_e2408450912454 : check e2408450912454 [[]] .width = true := by decide
def e2408450938906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450938906 : Closed e2408450938906 ∧ code e2408450938906 = 11204543961114 := by decide
theorem cert_e2408450938906 : check e2408450938906 [[]] .width = true := by decide
def e2408450943002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408450943002 : Closed e2408450943002 ∧ code e2408450943002 = 11204543965210 := by decide
theorem cert_e2408450943002 : check e2408450943002 [[]] .width = true := by decide
def e2408450944538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408450944538 : Closed e2408450944538 ∧ code e2408450944538 = 11204543966746 := by decide
private def t_e2408450944538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408450944538 : ¬ IsSelfInterpreter e2408450944538 :=
  wSource (t := t_e2408450944538) (replay_sound (ps := []) (t := e2408450944538) (by decide)) (by decide)
def e2408450946586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408450946586 : Closed e2408450946586 ∧ code e2408450946586 = 11204543968794 := by decide
private def t_e2408450946586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408450946586 : ¬ IsSelfInterpreter e2408450946586 :=
  wSource (t := t_e2408450946586) (replay_sound (ps := []) (t := e2408450946586) (by decide)) (by decide)
def e2408450981914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408450981914 : Closed e2408450981914 ∧ code e2408450981914 = 11204544004122 := by decide
theorem cert_e2408450981914 : check e2408450981914 [[]] .width = true := by decide
def e2408450982006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408450982006 : Closed e2408450982006 ∧ code e2408450982006 = 11204544004214 := by decide
theorem cert_e2408450982006 : check e2408450982006 [[]] .width = true := by decide
def e2408450982250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408450982250 : Closed e2408450982250 ∧ code e2408450982250 = 11204544004458 := by decide
theorem cert_e2408450982250 : check e2408450982250 [[]] .width = true := by decide
def e2408450982298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408450982298 : Closed e2408450982298 ∧ code e2408450982298 = 11204544004506 := by decide
theorem cert_e2408450982298 : check e2408450982298 [[]] .width = true := by decide
def e2408450983306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408450983306 : Closed e2408450983306 ∧ code e2408450983306 = 11204544005514 := by decide
theorem cert_e2408450983306 : check e2408450983306 [[]] .width = true := by decide
def e2408450983330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408450983330 : Closed e2408450983330 ∧ code e2408450983330 = 11204544005538 := by decide
private def t_e2408450983330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408450983330 : ¬ IsSelfInterpreter e2408450983330 :=
  wSource (t := t_e2408450983330) (replay_sound (ps := []) (t := e2408450983330) (by decide)) (by decide)
def e2408450983438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408450983438 : Closed e2408450983438 ∧ code e2408450983438 = 11204544005646 := by decide
theorem cert_e2408450983438 : check e2408450983438 [[]] .width = true := by decide
def e2408450983450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408450983450 : Closed e2408450983450 ∧ code e2408450983450 = 11204544005658 := by decide
private def t_e2408450983450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408450983450 : ¬ IsSelfInterpreter e2408450983450 :=
  wSource (t := t_e2408450983450) (replay_sound (ps := []) (t := e2408450983450) (by decide)) (by decide)
def e2408450983522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408450983522 : Closed e2408450983522 ∧ code e2408450983522 = 11204544005730 := by decide
theorem cert_e2408450983522 : check e2408450983522 [[]] .width = true := by decide
def e2408451371206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408451371206 : Closed e2408451371206 ∧ code e2408451371206 = 11204544393414 := by decide
theorem cert_e2408451371206 : check e2408451371206 [[]] .width = true := by decide
def e2408451395782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408451395782 : Closed e2408451395782 ∧ code e2408451395782 = 11204544417990 := by decide
theorem cert_e2408451395782 : check e2408451395782 [[]] .width = true := by decide
def e2408451586074 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408451586074 : Closed e2408451586074 ∧ code e2408451586074 = 11204544608282 := by decide
theorem cert_e2408451586074 : check e2408451586074 [[]] .width = true := by decide
def e2408451598362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408451598362 : Closed e2408451598362 ∧ code e2408451598362 = 11204544620570 := by decide
theorem cert_e2408451598362 : check e2408451598362 [[]] .width = true := by decide
def e2408451599898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408451599898 : Closed e2408451599898 ∧ code e2408451599898 = 11204544622106 := by decide
private def t_e2408451599898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408451599898 : ¬ IsSelfInterpreter e2408451599898 :=
  wSource (t := t_e2408451599898) (replay_sound (ps := []) (t := e2408451599898) (by decide)) (by decide)
def e2408451647514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408451647514 : Closed e2408451647514 ∧ code e2408451647514 = 11204544669722 := by decide
theorem cert_e2408451647514 : check e2408451647514 [[]] .width = true := by decide
def e2408451649050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408451649050 : Closed e2408451649050 ∧ code e2408451649050 = 11204544671258 := by decide
private def t_e2408451649050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408451649050 : ¬ IsSelfInterpreter e2408451649050 :=
  wSource (t := t_e2408451649050) (replay_sound (ps := []) (t := e2408451649050) (by decide)) (by decide)
def e2408451652122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408451652122 : Closed e2408451652122 ∧ code e2408451652122 = 11204544674330 := by decide
private def t_e2408451652122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408451652122 : ¬ IsSelfInterpreter e2408451652122 :=
  wSource (t := t_e2408451652122) (replay_sound (ps := []) (t := e2408451652122) (by decide)) (by decide)
def e2408451731654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408451731654 : Closed e2408451731654 ∧ code e2408451731654 = 11204544753862 := by decide
theorem cert_e2408451731654 : check e2408451731654 [[]] .width = true := by decide
def e2408451782682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408451782682 : Closed e2408451782682 ∧ code e2408451782682 = 11204544804890 := by decide
theorem cert_e2408451782682 : check e2408451782682 [[]] .width = true := by decide
def e2408451794970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408451794970 : Closed e2408451794970 ∧ code e2408451794970 = 11204544817178 := by decide
theorem cert_e2408451794970 : check e2408451794970 [[]] .width = true := by decide
def e2408451796506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408451796506 : Closed e2408451796506 ∧ code e2408451796506 = 11204544818714 := by decide
private def t_e2408451796506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408451796506 : ¬ IsSelfInterpreter e2408451796506 :=
  wSource (t := t_e2408451796506) (replay_sound (ps := []) (t := e2408451796506) (by decide)) (by decide)
def e2408451899418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408451899418 : Closed e2408451899418 ∧ code e2408451899418 = 11204544921626 := by decide
theorem cert_e2408451899418 : check e2408451899418 [[]] .width = true := by decide
def e2408451899510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408451899510 : Closed e2408451899510 ∧ code e2408451899510 = 11204544921718 := by decide
theorem cert_e2408451899510 : check e2408451899510 [[]] .width = true := by decide
def e2408451899754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408451899754 : Closed e2408451899754 ∧ code e2408451899754 = 11204544921962 := by decide
theorem cert_e2408451899754 : check e2408451899754 [[]] .width = true := by decide
def e2408451899802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408451899802 : Closed e2408451899802 ∧ code e2408451899802 = 11204544922010 := by decide
theorem cert_e2408451899802 : check e2408451899802 [[]] .width = true := by decide
def e2408451900810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408451900810 : Closed e2408451900810 ∧ code e2408451900810 = 11204544923018 := by decide
theorem cert_e2408451900810 : check e2408451900810 [[]] .width = true := by decide
def e2408451900834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408451900834 : Closed e2408451900834 ∧ code e2408451900834 = 11204544923042 := by decide
private def t_e2408451900834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408451900834 : ¬ IsSelfInterpreter e2408451900834 :=
  wSource (t := t_e2408451900834) (replay_sound (ps := []) (t := e2408451900834) (by decide)) (by decide)
def e2408451900942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408451900942 : Closed e2408451900942 ∧ code e2408451900942 = 11204544923150 := by decide
theorem cert_e2408451900942 : check e2408451900942 [[]] .width = true := by decide
def e2408451900954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408451900954 : Closed e2408451900954 ∧ code e2408451900954 = 11204544923162 := by decide
private def t_e2408451900954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408451900954 : ¬ IsSelfInterpreter e2408451900954 :=
  wSource (t := t_e2408451900954) (replay_sound (ps := []) (t := e2408451900954) (by decide)) (by decide)
def e2408451901026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408451901026 : Closed e2408451901026 ∧ code e2408451901026 = 11204544923234 := by decide
theorem cert_e2408451901026 : check e2408451901026 [[]] .width = true := by decide
def e2408452075718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408452075718 : Closed e2408452075718 ∧ code e2408452075718 = 11204545097926 := by decide
theorem cert_e2408452075718 : check e2408452075718 [[]] .width = true := by decide
def e2408452089882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408452089882 : Closed e2408452089882 ∧ code e2408452089882 = 11204545112090 := by decide
theorem cert_e2408452089882 : check e2408452089882 [[]] .width = true := by decide
def e2408452091418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452091418 : Closed e2408452091418 ∧ code e2408452091418 = 11204545113626 := by decide
private def t_e2408452091418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452091418 : ¬ IsSelfInterpreter e2408452091418 :=
  wSource (t := t_e2408452091418) (replay_sound (ps := []) (t := e2408452091418) (by decide)) (by decide)
def e2408452094490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452094490 : Closed e2408452094490 ∧ code e2408452094490 = 11204545116698 := by decide
private def t_e2408452094490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452094490 : ¬ IsSelfInterpreter e2408452094490 :=
  wSource (t := t_e2408452094490) (replay_sound (ps := []) (t := e2408452094490) (by decide)) (by decide)
def e2408452096026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408452096026 : Closed e2408452096026 ∧ code e2408452096026 = 11204545118234 := by decide
theorem cert_e2408452096026 : check e2408452096026 [[]] .width = true := by decide
def e2408452096118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408452096118 : Closed e2408452096118 ∧ code e2408452096118 = 11204545118326 := by decide
theorem cert_e2408452096118 : check e2408452096118 [[]] .width = true := by decide
def e2408452096362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408452096362 : Closed e2408452096362 ∧ code e2408452096362 = 11204545118570 := by decide
theorem cert_e2408452096362 : check e2408452096362 [[]] .width = true := by decide
def e2408452096410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408452096410 : Closed e2408452096410 ∧ code e2408452096410 = 11204545118618 := by decide
theorem cert_e2408452096410 : check e2408452096410 [[]] .width = true := by decide
def e2408452097418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408452097418 : Closed e2408452097418 ∧ code e2408452097418 = 11204545119626 := by decide
theorem cert_e2408452097418 : check e2408452097418 [[]] .width = true := by decide
def e2408452097442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408452097442 : Closed e2408452097442 ∧ code e2408452097442 = 11204545119650 := by decide
private def t_e2408452097442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408452097442 : ¬ IsSelfInterpreter e2408452097442 :=
  wSource (t := t_e2408452097442) (replay_sound (ps := []) (t := e2408452097442) (by decide)) (by decide)
def e2408452097550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408452097550 : Closed e2408452097550 ∧ code e2408452097550 = 11204545119758 := by decide
theorem cert_e2408452097550 : check e2408452097550 [[]] .width = true := by decide
def e2408452097562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408452097562 : Closed e2408452097562 ∧ code e2408452097562 = 11204545119770 := by decide
private def t_e2408452097562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408452097562 : ¬ IsSelfInterpreter e2408452097562 :=
  wSource (t := t_e2408452097562) (replay_sound (ps := []) (t := e2408452097562) (by decide)) (by decide)
def e2408452097634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408452097634 : Closed e2408452097634 ∧ code e2408452097634 = 11204545119842 := by decide
theorem cert_e2408452097634 : check e2408452097634 [[]] .width = true := by decide
def e2408452305094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408452305094 : Closed e2408452305094 ∧ code e2408452305094 = 11204545327302 := by decide
theorem cert_e2408452305094 : check e2408452305094 [[]] .width = true := by decide
def e2408452313286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408452313286 : Closed e2408452313286 ∧ code e2408452313286 = 11204545335494 := by decide
theorem cert_e2408452313286 : check e2408452313286 [[]] .width = true := by decide
def e2408452413466 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408452413466 : Closed e2408452413466 ∧ code e2408452413466 = 11204545435674 := by decide
theorem cert_e2408452413466 : check e2408452413466 [[]] .width = true := by decide
def e2408452417562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408452417562 : Closed e2408452417562 ∧ code e2408452417562 = 11204545439770 := by decide
theorem cert_e2408452417562 : check e2408452417562 [[]] .width = true := by decide
def e2408452419098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452419098 : Closed e2408452419098 ∧ code e2408452419098 = 11204545441306 := by decide
private def t_e2408452419098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452419098 : ¬ IsSelfInterpreter e2408452419098 :=
  wSource (t := t_e2408452419098) (replay_sound (ps := []) (t := e2408452419098) (by decide)) (by decide)
def e2408452421146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452421146 : Closed e2408452421146 ∧ code e2408452421146 = 11204545443354 := by decide
private def t_e2408452421146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452421146 : ¬ IsSelfInterpreter e2408452421146 :=
  wSource (t := t_e2408452421146) (replay_sound (ps := []) (t := e2408452421146) (by decide)) (by decide)
def e2408452433946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408452433946 : Closed e2408452433946 ∧ code e2408452433946 = 11204545456154 := by decide
theorem cert_e2408452433946 : check e2408452433946 [[]] .width = true := by decide
def e2408452435482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452435482 : Closed e2408452435482 ∧ code e2408452435482 = 11204545457690 := by decide
private def t_e2408452435482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452435482 : ¬ IsSelfInterpreter e2408452435482 :=
  wSource (t := t_e2408452435482) (replay_sound (ps := []) (t := e2408452435482) (by decide)) (by decide)
def e2408452438554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452438554 : Closed e2408452438554 ∧ code e2408452438554 = 11204545460762 := by decide
private def t_e2408452438554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452438554 : ¬ IsSelfInterpreter e2408452438554 :=
  wSource (t := t_e2408452438554) (replay_sound (ps := []) (t := e2408452438554) (by decide)) (by decide)
def e2408452445722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452445722 : Closed e2408452445722 ∧ code e2408452445722 = 11204545467930 := by decide
private def t_e2408452445722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452445722 : ¬ IsSelfInterpreter e2408452445722 :=
  wSource (t := t_e2408452445722) (replay_sound (ps := []) (t := e2408452445722) (by decide)) (by decide)
def e2408452446746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452446746 : Closed e2408452446746 ∧ code e2408452446746 = 11204545468954 := by decide
private def t_e2408452446746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452446746 : ¬ IsSelfInterpreter e2408452446746 :=
  wSource (t := t_e2408452446746) (replay_sound (ps := []) (t := e2408452446746) (by decide)) (by decide)
def e2408452485318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408452485318 : Closed e2408452485318 ∧ code e2408452485318 = 11204545507526 := by decide
theorem cert_e2408452485318 : check e2408452485318 [[]] .width = true := by decide
def e2408452511770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408452511770 : Closed e2408452511770 ∧ code e2408452511770 = 11204545533978 := by decide
theorem cert_e2408452511770 : check e2408452511770 [[]] .width = true := by decide
def e2408452515866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408452515866 : Closed e2408452515866 ∧ code e2408452515866 = 11204545538074 := by decide
theorem cert_e2408452515866 : check e2408452515866 [[]] .width = true := by decide
def e2408452517402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452517402 : Closed e2408452517402 ∧ code e2408452517402 = 11204545539610 := by decide
private def t_e2408452517402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452517402 : ¬ IsSelfInterpreter e2408452517402 :=
  wSource (t := t_e2408452517402) (replay_sound (ps := []) (t := e2408452517402) (by decide)) (by decide)
def e2408452519450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452519450 : Closed e2408452519450 ∧ code e2408452519450 = 11204545541658 := by decide
private def t_e2408452519450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452519450 : ¬ IsSelfInterpreter e2408452519450 :=
  wSource (t := t_e2408452519450) (replay_sound (ps := []) (t := e2408452519450) (by decide)) (by decide)
def e2408452554778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408452554778 : Closed e2408452554778 ∧ code e2408452554778 = 11204545576986 := by decide
theorem cert_e2408452554778 : check e2408452554778 [[]] .width = true := by decide
def e2408452554870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408452554870 : Closed e2408452554870 ∧ code e2408452554870 = 11204545577078 := by decide
theorem cert_e2408452554870 : check e2408452554870 [[]] .width = true := by decide
def e2408452555114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408452555114 : Closed e2408452555114 ∧ code e2408452555114 = 11204545577322 := by decide
theorem cert_e2408452555114 : check e2408452555114 [[]] .width = true := by decide
def e2408452555162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408452555162 : Closed e2408452555162 ∧ code e2408452555162 = 11204545577370 := by decide
theorem cert_e2408452555162 : check e2408452555162 [[]] .width = true := by decide
def e2408452556170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408452556170 : Closed e2408452556170 ∧ code e2408452556170 = 11204545578378 := by decide
theorem cert_e2408452556170 : check e2408452556170 [[]] .width = true := by decide
def e2408452556194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408452556194 : Closed e2408452556194 ∧ code e2408452556194 = 11204545578402 := by decide
private def t_e2408452556194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408452556194 : ¬ IsSelfInterpreter e2408452556194 :=
  wSource (t := t_e2408452556194) (replay_sound (ps := []) (t := e2408452556194) (by decide)) (by decide)
def e2408452556302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408452556302 : Closed e2408452556302 ∧ code e2408452556302 = 11204545578510 := by decide
theorem cert_e2408452556302 : check e2408452556302 [[]] .width = true := by decide
def e2408452556314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408452556314 : Closed e2408452556314 ∧ code e2408452556314 = 11204545578522 := by decide
private def t_e2408452556314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408452556314 : ¬ IsSelfInterpreter e2408452556314 :=
  wSource (t := t_e2408452556314) (replay_sound (ps := []) (t := e2408452556314) (by decide)) (by decide)
def e2408452556386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408452556386 : Closed e2408452556386 ∧ code e2408452556386 = 11204545578594 := by decide
theorem cert_e2408452556386 : check e2408452556386 [[]] .width = true := by decide
def e2408452600006 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408452600006 : Closed e2408452600006 ∧ code e2408452600006 = 11204545622214 := by decide
theorem cert_e2408452600006 : check e2408452600006 [[]] .width = true := by decide
def e2408452614170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408452614170 : Closed e2408452614170 ∧ code e2408452614170 = 11204545636378 := by decide
theorem cert_e2408452614170 : check e2408452614170 [[]] .width = true := by decide
def e2408452615706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452615706 : Closed e2408452615706 ∧ code e2408452615706 = 11204545637914 := by decide
private def t_e2408452615706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452615706 : ¬ IsSelfInterpreter e2408452615706 :=
  wSource (t := t_e2408452615706) (replay_sound (ps := []) (t := e2408452615706) (by decide)) (by decide)
def e2408452618778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452618778 : Closed e2408452618778 ∧ code e2408452618778 = 11204545640986 := by decide
private def t_e2408452618778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452618778 : ¬ IsSelfInterpreter e2408452618778 :=
  wSource (t := t_e2408452618778) (replay_sound (ps := []) (t := e2408452618778) (by decide)) (by decide)
def e2408452620314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408452620314 : Closed e2408452620314 ∧ code e2408452620314 = 11204545642522 := by decide
theorem cert_e2408452620314 : check e2408452620314 [[]] .width = true := by decide
def e2408452620406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408452620406 : Closed e2408452620406 ∧ code e2408452620406 = 11204545642614 := by decide
theorem cert_e2408452620406 : check e2408452620406 [[]] .width = true := by decide
def e2408452620650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408452620650 : Closed e2408452620650 ∧ code e2408452620650 = 11204545642858 := by decide
theorem cert_e2408452620650 : check e2408452620650 [[]] .width = true := by decide
def e2408452620698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408452620698 : Closed e2408452620698 ∧ code e2408452620698 = 11204545642906 := by decide
theorem cert_e2408452620698 : check e2408452620698 [[]] .width = true := by decide
def e2408452621706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408452621706 : Closed e2408452621706 ∧ code e2408452621706 = 11204545643914 := by decide
theorem cert_e2408452621706 : check e2408452621706 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2408276260378
#print axioms Blc.Floor43.cert_e2408276284954
#print axioms Blc.Floor43.cert_e2408276669978
#print axioms Blc.Floor43.cert_e2408276678170
#print axioms Blc.Floor43.cert_e2408319774234
#print axioms Blc.Floor43.cert_e2408319776282
#print axioms Blc.Floor43.cert_e2408319790618
#print axioms Blc.Floor43.cert_e2408319793690
#print axioms Blc.Floor43.cert_e2408319800858
#print axioms Blc.Floor43.cert_e2408319801882
#print axioms Blc.Floor43.cert_e2408319872538
#print axioms Blc.Floor43.cert_e2408319874586
#print axioms Blc.Floor43.cert_e2408319970842
#print axioms Blc.Floor43.cert_e2408319973914
#print axioms Blc.Floor43.cert_e2408320022042
#print axioms Blc.Floor43.cert_e2408320023066
#print axioms Blc.Floor43.cert_e2408448454170
#print axioms Blc.Floor43.cert_e2408448486938
#print axioms Blc.Floor43.cert_e2408448488986
#print axioms Blc.Floor43.cert_e2408448716314
#print axioms Blc.Floor43.cert_e2408448765466
#print axioms Blc.Floor43.cert_e2408448768538
#print axioms Blc.Floor43.cert_e2408448880154
#print axioms Blc.Floor43.cert_e2408448882202
#print axioms Blc.Floor43.cert_e2408448896538
#print axioms Blc.Floor43.cert_e2408448899610
#print axioms Blc.Floor43.cert_e2408448906778
#print axioms Blc.Floor43.cert_e2408448907802
#print axioms Blc.Floor43.cert_e2408450027034
#print axioms Blc.Floor43.cert_e2408450059802
#print axioms Blc.Floor43.cert_e2408450061850
#print axioms Blc.Floor43.cert_e2408450747930
#print axioms Blc.Floor43.cert_e2408450852258
#print axioms Blc.Floor43.cert_e2408450852378
#print axioms Blc.Floor43.cert_e2408450944538
#print axioms Blc.Floor43.cert_e2408450946586
#print axioms Blc.Floor43.cert_e2408450983330
#print axioms Blc.Floor43.cert_e2408450983450
#print axioms Blc.Floor43.cert_e2408451599898
#print axioms Blc.Floor43.cert_e2408451649050
#print axioms Blc.Floor43.cert_e2408451652122
#print axioms Blc.Floor43.cert_e2408451796506
#print axioms Blc.Floor43.cert_e2408451900834
#print axioms Blc.Floor43.cert_e2408451900954
#print axioms Blc.Floor43.cert_e2408452091418
#print axioms Blc.Floor43.cert_e2408452094490
#print axioms Blc.Floor43.cert_e2408452097442
#print axioms Blc.Floor43.cert_e2408452097562
#print axioms Blc.Floor43.cert_e2408452419098
#print axioms Blc.Floor43.cert_e2408452421146
#print axioms Blc.Floor43.cert_e2408452435482
#print axioms Blc.Floor43.cert_e2408452438554
#print axioms Blc.Floor43.cert_e2408452445722
#print axioms Blc.Floor43.cert_e2408452446746
#print axioms Blc.Floor43.cert_e2408452517402
#print axioms Blc.Floor43.cert_e2408452519450
#print axioms Blc.Floor43.cert_e2408452556194
#print axioms Blc.Floor43.cert_e2408452556314
#print axioms Blc.Floor43.cert_e2408452615706
#print axioms Blc.Floor43.cert_e2408452618778
