import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364646794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364646794 : Closed e2422364646794 ∧ code e2422364646794 = 11218457669002 := by decide
theorem cert_e2422364646794 : check e2422364646794 [[],[]] .smaller = true := by decide
def e2422364646818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364646818 : Closed e2422364646818 ∧ code e2422364646818 = 11218457669026 := by decide
theorem cert_e2422364646818 : check e2422364646818 [[],[]] .smaller = true := by decide
def e2422364646830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e2422364646830 : Closed e2422364646830 ∧ code e2422364646830 = 11218457669038 := by decide
theorem cert_e2422364646830 : check e2422364646830 [[],[]] .smaller = true := by decide
def e2422364646838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1))))))))
theorem wire_e2422364646838 : Closed e2422364646838 ∧ code e2422364646838 = 11218457669046 := by decide
theorem cert_e2422364646838 : check e2422364646838 [[],[]] .smaller = true := by decide
def e2422364646842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e2422364646842 : Closed e2422364646842 ∧ code e2422364646842 = 11218457669050 := by decide
theorem cert_e2422364646842 : check e2422364646842 [[],[]] .smaller = true := by decide
def e2422364646870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e2422364646870 : Closed e2422364646870 ∧ code e2422364646870 = 11218457669078 := by decide
theorem cert_e2422364646870 : check e2422364646870 [[],[]] .smaller = true := by decide
def e2422364646874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e2422364646874 : Closed e2422364646874 ∧ code e2422364646874 = 11218457669082 := by decide
theorem cert_e2422364646874 : check e2422364646874 [[],[]] .smaller = true := by decide
def e2422364646890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 0))))))))
theorem wire_e2422364646890 : Closed e2422364646890 ∧ code e2422364646890 = 11218457669098 := by decide
theorem cert_e2422364646890 : check e2422364646890 [[],[]] .smaller = true := by decide
def e2422364646954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0))))))))
theorem wire_e2422364646954 : Closed e2422364646954 ∧ code e2422364646954 = 11218457669162 := by decide
theorem cert_e2422364646954 : check e2422364646954 [[],[]] .smaller = true := by decide
def e2422364647050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364647050 : Closed e2422364647050 ∧ code e2422364647050 = 11218457669258 := by decide
theorem cert_e2422364647050 : check e2422364647050 [[],[]] .smaller = true := by decide
def e2422364647074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364647074 : Closed e2422364647074 ∧ code e2422364647074 = 11218457669282 := by decide
theorem cert_e2422364647074 : check e2422364647074 [[],[]] .smaller = true := by decide
def e2422364647086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e2422364647086 : Closed e2422364647086 ∧ code e2422364647086 = 11218457669294 := by decide
theorem cert_e2422364647086 : check e2422364647086 [[],[]] .smaller = true := by decide
def e2422364647094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1))))))))
theorem wire_e2422364647094 : Closed e2422364647094 ∧ code e2422364647094 = 11218457669302 := by decide
theorem cert_e2422364647094 : check e2422364647094 [[],[]] .smaller = true := by decide
def e2422364647098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e2422364647098 : Closed e2422364647098 ∧ code e2422364647098 = 11218457669306 := by decide
theorem cert_e2422364647098 : check e2422364647098 [[],[]] .smaller = true := by decide
def e2422364647126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1))))))))
theorem wire_e2422364647126 : Closed e2422364647126 ∧ code e2422364647126 = 11218457669334 := by decide
theorem cert_e2422364647126 : check e2422364647126 [[],[]] .smaller = true := by decide
def e2422364647130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))))))))
theorem wire_e2422364647130 : Closed e2422364647130 ∧ code e2422364647130 = 11218457669338 := by decide
theorem cert_e2422364647130 : check e2422364647130 [[],[]] .smaller = true := by decide
def e2422364647146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e2422364647146 : Closed e2422364647146 ∧ code e2422364647146 = 11218457669354 := by decide
theorem cert_e2422364647146 : check e2422364647146 [[],[]] .smaller = true := by decide
def e2422364647254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422364647254 : Closed e2422364647254 ∧ code e2422364647254 = 11218457669462 := by decide
theorem cert_e2422364647254 : check e2422364647254 [[],[]] .smaller = true := by decide
def e2422364647258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422364647258 : Closed e2422364647258 ∧ code e2422364647258 = 11218457669466 := by decide
theorem cert_e2422364647258 : check e2422364647258 [[],[]] .smaller = true := by decide
def e2422364647274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422364647274 : Closed e2422364647274 ∧ code e2422364647274 = 11218457669482 := by decide
theorem cert_e2422364647274 : check e2422364647274 [[],[]] .smaller = true := by decide
def e2422364647338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422364647338 : Closed e2422364647338 ∧ code e2422364647338 = 11218457669546 := by decide
theorem cert_e2422364647338 : check e2422364647338 [[],[]] .smaller = true := by decide
def e2422364647542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1))))))))
theorem wire_e2422364647542 : Closed e2422364647542 ∧ code e2422364647542 = 11218457669750 := by decide
theorem cert_e2422364647542 : check e2422364647542 [[],[]] .smaller = true := by decide
def e2422364647546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0))))))))
theorem wire_e2422364647546 : Closed e2422364647546 ∧ code e2422364647546 = 11218457669754 := by decide
theorem cert_e2422364647546 : check e2422364647546 [[],[]] .smaller = true := by decide
def e2422364647638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))))
theorem wire_e2422364647638 : Closed e2422364647638 ∧ code e2422364647638 = 11218457669846 := by decide
theorem cert_e2422364647638 : check e2422364647638 [[],[]] .smaller = true := by decide
def e2422364647734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364647734 : Closed e2422364647734 ∧ code e2422364647734 = 11218457669942 := by decide
theorem cert_e2422364647734 : check e2422364647734 [[],[]] .smaller = true := by decide
def e2422364647738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364647738 : Closed e2422364647738 ∧ code e2422364647738 = 11218457669946 := by decide
theorem cert_e2422364647738 : check e2422364647738 [[],[]] .smaller = true := by decide
def e2422364647822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2)))))))))
theorem wire_e2422364647822 : Closed e2422364647822 ∧ code e2422364647822 = 11218457670030 := by decide
theorem cert_e2422364647822 : check e2422364647822 [[],[]] .smaller = true := by decide
def e2422364647870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 4))))))))
theorem wire_e2422364647870 : Closed e2422364647870 ∧ code e2422364647870 = 11218457670078 := by decide
theorem cert_e2422364647870 : check e2422364647870 [[],[]] .three = true := by decide
def e2422364647878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1)))))))))
theorem wire_e2422364647878 : Closed e2422364647878 ∧ code e2422364647878 = 11218457670086 := by decide
theorem cert_e2422364647878 : check e2422364647878 [[],[]] .smaller = true := by decide
def e2422364647930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 5)))) (.var 0))))))))
theorem wire_e2422364647930 : Closed e2422364647930 ∧ code e2422364647930 = 11218457670138 := by decide
theorem cert_e2422364647930 : check e2422364647930 [[],[]] .three = true := by decide
def e2422364648214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))))
theorem wire_e2422364648214 : Closed e2422364648214 ∧ code e2422364648214 = 11218457670422 := by decide
theorem cert_e2422364648214 : check e2422364648214 [[],[]] .smaller = true := by decide
def e2422364648286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e2422364648286 : Closed e2422364648286 ∧ code e2422364648286 = 11218457670494 := by decide
theorem cert_e2422364648286 : check e2422364648286 [[],[]] .smaller = true := by decide
def e2422364648290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))))
theorem wire_e2422364648290 : Closed e2422364648290 ∧ code e2422364648290 = 11218457670498 := by decide
theorem cert_e2422364648290 : check e2422364648290 [[],[]] .smaller = true := by decide
def e2422364648302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e2422364648302 : Closed e2422364648302 ∧ code e2422364648302 = 11218457670510 := by decide
theorem cert_e2422364648302 : check e2422364648302 [[],[]] .smaller = true := by decide
def e2422364648310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e2422364648310 : Closed e2422364648310 ∧ code e2422364648310 = 11218457670518 := by decide
theorem cert_e2422364648310 : check e2422364648310 [[],[]] .smaller = true := by decide
def e2422364648314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e2422364648314 : Closed e2422364648314 ∧ code e2422364648314 = 11218457670522 := by decide
theorem cert_e2422364648314 : check e2422364648314 [[],[]] .smaller = true := by decide
def e2422364648330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422364648330 : Closed e2422364648330 ∧ code e2422364648330 = 11218457670538 := by decide
theorem cert_e2422364648330 : check e2422364648330 [[],[]] .smaller = true := by decide
def e2422364648354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))))
theorem wire_e2422364648354 : Closed e2422364648354 ∧ code e2422364648354 = 11218457670562 := by decide
theorem cert_e2422364648354 : check e2422364648354 [[],[]] .smaller = true := by decide
def e2422364648366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e2422364648366 : Closed e2422364648366 ∧ code e2422364648366 = 11218457670574 := by decide
theorem cert_e2422364648366 : check e2422364648366 [[],[]] .smaller = true := by decide
def e2422364648374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e2422364648374 : Closed e2422364648374 ∧ code e2422364648374 = 11218457670582 := by decide
theorem cert_e2422364648374 : check e2422364648374 [[],[]] .smaller = true := by decide
def e2422364648378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e2422364648378 : Closed e2422364648378 ∧ code e2422364648378 = 11218457670586 := by decide
theorem cert_e2422364648378 : check e2422364648378 [[],[]] .smaller = true := by decide
def e2422364648406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e2422364648406 : Closed e2422364648406 ∧ code e2422364648406 = 11218457670614 := by decide
theorem cert_e2422364648406 : check e2422364648406 [[],[]] .smaller = true := by decide
def e2422364648410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e2422364648410 : Closed e2422364648410 ∧ code e2422364648410 = 11218457670618 := by decide
theorem cert_e2422364648410 : check e2422364648410 [[],[]] .smaller = true := by decide
def e2422364648426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e2422364648426 : Closed e2422364648426 ∧ code e2422364648426 = 11218457670634 := by decide
theorem cert_e2422364648426 : check e2422364648426 [[],[]] .smaller = true := by decide
def e2422364648478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))))))))
theorem wire_e2422364648478 : Closed e2422364648478 ∧ code e2422364648478 = 11218457670686 := by decide
theorem cert_e2422364648478 : check e2422364648478 [[],[]] .smaller = true := by decide
def e2422364648574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 5)))))))))
theorem wire_e2422364648574 : Closed e2422364648574 ∧ code e2422364648574 = 11218457670782 := by decide
theorem cert_e2422364648574 : check e2422364648574 [[],[]] .three = true := by decide
def e2422364648670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364648670 : Closed e2422364648670 ∧ code e2422364648670 = 11218457670878 := by decide
theorem cert_e2422364648670 : check e2422364648670 [[],[]] .smaller = true := by decide
def e2422364648674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422364648674 : Closed e2422364648674 ∧ code e2422364648674 = 11218457670882 := by decide
theorem cert_e2422364648674 : check e2422364648674 [[],[]] .smaller = true := by decide
def e2422364648686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364648686 : Closed e2422364648686 ∧ code e2422364648686 = 11218457670894 := by decide
theorem cert_e2422364648686 : check e2422364648686 [[],[]] .smaller = true := by decide
def e2422364648694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364648694 : Closed e2422364648694 ∧ code e2422364648694 = 11218457670902 := by decide
theorem cert_e2422364648694 : check e2422364648694 [[],[]] .smaller = true := by decide
def e2422364648698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364648698 : Closed e2422364648698 ∧ code e2422364648698 = 11218457670906 := by decide
theorem cert_e2422364648698 : check e2422364648698 [[],[]] .smaller = true := by decide
def e2422364648974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364648974 : Closed e2422364648974 ∧ code e2422364648974 = 11218457671182 := by decide
theorem cert_e2422364648974 : check e2422364648974 [[],[]] .smaller = true := by decide
def e2422364648986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364648986 : Closed e2422364648986 ∧ code e2422364648986 = 11218457671194 := by decide
theorem cert_e2422364648986 : check e2422364648986 [[],[]] .smaller = true := by decide
def e2422364649058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364649058 : Closed e2422364649058 ∧ code e2422364649058 = 11218457671266 := by decide
theorem cert_e2422364649058 : check e2422364649058 [[],[]] .smaller = true := by decide
def e2422364649070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364649070 : Closed e2422364649070 ∧ code e2422364649070 = 11218457671278 := by decide
theorem cert_e2422364649070 : check e2422364649070 [[],[]] .smaller = true := by decide
def e2422364649078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364649078 : Closed e2422364649078 ∧ code e2422364649078 = 11218457671286 := by decide
theorem cert_e2422364649078 : check e2422364649078 [[],[]] .smaller = true := by decide
def e2422364649082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364649082 : Closed e2422364649082 ∧ code e2422364649082 = 11218457671290 := by decide
theorem cert_e2422364649082 : check e2422364649082 [[],[]] .smaller = true := by decide
def e2422364649270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364649270 : Closed e2422364649270 ∧ code e2422364649270 = 11218457671478 := by decide
theorem cert_e2422364649270 : check e2422364649270 [[],[]] .smaller = true := by decide
def e2422364649274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364649274 : Closed e2422364649274 ∧ code e2422364649274 = 11218457671482 := by decide
theorem cert_e2422364649274 : check e2422364649274 [[],[]] .smaller = true := by decide
def e2422364649370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364649370 : Closed e2422364649370 ∧ code e2422364649370 = 11218457671578 := by decide
theorem cert_e2422364649370 : check e2422364649370 [[],[]] .smaller = true := by decide
def e2422364649414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 4))) (.lam (.var 1)))))))))
theorem wire_e2422364649414 : Closed e2422364649414 ∧ code e2422364649414 = 11218457671622 := by decide
theorem cert_e2422364649414 : check e2422364649414 [[],[]] .three = true := by decide
def e2422364649530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0))))))))
theorem wire_e2422364649530 : Closed e2422364649530 ∧ code e2422364649530 = 11218457671738 := by decide
theorem cert_e2422364649530 : check e2422364649530 [[],[]] .smaller = true := by decide
def e2422364649578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))))
theorem wire_e2422364649578 : Closed e2422364649578 ∧ code e2422364649578 = 11218457671786 := by decide
theorem cert_e2422364649578 : check e2422364649578 [[],[]] .smaller = true := by decide
def e2422364649626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364649626 : Closed e2422364649626 ∧ code e2422364649626 = 11218457671834 := by decide
theorem cert_e2422364649626 : check e2422364649626 [[],[]] .smaller = true := by decide
def e2422364649670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1)))))))))
theorem wire_e2422364649670 : Closed e2422364649670 ∧ code e2422364649670 = 11218457671878 := by decide
theorem cert_e2422364649670 : check e2422364649670 [[],[]] .smaller = true := by decide
def e2422364649866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422364649866 : Closed e2422364649866 ∧ code e2422364649866 = 11218457672074 := by decide
theorem cert_e2422364649866 : check e2422364649866 [[],[]] .smaller = true := by decide
def e2422364649890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))))
theorem wire_e2422364649890 : Closed e2422364649890 ∧ code e2422364649890 = 11218457672098 := by decide
theorem cert_e2422364649890 : check e2422364649890 [[],[]] .smaller = true := by decide
def e2422364649902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422364649902 : Closed e2422364649902 ∧ code e2422364649902 = 11218457672110 := by decide
theorem cert_e2422364649902 : check e2422364649902 [[],[]] .smaller = true := by decide
def e2422364649910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422364649910 : Closed e2422364649910 ∧ code e2422364649910 = 11218457672118 := by decide
theorem cert_e2422364649910 : check e2422364649910 [[],[]] .smaller = true := by decide
def e2422364649914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422364649914 : Closed e2422364649914 ∧ code e2422364649914 = 11218457672122 := by decide
theorem cert_e2422364649914 : check e2422364649914 [[],[]] .smaller = true := by decide
def e2422364649942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422364649942 : Closed e2422364649942 ∧ code e2422364649942 = 11218457672150 := by decide
theorem cert_e2422364649942 : check e2422364649942 [[],[]] .smaller = true := by decide
def e2422364649946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e2422364649946 : Closed e2422364649946 ∧ code e2422364649946 = 11218457672154 := by decide
theorem cert_e2422364649946 : check e2422364649946 [[],[]] .smaller = true := by decide
def e2422364649962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422364649962 : Closed e2422364649962 ∧ code e2422364649962 = 11218457672170 := by decide
theorem cert_e2422364649962 : check e2422364649962 [[],[]] .smaller = true := by decide
def e2422364649998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364649998 : Closed e2422364649998 ∧ code e2422364649998 = 11218457672206 := by decide
theorem cert_e2422364649998 : check e2422364649998 [[],[]] .smaller = true := by decide
def e2422364650010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364650010 : Closed e2422364650010 ∧ code e2422364650010 = 11218457672218 := by decide
theorem cert_e2422364650010 : check e2422364650010 [[],[]] .smaller = true := by decide
def e2422364650082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364650082 : Closed e2422364650082 ∧ code e2422364650082 = 11218457672290 := by decide
theorem cert_e2422364650082 : check e2422364650082 [[],[]] .smaller = true := by decide
def e2422364650094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364650094 : Closed e2422364650094 ∧ code e2422364650094 = 11218457672302 := by decide
theorem cert_e2422364650094 : check e2422364650094 [[],[]] .smaller = true := by decide
def e2422364650102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364650102 : Closed e2422364650102 ∧ code e2422364650102 = 11218457672310 := by decide
theorem cert_e2422364650102 : check e2422364650102 [[],[]] .smaller = true := by decide
def e2422364650106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364650106 : Closed e2422364650106 ∧ code e2422364650106 = 11218457672314 := by decide
theorem cert_e2422364650106 : check e2422364650106 [[],[]] .smaller = true := by decide
def e2422364650294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364650294 : Closed e2422364650294 ∧ code e2422364650294 = 11218457672502 := by decide
theorem cert_e2422364650294 : check e2422364650294 [[],[]] .smaller = true := by decide
def e2422364650298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364650298 : Closed e2422364650298 ∧ code e2422364650298 = 11218457672506 := by decide
theorem cert_e2422364650298 : check e2422364650298 [[],[]] .smaller = true := by decide
def e2422364650394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364650394 : Closed e2422364650394 ∧ code e2422364650394 = 11218457672602 := by decide
theorem cert_e2422364650394 : check e2422364650394 [[],[]] .smaller = true := by decide
def e2422364650430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 4))))))))
theorem wire_e2422364650430 : Closed e2422364650430 ∧ code e2422364650430 = 11218457672638 := by decide
theorem cert_e2422364650430 : check e2422364650430 [[],[]] .three = true := by decide
def e2422364650462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 3))))))))
theorem wire_e2422364650462 : Closed e2422364650462 ∧ code e2422364650462 = 11218457672670 := by decide
theorem cert_e2422364650462 : check e2422364650462 [[],[]] .smaller = true := by decide
def e2422364650478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 4))) (.var 2))))))))
theorem wire_e2422364650478 : Closed e2422364650478 ∧ code e2422364650478 = 11218457672686 := by decide
theorem cert_e2422364650478 : check e2422364650478 [[],[]] .three = true := by decide
def e2422364650710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422364650710 : Closed e2422364650710 ∧ code e2422364650710 = 11218457672918 := by decide
theorem cert_e2422364650710 : check e2422364650710 [[],[]] .smaller = true := by decide
def e2422364650714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422364650714 : Closed e2422364650714 ∧ code e2422364650714 = 11218457672922 := by decide
theorem cert_e2422364650714 : check e2422364650714 [[],[]] .smaller = true := by decide
def e2422364650730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422364650730 : Closed e2422364650730 ∧ code e2422364650730 = 11218457672938 := by decide
theorem cert_e2422364650730 : check e2422364650730 [[],[]] .smaller = true := by decide
def e2422364650806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364650806 : Closed e2422364650806 ∧ code e2422364650806 = 11218457673014 := by decide
theorem cert_e2422364650806 : check e2422364650806 [[],[]] .smaller = true := by decide
def e2422364650810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364650810 : Closed e2422364650810 ∧ code e2422364650810 = 11218457673018 := by decide
theorem cert_e2422364650810 : check e2422364650810 [[],[]] .smaller = true := by decide
def e2422364650906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364650906 : Closed e2422364650906 ∧ code e2422364650906 = 11218457673114 := by decide
theorem cert_e2422364650906 : check e2422364650906 [[],[]] .smaller = true := by decide
def e2422364650942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 4))))))))
theorem wire_e2422364650942 : Closed e2422364650942 ∧ code e2422364650942 = 11218457673150 := by decide
theorem cert_e2422364650942 : check e2422364650942 [[],[]] .three = true := by decide
def e2422364650998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 4))) (.var 1))))))))
theorem wire_e2422364650998 : Closed e2422364650998 ∧ code e2422364650998 = 11218457673206 := by decide
theorem cert_e2422364650998 : check e2422364650998 [[],[]] .three = true := by decide
def e2422364651114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422364651114 : Closed e2422364651114 ∧ code e2422364651114 = 11218457673322 := by decide
theorem cert_e2422364651114 : check e2422364651114 [[],[]] .smaller = true := by decide
def e2422364651162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364651162 : Closed e2422364651162 ∧ code e2422364651162 = 11218457673370 := by decide
theorem cert_e2422364651162 : check e2422364651162 [[],[]] .smaller = true := by decide
def e2422364651230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 3))))))))
theorem wire_e2422364651230 : Closed e2422364651230 ∧ code e2422364651230 = 11218457673438 := by decide
theorem cert_e2422364651230 : check e2422364651230 [[],[]] .smaller = true := by decide
def e2422364651254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 3))) (.var 1))))))))
theorem wire_e2422364651254 : Closed e2422364651254 ∧ code e2422364651254 = 11218457673462 := by decide
theorem cert_e2422364651254 : check e2422364651254 [[],[]] .smaller = true := by decide
def e2422364651290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422364651290 : Closed e2422364651290 ∧ code e2422364651290 = 11218457673498 := by decide
theorem cert_e2422364651290 : check e2422364651290 [[],[]] .three = true := by decide
def e2422364651334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422364651334 : Closed e2422364651334 ∧ code e2422364651334 = 11218457673542 := by decide
theorem cert_e2422364651334 : check e2422364651334 [[],[]] .three = true := by decide
def e2422364651374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 1))) (.var 2))))))))
theorem wire_e2422364651374 : Closed e2422364651374 ∧ code e2422364651374 = 11218457673582 := by decide
theorem cert_e2422364651374 : check e2422364651374 [[],[]] .three = true := by decide
def e2422364651382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 2))) (.var 1))))))))
theorem wire_e2422364651382 : Closed e2422364651382 ∧ code e2422364651382 = 11218457673590 := by decide
theorem cert_e2422364651382 : check e2422364651382 [[],[]] .three = true := by decide
def e2422364652478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2422364652478 : Closed e2422364652478 ∧ code e2422364652478 = 11218457674686 := by decide
theorem cert_e2422364652478 : check e2422364652478 [[],[]] .smaller = true := by decide
def e2422364652510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422364652510 : Closed e2422364652510 ∧ code e2422364652510 = 11218457674718 := by decide
theorem cert_e2422364652510 : check e2422364652510 [[],[]] .smaller = true := by decide
def e2422364652526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422364652526 : Closed e2422364652526 ∧ code e2422364652526 = 11218457674734 := by decide
theorem cert_e2422364652526 : check e2422364652526 [[],[]] .smaller = true := by decide
def e2422364652534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2422364652534 : Closed e2422364652534 ∧ code e2422364652534 = 11218457674742 := by decide
theorem cert_e2422364652534 : check e2422364652534 [[],[]] .smaller = true := by decide
def e2422364654358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422364654358 : Closed e2422364654358 ∧ code e2422364654358 = 11218457676566 := by decide
theorem cert_e2422364654358 : check e2422364654358 [[],[]] .smaller = true := by decide
def e2422364654430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2422364654430 : Closed e2422364654430 ∧ code e2422364654430 = 11218457676638 := by decide
theorem cert_e2422364654430 : check e2422364654430 [[],[]] .smaller = true := by decide
def e2422364654434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422364654434 : Closed e2422364654434 ∧ code e2422364654434 = 11218457676642 := by decide
theorem cert_e2422364654434 : check e2422364654434 [[],[]] .smaller = true := by decide
def e2422364654446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422364654446 : Closed e2422364654446 ∧ code e2422364654446 = 11218457676654 := by decide
theorem cert_e2422364654446 : check e2422364654446 [[],[]] .smaller = true := by decide
def e2422364654454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422364654454 : Closed e2422364654454 ∧ code e2422364654454 = 11218457676662 := by decide
theorem cert_e2422364654454 : check e2422364654454 [[],[]] .smaller = true := by decide
def e2422364654458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2422364654458 : Closed e2422364654458 ∧ code e2422364654458 = 11218457676666 := by decide
theorem cert_e2422364654458 : check e2422364654458 [[],[]] .smaller = true := by decide
def e2422364654474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364654474 : Closed e2422364654474 ∧ code e2422364654474 = 11218457676682 := by decide
theorem cert_e2422364654474 : check e2422364654474 [[],[]] .smaller = true := by decide
def e2422364654498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364654498 : Closed e2422364654498 ∧ code e2422364654498 = 11218457676706 := by decide
theorem cert_e2422364654498 : check e2422364654498 [[],[]] .smaller = true := by decide
def e2422364654510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422364654510 : Closed e2422364654510 ∧ code e2422364654510 = 11218457676718 := by decide
theorem cert_e2422364654510 : check e2422364654510 [[],[]] .smaller = true := by decide
def e2422364654518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e2422364654518 : Closed e2422364654518 ∧ code e2422364654518 = 11218457676726 := by decide
theorem cert_e2422364654518 : check e2422364654518 [[],[]] .smaller = true := by decide
def e2422364654522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422364654522 : Closed e2422364654522 ∧ code e2422364654522 = 11218457676730 := by decide
theorem cert_e2422364654522 : check e2422364654522 [[],[]] .smaller = true := by decide
def e2422364654550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422364654550 : Closed e2422364654550 ∧ code e2422364654550 = 11218457676758 := by decide
theorem cert_e2422364654550 : check e2422364654550 [[],[]] .smaller = true := by decide
def e2422364654554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422364654554 : Closed e2422364654554 ∧ code e2422364654554 = 11218457676762 := by decide
theorem cert_e2422364654554 : check e2422364654554 [[],[]] .smaller = true := by decide
def e2422364654570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2422364654570 : Closed e2422364654570 ∧ code e2422364654570 = 11218457676778 := by decide
theorem cert_e2422364654570 : check e2422364654570 [[],[]] .smaller = true := by decide
def e2422364654622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422364654622 : Closed e2422364654622 ∧ code e2422364654622 = 11218457676830 := by decide
theorem cert_e2422364654622 : check e2422364654622 [[],[]] .smaller = true := by decide
def e2422364654718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 5))))))))))
theorem wire_e2422364654718 : Closed e2422364654718 ∧ code e2422364654718 = 11218457676926 := by decide
theorem cert_e2422364654718 : check e2422364654718 [[],[]] .three = true := by decide
def e2422364654814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364654814 : Closed e2422364654814 ∧ code e2422364654814 = 11218457677022 := by decide
theorem cert_e2422364654814 : check e2422364654814 [[],[]] .smaller = true := by decide
def e2422364654818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422364654818 : Closed e2422364654818 ∧ code e2422364654818 = 11218457677026 := by decide
theorem cert_e2422364654818 : check e2422364654818 [[],[]] .smaller = true := by decide
def e2422364654830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364654830 : Closed e2422364654830 ∧ code e2422364654830 = 11218457677038 := by decide
theorem cert_e2422364654830 : check e2422364654830 [[],[]] .smaller = true := by decide
def e2422364654838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364654838 : Closed e2422364654838 ∧ code e2422364654838 = 11218457677046 := by decide
theorem cert_e2422364654838 : check e2422364654838 [[],[]] .smaller = true := by decide
def e2422364654842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364654842 : Closed e2422364654842 ∧ code e2422364654842 = 11218457677050 := by decide
theorem cert_e2422364654842 : check e2422364654842 [[],[]] .smaller = true := by decide
def e2422364655118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364655118 : Closed e2422364655118 ∧ code e2422364655118 = 11218457677326 := by decide
theorem cert_e2422364655118 : check e2422364655118 [[],[]] .smaller = true := by decide
def e2422364655130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364655130 : Closed e2422364655130 ∧ code e2422364655130 = 11218457677338 := by decide
theorem cert_e2422364655130 : check e2422364655130 [[],[]] .smaller = true := by decide
def e2422364655202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364655202 : Closed e2422364655202 ∧ code e2422364655202 = 11218457677410 := by decide
theorem cert_e2422364655202 : check e2422364655202 [[],[]] .smaller = true := by decide
def e2422364655214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364655214 : Closed e2422364655214 ∧ code e2422364655214 = 11218457677422 := by decide
theorem cert_e2422364655214 : check e2422364655214 [[],[]] .smaller = true := by decide
def e2422364655222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364655222 : Closed e2422364655222 ∧ code e2422364655222 = 11218457677430 := by decide
theorem cert_e2422364655222 : check e2422364655222 [[],[]] .smaller = true := by decide
def e2422364655226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364655226 : Closed e2422364655226 ∧ code e2422364655226 = 11218457677434 := by decide
theorem cert_e2422364655226 : check e2422364655226 [[],[]] .smaller = true := by decide
def e2422364655414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364655414 : Closed e2422364655414 ∧ code e2422364655414 = 11218457677622 := by decide
theorem cert_e2422364655414 : check e2422364655414 [[],[]] .smaller = true := by decide
def e2422364655418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364655418 : Closed e2422364655418 ∧ code e2422364655418 = 11218457677626 := by decide
theorem cert_e2422364655418 : check e2422364655418 [[],[]] .smaller = true := by decide
def e2422364655514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364655514 : Closed e2422364655514 ∧ code e2422364655514 = 11218457677722 := by decide
theorem cert_e2422364655514 : check e2422364655514 [[],[]] .smaller = true := by decide
def e2422364655558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 4) (.lam (.var 1))))))))))
theorem wire_e2422364655558 : Closed e2422364655558 ∧ code e2422364655558 = 11218457677766 := by decide
theorem cert_e2422364655558 : check e2422364655558 [[],[]] .three = true := by decide
def e2422364660190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364660190 : Closed e2422364660190 ∧ code e2422364660190 = 11218457682398 := by decide
theorem cert_e2422364660190 : check e2422364660190 [[],[]] .smaller = true := by decide
def e2422364660214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364660214 : Closed e2422364660214 ∧ code e2422364660214 = 11218457682422 := by decide
theorem cert_e2422364660214 : check e2422364660214 [[],[]] .smaller = true := by decide
def e2422364661130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364661130 : Closed e2422364661130 ∧ code e2422364661130 = 11218457683338 := by decide
theorem cert_e2422364661130 : check e2422364661130 [[],[]] .smaller = true := by decide
def e2422364661154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364661154 : Closed e2422364661154 ∧ code e2422364661154 = 11218457683362 := by decide
theorem cert_e2422364661154 : check e2422364661154 [[],[]] .smaller = true := by decide
def e2422364661166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422364661166 : Closed e2422364661166 ∧ code e2422364661166 = 11218457683374 := by decide
theorem cert_e2422364661166 : check e2422364661166 [[],[]] .smaller = true := by decide
def e2422364661174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422364661174 : Closed e2422364661174 ∧ code e2422364661174 = 11218457683382 := by decide
theorem cert_e2422364661174 : check e2422364661174 [[],[]] .smaller = true := by decide
def e2422364661178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422364661178 : Closed e2422364661178 ∧ code e2422364661178 = 11218457683386 := by decide
theorem cert_e2422364661178 : check e2422364661178 [[],[]] .smaller = true := by decide
def e2422364661206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422364661206 : Closed e2422364661206 ∧ code e2422364661206 = 11218457683414 := by decide
theorem cert_e2422364661206 : check e2422364661206 [[],[]] .smaller = true := by decide
def e2422364661210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422364661210 : Closed e2422364661210 ∧ code e2422364661210 = 11218457683418 := by decide
theorem cert_e2422364661210 : check e2422364661210 [[],[]] .smaller = true := by decide
def e2422364661226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422364661226 : Closed e2422364661226 ∧ code e2422364661226 = 11218457683434 := by decide
theorem cert_e2422364661226 : check e2422364661226 [[],[]] .smaller = true := by decide
def e2422364661262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364661262 : Closed e2422364661262 ∧ code e2422364661262 = 11218457683470 := by decide
theorem cert_e2422364661262 : check e2422364661262 [[],[]] .smaller = true := by decide
def e2422364661274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364661274 : Closed e2422364661274 ∧ code e2422364661274 = 11218457683482 := by decide
theorem cert_e2422364661274 : check e2422364661274 [[],[]] .smaller = true := by decide
def e2422364661346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364661346 : Closed e2422364661346 ∧ code e2422364661346 = 11218457683554 := by decide
theorem cert_e2422364661346 : check e2422364661346 [[],[]] .smaller = true := by decide
def e2422364661358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364661358 : Closed e2422364661358 ∧ code e2422364661358 = 11218457683566 := by decide
theorem cert_e2422364661358 : check e2422364661358 [[],[]] .smaller = true := by decide
def e2422364661366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364661366 : Closed e2422364661366 ∧ code e2422364661366 = 11218457683574 := by decide
theorem cert_e2422364661366 : check e2422364661366 [[],[]] .smaller = true := by decide
def e2422364661370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364661370 : Closed e2422364661370 ∧ code e2422364661370 = 11218457683578 := by decide
theorem cert_e2422364661370 : check e2422364661370 [[],[]] .smaller = true := by decide
def e2422364661558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364661558 : Closed e2422364661558 ∧ code e2422364661558 = 11218457683766 := by decide
theorem cert_e2422364661558 : check e2422364661558 [[],[]] .smaller = true := by decide
def e2422364661562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364661562 : Closed e2422364661562 ∧ code e2422364661562 = 11218457683770 := by decide
theorem cert_e2422364661562 : check e2422364661562 [[],[]] .smaller = true := by decide
def e2422364661658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364661658 : Closed e2422364661658 ∧ code e2422364661658 = 11218457683866 := by decide
theorem cert_e2422364661658 : check e2422364661658 [[],[]] .smaller = true := by decide
def e2422364661694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 4)))))))))
theorem wire_e2422364661694 : Closed e2422364661694 ∧ code e2422364661694 = 11218457683902 := by decide
theorem cert_e2422364661694 : check e2422364661694 [[],[]] .three = true := by decide
def e2422364661726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422364661726 : Closed e2422364661726 ∧ code e2422364661726 = 11218457683934 := by decide
theorem cert_e2422364661726 : check e2422364661726 [[],[]] .smaller = true := by decide
def e2422364661742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 4) (.var 2)))))))))
theorem wire_e2422364661742 : Closed e2422364661742 ∧ code e2422364661742 = 11218457683950 := by decide
theorem cert_e2422364661742 : check e2422364661742 [[],[]] .three = true := by decide
def e2422364664046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364664046 : Closed e2422364664046 ∧ code e2422364664046 = 11218457686254 := by decide
theorem cert_e2422364664046 : check e2422364664046 [[],[]] .smaller = true := by decide
def e2422364664054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364664054 : Closed e2422364664054 ∧ code e2422364664054 = 11218457686262 := by decide
theorem cert_e2422364664054 : check e2422364664054 [[],[]] .smaller = true := by decide
end Blc.Floor43
