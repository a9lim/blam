import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364879726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e2422364879726 : Closed e2422364879726 ∧ code e2422364879726 = 11218457901934 := by decide
theorem cert_e2422364879726 : check e2422364879726 [[],[]] .smaller = true := by decide
def e2422364879734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e2422364879734 : Closed e2422364879734 ∧ code e2422364879734 = 11218457901942 := by decide
theorem cert_e2422364879734 : check e2422364879734 [[],[]] .smaller = true := by decide
def e2422364879738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e2422364879738 : Closed e2422364879738 ∧ code e2422364879738 = 11218457901946 := by decide
theorem cert_e2422364879738 : check e2422364879738 [[],[]] .smaller = true := by decide
def e2422364879754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364879754 : Closed e2422364879754 ∧ code e2422364879754 = 11218457901962 := by decide
theorem cert_e2422364879754 : check e2422364879754 [[],[]] .smaller = true := by decide
def e2422364879778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364879778 : Closed e2422364879778 ∧ code e2422364879778 = 11218457901986 := by decide
theorem cert_e2422364879778 : check e2422364879778 [[],[]] .smaller = true := by decide
def e2422364879790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e2422364879790 : Closed e2422364879790 ∧ code e2422364879790 = 11218457901998 := by decide
theorem cert_e2422364879790 : check e2422364879790 [[],[]] .smaller = true := by decide
def e2422364879798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e2422364879798 : Closed e2422364879798 ∧ code e2422364879798 = 11218457902006 := by decide
theorem cert_e2422364879798 : check e2422364879798 [[],[]] .smaller = true := by decide
def e2422364879802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e2422364879802 : Closed e2422364879802 ∧ code e2422364879802 = 11218457902010 := by decide
theorem cert_e2422364879802 : check e2422364879802 [[],[]] .smaller = true := by decide
def e2422364879830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e2422364879830 : Closed e2422364879830 ∧ code e2422364879830 = 11218457902038 := by decide
theorem cert_e2422364879830 : check e2422364879830 [[],[]] .smaller = true := by decide
def e2422364879834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e2422364879834 : Closed e2422364879834 ∧ code e2422364879834 = 11218457902042 := by decide
theorem cert_e2422364879834 : check e2422364879834 [[],[]] .smaller = true := by decide
def e2422364879850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0)))))))))
theorem wire_e2422364879850 : Closed e2422364879850 ∧ code e2422364879850 = 11218457902058 := by decide
theorem cert_e2422364879850 : check e2422364879850 [[],[]] .three = true := by decide
def e2422364879958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))))
theorem wire_e2422364879958 : Closed e2422364879958 ∧ code e2422364879958 = 11218457902166 := by decide
theorem cert_e2422364879958 : check e2422364879958 [[],[]] .smaller = true := by decide
def e2422364879962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))))
theorem wire_e2422364879962 : Closed e2422364879962 ∧ code e2422364879962 = 11218457902170 := by decide
theorem cert_e2422364879962 : check e2422364879962 [[],[]] .smaller = true := by decide
def e2422364880150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422364880150 : Closed e2422364880150 ∧ code e2422364880150 = 11218457902358 := by decide
theorem cert_e2422364880150 : check e2422364880150 [[],[]] .smaller = true := by decide
def e2422364880222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e2422364880222 : Closed e2422364880222 ∧ code e2422364880222 = 11218457902430 := by decide
theorem cert_e2422364880222 : check e2422364880222 [[],[]] .smaller = true := by decide
def e2422364880226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422364880226 : Closed e2422364880226 ∧ code e2422364880226 = 11218457902434 := by decide
theorem cert_e2422364880226 : check e2422364880226 [[],[]] .smaller = true := by decide
def e2422364880238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422364880238 : Closed e2422364880238 ∧ code e2422364880238 = 11218457902446 := by decide
theorem cert_e2422364880238 : check e2422364880238 [[],[]] .smaller = true := by decide
def e2422364880246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422364880246 : Closed e2422364880246 ∧ code e2422364880246 = 11218457902454 := by decide
theorem cert_e2422364880246 : check e2422364880246 [[],[]] .smaller = true := by decide
def e2422364880250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e2422364880250 : Closed e2422364880250 ∧ code e2422364880250 = 11218457902458 := by decide
theorem cert_e2422364880250 : check e2422364880250 [[],[]] .smaller = true := by decide
def e2422364880266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364880266 : Closed e2422364880266 ∧ code e2422364880266 = 11218457902474 := by decide
theorem cert_e2422364880266 : check e2422364880266 [[],[]] .smaller = true := by decide
def e2422364880290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364880290 : Closed e2422364880290 ∧ code e2422364880290 = 11218457902498 := by decide
theorem cert_e2422364880290 : check e2422364880290 [[],[]] .smaller = true := by decide
def e2422364880302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422364880302 : Closed e2422364880302 ∧ code e2422364880302 = 11218457902510 := by decide
theorem cert_e2422364880302 : check e2422364880302 [[],[]] .smaller = true := by decide
def e2422364880310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)))))))))
theorem wire_e2422364880310 : Closed e2422364880310 ∧ code e2422364880310 = 11218457902518 := by decide
theorem cert_e2422364880310 : check e2422364880310 [[],[]] .smaller = true := by decide
def e2422364880314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422364880314 : Closed e2422364880314 ∧ code e2422364880314 = 11218457902522 := by decide
theorem cert_e2422364880314 : check e2422364880314 [[],[]] .smaller = true := by decide
def e2422364880342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422364880342 : Closed e2422364880342 ∧ code e2422364880342 = 11218457902550 := by decide
theorem cert_e2422364880342 : check e2422364880342 [[],[]] .smaller = true := by decide
def e2422364880346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422364880346 : Closed e2422364880346 ∧ code e2422364880346 = 11218457902554 := by decide
theorem cert_e2422364880346 : check e2422364880346 [[],[]] .smaller = true := by decide
def e2422364880362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e2422364880362 : Closed e2422364880362 ∧ code e2422364880362 = 11218457902570 := by decide
theorem cert_e2422364880362 : check e2422364880362 [[],[]] .smaller = true := by decide
def e2422364880558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422364880558 : Closed e2422364880558 ∧ code e2422364880558 = 11218457902766 := by decide
theorem cert_e2422364880558 : check e2422364880558 [[],[]] .smaller = true := by decide
def e2422364880566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2422364880566 : Closed e2422364880566 ∧ code e2422364880566 = 11218457902774 := by decide
theorem cert_e2422364880566 : check e2422364880566 [[],[]] .smaller = true := by decide
def e2422364880570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422364880570 : Closed e2422364880570 ∧ code e2422364880570 = 11218457902778 := by decide
theorem cert_e2422364880570 : check e2422364880570 [[],[]] .smaller = true := by decide
def e2422364880598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2422364880598 : Closed e2422364880598 ∧ code e2422364880598 = 11218457902806 := by decide
theorem cert_e2422364880598 : check e2422364880598 [[],[]] .smaller = true := by decide
def e2422364880602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2422364880602 : Closed e2422364880602 ∧ code e2422364880602 = 11218457902810 := by decide
theorem cert_e2422364880602 : check e2422364880602 [[],[]] .smaller = true := by decide
def e2422364880618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422364880618 : Closed e2422364880618 ∧ code e2422364880618 = 11218457902826 := by decide
theorem cert_e2422364880618 : check e2422364880618 [[],[]] .smaller = true := by decide
def e2422364880726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422364880726 : Closed e2422364880726 ∧ code e2422364880726 = 11218457902934 := by decide
theorem cert_e2422364880726 : check e2422364880726 [[],[]] .three = true := by decide
def e2422364880730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422364880730 : Closed e2422364880730 ∧ code e2422364880730 = 11218457902938 := by decide
theorem cert_e2422364880730 : check e2422364880730 [[],[]] .three = true := by decide
def e2422364880746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422364880746 : Closed e2422364880746 ∧ code e2422364880746 = 11218457902954 := by decide
theorem cert_e2422364880746 : check e2422364880746 [[],[]] .three = true := by decide
def e2422364881390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))))
theorem wire_e2422364881390 : Closed e2422364881390 ∧ code e2422364881390 = 11218457903598 := by decide
theorem cert_e2422364881390 : check e2422364881390 [[],[]] .smaller = true := by decide
def e2422364881398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))))
theorem wire_e2422364881398 : Closed e2422364881398 ∧ code e2422364881398 = 11218457903606 := by decide
theorem cert_e2422364881398 : check e2422364881398 [[],[]] .smaller = true := by decide
def e2422364882158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364882158 : Closed e2422364882158 ∧ code e2422364882158 = 11218457904366 := by decide
theorem cert_e2422364882158 : check e2422364882158 [[],[]] .smaller = true := by decide
def e2422364882166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364882166 : Closed e2422364882166 ∧ code e2422364882166 = 11218457904374 := by decide
theorem cert_e2422364882166 : check e2422364882166 [[],[]] .smaller = true := by decide
def e2422364882718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))))
theorem wire_e2422364882718 : Closed e2422364882718 ∧ code e2422364882718 = 11218457904926 := by decide
theorem cert_e2422364882718 : check e2422364882718 [[],[]] .smaller = true := by decide
def e2422364882830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))))
theorem wire_e2422364882830 : Closed e2422364882830 ∧ code e2422364882830 = 11218457905038 := by decide
theorem cert_e2422364882830 : check e2422364882830 [[],[]] .smaller = true := by decide
def e2422364882878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 4)))))))))
theorem wire_e2422364882878 : Closed e2422364882878 ∧ code e2422364882878 = 11218457905086 := by decide
theorem cert_e2422364882878 : check e2422364882878 [[],[]] .three = true := by decide
def e2422364882926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 5))) (.var 2)))))))))
theorem wire_e2422364882926 : Closed e2422364882926 ∧ code e2422364882926 = 11218457905134 := by decide
theorem cert_e2422364882926 : check e2422364882926 [[],[]] .three = true := by decide
def e2422364884414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4)))))))))
theorem wire_e2422364884414 : Closed e2422364884414 ∧ code e2422364884414 = 11218457906622 := by decide
theorem cert_e2422364884414 : check e2422364884414 [[],[]] .three = true := by decide
def e2422364884446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e2422364884446 : Closed e2422364884446 ∧ code e2422364884446 = 11218457906654 := by decide
theorem cert_e2422364884446 : check e2422364884446 [[],[]] .smaller = true := by decide
def e2422364884462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e2422364884462 : Closed e2422364884462 ∧ code e2422364884462 = 11218457906670 := by decide
theorem cert_e2422364884462 : check e2422364884462 [[],[]] .smaller = true := by decide
def e2422364884470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1)))))))))
theorem wire_e2422364884470 : Closed e2422364884470 ∧ code e2422364884470 = 11218457906678 := by decide
theorem cert_e2422364884470 : check e2422364884470 [[],[]] .three = true := by decide
def e2422364884526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422364884526 : Closed e2422364884526 ∧ code e2422364884526 = 11218457906734 := by decide
theorem cert_e2422364884526 : check e2422364884526 [[],[]] .smaller = true := by decide
def e2422364884670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4)))))))))
theorem wire_e2422364884670 : Closed e2422364884670 ∧ code e2422364884670 = 11218457906878 := by decide
theorem cert_e2422364884670 : check e2422364884670 [[],[]] .three = true := by decide
def e2422364884702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e2422364884702 : Closed e2422364884702 ∧ code e2422364884702 = 11218457906910 := by decide
theorem cert_e2422364884702 : check e2422364884702 [[],[]] .smaller = true := by decide
def e2422364884706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))))
theorem wire_e2422364884706 : Closed e2422364884706 ∧ code e2422364884706 = 11218457906914 := by decide
theorem cert_e2422364884706 : check e2422364884706 [[],[]] .smaller = true := by decide
def e2422364884718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))))
theorem wire_e2422364884718 : Closed e2422364884718 ∧ code e2422364884718 = 11218457906926 := by decide
theorem cert_e2422364884718 : check e2422364884718 [[],[]] .smaller = true := by decide
def e2422364884726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e2422364884726 : Closed e2422364884726 ∧ code e2422364884726 = 11218457906934 := by decide
theorem cert_e2422364884726 : check e2422364884726 [[],[]] .smaller = true := by decide
def e2422364884730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0)))))))))
theorem wire_e2422364884730 : Closed e2422364884730 ∧ code e2422364884730 = 11218457906938 := by decide
theorem cert_e2422364884730 : check e2422364884730 [[],[]] .three = true := by decide
def e2422364884758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422364884758 : Closed e2422364884758 ∧ code e2422364884758 = 11218457906966 := by decide
theorem cert_e2422364884758 : check e2422364884758 [[],[]] .smaller = true := by decide
def e2422364884830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e2422364884830 : Closed e2422364884830 ∧ code e2422364884830 = 11218457907038 := by decide
theorem cert_e2422364884830 : check e2422364884830 [[],[]] .smaller = true := by decide
def e2422364884834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))))
theorem wire_e2422364884834 : Closed e2422364884834 ∧ code e2422364884834 = 11218457907042 := by decide
theorem cert_e2422364884834 : check e2422364884834 [[],[]] .smaller = true := by decide
def e2422364884846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))))
theorem wire_e2422364884846 : Closed e2422364884846 ∧ code e2422364884846 = 11218457907054 := by decide
theorem cert_e2422364884846 : check e2422364884846 [[],[]] .smaller = true := by decide
def e2422364884854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))))
theorem wire_e2422364884854 : Closed e2422364884854 ∧ code e2422364884854 = 11218457907062 := by decide
theorem cert_e2422364884854 : check e2422364884854 [[],[]] .smaller = true := by decide
def e2422364884858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e2422364884858 : Closed e2422364884858 ∧ code e2422364884858 = 11218457907066 := by decide
theorem cert_e2422364884858 : check e2422364884858 [[],[]] .smaller = true := by decide
def e2422364884910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e2422364884910 : Closed e2422364884910 ∧ code e2422364884910 = 11218457907118 := by decide
theorem cert_e2422364884910 : check e2422364884910 [[],[]] .smaller = true := by decide
def e2422364884918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e2422364884918 : Closed e2422364884918 ∧ code e2422364884918 = 11218457907126 := by decide
theorem cert_e2422364884918 : check e2422364884918 [[],[]] .smaller = true := by decide
def e2422364884922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e2422364884922 : Closed e2422364884922 ∧ code e2422364884922 = 11218457907130 := by decide
theorem cert_e2422364884922 : check e2422364884922 [[],[]] .smaller = true := by decide
def e2422364884950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1)))))))))
theorem wire_e2422364884950 : Closed e2422364884950 ∧ code e2422364884950 = 11218457907158 := by decide
theorem cert_e2422364884950 : check e2422364884950 [[],[]] .three = true := by decide
def e2422364884954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0)))))))))
theorem wire_e2422364884954 : Closed e2422364884954 ∧ code e2422364884954 = 11218457907162 := by decide
theorem cert_e2422364884954 : check e2422364884954 [[],[]] .three = true := by decide
def e2422364885950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422364885950 : Closed e2422364885950 ∧ code e2422364885950 = 11218457908158 := by decide
theorem cert_e2422364885950 : check e2422364885950 [[],[]] .three = true := by decide
def e2422364885982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422364885982 : Closed e2422364885982 ∧ code e2422364885982 = 11218457908190 := by decide
theorem cert_e2422364885982 : check e2422364885982 [[],[]] .smaller = true := by decide
def e2422364885998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422364885998 : Closed e2422364885998 ∧ code e2422364885998 = 11218457908206 := by decide
theorem cert_e2422364885998 : check e2422364885998 [[],[]] .smaller = true := by decide
def e2422364886006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422364886006 : Closed e2422364886006 ∧ code e2422364886006 = 11218457908214 := by decide
theorem cert_e2422364886006 : check e2422364886006 [[],[]] .three = true := by decide
def e2422364887102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422364887102 : Closed e2422364887102 ∧ code e2422364887102 = 11218457909310 := by decide
theorem cert_e2422364887102 : check e2422364887102 [[],[]] .smaller = true := by decide
def e2422364887486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422364887486 : Closed e2422364887486 ∧ code e2422364887486 = 11218457909694 := by decide
theorem cert_e2422364887486 : check e2422364887486 [[],[]] .three = true := by decide
def e2422364887518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364887518 : Closed e2422364887518 ∧ code e2422364887518 = 11218457909726 := by decide
theorem cert_e2422364887518 : check e2422364887518 [[],[]] .smaller = true := by decide
def e2422364887522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422364887522 : Closed e2422364887522 ∧ code e2422364887522 = 11218457909730 := by decide
theorem cert_e2422364887522 : check e2422364887522 [[],[]] .smaller = true := by decide
def e2422364887534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422364887534 : Closed e2422364887534 ∧ code e2422364887534 = 11218457909742 := by decide
theorem cert_e2422364887534 : check e2422364887534 [[],[]] .smaller = true := by decide
def e2422364887542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364887542 : Closed e2422364887542 ∧ code e2422364887542 = 11218457909750 := by decide
theorem cert_e2422364887542 : check e2422364887542 [[],[]] .smaller = true := by decide
def e2422364887546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422364887546 : Closed e2422364887546 ∧ code e2422364887546 = 11218457909754 := by decide
theorem cert_e2422364887546 : check e2422364887546 [[],[]] .three = true := by decide
def e2422364888094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422364888094 : Closed e2422364888094 ∧ code e2422364888094 = 11218457910302 := by decide
theorem cert_e2422364888094 : check e2422364888094 [[],[]] .smaller = true := by decide
def e2422364888190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 5))))))))))
theorem wire_e2422364888190 : Closed e2422364888190 ∧ code e2422364888190 = 11218457910398 := by decide
theorem cert_e2422364888190 : check e2422364888190 [[],[]] .three = true := by decide
def e2422364888286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364888286 : Closed e2422364888286 ∧ code e2422364888286 = 11218457910494 := by decide
theorem cert_e2422364888286 : check e2422364888286 [[],[]] .smaller = true := by decide
def e2422364888290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422364888290 : Closed e2422364888290 ∧ code e2422364888290 = 11218457910498 := by decide
theorem cert_e2422364888290 : check e2422364888290 [[],[]] .smaller = true := by decide
def e2422364888302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364888302 : Closed e2422364888302 ∧ code e2422364888302 = 11218457910510 := by decide
theorem cert_e2422364888302 : check e2422364888302 [[],[]] .smaller = true := by decide
def e2422364888310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364888310 : Closed e2422364888310 ∧ code e2422364888310 = 11218457910518 := by decide
theorem cert_e2422364888310 : check e2422364888310 [[],[]] .smaller = true := by decide
def e2422364888314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364888314 : Closed e2422364888314 ∧ code e2422364888314 = 11218457910522 := by decide
theorem cert_e2422364888314 : check e2422364888314 [[],[]] .smaller = true := by decide
def e2422364888686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364888686 : Closed e2422364888686 ∧ code e2422364888686 = 11218457910894 := by decide
theorem cert_e2422364888686 : check e2422364888686 [[],[]] .smaller = true := by decide
def e2422364888694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364888694 : Closed e2422364888694 ∧ code e2422364888694 = 11218457910902 := by decide
theorem cert_e2422364888694 : check e2422364888694 [[],[]] .smaller = true := by decide
def e2422364888698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364888698 : Closed e2422364888698 ∧ code e2422364888698 = 11218457910906 := by decide
theorem cert_e2422364888698 : check e2422364888698 [[],[]] .smaller = true := by decide
def e2422364888862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.lam (.var 3))))))))))
theorem wire_e2422364888862 : Closed e2422364888862 ∧ code e2422364888862 = 11218457911070 := by decide
theorem cert_e2422364888862 : check e2422364888862 [[],[]] .three = true := by decide
def e2422364888886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364888886 : Closed e2422364888886 ∧ code e2422364888886 = 11218457911094 := by decide
theorem cert_e2422364888886 : check e2422364888886 [[],[]] .three = true := by decide
def e2422364888890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364888890 : Closed e2422364888890 ∧ code e2422364888890 = 11218457911098 := by decide
theorem cert_e2422364888890 : check e2422364888890 [[],[]] .three = true := by decide
def e2422364889326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))))
theorem wire_e2422364889326 : Closed e2422364889326 ∧ code e2422364889326 = 11218457911534 := by decide
theorem cert_e2422364889326 : check e2422364889326 [[],[]] .smaller = true := by decide
def e2422364889338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))))
theorem wire_e2422364889338 : Closed e2422364889338 ∧ code e2422364889338 = 11218457911546 := by decide
theorem cert_e2422364889338 : check e2422364889338 [[],[]] .smaller = true := by decide
def e2422364889518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))))
theorem wire_e2422364889518 : Closed e2422364889518 ∧ code e2422364889518 = 11218457911726 := by decide
theorem cert_e2422364889518 : check e2422364889518 [[],[]] .smaller = true := by decide
def e2422364889710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364889710 : Closed e2422364889710 ∧ code e2422364889710 = 11218457911918 := by decide
theorem cert_e2422364889710 : check e2422364889710 [[],[]] .smaller = true := by decide
def e2422364889722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364889722 : Closed e2422364889722 ∧ code e2422364889722 = 11218457911930 := by decide
theorem cert_e2422364889722 : check e2422364889722 [[],[]] .smaller = true := by decide
def e2422364889886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))))
theorem wire_e2422364889886 : Closed e2422364889886 ∧ code e2422364889886 = 11218457912094 := by decide
theorem cert_e2422364889886 : check e2422364889886 [[],[]] .smaller = true := by decide
def e2422364890046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 4)))))))))
theorem wire_e2422364890046 : Closed e2422364890046 ∧ code e2422364890046 = 11218457912254 := by decide
theorem cert_e2422364890046 : check e2422364890046 [[],[]] .three = true := by decide
def e2422364890054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))))
theorem wire_e2422364890054 : Closed e2422364890054 ∧ code e2422364890054 = 11218457912262 := by decide
theorem cert_e2422364890054 : check e2422364890054 [[],[]] .smaller = true := by decide
def e2422364890102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 5))) (.var 1)))))))))
theorem wire_e2422364890102 : Closed e2422364890102 ∧ code e2422364890102 = 11218457912310 := by decide
theorem cert_e2422364890102 : check e2422364890102 [[],[]] .three = true := by decide
def e2422364890670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422364890670 : Closed e2422364890670 ∧ code e2422364890670 = 11218457912878 := by decide
theorem cert_e2422364890670 : check e2422364890670 [[],[]] .smaller = true := by decide
def e2422364890814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4)))))))))
theorem wire_e2422364890814 : Closed e2422364890814 ∧ code e2422364890814 = 11218457913022 := by decide
theorem cert_e2422364890814 : check e2422364890814 [[],[]] .three = true := by decide
def e2422364890846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e2422364890846 : Closed e2422364890846 ∧ code e2422364890846 = 11218457913054 := by decide
theorem cert_e2422364890846 : check e2422364890846 [[],[]] .smaller = true := by decide
def e2422364890850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))))
theorem wire_e2422364890850 : Closed e2422364890850 ∧ code e2422364890850 = 11218457913058 := by decide
theorem cert_e2422364890850 : check e2422364890850 [[],[]] .smaller = true := by decide
def e2422364890862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e2422364890862 : Closed e2422364890862 ∧ code e2422364890862 = 11218457913070 := by decide
theorem cert_e2422364890862 : check e2422364890862 [[],[]] .smaller = true := by decide
def e2422364890870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e2422364890870 : Closed e2422364890870 ∧ code e2422364890870 = 11218457913078 := by decide
theorem cert_e2422364890870 : check e2422364890870 [[],[]] .smaller = true := by decide
def e2422364890874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0)))))))))
theorem wire_e2422364890874 : Closed e2422364890874 ∧ code e2422364890874 = 11218457913082 := by decide
theorem cert_e2422364890874 : check e2422364890874 [[],[]] .three = true := by decide
def e2422364890974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e2422364890974 : Closed e2422364890974 ∧ code e2422364890974 = 11218457913182 := by decide
theorem cert_e2422364890974 : check e2422364890974 [[],[]] .smaller = true := by decide
def e2422364890990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e2422364890990 : Closed e2422364890990 ∧ code e2422364890990 = 11218457913198 := by decide
theorem cert_e2422364890990 : check e2422364890990 [[],[]] .smaller = true := by decide
def e2422364890998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e2422364890998 : Closed e2422364890998 ∧ code e2422364890998 = 11218457913206 := by decide
theorem cert_e2422364890998 : check e2422364890998 [[],[]] .smaller = true := by decide
def e2422364891002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e2422364891002 : Closed e2422364891002 ∧ code e2422364891002 = 11218457913210 := by decide
theorem cert_e2422364891002 : check e2422364891002 [[],[]] .smaller = true := by decide
def e2422364891018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422364891018 : Closed e2422364891018 ∧ code e2422364891018 = 11218457913226 := by decide
theorem cert_e2422364891018 : check e2422364891018 [[],[]] .smaller = true := by decide
def e2422364891042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422364891042 : Closed e2422364891042 ∧ code e2422364891042 = 11218457913250 := by decide
theorem cert_e2422364891042 : check e2422364891042 [[],[]] .smaller = true := by decide
def e2422364891054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e2422364891054 : Closed e2422364891054 ∧ code e2422364891054 = 11218457913262 := by decide
theorem cert_e2422364891054 : check e2422364891054 [[],[]] .smaller = true := by decide
def e2422364891062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e2422364891062 : Closed e2422364891062 ∧ code e2422364891062 = 11218457913270 := by decide
theorem cert_e2422364891062 : check e2422364891062 [[],[]] .smaller = true := by decide
def e2422364891066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e2422364891066 : Closed e2422364891066 ∧ code e2422364891066 = 11218457913274 := by decide
theorem cert_e2422364891066 : check e2422364891066 [[],[]] .smaller = true := by decide
def e2422364891094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e2422364891094 : Closed e2422364891094 ∧ code e2422364891094 = 11218457913302 := by decide
theorem cert_e2422364891094 : check e2422364891094 [[],[]] .smaller = true := by decide
def e2422364891098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e2422364891098 : Closed e2422364891098 ∧ code e2422364891098 = 11218457913306 := by decide
theorem cert_e2422364891098 : check e2422364891098 [[],[]] .smaller = true := by decide
def e2422364891114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0)))))))))
theorem wire_e2422364891114 : Closed e2422364891114 ∧ code e2422364891114 = 11218457913322 := by decide
theorem cert_e2422364891114 : check e2422364891114 [[],[]] .three = true := by decide
def e2422364891198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422364891198 : Closed e2422364891198 ∧ code e2422364891198 = 11218457913406 := by decide
theorem cert_e2422364891198 : check e2422364891198 [[],[]] .smaller = true := by decide
def e2422364891582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422364891582 : Closed e2422364891582 ∧ code e2422364891582 = 11218457913790 := by decide
theorem cert_e2422364891582 : check e2422364891582 [[],[]] .three = true := by decide
def e2422364891614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364891614 : Closed e2422364891614 ∧ code e2422364891614 = 11218457913822 := by decide
theorem cert_e2422364891614 : check e2422364891614 [[],[]] .smaller = true := by decide
def e2422364891618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422364891618 : Closed e2422364891618 ∧ code e2422364891618 = 11218457913826 := by decide
theorem cert_e2422364891618 : check e2422364891618 [[],[]] .smaller = true := by decide
def e2422364891630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422364891630 : Closed e2422364891630 ∧ code e2422364891630 = 11218457913838 := by decide
theorem cert_e2422364891630 : check e2422364891630 [[],[]] .smaller = true := by decide
def e2422364891638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364891638 : Closed e2422364891638 ∧ code e2422364891638 = 11218457913846 := by decide
theorem cert_e2422364891638 : check e2422364891638 [[],[]] .smaller = true := by decide
def e2422364891642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422364891642 : Closed e2422364891642 ∧ code e2422364891642 = 11218457913850 := by decide
theorem cert_e2422364891642 : check e2422364891642 [[],[]] .three = true := by decide
def e2422364892286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 5))))))))))
theorem wire_e2422364892286 : Closed e2422364892286 ∧ code e2422364892286 = 11218457914494 := by decide
theorem cert_e2422364892286 : check e2422364892286 [[],[]] .three = true := by decide
def e2422364892382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364892382 : Closed e2422364892382 ∧ code e2422364892382 = 11218457914590 := by decide
theorem cert_e2422364892382 : check e2422364892382 [[],[]] .smaller = true := by decide
def e2422364892398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364892398 : Closed e2422364892398 ∧ code e2422364892398 = 11218457914606 := by decide
theorem cert_e2422364892398 : check e2422364892398 [[],[]] .smaller = true := by decide
def e2422364892406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364892406 : Closed e2422364892406 ∧ code e2422364892406 = 11218457914614 := by decide
theorem cert_e2422364892406 : check e2422364892406 [[],[]] .smaller = true := by decide
def e2422364892410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364892410 : Closed e2422364892410 ∧ code e2422364892410 = 11218457914618 := by decide
theorem cert_e2422364892410 : check e2422364892410 [[],[]] .smaller = true := by decide
def e2422364892686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364892686 : Closed e2422364892686 ∧ code e2422364892686 = 11218457914894 := by decide
theorem cert_e2422364892686 : check e2422364892686 [[],[]] .smaller = true := by decide
def e2422364892698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364892698 : Closed e2422364892698 ∧ code e2422364892698 = 11218457914906 := by decide
theorem cert_e2422364892698 : check e2422364892698 [[],[]] .smaller = true := by decide
def e2422364892770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364892770 : Closed e2422364892770 ∧ code e2422364892770 = 11218457914978 := by decide
theorem cert_e2422364892770 : check e2422364892770 [[],[]] .smaller = true := by decide
def e2422364892782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364892782 : Closed e2422364892782 ∧ code e2422364892782 = 11218457914990 := by decide
theorem cert_e2422364892782 : check e2422364892782 [[],[]] .smaller = true := by decide
def e2422364892790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364892790 : Closed e2422364892790 ∧ code e2422364892790 = 11218457914998 := by decide
theorem cert_e2422364892790 : check e2422364892790 [[],[]] .smaller = true := by decide
def e2422364892794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364892794 : Closed e2422364892794 ∧ code e2422364892794 = 11218457915002 := by decide
theorem cert_e2422364892794 : check e2422364892794 [[],[]] .smaller = true := by decide
def e2422364892982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364892982 : Closed e2422364892982 ∧ code e2422364892982 = 11218457915190 := by decide
theorem cert_e2422364892982 : check e2422364892982 [[],[]] .smaller = true := by decide
def e2422364892986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364892986 : Closed e2422364892986 ∧ code e2422364892986 = 11218457915194 := by decide
theorem cert_e2422364892986 : check e2422364892986 [[],[]] .smaller = true := by decide
def e2422364893070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.lam (.var 2))))))))))
theorem wire_e2422364893070 : Closed e2422364893070 ∧ code e2422364893070 = 11218457915278 := by decide
theorem cert_e2422364893070 : check e2422364893070 [[],[]] .three = true := by decide
def e2422364893082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364893082 : Closed e2422364893082 ∧ code e2422364893082 = 11218457915290 := by decide
theorem cert_e2422364893082 : check e2422364893082 [[],[]] .three = true := by decide
def e2422364893118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 4)))))))))
theorem wire_e2422364893118 : Closed e2422364893118 ∧ code e2422364893118 = 11218457915326 := by decide
theorem cert_e2422364893118 : check e2422364893118 [[],[]] .three = true := by decide
def e2422364893302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))))
theorem wire_e2422364893302 : Closed e2422364893302 ∧ code e2422364893302 = 11218457915510 := by decide
theorem cert_e2422364893302 : check e2422364893302 [[],[]] .smaller = true := by decide
def e2422364893306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))))
theorem wire_e2422364893306 : Closed e2422364893306 ∧ code e2422364893306 = 11218457915514 := by decide
theorem cert_e2422364893306 : check e2422364893306 [[],[]] .smaller = true := by decide
def e2422364893398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))))
theorem wire_e2422364893398 : Closed e2422364893398 ∧ code e2422364893398 = 11218457915606 := by decide
theorem cert_e2422364893398 : check e2422364893398 [[],[]] .smaller = true := by decide
def e2422364893494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364893494 : Closed e2422364893494 ∧ code e2422364893494 = 11218457915702 := by decide
theorem cert_e2422364893494 : check e2422364893494 [[],[]] .smaller = true := by decide
def e2422364893498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364893498 : Closed e2422364893498 ∧ code e2422364893498 = 11218457915706 := by decide
theorem cert_e2422364893498 : check e2422364893498 [[],[]] .smaller = true := by decide
def e2422364893582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))))
theorem wire_e2422364893582 : Closed e2422364893582 ∧ code e2422364893582 = 11218457915790 := by decide
theorem cert_e2422364893582 : check e2422364893582 [[],[]] .smaller = true := by decide
def e2422364893630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 4)))))))))
theorem wire_e2422364893630 : Closed e2422364893630 ∧ code e2422364893630 = 11218457915838 := by decide
theorem cert_e2422364893630 : check e2422364893630 [[],[]] .three = true := by decide
def e2422364893638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))))
theorem wire_e2422364893638 : Closed e2422364893638 ∧ code e2422364893638 = 11218457915846 := by decide
theorem cert_e2422364893638 : check e2422364893638 [[],[]] .smaller = true := by decide
def e2422364893690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 5))) (.var 0)))))))))
theorem wire_e2422364893690 : Closed e2422364893690 ∧ code e2422364893690 = 11218457915898 := by decide
theorem cert_e2422364893690 : check e2422364893690 [[],[]] .three = true := by decide
def e2422364893974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422364893974 : Closed e2422364893974 ∧ code e2422364893974 = 11218457916182 := by decide
theorem cert_e2422364893974 : check e2422364893974 [[],[]] .smaller = true := by decide
def e2422364894046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e2422364894046 : Closed e2422364894046 ∧ code e2422364894046 = 11218457916254 := by decide
theorem cert_e2422364894046 : check e2422364894046 [[],[]] .smaller = true := by decide
def e2422364894050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))))
theorem wire_e2422364894050 : Closed e2422364894050 ∧ code e2422364894050 = 11218457916258 := by decide
theorem cert_e2422364894050 : check e2422364894050 [[],[]] .smaller = true := by decide
def e2422364894062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422364894062 : Closed e2422364894062 ∧ code e2422364894062 = 11218457916270 := by decide
theorem cert_e2422364894062 : check e2422364894062 [[],[]] .smaller = true := by decide
def e2422364894070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422364894070 : Closed e2422364894070 ∧ code e2422364894070 = 11218457916278 := by decide
theorem cert_e2422364894070 : check e2422364894070 [[],[]] .smaller = true := by decide
def e2422364894074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e2422364894074 : Closed e2422364894074 ∧ code e2422364894074 = 11218457916282 := by decide
theorem cert_e2422364894074 : check e2422364894074 [[],[]] .smaller = true := by decide
def e2422364894090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422364894090 : Closed e2422364894090 ∧ code e2422364894090 = 11218457916298 := by decide
theorem cert_e2422364894090 : check e2422364894090 [[],[]] .smaller = true := by decide
def e2422364894114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422364894114 : Closed e2422364894114 ∧ code e2422364894114 = 11218457916322 := by decide
theorem cert_e2422364894114 : check e2422364894114 [[],[]] .smaller = true := by decide
def e2422364894126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422364894126 : Closed e2422364894126 ∧ code e2422364894126 = 11218457916334 := by decide
theorem cert_e2422364894126 : check e2422364894126 [[],[]] .smaller = true := by decide
def e2422364894134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)))))))))
theorem wire_e2422364894134 : Closed e2422364894134 ∧ code e2422364894134 = 11218457916342 := by decide
theorem cert_e2422364894134 : check e2422364894134 [[],[]] .smaller = true := by decide
end Blc.Floor43
