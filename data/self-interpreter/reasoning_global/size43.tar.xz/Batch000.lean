import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e552670566426 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552670566426 : Closed e552670566426 ∧ code e552670566426 = 9348763588634 := by decide
theorem cert_e552670566426 : check e552670566426 [[.under]] .three = true := by decide
def e552672663578 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552672663578 : Closed e552672663578 ∧ code e552672663578 = 9348765685786 := by decide
theorem cert_e552672663578 : check e552672663578 [[.under]] .three = true := by decide
def e552672794650 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552672794650 : Closed e552672794650 ∧ code e552672794650 = 9348765816858 := by decide
theorem cert_e552672794650 : check e552672794650 [[.under]] .three = true := by decide
def e552687343642 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552687343642 : Closed e552687343642 ∧ code e552687343642 = 9348780365850 := by decide
theorem cert_e552687343642 : check e552687343642 [[.under]] .three = true := by decide
def e552690489370 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552690489370 : Closed e552690489370 ∧ code e552690489370 = 9348783511578 := by decide
theorem cert_e552690489370 : check e552690489370 [[.under]] .three = true := by decide
def e552690685978 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552690685978 : Closed e552690685978 ∧ code e552690685978 = 9348783708186 := by decide
theorem cert_e552690685978 : check e552690685978 [[.under]] .three = true := by decide
def e552697829402 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552697829402 : Closed e552697829402 ∧ code e552697829402 = 9348790851610 := by decide
theorem cert_e552697829402 : check e552697829402 [[.under]] .three = true := by decide
def e552697960474 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552697960474 : Closed e552697960474 ∧ code e552697960474 = 9348790982682 := by decide
theorem cert_e552697960474 : check e552697960474 [[.under]] .three = true := by decide
def e552698877978 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552698877978 : Closed e552698877978 ∧ code e552698877978 = 9348791900186 := by decide
theorem cert_e552698877978 : check e552698877978 [[.under]] .three = true := by decide
def e552699074586 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552699074586 : Closed e552699074586 ∧ code e552699074586 = 9348792096794 := by decide
theorem cert_e552699074586 : check e552699074586 [[.under]] .three = true := by decide
def e552699533338 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552699533338 : Closed e552699533338 ∧ code e552699533338 = 9348792555546 := by decide
theorem cert_e552699533338 : check e552699533338 [[.under]] .three = true := by decide
def e552699598874 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552699598874 : Closed e552699598874 ∧ code e552699598874 = 9348792621082 := by decide
theorem cert_e552699598874 : check e552699598874 [[.under]] .three = true := by decide
def e552771229722 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552771229722 : Closed e552771229722 ∧ code e552771229722 = 9348864251930 := by decide
theorem cert_e552771229722 : check e552771229722 [[.under]] .three = true := by decide
def e552773326874 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552773326874 : Closed e552773326874 ∧ code e552773326874 = 9348866349082 := by decide
theorem cert_e552773326874 : check e552773326874 [[.under]] .three = true := by decide
def e552773457946 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552773457946 : Closed e552773457946 ∧ code e552773457946 = 9348866480154 := by decide
theorem cert_e552773457946 : check e552773457946 [[.under]] .three = true := by decide
def e552817367066 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552817367066 : Closed e552817367066 ∧ code e552817367066 = 9348910389274 := by decide
theorem cert_e552817367066 : check e552817367066 [[.under]] .three = true := by decide
def e552829949978 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552829949978 : Closed e552829949978 ∧ code e552829949978 = 9348922972186 := by decide
theorem cert_e552829949978 : check e552829949978 [[.under]] .three = true := by decide
def e552830081050 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552830081050 : Closed e552830081050 ∧ code e552830081050 = 9348923103258 := by decide
theorem cert_e552830081050 : check e552830081050 [[.under]] .three = true := by decide
def e552871893018 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552871893018 : Closed e552871893018 ∧ code e552871893018 = 9348964915226 := by decide
theorem cert_e552871893018 : check e552871893018 [[.under]] .three = true := by decide
def e552875038746 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552875038746 : Closed e552875038746 ∧ code e552875038746 = 9348968060954 := by decide
theorem cert_e552875038746 : check e552875038746 [[.under]] .three = true := by decide
def e552875235354 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552875235354 : Closed e552875235354 ∧ code e552875235354 = 9348968257562 := by decide
theorem cert_e552875235354 : check e552875235354 [[.under]] .three = true := by decide
def e552884475930 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552884475930 : Closed e552884475930 ∧ code e552884475930 = 9348977498138 := by decide
theorem cert_e552884475930 : check e552884475930 [[.under]] .three = true := by decide
def e552903350298 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552903350298 : Closed e552903350298 ∧ code e552903350298 = 9348996372506 := by decide
theorem cert_e552903350298 : check e552903350298 [[.under]] .three = true := by decide
def e552903546906 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552903546906 : Closed e552903546906 ∧ code e552903546906 = 9348996569114 := by decide
theorem cert_e552903546906 : check e552903546906 [[.under]] .three = true := by decide
def e552924321818 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552924321818 : Closed e552924321818 ∧ code e552924321818 = 9349017344026 := by decide
theorem cert_e552924321818 : check e552924321818 [[.under]] .three = true := by decide
def e552924452890 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552924452890 : Closed e552924452890 ∧ code e552924452890 = 9349017475098 := by decide
theorem cert_e552924452890 : check e552924452890 [[.under]] .three = true := by decide
def e552925370394 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552925370394 : Closed e552925370394 ∧ code e552925370394 = 9349018392602 := by decide
theorem cert_e552925370394 : check e552925370394 [[.under]] .three = true := by decide
def e552925567002 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552925567002 : Closed e552925567002 ∧ code e552925567002 = 9349018589210 := by decide
theorem cert_e552925567002 : check e552925567002 [[.under]] .three = true := by decide
def e552926025754 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552926025754 : Closed e552926025754 ∧ code e552926025754 = 9349019047962 := by decide
theorem cert_e552926025754 : check e552926025754 [[.under]] .three = true := by decide
def e552926091290 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552926091290 : Closed e552926091290 ∧ code e552926091290 = 9349019113498 := by decide
theorem cert_e552926091290 : check e552926091290 [[.under]] .three = true := by decide
def e552930613274 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552930613274 : Closed e552930613274 ∧ code e552930613274 = 9349023635482 := by decide
theorem cert_e552930613274 : check e552930613274 [[.under]] .three = true := by decide
def e552930744346 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552930744346 : Closed e552930744346 ∧ code e552930744346 = 9349023766554 := by decide
theorem cert_e552930744346 : check e552930744346 [[.under]] .three = true := by decide
def e552936904730 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552936904730 : Closed e552936904730 ∧ code e552936904730 = 9349029926938 := by decide
theorem cert_e552936904730 : check e552936904730 [[.under]] .three = true := by decide
def e552937101338 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552937101338 : Closed e552937101338 ∧ code e552937101338 = 9349030123546 := by decide
theorem cert_e552937101338 : check e552937101338 [[.under]] .three = true := by decide
def e552940181530 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552940181530 : Closed e552940181530 ∧ code e552940181530 = 9349033203738 := by decide
theorem cert_e552940181530 : check e552940181530 [[.under]] .three = true := by decide
def e552940247066 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552940247066 : Closed e552940247066 ∧ code e552940247066 = 9349033269274 := by decide
theorem cert_e552940247066 : check e552940247066 [[.under]] .three = true := by decide
def e553173882906 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553173882906 : Closed e553173882906 ∧ code e553173882906 = 9349266905114 := by decide
theorem cert_e553173882906 : check e553173882906 [[.under]] .three = true := by decide
def e553175980058 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553175980058 : Closed e553175980058 ∧ code e553175980058 = 9349269002266 := by decide
theorem cert_e553175980058 : check e553175980058 [[.under]] .three = true := by decide
def e553176111130 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553176111130 : Closed e553176111130 ∧ code e553176111130 = 9349269133338 := by decide
theorem cert_e553176111130 : check e553176111130 [[.under]] .three = true := by decide
def e553220020250 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553220020250 : Closed e553220020250 ∧ code e553220020250 = 9349313042458 := by decide
theorem cert_e553220020250 : check e553220020250 [[.under]] .three = true := by decide
def e553232603162 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553232603162 : Closed e553232603162 ∧ code e553232603162 = 9349325625370 := by decide
theorem cert_e553232603162 : check e553232603162 [[.under]] .three = true := by decide
def e553232734234 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553232734234 : Closed e553232734234 ∧ code e553232734234 = 9349325756442 := by decide
theorem cert_e553232734234 : check e553232734234 [[.under]] .three = true := by decide
def e553610090522 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553610090522 : Closed e553610090522 ∧ code e553610090522 = 9349703112730 := by decide
theorem cert_e553610090522 : check e553610090522 [[.under]] .three = true := by decide
def e553613236250 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553613236250 : Closed e553613236250 ∧ code e553613236250 = 9349706258458 := by decide
theorem cert_e553613236250 : check e553613236250 [[.under]] .three = true := by decide
def e553613432858 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553613432858 : Closed e553613432858 ∧ code e553613432858 = 9349706455066 := by decide
theorem cert_e553613432858 : check e553613432858 [[.under]] .three = true := by decide
def e553622673434 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553622673434 : Closed e553622673434 ∧ code e553622673434 = 9349715695642 := by decide
theorem cert_e553622673434 : check e553622673434 [[.under]] .three = true := by decide
def e553641547802 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553641547802 : Closed e553641547802 ∧ code e553641547802 = 9349734570010 := by decide
theorem cert_e553641547802 : check e553641547802 [[.under]] .three = true := by decide
def e553641744410 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553641744410 : Closed e553641744410 ∧ code e553641744410 = 9349734766618 := by decide
theorem cert_e553641744410 : check e553641744410 [[.under]] .three = true := by decide
def e553830291482 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553830291482 : Closed e553830291482 ∧ code e553830291482 = 9349923313690 := by decide
theorem cert_e553830291482 : check e553830291482 [[.under]] .three = true := by decide
def e553830422554 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553830422554 : Closed e553830422554 ∧ code e553830422554 = 9349923444762 := by decide
theorem cert_e553830422554 : check e553830422554 [[.under]] .three = true := by decide
def e553831340058 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553831340058 : Closed e553831340058 ∧ code e553831340058 = 9349924362266 := by decide
theorem cert_e553831340058 : check e553831340058 [[.under]] .three = true := by decide
def e553831536666 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553831536666 : Closed e553831536666 ∧ code e553831536666 = 9349924558874 := by decide
theorem cert_e553831536666 : check e553831536666 [[.under]] .three = true := by decide
def e553831995418 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553831995418 : Closed e553831995418 ∧ code e553831995418 = 9349925017626 := by decide
theorem cert_e553831995418 : check e553831995418 [[.under]] .three = true := by decide
def e553832060954 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553832060954 : Closed e553832060954 ∧ code e553832060954 = 9349925083162 := by decide
theorem cert_e553832060954 : check e553832060954 [[.under]] .three = true := by decide
def e553836582938 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553836582938 : Closed e553836582938 ∧ code e553836582938 = 9349929605146 := by decide
theorem cert_e553836582938 : check e553836582938 [[.under]] .three = true := by decide
def e553836714010 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553836714010 : Closed e553836714010 ∧ code e553836714010 = 9349929736218 := by decide
theorem cert_e553836714010 : check e553836714010 [[.under]] .three = true := by decide
def e553842874394 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553842874394 : Closed e553842874394 ∧ code e553842874394 = 9349935896602 := by decide
theorem cert_e553842874394 : check e553842874394 [[.under]] .three = true := by decide
def e553843071002 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553843071002 : Closed e553843071002 ∧ code e553843071002 = 9349936093210 := by decide
theorem cert_e553843071002 : check e553843071002 [[.under]] .three = true := by decide
def e553846151194 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553846151194 : Closed e553846151194 ∧ code e553846151194 = 9349939173402 := by decide
theorem cert_e553846151194 : check e553846151194 [[.under]] .three = true := by decide
def e553846216730 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553846216730 : Closed e553846216730 ∧ code e553846216730 = 9349939238938 := by decide
theorem cert_e553846216730 : check e553846216730 [[.under]] .three = true := by decide
def e564812178970 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812178970 : Closed e564812178970 ∧ code e564812178970 = 9360905201178 := by decide
theorem cert_e564812178970 : check e564812178970 [[.under]] .width = true := by decide
def e564812277274 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812277274 : Closed e564812277274 ∧ code e564812277274 = 9360905299482 := by decide
theorem cert_e564812277274 : check e564812277274 [[.under]] .width = true := by decide
def e564812703258 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812703258 : Closed e564812703258 ∧ code e564812703258 = 9360905725466 := by decide
theorem cert_e564812703258 : check e564812703258 [[.under]] .width = true := by decide
def e564812817946 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812817946 : Closed e564812817946 ∧ code e564812817946 = 9360905840154 := by decide
theorem cert_e564812817946 : check e564812817946 [[.under]] .width = true := by decide
def e564813194778 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564813194778 : Closed e564813194778 ∧ code e564813194778 = 9360906216986 := by decide
theorem cert_e564813194778 : check e564813194778 [[.under]] .width = true := by decide
def e564813211162 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564813211162 : Closed e564813211162 ∧ code e564813211162 = 9360906233370 := by decide
theorem cert_e564813211162 : check e564813211162 [[.under]] .width = true := by decide
def e564815324698 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564815324698 : Closed e564815324698 ∧ code e564815324698 = 9360908346906 := by decide
theorem cert_e564815324698 : check e564815324698 [[.under]] .width = true := by decide
def e564815423002 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564815423002 : Closed e564815423002 ∧ code e564815423002 = 9360908445210 := by decide
theorem cert_e564815423002 : check e564815423002 [[.under]] .width = true := by decide
def e564818470426 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564818470426 : Closed e564818470426 ∧ code e564818470426 = 9360911492634 := by decide
theorem cert_e564818470426 : check e564818470426 [[.under]] .width = true := by decide
def e564818585114 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564818585114 : Closed e564818585114 ∧ code e564818585114 = 9360911607322 := by decide
theorem cert_e564818585114 : check e564818585114 [[.under]] .width = true := by decide
def e564820928026 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564820928026 : Closed e564820928026 ∧ code e564820928026 = 9360913950234 := by decide
theorem cert_e564820928026 : check e564820928026 [[.under]] .width = true := by decide
def e564820944410 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564820944410 : Closed e564820944410 ∧ code e564820944410 = 9360913966618 := by decide
theorem cert_e564820944410 : check e564820944410 [[.under]] .width = true := by decide
def e564881450522 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564881450522 : Closed e564881450522 ∧ code e564881450522 = 9360974472730 := by decide
theorem cert_e564881450522 : check e564881450522 [[.under]] .width = true := by decide
def e564881483290 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564881483290 : Closed e564881483290 ∧ code e564881483290 = 9360974505498 := by decide
theorem cert_e564881483290 : check e564881483290 [[.under]] .width = true := by decide
def e564883744282 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564883744282 : Closed e564883744282 ∧ code e564883744282 = 9360976766490 := by decide
theorem cert_e564883744282 : check e564883744282 [[.under]] .width = true := by decide
def e564884082202 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564884082202 : Closed e564884082202 ∧ code e564884082202 = 9360977104410 := by decide
theorem cert_e564884082202 : check e564884082202 [[.under]] .width = true := by decide
def e564884091078 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564884091078 : Closed e564884091078 ∧ code e564884091078 = 9360977113286 := by decide
theorem cert_e564884091078 : check e564884091078 [[.under]] .width = true := by decide
def e564884203034 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564884203034 : Closed e564884203034 ∧ code e564884203034 = 9360977225242 := by decide
theorem cert_e564884203034 : check e564884203034 [[.under]] .width = true := by decide
def e564884344346 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564884344346 : Closed e564884344346 ∧ code e564884344346 = 9360977366554 := by decide
theorem cert_e564884344346 : check e564884344346 [[.under]] .width = true := by decide
def e564884353222 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564884353222 : Closed e564884353222 ∧ code e564884353222 = 9360977375430 := by decide
theorem cert_e564884353222 : check e564884353222 [[.under]] .width = true := by decide
def e564885120538 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564885120538 : Closed e564885120538 ∧ code e564885120538 = 9360978142746 := by decide
theorem cert_e564885120538 : check e564885120538 [[.under]] .width = true := by decide
def e564885169690 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564885169690 : Closed e564885169690 ∧ code e564885169690 = 9360978191898 := by decide
theorem cert_e564885169690 : check e564885169690 [[.under]] .width = true := by decide
def e564885841434 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564885841434 : Closed e564885841434 ∧ code e564885841434 = 9360978863642 := by decide
theorem cert_e564885841434 : check e564885841434 [[.under]] .width = true := by decide
def e564886179354 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564886179354 : Closed e564886179354 ∧ code e564886179354 = 9360979201562 := by decide
theorem cert_e564886179354 : check e564886179354 [[.under]] .width = true := by decide
def e564886188230 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564886188230 : Closed e564886188230 ∧ code e564886188230 = 9360979210438 := by decide
theorem cert_e564886188230 : check e564886188230 [[.under]] .width = true := by decide
def e564886529562 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564886529562 : Closed e564886529562 ∧ code e564886529562 = 9360979551770 := by decide
theorem cert_e564886529562 : check e564886529562 [[.under]] .width = true := by decide
def e564886572570 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564886572570 : Closed e564886572570 ∧ code e564886572570 = 9360979594778 := by decide
theorem cert_e564886572570 : check e564886572570 [[.under]] .width = true := by decide
def e564886581446 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564886581446 : Closed e564886581446 ∧ code e564886581446 = 9360979603654 := by decide
theorem cert_e564886581446 : check e564886581446 [[.under]] .width = true := by decide
def e564886988314 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564886988314 : Closed e564886988314 ∧ code e564886988314 = 9360980010522 := by decide
theorem cert_e564886988314 : check e564886988314 [[.under]] .width = true := by decide
def e564887004698 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564887004698 : Closed e564887004698 ∧ code e564887004698 = 9360980026906 := by decide
theorem cert_e564887004698 : check e564887004698 [[.under]] .width = true := by decide
def e564887348762 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564887348762 : Closed e564887348762 ∧ code e564887348762 = 9360980370970 := by decide
theorem cert_e564887348762 : check e564887348762 [[.under]] .width = true := by decide
def e564887490074 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564887490074 : Closed e564887490074 ∧ code e564887490074 = 9360980512282 := by decide
theorem cert_e564887490074 : check e564887490074 [[.under]] .width = true := by decide
def e564887498950 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564887498950 : Closed e564887498950 ∧ code e564887498950 = 9360980521158 := by decide
theorem cert_e564887498950 : check e564887498950 [[.under]] .width = true := by decide
def e564887578138 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564887578138 : Closed e564887578138 ∧ code e564887578138 = 9360980600346 := by decide
theorem cert_e564887578138 : check e564887578138 [[.under]] .width = true := by decide
def e564887621146 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564887621146 : Closed e564887621146 ∧ code e564887621146 = 9360980643354 := by decide
theorem cert_e564887621146 : check e564887621146 [[.under]] .width = true := by decide
def e564887630022 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564887630022 : Closed e564887630022 ∧ code e564887630022 = 9360980652230 := by decide
theorem cert_e564887630022 : check e564887630022 [[.under]] .width = true := by decide
def e564896327194 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564896327194 : Closed e564896327194 ∧ code e564896327194 = 9360989349402 := by decide
theorem cert_e564896327194 : check e564896327194 [[.under]] .width = true := by decide
def e564896665114 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564896665114 : Closed e564896665114 ∧ code e564896665114 = 9360989687322 := by decide
theorem cert_e564896665114 : check e564896665114 [[.under]] .width = true := by decide
def e564896673990 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564896673990 : Closed e564896673990 ∧ code e564896673990 = 9360989696198 := by decide
theorem cert_e564896673990 : check e564896673990 [[.under]] .width = true := by decide
def e564896785946 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564896785946 : Closed e564896785946 ∧ code e564896785946 = 9360989808154 := by decide
theorem cert_e564896785946 : check e564896785946 [[.under]] .width = true := by decide
def e564896927258 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564896927258 : Closed e564896927258 ∧ code e564896927258 = 9360989949466 := by decide
theorem cert_e564896927258 : check e564896927258 [[.under]] .width = true := by decide
def e564896936134 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564896936134 : Closed e564896936134 ∧ code e564896936134 = 9360989958342 := by decide
theorem cert_e564896936134 : check e564896936134 [[.under]] .width = true := by decide
def e564908910106 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564908910106 : Closed e564908910106 ∧ code e564908910106 = 9361001932314 := by decide
theorem cert_e564908910106 : check e564908910106 [[.under]] .width = true := by decide
def e564909248026 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564909248026 : Closed e564909248026 ∧ code e564909248026 = 9361002270234 := by decide
theorem cert_e564909248026 : check e564909248026 [[.under]] .width = true := by decide
def e564909256902 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564909256902 : Closed e564909256902 ∧ code e564909256902 = 9361002279110 := by decide
theorem cert_e564909256902 : check e564909256902 [[.under]] .width = true := by decide
def e564909598234 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564909598234 : Closed e564909598234 ∧ code e564909598234 = 9361002620442 := by decide
theorem cert_e564909598234 : check e564909598234 [[.under]] .width = true := by decide
def e564909641242 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564909641242 : Closed e564909641242 ∧ code e564909641242 = 9361002663450 := by decide
theorem cert_e564909641242 : check e564909641242 [[.under]] .width = true := by decide
def e564909650118 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564909650118 : Closed e564909650118 ∧ code e564909650118 = 9361002672326 := by decide
theorem cert_e564909650118 : check e564909650118 [[.under]] .width = true := by decide
def e564915660314 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564915660314 : Closed e564915660314 ∧ code e564915660314 = 9361008682522 := by decide
theorem cert_e564915660314 : check e564915660314 [[.under]] .width = true := by decide
def e564915801626 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564915801626 : Closed e564915801626 ∧ code e564915801626 = 9361008823834 := by decide
theorem cert_e564915801626 : check e564915801626 [[.under]] .width = true := by decide
def e564915810502 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564915810502 : Closed e564915810502 ∧ code e564915810502 = 9361008832710 := by decide
theorem cert_e564915810502 : check e564915810502 [[.under]] .width = true := by decide
def e564915889690 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564915889690 : Closed e564915889690 ∧ code e564915889690 = 9361008911898 := by decide
theorem cert_e564915889690 : check e564915889690 [[.under]] .width = true := by decide
def e564915932698 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e564915932698 : Closed e564915932698 ∧ code e564915932698 = 9361008954906 := by decide
theorem cert_e564915932698 : check e564915932698 [[.under]] .width = true := by decide
def e564915941574 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564915941574 : Closed e564915941574 ∧ code e564915941574 = 9361008963782 := by decide
theorem cert_e564915941574 : check e564915941574 [[.under]] .width = true := by decide
def e565643881838 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e565643881838 : Closed e565643881838 ∧ code e565643881838 = 9361736904046 := by decide
theorem cert_e565643881838 : checkPay e565643881838 [[.left],[.left],[]] 0 [] = true := by decide
def e565643881846 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e565643881846 : Closed e565643881846 ∧ code e565643881846 = 9361736904054 := by decide
theorem cert_e565643881846 : checkPay e565643881846 [[.left],[.left],[]] 0 [] = true := by decide
def e565643881902 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e565643881902 : Closed e565643881902 ∧ code e565643881902 = 9361736904110 := by decide
theorem cert_e565643881902 : checkPay e565643881902 [[.left],[.left],[]] 0 [] = true := by decide
def e565643881914 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e565643881914 : Closed e565643881914 ∧ code e565643881914 = 9361736904122 := by decide
theorem cert_e565643881914 : checkPay e565643881914 [[.left],[.left],[]] 0 [] = true := by decide
def e565643881942 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e565643881942 : Closed e565643881942 ∧ code e565643881942 = 9361736904150 := by decide
theorem cert_e565643881942 : checkPay e565643881942 [[.left],[.left],[]] 0 [] = true := by decide
def e565643881946 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e565643881946 : Closed e565643881946 ∧ code e565643881946 = 9361736904154 := by decide
theorem cert_e565643881946 : checkPay e565643881946 [[.left],[.left],[]] 0 [] = true := by decide
def e565643882158 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e565643882158 : Closed e565643882158 ∧ code e565643882158 = 9361736904366 := by decide
theorem cert_e565643882158 : checkPay e565643882158 [[.left],[.left],[]] 0 [] = true := by decide
def e565643882170 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e565643882170 : Closed e565643882170 ∧ code e565643882170 = 9361736904378 := by decide
theorem cert_e565643882170 : checkPay e565643882170 [[.left],[.left],[]] 0 [] = true := by decide
def e565643882218 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e565643882218 : Closed e565643882218 ∧ code e565643882218 = 9361736904426 := by decide
theorem cert_e565643882218 : checkPay e565643882218 [[.left],[.left],[]] 0 [] = true := by decide
def e565643882326 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e565643882326 : Closed e565643882326 ∧ code e565643882326 = 9361736904534 := by decide
theorem cert_e565643882326 : checkPay e565643882326 [[.left],[.left],[]] 0 [] = true := by decide
def e565643882330 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e565643882330 : Closed e565643882330 ∧ code e565643882330 = 9361736904538 := by decide
theorem cert_e565643882330 : checkPay e565643882330 [[.left],[.left],[]] 0 [] = true := by decide
def e565643882346 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e565643882346 : Closed e565643882346 ∧ code e565643882346 = 9361736904554 := by decide
theorem cert_e565643882346 : checkPay e565643882346 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883374 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e565643883374 : Closed e565643883374 ∧ code e565643883374 = 9361736905582 := by decide
theorem cert_e565643883374 : checkPay e565643883374 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883382 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e565643883382 : Closed e565643883382 ∧ code e565643883382 = 9361736905590 := by decide
theorem cert_e565643883382 : checkPay e565643883382 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883438 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e565643883438 : Closed e565643883438 ∧ code e565643883438 = 9361736905646 := by decide
theorem cert_e565643883438 : checkPay e565643883438 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883450 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e565643883450 : Closed e565643883450 ∧ code e565643883450 = 9361736905658 := by decide
theorem cert_e565643883450 : checkPay e565643883450 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883478 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e565643883478 : Closed e565643883478 ∧ code e565643883478 = 9361736905686 := by decide
theorem cert_e565643883478 : checkPay e565643883478 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883482 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e565643883482 : Closed e565643883482 ∧ code e565643883482 = 9361736905690 := by decide
theorem cert_e565643883482 : checkPay e565643883482 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883758 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e565643883758 : Closed e565643883758 ∧ code e565643883758 = 9361736905966 := by decide
theorem cert_e565643883758 : checkPay e565643883758 [[.left],[.left],[]] 0 [] = true := by decide
def e565643883766 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e565643883766 : Closed e565643883766 ∧ code e565643883766 = 9361736905974 := by decide
theorem cert_e565643883766 : checkPay e565643883766 [[.left],[.left],[]] 0 [] = true := by decide
def e565643884142 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e565643884142 : Closed e565643884142 ∧ code e565643884142 = 9361736906350 := by decide
theorem cert_e565643884142 : checkPay e565643884142 [[.left],[.left],[]] 0 [] = true := by decide
def e565643884154 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e565643884154 : Closed e565643884154 ∧ code e565643884154 = 9361736906362 := by decide
theorem cert_e565643884154 : checkPay e565643884154 [[.left],[.left],[]] 0 [] = true := by decide
def e565643884342 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e565643884342 : Closed e565643884342 ∧ code e565643884342 = 9361736906550 := by decide
theorem cert_e565643884342 : checkPay e565643884342 [[.left],[.left],[]] 0 [] = true := by decide
def e565643884346 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e565643884346 : Closed e565643884346 ∧ code e565643884346 = 9361736906554 := by decide
theorem cert_e565643884346 : checkPay e565643884346 [[.left],[.left],[]] 0 [] = true := by decide
def e565643884974 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e565643884974 : Closed e565643884974 ∧ code e565643884974 = 9361736907182 := by decide
theorem cert_e565643884974 : checkPay e565643884974 [[.left],[.left],[]] 0 [] = true := by decide
def e565643884986 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e565643884986 : Closed e565643884986 ∧ code e565643884986 = 9361736907194 := by decide
theorem cert_e565643884986 : checkPay e565643884986 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885034 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e565643885034 : Closed e565643885034 ∧ code e565643885034 = 9361736907242 := by decide
theorem cert_e565643885034 : checkPay e565643885034 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885166 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e565643885166 : Closed e565643885166 ∧ code e565643885166 = 9361736907374 := by decide
theorem cert_e565643885166 : checkPay e565643885166 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885178 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e565643885178 : Closed e565643885178 ∧ code e565643885178 = 9361736907386 := by decide
theorem cert_e565643885178 : checkPay e565643885178 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885466 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e565643885466 : Closed e565643885466 ∧ code e565643885466 = 9361736907674 := by decide
theorem cert_e565643885466 : checkPay e565643885466 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885782 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e565643885782 : Closed e565643885782 ∧ code e565643885782 = 9361736907990 := by decide
theorem cert_e565643885782 : checkPay e565643885782 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885786 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e565643885786 : Closed e565643885786 ∧ code e565643885786 = 9361736907994 := by decide
theorem cert_e565643885786 : checkPay e565643885786 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885802 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e565643885802 : Closed e565643885802 ∧ code e565643885802 = 9361736908010 := by decide
theorem cert_e565643885802 : checkPay e565643885802 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885878 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e565643885878 : Closed e565643885878 ∧ code e565643885878 = 9361736908086 := by decide
theorem cert_e565643885878 : checkPay e565643885878 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885882 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e565643885882 : Closed e565643885882 ∧ code e565643885882 = 9361736908090 := by decide
theorem cert_e565643885882 : checkPay e565643885882 [[.left],[.left],[]] 0 [] = true := by decide
def e565643885978 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e565643885978 : Closed e565643885978 ∧ code e565643885978 = 9361736908186 := by decide
theorem cert_e565643885978 : checkPay e565643885978 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889518 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e565643889518 : Closed e565643889518 ∧ code e565643889518 = 9361736911726 := by decide
theorem cert_e565643889518 : checkPay e565643889518 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889526 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e565643889526 : Closed e565643889526 ∧ code e565643889526 = 9361736911734 := by decide
theorem cert_e565643889526 : checkPay e565643889526 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889582 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e565643889582 : Closed e565643889582 ∧ code e565643889582 = 9361736911790 := by decide
theorem cert_e565643889582 : checkPay e565643889582 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889594 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e565643889594 : Closed e565643889594 ∧ code e565643889594 = 9361736911802 := by decide
theorem cert_e565643889594 : checkPay e565643889594 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889622 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e565643889622 : Closed e565643889622 ∧ code e565643889622 = 9361736911830 := by decide
theorem cert_e565643889622 : checkPay e565643889622 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889626 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e565643889626 : Closed e565643889626 ∧ code e565643889626 = 9361736911834 := by decide
theorem cert_e565643889626 : checkPay e565643889626 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889902 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e565643889902 : Closed e565643889902 ∧ code e565643889902 = 9361736912110 := by decide
theorem cert_e565643889902 : checkPay e565643889902 [[.left],[.left],[]] 0 [] = true := by decide
def e565643889910 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e565643889910 : Closed e565643889910 ∧ code e565643889910 = 9361736912118 := by decide
theorem cert_e565643889910 : checkPay e565643889910 [[.left],[.left],[]] 0 [] = true := by decide
def e565643890286 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e565643890286 : Closed e565643890286 ∧ code e565643890286 = 9361736912494 := by decide
theorem cert_e565643890286 : checkPay e565643890286 [[.left],[.left],[]] 0 [] = true := by decide
def e565643890298 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e565643890298 : Closed e565643890298 ∧ code e565643890298 = 9361736912506 := by decide
theorem cert_e565643890298 : checkPay e565643890298 [[.left],[.left],[]] 0 [] = true := by decide
end Blc.Floor43
