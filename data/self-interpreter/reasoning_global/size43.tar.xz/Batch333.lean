import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418335278554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2418335278554 : Closed e2418335278554 ∧ code e2418335278554 = 11214428300762 := by decide
theorem cert_e2418335278554 : check e2418335278554 [[],[]] .three = true := by decide
def e2418335278570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2418335278570 : Closed e2418335278570 ∧ code e2418335278570 = 11214428300778 := by decide
theorem cert_e2418335278570 : check e2418335278570 [[],[]] .three = true := by decide
def e2418335278702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335278702 : Closed e2418335278702 ∧ code e2418335278702 = 11214428300910 := by decide
theorem cert_e2418335278702 : check e2418335278702 [[],[]] .three = true := by decide
def e2418335278710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2418335278710 : Closed e2418335278710 ∧ code e2418335278710 = 11214428300918 := by decide
theorem cert_e2418335278710 : check e2418335278710 [[],[]] .three = true := by decide
def e2418335278714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335278714 : Closed e2418335278714 ∧ code e2418335278714 = 11214428300922 := by decide
theorem cert_e2418335278714 : check e2418335278714 [[],[]] .three = true := by decide
def e2418335278902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418335278902 : Closed e2418335278902 ∧ code e2418335278902 = 11214428301110 := by decide
theorem cert_e2418335278902 : check e2418335278902 [[],[]] .three = true := by decide
def e2418335278906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418335278906 : Closed e2418335278906 ∧ code e2418335278906 = 11214428301114 := by decide
theorem cert_e2418335278906 : check e2418335278906 [[],[]] .three = true := by decide
def e2418335279002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335279002 : Closed e2418335279002 ∧ code e2418335279002 = 11214428301210 := by decide
theorem cert_e2418335279002 : check e2418335279002 [[],[]] .three = true := by decide
def e2418335724910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418335724910 : Closed e2418335724910 ∧ code e2418335724910 = 11214428747118 := by decide
theorem cert_e2418335724910 : check e2418335724910 [[],[]] .chain = true := by decide
def e2418335724918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418335724918 : Closed e2418335724918 ∧ code e2418335724918 = 11214428747126 := by decide
theorem cert_e2418335724918 : check e2418335724918 [[],[]] .chain = true := by decide
def e2418335724974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418335724974 : Closed e2418335724974 ∧ code e2418335724974 = 11214428747182 := by decide
theorem cert_e2418335724974 : check e2418335724974 [[],[]] .chain = true := by decide
def e2418335724986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418335724986 : Closed e2418335724986 ∧ code e2418335724986 = 11214428747194 := by decide
theorem cert_e2418335724986 : check e2418335724986 [[],[]] .chain = true := by decide
def e2418335725014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418335725014 : Closed e2418335725014 ∧ code e2418335725014 = 11214428747222 := by decide
theorem cert_e2418335725014 : check e2418335725014 [[],[]] .chain = true := by decide
def e2418335725018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418335725018 : Closed e2418335725018 ∧ code e2418335725018 = 11214428747226 := by decide
theorem cert_e2418335725018 : check e2418335725018 [[],[]] .chain = true := by decide
def e2418335725230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2418335725230 : Closed e2418335725230 ∧ code e2418335725230 = 11214428747438 := by decide
theorem cert_e2418335725230 : check e2418335725230 [[],[]] .chain = true := by decide
def e2418335725242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2418335725242 : Closed e2418335725242 ∧ code e2418335725242 = 11214428747450 := by decide
theorem cert_e2418335725242 : check e2418335725242 [[],[]] .chain = true := by decide
def e2418335725290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2418335725290 : Closed e2418335725290 ∧ code e2418335725290 = 11214428747498 := by decide
theorem cert_e2418335725290 : check e2418335725290 [[],[]] .chain = true := by decide
def e2418335725398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2418335725398 : Closed e2418335725398 ∧ code e2418335725398 = 11214428747606 := by decide
theorem cert_e2418335725398 : check e2418335725398 [[],[]] .chain = true := by decide
def e2418335725402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2418335725402 : Closed e2418335725402 ∧ code e2418335725402 = 11214428747610 := by decide
theorem cert_e2418335725402 : check e2418335725402 [[],[]] .chain = true := by decide
def e2418335725418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2418335725418 : Closed e2418335725418 ∧ code e2418335725418 = 11214428747626 := by decide
theorem cert_e2418335725418 : check e2418335725418 [[],[]] .chain = true := by decide
def e2418335726254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2418335726254 : Closed e2418335726254 ∧ code e2418335726254 = 11214428748462 := by decide
theorem cert_e2418335726254 : check e2418335726254 [[],[]] .chain = true := by decide
def e2418335726266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2418335726266 : Closed e2418335726266 ∧ code e2418335726266 = 11214428748474 := by decide
theorem cert_e2418335726266 : check e2418335726266 [[],[]] .chain = true := by decide
def e2418335726314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2418335726314 : Closed e2418335726314 ∧ code e2418335726314 = 11214428748522 := by decide
theorem cert_e2418335726314 : check e2418335726314 [[],[]] .chain = true := by decide
def e2418335726506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2418335726506 : Closed e2418335726506 ∧ code e2418335726506 = 11214428748714 := by decide
theorem cert_e2418335726506 : check e2418335726506 [[],[]] .chain = true := by decide
def e2418335726934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2418335726934 : Closed e2418335726934 ∧ code e2418335726934 = 11214428749142 := by decide
theorem cert_e2418335726934 : check e2418335726934 [[],[]] .chain = true := by decide
def e2418335726938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2418335726938 : Closed e2418335726938 ∧ code e2418335726938 = 11214428749146 := by decide
theorem cert_e2418335726938 : check e2418335726938 [[],[]] .chain = true := by decide
def e2418335726954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2418335726954 : Closed e2418335726954 ∧ code e2418335726954 = 11214428749162 := by decide
theorem cert_e2418335726954 : check e2418335726954 [[],[]] .chain = true := by decide
def e2418335727018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2418335727018 : Closed e2418335727018 ∧ code e2418335727018 = 11214428749226 := by decide
theorem cert_e2418335727018 : check e2418335727018 [[],[]] .chain = true := by decide
def e2418335729518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2418335729518 : Closed e2418335729518 ∧ code e2418335729518 = 11214428751726 := by decide
theorem cert_e2418335729518 : check e2418335729518 [[],[]] .chain = true := by decide
def e2418335729526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2418335729526 : Closed e2418335729526 ∧ code e2418335729526 = 11214428751734 := by decide
theorem cert_e2418335729526 : check e2418335729526 [[],[]] .chain = true := by decide
def e2418335729590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e2418335729590 : Closed e2418335729590 ∧ code e2418335729590 = 11214428751798 := by decide
theorem cert_e2418335729590 : check e2418335729590 [[],[]] .chain = true := by decide
def e2418335731054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2418335731054 : Closed e2418335731054 ∧ code e2418335731054 = 11214428753262 := by decide
theorem cert_e2418335731054 : check e2418335731054 [[],[]] .chain = true := by decide
def e2418335731062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2418335731062 : Closed e2418335731062 ∧ code e2418335731062 = 11214428753270 := by decide
theorem cert_e2418335731062 : check e2418335731062 [[],[]] .chain = true := by decide
def e2418335731118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2418335731118 : Closed e2418335731118 ∧ code e2418335731118 = 11214428753326 := by decide
theorem cert_e2418335731118 : check e2418335731118 [[],[]] .chain = true := by decide
def e2418335731130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2418335731130 : Closed e2418335731130 ∧ code e2418335731130 = 11214428753338 := by decide
theorem cert_e2418335731130 : check e2418335731130 [[],[]] .chain = true := by decide
def e2418335731158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2418335731158 : Closed e2418335731158 ∧ code e2418335731158 = 11214428753366 := by decide
theorem cert_e2418335731158 : check e2418335731158 [[],[]] .chain = true := by decide
def e2418335731162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2418335731162 : Closed e2418335731162 ∧ code e2418335731162 = 11214428753370 := by decide
theorem cert_e2418335731162 : check e2418335731162 [[],[]] .chain = true := by decide
def e2418335731374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2418335731374 : Closed e2418335731374 ∧ code e2418335731374 = 11214428753582 := by decide
theorem cert_e2418335731374 : check e2418335731374 [[],[]] .chain = true := by decide
def e2418335731386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2418335731386 : Closed e2418335731386 ∧ code e2418335731386 = 11214428753594 := by decide
theorem cert_e2418335731386 : check e2418335731386 [[],[]] .chain = true := by decide
def e2418335731434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2418335731434 : Closed e2418335731434 ∧ code e2418335731434 = 11214428753642 := by decide
theorem cert_e2418335731434 : check e2418335731434 [[],[]] .chain = true := by decide
def e2418335731542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2418335731542 : Closed e2418335731542 ∧ code e2418335731542 = 11214428753750 := by decide
theorem cert_e2418335731542 : check e2418335731542 [[],[]] .chain = true := by decide
def e2418335731546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2418335731546 : Closed e2418335731546 ∧ code e2418335731546 = 11214428753754 := by decide
theorem cert_e2418335731546 : check e2418335731546 [[],[]] .chain = true := by decide
def e2418335731562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2418335731562 : Closed e2418335731562 ∧ code e2418335731562 = 11214428753770 := by decide
theorem cert_e2418335731562 : check e2418335731562 [[],[]] .chain = true := by decide
def e2418335732590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418335732590 : Closed e2418335732590 ∧ code e2418335732590 = 11214428754798 := by decide
theorem cert_e2418335732590 : check e2418335732590 [[],[]] .chain = true := by decide
def e2418335732598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418335732598 : Closed e2418335732598 ∧ code e2418335732598 = 11214428754806 := by decide
theorem cert_e2418335732598 : check e2418335732598 [[],[]] .chain = true := by decide
def e2418335732654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418335732654 : Closed e2418335732654 ∧ code e2418335732654 = 11214428754862 := by decide
theorem cert_e2418335732654 : check e2418335732654 [[],[]] .chain = true := by decide
def e2418335732666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418335732666 : Closed e2418335732666 ∧ code e2418335732666 = 11214428754874 := by decide
theorem cert_e2418335732666 : check e2418335732666 [[],[]] .chain = true := by decide
def e2418335732694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418335732694 : Closed e2418335732694 ∧ code e2418335732694 = 11214428754902 := by decide
theorem cert_e2418335732694 : check e2418335732694 [[],[]] .chain = true := by decide
def e2418335732698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418335732698 : Closed e2418335732698 ∧ code e2418335732698 = 11214428754906 := by decide
theorem cert_e2418335732698 : check e2418335732698 [[],[]] .chain = true := by decide
def e2418335732974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418335732974 : Closed e2418335732974 ∧ code e2418335732974 = 11214428755182 := by decide
theorem cert_e2418335732974 : check e2418335732974 [[],[]] .chain = true := by decide
def e2418335732982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418335732982 : Closed e2418335732982 ∧ code e2418335732982 = 11214428755190 := by decide
theorem cert_e2418335732982 : check e2418335732982 [[],[]] .chain = true := by decide
def e2418335733358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418335733358 : Closed e2418335733358 ∧ code e2418335733358 = 11214428755566 := by decide
theorem cert_e2418335733358 : check e2418335733358 [[],[]] .chain = true := by decide
def e2418335733370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418335733370 : Closed e2418335733370 ∧ code e2418335733370 = 11214428755578 := by decide
theorem cert_e2418335733370 : check e2418335733370 [[],[]] .chain = true := by decide
def e2418335733558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335733558 : Closed e2418335733558 ∧ code e2418335733558 = 11214428755766 := by decide
theorem cert_e2418335733558 : check e2418335733558 [[],[]] .chain = true := by decide
def e2418335733562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335733562 : Closed e2418335733562 ∧ code e2418335733562 = 11214428755770 := by decide
theorem cert_e2418335733562 : check e2418335733562 [[],[]] .chain = true := by decide
def e2418335733998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2418335733998 : Closed e2418335733998 ∧ code e2418335733998 = 11214428756206 := by decide
theorem cert_e2418335733998 : check e2418335733998 [[],[]] .chain = true := by decide
def e2418335734006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2418335734006 : Closed e2418335734006 ∧ code e2418335734006 = 11214428756214 := by decide
theorem cert_e2418335734006 : check e2418335734006 [[],[]] .chain = true := by decide
def e2418335734190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2418335734190 : Closed e2418335734190 ∧ code e2418335734190 = 11214428756398 := by decide
theorem cert_e2418335734190 : check e2418335734190 [[],[]] .chain = true := by decide
def e2418335734202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2418335734202 : Closed e2418335734202 ∧ code e2418335734202 = 11214428756410 := by decide
theorem cert_e2418335734202 : check e2418335734202 [[],[]] .chain = true := by decide
def e2418335734250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2418335734250 : Closed e2418335734250 ∧ code e2418335734250 = 11214428756458 := by decide
theorem cert_e2418335734250 : check e2418335734250 [[],[]] .chain = true := by decide
def e2418335734382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418335734382 : Closed e2418335734382 ∧ code e2418335734382 = 11214428756590 := by decide
theorem cert_e2418335734382 : check e2418335734382 [[],[]] .chain = true := by decide
def e2418335734394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418335734394 : Closed e2418335734394 ∧ code e2418335734394 = 11214428756602 := by decide
theorem cert_e2418335734394 : check e2418335734394 [[],[]] .chain = true := by decide
def e2418335734558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2418335734558 : Closed e2418335734558 ∧ code e2418335734558 = 11214428756766 := by decide
theorem cert_e2418335734558 : check e2418335734558 [[],[]] .chain = true := by decide
def e2418335734670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2418335734670 : Closed e2418335734670 ∧ code e2418335734670 = 11214428756878 := by decide
theorem cert_e2418335734670 : check e2418335734670 [[],[]] .chain = true := by decide
def e2418335734682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335734682 : Closed e2418335734682 ∧ code e2418335734682 = 11214428756890 := by decide
theorem cert_e2418335734682 : check e2418335734682 [[],[]] .chain = true := by decide
def e2418335734902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2418335734902 : Closed e2418335734902 ∧ code e2418335734902 = 11214428757110 := by decide
theorem cert_e2418335734902 : check e2418335734902 [[],[]] .chain = true := by decide
def e2418335734998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2418335734998 : Closed e2418335734998 ∧ code e2418335734998 = 11214428757206 := by decide
theorem cert_e2418335734998 : check e2418335734998 [[],[]] .chain = true := by decide
def e2418335735002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2418335735002 : Closed e2418335735002 ∧ code e2418335735002 = 11214428757210 := by decide
theorem cert_e2418335735002 : check e2418335735002 [[],[]] .chain = true := by decide
def e2418335735018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2418335735018 : Closed e2418335735018 ∧ code e2418335735018 = 11214428757226 := by decide
theorem cert_e2418335735018 : check e2418335735018 [[],[]] .chain = true := by decide
def e2418335735094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335735094 : Closed e2418335735094 ∧ code e2418335735094 = 11214428757302 := by decide
theorem cert_e2418335735094 : check e2418335735094 [[],[]] .chain = true := by decide
def e2418335735098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335735098 : Closed e2418335735098 ∧ code e2418335735098 = 11214428757306 := by decide
theorem cert_e2418335735098 : check e2418335735098 [[],[]] .chain = true := by decide
def e2418335735182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2418335735182 : Closed e2418335735182 ∧ code e2418335735182 = 11214428757390 := by decide
theorem cert_e2418335735182 : check e2418335735182 [[],[]] .chain = true := by decide
def e2418335735194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335735194 : Closed e2418335735194 ∧ code e2418335735194 = 11214428757402 := by decide
theorem cert_e2418335735194 : check e2418335735194 [[],[]] .chain = true := by decide
def e2418335736686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2418335736686 : Closed e2418335736686 ∧ code e2418335736686 = 11214428758894 := by decide
theorem cert_e2418335736686 : check e2418335736686 [[],[]] .chain = true := by decide
def e2418335736694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2418335736694 : Closed e2418335736694 ∧ code e2418335736694 = 11214428758902 := by decide
theorem cert_e2418335736694 : check e2418335736694 [[],[]] .chain = true := by decide
def e2418335736750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2418335736750 : Closed e2418335736750 ∧ code e2418335736750 = 11214428758958 := by decide
theorem cert_e2418335736750 : check e2418335736750 [[],[]] .chain = true := by decide
def e2418335736762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2418335736762 : Closed e2418335736762 ∧ code e2418335736762 = 11214428758970 := by decide
theorem cert_e2418335736762 : check e2418335736762 [[],[]] .chain = true := by decide
def e2418335736790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2418335736790 : Closed e2418335736790 ∧ code e2418335736790 = 11214428758998 := by decide
theorem cert_e2418335736790 : check e2418335736790 [[],[]] .chain = true := by decide
def e2418335736794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2418335736794 : Closed e2418335736794 ∧ code e2418335736794 = 11214428759002 := by decide
theorem cert_e2418335736794 : check e2418335736794 [[],[]] .chain = true := by decide
def e2418335737518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2418335737518 : Closed e2418335737518 ∧ code e2418335737518 = 11214428759726 := by decide
theorem cert_e2418335737518 : check e2418335737518 [[],[]] .chain = true := by decide
def e2418335737530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2418335737530 : Closed e2418335737530 ∧ code e2418335737530 = 11214428759738 := by decide
theorem cert_e2418335737530 : check e2418335737530 [[],[]] .chain = true := by decide
def e2418335737578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2418335737578 : Closed e2418335737578 ∧ code e2418335737578 = 11214428759786 := by decide
theorem cert_e2418335737578 : check e2418335737578 [[],[]] .chain = true := by decide
def e2418335737770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2418335737770 : Closed e2418335737770 ∧ code e2418335737770 = 11214428759978 := by decide
theorem cert_e2418335737770 : check e2418335737770 [[],[]] .chain = true := by decide
def e2418335738094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2418335738094 : Closed e2418335738094 ∧ code e2418335738094 = 11214428760302 := by decide
theorem cert_e2418335738094 : check e2418335738094 [[],[]] .chain = true := by decide
def e2418335738102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2418335738102 : Closed e2418335738102 ∧ code e2418335738102 = 11214428760310 := by decide
theorem cert_e2418335738102 : check e2418335738102 [[],[]] .chain = true := by decide
def e2418335738286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2418335738286 : Closed e2418335738286 ∧ code e2418335738286 = 11214428760494 := by decide
theorem cert_e2418335738286 : check e2418335738286 [[],[]] .chain = true := by decide
def e2418335738298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2418335738298 : Closed e2418335738298 ∧ code e2418335738298 = 11214428760506 := by decide
theorem cert_e2418335738298 : check e2418335738298 [[],[]] .chain = true := by decide
def e2418335738346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2418335738346 : Closed e2418335738346 ∧ code e2418335738346 = 11214428760554 := by decide
theorem cert_e2418335738346 : check e2418335738346 [[],[]] .chain = true := by decide
def e2418335738478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418335738478 : Closed e2418335738478 ∧ code e2418335738478 = 11214428760686 := by decide
theorem cert_e2418335738478 : check e2418335738478 [[],[]] .chain = true := by decide
def e2418335738490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418335738490 : Closed e2418335738490 ∧ code e2418335738490 = 11214428760698 := by decide
theorem cert_e2418335738490 : check e2418335738490 [[],[]] .chain = true := by decide
def e2418335738654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2418335738654 : Closed e2418335738654 ∧ code e2418335738654 = 11214428760862 := by decide
theorem cert_e2418335738654 : check e2418335738654 [[],[]] .chain = true := by decide
def e2418335738766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2418335738766 : Closed e2418335738766 ∧ code e2418335738766 = 11214428760974 := by decide
theorem cert_e2418335738766 : check e2418335738766 [[],[]] .chain = true := by decide
def e2418335738778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335738778 : Closed e2418335738778 ∧ code e2418335738778 = 11214428760986 := by decide
theorem cert_e2418335738778 : check e2418335738778 [[],[]] .chain = true := by decide
def e2418335738990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2418335738990 : Closed e2418335738990 ∧ code e2418335738990 = 11214428761198 := by decide
theorem cert_e2418335738990 : check e2418335738990 [[],[]] .chain = true := by decide
def e2418335739002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2418335739002 : Closed e2418335739002 ∧ code e2418335739002 = 11214428761210 := by decide
theorem cert_e2418335739002 : check e2418335739002 [[],[]] .chain = true := by decide
def e2418335739166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2418335739166 : Closed e2418335739166 ∧ code e2418335739166 = 11214428761374 := by decide
theorem cert_e2418335739166 : check e2418335739166 [[],[]] .chain = true := by decide
def e2418335739334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2418335739334 : Closed e2418335739334 ∧ code e2418335739334 = 11214428761542 := by decide
theorem cert_e2418335739334 : check e2418335739334 [[],[]] .chain = true := by decide
def e2418335739446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2418335739446 : Closed e2418335739446 ∧ code e2418335739446 = 11214428761654 := by decide
theorem cert_e2418335739446 : check e2418335739446 [[],[]] .chain = true := by decide
def e2418335739450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2418335739450 : Closed e2418335739450 ∧ code e2418335739450 = 11214428761658 := by decide
theorem cert_e2418335739450 : check e2418335739450 [[],[]] .chain = true := by decide
def e2418335739498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2418335739498 : Closed e2418335739498 ∧ code e2418335739498 = 11214428761706 := by decide
theorem cert_e2418335739498 : check e2418335739498 [[],[]] .chain = true := by decide
def e2418335739534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2418335739534 : Closed e2418335739534 ∧ code e2418335739534 = 11214428761742 := by decide
theorem cert_e2418335739534 : check e2418335739534 [[],[]] .chain = true := by decide
def e2418335739546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335739546 : Closed e2418335739546 ∧ code e2418335739546 = 11214428761754 := by decide
theorem cert_e2418335739546 : check e2418335739546 [[],[]] .chain = true := by decide
def e2418335739590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2418335739590 : Closed e2418335739590 ∧ code e2418335739590 = 11214428761798 := by decide
theorem cert_e2418335739590 : check e2418335739590 [[],[]] .chain = true := by decide
def e2418335740342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2418335740342 : Closed e2418335740342 ∧ code e2418335740342 = 11214428762550 := by decide
theorem cert_e2418335740342 : check e2418335740342 [[],[]] .chain = true := by decide
def e2418335740374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2418335740374 : Closed e2418335740374 ∧ code e2418335740374 = 11214428762582 := by decide
theorem cert_e2418335740374 : check e2418335740374 [[],[]] .chain = true := by decide
def e2418335740378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2418335740378 : Closed e2418335740378 ∧ code e2418335740378 = 11214428762586 := by decide
theorem cert_e2418335740378 : check e2418335740378 [[],[]] .chain = true := by decide
def e2418335740758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2418335740758 : Closed e2418335740758 ∧ code e2418335740758 = 11214428762966 := by decide
theorem cert_e2418335740758 : check e2418335740758 [[],[]] .chain = true := by decide
def e2418335740762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2418335740762 : Closed e2418335740762 ∧ code e2418335740762 = 11214428762970 := by decide
theorem cert_e2418335740762 : check e2418335740762 [[],[]] .chain = true := by decide
def e2418335740778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2418335740778 : Closed e2418335740778 ∧ code e2418335740778 = 11214428762986 := by decide
theorem cert_e2418335740778 : check e2418335740778 [[],[]] .chain = true := by decide
def e2418335740842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2418335740842 : Closed e2418335740842 ∧ code e2418335740842 = 11214428763050 := by decide
theorem cert_e2418335740842 : check e2418335740842 [[],[]] .chain = true := by decide
def e2418335741046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2418335741046 : Closed e2418335741046 ∧ code e2418335741046 = 11214428763254 := by decide
theorem cert_e2418335741046 : check e2418335741046 [[],[]] .chain = true := by decide
def e2418335741142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2418335741142 : Closed e2418335741142 ∧ code e2418335741142 = 11214428763350 := by decide
theorem cert_e2418335741142 : check e2418335741142 [[],[]] .chain = true := by decide
def e2418335741146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2418335741146 : Closed e2418335741146 ∧ code e2418335741146 = 11214428763354 := by decide
theorem cert_e2418335741146 : check e2418335741146 [[],[]] .chain = true := by decide
def e2418335741162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2418335741162 : Closed e2418335741162 ∧ code e2418335741162 = 11214428763370 := by decide
theorem cert_e2418335741162 : check e2418335741162 [[],[]] .chain = true := by decide
def e2418335741238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335741238 : Closed e2418335741238 ∧ code e2418335741238 = 11214428763446 := by decide
theorem cert_e2418335741238 : check e2418335741238 [[],[]] .chain = true := by decide
def e2418335741242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335741242 : Closed e2418335741242 ∧ code e2418335741242 = 11214428763450 := by decide
theorem cert_e2418335741242 : check e2418335741242 [[],[]] .chain = true := by decide
def e2418335741326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2418335741326 : Closed e2418335741326 ∧ code e2418335741326 = 11214428763534 := by decide
theorem cert_e2418335741326 : check e2418335741326 [[],[]] .chain = true := by decide
def e2418335741338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335741338 : Closed e2418335741338 ∧ code e2418335741338 = 11214428763546 := by decide
theorem cert_e2418335741338 : check e2418335741338 [[],[]] .chain = true := by decide
def e2418335741494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2418335741494 : Closed e2418335741494 ∧ code e2418335741494 = 11214428763702 := by decide
theorem cert_e2418335741494 : check e2418335741494 [[],[]] .chain = true := by decide
def e2418335741498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2418335741498 : Closed e2418335741498 ∧ code e2418335741498 = 11214428763706 := by decide
theorem cert_e2418335741498 : check e2418335741498 [[],[]] .chain = true := by decide
def e2418335741546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2418335741546 : Closed e2418335741546 ∧ code e2418335741546 = 11214428763754 := by decide
theorem cert_e2418335741546 : check e2418335741546 [[],[]] .chain = true := by decide
def e2418335741582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2418335741582 : Closed e2418335741582 ∧ code e2418335741582 = 11214428763790 := by decide
theorem cert_e2418335741582 : check e2418335741582 [[],[]] .chain = true := by decide
def e2418335741594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335741594 : Closed e2418335741594 ∧ code e2418335741594 = 11214428763802 := by decide
theorem cert_e2418335741594 : check e2418335741594 [[],[]] .chain = true := by decide
def e2418335741638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2418335741638 : Closed e2418335741638 ∧ code e2418335741638 = 11214428763846 := by decide
theorem cert_e2418335741638 : check e2418335741638 [[],[]] .chain = true := by decide
def e2418335747822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2418335747822 : Closed e2418335747822 ∧ code e2418335747822 = 11214428770030 := by decide
theorem cert_e2418335747822 : check e2418335747822 [[],[]] .chain = true := by decide
def e2418335747830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2418335747830 : Closed e2418335747830 ∧ code e2418335747830 = 11214428770038 := by decide
theorem cert_e2418335747830 : check e2418335747830 [[],[]] .chain = true := by decide
def e2418335747950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2418335747950 : Closed e2418335747950 ∧ code e2418335747950 = 11214428770158 := by decide
theorem cert_e2418335747950 : check e2418335747950 [[],[]] .chain = true := by decide
def e2418335747962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2418335747962 : Closed e2418335747962 ∧ code e2418335747962 = 11214428770170 := by decide
theorem cert_e2418335747962 : check e2418335747962 [[],[]] .chain = true := by decide
def e2418335748022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2418335748022 : Closed e2418335748022 ∧ code e2418335748022 = 11214428770230 := by decide
theorem cert_e2418335748022 : check e2418335748022 [[],[]] .chain = true := by decide
def e2418335748026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2418335748026 : Closed e2418335748026 ∧ code e2418335748026 = 11214428770234 := by decide
theorem cert_e2418335748026 : check e2418335748026 [[],[]] .chain = true := by decide
def e2418335751406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2418335751406 : Closed e2418335751406 ∧ code e2418335751406 = 11214428773614 := by decide
theorem cert_e2418335751406 : check e2418335751406 [[],[]] .chain = true := by decide
def e2418335751414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2418335751414 : Closed e2418335751414 ∧ code e2418335751414 = 11214428773622 := by decide
theorem cert_e2418335751414 : check e2418335751414 [[],[]] .chain = true := by decide
def e2418335751798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e2418335751798 : Closed e2418335751798 ∧ code e2418335751798 = 11214428774006 := by decide
theorem cert_e2418335751798 : check e2418335751798 [[],[]] .chain = true := by decide
def e2418335755630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2418335755630 : Closed e2418335755630 ∧ code e2418335755630 = 11214428777838 := by decide
theorem cert_e2418335755630 : check e2418335755630 [[],[]] .chain = true := by decide
def e2418335755638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2418335755638 : Closed e2418335755638 ∧ code e2418335755638 = 11214428777846 := by decide
theorem cert_e2418335755638 : check e2418335755638 [[],[]] .chain = true := by decide
def e2418335755694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2418335755694 : Closed e2418335755694 ∧ code e2418335755694 = 11214428777902 := by decide
theorem cert_e2418335755694 : check e2418335755694 [[],[]] .chain = true := by decide
def e2418335755706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2418335755706 : Closed e2418335755706 ∧ code e2418335755706 = 11214428777914 := by decide
theorem cert_e2418335755706 : check e2418335755706 [[],[]] .chain = true := by decide
def e2418335755734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2418335755734 : Closed e2418335755734 ∧ code e2418335755734 = 11214428777942 := by decide
theorem cert_e2418335755734 : check e2418335755734 [[],[]] .chain = true := by decide
def e2418335755738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2418335755738 : Closed e2418335755738 ∧ code e2418335755738 = 11214428777946 := by decide
theorem cert_e2418335755738 : check e2418335755738 [[],[]] .chain = true := by decide
def e2418335755950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2418335755950 : Closed e2418335755950 ∧ code e2418335755950 = 11214428778158 := by decide
theorem cert_e2418335755950 : check e2418335755950 [[],[]] .chain = true := by decide
def e2418335755962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2418335755962 : Closed e2418335755962 ∧ code e2418335755962 = 11214428778170 := by decide
theorem cert_e2418335755962 : check e2418335755962 [[],[]] .chain = true := by decide
def e2418335756010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2418335756010 : Closed e2418335756010 ∧ code e2418335756010 = 11214428778218 := by decide
theorem cert_e2418335756010 : check e2418335756010 [[],[]] .chain = true := by decide
def e2418335756118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2418335756118 : Closed e2418335756118 ∧ code e2418335756118 = 11214428778326 := by decide
theorem cert_e2418335756118 : check e2418335756118 [[],[]] .chain = true := by decide
def e2418335756122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2418335756122 : Closed e2418335756122 ∧ code e2418335756122 = 11214428778330 := by decide
theorem cert_e2418335756122 : check e2418335756122 [[],[]] .chain = true := by decide
def e2418335756138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2418335756138 : Closed e2418335756138 ∧ code e2418335756138 = 11214428778346 := by decide
theorem cert_e2418335756138 : check e2418335756138 [[],[]] .chain = true := by decide
def e2418335757166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2418335757166 : Closed e2418335757166 ∧ code e2418335757166 = 11214428779374 := by decide
theorem cert_e2418335757166 : check e2418335757166 [[],[]] .chain = true := by decide
def e2418335757174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2418335757174 : Closed e2418335757174 ∧ code e2418335757174 = 11214428779382 := by decide
theorem cert_e2418335757174 : check e2418335757174 [[],[]] .chain = true := by decide
def e2418335757230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2418335757230 : Closed e2418335757230 ∧ code e2418335757230 = 11214428779438 := by decide
theorem cert_e2418335757230 : check e2418335757230 [[],[]] .chain = true := by decide
def e2418335757242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2418335757242 : Closed e2418335757242 ∧ code e2418335757242 = 11214428779450 := by decide
theorem cert_e2418335757242 : check e2418335757242 [[],[]] .chain = true := by decide
def e2418335757270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2418335757270 : Closed e2418335757270 ∧ code e2418335757270 = 11214428779478 := by decide
theorem cert_e2418335757270 : check e2418335757270 [[],[]] .chain = true := by decide
def e2418335757274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2418335757274 : Closed e2418335757274 ∧ code e2418335757274 = 11214428779482 := by decide
theorem cert_e2418335757274 : check e2418335757274 [[],[]] .chain = true := by decide
def e2418335757550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2418335757550 : Closed e2418335757550 ∧ code e2418335757550 = 11214428779758 := by decide
theorem cert_e2418335757550 : check e2418335757550 [[],[]] .chain = true := by decide
def e2418335757558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2418335757558 : Closed e2418335757558 ∧ code e2418335757558 = 11214428779766 := by decide
theorem cert_e2418335757558 : check e2418335757558 [[],[]] .chain = true := by decide
def e2418335757934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2418335757934 : Closed e2418335757934 ∧ code e2418335757934 = 11214428780142 := by decide
theorem cert_e2418335757934 : check e2418335757934 [[],[]] .chain = true := by decide
def e2418335757946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2418335757946 : Closed e2418335757946 ∧ code e2418335757946 = 11214428780154 := by decide
theorem cert_e2418335757946 : check e2418335757946 [[],[]] .chain = true := by decide
def e2418335758134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335758134 : Closed e2418335758134 ∧ code e2418335758134 = 11214428780342 := by decide
theorem cert_e2418335758134 : check e2418335758134 [[],[]] .chain = true := by decide
def e2418335758138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335758138 : Closed e2418335758138 ∧ code e2418335758138 = 11214428780346 := by decide
theorem cert_e2418335758138 : check e2418335758138 [[],[]] .chain = true := by decide
def e2418335758574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2418335758574 : Closed e2418335758574 ∧ code e2418335758574 = 11214428780782 := by decide
theorem cert_e2418335758574 : check e2418335758574 [[],[]] .chain = true := by decide
def e2418335758582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2418335758582 : Closed e2418335758582 ∧ code e2418335758582 = 11214428780790 := by decide
theorem cert_e2418335758582 : check e2418335758582 [[],[]] .chain = true := by decide
def e2418335758766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2418335758766 : Closed e2418335758766 ∧ code e2418335758766 = 11214428780974 := by decide
theorem cert_e2418335758766 : check e2418335758766 [[],[]] .chain = true := by decide
end Blc.Floor43
