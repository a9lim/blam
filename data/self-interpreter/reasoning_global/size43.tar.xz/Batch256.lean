import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405949702874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405949702874 : Closed e2405949702874 ∧ code e2405949702874 = 11202042725082 := by decide
theorem cert_e2405949702874 : check e2405949702874 [[]] .width = true := by decide
def e2405949702890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405949702890 : Closed e2405949702890 ∧ code e2405949702890 = 11202042725098 := by decide
theorem cert_e2405949702890 : check e2405949702890 [[]] .width = true := by decide
def e2405949702966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405949702966 : Closed e2405949702966 ∧ code e2405949702966 = 11202042725174 := by decide
theorem cert_e2405949702966 : check e2405949702966 [[]] .width = true := by decide
def e2405949702970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405949702970 : Closed e2405949702970 ∧ code e2405949702970 = 11202042725178 := by decide
theorem cert_e2405949702970 : check e2405949702970 [[]] .width = true := by decide
def e2405949703054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405949703054 : Closed e2405949703054 ∧ code e2405949703054 = 11202042725262 := by decide
theorem cert_e2405949703054 : check e2405949703054 [[]] .width = true := by decide
def e2405949703066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405949703066 : Closed e2405949703066 ∧ code e2405949703066 = 11202042725274 := by decide
theorem cert_e2405949703066 : check e2405949703066 [[]] .width = true := by decide
def e2405949704986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405949704986 : Closed e2405949704986 ∧ code e2405949704986 = 11202042727194 := by decide
theorem cert_e2405949704986 : check e2405949704986 [[]] .width = true := by decide
def e2405949705030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405949705030 : Closed e2405949705030 ∧ code e2405949705030 = 11202042727238 := by decide
theorem cert_e2405949705030 : check e2405949705030 [[]] .width = true := by decide
def e2405949705270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405949705270 : Closed e2405949705270 ∧ code e2405949705270 = 11202042727478 := by decide
theorem cert_e2405949705270 : check e2405949705270 [[]] .width = true := by decide
def e2405949705274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405949705274 : Closed e2405949705274 ∧ code e2405949705274 = 11202042727482 := by decide
theorem cert_e2405949705274 : check e2405949705274 [[]] .width = true := by decide
def e2405949705414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405949705414 : Closed e2405949705414 ∧ code e2405949705414 = 11202042727622 := by decide
theorem cert_e2405949705414 : check e2405949705414 [[]] .width = true := by decide
def e2405949986842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405949986842 : Closed e2405949986842 ∧ code e2405949986842 = 11202043009050 := by decide
theorem cert_e2405949986842 : check e2405949986842 [[]] .width = true := by decide
def e2405949990938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405949990938 : Closed e2405949990938 ∧ code e2405949990938 = 11202043013146 := by decide
theorem cert_e2405949990938 : check e2405949990938 [[]] .width = true := by decide
def e2405949992474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405949992474 : Closed e2405949992474 ∧ code e2405949992474 = 11202043014682 := by decide
theorem cert_e2405949992474 : check e2405949992474 [[]] .width = true := by decide
def e2405949994522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405949994522 : Closed e2405949994522 ∧ code e2405949994522 = 11202043016730 := by decide
theorem cert_e2405949994522 : check e2405949994522 [[]] .width = true := by decide
def e2405950007322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405950007322 : Closed e2405950007322 ∧ code e2405950007322 = 11202043029530 := by decide
theorem cert_e2405950007322 : check e2405950007322 [[]] .width = true := by decide
def e2405950008858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950008858 : Closed e2405950008858 ∧ code e2405950008858 = 11202043031066 := by decide
theorem cert_e2405950008858 : check e2405950008858 [[]] .width = true := by decide
def e2405950011930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950011930 : Closed e2405950011930 ∧ code e2405950011930 = 11202043034138 := by decide
theorem cert_e2405950011930 : check e2405950011930 [[]] .width = true := by decide
def e2405950019098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950019098 : Closed e2405950019098 ∧ code e2405950019098 = 11202043041306 := by decide
theorem cert_e2405950019098 : check e2405950019098 [[]] .width = true := by decide
def e2405950020122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950020122 : Closed e2405950020122 ∧ code e2405950020122 = 11202043042330 := by decide
theorem cert_e2405950020122 : check e2405950020122 [[]] .width = true := by decide
def e2405950058694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405950058694 : Closed e2405950058694 ∧ code e2405950058694 = 11202043080902 := by decide
theorem cert_e2405950058694 : check e2405950058694 [[]] .width = true := by decide
def e2405950085146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405950085146 : Closed e2405950085146 ∧ code e2405950085146 = 11202043107354 := by decide
theorem cert_e2405950085146 : check e2405950085146 [[]] .width = true := by decide
def e2405950089242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405950089242 : Closed e2405950089242 ∧ code e2405950089242 = 11202043111450 := by decide
theorem cert_e2405950089242 : check e2405950089242 [[]] .width = true := by decide
def e2405950090778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950090778 : Closed e2405950090778 ∧ code e2405950090778 = 11202043112986 := by decide
theorem cert_e2405950090778 : check e2405950090778 [[]] .width = true := by decide
def e2405950092826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950092826 : Closed e2405950092826 ∧ code e2405950092826 = 11202043115034 := by decide
theorem cert_e2405950092826 : check e2405950092826 [[]] .width = true := by decide
def e2405950128154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405950128154 : Closed e2405950128154 ∧ code e2405950128154 = 11202043150362 := by decide
theorem cert_e2405950128154 : check e2405950128154 [[]] .width = true := by decide
def e2405950128246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405950128246 : Closed e2405950128246 ∧ code e2405950128246 = 11202043150454 := by decide
theorem cert_e2405950128246 : check e2405950128246 [[]] .width = true := by decide
def e2405950128490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405950128490 : Closed e2405950128490 ∧ code e2405950128490 = 11202043150698 := by decide
theorem cert_e2405950128490 : check e2405950128490 [[]] .width = true := by decide
def e2405950128538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405950128538 : Closed e2405950128538 ∧ code e2405950128538 = 11202043150746 := by decide
theorem cert_e2405950128538 : check e2405950128538 [[]] .width = true := by decide
def e2405950129546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405950129546 : Closed e2405950129546 ∧ code e2405950129546 = 11202043151754 := by decide
theorem cert_e2405950129546 : check e2405950129546 [[]] .width = true := by decide
def e2405950129570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405950129570 : Closed e2405950129570 ∧ code e2405950129570 = 11202043151778 := by decide
theorem cert_e2405950129570 : check e2405950129570 [[]] .width = true := by decide
def e2405950129678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405950129678 : Closed e2405950129678 ∧ code e2405950129678 = 11202043151886 := by decide
theorem cert_e2405950129678 : check e2405950129678 [[]] .width = true := by decide
def e2405950129690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405950129690 : Closed e2405950129690 ∧ code e2405950129690 = 11202043151898 := by decide
theorem cert_e2405950129690 : check e2405950129690 [[]] .width = true := by decide
def e2405950129762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405950129762 : Closed e2405950129762 ∧ code e2405950129762 = 11202043151970 := by decide
theorem cert_e2405950129762 : check e2405950129762 [[]] .width = true := by decide
def e2405950162970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405950162970 : Closed e2405950162970 ∧ code e2405950162970 = 11202043185178 := by decide
theorem cert_e2405950162970 : check e2405950162970 [[]] .width = true := by decide
def e2405950169114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405950169114 : Closed e2405950169114 ∧ code e2405950169114 = 11202043191322 := by decide
theorem cert_e2405950169114 : check e2405950169114 [[]] .width = true := by decide
def e2405950169206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405950169206 : Closed e2405950169206 ∧ code e2405950169206 = 11202043191414 := by decide
theorem cert_e2405950169206 : check e2405950169206 [[]] .width = true := by decide
def e2405950169450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405950169450 : Closed e2405950169450 ∧ code e2405950169450 = 11202043191658 := by decide
theorem cert_e2405950169450 : check e2405950169450 [[]] .width = true := by decide
def e2405950169498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405950169498 : Closed e2405950169498 ∧ code e2405950169498 = 11202043191706 := by decide
theorem cert_e2405950169498 : check e2405950169498 [[]] .width = true := by decide
def e2405950173382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405950173382 : Closed e2405950173382 ∧ code e2405950173382 = 11202043195590 := by decide
theorem cert_e2405950173382 : check e2405950173382 [[]] .width = true := by decide
def e2405950175258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405950175258 : Closed e2405950175258 ∧ code e2405950175258 = 11202043197466 := by decide
theorem cert_e2405950175258 : check e2405950175258 [[]] .width = true := by decide
def e2405950187546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405950187546 : Closed e2405950187546 ∧ code e2405950187546 = 11202043209754 := by decide
theorem cert_e2405950187546 : check e2405950187546 [[]] .width = true := by decide
def e2405950189082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950189082 : Closed e2405950189082 ∧ code e2405950189082 = 11202043211290 := by decide
theorem cert_e2405950189082 : check e2405950189082 [[]] .width = true := by decide
def e2405950192154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950192154 : Closed e2405950192154 ∧ code e2405950192154 = 11202043214362 := by decide
theorem cert_e2405950192154 : check e2405950192154 [[]] .width = true := by decide
def e2405950193690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405950193690 : Closed e2405950193690 ∧ code e2405950193690 = 11202043215898 := by decide
theorem cert_e2405950193690 : check e2405950193690 [[]] .width = true := by decide
def e2405950193782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405950193782 : Closed e2405950193782 ∧ code e2405950193782 = 11202043215990 := by decide
theorem cert_e2405950193782 : check e2405950193782 [[]] .width = true := by decide
def e2405950194026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405950194026 : Closed e2405950194026 ∧ code e2405950194026 = 11202043216234 := by decide
theorem cert_e2405950194026 : check e2405950194026 [[]] .width = true := by decide
def e2405950194074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405950194074 : Closed e2405950194074 ∧ code e2405950194074 = 11202043216282 := by decide
theorem cert_e2405950194074 : check e2405950194074 [[]] .width = true := by decide
def e2405950195082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405950195082 : Closed e2405950195082 ∧ code e2405950195082 = 11202043217290 := by decide
theorem cert_e2405950195082 : check e2405950195082 [[]] .width = true := by decide
def e2405950195106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405950195106 : Closed e2405950195106 ∧ code e2405950195106 = 11202043217314 := by decide
theorem cert_e2405950195106 : check e2405950195106 [[]] .width = true := by decide
def e2405950195214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405950195214 : Closed e2405950195214 ∧ code e2405950195214 = 11202043217422 := by decide
theorem cert_e2405950195214 : check e2405950195214 [[]] .width = true := by decide
def e2405950195226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405950195226 : Closed e2405950195226 ∧ code e2405950195226 = 11202043217434 := by decide
theorem cert_e2405950195226 : check e2405950195226 [[]] .width = true := by decide
def e2405950195298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405950195298 : Closed e2405950195298 ∧ code e2405950195298 = 11202043217506 := by decide
theorem cert_e2405950195298 : check e2405950195298 [[]] .width = true := by decide
def e2405950210246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405950210246 : Closed e2405950210246 ∧ code e2405950210246 = 11202043232454 := by decide
theorem cert_e2405950210246 : check e2405950210246 [[]] .width = true := by decide
def e2405950218266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405950218266 : Closed e2405950218266 ∧ code e2405950218266 = 11202043240474 := by decide
theorem cert_e2405950218266 : check e2405950218266 [[]] .width = true := by decide
def e2405950218358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405950218358 : Closed e2405950218358 ∧ code e2405950218358 = 11202043240566 := by decide
theorem cert_e2405950218358 : check e2405950218358 [[]] .width = true := by decide
def e2405950218602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405950218602 : Closed e2405950218602 ∧ code e2405950218602 = 11202043240810 := by decide
theorem cert_e2405950218602 : check e2405950218602 [[]] .width = true := by decide
def e2405950218650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405950218650 : Closed e2405950218650 ∧ code e2405950218650 = 11202043240858 := by decide
theorem cert_e2405950218650 : check e2405950218650 [[]] .width = true := by decide
def e2405950240282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950240282 : Closed e2405950240282 ∧ code e2405950240282 = 11202043262490 := by decide
theorem cert_e2405950240282 : check e2405950240282 [[]] .width = true := by decide
def e2405950241306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405950241306 : Closed e2405950241306 ∧ code e2405950241306 = 11202043263514 := by decide
theorem cert_e2405950241306 : check e2405950241306 [[]] .width = true := by decide
def e2405950251034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405950251034 : Closed e2405950251034 ∧ code e2405950251034 = 11202043273242 := by decide
theorem cert_e2405950251034 : check e2405950251034 [[]] .width = true := by decide
def e2405950251126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405950251126 : Closed e2405950251126 ∧ code e2405950251126 = 11202043273334 := by decide
theorem cert_e2405950251126 : check e2405950251126 [[]] .width = true := by decide
def e2405950251370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405950251370 : Closed e2405950251370 ∧ code e2405950251370 = 11202043273578 := by decide
theorem cert_e2405950251370 : check e2405950251370 [[]] .width = true := by decide
def e2405950251418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405950251418 : Closed e2405950251418 ∧ code e2405950251418 = 11202043273626 := by decide
theorem cert_e2405950251418 : check e2405950251418 [[]] .width = true := by decide
def e2405950816282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2405950816282 : Closed e2405950816282 ∧ code e2405950816282 = 11202043838490 := by decide
theorem cert_e2405950816282 : check e2405950816282 [[]] .width = true := by decide
def e2405950816374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2405950816374 : Closed e2405950816374 ∧ code e2405950816374 = 11202043838582 := by decide
theorem cert_e2405950816374 : check e2405950816374 [[]] .width = true := by decide
def e2405950816618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2405950816618 : Closed e2405950816618 ∧ code e2405950816618 = 11202043838826 := by decide
theorem cert_e2405950816618 : check e2405950816618 [[]] .width = true := by decide
def e2405950816666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2405950816666 : Closed e2405950816666 ∧ code e2405950816666 = 11202043838874 := by decide
theorem cert_e2405950816666 : check e2405950816666 [[]] .width = true := by decide
def e2405950816750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2405950816750 : Closed e2405950816750 ∧ code e2405950816750 = 11202043838958 := by decide
theorem cert_e2405950816750 : check e2405950816750 [[]] .width = true := by decide
def e2405950817674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2405950817674 : Closed e2405950817674 ∧ code e2405950817674 = 11202043839882 := by decide
theorem cert_e2405950817674 : check e2405950817674 [[]] .width = true := by decide
def e2405950817698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2405950817698 : Closed e2405950817698 ∧ code e2405950817698 = 11202043839906 := by decide
theorem cert_e2405950817698 : check e2405950817698 [[]] .width = true := by decide
def e2405950817710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2405950817710 : Closed e2405950817710 ∧ code e2405950817710 = 11202043839918 := by decide
theorem cert_e2405950817710 : check e2405950817710 [[]] .width = true := by decide
def e2405950817718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2405950817718 : Closed e2405950817718 ∧ code e2405950817718 = 11202043839926 := by decide
theorem cert_e2405950817718 : check e2405950817718 [[]] .width = true := by decide
def e2405950817722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2405950817722 : Closed e2405950817722 ∧ code e2405950817722 = 11202043839930 := by decide
theorem cert_e2405950817722 : check e2405950817722 [[]] .width = true := by decide
def e2405950817750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2405950817750 : Closed e2405950817750 ∧ code e2405950817750 = 11202043839958 := by decide
theorem cert_e2405950817750 : check e2405950817750 [[]] .width = true := by decide
def e2405950817754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2405950817754 : Closed e2405950817754 ∧ code e2405950817754 = 11202043839962 := by decide
theorem cert_e2405950817754 : check e2405950817754 [[]] .width = true := by decide
def e2405950817770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2405950817770 : Closed e2405950817770 ∧ code e2405950817770 = 11202043839978 := by decide
theorem cert_e2405950817770 : check e2405950817770 [[]] .width = true := by decide
def e2405950817806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2405950817806 : Closed e2405950817806 ∧ code e2405950817806 = 11202043840014 := by decide
theorem cert_e2405950817806 : check e2405950817806 [[]] .width = true := by decide
def e2405950817818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405950817818 : Closed e2405950817818 ∧ code e2405950817818 = 11202043840026 := by decide
theorem cert_e2405950817818 : check e2405950817818 [[]] .width = true := by decide
def e2405950817890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2405950817890 : Closed e2405950817890 ∧ code e2405950817890 = 11202043840098 := by decide
theorem cert_e2405950817890 : check e2405950817890 [[]] .width = true := by decide
def e2405950817902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2405950817902 : Closed e2405950817902 ∧ code e2405950817902 = 11202043840110 := by decide
theorem cert_e2405950817902 : check e2405950817902 [[]] .width = true := by decide
def e2405950817910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2405950817910 : Closed e2405950817910 ∧ code e2405950817910 = 11202043840118 := by decide
theorem cert_e2405950817910 : check e2405950817910 [[]] .width = true := by decide
def e2405950817914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2405950817914 : Closed e2405950817914 ∧ code e2405950817914 = 11202043840122 := by decide
theorem cert_e2405950817914 : check e2405950817914 [[]] .width = true := by decide
def e2405950818102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2405950818102 : Closed e2405950818102 ∧ code e2405950818102 = 11202043840310 := by decide
theorem cert_e2405950818102 : check e2405950818102 [[]] .width = true := by decide
def e2405950818106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2405950818106 : Closed e2405950818106 ∧ code e2405950818106 = 11202043840314 := by decide
theorem cert_e2405950818106 : check e2405950818106 [[]] .width = true := by decide
def e2405950818202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2405950818202 : Closed e2405950818202 ∧ code e2405950818202 = 11202043840410 := by decide
theorem cert_e2405950818202 : check e2405950818202 [[]] .width = true := by decide
def e2405950821802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2405950821802 : Closed e2405950821802 ∧ code e2405950821802 = 11202043844010 := by decide
theorem cert_e2405950821802 : check e2405950821802 [[]] .width = true := by decide
def e2405950821898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2405950821898 : Closed e2405950821898 ∧ code e2405950821898 = 11202043844106 := by decide
theorem cert_e2405950821898 : check e2405950821898 [[]] .width = true := by decide
def e2405950821942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2405950821942 : Closed e2405950821942 ∧ code e2405950821942 = 11202043844150 := by decide
theorem cert_e2405950821942 : check e2405950821942 [[]] .width = true := by decide
def e2405950821946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2405950821946 : Closed e2405950821946 ∧ code e2405950821946 = 11202043844154 := by decide
theorem cert_e2405950821946 : check e2405950821946 [[]] .width = true := by decide
def e2405950821994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2405950821994 : Closed e2405950821994 ∧ code e2405950821994 = 11202043844202 := by decide
theorem cert_e2405950821994 : check e2405950821994 [[]] .width = true := by decide
def e2405950822018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2405950822018 : Closed e2405950822018 ∧ code e2405950822018 = 11202043844226 := by decide
theorem cert_e2405950822018 : check e2405950822018 [[]] .width = true := by decide
def e2405950822030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2405950822030 : Closed e2405950822030 ∧ code e2405950822030 = 11202043844238 := by decide
theorem cert_e2405950822030 : check e2405950822030 [[]] .width = true := by decide
def e2405950822042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2405950822042 : Closed e2405950822042 ∧ code e2405950822042 = 11202043844250 := by decide
theorem cert_e2405950822042 : check e2405950822042 [[]] .width = true := by decide
def e2405950822086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2405950822086 : Closed e2405950822086 ∧ code e2405950822086 = 11202043844294 := by decide
theorem cert_e2405950822086 : check e2405950822086 [[]] .width = true := by decide
def e2405950822166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2405950822166 : Closed e2405950822166 ∧ code e2405950822166 = 11202043844374 := by decide
theorem cert_e2405950822166 : check e2405950822166 [[]] .width = true := by decide
def e2405950822170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2405950822170 : Closed e2405950822170 ∧ code e2405950822170 = 11202043844378 := by decide
theorem cert_e2405950822170 : check e2405950822170 [[]] .width = true := by decide
def e2405950822214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2405950822214 : Closed e2405950822214 ∧ code e2405950822214 = 11202043844422 := by decide
theorem cert_e2405950822214 : check e2405950822214 [[]] .width = true := by decide
def e2405950822242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2405950822242 : Closed e2405950822242 ∧ code e2405950822242 = 11202043844450 := by decide
theorem cert_e2405950822242 : check e2405950822242 [[]] .width = true := by decide
def e2405950822426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405950822426 : Closed e2405950822426 ∧ code e2405950822426 = 11202043844634 := by decide
theorem cert_e2405950822426 : check e2405950822426 [[]] .width = true := by decide
def e2405950822518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405950822518 : Closed e2405950822518 ∧ code e2405950822518 = 11202043844726 := by decide
theorem cert_e2405950822518 : check e2405950822518 [[]] .width = true := by decide
def e2405950822762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405950822762 : Closed e2405950822762 ∧ code e2405950822762 = 11202043844970 := by decide
theorem cert_e2405950822762 : check e2405950822762 [[]] .width = true := by decide
def e2405950822786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2405950822786 : Closed e2405950822786 ∧ code e2405950822786 = 11202043844994 := by decide
theorem cert_e2405950822786 : check e2405950822786 [[]] .width = true := by decide
def e2405950822798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405950822798 : Closed e2405950822798 ∧ code e2405950822798 = 11202043845006 := by decide
theorem cert_e2405950822798 : check e2405950822798 [[]] .width = true := by decide
def e2405950822810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405950822810 : Closed e2405950822810 ∧ code e2405950822810 = 11202043845018 := by decide
theorem cert_e2405950822810 : check e2405950822810 [[]] .width = true := by decide
def e2405950822854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405950822854 : Closed e2405950822854 ∧ code e2405950822854 = 11202043845062 := by decide
theorem cert_e2405950822854 : check e2405950822854 [[]] .width = true := by decide
def e2405950823454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2405950823454 : Closed e2405950823454 ∧ code e2405950823454 = 11202043845662 := by decide
theorem cert_e2405950823454 : check e2405950823454 [[]] .width = true := by decide
def e2405950823622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405950823622 : Closed e2405950823622 ∧ code e2405950823622 = 11202043845830 := by decide
theorem cert_e2405950823622 : check e2405950823622 [[]] .width = true := by decide
def e2405950823650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2405950823650 : Closed e2405950823650 ∧ code e2405950823650 = 11202043845858 := by decide
theorem cert_e2405950823650 : check e2405950823650 [[]] .width = true := by decide
def e2405950838314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2405950838314 : Closed e2405950838314 ∧ code e2405950838314 = 11202043860522 := by decide
theorem cert_e2405950838314 : check e2405950838314 [[]] .width = true := by decide
def e2405950838410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2405950838410 : Closed e2405950838410 ∧ code e2405950838410 = 11202043860618 := by decide
theorem cert_e2405950838410 : check e2405950838410 [[]] .width = true := by decide
def e2405950838434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405950838434 : Closed e2405950838434 ∧ code e2405950838434 = 11202043860642 := by decide
theorem cert_e2405950838434 : check e2405950838434 [[]] .width = true := by decide
def e2405950838794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2405950838794 : Closed e2405950838794 ∧ code e2405950838794 = 11202043861002 := by decide
theorem cert_e2405950838794 : check e2405950838794 [[]] .width = true := by decide
def e2405950838842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2405950838842 : Closed e2405950838842 ∧ code e2405950838842 = 11202043861050 := by decide
theorem cert_e2405950838842 : check e2405950838842 [[]] .width = true := by decide
def e2405950838890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2405950838890 : Closed e2405950838890 ∧ code e2405950838890 = 11202043861098 := by decide
theorem cert_e2405950838890 : check e2405950838890 [[]] .width = true := by decide
def e2405950838938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2405950838938 : Closed e2405950838938 ∧ code e2405950838938 = 11202043861146 := by decide
theorem cert_e2405950838938 : check e2405950838938 [[]] .width = true := by decide
def e2405950838982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2405950838982 : Closed e2405950838982 ∧ code e2405950838982 = 11202043861190 := by decide
theorem cert_e2405950838982 : check e2405950838982 [[]] .width = true := by decide
def e2405950839178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2405950839178 : Closed e2405950839178 ∧ code e2405950839178 = 11202043861386 := by decide
theorem cert_e2405950839178 : check e2405950839178 [[]] .width = true := by decide
def e2405950839202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2405950839202 : Closed e2405950839202 ∧ code e2405950839202 = 11202043861410 := by decide
theorem cert_e2405950839202 : check e2405950839202 [[]] .width = true := by decide
def e2405950839298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2405950839298 : Closed e2405950839298 ∧ code e2405950839298 = 11202043861506 := by decide
theorem cert_e2405950839298 : check e2405950839298 [[]] .width = true := by decide
def e2405950839310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2405950839310 : Closed e2405950839310 ∧ code e2405950839310 = 11202043861518 := by decide
theorem cert_e2405950839310 : check e2405950839310 [[]] .width = true := by decide
def e2405950839322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405950839322 : Closed e2405950839322 ∧ code e2405950839322 = 11202043861530 := by decide
theorem cert_e2405950839322 : check e2405950839322 [[]] .width = true := by decide
def e2405950839394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405950839394 : Closed e2405950839394 ∧ code e2405950839394 = 11202043861602 := by decide
theorem cert_e2405950839394 : check e2405950839394 [[]] .width = true := by decide
def e2405950840858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405950840858 : Closed e2405950840858 ∧ code e2405950840858 = 11202043863066 := by decide
theorem cert_e2405950840858 : check e2405950840858 [[]] .width = true := by decide
def e2405950840942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2405950840942 : Closed e2405950840942 ∧ code e2405950840942 = 11202043863150 := by decide
theorem cert_e2405950840942 : check e2405950840942 [[]] .width = true := by decide
def e2405950840950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405950840950 : Closed e2405950840950 ∧ code e2405950840950 = 11202043863158 := by decide
theorem cert_e2405950840950 : check e2405950840950 [[]] .width = true := by decide
def e2405950840954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2405950840954 : Closed e2405950840954 ∧ code e2405950840954 = 11202043863162 := by decide
theorem cert_e2405950840954 : check e2405950840954 [[]] .width = true := by decide
def e2405950841194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405950841194 : Closed e2405950841194 ∧ code e2405950841194 = 11202043863402 := by decide
theorem cert_e2405950841194 : check e2405950841194 [[]] .width = true := by decide
def e2405950841230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405950841230 : Closed e2405950841230 ∧ code e2405950841230 = 11202043863438 := by decide
theorem cert_e2405950841230 : check e2405950841230 [[]] .width = true := by decide
def e2405950841242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405950841242 : Closed e2405950841242 ∧ code e2405950841242 = 11202043863450 := by decide
theorem cert_e2405950841242 : check e2405950841242 [[]] .width = true := by decide
def e2405950841286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405950841286 : Closed e2405950841286 ∧ code e2405950841286 = 11202043863494 := by decide
theorem cert_e2405950841286 : check e2405950841286 [[]] .width = true := by decide
def e2405950842250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2405950842250 : Closed e2405950842250 ∧ code e2405950842250 = 11202043864458 := by decide
theorem cert_e2405950842250 : check e2405950842250 [[]] .width = true := by decide
def e2405950842274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2405950842274 : Closed e2405950842274 ∧ code e2405950842274 = 11202043864482 := by decide
theorem cert_e2405950842274 : check e2405950842274 [[]] .width = true := by decide
def e2405950842370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2405950842370 : Closed e2405950842370 ∧ code e2405950842370 = 11202043864578 := by decide
theorem cert_e2405950842370 : check e2405950842370 [[]] .width = true := by decide
def e2405950842382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2405950842382 : Closed e2405950842382 ∧ code e2405950842382 = 11202043864590 := by decide
theorem cert_e2405950842382 : check e2405950842382 [[]] .width = true := by decide
def e2405950842394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405950842394 : Closed e2405950842394 ∧ code e2405950842394 = 11202043864602 := by decide
theorem cert_e2405950842394 : check e2405950842394 [[]] .width = true := by decide
def e2405950842466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2405950842466 : Closed e2405950842466 ∧ code e2405950842466 = 11202043864674 := by decide
theorem cert_e2405950842466 : check e2405950842466 [[]] .width = true := by decide
def e2405950888450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2405950888450 : Closed e2405950888450 ∧ code e2405950888450 = 11202043910658 := by decide
theorem cert_e2405950888450 : check e2405950888450 [[]] .width = true := by decide
def e2405950888474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405950888474 : Closed e2405950888474 ∧ code e2405950888474 = 11202043910682 := by decide
theorem cert_e2405950888474 : check e2405950888474 [[]] .width = true := by decide
def e2405954074650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405954074650 : Closed e2405954074650 ∧ code e2405954074650 = 11202047096858 := by decide
theorem cert_e2405954074650 : check e2405954074650 [[]] .width = true := by decide
def e2405954086938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405954086938 : Closed e2405954086938 ∧ code e2405954086938 = 11202047109146 := by decide
theorem cert_e2405954086938 : check e2405954086938 [[]] .width = true := by decide
def e2405954412570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405954412570 : Closed e2405954412570 ∧ code e2405954412570 = 11202047434778 := by decide
theorem cert_e2405954412570 : check e2405954412570 [[]] .width = true := by decide
def e2405954412662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405954412662 : Closed e2405954412662 ∧ code e2405954412662 = 11202047434870 := by decide
theorem cert_e2405954412662 : check e2405954412662 [[]] .width = true := by decide
def e2405954412906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405954412906 : Closed e2405954412906 ∧ code e2405954412906 = 11202047435114 := by decide
theorem cert_e2405954412906 : check e2405954412906 [[]] .width = true := by decide
def e2405954412954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405954412954 : Closed e2405954412954 ∧ code e2405954412954 = 11202047435162 := by decide
theorem cert_e2405954412954 : check e2405954412954 [[]] .width = true := by decide
def e2405954461722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405954461722 : Closed e2405954461722 ∧ code e2405954461722 = 11202047483930 := by decide
theorem cert_e2405954461722 : check e2405954461722 [[]] .width = true := by decide
def e2405954461814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405954461814 : Closed e2405954461814 ∧ code e2405954461814 = 11202047484022 := by decide
theorem cert_e2405954461814 : check e2405954461814 [[]] .width = true := by decide
def e2405954462058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405954462058 : Closed e2405954462058 ∧ code e2405954462058 = 11202047484266 := by decide
theorem cert_e2405954462058 : check e2405954462058 [[]] .width = true := by decide
def e2405954462106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405954462106 : Closed e2405954462106 ∧ code e2405954462106 = 11202047484314 := by decide
theorem cert_e2405954462106 : check e2405954462106 [[]] .width = true := by decide
def e2405955236038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405955236038 : Closed e2405955236038 ∧ code e2405955236038 = 11202048258246 := by decide
theorem cert_e2405955236038 : check e2405955236038 [[]] .width = true := by decide
def e2405955260614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405955260614 : Closed e2405955260614 ∧ code e2405955260614 = 11202048282822 := by decide
theorem cert_e2405955260614 : check e2405955260614 [[]] .width = true := by decide
def e2405955367110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405955367110 : Closed e2405955367110 ∧ code e2405955367110 = 11202048389318 := by decide
theorem cert_e2405955367110 : check e2405955367110 [[]] .width = true := by decide
def e2405955385370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405955385370 : Closed e2405955385370 ∧ code e2405955385370 = 11202048407578 := by decide
theorem cert_e2405955385370 : check e2405955385370 [[]] .width = true := by decide
def e2405955399194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405955399194 : Closed e2405955399194 ∧ code e2405955399194 = 11202048421402 := by decide
theorem cert_e2405955399194 : check e2405955399194 [[]] .width = true := by decide
def e2405955489990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405955489990 : Closed e2405955489990 ∧ code e2405955489990 = 11202048512198 := by decide
theorem cert_e2405955489990 : check e2405955489990 [[]] .width = true := by decide
def e2405955497498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405955497498 : Closed e2405955497498 ∧ code e2405955497498 = 11202048519706 := by decide
theorem cert_e2405955497498 : check e2405955497498 [[]] .width = true := by decide
def e2405955500570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405955500570 : Closed e2405955500570 ∧ code e2405955500570 = 11202048522778 := by decide
private def t_e2405955500570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405955500570 : ¬ IsSelfInterpreter e2405955500570 :=
  wSource (t := t_e2405955500570) (replay_sound (ps := []) (t := e2405955500570) (by decide)) (by decide)
def e2405955985434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405955985434 : Closed e2405955985434 ∧ code e2405955985434 = 11202049007642 := by decide
theorem cert_e2405955985434 : check e2405955985434 [[]] .width = true := by decide
def e2405955985526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405955985526 : Closed e2405955985526 ∧ code e2405955985526 = 11202049007734 := by decide
theorem cert_e2405955985526 : check e2405955985526 [[]] .width = true := by decide
def e2405955985770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405955985770 : Closed e2405955985770 ∧ code e2405955985770 = 11202049007978 := by decide
theorem cert_e2405955985770 : check e2405955985770 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405955500570
