import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392515088182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392515088182 : Closed e2392515088182 ∧ code e2392515088182 = 11188608110390 := by decide
theorem cert_e2392515088182 : check e2392515088182 [[],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2392515088186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392515088186 : Closed e2392515088186 ∧ code e2392515088186 = 11188608110394 := by decide
theorem cert_e2392515088186 : check e2392515088186 [[],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2392515677038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392515677038 : Closed e2392515677038 ∧ code e2392515677038 = 11188608699246 := by decide
def e2392515677046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392515677046 : Closed e2392515677046 ∧ code e2392515677046 = 11188608699254 := by decide
def e2392515677102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392515677102 : Closed e2392515677102 ∧ code e2392515677102 = 11188608699310 := by decide
def e2392515677114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392515677114 : Closed e2392515677114 ∧ code e2392515677114 = 11188608699322 := by decide
private def t_e2392515677114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2392515677114 : ¬ IsSelfInterpreter e2392515677114 :=
  wSource (t := t_e2392515677114) (replay_sound (ps := []) (t := e2392515677114) (by decide)) (by decide)
def e2392515677142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392515677142 : Closed e2392515677142 ∧ code e2392515677142 = 11188608699350 := by decide
def e2392515677146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392515677146 : Closed e2392515677146 ∧ code e2392515677146 = 11188608699354 := by decide
private def t_e2392515677146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2392515677146 : ¬ IsSelfInterpreter e2392515677146 :=
  wSource (t := t_e2392515677146) (replay_sound (ps := []) (t := e2392515677146) (by decide)) (by decide)
def e2392515677422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392515677422 : Closed e2392515677422 ∧ code e2392515677422 = 11188608699630 := by decide
def e2392515677430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392515677430 : Closed e2392515677430 ∧ code e2392515677430 = 11188608699638 := by decide
def e2392515677806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392515677806 : Closed e2392515677806 ∧ code e2392515677806 = 11188608700014 := by decide
theorem cert_e2392515677806 : check e2392515677806 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2392515677818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392515677818 : Closed e2392515677818 ∧ code e2392515677818 = 11188608700026 := by decide
theorem cert_e2392515677818 : checkPay e2392515677818 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left]] 0 [[],[.left],[],[.right],[.right],[.right,.under],[.right,.under,.under,.left,.left],[.right,.under,.under,.left],[.right,.under,.under,.left,.right],[.right,.under,.under,.right],[.right,.under,.under,.right,.under,.right,.left],[.right,.under,.under,.right,.under,.right],[.right,.under,.under,.right,.under,.right,.right]] = true := by decide
def e2392515678006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392515678006 : Closed e2392515678006 ∧ code e2392515678006 = 11188608700214 := by decide
theorem cert_e2392515678006 : check e2392515678006 [[],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2392515678010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392515678010 : Closed e2392515678010 ∧ code e2392515678010 = 11188608700218 := by decide
def e2392565263726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2392565263726 : Closed e2392565263726 ∧ code e2392565263726 = 11188658285934 := by decide
theorem cert_e2392565263726 : check e2392565263726 [[],[.left]] .smaller = true := by decide
def e2392565263734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2392565263734 : Closed e2392565263734 ∧ code e2392565263734 = 11188658285942 := by decide
theorem cert_e2392565263734 : check e2392565263734 [[],[.left]] .smaller = true := by decide
def e2392565263790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2392565263790 : Closed e2392565263790 ∧ code e2392565263790 = 11188658285998 := by decide
theorem cert_e2392565263790 : check e2392565263790 [[],[.left]] .smaller = true := by decide
def e2392565263802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2392565263802 : Closed e2392565263802 ∧ code e2392565263802 = 11188658286010 := by decide
theorem cert_e2392565263802 : check e2392565263802 [[],[.left]] .smaller = true := by decide
def e2392565263830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2392565263830 : Closed e2392565263830 ∧ code e2392565263830 = 11188658286038 := by decide
theorem cert_e2392565263830 : check e2392565263830 [[],[.left]] .smaller = true := by decide
def e2392565263834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2392565263834 : Closed e2392565263834 ∧ code e2392565263834 = 11188658286042 := by decide
theorem cert_e2392565263834 : check e2392565263834 [[],[.left]] .smaller = true := by decide
def e2392565264046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2392565264046 : Closed e2392565264046 ∧ code e2392565264046 = 11188658286254 := by decide
theorem cert_e2392565264046 : check e2392565264046 [[],[.left]] .smaller = true := by decide
def e2392565264058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2392565264058 : Closed e2392565264058 ∧ code e2392565264058 = 11188658286266 := by decide
theorem cert_e2392565264058 : check e2392565264058 [[],[.left]] .smaller = true := by decide
def e2392565264106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2392565264106 : Closed e2392565264106 ∧ code e2392565264106 = 11188658286314 := by decide
theorem cert_e2392565264106 : check e2392565264106 [[],[.left]] .smaller = true := by decide
def e2392565264214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2392565264214 : Closed e2392565264214 ∧ code e2392565264214 = 11188658286422 := by decide
theorem cert_e2392565264214 : check e2392565264214 [[],[.left]] .smaller = true := by decide
def e2392565264218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2392565264218 : Closed e2392565264218 ∧ code e2392565264218 = 11188658286426 := by decide
theorem cert_e2392565264218 : check e2392565264218 [[],[.left]] .smaller = true := by decide
def e2392565264234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2392565264234 : Closed e2392565264234 ∧ code e2392565264234 = 11188658286442 := by decide
theorem cert_e2392565264234 : check e2392565264234 [[],[.left]] .smaller = true := by decide
def e2392565265262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2392565265262 : Closed e2392565265262 ∧ code e2392565265262 = 11188658287470 := by decide
theorem cert_e2392565265262 : check e2392565265262 [[],[.left]] .smaller = true := by decide
def e2392565265270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2392565265270 : Closed e2392565265270 ∧ code e2392565265270 = 11188658287478 := by decide
theorem cert_e2392565265270 : check e2392565265270 [[],[.left]] .smaller = true := by decide
def e2392565265326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2392565265326 : Closed e2392565265326 ∧ code e2392565265326 = 11188658287534 := by decide
theorem cert_e2392565265326 : check e2392565265326 [[],[.left]] .smaller = true := by decide
def e2392565265338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2392565265338 : Closed e2392565265338 ∧ code e2392565265338 = 11188658287546 := by decide
theorem cert_e2392565265338 : check e2392565265338 [[],[.left]] .smaller = true := by decide
def e2392565265366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2392565265366 : Closed e2392565265366 ∧ code e2392565265366 = 11188658287574 := by decide
theorem cert_e2392565265366 : check e2392565265366 [[],[.left]] .smaller = true := by decide
def e2392565265370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2392565265370 : Closed e2392565265370 ∧ code e2392565265370 = 11188658287578 := by decide
theorem cert_e2392565265370 : check e2392565265370 [[],[.left]] .smaller = true := by decide
def e2392565265646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392565265646 : Closed e2392565265646 ∧ code e2392565265646 = 11188658287854 := by decide
theorem cert_e2392565265646 : check e2392565265646 [[],[.left]] .smaller = true := by decide
def e2392565265654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392565265654 : Closed e2392565265654 ∧ code e2392565265654 = 11188658287862 := by decide
theorem cert_e2392565265654 : check e2392565265654 [[],[.left]] .smaller = true := by decide
def e2392565266030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392565266030 : Closed e2392565266030 ∧ code e2392565266030 = 11188658288238 := by decide
theorem cert_e2392565266030 : check e2392565266030 [[],[.left]] .smaller = true := by decide
def e2392565266042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392565266042 : Closed e2392565266042 ∧ code e2392565266042 = 11188658288250 := by decide
theorem cert_e2392565266042 : check e2392565266042 [[],[.left]] .smaller = true := by decide
def e2392565266230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392565266230 : Closed e2392565266230 ∧ code e2392565266230 = 11188658288438 := by decide
theorem cert_e2392565266230 : check e2392565266230 [[],[.left]] .smaller = true := by decide
def e2392565266234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392565266234 : Closed e2392565266234 ∧ code e2392565266234 = 11188658288442 := by decide
theorem cert_e2392565266234 : check e2392565266234 [[],[.left]] .smaller = true := by decide
def e2392565266862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2392565266862 : Closed e2392565266862 ∧ code e2392565266862 = 11188658289070 := by decide
theorem cert_e2392565266862 : check e2392565266862 [[],[.left]] .smaller = true := by decide
def e2392565266874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2392565266874 : Closed e2392565266874 ∧ code e2392565266874 = 11188658289082 := by decide
theorem cert_e2392565266874 : check e2392565266874 [[],[.left]] .smaller = true := by decide
def e2392565266922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2392565266922 : Closed e2392565266922 ∧ code e2392565266922 = 11188658289130 := by decide
theorem cert_e2392565266922 : check e2392565266922 [[],[.left]] .smaller = true := by decide
def e2392565267054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392565267054 : Closed e2392565267054 ∧ code e2392565267054 = 11188658289262 := by decide
theorem cert_e2392565267054 : check e2392565267054 [[],[.left]] .smaller = true := by decide
def e2392565267066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392565267066 : Closed e2392565267066 ∧ code e2392565267066 = 11188658289274 := by decide
theorem cert_e2392565267066 : check e2392565267066 [[],[.left]] .smaller = true := by decide
def e2392565267354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392565267354 : Closed e2392565267354 ∧ code e2392565267354 = 11188658289562 := by decide
theorem cert_e2392565267354 : check e2392565267354 [[],[.left]] .smaller = true := by decide
def e2392565267670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2392565267670 : Closed e2392565267670 ∧ code e2392565267670 = 11188658289878 := by decide
theorem cert_e2392565267670 : check e2392565267670 [[],[.left]] .smaller = true := by decide
def e2392565267674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2392565267674 : Closed e2392565267674 ∧ code e2392565267674 = 11188658289882 := by decide
theorem cert_e2392565267674 : check e2392565267674 [[],[.left]] .smaller = true := by decide
def e2392565267690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2392565267690 : Closed e2392565267690 ∧ code e2392565267690 = 11188658289898 := by decide
theorem cert_e2392565267690 : check e2392565267690 [[],[.left]] .smaller = true := by decide
def e2392565267766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392565267766 : Closed e2392565267766 ∧ code e2392565267766 = 11188658289974 := by decide
theorem cert_e2392565267766 : check e2392565267766 [[],[.left]] .smaller = true := by decide
def e2392565267770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392565267770 : Closed e2392565267770 ∧ code e2392565267770 = 11188658289978 := by decide
theorem cert_e2392565267770 : check e2392565267770 [[],[.left]] .smaller = true := by decide
def e2392565267866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392565267866 : Closed e2392565267866 ∧ code e2392565267866 = 11188658290074 := by decide
theorem cert_e2392565267866 : check e2392565267866 [[],[.left]] .smaller = true := by decide
def e2392565271406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2392565271406 : Closed e2392565271406 ∧ code e2392565271406 = 11188658293614 := by decide
theorem cert_e2392565271406 : check e2392565271406 [[],[.left]] .smaller = true := by decide
def e2392565271414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2392565271414 : Closed e2392565271414 ∧ code e2392565271414 = 11188658293622 := by decide
theorem cert_e2392565271414 : check e2392565271414 [[],[.left]] .smaller = true := by decide
def e2392565271470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2392565271470 : Closed e2392565271470 ∧ code e2392565271470 = 11188658293678 := by decide
theorem cert_e2392565271470 : check e2392565271470 [[],[.left]] .smaller = true := by decide
def e2392565271482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2392565271482 : Closed e2392565271482 ∧ code e2392565271482 = 11188658293690 := by decide
theorem cert_e2392565271482 : check e2392565271482 [[],[.left]] .smaller = true := by decide
def e2392565271510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2392565271510 : Closed e2392565271510 ∧ code e2392565271510 = 11188658293718 := by decide
theorem cert_e2392565271510 : check e2392565271510 [[],[.left]] .smaller = true := by decide
def e2392565271514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2392565271514 : Closed e2392565271514 ∧ code e2392565271514 = 11188658293722 := by decide
theorem cert_e2392565271514 : check e2392565271514 [[],[.left]] .smaller = true := by decide
def e2392565271790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2392565271790 : Closed e2392565271790 ∧ code e2392565271790 = 11188658293998 := by decide
theorem cert_e2392565271790 : check e2392565271790 [[],[.left]] .smaller = true := by decide
def e2392565271798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2392565271798 : Closed e2392565271798 ∧ code e2392565271798 = 11188658294006 := by decide
theorem cert_e2392565271798 : check e2392565271798 [[],[.left]] .smaller = true := by decide
def e2392565272174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2392565272174 : Closed e2392565272174 ∧ code e2392565272174 = 11188658294382 := by decide
theorem cert_e2392565272174 : check e2392565272174 [[],[.left]] .smaller = true := by decide
def e2392565272186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2392565272186 : Closed e2392565272186 ∧ code e2392565272186 = 11188658294394 := by decide
theorem cert_e2392565272186 : check e2392565272186 [[],[.left]] .smaller = true := by decide
def e2392565272374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2392565272374 : Closed e2392565272374 ∧ code e2392565272374 = 11188658294582 := by decide
theorem cert_e2392565272374 : check e2392565272374 [[],[.left]] .smaller = true := by decide
def e2392565272378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2392565272378 : Closed e2392565272378 ∧ code e2392565272378 = 11188658294586 := by decide
theorem cert_e2392565272378 : check e2392565272378 [[],[.left]] .smaller = true := by decide
def e2392565278126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2392565278126 : Closed e2392565278126 ∧ code e2392565278126 = 11188658300334 := by decide
theorem cert_e2392565278126 : check e2392565278126 [[],[.left]] .smaller = true := by decide
def e2392565278138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2392565278138 : Closed e2392565278138 ∧ code e2392565278138 = 11188658300346 := by decide
theorem cert_e2392565278138 : check e2392565278138 [[],[.left]] .smaller = true := by decide
def e2392565278186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2392565278186 : Closed e2392565278186 ∧ code e2392565278186 = 11188658300394 := by decide
theorem cert_e2392565278186 : check e2392565278186 [[],[.left]] .smaller = true := by decide
def e2392565278318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2392565278318 : Closed e2392565278318 ∧ code e2392565278318 = 11188658300526 := by decide
theorem cert_e2392565278318 : check e2392565278318 [[],[.left]] .smaller = true := by decide
def e2392565278330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2392565278330 : Closed e2392565278330 ∧ code e2392565278330 = 11188658300538 := by decide
theorem cert_e2392565278330 : check e2392565278330 [[],[.left]] .smaller = true := by decide
def e2392565278618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2392565278618 : Closed e2392565278618 ∧ code e2392565278618 = 11188658300826 := by decide
theorem cert_e2392565278618 : check e2392565278618 [[],[.left]] .smaller = true := by decide
def e2392565281494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2392565281494 : Closed e2392565281494 ∧ code e2392565281494 = 11188658303702 := by decide
theorem cert_e2392565281494 : check e2392565281494 [[],[.left]] .smaller = true := by decide
def e2392565281498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2392565281498 : Closed e2392565281498 ∧ code e2392565281498 = 11188658303706 := by decide
theorem cert_e2392565281498 : check e2392565281498 [[],[.left]] .smaller = true := by decide
def e2392565281514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2392565281514 : Closed e2392565281514 ∧ code e2392565281514 = 11188658303722 := by decide
theorem cert_e2392565281514 : check e2392565281514 [[],[.left]] .smaller = true := by decide
def e2392565281590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2392565281590 : Closed e2392565281590 ∧ code e2392565281590 = 11188658303798 := by decide
theorem cert_e2392565281590 : check e2392565281590 [[],[.left]] .smaller = true := by decide
def e2392565281594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2392565281594 : Closed e2392565281594 ∧ code e2392565281594 = 11188658303802 := by decide
theorem cert_e2392565281594 : check e2392565281594 [[],[.left]] .smaller = true := by decide
def e2392565281690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2392565281690 : Closed e2392565281690 ∧ code e2392565281690 = 11188658303898 := by decide
theorem cert_e2392565281690 : check e2392565281690 [[],[.left]] .smaller = true := by decide
def e2392565396958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2392565396958 : Closed e2392565396958 ∧ code e2392565396958 = 11188658419166 := by decide
theorem cert_e2392565396958 : check e2392565396958 [[],[.left]] .chain = true := by decide
def e2392565396974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2392565396974 : Closed e2392565396974 ∧ code e2392565396974 = 11188658419182 := by decide
theorem cert_e2392565396974 : check e2392565396974 [[],[.left]] .chain = true := by decide
def e2392565397214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2392565397214 : Closed e2392565397214 ∧ code e2392565397214 = 11188658419422 := by decide
theorem cert_e2392565397214 : check e2392565397214 [[],[.left]] .chain = true := by decide
def e2392565397230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2392565397230 : Closed e2392565397230 ∧ code e2392565397230 = 11188658419438 := by decide
theorem cert_e2392565397230 : check e2392565397230 [[],[.left]] .smaller = true := by decide
def e2392565397238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2392565397238 : Closed e2392565397238 ∧ code e2392565397238 = 11188658419446 := by decide
theorem cert_e2392565397238 : check e2392565397238 [[],[.left]] .chain = true := by decide
def e2392565397342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2392565397342 : Closed e2392565397342 ∧ code e2392565397342 = 11188658419550 := by decide
theorem cert_e2392565397342 : check e2392565397342 [[],[.left]] .chain = true := by decide
def e2392565397358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2392565397358 : Closed e2392565397358 ∧ code e2392565397358 = 11188658419566 := by decide
theorem cert_e2392565397358 : check e2392565397358 [[],[.left]] .smaller = true := by decide
def e2392565397366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2392565397366 : Closed e2392565397366 ∧ code e2392565397366 = 11188658419574 := by decide
theorem cert_e2392565397366 : check e2392565397366 [[],[.left]] .smaller = true := by decide
def e2392565397370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2392565397370 : Closed e2392565397370 ∧ code e2392565397370 = 11188658419578 := by decide
theorem cert_e2392565397370 : check e2392565397370 [[],[.left]] .chain = true := by decide
def e2392565397422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2392565397422 : Closed e2392565397422 ∧ code e2392565397422 = 11188658419630 := by decide
theorem cert_e2392565397422 : check e2392565397422 [[],[.left]] .chain = true := by decide
def e2392565397430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2392565397430 : Closed e2392565397430 ∧ code e2392565397430 = 11188658419638 := by decide
theorem cert_e2392565397430 : check e2392565397430 [[],[.left]] .chain = true := by decide
def e2392565397434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2392565397434 : Closed e2392565397434 ∧ code e2392565397434 = 11188658419642 := by decide
theorem cert_e2392565397434 : check e2392565397434 [[],[.left]] .chain = true := by decide
def e2392565398238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2392565398238 : Closed e2392565398238 ∧ code e2392565398238 = 11188658420446 := by decide
theorem cert_e2392565398238 : check e2392565398238 [[],[.left]] .chain = true := by decide
def e2392565398254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2392565398254 : Closed e2392565398254 ∧ code e2392565398254 = 11188658420462 := by decide
theorem cert_e2392565398254 : check e2392565398254 [[],[.left]] .smaller = true := by decide
def e2392565398262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2392565398262 : Closed e2392565398262 ∧ code e2392565398262 = 11188658420470 := by decide
theorem cert_e2392565398262 : check e2392565398262 [[],[.left]] .chain = true := by decide
def e2392565398366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2392565398366 : Closed e2392565398366 ∧ code e2392565398366 = 11188658420574 := by decide
theorem cert_e2392565398366 : check e2392565398366 [[],[.left]] .chain = true := by decide
def e2392565398394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2392565398394 : Closed e2392565398394 ∧ code e2392565398394 = 11188658420602 := by decide
theorem cert_e2392565398394 : check e2392565398394 [[],[.left]] .chain = true := by decide
def e2392565398446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2392565398446 : Closed e2392565398446 ∧ code e2392565398446 = 11188658420654 := by decide
theorem cert_e2392565398446 : check e2392565398446 [[],[.left]] .smaller = true := by decide
def e2392565398458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2392565398458 : Closed e2392565398458 ∧ code e2392565398458 = 11188658420666 := by decide
theorem cert_e2392565398458 : check e2392565398458 [[],[.left]] .smaller = true := by decide
def e2392565398486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2392565398486 : Closed e2392565398486 ∧ code e2392565398486 = 11188658420694 := by decide
theorem cert_e2392565398486 : check e2392565398486 [[],[.left]] .chain = true := by decide
def e2392565398490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2392565398490 : Closed e2392565398490 ∧ code e2392565398490 = 11188658420698 := by decide
theorem cert_e2392565398490 : check e2392565398490 [[],[.left]] .chain = true := by decide
def e2392565398878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2392565398878 : Closed e2392565398878 ∧ code e2392565398878 = 11188658421086 := by decide
theorem cert_e2392565398878 : check e2392565398878 [[],[.left]] .chain = true := by decide
def e2392565398894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2392565398894 : Closed e2392565398894 ∧ code e2392565398894 = 11188658421102 := by decide
theorem cert_e2392565398894 : check e2392565398894 [[],[.left]] .smaller = true := by decide
def e2392565398902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2392565398902 : Closed e2392565398902 ∧ code e2392565398902 = 11188658421110 := by decide
theorem cert_e2392565398902 : check e2392565398902 [[],[.left]] .smaller = true := by decide
def e2392565398906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2392565398906 : Closed e2392565398906 ∧ code e2392565398906 = 11188658421114 := by decide
theorem cert_e2392565398906 : check e2392565398906 [[],[.left]] .chain = true := by decide
def e2392565398958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2392565398958 : Closed e2392565398958 ∧ code e2392565398958 = 11188658421166 := by decide
theorem cert_e2392565398958 : check e2392565398958 [[],[.left]] .smaller = true := by decide
def e2392565398970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2392565398970 : Closed e2392565398970 ∧ code e2392565398970 = 11188658421178 := by decide
theorem cert_e2392565398970 : check e2392565398970 [[],[.left]] .smaller = true := by decide
def e2392565398998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2392565398998 : Closed e2392565398998 ∧ code e2392565398998 = 11188658421206 := by decide
theorem cert_e2392565398998 : check e2392565398998 [[],[.left]] .smaller = true := by decide
def e2392565399002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2392565399002 : Closed e2392565399002 ∧ code e2392565399002 = 11188658421210 := by decide
theorem cert_e2392565399002 : check e2392565399002 [[],[.left]] .smaller = true := by decide
def e2392565399018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2392565399018 : Closed e2392565399018 ∧ code e2392565399018 = 11188658421226 := by decide
theorem cert_e2392565399018 : check e2392565399018 [[],[.left]] .chain = true := by decide
def e2392565399214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2392565399214 : Closed e2392565399214 ∧ code e2392565399214 = 11188658421422 := by decide
theorem cert_e2392565399214 : check e2392565399214 [[],[.left]] .chain = true := by decide
def e2392565399222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2392565399222 : Closed e2392565399222 ∧ code e2392565399222 = 11188658421430 := by decide
theorem cert_e2392565399222 : check e2392565399222 [[],[.left]] .chain = true := by decide
def e2392565399226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2392565399226 : Closed e2392565399226 ∧ code e2392565399226 = 11188658421434 := by decide
theorem cert_e2392565399226 : check e2392565399226 [[],[.left]] .chain = true := by decide
def e2392565399254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2392565399254 : Closed e2392565399254 ∧ code e2392565399254 = 11188658421462 := by decide
theorem cert_e2392565399254 : check e2392565399254 [[],[.left]] .chain = true := by decide
def e2392565399258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2392565399258 : Closed e2392565399258 ∧ code e2392565399258 = 11188658421466 := by decide
theorem cert_e2392565399258 : check e2392565399258 [[],[.left]] .chain = true := by decide
def e2392565399274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2392565399274 : Closed e2392565399274 ∧ code e2392565399274 = 11188658421482 := by decide
theorem cert_e2392565399274 : check e2392565399274 [[],[.left]] .chain = true := by decide
def e2392565403102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2392565403102 : Closed e2392565403102 ∧ code e2392565403102 = 11188658425310 := by decide
theorem cert_e2392565403102 : check e2392565403102 [[],[.left]] .chain = true := by decide
def e2392565403118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2392565403118 : Closed e2392565403118 ∧ code e2392565403118 = 11188658425326 := by decide
theorem cert_e2392565403118 : check e2392565403118 [[],[.left]] .chain = true := by decide
def e2392565403358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2392565403358 : Closed e2392565403358 ∧ code e2392565403358 = 11188658425566 := by decide
theorem cert_e2392565403358 : check e2392565403358 [[],[.left]] .chain = true := by decide
def e2392565403374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2392565403374 : Closed e2392565403374 ∧ code e2392565403374 = 11188658425582 := by decide
theorem cert_e2392565403374 : check e2392565403374 [[],[.left]] .smaller = true := by decide
def e2392565403382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2392565403382 : Closed e2392565403382 ∧ code e2392565403382 = 11188658425590 := by decide
theorem cert_e2392565403382 : check e2392565403382 [[],[.left]] .chain = true := by decide
def e2392565403486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2392565403486 : Closed e2392565403486 ∧ code e2392565403486 = 11188658425694 := by decide
theorem cert_e2392565403486 : check e2392565403486 [[],[.left]] .chain = true := by decide
def e2392565403502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2392565403502 : Closed e2392565403502 ∧ code e2392565403502 = 11188658425710 := by decide
theorem cert_e2392565403502 : check e2392565403502 [[],[.left]] .smaller = true := by decide
def e2392565403510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2392565403510 : Closed e2392565403510 ∧ code e2392565403510 = 11188658425718 := by decide
theorem cert_e2392565403510 : check e2392565403510 [[],[.left]] .smaller = true := by decide
def e2392565403514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2392565403514 : Closed e2392565403514 ∧ code e2392565403514 = 11188658425722 := by decide
theorem cert_e2392565403514 : check e2392565403514 [[],[.left]] .chain = true := by decide
def e2392565403566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2392565403566 : Closed e2392565403566 ∧ code e2392565403566 = 11188658425774 := by decide
theorem cert_e2392565403566 : check e2392565403566 [[],[.left]] .chain = true := by decide
def e2392565403574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2392565403574 : Closed e2392565403574 ∧ code e2392565403574 = 11188658425782 := by decide
theorem cert_e2392565403574 : check e2392565403574 [[],[.left]] .chain = true := by decide
def e2392565403578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2392565403578 : Closed e2392565403578 ∧ code e2392565403578 = 11188658425786 := by decide
theorem cert_e2392565403578 : check e2392565403578 [[],[.left]] .chain = true := by decide
def e2392565404638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2392565404638 : Closed e2392565404638 ∧ code e2392565404638 = 11188658426846 := by decide
theorem cert_e2392565404638 : check e2392565404638 [[],[.left]] .chain = true := by decide
def e2392565404654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2392565404654 : Closed e2392565404654 ∧ code e2392565404654 = 11188658426862 := by decide
theorem cert_e2392565404654 : check e2392565404654 [[],[.left]] .chain = true := by decide
def e2392565406174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2392565406174 : Closed e2392565406174 ∧ code e2392565406174 = 11188658428382 := by decide
theorem cert_e2392565406174 : check e2392565406174 [[],[.left]] .chain = true := by decide
def e2392565406190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2392565406190 : Closed e2392565406190 ∧ code e2392565406190 = 11188658428398 := by decide
theorem cert_e2392565406190 : check e2392565406190 [[],[.left]] .smaller = true := by decide
def e2392565406198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2392565406198 : Closed e2392565406198 ∧ code e2392565406198 = 11188658428406 := by decide
theorem cert_e2392565406198 : check e2392565406198 [[],[.left]] .chain = true := by decide
def e2392565406942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2392565406942 : Closed e2392565406942 ∧ code e2392565406942 = 11188658429150 := by decide
theorem cert_e2392565406942 : check e2392565406942 [[],[.left]] .chain = true := by decide
def e2392565406958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392565406958 : Closed e2392565406958 ∧ code e2392565406958 = 11188658429166 := by decide
theorem cert_e2392565406958 : check e2392565406958 [[],[.left]] .smaller = true := by decide
def e2392565406966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392565406966 : Closed e2392565406966 ∧ code e2392565406966 = 11188658429174 := by decide
theorem cert_e2392565406966 : check e2392565406966 [[],[.left]] .smaller = true := by decide
def e2392565406970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2392565406970 : Closed e2392565406970 ∧ code e2392565406970 = 11188658429178 := by decide
theorem cert_e2392565406970 : check e2392565406970 [[],[.left]] .chain = true := by decide
def e2392565407342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392565407342 : Closed e2392565407342 ∧ code e2392565407342 = 11188658429550 := by decide
theorem cert_e2392565407342 : check e2392565407342 [[],[.left]] .chain = true := by decide
def e2392565407350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2392565407350 : Closed e2392565407350 ∧ code e2392565407350 = 11188658429558 := by decide
theorem cert_e2392565407350 : check e2392565407350 [[],[.left]] .chain = true := by decide
def e2392565407354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392565407354 : Closed e2392565407354 ∧ code e2392565407354 = 11188658429562 := by decide
theorem cert_e2392565407354 : check e2392565407354 [[],[.left]] .chain = true := by decide
def e2392565409502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2392565409502 : Closed e2392565409502 ∧ code e2392565409502 = 11188658431710 := by decide
theorem cert_e2392565409502 : check e2392565409502 [[],[.left]] .chain = true := by decide
def e2392565409518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2392565409518 : Closed e2392565409518 ∧ code e2392565409518 = 11188658431726 := by decide
theorem cert_e2392565409518 : check e2392565409518 [[],[.left]] .smaller = true := by decide
def e2392565409526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2392565409526 : Closed e2392565409526 ∧ code e2392565409526 = 11188658431734 := by decide
theorem cert_e2392565409526 : check e2392565409526 [[],[.left]] .chain = true := by decide
def e2392565409630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2392565409630 : Closed e2392565409630 ∧ code e2392565409630 = 11188658431838 := by decide
theorem cert_e2392565409630 : check e2392565409630 [[],[.left]] .chain = true := by decide
def e2392565409658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2392565409658 : Closed e2392565409658 ∧ code e2392565409658 = 11188658431866 := by decide
theorem cert_e2392565409658 : check e2392565409658 [[],[.left]] .chain = true := by decide
def e2392565409710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2392565409710 : Closed e2392565409710 ∧ code e2392565409710 = 11188658431918 := by decide
theorem cert_e2392565409710 : check e2392565409710 [[],[.left]] .smaller = true := by decide
def e2392565409722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2392565409722 : Closed e2392565409722 ∧ code e2392565409722 = 11188658431930 := by decide
theorem cert_e2392565409722 : check e2392565409722 [[],[.left]] .smaller = true := by decide
def e2392565409750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2392565409750 : Closed e2392565409750 ∧ code e2392565409750 = 11188658431958 := by decide
theorem cert_e2392565409750 : check e2392565409750 [[],[.left]] .chain = true := by decide
def e2392565409754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2392565409754 : Closed e2392565409754 ∧ code e2392565409754 = 11188658431962 := by decide
theorem cert_e2392565409754 : check e2392565409754 [[],[.left]] .chain = true := by decide
def e2392565410270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2392565410270 : Closed e2392565410270 ∧ code e2392565410270 = 11188658432478 := by decide
theorem cert_e2392565410270 : check e2392565410270 [[],[.left]] .chain = true := by decide
def e2392565410286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2392565410286 : Closed e2392565410286 ∧ code e2392565410286 = 11188658432494 := by decide
theorem cert_e2392565410286 : check e2392565410286 [[],[.left]] .smaller = true := by decide
def e2392565410294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2392565410294 : Closed e2392565410294 ∧ code e2392565410294 = 11188658432502 := by decide
theorem cert_e2392565410294 : check e2392565410294 [[],[.left]] .chain = true := by decide
def e2392565411038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2392565411038 : Closed e2392565411038 ∧ code e2392565411038 = 11188658433246 := by decide
theorem cert_e2392565411038 : check e2392565411038 [[],[.left]] .chain = true := by decide
def e2392565411066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2392565411066 : Closed e2392565411066 ∧ code e2392565411066 = 11188658433274 := by decide
theorem cert_e2392565411066 : check e2392565411066 [[],[.left]] .chain = true := by decide
def e2392565411438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392565411438 : Closed e2392565411438 ∧ code e2392565411438 = 11188658433646 := by decide
theorem cert_e2392565411438 : check e2392565411438 [[],[.left]] .smaller = true := by decide
def e2392565411450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392565411450 : Closed e2392565411450 ∧ code e2392565411450 = 11188658433658 := by decide
theorem cert_e2392565411450 : check e2392565411450 [[],[.left]] .smaller = true := by decide
def e2392565411638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392565411638 : Closed e2392565411638 ∧ code e2392565411638 = 11188658433846 := by decide
theorem cert_e2392565411638 : check e2392565411638 [[],[.left]] .chain = true := by decide
def e2392565411642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392565411642 : Closed e2392565411642 ∧ code e2392565411642 = 11188658433850 := by decide
theorem cert_e2392565411642 : check e2392565411642 [[],[.left]] .chain = true := by decide
def e2392565412702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2392565412702 : Closed e2392565412702 ∧ code e2392565412702 = 11188658434910 := by decide
theorem cert_e2392565412702 : check e2392565412702 [[],[.left]] .chain = true := by decide
def e2392565412718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2392565412718 : Closed e2392565412718 ∧ code e2392565412718 = 11188658434926 := by decide
theorem cert_e2392565412718 : check e2392565412718 [[],[.left]] .smaller = true := by decide
def e2392565412726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2392565412726 : Closed e2392565412726 ∧ code e2392565412726 = 11188658434934 := by decide
theorem cert_e2392565412726 : check e2392565412726 [[],[.left]] .smaller = true := by decide
def e2392565412730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2392565412730 : Closed e2392565412730 ∧ code e2392565412730 = 11188658434938 := by decide
theorem cert_e2392565412730 : check e2392565412730 [[],[.left]] .chain = true := by decide
def e2392565412782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2392565412782 : Closed e2392565412782 ∧ code e2392565412782 = 11188658434990 := by decide
theorem cert_e2392565412782 : check e2392565412782 [[],[.left]] .smaller = true := by decide
def e2392565412794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2392565412794 : Closed e2392565412794 ∧ code e2392565412794 = 11188658435002 := by decide
theorem cert_e2392565412794 : check e2392565412794 [[],[.left]] .smaller = true := by decide
def e2392565412822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2392565412822 : Closed e2392565412822 ∧ code e2392565412822 = 11188658435030 := by decide
theorem cert_e2392565412822 : check e2392565412822 [[],[.left]] .smaller = true := by decide
def e2392565412826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2392565412826 : Closed e2392565412826 ∧ code e2392565412826 = 11188658435034 := by decide
theorem cert_e2392565412826 : check e2392565412826 [[],[.left]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392515677114
#print axioms Blc.Floor43.cert_e2392515677146
