import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2261048667822 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2261048667822 : Closed e2261048667822 ∧ code e2261048667822 = 11057141690030 := by decide
theorem cert_e2261048667822 : check e2261048667822 [[],[.under]] .three = true := by decide
def e2261048667834 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2261048667834 : Closed e2261048667834 ∧ code e2261048667834 = 11057141690042 := by decide
theorem cert_e2261048667834 : check e2261048667834 [[],[.under]] .three = true := by decide
def e2261048667882 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2261048667882 : Closed e2261048667882 ∧ code e2261048667882 = 11057141690090 := by decide
theorem cert_e2261048667882 : check e2261048667882 [[],[.under]] .three = true := by decide
def e2261048667990 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2261048667990 : Closed e2261048667990 ∧ code e2261048667990 = 11057141690198 := by decide
theorem cert_e2261048667990 : check e2261048667990 [[],[.under]] .three = true := by decide
def e2261048667994 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2261048667994 : Closed e2261048667994 ∧ code e2261048667994 = 11057141690202 := by decide
theorem cert_e2261048667994 : check e2261048667994 [[],[.under]] .three = true := by decide
def e2261048668010 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2261048668010 : Closed e2261048668010 ∧ code e2261048668010 = 11057141690218 := by decide
theorem cert_e2261048668010 : check e2261048668010 [[],[.under]] .three = true := by decide
def e2261048669038 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2261048669038 : Closed e2261048669038 ∧ code e2261048669038 = 11057141691246 := by decide
theorem cert_e2261048669038 : check e2261048669038 [[],[.under]] .three = true := by decide
def e2261048669046 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2261048669046 : Closed e2261048669046 ∧ code e2261048669046 = 11057141691254 := by decide
theorem cert_e2261048669046 : check e2261048669046 [[],[.under]] .three = true := by decide
def e2261048669102 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2261048669102 : Closed e2261048669102 ∧ code e2261048669102 = 11057141691310 := by decide
theorem cert_e2261048669102 : check e2261048669102 [[],[.under]] .three = true := by decide
def e2261048669114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2261048669114 : Closed e2261048669114 ∧ code e2261048669114 = 11057141691322 := by decide
theorem cert_e2261048669114 : check e2261048669114 [[],[.under]] .three = true := by decide
def e2261048669142 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2261048669142 : Closed e2261048669142 ∧ code e2261048669142 = 11057141691350 := by decide
theorem cert_e2261048669142 : check e2261048669142 [[],[.under]] .three = true := by decide
def e2261048669146 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2261048669146 : Closed e2261048669146 ∧ code e2261048669146 = 11057141691354 := by decide
theorem cert_e2261048669146 : check e2261048669146 [[],[.under]] .three = true := by decide
def e2261048669422 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2261048669422 : Closed e2261048669422 ∧ code e2261048669422 = 11057141691630 := by decide
theorem cert_e2261048669422 : check e2261048669422 [[],[.under]] .three = true := by decide
def e2261048669430 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2261048669430 : Closed e2261048669430 ∧ code e2261048669430 = 11057141691638 := by decide
theorem cert_e2261048669430 : check e2261048669430 [[],[.under]] .three = true := by decide
def e2261048669806 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2261048669806 : Closed e2261048669806 ∧ code e2261048669806 = 11057141692014 := by decide
theorem cert_e2261048669806 : check e2261048669806 [[],[.under]] .three = true := by decide
def e2261048669818 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2261048669818 : Closed e2261048669818 ∧ code e2261048669818 = 11057141692026 := by decide
theorem cert_e2261048669818 : check e2261048669818 [[],[.under]] .three = true := by decide
def e2261048670006 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2261048670006 : Closed e2261048670006 ∧ code e2261048670006 = 11057141692214 := by decide
theorem cert_e2261048670006 : check e2261048670006 [[],[.under]] .three = true := by decide
def e2261048670010 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2261048670010 : Closed e2261048670010 ∧ code e2261048670010 = 11057141692218 := by decide
theorem cert_e2261048670010 : check e2261048670010 [[],[.under]] .three = true := by decide
def e2261048670638 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2261048670638 : Closed e2261048670638 ∧ code e2261048670638 = 11057141692846 := by decide
theorem cert_e2261048670638 : check e2261048670638 [[],[.under]] .three = true := by decide
def e2261048670650 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2261048670650 : Closed e2261048670650 ∧ code e2261048670650 = 11057141692858 := by decide
theorem cert_e2261048670650 : check e2261048670650 [[],[.under]] .three = true := by decide
def e2261048670698 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2261048670698 : Closed e2261048670698 ∧ code e2261048670698 = 11057141692906 := by decide
theorem cert_e2261048670698 : check e2261048670698 [[],[.under]] .three = true := by decide
def e2261048670830 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2261048670830 : Closed e2261048670830 ∧ code e2261048670830 = 11057141693038 := by decide
theorem cert_e2261048670830 : check e2261048670830 [[],[.under]] .three = true := by decide
def e2261048670842 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2261048670842 : Closed e2261048670842 ∧ code e2261048670842 = 11057141693050 := by decide
theorem cert_e2261048670842 : check e2261048670842 [[],[.under]] .three = true := by decide
def e2261048671130 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2261048671130 : Closed e2261048671130 ∧ code e2261048671130 = 11057141693338 := by decide
theorem cert_e2261048671130 : check e2261048671130 [[],[.under]] .three = true := by decide
def e2261048671446 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2261048671446 : Closed e2261048671446 ∧ code e2261048671446 = 11057141693654 := by decide
theorem cert_e2261048671446 : check e2261048671446 [[],[.under]] .three = true := by decide
def e2261048671450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2261048671450 : Closed e2261048671450 ∧ code e2261048671450 = 11057141693658 := by decide
theorem cert_e2261048671450 : check e2261048671450 [[],[.under]] .three = true := by decide
def e2261048671466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2261048671466 : Closed e2261048671466 ∧ code e2261048671466 = 11057141693674 := by decide
theorem cert_e2261048671466 : check e2261048671466 [[],[.under]] .three = true := by decide
def e2261048671542 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2261048671542 : Closed e2261048671542 ∧ code e2261048671542 = 11057141693750 := by decide
theorem cert_e2261048671542 : check e2261048671542 [[],[.under]] .three = true := by decide
def e2261048671546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2261048671546 : Closed e2261048671546 ∧ code e2261048671546 = 11057141693754 := by decide
theorem cert_e2261048671546 : check e2261048671546 [[],[.under]] .three = true := by decide
def e2261048671642 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2261048671642 : Closed e2261048671642 ∧ code e2261048671642 = 11057141693850 := by decide
theorem cert_e2261048671642 : check e2261048671642 [[],[.under]] .three = true := by decide
def e2261048675182 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2261048675182 : Closed e2261048675182 ∧ code e2261048675182 = 11057141697390 := by decide
theorem cert_e2261048675182 : check e2261048675182 [[],[.under]] .three = true := by decide
def e2261048675190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2261048675190 : Closed e2261048675190 ∧ code e2261048675190 = 11057141697398 := by decide
theorem cert_e2261048675190 : check e2261048675190 [[],[.under]] .three = true := by decide
def e2261048675246 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2261048675246 : Closed e2261048675246 ∧ code e2261048675246 = 11057141697454 := by decide
theorem cert_e2261048675246 : check e2261048675246 [[],[.under]] .three = true := by decide
def e2261048675258 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2261048675258 : Closed e2261048675258 ∧ code e2261048675258 = 11057141697466 := by decide
theorem cert_e2261048675258 : check e2261048675258 [[],[.under]] .three = true := by decide
def e2261048675286 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2261048675286 : Closed e2261048675286 ∧ code e2261048675286 = 11057141697494 := by decide
theorem cert_e2261048675286 : check e2261048675286 [[],[.under]] .three = true := by decide
def e2261048675290 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2261048675290 : Closed e2261048675290 ∧ code e2261048675290 = 11057141697498 := by decide
theorem cert_e2261048675290 : check e2261048675290 [[],[.under]] .three = true := by decide
def e2261048675566 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2261048675566 : Closed e2261048675566 ∧ code e2261048675566 = 11057141697774 := by decide
theorem cert_e2261048675566 : check e2261048675566 [[],[.under]] .three = true := by decide
def e2261048675574 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2261048675574 : Closed e2261048675574 ∧ code e2261048675574 = 11057141697782 := by decide
theorem cert_e2261048675574 : check e2261048675574 [[],[.under]] .three = true := by decide
def e2261048675950 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2261048675950 : Closed e2261048675950 ∧ code e2261048675950 = 11057141698158 := by decide
theorem cert_e2261048675950 : check e2261048675950 [[],[.under]] .three = true := by decide
def e2261048675962 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2261048675962 : Closed e2261048675962 ∧ code e2261048675962 = 11057141698170 := by decide
theorem cert_e2261048675962 : check e2261048675962 [[],[.under]] .three = true := by decide
def e2261048676150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2261048676150 : Closed e2261048676150 ∧ code e2261048676150 = 11057141698358 := by decide
theorem cert_e2261048676150 : check e2261048676150 [[],[.under]] .three = true := by decide
def e2261048676154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2261048676154 : Closed e2261048676154 ∧ code e2261048676154 = 11057141698362 := by decide
theorem cert_e2261048676154 : check e2261048676154 [[],[.under]] .three = true := by decide
def e2261048681902 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2261048681902 : Closed e2261048681902 ∧ code e2261048681902 = 11057141704110 := by decide
theorem cert_e2261048681902 : check e2261048681902 [[],[.under]] .three = true := by decide
def e2261048681914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2261048681914 : Closed e2261048681914 ∧ code e2261048681914 = 11057141704122 := by decide
theorem cert_e2261048681914 : check e2261048681914 [[],[.under]] .three = true := by decide
def e2261048681962 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2261048681962 : Closed e2261048681962 ∧ code e2261048681962 = 11057141704170 := by decide
theorem cert_e2261048681962 : check e2261048681962 [[],[.under]] .three = true := by decide
def e2261048682094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2261048682094 : Closed e2261048682094 ∧ code e2261048682094 = 11057141704302 := by decide
theorem cert_e2261048682094 : check e2261048682094 [[],[.under]] .three = true := by decide
def e2261048682106 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2261048682106 : Closed e2261048682106 ∧ code e2261048682106 = 11057141704314 := by decide
theorem cert_e2261048682106 : check e2261048682106 [[],[.under]] .three = true := by decide
def e2261048682394 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2261048682394 : Closed e2261048682394 ∧ code e2261048682394 = 11057141704602 := by decide
theorem cert_e2261048682394 : check e2261048682394 [[],[.under]] .three = true := by decide
def e2261048685270 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2261048685270 : Closed e2261048685270 ∧ code e2261048685270 = 11057141707478 := by decide
theorem cert_e2261048685270 : check e2261048685270 [[],[.under]] .three = true := by decide
def e2261048685274 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2261048685274 : Closed e2261048685274 ∧ code e2261048685274 = 11057141707482 := by decide
theorem cert_e2261048685274 : check e2261048685274 [[],[.under]] .three = true := by decide
def e2261048685290 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2261048685290 : Closed e2261048685290 ∧ code e2261048685290 = 11057141707498 := by decide
theorem cert_e2261048685290 : check e2261048685290 [[],[.under]] .three = true := by decide
def e2261048685366 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2261048685366 : Closed e2261048685366 ∧ code e2261048685366 = 11057141707574 := by decide
theorem cert_e2261048685366 : check e2261048685366 [[],[.under]] .three = true := by decide
def e2261048685370 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2261048685370 : Closed e2261048685370 ∧ code e2261048685370 = 11057141707578 := by decide
theorem cert_e2261048685370 : check e2261048685370 [[],[.under]] .three = true := by decide
def e2261048685466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2261048685466 : Closed e2261048685466 ∧ code e2261048685466 = 11057141707674 := by decide
theorem cert_e2261048685466 : check e2261048685466 [[],[.under]] .three = true := by decide
def e2261048822638 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2261048822638 : Closed e2261048822638 ∧ code e2261048822638 = 11057141844846 := by decide
theorem cert_e2261048822638 : check e2261048822638 [[],[.under]] .chain = true := by decide
def e2261048822646 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2261048822646 : Closed e2261048822646 ∧ code e2261048822646 = 11057141844854 := by decide
theorem cert_e2261048822646 : check e2261048822646 [[],[.under]] .chain = true := by decide
def e2261048822702 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2261048822702 : Closed e2261048822702 ∧ code e2261048822702 = 11057141844910 := by decide
theorem cert_e2261048822702 : check e2261048822702 [[],[.under]] .chain = true := by decide
def e2261048822714 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2261048822714 : Closed e2261048822714 ∧ code e2261048822714 = 11057141844922 := by decide
theorem cert_e2261048822714 : check e2261048822714 [[],[.under]] .chain = true := by decide
def e2261048822742 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2261048822742 : Closed e2261048822742 ∧ code e2261048822742 = 11057141844950 := by decide
theorem cert_e2261048822742 : check e2261048822742 [[],[.under]] .chain = true := by decide
def e2261048822746 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2261048822746 : Closed e2261048822746 ∧ code e2261048822746 = 11057141844954 := by decide
theorem cert_e2261048822746 : check e2261048822746 [[],[.under]] .chain = true := by decide
def e2261048823022 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2261048823022 : Closed e2261048823022 ∧ code e2261048823022 = 11057141845230 := by decide
theorem cert_e2261048823022 : check e2261048823022 [[],[.under]] .chain = true := by decide
def e2261048823030 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2261048823030 : Closed e2261048823030 ∧ code e2261048823030 = 11057141845238 := by decide
theorem cert_e2261048823030 : check e2261048823030 [[],[.under]] .chain = true := by decide
def e2261048823406 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2261048823406 : Closed e2261048823406 ∧ code e2261048823406 = 11057141845614 := by decide
theorem cert_e2261048823406 : check e2261048823406 [[],[.under]] .chain = true := by decide
def e2261048823418 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2261048823418 : Closed e2261048823418 ∧ code e2261048823418 = 11057141845626 := by decide
theorem cert_e2261048823418 : check e2261048823418 [[],[.under]] .chain = true := by decide
def e2261048823606 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2261048823606 : Closed e2261048823606 ∧ code e2261048823606 = 11057141845814 := by decide
theorem cert_e2261048823606 : check e2261048823606 [[],[.under]] .chain = true := by decide
def e2261048823610 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2261048823610 : Closed e2261048823610 ∧ code e2261048823610 = 11057141845818 := by decide
theorem cert_e2261048823610 : check e2261048823610 [[],[.under]] .chain = true := by decide
def e2261049412462 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2261049412462 : Closed e2261049412462 ∧ code e2261049412462 = 11057142434670 := by decide
theorem cert_e2261049412462 : check e2261049412462 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049412470 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2261049412470 : Closed e2261049412470 ∧ code e2261049412470 = 11057142434678 := by decide
theorem cert_e2261049412470 : check e2261049412470 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049412526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2261049412526 : Closed e2261049412526 ∧ code e2261049412526 = 11057142434734 := by decide
theorem cert_e2261049412526 : check e2261049412526 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049412538 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2261049412538 : Closed e2261049412538 ∧ code e2261049412538 = 11057142434746 := by decide
theorem cert_e2261049412538 : check e2261049412538 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049412566 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2261049412566 : Closed e2261049412566 ∧ code e2261049412566 = 11057142434774 := by decide
theorem cert_e2261049412566 : check e2261049412566 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049412570 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2261049412570 : Closed e2261049412570 ∧ code e2261049412570 = 11057142434778 := by decide
theorem cert_e2261049412570 : check e2261049412570 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049412846 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2261049412846 : Closed e2261049412846 ∧ code e2261049412846 = 11057142435054 := by decide
theorem cert_e2261049412846 : check e2261049412846 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049412854 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2261049412854 : Closed e2261049412854 ∧ code e2261049412854 = 11057142435062 := by decide
theorem cert_e2261049412854 : check e2261049412854 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049413230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2261049413230 : Closed e2261049413230 ∧ code e2261049413230 = 11057142435438 := by decide
theorem cert_e2261049413230 : check e2261049413230 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049413242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2261049413242 : Closed e2261049413242 ∧ code e2261049413242 = 11057142435450 := by decide
theorem cert_e2261049413242 : check e2261049413242 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049413430 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2261049413430 : Closed e2261049413430 ∧ code e2261049413430 = 11057142435638 := by decide
theorem cert_e2261049413430 : check e2261049413430 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261049413434 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2261049413434 : Closed e2261049413434 ∧ code e2261049413434 = 11057142435642 := by decide
theorem cert_e2261049413434 : check e2261049413434 [[],[.under],[.under,.left]] .chain = true := by decide
def e2261082926618 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261082926618 : Closed e2261082926618 ∧ code e2261082926618 = 11057175948826 := by decide
theorem cert_e2261082926618 : check e2261082926618 [[]] .width = true := by decide
def e2261082928666 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261082928666 : Closed e2261082928666 ∧ code e2261082928666 = 11057175950874 := by decide
theorem cert_e2261082928666 : check e2261082928666 [[]] .width = true := by decide
def e2261082943002 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261082943002 : Closed e2261082943002 ∧ code e2261082943002 = 11057175965210 := by decide
theorem cert_e2261082943002 : check e2261082943002 [[]] .width = true := by decide
def e2261082946074 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261082946074 : Closed e2261082946074 ∧ code e2261082946074 = 11057175968282 := by decide
theorem cert_e2261082946074 : check e2261082946074 [[]] .width = true := by decide
def e2261082953242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261082953242 : Closed e2261082953242 ∧ code e2261082953242 = 11057175975450 := by decide
theorem cert_e2261082953242 : check e2261082953242 [[]] .width = true := by decide
def e2261082954266 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261082954266 : Closed e2261082954266 ∧ code e2261082954266 = 11057175976474 := by decide
theorem cert_e2261082954266 : check e2261082954266 [[]] .width = true := by decide
def e2261083024922 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261083024922 : Closed e2261083024922 ∧ code e2261083024922 = 11057176047130 := by decide
theorem cert_e2261083024922 : check e2261083024922 [[]] .width = true := by decide
def e2261083026970 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261083026970 : Closed e2261083026970 ∧ code e2261083026970 = 11057176049178 := by decide
theorem cert_e2261083026970 : check e2261083026970 [[]] .width = true := by decide
def e2261083123226 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261083123226 : Closed e2261083123226 ∧ code e2261083123226 = 11057176145434 := by decide
theorem cert_e2261083123226 : check e2261083123226 [[]] .width = true := by decide
def e2261083126298 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261083126298 : Closed e2261083126298 ∧ code e2261083126298 = 11057176148506 := by decide
theorem cert_e2261083126298 : check e2261083126298 [[]] .width = true := by decide
def e2261083174426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261083174426 : Closed e2261083174426 ∧ code e2261083174426 = 11057176196634 := by decide
theorem cert_e2261083174426 : check e2261083174426 [[]] .width = true := by decide
def e2261083175450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261083175450 : Closed e2261083175450 ∧ code e2261083175450 = 11057176197658 := by decide
theorem cert_e2261083175450 : check e2261083175450 [[]] .width = true := by decide
def e2261098999150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2261098999150 : Closed e2261098999150 ∧ code e2261098999150 = 11057192021358 := by decide
theorem cert_e2261098999150 : check e2261098999150 [[],[.under]] .smaller = true := by decide
def e2261098999158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2261098999158 : Closed e2261098999158 ∧ code e2261098999158 = 11057192021366 := by decide
theorem cert_e2261098999158 : check e2261098999158 [[],[.under]] .smaller = true := by decide
def e2261098999214 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2261098999214 : Closed e2261098999214 ∧ code e2261098999214 = 11057192021422 := by decide
theorem cert_e2261098999214 : check e2261098999214 [[],[.under]] .smaller = true := by decide
def e2261098999226 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2261098999226 : Closed e2261098999226 ∧ code e2261098999226 = 11057192021434 := by decide
theorem cert_e2261098999226 : check e2261098999226 [[],[.under]] .smaller = true := by decide
def e2261098999254 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2261098999254 : Closed e2261098999254 ∧ code e2261098999254 = 11057192021462 := by decide
theorem cert_e2261098999254 : check e2261098999254 [[],[.under]] .smaller = true := by decide
def e2261098999258 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2261098999258 : Closed e2261098999258 ∧ code e2261098999258 = 11057192021466 := by decide
theorem cert_e2261098999258 : check e2261098999258 [[],[.under]] .smaller = true := by decide
def e2261098999470 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2261098999470 : Closed e2261098999470 ∧ code e2261098999470 = 11057192021678 := by decide
theorem cert_e2261098999470 : check e2261098999470 [[],[.under]] .smaller = true := by decide
def e2261098999482 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2261098999482 : Closed e2261098999482 ∧ code e2261098999482 = 11057192021690 := by decide
theorem cert_e2261098999482 : check e2261098999482 [[],[.under]] .smaller = true := by decide
def e2261098999530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2261098999530 : Closed e2261098999530 ∧ code e2261098999530 = 11057192021738 := by decide
theorem cert_e2261098999530 : check e2261098999530 [[],[.under]] .smaller = true := by decide
def e2261098999638 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2261098999638 : Closed e2261098999638 ∧ code e2261098999638 = 11057192021846 := by decide
theorem cert_e2261098999638 : check e2261098999638 [[],[.under]] .smaller = true := by decide
def e2261098999642 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2261098999642 : Closed e2261098999642 ∧ code e2261098999642 = 11057192021850 := by decide
theorem cert_e2261098999642 : check e2261098999642 [[],[.under]] .smaller = true := by decide
def e2261098999658 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2261098999658 : Closed e2261098999658 ∧ code e2261098999658 = 11057192021866 := by decide
theorem cert_e2261098999658 : check e2261098999658 [[],[.under]] .smaller = true := by decide
def e2261099000686 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2261099000686 : Closed e2261099000686 ∧ code e2261099000686 = 11057192022894 := by decide
theorem cert_e2261099000686 : check e2261099000686 [[],[.under]] .smaller = true := by decide
def e2261099000694 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2261099000694 : Closed e2261099000694 ∧ code e2261099000694 = 11057192022902 := by decide
theorem cert_e2261099000694 : check e2261099000694 [[],[.under]] .smaller = true := by decide
def e2261099000750 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2261099000750 : Closed e2261099000750 ∧ code e2261099000750 = 11057192022958 := by decide
theorem cert_e2261099000750 : check e2261099000750 [[],[.under]] .smaller = true := by decide
def e2261099000762 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2261099000762 : Closed e2261099000762 ∧ code e2261099000762 = 11057192022970 := by decide
theorem cert_e2261099000762 : check e2261099000762 [[],[.under]] .smaller = true := by decide
def e2261099000790 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2261099000790 : Closed e2261099000790 ∧ code e2261099000790 = 11057192022998 := by decide
theorem cert_e2261099000790 : check e2261099000790 [[],[.under]] .smaller = true := by decide
def e2261099000794 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2261099000794 : Closed e2261099000794 ∧ code e2261099000794 = 11057192023002 := by decide
theorem cert_e2261099000794 : check e2261099000794 [[],[.under]] .smaller = true := by decide
def e2261099001070 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2261099001070 : Closed e2261099001070 ∧ code e2261099001070 = 11057192023278 := by decide
theorem cert_e2261099001070 : check e2261099001070 [[],[.under]] .smaller = true := by decide
def e2261099001078 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2261099001078 : Closed e2261099001078 ∧ code e2261099001078 = 11057192023286 := by decide
theorem cert_e2261099001078 : check e2261099001078 [[],[.under]] .smaller = true := by decide
def e2261099001454 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2261099001454 : Closed e2261099001454 ∧ code e2261099001454 = 11057192023662 := by decide
theorem cert_e2261099001454 : check e2261099001454 [[],[.under]] .smaller = true := by decide
def e2261099001466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2261099001466 : Closed e2261099001466 ∧ code e2261099001466 = 11057192023674 := by decide
theorem cert_e2261099001466 : check e2261099001466 [[],[.under]] .smaller = true := by decide
def e2261099001654 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2261099001654 : Closed e2261099001654 ∧ code e2261099001654 = 11057192023862 := by decide
theorem cert_e2261099001654 : check e2261099001654 [[],[.under]] .smaller = true := by decide
def e2261099001658 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2261099001658 : Closed e2261099001658 ∧ code e2261099001658 = 11057192023866 := by decide
theorem cert_e2261099001658 : check e2261099001658 [[],[.under]] .smaller = true := by decide
def e2261099002286 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2261099002286 : Closed e2261099002286 ∧ code e2261099002286 = 11057192024494 := by decide
theorem cert_e2261099002286 : check e2261099002286 [[],[.under]] .smaller = true := by decide
def e2261099002298 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2261099002298 : Closed e2261099002298 ∧ code e2261099002298 = 11057192024506 := by decide
theorem cert_e2261099002298 : check e2261099002298 [[],[.under]] .smaller = true := by decide
def e2261099002346 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2261099002346 : Closed e2261099002346 ∧ code e2261099002346 = 11057192024554 := by decide
theorem cert_e2261099002346 : check e2261099002346 [[],[.under]] .smaller = true := by decide
def e2261099002478 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2261099002478 : Closed e2261099002478 ∧ code e2261099002478 = 11057192024686 := by decide
theorem cert_e2261099002478 : check e2261099002478 [[],[.under]] .smaller = true := by decide
def e2261099002490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2261099002490 : Closed e2261099002490 ∧ code e2261099002490 = 11057192024698 := by decide
theorem cert_e2261099002490 : check e2261099002490 [[],[.under]] .smaller = true := by decide
def e2261099002778 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2261099002778 : Closed e2261099002778 ∧ code e2261099002778 = 11057192024986 := by decide
theorem cert_e2261099002778 : check e2261099002778 [[],[.under]] .smaller = true := by decide
def e2261099003094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2261099003094 : Closed e2261099003094 ∧ code e2261099003094 = 11057192025302 := by decide
theorem cert_e2261099003094 : check e2261099003094 [[],[.under]] .smaller = true := by decide
def e2261099003098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2261099003098 : Closed e2261099003098 ∧ code e2261099003098 = 11057192025306 := by decide
theorem cert_e2261099003098 : check e2261099003098 [[],[.under]] .smaller = true := by decide
def e2261099003114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2261099003114 : Closed e2261099003114 ∧ code e2261099003114 = 11057192025322 := by decide
theorem cert_e2261099003114 : check e2261099003114 [[],[.under]] .smaller = true := by decide
def e2261099003190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2261099003190 : Closed e2261099003190 ∧ code e2261099003190 = 11057192025398 := by decide
theorem cert_e2261099003190 : check e2261099003190 [[],[.under]] .smaller = true := by decide
def e2261099003194 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2261099003194 : Closed e2261099003194 ∧ code e2261099003194 = 11057192025402 := by decide
theorem cert_e2261099003194 : check e2261099003194 [[],[.under]] .smaller = true := by decide
def e2261099003290 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2261099003290 : Closed e2261099003290 ∧ code e2261099003290 = 11057192025498 := by decide
theorem cert_e2261099003290 : check e2261099003290 [[],[.under]] .smaller = true := by decide
def e2261099006830 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2261099006830 : Closed e2261099006830 ∧ code e2261099006830 = 11057192029038 := by decide
theorem cert_e2261099006830 : check e2261099006830 [[],[.under]] .smaller = true := by decide
def e2261099006838 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2261099006838 : Closed e2261099006838 ∧ code e2261099006838 = 11057192029046 := by decide
theorem cert_e2261099006838 : check e2261099006838 [[],[.under]] .smaller = true := by decide
def e2261099006894 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2261099006894 : Closed e2261099006894 ∧ code e2261099006894 = 11057192029102 := by decide
theorem cert_e2261099006894 : check e2261099006894 [[],[.under]] .smaller = true := by decide
def e2261099006906 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2261099006906 : Closed e2261099006906 ∧ code e2261099006906 = 11057192029114 := by decide
theorem cert_e2261099006906 : check e2261099006906 [[],[.under]] .smaller = true := by decide
def e2261099006934 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2261099006934 : Closed e2261099006934 ∧ code e2261099006934 = 11057192029142 := by decide
theorem cert_e2261099006934 : check e2261099006934 [[],[.under]] .smaller = true := by decide
def e2261099006938 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2261099006938 : Closed e2261099006938 ∧ code e2261099006938 = 11057192029146 := by decide
theorem cert_e2261099006938 : check e2261099006938 [[],[.under]] .smaller = true := by decide
def e2261099007214 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2261099007214 : Closed e2261099007214 ∧ code e2261099007214 = 11057192029422 := by decide
theorem cert_e2261099007214 : check e2261099007214 [[],[.under]] .smaller = true := by decide
def e2261099007222 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2261099007222 : Closed e2261099007222 ∧ code e2261099007222 = 11057192029430 := by decide
theorem cert_e2261099007222 : check e2261099007222 [[],[.under]] .smaller = true := by decide
def e2261099007598 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2261099007598 : Closed e2261099007598 ∧ code e2261099007598 = 11057192029806 := by decide
theorem cert_e2261099007598 : check e2261099007598 [[],[.under]] .smaller = true := by decide
def e2261099007610 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2261099007610 : Closed e2261099007610 ∧ code e2261099007610 = 11057192029818 := by decide
theorem cert_e2261099007610 : check e2261099007610 [[],[.under]] .smaller = true := by decide
def e2261099007798 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2261099007798 : Closed e2261099007798 ∧ code e2261099007798 = 11057192030006 := by decide
theorem cert_e2261099007798 : check e2261099007798 [[],[.under]] .smaller = true := by decide
def e2261099007802 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2261099007802 : Closed e2261099007802 ∧ code e2261099007802 = 11057192030010 := by decide
theorem cert_e2261099007802 : check e2261099007802 [[],[.under]] .smaller = true := by decide
def e2261099013550 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2261099013550 : Closed e2261099013550 ∧ code e2261099013550 = 11057192035758 := by decide
theorem cert_e2261099013550 : check e2261099013550 [[],[.under]] .smaller = true := by decide
def e2261099013562 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2261099013562 : Closed e2261099013562 ∧ code e2261099013562 = 11057192035770 := by decide
theorem cert_e2261099013562 : check e2261099013562 [[],[.under]] .smaller = true := by decide
def e2261099013610 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2261099013610 : Closed e2261099013610 ∧ code e2261099013610 = 11057192035818 := by decide
theorem cert_e2261099013610 : check e2261099013610 [[],[.under]] .smaller = true := by decide
def e2261099013742 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2261099013742 : Closed e2261099013742 ∧ code e2261099013742 = 11057192035950 := by decide
theorem cert_e2261099013742 : check e2261099013742 [[],[.under]] .smaller = true := by decide
def e2261099013754 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2261099013754 : Closed e2261099013754 ∧ code e2261099013754 = 11057192035962 := by decide
theorem cert_e2261099013754 : check e2261099013754 [[],[.under]] .smaller = true := by decide
def e2261099014042 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2261099014042 : Closed e2261099014042 ∧ code e2261099014042 = 11057192036250 := by decide
theorem cert_e2261099014042 : check e2261099014042 [[],[.under]] .smaller = true := by decide
def e2261099016918 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2261099016918 : Closed e2261099016918 ∧ code e2261099016918 = 11057192039126 := by decide
theorem cert_e2261099016918 : check e2261099016918 [[],[.under]] .smaller = true := by decide
def e2261099016922 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2261099016922 : Closed e2261099016922 ∧ code e2261099016922 = 11057192039130 := by decide
theorem cert_e2261099016922 : check e2261099016922 [[],[.under]] .smaller = true := by decide
def e2261099016938 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2261099016938 : Closed e2261099016938 ∧ code e2261099016938 = 11057192039146 := by decide
theorem cert_e2261099016938 : check e2261099016938 [[],[.under]] .smaller = true := by decide
def e2261099017014 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2261099017014 : Closed e2261099017014 ∧ code e2261099017014 = 11057192039222 := by decide
theorem cert_e2261099017014 : check e2261099017014 [[],[.under]] .smaller = true := by decide
def e2261099017018 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2261099017018 : Closed e2261099017018 ∧ code e2261099017018 = 11057192039226 := by decide
theorem cert_e2261099017018 : check e2261099017018 [[],[.under]] .smaller = true := by decide
def e2261099017114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2261099017114 : Closed e2261099017114 ∧ code e2261099017114 = 11057192039322 := by decide
theorem cert_e2261099017114 : check e2261099017114 [[],[.under]] .smaller = true := by decide
def e2261099132654 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2261099132654 : Closed e2261099132654 ∧ code e2261099132654 = 11057192154862 := by decide
theorem cert_e2261099132654 : check e2261099132654 [[],[.under]] .three = true := by decide
def e2261099132782 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2261099132782 : Closed e2261099132782 ∧ code e2261099132782 = 11057192154990 := by decide
theorem cert_e2261099132782 : check e2261099132782 [[],[.under]] .three = true := by decide
def e2261099132790 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2261099132790 : Closed e2261099132790 ∧ code e2261099132790 = 11057192154998 := by decide
theorem cert_e2261099132790 : check e2261099132790 [[],[.under]] .three = true := by decide
def e2261099133678 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2261099133678 : Closed e2261099133678 ∧ code e2261099133678 = 11057192155886 := by decide
theorem cert_e2261099133678 : check e2261099133678 [[],[.under]] .three = true := by decide
def e2261099133870 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2261099133870 : Closed e2261099133870 ∧ code e2261099133870 = 11057192156078 := by decide
theorem cert_e2261099133870 : check e2261099133870 [[],[.under]] .three = true := by decide
def e2261099133882 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2261099133882 : Closed e2261099133882 ∧ code e2261099133882 = 11057192156090 := by decide
theorem cert_e2261099133882 : check e2261099133882 [[],[.under]] .three = true := by decide
def e2261099134318 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2261099134318 : Closed e2261099134318 ∧ code e2261099134318 = 11057192156526 := by decide
theorem cert_e2261099134318 : check e2261099134318 [[],[.under]] .three = true := by decide
def e2261099134326 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2261099134326 : Closed e2261099134326 ∧ code e2261099134326 = 11057192156534 := by decide
theorem cert_e2261099134326 : check e2261099134326 [[],[.under]] .three = true := by decide
def e2261099134382 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2261099134382 : Closed e2261099134382 ∧ code e2261099134382 = 11057192156590 := by decide
theorem cert_e2261099134382 : check e2261099134382 [[],[.under]] .three = true := by decide
def e2261099134394 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2261099134394 : Closed e2261099134394 ∧ code e2261099134394 = 11057192156602 := by decide
theorem cert_e2261099134394 : check e2261099134394 [[],[.under]] .three = true := by decide
end Blc.Floor43
