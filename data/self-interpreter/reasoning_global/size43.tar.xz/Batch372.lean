import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364387246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)) (.var 2))))))))
theorem wire_e2422364387246 : Closed e2422364387246 ∧ code e2422364387246 = 11218457409454 := by decide
theorem cert_e2422364387246 : check e2422364387246 [[],[]] .smaller = true := by decide
def e2422364387254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 1))))))))
theorem wire_e2422364387254 : Closed e2422364387254 ∧ code e2422364387254 = 11218457409462 := by decide
theorem cert_e2422364387254 : check e2422364387254 [[],[]] .smaller = true := by decide
def e2422364387258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)) (.var 0))))))))
theorem wire_e2422364387258 : Closed e2422364387258 ∧ code e2422364387258 = 11218457409466 := by decide
theorem cert_e2422364387258 : check e2422364387258 [[],[]] .smaller = true := by decide
def e2422364387286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 0)) (.var 1))))))))
theorem wire_e2422364387286 : Closed e2422364387286 ∧ code e2422364387286 = 11218457409494 := by decide
theorem cert_e2422364387286 : check e2422364387286 [[],[]] .three = true := by decide
def e2422364387290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1)) (.var 0))))))))
theorem wire_e2422364387290 : Closed e2422364387290 ∧ code e2422364387290 = 11218457409498 := by decide
theorem cert_e2422364387290 : check e2422364387290 [[],[]] .three = true := by decide
def e2422364387502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))))
theorem wire_e2422364387502 : Closed e2422364387502 ∧ code e2422364387502 = 11218457409710 := by decide
theorem cert_e2422364387502 : check e2422364387502 [[],[]] .smaller = true := by decide
def e2422364387514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))))
theorem wire_e2422364387514 : Closed e2422364387514 ∧ code e2422364387514 = 11218457409722 := by decide
theorem cert_e2422364387514 : check e2422364387514 [[],[]] .smaller = true := by decide
def e2422364387886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422364387886 : Closed e2422364387886 ∧ code e2422364387886 = 11218457410094 := by decide
theorem cert_e2422364387886 : check e2422364387886 [[],[]] .smaller = true := by decide
def e2422364388030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 4))))))))
theorem wire_e2422364388030 : Closed e2422364388030 ∧ code e2422364388030 = 11218457410238 := by decide
theorem cert_e2422364388030 : check e2422364388030 [[],[]] .three = true := by decide
def e2422364388062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e2422364388062 : Closed e2422364388062 ∧ code e2422364388062 = 11218457410270 := by decide
theorem cert_e2422364388062 : check e2422364388062 [[],[]] .smaller = true := by decide
def e2422364388066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422364388066 : Closed e2422364388066 ∧ code e2422364388066 = 11218457410274 := by decide
theorem cert_e2422364388066 : check e2422364388066 [[],[]] .smaller = true := by decide
def e2422364388078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))))
theorem wire_e2422364388078 : Closed e2422364388078 ∧ code e2422364388078 = 11218457410286 := by decide
theorem cert_e2422364388078 : check e2422364388078 [[],[]] .smaller = true := by decide
def e2422364388086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e2422364388086 : Closed e2422364388086 ∧ code e2422364388086 = 11218457410294 := by decide
theorem cert_e2422364388086 : check e2422364388086 [[],[]] .smaller = true := by decide
def e2422364388090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4)) (.var 0))))))))
theorem wire_e2422364388090 : Closed e2422364388090 ∧ code e2422364388090 = 11218457410298 := by decide
theorem cert_e2422364388090 : check e2422364388090 [[],[]] .three = true := by decide
def e2422364388190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 3))))))))
theorem wire_e2422364388190 : Closed e2422364388190 ∧ code e2422364388190 = 11218457410398 := by decide
theorem cert_e2422364388190 : check e2422364388190 [[],[]] .smaller = true := by decide
def e2422364388206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e2422364388206 : Closed e2422364388206 ∧ code e2422364388206 = 11218457410414 := by decide
theorem cert_e2422364388206 : check e2422364388206 [[],[]] .smaller = true := by decide
def e2422364388214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e2422364388214 : Closed e2422364388214 ∧ code e2422364388214 = 11218457410422 := by decide
theorem cert_e2422364388214 : check e2422364388214 [[],[]] .smaller = true := by decide
def e2422364388218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)) (.var 0))))))))
theorem wire_e2422364388218 : Closed e2422364388218 ∧ code e2422364388218 = 11218457410426 := by decide
theorem cert_e2422364388218 : check e2422364388218 [[],[]] .smaller = true := by decide
def e2422364388234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364388234 : Closed e2422364388234 ∧ code e2422364388234 = 11218457410442 := by decide
theorem cert_e2422364388234 : check e2422364388234 [[],[]] .smaller = true := by decide
def e2422364388258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364388258 : Closed e2422364388258 ∧ code e2422364388258 = 11218457410466 := by decide
theorem cert_e2422364388258 : check e2422364388258 [[],[]] .smaller = true := by decide
def e2422364388270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e2422364388270 : Closed e2422364388270 ∧ code e2422364388270 = 11218457410478 := by decide
theorem cert_e2422364388270 : check e2422364388270 [[],[]] .smaller = true := by decide
def e2422364388278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 1))))))))
theorem wire_e2422364388278 : Closed e2422364388278 ∧ code e2422364388278 = 11218457410486 := by decide
theorem cert_e2422364388278 : check e2422364388278 [[],[]] .smaller = true := by decide
def e2422364388282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e2422364388282 : Closed e2422364388282 ∧ code e2422364388282 = 11218457410490 := by decide
theorem cert_e2422364388282 : check e2422364388282 [[],[]] .smaller = true := by decide
def e2422364388310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e2422364388310 : Closed e2422364388310 ∧ code e2422364388310 = 11218457410518 := by decide
theorem cert_e2422364388310 : check e2422364388310 [[],[]] .smaller = true := by decide
def e2422364388314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e2422364388314 : Closed e2422364388314 ∧ code e2422364388314 = 11218457410522 := by decide
theorem cert_e2422364388314 : check e2422364388314 [[],[]] .smaller = true := by decide
def e2422364388330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0)) (.var 0))))))))
theorem wire_e2422364388330 : Closed e2422364388330 ∧ code e2422364388330 = 11218457410538 := by decide
theorem cert_e2422364388330 : check e2422364388330 [[],[]] .three = true := by decide
def e2422364388438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))))
theorem wire_e2422364388438 : Closed e2422364388438 ∧ code e2422364388438 = 11218457410646 := by decide
theorem cert_e2422364388438 : check e2422364388438 [[],[]] .smaller = true := by decide
def e2422364388442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))))
theorem wire_e2422364388442 : Closed e2422364388442 ∧ code e2422364388442 = 11218457410650 := by decide
theorem cert_e2422364388442 : check e2422364388442 [[],[]] .smaller = true := by decide
def e2422364388630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422364388630 : Closed e2422364388630 ∧ code e2422364388630 = 11218457410838 := by decide
theorem cert_e2422364388630 : check e2422364388630 [[],[]] .smaller = true := by decide
def e2422364388702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e2422364388702 : Closed e2422364388702 ∧ code e2422364388702 = 11218457410910 := by decide
theorem cert_e2422364388702 : check e2422364388702 [[],[]] .smaller = true := by decide
def e2422364388706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422364388706 : Closed e2422364388706 ∧ code e2422364388706 = 11218457410914 := by decide
theorem cert_e2422364388706 : check e2422364388706 [[],[]] .smaller = true := by decide
def e2422364388718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e2422364388718 : Closed e2422364388718 ∧ code e2422364388718 = 11218457410926 := by decide
theorem cert_e2422364388718 : check e2422364388718 [[],[]] .smaller = true := by decide
def e2422364388726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e2422364388726 : Closed e2422364388726 ∧ code e2422364388726 = 11218457410934 := by decide
theorem cert_e2422364388726 : check e2422364388726 [[],[]] .smaller = true := by decide
def e2422364388730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e2422364388730 : Closed e2422364388730 ∧ code e2422364388730 = 11218457410938 := by decide
theorem cert_e2422364388730 : check e2422364388730 [[],[]] .smaller = true := by decide
def e2422364388746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364388746 : Closed e2422364388746 ∧ code e2422364388746 = 11218457410954 := by decide
theorem cert_e2422364388746 : check e2422364388746 [[],[]] .smaller = true := by decide
def e2422364388770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364388770 : Closed e2422364388770 ∧ code e2422364388770 = 11218457410978 := by decide
theorem cert_e2422364388770 : check e2422364388770 [[],[]] .smaller = true := by decide
def e2422364388782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e2422364388782 : Closed e2422364388782 ∧ code e2422364388782 = 11218457410990 := by decide
theorem cert_e2422364388782 : check e2422364388782 [[],[]] .smaller = true := by decide
def e2422364388790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e2422364388790 : Closed e2422364388790 ∧ code e2422364388790 = 11218457410998 := by decide
theorem cert_e2422364388790 : check e2422364388790 [[],[]] .smaller = true := by decide
def e2422364388794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e2422364388794 : Closed e2422364388794 ∧ code e2422364388794 = 11218457411002 := by decide
theorem cert_e2422364388794 : check e2422364388794 [[],[]] .smaller = true := by decide
def e2422364388822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e2422364388822 : Closed e2422364388822 ∧ code e2422364388822 = 11218457411030 := by decide
theorem cert_e2422364388822 : check e2422364388822 [[],[]] .smaller = true := by decide
def e2422364388826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e2422364388826 : Closed e2422364388826 ∧ code e2422364388826 = 11218457411034 := by decide
theorem cert_e2422364388826 : check e2422364388826 [[],[]] .smaller = true := by decide
def e2422364388842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e2422364388842 : Closed e2422364388842 ∧ code e2422364388842 = 11218457411050 := by decide
theorem cert_e2422364388842 : check e2422364388842 [[],[]] .smaller = true := by decide
def e2422364389038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422364389038 : Closed e2422364389038 ∧ code e2422364389038 = 11218457411246 := by decide
theorem cert_e2422364389038 : check e2422364389038 [[],[]] .smaller = true := by decide
def e2422364389046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e2422364389046 : Closed e2422364389046 ∧ code e2422364389046 = 11218457411254 := by decide
theorem cert_e2422364389046 : check e2422364389046 [[],[]] .smaller = true := by decide
def e2422364389050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422364389050 : Closed e2422364389050 ∧ code e2422364389050 = 11218457411258 := by decide
theorem cert_e2422364389050 : check e2422364389050 [[],[]] .smaller = true := by decide
def e2422364389078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422364389078 : Closed e2422364389078 ∧ code e2422364389078 = 11218457411286 := by decide
theorem cert_e2422364389078 : check e2422364389078 [[],[]] .smaller = true := by decide
def e2422364389082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422364389082 : Closed e2422364389082 ∧ code e2422364389082 = 11218457411290 := by decide
theorem cert_e2422364389082 : check e2422364389082 [[],[]] .smaller = true := by decide
def e2422364389098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422364389098 : Closed e2422364389098 ∧ code e2422364389098 = 11218457411306 := by decide
theorem cert_e2422364389098 : check e2422364389098 [[],[]] .smaller = true := by decide
def e2422364389206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422364389206 : Closed e2422364389206 ∧ code e2422364389206 = 11218457411414 := by decide
theorem cert_e2422364389206 : check e2422364389206 [[],[]] .three = true := by decide
def e2422364389210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422364389210 : Closed e2422364389210 ∧ code e2422364389210 = 11218457411418 := by decide
theorem cert_e2422364389210 : check e2422364389210 [[],[]] .three = true := by decide
def e2422364389226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422364389226 : Closed e2422364389226 ∧ code e2422364389226 = 11218457411434 := by decide
theorem cert_e2422364389226 : check e2422364389226 [[],[]] .three = true := by decide
def e2422364389870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e2422364389870 : Closed e2422364389870 ∧ code e2422364389870 = 11218457412078 := by decide
theorem cert_e2422364389870 : check e2422364389870 [[],[]] .smaller = true := by decide
def e2422364389878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e2422364389878 : Closed e2422364389878 ∧ code e2422364389878 = 11218457412086 := by decide
theorem cert_e2422364389878 : check e2422364389878 [[],[]] .smaller = true := by decide
def e2422364390638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364390638 : Closed e2422364390638 ∧ code e2422364390638 = 11218457412846 := by decide
theorem cert_e2422364390638 : check e2422364390638 [[],[]] .smaller = true := by decide
def e2422364390646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364390646 : Closed e2422364390646 ∧ code e2422364390646 = 11218457412854 := by decide
theorem cert_e2422364390646 : check e2422364390646 [[],[]] .smaller = true := by decide
def e2422364391198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e2422364391198 : Closed e2422364391198 ∧ code e2422364391198 = 11218457413406 := by decide
theorem cert_e2422364391198 : check e2422364391198 [[],[]] .smaller = true := by decide
def e2422364391310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e2422364391310 : Closed e2422364391310 ∧ code e2422364391310 = 11218457413518 := by decide
theorem cert_e2422364391310 : check e2422364391310 [[],[]] .smaller = true := by decide
def e2422364391358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 4))))))))
theorem wire_e2422364391358 : Closed e2422364391358 ∧ code e2422364391358 = 11218457413566 := by decide
theorem cert_e2422364391358 : check e2422364391358 [[],[]] .three = true := by decide
def e2422364391406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 5))) (.var 2))))))))
theorem wire_e2422364391406 : Closed e2422364391406 ∧ code e2422364391406 = 11218457413614 := by decide
theorem cert_e2422364391406 : check e2422364391406 [[],[]] .three = true := by decide
def e2422364392894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e2422364392894 : Closed e2422364392894 ∧ code e2422364392894 = 11218457415102 := by decide
theorem cert_e2422364392894 : check e2422364392894 [[],[]] .three = true := by decide
def e2422364392926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e2422364392926 : Closed e2422364392926 ∧ code e2422364392926 = 11218457415134 := by decide
theorem cert_e2422364392926 : check e2422364392926 [[],[]] .smaller = true := by decide
def e2422364392942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e2422364392942 : Closed e2422364392942 ∧ code e2422364392942 = 11218457415150 := by decide
theorem cert_e2422364392942 : check e2422364392942 [[],[]] .smaller = true := by decide
def e2422364392950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e2422364392950 : Closed e2422364392950 ∧ code e2422364392950 = 11218457415158 := by decide
theorem cert_e2422364392950 : check e2422364392950 [[],[]] .three = true := by decide
def e2422364393006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422364393006 : Closed e2422364393006 ∧ code e2422364393006 = 11218457415214 := by decide
theorem cert_e2422364393006 : check e2422364393006 [[],[]] .smaller = true := by decide
def e2422364393150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e2422364393150 : Closed e2422364393150 ∧ code e2422364393150 = 11218457415358 := by decide
theorem cert_e2422364393150 : check e2422364393150 [[],[]] .three = true := by decide
def e2422364393182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e2422364393182 : Closed e2422364393182 ∧ code e2422364393182 = 11218457415390 := by decide
theorem cert_e2422364393182 : check e2422364393182 [[],[]] .smaller = true := by decide
def e2422364393186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422364393186 : Closed e2422364393186 ∧ code e2422364393186 = 11218457415394 := by decide
theorem cert_e2422364393186 : check e2422364393186 [[],[]] .smaller = true := by decide
def e2422364393198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e2422364393198 : Closed e2422364393198 ∧ code e2422364393198 = 11218457415406 := by decide
theorem cert_e2422364393198 : check e2422364393198 [[],[]] .smaller = true := by decide
def e2422364393206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e2422364393206 : Closed e2422364393206 ∧ code e2422364393206 = 11218457415414 := by decide
theorem cert_e2422364393206 : check e2422364393206 [[],[]] .smaller = true := by decide
def e2422364393210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e2422364393210 : Closed e2422364393210 ∧ code e2422364393210 = 11218457415418 := by decide
theorem cert_e2422364393210 : check e2422364393210 [[],[]] .three = true := by decide
def e2422364393238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422364393238 : Closed e2422364393238 ∧ code e2422364393238 = 11218457415446 := by decide
theorem cert_e2422364393238 : check e2422364393238 [[],[]] .smaller = true := by decide
def e2422364393310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e2422364393310 : Closed e2422364393310 ∧ code e2422364393310 = 11218457415518 := by decide
theorem cert_e2422364393310 : check e2422364393310 [[],[]] .smaller = true := by decide
def e2422364393314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422364393314 : Closed e2422364393314 ∧ code e2422364393314 = 11218457415522 := by decide
theorem cert_e2422364393314 : check e2422364393314 [[],[]] .smaller = true := by decide
def e2422364393326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e2422364393326 : Closed e2422364393326 ∧ code e2422364393326 = 11218457415534 := by decide
theorem cert_e2422364393326 : check e2422364393326 [[],[]] .smaller = true := by decide
def e2422364393334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e2422364393334 : Closed e2422364393334 ∧ code e2422364393334 = 11218457415542 := by decide
theorem cert_e2422364393334 : check e2422364393334 [[],[]] .smaller = true := by decide
def e2422364393338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e2422364393338 : Closed e2422364393338 ∧ code e2422364393338 = 11218457415546 := by decide
theorem cert_e2422364393338 : check e2422364393338 [[],[]] .smaller = true := by decide
def e2422364393390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e2422364393390 : Closed e2422364393390 ∧ code e2422364393390 = 11218457415598 := by decide
theorem cert_e2422364393390 : check e2422364393390 [[],[]] .smaller = true := by decide
def e2422364393398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e2422364393398 : Closed e2422364393398 ∧ code e2422364393398 = 11218457415606 := by decide
theorem cert_e2422364393398 : check e2422364393398 [[],[]] .smaller = true := by decide
def e2422364393402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e2422364393402 : Closed e2422364393402 ∧ code e2422364393402 = 11218457415610 := by decide
theorem cert_e2422364393402 : check e2422364393402 [[],[]] .smaller = true := by decide
def e2422364393430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e2422364393430 : Closed e2422364393430 ∧ code e2422364393430 = 11218457415638 := by decide
theorem cert_e2422364393430 : check e2422364393430 [[],[]] .three = true := by decide
def e2422364393434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e2422364393434 : Closed e2422364393434 ∧ code e2422364393434 = 11218457415642 := by decide
theorem cert_e2422364393434 : check e2422364393434 [[],[]] .three = true := by decide
def e2422364394430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364394430 : Closed e2422364394430 ∧ code e2422364394430 = 11218457416638 := by decide
theorem cert_e2422364394430 : check e2422364394430 [[],[]] .three = true := by decide
def e2422364394462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422364394462 : Closed e2422364394462 ∧ code e2422364394462 = 11218457416670 := by decide
theorem cert_e2422364394462 : check e2422364394462 [[],[]] .smaller = true := by decide
def e2422364394478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422364394478 : Closed e2422364394478 ∧ code e2422364394478 = 11218457416686 := by decide
theorem cert_e2422364394478 : check e2422364394478 [[],[]] .smaller = true := by decide
def e2422364394486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364394486 : Closed e2422364394486 ∧ code e2422364394486 = 11218457416694 := by decide
theorem cert_e2422364394486 : check e2422364394486 [[],[]] .three = true := by decide
def e2422364395582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422364395582 : Closed e2422364395582 ∧ code e2422364395582 = 11218457417790 := by decide
theorem cert_e2422364395582 : check e2422364395582 [[],[]] .smaller = true := by decide
def e2422364395966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364395966 : Closed e2422364395966 ∧ code e2422364395966 = 11218457418174 := by decide
theorem cert_e2422364395966 : check e2422364395966 [[],[]] .three = true := by decide
def e2422364395998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364395998 : Closed e2422364395998 ∧ code e2422364395998 = 11218457418206 := by decide
theorem cert_e2422364395998 : check e2422364395998 [[],[]] .smaller = true := by decide
def e2422364396002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422364396002 : Closed e2422364396002 ∧ code e2422364396002 = 11218457418210 := by decide
theorem cert_e2422364396002 : check e2422364396002 [[],[]] .smaller = true := by decide
def e2422364396014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364396014 : Closed e2422364396014 ∧ code e2422364396014 = 11218457418222 := by decide
theorem cert_e2422364396014 : check e2422364396014 [[],[]] .smaller = true := by decide
def e2422364396022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364396022 : Closed e2422364396022 ∧ code e2422364396022 = 11218457418230 := by decide
theorem cert_e2422364396022 : check e2422364396022 [[],[]] .smaller = true := by decide
def e2422364396026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364396026 : Closed e2422364396026 ∧ code e2422364396026 = 11218457418234 := by decide
theorem cert_e2422364396026 : check e2422364396026 [[],[]] .three = true := by decide
def e2422364396574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422364396574 : Closed e2422364396574 ∧ code e2422364396574 = 11218457418782 := by decide
theorem cert_e2422364396574 : check e2422364396574 [[],[]] .smaller = true := by decide
def e2422364396670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 5)))))))))
theorem wire_e2422364396670 : Closed e2422364396670 ∧ code e2422364396670 = 11218457418878 := by decide
theorem cert_e2422364396670 : check e2422364396670 [[],[]] .three = true := by decide
def e2422364396766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364396766 : Closed e2422364396766 ∧ code e2422364396766 = 11218457418974 := by decide
theorem cert_e2422364396766 : check e2422364396766 [[],[]] .smaller = true := by decide
def e2422364396770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422364396770 : Closed e2422364396770 ∧ code e2422364396770 = 11218457418978 := by decide
theorem cert_e2422364396770 : check e2422364396770 [[],[]] .smaller = true := by decide
def e2422364396782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364396782 : Closed e2422364396782 ∧ code e2422364396782 = 11218457418990 := by decide
theorem cert_e2422364396782 : check e2422364396782 [[],[]] .smaller = true := by decide
def e2422364396790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364396790 : Closed e2422364396790 ∧ code e2422364396790 = 11218457418998 := by decide
theorem cert_e2422364396790 : check e2422364396790 [[],[]] .smaller = true := by decide
def e2422364396794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364396794 : Closed e2422364396794 ∧ code e2422364396794 = 11218457419002 := by decide
theorem cert_e2422364396794 : check e2422364396794 [[],[]] .smaller = true := by decide
def e2422364397166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364397166 : Closed e2422364397166 ∧ code e2422364397166 = 11218457419374 := by decide
theorem cert_e2422364397166 : check e2422364397166 [[],[]] .smaller = true := by decide
def e2422364397174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364397174 : Closed e2422364397174 ∧ code e2422364397174 = 11218457419382 := by decide
theorem cert_e2422364397174 : check e2422364397174 [[],[]] .smaller = true := by decide
def e2422364397178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364397178 : Closed e2422364397178 ∧ code e2422364397178 = 11218457419386 := by decide
theorem cert_e2422364397178 : check e2422364397178 [[],[]] .smaller = true := by decide
def e2422364397342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.lam (.var 3)))))))))
theorem wire_e2422364397342 : Closed e2422364397342 ∧ code e2422364397342 = 11218457419550 := by decide
theorem cert_e2422364397342 : check e2422364397342 [[],[]] .three = true := by decide
def e2422364397366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364397366 : Closed e2422364397366 ∧ code e2422364397366 = 11218457419574 := by decide
theorem cert_e2422364397366 : check e2422364397366 [[],[]] .three = true := by decide
def e2422364397370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364397370 : Closed e2422364397370 ∧ code e2422364397370 = 11218457419578 := by decide
theorem cert_e2422364397370 : check e2422364397370 [[],[]] .three = true := by decide
def e2422364397806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422364397806 : Closed e2422364397806 ∧ code e2422364397806 = 11218457420014 := by decide
theorem cert_e2422364397806 : check e2422364397806 [[],[]] .smaller = true := by decide
def e2422364397818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422364397818 : Closed e2422364397818 ∧ code e2422364397818 = 11218457420026 := by decide
theorem cert_e2422364397818 : check e2422364397818 [[],[]] .smaller = true := by decide
def e2422364397998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422364397998 : Closed e2422364397998 ∧ code e2422364397998 = 11218457420206 := by decide
theorem cert_e2422364397998 : check e2422364397998 [[],[]] .smaller = true := by decide
def e2422364398190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364398190 : Closed e2422364398190 ∧ code e2422364398190 = 11218457420398 := by decide
theorem cert_e2422364398190 : check e2422364398190 [[],[]] .smaller = true := by decide
def e2422364398202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364398202 : Closed e2422364398202 ∧ code e2422364398202 = 11218457420410 := by decide
theorem cert_e2422364398202 : check e2422364398202 [[],[]] .smaller = true := by decide
def e2422364398366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422364398366 : Closed e2422364398366 ∧ code e2422364398366 = 11218457420574 := by decide
theorem cert_e2422364398366 : check e2422364398366 [[],[]] .smaller = true := by decide
def e2422364398526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 4))))))))
theorem wire_e2422364398526 : Closed e2422364398526 ∧ code e2422364398526 = 11218457420734 := by decide
theorem cert_e2422364398526 : check e2422364398526 [[],[]] .three = true := by decide
def e2422364398534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422364398534 : Closed e2422364398534 ∧ code e2422364398534 = 11218457420742 := by decide
theorem cert_e2422364398534 : check e2422364398534 [[],[]] .smaller = true := by decide
def e2422364398582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 5))) (.var 1))))))))
theorem wire_e2422364398582 : Closed e2422364398582 ∧ code e2422364398582 = 11218457420790 := by decide
theorem cert_e2422364398582 : check e2422364398582 [[],[]] .three = true := by decide
def e2422364399150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422364399150 : Closed e2422364399150 ∧ code e2422364399150 = 11218457421358 := by decide
theorem cert_e2422364399150 : check e2422364399150 [[],[]] .smaller = true := by decide
def e2422364399294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e2422364399294 : Closed e2422364399294 ∧ code e2422364399294 = 11218457421502 := by decide
theorem cert_e2422364399294 : check e2422364399294 [[],[]] .three = true := by decide
def e2422364399326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2422364399326 : Closed e2422364399326 ∧ code e2422364399326 = 11218457421534 := by decide
theorem cert_e2422364399326 : check e2422364399326 [[],[]] .smaller = true := by decide
def e2422364399330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422364399330 : Closed e2422364399330 ∧ code e2422364399330 = 11218457421538 := by decide
theorem cert_e2422364399330 : check e2422364399330 [[],[]] .smaller = true := by decide
def e2422364399342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2422364399342 : Closed e2422364399342 ∧ code e2422364399342 = 11218457421550 := by decide
theorem cert_e2422364399342 : check e2422364399342 [[],[]] .smaller = true := by decide
def e2422364399350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2422364399350 : Closed e2422364399350 ∧ code e2422364399350 = 11218457421558 := by decide
theorem cert_e2422364399350 : check e2422364399350 [[],[]] .smaller = true := by decide
def e2422364399354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e2422364399354 : Closed e2422364399354 ∧ code e2422364399354 = 11218457421562 := by decide
theorem cert_e2422364399354 : check e2422364399354 [[],[]] .three = true := by decide
def e2422364399454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2422364399454 : Closed e2422364399454 ∧ code e2422364399454 = 11218457421662 := by decide
theorem cert_e2422364399454 : check e2422364399454 [[],[]] .smaller = true := by decide
def e2422364399470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2422364399470 : Closed e2422364399470 ∧ code e2422364399470 = 11218457421678 := by decide
theorem cert_e2422364399470 : check e2422364399470 [[],[]] .smaller = true := by decide
def e2422364399478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2422364399478 : Closed e2422364399478 ∧ code e2422364399478 = 11218457421686 := by decide
theorem cert_e2422364399478 : check e2422364399478 [[],[]] .smaller = true := by decide
def e2422364399482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2422364399482 : Closed e2422364399482 ∧ code e2422364399482 = 11218457421690 := by decide
theorem cert_e2422364399482 : check e2422364399482 [[],[]] .smaller = true := by decide
def e2422364399498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364399498 : Closed e2422364399498 ∧ code e2422364399498 = 11218457421706 := by decide
theorem cert_e2422364399498 : check e2422364399498 [[],[]] .smaller = true := by decide
def e2422364399522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364399522 : Closed e2422364399522 ∧ code e2422364399522 = 11218457421730 := by decide
theorem cert_e2422364399522 : check e2422364399522 [[],[]] .smaller = true := by decide
def e2422364399534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2422364399534 : Closed e2422364399534 ∧ code e2422364399534 = 11218457421742 := by decide
theorem cert_e2422364399534 : check e2422364399534 [[],[]] .smaller = true := by decide
def e2422364399542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2422364399542 : Closed e2422364399542 ∧ code e2422364399542 = 11218457421750 := by decide
theorem cert_e2422364399542 : check e2422364399542 [[],[]] .smaller = true := by decide
def e2422364399546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2422364399546 : Closed e2422364399546 ∧ code e2422364399546 = 11218457421754 := by decide
theorem cert_e2422364399546 : check e2422364399546 [[],[]] .smaller = true := by decide
def e2422364399574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2422364399574 : Closed e2422364399574 ∧ code e2422364399574 = 11218457421782 := by decide
theorem cert_e2422364399574 : check e2422364399574 [[],[]] .smaller = true := by decide
def e2422364399578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2422364399578 : Closed e2422364399578 ∧ code e2422364399578 = 11218457421786 := by decide
theorem cert_e2422364399578 : check e2422364399578 [[],[]] .smaller = true := by decide
def e2422364399594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e2422364399594 : Closed e2422364399594 ∧ code e2422364399594 = 11218457421802 := by decide
theorem cert_e2422364399594 : check e2422364399594 [[],[]] .three = true := by decide
def e2422364399678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422364399678 : Closed e2422364399678 ∧ code e2422364399678 = 11218457421886 := by decide
theorem cert_e2422364399678 : check e2422364399678 [[],[]] .smaller = true := by decide
def e2422364400062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364400062 : Closed e2422364400062 ∧ code e2422364400062 = 11218457422270 := by decide
theorem cert_e2422364400062 : check e2422364400062 [[],[]] .three = true := by decide
def e2422364400094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364400094 : Closed e2422364400094 ∧ code e2422364400094 = 11218457422302 := by decide
theorem cert_e2422364400094 : check e2422364400094 [[],[]] .smaller = true := by decide
def e2422364400098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422364400098 : Closed e2422364400098 ∧ code e2422364400098 = 11218457422306 := by decide
theorem cert_e2422364400098 : check e2422364400098 [[],[]] .smaller = true := by decide
def e2422364400110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364400110 : Closed e2422364400110 ∧ code e2422364400110 = 11218457422318 := by decide
theorem cert_e2422364400110 : check e2422364400110 [[],[]] .smaller = true := by decide
def e2422364400118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364400118 : Closed e2422364400118 ∧ code e2422364400118 = 11218457422326 := by decide
theorem cert_e2422364400118 : check e2422364400118 [[],[]] .smaller = true := by decide
def e2422364400122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364400122 : Closed e2422364400122 ∧ code e2422364400122 = 11218457422330 := by decide
theorem cert_e2422364400122 : check e2422364400122 [[],[]] .three = true := by decide
def e2422364400766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 5)))))))))
theorem wire_e2422364400766 : Closed e2422364400766 ∧ code e2422364400766 = 11218457422974 := by decide
theorem cert_e2422364400766 : check e2422364400766 [[],[]] .three = true := by decide
def e2422364400862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364400862 : Closed e2422364400862 ∧ code e2422364400862 = 11218457423070 := by decide
theorem cert_e2422364400862 : check e2422364400862 [[],[]] .smaller = true := by decide
def e2422364400878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364400878 : Closed e2422364400878 ∧ code e2422364400878 = 11218457423086 := by decide
theorem cert_e2422364400878 : check e2422364400878 [[],[]] .smaller = true := by decide
def e2422364400886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364400886 : Closed e2422364400886 ∧ code e2422364400886 = 11218457423094 := by decide
theorem cert_e2422364400886 : check e2422364400886 [[],[]] .smaller = true := by decide
def e2422364400890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364400890 : Closed e2422364400890 ∧ code e2422364400890 = 11218457423098 := by decide
theorem cert_e2422364400890 : check e2422364400890 [[],[]] .smaller = true := by decide
def e2422364401166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364401166 : Closed e2422364401166 ∧ code e2422364401166 = 11218457423374 := by decide
theorem cert_e2422364401166 : check e2422364401166 [[],[]] .smaller = true := by decide
def e2422364401178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364401178 : Closed e2422364401178 ∧ code e2422364401178 = 11218457423386 := by decide
theorem cert_e2422364401178 : check e2422364401178 [[],[]] .smaller = true := by decide
def e2422364401250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364401250 : Closed e2422364401250 ∧ code e2422364401250 = 11218457423458 := by decide
theorem cert_e2422364401250 : check e2422364401250 [[],[]] .smaller = true := by decide
def e2422364401262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364401262 : Closed e2422364401262 ∧ code e2422364401262 = 11218457423470 := by decide
theorem cert_e2422364401262 : check e2422364401262 [[],[]] .smaller = true := by decide
def e2422364401270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364401270 : Closed e2422364401270 ∧ code e2422364401270 = 11218457423478 := by decide
theorem cert_e2422364401270 : check e2422364401270 [[],[]] .smaller = true := by decide
def e2422364401274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364401274 : Closed e2422364401274 ∧ code e2422364401274 = 11218457423482 := by decide
theorem cert_e2422364401274 : check e2422364401274 [[],[]] .smaller = true := by decide
def e2422364401462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364401462 : Closed e2422364401462 ∧ code e2422364401462 = 11218457423670 := by decide
theorem cert_e2422364401462 : check e2422364401462 [[],[]] .smaller = true := by decide
def e2422364401466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364401466 : Closed e2422364401466 ∧ code e2422364401466 = 11218457423674 := by decide
theorem cert_e2422364401466 : check e2422364401466 [[],[]] .smaller = true := by decide
def e2422364401550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.lam (.var 2)))))))))
theorem wire_e2422364401550 : Closed e2422364401550 ∧ code e2422364401550 = 11218457423758 := by decide
theorem cert_e2422364401550 : check e2422364401550 [[],[]] .three = true := by decide
def e2422364401562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364401562 : Closed e2422364401562 ∧ code e2422364401562 = 11218457423770 := by decide
theorem cert_e2422364401562 : check e2422364401562 [[],[]] .three = true := by decide
def e2422364401598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 4))))))))
theorem wire_e2422364401598 : Closed e2422364401598 ∧ code e2422364401598 = 11218457423806 := by decide
theorem cert_e2422364401598 : check e2422364401598 [[],[]] .three = true := by decide
def e2422364401782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422364401782 : Closed e2422364401782 ∧ code e2422364401782 = 11218457423990 := by decide
theorem cert_e2422364401782 : check e2422364401782 [[],[]] .smaller = true := by decide
def e2422364401786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422364401786 : Closed e2422364401786 ∧ code e2422364401786 = 11218457423994 := by decide
theorem cert_e2422364401786 : check e2422364401786 [[],[]] .smaller = true := by decide
def e2422364401878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422364401878 : Closed e2422364401878 ∧ code e2422364401878 = 11218457424086 := by decide
theorem cert_e2422364401878 : check e2422364401878 [[],[]] .smaller = true := by decide
def e2422364401974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364401974 : Closed e2422364401974 ∧ code e2422364401974 = 11218457424182 := by decide
theorem cert_e2422364401974 : check e2422364401974 [[],[]] .smaller = true := by decide
end Blc.Floor43
