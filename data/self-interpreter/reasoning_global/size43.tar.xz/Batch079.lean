import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e773242014958 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e773242014958 : Closed e773242014958 ∧ code e773242014958 = 9569335037166 := by decide
theorem cert_e773242014958 : check e773242014958 [] .sourceHead = true := by decide
def e773242014966 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e773242014966 : Closed e773242014966 ∧ code e773242014966 = 9569335037174 := by decide
theorem cert_e773242014966 : check e773242014966 [] .sourceHead = true := by decide
def e773242015342 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e773242015342 : Closed e773242015342 ∧ code e773242015342 = 9569335037550 := by decide
theorem cert_e773242015342 : check e773242015342 [] .sourceHead = true := by decide
def e773242015354 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e773242015354 : Closed e773242015354 ∧ code e773242015354 = 9569335037562 := by decide
theorem cert_e773242015354 : check e773242015354 [] .sourceHead = true := by decide
def e773242015542 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e773242015542 : Closed e773242015542 ∧ code e773242015542 = 9569335037750 := by decide
theorem cert_e773242015542 : check e773242015542 [] .sourceHead = true := by decide
def e773242015546 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e773242015546 : Closed e773242015546 ∧ code e773242015546 = 9569335037754 := by decide
theorem cert_e773242015546 : check e773242015546 [] .sourceHead = true := by decide
def e773242021294 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e773242021294 : Closed e773242021294 ∧ code e773242021294 = 9569335043502 := by decide
theorem cert_e773242021294 : check e773242021294 [] .sourceHead = true := by decide
def e773242021306 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e773242021306 : Closed e773242021306 ∧ code e773242021306 = 9569335043514 := by decide
theorem cert_e773242021306 : check e773242021306 [] .sourceHead = true := by decide
def e773242021354 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e773242021354 : Closed e773242021354 ∧ code e773242021354 = 9569335043562 := by decide
theorem cert_e773242021354 : check e773242021354 [] .sourceHead = true := by decide
def e773242021486 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e773242021486 : Closed e773242021486 ∧ code e773242021486 = 9569335043694 := by decide
theorem cert_e773242021486 : check e773242021486 [] .sourceHead = true := by decide
def e773242021498 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e773242021498 : Closed e773242021498 ∧ code e773242021498 = 9569335043706 := by decide
theorem cert_e773242021498 : check e773242021498 [] .sourceHead = true := by decide
def e773242021786 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e773242021786 : Closed e773242021786 ∧ code e773242021786 = 9569335043994 := by decide
theorem cert_e773242021786 : check e773242021786 [] .sourceHead = true := by decide
def e773242024662 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e773242024662 : Closed e773242024662 ∧ code e773242024662 = 9569335046870 := by decide
theorem cert_e773242024662 : check e773242024662 [] .sourceHead = true := by decide
def e773242024666 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e773242024666 : Closed e773242024666 ∧ code e773242024666 = 9569335046874 := by decide
theorem cert_e773242024666 : check e773242024666 [] .sourceHead = true := by decide
def e773242024682 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e773242024682 : Closed e773242024682 ∧ code e773242024682 = 9569335046890 := by decide
theorem cert_e773242024682 : check e773242024682 [] .sourceHead = true := by decide
def e773242024758 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e773242024758 : Closed e773242024758 ∧ code e773242024758 = 9569335046966 := by decide
theorem cert_e773242024758 : check e773242024758 [] .sourceHead = true := by decide
def e773242024762 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e773242024762 : Closed e773242024762 ∧ code e773242024762 = 9569335046970 := by decide
theorem cert_e773242024762 : check e773242024762 [] .sourceHead = true := by decide
def e773242024858 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e773242024858 : Closed e773242024858 ∧ code e773242024858 = 9569335047066 := by decide
theorem cert_e773242024858 : check e773242024858 [] .sourceHead = true := by decide
def e773685554542 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e773685554542 : Closed e773685554542 ∧ code e773685554542 = 9569778576750 := by decide
theorem cert_e773685554542 : check e773685554542 [] .sourceHead = true := by decide
def e773685554550 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e773685554550 : Closed e773685554550 ∧ code e773685554550 = 9569778576758 := by decide
theorem cert_e773685554550 : check e773685554550 [] .sourceHead = true := by decide
def e773685554606 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e773685554606 : Closed e773685554606 ∧ code e773685554606 = 9569778576814 := by decide
theorem cert_e773685554606 : check e773685554606 [] .sourceHead = true := by decide
def e773685554618 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e773685554618 : Closed e773685554618 ∧ code e773685554618 = 9569778576826 := by decide
theorem cert_e773685554618 : check e773685554618 [] .sourceHead = true := by decide
def e773685554646 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e773685554646 : Closed e773685554646 ∧ code e773685554646 = 9569778576854 := by decide
theorem cert_e773685554646 : check e773685554646 [] .sourceHead = true := by decide
def e773685554650 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e773685554650 : Closed e773685554650 ∧ code e773685554650 = 9569778576858 := by decide
theorem cert_e773685554650 : check e773685554650 [] .sourceHead = true := by decide
def e773685554862 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e773685554862 : Closed e773685554862 ∧ code e773685554862 = 9569778577070 := by decide
theorem cert_e773685554862 : check e773685554862 [] .sourceHead = true := by decide
def e773685554874 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e773685554874 : Closed e773685554874 ∧ code e773685554874 = 9569778577082 := by decide
theorem cert_e773685554874 : check e773685554874 [] .sourceHead = true := by decide
def e773685554922 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e773685554922 : Closed e773685554922 ∧ code e773685554922 = 9569778577130 := by decide
theorem cert_e773685554922 : check e773685554922 [] .sourceHead = true := by decide
def e773685555030 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e773685555030 : Closed e773685555030 ∧ code e773685555030 = 9569778577238 := by decide
theorem cert_e773685555030 : check e773685555030 [] .sourceHead = true := by decide
def e773685555034 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e773685555034 : Closed e773685555034 ∧ code e773685555034 = 9569778577242 := by decide
theorem cert_e773685555034 : check e773685555034 [] .sourceHead = true := by decide
def e773685555050 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e773685555050 : Closed e773685555050 ∧ code e773685555050 = 9569778577258 := by decide
theorem cert_e773685555050 : check e773685555050 [] .sourceHead = true := by decide
def e773685556078 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e773685556078 : Closed e773685556078 ∧ code e773685556078 = 9569778578286 := by decide
theorem cert_e773685556078 : check e773685556078 [] .sourceHead = true := by decide
def e773685556086 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e773685556086 : Closed e773685556086 ∧ code e773685556086 = 9569778578294 := by decide
theorem cert_e773685556086 : check e773685556086 [] .sourceHead = true := by decide
def e773685556142 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e773685556142 : Closed e773685556142 ∧ code e773685556142 = 9569778578350 := by decide
theorem cert_e773685556142 : check e773685556142 [] .sourceHead = true := by decide
def e773685556154 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e773685556154 : Closed e773685556154 ∧ code e773685556154 = 9569778578362 := by decide
theorem cert_e773685556154 : check e773685556154 [] .sourceHead = true := by decide
def e773685556182 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e773685556182 : Closed e773685556182 ∧ code e773685556182 = 9569778578390 := by decide
theorem cert_e773685556182 : check e773685556182 [] .sourceHead = true := by decide
def e773685556186 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e773685556186 : Closed e773685556186 ∧ code e773685556186 = 9569778578394 := by decide
theorem cert_e773685556186 : check e773685556186 [] .sourceHead = true := by decide
def e773685556462 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e773685556462 : Closed e773685556462 ∧ code e773685556462 = 9569778578670 := by decide
theorem cert_e773685556462 : check e773685556462 [] .sourceHead = true := by decide
def e773685556470 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e773685556470 : Closed e773685556470 ∧ code e773685556470 = 9569778578678 := by decide
theorem cert_e773685556470 : check e773685556470 [] .sourceHead = true := by decide
def e773685556846 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e773685556846 : Closed e773685556846 ∧ code e773685556846 = 9569778579054 := by decide
theorem cert_e773685556846 : check e773685556846 [] .sourceHead = true := by decide
def e773685556858 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e773685556858 : Closed e773685556858 ∧ code e773685556858 = 9569778579066 := by decide
theorem cert_e773685556858 : check e773685556858 [] .sourceHead = true := by decide
def e773685557046 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e773685557046 : Closed e773685557046 ∧ code e773685557046 = 9569778579254 := by decide
theorem cert_e773685557046 : check e773685557046 [] .sourceHead = true := by decide
def e773685557050 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e773685557050 : Closed e773685557050 ∧ code e773685557050 = 9569778579258 := by decide
theorem cert_e773685557050 : check e773685557050 [] .sourceHead = true := by decide
def e773685557678 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e773685557678 : Closed e773685557678 ∧ code e773685557678 = 9569778579886 := by decide
theorem cert_e773685557678 : check e773685557678 [] .sourceHead = true := by decide
def e773685557690 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e773685557690 : Closed e773685557690 ∧ code e773685557690 = 9569778579898 := by decide
theorem cert_e773685557690 : check e773685557690 [] .sourceHead = true := by decide
def e773685557738 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e773685557738 : Closed e773685557738 ∧ code e773685557738 = 9569778579946 := by decide
theorem cert_e773685557738 : check e773685557738 [] .sourceHead = true := by decide
def e773685557870 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e773685557870 : Closed e773685557870 ∧ code e773685557870 = 9569778580078 := by decide
theorem cert_e773685557870 : check e773685557870 [] .sourceHead = true := by decide
def e773685557882 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e773685557882 : Closed e773685557882 ∧ code e773685557882 = 9569778580090 := by decide
theorem cert_e773685557882 : check e773685557882 [] .sourceHead = true := by decide
def e773685558170 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e773685558170 : Closed e773685558170 ∧ code e773685558170 = 9569778580378 := by decide
theorem cert_e773685558170 : check e773685558170 [] .sourceHead = true := by decide
def e773685558486 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e773685558486 : Closed e773685558486 ∧ code e773685558486 = 9569778580694 := by decide
theorem cert_e773685558486 : check e773685558486 [] .sourceHead = true := by decide
def e773685558490 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e773685558490 : Closed e773685558490 ∧ code e773685558490 = 9569778580698 := by decide
theorem cert_e773685558490 : check e773685558490 [] .sourceHead = true := by decide
def e773685558506 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e773685558506 : Closed e773685558506 ∧ code e773685558506 = 9569778580714 := by decide
theorem cert_e773685558506 : check e773685558506 [] .sourceHead = true := by decide
def e773685558582 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e773685558582 : Closed e773685558582 ∧ code e773685558582 = 9569778580790 := by decide
theorem cert_e773685558582 : check e773685558582 [] .sourceHead = true := by decide
def e773685558586 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e773685558586 : Closed e773685558586 ∧ code e773685558586 = 9569778580794 := by decide
theorem cert_e773685558586 : check e773685558586 [] .sourceHead = true := by decide
def e773685558682 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e773685558682 : Closed e773685558682 ∧ code e773685558682 = 9569778580890 := by decide
theorem cert_e773685558682 : check e773685558682 [] .sourceHead = true := by decide
def e773685562222 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e773685562222 : Closed e773685562222 ∧ code e773685562222 = 9569778584430 := by decide
theorem cert_e773685562222 : check e773685562222 [] .sourceHead = true := by decide
def e773685562230 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e773685562230 : Closed e773685562230 ∧ code e773685562230 = 9569778584438 := by decide
theorem cert_e773685562230 : check e773685562230 [] .sourceHead = true := by decide
def e773685562286 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e773685562286 : Closed e773685562286 ∧ code e773685562286 = 9569778584494 := by decide
theorem cert_e773685562286 : check e773685562286 [] .sourceHead = true := by decide
def e773685562298 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e773685562298 : Closed e773685562298 ∧ code e773685562298 = 9569778584506 := by decide
theorem cert_e773685562298 : check e773685562298 [] .sourceHead = true := by decide
def e773685562326 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e773685562326 : Closed e773685562326 ∧ code e773685562326 = 9569778584534 := by decide
theorem cert_e773685562326 : check e773685562326 [] .sourceHead = true := by decide
def e773685562330 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e773685562330 : Closed e773685562330 ∧ code e773685562330 = 9569778584538 := by decide
theorem cert_e773685562330 : check e773685562330 [] .sourceHead = true := by decide
def e773685562606 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e773685562606 : Closed e773685562606 ∧ code e773685562606 = 9569778584814 := by decide
theorem cert_e773685562606 : check e773685562606 [] .sourceHead = true := by decide
def e773685562614 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e773685562614 : Closed e773685562614 ∧ code e773685562614 = 9569778584822 := by decide
theorem cert_e773685562614 : check e773685562614 [] .sourceHead = true := by decide
def e773685562990 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e773685562990 : Closed e773685562990 ∧ code e773685562990 = 9569778585198 := by decide
theorem cert_e773685562990 : check e773685562990 [] .sourceHead = true := by decide
def e773685563002 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e773685563002 : Closed e773685563002 ∧ code e773685563002 = 9569778585210 := by decide
theorem cert_e773685563002 : check e773685563002 [] .sourceHead = true := by decide
def e773685563190 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e773685563190 : Closed e773685563190 ∧ code e773685563190 = 9569778585398 := by decide
theorem cert_e773685563190 : check e773685563190 [] .sourceHead = true := by decide
def e773685563194 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e773685563194 : Closed e773685563194 ∧ code e773685563194 = 9569778585402 := by decide
theorem cert_e773685563194 : check e773685563194 [] .sourceHead = true := by decide
def e773685568942 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e773685568942 : Closed e773685568942 ∧ code e773685568942 = 9569778591150 := by decide
theorem cert_e773685568942 : check e773685568942 [] .sourceHead = true := by decide
def e773685568954 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e773685568954 : Closed e773685568954 ∧ code e773685568954 = 9569778591162 := by decide
theorem cert_e773685568954 : check e773685568954 [] .sourceHead = true := by decide
def e773685569002 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e773685569002 : Closed e773685569002 ∧ code e773685569002 = 9569778591210 := by decide
theorem cert_e773685569002 : check e773685569002 [] .sourceHead = true := by decide
def e773685569134 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e773685569134 : Closed e773685569134 ∧ code e773685569134 = 9569778591342 := by decide
theorem cert_e773685569134 : check e773685569134 [] .sourceHead = true := by decide
def e773685569146 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e773685569146 : Closed e773685569146 ∧ code e773685569146 = 9569778591354 := by decide
theorem cert_e773685569146 : check e773685569146 [] .sourceHead = true := by decide
def e773685569434 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e773685569434 : Closed e773685569434 ∧ code e773685569434 = 9569778591642 := by decide
theorem cert_e773685569434 : check e773685569434 [] .sourceHead = true := by decide
def e773685572310 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e773685572310 : Closed e773685572310 ∧ code e773685572310 = 9569778594518 := by decide
theorem cert_e773685572310 : check e773685572310 [] .sourceHead = true := by decide
def e773685572314 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e773685572314 : Closed e773685572314 ∧ code e773685572314 = 9569778594522 := by decide
theorem cert_e773685572314 : check e773685572314 [] .sourceHead = true := by decide
def e773685572330 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e773685572330 : Closed e773685572330 ∧ code e773685572330 = 9569778594538 := by decide
theorem cert_e773685572330 : check e773685572330 [] .sourceHead = true := by decide
def e773685572406 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e773685572406 : Closed e773685572406 ∧ code e773685572406 = 9569778594614 := by decide
theorem cert_e773685572406 : check e773685572406 [] .sourceHead = true := by decide
def e773685572410 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e773685572410 : Closed e773685572410 ∧ code e773685572410 = 9569778594618 := by decide
theorem cert_e773685572410 : check e773685572410 [] .sourceHead = true := by decide
def e773685572506 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e773685572506 : Closed e773685572506 ∧ code e773685572506 = 9569778594714 := by decide
theorem cert_e773685572506 : check e773685572506 [] .sourceHead = true := by decide
def e773685709678 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e773685709678 : Closed e773685709678 ∧ code e773685709678 = 9569778731886 := by decide
theorem cert_e773685709678 : check e773685709678 [] .sourceHead = true := by decide
def e773685709686 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e773685709686 : Closed e773685709686 ∧ code e773685709686 = 9569778731894 := by decide
theorem cert_e773685709686 : check e773685709686 [] .sourceHead = true := by decide
def e773685709742 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e773685709742 : Closed e773685709742 ∧ code e773685709742 = 9569778731950 := by decide
theorem cert_e773685709742 : check e773685709742 [] .sourceHead = true := by decide
def e773685709754 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e773685709754 : Closed e773685709754 ∧ code e773685709754 = 9569778731962 := by decide
theorem cert_e773685709754 : check e773685709754 [] .sourceHead = true := by decide
def e773685709782 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e773685709782 : Closed e773685709782 ∧ code e773685709782 = 9569778731990 := by decide
theorem cert_e773685709782 : check e773685709782 [] .sourceHead = true := by decide
def e773685709786 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e773685709786 : Closed e773685709786 ∧ code e773685709786 = 9569778731994 := by decide
theorem cert_e773685709786 : check e773685709786 [] .sourceHead = true := by decide
def e773685710062 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e773685710062 : Closed e773685710062 ∧ code e773685710062 = 9569778732270 := by decide
theorem cert_e773685710062 : check e773685710062 [] .sourceHead = true := by decide
def e773685710070 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e773685710070 : Closed e773685710070 ∧ code e773685710070 = 9569778732278 := by decide
theorem cert_e773685710070 : check e773685710070 [] .sourceHead = true := by decide
def e773685710446 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e773685710446 : Closed e773685710446 ∧ code e773685710446 = 9569778732654 := by decide
theorem cert_e773685710446 : check e773685710446 [] .sourceHead = true := by decide
def e773685710458 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e773685710458 : Closed e773685710458 ∧ code e773685710458 = 9569778732666 := by decide
theorem cert_e773685710458 : check e773685710458 [] .sourceHead = true := by decide
def e773685710646 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e773685710646 : Closed e773685710646 ∧ code e773685710646 = 9569778732854 := by decide
theorem cert_e773685710646 : check e773685710646 [] .sourceHead = true := by decide
def e773685710650 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e773685710650 : Closed e773685710650 ∧ code e773685710650 = 9569778732858 := by decide
theorem cert_e773685710650 : check e773685710650 [] .sourceHead = true := by decide
def e775459745134 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e775459745134 : Closed e775459745134 ∧ code e775459745134 = 9571552767342 := by decide
theorem cert_e775459745134 : check e775459745134 [] .sourceHead = true := by decide
def e775459745142 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e775459745142 : Closed e775459745142 ∧ code e775459745142 = 9571552767350 := by decide
theorem cert_e775459745142 : check e775459745142 [] .sourceHead = true := by decide
def e775459745198 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e775459745198 : Closed e775459745198 ∧ code e775459745198 = 9571552767406 := by decide
theorem cert_e775459745198 : check e775459745198 [] .sourceHead = true := by decide
def e775459745210 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e775459745210 : Closed e775459745210 ∧ code e775459745210 = 9571552767418 := by decide
theorem cert_e775459745210 : check e775459745210 [] .sourceHead = true := by decide
def e775459745238 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e775459745238 : Closed e775459745238 ∧ code e775459745238 = 9571552767446 := by decide
theorem cert_e775459745238 : check e775459745238 [] .sourceHead = true := by decide
def e775459745242 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e775459745242 : Closed e775459745242 ∧ code e775459745242 = 9571552767450 := by decide
theorem cert_e775459745242 : check e775459745242 [] .sourceHead = true := by decide
def e775459745454 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e775459745454 : Closed e775459745454 ∧ code e775459745454 = 9571552767662 := by decide
theorem cert_e775459745454 : check e775459745454 [] .sourceHead = true := by decide
def e775459745466 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e775459745466 : Closed e775459745466 ∧ code e775459745466 = 9571552767674 := by decide
theorem cert_e775459745466 : check e775459745466 [] .sourceHead = true := by decide
def e775459745514 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e775459745514 : Closed e775459745514 ∧ code e775459745514 = 9571552767722 := by decide
theorem cert_e775459745514 : check e775459745514 [] .sourceHead = true := by decide
def e775459745622 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e775459745622 : Closed e775459745622 ∧ code e775459745622 = 9571552767830 := by decide
theorem cert_e775459745622 : check e775459745622 [] .sourceHead = true := by decide
def e775459745626 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e775459745626 : Closed e775459745626 ∧ code e775459745626 = 9571552767834 := by decide
theorem cert_e775459745626 : check e775459745626 [] .sourceHead = true := by decide
def e775459745642 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e775459745642 : Closed e775459745642 ∧ code e775459745642 = 9571552767850 := by decide
theorem cert_e775459745642 : check e775459745642 [] .sourceHead = true := by decide
def e775459746670 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e775459746670 : Closed e775459746670 ∧ code e775459746670 = 9571552768878 := by decide
theorem cert_e775459746670 : check e775459746670 [] .sourceHead = true := by decide
def e775459746678 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e775459746678 : Closed e775459746678 ∧ code e775459746678 = 9571552768886 := by decide
theorem cert_e775459746678 : check e775459746678 [] .sourceHead = true := by decide
def e775459746734 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e775459746734 : Closed e775459746734 ∧ code e775459746734 = 9571552768942 := by decide
theorem cert_e775459746734 : check e775459746734 [] .sourceHead = true := by decide
def e775459746746 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e775459746746 : Closed e775459746746 ∧ code e775459746746 = 9571552768954 := by decide
theorem cert_e775459746746 : check e775459746746 [] .sourceHead = true := by decide
def e775459746774 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e775459746774 : Closed e775459746774 ∧ code e775459746774 = 9571552768982 := by decide
theorem cert_e775459746774 : check e775459746774 [] .sourceHead = true := by decide
def e775459746778 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e775459746778 : Closed e775459746778 ∧ code e775459746778 = 9571552768986 := by decide
theorem cert_e775459746778 : check e775459746778 [] .sourceHead = true := by decide
def e775459747054 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e775459747054 : Closed e775459747054 ∧ code e775459747054 = 9571552769262 := by decide
theorem cert_e775459747054 : check e775459747054 [] .sourceHead = true := by decide
def e775459747062 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e775459747062 : Closed e775459747062 ∧ code e775459747062 = 9571552769270 := by decide
theorem cert_e775459747062 : check e775459747062 [] .sourceHead = true := by decide
def e775459747438 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e775459747438 : Closed e775459747438 ∧ code e775459747438 = 9571552769646 := by decide
theorem cert_e775459747438 : check e775459747438 [] .sourceHead = true := by decide
def e775459747450 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e775459747450 : Closed e775459747450 ∧ code e775459747450 = 9571552769658 := by decide
theorem cert_e775459747450 : check e775459747450 [] .sourceHead = true := by decide
def e775459747638 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e775459747638 : Closed e775459747638 ∧ code e775459747638 = 9571552769846 := by decide
theorem cert_e775459747638 : check e775459747638 [] .sourceHead = true := by decide
def e775459747642 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e775459747642 : Closed e775459747642 ∧ code e775459747642 = 9571552769850 := by decide
theorem cert_e775459747642 : check e775459747642 [] .sourceHead = true := by decide
def e775459748270 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e775459748270 : Closed e775459748270 ∧ code e775459748270 = 9571552770478 := by decide
theorem cert_e775459748270 : check e775459748270 [] .sourceHead = true := by decide
def e775459748282 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e775459748282 : Closed e775459748282 ∧ code e775459748282 = 9571552770490 := by decide
theorem cert_e775459748282 : check e775459748282 [] .sourceHead = true := by decide
def e775459748330 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e775459748330 : Closed e775459748330 ∧ code e775459748330 = 9571552770538 := by decide
theorem cert_e775459748330 : check e775459748330 [] .sourceHead = true := by decide
def e775459748462 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e775459748462 : Closed e775459748462 ∧ code e775459748462 = 9571552770670 := by decide
theorem cert_e775459748462 : check e775459748462 [] .sourceHead = true := by decide
def e775459748474 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e775459748474 : Closed e775459748474 ∧ code e775459748474 = 9571552770682 := by decide
theorem cert_e775459748474 : check e775459748474 [] .sourceHead = true := by decide
def e775459748762 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e775459748762 : Closed e775459748762 ∧ code e775459748762 = 9571552770970 := by decide
theorem cert_e775459748762 : check e775459748762 [] .sourceHead = true := by decide
def e775459749078 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e775459749078 : Closed e775459749078 ∧ code e775459749078 = 9571552771286 := by decide
theorem cert_e775459749078 : check e775459749078 [] .sourceHead = true := by decide
def e775459749082 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e775459749082 : Closed e775459749082 ∧ code e775459749082 = 9571552771290 := by decide
theorem cert_e775459749082 : check e775459749082 [] .sourceHead = true := by decide
def e775459749098 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e775459749098 : Closed e775459749098 ∧ code e775459749098 = 9571552771306 := by decide
theorem cert_e775459749098 : check e775459749098 [] .sourceHead = true := by decide
def e775459749174 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e775459749174 : Closed e775459749174 ∧ code e775459749174 = 9571552771382 := by decide
theorem cert_e775459749174 : check e775459749174 [] .sourceHead = true := by decide
def e775459749178 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e775459749178 : Closed e775459749178 ∧ code e775459749178 = 9571552771386 := by decide
theorem cert_e775459749178 : check e775459749178 [] .sourceHead = true := by decide
def e775459749274 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e775459749274 : Closed e775459749274 ∧ code e775459749274 = 9571552771482 := by decide
theorem cert_e775459749274 : check e775459749274 [] .sourceHead = true := by decide
def e775459752814 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e775459752814 : Closed e775459752814 ∧ code e775459752814 = 9571552775022 := by decide
theorem cert_e775459752814 : check e775459752814 [] .sourceHead = true := by decide
def e775459752822 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e775459752822 : Closed e775459752822 ∧ code e775459752822 = 9571552775030 := by decide
theorem cert_e775459752822 : check e775459752822 [] .sourceHead = true := by decide
def e775459752878 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e775459752878 : Closed e775459752878 ∧ code e775459752878 = 9571552775086 := by decide
theorem cert_e775459752878 : check e775459752878 [] .sourceHead = true := by decide
def e775459752890 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e775459752890 : Closed e775459752890 ∧ code e775459752890 = 9571552775098 := by decide
theorem cert_e775459752890 : check e775459752890 [] .sourceHead = true := by decide
def e775459752918 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e775459752918 : Closed e775459752918 ∧ code e775459752918 = 9571552775126 := by decide
theorem cert_e775459752918 : check e775459752918 [] .sourceHead = true := by decide
def e775459752922 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e775459752922 : Closed e775459752922 ∧ code e775459752922 = 9571552775130 := by decide
theorem cert_e775459752922 : check e775459752922 [] .sourceHead = true := by decide
def e775459753198 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e775459753198 : Closed e775459753198 ∧ code e775459753198 = 9571552775406 := by decide
theorem cert_e775459753198 : check e775459753198 [] .sourceHead = true := by decide
def e775459753206 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e775459753206 : Closed e775459753206 ∧ code e775459753206 = 9571552775414 := by decide
theorem cert_e775459753206 : check e775459753206 [] .sourceHead = true := by decide
def e775459753582 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e775459753582 : Closed e775459753582 ∧ code e775459753582 = 9571552775790 := by decide
theorem cert_e775459753582 : check e775459753582 [] .sourceHead = true := by decide
def e775459753594 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e775459753594 : Closed e775459753594 ∧ code e775459753594 = 9571552775802 := by decide
theorem cert_e775459753594 : check e775459753594 [] .sourceHead = true := by decide
def e775459753782 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e775459753782 : Closed e775459753782 ∧ code e775459753782 = 9571552775990 := by decide
theorem cert_e775459753782 : check e775459753782 [] .sourceHead = true := by decide
def e775459753786 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e775459753786 : Closed e775459753786 ∧ code e775459753786 = 9571552775994 := by decide
theorem cert_e775459753786 : check e775459753786 [] .sourceHead = true := by decide
def e775459759534 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e775459759534 : Closed e775459759534 ∧ code e775459759534 = 9571552781742 := by decide
theorem cert_e775459759534 : check e775459759534 [] .sourceHead = true := by decide
def e775459759546 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e775459759546 : Closed e775459759546 ∧ code e775459759546 = 9571552781754 := by decide
theorem cert_e775459759546 : check e775459759546 [] .sourceHead = true := by decide
def e775459759594 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e775459759594 : Closed e775459759594 ∧ code e775459759594 = 9571552781802 := by decide
theorem cert_e775459759594 : check e775459759594 [] .sourceHead = true := by decide
def e775459759726 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e775459759726 : Closed e775459759726 ∧ code e775459759726 = 9571552781934 := by decide
theorem cert_e775459759726 : check e775459759726 [] .sourceHead = true := by decide
def e775459759738 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e775459759738 : Closed e775459759738 ∧ code e775459759738 = 9571552781946 := by decide
theorem cert_e775459759738 : check e775459759738 [] .sourceHead = true := by decide
def e775459760026 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e775459760026 : Closed e775459760026 ∧ code e775459760026 = 9571552782234 := by decide
theorem cert_e775459760026 : check e775459760026 [] .sourceHead = true := by decide
def e775459762902 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e775459762902 : Closed e775459762902 ∧ code e775459762902 = 9571552785110 := by decide
theorem cert_e775459762902 : check e775459762902 [] .sourceHead = true := by decide
def e775459762906 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e775459762906 : Closed e775459762906 ∧ code e775459762906 = 9571552785114 := by decide
theorem cert_e775459762906 : check e775459762906 [] .sourceHead = true := by decide
def e775459762922 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e775459762922 : Closed e775459762922 ∧ code e775459762922 = 9571552785130 := by decide
theorem cert_e775459762922 : check e775459762922 [] .sourceHead = true := by decide
def e775459762998 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e775459762998 : Closed e775459762998 ∧ code e775459762998 = 9571552785206 := by decide
theorem cert_e775459762998 : check e775459762998 [] .sourceHead = true := by decide
def e775459763002 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e775459763002 : Closed e775459763002 ∧ code e775459763002 = 9571552785210 := by decide
theorem cert_e775459763002 : check e775459763002 [] .sourceHead = true := by decide
def e775459763098 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e775459763098 : Closed e775459763098 ∧ code e775459763098 = 9571552785306 := by decide
theorem cert_e775459763098 : check e775459763098 [] .sourceHead = true := by decide
def e775459900270 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e775459900270 : Closed e775459900270 ∧ code e775459900270 = 9571552922478 := by decide
theorem cert_e775459900270 : check e775459900270 [] .sourceHead = true := by decide
def e775459900278 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e775459900278 : Closed e775459900278 ∧ code e775459900278 = 9571552922486 := by decide
theorem cert_e775459900278 : check e775459900278 [] .sourceHead = true := by decide
def e775459900334 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e775459900334 : Closed e775459900334 ∧ code e775459900334 = 9571552922542 := by decide
theorem cert_e775459900334 : check e775459900334 [] .sourceHead = true := by decide
def e775459900346 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e775459900346 : Closed e775459900346 ∧ code e775459900346 = 9571552922554 := by decide
theorem cert_e775459900346 : check e775459900346 [] .sourceHead = true := by decide
def e775459900374 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e775459900374 : Closed e775459900374 ∧ code e775459900374 = 9571552922582 := by decide
theorem cert_e775459900374 : check e775459900374 [] .sourceHead = true := by decide
def e775459900378 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e775459900378 : Closed e775459900378 ∧ code e775459900378 = 9571552922586 := by decide
theorem cert_e775459900378 : check e775459900378 [] .sourceHead = true := by decide
def e775459900654 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e775459900654 : Closed e775459900654 ∧ code e775459900654 = 9571552922862 := by decide
theorem cert_e775459900654 : check e775459900654 [] .sourceHead = true := by decide
def e775459900662 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e775459900662 : Closed e775459900662 ∧ code e775459900662 = 9571552922870 := by decide
theorem cert_e775459900662 : check e775459900662 [] .sourceHead = true := by decide
def e775459901038 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e775459901038 : Closed e775459901038 ∧ code e775459901038 = 9571552923246 := by decide
theorem cert_e775459901038 : check e775459901038 [] .sourceHead = true := by decide
def e775459901050 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e775459901050 : Closed e775459901050 ∧ code e775459901050 = 9571552923258 := by decide
theorem cert_e775459901050 : check e775459901050 [] .sourceHead = true := by decide
end Blc.Floor43
