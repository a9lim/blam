import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411629841850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2411629841850 : Closed e2411629841850 ∧ code e2411629841850 = 11207722864058 := by decide
theorem cert_e2411629841850 : check e2411629841850 [[],[]] .chain = true := by decide
def e2411629841898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2411629841898 : Closed e2411629841898 ∧ code e2411629841898 = 11207722864106 := by decide
theorem cert_e2411629841898 : check e2411629841898 [[],[]] .chain = true := by decide
def e2411629842094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2411629842094 : Closed e2411629842094 ∧ code e2411629842094 = 11207722864302 := by decide
theorem cert_e2411629842094 : check e2411629842094 [[],[]] .chain = true := by decide
def e2411629842106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2411629842106 : Closed e2411629842106 ∧ code e2411629842106 = 11207722864314 := by decide
theorem cert_e2411629842106 : check e2411629842106 [[],[]] .chain = true := by decide
def e2411629842346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2411629842346 : Closed e2411629842346 ∧ code e2411629842346 = 11207722864554 := by decide
theorem cert_e2411629842346 : check e2411629842346 [[],[]] .chain = true := by decide
def e2411629843310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2411629843310 : Closed e2411629843310 ∧ code e2411629843310 = 11207722865518 := by decide
theorem cert_e2411629843310 : check e2411629843310 [[],[]] .chain = true := by decide
def e2411629843318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2411629843318 : Closed e2411629843318 ∧ code e2411629843318 = 11207722865526 := by decide
theorem cert_e2411629843318 : check e2411629843318 [[],[]] .chain = true := by decide
def e2411629843374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2411629843374 : Closed e2411629843374 ∧ code e2411629843374 = 11207722865582 := by decide
theorem cert_e2411629843374 : check e2411629843374 [[],[]] .chain = true := by decide
def e2411629843386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2411629843386 : Closed e2411629843386 ∧ code e2411629843386 = 11207722865594 := by decide
theorem cert_e2411629843386 : check e2411629843386 [[],[]] .chain = true := by decide
def e2411629843414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2411629843414 : Closed e2411629843414 ∧ code e2411629843414 = 11207722865622 := by decide
theorem cert_e2411629843414 : check e2411629843414 [[],[]] .chain = true := by decide
def e2411629843418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2411629843418 : Closed e2411629843418 ∧ code e2411629843418 = 11207722865626 := by decide
theorem cert_e2411629843418 : check e2411629843418 [[],[]] .chain = true := by decide
def e2411629843694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629843694 : Closed e2411629843694 ∧ code e2411629843694 = 11207722865902 := by decide
theorem cert_e2411629843694 : check e2411629843694 [[],[]] .chain = true := by decide
def e2411629843702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629843702 : Closed e2411629843702 ∧ code e2411629843702 = 11207722865910 := by decide
theorem cert_e2411629843702 : check e2411629843702 [[],[]] .chain = true := by decide
def e2411629844078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629844078 : Closed e2411629844078 ∧ code e2411629844078 = 11207722866286 := by decide
theorem cert_e2411629844078 : check e2411629844078 [[],[]] .chain = true := by decide
def e2411629844090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629844090 : Closed e2411629844090 ∧ code e2411629844090 = 11207722866298 := by decide
theorem cert_e2411629844090 : check e2411629844090 [[],[]] .chain = true := by decide
def e2411629844278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629844278 : Closed e2411629844278 ∧ code e2411629844278 = 11207722866486 := by decide
theorem cert_e2411629844278 : check e2411629844278 [[],[]] .chain = true := by decide
def e2411629844282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629844282 : Closed e2411629844282 ∧ code e2411629844282 = 11207722866490 := by decide
theorem cert_e2411629844282 : check e2411629844282 [[],[]] .chain = true := by decide
def e2411629844718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2411629844718 : Closed e2411629844718 ∧ code e2411629844718 = 11207722866926 := by decide
theorem cert_e2411629844718 : check e2411629844718 [[],[]] .chain = true := by decide
def e2411629844726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2411629844726 : Closed e2411629844726 ∧ code e2411629844726 = 11207722866934 := by decide
theorem cert_e2411629844726 : check e2411629844726 [[],[]] .chain = true := by decide
def e2411629844910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2411629844910 : Closed e2411629844910 ∧ code e2411629844910 = 11207722867118 := by decide
theorem cert_e2411629844910 : check e2411629844910 [[],[]] .chain = true := by decide
def e2411629844922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2411629844922 : Closed e2411629844922 ∧ code e2411629844922 = 11207722867130 := by decide
theorem cert_e2411629844922 : check e2411629844922 [[],[]] .chain = true := by decide
def e2411629844970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2411629844970 : Closed e2411629844970 ∧ code e2411629844970 = 11207722867178 := by decide
theorem cert_e2411629844970 : check e2411629844970 [[],[]] .chain = true := by decide
def e2411629845102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629845102 : Closed e2411629845102 ∧ code e2411629845102 = 11207722867310 := by decide
theorem cert_e2411629845102 : check e2411629845102 [[],[]] .chain = true := by decide
def e2411629845114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629845114 : Closed e2411629845114 ∧ code e2411629845114 = 11207722867322 := by decide
theorem cert_e2411629845114 : check e2411629845114 [[],[]] .chain = true := by decide
def e2411629845278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2411629845278 : Closed e2411629845278 ∧ code e2411629845278 = 11207722867486 := by decide
theorem cert_e2411629845278 : check e2411629845278 [[],[]] .chain = true := by decide
def e2411629845390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2411629845390 : Closed e2411629845390 ∧ code e2411629845390 = 11207722867598 := by decide
theorem cert_e2411629845390 : check e2411629845390 [[],[]] .chain = true := by decide
def e2411629845402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629845402 : Closed e2411629845402 ∧ code e2411629845402 = 11207722867610 := by decide
theorem cert_e2411629845402 : check e2411629845402 [[],[]] .chain = true := by decide
def e2411629845614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2411629845614 : Closed e2411629845614 ∧ code e2411629845614 = 11207722867822 := by decide
theorem cert_e2411629845614 : check e2411629845614 [[],[]] .chain = true := by decide
def e2411629845626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2411629845626 : Closed e2411629845626 ∧ code e2411629845626 = 11207722867834 := by decide
theorem cert_e2411629845626 : check e2411629845626 [[],[]] .chain = true := by decide
def e2411629845790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2411629845790 : Closed e2411629845790 ∧ code e2411629845790 = 11207722867998 := by decide
theorem cert_e2411629845790 : check e2411629845790 [[],[]] .chain = true := by decide
def e2411629845958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2411629845958 : Closed e2411629845958 ∧ code e2411629845958 = 11207722868166 := by decide
theorem cert_e2411629845958 : check e2411629845958 [[],[]] .chain = true := by decide
def e2411629846070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629846070 : Closed e2411629846070 ∧ code e2411629846070 = 11207722868278 := by decide
theorem cert_e2411629846070 : check e2411629846070 [[],[]] .chain = true := by decide
def e2411629846074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629846074 : Closed e2411629846074 ∧ code e2411629846074 = 11207722868282 := by decide
theorem cert_e2411629846074 : check e2411629846074 [[],[]] .chain = true := by decide
def e2411629846122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2411629846122 : Closed e2411629846122 ∧ code e2411629846122 = 11207722868330 := by decide
theorem cert_e2411629846122 : check e2411629846122 [[],[]] .chain = true := by decide
def e2411629846158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629846158 : Closed e2411629846158 ∧ code e2411629846158 = 11207722868366 := by decide
theorem cert_e2411629846158 : check e2411629846158 [[],[]] .chain = true := by decide
def e2411629846170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629846170 : Closed e2411629846170 ∧ code e2411629846170 = 11207722868378 := by decide
theorem cert_e2411629846170 : check e2411629846170 [[],[]] .chain = true := by decide
def e2411629846214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629846214 : Closed e2411629846214 ∧ code e2411629846214 = 11207722868422 := by decide
theorem cert_e2411629846214 : check e2411629846214 [[],[]] .chain = true := by decide
def e2411629850990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2411629850990 : Closed e2411629850990 ∧ code e2411629850990 = 11207722873198 := by decide
theorem cert_e2411629850990 : check e2411629850990 [[],[]] .chain = true := by decide
def e2411629850998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2411629850998 : Closed e2411629850998 ∧ code e2411629850998 = 11207722873206 := by decide
theorem cert_e2411629850998 : check e2411629850998 [[],[]] .chain = true := by decide
def e2411629851054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2411629851054 : Closed e2411629851054 ∧ code e2411629851054 = 11207722873262 := by decide
theorem cert_e2411629851054 : check e2411629851054 [[],[]] .chain = true := by decide
def e2411629851066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2411629851066 : Closed e2411629851066 ∧ code e2411629851066 = 11207722873274 := by decide
theorem cert_e2411629851066 : check e2411629851066 [[],[]] .chain = true := by decide
def e2411629851114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2411629851114 : Closed e2411629851114 ∧ code e2411629851114 = 11207722873322 := by decide
theorem cert_e2411629851114 : check e2411629851114 [[],[]] .chain = true := by decide
def e2411629851758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2411629851758 : Closed e2411629851758 ∧ code e2411629851758 = 11207722873966 := by decide
theorem cert_e2411629851758 : check e2411629851758 [[],[]] .chain = true := by decide
def e2411629851770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2411629851770 : Closed e2411629851770 ∧ code e2411629851770 = 11207722873978 := by decide
theorem cert_e2411629851770 : check e2411629851770 [[],[]] .chain = true := by decide
def e2411629851934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2411629851934 : Closed e2411629851934 ∧ code e2411629851934 = 11207722874142 := by decide
theorem cert_e2411629851934 : check e2411629851934 [[],[]] .chain = true := by decide
def e2411629852102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2411629852102 : Closed e2411629852102 ∧ code e2411629852102 = 11207722874310 := by decide
theorem cert_e2411629852102 : check e2411629852102 [[],[]] .chain = true := by decide
def e2411629852206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2411629852206 : Closed e2411629852206 ∧ code e2411629852206 = 11207722874414 := by decide
theorem cert_e2411629852206 : check e2411629852206 [[],[]] .chain = true := by decide
def e2411629852386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2411629852386 : Closed e2411629852386 ∧ code e2411629852386 = 11207722874594 := by decide
theorem cert_e2411629852386 : check e2411629852386 [[],[]] .chain = true := by decide
def e2411629852398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e2411629852398 : Closed e2411629852398 ∧ code e2411629852398 = 11207722874606 := by decide
theorem cert_e2411629852398 : check e2411629852398 [[],[]] .sourceHead = true := by decide
def e2411629852438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629852438 : Closed e2411629852438 ∧ code e2411629852438 = 11207722874646 := by decide
theorem cert_e2411629852438 : check e2411629852438 [[],[]] .chain = true := by decide
def e2411629852442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629852442 : Closed e2411629852442 ∧ code e2411629852442 = 11207722874650 := by decide
theorem cert_e2411629852442 : check e2411629852442 [[],[]] .chain = true := by decide
def e2411629852486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629852486 : Closed e2411629852486 ∧ code e2411629852486 = 11207722874694 := by decide
theorem cert_e2411629852486 : check e2411629852486 [[],[]] .chain = true := by decide
def e2411629852514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629852514 : Closed e2411629852514 ∧ code e2411629852514 = 11207722874722 := by decide
theorem cert_e2411629852514 : check e2411629852514 [[],[]] .chain = true := by decide
def e2411629852526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2411629852526 : Closed e2411629852526 ∧ code e2411629852526 = 11207722874734 := by decide
theorem cert_e2411629852526 : check e2411629852526 [[],[]] .sourceHead = true := by decide
def e2411629852534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2411629852534 : Closed e2411629852534 ∧ code e2411629852534 = 11207722874742 := by decide
theorem cert_e2411629852534 : check e2411629852534 [[],[]] .sourceHead = true := by decide
def e2411629852846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2411629852846 : Closed e2411629852846 ∧ code e2411629852846 = 11207722875054 := by decide
theorem cert_e2411629852846 : check e2411629852846 [[],[]] .chain = true := by decide
def e2411629852858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2411629852858 : Closed e2411629852858 ∧ code e2411629852858 = 11207722875066 := by decide
theorem cert_e2411629852858 : check e2411629852858 [[],[]] .chain = true := by decide
def e2411629853230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2411629853230 : Closed e2411629853230 ∧ code e2411629853230 = 11207722875438 := by decide
theorem cert_e2411629853230 : check e2411629853230 [[],[]] .chain = true := by decide
def e2411629853410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2411629853410 : Closed e2411629853410 ∧ code e2411629853410 = 11207722875618 := by decide
theorem cert_e2411629853410 : check e2411629853410 [[],[]] .chain = true := by decide
def e2411629853422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2411629853422 : Closed e2411629853422 ∧ code e2411629853422 = 11207722875630 := by decide
theorem cert_e2411629853422 : check e2411629853422 [[],[]] .sourceHead = true := by decide
def e2411629853578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2411629853578 : Closed e2411629853578 ∧ code e2411629853578 = 11207722875786 := by decide
theorem cert_e2411629853578 : check e2411629853578 [[],[]] .chain = true := by decide
def e2411629853602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2411629853602 : Closed e2411629853602 ∧ code e2411629853602 = 11207722875810 := by decide
theorem cert_e2411629853602 : check e2411629853602 [[],[]] .chain = true := by decide
def e2411629853614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2411629853614 : Closed e2411629853614 ∧ code e2411629853614 = 11207722875822 := by decide
theorem cert_e2411629853614 : check e2411629853614 [[],[]] .sourceHead = true := by decide
def e2411629853626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2411629853626 : Closed e2411629853626 ∧ code e2411629853626 = 11207722875834 := by decide
theorem cert_e2411629853626 : check e2411629853626 [[],[]] .sourceHead = true := by decide
def e2411629853782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2411629853782 : Closed e2411629853782 ∧ code e2411629853782 = 11207722875990 := by decide
theorem cert_e2411629853782 : check e2411629853782 [[],[]] .chain = true := by decide
def e2411629853786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2411629853786 : Closed e2411629853786 ∧ code e2411629853786 = 11207722875994 := by decide
theorem cert_e2411629853786 : check e2411629853786 [[],[]] .chain = true := by decide
def e2411629853802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2411629853802 : Closed e2411629853802 ∧ code e2411629853802 = 11207722876010 := by decide
theorem cert_e2411629853802 : check e2411629853802 [[],[]] .chain = true := by decide
def e2411629853974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629853974 : Closed e2411629853974 ∧ code e2411629853974 = 11207722876182 := by decide
theorem cert_e2411629853974 : check e2411629853974 [[],[]] .chain = true := by decide
def e2411629853978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629853978 : Closed e2411629853978 ∧ code e2411629853978 = 11207722876186 := by decide
theorem cert_e2411629853978 : check e2411629853978 [[],[]] .chain = true := by decide
def e2411629854022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629854022 : Closed e2411629854022 ∧ code e2411629854022 = 11207722876230 := by decide
theorem cert_e2411629854022 : check e2411629854022 [[],[]] .chain = true := by decide
def e2411629854050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629854050 : Closed e2411629854050 ∧ code e2411629854050 = 11207722876258 := by decide
theorem cert_e2411629854050 : check e2411629854050 [[],[]] .chain = true := by decide
def e2411629854062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2411629854062 : Closed e2411629854062 ∧ code e2411629854062 = 11207722876270 := by decide
theorem cert_e2411629854062 : check e2411629854062 [[],[]] .sourceHead = true := by decide
def e2411629854070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2411629854070 : Closed e2411629854070 ∧ code e2411629854070 = 11207722876278 := by decide
theorem cert_e2411629854070 : check e2411629854070 [[],[]] .sourceHead = true := by decide
def e2411629854090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2411629854090 : Closed e2411629854090 ∧ code e2411629854090 = 11207722876298 := by decide
theorem cert_e2411629854090 : check e2411629854090 [[],[]] .chain = true := by decide
def e2411629854114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2411629854114 : Closed e2411629854114 ∧ code e2411629854114 = 11207722876322 := by decide
theorem cert_e2411629854114 : check e2411629854114 [[],[]] .chain = true := by decide
def e2411629854126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2411629854126 : Closed e2411629854126 ∧ code e2411629854126 = 11207722876334 := by decide
theorem cert_e2411629854126 : check e2411629854126 [[],[]] .sourceHead = true := by decide
def e2411629854138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2411629854138 : Closed e2411629854138 ∧ code e2411629854138 = 11207722876346 := by decide
theorem cert_e2411629854138 : check e2411629854138 [[],[]] .sourceHead = true := by decide
def e2411629854166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2411629854166 : Closed e2411629854166 ∧ code e2411629854166 = 11207722876374 := by decide
theorem cert_e2411629854166 : check e2411629854166 [[],[]] .sourceHead = true := by decide
def e2411629854170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2411629854170 : Closed e2411629854170 ∧ code e2411629854170 = 11207722876378 := by decide
theorem cert_e2411629854170 : check e2411629854170 [[],[]] .sourceHead = true := by decide
def e2411629855214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2411629855214 : Closed e2411629855214 ∧ code e2411629855214 = 11207722877422 := by decide
theorem cert_e2411629855214 : check e2411629855214 [[],[]] .chain = true := by decide
def e2411629855222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2411629855222 : Closed e2411629855222 ∧ code e2411629855222 = 11207722877430 := by decide
theorem cert_e2411629855222 : check e2411629855222 [[],[]] .chain = true := by decide
def e2411629855598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2411629855598 : Closed e2411629855598 ∧ code e2411629855598 = 11207722877806 := by decide
theorem cert_e2411629855598 : check e2411629855598 [[],[]] .chain = true := by decide
def e2411629855610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e2411629855610 : Closed e2411629855610 ∧ code e2411629855610 = 11207722877818 := by decide
theorem cert_e2411629855610 : check e2411629855610 [[],[]] .chain = true := by decide
def e2411629855662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2411629855662 : Closed e2411629855662 ∧ code e2411629855662 = 11207722877870 := by decide
theorem cert_e2411629855662 : check e2411629855662 [[],[]] .chain = true := by decide
def e2411629855722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e2411629855722 : Closed e2411629855722 ∧ code e2411629855722 = 11207722877930 := by decide
theorem cert_e2411629855722 : check e2411629855722 [[],[]] .chain = true := by decide
def e2411629855982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629855982 : Closed e2411629855982 ∧ code e2411629855982 = 11207722878190 := by decide
theorem cert_e2411629855982 : check e2411629855982 [[],[]] .chain = true := by decide
def e2411629855990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629855990 : Closed e2411629855990 ∧ code e2411629855990 = 11207722878198 := by decide
theorem cert_e2411629855990 : check e2411629855990 [[],[]] .chain = true := by decide
def e2411629856366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629856366 : Closed e2411629856366 ∧ code e2411629856366 = 11207722878574 := by decide
theorem cert_e2411629856366 : check e2411629856366 [[],[]] .chain = true := by decide
def e2411629856378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629856378 : Closed e2411629856378 ∧ code e2411629856378 = 11207722878586 := by decide
theorem cert_e2411629856378 : check e2411629856378 [[],[]] .chain = true := by decide
def e2411629856542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2411629856542 : Closed e2411629856542 ∧ code e2411629856542 = 11207722878750 := by decide
theorem cert_e2411629856542 : check e2411629856542 [[],[]] .chain = true := by decide
def e2411629856654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2411629856654 : Closed e2411629856654 ∧ code e2411629856654 = 11207722878862 := by decide
theorem cert_e2411629856654 : check e2411629856654 [[],[]] .chain = true := by decide
def e2411629856666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629856666 : Closed e2411629856666 ∧ code e2411629856666 = 11207722878874 := by decide
theorem cert_e2411629856666 : check e2411629856666 [[],[]] .chain = true := by decide
def e2411629857902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2411629857902 : Closed e2411629857902 ∧ code e2411629857902 = 11207722880110 := by decide
theorem cert_e2411629857902 : check e2411629857902 [[],[]] .chain = true := by decide
def e2411629857914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411629857914 : Closed e2411629857914 ∧ code e2411629857914 = 11207722880122 := by decide
theorem cert_e2411629857914 : check e2411629857914 [[],[]] .chain = true := by decide
def e2411629858078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2411629858078 : Closed e2411629858078 ∧ code e2411629858078 = 11207722880286 := by decide
theorem cert_e2411629858078 : check e2411629858078 [[],[]] .chain = true := by decide
def e2411629858246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411629858246 : Closed e2411629858246 ∧ code e2411629858246 = 11207722880454 := by decide
theorem cert_e2411629858246 : check e2411629858246 [[],[]] .chain = true := by decide
def e2411629858350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2411629858350 : Closed e2411629858350 ∧ code e2411629858350 = 11207722880558 := by decide
theorem cert_e2411629858350 : check e2411629858350 [[],[]] .chain = true := by decide
def e2411629858530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2411629858530 : Closed e2411629858530 ∧ code e2411629858530 = 11207722880738 := by decide
theorem cert_e2411629858530 : check e2411629858530 [[],[]] .chain = true := by decide
def e2411629858542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2411629858542 : Closed e2411629858542 ∧ code e2411629858542 = 11207722880750 := by decide
theorem cert_e2411629858542 : check e2411629858542 [[],[]] .sourceHead = true := by decide
def e2411629858582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411629858582 : Closed e2411629858582 ∧ code e2411629858582 = 11207722880790 := by decide
theorem cert_e2411629858582 : check e2411629858582 [[],[]] .chain = true := by decide
def e2411629858586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411629858586 : Closed e2411629858586 ∧ code e2411629858586 = 11207722880794 := by decide
theorem cert_e2411629858586 : check e2411629858586 [[],[]] .chain = true := by decide
def e2411629858630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411629858630 : Closed e2411629858630 ∧ code e2411629858630 = 11207722880838 := by decide
theorem cert_e2411629858630 : check e2411629858630 [[],[]] .chain = true := by decide
def e2411629858658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411629858658 : Closed e2411629858658 ∧ code e2411629858658 = 11207722880866 := by decide
theorem cert_e2411629858658 : check e2411629858658 [[],[]] .chain = true := by decide
def e2411629858670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2411629858670 : Closed e2411629858670 ∧ code e2411629858670 = 11207722880878 := by decide
theorem cert_e2411629858670 : check e2411629858670 [[],[]] .sourceHead = true := by decide
def e2411629858678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2411629858678 : Closed e2411629858678 ∧ code e2411629858678 = 11207722880886 := by decide
theorem cert_e2411629858678 : check e2411629858678 [[],[]] .sourceHead = true := by decide
def e2411629859038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2411629859038 : Closed e2411629859038 ∧ code e2411629859038 = 11207722881246 := by decide
theorem cert_e2411629859038 : check e2411629859038 [[],[]] .chain = true := by decide
def e2411629859066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2411629859066 : Closed e2411629859066 ∧ code e2411629859066 = 11207722881274 := by decide
theorem cert_e2411629859066 : check e2411629859066 [[],[]] .chain = true := by decide
def e2411629859614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2411629859614 : Closed e2411629859614 ∧ code e2411629859614 = 11207722881822 := by decide
theorem cert_e2411629859614 : check e2411629859614 [[],[]] .chain = true := by decide
def e2411629859782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2411629859782 : Closed e2411629859782 ∧ code e2411629859782 = 11207722881990 := by decide
theorem cert_e2411629859782 : check e2411629859782 [[],[]] .chain = true := by decide
def e2411629860926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2411629860926 : Closed e2411629860926 ∧ code e2411629860926 = 11207722883134 := by decide
theorem cert_e2411629860926 : check e2411629860926 [[],[]] .chain = true := by decide
def e2411629861346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2411629861346 : Closed e2411629861346 ∧ code e2411629861346 = 11207722883554 := by decide
theorem cert_e2411629861346 : check e2411629861346 [[],[]] .chain = true := by decide
def e2411629861358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2411629861358 : Closed e2411629861358 ∧ code e2411629861358 = 11207722883566 := by decide
theorem cert_e2411629861358 : check e2411629861358 [[],[]] .sourceHead = true := by decide
def e2411629861918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2411629861918 : Closed e2411629861918 ∧ code e2411629861918 = 11207722884126 := by decide
theorem cert_e2411629861918 : check e2411629861918 [[],[]] .chain = true := by decide
def e2411629861942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411629861942 : Closed e2411629861942 ∧ code e2411629861942 = 11207722884150 := by decide
theorem cert_e2411629861942 : check e2411629861942 [[],[]] .chain = true := by decide
def e2411629861946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411629861946 : Closed e2411629861946 ∧ code e2411629861946 = 11207722884154 := by decide
theorem cert_e2411629861946 : check e2411629861946 [[],[]] .chain = true := by decide
def e2411629862086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411629862086 : Closed e2411629862086 ∧ code e2411629862086 = 11207722884294 := by decide
theorem cert_e2411629862086 : check e2411629862086 [[],[]] .chain = true := by decide
def e2411629862114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411629862114 : Closed e2411629862114 ∧ code e2411629862114 = 11207722884322 := by decide
theorem cert_e2411629862114 : check e2411629862114 [[],[]] .chain = true := by decide
def e2411629862126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629862126 : Closed e2411629862126 ∧ code e2411629862126 = 11207722884334 := by decide
theorem cert_e2411629862126 : check e2411629862126 [[],[]] .sourceHead = true := by decide
def e2411629862134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629862134 : Closed e2411629862134 ∧ code e2411629862134 = 11207722884342 := by decide
theorem cert_e2411629862134 : check e2411629862134 [[],[]] .sourceHead = true := by decide
def e2411629863150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2411629863150 : Closed e2411629863150 ∧ code e2411629863150 = 11207722885358 := by decide
theorem cert_e2411629863150 : check e2411629863150 [[],[]] .chain = true := by decide
def e2411629863162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2411629863162 : Closed e2411629863162 ∧ code e2411629863162 = 11207722885370 := by decide
theorem cert_e2411629863162 : check e2411629863162 [[],[]] .chain = true := by decide
def e2411629863534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629863534 : Closed e2411629863534 ∧ code e2411629863534 = 11207722885742 := by decide
theorem cert_e2411629863534 : check e2411629863534 [[],[]] .chain = true := by decide
def e2411629863546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629863546 : Closed e2411629863546 ∧ code e2411629863546 = 11207722885754 := by decide
theorem cert_e2411629863546 : check e2411629863546 [[],[]] .chain = true := by decide
def e2411629863710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2411629863710 : Closed e2411629863710 ∧ code e2411629863710 = 11207722885918 := by decide
theorem cert_e2411629863710 : check e2411629863710 [[],[]] .chain = true := by decide
def e2411629863878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2411629863878 : Closed e2411629863878 ∧ code e2411629863878 = 11207722886086 := by decide
theorem cert_e2411629863878 : check e2411629863878 [[],[]] .chain = true := by decide
def e2411629864494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2411629864494 : Closed e2411629864494 ∧ code e2411629864494 = 11207722886702 := by decide
theorem cert_e2411629864494 : check e2411629864494 [[],[]] .chain = true := by decide
def e2411629864674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2411629864674 : Closed e2411629864674 ∧ code e2411629864674 = 11207722886882 := by decide
theorem cert_e2411629864674 : check e2411629864674 [[],[]] .chain = true := by decide
def e2411629864686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2411629864686 : Closed e2411629864686 ∧ code e2411629864686 = 11207722886894 := by decide
theorem cert_e2411629864686 : check e2411629864686 [[],[]] .sourceHead = true := by decide
def e2411629864842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2411629864842 : Closed e2411629864842 ∧ code e2411629864842 = 11207722887050 := by decide
theorem cert_e2411629864842 : check e2411629864842 [[],[]] .chain = true := by decide
def e2411629864866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2411629864866 : Closed e2411629864866 ∧ code e2411629864866 = 11207722887074 := by decide
theorem cert_e2411629864866 : check e2411629864866 [[],[]] .chain = true := by decide
def e2411629864878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2411629864878 : Closed e2411629864878 ∧ code e2411629864878 = 11207722887086 := by decide
theorem cert_e2411629864878 : check e2411629864878 [[],[]] .sourceHead = true := by decide
def e2411629864890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2411629864890 : Closed e2411629864890 ∧ code e2411629864890 = 11207722887098 := by decide
theorem cert_e2411629864890 : check e2411629864890 [[],[]] .sourceHead = true := by decide
def e2411629865022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2411629865022 : Closed e2411629865022 ∧ code e2411629865022 = 11207722887230 := by decide
theorem cert_e2411629865022 : check e2411629865022 [[],[]] .chain = true := by decide
def e2411629865442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2411629865442 : Closed e2411629865442 ∧ code e2411629865442 = 11207722887650 := by decide
theorem cert_e2411629865442 : check e2411629865442 [[],[]] .chain = true := by decide
def e2411629865454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2411629865454 : Closed e2411629865454 ∧ code e2411629865454 = 11207722887662 := by decide
theorem cert_e2411629865454 : check e2411629865454 [[],[]] .sourceHead = true := by decide
def e2411629866510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2411629866510 : Closed e2411629866510 ∧ code e2411629866510 = 11207722888718 := by decide
theorem cert_e2411629866510 : check e2411629866510 [[],[]] .chain = true := by decide
def e2411629866594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2411629866594 : Closed e2411629866594 ∧ code e2411629866594 = 11207722888802 := by decide
theorem cert_e2411629866594 : check e2411629866594 [[],[]] .chain = true := by decide
def e2411629866606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629866606 : Closed e2411629866606 ∧ code e2411629866606 = 11207722888814 := by decide
theorem cert_e2411629866606 : check e2411629866606 [[],[]] .sourceHead = true := by decide
def e2411629866618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629866618 : Closed e2411629866618 ∧ code e2411629866618 = 11207722888826 := by decide
theorem cert_e2411629866618 : check e2411629866618 [[],[]] .sourceHead = true := by decide
def e2411629867126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2411629867126 : Closed e2411629867126 ∧ code e2411629867126 = 11207722889334 := by decide
theorem cert_e2411629867126 : check e2411629867126 [[],[]] .chain = true := by decide
def e2411629867130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411629867130 : Closed e2411629867130 ∧ code e2411629867130 = 11207722889338 := by decide
theorem cert_e2411629867130 : check e2411629867130 [[],[]] .chain = true := by decide
def e2411629867226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2411629867226 : Closed e2411629867226 ∧ code e2411629867226 = 11207722889434 := by decide
theorem cert_e2411629867226 : check e2411629867226 [[],[]] .chain = true := by decide
def e2411629867242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2411629867242 : Closed e2411629867242 ∧ code e2411629867242 = 11207722889450 := by decide
theorem cert_e2411629867242 : check e2411629867242 [[],[]] .chain = true := by decide
def e2411629867318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629867318 : Closed e2411629867318 ∧ code e2411629867318 = 11207722889526 := by decide
theorem cert_e2411629867318 : check e2411629867318 [[],[]] .chain = true := by decide
def e2411629867322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629867322 : Closed e2411629867322 ∧ code e2411629867322 = 11207722889530 := by decide
theorem cert_e2411629867322 : check e2411629867322 [[],[]] .chain = true := by decide
def e2411629867406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2411629867406 : Closed e2411629867406 ∧ code e2411629867406 = 11207722889614 := by decide
theorem cert_e2411629867406 : check e2411629867406 [[],[]] .chain = true := by decide
def e2411629867418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629867418 : Closed e2411629867418 ∧ code e2411629867418 = 11207722889626 := by decide
theorem cert_e2411629867418 : check e2411629867418 [[],[]] .chain = true := by decide
def e2411629867462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411629867462 : Closed e2411629867462 ∧ code e2411629867462 = 11207722889670 := by decide
theorem cert_e2411629867462 : check e2411629867462 [[],[]] .chain = true := by decide
def e2411629867798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411629867798 : Closed e2411629867798 ∧ code e2411629867798 = 11207722890006 := by decide
theorem cert_e2411629867798 : check e2411629867798 [[],[]] .chain = true := by decide
def e2411629867802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411629867802 : Closed e2411629867802 ∧ code e2411629867802 = 11207722890010 := by decide
theorem cert_e2411629867802 : check e2411629867802 [[],[]] .chain = true := by decide
def e2411629867846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411629867846 : Closed e2411629867846 ∧ code e2411629867846 = 11207722890054 := by decide
theorem cert_e2411629867846 : check e2411629867846 [[],[]] .chain = true := by decide
def e2411629867874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411629867874 : Closed e2411629867874 ∧ code e2411629867874 = 11207722890082 := by decide
theorem cert_e2411629867874 : check e2411629867874 [[],[]] .chain = true := by decide
def e2411629867886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2411629867886 : Closed e2411629867886 ∧ code e2411629867886 = 11207722890094 := by decide
theorem cert_e2411629867886 : check e2411629867886 [[],[]] .sourceHead = true := by decide
def e2411629867894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2411629867894 : Closed e2411629867894 ∧ code e2411629867894 = 11207722890102 := by decide
theorem cert_e2411629867894 : check e2411629867894 [[],[]] .sourceHead = true := by decide
def e2411629867914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2411629867914 : Closed e2411629867914 ∧ code e2411629867914 = 11207722890122 := by decide
theorem cert_e2411629867914 : check e2411629867914 [[],[]] .chain = true := by decide
def e2411629867938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2411629867938 : Closed e2411629867938 ∧ code e2411629867938 = 11207722890146 := by decide
theorem cert_e2411629867938 : check e2411629867938 [[],[]] .chain = true := by decide
def e2411629867950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2411629867950 : Closed e2411629867950 ∧ code e2411629867950 = 11207722890158 := by decide
theorem cert_e2411629867950 : check e2411629867950 [[],[]] .sourceHead = true := by decide
def e2411629867962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2411629867962 : Closed e2411629867962 ∧ code e2411629867962 = 11207722890170 := by decide
theorem cert_e2411629867962 : check e2411629867962 [[],[]] .sourceHead = true := by decide
def e2411629867990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2411629867990 : Closed e2411629867990 ∧ code e2411629867990 = 11207722890198 := by decide
theorem cert_e2411629867990 : check e2411629867990 [[],[]] .sourceHead = true := by decide
def e2411629867994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2411629867994 : Closed e2411629867994 ∧ code e2411629867994 = 11207722890202 := by decide
theorem cert_e2411629867994 : check e2411629867994 [[],[]] .sourceHead = true := by decide
end Blc.Floor43
