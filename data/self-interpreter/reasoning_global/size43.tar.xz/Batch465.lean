import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406717046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406717046 : Closed e2422406717046 ∧ code e2422406717046 = 11218499739254 := by decide
theorem cert_e2422406717046 : check e2422406717046 [[],[]] .chain = true := by decide
def e2422406720878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422406720878 : Closed e2422406720878 ∧ code e2422406720878 = 11218499743086 := by decide
theorem cert_e2422406720878 : check e2422406720878 [[],[]] .chain = true := by decide
def e2422406720886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422406720886 : Closed e2422406720886 ∧ code e2422406720886 = 11218499743094 := by decide
theorem cert_e2422406720886 : check e2422406720886 [[],[]] .chain = true := by decide
def e2422406720942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422406720942 : Closed e2422406720942 ∧ code e2422406720942 = 11218499743150 := by decide
theorem cert_e2422406720942 : check e2422406720942 [[],[]] .chain = true := by decide
def e2422406720954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422406720954 : Closed e2422406720954 ∧ code e2422406720954 = 11218499743162 := by decide
theorem cert_e2422406720954 : check e2422406720954 [[],[]] .chain = true := by decide
def e2422406720982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422406720982 : Closed e2422406720982 ∧ code e2422406720982 = 11218499743190 := by decide
theorem cert_e2422406720982 : check e2422406720982 [[],[]] .chain = true := by decide
def e2422406720986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422406720986 : Closed e2422406720986 ∧ code e2422406720986 = 11218499743194 := by decide
theorem cert_e2422406720986 : check e2422406720986 [[],[]] .chain = true := by decide
def e2422406721198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422406721198 : Closed e2422406721198 ∧ code e2422406721198 = 11218499743406 := by decide
theorem cert_e2422406721198 : check e2422406721198 [[],[]] .chain = true := by decide
def e2422406721210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422406721210 : Closed e2422406721210 ∧ code e2422406721210 = 11218499743418 := by decide
theorem cert_e2422406721210 : check e2422406721210 [[],[]] .chain = true := by decide
def e2422406721258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422406721258 : Closed e2422406721258 ∧ code e2422406721258 = 11218499743466 := by decide
theorem cert_e2422406721258 : check e2422406721258 [[],[]] .chain = true := by decide
def e2422406721366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422406721366 : Closed e2422406721366 ∧ code e2422406721366 = 11218499743574 := by decide
theorem cert_e2422406721366 : check e2422406721366 [[],[]] .chain = true := by decide
def e2422406721370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422406721370 : Closed e2422406721370 ∧ code e2422406721370 = 11218499743578 := by decide
theorem cert_e2422406721370 : check e2422406721370 [[],[]] .chain = true := by decide
def e2422406721386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422406721386 : Closed e2422406721386 ∧ code e2422406721386 = 11218499743594 := by decide
theorem cert_e2422406721386 : check e2422406721386 [[],[]] .chain = true := by decide
def e2422406722414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422406722414 : Closed e2422406722414 ∧ code e2422406722414 = 11218499744622 := by decide
theorem cert_e2422406722414 : check e2422406722414 [[],[]] .chain = true := by decide
def e2422406722422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422406722422 : Closed e2422406722422 ∧ code e2422406722422 = 11218499744630 := by decide
theorem cert_e2422406722422 : check e2422406722422 [[],[]] .chain = true := by decide
def e2422406722478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422406722478 : Closed e2422406722478 ∧ code e2422406722478 = 11218499744686 := by decide
theorem cert_e2422406722478 : check e2422406722478 [[],[]] .chain = true := by decide
def e2422406722490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422406722490 : Closed e2422406722490 ∧ code e2422406722490 = 11218499744698 := by decide
theorem cert_e2422406722490 : check e2422406722490 [[],[]] .chain = true := by decide
def e2422406722518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422406722518 : Closed e2422406722518 ∧ code e2422406722518 = 11218499744726 := by decide
theorem cert_e2422406722518 : check e2422406722518 [[],[]] .chain = true := by decide
def e2422406722522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422406722522 : Closed e2422406722522 ∧ code e2422406722522 = 11218499744730 := by decide
theorem cert_e2422406722522 : check e2422406722522 [[],[]] .chain = true := by decide
def e2422406722798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406722798 : Closed e2422406722798 ∧ code e2422406722798 = 11218499745006 := by decide
theorem cert_e2422406722798 : check e2422406722798 [[],[]] .chain = true := by decide
def e2422406722806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406722806 : Closed e2422406722806 ∧ code e2422406722806 = 11218499745014 := by decide
theorem cert_e2422406722806 : check e2422406722806 [[],[]] .chain = true := by decide
def e2422406723182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406723182 : Closed e2422406723182 ∧ code e2422406723182 = 11218499745390 := by decide
theorem cert_e2422406723182 : check e2422406723182 [[],[]] .chain = true := by decide
def e2422406723194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406723194 : Closed e2422406723194 ∧ code e2422406723194 = 11218499745402 := by decide
theorem cert_e2422406723194 : check e2422406723194 [[],[]] .chain = true := by decide
def e2422406723382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406723382 : Closed e2422406723382 ∧ code e2422406723382 = 11218499745590 := by decide
theorem cert_e2422406723382 : check e2422406723382 [[],[]] .chain = true := by decide
def e2422406723386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406723386 : Closed e2422406723386 ∧ code e2422406723386 = 11218499745594 := by decide
theorem cert_e2422406723386 : check e2422406723386 [[],[]] .chain = true := by decide
def e2422406723822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422406723822 : Closed e2422406723822 ∧ code e2422406723822 = 11218499746030 := by decide
theorem cert_e2422406723822 : check e2422406723822 [[],[]] .chain = true := by decide
def e2422406723830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422406723830 : Closed e2422406723830 ∧ code e2422406723830 = 11218499746038 := by decide
theorem cert_e2422406723830 : check e2422406723830 [[],[]] .chain = true := by decide
def e2422406724014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422406724014 : Closed e2422406724014 ∧ code e2422406724014 = 11218499746222 := by decide
theorem cert_e2422406724014 : check e2422406724014 [[],[]] .chain = true := by decide
def e2422406724026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422406724026 : Closed e2422406724026 ∧ code e2422406724026 = 11218499746234 := by decide
theorem cert_e2422406724026 : check e2422406724026 [[],[]] .chain = true := by decide
def e2422406724074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422406724074 : Closed e2422406724074 ∧ code e2422406724074 = 11218499746282 := by decide
theorem cert_e2422406724074 : check e2422406724074 [[],[]] .chain = true := by decide
def e2422406724206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406724206 : Closed e2422406724206 ∧ code e2422406724206 = 11218499746414 := by decide
theorem cert_e2422406724206 : check e2422406724206 [[],[]] .chain = true := by decide
def e2422406724218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406724218 : Closed e2422406724218 ∧ code e2422406724218 = 11218499746426 := by decide
theorem cert_e2422406724218 : check e2422406724218 [[],[]] .chain = true := by decide
def e2422406724382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422406724382 : Closed e2422406724382 ∧ code e2422406724382 = 11218499746590 := by decide
theorem cert_e2422406724382 : check e2422406724382 [[],[]] .chain = true := by decide
def e2422406724494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422406724494 : Closed e2422406724494 ∧ code e2422406724494 = 11218499746702 := by decide
theorem cert_e2422406724494 : check e2422406724494 [[],[]] .chain = true := by decide
def e2422406724506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406724506 : Closed e2422406724506 ∧ code e2422406724506 = 11218499746714 := by decide
theorem cert_e2422406724506 : check e2422406724506 [[],[]] .chain = true := by decide
def e2422406724726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422406724726 : Closed e2422406724726 ∧ code e2422406724726 = 11218499746934 := by decide
theorem cert_e2422406724726 : check e2422406724726 [[],[]] .chain = true := by decide
def e2422406724822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422406724822 : Closed e2422406724822 ∧ code e2422406724822 = 11218499747030 := by decide
theorem cert_e2422406724822 : check e2422406724822 [[],[]] .chain = true := by decide
def e2422406724826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422406724826 : Closed e2422406724826 ∧ code e2422406724826 = 11218499747034 := by decide
theorem cert_e2422406724826 : check e2422406724826 [[],[]] .chain = true := by decide
def e2422406724842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422406724842 : Closed e2422406724842 ∧ code e2422406724842 = 11218499747050 := by decide
theorem cert_e2422406724842 : check e2422406724842 [[],[]] .chain = true := by decide
def e2422406724918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406724918 : Closed e2422406724918 ∧ code e2422406724918 = 11218499747126 := by decide
theorem cert_e2422406724918 : check e2422406724918 [[],[]] .chain = true := by decide
def e2422406724922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406724922 : Closed e2422406724922 ∧ code e2422406724922 = 11218499747130 := by decide
theorem cert_e2422406724922 : check e2422406724922 [[],[]] .chain = true := by decide
def e2422406725006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422406725006 : Closed e2422406725006 ∧ code e2422406725006 = 11218499747214 := by decide
theorem cert_e2422406725006 : check e2422406725006 [[],[]] .chain = true := by decide
def e2422406725018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406725018 : Closed e2422406725018 ∧ code e2422406725018 = 11218499747226 := by decide
theorem cert_e2422406725018 : check e2422406725018 [[],[]] .chain = true := by decide
def e2422406726622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422406726622 : Closed e2422406726622 ∧ code e2422406726622 = 11218499748830 := by decide
theorem cert_e2422406726622 : check e2422406726622 [[],[]] .chain = true := by decide
def e2422406726638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422406726638 : Closed e2422406726638 ∧ code e2422406726638 = 11218499748846 := by decide
theorem cert_e2422406726638 : check e2422406726638 [[],[]] .chain = true := by decide
def e2422406728558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422406728558 : Closed e2422406728558 ∧ code e2422406728558 = 11218499750766 := by decide
theorem cert_e2422406728558 : check e2422406728558 [[],[]] .chain = true := by decide
def e2422406728566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422406728566 : Closed e2422406728566 ∧ code e2422406728566 = 11218499750774 := by decide
theorem cert_e2422406728566 : check e2422406728566 [[],[]] .chain = true := by decide
def e2422406728622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422406728622 : Closed e2422406728622 ∧ code e2422406728622 = 11218499750830 := by decide
theorem cert_e2422406728622 : check e2422406728622 [[],[]] .chain = true := by decide
def e2422406728634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422406728634 : Closed e2422406728634 ∧ code e2422406728634 = 11218499750842 := by decide
theorem cert_e2422406728634 : check e2422406728634 [[],[]] .chain = true := by decide
def e2422406728662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422406728662 : Closed e2422406728662 ∧ code e2422406728662 = 11218499750870 := by decide
theorem cert_e2422406728662 : check e2422406728662 [[],[]] .chain = true := by decide
def e2422406728666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422406728666 : Closed e2422406728666 ∧ code e2422406728666 = 11218499750874 := by decide
theorem cert_e2422406728666 : check e2422406728666 [[],[]] .chain = true := by decide
def e2422406728942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422406728942 : Closed e2422406728942 ∧ code e2422406728942 = 11218499751150 := by decide
theorem cert_e2422406728942 : check e2422406728942 [[],[]] .chain = true := by decide
def e2422406728950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422406728950 : Closed e2422406728950 ∧ code e2422406728950 = 11218499751158 := by decide
theorem cert_e2422406728950 : check e2422406728950 [[],[]] .chain = true := by decide
def e2422406729326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422406729326 : Closed e2422406729326 ∧ code e2422406729326 = 11218499751534 := by decide
theorem cert_e2422406729326 : check e2422406729326 [[],[]] .chain = true := by decide
def e2422406729338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422406729338 : Closed e2422406729338 ∧ code e2422406729338 = 11218499751546 := by decide
theorem cert_e2422406729338 : check e2422406729338 [[],[]] .chain = true := by decide
def e2422406729526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422406729526 : Closed e2422406729526 ∧ code e2422406729526 = 11218499751734 := by decide
theorem cert_e2422406729526 : check e2422406729526 [[],[]] .chain = true := by decide
def e2422406729530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422406729530 : Closed e2422406729530 ∧ code e2422406729530 = 11218499751738 := by decide
theorem cert_e2422406729530 : check e2422406729530 [[],[]] .chain = true := by decide
def e2422406734302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422406734302 : Closed e2422406734302 ∧ code e2422406734302 = 11218499756510 := by decide
theorem cert_e2422406734302 : check e2422406734302 [[],[]] .chain = true := by decide
def e2422406734326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422406734326 : Closed e2422406734326 ∧ code e2422406734326 = 11218499756534 := by decide
theorem cert_e2422406734326 : check e2422406734326 [[],[]] .chain = true := by decide
def e2422406735278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422406735278 : Closed e2422406735278 ∧ code e2422406735278 = 11218499757486 := by decide
theorem cert_e2422406735278 : check e2422406735278 [[],[]] .chain = true := by decide
def e2422406735290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422406735290 : Closed e2422406735290 ∧ code e2422406735290 = 11218499757498 := by decide
theorem cert_e2422406735290 : check e2422406735290 [[],[]] .chain = true := by decide
def e2422406735338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422406735338 : Closed e2422406735338 ∧ code e2422406735338 = 11218499757546 := by decide
theorem cert_e2422406735338 : check e2422406735338 [[],[]] .chain = true := by decide
def e2422406735470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422406735470 : Closed e2422406735470 ∧ code e2422406735470 = 11218499757678 := by decide
theorem cert_e2422406735470 : check e2422406735470 [[],[]] .chain = true := by decide
def e2422406735482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422406735482 : Closed e2422406735482 ∧ code e2422406735482 = 11218499757690 := by decide
theorem cert_e2422406735482 : check e2422406735482 [[],[]] .chain = true := by decide
def e2422406735646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422406735646 : Closed e2422406735646 ∧ code e2422406735646 = 11218499757854 := by decide
theorem cert_e2422406735646 : check e2422406735646 [[],[]] .chain = true := by decide
def e2422406735758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422406735758 : Closed e2422406735758 ∧ code e2422406735758 = 11218499757966 := by decide
theorem cert_e2422406735758 : check e2422406735758 [[],[]] .chain = true := by decide
def e2422406735770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422406735770 : Closed e2422406735770 ∧ code e2422406735770 = 11218499757978 := by decide
theorem cert_e2422406735770 : check e2422406735770 [[],[]] .chain = true := by decide
def e2422406738158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422406738158 : Closed e2422406738158 ∧ code e2422406738158 = 11218499760366 := by decide
theorem cert_e2422406738158 : check e2422406738158 [[],[]] .chain = true := by decide
def e2422406738166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422406738166 : Closed e2422406738166 ∧ code e2422406738166 = 11218499760374 := by decide
theorem cert_e2422406738166 : check e2422406738166 [[],[]] .chain = true := by decide
def e2422406738646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422406738646 : Closed e2422406738646 ∧ code e2422406738646 = 11218499760854 := by decide
theorem cert_e2422406738646 : check e2422406738646 [[],[]] .chain = true := by decide
def e2422406738650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422406738650 : Closed e2422406738650 ∧ code e2422406738650 = 11218499760858 := by decide
theorem cert_e2422406738650 : check e2422406738650 [[],[]] .chain = true := by decide
def e2422406738666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422406738666 : Closed e2422406738666 ∧ code e2422406738666 = 11218499760874 := by decide
theorem cert_e2422406738666 : check e2422406738666 [[],[]] .chain = true := by decide
def e2422406738742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422406738742 : Closed e2422406738742 ∧ code e2422406738742 = 11218499760950 := by decide
theorem cert_e2422406738742 : check e2422406738742 [[],[]] .chain = true := by decide
def e2422406738746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422406738746 : Closed e2422406738746 ∧ code e2422406738746 = 11218499760954 := by decide
theorem cert_e2422406738746 : check e2422406738746 [[],[]] .chain = true := by decide
def e2422406738830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422406738830 : Closed e2422406738830 ∧ code e2422406738830 = 11218499761038 := by decide
theorem cert_e2422406738830 : check e2422406738830 [[],[]] .chain = true := by decide
def e2422406738842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422406738842 : Closed e2422406738842 ∧ code e2422406738842 = 11218499761050 := by decide
theorem cert_e2422406738842 : check e2422406738842 [[],[]] .chain = true := by decide
def e2422406743790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2422406743790 : Closed e2422406743790 ∧ code e2422406743790 = 11218499765998 := by decide
theorem cert_e2422406743790 : check e2422406743790 [[],[]] .chain = true := by decide
def e2422406743798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))
theorem wire_e2422406743798 : Closed e2422406743798 ∧ code e2422406743798 = 11218499766006 := by decide
theorem cert_e2422406743798 : check e2422406743798 [[],[]] .chain = true := by decide
def e2422406743982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2422406743982 : Closed e2422406743982 ∧ code e2422406743982 = 11218499766190 := by decide
theorem cert_e2422406743982 : check e2422406743982 [[],[]] .chain = true := by decide
def e2422406744022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))
theorem wire_e2422406744022 : Closed e2422406744022 ∧ code e2422406744022 = 11218499766230 := by decide
theorem cert_e2422406744022 : check e2422406744022 [[],[]] .chain = true := by decide
def e2422406745326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406745326 : Closed e2422406745326 ∧ code e2422406745326 = 11218499767534 := by decide
theorem cert_e2422406745326 : check e2422406745326 [[],[]] .chain = true := by decide
def e2422406745334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406745334 : Closed e2422406745334 ∧ code e2422406745334 = 11218499767542 := by decide
theorem cert_e2422406745334 : check e2422406745334 [[],[]] .chain = true := by decide
def e2422406745710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406745710 : Closed e2422406745710 ∧ code e2422406745710 = 11218499767918 := by decide
theorem cert_e2422406745710 : check e2422406745710 [[],[]] .chain = true := by decide
def e2422406745722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406745722 : Closed e2422406745722 ∧ code e2422406745722 = 11218499767930 := by decide
theorem cert_e2422406745722 : check e2422406745722 [[],[]] .chain = true := by decide
def e2422406745910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406745910 : Closed e2422406745910 ∧ code e2422406745910 = 11218499768118 := by decide
theorem cert_e2422406745910 : check e2422406745910 [[],[]] .chain = true := by decide
def e2422406745914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406745914 : Closed e2422406745914 ∧ code e2422406745914 = 11218499768122 := by decide
theorem cert_e2422406745914 : check e2422406745914 [[],[]] .chain = true := by decide
def e2422406748398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422406748398 : Closed e2422406748398 ∧ code e2422406748398 = 11218499770606 := by decide
theorem cert_e2422406748398 : check e2422406748398 [[],[]] .chain = true := by decide
def e2422406748406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422406748406 : Closed e2422406748406 ∧ code e2422406748406 = 11218499770614 := by decide
theorem cert_e2422406748406 : check e2422406748406 [[],[]] .chain = true := by decide
def e2422406748958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422406748958 : Closed e2422406748958 ∧ code e2422406748958 = 11218499771166 := by decide
theorem cert_e2422406748958 : check e2422406748958 [[],[]] .chain = true := by decide
def e2422406749070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422406749070 : Closed e2422406749070 ∧ code e2422406749070 = 11218499771278 := by decide
theorem cert_e2422406749070 : check e2422406749070 [[],[]] .chain = true := by decide
def e2422406749294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422406749294 : Closed e2422406749294 ∧ code e2422406749294 = 11218499771502 := by decide
theorem cert_e2422406749294 : check e2422406749294 [[],[]] .chain = true := by decide
def e2422406749306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422406749306 : Closed e2422406749306 ∧ code e2422406749306 = 11218499771514 := by decide
theorem cert_e2422406749306 : check e2422406749306 [[],[]] .chain = true := by decide
def e2422406749470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422406749470 : Closed e2422406749470 ∧ code e2422406749470 = 11218499771678 := by decide
theorem cert_e2422406749470 : check e2422406749470 [[],[]] .chain = true := by decide
def e2422406749638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422406749638 : Closed e2422406749638 ∧ code e2422406749638 = 11218499771846 := by decide
theorem cert_e2422406749638 : check e2422406749638 [[],[]] .chain = true := by decide
def e2422406749750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406749750 : Closed e2422406749750 ∧ code e2422406749750 = 11218499771958 := by decide
theorem cert_e2422406749750 : check e2422406749750 [[],[]] .chain = true := by decide
def e2422406749754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406749754 : Closed e2422406749754 ∧ code e2422406749754 = 11218499771962 := by decide
theorem cert_e2422406749754 : check e2422406749754 [[],[]] .chain = true := by decide
def e2422406749838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406749838 : Closed e2422406749838 ∧ code e2422406749838 = 11218499772046 := by decide
theorem cert_e2422406749838 : check e2422406749838 [[],[]] .chain = true := by decide
def e2422406749894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406749894 : Closed e2422406749894 ∧ code e2422406749894 = 11218499772102 := by decide
theorem cert_e2422406749894 : check e2422406749894 [[],[]] .chain = true := by decide
def e2422406752030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422406752030 : Closed e2422406752030 ∧ code e2422406752030 = 11218499774238 := by decide
theorem cert_e2422406752030 : check e2422406752030 [[],[]] .chain = true := by decide
def e2422406752142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422406752142 : Closed e2422406752142 ∧ code e2422406752142 = 11218499774350 := by decide
theorem cert_e2422406752142 : check e2422406752142 [[],[]] .chain = true := by decide
def e2422406754526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422406754526 : Closed e2422406754526 ∧ code e2422406754526 = 11218499776734 := by decide
theorem cert_e2422406754526 : check e2422406754526 [[],[]] .chain = true := by decide
def e2422406754554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422406754554 : Closed e2422406754554 ∧ code e2422406754554 = 11218499776762 := by decide
theorem cert_e2422406754554 : check e2422406754554 [[],[]] .chain = true := by decide
def e2422406755102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422406755102 : Closed e2422406755102 ∧ code e2422406755102 = 11218499777310 := by decide
theorem cert_e2422406755102 : check e2422406755102 [[],[]] .chain = true := by decide
def e2422406755270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422406755270 : Closed e2422406755270 ∧ code e2422406755270 = 11218499777478 := by decide
theorem cert_e2422406755270 : check e2422406755270 [[],[]] .chain = true := by decide
def e2422406756462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422406756462 : Closed e2422406756462 ∧ code e2422406756462 = 11218499778670 := by decide
theorem cert_e2422406756462 : check e2422406756462 [[],[]] .chain = true := by decide
def e2422406756474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422406756474 : Closed e2422406756474 ∧ code e2422406756474 = 11218499778682 := by decide
theorem cert_e2422406756474 : check e2422406756474 [[],[]] .chain = true := by decide
def e2422406756750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422406756750 : Closed e2422406756750 ∧ code e2422406756750 = 11218499778958 := by decide
theorem cert_e2422406756750 : check e2422406756750 [[],[]] .chain = true := by decide
def e2422406756806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422406756806 : Closed e2422406756806 ∧ code e2422406756806 = 11218499779014 := by decide
theorem cert_e2422406756806 : check e2422406756806 [[],[]] .chain = true := by decide
def e2422406758894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422406758894 : Closed e2422406758894 ∧ code e2422406758894 = 11218499781102 := by decide
theorem cert_e2422406758894 : check e2422406758894 [[],[]] .chain = true := by decide
def e2422406758902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2422406758902 : Closed e2422406758902 ∧ code e2422406758902 = 11218499781110 := by decide
theorem cert_e2422406758902 : check e2422406758902 [[],[]] .chain = true := by decide
def e2422406759278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422406759278 : Closed e2422406759278 ∧ code e2422406759278 = 11218499781486 := by decide
theorem cert_e2422406759278 : check e2422406759278 [[],[]] .chain = true := by decide
def e2422406759290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e2422406759290 : Closed e2422406759290 ∧ code e2422406759290 = 11218499781498 := by decide
theorem cert_e2422406759290 : check e2422406759290 [[],[]] .chain = true := by decide
def e2422406759342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422406759342 : Closed e2422406759342 ∧ code e2422406759342 = 11218499781550 := by decide
theorem cert_e2422406759342 : check e2422406759342 [[],[]] .chain = true := by decide
def e2422406759402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e2422406759402 : Closed e2422406759402 ∧ code e2422406759402 = 11218499781610 := by decide
theorem cert_e2422406759402 : check e2422406759402 [[],[]] .chain = true := by decide
def e2422406759662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406759662 : Closed e2422406759662 ∧ code e2422406759662 = 11218499781870 := by decide
theorem cert_e2422406759662 : check e2422406759662 [[],[]] .chain = true := by decide
def e2422406759670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406759670 : Closed e2422406759670 ∧ code e2422406759670 = 11218499781878 := by decide
theorem cert_e2422406759670 : check e2422406759670 [[],[]] .chain = true := by decide
def e2422406760046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406760046 : Closed e2422406760046 ∧ code e2422406760046 = 11218499782254 := by decide
theorem cert_e2422406760046 : check e2422406760046 [[],[]] .chain = true := by decide
def e2422406760058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406760058 : Closed e2422406760058 ∧ code e2422406760058 = 11218499782266 := by decide
theorem cert_e2422406760058 : check e2422406760058 [[],[]] .chain = true := by decide
def e2422406760222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422406760222 : Closed e2422406760222 ∧ code e2422406760222 = 11218499782430 := by decide
theorem cert_e2422406760222 : check e2422406760222 [[],[]] .chain = true := by decide
def e2422406760334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2422406760334 : Closed e2422406760334 ∧ code e2422406760334 = 11218499782542 := by decide
theorem cert_e2422406760334 : check e2422406760334 [[],[]] .chain = true := by decide
def e2422406760346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406760346 : Closed e2422406760346 ∧ code e2422406760346 = 11218499782554 := by decide
theorem cert_e2422406760346 : check e2422406760346 [[],[]] .chain = true := by decide
def e2422406761582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422406761582 : Closed e2422406761582 ∧ code e2422406761582 = 11218499783790 := by decide
theorem cert_e2422406761582 : check e2422406761582 [[],[]] .chain = true := by decide
def e2422406761594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422406761594 : Closed e2422406761594 ∧ code e2422406761594 = 11218499783802 := by decide
theorem cert_e2422406761594 : check e2422406761594 [[],[]] .chain = true := by decide
def e2422406761758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422406761758 : Closed e2422406761758 ∧ code e2422406761758 = 11218499783966 := by decide
theorem cert_e2422406761758 : check e2422406761758 [[],[]] .chain = true := by decide
def e2422406761926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422406761926 : Closed e2422406761926 ∧ code e2422406761926 = 11218499784134 := by decide
theorem cert_e2422406761926 : check e2422406761926 [[],[]] .chain = true := by decide
def e2422406762030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406762030 : Closed e2422406762030 ∧ code e2422406762030 = 11218499784238 := by decide
theorem cert_e2422406762030 : check e2422406762030 [[],[]] .chain = true := by decide
def e2422406762210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406762210 : Closed e2422406762210 ∧ code e2422406762210 = 11218499784418 := by decide
theorem cert_e2422406762210 : check e2422406762210 [[],[]] .chain = true := by decide
def e2422406762222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2422406762222 : Closed e2422406762222 ∧ code e2422406762222 = 11218499784430 := by decide
theorem cert_e2422406762222 : check e2422406762222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406762262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406762262 : Closed e2422406762262 ∧ code e2422406762262 = 11218499784470 := by decide
theorem cert_e2422406762262 : check e2422406762262 [[],[]] .chain = true := by decide
def e2422406762266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422406762266 : Closed e2422406762266 ∧ code e2422406762266 = 11218499784474 := by decide
theorem cert_e2422406762266 : check e2422406762266 [[],[]] .chain = true := by decide
def e2422406762310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422406762310 : Closed e2422406762310 ∧ code e2422406762310 = 11218499784518 := by decide
theorem cert_e2422406762310 : check e2422406762310 [[],[]] .chain = true := by decide
def e2422406762338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406762338 : Closed e2422406762338 ∧ code e2422406762338 = 11218499784546 := by decide
theorem cert_e2422406762338 : check e2422406762338 [[],[]] .chain = true := by decide
def e2422406762350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2422406762350 : Closed e2422406762350 ∧ code e2422406762350 = 11218499784558 := by decide
theorem cert_e2422406762350 : check e2422406762350 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406762358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2422406762358 : Closed e2422406762358 ∧ code e2422406762358 = 11218499784566 := by decide
theorem cert_e2422406762358 : check e2422406762358 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406762718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422406762718 : Closed e2422406762718 ∧ code e2422406762718 = 11218499784926 := by decide
theorem cert_e2422406762718 : check e2422406762718 [[],[]] .chain = true := by decide
def e2422406762746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422406762746 : Closed e2422406762746 ∧ code e2422406762746 = 11218499784954 := by decide
theorem cert_e2422406762746 : check e2422406762746 [[],[]] .chain = true := by decide
def e2422406763294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422406763294 : Closed e2422406763294 ∧ code e2422406763294 = 11218499785502 := by decide
theorem cert_e2422406763294 : check e2422406763294 [[],[]] .chain = true := by decide
def e2422406763462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422406763462 : Closed e2422406763462 ∧ code e2422406763462 = 11218499785670 := by decide
theorem cert_e2422406763462 : check e2422406763462 [[],[]] .chain = true := by decide
def e2422406764606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406764606 : Closed e2422406764606 ∧ code e2422406764606 = 11218499786814 := by decide
theorem cert_e2422406764606 : check e2422406764606 [[],[]] .chain = true := by decide
def e2422406765026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406765026 : Closed e2422406765026 ∧ code e2422406765026 = 11218499787234 := by decide
theorem cert_e2422406765026 : check e2422406765026 [[],[]] .chain = true := by decide
def e2422406765038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406765038 : Closed e2422406765038 ∧ code e2422406765038 = 11218499787246 := by decide
theorem cert_e2422406765038 : check e2422406765038 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406765598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406765598 : Closed e2422406765598 ∧ code e2422406765598 = 11218499787806 := by decide
theorem cert_e2422406765598 : check e2422406765598 [[],[]] .chain = true := by decide
def e2422406765622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422406765622 : Closed e2422406765622 ∧ code e2422406765622 = 11218499787830 := by decide
theorem cert_e2422406765622 : check e2422406765622 [[],[]] .chain = true := by decide
def e2422406765626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422406765626 : Closed e2422406765626 ∧ code e2422406765626 = 11218499787834 := by decide
theorem cert_e2422406765626 : check e2422406765626 [[],[]] .chain = true := by decide
def e2422406765766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422406765766 : Closed e2422406765766 ∧ code e2422406765766 = 11218499787974 := by decide
theorem cert_e2422406765766 : check e2422406765766 [[],[]] .chain = true := by decide
def e2422406765794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406765794 : Closed e2422406765794 ∧ code e2422406765794 = 11218499788002 := by decide
theorem cert_e2422406765794 : check e2422406765794 [[],[]] .chain = true := by decide
def e2422406765806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406765806 : Closed e2422406765806 ∧ code e2422406765806 = 11218499788014 := by decide
theorem cert_e2422406765806 : check e2422406765806 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406765814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406765814 : Closed e2422406765814 ∧ code e2422406765814 = 11218499788022 := by decide
theorem cert_e2422406765814 : check e2422406765814 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406766838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422406766838 : Closed e2422406766838 ∧ code e2422406766838 = 11218499789046 := by decide
theorem cert_e2422406766838 : check e2422406766838 [[],[]] .chain = true := by decide
def e2422406767030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422406767030 : Closed e2422406767030 ∧ code e2422406767030 = 11218499789238 := by decide
theorem cert_e2422406767030 : check e2422406767030 [[],[]] .chain = true := by decide
def e2422406767034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422406767034 : Closed e2422406767034 ∧ code e2422406767034 = 11218499789242 := by decide
theorem cert_e2422406767034 : check e2422406767034 [[],[]] .chain = true := by decide
def e2422406767062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422406767062 : Closed e2422406767062 ∧ code e2422406767062 = 11218499789270 := by decide
theorem cert_e2422406767062 : check e2422406767062 [[],[]] .chain = true := by decide
def e2422406767082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422406767082 : Closed e2422406767082 ∧ code e2422406767082 = 11218499789290 := by decide
theorem cert_e2422406767082 : check e2422406767082 [[],[]] .chain = true := by decide
def e2422406767222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406767222 : Closed e2422406767222 ∧ code e2422406767222 = 11218499789430 := by decide
theorem cert_e2422406767222 : check e2422406767222 [[],[]] .chain = true := by decide
def e2422406767414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406767414 : Closed e2422406767414 ∧ code e2422406767414 = 11218499789622 := by decide
theorem cert_e2422406767414 : check e2422406767414 [[],[]] .chain = true := by decide
def e2422406767418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406767418 : Closed e2422406767418 ∧ code e2422406767418 = 11218499789626 := by decide
theorem cert_e2422406767418 : check e2422406767418 [[],[]] .chain = true := by decide
def e2422406767502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422406767502 : Closed e2422406767502 ∧ code e2422406767502 = 11218499789710 := by decide
theorem cert_e2422406767502 : check e2422406767502 [[],[]] .chain = true := by decide
def e2422406767514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406767514 : Closed e2422406767514 ∧ code e2422406767514 = 11218499789722 := by decide
theorem cert_e2422406767514 : check e2422406767514 [[],[]] .chain = true := by decide
def e2422406768182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406768182 : Closed e2422406768182 ∧ code e2422406768182 = 11218499790390 := by decide
theorem cert_e2422406768182 : check e2422406768182 [[],[]] .chain = true := by decide
def e2422406768186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406768186 : Closed e2422406768186 ∧ code e2422406768186 = 11218499790394 := by decide
theorem cert_e2422406768186 : check e2422406768186 [[],[]] .chain = true := by decide
end Blc.Floor43
