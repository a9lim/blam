import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418133742446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2418133742446 : Closed e2418133742446 ∧ code e2418133742446 = 11214226764654 := by decide
theorem cert_e2418133742446 : check e2418133742446 [[],[]] .smaller = true := by decide
def e2418133742454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2418133742454 : Closed e2418133742454 ∧ code e2418133742454 = 11214226764662 := by decide
theorem cert_e2418133742454 : check e2418133742454 [[],[]] .smaller = true := by decide
def e2418133742510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2418133742510 : Closed e2418133742510 ∧ code e2418133742510 = 11214226764718 := by decide
theorem cert_e2418133742510 : check e2418133742510 [[],[]] .smaller = true := by decide
def e2418133742522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2418133742522 : Closed e2418133742522 ∧ code e2418133742522 = 11214226764730 := by decide
theorem cert_e2418133742522 : check e2418133742522 [[],[]] .smaller = true := by decide
def e2418133742550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2418133742550 : Closed e2418133742550 ∧ code e2418133742550 = 11214226764758 := by decide
theorem cert_e2418133742550 : check e2418133742550 [[],[]] .smaller = true := by decide
def e2418133742554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2418133742554 : Closed e2418133742554 ∧ code e2418133742554 = 11214226764762 := by decide
theorem cert_e2418133742554 : check e2418133742554 [[],[]] .smaller = true := by decide
def e2418133742830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418133742830 : Closed e2418133742830 ∧ code e2418133742830 = 11214226765038 := by decide
theorem cert_e2418133742830 : check e2418133742830 [[],[]] .smaller = true := by decide
def e2418133742838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418133742838 : Closed e2418133742838 ∧ code e2418133742838 = 11214226765046 := by decide
theorem cert_e2418133742838 : check e2418133742838 [[],[]] .smaller = true := by decide
def e2418133743214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418133743214 : Closed e2418133743214 ∧ code e2418133743214 = 11214226765422 := by decide
theorem cert_e2418133743214 : check e2418133743214 [[],[]] .smaller = true := by decide
def e2418133743226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418133743226 : Closed e2418133743226 ∧ code e2418133743226 = 11214226765434 := by decide
theorem cert_e2418133743226 : check e2418133743226 [[],[]] .smaller = true := by decide
def e2418133743414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418133743414 : Closed e2418133743414 ∧ code e2418133743414 = 11214226765622 := by decide
theorem cert_e2418133743414 : check e2418133743414 [[],[]] .smaller = true := by decide
def e2418133743418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418133743418 : Closed e2418133743418 ∧ code e2418133743418 = 11214226765626 := by decide
theorem cert_e2418133743418 : check e2418133743418 [[],[]] .smaller = true := by decide
def e2418133744046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2418133744046 : Closed e2418133744046 ∧ code e2418133744046 = 11214226766254 := by decide
theorem cert_e2418133744046 : check e2418133744046 [[],[]] .smaller = true := by decide
def e2418133744058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2418133744058 : Closed e2418133744058 ∧ code e2418133744058 = 11214226766266 := by decide
theorem cert_e2418133744058 : check e2418133744058 [[],[]] .smaller = true := by decide
def e2418133744106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2418133744106 : Closed e2418133744106 ∧ code e2418133744106 = 11214226766314 := by decide
theorem cert_e2418133744106 : check e2418133744106 [[],[]] .smaller = true := by decide
def e2418133744238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418133744238 : Closed e2418133744238 ∧ code e2418133744238 = 11214226766446 := by decide
theorem cert_e2418133744238 : check e2418133744238 [[],[]] .smaller = true := by decide
def e2418133744250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418133744250 : Closed e2418133744250 ∧ code e2418133744250 = 11214226766458 := by decide
theorem cert_e2418133744250 : check e2418133744250 [[],[]] .smaller = true := by decide
def e2418133744538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418133744538 : Closed e2418133744538 ∧ code e2418133744538 = 11214226766746 := by decide
theorem cert_e2418133744538 : check e2418133744538 [[],[]] .smaller = true := by decide
def e2418133744854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2418133744854 : Closed e2418133744854 ∧ code e2418133744854 = 11214226767062 := by decide
theorem cert_e2418133744854 : check e2418133744854 [[],[]] .smaller = true := by decide
def e2418133744858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2418133744858 : Closed e2418133744858 ∧ code e2418133744858 = 11214226767066 := by decide
theorem cert_e2418133744858 : check e2418133744858 [[],[]] .smaller = true := by decide
def e2418133744874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2418133744874 : Closed e2418133744874 ∧ code e2418133744874 = 11214226767082 := by decide
theorem cert_e2418133744874 : check e2418133744874 [[],[]] .smaller = true := by decide
def e2418133744950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418133744950 : Closed e2418133744950 ∧ code e2418133744950 = 11214226767158 := by decide
theorem cert_e2418133744950 : check e2418133744950 [[],[]] .smaller = true := by decide
def e2418133744954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418133744954 : Closed e2418133744954 ∧ code e2418133744954 = 11214226767162 := by decide
theorem cert_e2418133744954 : check e2418133744954 [[],[]] .smaller = true := by decide
def e2418133745050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418133745050 : Closed e2418133745050 ∧ code e2418133745050 = 11214226767258 := by decide
theorem cert_e2418133745050 : check e2418133745050 [[],[]] .smaller = true := by decide
def e2418133748590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418133748590 : Closed e2418133748590 ∧ code e2418133748590 = 11214226770798 := by decide
theorem cert_e2418133748590 : check e2418133748590 [[],[]] .smaller = true := by decide
def e2418133748598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418133748598 : Closed e2418133748598 ∧ code e2418133748598 = 11214226770806 := by decide
theorem cert_e2418133748598 : check e2418133748598 [[],[]] .smaller = true := by decide
def e2418133748654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418133748654 : Closed e2418133748654 ∧ code e2418133748654 = 11214226770862 := by decide
theorem cert_e2418133748654 : check e2418133748654 [[],[]] .smaller = true := by decide
def e2418133748666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418133748666 : Closed e2418133748666 ∧ code e2418133748666 = 11214226770874 := by decide
theorem cert_e2418133748666 : check e2418133748666 [[],[]] .smaller = true := by decide
def e2418133748694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418133748694 : Closed e2418133748694 ∧ code e2418133748694 = 11214226770902 := by decide
theorem cert_e2418133748694 : check e2418133748694 [[],[]] .smaller = true := by decide
def e2418133748698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418133748698 : Closed e2418133748698 ∧ code e2418133748698 = 11214226770906 := by decide
theorem cert_e2418133748698 : check e2418133748698 [[],[]] .smaller = true := by decide
def e2418133748974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418133748974 : Closed e2418133748974 ∧ code e2418133748974 = 11214226771182 := by decide
theorem cert_e2418133748974 : check e2418133748974 [[],[]] .smaller = true := by decide
def e2418133748982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418133748982 : Closed e2418133748982 ∧ code e2418133748982 = 11214226771190 := by decide
theorem cert_e2418133748982 : check e2418133748982 [[],[]] .smaller = true := by decide
def e2418133749358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418133749358 : Closed e2418133749358 ∧ code e2418133749358 = 11214226771566 := by decide
theorem cert_e2418133749358 : check e2418133749358 [[],[]] .smaller = true := by decide
def e2418133749370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418133749370 : Closed e2418133749370 ∧ code e2418133749370 = 11214226771578 := by decide
theorem cert_e2418133749370 : check e2418133749370 [[],[]] .smaller = true := by decide
def e2418133749558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418133749558 : Closed e2418133749558 ∧ code e2418133749558 = 11214226771766 := by decide
theorem cert_e2418133749558 : check e2418133749558 [[],[]] .smaller = true := by decide
def e2418133749562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418133749562 : Closed e2418133749562 ∧ code e2418133749562 = 11214226771770 := by decide
theorem cert_e2418133749562 : check e2418133749562 [[],[]] .smaller = true := by decide
def e2418133755310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2418133755310 : Closed e2418133755310 ∧ code e2418133755310 = 11214226777518 := by decide
theorem cert_e2418133755310 : check e2418133755310 [[],[]] .smaller = true := by decide
def e2418133755322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2418133755322 : Closed e2418133755322 ∧ code e2418133755322 = 11214226777530 := by decide
theorem cert_e2418133755322 : check e2418133755322 [[],[]] .smaller = true := by decide
def e2418133755370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2418133755370 : Closed e2418133755370 ∧ code e2418133755370 = 11214226777578 := by decide
theorem cert_e2418133755370 : check e2418133755370 [[],[]] .smaller = true := by decide
def e2418133755502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418133755502 : Closed e2418133755502 ∧ code e2418133755502 = 11214226777710 := by decide
theorem cert_e2418133755502 : check e2418133755502 [[],[]] .smaller = true := by decide
def e2418133755514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418133755514 : Closed e2418133755514 ∧ code e2418133755514 = 11214226777722 := by decide
theorem cert_e2418133755514 : check e2418133755514 [[],[]] .smaller = true := by decide
def e2418133755802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418133755802 : Closed e2418133755802 ∧ code e2418133755802 = 11214226778010 := by decide
theorem cert_e2418133755802 : check e2418133755802 [[],[]] .smaller = true := by decide
def e2418133758678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2418133758678 : Closed e2418133758678 ∧ code e2418133758678 = 11214226780886 := by decide
theorem cert_e2418133758678 : check e2418133758678 [[],[]] .smaller = true := by decide
def e2418133758682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2418133758682 : Closed e2418133758682 ∧ code e2418133758682 = 11214226780890 := by decide
theorem cert_e2418133758682 : check e2418133758682 [[],[]] .smaller = true := by decide
def e2418133758698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2418133758698 : Closed e2418133758698 ∧ code e2418133758698 = 11214226780906 := by decide
theorem cert_e2418133758698 : check e2418133758698 [[],[]] .smaller = true := by decide
def e2418133758774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418133758774 : Closed e2418133758774 ∧ code e2418133758774 = 11214226780982 := by decide
theorem cert_e2418133758774 : check e2418133758774 [[],[]] .smaller = true := by decide
def e2418133758778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418133758778 : Closed e2418133758778 ∧ code e2418133758778 = 11214226780986 := by decide
theorem cert_e2418133758778 : check e2418133758778 [[],[]] .smaller = true := by decide
def e2418133758874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418133758874 : Closed e2418133758874 ∧ code e2418133758874 = 11214226781082 := by decide
theorem cert_e2418133758874 : check e2418133758874 [[],[]] .smaller = true := by decide
def e2418133874414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2418133874414 : Closed e2418133874414 ∧ code e2418133874414 = 11214226896622 := by decide
theorem cert_e2418133874414 : check e2418133874414 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418133874542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2418133874542 : Closed e2418133874542 ∧ code e2418133874542 = 11214226896750 := by decide
theorem cert_e2418133874542 : check e2418133874542 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418133874550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2418133874550 : Closed e2418133874550 ∧ code e2418133874550 = 11214226896758 := by decide
theorem cert_e2418133874550 : check e2418133874550 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418133875438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2418133875438 : Closed e2418133875438 ∧ code e2418133875438 = 11214226897646 := by decide
theorem cert_e2418133875438 : check e2418133875438 [[],[]] .sourceHead = true := by decide
def e2418133875630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2418133875630 : Closed e2418133875630 ∧ code e2418133875630 = 11214226897838 := by decide
theorem cert_e2418133875630 : check e2418133875630 [[],[]] .sourceHead = true := by decide
def e2418133875642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2418133875642 : Closed e2418133875642 ∧ code e2418133875642 = 11214226897850 := by decide
theorem cert_e2418133875642 : check e2418133875642 [[],[]] .sourceHead = true := by decide
def e2418133876078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418133876078 : Closed e2418133876078 ∧ code e2418133876078 = 11214226898286 := by decide
theorem cert_e2418133876078 : check e2418133876078 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418133876086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418133876086 : Closed e2418133876086 ∧ code e2418133876086 = 11214226898294 := by decide
theorem cert_e2418133876086 : check e2418133876086 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418133876142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418133876142 : Closed e2418133876142 ∧ code e2418133876142 = 11214226898350 := by decide
theorem cert_e2418133876142 : check e2418133876142 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418133876154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418133876154 : Closed e2418133876154 ∧ code e2418133876154 = 11214226898362 := by decide
theorem cert_e2418133876154 : check e2418133876154 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418133876182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418133876182 : Closed e2418133876182 ∧ code e2418133876182 = 11214226898390 := by decide
theorem cert_e2418133876182 : check e2418133876182 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418133876186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418133876186 : Closed e2418133876186 ∧ code e2418133876186 = 11214226898394 := by decide
theorem cert_e2418133876186 : check e2418133876186 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418133880558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2418133880558 : Closed e2418133880558 ∧ code e2418133880558 = 11214226902766 := by decide
theorem cert_e2418133880558 : check e2418133880558 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418133880686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2418133880686 : Closed e2418133880686 ∧ code e2418133880686 = 11214226902894 := by decide
theorem cert_e2418133880686 : check e2418133880686 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418133880694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2418133880694 : Closed e2418133880694 ∧ code e2418133880694 = 11214226902902 := by decide
theorem cert_e2418133880694 : checkPay e2418133880694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418133883374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2418133883374 : Closed e2418133883374 ∧ code e2418133883374 = 11214226905582 := by decide
theorem cert_e2418133883374 : check e2418133883374 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418133884142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418133884142 : Closed e2418133884142 ∧ code e2418133884142 = 11214226906350 := by decide
theorem cert_e2418133884142 : check e2418133884142 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418133884150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418133884150 : Closed e2418133884150 ∧ code e2418133884150 = 11214226906358 := by decide
theorem cert_e2418133884150 : check e2418133884150 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418133886702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2418133886702 : Closed e2418133886702 ∧ code e2418133886702 = 11214226908910 := by decide
theorem cert_e2418133886702 : checkPay e2418133886702 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e2418133886894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2418133886894 : Closed e2418133886894 ∧ code e2418133886894 = 11214226909102 := by decide
theorem cert_e2418133886894 : checkPay e2418133886894 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e2418133886906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2418133886906 : Closed e2418133886906 ∧ code e2418133886906 = 11214226909114 := by decide
theorem cert_e2418133886906 : checkPay e2418133886906 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] = true := by decide
def e2418133887470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2418133887470 : Closed e2418133887470 ∧ code e2418133887470 = 11214226909678 := by decide
theorem cert_e2418133887470 : checkPay e2418133887470 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418133888622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418133888622 : Closed e2418133888622 ∧ code e2418133888622 = 11214226910830 := by decide
theorem cert_e2418133888622 : checkPay e2418133888622 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2418133888634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418133888634 : Closed e2418133888634 ∧ code e2418133888634 = 11214226910842 := by decide
theorem cert_e2418133888634 : checkPay e2418133888634 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right]] = true := by decide
def e2418133889902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418133889902 : Closed e2418133889902 ∧ code e2418133889902 = 11214226912110 := by decide
theorem cert_e2418133889902 : check e2418133889902 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133889910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418133889910 : Closed e2418133889910 ∧ code e2418133889910 = 11214226912118 := by decide
theorem cert_e2418133889910 : check e2418133889910 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133889966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418133889966 : Closed e2418133889966 ∧ code e2418133889966 = 11214226912174 := by decide
theorem cert_e2418133889966 : check e2418133889966 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133889978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418133889978 : Closed e2418133889978 ∧ code e2418133889978 = 11214226912186 := by decide
theorem cert_e2418133889978 : check e2418133889978 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418133890006 : Closed e2418133890006 ∧ code e2418133890006 = 11214226912214 := by decide
theorem cert_e2418133890006 : check e2418133890006 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418133890010 : Closed e2418133890010 ∧ code e2418133890010 = 11214226912218 := by decide
theorem cert_e2418133890010 : check e2418133890010 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418133890286 : Closed e2418133890286 ∧ code e2418133890286 = 11214226912494 := by decide
theorem cert_e2418133890286 : check e2418133890286 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418133890294 : Closed e2418133890294 ∧ code e2418133890294 = 11214226912502 := by decide
theorem cert_e2418133890294 : check e2418133890294 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418133890670 : Closed e2418133890670 ∧ code e2418133890670 = 11214226912878 := by decide
theorem cert_e2418133890670 : check e2418133890670 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418133890682 : Closed e2418133890682 ∧ code e2418133890682 = 11214226912890 := by decide
theorem cert_e2418133890682 : check e2418133890682 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418133890870 : Closed e2418133890870 ∧ code e2418133890870 = 11214226913078 := by decide
theorem cert_e2418133890870 : check e2418133890870 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133890874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418133890874 : Closed e2418133890874 ∧ code e2418133890874 = 11214226913082 := by decide
theorem cert_e2418133890874 : check e2418133890874 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418133896046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418133896046 : Closed e2418133896046 ∧ code e2418133896046 = 11214226918254 := by decide
theorem cert_e2418133896046 : check e2418133896046 [[],[]] .smaller = true := by decide
def e2418133896054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418133896054 : Closed e2418133896054 ∧ code e2418133896054 = 11214226918262 := by decide
theorem cert_e2418133896054 : check e2418133896054 [[],[]] .smaller = true := by decide
def e2418133896110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418133896110 : Closed e2418133896110 ∧ code e2418133896110 = 11214226918318 := by decide
theorem cert_e2418133896110 : check e2418133896110 [[],[]] .smaller = true := by decide
def e2418133896122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418133896122 : Closed e2418133896122 ∧ code e2418133896122 = 11214226918330 := by decide
theorem cert_e2418133896122 : check e2418133896122 [[],[]] .smaller = true := by decide
def e2418133896150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418133896150 : Closed e2418133896150 ∧ code e2418133896150 = 11214226918358 := by decide
theorem cert_e2418133896150 : check e2418133896150 [[],[]] .smaller = true := by decide
def e2418133896154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418133896154 : Closed e2418133896154 ∧ code e2418133896154 = 11214226918362 := by decide
theorem cert_e2418133896154 : check e2418133896154 [[],[]] .smaller = true := by decide
def e2418133896430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418133896430 : Closed e2418133896430 ∧ code e2418133896430 = 11214226918638 := by decide
theorem cert_e2418133896430 : check e2418133896430 [[],[]] .smaller = true := by decide
def e2418133896438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418133896438 : Closed e2418133896438 ∧ code e2418133896438 = 11214226918646 := by decide
theorem cert_e2418133896438 : check e2418133896438 [[],[]] .smaller = true := by decide
def e2418133896814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418133896814 : Closed e2418133896814 ∧ code e2418133896814 = 11214226919022 := by decide
theorem cert_e2418133896814 : check e2418133896814 [[],[]] .smaller = true := by decide
def e2418133896826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418133896826 : Closed e2418133896826 ∧ code e2418133896826 = 11214226919034 := by decide
theorem cert_e2418133896826 : check e2418133896826 [[],[]] .smaller = true := by decide
def e2418133897014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418133897014 : Closed e2418133897014 ∧ code e2418133897014 = 11214226919222 := by decide
theorem cert_e2418133897014 : check e2418133897014 [[],[]] .smaller = true := by decide
def e2418133897018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418133897018 : Closed e2418133897018 ∧ code e2418133897018 = 11214226919226 := by decide
theorem cert_e2418133897018 : check e2418133897018 [[],[]] .smaller = true := by decide
def e2418133905134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2418133905134 : Closed e2418133905134 ∧ code e2418133905134 = 11214226927342 := by decide
theorem cert_e2418133905134 : check e2418133905134 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418133905262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2418133905262 : Closed e2418133905262 ∧ code e2418133905262 = 11214226927470 := by decide
theorem cert_e2418133905262 : check e2418133905262 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418133905270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2418133905270 : Closed e2418133905270 ∧ code e2418133905270 = 11214226927478 := by decide
theorem cert_e2418133905270 : check e2418133905270 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418133907950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2418133907950 : Closed e2418133907950 ∧ code e2418133907950 = 11214226930158 := by decide
theorem cert_e2418133907950 : check e2418133907950 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418133908718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2418133908718 : Closed e2418133908718 ∧ code e2418133908718 = 11214226930926 := by decide
theorem cert_e2418133908718 : check e2418133908718 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2418133908726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2418133908726 : Closed e2418133908726 ∧ code e2418133908726 = 11214226930934 := by decide
theorem cert_e2418133908726 : check e2418133908726 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2418133931758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2418133931758 : Closed e2418133931758 ∧ code e2418133931758 = 11214226953966 := by decide
theorem cert_e2418133931758 : check e2418133931758 [[],[]] .sourceHead = true := by decide
def e2418133931950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2418133931950 : Closed e2418133931950 ∧ code e2418133931950 = 11214226954158 := by decide
theorem cert_e2418133931950 : check e2418133931950 [[],[]] .sourceHead = true := by decide
def e2418133931962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2418133931962 : Closed e2418133931962 ∧ code e2418133931962 = 11214226954170 := by decide
theorem cert_e2418133931962 : check e2418133931962 [[],[]] .sourceHead = true := by decide
def e2418133932526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2418133932526 : Closed e2418133932526 ∧ code e2418133932526 = 11214226954734 := by decide
theorem cert_e2418133932526 : check e2418133932526 [[],[]] .sourceHead = true := by decide
def e2418133933678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2418133933678 : Closed e2418133933678 ∧ code e2418133933678 = 11214226955886 := by decide
theorem cert_e2418133933678 : check e2418133933678 [[],[]] .sourceHead = true := by decide
def e2418133933690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2418133933690 : Closed e2418133933690 ∧ code e2418133933690 = 11214226955898 := by decide
theorem cert_e2418133933690 : check e2418133933690 [[],[]] .sourceHead = true := by decide
def e2418133945198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418133945198 : Closed e2418133945198 ∧ code e2418133945198 = 11214226967406 := by decide
theorem cert_e2418133945198 : check e2418133945198 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418133945206 : Closed e2418133945206 ∧ code e2418133945206 = 11214226967414 := by decide
theorem cert_e2418133945206 : check e2418133945206 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418133945262 : Closed e2418133945262 ∧ code e2418133945262 = 11214226967470 := by decide
theorem cert_e2418133945262 : check e2418133945262 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418133945274 : Closed e2418133945274 ∧ code e2418133945274 = 11214226967482 := by decide
theorem cert_e2418133945274 : check e2418133945274 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418133945302 : Closed e2418133945302 ∧ code e2418133945302 = 11214226967510 := by decide
theorem cert_e2418133945302 : check e2418133945302 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418133945306 : Closed e2418133945306 ∧ code e2418133945306 = 11214226967514 := by decide
theorem cert_e2418133945306 : check e2418133945306 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418133945582 : Closed e2418133945582 ∧ code e2418133945582 = 11214226967790 := by decide
theorem cert_e2418133945582 : check e2418133945582 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418133945590 : Closed e2418133945590 ∧ code e2418133945590 = 11214226967798 := by decide
theorem cert_e2418133945590 : check e2418133945590 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418133945966 : Closed e2418133945966 ∧ code e2418133945966 = 11214226968174 := by decide
theorem cert_e2418133945966 : check e2418133945966 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133945978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418133945978 : Closed e2418133945978 ∧ code e2418133945978 = 11214226968186 := by decide
theorem cert_e2418133945978 : check e2418133945978 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133946166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418133946166 : Closed e2418133946166 ∧ code e2418133946166 = 11214226968374 := by decide
theorem cert_e2418133946166 : check e2418133946166 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418133946170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418133946170 : Closed e2418133946170 ∧ code e2418133946170 = 11214226968378 := by decide
theorem cert_e2418133946170 : check e2418133946170 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418134485870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418134485870 : Closed e2418134485870 ∧ code e2418134485870 = 11214227508078 := by decide
theorem cert_e2418134485870 : check e2418134485870 [[],[]] .smaller = true := by decide
def e2418134485878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418134485878 : Closed e2418134485878 ∧ code e2418134485878 = 11214227508086 := by decide
theorem cert_e2418134485878 : check e2418134485878 [[],[]] .smaller = true := by decide
def e2418134485934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418134485934 : Closed e2418134485934 ∧ code e2418134485934 = 11214227508142 := by decide
theorem cert_e2418134485934 : check e2418134485934 [[],[]] .smaller = true := by decide
def e2418134485946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418134485946 : Closed e2418134485946 ∧ code e2418134485946 = 11214227508154 := by decide
theorem cert_e2418134485946 : check e2418134485946 [[],[]] .smaller = true := by decide
def e2418134485974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418134485974 : Closed e2418134485974 ∧ code e2418134485974 = 11214227508182 := by decide
theorem cert_e2418134485974 : check e2418134485974 [[],[]] .smaller = true := by decide
def e2418134485978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418134485978 : Closed e2418134485978 ∧ code e2418134485978 = 11214227508186 := by decide
theorem cert_e2418134485978 : check e2418134485978 [[],[]] .smaller = true := by decide
def e2418134486254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418134486254 : Closed e2418134486254 ∧ code e2418134486254 = 11214227508462 := by decide
theorem cert_e2418134486254 : check e2418134486254 [[],[]] .smaller = true := by decide
def e2418134486262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418134486262 : Closed e2418134486262 ∧ code e2418134486262 = 11214227508470 := by decide
theorem cert_e2418134486262 : check e2418134486262 [[],[]] .smaller = true := by decide
def e2418134486638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418134486638 : Closed e2418134486638 ∧ code e2418134486638 = 11214227508846 := by decide
theorem cert_e2418134486638 : check e2418134486638 [[],[]] .smaller = true := by decide
def e2418134486650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418134486650 : Closed e2418134486650 ∧ code e2418134486650 = 11214227508858 := by decide
theorem cert_e2418134486650 : check e2418134486650 [[],[]] .smaller = true := by decide
def e2418134486838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418134486838 : Closed e2418134486838 ∧ code e2418134486838 = 11214227509046 := by decide
theorem cert_e2418134486838 : check e2418134486838 [[],[]] .smaller = true := by decide
def e2418134486842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418134486842 : Closed e2418134486842 ∧ code e2418134486842 = 11214227509050 := by decide
theorem cert_e2418134486842 : check e2418134486842 [[],[]] .smaller = true := by decide
def e2418167339886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2418167339886 : Closed e2418167339886 ∧ code e2418167339886 = 11214260362094 := by decide
theorem cert_e2418167339886 : check e2418167339886 [[],[]] .chain = true := by decide
def e2418167339894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2418167339894 : Closed e2418167339894 ∧ code e2418167339894 = 11214260362102 := by decide
theorem cert_e2418167339894 : check e2418167339894 [[],[]] .chain = true := by decide
def e2418167339958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2418167339958 : Closed e2418167339958 ∧ code e2418167339958 = 11214260362166 := by decide
theorem cert_e2418167339958 : check e2418167339958 [[],[]] .chain = true := by decide
def e2418167340398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418167340398 : Closed e2418167340398 ∧ code e2418167340398 = 11214260362606 := by decide
theorem cert_e2418167340398 : check e2418167340398 [[],[]] .chain = true := by decide
def e2418167340406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418167340406 : Closed e2418167340406 ∧ code e2418167340406 = 11214260362614 := by decide
theorem cert_e2418167340406 : check e2418167340406 [[],[]] .chain = true := by decide
def e2418167340462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418167340462 : Closed e2418167340462 ∧ code e2418167340462 = 11214260362670 := by decide
theorem cert_e2418167340462 : check e2418167340462 [[],[]] .chain = true := by decide
def e2418167340474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418167340474 : Closed e2418167340474 ∧ code e2418167340474 = 11214260362682 := by decide
theorem cert_e2418167340474 : check e2418167340474 [[],[]] .chain = true := by decide
def e2418167340502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418167340502 : Closed e2418167340502 ∧ code e2418167340502 = 11214260362710 := by decide
theorem cert_e2418167340502 : check e2418167340502 [[],[]] .chain = true := by decide
def e2418167340506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418167340506 : Closed e2418167340506 ∧ code e2418167340506 = 11214260362714 := by decide
theorem cert_e2418167340506 : check e2418167340506 [[],[]] .chain = true := by decide
def e2418167340726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2418167340726 : Closed e2418167340726 ∧ code e2418167340726 = 11214260362934 := by decide
theorem cert_e2418167340726 : check e2418167340726 [[],[]] .chain = true := by decide
def e2418167340758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2418167340758 : Closed e2418167340758 ∧ code e2418167340758 = 11214260362966 := by decide
theorem cert_e2418167340758 : check e2418167340758 [[],[]] .chain = true := by decide
def e2418167340762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2418167340762 : Closed e2418167340762 ∧ code e2418167340762 = 11214260362970 := by decide
theorem cert_e2418167340762 : check e2418167340762 [[],[]] .chain = true := by decide
def e2418167342958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2418167342958 : Closed e2418167342958 ∧ code e2418167342958 = 11214260365166 := by decide
theorem cert_e2418167342958 : check e2418167342958 [[],[]] .chain = true := by decide
def e2418167342966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2418167342966 : Closed e2418167342966 ∧ code e2418167342966 = 11214260365174 := by decide
theorem cert_e2418167342966 : check e2418167342966 [[],[]] .chain = true := by decide
def e2418167343030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2418167343030 : Closed e2418167343030 ∧ code e2418167343030 = 11214260365238 := by decide
theorem cert_e2418167343030 : check e2418167343030 [[],[]] .chain = true := by decide
def e2418167344366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418167344366 : Closed e2418167344366 ∧ code e2418167344366 = 11214260366574 := by decide
theorem cert_e2418167344366 : check e2418167344366 [[],[]] .chain = true := by decide
def e2418167344374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418167344374 : Closed e2418167344374 ∧ code e2418167344374 = 11214260366582 := by decide
theorem cert_e2418167344374 : check e2418167344374 [[],[]] .chain = true := by decide
def e2418167344758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2418167344758 : Closed e2418167344758 ∧ code e2418167344758 = 11214260366966 := by decide
theorem cert_e2418167344758 : check e2418167344758 [[],[]] .chain = true := by decide
def e2418167346030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418167346030 : Closed e2418167346030 ∧ code e2418167346030 = 11214260368238 := by decide
theorem cert_e2418167346030 : check e2418167346030 [[],[]] .chain = true := by decide
def e2418167346038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418167346038 : Closed e2418167346038 ∧ code e2418167346038 = 11214260368246 := by decide
theorem cert_e2418167346038 : check e2418167346038 [[],[]] .chain = true := by decide
def e2418167346094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418167346094 : Closed e2418167346094 ∧ code e2418167346094 = 11214260368302 := by decide
theorem cert_e2418167346094 : check e2418167346094 [[],[]] .chain = true := by decide
def e2418167346106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418167346106 : Closed e2418167346106 ∧ code e2418167346106 = 11214260368314 := by decide
theorem cert_e2418167346106 : check e2418167346106 [[],[]] .chain = true := by decide
def e2418167346134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418167346134 : Closed e2418167346134 ∧ code e2418167346134 = 11214260368342 := by decide
theorem cert_e2418167346134 : check e2418167346134 [[],[]] .chain = true := by decide
def e2418167346138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418167346138 : Closed e2418167346138 ∧ code e2418167346138 = 11214260368346 := by decide
theorem cert_e2418167346138 : check e2418167346138 [[],[]] .chain = true := by decide
def e2418167346414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418167346414 : Closed e2418167346414 ∧ code e2418167346414 = 11214260368622 := by decide
theorem cert_e2418167346414 : check e2418167346414 [[],[]] .chain = true := by decide
def e2418167346422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418167346422 : Closed e2418167346422 ∧ code e2418167346422 = 11214260368630 := by decide
theorem cert_e2418167346422 : check e2418167346422 [[],[]] .chain = true := by decide
def e2418167346798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418167346798 : Closed e2418167346798 ∧ code e2418167346798 = 11214260369006 := by decide
theorem cert_e2418167346798 : check e2418167346798 [[],[]] .chain = true := by decide
def e2418167346810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418167346810 : Closed e2418167346810 ∧ code e2418167346810 = 11214260369018 := by decide
theorem cert_e2418167346810 : check e2418167346810 [[],[]] .chain = true := by decide
end Blc.Floor43
