import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422376588142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e2422376588142 : Closed e2422376588142 ∧ code e2422376588142 = 11218469610350 := by decide
theorem cert_e2422376588142 : check e2422376588142 [[],[]] .smaller = true := by decide
def e2422376588150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e2422376588150 : Closed e2422376588150 ∧ code e2422376588150 = 11218469610358 := by decide
theorem cert_e2422376588150 : check e2422376588150 [[],[]] .smaller = true := by decide
def e2422376588154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 0))))))))
theorem wire_e2422376588154 : Closed e2422376588154 ∧ code e2422376588154 = 11218469610362 := by decide
theorem cert_e2422376588154 : check e2422376588154 [[],[]] .three = true := by decide
def e2422376588206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e2422376588206 : Closed e2422376588206 ∧ code e2422376588206 = 11218469610414 := by decide
theorem cert_e2422376588206 : check e2422376588206 [[],[]] .smaller = true := by decide
def e2422376588218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e2422376588218 : Closed e2422376588218 ∧ code e2422376588218 = 11218469610426 := by decide
theorem cert_e2422376588218 : check e2422376588218 [[],[]] .smaller = true := by decide
def e2422376588246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e2422376588246 : Closed e2422376588246 ∧ code e2422376588246 = 11218469610454 := by decide
theorem cert_e2422376588246 : check e2422376588246 [[],[]] .smaller = true := by decide
def e2422376588250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e2422376588250 : Closed e2422376588250 ∧ code e2422376588250 = 11218469610458 := by decide
theorem cert_e2422376588250 : check e2422376588250 [[],[]] .smaller = true := by decide
def e2422376588266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 0))))))))
theorem wire_e2422376588266 : Closed e2422376588266 ∧ code e2422376588266 = 11218469610474 := by decide
theorem cert_e2422376588266 : check e2422376588266 [[],[]] .three = true := by decide
def e2422376588974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422376588974 : Closed e2422376588974 ∧ code e2422376588974 = 11218469611182 := by decide
theorem cert_e2422376588974 : check e2422376588974 [[],[]] .smaller = true := by decide
def e2422376588986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422376588986 : Closed e2422376588986 ∧ code e2422376588986 = 11218469611194 := by decide
theorem cert_e2422376588986 : check e2422376588986 [[],[]] .smaller = true := by decide
def e2422376589034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422376589034 : Closed e2422376589034 ∧ code e2422376589034 = 11218469611242 := by decide
theorem cert_e2422376589034 : check e2422376589034 [[],[]] .smaller = true := by decide
def e2422376589226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422376589226 : Closed e2422376589226 ∧ code e2422376589226 = 11218469611434 := by decide
theorem cert_e2422376589226 : check e2422376589226 [[],[]] .smaller = true := by decide
def e2422376589358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422376589358 : Closed e2422376589358 ∧ code e2422376589358 = 11218469611566 := by decide
theorem cert_e2422376589358 : check e2422376589358 [[],[]] .smaller = true := by decide
def e2422376589534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422376589534 : Closed e2422376589534 ∧ code e2422376589534 = 11218469611742 := by decide
theorem cert_e2422376589534 : check e2422376589534 [[],[]] .three = true := by decide
def e2422376589550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422376589550 : Closed e2422376589550 ∧ code e2422376589550 = 11218469611758 := by decide
theorem cert_e2422376589550 : check e2422376589550 [[],[]] .smaller = true := by decide
def e2422376589558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422376589558 : Closed e2422376589558 ∧ code e2422376589558 = 11218469611766 := by decide
theorem cert_e2422376589558 : check e2422376589558 [[],[]] .smaller = true := by decide
def e2422376589562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422376589562 : Closed e2422376589562 ∧ code e2422376589562 = 11218469611770 := by decide
theorem cert_e2422376589562 : check e2422376589562 [[],[]] .three = true := by decide
def e2422376589742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422376589742 : Closed e2422376589742 ∧ code e2422376589742 = 11218469611950 := by decide
theorem cert_e2422376589742 : check e2422376589742 [[],[]] .smaller = true := by decide
def e2422376589754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422376589754 : Closed e2422376589754 ∧ code e2422376589754 = 11218469611962 := by decide
theorem cert_e2422376589754 : check e2422376589754 [[],[]] .smaller = true := by decide
def e2422376589802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422376589802 : Closed e2422376589802 ∧ code e2422376589802 = 11218469612010 := by decide
theorem cert_e2422376589802 : check e2422376589802 [[],[]] .smaller = true := by decide
def e2422376589886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422376589886 : Closed e2422376589886 ∧ code e2422376589886 = 11218469612094 := by decide
theorem cert_e2422376589886 : check e2422376589886 [[],[]] .three = true := by decide
def e2422376589934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376589934 : Closed e2422376589934 ∧ code e2422376589934 = 11218469612142 := by decide
theorem cert_e2422376589934 : check e2422376589934 [[],[]] .smaller = true := by decide
def e2422376589946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376589946 : Closed e2422376589946 ∧ code e2422376589946 = 11218469612154 := by decide
theorem cert_e2422376589946 : check e2422376589946 [[],[]] .smaller = true := by decide
def e2422376590110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422376590110 : Closed e2422376590110 ∧ code e2422376590110 = 11218469612318 := by decide
theorem cert_e2422376590110 : check e2422376590110 [[],[]] .smaller = true := by decide
def e2422376590210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422376590210 : Closed e2422376590210 ∧ code e2422376590210 = 11218469612418 := by decide
theorem cert_e2422376590210 : check e2422376590210 [[],[]] .smaller = true := by decide
def e2422376590222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422376590222 : Closed e2422376590222 ∧ code e2422376590222 = 11218469612430 := by decide
theorem cert_e2422376590222 : check e2422376590222 [[],[]] .smaller = true := by decide
def e2422376590234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376590234 : Closed e2422376590234 ∧ code e2422376590234 = 11218469612442 := by decide
theorem cert_e2422376590234 : check e2422376590234 [[],[]] .smaller = true := by decide
def e2422376590278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422376590278 : Closed e2422376590278 ∧ code e2422376590278 = 11218469612486 := by decide
theorem cert_e2422376590278 : check e2422376590278 [[],[]] .three = true := by decide
def e2422376590302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 3))))))))
theorem wire_e2422376590302 : Closed e2422376590302 ∧ code e2422376590302 = 11218469612510 := by decide
theorem cert_e2422376590302 : check e2422376590302 [[],[]] .three = true := by decide
def e2422376590430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422376590430 : Closed e2422376590430 ∧ code e2422376590430 = 11218469612638 := by decide
theorem cert_e2422376590430 : check e2422376590430 [[],[]] .three = true := by decide
def e2422376590446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422376590446 : Closed e2422376590446 ∧ code e2422376590446 = 11218469612654 := by decide
theorem cert_e2422376590446 : check e2422376590446 [[],[]] .smaller = true := by decide
def e2422376590458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422376590458 : Closed e2422376590458 ∧ code e2422376590458 = 11218469612666 := by decide
theorem cert_e2422376590458 : check e2422376590458 [[],[]] .smaller = true := by decide
def e2422376590622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422376590622 : Closed e2422376590622 ∧ code e2422376590622 = 11218469612830 := by decide
theorem cert_e2422376590622 : check e2422376590622 [[],[]] .smaller = true := by decide
def e2422376590790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422376590790 : Closed e2422376590790 ∧ code e2422376590790 = 11218469612998 := by decide
theorem cert_e2422376590790 : check e2422376590790 [[],[]] .smaller = true := by decide
def e2422376590814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e2422376590814 : Closed e2422376590814 ∧ code e2422376590814 = 11218469613022 := by decide
theorem cert_e2422376590814 : check e2422376590814 [[],[]] .three = true := by decide
def e2422376590818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422376590818 : Closed e2422376590818 ∧ code e2422376590818 = 11218469613026 := by decide
theorem cert_e2422376590818 : check e2422376590818 [[],[]] .three = true := by decide
def e2422376590830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e2422376590830 : Closed e2422376590830 ∧ code e2422376590830 = 11218469613038 := by decide
theorem cert_e2422376590830 : check e2422376590830 [[],[]] .three = true := by decide
def e2422376590858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422376590858 : Closed e2422376590858 ∧ code e2422376590858 = 11218469613066 := by decide
theorem cert_e2422376590858 : check e2422376590858 [[],[]] .smaller = true := by decide
def e2422376590894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422376590894 : Closed e2422376590894 ∧ code e2422376590894 = 11218469613102 := by decide
theorem cert_e2422376590894 : check e2422376590894 [[],[]] .smaller = true := by decide
def e2422376590902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422376590902 : Closed e2422376590902 ∧ code e2422376590902 = 11218469613110 := by decide
theorem cert_e2422376590902 : check e2422376590902 [[],[]] .smaller = true := by decide
def e2422376590906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422376590906 : Closed e2422376590906 ∧ code e2422376590906 = 11218469613114 := by decide
theorem cert_e2422376590906 : check e2422376590906 [[],[]] .smaller = true := by decide
def e2422376590954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422376590954 : Closed e2422376590954 ∧ code e2422376590954 = 11218469613162 := by decide
theorem cert_e2422376590954 : check e2422376590954 [[],[]] .smaller = true := by decide
def e2422376590978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422376590978 : Closed e2422376590978 ∧ code e2422376590978 = 11218469613186 := by decide
theorem cert_e2422376590978 : check e2422376590978 [[],[]] .smaller = true := by decide
def e2422376590990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422376590990 : Closed e2422376590990 ∧ code e2422376590990 = 11218469613198 := by decide
theorem cert_e2422376590990 : check e2422376590990 [[],[]] .smaller = true := by decide
def e2422376591002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376591002 : Closed e2422376591002 ∧ code e2422376591002 = 11218469613210 := by decide
theorem cert_e2422376591002 : check e2422376591002 [[],[]] .smaller = true := by decide
def e2422376591046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422376591046 : Closed e2422376591046 ∧ code e2422376591046 = 11218469613254 := by decide
theorem cert_e2422376591046 : check e2422376591046 [[],[]] .smaller = true := by decide
def e2422376591070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e2422376591070 : Closed e2422376591070 ∧ code e2422376591070 = 11218469613278 := by decide
theorem cert_e2422376591070 : check e2422376591070 [[],[]] .three = true := by decide
def e2422376591074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422376591074 : Closed e2422376591074 ∧ code e2422376591074 = 11218469613282 := by decide
theorem cert_e2422376591074 : check e2422376591074 [[],[]] .smaller = true := by decide
def e2422376591086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2))))))))
theorem wire_e2422376591086 : Closed e2422376591086 ∧ code e2422376591086 = 11218469613294 := by decide
theorem cert_e2422376591086 : check e2422376591086 [[],[]] .smaller = true := by decide
def e2422376591094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e2422376591094 : Closed e2422376591094 ∧ code e2422376591094 = 11218469613302 := by decide
theorem cert_e2422376591094 : check e2422376591094 [[],[]] .three = true := by decide
def e2422376591126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422376591126 : Closed e2422376591126 ∧ code e2422376591126 = 11218469613334 := by decide
theorem cert_e2422376591126 : check e2422376591126 [[],[]] .three = true := by decide
def e2422376591130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422376591130 : Closed e2422376591130 ∧ code e2422376591130 = 11218469613338 := by decide
theorem cert_e2422376591130 : check e2422376591130 [[],[]] .three = true := by decide
def e2422376591174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422376591174 : Closed e2422376591174 ∧ code e2422376591174 = 11218469613382 := by decide
theorem cert_e2422376591174 : check e2422376591174 [[],[]] .three = true := by decide
def e2422376591198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 3))))))))
theorem wire_e2422376591198 : Closed e2422376591198 ∧ code e2422376591198 = 11218469613406 := by decide
theorem cert_e2422376591198 : check e2422376591198 [[],[]] .three = true := by decide
def e2422376591202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422376591202 : Closed e2422376591202 ∧ code e2422376591202 = 11218469613410 := by decide
theorem cert_e2422376591202 : check e2422376591202 [[],[]] .three = true := by decide
def e2422376591214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e2422376591214 : Closed e2422376591214 ∧ code e2422376591214 = 11218469613422 := by decide
theorem cert_e2422376591214 : check e2422376591214 [[],[]] .three = true := by decide
def e2422376591222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e2422376591222 : Closed e2422376591222 ∧ code e2422376591222 = 11218469613430 := by decide
theorem cert_e2422376591222 : check e2422376591222 [[],[]] .three = true := by decide
def e2422376591226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 0))))))))
theorem wire_e2422376591226 : Closed e2422376591226 ∧ code e2422376591226 = 11218469613434 := by decide
theorem cert_e2422376591226 : check e2422376591226 [[],[]] .three = true := by decide
def e2422376591710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e2422376591710 : Closed e2422376591710 ∧ code e2422376591710 = 11218469613918 := by decide
theorem cert_e2422376591710 : check e2422376591710 [[],[]] .three = true := by decide
def e2422376591738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e2422376591738 : Closed e2422376591738 ∧ code e2422376591738 = 11218469613946 := by decide
theorem cert_e2422376591738 : check e2422376591738 [[],[]] .three = true := by decide
def e2422376591790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e2422376591790 : Closed e2422376591790 ∧ code e2422376591790 = 11218469613998 := by decide
theorem cert_e2422376591790 : check e2422376591790 [[],[]] .smaller = true := by decide
def e2422376591802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e2422376591802 : Closed e2422376591802 ∧ code e2422376591802 = 11218469614010 := by decide
theorem cert_e2422376591802 : check e2422376591802 [[],[]] .smaller = true := by decide
def e2422376591850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e2422376591850 : Closed e2422376591850 ∧ code e2422376591850 = 11218469614058 := by decide
theorem cert_e2422376591850 : check e2422376591850 [[],[]] .smaller = true := by decide
def e2422376592478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422376592478 : Closed e2422376592478 ∧ code e2422376592478 = 11218469614686 := by decide
theorem cert_e2422376592478 : check e2422376592478 [[],[]] .three = true := by decide
def e2422376592494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422376592494 : Closed e2422376592494 ∧ code e2422376592494 = 11218469614702 := by decide
theorem cert_e2422376592494 : check e2422376592494 [[],[]] .smaller = true := by decide
def e2422376592506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422376592506 : Closed e2422376592506 ∧ code e2422376592506 = 11218469614714 := by decide
theorem cert_e2422376592506 : check e2422376592506 [[],[]] .smaller = true := by decide
def e2422376592670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422376592670 : Closed e2422376592670 ∧ code e2422376592670 = 11218469614878 := by decide
theorem cert_e2422376592670 : check e2422376592670 [[],[]] .smaller = true := by decide
def e2422376592838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422376592838 : Closed e2422376592838 ∧ code e2422376592838 = 11218469615046 := by decide
theorem cert_e2422376592838 : check e2422376592838 [[],[]] .smaller = true := by decide
def e2422376592862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e2422376592862 : Closed e2422376592862 ∧ code e2422376592862 = 11218469615070 := by decide
theorem cert_e2422376592862 : check e2422376592862 [[],[]] .three = true := by decide
def e2422376592866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422376592866 : Closed e2422376592866 ∧ code e2422376592866 = 11218469615074 := by decide
theorem cert_e2422376592866 : check e2422376592866 [[],[]] .three = true := by decide
def e2422376592878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e2422376592878 : Closed e2422376592878 ∧ code e2422376592878 = 11218469615086 := by decide
theorem cert_e2422376592878 : check e2422376592878 [[],[]] .three = true := by decide
def e2422376593178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422376593178 : Closed e2422376593178 ∧ code e2422376593178 = 11218469615386 := by decide
theorem cert_e2422376593178 : check e2422376593178 [[],[]] .smaller = true := by decide
def e2422376593222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422376593222 : Closed e2422376593222 ∧ code e2422376593222 = 11218469615430 := by decide
theorem cert_e2422376593222 : check e2422376593222 [[],[]] .smaller = true := by decide
def e2422376593246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e2422376593246 : Closed e2422376593246 ∧ code e2422376593246 = 11218469615454 := by decide
theorem cert_e2422376593246 : check e2422376593246 [[],[]] .three = true := by decide
def e2422376593274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e2422376593274 : Closed e2422376593274 ∧ code e2422376593274 = 11218469615482 := by decide
theorem cert_e2422376593274 : check e2422376593274 [[],[]] .three = true := by decide
def e2422376593290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422376593290 : Closed e2422376593290 ∧ code e2422376593290 = 11218469615498 := by decide
theorem cert_e2422376593290 : check e2422376593290 [[],[]] .three = true := by decide
def e2422376593314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422376593314 : Closed e2422376593314 ∧ code e2422376593314 = 11218469615522 := by decide
theorem cert_e2422376593314 : check e2422376593314 [[],[]] .three = true := by decide
def e2422376593326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e2422376593326 : Closed e2422376593326 ∧ code e2422376593326 = 11218469615534 := by decide
theorem cert_e2422376593326 : check e2422376593326 [[],[]] .three = true := by decide
def e2422376593338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e2422376593338 : Closed e2422376593338 ∧ code e2422376593338 = 11218469615546 := by decide
theorem cert_e2422376593338 : check e2422376593338 [[],[]] .three = true := by decide
def e2422376593450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 0))))))))
theorem wire_e2422376593450 : Closed e2422376593450 ∧ code e2422376593450 = 11218469615658 := by decide
theorem cert_e2422376593450 : check e2422376593450 [[],[]] .smaller = true := by decide
def e2422376593582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422376593582 : Closed e2422376593582 ∧ code e2422376593582 = 11218469615790 := by decide
theorem cert_e2422376593582 : check e2422376593582 [[],[]] .smaller = true := by decide
def e2422376593594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422376593594 : Closed e2422376593594 ∧ code e2422376593594 = 11218469615802 := by decide
theorem cert_e2422376593594 : check e2422376593594 [[],[]] .smaller = true := by decide
def e2422376593622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422376593622 : Closed e2422376593622 ∧ code e2422376593622 = 11218469615830 := by decide
theorem cert_e2422376593622 : check e2422376593622 [[],[]] .smaller = true := by decide
def e2422376593626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422376593626 : Closed e2422376593626 ∧ code e2422376593626 = 11218469615834 := by decide
theorem cert_e2422376593626 : check e2422376593626 [[],[]] .smaller = true := by decide
def e2422376593642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422376593642 : Closed e2422376593642 ∧ code e2422376593642 = 11218469615850 := by decide
theorem cert_e2422376593642 : check e2422376593642 [[],[]] .smaller = true := by decide
def e2422376593834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422376593834 : Closed e2422376593834 ∧ code e2422376593834 = 11218469616042 := by decide
theorem cert_e2422376593834 : check e2422376593834 [[],[]] .smaller = true := by decide
def e2422376593930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422376593930 : Closed e2422376593930 ∧ code e2422376593930 = 11218469616138 := by decide
theorem cert_e2422376593930 : check e2422376593930 [[],[]] .smaller = true := by decide
def e2422376593966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422376593966 : Closed e2422376593966 ∧ code e2422376593966 = 11218469616174 := by decide
theorem cert_e2422376593966 : check e2422376593966 [[],[]] .smaller = true := by decide
def e2422376593974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422376593974 : Closed e2422376593974 ∧ code e2422376593974 = 11218469616182 := by decide
theorem cert_e2422376593974 : check e2422376593974 [[],[]] .smaller = true := by decide
def e2422376593978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422376593978 : Closed e2422376593978 ∧ code e2422376593978 = 11218469616186 := by decide
theorem cert_e2422376593978 : check e2422376593978 [[],[]] .smaller = true := by decide
def e2422376594026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422376594026 : Closed e2422376594026 ∧ code e2422376594026 = 11218469616234 := by decide
theorem cert_e2422376594026 : check e2422376594026 [[],[]] .smaller = true := by decide
def e2422376594050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422376594050 : Closed e2422376594050 ∧ code e2422376594050 = 11218469616258 := by decide
theorem cert_e2422376594050 : check e2422376594050 [[],[]] .smaller = true := by decide
def e2422376594062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422376594062 : Closed e2422376594062 ∧ code e2422376594062 = 11218469616270 := by decide
theorem cert_e2422376594062 : check e2422376594062 [[],[]] .smaller = true := by decide
def e2422376594074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376594074 : Closed e2422376594074 ∧ code e2422376594074 = 11218469616282 := by decide
theorem cert_e2422376594074 : check e2422376594074 [[],[]] .smaller = true := by decide
def e2422376594118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422376594118 : Closed e2422376594118 ∧ code e2422376594118 = 11218469616326 := by decide
theorem cert_e2422376594118 : check e2422376594118 [[],[]] .smaller = true := by decide
def e2422376594142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2422376594142 : Closed e2422376594142 ∧ code e2422376594142 = 11218469616350 := by decide
theorem cert_e2422376594142 : check e2422376594142 [[],[]] .three = true := by decide
def e2422376594146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422376594146 : Closed e2422376594146 ∧ code e2422376594146 = 11218469616354 := by decide
theorem cert_e2422376594146 : check e2422376594146 [[],[]] .smaller = true := by decide
def e2422376594158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2422376594158 : Closed e2422376594158 ∧ code e2422376594158 = 11218469616366 := by decide
theorem cert_e2422376594158 : check e2422376594158 [[],[]] .smaller = true := by decide
def e2422376594166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2422376594166 : Closed e2422376594166 ∧ code e2422376594166 = 11218469616374 := by decide
theorem cert_e2422376594166 : check e2422376594166 [[],[]] .three = true := by decide
def e2422376594202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422376594202 : Closed e2422376594202 ∧ code e2422376594202 = 11218469616410 := by decide
theorem cert_e2422376594202 : check e2422376594202 [[],[]] .smaller = true := by decide
def e2422376594246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422376594246 : Closed e2422376594246 ∧ code e2422376594246 = 11218469616454 := by decide
theorem cert_e2422376594246 : check e2422376594246 [[],[]] .smaller = true := by decide
def e2422376594270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2422376594270 : Closed e2422376594270 ∧ code e2422376594270 = 11218469616478 := by decide
theorem cert_e2422376594270 : check e2422376594270 [[],[]] .three = true := by decide
def e2422376594298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2422376594298 : Closed e2422376594298 ∧ code e2422376594298 = 11218469616506 := by decide
theorem cert_e2422376594298 : check e2422376594298 [[],[]] .three = true := by decide
def e2422376594314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422376594314 : Closed e2422376594314 ∧ code e2422376594314 = 11218469616522 := by decide
theorem cert_e2422376594314 : check e2422376594314 [[],[]] .smaller = true := by decide
def e2422376594338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422376594338 : Closed e2422376594338 ∧ code e2422376594338 = 11218469616546 := by decide
theorem cert_e2422376594338 : check e2422376594338 [[],[]] .smaller = true := by decide
def e2422376594350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2422376594350 : Closed e2422376594350 ∧ code e2422376594350 = 11218469616558 := by decide
theorem cert_e2422376594350 : check e2422376594350 [[],[]] .smaller = true := by decide
def e2422376594362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2422376594362 : Closed e2422376594362 ∧ code e2422376594362 = 11218469616570 := by decide
theorem cert_e2422376594362 : check e2422376594362 [[],[]] .smaller = true := by decide
def e2422376594390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2422376594390 : Closed e2422376594390 ∧ code e2422376594390 = 11218469616598 := by decide
theorem cert_e2422376594390 : check e2422376594390 [[],[]] .three = true := by decide
def e2422376594394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2422376594394 : Closed e2422376594394 ∧ code e2422376594394 = 11218469616602 := by decide
theorem cert_e2422376594394 : check e2422376594394 [[],[]] .three = true := by decide
def e2422376594518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422376594518 : Closed e2422376594518 ∧ code e2422376594518 = 11218469616726 := by decide
theorem cert_e2422376594518 : check e2422376594518 [[],[]] .three = true := by decide
def e2422376594522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422376594522 : Closed e2422376594522 ∧ code e2422376594522 = 11218469616730 := by decide
theorem cert_e2422376594522 : check e2422376594522 [[],[]] .three = true := by decide
def e2422376594538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422376594538 : Closed e2422376594538 ∧ code e2422376594538 = 11218469616746 := by decide
theorem cert_e2422376594538 : check e2422376594538 [[],[]] .three = true := by decide
def e2422376594710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422376594710 : Closed e2422376594710 ∧ code e2422376594710 = 11218469616918 := by decide
theorem cert_e2422376594710 : check e2422376594710 [[],[]] .three = true := by decide
def e2422376594714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422376594714 : Closed e2422376594714 ∧ code e2422376594714 = 11218469616922 := by decide
theorem cert_e2422376594714 : check e2422376594714 [[],[]] .three = true := by decide
def e2422376594758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422376594758 : Closed e2422376594758 ∧ code e2422376594758 = 11218469616966 := by decide
theorem cert_e2422376594758 : check e2422376594758 [[],[]] .three = true := by decide
def e2422376594782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2422376594782 : Closed e2422376594782 ∧ code e2422376594782 = 11218469616990 := by decide
theorem cert_e2422376594782 : check e2422376594782 [[],[]] .three = true := by decide
def e2422376594786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422376594786 : Closed e2422376594786 ∧ code e2422376594786 = 11218469616994 := by decide
theorem cert_e2422376594786 : check e2422376594786 [[],[]] .three = true := by decide
def e2422376594798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422376594798 : Closed e2422376594798 ∧ code e2422376594798 = 11218469617006 := by decide
theorem cert_e2422376594798 : check e2422376594798 [[],[]] .three = true := by decide
def e2422376594806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422376594806 : Closed e2422376594806 ∧ code e2422376594806 = 11218469617014 := by decide
theorem cert_e2422376594806 : check e2422376594806 [[],[]] .three = true := by decide
def e2422376594810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2422376594810 : Closed e2422376594810 ∧ code e2422376594810 = 11218469617018 := by decide
theorem cert_e2422376594810 : check e2422376594810 [[],[]] .three = true := by decide
def e2422376594826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422376594826 : Closed e2422376594826 ∧ code e2422376594826 = 11218469617034 := by decide
theorem cert_e2422376594826 : check e2422376594826 [[],[]] .three = true := by decide
def e2422376594850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422376594850 : Closed e2422376594850 ∧ code e2422376594850 = 11218469617058 := by decide
theorem cert_e2422376594850 : check e2422376594850 [[],[]] .three = true := by decide
def e2422376594862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422376594862 : Closed e2422376594862 ∧ code e2422376594862 = 11218469617070 := by decide
theorem cert_e2422376594862 : check e2422376594862 [[],[]] .three = true := by decide
def e2422376594874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422376594874 : Closed e2422376594874 ∧ code e2422376594874 = 11218469617082 := by decide
theorem cert_e2422376594874 : check e2422376594874 [[],[]] .three = true := by decide
def e2422376594902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422376594902 : Closed e2422376594902 ∧ code e2422376594902 = 11218469617110 := by decide
theorem cert_e2422376594902 : check e2422376594902 [[],[]] .three = true := by decide
def e2422376594906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422376594906 : Closed e2422376594906 ∧ code e2422376594906 = 11218469617114 := by decide
theorem cert_e2422376594906 : check e2422376594906 [[],[]] .three = true := by decide
def e2422376594922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2422376594922 : Closed e2422376594922 ∧ code e2422376594922 = 11218469617130 := by decide
theorem cert_e2422376594922 : check e2422376594922 [[],[]] .three = true := by decide
def e2422376595886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2))))))))
theorem wire_e2422376595886 : Closed e2422376595886 ∧ code e2422376595886 = 11218469618094 := by decide
theorem cert_e2422376595886 : check e2422376595886 [[],[]] .smaller = true := by decide
def e2422376596078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376596078 : Closed e2422376596078 ∧ code e2422376596078 = 11218469618286 := by decide
theorem cert_e2422376596078 : check e2422376596078 [[],[]] .smaller = true := by decide
def e2422376596090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376596090 : Closed e2422376596090 ∧ code e2422376596090 = 11218469618298 := by decide
theorem cert_e2422376596090 : check e2422376596090 [[],[]] .smaller = true := by decide
def e2422376596446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 3))))))))
theorem wire_e2422376596446 : Closed e2422376596446 ∧ code e2422376596446 = 11218469618654 := by decide
theorem cert_e2422376596446 : check e2422376596446 [[],[]] .three = true := by decide
def e2422376596462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 2))))))))
theorem wire_e2422376596462 : Closed e2422376596462 ∧ code e2422376596462 = 11218469618670 := by decide
theorem cert_e2422376596462 : check e2422376596462 [[],[]] .smaller = true := by decide
def e2422376596470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 1))))))))
theorem wire_e2422376596470 : Closed e2422376596470 ∧ code e2422376596470 = 11218469618678 := by decide
theorem cert_e2422376596470 : check e2422376596470 [[],[]] .three = true := by decide
def e2422376597214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 3))))))))
theorem wire_e2422376597214 : Closed e2422376597214 ∧ code e2422376597214 = 11218469619422 := by decide
theorem cert_e2422376597214 : check e2422376597214 [[],[]] .three = true := by decide
def e2422376597230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))))
theorem wire_e2422376597230 : Closed e2422376597230 ∧ code e2422376597230 = 11218469619438 := by decide
theorem cert_e2422376597230 : check e2422376597230 [[],[]] .smaller = true := by decide
def e2422376597238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e2422376597238 : Closed e2422376597238 ∧ code e2422376597238 = 11218469619446 := by decide
theorem cert_e2422376597238 : check e2422376597238 [[],[]] .smaller = true := by decide
def e2422376597242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 4)))) (.var 0))))))))
theorem wire_e2422376597242 : Closed e2422376597242 ∧ code e2422376597242 = 11218469619450 := by decide
theorem cert_e2422376597242 : check e2422376597242 [[],[]] .three = true := by decide
def e2422376597342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 3))))))))
theorem wire_e2422376597342 : Closed e2422376597342 ∧ code e2422376597342 = 11218469619550 := by decide
theorem cert_e2422376597342 : check e2422376597342 [[],[]] .three = true := by decide
def e2422376597358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e2422376597358 : Closed e2422376597358 ∧ code e2422376597358 = 11218469619566 := by decide
theorem cert_e2422376597358 : check e2422376597358 [[],[]] .smaller = true := by decide
def e2422376597370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e2422376597370 : Closed e2422376597370 ∧ code e2422376597370 = 11218469619578 := by decide
theorem cert_e2422376597370 : check e2422376597370 [[],[]] .smaller = true := by decide
def e2422376597422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))))
theorem wire_e2422376597422 : Closed e2422376597422 ∧ code e2422376597422 = 11218469619630 := by decide
theorem cert_e2422376597422 : check e2422376597422 [[],[]] .smaller = true := by decide
def e2422376597462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e2422376597462 : Closed e2422376597462 ∧ code e2422376597462 = 11218469619670 := by decide
theorem cert_e2422376597462 : check e2422376597462 [[],[]] .smaller = true := by decide
def e2422376597466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e2422376597466 : Closed e2422376597466 ∧ code e2422376597466 = 11218469619674 := by decide
theorem cert_e2422376597466 : check e2422376597466 [[],[]] .smaller = true := by decide
def e2422376597482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 4) (.var 0)))) (.var 0))))))))
theorem wire_e2422376597482 : Closed e2422376597482 ∧ code e2422376597482 = 11218469619690 := by decide
theorem cert_e2422376597482 : check e2422376597482 [[],[]] .three = true := by decide
def e2422376597982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422376597982 : Closed e2422376597982 ∧ code e2422376597982 = 11218469620190 := by decide
theorem cert_e2422376597982 : check e2422376597982 [[],[]] .three = true := by decide
def e2422376597998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422376597998 : Closed e2422376597998 ∧ code e2422376597998 = 11218469620206 := by decide
theorem cert_e2422376597998 : check e2422376597998 [[],[]] .smaller = true := by decide
def e2422376598006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422376598006 : Closed e2422376598006 ∧ code e2422376598006 = 11218469620214 := by decide
theorem cert_e2422376598006 : check e2422376598006 [[],[]] .three = true := by decide
def e2422376598750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422376598750 : Closed e2422376598750 ∧ code e2422376598750 = 11218469620958 := by decide
theorem cert_e2422376598750 : check e2422376598750 [[],[]] .three = true := by decide
def e2422376598766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422376598766 : Closed e2422376598766 ∧ code e2422376598766 = 11218469620974 := by decide
theorem cert_e2422376598766 : check e2422376598766 [[],[]] .smaller = true := by decide
def e2422376598774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422376598774 : Closed e2422376598774 ∧ code e2422376598774 = 11218469620982 := by decide
theorem cert_e2422376598774 : check e2422376598774 [[],[]] .smaller = true := by decide
def e2422376598778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422376598778 : Closed e2422376598778 ∧ code e2422376598778 = 11218469620986 := by decide
theorem cert_e2422376598778 : check e2422376598778 [[],[]] .three = true := by decide
def e2422376599102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 4)))))))))
theorem wire_e2422376599102 : Closed e2422376599102 ∧ code e2422376599102 = 11218469621310 := by decide
theorem cert_e2422376599102 : check e2422376599102 [[],[]] .three = true := by decide
def e2422376599150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376599150 : Closed e2422376599150 ∧ code e2422376599150 = 11218469621358 := by decide
theorem cert_e2422376599150 : check e2422376599150 [[],[]] .smaller = true := by decide
def e2422376599162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376599162 : Closed e2422376599162 ∧ code e2422376599162 = 11218469621370 := by decide
theorem cert_e2422376599162 : check e2422376599162 [[],[]] .smaller = true := by decide
def e2422376599326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 3)))))))))
theorem wire_e2422376599326 : Closed e2422376599326 ∧ code e2422376599326 = 11218469621534 := by decide
theorem cert_e2422376599326 : check e2422376599326 [[],[]] .smaller = true := by decide
def e2422376599350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422376599350 : Closed e2422376599350 ∧ code e2422376599350 = 11218469621558 := by decide
theorem cert_e2422376599350 : check e2422376599350 [[],[]] .smaller = true := by decide
def e2422376599354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422376599354 : Closed e2422376599354 ∧ code e2422376599354 = 11218469621562 := by decide
theorem cert_e2422376599354 : check e2422376599354 [[],[]] .smaller = true := by decide
def e2422376599438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 2)))))))))
theorem wire_e2422376599438 : Closed e2422376599438 ∧ code e2422376599438 = 11218469621646 := by decide
theorem cert_e2422376599438 : check e2422376599438 [[],[]] .three = true := by decide
def e2422376599450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376599450 : Closed e2422376599450 ∧ code e2422376599450 = 11218469621658 := by decide
theorem cert_e2422376599450 : check e2422376599450 [[],[]] .three = true := by decide
def e2422376601262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e2422376601262 : Closed e2422376601262 ∧ code e2422376601262 = 11218469623470 := by decide
theorem cert_e2422376601262 : check e2422376601262 [[],[]] .smaller = true := by decide
end Blc.Floor43
