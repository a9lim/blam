import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389662819818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2389662819818 : Closed e2389662819818 ∧ code e2389662819818 = 11185755842026 := by decide
theorem cert_e2389662819818 : check e2389662819818 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662819950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2389662819950 : Closed e2389662819950 ∧ code e2389662819950 = 11185755842158 := by decide
theorem cert_e2389662819950 : check e2389662819950 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662819962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2389662819962 : Closed e2389662819962 ∧ code e2389662819962 = 11185755842170 := by decide
theorem cert_e2389662819962 : check e2389662819962 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662820250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2389662820250 : Closed e2389662820250 ∧ code e2389662820250 = 11185755842458 := by decide
theorem cert_e2389662820250 : check e2389662820250 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662823126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2389662823126 : Closed e2389662823126 ∧ code e2389662823126 = 11185755845334 := by decide
theorem cert_e2389662823126 : check e2389662823126 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662823130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2389662823130 : Closed e2389662823130 ∧ code e2389662823130 = 11185755845338 := by decide
theorem cert_e2389662823130 : check e2389662823130 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662823146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2389662823146 : Closed e2389662823146 ∧ code e2389662823146 = 11185755845354 := by decide
theorem cert_e2389662823146 : check e2389662823146 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662823222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2389662823222 : Closed e2389662823222 ∧ code e2389662823222 = 11185755845430 := by decide
theorem cert_e2389662823222 : check e2389662823222 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662823226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2389662823226 : Closed e2389662823226 ∧ code e2389662823226 = 11185755845434 := by decide
theorem cert_e2389662823226 : check e2389662823226 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662823322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2389662823322 : Closed e2389662823322 ∧ code e2389662823322 = 11185755845530 := by decide
theorem cert_e2389662823322 : check e2389662823322 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662960494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389662960494 : Closed e2389662960494 ∧ code e2389662960494 = 11185755982702 := by decide
theorem cert_e2389662960494 : check e2389662960494 [[],[.left],[],[]] .smaller = true := by decide
def e2389662960502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389662960502 : Closed e2389662960502 ∧ code e2389662960502 = 11185755982710 := by decide
theorem cert_e2389662960502 : check e2389662960502 [[],[.left],[],[]] .smaller = true := by decide
def e2389662960558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389662960558 : Closed e2389662960558 ∧ code e2389662960558 = 11185755982766 := by decide
theorem cert_e2389662960558 : check e2389662960558 [[],[.left],[],[]] .smaller = true := by decide
def e2389662960570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389662960570 : Closed e2389662960570 ∧ code e2389662960570 = 11185755982778 := by decide
theorem cert_e2389662960570 : check e2389662960570 [[],[.left],[],[]] .smaller = true := by decide
def e2389662960598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389662960598 : Closed e2389662960598 ∧ code e2389662960598 = 11185755982806 := by decide
theorem cert_e2389662960598 : check e2389662960598 [[],[.left],[],[]] .smaller = true := by decide
def e2389662960602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389662960602 : Closed e2389662960602 ∧ code e2389662960602 = 11185755982810 := by decide
theorem cert_e2389662960602 : check e2389662960602 [[],[.left],[],[]] .smaller = true := by decide
def e2389662960878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389662960878 : Closed e2389662960878 ∧ code e2389662960878 = 11185755983086 := by decide
theorem cert_e2389662960878 : check e2389662960878 [[],[.left],[],[]] .smaller = true := by decide
def e2389662960886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389662960886 : Closed e2389662960886 ∧ code e2389662960886 = 11185755983094 := by decide
theorem cert_e2389662960886 : check e2389662960886 [[],[.left],[],[]] .smaller = true := by decide
def e2389662961262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389662961262 : Closed e2389662961262 ∧ code e2389662961262 = 11185755983470 := by decide
theorem cert_e2389662961262 : check e2389662961262 [[],[.left],[],[]] .smaller = true := by decide
def e2389662961274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389662961274 : Closed e2389662961274 ∧ code e2389662961274 = 11185755983482 := by decide
theorem cert_e2389662961274 : check e2389662961274 [[],[.left],[],[]] .smaller = true := by decide
def e2389662961462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389662961462 : Closed e2389662961462 ∧ code e2389662961462 = 11185755983670 := by decide
theorem cert_e2389662961462 : check e2389662961462 [[],[.left],[],[]] .smaller = true := by decide
def e2389662961466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389662961466 : Closed e2389662961466 ∧ code e2389662961466 = 11185755983674 := by decide
theorem cert_e2389662961466 : check e2389662961466 [[],[.left],[],[]] .smaller = true := by decide
def e2389663550318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389663550318 : Closed e2389663550318 ∧ code e2389663550318 = 11185756572526 := by decide
theorem cert_e2389663550318 : check e2389663550318 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663550326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389663550326 : Closed e2389663550326 ∧ code e2389663550326 = 11185756572534 := by decide
theorem cert_e2389663550326 : check e2389663550326 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663550382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389663550382 : Closed e2389663550382 ∧ code e2389663550382 = 11185756572590 := by decide
theorem cert_e2389663550382 : check e2389663550382 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663550394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389663550394 : Closed e2389663550394 ∧ code e2389663550394 = 11185756572602 := by decide
theorem cert_e2389663550394 : check e2389663550394 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663550422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389663550422 : Closed e2389663550422 ∧ code e2389663550422 = 11185756572630 := by decide
theorem cert_e2389663550422 : check e2389663550422 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663550426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389663550426 : Closed e2389663550426 ∧ code e2389663550426 = 11185756572634 := by decide
theorem cert_e2389663550426 : check e2389663550426 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663550702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389663550702 : Closed e2389663550702 ∧ code e2389663550702 = 11185756572910 := by decide
theorem cert_e2389663550702 : check e2389663550702 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663550710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389663550710 : Closed e2389663550710 ∧ code e2389663550710 = 11185756572918 := by decide
theorem cert_e2389663550710 : check e2389663550710 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663551086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389663551086 : Closed e2389663551086 ∧ code e2389663551086 = 11185756573294 := by decide
theorem cert_e2389663551086 : check e2389663551086 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663551098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389663551098 : Closed e2389663551098 ∧ code e2389663551098 = 11185756573306 := by decide
theorem cert_e2389663551098 : check e2389663551098 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663551286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389663551286 : Closed e2389663551286 ∧ code e2389663551286 = 11185756573494 := by decide
theorem cert_e2389663551286 : check e2389663551286 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389663551290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389663551290 : Closed e2389663551290 ∧ code e2389663551290 = 11185756573498 := by decide
theorem cert_e2389663551290 : check e2389663551290 [[],[.left],[.left],[],[]] .smaller = true := by decide
def e2389746735838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2389746735838 : Closed e2389746735838 ∧ code e2389746735838 = 11185839758046 := by decide
theorem cert_e2389746735838 : check e2389746735838 [[],[.left],[]] .chain = true := by decide
def e2389746735862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2389746735862 : Closed e2389746735862 ∧ code e2389746735862 = 11185839758070 := by decide
theorem cert_e2389746735862 : check e2389746735862 [[],[.left],[]] .chain = true := by decide
def e2389746735966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2389746735966 : Closed e2389746735966 ∧ code e2389746735966 = 11185839758174 := by decide
theorem cert_e2389746735966 : check e2389746735966 [[],[.left],[]] .chain = true := by decide
def e2389746735982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2389746735982 : Closed e2389746735982 ∧ code e2389746735982 = 11185839758190 := by decide
theorem cert_e2389746735982 : check e2389746735982 [[],[.left],[]] .chain = true := by decide
def e2389746735990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2389746735990 : Closed e2389746735990 ∧ code e2389746735990 = 11185839758198 := by decide
theorem cert_e2389746735990 : check e2389746735990 [[],[.left],[]] .chain = true := by decide
def e2389746735994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2389746735994 : Closed e2389746735994 ∧ code e2389746735994 = 11185839758202 := by decide
theorem cert_e2389746735994 : check e2389746735994 [[],[.left],[]] .chain = true := by decide
def e2389746736054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2389746736054 : Closed e2389746736054 ∧ code e2389746736054 = 11185839758262 := by decide
theorem cert_e2389746736054 : check e2389746736054 [[],[.left],[]] .chain = true := by decide
def e2389746736086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2389746736086 : Closed e2389746736086 ∧ code e2389746736086 = 11185839758294 := by decide
theorem cert_e2389746736086 : check e2389746736086 [[],[.left],[]] .chain = true := by decide
def e2389746736090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2389746736090 : Closed e2389746736090 ∧ code e2389746736090 = 11185839758298 := by decide
theorem cert_e2389746736090 : check e2389746736090 [[],[.left],[]] .chain = true := by decide
def e2389746736478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2389746736478 : Closed e2389746736478 ∧ code e2389746736478 = 11185839758686 := by decide
theorem cert_e2389746736478 : check e2389746736478 [[],[.left],[]] .chain = true := by decide
def e2389746736494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2389746736494 : Closed e2389746736494 ∧ code e2389746736494 = 11185839758702 := by decide
theorem cert_e2389746736494 : check e2389746736494 [[],[.left],[]] .chain = true := by decide
def e2389746736502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2389746736502 : Closed e2389746736502 ∧ code e2389746736502 = 11185839758710 := by decide
theorem cert_e2389746736502 : check e2389746736502 [[],[.left],[]] .chain = true := by decide
def e2389746736506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2389746736506 : Closed e2389746736506 ∧ code e2389746736506 = 11185839758714 := by decide
theorem cert_e2389746736506 : check e2389746736506 [[],[.left],[]] .chain = true := by decide
def e2389746736558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2389746736558 : Closed e2389746736558 ∧ code e2389746736558 = 11185839758766 := by decide
theorem cert_e2389746736558 : check e2389746736558 [[],[.left],[]] .chain = true := by decide
def e2389746736570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2389746736570 : Closed e2389746736570 ∧ code e2389746736570 = 11185839758778 := by decide
theorem cert_e2389746736570 : check e2389746736570 [[],[.left],[]] .chain = true := by decide
def e2389746736598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2389746736598 : Closed e2389746736598 ∧ code e2389746736598 = 11185839758806 := by decide
theorem cert_e2389746736598 : check e2389746736598 [[],[.left],[]] .chain = true := by decide
def e2389746736602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2389746736602 : Closed e2389746736602 ∧ code e2389746736602 = 11185839758810 := by decide
theorem cert_e2389746736602 : check e2389746736602 [[],[.left],[]] .chain = true := by decide
def e2389746736618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2389746736618 : Closed e2389746736618 ∧ code e2389746736618 = 11185839758826 := by decide
theorem cert_e2389746736618 : check e2389746736618 [[],[.left],[]] .chain = true := by decide
def e2389746736822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2389746736822 : Closed e2389746736822 ∧ code e2389746736822 = 11185839759030 := by decide
theorem cert_e2389746736822 : check e2389746736822 [[],[.left],[]] .chain = true := by decide
def e2389746736854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2389746736854 : Closed e2389746736854 ∧ code e2389746736854 = 11185839759062 := by decide
theorem cert_e2389746736854 : check e2389746736854 [[],[.left],[]] .chain = true := by decide
def e2389746736858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2389746736858 : Closed e2389746736858 ∧ code e2389746736858 = 11185839759066 := by decide
theorem cert_e2389746736858 : check e2389746736858 [[],[.left],[]] .chain = true := by decide
def e2389746736982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2389746736982 : Closed e2389746736982 ∧ code e2389746736982 = 11185839759190 := by decide
theorem cert_e2389746736982 : check e2389746736982 [[],[.left],[]] .chain = true := by decide
def e2389746736986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2389746736986 : Closed e2389746736986 ∧ code e2389746736986 = 11185839759194 := by decide
theorem cert_e2389746736986 : check e2389746736986 [[],[.left],[]] .chain = true := by decide
def e2389746737002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2389746737002 : Closed e2389746737002 ∧ code e2389746737002 = 11185839759210 := by decide
theorem cert_e2389746737002 : check e2389746737002 [[],[.left],[]] .chain = true := by decide
def e2389746738910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2389746738910 : Closed e2389746738910 ∧ code e2389746738910 = 11185839761118 := by decide
theorem cert_e2389746738910 : check e2389746738910 [[],[.left],[]] .chain = true := by decide
def e2389746738934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2389746738934 : Closed e2389746738934 ∧ code e2389746738934 = 11185839761142 := by decide
theorem cert_e2389746738934 : check e2389746738934 [[],[.left],[]] .chain = true := by decide
def e2389746739038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2389746739038 : Closed e2389746739038 ∧ code e2389746739038 = 11185839761246 := by decide
theorem cert_e2389746739038 : check e2389746739038 [[],[.left],[]] .chain = true := by decide
def e2389746739054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2389746739054 : Closed e2389746739054 ∧ code e2389746739054 = 11185839761262 := by decide
theorem cert_e2389746739054 : check e2389746739054 [[],[.left],[]] .chain = true := by decide
def e2389746739062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2389746739062 : Closed e2389746739062 ∧ code e2389746739062 = 11185839761270 := by decide
theorem cert_e2389746739062 : check e2389746739062 [[],[.left],[]] .chain = true := by decide
def e2389746739066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2389746739066 : Closed e2389746739066 ∧ code e2389746739066 = 11185839761274 := by decide
theorem cert_e2389746739066 : check e2389746739066 [[],[.left],[]] .chain = true := by decide
def e2389746739126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2389746739126 : Closed e2389746739126 ∧ code e2389746739126 = 11185839761334 := by decide
theorem cert_e2389746739126 : check e2389746739126 [[],[.left],[]] .chain = true := by decide
def e2389746739158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2389746739158 : Closed e2389746739158 ∧ code e2389746739158 = 11185839761366 := by decide
theorem cert_e2389746739158 : check e2389746739158 [[],[.left],[]] .chain = true := by decide
def e2389746739162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2389746739162 : Closed e2389746739162 ∧ code e2389746739162 = 11185839761370 := by decide
theorem cert_e2389746739162 : check e2389746739162 [[],[.left],[]] .chain = true := by decide
def e2389746739678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2389746739678 : Closed e2389746739678 ∧ code e2389746739678 = 11185839761886 := by decide
theorem cert_e2389746739678 : check e2389746739678 [[],[.left],[]] .chain = true := by decide
def e2389746739702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2389746739702 : Closed e2389746739702 ∧ code e2389746739702 = 11185839761910 := by decide
theorem cert_e2389746739702 : check e2389746739702 [[],[.left],[]] .chain = true := by decide
def e2389746740446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2389746740446 : Closed e2389746740446 ∧ code e2389746740446 = 11185839762654 := by decide
theorem cert_e2389746740446 : check e2389746740446 [[],[.left],[]] .chain = true := by decide
def e2389746740462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2389746740462 : Closed e2389746740462 ∧ code e2389746740462 = 11185839762670 := by decide
theorem cert_e2389746740462 : check e2389746740462 [[],[.left],[]] .chain = true := by decide
def e2389746740470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2389746740470 : Closed e2389746740470 ∧ code e2389746740470 = 11185839762678 := by decide
theorem cert_e2389746740470 : check e2389746740470 [[],[.left],[]] .chain = true := by decide
def e2389746740474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2389746740474 : Closed e2389746740474 ∧ code e2389746740474 = 11185839762682 := by decide
theorem cert_e2389746740474 : check e2389746740474 [[],[.left],[]] .chain = true := by decide
def e2389746740854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2389746740854 : Closed e2389746740854 ∧ code e2389746740854 = 11185839763062 := by decide
theorem cert_e2389746740854 : check e2389746740854 [[],[.left],[]] .chain = true := by decide
def e2389746741046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389746741046 : Closed e2389746741046 ∧ code e2389746741046 = 11185839763254 := by decide
theorem cert_e2389746741046 : check e2389746741046 [[],[.left],[]] .chain = true := by decide
def e2389746741050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389746741050 : Closed e2389746741050 ∧ code e2389746741050 = 11185839763258 := by decide
theorem cert_e2389746741050 : check e2389746741050 [[],[.left],[]] .chain = true := by decide
def e2389746742110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2389746742110 : Closed e2389746742110 ∧ code e2389746742110 = 11185839764318 := by decide
theorem cert_e2389746742110 : check e2389746742110 [[],[.left],[]] .chain = true := by decide
def e2389746742126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2389746742126 : Closed e2389746742126 ∧ code e2389746742126 = 11185839764334 := by decide
theorem cert_e2389746742126 : check e2389746742126 [[],[.left],[]] .chain = true := by decide
def e2389746742134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2389746742134 : Closed e2389746742134 ∧ code e2389746742134 = 11185839764342 := by decide
theorem cert_e2389746742134 : check e2389746742134 [[],[.left],[]] .chain = true := by decide
def e2389746742138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2389746742138 : Closed e2389746742138 ∧ code e2389746742138 = 11185839764346 := by decide
theorem cert_e2389746742138 : check e2389746742138 [[],[.left],[]] .chain = true := by decide
def e2389746742190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2389746742190 : Closed e2389746742190 ∧ code e2389746742190 = 11185839764398 := by decide
theorem cert_e2389746742190 : check e2389746742190 [[],[.left],[]] .chain = true := by decide
def e2389746742202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2389746742202 : Closed e2389746742202 ∧ code e2389746742202 = 11185839764410 := by decide
theorem cert_e2389746742202 : check e2389746742202 [[],[.left],[]] .chain = true := by decide
def e2389746742230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2389746742230 : Closed e2389746742230 ∧ code e2389746742230 = 11185839764438 := by decide
theorem cert_e2389746742230 : check e2389746742230 [[],[.left],[]] .chain = true := by decide
def e2389746742234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2389746742234 : Closed e2389746742234 ∧ code e2389746742234 = 11185839764442 := by decide
theorem cert_e2389746742234 : check e2389746742234 [[],[.left],[]] .chain = true := by decide
def e2389746742250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2389746742250 : Closed e2389746742250 ∧ code e2389746742250 = 11185839764458 := by decide
theorem cert_e2389746742250 : check e2389746742250 [[],[.left],[]] .chain = true := by decide
def e2389746742494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2389746742494 : Closed e2389746742494 ∧ code e2389746742494 = 11185839764702 := by decide
theorem cert_e2389746742494 : check e2389746742494 [[],[.left],[]] .chain = true := by decide
def e2389746742510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2389746742510 : Closed e2389746742510 ∧ code e2389746742510 = 11185839764718 := by decide
theorem cert_e2389746742510 : check e2389746742510 [[],[.left],[]] .chain = true := by decide
def e2389746742518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2389746742518 : Closed e2389746742518 ∧ code e2389746742518 = 11185839764726 := by decide
theorem cert_e2389746742518 : check e2389746742518 [[],[.left],[]] .chain = true := by decide
def e2389746742522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2389746742522 : Closed e2389746742522 ∧ code e2389746742522 = 11185839764730 := by decide
theorem cert_e2389746742522 : check e2389746742522 [[],[.left],[]] .chain = true := by decide
def e2389746742894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389746742894 : Closed e2389746742894 ∧ code e2389746742894 = 11185839765102 := by decide
theorem cert_e2389746742894 : check e2389746742894 [[],[.left],[]] .chain = true := by decide
def e2389746742906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389746742906 : Closed e2389746742906 ∧ code e2389746742906 = 11185839765114 := by decide
theorem cert_e2389746742906 : check e2389746742906 [[],[.left],[]] .chain = true := by decide
def e2389746743094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389746743094 : Closed e2389746743094 ∧ code e2389746743094 = 11185839765302 := by decide
theorem cert_e2389746743094 : check e2389746743094 [[],[.left],[]] .chain = true := by decide
def e2389746743098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389746743098 : Closed e2389746743098 ∧ code e2389746743098 = 11185839765306 := by decide
theorem cert_e2389746743098 : check e2389746743098 [[],[.left],[]] .chain = true := by decide
def e2389746743194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389746743194 : Closed e2389746743194 ∧ code e2389746743194 = 11185839765402 := by decide
theorem cert_e2389746743194 : check e2389746743194 [[],[.left],[]] .chain = true := by decide
def e2389746743734 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2389746743734 : Closed e2389746743734 ∧ code e2389746743734 = 11185839765942 := by decide
theorem cert_e2389746743734 : check e2389746743734 [[],[.left],[]] .chain = true := by decide
def e2389746743766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2389746743766 : Closed e2389746743766 ∧ code e2389746743766 = 11185839765974 := by decide
theorem cert_e2389746743766 : check e2389746743766 [[],[.left],[]] .chain = true := by decide
def e2389746743770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2389746743770 : Closed e2389746743770 ∧ code e2389746743770 = 11185839765978 := by decide
theorem cert_e2389746743770 : check e2389746743770 [[],[.left],[]] .chain = true := by decide
def e2389746743926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2389746743926 : Closed e2389746743926 ∧ code e2389746743926 = 11185839766134 := by decide
theorem cert_e2389746743926 : check e2389746743926 [[],[.left],[]] .chain = true := by decide
def e2389746744118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389746744118 : Closed e2389746744118 ∧ code e2389746744118 = 11185839766326 := by decide
theorem cert_e2389746744118 : check e2389746744118 [[],[.left],[]] .chain = true := by decide
def e2389746744122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389746744122 : Closed e2389746744122 ∧ code e2389746744122 = 11185839766330 := by decide
theorem cert_e2389746744122 : check e2389746744122 [[],[.left],[]] .chain = true := by decide
def e2389746744534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2389746744534 : Closed e2389746744534 ∧ code e2389746744534 = 11185839766742 := by decide
theorem cert_e2389746744534 : check e2389746744534 [[],[.left],[]] .chain = true := by decide
def e2389746744538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2389746744538 : Closed e2389746744538 ∧ code e2389746744538 = 11185839766746 := by decide
theorem cert_e2389746744538 : check e2389746744538 [[],[.left],[]] .chain = true := by decide
def e2389746744554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2389746744554 : Closed e2389746744554 ∧ code e2389746744554 = 11185839766762 := by decide
theorem cert_e2389746744554 : check e2389746744554 [[],[.left],[]] .chain = true := by decide
def e2389746744630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389746744630 : Closed e2389746744630 ∧ code e2389746744630 = 11185839766838 := by decide
theorem cert_e2389746744630 : check e2389746744630 [[],[.left],[]] .chain = true := by decide
def e2389746744634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389746744634 : Closed e2389746744634 ∧ code e2389746744634 = 11185839766842 := by decide
theorem cert_e2389746744634 : check e2389746744634 [[],[.left],[]] .chain = true := by decide
def e2389746744730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389746744730 : Closed e2389746744730 ∧ code e2389746744730 = 11185839766938 := by decide
theorem cert_e2389746744730 : check e2389746744730 [[],[.left],[]] .chain = true := by decide
def e2389746751198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2389746751198 : Closed e2389746751198 ∧ code e2389746751198 = 11185839773406 := by decide
theorem cert_e2389746751198 : check e2389746751198 [[],[.left],[]] .chain = true := by decide
def e2389746751222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2389746751222 : Closed e2389746751222 ∧ code e2389746751222 = 11185839773430 := by decide
theorem cert_e2389746751222 : check e2389746751222 [[],[.left],[]] .chain = true := by decide
def e2389746751326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2389746751326 : Closed e2389746751326 ∧ code e2389746751326 = 11185839773534 := by decide
theorem cert_e2389746751326 : check e2389746751326 [[],[.left],[]] .chain = true := by decide
def e2389746751342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2389746751342 : Closed e2389746751342 ∧ code e2389746751342 = 11185839773550 := by decide
theorem cert_e2389746751342 : check e2389746751342 [[],[.left],[]] .chain = true := by decide
def e2389746751350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2389746751350 : Closed e2389746751350 ∧ code e2389746751350 = 11185839773558 := by decide
theorem cert_e2389746751350 : check e2389746751350 [[],[.left],[]] .chain = true := by decide
def e2389746751354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2389746751354 : Closed e2389746751354 ∧ code e2389746751354 = 11185839773562 := by decide
theorem cert_e2389746751354 : check e2389746751354 [[],[.left],[]] .chain = true := by decide
def e2389746751414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2389746751414 : Closed e2389746751414 ∧ code e2389746751414 = 11185839773622 := by decide
theorem cert_e2389746751414 : check e2389746751414 [[],[.left],[]] .chain = true := by decide
def e2389746751446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2389746751446 : Closed e2389746751446 ∧ code e2389746751446 = 11185839773654 := by decide
theorem cert_e2389746751446 : check e2389746751446 [[],[.left],[]] .chain = true := by decide
def e2389746751450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2389746751450 : Closed e2389746751450 ∧ code e2389746751450 = 11185839773658 := by decide
theorem cert_e2389746751450 : check e2389746751450 [[],[.left],[]] .chain = true := by decide
def e2389746751966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2389746751966 : Closed e2389746751966 ∧ code e2389746751966 = 11185839774174 := by decide
theorem cert_e2389746751966 : check e2389746751966 [[],[.left],[]] .chain = true := by decide
def e2389746751990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2389746751990 : Closed e2389746751990 ∧ code e2389746751990 = 11185839774198 := by decide
theorem cert_e2389746751990 : check e2389746751990 [[],[.left],[]] .chain = true := by decide
def e2389746752734 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389746752734 : Closed e2389746752734 ∧ code e2389746752734 = 11185839774942 := by decide
theorem cert_e2389746752734 : check e2389746752734 [[],[.left],[]] .chain = true := by decide
def e2389746752750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389746752750 : Closed e2389746752750 ∧ code e2389746752750 = 11185839774958 := by decide
theorem cert_e2389746752750 : check e2389746752750 [[],[.left],[]] .chain = true := by decide
def e2389746752758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389746752758 : Closed e2389746752758 ∧ code e2389746752758 = 11185839774966 := by decide
theorem cert_e2389746752758 : check e2389746752758 [[],[.left],[]] .chain = true := by decide
def e2389746752762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389746752762 : Closed e2389746752762 ∧ code e2389746752762 = 11185839774970 := by decide
theorem cert_e2389746752762 : check e2389746752762 [[],[.left],[]] .chain = true := by decide
def e2389746753142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2389746753142 : Closed e2389746753142 ∧ code e2389746753142 = 11185839775350 := by decide
theorem cert_e2389746753142 : check e2389746753142 [[],[.left],[]] .chain = true := by decide
def e2389746753334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389746753334 : Closed e2389746753334 ∧ code e2389746753334 = 11185839775542 := by decide
theorem cert_e2389746753334 : check e2389746753334 [[],[.left],[]] .chain = true := by decide
def e2389746753338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389746753338 : Closed e2389746753338 ∧ code e2389746753338 = 11185839775546 := by decide
theorem cert_e2389746753338 : check e2389746753338 [[],[.left],[]] .chain = true := by decide
def e2389746764638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2389746764638 : Closed e2389746764638 ∧ code e2389746764638 = 11185839786846 := by decide
theorem cert_e2389746764638 : check e2389746764638 [[],[.left],[]] .chain = true := by decide
def e2389746764654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389746764654 : Closed e2389746764654 ∧ code e2389746764654 = 11185839786862 := by decide
theorem cert_e2389746764654 : check e2389746764654 [[],[.left],[]] .chain = true := by decide
def e2389746764662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389746764662 : Closed e2389746764662 ∧ code e2389746764662 = 11185839786870 := by decide
theorem cert_e2389746764662 : check e2389746764662 [[],[.left],[]] .chain = true := by decide
def e2389746764666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2389746764666 : Closed e2389746764666 ∧ code e2389746764666 = 11185839786874 := by decide
theorem cert_e2389746764666 : check e2389746764666 [[],[.left],[]] .chain = true := by decide
def e2389746764718 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389746764718 : Closed e2389746764718 ∧ code e2389746764718 = 11185839786926 := by decide
theorem cert_e2389746764718 : check e2389746764718 [[],[.left],[]] .chain = true := by decide
def e2389746764730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389746764730 : Closed e2389746764730 ∧ code e2389746764730 = 11185839786938 := by decide
theorem cert_e2389746764730 : check e2389746764730 [[],[.left],[]] .chain = true := by decide
def e2389746764758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389746764758 : Closed e2389746764758 ∧ code e2389746764758 = 11185839786966 := by decide
theorem cert_e2389746764758 : check e2389746764758 [[],[.left],[]] .chain = true := by decide
def e2389746764762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389746764762 : Closed e2389746764762 ∧ code e2389746764762 = 11185839786970 := by decide
theorem cert_e2389746764762 : check e2389746764762 [[],[.left],[]] .chain = true := by decide
def e2389746764778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2389746764778 : Closed e2389746764778 ∧ code e2389746764778 = 11185839786986 := by decide
theorem cert_e2389746764778 : check e2389746764778 [[],[.left],[]] .chain = true := by decide
def e2389746765022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389746765022 : Closed e2389746765022 ∧ code e2389746765022 = 11185839787230 := by decide
theorem cert_e2389746765022 : check e2389746765022 [[],[.left],[]] .chain = true := by decide
def e2389746765038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389746765038 : Closed e2389746765038 ∧ code e2389746765038 = 11185839787246 := by decide
theorem cert_e2389746765038 : check e2389746765038 [[],[.left],[]] .chain = true := by decide
def e2389746765046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389746765046 : Closed e2389746765046 ∧ code e2389746765046 = 11185839787254 := by decide
theorem cert_e2389746765046 : check e2389746765046 [[],[.left],[]] .chain = true := by decide
def e2389746765050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389746765050 : Closed e2389746765050 ∧ code e2389746765050 = 11185839787258 := by decide
theorem cert_e2389746765050 : check e2389746765050 [[],[.left],[]] .chain = true := by decide
def e2389746765422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389746765422 : Closed e2389746765422 ∧ code e2389746765422 = 11185839787630 := by decide
theorem cert_e2389746765422 : check e2389746765422 [[],[.left],[]] .chain = true := by decide
def e2389746765434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389746765434 : Closed e2389746765434 ∧ code e2389746765434 = 11185839787642 := by decide
theorem cert_e2389746765434 : check e2389746765434 [[],[.left],[]] .chain = true := by decide
def e2389746765622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389746765622 : Closed e2389746765622 ∧ code e2389746765622 = 11185839787830 := by decide
theorem cert_e2389746765622 : check e2389746765622 [[],[.left],[]] .chain = true := by decide
def e2389746765626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389746765626 : Closed e2389746765626 ∧ code e2389746765626 = 11185839787834 := by decide
theorem cert_e2389746765626 : check e2389746765626 [[],[.left],[]] .chain = true := by decide
def e2389746765722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389746765722 : Closed e2389746765722 ∧ code e2389746765722 = 11185839787930 := by decide
theorem cert_e2389746765722 : check e2389746765722 [[],[.left],[]] .chain = true := by decide
def e2389746771382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2389746771382 : Closed e2389746771382 ∧ code e2389746771382 = 11185839793590 := by decide
theorem cert_e2389746771382 : check e2389746771382 [[],[.left],[]] .chain = true := by decide
def e2389746771414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2389746771414 : Closed e2389746771414 ∧ code e2389746771414 = 11185839793622 := by decide
theorem cert_e2389746771414 : check e2389746771414 [[],[.left],[]] .chain = true := by decide
def e2389746771418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2389746771418 : Closed e2389746771418 ∧ code e2389746771418 = 11185839793626 := by decide
theorem cert_e2389746771418 : check e2389746771418 [[],[.left],[]] .chain = true := by decide
def e2389746771574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2389746771574 : Closed e2389746771574 ∧ code e2389746771574 = 11185839793782 := by decide
theorem cert_e2389746771574 : check e2389746771574 [[],[.left],[]] .chain = true := by decide
def e2389746771766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389746771766 : Closed e2389746771766 ∧ code e2389746771766 = 11185839793974 := by decide
theorem cert_e2389746771766 : check e2389746771766 [[],[.left],[]] .chain = true := by decide
def e2389746771770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389746771770 : Closed e2389746771770 ∧ code e2389746771770 = 11185839793978 := by decide
theorem cert_e2389746771770 : check e2389746771770 [[],[.left],[]] .chain = true := by decide
def e2389746774742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2389746774742 : Closed e2389746774742 ∧ code e2389746774742 = 11185839796950 := by decide
theorem cert_e2389746774742 : check e2389746774742 [[],[.left],[]] .chain = true := by decide
def e2389746774746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2389746774746 : Closed e2389746774746 ∧ code e2389746774746 = 11185839796954 := by decide
theorem cert_e2389746774746 : check e2389746774746 [[],[.left],[]] .chain = true := by decide
def e2389746774762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2389746774762 : Closed e2389746774762 ∧ code e2389746774762 = 11185839796970 := by decide
theorem cert_e2389746774762 : check e2389746774762 [[],[.left],[]] .chain = true := by decide
def e2389746774838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389746774838 : Closed e2389746774838 ∧ code e2389746774838 = 11185839797046 := by decide
theorem cert_e2389746774838 : check e2389746774838 [[],[.left],[]] .chain = true := by decide
def e2389746774842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389746774842 : Closed e2389746774842 ∧ code e2389746774842 = 11185839797050 := by decide
theorem cert_e2389746774842 : check e2389746774842 [[],[.left],[]] .chain = true := by decide
def e2389746774938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389746774938 : Closed e2389746774938 ∧ code e2389746774938 = 11185839797146 := by decide
theorem cert_e2389746774938 : check e2389746774938 [[],[.left],[]] .chain = true := by decide
def e2389747000174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2389747000174 : Closed e2389747000174 ∧ code e2389747000174 = 11185840022382 := by decide
theorem cert_e2389747000174 : check e2389747000174 [[],[.left],[]] .sourceHead = true := by decide
def e2389747000182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2389747000182 : Closed e2389747000182 ∧ code e2389747000182 = 11185840022390 := by decide
theorem cert_e2389747000182 : check e2389747000182 [[],[.left],[]] .sourceHead = true := by decide
def e2389747000238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2389747000238 : Closed e2389747000238 ∧ code e2389747000238 = 11185840022446 := by decide
theorem cert_e2389747000238 : check e2389747000238 [[],[.left],[]] .sourceHead = true := by decide
def e2389747000250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2389747000250 : Closed e2389747000250 ∧ code e2389747000250 = 11185840022458 := by decide
theorem cert_e2389747000250 : check e2389747000250 [[],[.left],[]] .sourceHead = true := by decide
def e2389747000278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2389747000278 : Closed e2389747000278 ∧ code e2389747000278 = 11185840022486 := by decide
theorem cert_e2389747000278 : check e2389747000278 [[],[.left],[]] .sourceHead = true := by decide
def e2389747000282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2389747000282 : Closed e2389747000282 ∧ code e2389747000282 = 11185840022490 := by decide
theorem cert_e2389747000282 : check e2389747000282 [[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor43
