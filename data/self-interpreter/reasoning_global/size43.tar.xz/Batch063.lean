import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756132410074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e756132410074 : Closed e756132410074 ∧ code e756132410074 = 9552225432282 := by decide
theorem cert_e756132410074 : check e756132410074 [] .sourceHead = true := by decide
def e756132410090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e756132410090 : Closed e756132410090 ∧ code e756132410090 = 9552225432298 := by decide
theorem cert_e756132410090 : check e756132410090 [] .sourceHead = true := by decide
def e756132410166 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e756132410166 : Closed e756132410166 ∧ code e756132410166 = 9552225432374 := by decide
theorem cert_e756132410166 : check e756132410166 [] .sourceHead = true := by decide
def e756132410170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e756132410170 : Closed e756132410170 ∧ code e756132410170 = 9552225432378 := by decide
theorem cert_e756132410170 : check e756132410170 [] .sourceHead = true := by decide
def e756132410266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e756132410266 : Closed e756132410266 ∧ code e756132410266 = 9552225432474 := by decide
theorem cert_e756132410266 : check e756132410266 [] .sourceHead = true := by decide
def e756132547438 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e756132547438 : Closed e756132547438 ∧ code e756132547438 = 9552225569646 := by decide
theorem cert_e756132547438 : check e756132547438 [] .sourceHead = true := by decide
def e756132547446 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e756132547446 : Closed e756132547446 ∧ code e756132547446 = 9552225569654 := by decide
theorem cert_e756132547446 : check e756132547446 [] .sourceHead = true := by decide
def e756132547502 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e756132547502 : Closed e756132547502 ∧ code e756132547502 = 9552225569710 := by decide
theorem cert_e756132547502 : check e756132547502 [] .sourceHead = true := by decide
def e756132547514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e756132547514 : Closed e756132547514 ∧ code e756132547514 = 9552225569722 := by decide
theorem cert_e756132547514 : check e756132547514 [] .sourceHead = true := by decide
def e756132547542 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e756132547542 : Closed e756132547542 ∧ code e756132547542 = 9552225569750 := by decide
theorem cert_e756132547542 : check e756132547542 [] .sourceHead = true := by decide
def e756132547546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e756132547546 : Closed e756132547546 ∧ code e756132547546 = 9552225569754 := by decide
theorem cert_e756132547546 : check e756132547546 [] .sourceHead = true := by decide
def e756132547822 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e756132547822 : Closed e756132547822 ∧ code e756132547822 = 9552225570030 := by decide
theorem cert_e756132547822 : check e756132547822 [] .sourceHead = true := by decide
def e756132547830 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e756132547830 : Closed e756132547830 ∧ code e756132547830 = 9552225570038 := by decide
theorem cert_e756132547830 : check e756132547830 [] .sourceHead = true := by decide
def e756132548206 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e756132548206 : Closed e756132548206 ∧ code e756132548206 = 9552225570414 := by decide
theorem cert_e756132548206 : check e756132548206 [] .sourceHead = true := by decide
def e756132548218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e756132548218 : Closed e756132548218 ∧ code e756132548218 = 9552225570426 := by decide
theorem cert_e756132548218 : check e756132548218 [] .sourceHead = true := by decide
def e756132548406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e756132548406 : Closed e756132548406 ∧ code e756132548406 = 9552225570614 := by decide
theorem cert_e756132548406 : check e756132548406 [] .sourceHead = true := by decide
def e756132548410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e756132548410 : Closed e756132548410 ∧ code e756132548410 = 9552225570618 := by decide
theorem cert_e756132548410 : check e756132548410 [] .sourceHead = true := by decide
def e756133137262 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e756133137262 : Closed e756133137262 ∧ code e756133137262 = 9552226159470 := by decide
theorem cert_e756133137262 : check e756133137262 [] .sourceHead = true := by decide
def e756133137270 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e756133137270 : Closed e756133137270 ∧ code e756133137270 = 9552226159478 := by decide
theorem cert_e756133137270 : check e756133137270 [] .sourceHead = true := by decide
def e756133137326 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e756133137326 : Closed e756133137326 ∧ code e756133137326 = 9552226159534 := by decide
theorem cert_e756133137326 : check e756133137326 [] .sourceHead = true := by decide
def e756133137338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e756133137338 : Closed e756133137338 ∧ code e756133137338 = 9552226159546 := by decide
theorem cert_e756133137338 : check e756133137338 [] .sourceHead = true := by decide
def e756133137366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e756133137366 : Closed e756133137366 ∧ code e756133137366 = 9552226159574 := by decide
theorem cert_e756133137366 : check e756133137366 [] .sourceHead = true := by decide
def e756133137370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e756133137370 : Closed e756133137370 ∧ code e756133137370 = 9552226159578 := by decide
theorem cert_e756133137370 : check e756133137370 [] .sourceHead = true := by decide
def e756133137646 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e756133137646 : Closed e756133137646 ∧ code e756133137646 = 9552226159854 := by decide
theorem cert_e756133137646 : check e756133137646 [] .sourceHead = true := by decide
def e756133137654 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e756133137654 : Closed e756133137654 ∧ code e756133137654 = 9552226159862 := by decide
theorem cert_e756133137654 : check e756133137654 [] .sourceHead = true := by decide
def e756133138030 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e756133138030 : Closed e756133138030 ∧ code e756133138030 = 9552226160238 := by decide
theorem cert_e756133138030 : check e756133138030 [] .sourceHead = true := by decide
def e756133138042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e756133138042 : Closed e756133138042 ∧ code e756133138042 = 9552226160250 := by decide
theorem cert_e756133138042 : check e756133138042 [] .sourceHead = true := by decide
def e756133138230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e756133138230 : Closed e756133138230 ∧ code e756133138230 = 9552226160438 := by decide
theorem cert_e756133138230 : check e756133138230 [] .sourceHead = true := by decide
def e756133138234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e756133138234 : Closed e756133138234 ∧ code e756133138234 = 9552226160442 := by decide
theorem cert_e756133138234 : check e756133138234 [] .sourceHead = true := by decide
def e756154805786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756154805786 : Closed e756154805786 ∧ code e756154805786 = 9552247827994 := by decide
theorem cert_e756154805786 : check e756154805786 [] .sourceHead = true := by decide
def e756154808858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756154808858 : Closed e756154808858 ∧ code e756154808858 = 9552247831066 := by decide
theorem cert_e756154808858 : check e756154808858 [] .sourceHead = true := by decide
def e756154821146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756154821146 : Closed e756154821146 ∧ code e756154821146 = 9552247843354 := by decide
theorem cert_e756154821146 : check e756154821146 [] .sourceHead = true := by decide
def e756154870298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756154870298 : Closed e756154870298 ∧ code e756154870298 = 9552247892506 := by decide
theorem cert_e756154870298 : check e756154870298 [] .sourceHead = true := by decide
def e756154953242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756154953242 : Closed e756154953242 ∧ code e756154953242 = 9552247975450 := by decide
theorem cert_e756154953242 : check e756154953242 [] .sourceHead = true := by decide
def e756154955290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756154955290 : Closed e756154955290 ∧ code e756154955290 = 9552247977498 := by decide
theorem cert_e756154955290 : check e756154955290 [] .sourceHead = true := by decide
def e756155002394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155002394 : Closed e756155002394 ∧ code e756155002394 = 9552248024602 := by decide
theorem cert_e756155002394 : check e756155002394 [] .sourceHead = true := by decide
def e756155005466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155005466 : Closed e756155005466 ∧ code e756155005466 = 9552248027674 := by decide
theorem cert_e756155005466 : check e756155005466 [] .sourceHead = true := by decide
def e756155017754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155017754 : Closed e756155017754 ∧ code e756155017754 = 9552248039962 := by decide
theorem cert_e756155017754 : check e756155017754 [] .sourceHead = true := by decide
def e756155051546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155051546 : Closed e756155051546 ∧ code e756155051546 = 9552248073754 := by decide
theorem cert_e756155051546 : check e756155051546 [] .sourceHead = true := by decide
def e756155054618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155054618 : Closed e756155054618 ∧ code e756155054618 = 9552248076826 := by decide
theorem cert_e756155054618 : check e756155054618 [] .sourceHead = true := by decide
def e756155080730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756155080730 : Closed e756155080730 ∧ code e756155080730 = 9552248102938 := by decide
theorem cert_e756155080730 : check e756155080730 [] .sourceHead = true := by decide
def e756155080822 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756155080822 : Closed e756155080822 ∧ code e756155080822 = 9552248103030 := by decide
theorem cert_e756155080822 : check e756155080822 [] .sourceHead = true := by decide
def e756155081066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756155081066 : Closed e756155081066 ∧ code e756155081066 = 9552248103274 := by decide
theorem cert_e756155081066 : check e756155081066 [] .sourceHead = true := by decide
def e756155081114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756155081114 : Closed e756155081114 ∧ code e756155081114 = 9552248103322 := by decide
theorem cert_e756155081114 : check e756155081114 [] .sourceHead = true := by decide
def e756155082266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155082266 : Closed e756155082266 ∧ code e756155082266 = 9552248104474 := by decide
theorem cert_e756155082266 : check e756155082266 [] .sourceHead = true := by decide
def e756155096602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155096602 : Closed e756155096602 ∧ code e756155096602 = 9552248118810 := by decide
theorem cert_e756155096602 : check e756155096602 [] .sourceHead = true := by decide
def e756155117766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155117766 : Closed e756155117766 ∧ code e756155117766 = 9552248139974 := by decide
theorem cert_e756155117766 : check e756155117766 [] .sourceHead = true := by decide
def e756155125274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155125274 : Closed e756155125274 ∧ code e756155125274 = 9552248147482 := by decide
theorem cert_e756155125274 : check e756155125274 [] .sourceHead = true := by decide
def e756155128346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155128346 : Closed e756155128346 ∧ code e756155128346 = 9552248150554 := by decide
theorem cert_e756155128346 : check e756155128346 [] .sourceHead = true := by decide
def e756155129882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756155129882 : Closed e756155129882 ∧ code e756155129882 = 9552248152090 := by decide
theorem cert_e756155129882 : check e756155129882 [] .sourceHead = true := by decide
def e756155129974 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756155129974 : Closed e756155129974 ∧ code e756155129974 = 9552248152182 := by decide
theorem cert_e756155129974 : check e756155129974 [] .sourceHead = true := by decide
def e756155130218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756155130218 : Closed e756155130218 ∧ code e756155130218 = 9552248152426 := by decide
theorem cert_e756155130218 : check e756155130218 [] .sourceHead = true := by decide
def e756155130266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756155130266 : Closed e756155130266 ∧ code e756155130266 = 9552248152474 := by decide
theorem cert_e756155130266 : check e756155130266 [] .sourceHead = true := by decide
def e756155131418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155131418 : Closed e756155131418 ∧ code e756155131418 = 9552248153626 := by decide
theorem cert_e756155131418 : check e756155131418 [] .sourceHead = true := by decide
def e756155134150 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155134150 : Closed e756155134150 ∧ code e756155134150 = 9552248156358 := by decide
theorem cert_e756155134150 : check e756155134150 [] .sourceHead = true := by decide
def e756155136026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155136026 : Closed e756155136026 ∧ code e756155136026 = 9552248158234 := by decide
theorem cert_e756155136026 : check e756155136026 [] .sourceHead = true := by decide
def e756155182618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155182618 : Closed e756155182618 ∧ code e756155182618 = 9552248204826 := by decide
theorem cert_e756155182618 : check e756155182618 [] .sourceHead = true := by decide
def e756155185690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155185690 : Closed e756155185690 ∧ code e756155185690 = 9552248207898 := by decide
theorem cert_e756155185690 : check e756155185690 [] .sourceHead = true := by decide
def e756155227674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155227674 : Closed e756155227674 ∧ code e756155227674 = 9552248249882 := by decide
theorem cert_e756155227674 : check e756155227674 [] .sourceHead = true := by decide
def e756155248838 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155248838 : Closed e756155248838 ∧ code e756155248838 = 9552248271046 := by decide
theorem cert_e756155248838 : check e756155248838 [] .sourceHead = true := by decide
def e756155270682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155270682 : Closed e756155270682 ∧ code e756155270682 = 9552248292890 := by decide
theorem cert_e756155270682 : check e756155270682 [] .sourceHead = true := by decide
def e756155273414 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155273414 : Closed e756155273414 ∧ code e756155273414 = 9552248295622 := by decide
theorem cert_e756155273414 : check e756155273414 [] .sourceHead = true := by decide
def e756155299354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155299354 : Closed e756155299354 ∧ code e756155299354 = 9552248321562 := by decide
theorem cert_e756155299354 : check e756155299354 [] .sourceHead = true := by decide
def e756155300378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155300378 : Closed e756155300378 ∧ code e756155300378 = 9552248322586 := by decide
theorem cert_e756155300378 : check e756155300378 [] .sourceHead = true := by decide
def e756155312666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155312666 : Closed e756155312666 ∧ code e756155312666 = 9552248334874 := by decide
theorem cert_e756155312666 : check e756155312666 [] .sourceHead = true := by decide
def e756155321882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155321882 : Closed e756155321882 ∧ code e756155321882 = 9552248344090 := by decide
theorem cert_e756155321882 : check e756155321882 [] .sourceHead = true := by decide
def e756155324954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155324954 : Closed e756155324954 ∧ code e756155324954 = 9552248347162 := by decide
theorem cert_e756155324954 : check e756155324954 [] .sourceHead = true := by decide
def e756155326490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756155326490 : Closed e756155326490 ∧ code e756155326490 = 9552248348698 := by decide
theorem cert_e756155326490 : check e756155326490 [] .sourceHead = true := by decide
def e756155326582 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756155326582 : Closed e756155326582 ∧ code e756155326582 = 9552248348790 := by decide
theorem cert_e756155326582 : check e756155326582 [] .sourceHead = true := by decide
def e756155326826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756155326826 : Closed e756155326826 ∧ code e756155326826 = 9552248349034 := by decide
theorem cert_e756155326826 : check e756155326826 [] .sourceHead = true := by decide
def e756155326874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756155326874 : Closed e756155326874 ∧ code e756155326874 = 9552248349082 := by decide
theorem cert_e756155326874 : check e756155326874 [] .sourceHead = true := by decide
def e756155328026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155328026 : Closed e756155328026 ∧ code e756155328026 = 9552248350234 := by decide
theorem cert_e756155328026 : check e756155328026 [] .sourceHead = true := by decide
def e756155330758 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155330758 : Closed e756155330758 ∧ code e756155330758 = 9552248352966 := by decide
theorem cert_e756155330758 : check e756155330758 [] .sourceHead = true := by decide
def e756155332634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155332634 : Closed e756155332634 ∧ code e756155332634 = 9552248354842 := by decide
theorem cert_e756155332634 : check e756155332634 [] .sourceHead = true := by decide
def e756155336218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155336218 : Closed e756155336218 ∧ code e756155336218 = 9552248358426 := by decide
theorem cert_e756155336218 : check e756155336218 [] .sourceHead = true := by decide
def e756155338950 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155338950 : Closed e756155338950 ∧ code e756155338950 = 9552248361158 := by decide
theorem cert_e756155338950 : check e756155338950 [] .sourceHead = true := by decide
def e756155344922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155344922 : Closed e756155344922 ∧ code e756155344922 = 9552248367130 := by decide
theorem cert_e756155344922 : check e756155344922 [] .sourceHead = true := by decide
def e756155538970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155538970 : Closed e756155538970 ∧ code e756155538970 = 9552248561178 := by decide
theorem cert_e756155538970 : check e756155538970 [] .sourceHead = true := by decide
def e756155545114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155545114 : Closed e756155545114 ∧ code e756155545114 = 9552248567322 := by decide
theorem cert_e756155545114 : check e756155545114 [] .sourceHead = true := by decide
def e756155788826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155788826 : Closed e756155788826 ∧ code e756155788826 = 9552248811034 := by decide
theorem cert_e756155788826 : check e756155788826 [] .sourceHead = true := by decide
def e756155791898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155791898 : Closed e756155791898 ∧ code e756155791898 = 9552248814106 := by decide
theorem cert_e756155791898 : check e756155791898 [] .sourceHead = true := by decide
def e756155804186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155804186 : Closed e756155804186 ∧ code e756155804186 = 9552248826394 := by decide
theorem cert_e756155804186 : check e756155804186 [] .sourceHead = true := by decide
def e756155837978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155837978 : Closed e756155837978 ∧ code e756155837978 = 9552248860186 := by decide
theorem cert_e756155837978 : check e756155837978 [] .sourceHead = true := by decide
def e756155841050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155841050 : Closed e756155841050 ∧ code e756155841050 = 9552248863258 := by decide
theorem cert_e756155841050 : check e756155841050 [] .sourceHead = true := by decide
def e756155867162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756155867162 : Closed e756155867162 ∧ code e756155867162 = 9552248889370 := by decide
theorem cert_e756155867162 : check e756155867162 [] .sourceHead = true := by decide
def e756155867254 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756155867254 : Closed e756155867254 ∧ code e756155867254 = 9552248889462 := by decide
theorem cert_e756155867254 : check e756155867254 [] .sourceHead = true := by decide
def e756155867498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756155867498 : Closed e756155867498 ∧ code e756155867498 = 9552248889706 := by decide
theorem cert_e756155867498 : check e756155867498 [] .sourceHead = true := by decide
def e756155867546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756155867546 : Closed e756155867546 ∧ code e756155867546 = 9552248889754 := by decide
theorem cert_e756155867546 : check e756155867546 [] .sourceHead = true := by decide
def e756155868698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155868698 : Closed e756155868698 ∧ code e756155868698 = 9552248890906 := by decide
theorem cert_e756155868698 : check e756155868698 [] .sourceHead = true := by decide
def e756155883034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155883034 : Closed e756155883034 ∧ code e756155883034 = 9552248905242 := by decide
theorem cert_e756155883034 : check e756155883034 [] .sourceHead = true := by decide
def e756155904198 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155904198 : Closed e756155904198 ∧ code e756155904198 = 9552248926406 := by decide
theorem cert_e756155904198 : check e756155904198 [] .sourceHead = true := by decide
def e756155911706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155911706 : Closed e756155911706 ∧ code e756155911706 = 9552248933914 := by decide
theorem cert_e756155911706 : check e756155911706 [] .sourceHead = true := by decide
def e756155914778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756155914778 : Closed e756155914778 ∧ code e756155914778 = 9552248936986 := by decide
theorem cert_e756155914778 : check e756155914778 [] .sourceHead = true := by decide
def e756155916314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756155916314 : Closed e756155916314 ∧ code e756155916314 = 9552248938522 := by decide
theorem cert_e756155916314 : check e756155916314 [] .sourceHead = true := by decide
def e756155916406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756155916406 : Closed e756155916406 ∧ code e756155916406 = 9552248938614 := by decide
theorem cert_e756155916406 : check e756155916406 [] .sourceHead = true := by decide
def e756155916650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756155916650 : Closed e756155916650 ∧ code e756155916650 = 9552248938858 := by decide
theorem cert_e756155916650 : check e756155916650 [] .sourceHead = true := by decide
def e756155916698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756155916698 : Closed e756155916698 ∧ code e756155916698 = 9552248938906 := by decide
theorem cert_e756155916698 : check e756155916698 [] .sourceHead = true := by decide
def e756155917850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155917850 : Closed e756155917850 ∧ code e756155917850 = 9552248940058 := by decide
theorem cert_e756155917850 : check e756155917850 [] .sourceHead = true := by decide
def e756155920582 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756155920582 : Closed e756155920582 ∧ code e756155920582 = 9552248942790 := by decide
theorem cert_e756155920582 : check e756155920582 [] .sourceHead = true := by decide
def e756155922458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756155922458 : Closed e756155922458 ∧ code e756155922458 = 9552248944666 := by decide
theorem cert_e756155922458 : check e756155922458 [] .sourceHead = true := by decide
def e756156669466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756156669466 : Closed e756156669466 ∧ code e756156669466 = 9552249691674 := by decide
theorem cert_e756156669466 : check e756156669466 [] .sourceHead = true := by decide
def e756156690630 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756156690630 : Closed e756156690630 ∧ code e756156690630 = 9552249712838 := by decide
theorem cert_e756156690630 : check e756156690630 [] .sourceHead = true := by decide
def e756156712474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756156712474 : Closed e756156712474 ∧ code e756156712474 = 9552249734682 := by decide
theorem cert_e756156712474 : check e756156712474 [] .sourceHead = true := by decide
def e756156715206 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756156715206 : Closed e756156715206 ∧ code e756156715206 = 9552249737414 := by decide
theorem cert_e756156715206 : check e756156715206 [] .sourceHead = true := by decide
def e756157019674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756157019674 : Closed e756157019674 ∧ code e756157019674 = 9552250041882 := by decide
theorem cert_e756157019674 : check e756157019674 [] .sourceHead = true := by decide
def e756157082138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756157082138 : Closed e756157082138 ∧ code e756157082138 = 9552250104346 := by decide
theorem cert_e756157082138 : check e756157082138 [] .sourceHead = true := by decide
def e756157091354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756157091354 : Closed e756157091354 ∧ code e756157091354 = 9552250113562 := by decide
theorem cert_e756157091354 : check e756157091354 [] .sourceHead = true := by decide
def e756157094426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756157094426 : Closed e756157094426 ∧ code e756157094426 = 9552250116634 := by decide
theorem cert_e756157094426 : check e756157094426 [] .sourceHead = true := by decide
def e756157095962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756157095962 : Closed e756157095962 ∧ code e756157095962 = 9552250118170 := by decide
theorem cert_e756157095962 : check e756157095962 [] .sourceHead = true := by decide
def e756157096054 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756157096054 : Closed e756157096054 ∧ code e756157096054 = 9552250118262 := by decide
theorem cert_e756157096054 : check e756157096054 [] .sourceHead = true := by decide
def e756157096298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756157096298 : Closed e756157096298 ∧ code e756157096298 = 9552250118506 := by decide
theorem cert_e756157096298 : check e756157096298 [] .sourceHead = true := by decide
def e756157096346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756157096346 : Closed e756157096346 ∧ code e756157096346 = 9552250118554 := by decide
theorem cert_e756157096346 : check e756157096346 [] .sourceHead = true := by decide
def e756157097498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756157097498 : Closed e756157097498 ∧ code e756157097498 = 9552250119706 := by decide
theorem cert_e756157097498 : check e756157097498 [] .sourceHead = true := by decide
def e756157100230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756157100230 : Closed e756157100230 ∧ code e756157100230 = 9552250122438 := by decide
theorem cert_e756157100230 : check e756157100230 [] .sourceHead = true := by decide
def e756157102106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756157102106 : Closed e756157102106 ∧ code e756157102106 = 9552250124314 := by decide
theorem cert_e756157102106 : check e756157102106 [] .sourceHead = true := by decide
def e756157105690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756157105690 : Closed e756157105690 ∧ code e756157105690 = 9552250127898 := by decide
theorem cert_e756157105690 : check e756157105690 [] .sourceHead = true := by decide
def e756157108422 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756157108422 : Closed e756157108422 ∧ code e756157108422 = 9552250130630 := by decide
theorem cert_e756157108422 : check e756157108422 [] .sourceHead = true := by decide
def e756157114394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756157114394 : Closed e756157114394 ∧ code e756157114394 = 9552250136602 := by decide
theorem cert_e756157114394 : check e756157114394 [] .sourceHead = true := by decide
def e756168742426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168742426 : Closed e756168742426 ∧ code e756168742426 = 9552261764634 := by decide
theorem cert_e756168742426 : check e756168742426 [] .sourceHead = true := by decide
def e756168743450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168743450 : Closed e756168743450 ∧ code e756168743450 = 9552261765658 := by decide
theorem cert_e756168743450 : check e756168743450 [] .sourceHead = true := by decide
def e756168747546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168747546 : Closed e756168747546 ∧ code e756168747546 = 9552261769754 := by decide
theorem cert_e756168747546 : check e756168747546 [] .sourceHead = true := by decide
def e756168763930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168763930 : Closed e756168763930 ∧ code e756168763930 = 9552261786138 := by decide
theorem cert_e756168763930 : check e756168763930 [] .sourceHead = true := by decide
def e756168816154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168816154 : Closed e756168816154 ∧ code e756168816154 = 9552261838362 := by decide
theorem cert_e756168816154 : check e756168816154 [] .sourceHead = true := by decide
def e756168840730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168840730 : Closed e756168840730 ∧ code e756168840730 = 9552261862938 := by decide
theorem cert_e756168840730 : check e756168840730 [] .sourceHead = true := by decide
def e756168841754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168841754 : Closed e756168841754 ∧ code e756168841754 = 9552261863962 := by decide
theorem cert_e756168841754 : check e756168841754 [] .sourceHead = true := by decide
def e756168845850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168845850 : Closed e756168845850 ∧ code e756168845850 = 9552261868058 := by decide
theorem cert_e756168845850 : check e756168845850 [] .sourceHead = true := by decide
def e756168865306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168865306 : Closed e756168865306 ∧ code e756168865306 = 9552261887514 := by decide
theorem cert_e756168865306 : check e756168865306 [] .sourceHead = true := by decide
def e756168866330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168866330 : Closed e756168866330 ∧ code e756168866330 = 9552261888538 := by decide
theorem cert_e756168866330 : check e756168866330 [] .sourceHead = true := by decide
def e756168876058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756168876058 : Closed e756168876058 ∧ code e756168876058 = 9552261898266 := by decide
theorem cert_e756168876058 : check e756168876058 [] .sourceHead = true := by decide
def e756168876150 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756168876150 : Closed e756168876150 ∧ code e756168876150 = 9552261898358 := by decide
theorem cert_e756168876150 : check e756168876150 [] .sourceHead = true := by decide
def e756168876394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756168876394 : Closed e756168876394 ∧ code e756168876394 = 9552261898602 := by decide
theorem cert_e756168876394 : check e756168876394 [] .sourceHead = true := by decide
def e756168876442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756168876442 : Closed e756168876442 ∧ code e756168876442 = 9552261898650 := by decide
theorem cert_e756168876442 : check e756168876442 [] .sourceHead = true := by decide
def e756168877594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756168877594 : Closed e756168877594 ∧ code e756168877594 = 9552261899802 := by decide
theorem cert_e756168877594 : check e756168877594 [] .sourceHead = true := by decide
def e756168887834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168887834 : Closed e756168887834 ∧ code e756168887834 = 9552261910042 := by decide
theorem cert_e756168887834 : check e756168887834 [] .sourceHead = true := by decide
def e756168890906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168890906 : Closed e756168890906 ∧ code e756168890906 = 9552261913114 := by decide
theorem cert_e756168890906 : check e756168890906 [] .sourceHead = true := by decide
def e756168892442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756168892442 : Closed e756168892442 ∧ code e756168892442 = 9552261914650 := by decide
theorem cert_e756168892442 : check e756168892442 [] .sourceHead = true := by decide
def e756168892534 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756168892534 : Closed e756168892534 ∧ code e756168892534 = 9552261914742 := by decide
theorem cert_e756168892534 : check e756168892534 [] .sourceHead = true := by decide
def e756168892778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756168892778 : Closed e756168892778 ∧ code e756168892778 = 9552261914986 := by decide
theorem cert_e756168892778 : check e756168892778 [] .sourceHead = true := by decide
def e756168892826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756168892826 : Closed e756168892826 ∧ code e756168892826 = 9552261915034 := by decide
theorem cert_e756168892826 : check e756168892826 [] .sourceHead = true := by decide
def e756168893978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756168893978 : Closed e756168893978 ∧ code e756168893978 = 9552261916186 := by decide
theorem cert_e756168893978 : check e756168893978 [] .sourceHead = true := by decide
def e756168896710 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756168896710 : Closed e756168896710 ∧ code e756168896710 = 9552261918918 := by decide
theorem cert_e756168896710 : check e756168896710 [] .sourceHead = true := by decide
def e756168898586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756168898586 : Closed e756168898586 ∧ code e756168898586 = 9552261920794 := by decide
theorem cert_e756168898586 : check e756168898586 [] .sourceHead = true := by decide
def e756168906778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756168906778 : Closed e756168906778 ∧ code e756168906778 = 9552261928986 := by decide
theorem cert_e756168906778 : check e756168906778 [] .sourceHead = true := by decide
def e756168930842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168930842 : Closed e756168930842 ∧ code e756168930842 = 9552261953050 := by decide
theorem cert_e756168930842 : check e756168930842 [] .sourceHead = true := by decide
def e756168931866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168931866 : Closed e756168931866 ∧ code e756168931866 = 9552261954074 := by decide
theorem cert_e756168931866 : check e756168931866 [] .sourceHead = true := by decide
def e756168944154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168944154 : Closed e756168944154 ∧ code e756168944154 = 9552261966362 := by decide
theorem cert_e756168944154 : check e756168944154 [] .sourceHead = true := by decide
def e756168953370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168953370 : Closed e756168953370 ∧ code e756168953370 = 9552261975578 := by decide
theorem cert_e756168953370 : check e756168953370 [] .sourceHead = true := by decide
def e756168956442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168956442 : Closed e756168956442 ∧ code e756168956442 = 9552261978650 := by decide
theorem cert_e756168956442 : check e756168956442 [] .sourceHead = true := by decide
def e756168957978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756168957978 : Closed e756168957978 ∧ code e756168957978 = 9552261980186 := by decide
theorem cert_e756168957978 : check e756168957978 [] .sourceHead = true := by decide
def e756168958070 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756168958070 : Closed e756168958070 ∧ code e756168958070 = 9552261980278 := by decide
theorem cert_e756168958070 : check e756168958070 [] .sourceHead = true := by decide
def e756168958314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756168958314 : Closed e756168958314 ∧ code e756168958314 = 9552261980522 := by decide
theorem cert_e756168958314 : check e756168958314 [] .sourceHead = true := by decide
def e756168958362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756168958362 : Closed e756168958362 ∧ code e756168958362 = 9552261980570 := by decide
theorem cert_e756168958362 : check e756168958362 [] .sourceHead = true := by decide
def e756168959514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756168959514 : Closed e756168959514 ∧ code e756168959514 = 9552261981722 := by decide
theorem cert_e756168959514 : check e756168959514 [] .sourceHead = true := by decide
def e756168962246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756168962246 : Closed e756168962246 ∧ code e756168962246 = 9552261984454 := by decide
theorem cert_e756168962246 : check e756168962246 [] .sourceHead = true := by decide
def e756168964122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756168964122 : Closed e756168964122 ∧ code e756168964122 = 9552261986330 := by decide
theorem cert_e756168964122 : check e756168964122 [] .sourceHead = true := by decide
def e756168967706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756168967706 : Closed e756168967706 ∧ code e756168967706 = 9552261989914 := by decide
theorem cert_e756168967706 : check e756168967706 [] .sourceHead = true := by decide
def e756168970438 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756168970438 : Closed e756168970438 ∧ code e756168970438 = 9552261992646 := by decide
theorem cert_e756168970438 : check e756168970438 [] .sourceHead = true := by decide
def e756168976410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756168976410 : Closed e756168976410 ∧ code e756168976410 = 9552261998618 := by decide
theorem cert_e756168976410 : check e756168976410 [] .sourceHead = true := by decide
def e756169005082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169005082 : Closed e756169005082 ∧ code e756169005082 = 9552262027290 := by decide
theorem cert_e756169005082 : check e756169005082 [] .sourceHead = true := by decide
def e756169009178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169009178 : Closed e756169009178 ∧ code e756169009178 = 9552262031386 := by decide
theorem cert_e756169009178 : check e756169009178 [] .sourceHead = true := by decide
end Blc.Floor43
