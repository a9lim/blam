import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405974659270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405974659270 : Closed e2405974659270 ∧ code e2405974659270 = 11202067681478 := by decide
theorem cert_e2405974659270 : check e2405974659270 [[]] .width = true := by decide
def e2405974661146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405974661146 : Closed e2405974661146 ∧ code e2405974661146 = 11202067683354 := by decide
theorem cert_e2405974661146 : check e2405974661146 [[]] .width = true := by decide
def e2405974662682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974662682 : Closed e2405974662682 ∧ code e2405974662682 = 11202067684890 := by decide
theorem cert_e2405974662682 : check e2405974662682 [[]] .width = true := by decide
def e2405974666778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974666778 : Closed e2405974666778 ∧ code e2405974666778 = 11202067688986 := by decide
theorem cert_e2405974666778 : check e2405974666778 [[]] .width = true := by decide
def e2405974868166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405974868166 : Closed e2405974868166 ∧ code e2405974868166 = 11202067890374 := by decide
theorem cert_e2405974868166 : check e2405974868166 [[]] .width = true := by decide
def e2405974868694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405974868694 : Closed e2405974868694 ∧ code e2405974868694 = 11202067890902 := by decide
theorem cert_e2405974868694 : check e2405974868694 [[]] .width = true := by decide
def e2405974868698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405974868698 : Closed e2405974868698 ∧ code e2405974868698 = 11202067890906 := by decide
theorem cert_e2405974868698 : check e2405974868698 [[]] .width = true := by decide
def e2405974868714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405974868714 : Closed e2405974868714 ∧ code e2405974868714 = 11202067890922 := by decide
theorem cert_e2405974868714 : check e2405974868714 [[]] .width = true := by decide
def e2405974868790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405974868790 : Closed e2405974868790 ∧ code e2405974868790 = 11202067890998 := by decide
theorem cert_e2405974868790 : check e2405974868790 [[]] .width = true := by decide
def e2405974868794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405974868794 : Closed e2405974868794 ∧ code e2405974868794 = 11202067891002 := by decide
theorem cert_e2405974868794 : check e2405974868794 [[]] .width = true := by decide
def e2405974868878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405974868878 : Closed e2405974868878 ∧ code e2405974868878 = 11202067891086 := by decide
theorem cert_e2405974868878 : check e2405974868878 [[]] .width = true := by decide
def e2405974868890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405974868890 : Closed e2405974868890 ∧ code e2405974868890 = 11202067891098 := by decide
theorem cert_e2405974868890 : check e2405974868890 [[]] .width = true := by decide
def e2405974870810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405974870810 : Closed e2405974870810 ∧ code e2405974870810 = 11202067893018 := by decide
theorem cert_e2405974870810 : check e2405974870810 [[]] .width = true := by decide
def e2405974870854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405974870854 : Closed e2405974870854 ∧ code e2405974870854 = 11202067893062 := by decide
theorem cert_e2405974870854 : check e2405974870854 [[]] .width = true := by decide
def e2405974871094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405974871094 : Closed e2405974871094 ∧ code e2405974871094 = 11202067893302 := by decide
theorem cert_e2405974871094 : check e2405974871094 [[]] .width = true := by decide
def e2405974871098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405974871098 : Closed e2405974871098 ∧ code e2405974871098 = 11202067893306 := by decide
theorem cert_e2405974871098 : check e2405974871098 [[]] .width = true := by decide
def e2405974871238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405974871238 : Closed e2405974871238 ∧ code e2405974871238 = 11202067893446 := by decide
theorem cert_e2405974871238 : check e2405974871238 [[]] .width = true := by decide
def e2405975152666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975152666 : Closed e2405975152666 ∧ code e2405975152666 = 11202068174874 := by decide
theorem cert_e2405975152666 : check e2405975152666 [[]] .width = true := by decide
def e2405975156762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975156762 : Closed e2405975156762 ∧ code e2405975156762 = 11202068178970 := by decide
theorem cert_e2405975156762 : check e2405975156762 [[]] .width = true := by decide
def e2405975158298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975158298 : Closed e2405975158298 ∧ code e2405975158298 = 11202068180506 := by decide
theorem cert_e2405975158298 : check e2405975158298 [[]] .width = true := by decide
def e2405975160346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975160346 : Closed e2405975160346 ∧ code e2405975160346 = 11202068182554 := by decide
theorem cert_e2405975160346 : check e2405975160346 [[]] .width = true := by decide
def e2405975173146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975173146 : Closed e2405975173146 ∧ code e2405975173146 = 11202068195354 := by decide
theorem cert_e2405975173146 : check e2405975173146 [[]] .width = true := by decide
def e2405975174682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975174682 : Closed e2405975174682 ∧ code e2405975174682 = 11202068196890 := by decide
theorem cert_e2405975174682 : check e2405975174682 [[]] .width = true := by decide
def e2405975177754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975177754 : Closed e2405975177754 ∧ code e2405975177754 = 11202068199962 := by decide
theorem cert_e2405975177754 : check e2405975177754 [[]] .width = true := by decide
def e2405975184922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975184922 : Closed e2405975184922 ∧ code e2405975184922 = 11202068207130 := by decide
theorem cert_e2405975184922 : check e2405975184922 [[]] .width = true := by decide
def e2405975185946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975185946 : Closed e2405975185946 ∧ code e2405975185946 = 11202068208154 := by decide
theorem cert_e2405975185946 : check e2405975185946 [[]] .width = true := by decide
def e2405975224518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405975224518 : Closed e2405975224518 ∧ code e2405975224518 = 11202068246726 := by decide
theorem cert_e2405975224518 : check e2405975224518 [[]] .width = true := by decide
def e2405975250970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975250970 : Closed e2405975250970 ∧ code e2405975250970 = 11202068273178 := by decide
theorem cert_e2405975250970 : check e2405975250970 [[]] .width = true := by decide
def e2405975255066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975255066 : Closed e2405975255066 ∧ code e2405975255066 = 11202068277274 := by decide
theorem cert_e2405975255066 : check e2405975255066 [[]] .width = true := by decide
def e2405975256602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975256602 : Closed e2405975256602 ∧ code e2405975256602 = 11202068278810 := by decide
theorem cert_e2405975256602 : check e2405975256602 [[]] .width = true := by decide
def e2405975258650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975258650 : Closed e2405975258650 ∧ code e2405975258650 = 11202068280858 := by decide
theorem cert_e2405975258650 : check e2405975258650 [[]] .width = true := by decide
def e2405975293978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405975293978 : Closed e2405975293978 ∧ code e2405975293978 = 11202068316186 := by decide
theorem cert_e2405975293978 : check e2405975293978 [[]] .width = true := by decide
def e2405975294070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405975294070 : Closed e2405975294070 ∧ code e2405975294070 = 11202068316278 := by decide
theorem cert_e2405975294070 : check e2405975294070 [[]] .width = true := by decide
def e2405975294314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405975294314 : Closed e2405975294314 ∧ code e2405975294314 = 11202068316522 := by decide
theorem cert_e2405975294314 : check e2405975294314 [[]] .width = true := by decide
def e2405975294362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405975294362 : Closed e2405975294362 ∧ code e2405975294362 = 11202068316570 := by decide
theorem cert_e2405975294362 : check e2405975294362 [[]] .width = true := by decide
def e2405975295370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405975295370 : Closed e2405975295370 ∧ code e2405975295370 = 11202068317578 := by decide
theorem cert_e2405975295370 : check e2405975295370 [[]] .width = true := by decide
def e2405975295394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405975295394 : Closed e2405975295394 ∧ code e2405975295394 = 11202068317602 := by decide
theorem cert_e2405975295394 : check e2405975295394 [[]] .width = true := by decide
def e2405975295502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405975295502 : Closed e2405975295502 ∧ code e2405975295502 = 11202068317710 := by decide
theorem cert_e2405975295502 : check e2405975295502 [[]] .width = true := by decide
def e2405975295514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405975295514 : Closed e2405975295514 ∧ code e2405975295514 = 11202068317722 := by decide
theorem cert_e2405975295514 : check e2405975295514 [[]] .width = true := by decide
def e2405975295586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405975295586 : Closed e2405975295586 ∧ code e2405975295586 = 11202068317794 := by decide
theorem cert_e2405975295586 : check e2405975295586 [[]] .width = true := by decide
def e2405975328794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975328794 : Closed e2405975328794 ∧ code e2405975328794 = 11202068351002 := by decide
theorem cert_e2405975328794 : check e2405975328794 [[]] .width = true := by decide
def e2405975334938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405975334938 : Closed e2405975334938 ∧ code e2405975334938 = 11202068357146 := by decide
theorem cert_e2405975334938 : check e2405975334938 [[]] .width = true := by decide
def e2405975335030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405975335030 : Closed e2405975335030 ∧ code e2405975335030 = 11202068357238 := by decide
theorem cert_e2405975335030 : check e2405975335030 [[]] .width = true := by decide
def e2405975335274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405975335274 : Closed e2405975335274 ∧ code e2405975335274 = 11202068357482 := by decide
theorem cert_e2405975335274 : check e2405975335274 [[]] .width = true := by decide
def e2405975335322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405975335322 : Closed e2405975335322 ∧ code e2405975335322 = 11202068357530 := by decide
theorem cert_e2405975335322 : check e2405975335322 [[]] .width = true := by decide
def e2405975339206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405975339206 : Closed e2405975339206 ∧ code e2405975339206 = 11202068361414 := by decide
theorem cert_e2405975339206 : check e2405975339206 [[]] .width = true := by decide
def e2405975341082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975341082 : Closed e2405975341082 ∧ code e2405975341082 = 11202068363290 := by decide
theorem cert_e2405975341082 : check e2405975341082 [[]] .width = true := by decide
def e2405975353370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405975353370 : Closed e2405975353370 ∧ code e2405975353370 = 11202068375578 := by decide
theorem cert_e2405975353370 : check e2405975353370 [[]] .width = true := by decide
def e2405975354906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975354906 : Closed e2405975354906 ∧ code e2405975354906 = 11202068377114 := by decide
theorem cert_e2405975354906 : check e2405975354906 [[]] .width = true := by decide
def e2405975357978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975357978 : Closed e2405975357978 ∧ code e2405975357978 = 11202068380186 := by decide
theorem cert_e2405975357978 : check e2405975357978 [[]] .width = true := by decide
def e2405975359514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405975359514 : Closed e2405975359514 ∧ code e2405975359514 = 11202068381722 := by decide
theorem cert_e2405975359514 : check e2405975359514 [[]] .width = true := by decide
def e2405975359606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405975359606 : Closed e2405975359606 ∧ code e2405975359606 = 11202068381814 := by decide
theorem cert_e2405975359606 : check e2405975359606 [[]] .width = true := by decide
def e2405975359850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405975359850 : Closed e2405975359850 ∧ code e2405975359850 = 11202068382058 := by decide
theorem cert_e2405975359850 : check e2405975359850 [[]] .width = true := by decide
def e2405975359898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405975359898 : Closed e2405975359898 ∧ code e2405975359898 = 11202068382106 := by decide
theorem cert_e2405975359898 : check e2405975359898 [[]] .width = true := by decide
def e2405975360906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405975360906 : Closed e2405975360906 ∧ code e2405975360906 = 11202068383114 := by decide
theorem cert_e2405975360906 : check e2405975360906 [[]] .width = true := by decide
def e2405975360930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405975360930 : Closed e2405975360930 ∧ code e2405975360930 = 11202068383138 := by decide
theorem cert_e2405975360930 : check e2405975360930 [[]] .width = true := by decide
def e2405975361038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405975361038 : Closed e2405975361038 ∧ code e2405975361038 = 11202068383246 := by decide
theorem cert_e2405975361038 : check e2405975361038 [[]] .width = true := by decide
def e2405975361050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405975361050 : Closed e2405975361050 ∧ code e2405975361050 = 11202068383258 := by decide
theorem cert_e2405975361050 : check e2405975361050 [[]] .width = true := by decide
def e2405975361122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405975361122 : Closed e2405975361122 ∧ code e2405975361122 = 11202068383330 := by decide
theorem cert_e2405975361122 : check e2405975361122 [[]] .width = true := by decide
def e2405975376070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405975376070 : Closed e2405975376070 ∧ code e2405975376070 = 11202068398278 := by decide
theorem cert_e2405975376070 : check e2405975376070 [[]] .width = true := by decide
def e2405975384090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405975384090 : Closed e2405975384090 ∧ code e2405975384090 = 11202068406298 := by decide
theorem cert_e2405975384090 : check e2405975384090 [[]] .width = true := by decide
def e2405975384182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405975384182 : Closed e2405975384182 ∧ code e2405975384182 = 11202068406390 := by decide
theorem cert_e2405975384182 : check e2405975384182 [[]] .width = true := by decide
def e2405975384426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405975384426 : Closed e2405975384426 ∧ code e2405975384426 = 11202068406634 := by decide
theorem cert_e2405975384426 : check e2405975384426 [[]] .width = true := by decide
def e2405975384474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405975384474 : Closed e2405975384474 ∧ code e2405975384474 = 11202068406682 := by decide
theorem cert_e2405975384474 : check e2405975384474 [[]] .width = true := by decide
def e2405975406106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975406106 : Closed e2405975406106 ∧ code e2405975406106 = 11202068428314 := by decide
theorem cert_e2405975406106 : check e2405975406106 [[]] .width = true := by decide
def e2405975407130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405975407130 : Closed e2405975407130 ∧ code e2405975407130 = 11202068429338 := by decide
theorem cert_e2405975407130 : check e2405975407130 [[]] .width = true := by decide
def e2405975416858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405975416858 : Closed e2405975416858 ∧ code e2405975416858 = 11202068439066 := by decide
theorem cert_e2405975416858 : check e2405975416858 [[]] .width = true := by decide
def e2405975416950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405975416950 : Closed e2405975416950 ∧ code e2405975416950 = 11202068439158 := by decide
theorem cert_e2405975416950 : check e2405975416950 [[]] .width = true := by decide
def e2405975417194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405975417194 : Closed e2405975417194 ∧ code e2405975417194 = 11202068439402 := by decide
theorem cert_e2405975417194 : check e2405975417194 [[]] .width = true := by decide
def e2405975417242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405975417242 : Closed e2405975417242 ∧ code e2405975417242 = 11202068439450 := by decide
theorem cert_e2405975417242 : check e2405975417242 [[]] .width = true := by decide
def e2405975982106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2405975982106 : Closed e2405975982106 ∧ code e2405975982106 = 11202069004314 := by decide
theorem cert_e2405975982106 : check e2405975982106 [[]] .width = true := by decide
def e2405975982198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2405975982198 : Closed e2405975982198 ∧ code e2405975982198 = 11202069004406 := by decide
theorem cert_e2405975982198 : check e2405975982198 [[]] .width = true := by decide
def e2405975982442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2405975982442 : Closed e2405975982442 ∧ code e2405975982442 = 11202069004650 := by decide
theorem cert_e2405975982442 : check e2405975982442 [[]] .width = true := by decide
def e2405975982490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2405975982490 : Closed e2405975982490 ∧ code e2405975982490 = 11202069004698 := by decide
theorem cert_e2405975982490 : check e2405975982490 [[]] .width = true := by decide
def e2405975982574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2405975982574 : Closed e2405975982574 ∧ code e2405975982574 = 11202069004782 := by decide
theorem cert_e2405975982574 : check e2405975982574 [[]] .width = true := by decide
def e2405975983498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2405975983498 : Closed e2405975983498 ∧ code e2405975983498 = 11202069005706 := by decide
theorem cert_e2405975983498 : check e2405975983498 [[]] .width = true := by decide
def e2405975983522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2405975983522 : Closed e2405975983522 ∧ code e2405975983522 = 11202069005730 := by decide
theorem cert_e2405975983522 : check e2405975983522 [[]] .width = true := by decide
def e2405975983534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2405975983534 : Closed e2405975983534 ∧ code e2405975983534 = 11202069005742 := by decide
theorem cert_e2405975983534 : check e2405975983534 [[]] .width = true := by decide
def e2405975983542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2405975983542 : Closed e2405975983542 ∧ code e2405975983542 = 11202069005750 := by decide
theorem cert_e2405975983542 : check e2405975983542 [[]] .width = true := by decide
def e2405975983546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2405975983546 : Closed e2405975983546 ∧ code e2405975983546 = 11202069005754 := by decide
theorem cert_e2405975983546 : check e2405975983546 [[]] .width = true := by decide
def e2405975983574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2405975983574 : Closed e2405975983574 ∧ code e2405975983574 = 11202069005782 := by decide
theorem cert_e2405975983574 : check e2405975983574 [[]] .width = true := by decide
def e2405975983578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2405975983578 : Closed e2405975983578 ∧ code e2405975983578 = 11202069005786 := by decide
theorem cert_e2405975983578 : check e2405975983578 [[]] .width = true := by decide
def e2405975983594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2405975983594 : Closed e2405975983594 ∧ code e2405975983594 = 11202069005802 := by decide
theorem cert_e2405975983594 : check e2405975983594 [[]] .width = true := by decide
def e2405975983630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2405975983630 : Closed e2405975983630 ∧ code e2405975983630 = 11202069005838 := by decide
theorem cert_e2405975983630 : check e2405975983630 [[]] .width = true := by decide
def e2405975983642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405975983642 : Closed e2405975983642 ∧ code e2405975983642 = 11202069005850 := by decide
theorem cert_e2405975983642 : check e2405975983642 [[]] .width = true := by decide
def e2405975983714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2405975983714 : Closed e2405975983714 ∧ code e2405975983714 = 11202069005922 := by decide
theorem cert_e2405975983714 : check e2405975983714 [[]] .width = true := by decide
def e2405975983726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2405975983726 : Closed e2405975983726 ∧ code e2405975983726 = 11202069005934 := by decide
theorem cert_e2405975983726 : check e2405975983726 [[]] .width = true := by decide
def e2405975983734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2405975983734 : Closed e2405975983734 ∧ code e2405975983734 = 11202069005942 := by decide
theorem cert_e2405975983734 : check e2405975983734 [[]] .width = true := by decide
def e2405975983738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2405975983738 : Closed e2405975983738 ∧ code e2405975983738 = 11202069005946 := by decide
theorem cert_e2405975983738 : check e2405975983738 [[]] .width = true := by decide
def e2405975983926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2405975983926 : Closed e2405975983926 ∧ code e2405975983926 = 11202069006134 := by decide
theorem cert_e2405975983926 : check e2405975983926 [[]] .width = true := by decide
def e2405975983930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2405975983930 : Closed e2405975983930 ∧ code e2405975983930 = 11202069006138 := by decide
theorem cert_e2405975983930 : check e2405975983930 [[]] .width = true := by decide
def e2405975984026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2405975984026 : Closed e2405975984026 ∧ code e2405975984026 = 11202069006234 := by decide
theorem cert_e2405975984026 : check e2405975984026 [[]] .width = true := by decide
def e2405975987626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2405975987626 : Closed e2405975987626 ∧ code e2405975987626 = 11202069009834 := by decide
theorem cert_e2405975987626 : check e2405975987626 [[]] .width = true := by decide
def e2405975987722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2405975987722 : Closed e2405975987722 ∧ code e2405975987722 = 11202069009930 := by decide
theorem cert_e2405975987722 : check e2405975987722 [[]] .width = true := by decide
def e2405975987766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2405975987766 : Closed e2405975987766 ∧ code e2405975987766 = 11202069009974 := by decide
theorem cert_e2405975987766 : check e2405975987766 [[]] .width = true := by decide
def e2405975987770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2405975987770 : Closed e2405975987770 ∧ code e2405975987770 = 11202069009978 := by decide
theorem cert_e2405975987770 : check e2405975987770 [[]] .width = true := by decide
def e2405975987818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2405975987818 : Closed e2405975987818 ∧ code e2405975987818 = 11202069010026 := by decide
theorem cert_e2405975987818 : check e2405975987818 [[]] .width = true := by decide
def e2405975987842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2405975987842 : Closed e2405975987842 ∧ code e2405975987842 = 11202069010050 := by decide
theorem cert_e2405975987842 : check e2405975987842 [[]] .width = true := by decide
def e2405975987854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2405975987854 : Closed e2405975987854 ∧ code e2405975987854 = 11202069010062 := by decide
theorem cert_e2405975987854 : check e2405975987854 [[]] .width = true := by decide
def e2405975987866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2405975987866 : Closed e2405975987866 ∧ code e2405975987866 = 11202069010074 := by decide
theorem cert_e2405975987866 : check e2405975987866 [[]] .width = true := by decide
def e2405975987910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2405975987910 : Closed e2405975987910 ∧ code e2405975987910 = 11202069010118 := by decide
theorem cert_e2405975987910 : check e2405975987910 [[]] .width = true := by decide
def e2405975987990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2405975987990 : Closed e2405975987990 ∧ code e2405975987990 = 11202069010198 := by decide
theorem cert_e2405975987990 : check e2405975987990 [[]] .width = true := by decide
def e2405975987994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2405975987994 : Closed e2405975987994 ∧ code e2405975987994 = 11202069010202 := by decide
theorem cert_e2405975987994 : check e2405975987994 [[]] .width = true := by decide
def e2405975988038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2405975988038 : Closed e2405975988038 ∧ code e2405975988038 = 11202069010246 := by decide
theorem cert_e2405975988038 : check e2405975988038 [[]] .width = true := by decide
def e2405975988066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2405975988066 : Closed e2405975988066 ∧ code e2405975988066 = 11202069010274 := by decide
theorem cert_e2405975988066 : check e2405975988066 [[]] .width = true := by decide
def e2405975988250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405975988250 : Closed e2405975988250 ∧ code e2405975988250 = 11202069010458 := by decide
theorem cert_e2405975988250 : check e2405975988250 [[]] .width = true := by decide
def e2405975988342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405975988342 : Closed e2405975988342 ∧ code e2405975988342 = 11202069010550 := by decide
theorem cert_e2405975988342 : check e2405975988342 [[]] .width = true := by decide
def e2405975988586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405975988586 : Closed e2405975988586 ∧ code e2405975988586 = 11202069010794 := by decide
theorem cert_e2405975988586 : check e2405975988586 [[]] .width = true := by decide
def e2405975988610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2405975988610 : Closed e2405975988610 ∧ code e2405975988610 = 11202069010818 := by decide
theorem cert_e2405975988610 : check e2405975988610 [[]] .width = true := by decide
def e2405975988622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405975988622 : Closed e2405975988622 ∧ code e2405975988622 = 11202069010830 := by decide
theorem cert_e2405975988622 : check e2405975988622 [[]] .width = true := by decide
def e2405975988634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405975988634 : Closed e2405975988634 ∧ code e2405975988634 = 11202069010842 := by decide
theorem cert_e2405975988634 : check e2405975988634 [[]] .width = true := by decide
def e2405975988678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405975988678 : Closed e2405975988678 ∧ code e2405975988678 = 11202069010886 := by decide
theorem cert_e2405975988678 : check e2405975988678 [[]] .width = true := by decide
def e2405975989278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2405975989278 : Closed e2405975989278 ∧ code e2405975989278 = 11202069011486 := by decide
theorem cert_e2405975989278 : check e2405975989278 [[]] .width = true := by decide
def e2405975989446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405975989446 : Closed e2405975989446 ∧ code e2405975989446 = 11202069011654 := by decide
theorem cert_e2405975989446 : check e2405975989446 [[]] .width = true := by decide
def e2405975989474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2405975989474 : Closed e2405975989474 ∧ code e2405975989474 = 11202069011682 := by decide
theorem cert_e2405975989474 : check e2405975989474 [[]] .width = true := by decide
def e2405976004138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2405976004138 : Closed e2405976004138 ∧ code e2405976004138 = 11202069026346 := by decide
theorem cert_e2405976004138 : check e2405976004138 [[]] .width = true := by decide
def e2405976004234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2405976004234 : Closed e2405976004234 ∧ code e2405976004234 = 11202069026442 := by decide
theorem cert_e2405976004234 : check e2405976004234 [[]] .width = true := by decide
def e2405976004258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405976004258 : Closed e2405976004258 ∧ code e2405976004258 = 11202069026466 := by decide
theorem cert_e2405976004258 : check e2405976004258 [[]] .width = true := by decide
def e2405976004618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2405976004618 : Closed e2405976004618 ∧ code e2405976004618 = 11202069026826 := by decide
theorem cert_e2405976004618 : check e2405976004618 [[]] .width = true := by decide
def e2405976004666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2405976004666 : Closed e2405976004666 ∧ code e2405976004666 = 11202069026874 := by decide
theorem cert_e2405976004666 : check e2405976004666 [[]] .width = true := by decide
def e2405976004714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2405976004714 : Closed e2405976004714 ∧ code e2405976004714 = 11202069026922 := by decide
theorem cert_e2405976004714 : check e2405976004714 [[]] .width = true := by decide
def e2405976004762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2405976004762 : Closed e2405976004762 ∧ code e2405976004762 = 11202069026970 := by decide
theorem cert_e2405976004762 : check e2405976004762 [[]] .width = true := by decide
def e2405976004806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2405976004806 : Closed e2405976004806 ∧ code e2405976004806 = 11202069027014 := by decide
theorem cert_e2405976004806 : check e2405976004806 [[]] .width = true := by decide
def e2405976005002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2405976005002 : Closed e2405976005002 ∧ code e2405976005002 = 11202069027210 := by decide
theorem cert_e2405976005002 : check e2405976005002 [[]] .width = true := by decide
def e2405976005026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2405976005026 : Closed e2405976005026 ∧ code e2405976005026 = 11202069027234 := by decide
theorem cert_e2405976005026 : check e2405976005026 [[]] .width = true := by decide
def e2405976005122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2405976005122 : Closed e2405976005122 ∧ code e2405976005122 = 11202069027330 := by decide
theorem cert_e2405976005122 : check e2405976005122 [[]] .width = true := by decide
def e2405976005134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2405976005134 : Closed e2405976005134 ∧ code e2405976005134 = 11202069027342 := by decide
theorem cert_e2405976005134 : check e2405976005134 [[]] .width = true := by decide
def e2405976005146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405976005146 : Closed e2405976005146 ∧ code e2405976005146 = 11202069027354 := by decide
theorem cert_e2405976005146 : check e2405976005146 [[]] .width = true := by decide
def e2405976005218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405976005218 : Closed e2405976005218 ∧ code e2405976005218 = 11202069027426 := by decide
theorem cert_e2405976005218 : check e2405976005218 [[]] .width = true := by decide
def e2405976006682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405976006682 : Closed e2405976006682 ∧ code e2405976006682 = 11202069028890 := by decide
theorem cert_e2405976006682 : check e2405976006682 [[]] .width = true := by decide
def e2405976006766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2405976006766 : Closed e2405976006766 ∧ code e2405976006766 = 11202069028974 := by decide
theorem cert_e2405976006766 : check e2405976006766 [[]] .width = true := by decide
def e2405976006774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405976006774 : Closed e2405976006774 ∧ code e2405976006774 = 11202069028982 := by decide
theorem cert_e2405976006774 : check e2405976006774 [[]] .width = true := by decide
def e2405976006778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2405976006778 : Closed e2405976006778 ∧ code e2405976006778 = 11202069028986 := by decide
theorem cert_e2405976006778 : check e2405976006778 [[]] .width = true := by decide
def e2405976007018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405976007018 : Closed e2405976007018 ∧ code e2405976007018 = 11202069029226 := by decide
theorem cert_e2405976007018 : check e2405976007018 [[]] .width = true := by decide
def e2405976007054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405976007054 : Closed e2405976007054 ∧ code e2405976007054 = 11202069029262 := by decide
theorem cert_e2405976007054 : check e2405976007054 [[]] .width = true := by decide
def e2405976007066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405976007066 : Closed e2405976007066 ∧ code e2405976007066 = 11202069029274 := by decide
theorem cert_e2405976007066 : check e2405976007066 [[]] .width = true := by decide
def e2405976007110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405976007110 : Closed e2405976007110 ∧ code e2405976007110 = 11202069029318 := by decide
theorem cert_e2405976007110 : check e2405976007110 [[]] .width = true := by decide
def e2405976008074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2405976008074 : Closed e2405976008074 ∧ code e2405976008074 = 11202069030282 := by decide
theorem cert_e2405976008074 : check e2405976008074 [[]] .width = true := by decide
def e2405976008098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2405976008098 : Closed e2405976008098 ∧ code e2405976008098 = 11202069030306 := by decide
theorem cert_e2405976008098 : check e2405976008098 [[]] .width = true := by decide
def e2405976008194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2405976008194 : Closed e2405976008194 ∧ code e2405976008194 = 11202069030402 := by decide
theorem cert_e2405976008194 : check e2405976008194 [[]] .width = true := by decide
def e2405976008206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2405976008206 : Closed e2405976008206 ∧ code e2405976008206 = 11202069030414 := by decide
theorem cert_e2405976008206 : check e2405976008206 [[]] .width = true := by decide
def e2405976008218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405976008218 : Closed e2405976008218 ∧ code e2405976008218 = 11202069030426 := by decide
theorem cert_e2405976008218 : check e2405976008218 [[]] .width = true := by decide
def e2405976008290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2405976008290 : Closed e2405976008290 ∧ code e2405976008290 = 11202069030498 := by decide
theorem cert_e2405976008290 : check e2405976008290 [[]] .width = true := by decide
def e2405976054274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2405976054274 : Closed e2405976054274 ∧ code e2405976054274 = 11202069076482 := by decide
theorem cert_e2405976054274 : check e2405976054274 [[]] .width = true := by decide
def e2405976054298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405976054298 : Closed e2405976054298 ∧ code e2405976054298 = 11202069076506 := by decide
theorem cert_e2405976054298 : check e2405976054298 [[]] .width = true := by decide
def e2405976563738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405976563738 : Closed e2405976563738 ∧ code e2405976563738 = 11202069585946 := by decide
theorem cert_e2405976563738 : check e2405976563738 [[]] .width = true := by decide
def e2405976563830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405976563830 : Closed e2405976563830 ∧ code e2405976563830 = 11202069586038 := by decide
private def t_e2405976563830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405976563830 : ¬ IsSelfInterpreter e2405976563830 :=
  wSource (t := t_e2405976563830) (replay_sound (ps := []) (t := e2405976563830) (by decide)) (by decide)
def e2405976564074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405976564074 : Closed e2405976564074 ∧ code e2405976564074 = 11202069586282 := by decide
private def t_e2405976564074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405976564074 : ¬ IsSelfInterpreter e2405976564074 :=
  wSource (t := t_e2405976564074) (replay_sound (ps := []) (t := e2405976564074) (by decide)) (by decide)
def e2405976564122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405976564122 : Closed e2405976564122 ∧ code e2405976564122 = 11202069586330 := by decide
private def t_e2405976564122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405976564122 : ¬ IsSelfInterpreter e2405976564122 :=
  wSource (t := t_e2405976564122) (replay_sound (ps := []) (t := e2405976564122) (by decide)) (by decide)
def e2405976617158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405976617158 : Closed e2405976617158 ∧ code e2405976617158 = 11202069639366 := by decide
theorem cert_e2405976617158 : check e2405976617158 [[]] .width = true := by decide
def e2405976625350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405976625350 : Closed e2405976625350 ∧ code e2405976625350 = 11202069647558 := by decide
theorem cert_e2405976625350 : check e2405976625350 [[]] .width = true := by decide
def e2405976627226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405976627226 : Closed e2405976627226 ∧ code e2405976627226 = 11202069649434 := by decide
theorem cert_e2405976627226 : check e2405976627226 [[]] .width = true := by decide
def e2405976628762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405976628762 : Closed e2405976628762 ∧ code e2405976628762 = 11202069650970 := by decide
private def t_e2405976628762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405976628762 : ¬ IsSelfInterpreter e2405976628762 :=
  wSource (t := t_e2405976628762) (replay_sound (ps := []) (t := e2405976628762) (by decide)) (by decide)
def e2405976634906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405976634906 : Closed e2405976634906 ∧ code e2405976634906 = 11202069657114 := by decide
private def t_e2405976634906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405976634906 : ¬ IsSelfInterpreter e2405976634906 :=
  wSource (t := t_e2405976634906) (replay_sound (ps := []) (t := e2405976634906) (by decide)) (by decide)
def e2405976703174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405976703174 : Closed e2405976703174 ∧ code e2405976703174 = 11202069725382 := by decide
theorem cert_e2405976703174 : check e2405976703174 [[]] .width = true := by decide
def e2405976703702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405976703702 : Closed e2405976703702 ∧ code e2405976703702 = 11202069725910 := by decide
theorem cert_e2405976703702 : check e2405976703702 [[]] .width = true := by decide
def e2405976703706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405976703706 : Closed e2405976703706 ∧ code e2405976703706 = 11202069725914 := by decide
theorem cert_e2405976703706 : check e2405976703706 [[]] .width = true := by decide
def e2405976703722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405976703722 : Closed e2405976703722 ∧ code e2405976703722 = 11202069725930 := by decide
theorem cert_e2405976703722 : check e2405976703722 [[]] .width = true := by decide
def e2405976703798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405976703798 : Closed e2405976703798 ∧ code e2405976703798 = 11202069726006 := by decide
theorem cert_e2405976703798 : check e2405976703798 [[]] .width = true := by decide
def e2405976703802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405976703802 : Closed e2405976703802 ∧ code e2405976703802 = 11202069726010 := by decide
theorem cert_e2405976703802 : check e2405976703802 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405976563830
#print axioms Blc.Floor43.cert_e2405976564074
#print axioms Blc.Floor43.cert_e2405976564122
#print axioms Blc.Floor43.cert_e2405976628762
#print axioms Blc.Floor43.cert_e2405976634906
