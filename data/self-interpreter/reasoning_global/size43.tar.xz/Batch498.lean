import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408668650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422408668650 : Closed e2422408668650 ∧ code e2422408668650 = 11218501690858 := by decide
theorem cert_e2422408668650 : check e2422408668650 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422408668674 : Closed e2422408668674 ∧ code e2422408668674 = 11218501690882 := by decide
theorem cert_e2422408668674 : check e2422408668674 [[],[]] .chain = true := by decide
def e2422408668686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422408668686 : Closed e2422408668686 ∧ code e2422408668686 = 11218501690894 := by decide
theorem cert_e2422408668686 : check e2422408668686 [[],[]] .chain = true := by decide
def e2422408668698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408668698 : Closed e2422408668698 ∧ code e2422408668698 = 11218501690906 := by decide
theorem cert_e2422408668698 : check e2422408668698 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422408668770 : Closed e2422408668770 ∧ code e2422408668770 = 11218501690978 := by decide
theorem cert_e2422408668770 : check e2422408668770 [[],[]] .chain = true := by decide
def e2422408668782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408668782 : Closed e2422408668782 ∧ code e2422408668782 = 11218501690990 := by decide
theorem cert_e2422408668782 : check e2422408668782 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422408668790 : Closed e2422408668790 ∧ code e2422408668790 = 11218501690998 := by decide
theorem cert_e2422408668790 : check e2422408668790 [[],[]] .chain = true := by decide
def e2422408668794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408668794 : Closed e2422408668794 ∧ code e2422408668794 = 11218501691002 := by decide
theorem cert_e2422408668794 : check e2422408668794 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422408668934 : Closed e2422408668934 ∧ code e2422408668934 = 11218501691142 := by decide
theorem cert_e2422408668934 : check e2422408668934 [[],[]] .chain = true := by decide
def e2422408668958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422408668958 : Closed e2422408668958 ∧ code e2422408668958 = 11218501691166 := by decide
theorem cert_e2422408668958 : check e2422408668958 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408668982 : Closed e2422408668982 ∧ code e2422408668982 = 11218501691190 := by decide
theorem cert_e2422408668982 : check e2422408668982 [[],[]] .chain = true := by decide
def e2422408668986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408668986 : Closed e2422408668986 ∧ code e2422408668986 = 11218501691194 := by decide
theorem cert_e2422408668986 : check e2422408668986 [[],[]] .chain = true := by decide
def e2422408669058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422408669058 : Closed e2422408669058 ∧ code e2422408669058 = 11218501691266 := by decide
theorem cert_e2422408669058 : check e2422408669058 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408669070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422408669070 : Closed e2422408669070 ∧ code e2422408669070 = 11218501691278 := by decide
theorem cert_e2422408669070 : check e2422408669070 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408669082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422408669082 : Closed e2422408669082 ∧ code e2422408669082 = 11218501691290 := by decide
theorem cert_e2422408669082 : check e2422408669082 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408675542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))) (.var 1))))))
theorem wire_e2422408675542 : Closed e2422408675542 ∧ code e2422408675542 = 11218501697750 := by decide
theorem cert_e2422408675542 : check e2422408675542 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422408675638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408675638 : Closed e2422408675638 ∧ code e2422408675638 = 11218501697846 := by decide
theorem cert_e2422408675638 : check e2422408675638 [[],[]] .chain = true := by decide
def e2422408675642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408675642 : Closed e2422408675642 ∧ code e2422408675642 = 11218501697850 := by decide
theorem cert_e2422408675642 : check e2422408675642 [[],[]] .chain = true := by decide
def e2422408675830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 4)))))) (.var 1))))))
theorem wire_e2422408675830 : Closed e2422408675830 ∧ code e2422408675830 = 11218501698038 := by decide
theorem cert_e2422408675830 : check e2422408675830 [[],[]] .chain = true := by decide
def e2422408676214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 2)))))) (.var 1))))))
theorem wire_e2422408676214 : Closed e2422408676214 ∧ code e2422408676214 = 11218501698422 := by decide
theorem cert_e2422408676214 : check e2422408676214 [[],[]] .chain = true := by decide
def e2422408676218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 3)))))) (.var 0))))))
theorem wire_e2422408676218 : Closed e2422408676218 ∧ code e2422408676218 = 11218501698426 := by decide
theorem cert_e2422408676218 : check e2422408676218 [[],[]] .chain = true := by decide
def e2422408676278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 1) (.var 1)))))) (.var 1))))))
theorem wire_e2422408676278 : Closed e2422408676278 ∧ code e2422408676278 = 11218501698486 := by decide
private def t_e2422408676278 : Term := (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.var 1)))) (.var 1))
theorem cert_e2422408676278 : ¬ IsSelfInterpreter e2422408676278 :=
  wIdentity (t := t_e2422408676278) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]]) (t := (inv e2422408676278)) (by decide)) (by decide)
def e2422408676310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 0)))))) (.var 1))))))
theorem wire_e2422408676310 : Closed e2422408676310 ∧ code e2422408676310 = 11218501698518 := by decide
theorem cert_e2422408676310 : check e2422408676310 [[],[]] .chain = true := by decide
def e2422408676330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 0)))))) (.var 0))))))
theorem wire_e2422408676330 : Closed e2422408676330 ∧ code e2422408676330 = 11218501698538 := by decide
theorem cert_e2422408676330 : check e2422408676330 [[],[]] .chain = true := by decide
def e2422408676590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408676590 : Closed e2422408676590 ∧ code e2422408676590 = 11218501698798 := by decide
theorem cert_e2422408676590 : check e2422408676590 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408676598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408676598 : Closed e2422408676598 ∧ code e2422408676598 = 11218501698806 := by decide
theorem cert_e2422408676598 : check e2422408676598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408676982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408676982 : Closed e2422408676982 ∧ code e2422408676982 = 11218501699190 := by decide
theorem cert_e2422408676982 : check e2422408676982 [[],[]] .chain = true := by decide
def e2422408677174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408677174 : Closed e2422408677174 ∧ code e2422408677174 = 11218501699382 := by decide
theorem cert_e2422408677174 : check e2422408677174 [[],[]] .chain = true := by decide
def e2422408677178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408677178 : Closed e2422408677178 ∧ code e2422408677178 = 11218501699386 := by decide
theorem cert_e2422408677178 : check e2422408677178 [[],[]] .chain = true := by decide
def e2422408677262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.lam (.var 2)))))))
theorem wire_e2422408677262 : Closed e2422408677262 ∧ code e2422408677262 = 11218501699470 := by decide
theorem cert_e2422408677262 : check e2422408677262 [[],[]] .chain = true := by decide
def e2422408677274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408677274 : Closed e2422408677274 ∧ code e2422408677274 = 11218501699482 := by decide
theorem cert_e2422408677274 : check e2422408677274 [[],[]] .chain = true := by decide
def e2422408678230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))) (.var 1))))))
theorem wire_e2422408678230 : Closed e2422408678230 ∧ code e2422408678230 = 11218501700438 := by decide
private def t_e2422408678230 : Term := (.app (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.var 1)))) (.var 1))
theorem cert_e2422408678230 : ¬ IsSelfInterpreter e2422408678230 :=
  wIdentity (t := t_e2422408678230) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]]) (t := (inv e2422408678230)) (by decide)) (by decide)
def e2422408678518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 2)))))) (.var 1))))))
theorem wire_e2422408678518 : Closed e2422408678518 ∧ code e2422408678518 = 11218501700726 := by decide
theorem cert_e2422408678518 : check e2422408678518 [[],[]] .chain = true := by decide
def e2422408678522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 3)))))) (.var 0))))))
theorem wire_e2422408678522 : Closed e2422408678522 ∧ code e2422408678522 = 11218501700730 := by decide
theorem cert_e2422408678522 : check e2422408678522 [[],[]] .chain = true := by decide
def e2422408678614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e2422408678614 : Closed e2422408678614 ∧ code e2422408678614 = 11218501700822 := by decide
private def t_e2422408678614 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.var 1)))) (.var 1))
theorem cert_e2422408678614 : ¬ IsSelfInterpreter e2422408678614 :=
  wIdentity (t := t_e2422408678614) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]]) (t := (inv e2422408678614)) (by decide)) (by decide)
def e2422408678710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408678710 : Closed e2422408678710 ∧ code e2422408678710 = 11218501700918 := by decide
private def t_e2422408678710 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3))))))) (.lam (.lam (.var 1))))) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))))) (.var 1)))
theorem cert_e2422408678710 : ¬ IsSelfInterpreter e2422408678710 :=
  wIdentity (t := t_e2422408678710) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]]) (t := (inv e2422408678710)) (by decide)) (by decide)
def e2422408678714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408678714 : Closed e2422408678714 ∧ code e2422408678714 = 11218501700922 := by decide
private def t_e2422408678714 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.app (.lam (.lam (.var 1))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3))))))))) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))))
theorem cert_e2422408678714 : ¬ IsSelfInterpreter e2422408678714 :=
  wIdentity (t := t_e2422408678714) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]]) (t := (inv e2422408678714)) (by decide)) (by decide)
def e2422408678798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.lam (.var 2)))))))
theorem wire_e2422408678798 : Closed e2422408678798 ∧ code e2422408678798 = 11218501701006 := by decide
theorem cert_e2422408678798 : check e2422408678798 [[],[]] .chain = true := by decide
def e2422408678854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.lam (.var 1)))))))
theorem wire_e2422408678854 : Closed e2422408678854 ∧ code e2422408678854 = 11218501701062 := by decide
theorem cert_e2422408678854 : check e2422408678854 [[],[]] .chain = true := by decide
def e2422408678966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422408678966 : Closed e2422408678966 ∧ code e2422408678966 = 11218501701174 := by decide
theorem cert_e2422408678966 : check e2422408678966 [[],[]] .chain = true := by decide
def e2422408679054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422408679054 : Closed e2422408679054 ∧ code e2422408679054 = 11218501701262 := by decide
theorem cert_e2422408679054 : check e2422408679054 [[],[]] .chain = true := by decide
def e2422408679138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422408679138 : Closed e2422408679138 ∧ code e2422408679138 = 11218501701346 := by decide
theorem cert_e2422408679138 : check e2422408679138 [[],[]] .chain = true := by decide
def e2422408679150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e2422408679150 : Closed e2422408679150 ∧ code e2422408679150 = 11218501701358 := by decide
theorem cert_e2422408679150 : check e2422408679150 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408679158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e2422408679158 : Closed e2422408679158 ∧ code e2422408679158 = 11218501701366 := by decide
theorem cert_e2422408679158 : check e2422408679158 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422408679190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408679190 : Closed e2422408679190 ∧ code e2422408679190 = 11218501701398 := by decide
theorem cert_e2422408679190 : check e2422408679190 [[],[]] .chain = true := by decide
def e2422408679194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e2422408679194 : Closed e2422408679194 ∧ code e2422408679194 = 11218501701402 := by decide
theorem cert_e2422408679194 : check e2422408679194 [[],[]] .chain = true := by decide
def e2422408679238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e2422408679238 : Closed e2422408679238 ∧ code e2422408679238 = 11218501701446 := by decide
theorem cert_e2422408679238 : check e2422408679238 [[],[]] .chain = true := by decide
def e2422408679266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e2422408679266 : Closed e2422408679266 ∧ code e2422408679266 = 11218501701474 := by decide
theorem cert_e2422408679266 : check e2422408679266 [[],[]] .chain = true := by decide
def e2422408679278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e2422408679278 : Closed e2422408679278 ∧ code e2422408679278 = 11218501701486 := by decide
theorem cert_e2422408679278 : check e2422408679278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408679286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))) (.var 1))))))
theorem wire_e2422408679286 : Closed e2422408679286 ∧ code e2422408679286 = 11218501701494 := by decide
theorem cert_e2422408679286 : check e2422408679286 [[],[]] .chain = true := by decide
def e2422408679290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e2422408679290 : Closed e2422408679290 ∧ code e2422408679290 = 11218501701498 := by decide
theorem cert_e2422408679290 : check e2422408679290 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408679350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e2422408679350 : Closed e2422408679350 ∧ code e2422408679350 = 11218501701558 := by decide
theorem cert_e2422408679350 : check e2422408679350 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408679354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e2422408679354 : Closed e2422408679354 ∧ code e2422408679354 = 11218501701562 := by decide
theorem cert_e2422408679354 : check e2422408679354 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408679662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422408679662 : Closed e2422408679662 ∧ code e2422408679662 = 11218501701870 := by decide
theorem cert_e2422408679662 : check e2422408679662 [[],[]] .chain = true := by decide
def e2422408679670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422408679670 : Closed e2422408679670 ∧ code e2422408679670 = 11218501701878 := by decide
theorem cert_e2422408679670 : check e2422408679670 [[],[]] .chain = true := by decide
def e2422408680150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422408680150 : Closed e2422408680150 ∧ code e2422408680150 = 11218501702358 := by decide
theorem cert_e2422408680150 : check e2422408680150 [[],[]] .chain = true := by decide
def e2422408680154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422408680154 : Closed e2422408680154 ∧ code e2422408680154 = 11218501702362 := by decide
theorem cert_e2422408680154 : check e2422408680154 [[],[]] .chain = true := by decide
def e2422408680170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422408680170 : Closed e2422408680170 ∧ code e2422408680170 = 11218501702378 := by decide
theorem cert_e2422408680170 : check e2422408680170 [[],[]] .chain = true := by decide
def e2422408680246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408680246 : Closed e2422408680246 ∧ code e2422408680246 = 11218501702454 := by decide
theorem cert_e2422408680246 : check e2422408680246 [[],[]] .chain = true := by decide
def e2422408680250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408680250 : Closed e2422408680250 ∧ code e2422408680250 = 11218501702458 := by decide
theorem cert_e2422408680250 : check e2422408680250 [[],[]] .chain = true := by decide
def e2422408680334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422408680334 : Closed e2422408680334 ∧ code e2422408680334 = 11218501702542 := by decide
theorem cert_e2422408680334 : check e2422408680334 [[],[]] .chain = true := by decide
def e2422408680346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422408680346 : Closed e2422408680346 ∧ code e2422408680346 = 11218501702554 := by decide
theorem cert_e2422408680346 : check e2422408680346 [[],[]] .chain = true := by decide
def e2422408681582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422408681582 : Closed e2422408681582 ∧ code e2422408681582 = 11218501703790 := by decide
theorem cert_e2422408681582 : check e2422408681582 [[],[]] .chain = true := by decide
def e2422408681594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422408681594 : Closed e2422408681594 ∧ code e2422408681594 = 11218501703802 := by decide
theorem cert_e2422408681594 : check e2422408681594 [[],[]] .chain = true := by decide
def e2422408681870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422408681870 : Closed e2422408681870 ∧ code e2422408681870 = 11218501704078 := by decide
theorem cert_e2422408681870 : check e2422408681870 [[],[]] .chain = true := by decide
def e2422408681926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422408681926 : Closed e2422408681926 ∧ code e2422408681926 = 11218501704134 := by decide
theorem cert_e2422408681926 : check e2422408681926 [[],[]] .chain = true := by decide
def e2422408682526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408682526 : Closed e2422408682526 ∧ code e2422408682526 = 11218501704734 := by decide
theorem cert_e2422408682526 : check e2422408682526 [[],[]] .chain = true := by decide
def e2422408682550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422408682550 : Closed e2422408682550 ∧ code e2422408682550 = 11218501704758 := by decide
theorem cert_e2422408682550 : check e2422408682550 [[],[]] .chain = true := by decide
def e2422408682554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422408682554 : Closed e2422408682554 ∧ code e2422408682554 = 11218501704762 := by decide
theorem cert_e2422408682554 : check e2422408682554 [[],[]] .chain = true := by decide
def e2422408682694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422408682694 : Closed e2422408682694 ∧ code e2422408682694 = 11218501704902 := by decide
theorem cert_e2422408682694 : check e2422408682694 [[],[]] .chain = true := by decide
def e2422408682722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408682722 : Closed e2422408682722 ∧ code e2422408682722 = 11218501704930 := by decide
theorem cert_e2422408682722 : check e2422408682722 [[],[]] .chain = true := by decide
def e2422408682734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408682734 : Closed e2422408682734 ∧ code e2422408682734 = 11218501704942 := by decide
theorem cert_e2422408682734 : check e2422408682734 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408682742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408682742 : Closed e2422408682742 ∧ code e2422408682742 = 11218501704950 := by decide
theorem cert_e2422408682742 : check e2422408682742 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408683126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408683126 : Closed e2422408683126 ∧ code e2422408683126 = 11218501705334 := by decide
theorem cert_e2422408683126 : check e2422408683126 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408686678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.var 1))))))
theorem wire_e2422408686678 : Closed e2422408686678 ∧ code e2422408686678 = 11218501708886 := by decide
theorem cert_e2422408686678 : check e2422408686678 [[],[]] .chain = true := by decide
def e2422408686682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))) (.var 0))))))
theorem wire_e2422408686682 : Closed e2422408686682 ∧ code e2422408686682 = 11218501708890 := by decide
theorem cert_e2422408686682 : check e2422408686682 [[],[]] .chain = true := by decide
def e2422408686870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422408686870 : Closed e2422408686870 ∧ code e2422408686870 = 11218501709078 := by decide
theorem cert_e2422408686870 : check e2422408686870 [[],[]] .chain = true := by decide
def e2422408686946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422408686946 : Closed e2422408686946 ∧ code e2422408686946 = 11218501709154 := by decide
theorem cert_e2422408686946 : check e2422408686946 [[],[]] .chain = true := by decide
def e2422408686958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e2422408686958 : Closed e2422408686958 ∧ code e2422408686958 = 11218501709166 := by decide
theorem cert_e2422408686958 : check e2422408686958 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422408686966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e2422408686966 : Closed e2422408686966 ∧ code e2422408686966 = 11218501709174 := by decide
theorem cert_e2422408686966 : checkPay e2422408686966 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422408686986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408686986 : Closed e2422408686986 ∧ code e2422408686986 = 11218501709194 := by decide
theorem cert_e2422408686986 : check e2422408686986 [[],[]] .chain = true := by decide
def e2422408687010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408687010 : Closed e2422408687010 ∧ code e2422408687010 = 11218501709218 := by decide
theorem cert_e2422408687010 : check e2422408687010 [[],[]] .chain = true := by decide
def e2422408687022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e2422408687022 : Closed e2422408687022 ∧ code e2422408687022 = 11218501709230 := by decide
theorem cert_e2422408687022 : check e2422408687022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408687030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 1))))))
theorem wire_e2422408687030 : Closed e2422408687030 ∧ code e2422408687030 = 11218501709238 := by decide
theorem cert_e2422408687030 : check e2422408687030 [[],[]] .chain = true := by decide
def e2422408687034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2422408687034 : Closed e2422408687034 ∧ code e2422408687034 = 11218501709242 := by decide
theorem cert_e2422408687034 : check e2422408687034 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408687062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e2422408687062 : Closed e2422408687062 ∧ code e2422408687062 = 11218501709270 := by decide
theorem cert_e2422408687062 : checkPay e2422408687062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422408687066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2422408687066 : Closed e2422408687066 ∧ code e2422408687066 = 11218501709274 := by decide
theorem cert_e2422408687066 : check e2422408687066 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408687146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))) (.var 0))))))
theorem wire_e2422408687146 : Closed e2422408687146 ∧ code e2422408687146 = 11218501709354 := by decide
theorem cert_e2422408687146 : check e2422408687146 [[],[]] .chain = true := by decide
def e2422408687242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408687242 : Closed e2422408687242 ∧ code e2422408687242 = 11218501709450 := by decide
theorem cert_e2422408687242 : check e2422408687242 [[],[]] .chain = true := by decide
def e2422408687266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408687266 : Closed e2422408687266 ∧ code e2422408687266 = 11218501709474 := by decide
theorem cert_e2422408687266 : check e2422408687266 [[],[]] .chain = true := by decide
def e2422408687278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e2422408687278 : Closed e2422408687278 ∧ code e2422408687278 = 11218501709486 := by decide
theorem cert_e2422408687278 : check e2422408687278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408687286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e2422408687286 : Closed e2422408687286 ∧ code e2422408687286 = 11218501709494 := by decide
theorem cert_e2422408687286 : check e2422408687286 [[],[]] .chain = true := by decide
def e2422408687290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2422408687290 : Closed e2422408687290 ∧ code e2422408687290 = 11218501709498 := by decide
theorem cert_e2422408687290 : check e2422408687290 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408687318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e2422408687318 : Closed e2422408687318 ∧ code e2422408687318 = 11218501709526 := by decide
theorem cert_e2422408687318 : check e2422408687318 [[],[]] .chain = true := by decide
def e2422408687322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1)))) (.var 0))))))
theorem wire_e2422408687322 : Closed e2422408687322 ∧ code e2422408687322 = 11218501709530 := by decide
theorem cert_e2422408687322 : check e2422408687322 [[],[]] .chain = true := by decide
def e2422408687338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2422408687338 : Closed e2422408687338 ∧ code e2422408687338 = 11218501709546 := by decide
theorem cert_e2422408687338 : check e2422408687338 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408687446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e2422408687446 : Closed e2422408687446 ∧ code e2422408687446 = 11218501709654 := by decide
def e2422408687450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2422408687450 : Closed e2422408687450 ∧ code e2422408687450 = 11218501709658 := by decide
def e2422408687466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2422408687466 : Closed e2422408687466 ∧ code e2422408687466 = 11218501709674 := by decide
def e2422408687638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.var 1))))))
theorem wire_e2422408687638 : Closed e2422408687638 ∧ code e2422408687638 = 11218501709846 := by decide
theorem cert_e2422408687638 : check e2422408687638 [[],[]] .chain = true := by decide
def e2422408687734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2)))))) (.var 1))))))
theorem wire_e2422408687734 : Closed e2422408687734 ∧ code e2422408687734 = 11218501709942 := by decide
theorem cert_e2422408687734 : check e2422408687734 [[],[]] .chain = true := by decide
def e2422408687738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))) (.var 0))))))
theorem wire_e2422408687738 : Closed e2422408687738 ∧ code e2422408687738 = 11218501709946 := by decide
theorem cert_e2422408687738 : check e2422408687738 [[],[]] .chain = true := by decide
def e2422408687830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e2422408687830 : Closed e2422408687830 ∧ code e2422408687830 = 11218501710038 := by decide
theorem cert_e2422408687830 : checkPay e2422408687830 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422408687926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408687926 : Closed e2422408687926 ∧ code e2422408687926 = 11218501710134 := by decide
theorem cert_e2422408687926 : check e2422408687926 [[],[]] .chain = true := by decide
def e2422408687930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408687930 : Closed e2422408687930 ∧ code e2422408687930 = 11218501710138 := by decide
theorem cert_e2422408687930 : check e2422408687930 [[],[]] .chain = true := by decide
def e2422408688014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.lam (.var 2)))))))
theorem wire_e2422408688014 : Closed e2422408688014 ∧ code e2422408688014 = 11218501710222 := by decide
theorem cert_e2422408688014 : check e2422408688014 [[],[]] .chain = true := by decide
def e2422408688070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.lam (.var 1)))))))
theorem wire_e2422408688070 : Closed e2422408688070 ∧ code e2422408688070 = 11218501710278 := by decide
theorem cert_e2422408688070 : check e2422408688070 [[],[]] .chain = true := by decide
def e2422408688406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408688406 : Closed e2422408688406 ∧ code e2422408688406 = 11218501710614 := by decide
theorem cert_e2422408688406 : check e2422408688406 [[],[]] .chain = true := by decide
def e2422408688482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e2422408688482 : Closed e2422408688482 ∧ code e2422408688482 = 11218501710690 := by decide
theorem cert_e2422408688482 : check e2422408688482 [[],[]] .chain = true := by decide
def e2422408688494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e2422408688494 : Closed e2422408688494 ∧ code e2422408688494 = 11218501710702 := by decide
theorem cert_e2422408688494 : check e2422408688494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408688502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e2422408688502 : Closed e2422408688502 ∧ code e2422408688502 = 11218501710710 := by decide
theorem cert_e2422408688502 : checkPay e2422408688502 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422408688522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408688522 : Closed e2422408688522 ∧ code e2422408688522 = 11218501710730 := by decide
theorem cert_e2422408688522 : check e2422408688522 [[],[]] .chain = true := by decide
def e2422408688546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422408688546 : Closed e2422408688546 ∧ code e2422408688546 = 11218501710754 := by decide
theorem cert_e2422408688546 : check e2422408688546 [[],[]] .chain = true := by decide
def e2422408688558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e2422408688558 : Closed e2422408688558 ∧ code e2422408688558 = 11218501710766 := by decide
theorem cert_e2422408688558 : check e2422408688558 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408688566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e2422408688566 : Closed e2422408688566 ∧ code e2422408688566 = 11218501710774 := by decide
theorem cert_e2422408688566 : check e2422408688566 [[],[]] .chain = true := by decide
def e2422408688570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2422408688570 : Closed e2422408688570 ∧ code e2422408688570 = 11218501710778 := by decide
theorem cert_e2422408688570 : check e2422408688570 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408688598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e2422408688598 : Closed e2422408688598 ∧ code e2422408688598 = 11218501710806 := by decide
def e2422408688602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2422408688602 : Closed e2422408688602 ∧ code e2422408688602 = 11218501710810 := by decide
theorem cert_e2422408688602 : check e2422408688602 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408688670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408688670 : Closed e2422408688670 ∧ code e2422408688670 = 11218501710878 := by decide
theorem cert_e2422408688670 : check e2422408688670 [[],[]] .chain = true := by decide
def e2422408688866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408688866 : Closed e2422408688866 ∧ code e2422408688866 = 11218501711074 := by decide
theorem cert_e2422408688866 : check e2422408688866 [[],[]] .chain = true := by decide
def e2422408688878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408688878 : Closed e2422408688878 ∧ code e2422408688878 = 11218501711086 := by decide
theorem cert_e2422408688878 : check e2422408688878 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408688886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408688886 : Closed e2422408688886 ∧ code e2422408688886 = 11218501711094 := by decide
theorem cert_e2422408688886 : check e2422408688886 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408689154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408689154 : Closed e2422408689154 ∧ code e2422408689154 = 11218501711362 := by decide
theorem cert_e2422408689154 : check e2422408689154 [[],[]] .chain = true := by decide
def e2422408689166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408689166 : Closed e2422408689166 ∧ code e2422408689166 = 11218501711374 := by decide
theorem cert_e2422408689166 : check e2422408689166 [[],[]] .chain = true := by decide
def e2422408689178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408689178 : Closed e2422408689178 ∧ code e2422408689178 = 11218501711386 := by decide
theorem cert_e2422408689178 : check e2422408689178 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408689250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408689250 : Closed e2422408689250 ∧ code e2422408689250 = 11218501711458 := by decide
theorem cert_e2422408689250 : check e2422408689250 [[],[]] .chain = true := by decide
def e2422408689262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408689262 : Closed e2422408689262 ∧ code e2422408689262 = 11218501711470 := by decide
theorem cert_e2422408689262 : check e2422408689262 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408689270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408689270 : Closed e2422408689270 ∧ code e2422408689270 = 11218501711478 := by decide
theorem cert_e2422408689270 : check e2422408689270 [[],[]] .chain = true := by decide
def e2422408689274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408689274 : Closed e2422408689274 ∧ code e2422408689274 = 11218501711482 := by decide
theorem cert_e2422408689274 : check e2422408689274 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408689462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408689462 : Closed e2422408689462 ∧ code e2422408689462 = 11218501711670 := by decide
def e2422408689466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408689466 : Closed e2422408689466 ∧ code e2422408689466 = 11218501711674 := by decide
def e2422408689674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))) (.var 0))))))
theorem wire_e2422408689674 : Closed e2422408689674 ∧ code e2422408689674 = 11218501711882 := by decide
theorem cert_e2422408689674 : check e2422408689674 [[],[]] .chain = true := by decide
def e2422408689710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408689710 : Closed e2422408689710 ∧ code e2422408689710 = 11218501711918 := by decide
theorem cert_e2422408689710 : check e2422408689710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408689718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422408689718 : Closed e2422408689718 ∧ code e2422408689718 = 11218501711926 := by decide
theorem cert_e2422408689718 : check e2422408689718 [[],[]] .chain = true := by decide
def e2422408689722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))) (.var 0))))))
theorem wire_e2422408689722 : Closed e2422408689722 ∧ code e2422408689722 = 11218501711930 := by decide
theorem cert_e2422408689722 : check e2422408689722 [[],[]] .chain = true := by decide
def e2422408689770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e2422408689770 : Closed e2422408689770 ∧ code e2422408689770 = 11218501711978 := by decide
theorem cert_e2422408689770 : check e2422408689770 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408689806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422408689806 : Closed e2422408689806 ∧ code e2422408689806 = 11218501712014 := by decide
theorem cert_e2422408689806 : check e2422408689806 [[],[]] .chain = true := by decide
def e2422408689818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408689818 : Closed e2422408689818 ∧ code e2422408689818 = 11218501712026 := by decide
theorem cert_e2422408689818 : check e2422408689818 [[],[]] .chain = true := by decide
def e2422408689862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.lam (.var 1)))))))
theorem wire_e2422408689862 : Closed e2422408689862 ∧ code e2422408689862 = 11218501712070 := by decide
theorem cert_e2422408689862 : check e2422408689862 [[],[]] .chain = true := by decide
def e2422408689890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422408689890 : Closed e2422408689890 ∧ code e2422408689890 = 11218501712098 := by decide
theorem cert_e2422408689890 : check e2422408689890 [[],[]] .chain = true := by decide
def e2422408689902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422408689902 : Closed e2422408689902 ∧ code e2422408689902 = 11218501712110 := by decide
theorem cert_e2422408689902 : check e2422408689902 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408689910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))) (.var 1))))))
theorem wire_e2422408689910 : Closed e2422408689910 ∧ code e2422408689910 = 11218501712118 := by decide
theorem cert_e2422408689910 : check e2422408689910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408690058 : Closed e2422408690058 ∧ code e2422408690058 = 11218501712266 := by decide
theorem cert_e2422408690058 : check e2422408690058 [[],[]] .chain = true := by decide
def e2422408690082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422408690082 : Closed e2422408690082 ∧ code e2422408690082 = 11218501712290 := by decide
theorem cert_e2422408690082 : check e2422408690082 [[],[]] .chain = true := by decide
def e2422408690094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422408690094 : Closed e2422408690094 ∧ code e2422408690094 = 11218501712302 := by decide
theorem cert_e2422408690094 : check e2422408690094 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e2422408690102 : Closed e2422408690102 ∧ code e2422408690102 = 11218501712310 := by decide
theorem cert_e2422408690102 : check e2422408690102 [[],[]] .chain = true := by decide
def e2422408690106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2422408690106 : Closed e2422408690106 ∧ code e2422408690106 = 11218501712314 := by decide
theorem cert_e2422408690106 : check e2422408690106 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e2422408690134 : Closed e2422408690134 ∧ code e2422408690134 = 11218501712342 := by decide
theorem cert_e2422408690134 : check e2422408690134 [[],[]] .chain = true := by decide
def e2422408690138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e2422408690138 : Closed e2422408690138 ∧ code e2422408690138 = 11218501712346 := by decide
theorem cert_e2422408690138 : check e2422408690138 [[],[]] .chain = true := by decide
def e2422408690154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2422408690154 : Closed e2422408690154 ∧ code e2422408690154 = 11218501712362 := by decide
theorem cert_e2422408690154 : check e2422408690154 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408690178 : Closed e2422408690178 ∧ code e2422408690178 = 11218501712386 := by decide
theorem cert_e2422408690178 : check e2422408690178 [[],[]] .chain = true := by decide
def e2422408690190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408690190 : Closed e2422408690190 ∧ code e2422408690190 = 11218501712398 := by decide
theorem cert_e2422408690190 : check e2422408690190 [[],[]] .chain = true := by decide
def e2422408690202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408690202 : Closed e2422408690202 ∧ code e2422408690202 = 11218501712410 := by decide
theorem cert_e2422408690202 : check e2422408690202 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408690274 : Closed e2422408690274 ∧ code e2422408690274 = 11218501712482 := by decide
theorem cert_e2422408690274 : check e2422408690274 [[],[]] .chain = true := by decide
def e2422408690286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408690286 : Closed e2422408690286 ∧ code e2422408690286 = 11218501712494 := by decide
theorem cert_e2422408690286 : check e2422408690286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408690294 : Closed e2422408690294 ∧ code e2422408690294 = 11218501712502 := by decide
theorem cert_e2422408690294 : check e2422408690294 [[],[]] .chain = true := by decide
def e2422408690298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408690298 : Closed e2422408690298 ∧ code e2422408690298 = 11218501712506 := by decide
theorem cert_e2422408690298 : check e2422408690298 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.lam (.var 1))))))))
theorem wire_e2422408690438 : Closed e2422408690438 ∧ code e2422408690438 = 11218501712646 := by decide
theorem cert_e2422408690438 : check e2422408690438 [[],[]] .chain = true := by decide
def e2422408690462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422408690462 : Closed e2422408690462 ∧ code e2422408690462 = 11218501712670 := by decide
theorem cert_e2422408690462 : check e2422408690462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408690486 : Closed e2422408690486 ∧ code e2422408690486 = 11218501712694 := by decide
theorem cert_e2422408690486 : check e2422408690486 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422408676278
#print axioms Blc.Floor43.cert_e2422408678230
#print axioms Blc.Floor43.cert_e2422408678614
#print axioms Blc.Floor43.cert_e2422408678710
#print axioms Blc.Floor43.cert_e2422408678714
