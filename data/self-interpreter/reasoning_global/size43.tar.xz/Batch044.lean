import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e700482680282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e700482680282 : Closed e700482680282 ∧ code e700482680282 = 9496575702490 := by decide
theorem cert_e700482680282 : check e700482680282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482680506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e700482680506 : Closed e700482680506 ∧ code e700482680506 = 9496575702714 := by decide
theorem cert_e700482680506 : check e700482680506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482680554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e700482680554 : Closed e700482680554 ∧ code e700482680554 = 9496575702762 := by decide
theorem cert_e700482680554 : check e700482680554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482680666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e700482680666 : Closed e700482680666 ∧ code e700482680666 = 9496575702874 := by decide
theorem cert_e700482680666 : check e700482680666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482680682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e700482680682 : Closed e700482680682 ∧ code e700482680682 = 9496575702890 := by decide
theorem cert_e700482680682 : check e700482680682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482681562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.var 0)))
theorem wire_e700482681562 : Closed e700482681562 ∧ code e700482681562 = 9496575703770 := by decide
theorem cert_e700482681562 : check e700482681562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482681690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e700482681690 : Closed e700482681690 ∧ code e700482681690 = 9496575703898 := by decide
theorem cert_e700482681690 : check e700482681690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482681706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e700482681706 : Closed e700482681706 ∧ code e700482681706 = 9496575703914 := by decide
theorem cert_e700482681706 : check e700482681706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482690490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e700482690490 : Closed e700482690490 ∧ code e700482690490 = 9496575712698 := by decide
theorem cert_e700482690490 : check e700482690490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482690522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e700482690522 : Closed e700482690522 ∧ code e700482690522 = 9496575712730 := by decide
theorem cert_e700482690522 : check e700482690522 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482690778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e700482690778 : Closed e700482690778 ∧ code e700482690778 = 9496575712986 := by decide
theorem cert_e700482690778 : check e700482690778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482696122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e700482696122 : Closed e700482696122 ∧ code e700482696122 = 9496575718330 := by decide
theorem cert_e700482696122 : check e700482696122 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482696154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e700482696154 : Closed e700482696154 ∧ code e700482696154 = 9496575718362 := by decide
theorem cert_e700482696154 : check e700482696154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482697690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.var 0)))
theorem wire_e700482697690 : Closed e700482697690 ∧ code e700482697690 = 9496575719898 := by decide
theorem cert_e700482697690 : check e700482697690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482702778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e700482702778 : Closed e700482702778 ∧ code e700482702778 = 9496575724986 := by decide
theorem cert_e700482702778 : check e700482702778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482702810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e700482702810 : Closed e700482702810 ∧ code e700482702810 = 9496575725018 := by decide
theorem cert_e700482702810 : check e700482702810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482703034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e700482703034 : Closed e700482703034 ∧ code e700482703034 = 9496575725242 := by decide
theorem cert_e700482703034 : check e700482703034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482703082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e700482703082 : Closed e700482703082 ∧ code e700482703082 = 9496575725290 := by decide
theorem cert_e700482703082 : check e700482703082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482703194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e700482703194 : Closed e700482703194 ∧ code e700482703194 = 9496575725402 := by decide
theorem cert_e700482703194 : check e700482703194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482703210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e700482703210 : Closed e700482703210 ∧ code e700482703210 = 9496575725418 := by decide
theorem cert_e700482703210 : check e700482703210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482704314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e700482704314 : Closed e700482704314 ∧ code e700482704314 = 9496575726522 := by decide
theorem cert_e700482704314 : check e700482704314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482704346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e700482704346 : Closed e700482704346 ∧ code e700482704346 = 9496575726554 := by decide
theorem cert_e700482704346 : check e700482704346 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482705850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e700482705850 : Closed e700482705850 ∧ code e700482705850 = 9496575728058 := by decide
theorem cert_e700482705850 : check e700482705850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482705898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e700482705898 : Closed e700482705898 ∧ code e700482705898 = 9496575728106 := by decide
theorem cert_e700482705898 : check e700482705898 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482706650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e700482706650 : Closed e700482706650 ∧ code e700482706650 = 9496575728858 := by decide
theorem cert_e700482706650 : check e700482706650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482706666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e700482706666 : Closed e700482706666 ∧ code e700482706666 = 9496575728874 := by decide
theorem cert_e700482706666 : check e700482706666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482709210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e700482709210 : Closed e700482709210 ∧ code e700482709210 = 9496575731418 := by decide
theorem cert_e700482709210 : check e700482709210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482709338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e700482709338 : Closed e700482709338 ∧ code e700482709338 = 9496575731546 := by decide
theorem cert_e700482709338 : check e700482709338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482709354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e700482709354 : Closed e700482709354 ∧ code e700482709354 = 9496575731562 := by decide
theorem cert_e700482709354 : check e700482709354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482709978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.var 0)))
theorem wire_e700482709978 : Closed e700482709978 ∧ code e700482709978 = 9496575732186 := by decide
theorem cert_e700482709978 : check e700482709978 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482710746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e700482710746 : Closed e700482710746 ∧ code e700482710746 = 9496575732954 := by decide
theorem cert_e700482710746 : check e700482710746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482710762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e700482710762 : Closed e700482710762 ∧ code e700482710762 = 9496575732970 := by decide
theorem cert_e700482710762 : check e700482710762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482739642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e700482739642 : Closed e700482739642 ∧ code e700482739642 = 9496575761850 := by decide
theorem cert_e700482739642 : check e700482739642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482739674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e700482739674 : Closed e700482739674 ∧ code e700482739674 = 9496575761882 := by decide
theorem cert_e700482739674 : check e700482739674 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482739930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e700482739930 : Closed e700482739930 ∧ code e700482739930 = 9496575762138 := by decide
theorem cert_e700482739930 : check e700482739930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482745274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e700482745274 : Closed e700482745274 ∧ code e700482745274 = 9496575767482 := by decide
theorem cert_e700482745274 : check e700482745274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482745306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e700482745306 : Closed e700482745306 ∧ code e700482745306 = 9496575767514 := by decide
theorem cert_e700482745306 : check e700482745306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482746842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e700482746842 : Closed e700482746842 ∧ code e700482746842 = 9496575769050 := by decide
theorem cert_e700482746842 : check e700482746842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482792890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e700482792890 : Closed e700482792890 ∧ code e700482792890 = 9496575815098 := by decide
theorem cert_e700482792890 : check e700482792890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482792922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e700482792922 : Closed e700482792922 ∧ code e700482792922 = 9496575815130 := by decide
theorem cert_e700482792922 : check e700482792922 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482793146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e700482793146 : Closed e700482793146 ∧ code e700482793146 = 9496575815354 := by decide
theorem cert_e700482793146 : check e700482793146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482793194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e700482793194 : Closed e700482793194 ∧ code e700482793194 = 9496575815402 := by decide
theorem cert_e700482793194 : check e700482793194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482793306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e700482793306 : Closed e700482793306 ∧ code e700482793306 = 9496575815514 := by decide
theorem cert_e700482793306 : check e700482793306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482793322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e700482793322 : Closed e700482793322 ∧ code e700482793322 = 9496575815530 := by decide
theorem cert_e700482793322 : check e700482793322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482794426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e700482794426 : Closed e700482794426 ∧ code e700482794426 = 9496575816634 := by decide
theorem cert_e700482794426 : check e700482794426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482794458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e700482794458 : Closed e700482794458 ∧ code e700482794458 = 9496575816666 := by decide
theorem cert_e700482794458 : check e700482794458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482795962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e700482795962 : Closed e700482795962 ∧ code e700482795962 = 9496575818170 := by decide
theorem cert_e700482795962 : check e700482795962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482796010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e700482796010 : Closed e700482796010 ∧ code e700482796010 = 9496575818218 := by decide
theorem cert_e700482796010 : check e700482796010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482796762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e700482796762 : Closed e700482796762 ∧ code e700482796762 = 9496575818970 := by decide
theorem cert_e700482796762 : check e700482796762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482796778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e700482796778 : Closed e700482796778 ∧ code e700482796778 = 9496575818986 := by decide
theorem cert_e700482796778 : check e700482796778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482819802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e700482819802 : Closed e700482819802 ∧ code e700482819802 = 9496575842010 := by decide
theorem cert_e700482819802 : check e700482819802 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482819930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e700482819930 : Closed e700482819930 ∧ code e700482819930 = 9496575842138 := by decide
theorem cert_e700482819930 : check e700482819930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482819946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e700482819946 : Closed e700482819946 ∧ code e700482819946 = 9496575842154 := by decide
theorem cert_e700482819946 : check e700482819946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482820570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e700482820570 : Closed e700482820570 ∧ code e700482820570 = 9496575842778 := by decide
theorem cert_e700482820570 : check e700482820570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482821338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e700482821338 : Closed e700482821338 ∧ code e700482821338 = 9496575843546 := by decide
theorem cert_e700482821338 : check e700482821338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482821354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e700482821354 : Closed e700482821354 ∧ code e700482821354 = 9496575843562 := by decide
theorem cert_e700482821354 : check e700482821354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700484169146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e700484169146 : Closed e700484169146 ∧ code e700484169146 = 9496577191354 := by decide
theorem cert_e700484169146 : check e700484169146 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484169178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e700484169178 : Closed e700484169178 ∧ code e700484169178 = 9496577191386 := by decide
theorem cert_e700484169178 : check e700484169178 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484169402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e700484169402 : Closed e700484169402 ∧ code e700484169402 = 9496577191610 := by decide
theorem cert_e700484169402 : check e700484169402 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484169450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e700484169450 : Closed e700484169450 ∧ code e700484169450 = 9496577191658 := by decide
theorem cert_e700484169450 : check e700484169450 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484169562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e700484169562 : Closed e700484169562 ∧ code e700484169562 = 9496577191770 := by decide
theorem cert_e700484169562 : check e700484169562 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484169578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e700484169578 : Closed e700484169578 ∧ code e700484169578 = 9496577191786 := by decide
theorem cert_e700484169578 : check e700484169578 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484170682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e700484170682 : Closed e700484170682 ∧ code e700484170682 = 9496577192890 := by decide
theorem cert_e700484170682 : check e700484170682 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484170714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e700484170714 : Closed e700484170714 ∧ code e700484170714 = 9496577192922 := by decide
theorem cert_e700484170714 : check e700484170714 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484172218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e700484172218 : Closed e700484172218 ∧ code e700484172218 = 9496577194426 := by decide
theorem cert_e700484172218 : check e700484172218 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484172266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e700484172266 : Closed e700484172266 ∧ code e700484172266 = 9496577194474 := by decide
theorem cert_e700484172266 : check e700484172266 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484173018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e700484173018 : Closed e700484173018 ∧ code e700484173018 = 9496577195226 := by decide
theorem cert_e700484173018 : check e700484173018 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700484173034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e700484173034 : Closed e700484173034 ∧ code e700484173034 = 9496577195242 := by decide
theorem cert_e700484173034 : check e700484173034 [[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e700887971946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700887971946 : Closed e700887971946 ∧ code e700887971946 = 9496980994154 := by decide
theorem cert_e700887971946 : check e700887971946 [[.under,.left]] .width = true := by decide
def e700887980138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700887980138 : Closed e700887980138 ∧ code e700887980138 = 9496981002346 := by decide
theorem cert_e700887980138 : check e700887980138 [[.under,.left]] .width = true := by decide
def e700888037482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888037482 : Closed e700888037482 ∧ code e700888037482 = 9496981059690 := by decide
theorem cert_e700888037482 : check e700888037482 [[.under,.left]] .width = true := by decide
def e700888049770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888049770 : Closed e700888049770 ∧ code e700888049770 = 9496981071978 := by decide
private def t_e700888049770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e700888049770 : ¬ IsSelfInterpreter e700888049770 :=
  wSource (t := t_e700888049770) (replay_sound (ps := []) (t := e700888049770) (by decide)) (by decide)
def e700888078442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888078442 : Closed e700888078442 ∧ code e700888078442 = 9496981100650 := by decide
theorem cert_e700888078442 : check e700888078442 [[.under,.left]] .width = true := by decide
def e700888082538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888082538 : Closed e700888082538 ∧ code e700888082538 = 9496981104746 := by decide
private def t_e700888082538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e700888082538 : ¬ IsSelfInterpreter e700888082538 :=
  wSource (t := t_e700888082538) (replay_sound (ps := []) (t := e700888082538) (by decide)) (by decide)
def e700888365162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888365162 : Closed e700888365162 ∧ code e700888365162 = 9496981387370 := by decide
theorem cert_e700888365162 : check e700888365162 [[.under,.left]] .width = true := by decide
def e700888373354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888373354 : Closed e700888373354 ∧ code e700888373354 = 9496981395562 := by decide
theorem cert_e700888373354 : check e700888373354 [[.under,.left]] .width = true := by decide
def e700888758378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888758378 : Closed e700888758378 ∧ code e700888758378 = 9496981780586 := by decide
theorem cert_e700888758378 : check e700888758378 [[.under,.left]] .width = true := by decide
def e700888770666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888770666 : Closed e700888770666 ∧ code e700888770666 = 9496981792874 := by decide
theorem cert_e700888770666 : check e700888770666 [[.under,.left]] .width = true := by decide
def e700888963178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888963178 : Closed e700888963178 ∧ code e700888963178 = 9496981985386 := by decide
theorem cert_e700888963178 : check e700888963178 [[.under,.left]] .width = true := by decide
def e700888967274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e700888967274 : Closed e700888967274 ∧ code e700888967274 = 9496981989482 := by decide
theorem cert_e700888967274 : check e700888967274 [[.under,.left]] .width = true := by decide
def e700952262074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e700952262074 : Closed e700952262074 ∧ code e700952262074 = 9497045284282 := by decide
theorem cert_e700952262074 : check e700952262074 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e700952262106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e700952262106 : Closed e700952262106 ∧ code e700952262106 = 9497045284314 := by decide
theorem cert_e700952262106 : checkPay e700952262106 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e700952262330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e700952262330 : Closed e700952262330 ∧ code e700952262330 = 9497045284538 := by decide
theorem cert_e700952262330 : check e700952262330 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e700952262378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e700952262378 : Closed e700952262378 ∧ code e700952262378 = 9497045284586 := by decide
theorem cert_e700952262378 : check e700952262378 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e700952262490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e700952262490 : Closed e700952262490 ∧ code e700952262490 = 9497045284698 := by decide
theorem cert_e700952262490 : check e700952262490 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e700952262506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e700952262506 : Closed e700952262506 ∧ code e700952262506 = 9497045284714 := by decide
theorem cert_e700952262506 : check e700952262506 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e700952263354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e700952263354 : Closed e700952263354 ∧ code e700952263354 = 9497045285562 := by decide
theorem cert_e700952263354 : check e700952263354 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952263402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e700952263402 : Closed e700952263402 ∧ code e700952263402 = 9497045285610 := by decide
theorem cert_e700952263402 : check e700952263402 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952263594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e700952263594 : Closed e700952263594 ∧ code e700952263594 = 9497045285802 := by decide
theorem cert_e700952263594 : check e700952263594 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952264026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e700952264026 : Closed e700952264026 ∧ code e700952264026 = 9497045286234 := by decide
theorem cert_e700952264026 : check e700952264026 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e700952264042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e700952264042 : Closed e700952264042 ∧ code e700952264042 = 9497045286250 := by decide
theorem cert_e700952264042 : check e700952264042 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e700952264106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e700952264106 : Closed e700952264106 ∧ code e700952264106 = 9497045286314 := by decide
theorem cert_e700952264106 : check e700952264106 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e700952268218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e700952268218 : Closed e700952268218 ∧ code e700952268218 = 9497045290426 := by decide
theorem cert_e700952268218 : check e700952268218 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e700952268250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e700952268250 : Closed e700952268250 ∧ code e700952268250 = 9497045290458 := by decide
theorem cert_e700952268250 : check e700952268250 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e700952268474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e700952268474 : Closed e700952268474 ∧ code e700952268474 = 9497045290682 := by decide
theorem cert_e700952268474 : check e700952268474 [[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e700952268522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e700952268522 : Closed e700952268522 ∧ code e700952268522 = 9497045290730 := by decide
theorem cert_e700952268522 : check e700952268522 [[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e700952268634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e700952268634 : Closed e700952268634 ∧ code e700952268634 = 9497045290842 := by decide
theorem cert_e700952268634 : checkPay e700952268634 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e700952268650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e700952268650 : Closed e700952268650 ∧ code e700952268650 = 9497045290858 := by decide
theorem cert_e700952268650 : check e700952268650 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e700952269754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e700952269754 : Closed e700952269754 ∧ code e700952269754 = 9497045291962 := by decide
theorem cert_e700952269754 : check e700952269754 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e700952269786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e700952269786 : Closed e700952269786 ∧ code e700952269786 = 9497045291994 := by decide
theorem cert_e700952269786 : check e700952269786 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e700952271290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e700952271290 : Closed e700952271290 ∧ code e700952271290 = 9497045293498 := by decide
theorem cert_e700952271290 : check e700952271290 [[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e700952271338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e700952271338 : Closed e700952271338 ∧ code e700952271338 = 9497045293546 := by decide
theorem cert_e700952271338 : check e700952271338 [[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e700952272090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e700952272090 : Closed e700952272090 ∧ code e700952272090 = 9497045294298 := by decide
theorem cert_e700952272090 : check e700952272090 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e700952272106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e700952272106 : Closed e700952272106 ∧ code e700952272106 = 9497045294314 := by decide
theorem cert_e700952272106 : check e700952272106 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e700952274618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e700952274618 : Closed e700952274618 ∧ code e700952274618 = 9497045296826 := by decide
theorem cert_e700952274618 : checkPay e700952274618 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e700952274666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e700952274666 : Closed e700952274666 ∧ code e700952274666 = 9497045296874 := by decide
theorem cert_e700952274666 : checkPay e700952274666 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e700952274858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e700952274858 : Closed e700952274858 ∧ code e700952274858 = 9497045297066 := by decide
theorem cert_e700952274858 : checkPay e700952274858 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e700952275386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e700952275386 : Closed e700952275386 ∧ code e700952275386 = 9497045297594 := by decide
theorem cert_e700952275386 : checkPay e700952275386 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e700952275434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e700952275434 : Closed e700952275434 ∧ code e700952275434 = 9497045297642 := by decide
theorem cert_e700952275434 : checkPay e700952275434 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e700952276586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e700952276586 : Closed e700952276586 ∧ code e700952276586 = 9497045298794 := by decide
theorem cert_e700952276586 : checkPay e700952276586 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e700952277850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e700952277850 : Closed e700952277850 ∧ code e700952277850 = 9497045300058 := by decide
theorem cert_e700952277850 : check e700952277850 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e700952277866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e700952277866 : Closed e700952277866 ∧ code e700952277866 = 9497045300074 := by decide
theorem cert_e700952277866 : check e700952277866 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e700952277930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e700952277930 : Closed e700952277930 ∧ code e700952277930 = 9497045300138 := by decide
theorem cert_e700952277930 : check e700952277930 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e700952278234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e700952278234 : Closed e700952278234 ∧ code e700952278234 = 9497045300442 := by decide
theorem cert_e700952278234 : check e700952278234 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e700952278250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e700952278250 : Closed e700952278250 ∧ code e700952278250 = 9497045300458 := by decide
theorem cert_e700952278250 : check e700952278250 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e700952278634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e700952278634 : Closed e700952278634 ∧ code e700952278634 = 9497045300842 := by decide
theorem cert_e700952278634 : check e700952278634 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e700952292794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e700952292794 : Closed e700952292794 ∧ code e700952292794 = 9497045315002 := by decide
theorem cert_e700952292794 : check e700952292794 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e700952292826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e700952292826 : Closed e700952292826 ∧ code e700952292826 = 9497045315034 := by decide
theorem cert_e700952292826 : check e700952292826 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e700952293050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e700952293050 : Closed e700952293050 ∧ code e700952293050 = 9497045315258 := by decide
theorem cert_e700952293050 : check e700952293050 [[.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e700952293098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e700952293098 : Closed e700952293098 ∧ code e700952293098 = 9497045315306 := by decide
theorem cert_e700952293098 : check e700952293098 [[.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e700952293210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e700952293210 : Closed e700952293210 ∧ code e700952293210 = 9497045315418 := by decide
theorem cert_e700952293210 : check e700952293210 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e700952293226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e700952293226 : Closed e700952293226 ∧ code e700952293226 = 9497045315434 := by decide
theorem cert_e700952293226 : check e700952293226 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e700952294330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e700952294330 : Closed e700952294330 ∧ code e700952294330 = 9497045316538 := by decide
theorem cert_e700952294330 : check e700952294330 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e700952294362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e700952294362 : Closed e700952294362 ∧ code e700952294362 = 9497045316570 := by decide
theorem cert_e700952294362 : check e700952294362 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e700952295866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e700952295866 : Closed e700952295866 ∧ code e700952295866 = 9497045318074 := by decide
theorem cert_e700952295866 : check e700952295866 [[.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e700952295914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e700952295914 : Closed e700952295914 ∧ code e700952295914 = 9497045318122 := by decide
theorem cert_e700952295914 : check e700952295914 [[.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e700952296666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e700952296666 : Closed e700952296666 ∧ code e700952296666 = 9497045318874 := by decide
theorem cert_e700952296666 : check e700952296666 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e700952296682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e700952296682 : Closed e700952296682 ∧ code e700952296682 = 9497045318890 := by decide
theorem cert_e700952296682 : check e700952296682 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e700952319674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e700952319674 : Closed e700952319674 ∧ code e700952319674 = 9497045341882 := by decide
theorem cert_e700952319674 : check e700952319674 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952319722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e700952319722 : Closed e700952319722 ∧ code e700952319722 = 9497045341930 := by decide
theorem cert_e700952319722 : check e700952319722 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952319914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e700952319914 : Closed e700952319914 ∧ code e700952319914 = 9497045342122 := by decide
theorem cert_e700952319914 : check e700952319914 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952320442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e700952320442 : Closed e700952320442 ∧ code e700952320442 = 9497045342650 := by decide
theorem cert_e700952320442 : check e700952320442 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952320490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e700952320490 : Closed e700952320490 ∧ code e700952320490 = 9497045342698 := by decide
theorem cert_e700952320490 : check e700952320490 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952321642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e700952321642 : Closed e700952321642 ∧ code e700952321642 = 9497045343850 := by decide
theorem cert_e700952321642 : check e700952321642 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952333146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e700952333146 : Closed e700952333146 ∧ code e700952333146 = 9497045355354 := by decide
theorem cert_e700952333146 : check e700952333146 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e700952333162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e700952333162 : Closed e700952333162 ∧ code e700952333162 = 9497045355370 := by decide
theorem cert_e700952333162 : check e700952333162 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e700952333226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e700952333226 : Closed e700952333226 ∧ code e700952333226 = 9497045355434 := by decide
theorem cert_e700952333226 : check e700952333226 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e700952333530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e700952333530 : Closed e700952333530 ∧ code e700952333530 = 9497045355738 := by decide
theorem cert_e700952333530 : check e700952333530 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e700952333546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e700952333546 : Closed e700952333546 ∧ code e700952333546 = 9497045355754 := by decide
theorem cert_e700952333546 : check e700952333546 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e700952333930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e700952333930 : Closed e700952333930 ∧ code e700952333930 = 9497045356138 := by decide
theorem cert_e700952333930 : check e700952333930 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e700952882618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e700952882618 : Closed e700952882618 ∧ code e700952882618 = 9497045904826 := by decide
theorem cert_e700952882618 : check e700952882618 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952882650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e700952882650 : Closed e700952882650 ∧ code e700952882650 = 9497045904858 := by decide
theorem cert_e700952882650 : check e700952882650 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952882874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e700952882874 : Closed e700952882874 ∧ code e700952882874 = 9497045905082 := by decide
theorem cert_e700952882874 : check e700952882874 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952882922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e700952882922 : Closed e700952882922 ∧ code e700952882922 = 9497045905130 := by decide
theorem cert_e700952882922 : check e700952882922 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952883034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e700952883034 : Closed e700952883034 ∧ code e700952883034 = 9497045905242 := by decide
theorem cert_e700952883034 : check e700952883034 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952883050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e700952883050 : Closed e700952883050 ∧ code e700952883050 = 9497045905258 := by decide
theorem cert_e700952883050 : check e700952883050 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952884154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e700952884154 : Closed e700952884154 ∧ code e700952884154 = 9497045906362 := by decide
theorem cert_e700952884154 : check e700952884154 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952884186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e700952884186 : Closed e700952884186 ∧ code e700952884186 = 9497045906394 := by decide
theorem cert_e700952884186 : check e700952884186 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952885690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e700952885690 : Closed e700952885690 ∧ code e700952885690 = 9497045907898 := by decide
theorem cert_e700952885690 : check e700952885690 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952885738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e700952885738 : Closed e700952885738 ∧ code e700952885738 = 9497045907946 := by decide
theorem cert_e700952885738 : check e700952885738 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952886490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e700952886490 : Closed e700952886490 ∧ code e700952886490 = 9497045908698 := by decide
theorem cert_e700952886490 : check e700952886490 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700952886506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e700952886506 : Closed e700952886506 ∧ code e700952886506 = 9497045908714 := by decide
theorem cert_e700952886506 : check e700952886506 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700955241914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e700955241914 : Closed e700955241914 ∧ code e700955241914 = 9497048264122 := by decide
def e700955241946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e700955241946 : Closed e700955241946 ∧ code e700955241946 = 9497048264154 := by decide
def e700955242170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e700955242170 : Closed e700955242170 ∧ code e700955242170 = 9497048264378 := by decide
def e700955242218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e700955242218 : Closed e700955242218 ∧ code e700955242218 = 9497048264426 := by decide
private def t_e700955242218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem cert_e700955242218 : ¬ IsSelfInterpreter e700955242218 :=
  wSource (t := t_e700955242218) (replay_sound (ps := []) (t := e700955242218) (by decide)) (by decide)
def e700955242330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e700955242330 : Closed e700955242330 ∧ code e700955242330 = 9497048264538 := by decide
def e700955242346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e700955242346 : Closed e700955242346 ∧ code e700955242346 = 9497048264554 := by decide
private def t_e700955242346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem cert_e700955242346 : ¬ IsSelfInterpreter e700955242346 :=
  wSource (t := t_e700955242346) (replay_sound (ps := []) (t := e700955242346) (by decide)) (by decide)
def e700955243450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e700955243450 : Closed e700955243450 ∧ code e700955243450 = 9497048265658 := by decide
theorem cert_e700955243450 : check e700955243450 [[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e700955243482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e700955243482 : Closed e700955243482 ∧ code e700955243482 = 9497048265690 := by decide
theorem cert_e700955243482 : check e700955243482 [[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e700888049770
#print axioms Blc.Floor43.cert_e700888082538
#print axioms Blc.Floor43.cert_e700955242218
#print axioms Blc.Floor43.cert_e700955242346
