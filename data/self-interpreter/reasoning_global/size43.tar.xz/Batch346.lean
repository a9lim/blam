import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419141111606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419141111606 : Closed e2419141111606 ∧ code e2419141111606 = 11215234133814 := by decide
private def t_e2419141111606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem cert_e2419141111606 : ¬ IsSelfInterpreter e2419141111606 :=
  wSource (t := t_e2419141111606) (replay_sound (ps := []) (t := e2419141111606) (by decide)) (by decide)
def e2419141111610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419141111610 : Closed e2419141111610 ∧ code e2419141111610 = 11215234133818 := by decide
private def t_e2419141111610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem cert_e2419141111610 : ¬ IsSelfInterpreter e2419141111610 :=
  wSource (t := t_e2419141111610) (replay_sound (ps := []) (t := e2419141111610) (by decide)) (by decide)
def e2419141118830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2419141118830 : Closed e2419141118830 ∧ code e2419141118830 = 11215234141038 := by decide
theorem cert_e2419141118830 : check e2419141118830 [[],[]] .smaller = true := by decide
def e2419141118838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2419141118838 : Closed e2419141118838 ∧ code e2419141118838 = 11215234141046 := by decide
theorem cert_e2419141118838 : check e2419141118838 [[],[]] .smaller = true := by decide
def e2419141118894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2419141118894 : Closed e2419141118894 ∧ code e2419141118894 = 11215234141102 := by decide
theorem cert_e2419141118894 : check e2419141118894 [[],[]] .smaller = true := by decide
def e2419141118906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2419141118906 : Closed e2419141118906 ∧ code e2419141118906 = 11215234141114 := by decide
theorem cert_e2419141118906 : check e2419141118906 [[],[]] .smaller = true := by decide
def e2419141118934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2419141118934 : Closed e2419141118934 ∧ code e2419141118934 = 11215234141142 := by decide
theorem cert_e2419141118934 : check e2419141118934 [[],[]] .smaller = true := by decide
def e2419141118938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2419141118938 : Closed e2419141118938 ∧ code e2419141118938 = 11215234141146 := by decide
theorem cert_e2419141118938 : check e2419141118938 [[],[]] .smaller = true := by decide
def e2419141119214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2419141119214 : Closed e2419141119214 ∧ code e2419141119214 = 11215234141422 := by decide
theorem cert_e2419141119214 : check e2419141119214 [[],[]] .smaller = true := by decide
def e2419141119222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2419141119222 : Closed e2419141119222 ∧ code e2419141119222 = 11215234141430 := by decide
theorem cert_e2419141119222 : check e2419141119222 [[],[]] .smaller = true := by decide
def e2419141119598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2419141119598 : Closed e2419141119598 ∧ code e2419141119598 = 11215234141806 := by decide
theorem cert_e2419141119598 : check e2419141119598 [[],[]] .smaller = true := by decide
def e2419141119610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2419141119610 : Closed e2419141119610 ∧ code e2419141119610 = 11215234141818 := by decide
theorem cert_e2419141119610 : check e2419141119610 [[],[]] .smaller = true := by decide
def e2419141119798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2419141119798 : Closed e2419141119798 ∧ code e2419141119798 = 11215234142006 := by decide
theorem cert_e2419141119798 : check e2419141119798 [[],[]] .smaller = true := by decide
def e2419141119802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2419141119802 : Closed e2419141119802 ∧ code e2419141119802 = 11215234142010 := by decide
theorem cert_e2419141119802 : check e2419141119802 [[],[]] .smaller = true := by decide
def e2419141127614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2419141127614 : Closed e2419141127614 ∧ code e2419141127614 = 11215234149822 := by decide
theorem cert_e2419141127614 : check e2419141127614 [[],[]] .three = true := by decide
def e2419141127670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2419141127670 : Closed e2419141127670 ∧ code e2419141127670 = 11215234149878 := by decide
theorem cert_e2419141127670 : check e2419141127670 [[],[]] .three = true := by decide
def e2419141127870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2419141127870 : Closed e2419141127870 ∧ code e2419141127870 = 11215234150078 := by decide
theorem cert_e2419141127870 : check e2419141127870 [[],[]] .three = true := by decide
def e2419141127930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2419141127930 : Closed e2419141127930 ∧ code e2419141127930 = 11215234150138 := by decide
theorem cert_e2419141127930 : check e2419141127930 [[],[]] .three = true := by decide
def e2419141128150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2419141128150 : Closed e2419141128150 ∧ code e2419141128150 = 11215234150358 := by decide
theorem cert_e2419141128150 : check e2419141128150 [[],[]] .three = true := by decide
def e2419141128154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2419141128154 : Closed e2419141128154 ∧ code e2419141128154 = 11215234150362 := by decide
theorem cert_e2419141128154 : check e2419141128154 [[],[]] .three = true := by decide
def e2419141129150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2419141129150 : Closed e2419141129150 ∧ code e2419141129150 = 11215234151358 := by decide
theorem cert_e2419141129150 : check e2419141129150 [[],[]] .three = true := by decide
def e2419141129206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2419141129206 : Closed e2419141129206 ∧ code e2419141129206 = 11215234151414 := by decide
theorem cert_e2419141129206 : check e2419141129206 [[],[]] .three = true := by decide
def e2419141130686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2419141130686 : Closed e2419141130686 ∧ code e2419141130686 = 11215234152894 := by decide
theorem cert_e2419141130686 : check e2419141130686 [[],[]] .three = true := by decide
def e2419141130746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2419141130746 : Closed e2419141130746 ∧ code e2419141130746 = 11215234152954 := by decide
theorem cert_e2419141130746 : check e2419141130746 [[],[]] .three = true := by decide
def e2419141132086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419141132086 : Closed e2419141132086 ∧ code e2419141132086 = 11215234154294 := by decide
theorem cert_e2419141132086 : check e2419141132086 [[],[]] .three = true := by decide
def e2419141132090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419141132090 : Closed e2419141132090 ∧ code e2419141132090 = 11215234154298 := by decide
theorem cert_e2419141132090 : check e2419141132090 [[],[]] .three = true := by decide
def e2419141160302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2419141160302 : Closed e2419141160302 ∧ code e2419141160302 = 11215234182510 := by decide
theorem cert_e2419141160302 : check e2419141160302 [[],[]] .smaller = true := by decide
def e2419141160310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2419141160310 : Closed e2419141160310 ∧ code e2419141160310 = 11215234182518 := by decide
theorem cert_e2419141160310 : check e2419141160310 [[],[]] .smaller = true := by decide
def e2419141160366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2419141160366 : Closed e2419141160366 ∧ code e2419141160366 = 11215234182574 := by decide
theorem cert_e2419141160366 : check e2419141160366 [[],[]] .smaller = true := by decide
def e2419141160378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2419141160378 : Closed e2419141160378 ∧ code e2419141160378 = 11215234182586 := by decide
theorem cert_e2419141160378 : check e2419141160378 [[],[]] .smaller = true := by decide
def e2419141160406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2419141160406 : Closed e2419141160406 ∧ code e2419141160406 = 11215234182614 := by decide
theorem cert_e2419141160406 : check e2419141160406 [[],[]] .smaller = true := by decide
def e2419141160410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2419141160410 : Closed e2419141160410 ∧ code e2419141160410 = 11215234182618 := by decide
theorem cert_e2419141160410 : check e2419141160410 [[],[]] .smaller = true := by decide
def e2419141160622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2419141160622 : Closed e2419141160622 ∧ code e2419141160622 = 11215234182830 := by decide
theorem cert_e2419141160622 : check e2419141160622 [[],[]] .smaller = true := by decide
def e2419141160634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2419141160634 : Closed e2419141160634 ∧ code e2419141160634 = 11215234182842 := by decide
theorem cert_e2419141160634 : check e2419141160634 [[],[]] .smaller = true := by decide
def e2419141160682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2419141160682 : Closed e2419141160682 ∧ code e2419141160682 = 11215234182890 := by decide
theorem cert_e2419141160682 : check e2419141160682 [[],[]] .smaller = true := by decide
def e2419141160790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2419141160790 : Closed e2419141160790 ∧ code e2419141160790 = 11215234182998 := by decide
theorem cert_e2419141160790 : check e2419141160790 [[],[]] .smaller = true := by decide
def e2419141160794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2419141160794 : Closed e2419141160794 ∧ code e2419141160794 = 11215234183002 := by decide
theorem cert_e2419141160794 : check e2419141160794 [[],[]] .smaller = true := by decide
def e2419141160810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2419141160810 : Closed e2419141160810 ∧ code e2419141160810 = 11215234183018 := by decide
theorem cert_e2419141160810 : check e2419141160810 [[],[]] .smaller = true := by decide
def e2419141161438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2419141161438 : Closed e2419141161438 ∧ code e2419141161438 = 11215234183646 := by decide
theorem cert_e2419141161438 : check e2419141161438 [[],[]] .three = true := by decide
def e2419141161462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2419141161462 : Closed e2419141161462 ∧ code e2419141161462 = 11215234183670 := by decide
theorem cert_e2419141161462 : check e2419141161462 [[],[]] .three = true := by decide
def e2419141161838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2419141161838 : Closed e2419141161838 ∧ code e2419141161838 = 11215234184046 := by decide
theorem cert_e2419141161838 : check e2419141161838 [[],[]] .smaller = true := by decide
def e2419141161846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2419141161846 : Closed e2419141161846 ∧ code e2419141161846 = 11215234184054 := by decide
theorem cert_e2419141161846 : check e2419141161846 [[],[]] .smaller = true := by decide
def e2419141161902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2419141161902 : Closed e2419141161902 ∧ code e2419141161902 = 11215234184110 := by decide
theorem cert_e2419141161902 : check e2419141161902 [[],[]] .smaller = true := by decide
def e2419141161914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2419141161914 : Closed e2419141161914 ∧ code e2419141161914 = 11215234184122 := by decide
theorem cert_e2419141161914 : check e2419141161914 [[],[]] .smaller = true := by decide
def e2419141161942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2419141161942 : Closed e2419141161942 ∧ code e2419141161942 = 11215234184150 := by decide
theorem cert_e2419141161942 : check e2419141161942 [[],[]] .smaller = true := by decide
def e2419141161946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2419141161946 : Closed e2419141161946 ∧ code e2419141161946 = 11215234184154 := by decide
theorem cert_e2419141161946 : check e2419141161946 [[],[]] .smaller = true := by decide
def e2419141162222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419141162222 : Closed e2419141162222 ∧ code e2419141162222 = 11215234184430 := by decide
theorem cert_e2419141162222 : check e2419141162222 [[],[]] .smaller = true := by decide
def e2419141162230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419141162230 : Closed e2419141162230 ∧ code e2419141162230 = 11215234184438 := by decide
theorem cert_e2419141162230 : check e2419141162230 [[],[]] .smaller = true := by decide
def e2419141162558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2419141162558 : Closed e2419141162558 ∧ code e2419141162558 = 11215234184766 := by decide
theorem cert_e2419141162558 : check e2419141162558 [[],[]] .three = true := by decide
def e2419141162606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141162606 : Closed e2419141162606 ∧ code e2419141162606 = 11215234184814 := by decide
theorem cert_e2419141162606 : check e2419141162606 [[],[]] .smaller = true := by decide
def e2419141162618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141162618 : Closed e2419141162618 ∧ code e2419141162618 = 11215234184826 := by decide
theorem cert_e2419141162618 : check e2419141162618 [[],[]] .smaller = true := by decide
def e2419141162806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419141162806 : Closed e2419141162806 ∧ code e2419141162806 = 11215234185014 := by decide
theorem cert_e2419141162806 : check e2419141162806 [[],[]] .smaller = true := by decide
def e2419141162810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419141162810 : Closed e2419141162810 ∧ code e2419141162810 = 11215234185018 := by decide
theorem cert_e2419141162810 : check e2419141162810 [[],[]] .smaller = true := by decide
def e2419141162894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2419141162894 : Closed e2419141162894 ∧ code e2419141162894 = 11215234185102 := by decide
theorem cert_e2419141162894 : check e2419141162894 [[],[]] .three = true := by decide
def e2419141163230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2419141163230 : Closed e2419141163230 ∧ code e2419141163230 = 11215234185438 := by decide
theorem cert_e2419141163230 : check e2419141163230 [[],[]] .three = true := by decide
def e2419141163246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2419141163246 : Closed e2419141163246 ∧ code e2419141163246 = 11215234185454 := by decide
theorem cert_e2419141163246 : check e2419141163246 [[],[]] .smaller = true := by decide
def e2419141163254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2419141163254 : Closed e2419141163254 ∧ code e2419141163254 = 11215234185462 := by decide
theorem cert_e2419141163254 : check e2419141163254 [[],[]] .smaller = true := by decide
def e2419141163258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2419141163258 : Closed e2419141163258 ∧ code e2419141163258 = 11215234185466 := by decide
theorem cert_e2419141163258 : check e2419141163258 [[],[]] .three = true := by decide
def e2419141163438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2419141163438 : Closed e2419141163438 ∧ code e2419141163438 = 11215234185646 := by decide
theorem cert_e2419141163438 : check e2419141163438 [[],[]] .smaller = true := by decide
def e2419141163450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2419141163450 : Closed e2419141163450 ∧ code e2419141163450 = 11215234185658 := by decide
theorem cert_e2419141163450 : check e2419141163450 [[],[]] .smaller = true := by decide
def e2419141163498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2419141163498 : Closed e2419141163498 ∧ code e2419141163498 = 11215234185706 := by decide
theorem cert_e2419141163498 : check e2419141163498 [[],[]] .smaller = true := by decide
def e2419141163582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2419141163582 : Closed e2419141163582 ∧ code e2419141163582 = 11215234185790 := by decide
theorem cert_e2419141163582 : check e2419141163582 [[],[]] .three = true := by decide
def e2419141163630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141163630 : Closed e2419141163630 ∧ code e2419141163630 = 11215234185838 := by decide
theorem cert_e2419141163630 : check e2419141163630 [[],[]] .smaller = true := by decide
def e2419141163642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141163642 : Closed e2419141163642 ∧ code e2419141163642 = 11215234185850 := by decide
theorem cert_e2419141163642 : check e2419141163642 [[],[]] .smaller = true := by decide
def e2419141163806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2419141163806 : Closed e2419141163806 ∧ code e2419141163806 = 11215234186014 := by decide
theorem cert_e2419141163806 : check e2419141163806 [[],[]] .smaller = true := by decide
def e2419141163918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2419141163918 : Closed e2419141163918 ∧ code e2419141163918 = 11215234186126 := by decide
theorem cert_e2419141163918 : check e2419141163918 [[],[]] .smaller = true := by decide
def e2419141163930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141163930 : Closed e2419141163930 ∧ code e2419141163930 = 11215234186138 := by decide
theorem cert_e2419141163930 : check e2419141163930 [[],[]] .smaller = true := by decide
def e2419141163974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2419141163974 : Closed e2419141163974 ∧ code e2419141163974 = 11215234186182 := by decide
theorem cert_e2419141163974 : check e2419141163974 [[],[]] .three = true := by decide
def e2419141163998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e2419141163998 : Closed e2419141163998 ∧ code e2419141163998 = 11215234186206 := by decide
theorem cert_e2419141163998 : check e2419141163998 [[],[]] .three = true := by decide
def e2419141164150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2419141164150 : Closed e2419141164150 ∧ code e2419141164150 = 11215234186358 := by decide
theorem cert_e2419141164150 : check e2419141164150 [[],[]] .smaller = true := by decide
def e2419141164246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2419141164246 : Closed e2419141164246 ∧ code e2419141164246 = 11215234186454 := by decide
theorem cert_e2419141164246 : check e2419141164246 [[],[]] .smaller = true := by decide
def e2419141164250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2419141164250 : Closed e2419141164250 ∧ code e2419141164250 = 11215234186458 := by decide
theorem cert_e2419141164250 : check e2419141164250 [[],[]] .smaller = true := by decide
def e2419141164266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2419141164266 : Closed e2419141164266 ∧ code e2419141164266 = 11215234186474 := by decide
theorem cert_e2419141164266 : check e2419141164266 [[],[]] .smaller = true := by decide
def e2419141164342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419141164342 : Closed e2419141164342 ∧ code e2419141164342 = 11215234186550 := by decide
theorem cert_e2419141164342 : check e2419141164342 [[],[]] .smaller = true := by decide
def e2419141164346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419141164346 : Closed e2419141164346 ∧ code e2419141164346 = 11215234186554 := by decide
theorem cert_e2419141164346 : check e2419141164346 [[],[]] .smaller = true := by decide
def e2419141164430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2419141164430 : Closed e2419141164430 ∧ code e2419141164430 = 11215234186638 := by decide
theorem cert_e2419141164430 : check e2419141164430 [[],[]] .smaller = true := by decide
def e2419141164442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141164442 : Closed e2419141164442 ∧ code e2419141164442 = 11215234186650 := by decide
theorem cert_e2419141164442 : check e2419141164442 [[],[]] .smaller = true := by decide
def e2419141164510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2419141164510 : Closed e2419141164510 ∧ code e2419141164510 = 11215234186718 := by decide
theorem cert_e2419141164510 : check e2419141164510 [[],[]] .three = true := by decide
def e2419141164526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2419141164526 : Closed e2419141164526 ∧ code e2419141164526 = 11215234186734 := by decide
theorem cert_e2419141164526 : check e2419141164526 [[],[]] .three = true := by decide
def e2419141164598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2419141164598 : Closed e2419141164598 ∧ code e2419141164598 = 11215234186806 := by decide
theorem cert_e2419141164598 : check e2419141164598 [[],[]] .three = true := by decide
def e2419141164602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2419141164602 : Closed e2419141164602 ∧ code e2419141164602 = 11215234186810 := by decide
theorem cert_e2419141164602 : check e2419141164602 [[],[]] .three = true := by decide
def e2419141164686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2419141164686 : Closed e2419141164686 ∧ code e2419141164686 = 11215234186894 := by decide
theorem cert_e2419141164686 : check e2419141164686 [[],[]] .three = true := by decide
def e2419141164742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2419141164742 : Closed e2419141164742 ∧ code e2419141164742 = 11215234186950 := by decide
theorem cert_e2419141164742 : check e2419141164742 [[],[]] .three = true := by decide
def e2419141164766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e2419141164766 : Closed e2419141164766 ∧ code e2419141164766 = 11215234186974 := by decide
theorem cert_e2419141164766 : check e2419141164766 [[],[]] .three = true := by decide
def e2419141164782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2419141164782 : Closed e2419141164782 ∧ code e2419141164782 = 11215234186990 := by decide
theorem cert_e2419141164782 : check e2419141164782 [[],[]] .three = true := by decide
def e2419141164790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e2419141164790 : Closed e2419141164790 ∧ code e2419141164790 = 11215234186998 := by decide
theorem cert_e2419141164790 : check e2419141164790 [[],[]] .three = true := by decide
def e2419141166046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2419141166046 : Closed e2419141166046 ∧ code e2419141166046 = 11215234188254 := by decide
theorem cert_e2419141166046 : check e2419141166046 [[],[]] .smaller = true := by decide
def e2419141166062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2419141166062 : Closed e2419141166062 ∧ code e2419141166062 = 11215234188270 := by decide
theorem cert_e2419141166062 : check e2419141166062 [[],[]] .smaller = true := by decide
def e2419141167982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419141167982 : Closed e2419141167982 ∧ code e2419141167982 = 11215234190190 := by decide
theorem cert_e2419141167982 : check e2419141167982 [[],[]] .smaller = true := by decide
def e2419141167990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419141167990 : Closed e2419141167990 ∧ code e2419141167990 = 11215234190198 := by decide
theorem cert_e2419141167990 : check e2419141167990 [[],[]] .smaller = true := by decide
def e2419141168046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419141168046 : Closed e2419141168046 ∧ code e2419141168046 = 11215234190254 := by decide
theorem cert_e2419141168046 : check e2419141168046 [[],[]] .smaller = true := by decide
def e2419141168058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419141168058 : Closed e2419141168058 ∧ code e2419141168058 = 11215234190266 := by decide
theorem cert_e2419141168058 : check e2419141168058 [[],[]] .smaller = true := by decide
def e2419141168086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419141168086 : Closed e2419141168086 ∧ code e2419141168086 = 11215234190294 := by decide
theorem cert_e2419141168086 : check e2419141168086 [[],[]] .smaller = true := by decide
def e2419141168090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419141168090 : Closed e2419141168090 ∧ code e2419141168090 = 11215234190298 := by decide
theorem cert_e2419141168090 : check e2419141168090 [[],[]] .smaller = true := by decide
def e2419141168366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419141168366 : Closed e2419141168366 ∧ code e2419141168366 = 11215234190574 := by decide
theorem cert_e2419141168366 : check e2419141168366 [[],[]] .smaller = true := by decide
def e2419141168374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419141168374 : Closed e2419141168374 ∧ code e2419141168374 = 11215234190582 := by decide
theorem cert_e2419141168374 : check e2419141168374 [[],[]] .smaller = true := by decide
def e2419141168702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2419141168702 : Closed e2419141168702 ∧ code e2419141168702 = 11215234190910 := by decide
theorem cert_e2419141168702 : check e2419141168702 [[],[]] .three = true := by decide
def e2419141168750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419141168750 : Closed e2419141168750 ∧ code e2419141168750 = 11215234190958 := by decide
theorem cert_e2419141168750 : check e2419141168750 [[],[]] .smaller = true := by decide
def e2419141168762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419141168762 : Closed e2419141168762 ∧ code e2419141168762 = 11215234190970 := by decide
theorem cert_e2419141168762 : check e2419141168762 [[],[]] .smaller = true := by decide
def e2419141168950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419141168950 : Closed e2419141168950 ∧ code e2419141168950 = 11215234191158 := by decide
theorem cert_e2419141168950 : check e2419141168950 [[],[]] .smaller = true := by decide
def e2419141168954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419141168954 : Closed e2419141168954 ∧ code e2419141168954 = 11215234191162 := by decide
theorem cert_e2419141168954 : check e2419141168954 [[],[]] .smaller = true := by decide
def e2419141169038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2419141169038 : Closed e2419141169038 ∧ code e2419141169038 = 11215234191246 := by decide
theorem cert_e2419141169038 : check e2419141169038 [[],[]] .three = true := by decide
def e2419141173726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2419141173726 : Closed e2419141173726 ∧ code e2419141173726 = 11215234195934 := by decide
theorem cert_e2419141173726 : check e2419141173726 [[],[]] .smaller = true := by decide
def e2419141173750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2419141173750 : Closed e2419141173750 ∧ code e2419141173750 = 11215234195958 := by decide
theorem cert_e2419141173750 : check e2419141173750 [[],[]] .smaller = true := by decide
def e2419141174702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2419141174702 : Closed e2419141174702 ∧ code e2419141174702 = 11215234196910 := by decide
theorem cert_e2419141174702 : check e2419141174702 [[],[]] .smaller = true := by decide
def e2419141174714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2419141174714 : Closed e2419141174714 ∧ code e2419141174714 = 11215234196922 := by decide
theorem cert_e2419141174714 : check e2419141174714 [[],[]] .smaller = true := by decide
def e2419141174762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2419141174762 : Closed e2419141174762 ∧ code e2419141174762 = 11215234196970 := by decide
theorem cert_e2419141174762 : check e2419141174762 [[],[]] .smaller = true := by decide
def e2419141174846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2419141174846 : Closed e2419141174846 ∧ code e2419141174846 = 11215234197054 := by decide
theorem cert_e2419141174846 : check e2419141174846 [[],[]] .three = true := by decide
def e2419141174894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419141174894 : Closed e2419141174894 ∧ code e2419141174894 = 11215234197102 := by decide
theorem cert_e2419141174894 : check e2419141174894 [[],[]] .smaller = true := by decide
def e2419141174906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419141174906 : Closed e2419141174906 ∧ code e2419141174906 = 11215234197114 := by decide
theorem cert_e2419141174906 : check e2419141174906 [[],[]] .smaller = true := by decide
def e2419141175070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2419141175070 : Closed e2419141175070 ∧ code e2419141175070 = 11215234197278 := by decide
theorem cert_e2419141175070 : check e2419141175070 [[],[]] .smaller = true := by decide
def e2419141175182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2419141175182 : Closed e2419141175182 ∧ code e2419141175182 = 11215234197390 := by decide
theorem cert_e2419141175182 : check e2419141175182 [[],[]] .smaller = true := by decide
def e2419141175194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419141175194 : Closed e2419141175194 ∧ code e2419141175194 = 11215234197402 := by decide
theorem cert_e2419141175194 : check e2419141175194 [[],[]] .smaller = true := by decide
def e2419141175238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2419141175238 : Closed e2419141175238 ∧ code e2419141175238 = 11215234197446 := by decide
theorem cert_e2419141175238 : check e2419141175238 [[],[]] .three = true := by decide
def e2419141175262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e2419141175262 : Closed e2419141175262 ∧ code e2419141175262 = 11215234197470 := by decide
theorem cert_e2419141175262 : check e2419141175262 [[],[]] .three = true := by decide
def e2419141177582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2419141177582 : Closed e2419141177582 ∧ code e2419141177582 = 11215234199790 := by decide
theorem cert_e2419141177582 : check e2419141177582 [[],[]] .smaller = true := by decide
def e2419141177590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2419141177590 : Closed e2419141177590 ∧ code e2419141177590 = 11215234199798 := by decide
theorem cert_e2419141177590 : check e2419141177590 [[],[]] .smaller = true := by decide
def e2419141178070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2419141178070 : Closed e2419141178070 ∧ code e2419141178070 = 11215234200278 := by decide
theorem cert_e2419141178070 : check e2419141178070 [[],[]] .smaller = true := by decide
def e2419141178074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2419141178074 : Closed e2419141178074 ∧ code e2419141178074 = 11215234200282 := by decide
theorem cert_e2419141178074 : check e2419141178074 [[],[]] .smaller = true := by decide
def e2419141178090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2419141178090 : Closed e2419141178090 ∧ code e2419141178090 = 11215234200298 := by decide
theorem cert_e2419141178090 : check e2419141178090 [[],[]] .smaller = true := by decide
def e2419141178166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419141178166 : Closed e2419141178166 ∧ code e2419141178166 = 11215234200374 := by decide
theorem cert_e2419141178166 : check e2419141178166 [[],[]] .smaller = true := by decide
def e2419141178170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419141178170 : Closed e2419141178170 ∧ code e2419141178170 = 11215234200378 := by decide
theorem cert_e2419141178170 : check e2419141178170 [[],[]] .smaller = true := by decide
def e2419141178254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2419141178254 : Closed e2419141178254 ∧ code e2419141178254 = 11215234200462 := by decide
theorem cert_e2419141178254 : check e2419141178254 [[],[]] .smaller = true := by decide
def e2419141178266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419141178266 : Closed e2419141178266 ∧ code e2419141178266 = 11215234200474 := by decide
theorem cert_e2419141178266 : check e2419141178266 [[],[]] .smaller = true := by decide
def e2419141178334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419141178334 : Closed e2419141178334 ∧ code e2419141178334 = 11215234200542 := by decide
theorem cert_e2419141178334 : check e2419141178334 [[],[]] .three = true := by decide
def e2419141178350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419141178350 : Closed e2419141178350 ∧ code e2419141178350 = 11215234200558 := by decide
theorem cert_e2419141178350 : check e2419141178350 [[],[]] .three = true := by decide
def e2419141179790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2419141179790 : Closed e2419141179790 ∧ code e2419141179790 = 11215234201998 := by decide
theorem cert_e2419141179790 : check e2419141179790 [[],[]] .three = true := by decide
def e2419141179846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2419141179846 : Closed e2419141179846 ∧ code e2419141179846 = 11215234202054 := by decide
theorem cert_e2419141179846 : check e2419141179846 [[],[]] .three = true := by decide
def e2419141179870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419141179870 : Closed e2419141179870 ∧ code e2419141179870 = 11215234202078 := by decide
theorem cert_e2419141179870 : check e2419141179870 [[],[]] .three = true := by decide
def e2419141179886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419141179886 : Closed e2419141179886 ∧ code e2419141179886 = 11215234202094 := by decide
theorem cert_e2419141179886 : check e2419141179886 [[],[]] .three = true := by decide
def e2419141179894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419141179894 : Closed e2419141179894 ∧ code e2419141179894 = 11215234202102 := by decide
theorem cert_e2419141179894 : check e2419141179894 [[],[]] .three = true := by decide
def e2419141269166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2419141269166 : Closed e2419141269166 ∧ code e2419141269166 = 11215234291374 := by decide
theorem cert_e2419141269166 : check e2419141269166 [[],[]] .smaller = true := by decide
def e2419141269178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2419141269178 : Closed e2419141269178 ∧ code e2419141269178 = 11215234291386 := by decide
theorem cert_e2419141269178 : check e2419141269178 [[],[]] .smaller = true := by decide
def e2419141269226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2419141269226 : Closed e2419141269226 ∧ code e2419141269226 = 11215234291434 := by decide
theorem cert_e2419141269226 : check e2419141269226 [[],[]] .smaller = true := by decide
def e2419141269418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2419141269418 : Closed e2419141269418 ∧ code e2419141269418 = 11215234291626 := by decide
theorem cert_e2419141269418 : check e2419141269418 [[],[]] .smaller = true := by decide
def e2419141269726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2419141269726 : Closed e2419141269726 ∧ code e2419141269726 = 11215234291934 := by decide
theorem cert_e2419141269726 : check e2419141269726 [[],[]] .three = true := by decide
def e2419141269742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2419141269742 : Closed e2419141269742 ∧ code e2419141269742 = 11215234291950 := by decide
theorem cert_e2419141269742 : check e2419141269742 [[],[]] .smaller = true := by decide
def e2419141269750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2419141269750 : Closed e2419141269750 ∧ code e2419141269750 = 11215234291958 := by decide
theorem cert_e2419141269750 : check e2419141269750 [[],[]] .smaller = true := by decide
def e2419141269754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2419141269754 : Closed e2419141269754 ∧ code e2419141269754 = 11215234291962 := by decide
theorem cert_e2419141269754 : check e2419141269754 [[],[]] .three = true := by decide
def e2419141269934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2419141269934 : Closed e2419141269934 ∧ code e2419141269934 = 11215234292142 := by decide
theorem cert_e2419141269934 : check e2419141269934 [[],[]] .smaller = true := by decide
def e2419141269946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2419141269946 : Closed e2419141269946 ∧ code e2419141269946 = 11215234292154 := by decide
theorem cert_e2419141269946 : check e2419141269946 [[],[]] .smaller = true := by decide
def e2419141269994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2419141269994 : Closed e2419141269994 ∧ code e2419141269994 = 11215234292202 := by decide
theorem cert_e2419141269994 : check e2419141269994 [[],[]] .smaller = true := by decide
def e2419141270078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2419141270078 : Closed e2419141270078 ∧ code e2419141270078 = 11215234292286 := by decide
theorem cert_e2419141270078 : check e2419141270078 [[],[]] .three = true := by decide
def e2419141270126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141270126 : Closed e2419141270126 ∧ code e2419141270126 = 11215234292334 := by decide
theorem cert_e2419141270126 : check e2419141270126 [[],[]] .smaller = true := by decide
def e2419141270138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141270138 : Closed e2419141270138 ∧ code e2419141270138 = 11215234292346 := by decide
theorem cert_e2419141270138 : check e2419141270138 [[],[]] .smaller = true := by decide
def e2419141270302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2419141270302 : Closed e2419141270302 ∧ code e2419141270302 = 11215234292510 := by decide
theorem cert_e2419141270302 : check e2419141270302 [[],[]] .smaller = true := by decide
def e2419141270414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2419141270414 : Closed e2419141270414 ∧ code e2419141270414 = 11215234292622 := by decide
theorem cert_e2419141270414 : check e2419141270414 [[],[]] .smaller = true := by decide
def e2419141270426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141270426 : Closed e2419141270426 ∧ code e2419141270426 = 11215234292634 := by decide
theorem cert_e2419141270426 : check e2419141270426 [[],[]] .smaller = true := by decide
def e2419141270470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2419141270470 : Closed e2419141270470 ∧ code e2419141270470 = 11215234292678 := by decide
theorem cert_e2419141270470 : check e2419141270470 [[],[]] .three = true := by decide
def e2419141270494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e2419141270494 : Closed e2419141270494 ∧ code e2419141270494 = 11215234292702 := by decide
theorem cert_e2419141270494 : check e2419141270494 [[],[]] .three = true := by decide
def e2419141270638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2419141270638 : Closed e2419141270638 ∧ code e2419141270638 = 11215234292846 := by decide
theorem cert_e2419141270638 : check e2419141270638 [[],[]] .smaller = true := by decide
def e2419141270650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2419141270650 : Closed e2419141270650 ∧ code e2419141270650 = 11215234292858 := by decide
theorem cert_e2419141270650 : check e2419141270650 [[],[]] .smaller = true := by decide
def e2419141270814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2419141270814 : Closed e2419141270814 ∧ code e2419141270814 = 11215234293022 := by decide
theorem cert_e2419141270814 : check e2419141270814 [[],[]] .smaller = true := by decide
def e2419141270982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2419141270982 : Closed e2419141270982 ∧ code e2419141270982 = 11215234293190 := by decide
theorem cert_e2419141270982 : check e2419141270982 [[],[]] .smaller = true := by decide
def e2419141271006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2419141271006 : Closed e2419141271006 ∧ code e2419141271006 = 11215234293214 := by decide
theorem cert_e2419141271006 : check e2419141271006 [[],[]] .three = true := by decide
def e2419141271022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2419141271022 : Closed e2419141271022 ∧ code e2419141271022 = 11215234293230 := by decide
theorem cert_e2419141271022 : check e2419141271022 [[],[]] .three = true := by decide
def e2419141271094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2419141271094 : Closed e2419141271094 ∧ code e2419141271094 = 11215234293302 := by decide
theorem cert_e2419141271094 : check e2419141271094 [[],[]] .smaller = true := by decide
def e2419141271098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2419141271098 : Closed e2419141271098 ∧ code e2419141271098 = 11215234293306 := by decide
theorem cert_e2419141271098 : check e2419141271098 [[],[]] .smaller = true := by decide
def e2419141271146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2419141271146 : Closed e2419141271146 ∧ code e2419141271146 = 11215234293354 := by decide
theorem cert_e2419141271146 : check e2419141271146 [[],[]] .smaller = true := by decide
def e2419141271182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2419141271182 : Closed e2419141271182 ∧ code e2419141271182 = 11215234293390 := by decide
theorem cert_e2419141271182 : check e2419141271182 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419141111606
#print axioms Blc.Floor43.cert_e2419141111610
