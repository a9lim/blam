import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411725274310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411725274310 : Closed e2411725274310 ∧ code e2411725274310 = 11207818296518 := by decide
theorem cert_e2411725274310 : check e2411725274310 [[],[],[]] .smaller = true := by decide
def e2411725293342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411725293342 : Closed e2411725293342 ∧ code e2411725293342 = 11207818315550 := by decide
theorem cert_e2411725293342 : check e2411725293342 [[],[],[]] .smaller = true := by decide
def e2411725293454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411725293454 : Closed e2411725293454 ∧ code e2411725293454 = 11207818315662 := by decide
theorem cert_e2411725293454 : check e2411725293454 [[],[],[]] .smaller = true := by decide
def e2411725297206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411725297206 : Closed e2411725297206 ∧ code e2411725297206 = 11207818319414 := by decide
theorem cert_e2411725297206 : check e2411725297206 [[],[],[]] .smaller = true := by decide
def e2411725297210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411725297210 : Closed e2411725297210 ∧ code e2411725297210 = 11207818319418 := by decide
theorem cert_e2411725297210 : check e2411725297210 [[],[],[]] .smaller = true := by decide
def e2411725297294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411725297294 : Closed e2411725297294 ∧ code e2411725297294 = 11207818319502 := by decide
theorem cert_e2411725297294 : check e2411725297294 [[],[],[]] .smaller = true := by decide
def e2411725297350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411725297350 : Closed e2411725297350 ∧ code e2411725297350 = 11207818319558 := by decide
theorem cert_e2411725297350 : check e2411725297350 [[],[],[]] .smaller = true := by decide
def e2411725297434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411725297434 : Closed e2411725297434 ∧ code e2411725297434 = 11207818319642 := by decide
theorem cert_e2411725297434 : check e2411725297434 [[],[],[]] .smaller = true := by decide
def e2411725297478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411725297478 : Closed e2411725297478 ∧ code e2411725297478 = 11207818319686 := by decide
theorem cert_e2411725297478 : check e2411725297478 [[],[],[]] .smaller = true := by decide
def e2411725297774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2411725297774 : Closed e2411725297774 ∧ code e2411725297774 = 11207818319982 := by decide
theorem cert_e2411725297774 : check e2411725297774 [[],[],[]] .smaller = true := by decide
def e2411725297786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2411725297786 : Closed e2411725297786 ∧ code e2411725297786 = 11207818319994 := by decide
theorem cert_e2411725297786 : check e2411725297786 [[],[],[]] .smaller = true := by decide
def e2411725298062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411725298062 : Closed e2411725298062 ∧ code e2411725298062 = 11207818320270 := by decide
theorem cert_e2411725298062 : check e2411725298062 [[],[],[]] .smaller = true := by decide
def e2411725298118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411725298118 : Closed e2411725298118 ∧ code e2411725298118 = 11207818320326 := by decide
theorem cert_e2411725298118 : check e2411725298118 [[],[],[]] .smaller = true := by decide
def e2411725298742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411725298742 : Closed e2411725298742 ∧ code e2411725298742 = 11207818320950 := by decide
theorem cert_e2411725298742 : check e2411725298742 [[],[],[]] .smaller = true := by decide
def e2411725298746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411725298746 : Closed e2411725298746 ∧ code e2411725298746 = 11207818320954 := by decide
theorem cert_e2411725298746 : check e2411725298746 [[],[],[]] .smaller = true := by decide
def e2411725298886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411725298886 : Closed e2411725298886 ∧ code e2411725298886 = 11207818321094 := by decide
theorem cert_e2411725298886 : check e2411725298886 [[],[],[]] .smaller = true := by decide
def e2411726378718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411726378718 : Closed e2411726378718 ∧ code e2411726378718 = 11207819400926 := by decide
theorem cert_e2411726378718 : check e2411726378718 [[],[],[]] .smaller = true := by decide
def e2411726378742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411726378742 : Closed e2411726378742 ∧ code e2411726378742 = 11207819400950 := by decide
theorem cert_e2411726378742 : check e2411726378742 [[],[],[]] .smaller = true := by decide
def e2411726378846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411726378846 : Closed e2411726378846 ∧ code e2411726378846 = 11207819401054 := by decide
theorem cert_e2411726378846 : check e2411726378846 [[],[],[]] .smaller = true := by decide
def e2411726378874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411726378874 : Closed e2411726378874 ∧ code e2411726378874 = 11207819401082 := by decide
theorem cert_e2411726378874 : check e2411726378874 [[],[],[]] .smaller = true := by decide
def e2411726378966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411726378966 : Closed e2411726378966 ∧ code e2411726378966 = 11207819401174 := by decide
theorem cert_e2411726378966 : check e2411726378966 [[],[],[]] .smaller = true := by decide
def e2411726378970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411726378970 : Closed e2411726378970 ∧ code e2411726378970 = 11207819401178 := by decide
theorem cert_e2411726378970 : check e2411726378970 [[],[],[]] .smaller = true := by decide
def e2411726379486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411726379486 : Closed e2411726379486 ∧ code e2411726379486 = 11207819401694 := by decide
theorem cert_e2411726379486 : check e2411726379486 [[],[],[]] .smaller = true := by decide
def e2411726379510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411726379510 : Closed e2411726379510 ∧ code e2411726379510 = 11207819401718 := by decide
theorem cert_e2411726379510 : check e2411726379510 [[],[],[]] .smaller = true := by decide
def e2411726380254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411726380254 : Closed e2411726380254 ∧ code e2411726380254 = 11207819402462 := by decide
theorem cert_e2411726380254 : check e2411726380254 [[],[],[]] .smaller = true := by decide
def e2411726380282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411726380282 : Closed e2411726380282 ∧ code e2411726380282 = 11207819402490 := by decide
theorem cert_e2411726380282 : check e2411726380282 [[],[],[]] .smaller = true := by decide
def e2411726380854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411726380854 : Closed e2411726380854 ∧ code e2411726380854 = 11207819403062 := by decide
theorem cert_e2411726380854 : check e2411726380854 [[],[],[]] .smaller = true := by decide
def e2411726380858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411726380858 : Closed e2411726380858 ∧ code e2411726380858 = 11207819403066 := by decide
theorem cert_e2411726380858 : check e2411726380858 [[],[],[]] .smaller = true := by decide
def e2411726395630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411726395630 : Closed e2411726395630 ∧ code e2411726395630 = 11207819417838 := by decide
theorem cert_e2411726395630 : check e2411726395630 [[],[],[]] .smaller = true := by decide
def e2411726395638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411726395638 : Closed e2411726395638 ∧ code e2411726395638 = 11207819417846 := by decide
theorem cert_e2411726395638 : check e2411726395638 [[],[],[]] .smaller = true := by decide
def e2411726396190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411726396190 : Closed e2411726396190 ∧ code e2411726396190 = 11207819418398 := by decide
theorem cert_e2411726396190 : check e2411726396190 [[],[],[]] .smaller = true := by decide
def e2411726396302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411726396302 : Closed e2411726396302 ∧ code e2411726396302 = 11207819418510 := by decide
theorem cert_e2411726396302 : check e2411726396302 [[],[],[]] .smaller = true := by decide
def e2411726396526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411726396526 : Closed e2411726396526 ∧ code e2411726396526 = 11207819418734 := by decide
theorem cert_e2411726396526 : check e2411726396526 [[],[],[]] .smaller = true := by decide
def e2411726396538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411726396538 : Closed e2411726396538 ∧ code e2411726396538 = 11207819418746 := by decide
theorem cert_e2411726396538 : check e2411726396538 [[],[],[]] .smaller = true := by decide
def e2411726396702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411726396702 : Closed e2411726396702 ∧ code e2411726396702 = 11207819418910 := by decide
theorem cert_e2411726396702 : check e2411726396702 [[],[],[]] .smaller = true := by decide
def e2411726396870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411726396870 : Closed e2411726396870 ∧ code e2411726396870 = 11207819419078 := by decide
theorem cert_e2411726396870 : check e2411726396870 [[],[],[]] .smaller = true := by decide
def e2411726396982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411726396982 : Closed e2411726396982 ∧ code e2411726396982 = 11207819419190 := by decide
theorem cert_e2411726396982 : check e2411726396982 [[],[],[]] .smaller = true := by decide
def e2411726396986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411726396986 : Closed e2411726396986 ∧ code e2411726396986 = 11207819419194 := by decide
theorem cert_e2411726396986 : check e2411726396986 [[],[],[]] .smaller = true := by decide
def e2411726397070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411726397070 : Closed e2411726397070 ∧ code e2411726397070 = 11207819419278 := by decide
theorem cert_e2411726397070 : check e2411726397070 [[],[],[]] .smaller = true := by decide
def e2411726397126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411726397126 : Closed e2411726397126 ∧ code e2411726397126 = 11207819419334 := by decide
theorem cert_e2411726397126 : check e2411726397126 [[],[],[]] .smaller = true := by decide
def e2411726399262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411726399262 : Closed e2411726399262 ∧ code e2411726399262 = 11207819421470 := by decide
theorem cert_e2411726399262 : check e2411726399262 [[],[],[]] .smaller = true := by decide
def e2411726399374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411726399374 : Closed e2411726399374 ∧ code e2411726399374 = 11207819421582 := by decide
theorem cert_e2411726399374 : check e2411726399374 [[],[],[]] .smaller = true := by decide
def e2411726402334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411726402334 : Closed e2411726402334 ∧ code e2411726402334 = 11207819424542 := by decide
theorem cert_e2411726402334 : check e2411726402334 [[],[],[]] .smaller = true := by decide
def e2411726402502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411726402502 : Closed e2411726402502 ∧ code e2411726402502 = 11207819424710 := by decide
theorem cert_e2411726402502 : check e2411726402502 [[],[],[]] .smaller = true := by decide
def e2411726403982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411726403982 : Closed e2411726403982 ∧ code e2411726403982 = 11207819426190 := by decide
theorem cert_e2411726403982 : check e2411726403982 [[],[],[]] .smaller = true := by decide
def e2411726404038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411726404038 : Closed e2411726404038 ∧ code e2411726404038 = 11207819426246 := by decide
theorem cert_e2411726404038 : check e2411726404038 [[],[],[]] .smaller = true := by decide
def e2411726637934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411726637934 : Closed e2411726637934 ∧ code e2411726637934 = 11207819660142 := by decide
theorem cert_e2411726637934 : check e2411726637934 [[],[],[]] .smaller = true := by decide
def e2411726637942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411726637942 : Closed e2411726637942 ∧ code e2411726637942 = 11207819660150 := by decide
theorem cert_e2411726637942 : check e2411726637942 [[],[],[]] .smaller = true := by decide
def e2411726637998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411726637998 : Closed e2411726637998 ∧ code e2411726637998 = 11207819660206 := by decide
theorem cert_e2411726637998 : check e2411726637998 [[],[],[]] .smaller = true := by decide
def e2411726638010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411726638010 : Closed e2411726638010 ∧ code e2411726638010 = 11207819660218 := by decide
theorem cert_e2411726638010 : check e2411726638010 [[],[],[]] .smaller = true := by decide
def e2411726638038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411726638038 : Closed e2411726638038 ∧ code e2411726638038 = 11207819660246 := by decide
theorem cert_e2411726638038 : check e2411726638038 [[],[],[]] .smaller = true := by decide
def e2411726638042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411726638042 : Closed e2411726638042 ∧ code e2411726638042 = 11207819660250 := by decide
theorem cert_e2411726638042 : check e2411726638042 [[],[],[]] .smaller = true := by decide
def e2411726638318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411726638318 : Closed e2411726638318 ∧ code e2411726638318 = 11207819660526 := by decide
theorem cert_e2411726638318 : check e2411726638318 [[],[],[]] .smaller = true := by decide
def e2411726638326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411726638326 : Closed e2411726638326 ∧ code e2411726638326 = 11207819660534 := by decide
theorem cert_e2411726638326 : check e2411726638326 [[],[],[]] .smaller = true := by decide
def e2411726638702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411726638702 : Closed e2411726638702 ∧ code e2411726638702 = 11207819660910 := by decide
theorem cert_e2411726638702 : check e2411726638702 [[],[],[]] .smaller = true := by decide
def e2411726638714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411726638714 : Closed e2411726638714 ∧ code e2411726638714 = 11207819660922 := by decide
theorem cert_e2411726638714 : check e2411726638714 [[],[],[]] .smaller = true := by decide
def e2411726638902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411726638902 : Closed e2411726638902 ∧ code e2411726638902 = 11207819661110 := by decide
theorem cert_e2411726638902 : check e2411726638902 [[],[],[]] .smaller = true := by decide
def e2411726638906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411726638906 : Closed e2411726638906 ∧ code e2411726638906 = 11207819661114 := by decide
theorem cert_e2411726638906 : check e2411726638906 [[],[],[]] .smaller = true := by decide
def e2411731097310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411731097310 : Closed e2411731097310 ∧ code e2411731097310 = 11207824119518 := by decide
theorem cert_e2411731097310 : check e2411731097310 [[],[],[]] .smaller = true := by decide
def e2411731097334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411731097334 : Closed e2411731097334 ∧ code e2411731097334 = 11207824119542 := by decide
theorem cert_e2411731097334 : check e2411731097334 [[],[],[]] .smaller = true := by decide
def e2411731097438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411731097438 : Closed e2411731097438 ∧ code e2411731097438 = 11207824119646 := by decide
theorem cert_e2411731097438 : check e2411731097438 [[],[],[]] .smaller = true := by decide
def e2411731097466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411731097466 : Closed e2411731097466 ∧ code e2411731097466 = 11207824119674 := by decide
theorem cert_e2411731097466 : check e2411731097466 [[],[],[]] .smaller = true := by decide
def e2411731097558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411731097558 : Closed e2411731097558 ∧ code e2411731097558 = 11207824119766 := by decide
theorem cert_e2411731097558 : check e2411731097558 [[],[],[]] .smaller = true := by decide
def e2411731097562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411731097562 : Closed e2411731097562 ∧ code e2411731097562 = 11207824119770 := by decide
theorem cert_e2411731097562 : check e2411731097562 [[],[],[]] .smaller = true := by decide
def e2411731098078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411731098078 : Closed e2411731098078 ∧ code e2411731098078 = 11207824120286 := by decide
theorem cert_e2411731098078 : check e2411731098078 [[],[],[]] .smaller = true := by decide
def e2411731098102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411731098102 : Closed e2411731098102 ∧ code e2411731098102 = 11207824120310 := by decide
theorem cert_e2411731098102 : check e2411731098102 [[],[],[]] .smaller = true := by decide
def e2411731098846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411731098846 : Closed e2411731098846 ∧ code e2411731098846 = 11207824121054 := by decide
theorem cert_e2411731098846 : check e2411731098846 [[],[],[]] .smaller = true := by decide
def e2411731098874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411731098874 : Closed e2411731098874 ∧ code e2411731098874 = 11207824121082 := by decide
theorem cert_e2411731098874 : check e2411731098874 [[],[],[]] .smaller = true := by decide
def e2411731099446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411731099446 : Closed e2411731099446 ∧ code e2411731099446 = 11207824121654 := by decide
theorem cert_e2411731099446 : check e2411731099446 [[],[],[]] .smaller = true := by decide
def e2411731099450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411731099450 : Closed e2411731099450 ∧ code e2411731099450 = 11207824121658 := by decide
theorem cert_e2411731099450 : check e2411731099450 [[],[],[]] .smaller = true := by decide
def e2411731114222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411731114222 : Closed e2411731114222 ∧ code e2411731114222 = 11207824136430 := by decide
theorem cert_e2411731114222 : check e2411731114222 [[],[],[]] .smaller = true := by decide
def e2411731114230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411731114230 : Closed e2411731114230 ∧ code e2411731114230 = 11207824136438 := by decide
theorem cert_e2411731114230 : check e2411731114230 [[],[],[]] .smaller = true := by decide
def e2411731114782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411731114782 : Closed e2411731114782 ∧ code e2411731114782 = 11207824136990 := by decide
theorem cert_e2411731114782 : check e2411731114782 [[],[],[]] .smaller = true := by decide
def e2411731114894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411731114894 : Closed e2411731114894 ∧ code e2411731114894 = 11207824137102 := by decide
theorem cert_e2411731114894 : check e2411731114894 [[],[],[]] .smaller = true := by decide
def e2411731115118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411731115118 : Closed e2411731115118 ∧ code e2411731115118 = 11207824137326 := by decide
theorem cert_e2411731115118 : check e2411731115118 [[],[],[]] .smaller = true := by decide
def e2411731115130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411731115130 : Closed e2411731115130 ∧ code e2411731115130 = 11207824137338 := by decide
theorem cert_e2411731115130 : check e2411731115130 [[],[],[]] .smaller = true := by decide
def e2411731115294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411731115294 : Closed e2411731115294 ∧ code e2411731115294 = 11207824137502 := by decide
theorem cert_e2411731115294 : check e2411731115294 [[],[],[]] .smaller = true := by decide
def e2411731115462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411731115462 : Closed e2411731115462 ∧ code e2411731115462 = 11207824137670 := by decide
theorem cert_e2411731115462 : check e2411731115462 [[],[],[]] .smaller = true := by decide
def e2411731115574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411731115574 : Closed e2411731115574 ∧ code e2411731115574 = 11207824137782 := by decide
theorem cert_e2411731115574 : check e2411731115574 [[],[],[]] .smaller = true := by decide
def e2411731115578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411731115578 : Closed e2411731115578 ∧ code e2411731115578 = 11207824137786 := by decide
theorem cert_e2411731115578 : check e2411731115578 [[],[],[]] .smaller = true := by decide
def e2411731115662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411731115662 : Closed e2411731115662 ∧ code e2411731115662 = 11207824137870 := by decide
theorem cert_e2411731115662 : check e2411731115662 [[],[],[]] .smaller = true := by decide
def e2411731115718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411731115718 : Closed e2411731115718 ∧ code e2411731115718 = 11207824137926 := by decide
theorem cert_e2411731115718 : check e2411731115718 [[],[],[]] .smaller = true := by decide
def e2411731117854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411731117854 : Closed e2411731117854 ∧ code e2411731117854 = 11207824140062 := by decide
theorem cert_e2411731117854 : check e2411731117854 [[],[],[]] .smaller = true := by decide
def e2411731117966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411731117966 : Closed e2411731117966 ∧ code e2411731117966 = 11207824140174 := by decide
theorem cert_e2411731117966 : check e2411731117966 [[],[],[]] .smaller = true := by decide
def e2411731120926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411731120926 : Closed e2411731120926 ∧ code e2411731120926 = 11207824143134 := by decide
theorem cert_e2411731120926 : check e2411731120926 [[],[],[]] .smaller = true := by decide
def e2411731121094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411731121094 : Closed e2411731121094 ∧ code e2411731121094 = 11207824143302 := by decide
theorem cert_e2411731121094 : check e2411731121094 [[],[],[]] .smaller = true := by decide
def e2411731122574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411731122574 : Closed e2411731122574 ∧ code e2411731122574 = 11207824144782 := by decide
theorem cert_e2411731122574 : check e2411731122574 [[],[],[]] .smaller = true := by decide
def e2411731122630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411731122630 : Closed e2411731122630 ∧ code e2411731122630 = 11207824144838 := by decide
theorem cert_e2411731122630 : check e2411731122630 [[],[],[]] .smaller = true := by decide
def e2416995842586 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416995842586 : Closed e2416995842586 ∧ code e2416995842586 = 11213088864794 := by decide
private def t_e2416995842586 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))
theorem cert_e2416995842586 : ¬ IsSelfInterpreter e2416995842586 :=
  wSource (t := t_e2416995842586) (replay_sound (ps := [[],[],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left]]) (t := e2416995842586) (by decide)) (by decide)
def e2416995850778 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416995850778 : Closed e2416995850778 ∧ code e2416995850778 = 11213088872986 := by decide
theorem cert_e2416995850778 : check e2416995850778 [[],[],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2416995908122 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416995908122 : Closed e2416995908122 ∧ code e2416995908122 = 11213088930330 := by decide
def e2416995920410 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416995920410 : Closed e2416995920410 ∧ code e2416995920410 = 11213088942618 := by decide
theorem cert_e2416995920410 : check e2416995920410 [[],[],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2416995949082 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416995949082 : Closed e2416995949082 ∧ code e2416995949082 = 11213088971290 := by decide
theorem cert_e2416995949082 : check e2416995949082 [[],[],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .smaller = true := by decide
def e2416995953178 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416995953178 : Closed e2416995953178 ∧ code e2416995953178 = 11213088975386 := by decide
def e2416996235802 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416996235802 : Closed e2416996235802 ∧ code e2416996235802 = 11213089258010 := by decide
theorem cert_e2416996235802 : check e2416996235802 [[],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2416996243994 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416996243994 : Closed e2416996243994 ∧ code e2416996243994 = 11213089266202 := by decide
theorem cert_e2416996243994 : check e2416996243994 [[],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2416996629018 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416996629018 : Closed e2416996629018 ∧ code e2416996629018 = 11213089651226 := by decide
theorem cert_e2416996629018 : check e2416996629018 [[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left,.left]] .chain = true := by decide
def e2416996641306 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416996641306 : Closed e2416996641306 ∧ code e2416996641306 = 11213089663514 := by decide
theorem cert_e2416996641306 : check e2416996641306 [[],[],[.left,.left],[.left,.left],[.left],[],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2416996833818 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416996833818 : Closed e2416996833818 ∧ code e2416996833818 = 11213089856026 := by decide
theorem cert_e2416996833818 : check e2416996833818 [[],[],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .width = true := by decide
def e2416996837914 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2416996837914 : Closed e2416996837914 ∧ code e2416996837914 = 11213089860122 := by decide
theorem cert_e2416996837914 : check e2416996837914 [[],[],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2417004831258 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417004831258 : Closed e2417004831258 ∧ code e2417004831258 = 11213097853466 := by decide
theorem cert_e2417004831258 : check e2417004831258 [[]] .width = true := by decide
def e2417004832794 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417004832794 : Closed e2417004832794 ∧ code e2417004832794 = 11213097855002 := by decide
theorem cert_e2417004832794 : check e2417004832794 [[]] .width = true := by decide
def e2417004864026 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417004864026 : Closed e2417004864026 ∧ code e2417004864026 = 11213097886234 := by decide
theorem cert_e2417004864026 : check e2417004864026 [[]] .width = true := by decide
def e2417004865562 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417004865562 : Closed e2417004865562 ∧ code e2417004865562 = 11213097887770 := by decide
theorem cert_e2417004865562 : check e2417004865562 [[]] .width = true := by decide
def e2417005093402 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417005093402 : Closed e2417005093402 ∧ code e2417005093402 = 11213098115610 := by decide
theorem cert_e2417005093402 : check e2417005093402 [[]] .width = true := by decide
def e2417005094938 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417005094938 : Closed e2417005094938 ∧ code e2417005094938 = 11213098117146 := by decide
theorem cert_e2417005094938 : check e2417005094938 [[]] .width = true := by decide
def e2417005142554 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417005142554 : Closed e2417005142554 ∧ code e2417005142554 = 11213098164762 := by decide
private def t_e2417005142554 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417005142554 : ¬ IsSelfInterpreter e2417005142554 :=
  wSource (t := t_e2417005142554) (replay_sound (ps := []) (t := e2417005142554) (by decide)) (by decide)
def e2417005144090 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417005144090 : Closed e2417005144090 ∧ code e2417005144090 = 11213098166298 := by decide
theorem cert_e2417005144090 : check e2417005144090 [[]] .width = true := by decide
def e2417005257242 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417005257242 : Closed e2417005257242 ∧ code e2417005257242 = 11213098279450 := by decide
theorem cert_e2417005257242 : check e2417005257242 [[]] .width = true := by decide
def e2417005258778 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417005258778 : Closed e2417005258778 ∧ code e2417005258778 = 11213098280986 := by decide
theorem cert_e2417005258778 : check e2417005258778 [[]] .width = true := by decide
def e2417005273626 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417005273626 : Closed e2417005273626 ∧ code e2417005273626 = 11213098295834 := by decide
private def t_e2417005273626 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417005273626 : ¬ IsSelfInterpreter e2417005273626 :=
  wSource (t := t_e2417005273626) (replay_sound (ps := []) (t := e2417005273626) (by decide)) (by decide)
def e2417005275162 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417005275162 : Closed e2417005275162 ∧ code e2417005275162 = 11213098297370 := by decide
theorem cert_e2417005275162 : check e2417005275162 [[]] .width = true := by decide
def e2417006404122 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417006404122 : Closed e2417006404122 ∧ code e2417006404122 = 11213099426330 := by decide
theorem cert_e2417006404122 : check e2417006404122 [[]] .width = true := by decide
def e2417006405658 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417006405658 : Closed e2417006405658 ∧ code e2417006405658 = 11213099427866 := by decide
theorem cert_e2417006405658 : check e2417006405658 [[]] .width = true := by decide
def e2417006436890 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417006436890 : Closed e2417006436890 ∧ code e2417006436890 = 11213099459098 := by decide
theorem cert_e2417006436890 : check e2417006436890 [[]] .width = true := by decide
def e2417006438426 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417006438426 : Closed e2417006438426 ∧ code e2417006438426 = 11213099460634 := by decide
theorem cert_e2417006438426 : check e2417006438426 [[]] .width = true := by decide
def e2417007976986 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417007976986 : Closed e2417007976986 ∧ code e2417007976986 = 11213100999194 := by decide
theorem cert_e2417007976986 : check e2417007976986 [[]] .width = true := by decide
def e2417007978522 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417007978522 : Closed e2417007978522 ∧ code e2417007978522 = 11213101000730 := by decide
theorem cert_e2417007978522 : check e2417007978522 [[]] .width = true := by decide
def e2417008026138 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417008026138 : Closed e2417008026138 ∧ code e2417008026138 = 11213101048346 := by decide
theorem cert_e2417008026138 : check e2417008026138 [[]] .width = true := by decide
def e2417008027674 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417008027674 : Closed e2417008027674 ∧ code e2417008027674 = 11213101049882 := by decide
theorem cert_e2417008027674 : check e2417008027674 [[]] .width = true := by decide
def e2417008796186 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417008796186 : Closed e2417008796186 ∧ code e2417008796186 = 11213101818394 := by decide
theorem cert_e2417008796186 : check e2417008796186 [[]] .width = true := by decide
def e2417008797722 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417008797722 : Closed e2417008797722 ∧ code e2417008797722 = 11213101819930 := by decide
theorem cert_e2417008797722 : check e2417008797722 [[]] .width = true := by decide
def e2417008812570 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417008812570 : Closed e2417008812570 ∧ code e2417008812570 = 11213101834778 := by decide
theorem cert_e2417008812570 : check e2417008812570 [[]] .width = true := by decide
def e2417008814106 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417008814106 : Closed e2417008814106 ∧ code e2417008814106 = 11213101836314 := by decide
theorem cert_e2417008814106 : check e2417008814106 [[]] .width = true := by decide
def e2417060703770 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060703770 : Closed e2417060703770 ∧ code e2417060703770 = 11213153725978 := by decide
theorem cert_e2417060703770 : check e2417060703770 [[]] .width = true := by decide
def e2417060705818 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060705818 : Closed e2417060705818 ∧ code e2417060705818 = 11213153728026 := by decide
theorem cert_e2417060705818 : check e2417060705818 [[]] .width = true := by decide
def e2417060720154 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060720154 : Closed e2417060720154 ∧ code e2417060720154 = 11213153742362 := by decide
theorem cert_e2417060720154 : check e2417060720154 [[]] .width = true := by decide
def e2417060723226 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060723226 : Closed e2417060723226 ∧ code e2417060723226 = 11213153745434 := by decide
theorem cert_e2417060723226 : check e2417060723226 [[]] .width = true := by decide
def e2417060730394 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060730394 : Closed e2417060730394 ∧ code e2417060730394 = 11213153752602 := by decide
theorem cert_e2417060730394 : check e2417060730394 [[]] .width = true := by decide
def e2417060731418 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060731418 : Closed e2417060731418 ∧ code e2417060731418 = 11213153753626 := by decide
theorem cert_e2417060731418 : check e2417060731418 [[]] .width = true := by decide
def e2417060802074 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060802074 : Closed e2417060802074 ∧ code e2417060802074 = 11213153824282 := by decide
theorem cert_e2417060802074 : check e2417060802074 [[]] .width = true := by decide
def e2417060804122 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060804122 : Closed e2417060804122 ∧ code e2417060804122 = 11213153826330 := by decide
theorem cert_e2417060804122 : check e2417060804122 [[]] .width = true := by decide
def e2417060900378 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060900378 : Closed e2417060900378 ∧ code e2417060900378 = 11213153922586 := by decide
theorem cert_e2417060900378 : check e2417060900378 [[]] .width = true := by decide
def e2417060903450 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060903450 : Closed e2417060903450 ∧ code e2417060903450 = 11213153925658 := by decide
theorem cert_e2417060903450 : check e2417060903450 [[]] .width = true := by decide
def e2417060951578 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060951578 : Closed e2417060951578 ∧ code e2417060951578 = 11213153973786 := by decide
theorem cert_e2417060951578 : check e2417060951578 [[]] .width = true := by decide
def e2417060952602 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417060952602 : Closed e2417060952602 ∧ code e2417060952602 = 11213153974810 := by decide
theorem cert_e2417060952602 : check e2417060952602 [[]] .width = true := by decide
def e2417076776302 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2417076776302 : Closed e2417076776302 ∧ code e2417076776302 = 11213169798510 := by decide
theorem cert_e2417076776302 : check e2417076776302 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417076776310 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2417076776310 : Closed e2417076776310 ∧ code e2417076776310 = 11213169798518 := by decide
theorem cert_e2417076776310 : checkPay e2417076776310 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417076776366 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2417076776366 : Closed e2417076776366 ∧ code e2417076776366 = 11213169798574 := by decide
theorem cert_e2417076776366 : check e2417076776366 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2417076776378 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2417076776378 : Closed e2417076776378 ∧ code e2417076776378 = 11213169798586 := by decide
theorem cert_e2417076776378 : check e2417076776378 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2417076776406 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2417076776406 : Closed e2417076776406 ∧ code e2417076776406 = 11213169798614 := by decide
theorem cert_e2417076776406 : check e2417076776406 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417076776410 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2417076776410 : Closed e2417076776410 ∧ code e2417076776410 = 11213169798618 := by decide
theorem cert_e2417076776410 : check e2417076776410 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417076776622 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2417076776622 : Closed e2417076776622 ∧ code e2417076776622 = 11213169798830 := by decide
theorem cert_e2417076776622 : check e2417076776622 [[],[]] .sourceHead = true := by decide
def e2417076776634 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2417076776634 : Closed e2417076776634 ∧ code e2417076776634 = 11213169798842 := by decide
theorem cert_e2417076776634 : check e2417076776634 [[],[]] .sourceHead = true := by decide
def e2417076776682 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2417076776682 : Closed e2417076776682 ∧ code e2417076776682 = 11213169798890 := by decide
theorem cert_e2417076776682 : check e2417076776682 [[],[]] .sourceHead = true := by decide
def e2417076776790 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2417076776790 : Closed e2417076776790 ∧ code e2417076776790 = 11213169798998 := by decide
theorem cert_e2417076776790 : check e2417076776790 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417076776794 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2417076776794 : Closed e2417076776794 ∧ code e2417076776794 = 11213169799002 := by decide
theorem cert_e2417076776794 : check e2417076776794 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417076776810 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2417076776810 : Closed e2417076776810 ∧ code e2417076776810 = 11213169799018 := by decide
theorem cert_e2417076776810 : check e2417076776810 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417076777838 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2417076777838 : Closed e2417076777838 ∧ code e2417076777838 = 11213169800046 := by decide
theorem cert_e2417076777838 : check e2417076777838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417076777846 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2417076777846 : Closed e2417076777846 ∧ code e2417076777846 = 11213169800054 := by decide
theorem cert_e2417076777846 : check e2417076777846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417076777902 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2417076777902 : Closed e2417076777902 ∧ code e2417076777902 = 11213169800110 := by decide
theorem cert_e2417076777902 : check e2417076777902 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417076777914 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2417076777914 : Closed e2417076777914 ∧ code e2417076777914 = 11213169800122 := by decide
theorem cert_e2417076777914 : check e2417076777914 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417076777942 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2417076777942 : Closed e2417076777942 ∧ code e2417076777942 = 11213169800150 := by decide
theorem cert_e2417076777942 : check e2417076777942 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417076777946 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2417076777946 : Closed e2417076777946 ∧ code e2417076777946 = 11213169800154 := by decide
theorem cert_e2417076777946 : check e2417076777946 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417076778222 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2417076778222 : Closed e2417076778222 ∧ code e2417076778222 = 11213169800430 := by decide
theorem cert_e2417076778222 : check e2417076778222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417076778230 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2417076778230 : Closed e2417076778230 ∧ code e2417076778230 = 11213169800438 := by decide
theorem cert_e2417076778230 : check e2417076778230 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417076778606 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2417076778606 : Closed e2417076778606 ∧ code e2417076778606 = 11213169800814 := by decide
theorem cert_e2417076778606 : check e2417076778606 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417076778618 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2417076778618 : Closed e2417076778618 ∧ code e2417076778618 = 11213169800826 := by decide
theorem cert_e2417076778618 : check e2417076778618 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417076778806 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2417076778806 : Closed e2417076778806 ∧ code e2417076778806 = 11213169801014 := by decide
theorem cert_e2417076778806 : check e2417076778806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2417076778810 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2417076778810 : Closed e2417076778810 ∧ code e2417076778810 = 11213169801018 := by decide
theorem cert_e2417076778810 : check e2417076778810 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2416995842586
#print axioms Blc.Floor43.cert_e2417005142554
#print axioms Blc.Floor43.cert_e2417005273626
