import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606396454586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e606396454586 : Closed e606396454586 ∧ code e606396454586 = 9402489476794 := by decide
theorem cert_e606396454586 : check e606396454586 [[.under]] .sourceHead = true := by decide
def e606396454634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e606396454634 : Closed e606396454634 ∧ code e606396454634 = 9402489476842 := by decide
theorem cert_e606396454634 : check e606396454634 [[.under]] .sourceHead = true := by decide
def e606396454826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e606396454826 : Closed e606396454826 ∧ code e606396454826 = 9402489477034 := by decide
theorem cert_e606396454826 : check e606396454826 [[.under]] .sourceHead = true := by decide
def e606396455150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e606396455150 : Closed e606396455150 ∧ code e606396455150 = 9402489477358 := by decide
theorem cert_e606396455150 : check e606396455150 [[.under]] .sourceHead = true := by decide
def e606396455158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e606396455158 : Closed e606396455158 ∧ code e606396455158 = 9402489477366 := by decide
theorem cert_e606396455158 : check e606396455158 [[.under]] .sourceHead = true := by decide
def e606396455342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e606396455342 : Closed e606396455342 ∧ code e606396455342 = 9402489477550 := by decide
theorem cert_e606396455342 : check e606396455342 [[.under]] .sourceHead = true := by decide
def e606396455354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e606396455354 : Closed e606396455354 ∧ code e606396455354 = 9402489477562 := by decide
theorem cert_e606396455354 : check e606396455354 [[.under]] .sourceHead = true := by decide
def e606396455402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e606396455402 : Closed e606396455402 ∧ code e606396455402 = 9402489477610 := by decide
theorem cert_e606396455402 : check e606396455402 [[.under]] .sourceHead = true := by decide
def e606396455534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e606396455534 : Closed e606396455534 ∧ code e606396455534 = 9402489477742 := by decide
theorem cert_e606396455534 : check e606396455534 [[.under]] .sourceHead = true := by decide
def e606396455546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e606396455546 : Closed e606396455546 ∧ code e606396455546 = 9402489477754 := by decide
theorem cert_e606396455546 : check e606396455546 [[.under]] .sourceHead = true := by decide
def e606396455710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e606396455710 : Closed e606396455710 ∧ code e606396455710 = 9402489477918 := by decide
theorem cert_e606396455710 : check e606396455710 [[.under]] .sourceHead = true := by decide
def e606396455822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e606396455822 : Closed e606396455822 ∧ code e606396455822 = 9402489478030 := by decide
theorem cert_e606396455822 : check e606396455822 [[.under]] .sourceHead = true := by decide
def e606396455834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396455834 : Closed e606396455834 ∧ code e606396455834 = 9402489478042 := by decide
theorem cert_e606396455834 : check e606396455834 [[.under]] .sourceHead = true := by decide
def e606396456046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e606396456046 : Closed e606396456046 ∧ code e606396456046 = 9402489478254 := by decide
theorem cert_e606396456046 : check e606396456046 [[.under]] .sourceHead = true := by decide
def e606396456058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e606396456058 : Closed e606396456058 ∧ code e606396456058 = 9402489478266 := by decide
theorem cert_e606396456058 : check e606396456058 [[.under]] .sourceHead = true := by decide
def e606396456222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e606396456222 : Closed e606396456222 ∧ code e606396456222 = 9402489478430 := by decide
theorem cert_e606396456222 : check e606396456222 [[.under]] .sourceHead = true := by decide
def e606396456390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e606396456390 : Closed e606396456390 ∧ code e606396456390 = 9402489478598 := by decide
theorem cert_e606396456390 : check e606396456390 [[.under]] .sourceHead = true := by decide
def e606396456502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e606396456502 : Closed e606396456502 ∧ code e606396456502 = 9402489478710 := by decide
theorem cert_e606396456502 : check e606396456502 [[.under]] .sourceHead = true := by decide
def e606396456506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e606396456506 : Closed e606396456506 ∧ code e606396456506 = 9402489478714 := by decide
theorem cert_e606396456506 : check e606396456506 [[.under]] .sourceHead = true := by decide
def e606396456554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e606396456554 : Closed e606396456554 ∧ code e606396456554 = 9402489478762 := by decide
theorem cert_e606396456554 : check e606396456554 [[.under]] .sourceHead = true := by decide
def e606396456590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e606396456590 : Closed e606396456590 ∧ code e606396456590 = 9402489478798 := by decide
theorem cert_e606396456590 : check e606396456590 [[.under]] .sourceHead = true := by decide
def e606396456602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396456602 : Closed e606396456602 ∧ code e606396456602 = 9402489478810 := by decide
theorem cert_e606396456602 : check e606396456602 [[.under]] .sourceHead = true := by decide
def e606396456646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e606396456646 : Closed e606396456646 ∧ code e606396456646 = 9402489478854 := by decide
theorem cert_e606396456646 : check e606396456646 [[.under]] .sourceHead = true := by decide
def e606396457438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e606396457438 : Closed e606396457438 ∧ code e606396457438 = 9402489479646 := by decide
theorem cert_e606396457438 : check e606396457438 [[.under]] .sourceHead = true := by decide
def e606396457462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e606396457462 : Closed e606396457462 ∧ code e606396457462 = 9402489479670 := by decide
theorem cert_e606396457462 : check e606396457462 [[.under]] .sourceHead = true := by decide
def e606396458414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e606396458414 : Closed e606396458414 ∧ code e606396458414 = 9402489480622 := by decide
theorem cert_e606396458414 : check e606396458414 [[.under]] .sourceHead = true := by decide
def e606396458426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e606396458426 : Closed e606396458426 ∧ code e606396458426 = 9402489480634 := by decide
theorem cert_e606396458426 : check e606396458426 [[.under]] .sourceHead = true := by decide
def e606396458474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e606396458474 : Closed e606396458474 ∧ code e606396458474 = 9402489480682 := by decide
theorem cert_e606396458474 : check e606396458474 [[.under]] .sourceHead = true := by decide
def e606396458606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e606396458606 : Closed e606396458606 ∧ code e606396458606 = 9402489480814 := by decide
theorem cert_e606396458606 : check e606396458606 [[.under]] .sourceHead = true := by decide
def e606396458618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e606396458618 : Closed e606396458618 ∧ code e606396458618 = 9402489480826 := by decide
theorem cert_e606396458618 : check e606396458618 [[.under]] .sourceHead = true := by decide
def e606396458782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e606396458782 : Closed e606396458782 ∧ code e606396458782 = 9402489480990 := by decide
theorem cert_e606396458782 : check e606396458782 [[.under]] .sourceHead = true := by decide
def e606396458894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e606396458894 : Closed e606396458894 ∧ code e606396458894 = 9402489481102 := by decide
theorem cert_e606396458894 : check e606396458894 [[.under]] .sourceHead = true := by decide
def e606396458906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396458906 : Closed e606396458906 ∧ code e606396458906 = 9402489481114 := by decide
theorem cert_e606396458906 : check e606396458906 [[.under]] .sourceHead = true := by decide
def e606396461854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e606396461854 : Closed e606396461854 ∧ code e606396461854 = 9402489484062 := by decide
theorem cert_e606396461854 : check e606396461854 [[.under]] .sourceHead = true := by decide
def e606396462022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e606396462022 : Closed e606396462022 ∧ code e606396462022 = 9402489484230 := by decide
theorem cert_e606396462022 : check e606396462022 [[.under]] .sourceHead = true := by decide
def e606396463222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e606396463222 : Closed e606396463222 ∧ code e606396463222 = 9402489485430 := by decide
theorem cert_e606396463222 : check e606396463222 [[.under]] .sourceHead = true := by decide
def e606396463466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e606396463466 : Closed e606396463466 ∧ code e606396463466 = 9402489485674 := by decide
theorem cert_e606396463466 : check e606396463466 [[.under]] .sourceHead = true := by decide
def e606396463502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e606396463502 : Closed e606396463502 ∧ code e606396463502 = 9402489485710 := by decide
theorem cert_e606396463502 : check e606396463502 [[.under]] .sourceHead = true := by decide
def e606396463514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396463514 : Closed e606396463514 ∧ code e606396463514 = 9402489485722 := by decide
theorem cert_e606396463514 : check e606396463514 [[.under]] .sourceHead = true := by decide
def e606396463558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e606396463558 : Closed e606396463558 ∧ code e606396463558 = 9402489485766 := by decide
theorem cert_e606396463558 : check e606396463558 [[.under]] .sourceHead = true := by decide
def e606396466102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e606396466102 : Closed e606396466102 ∧ code e606396466102 = 9402489488310 := by decide
theorem cert_e606396466102 : check e606396466102 [[.under]] .sourceHead = true := by decide
def e606396466106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e606396466106 : Closed e606396466106 ∧ code e606396466106 = 9402489488314 := by decide
theorem cert_e606396466106 : check e606396466106 [[.under]] .sourceHead = true := by decide
def e606396466138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e606396466138 : Closed e606396466138 ∧ code e606396466138 = 9402489488346 := by decide
theorem cert_e606396466138 : check e606396466138 [[.under]] .sourceHead = true := by decide
def e606396466806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e606396466806 : Closed e606396466806 ∧ code e606396466806 = 9402489489014 := by decide
theorem cert_e606396466806 : check e606396466806 [[.under]] .sourceHead = true := by decide
def e606396466998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396466998 : Closed e606396466998 ∧ code e606396466998 = 9402489489206 := by decide
theorem cert_e606396466998 : check e606396466998 [[.under]] .sourceHead = true := by decide
def e606396467002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396467002 : Closed e606396467002 ∧ code e606396467002 = 9402489489210 := by decide
theorem cert_e606396467002 : check e606396467002 [[.under]] .sourceHead = true := by decide
def e606396468054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e606396468054 : Closed e606396468054 ∧ code e606396468054 = 9402489490262 := by decide
theorem cert_e606396468054 : check e606396468054 [[.under]] .sourceHead = true := by decide
def e606396468058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e606396468058 : Closed e606396468058 ∧ code e606396468058 = 9402489490266 := by decide
theorem cert_e606396468058 : check e606396468058 [[.under]] .sourceHead = true := by decide
def e606396468074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e606396468074 : Closed e606396468074 ∧ code e606396468074 = 9402489490282 := by decide
theorem cert_e606396468074 : check e606396468074 [[.under]] .sourceHead = true := by decide
def e606396468138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e606396468138 : Closed e606396468138 ∧ code e606396468138 = 9402489490346 := by decide
theorem cert_e606396468138 : check e606396468138 [[.under]] .sourceHead = true := by decide
def e606396468342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e606396468342 : Closed e606396468342 ∧ code e606396468342 = 9402489490550 := by decide
theorem cert_e606396468342 : check e606396468342 [[.under]] .sourceHead = true := by decide
def e606396468438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e606396468438 : Closed e606396468438 ∧ code e606396468438 = 9402489490646 := by decide
theorem cert_e606396468438 : check e606396468438 [[.under]] .sourceHead = true := by decide
def e606396468442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e606396468442 : Closed e606396468442 ∧ code e606396468442 = 9402489490650 := by decide
theorem cert_e606396468442 : check e606396468442 [[.under]] .sourceHead = true := by decide
def e606396468458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e606396468458 : Closed e606396468458 ∧ code e606396468458 = 9402489490666 := by decide
theorem cert_e606396468458 : check e606396468458 [[.under]] .sourceHead = true := by decide
def e606396468534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396468534 : Closed e606396468534 ∧ code e606396468534 = 9402489490742 := by decide
theorem cert_e606396468534 : check e606396468534 [[.under]] .sourceHead = true := by decide
def e606396468538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396468538 : Closed e606396468538 ∧ code e606396468538 = 9402489490746 := by decide
theorem cert_e606396468538 : check e606396468538 [[.under]] .sourceHead = true := by decide
def e606396468622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e606396468622 : Closed e606396468622 ∧ code e606396468622 = 9402489490830 := by decide
theorem cert_e606396468622 : check e606396468622 [[.under]] .sourceHead = true := by decide
def e606396468634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396468634 : Closed e606396468634 ∧ code e606396468634 = 9402489490842 := by decide
theorem cert_e606396468634 : check e606396468634 [[.under]] .sourceHead = true := by decide
def e606396468790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e606396468790 : Closed e606396468790 ∧ code e606396468790 = 9402489490998 := by decide
theorem cert_e606396468790 : check e606396468790 [[.under]] .sourceHead = true := by decide
def e606396468794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e606396468794 : Closed e606396468794 ∧ code e606396468794 = 9402489491002 := by decide
theorem cert_e606396468794 : check e606396468794 [[.under]] .sourceHead = true := by decide
def e606396468842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e606396468842 : Closed e606396468842 ∧ code e606396468842 = 9402489491050 := by decide
theorem cert_e606396468842 : check e606396468842 [[.under]] .sourceHead = true := by decide
def e606396468878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e606396468878 : Closed e606396468878 ∧ code e606396468878 = 9402489491086 := by decide
theorem cert_e606396468878 : check e606396468878 [[.under]] .sourceHead = true := by decide
def e606396468890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396468890 : Closed e606396468890 ∧ code e606396468890 = 9402489491098 := by decide
theorem cert_e606396468890 : check e606396468890 [[.under]] .sourceHead = true := by decide
def e606396468934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e606396468934 : Closed e606396468934 ∧ code e606396468934 = 9402489491142 := by decide
theorem cert_e606396468934 : check e606396468934 [[.under]] .sourceHead = true := by decide
def e606396469486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e606396469486 : Closed e606396469486 ∧ code e606396469486 = 9402489491694 := by decide
theorem cert_e606396469486 : check e606396469486 [[.under]] .sourceHead = true := by decide
def e606396469494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e606396469494 : Closed e606396469494 ∧ code e606396469494 = 9402489491702 := by decide
theorem cert_e606396469494 : check e606396469494 [[.under]] .sourceHead = true := by decide
def e606396469974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e606396469974 : Closed e606396469974 ∧ code e606396469974 = 9402489492182 := by decide
theorem cert_e606396469974 : check e606396469974 [[.under]] .sourceHead = true := by decide
def e606396469978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e606396469978 : Closed e606396469978 ∧ code e606396469978 = 9402489492186 := by decide
theorem cert_e606396469978 : check e606396469978 [[.under]] .sourceHead = true := by decide
def e606396469994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e606396469994 : Closed e606396469994 ∧ code e606396469994 = 9402489492202 := by decide
theorem cert_e606396469994 : check e606396469994 [[.under]] .sourceHead = true := by decide
def e606396470070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e606396470070 : Closed e606396470070 ∧ code e606396470070 = 9402489492278 := by decide
theorem cert_e606396470070 : check e606396470070 [[.under]] .sourceHead = true := by decide
def e606396470074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e606396470074 : Closed e606396470074 ∧ code e606396470074 = 9402489492282 := by decide
theorem cert_e606396470074 : check e606396470074 [[.under]] .sourceHead = true := by decide
def e606396470158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e606396470158 : Closed e606396470158 ∧ code e606396470158 = 9402489492366 := by decide
theorem cert_e606396470158 : check e606396470158 [[.under]] .sourceHead = true := by decide
def e606396470170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396470170 : Closed e606396470170 ∧ code e606396470170 = 9402489492378 := by decide
theorem cert_e606396470170 : check e606396470170 [[.under]] .sourceHead = true := by decide
def e606396471414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e606396471414 : Closed e606396471414 ∧ code e606396471414 = 9402489493622 := by decide
theorem cert_e606396471414 : check e606396471414 [[.under]] .sourceHead = true := by decide
def e606396471658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e606396471658 : Closed e606396471658 ∧ code e606396471658 = 9402489493866 := by decide
theorem cert_e606396471658 : check e606396471658 [[.under]] .sourceHead = true := by decide
def e606396471694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e606396471694 : Closed e606396471694 ∧ code e606396471694 = 9402489493902 := by decide
theorem cert_e606396471694 : check e606396471694 [[.under]] .sourceHead = true := by decide
def e606396471706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396471706 : Closed e606396471706 ∧ code e606396471706 = 9402489493914 := by decide
theorem cert_e606396471706 : check e606396471706 [[.under]] .sourceHead = true := by decide
def e606396471750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e606396471750 : Closed e606396471750 ∧ code e606396471750 = 9402489493958 := by decide
theorem cert_e606396471750 : check e606396471750 [[.under]] .sourceHead = true := by decide
def e606396484462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e606396484462 : Closed e606396484462 ∧ code e606396484462 = 9402489506670 := by decide
theorem cert_e606396484462 : check e606396484462 [[.under]] .sourceHead = true := by decide
def e606396484470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e606396484470 : Closed e606396484470 ∧ code e606396484470 = 9402489506678 := by decide
theorem cert_e606396484470 : check e606396484470 [[.under]] .sourceHead = true := by decide
def e606396484526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e606396484526 : Closed e606396484526 ∧ code e606396484526 = 9402489506734 := by decide
theorem cert_e606396484526 : check e606396484526 [[.under]] .sourceHead = true := by decide
def e606396484538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e606396484538 : Closed e606396484538 ∧ code e606396484538 = 9402489506746 := by decide
theorem cert_e606396484538 : check e606396484538 [[.under]] .sourceHead = true := by decide
def e606396484566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e606396484566 : Closed e606396484566 ∧ code e606396484566 = 9402489506774 := by decide
theorem cert_e606396484566 : check e606396484566 [[.under]] .sourceHead = true := by decide
def e606396484570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e606396484570 : Closed e606396484570 ∧ code e606396484570 = 9402489506778 := by decide
theorem cert_e606396484570 : check e606396484570 [[.under]] .sourceHead = true := by decide
def e606396484846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e606396484846 : Closed e606396484846 ∧ code e606396484846 = 9402489507054 := by decide
theorem cert_e606396484846 : check e606396484846 [[.under]] .sourceHead = true := by decide
def e606396484854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e606396484854 : Closed e606396484854 ∧ code e606396484854 = 9402489507062 := by decide
theorem cert_e606396484854 : check e606396484854 [[.under]] .sourceHead = true := by decide
def e606396485230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e606396485230 : Closed e606396485230 ∧ code e606396485230 = 9402489507438 := by decide
theorem cert_e606396485230 : check e606396485230 [[.under]] .sourceHead = true := by decide
def e606396485242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e606396485242 : Closed e606396485242 ∧ code e606396485242 = 9402489507450 := by decide
theorem cert_e606396485242 : check e606396485242 [[.under]] .sourceHead = true := by decide
def e606396485430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e606396485430 : Closed e606396485430 ∧ code e606396485430 = 9402489507638 := by decide
theorem cert_e606396485430 : check e606396485430 [[.under]] .sourceHead = true := by decide
def e606396485434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e606396485434 : Closed e606396485434 ∧ code e606396485434 = 9402489507642 := by decide
theorem cert_e606396485434 : check e606396485434 [[.under]] .sourceHead = true := by decide
def e606396525934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e606396525934 : Closed e606396525934 ∧ code e606396525934 = 9402489548142 := by decide
theorem cert_e606396525934 : check e606396525934 [[.under]] .sourceHead = true := by decide
def e606396525942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e606396525942 : Closed e606396525942 ∧ code e606396525942 = 9402489548150 := by decide
theorem cert_e606396525942 : check e606396525942 [[.under]] .sourceHead = true := by decide
def e606396525998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e606396525998 : Closed e606396525998 ∧ code e606396525998 = 9402489548206 := by decide
theorem cert_e606396525998 : check e606396525998 [[.under]] .sourceHead = true := by decide
def e606396526010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e606396526010 : Closed e606396526010 ∧ code e606396526010 = 9402489548218 := by decide
theorem cert_e606396526010 : check e606396526010 [[.under]] .sourceHead = true := by decide
def e606396526038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e606396526038 : Closed e606396526038 ∧ code e606396526038 = 9402489548246 := by decide
theorem cert_e606396526038 : check e606396526038 [[.under]] .sourceHead = true := by decide
def e606396526042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e606396526042 : Closed e606396526042 ∧ code e606396526042 = 9402489548250 := by decide
theorem cert_e606396526042 : check e606396526042 [[.under]] .sourceHead = true := by decide
def e606396526254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e606396526254 : Closed e606396526254 ∧ code e606396526254 = 9402489548462 := by decide
theorem cert_e606396526254 : check e606396526254 [[.under]] .sourceHead = true := by decide
def e606396526266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e606396526266 : Closed e606396526266 ∧ code e606396526266 = 9402489548474 := by decide
theorem cert_e606396526266 : check e606396526266 [[.under]] .sourceHead = true := by decide
def e606396526314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e606396526314 : Closed e606396526314 ∧ code e606396526314 = 9402489548522 := by decide
theorem cert_e606396526314 : check e606396526314 [[.under]] .sourceHead = true := by decide
def e606396526422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e606396526422 : Closed e606396526422 ∧ code e606396526422 = 9402489548630 := by decide
theorem cert_e606396526422 : check e606396526422 [[.under]] .sourceHead = true := by decide
def e606396526426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e606396526426 : Closed e606396526426 ∧ code e606396526426 = 9402489548634 := by decide
theorem cert_e606396526426 : check e606396526426 [[.under]] .sourceHead = true := by decide
def e606396526442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e606396526442 : Closed e606396526442 ∧ code e606396526442 = 9402489548650 := by decide
theorem cert_e606396526442 : check e606396526442 [[.under]] .sourceHead = true := by decide
def e606396527470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e606396527470 : Closed e606396527470 ∧ code e606396527470 = 9402489549678 := by decide
theorem cert_e606396527470 : check e606396527470 [[.under]] .sourceHead = true := by decide
def e606396527478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e606396527478 : Closed e606396527478 ∧ code e606396527478 = 9402489549686 := by decide
theorem cert_e606396527478 : check e606396527478 [[.under]] .sourceHead = true := by decide
def e606396527534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e606396527534 : Closed e606396527534 ∧ code e606396527534 = 9402489549742 := by decide
theorem cert_e606396527534 : check e606396527534 [[.under]] .sourceHead = true := by decide
def e606396527546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e606396527546 : Closed e606396527546 ∧ code e606396527546 = 9402489549754 := by decide
theorem cert_e606396527546 : check e606396527546 [[.under]] .sourceHead = true := by decide
def e606396527574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e606396527574 : Closed e606396527574 ∧ code e606396527574 = 9402489549782 := by decide
theorem cert_e606396527574 : check e606396527574 [[.under]] .sourceHead = true := by decide
def e606396527578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e606396527578 : Closed e606396527578 ∧ code e606396527578 = 9402489549786 := by decide
theorem cert_e606396527578 : check e606396527578 [[.under]] .sourceHead = true := by decide
def e606396527854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e606396527854 : Closed e606396527854 ∧ code e606396527854 = 9402489550062 := by decide
theorem cert_e606396527854 : check e606396527854 [[.under]] .sourceHead = true := by decide
def e606396527862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e606396527862 : Closed e606396527862 ∧ code e606396527862 = 9402489550070 := by decide
theorem cert_e606396527862 : check e606396527862 [[.under]] .sourceHead = true := by decide
def e606396528238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606396528238 : Closed e606396528238 ∧ code e606396528238 = 9402489550446 := by decide
theorem cert_e606396528238 : check e606396528238 [[.under]] .sourceHead = true := by decide
def e606396528250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606396528250 : Closed e606396528250 ∧ code e606396528250 = 9402489550458 := by decide
theorem cert_e606396528250 : check e606396528250 [[.under]] .sourceHead = true := by decide
def e606396528438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606396528438 : Closed e606396528438 ∧ code e606396528438 = 9402489550646 := by decide
theorem cert_e606396528438 : check e606396528438 [[.under]] .sourceHead = true := by decide
def e606396528442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606396528442 : Closed e606396528442 ∧ code e606396528442 = 9402489550650 := by decide
theorem cert_e606396528442 : check e606396528442 [[.under]] .sourceHead = true := by decide
def e606396528878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e606396528878 : Closed e606396528878 ∧ code e606396528878 = 9402489551086 := by decide
theorem cert_e606396528878 : check e606396528878 [[.under]] .sourceHead = true := by decide
def e606396528886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e606396528886 : Closed e606396528886 ∧ code e606396528886 = 9402489551094 := by decide
theorem cert_e606396528886 : check e606396528886 [[.under]] .sourceHead = true := by decide
def e606396529070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e606396529070 : Closed e606396529070 ∧ code e606396529070 = 9402489551278 := by decide
theorem cert_e606396529070 : check e606396529070 [[.under]] .sourceHead = true := by decide
def e606396529082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e606396529082 : Closed e606396529082 ∧ code e606396529082 = 9402489551290 := by decide
theorem cert_e606396529082 : check e606396529082 [[.under]] .sourceHead = true := by decide
def e606396529130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e606396529130 : Closed e606396529130 ∧ code e606396529130 = 9402489551338 := by decide
theorem cert_e606396529130 : check e606396529130 [[.under]] .sourceHead = true := by decide
def e606396529262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606396529262 : Closed e606396529262 ∧ code e606396529262 = 9402489551470 := by decide
theorem cert_e606396529262 : check e606396529262 [[.under]] .sourceHead = true := by decide
def e606396529274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606396529274 : Closed e606396529274 ∧ code e606396529274 = 9402489551482 := by decide
theorem cert_e606396529274 : check e606396529274 [[.under]] .sourceHead = true := by decide
def e606396529438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e606396529438 : Closed e606396529438 ∧ code e606396529438 = 9402489551646 := by decide
theorem cert_e606396529438 : check e606396529438 [[.under]] .sourceHead = true := by decide
def e606396529550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e606396529550 : Closed e606396529550 ∧ code e606396529550 = 9402489551758 := by decide
theorem cert_e606396529550 : check e606396529550 [[.under]] .sourceHead = true := by decide
def e606396529562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396529562 : Closed e606396529562 ∧ code e606396529562 = 9402489551770 := by decide
theorem cert_e606396529562 : check e606396529562 [[.under]] .sourceHead = true := by decide
def e606396529782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e606396529782 : Closed e606396529782 ∧ code e606396529782 = 9402489551990 := by decide
theorem cert_e606396529782 : check e606396529782 [[.under]] .sourceHead = true := by decide
def e606396529878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e606396529878 : Closed e606396529878 ∧ code e606396529878 = 9402489552086 := by decide
theorem cert_e606396529878 : check e606396529878 [[.under]] .sourceHead = true := by decide
def e606396529882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e606396529882 : Closed e606396529882 ∧ code e606396529882 = 9402489552090 := by decide
theorem cert_e606396529882 : check e606396529882 [[.under]] .sourceHead = true := by decide
def e606396529898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e606396529898 : Closed e606396529898 ∧ code e606396529898 = 9402489552106 := by decide
theorem cert_e606396529898 : check e606396529898 [[.under]] .sourceHead = true := by decide
def e606396529974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606396529974 : Closed e606396529974 ∧ code e606396529974 = 9402489552182 := by decide
theorem cert_e606396529974 : check e606396529974 [[.under]] .sourceHead = true := by decide
def e606396529978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606396529978 : Closed e606396529978 ∧ code e606396529978 = 9402489552186 := by decide
theorem cert_e606396529978 : check e606396529978 [[.under]] .sourceHead = true := by decide
def e606396530062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e606396530062 : Closed e606396530062 ∧ code e606396530062 = 9402489552270 := by decide
theorem cert_e606396530062 : check e606396530062 [[.under]] .sourceHead = true := by decide
def e606396530074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396530074 : Closed e606396530074 ∧ code e606396530074 = 9402489552282 := by decide
theorem cert_e606396530074 : check e606396530074 [[.under]] .sourceHead = true := by decide
def e606396531678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e606396531678 : Closed e606396531678 ∧ code e606396531678 = 9402489553886 := by decide
theorem cert_e606396531678 : check e606396531678 [[.under]] .sourceHead = true := by decide
def e606396531694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e606396531694 : Closed e606396531694 ∧ code e606396531694 = 9402489553902 := by decide
theorem cert_e606396531694 : check e606396531694 [[.under]] .sourceHead = true := by decide
def e606396533614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606396533614 : Closed e606396533614 ∧ code e606396533614 = 9402489555822 := by decide
theorem cert_e606396533614 : check e606396533614 [[.under]] .sourceHead = true := by decide
def e606396533622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606396533622 : Closed e606396533622 ∧ code e606396533622 = 9402489555830 := by decide
theorem cert_e606396533622 : check e606396533622 [[.under]] .sourceHead = true := by decide
def e606396533678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606396533678 : Closed e606396533678 ∧ code e606396533678 = 9402489555886 := by decide
theorem cert_e606396533678 : check e606396533678 [[.under]] .sourceHead = true := by decide
def e606396533690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606396533690 : Closed e606396533690 ∧ code e606396533690 = 9402489555898 := by decide
theorem cert_e606396533690 : check e606396533690 [[.under]] .sourceHead = true := by decide
def e606396533718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606396533718 : Closed e606396533718 ∧ code e606396533718 = 9402489555926 := by decide
theorem cert_e606396533718 : check e606396533718 [[.under]] .sourceHead = true := by decide
def e606396533722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606396533722 : Closed e606396533722 ∧ code e606396533722 = 9402489555930 := by decide
theorem cert_e606396533722 : check e606396533722 [[.under]] .sourceHead = true := by decide
def e606396533998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606396533998 : Closed e606396533998 ∧ code e606396533998 = 9402489556206 := by decide
theorem cert_e606396533998 : check e606396533998 [[.under]] .sourceHead = true := by decide
def e606396534006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606396534006 : Closed e606396534006 ∧ code e606396534006 = 9402489556214 := by decide
theorem cert_e606396534006 : check e606396534006 [[.under]] .sourceHead = true := by decide
def e606396534382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606396534382 : Closed e606396534382 ∧ code e606396534382 = 9402489556590 := by decide
theorem cert_e606396534382 : check e606396534382 [[.under]] .sourceHead = true := by decide
def e606396534394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606396534394 : Closed e606396534394 ∧ code e606396534394 = 9402489556602 := by decide
theorem cert_e606396534394 : check e606396534394 [[.under]] .sourceHead = true := by decide
def e606396534582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606396534582 : Closed e606396534582 ∧ code e606396534582 = 9402489556790 := by decide
theorem cert_e606396534582 : check e606396534582 [[.under]] .sourceHead = true := by decide
def e606396534586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606396534586 : Closed e606396534586 ∧ code e606396534586 = 9402489556794 := by decide
theorem cert_e606396534586 : check e606396534586 [[.under]] .sourceHead = true := by decide
def e606396539358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e606396539358 : Closed e606396539358 ∧ code e606396539358 = 9402489561566 := by decide
theorem cert_e606396539358 : check e606396539358 [[.under]] .sourceHead = true := by decide
def e606396539382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e606396539382 : Closed e606396539382 ∧ code e606396539382 = 9402489561590 := by decide
theorem cert_e606396539382 : check e606396539382 [[.under]] .sourceHead = true := by decide
def e606396540334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e606396540334 : Closed e606396540334 ∧ code e606396540334 = 9402489562542 := by decide
theorem cert_e606396540334 : check e606396540334 [[.under]] .sourceHead = true := by decide
def e606396540346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e606396540346 : Closed e606396540346 ∧ code e606396540346 = 9402489562554 := by decide
theorem cert_e606396540346 : check e606396540346 [[.under]] .sourceHead = true := by decide
def e606396540394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e606396540394 : Closed e606396540394 ∧ code e606396540394 = 9402489562602 := by decide
theorem cert_e606396540394 : check e606396540394 [[.under]] .sourceHead = true := by decide
def e606396540526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606396540526 : Closed e606396540526 ∧ code e606396540526 = 9402489562734 := by decide
theorem cert_e606396540526 : check e606396540526 [[.under]] .sourceHead = true := by decide
def e606396540538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606396540538 : Closed e606396540538 ∧ code e606396540538 = 9402489562746 := by decide
theorem cert_e606396540538 : check e606396540538 [[.under]] .sourceHead = true := by decide
def e606396540702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e606396540702 : Closed e606396540702 ∧ code e606396540702 = 9402489562910 := by decide
theorem cert_e606396540702 : check e606396540702 [[.under]] .sourceHead = true := by decide
def e606396540814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e606396540814 : Closed e606396540814 ∧ code e606396540814 = 9402489563022 := by decide
theorem cert_e606396540814 : check e606396540814 [[.under]] .sourceHead = true := by decide
def e606396540826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606396540826 : Closed e606396540826 ∧ code e606396540826 = 9402489563034 := by decide
theorem cert_e606396540826 : check e606396540826 [[.under]] .sourceHead = true := by decide
def e606396543214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e606396543214 : Closed e606396543214 ∧ code e606396543214 = 9402489565422 := by decide
theorem cert_e606396543214 : check e606396543214 [[.under]] .sourceHead = true := by decide
def e606396543222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e606396543222 : Closed e606396543222 ∧ code e606396543222 = 9402489565430 := by decide
theorem cert_e606396543222 : check e606396543222 [[.under]] .sourceHead = true := by decide
def e606396543702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e606396543702 : Closed e606396543702 ∧ code e606396543702 = 9402489565910 := by decide
theorem cert_e606396543702 : check e606396543702 [[.under]] .sourceHead = true := by decide
def e606396543706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e606396543706 : Closed e606396543706 ∧ code e606396543706 = 9402489565914 := by decide
theorem cert_e606396543706 : check e606396543706 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
