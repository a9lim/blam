import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259537363766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259537363766 : Closed e2259537363766 ∧ code e2259537363766 = 11055630385974 := by decide
theorem cert_e2259537363766 : check e2259537363766 [[]] .width = true := by decide
def e2259537363770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259537363770 : Closed e2259537363770 ∧ code e2259537363770 = 11055630385978 := by decide
theorem cert_e2259537363770 : check e2259537363770 [[]] .width = true := by decide
def e2259537363854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259537363854 : Closed e2259537363854 ∧ code e2259537363854 = 11055630386062 := by decide
theorem cert_e2259537363854 : check e2259537363854 [[]] .width = true := by decide
def e2259537363866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259537363866 : Closed e2259537363866 ∧ code e2259537363866 = 11055630386074 := by decide
theorem cert_e2259537363866 : check e2259537363866 [[]] .width = true := by decide
def e2259537365786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259537365786 : Closed e2259537365786 ∧ code e2259537365786 = 11055630387994 := by decide
theorem cert_e2259537365786 : check e2259537365786 [[]] .width = true := by decide
def e2259537365830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259537365830 : Closed e2259537365830 ∧ code e2259537365830 = 11055630388038 := by decide
theorem cert_e2259537365830 : check e2259537365830 [[]] .width = true := by decide
def e2259537365942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259537365942 : Closed e2259537365942 ∧ code e2259537365942 = 11055630388150 := by decide
private def t_e2259537365942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem cert_e2259537365942 : ¬ IsSelfInterpreter e2259537365942 :=
  wSource (t := t_e2259537365942) (replay_sound (ps := []) (t := e2259537365942) (by decide)) (by decide)
def e2259537366070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259537366070 : Closed e2259537366070 ∧ code e2259537366070 = 11055630388278 := by decide
theorem cert_e2259537366070 : check e2259537366070 [[]] .width = true := by decide
def e2259537366074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259537366074 : Closed e2259537366074 ∧ code e2259537366074 = 11055630388282 := by decide
theorem cert_e2259537366074 : check e2259537366074 [[]] .width = true := by decide
def e2259537366214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259537366214 : Closed e2259537366214 ∧ code e2259537366214 = 11055630388422 := by decide
theorem cert_e2259537366214 : check e2259537366214 [[]] .width = true := by decide
def e2259537366554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259537366554 : Closed e2259537366554 ∧ code e2259537366554 = 11055630388762 := by decide
private def t_e2259537366554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem cert_e2259537366554 : ¬ IsSelfInterpreter e2259537366554 :=
  wSource (t := t_e2259537366554) (replay_sound (ps := []) (t := e2259537366554) (by decide)) (by decide)
def e2259537366646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259537366646 : Closed e2259537366646 ∧ code e2259537366646 = 11055630388854 := by decide
private def t_e2259537366646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem cert_e2259537366646 : ¬ IsSelfInterpreter e2259537366646 :=
  wSource (t := t_e2259537366646) (replay_sound (ps := []) (t := e2259537366646) (by decide)) (by decide)
def e2259537374234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259537374234 : Closed e2259537374234 ∧ code e2259537374234 = 11055630396442 := by decide
theorem cert_e2259537374234 : check e2259537374234 [[]] .width = true := by decide
def e2259537374278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259537374278 : Closed e2259537374278 ∧ code e2259537374278 = 11055630396486 := by decide
theorem cert_e2259537374278 : check e2259537374278 [[]] .width = true := by decide
def e2259537374306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259537374306 : Closed e2259537374306 ∧ code e2259537374306 = 11055630396514 := by decide
theorem cert_e2259537374306 : check e2259537374306 [[]] .width = true := by decide
def e2259537374470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259537374470 : Closed e2259537374470 ∧ code e2259537374470 = 11055630396678 := by decide
private def t_e2259537374470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem cert_e2259537374470 : ¬ IsSelfInterpreter e2259537374470 :=
  wSource (t := t_e2259537374470) (replay_sound (ps := []) (t := e2259537374470) (by decide)) (by decide)
def e2259537375262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259537375262 : Closed e2259537375262 ∧ code e2259537375262 = 11055630397470 := by decide
theorem cert_e2259537375262 : check e2259537375262 [[]] .width = true := by decide
def e2259537375430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259537375430 : Closed e2259537375430 ∧ code e2259537375430 = 11055630397638 := by decide
theorem cert_e2259537375430 : check e2259537375430 [[]] .width = true := by decide
def e2259537375458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259537375458 : Closed e2259537375458 ∧ code e2259537375458 = 11055630397666 := by decide
theorem cert_e2259537375458 : check e2259537375458 [[]] .width = true := by decide
def e2259537376006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259537376006 : Closed e2259537376006 ∧ code e2259537376006 = 11055630398214 := by decide
theorem cert_e2259537376006 : check e2259537376006 [[]] .width = true := by decide
def e2259539161286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259539161286 : Closed e2259539161286 ∧ code e2259539161286 = 11055632183494 := by decide
theorem cert_e2259539161286 : check e2259539161286 [[]] .width = true := by decide
def e2259539947718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259539947718 : Closed e2259539947718 ∧ code e2259539947718 = 11055632969926 := by decide
theorem cert_e2259539947718 : check e2259539947718 [[]] .width = true := by decide
def e2259539972294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259539972294 : Closed e2259539972294 ∧ code e2259539972294 = 11055632994502 := by decide
theorem cert_e2259539972294 : check e2259539972294 [[]] .width = true := by decide
def e2259540373018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259540373018 : Closed e2259540373018 ∧ code e2259540373018 = 11055633395226 := by decide
theorem cert_e2259540373018 : check e2259540373018 [[]] .width = true := by decide
def e2259540475930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259540475930 : Closed e2259540475930 ∧ code e2259540475930 = 11055633498138 := by decide
theorem cert_e2259540475930 : check e2259540475930 [[]] .width = true := by decide
def e2259540476022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259540476022 : Closed e2259540476022 ∧ code e2259540476022 = 11055633498230 := by decide
theorem cert_e2259540476022 : check e2259540476022 [[]] .width = true := by decide
def e2259540476266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259540476266 : Closed e2259540476266 ∧ code e2259540476266 = 11055633498474 := by decide
theorem cert_e2259540476266 : check e2259540476266 [[]] .width = true := by decide
def e2259540476314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259540476314 : Closed e2259540476314 ∧ code e2259540476314 = 11055633498522 := by decide
theorem cert_e2259540476314 : check e2259540476314 [[]] .width = true := by decide
def e2259540477322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259540477322 : Closed e2259540477322 ∧ code e2259540477322 = 11055633499530 := by decide
theorem cert_e2259540477322 : check e2259540477322 [[]] .width = true := by decide
def e2259540477346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259540477346 : Closed e2259540477346 ∧ code e2259540477346 = 11055633499554 := by decide
theorem cert_e2259540477346 : check e2259540477346 [[]] .width = true := by decide
def e2259540477454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259540477454 : Closed e2259540477454 ∧ code e2259540477454 = 11055633499662 := by decide
theorem cert_e2259540477454 : check e2259540477454 [[]] .width = true := by decide
def e2259540477466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259540477466 : Closed e2259540477466 ∧ code e2259540477466 = 11055633499674 := by decide
theorem cert_e2259540477466 : check e2259540477466 [[]] .width = true := by decide
def e2259540477538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259540477538 : Closed e2259540477538 ∧ code e2259540477538 = 11055633499746 := by decide
theorem cert_e2259540477538 : check e2259540477538 [[]] .width = true := by decide
def e2259540667930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259540667930 : Closed e2259540667930 ∧ code e2259540667930 = 11055633690138 := by decide
theorem cert_e2259540667930 : check e2259540667930 [[]] .width = true := by decide
def e2259540671002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259540671002 : Closed e2259540671002 ∧ code e2259540671002 = 11055633693210 := by decide
theorem cert_e2259540671002 : check e2259540671002 [[]] .width = true := by decide
def e2259540672538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259540672538 : Closed e2259540672538 ∧ code e2259540672538 = 11055633694746 := by decide
theorem cert_e2259540672538 : check e2259540672538 [[]] .width = true := by decide
def e2259540672630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259540672630 : Closed e2259540672630 ∧ code e2259540672630 = 11055633694838 := by decide
theorem cert_e2259540672630 : check e2259540672630 [[]] .width = true := by decide
def e2259540672874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259540672874 : Closed e2259540672874 ∧ code e2259540672874 = 11055633695082 := by decide
theorem cert_e2259540672874 : check e2259540672874 [[]] .width = true := by decide
def e2259540672922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259540672922 : Closed e2259540672922 ∧ code e2259540672922 = 11055633695130 := by decide
theorem cert_e2259540672922 : check e2259540672922 [[]] .width = true := by decide
def e2259540673930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259540673930 : Closed e2259540673930 ∧ code e2259540673930 = 11055633696138 := by decide
theorem cert_e2259540673930 : check e2259540673930 [[]] .width = true := by decide
def e2259540673954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259540673954 : Closed e2259540673954 ∧ code e2259540673954 = 11055633696162 := by decide
theorem cert_e2259540673954 : check e2259540673954 [[]] .width = true := by decide
def e2259540674062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259540674062 : Closed e2259540674062 ∧ code e2259540674062 = 11055633696270 := by decide
theorem cert_e2259540674062 : check e2259540674062 [[]] .width = true := by decide
def e2259540674074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259540674074 : Closed e2259540674074 ∧ code e2259540674074 = 11055633696282 := by decide
theorem cert_e2259540674074 : check e2259540674074 [[]] .width = true := by decide
def e2259540674146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259540674146 : Closed e2259540674146 ∧ code e2259540674146 = 11055633696354 := by decide
theorem cert_e2259540674146 : check e2259540674146 [[]] .width = true := by decide
def e2259541913798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259541913798 : Closed e2259541913798 ∧ code e2259541913798 = 11055634936006 := by decide
theorem cert_e2259541913798 : check e2259541913798 [[]] .width = true := by decide
def e2259541945882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259541945882 : Closed e2259541945882 ∧ code e2259541945882 = 11055634968090 := by decide
theorem cert_e2259541945882 : check e2259541945882 [[]] .width = true := by decide
def e2259542196422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259542196422 : Closed e2259542196422 ∧ code e2259542196422 = 11055635218630 := by decide
theorem cert_e2259542196422 : check e2259542196422 [[]] .width = true := by decide
def e2259542269978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259542269978 : Closed e2259542269978 ∧ code e2259542269978 = 11055635292186 := by decide
theorem cert_e2259542269978 : check e2259542269978 [[]] .width = true := by decide
def e2259542270070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259542270070 : Closed e2259542270070 ∧ code e2259542270070 = 11055635292278 := by decide
theorem cert_e2259542270070 : check e2259542270070 [[]] .width = true := by decide
def e2259542270314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259542270314 : Closed e2259542270314 ∧ code e2259542270314 = 11055635292522 := by decide
theorem cert_e2259542270314 : check e2259542270314 [[]] .width = true := by decide
def e2259542270362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259542270362 : Closed e2259542270362 ∧ code e2259542270362 = 11055635292570 := by decide
theorem cert_e2259542270362 : check e2259542270362 [[]] .width = true := by decide
def e2259542282438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259542282438 : Closed e2259542282438 ∧ code e2259542282438 = 11055635304646 := by decide
theorem cert_e2259542282438 : check e2259542282438 [[]] .width = true := by decide
def e2259542285850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259542285850 : Closed e2259542285850 ∧ code e2259542285850 = 11055635308058 := by decide
theorem cert_e2259542285850 : check e2259542285850 [[]] .width = true := by decide
def e2259542294726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259542294726 : Closed e2259542294726 ∧ code e2259542294726 = 11055635316934 := by decide
theorem cert_e2259542294726 : check e2259542294726 [[]] .width = true := by decide
def e2259542302746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259542302746 : Closed e2259542302746 ∧ code e2259542302746 = 11055635324954 := by decide
theorem cert_e2259542302746 : check e2259542302746 [[]] .width = true := by decide
def e2259542302838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259542302838 : Closed e2259542302838 ∧ code e2259542302838 = 11055635325046 := by decide
theorem cert_e2259542302838 : check e2259542302838 [[]] .width = true := by decide
def e2259542303082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259542303082 : Closed e2259542303082 ∧ code e2259542303082 = 11055635325290 := by decide
theorem cert_e2259542303082 : check e2259542303082 [[]] .width = true := by decide
def e2259542303130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259542303130 : Closed e2259542303130 ∧ code e2259542303130 = 11055635325338 := by decide
theorem cert_e2259542303130 : check e2259542303130 [[]] .width = true := by decide
def e2259542307014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259542307014 : Closed e2259542307014 ∧ code e2259542307014 = 11055635329222 := by decide
theorem cert_e2259542307014 : check e2259542307014 [[]] .width = true := by decide
def e2259542532122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259542532122 : Closed e2259542532122 ∧ code e2259542532122 = 11055635554330 := by decide
theorem cert_e2259542532122 : check e2259542532122 [[]] .width = true := by decide
def e2259542532214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259542532214 : Closed e2259542532214 ∧ code e2259542532214 = 11055635554422 := by decide
theorem cert_e2259542532214 : check e2259542532214 [[]] .width = true := by decide
def e2259542532458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259542532458 : Closed e2259542532458 ∧ code e2259542532458 = 11055635554666 := by decide
theorem cert_e2259542532458 : check e2259542532458 [[]] .width = true := by decide
def e2259542532506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259542532506 : Closed e2259542532506 ∧ code e2259542532506 = 11055635554714 := by decide
theorem cert_e2259542532506 : check e2259542532506 [[]] .width = true := by decide
def e2259542581274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259542581274 : Closed e2259542581274 ∧ code e2259542581274 = 11055635603482 := by decide
theorem cert_e2259542581274 : check e2259542581274 [[]] .width = true := by decide
def e2259542581366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259542581366 : Closed e2259542581366 ∧ code e2259542581366 = 11055635603574 := by decide
theorem cert_e2259542581366 : check e2259542581366 [[]] .width = true := by decide
def e2259542581610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259542581610 : Closed e2259542581610 ∧ code e2259542581610 = 11055635603818 := by decide
theorem cert_e2259542581610 : check e2259542581610 [[]] .width = true := by decide
def e2259542581658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259542581658 : Closed e2259542581658 ∧ code e2259542581658 = 11055635603866 := by decide
theorem cert_e2259542581658 : check e2259542581658 [[]] .width = true := by decide
def e2259542626502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259542626502 : Closed e2259542626502 ∧ code e2259542626502 = 11055635648710 := by decide
theorem cert_e2259542626502 : check e2259542626502 [[]] .width = true := by decide
def e2259542634010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259542634010 : Closed e2259542634010 ∧ code e2259542634010 = 11055635656218 := by decide
theorem cert_e2259542634010 : check e2259542634010 [[]] .width = true := by decide
def e2259542637082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259542637082 : Closed e2259542637082 ∧ code e2259542637082 = 11055635659290 := by decide
theorem cert_e2259542637082 : check e2259542637082 [[]] .width = true := by decide
def e2259542675654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259542675654 : Closed e2259542675654 ∧ code e2259542675654 = 11055635697862 := by decide
theorem cert_e2259542675654 : check e2259542675654 [[]] .width = true := by decide
def e2259542679066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259542679066 : Closed e2259542679066 ∧ code e2259542679066 = 11055635701274 := by decide
theorem cert_e2259542679066 : check e2259542679066 [[]] .width = true := by decide
def e2259542687942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259542687942 : Closed e2259542687942 ∧ code e2259542687942 = 11055635710150 := by decide
theorem cert_e2259542687942 : check e2259542687942 [[]] .width = true := by decide
def e2259542695962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259542695962 : Closed e2259542695962 ∧ code e2259542695962 = 11055635718170 := by decide
theorem cert_e2259542695962 : check e2259542695962 [[]] .width = true := by decide
def e2259542696054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259542696054 : Closed e2259542696054 ∧ code e2259542696054 = 11055635718262 := by decide
theorem cert_e2259542696054 : check e2259542696054 [[]] .width = true := by decide
def e2259542696298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259542696298 : Closed e2259542696298 ∧ code e2259542696298 = 11055635718506 := by decide
theorem cert_e2259542696298 : check e2259542696298 [[]] .width = true := by decide
def e2259542696346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259542696346 : Closed e2259542696346 ∧ code e2259542696346 = 11055635718554 := by decide
theorem cert_e2259542696346 : check e2259542696346 [[]] .width = true := by decide
def e2259542700230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259542700230 : Closed e2259542700230 ∧ code e2259542700230 = 11055635722438 := by decide
theorem cert_e2259542700230 : check e2259542700230 [[]] .width = true := by decide
def e2259542712346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259542712346 : Closed e2259542712346 ∧ code e2259542712346 = 11055635734554 := by decide
theorem cert_e2259542712346 : check e2259542712346 [[]] .width = true := by decide
def e2259542712438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259542712438 : Closed e2259542712438 ∧ code e2259542712438 = 11055635734646 := by decide
theorem cert_e2259542712438 : check e2259542712438 [[]] .width = true := by decide
def e2259542712682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259542712682 : Closed e2259542712682 ∧ code e2259542712682 = 11055635734890 := by decide
theorem cert_e2259542712682 : check e2259542712682 [[]] .width = true := by decide
def e2259542712730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259542712730 : Closed e2259542712730 ∧ code e2259542712730 = 11055635734938 := by decide
theorem cert_e2259542712730 : check e2259542712730 [[]] .width = true := by decide
def e2259542722074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259542722074 : Closed e2259542722074 ∧ code e2259542722074 = 11055635744282 := by decide
theorem cert_e2259542722074 : check e2259542722074 [[]] .width = true := by decide
def e2259542724806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259542724806 : Closed e2259542724806 ∧ code e2259542724806 = 11055635747014 := by decide
theorem cert_e2259542724806 : check e2259542724806 [[]] .width = true := by decide
def e2259543359514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259543359514 : Closed e2259543359514 ∧ code e2259543359514 = 11055636381722 := by decide
theorem cert_e2259543359514 : check e2259543359514 [[]] .width = true := by decide
def e2259543359606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259543359606 : Closed e2259543359606 ∧ code e2259543359606 = 11055636381814 := by decide
theorem cert_e2259543359606 : check e2259543359606 [[]] .width = true := by decide
def e2259543359850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259543359850 : Closed e2259543359850 ∧ code e2259543359850 = 11055636382058 := by decide
theorem cert_e2259543359850 : check e2259543359850 [[]] .width = true := by decide
def e2259543359898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259543359898 : Closed e2259543359898 ∧ code e2259543359898 = 11055636382106 := by decide
theorem cert_e2259543359898 : check e2259543359898 [[]] .width = true := by decide
def e2259543360906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259543360906 : Closed e2259543360906 ∧ code e2259543360906 = 11055636383114 := by decide
theorem cert_e2259543360906 : check e2259543360906 [[]] .width = true := by decide
def e2259543360930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259543360930 : Closed e2259543360930 ∧ code e2259543360930 = 11055636383138 := by decide
theorem cert_e2259543360930 : check e2259543360930 [[]] .width = true := by decide
def e2259543361038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259543361038 : Closed e2259543361038 ∧ code e2259543361038 = 11055636383246 := by decide
theorem cert_e2259543361038 : check e2259543361038 [[]] .width = true := by decide
def e2259543361050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259543361050 : Closed e2259543361050 ∧ code e2259543361050 = 11055636383258 := by decide
theorem cert_e2259543361050 : check e2259543361050 [[]] .width = true := by decide
def e2259543361122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259543361122 : Closed e2259543361122 ∧ code e2259543361122 = 11055636383330 := by decide
theorem cert_e2259543361122 : check e2259543361122 [[]] .width = true := by decide
def e2259543769286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259543769286 : Closed e2259543769286 ∧ code e2259543769286 = 11055636791494 := by decide
theorem cert_e2259543769286 : check e2259543769286 [[]] .width = true := by decide
def e2259543842842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259543842842 : Closed e2259543842842 ∧ code e2259543842842 = 11055636865050 := by decide
theorem cert_e2259543842842 : check e2259543842842 [[]] .width = true := by decide
def e2259543842934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259543842934 : Closed e2259543842934 ∧ code e2259543842934 = 11055636865142 := by decide
theorem cert_e2259543842934 : check e2259543842934 [[]] .width = true := by decide
def e2259543843178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259543843178 : Closed e2259543843178 ∧ code e2259543843178 = 11055636865386 := by decide
theorem cert_e2259543843178 : check e2259543843178 [[]] .width = true := by decide
def e2259543843226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259543843226 : Closed e2259543843226 ∧ code e2259543843226 = 11055636865434 := by decide
theorem cert_e2259543843226 : check e2259543843226 [[]] .width = true := by decide
def e2259543855302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259543855302 : Closed e2259543855302 ∧ code e2259543855302 = 11055636877510 := by decide
theorem cert_e2259543855302 : check e2259543855302 [[]] .width = true := by decide
def e2259543858714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259543858714 : Closed e2259543858714 ∧ code e2259543858714 = 11055636880922 := by decide
theorem cert_e2259543858714 : check e2259543858714 [[]] .width = true := by decide
def e2259543867590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259543867590 : Closed e2259543867590 ∧ code e2259543867590 = 11055636889798 := by decide
theorem cert_e2259543867590 : check e2259543867590 [[]] .width = true := by decide
def e2259543875610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259543875610 : Closed e2259543875610 ∧ code e2259543875610 = 11055636897818 := by decide
theorem cert_e2259543875610 : check e2259543875610 [[]] .width = true := by decide
def e2259543875702 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259543875702 : Closed e2259543875702 ∧ code e2259543875702 = 11055636897910 := by decide
theorem cert_e2259543875702 : check e2259543875702 [[]] .width = true := by decide
def e2259543875946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259543875946 : Closed e2259543875946 ∧ code e2259543875946 = 11055636898154 := by decide
theorem cert_e2259543875946 : check e2259543875946 [[]] .width = true := by decide
def e2259543875994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259543875994 : Closed e2259543875994 ∧ code e2259543875994 = 11055636898202 := by decide
theorem cert_e2259543875994 : check e2259543875994 [[]] .width = true := by decide
def e2259543879878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259543879878 : Closed e2259543879878 ∧ code e2259543879878 = 11055636902086 := by decide
theorem cert_e2259543879878 : check e2259543879878 [[]] .width = true := by decide
def e2259544703174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259544703174 : Closed e2259544703174 ∧ code e2259544703174 = 11055637725382 := by decide
theorem cert_e2259544703174 : check e2259544703174 [[]] .width = true := by decide
def e2259544703702 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259544703702 : Closed e2259544703702 ∧ code e2259544703702 = 11055637725910 := by decide
theorem cert_e2259544703702 : check e2259544703702 [[]] .width = true := by decide
def e2259544703706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259544703706 : Closed e2259544703706 ∧ code e2259544703706 = 11055637725914 := by decide
theorem cert_e2259544703706 : check e2259544703706 [[]] .width = true := by decide
def e2259544703722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259544703722 : Closed e2259544703722 ∧ code e2259544703722 = 11055637725930 := by decide
theorem cert_e2259544703722 : check e2259544703722 [[]] .width = true := by decide
def e2259544703798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259544703798 : Closed e2259544703798 ∧ code e2259544703798 = 11055637726006 := by decide
theorem cert_e2259544703798 : check e2259544703798 [[]] .width = true := by decide
def e2259544703802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259544703802 : Closed e2259544703802 ∧ code e2259544703802 = 11055637726010 := by decide
theorem cert_e2259544703802 : check e2259544703802 [[]] .width = true := by decide
def e2259544703886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259544703886 : Closed e2259544703886 ∧ code e2259544703886 = 11055637726094 := by decide
theorem cert_e2259544703886 : check e2259544703886 [[]] .width = true := by decide
def e2259544703898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259544703898 : Closed e2259544703898 ∧ code e2259544703898 = 11055637726106 := by decide
theorem cert_e2259544703898 : check e2259544703898 [[]] .width = true := by decide
def e2259544705818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259544705818 : Closed e2259544705818 ∧ code e2259544705818 = 11055637728026 := by decide
theorem cert_e2259544705818 : check e2259544705818 [[]] .width = true := by decide
def e2259544705862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259544705862 : Closed e2259544705862 ∧ code e2259544705862 = 11055637728070 := by decide
theorem cert_e2259544705862 : check e2259544705862 [[]] .width = true := by decide
def e2259544705974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259544705974 : Closed e2259544705974 ∧ code e2259544705974 = 11055637728182 := by decide
theorem cert_e2259544705974 : check e2259544705974 [[]] .width = true := by decide
def e2259544706102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259544706102 : Closed e2259544706102 ∧ code e2259544706102 = 11055637728310 := by decide
theorem cert_e2259544706102 : check e2259544706102 [[]] .width = true := by decide
def e2259544706106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259544706106 : Closed e2259544706106 ∧ code e2259544706106 = 11055637728314 := by decide
theorem cert_e2259544706106 : check e2259544706106 [[]] .width = true := by decide
def e2259544706246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259544706246 : Closed e2259544706246 ∧ code e2259544706246 = 11055637728454 := by decide
theorem cert_e2259544706246 : check e2259544706246 [[]] .width = true := by decide
def e2259544706586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259544706586 : Closed e2259544706586 ∧ code e2259544706586 = 11055637728794 := by decide
theorem cert_e2259544706586 : check e2259544706586 [[]] .width = true := by decide
def e2259544706678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259544706678 : Closed e2259544706678 ∧ code e2259544706678 = 11055637728886 := by decide
theorem cert_e2259544706678 : check e2259544706678 [[]] .width = true := by decide
def e2259544714266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259544714266 : Closed e2259544714266 ∧ code e2259544714266 = 11055637736474 := by decide
theorem cert_e2259544714266 : check e2259544714266 [[]] .width = true := by decide
def e2259544714310 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259544714310 : Closed e2259544714310 ∧ code e2259544714310 = 11055637736518 := by decide
theorem cert_e2259544714310 : check e2259544714310 [[]] .width = true := by decide
def e2259544714338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259544714338 : Closed e2259544714338 ∧ code e2259544714338 = 11055637736546 := by decide
theorem cert_e2259544714338 : check e2259544714338 [[]] .width = true := by decide
def e2259544714502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259544714502 : Closed e2259544714502 ∧ code e2259544714502 = 11055637736710 := by decide
theorem cert_e2259544714502 : check e2259544714502 [[]] .width = true := by decide
def e2259544715294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259544715294 : Closed e2259544715294 ∧ code e2259544715294 = 11055637737502 := by decide
theorem cert_e2259544715294 : check e2259544715294 [[]] .width = true := by decide
def e2259544715462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259544715462 : Closed e2259544715462 ∧ code e2259544715462 = 11055637737670 := by decide
theorem cert_e2259544715462 : check e2259544715462 [[]] .width = true := by decide
def e2259544715490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259544715490 : Closed e2259544715490 ∧ code e2259544715490 = 11055637737698 := by decide
theorem cert_e2259544715490 : check e2259544715490 [[]] .width = true := by decide
def e2259544716038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259544716038 : Closed e2259544716038 ∧ code e2259544716038 = 11055637738246 := by decide
theorem cert_e2259544716038 : check e2259544716038 [[]] .width = true := by decide
def e2259545415706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259545415706 : Closed e2259545415706 ∧ code e2259545415706 = 11055638437914 := by decide
theorem cert_e2259545415706 : check e2259545415706 [[]] .width = true := by decide
def e2259545415798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259545415798 : Closed e2259545415798 ∧ code e2259545415798 = 11055638438006 := by decide
theorem cert_e2259545415798 : check e2259545415798 [[]] .width = true := by decide
def e2259545416042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259545416042 : Closed e2259545416042 ∧ code e2259545416042 = 11055638438250 := by decide
theorem cert_e2259545416042 : check e2259545416042 [[]] .width = true := by decide
def e2259545416090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259545416090 : Closed e2259545416090 ∧ code e2259545416090 = 11055638438298 := by decide
theorem cert_e2259545416090 : check e2259545416090 [[]] .width = true := by decide
def e2259545464858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259545464858 : Closed e2259545464858 ∧ code e2259545464858 = 11055638487066 := by decide
theorem cert_e2259545464858 : check e2259545464858 [[]] .width = true := by decide
def e2259545464950 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259545464950 : Closed e2259545464950 ∧ code e2259545464950 = 11055638487158 := by decide
theorem cert_e2259545464950 : check e2259545464950 [[]] .width = true := by decide
def e2259545465194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259545465194 : Closed e2259545465194 ∧ code e2259545465194 = 11055638487402 := by decide
theorem cert_e2259545465194 : check e2259545465194 [[]] .width = true := by decide
def e2259545465242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259545465242 : Closed e2259545465242 ∧ code e2259545465242 = 11055638487450 := by decide
theorem cert_e2259545465242 : check e2259545465242 [[]] .width = true := by decide
def e2259546042566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259546042566 : Closed e2259546042566 ∧ code e2259546042566 = 11055639064774 := by decide
theorem cert_e2259546042566 : check e2259546042566 [[]] .width = true := by decide
def e2259546112026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259546112026 : Closed e2259546112026 ∧ code e2259546112026 = 11055639134234 := by decide
theorem cert_e2259546112026 : check e2259546112026 [[]] .width = true := by decide
def e2259546112118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259546112118 : Closed e2259546112118 ∧ code e2259546112118 = 11055639134326 := by decide
theorem cert_e2259546112118 : check e2259546112118 [[]] .width = true := by decide
def e2259546112362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259546112362 : Closed e2259546112362 ∧ code e2259546112362 = 11055639134570 := by decide
theorem cert_e2259546112362 : check e2259546112362 [[]] .width = true := by decide
def e2259546112410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259546112410 : Closed e2259546112410 ∧ code e2259546112410 = 11055639134618 := by decide
theorem cert_e2259546112410 : check e2259546112410 [[]] .width = true := by decide
def e2259546113418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259546113418 : Closed e2259546113418 ∧ code e2259546113418 = 11055639135626 := by decide
theorem cert_e2259546113418 : check e2259546113418 [[]] .width = true := by decide
def e2259546113442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259546113442 : Closed e2259546113442 ∧ code e2259546113442 = 11055639135650 := by decide
theorem cert_e2259546113442 : check e2259546113442 [[]] .width = true := by decide
def e2259546113550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259546113550 : Closed e2259546113550 ∧ code e2259546113550 = 11055639135758 := by decide
theorem cert_e2259546113550 : check e2259546113550 [[]] .width = true := by decide
def e2259546113562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259546113562 : Closed e2259546113562 ∧ code e2259546113562 = 11055639135770 := by decide
theorem cert_e2259546113562 : check e2259546113562 [[]] .width = true := by decide
def e2259546113634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259546113634 : Closed e2259546113634 ∧ code e2259546113634 = 11055639135842 := by decide
theorem cert_e2259546113634 : check e2259546113634 [[]] .width = true := by decide
def e2259546214598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259546214598 : Closed e2259546214598 ∧ code e2259546214598 = 11055639236806 := by decide
theorem cert_e2259546214598 : check e2259546214598 [[]] .width = true := by decide
def e2259546218010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259546218010 : Closed e2259546218010 ∧ code e2259546218010 = 11055639240218 := by decide
theorem cert_e2259546218010 : check e2259546218010 [[]] .width = true := by decide
def e2259546226886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259546226886 : Closed e2259546226886 ∧ code e2259546226886 = 11055639249094 := by decide
theorem cert_e2259546226886 : check e2259546226886 [[]] .width = true := by decide
def e2259546234906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259546234906 : Closed e2259546234906 ∧ code e2259546234906 = 11055639257114 := by decide
theorem cert_e2259546234906 : check e2259546234906 [[]] .width = true := by decide
def e2259546234998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259546234998 : Closed e2259546234998 ∧ code e2259546234998 = 11055639257206 := by decide
theorem cert_e2259546234998 : check e2259546234998 [[]] .width = true := by decide
def e2259546235242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259546235242 : Closed e2259546235242 ∧ code e2259546235242 = 11055639257450 := by decide
theorem cert_e2259546235242 : check e2259546235242 [[]] .width = true := by decide
def e2259546235290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259546235290 : Closed e2259546235290 ∧ code e2259546235290 = 11055639257498 := by decide
theorem cert_e2259546235290 : check e2259546235290 [[]] .width = true := by decide
def e2259546239174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259546239174 : Closed e2259546239174 ∧ code e2259546239174 = 11055639261382 := by decide
theorem cert_e2259546239174 : check e2259546239174 [[]] .width = true := by decide
def e2259546251290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259546251290 : Closed e2259546251290 ∧ code e2259546251290 = 11055639273498 := by decide
theorem cert_e2259546251290 : check e2259546251290 [[]] .width = true := by decide
def e2259546251382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259546251382 : Closed e2259546251382 ∧ code e2259546251382 = 11055639273590 := by decide
theorem cert_e2259546251382 : check e2259546251382 [[]] .width = true := by decide
def e2259546251626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259546251626 : Closed e2259546251626 ∧ code e2259546251626 = 11055639273834 := by decide
theorem cert_e2259546251626 : check e2259546251626 [[]] .width = true := by decide
def e2259546251674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259546251674 : Closed e2259546251674 ∧ code e2259546251674 = 11055639273882 := by decide
theorem cert_e2259546251674 : check e2259546251674 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259537365942
#print axioms Blc.Floor43.cert_e2259537366554
#print axioms Blc.Floor43.cert_e2259537366646
#print axioms Blc.Floor43.cert_e2259537374470
