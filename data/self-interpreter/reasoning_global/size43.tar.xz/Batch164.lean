import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262374216662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2262374216662 : Closed e2262374216662 ∧ code e2262374216662 = 11058467238870 := by decide
theorem cert_e2262374216662 : check e2262374216662 [[],[.under]] .smaller = true := by decide
def e2262374216666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2262374216666 : Closed e2262374216666 ∧ code e2262374216666 = 11058467238874 := by decide
theorem cert_e2262374216666 : check e2262374216666 [[],[.under]] .smaller = true := by decide
def e2262374216682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2262374216682 : Closed e2262374216682 ∧ code e2262374216682 = 11058467238890 := by decide
theorem cert_e2262374216682 : check e2262374216682 [[],[.under]] .smaller = true := by decide
def e2262374216926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2262374216926 : Closed e2262374216926 ∧ code e2262374216926 = 11058467239134 := by decide
theorem cert_e2262374216926 : check e2262374216926 [[],[.under]] .smaller = true := by decide
def e2262374216942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262374216942 : Closed e2262374216942 ∧ code e2262374216942 = 11058467239150 := by decide
theorem cert_e2262374216942 : check e2262374216942 [[],[.under]] .smaller = true := by decide
def e2262374216950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262374216950 : Closed e2262374216950 ∧ code e2262374216950 = 11058467239158 := by decide
theorem cert_e2262374216950 : check e2262374216950 [[],[.under]] .smaller = true := by decide
def e2262374216954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2262374216954 : Closed e2262374216954 ∧ code e2262374216954 = 11058467239162 := by decide
theorem cert_e2262374216954 : check e2262374216954 [[],[.under]] .smaller = true := by decide
def e2262374217326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374217326 : Closed e2262374217326 ∧ code e2262374217326 = 11058467239534 := by decide
theorem cert_e2262374217326 : check e2262374217326 [[],[.under]] .smaller = true := by decide
def e2262374217338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374217338 : Closed e2262374217338 ∧ code e2262374217338 = 11058467239546 := by decide
theorem cert_e2262374217338 : check e2262374217338 [[],[.under]] .smaller = true := by decide
def e2262374217526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374217526 : Closed e2262374217526 ∧ code e2262374217526 = 11058467239734 := by decide
theorem cert_e2262374217526 : check e2262374217526 [[],[.under]] .smaller = true := by decide
def e2262374217530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374217530 : Closed e2262374217530 ∧ code e2262374217530 = 11058467239738 := by decide
theorem cert_e2262374217530 : check e2262374217530 [[],[.under]] .smaller = true := by decide
def e2262374217626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374217626 : Closed e2262374217626 ∧ code e2262374217626 = 11058467239834 := by decide
theorem cert_e2262374217626 : check e2262374217626 [[],[.under]] .smaller = true := by decide
def e2262374218158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2262374218158 : Closed e2262374218158 ∧ code e2262374218158 = 11058467240366 := by decide
theorem cert_e2262374218158 : check e2262374218158 [[],[.under]] .smaller = true := by decide
def e2262374218166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2262374218166 : Closed e2262374218166 ∧ code e2262374218166 = 11058467240374 := by decide
theorem cert_e2262374218166 : check e2262374218166 [[],[.under]] .smaller = true := by decide
def e2262374218170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2262374218170 : Closed e2262374218170 ∧ code e2262374218170 = 11058467240378 := by decide
theorem cert_e2262374218170 : check e2262374218170 [[],[.under]] .smaller = true := by decide
def e2262374218198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2262374218198 : Closed e2262374218198 ∧ code e2262374218198 = 11058467240406 := by decide
theorem cert_e2262374218198 : check e2262374218198 [[],[.under]] .smaller = true := by decide
def e2262374218202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2262374218202 : Closed e2262374218202 ∧ code e2262374218202 = 11058467240410 := by decide
theorem cert_e2262374218202 : check e2262374218202 [[],[.under]] .smaller = true := by decide
def e2262374218218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2262374218218 : Closed e2262374218218 ∧ code e2262374218218 = 11058467240426 := by decide
theorem cert_e2262374218218 : check e2262374218218 [[],[.under]] .smaller = true := by decide
def e2262374218350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374218350 : Closed e2262374218350 ∧ code e2262374218350 = 11058467240558 := by decide
theorem cert_e2262374218350 : check e2262374218350 [[],[.under]] .smaller = true := by decide
def e2262374218358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262374218358 : Closed e2262374218358 ∧ code e2262374218358 = 11058467240566 := by decide
theorem cert_e2262374218358 : check e2262374218358 [[],[.under]] .smaller = true := by decide
def e2262374218362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374218362 : Closed e2262374218362 ∧ code e2262374218362 = 11058467240570 := by decide
theorem cert_e2262374218362 : check e2262374218362 [[],[.under]] .smaller = true := by decide
def e2262374218550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374218550 : Closed e2262374218550 ∧ code e2262374218550 = 11058467240758 := by decide
theorem cert_e2262374218550 : check e2262374218550 [[],[.under]] .smaller = true := by decide
def e2262374218554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374218554 : Closed e2262374218554 ∧ code e2262374218554 = 11058467240762 := by decide
theorem cert_e2262374218554 : check e2262374218554 [[],[.under]] .smaller = true := by decide
def e2262374218650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374218650 : Closed e2262374218650 ∧ code e2262374218650 = 11058467240858 := by decide
theorem cert_e2262374218650 : check e2262374218650 [[],[.under]] .smaller = true := by decide
def e2262374218966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2262374218966 : Closed e2262374218966 ∧ code e2262374218966 = 11058467241174 := by decide
theorem cert_e2262374218966 : check e2262374218966 [[],[.under]] .three = true := by decide
def e2262374218970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2262374218970 : Closed e2262374218970 ∧ code e2262374218970 = 11058467241178 := by decide
theorem cert_e2262374218970 : check e2262374218970 [[],[.under]] .three = true := by decide
def e2262374218986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2262374218986 : Closed e2262374218986 ∧ code e2262374218986 = 11058467241194 := by decide
theorem cert_e2262374218986 : check e2262374218986 [[],[.under]] .three = true := by decide
def e2262374219062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374219062 : Closed e2262374219062 ∧ code e2262374219062 = 11058467241270 := by decide
theorem cert_e2262374219062 : check e2262374219062 [[],[.under]] .three = true := by decide
def e2262374219066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374219066 : Closed e2262374219066 ∧ code e2262374219066 = 11058467241274 := by decide
theorem cert_e2262374219066 : check e2262374219066 [[],[.under]] .three = true := by decide
def e2262374219162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374219162 : Closed e2262374219162 ∧ code e2262374219162 = 11058467241370 := by decide
theorem cert_e2262374219162 : check e2262374219162 [[],[.under]] .three = true := by decide
def e2262374222702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2262374222702 : Closed e2262374222702 ∧ code e2262374222702 = 11058467244910 := by decide
theorem cert_e2262374222702 : check e2262374222702 [[],[.under]] .smaller = true := by decide
def e2262374222710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2262374222710 : Closed e2262374222710 ∧ code e2262374222710 = 11058467244918 := by decide
theorem cert_e2262374222710 : check e2262374222710 [[],[.under]] .smaller = true := by decide
def e2262374222766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2262374222766 : Closed e2262374222766 ∧ code e2262374222766 = 11058467244974 := by decide
theorem cert_e2262374222766 : check e2262374222766 [[],[.under]] .smaller = true := by decide
def e2262374222778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2262374222778 : Closed e2262374222778 ∧ code e2262374222778 = 11058467244986 := by decide
theorem cert_e2262374222778 : check e2262374222778 [[],[.under]] .smaller = true := by decide
def e2262374222806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2262374222806 : Closed e2262374222806 ∧ code e2262374222806 = 11058467245014 := by decide
theorem cert_e2262374222806 : check e2262374222806 [[],[.under]] .smaller = true := by decide
def e2262374222810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2262374222810 : Closed e2262374222810 ∧ code e2262374222810 = 11058467245018 := by decide
theorem cert_e2262374222810 : check e2262374222810 [[],[.under]] .smaller = true := by decide
def e2262374223086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2262374223086 : Closed e2262374223086 ∧ code e2262374223086 = 11058467245294 := by decide
theorem cert_e2262374223086 : check e2262374223086 [[],[.under]] .smaller = true := by decide
def e2262374223094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2262374223094 : Closed e2262374223094 ∧ code e2262374223094 = 11058467245302 := by decide
theorem cert_e2262374223094 : check e2262374223094 [[],[.under]] .smaller = true := by decide
def e2262374223470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2262374223470 : Closed e2262374223470 ∧ code e2262374223470 = 11058467245678 := by decide
theorem cert_e2262374223470 : check e2262374223470 [[],[.under]] .smaller = true := by decide
def e2262374223482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2262374223482 : Closed e2262374223482 ∧ code e2262374223482 = 11058467245690 := by decide
theorem cert_e2262374223482 : check e2262374223482 [[],[.under]] .smaller = true := by decide
def e2262374223670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2262374223670 : Closed e2262374223670 ∧ code e2262374223670 = 11058467245878 := by decide
theorem cert_e2262374223670 : check e2262374223670 [[],[.under]] .smaller = true := by decide
def e2262374223674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2262374223674 : Closed e2262374223674 ∧ code e2262374223674 = 11058467245882 := by decide
theorem cert_e2262374223674 : check e2262374223674 [[],[.under]] .smaller = true := by decide
def e2262374231486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2262374231486 : Closed e2262374231486 ∧ code e2262374231486 = 11058467253694 := by decide
theorem cert_e2262374231486 : check e2262374231486 [[],[.under]] .three = true := by decide
def e2262374231518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2262374231518 : Closed e2262374231518 ∧ code e2262374231518 = 11058467253726 := by decide
theorem cert_e2262374231518 : check e2262374231518 [[],[.under]] .smaller = true := by decide
def e2262374231534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2262374231534 : Closed e2262374231534 ∧ code e2262374231534 = 11058467253742 := by decide
theorem cert_e2262374231534 : check e2262374231534 [[],[.under]] .smaller = true := by decide
def e2262374231542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2262374231542 : Closed e2262374231542 ∧ code e2262374231542 = 11058467253750 := by decide
theorem cert_e2262374231542 : check e2262374231542 [[],[.under]] .three = true := by decide
def e2262374231742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2262374231742 : Closed e2262374231742 ∧ code e2262374231742 = 11058467253950 := by decide
theorem cert_e2262374231742 : check e2262374231742 [[],[.under]] .three = true := by decide
def e2262374231774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2262374231774 : Closed e2262374231774 ∧ code e2262374231774 = 11058467253982 := by decide
theorem cert_e2262374231774 : check e2262374231774 [[],[.under]] .smaller = true := by decide
def e2262374231790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e2262374231790 : Closed e2262374231790 ∧ code e2262374231790 = 11058467253998 := by decide
theorem cert_e2262374231790 : check e2262374231790 [[],[.under]] .smaller = true := by decide
def e2262374231798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2262374231798 : Closed e2262374231798 ∧ code e2262374231798 = 11058467254006 := by decide
theorem cert_e2262374231798 : check e2262374231798 [[],[.under]] .smaller = true := by decide
def e2262374231802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2262374231802 : Closed e2262374231802 ∧ code e2262374231802 = 11058467254010 := by decide
theorem cert_e2262374231802 : check e2262374231802 [[],[.under]] .three = true := by decide
def e2262374231902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2262374231902 : Closed e2262374231902 ∧ code e2262374231902 = 11058467254110 := by decide
theorem cert_e2262374231902 : check e2262374231902 [[],[.under]] .smaller = true := by decide
def e2262374231918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e2262374231918 : Closed e2262374231918 ∧ code e2262374231918 = 11058467254126 := by decide
theorem cert_e2262374231918 : check e2262374231918 [[],[.under]] .smaller = true := by decide
def e2262374231926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e2262374231926 : Closed e2262374231926 ∧ code e2262374231926 = 11058467254134 := by decide
theorem cert_e2262374231926 : check e2262374231926 [[],[.under]] .smaller = true := by decide
def e2262374231930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2262374231930 : Closed e2262374231930 ∧ code e2262374231930 = 11058467254138 := by decide
theorem cert_e2262374231930 : check e2262374231930 [[],[.under]] .smaller = true := by decide
def e2262374231982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2262374231982 : Closed e2262374231982 ∧ code e2262374231982 = 11058467254190 := by decide
theorem cert_e2262374231982 : check e2262374231982 [[],[.under]] .smaller = true := by decide
def e2262374231990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2262374231990 : Closed e2262374231990 ∧ code e2262374231990 = 11058467254198 := by decide
theorem cert_e2262374231990 : check e2262374231990 [[],[.under]] .smaller = true := by decide
def e2262374231994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2262374231994 : Closed e2262374231994 ∧ code e2262374231994 = 11058467254202 := by decide
theorem cert_e2262374231994 : check e2262374231994 [[],[.under]] .smaller = true := by decide
def e2262374232022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2262374232022 : Closed e2262374232022 ∧ code e2262374232022 = 11058467254230 := by decide
theorem cert_e2262374232022 : check e2262374232022 [[],[.under]] .three = true := by decide
def e2262374232026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2262374232026 : Closed e2262374232026 ∧ code e2262374232026 = 11058467254234 := by decide
theorem cert_e2262374232026 : check e2262374232026 [[],[.under]] .three = true := by decide
def e2262374233022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2262374233022 : Closed e2262374233022 ∧ code e2262374233022 = 11058467255230 := by decide
theorem cert_e2262374233022 : check e2262374233022 [[],[.under]] .three = true := by decide
def e2262374233054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2262374233054 : Closed e2262374233054 ∧ code e2262374233054 = 11058467255262 := by decide
theorem cert_e2262374233054 : check e2262374233054 [[],[.under]] .smaller = true := by decide
def e2262374233070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2262374233070 : Closed e2262374233070 ∧ code e2262374233070 = 11058467255278 := by decide
theorem cert_e2262374233070 : check e2262374233070 [[],[.under]] .smaller = true := by decide
def e2262374233078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2262374233078 : Closed e2262374233078 ∧ code e2262374233078 = 11058467255286 := by decide
theorem cert_e2262374233078 : check e2262374233078 [[],[.under]] .three = true := by decide
def e2262374234558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2262374234558 : Closed e2262374234558 ∧ code e2262374234558 = 11058467256766 := by decide
theorem cert_e2262374234558 : check e2262374234558 [[],[.under]] .three = true := by decide
def e2262374234590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2262374234590 : Closed e2262374234590 ∧ code e2262374234590 = 11058467256798 := by decide
theorem cert_e2262374234590 : check e2262374234590 [[],[.under]] .smaller = true := by decide
def e2262374234606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e2262374234606 : Closed e2262374234606 ∧ code e2262374234606 = 11058467256814 := by decide
theorem cert_e2262374234606 : check e2262374234606 [[],[.under]] .smaller = true := by decide
def e2262374234614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2262374234614 : Closed e2262374234614 ∧ code e2262374234614 = 11058467256822 := by decide
theorem cert_e2262374234614 : check e2262374234614 [[],[.under]] .smaller = true := by decide
def e2262374234618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2262374234618 : Closed e2262374234618 ∧ code e2262374234618 = 11058467256826 := by decide
theorem cert_e2262374234618 : check e2262374234618 [[],[.under]] .three = true := by decide
def e2262374235358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2262374235358 : Closed e2262374235358 ∧ code e2262374235358 = 11058467257566 := by decide
theorem cert_e2262374235358 : check e2262374235358 [[],[.under]] .smaller = true := by decide
def e2262374235374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262374235374 : Closed e2262374235374 ∧ code e2262374235374 = 11058467257582 := by decide
theorem cert_e2262374235374 : check e2262374235374 [[],[.under]] .smaller = true := by decide
def e2262374235382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262374235382 : Closed e2262374235382 ∧ code e2262374235382 = 11058467257590 := by decide
theorem cert_e2262374235382 : check e2262374235382 [[],[.under]] .smaller = true := by decide
def e2262374235386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2262374235386 : Closed e2262374235386 ∧ code e2262374235386 = 11058467257594 := by decide
theorem cert_e2262374235386 : check e2262374235386 [[],[.under]] .smaller = true := by decide
def e2262374235758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374235758 : Closed e2262374235758 ∧ code e2262374235758 = 11058467257966 := by decide
theorem cert_e2262374235758 : check e2262374235758 [[],[.under]] .smaller = true := by decide
def e2262374235766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2262374235766 : Closed e2262374235766 ∧ code e2262374235766 = 11058467257974 := by decide
theorem cert_e2262374235766 : check e2262374235766 [[],[.under]] .smaller = true := by decide
def e2262374235770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374235770 : Closed e2262374235770 ∧ code e2262374235770 = 11058467257978 := by decide
theorem cert_e2262374235770 : check e2262374235770 [[],[.under]] .smaller = true := by decide
def e2262374235958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374235958 : Closed e2262374235958 ∧ code e2262374235958 = 11058467258166 := by decide
theorem cert_e2262374235958 : check e2262374235958 [[],[.under]] .three = true := by decide
def e2262374235962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374235962 : Closed e2262374235962 ∧ code e2262374235962 = 11058467258170 := by decide
theorem cert_e2262374235962 : check e2262374235962 [[],[.under]] .three = true := by decide
def e2262374258366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2262374258366 : Closed e2262374258366 ∧ code e2262374258366 = 11058467280574 := by decide
theorem cert_e2262374258366 : check e2262374258366 [[],[.under]] .three = true := by decide
def e2262374258398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2262374258398 : Closed e2262374258398 ∧ code e2262374258398 = 11058467280606 := by decide
theorem cert_e2262374258398 : check e2262374258398 [[],[.under]] .smaller = true := by decide
def e2262374258414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2262374258414 : Closed e2262374258414 ∧ code e2262374258414 = 11058467280622 := by decide
theorem cert_e2262374258414 : check e2262374258414 [[],[.under]] .smaller = true := by decide
def e2262374258422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2262374258422 : Closed e2262374258422 ∧ code e2262374258422 = 11058467280630 := by decide
theorem cert_e2262374258422 : check e2262374258422 [[],[.under]] .smaller = true := by decide
def e2262374258426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2262374258426 : Closed e2262374258426 ∧ code e2262374258426 = 11058467280634 := by decide
theorem cert_e2262374258426 : check e2262374258426 [[],[.under]] .three = true := by decide
def e2262374258526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2262374258526 : Closed e2262374258526 ∧ code e2262374258526 = 11058467280734 := by decide
theorem cert_e2262374258526 : check e2262374258526 [[],[.under]] .smaller = true := by decide
def e2262374258554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2262374258554 : Closed e2262374258554 ∧ code e2262374258554 = 11058467280762 := by decide
theorem cert_e2262374258554 : check e2262374258554 [[],[.under]] .smaller = true := by decide
def e2262374258606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2262374258606 : Closed e2262374258606 ∧ code e2262374258606 = 11058467280814 := by decide
theorem cert_e2262374258606 : check e2262374258606 [[],[.under]] .smaller = true := by decide
def e2262374258618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2262374258618 : Closed e2262374258618 ∧ code e2262374258618 = 11058467280826 := by decide
theorem cert_e2262374258618 : check e2262374258618 [[],[.under]] .smaller = true := by decide
def e2262374258646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2262374258646 : Closed e2262374258646 ∧ code e2262374258646 = 11058467280854 := by decide
theorem cert_e2262374258646 : check e2262374258646 [[],[.under]] .smaller = true := by decide
def e2262374258650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2262374258650 : Closed e2262374258650 ∧ code e2262374258650 = 11058467280858 := by decide
theorem cert_e2262374258650 : check e2262374258650 [[],[.under]] .smaller = true := by decide
def e2262374258666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2262374258666 : Closed e2262374258666 ∧ code e2262374258666 = 11058467280874 := by decide
theorem cert_e2262374258666 : check e2262374258666 [[],[.under]] .three = true := by decide
def e2262374259134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2262374259134 : Closed e2262374259134 ∧ code e2262374259134 = 11058467281342 := by decide
theorem cert_e2262374259134 : check e2262374259134 [[],[.under]] .three = true := by decide
def e2262374259166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2262374259166 : Closed e2262374259166 ∧ code e2262374259166 = 11058467281374 := by decide
theorem cert_e2262374259166 : check e2262374259166 [[],[.under]] .smaller = true := by decide
def e2262374259182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2262374259182 : Closed e2262374259182 ∧ code e2262374259182 = 11058467281390 := by decide
theorem cert_e2262374259182 : check e2262374259182 [[],[.under]] .smaller = true := by decide
def e2262374259190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2262374259190 : Closed e2262374259190 ∧ code e2262374259190 = 11058467281398 := by decide
theorem cert_e2262374259190 : check e2262374259190 [[],[.under]] .smaller = true := by decide
def e2262374259194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2262374259194 : Closed e2262374259194 ∧ code e2262374259194 = 11058467281402 := by decide
theorem cert_e2262374259194 : check e2262374259194 [[],[.under]] .three = true := by decide
def e2262374259934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2262374259934 : Closed e2262374259934 ∧ code e2262374259934 = 11058467282142 := by decide
theorem cert_e2262374259934 : check e2262374259934 [[],[.under]] .smaller = true := by decide
def e2262374259962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2262374259962 : Closed e2262374259962 ∧ code e2262374259962 = 11058467282170 := by decide
theorem cert_e2262374259962 : check e2262374259962 [[],[.under]] .smaller = true := by decide
def e2262374260334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374260334 : Closed e2262374260334 ∧ code e2262374260334 = 11058467282542 := by decide
theorem cert_e2262374260334 : check e2262374260334 [[],[.under]] .smaller = true := by decide
def e2262374260346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374260346 : Closed e2262374260346 ∧ code e2262374260346 = 11058467282554 := by decide
theorem cert_e2262374260346 : check e2262374260346 [[],[.under]] .smaller = true := by decide
def e2262374260534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374260534 : Closed e2262374260534 ∧ code e2262374260534 = 11058467282742 := by decide
theorem cert_e2262374260534 : check e2262374260534 [[],[.under]] .smaller = true := by decide
def e2262374260538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374260538 : Closed e2262374260538 ∧ code e2262374260538 = 11058467282746 := by decide
theorem cert_e2262374260538 : check e2262374260538 [[],[.under]] .smaller = true := by decide
def e2262374260634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374260634 : Closed e2262374260634 ∧ code e2262374260634 = 11058467282842 := by decide
theorem cert_e2262374260634 : check e2262374260634 [[],[.under]] .three = true := by decide
def e2262374271838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2262374271838 : Closed e2262374271838 ∧ code e2262374271838 = 11058467294046 := by decide
theorem cert_e2262374271838 : check e2262374271838 [[],[.under]] .smaller = true := by decide
def e2262374271854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262374271854 : Closed e2262374271854 ∧ code e2262374271854 = 11058467294062 := by decide
theorem cert_e2262374271854 : check e2262374271854 [[],[.under]] .smaller = true := by decide
def e2262374271862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262374271862 : Closed e2262374271862 ∧ code e2262374271862 = 11058467294070 := by decide
theorem cert_e2262374271862 : check e2262374271862 [[],[.under]] .smaller = true := by decide
def e2262374271866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2262374271866 : Closed e2262374271866 ∧ code e2262374271866 = 11058467294074 := by decide
theorem cert_e2262374271866 : check e2262374271866 [[],[.under]] .smaller = true := by decide
def e2262374271918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262374271918 : Closed e2262374271918 ∧ code e2262374271918 = 11058467294126 := by decide
theorem cert_e2262374271918 : check e2262374271918 [[],[.under]] .smaller = true := by decide
def e2262374271930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262374271930 : Closed e2262374271930 ∧ code e2262374271930 = 11058467294138 := by decide
theorem cert_e2262374271930 : check e2262374271930 [[],[.under]] .smaller = true := by decide
def e2262374271958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262374271958 : Closed e2262374271958 ∧ code e2262374271958 = 11058467294166 := by decide
theorem cert_e2262374271958 : check e2262374271958 [[],[.under]] .smaller = true := by decide
def e2262374271962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262374271962 : Closed e2262374271962 ∧ code e2262374271962 = 11058467294170 := by decide
theorem cert_e2262374271962 : check e2262374271962 [[],[.under]] .smaller = true := by decide
def e2262374271978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2262374271978 : Closed e2262374271978 ∧ code e2262374271978 = 11058467294186 := by decide
theorem cert_e2262374271978 : check e2262374271978 [[],[.under]] .smaller = true := by decide
def e2262374272222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2262374272222 : Closed e2262374272222 ∧ code e2262374272222 = 11058467294430 := by decide
theorem cert_e2262374272222 : check e2262374272222 [[],[.under]] .smaller = true := by decide
def e2262374272238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262374272238 : Closed e2262374272238 ∧ code e2262374272238 = 11058467294446 := by decide
theorem cert_e2262374272238 : check e2262374272238 [[],[.under]] .smaller = true := by decide
def e2262374272246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262374272246 : Closed e2262374272246 ∧ code e2262374272246 = 11058467294454 := by decide
theorem cert_e2262374272246 : check e2262374272246 [[],[.under]] .smaller = true := by decide
def e2262374272250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2262374272250 : Closed e2262374272250 ∧ code e2262374272250 = 11058467294458 := by decide
theorem cert_e2262374272250 : check e2262374272250 [[],[.under]] .smaller = true := by decide
def e2262374272622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374272622 : Closed e2262374272622 ∧ code e2262374272622 = 11058467294830 := by decide
theorem cert_e2262374272622 : check e2262374272622 [[],[.under]] .smaller = true := by decide
def e2262374272634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374272634 : Closed e2262374272634 ∧ code e2262374272634 = 11058467294842 := by decide
theorem cert_e2262374272634 : check e2262374272634 [[],[.under]] .smaller = true := by decide
def e2262374272822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374272822 : Closed e2262374272822 ∧ code e2262374272822 = 11058467295030 := by decide
theorem cert_e2262374272822 : check e2262374272822 [[],[.under]] .smaller = true := by decide
def e2262374272826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374272826 : Closed e2262374272826 ∧ code e2262374272826 = 11058467295034 := by decide
theorem cert_e2262374272826 : check e2262374272826 [[],[.under]] .smaller = true := by decide
def e2262374272922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374272922 : Closed e2262374272922 ∧ code e2262374272922 = 11058467295130 := by decide
theorem cert_e2262374272922 : check e2262374272922 [[],[.under]] .smaller = true := by decide
def e2262374278574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2262374278574 : Closed e2262374278574 ∧ code e2262374278574 = 11058467300782 := by decide
theorem cert_e2262374278574 : check e2262374278574 [[],[.under]] .smaller = true := by decide
def e2262374278582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2262374278582 : Closed e2262374278582 ∧ code e2262374278582 = 11058467300790 := by decide
theorem cert_e2262374278582 : check e2262374278582 [[],[.under]] .smaller = true := by decide
def e2262374278586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2262374278586 : Closed e2262374278586 ∧ code e2262374278586 = 11058467300794 := by decide
theorem cert_e2262374278586 : check e2262374278586 [[],[.under]] .smaller = true := by decide
def e2262374278614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2262374278614 : Closed e2262374278614 ∧ code e2262374278614 = 11058467300822 := by decide
theorem cert_e2262374278614 : check e2262374278614 [[],[.under]] .smaller = true := by decide
def e2262374278618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2262374278618 : Closed e2262374278618 ∧ code e2262374278618 = 11058467300826 := by decide
theorem cert_e2262374278618 : check e2262374278618 [[],[.under]] .smaller = true := by decide
def e2262374278634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2262374278634 : Closed e2262374278634 ∧ code e2262374278634 = 11058467300842 := by decide
theorem cert_e2262374278634 : check e2262374278634 [[],[.under]] .smaller = true := by decide
def e2262374278766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374278766 : Closed e2262374278766 ∧ code e2262374278766 = 11058467300974 := by decide
theorem cert_e2262374278766 : check e2262374278766 [[],[.under]] .smaller = true := by decide
def e2262374278774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2262374278774 : Closed e2262374278774 ∧ code e2262374278774 = 11058467300982 := by decide
theorem cert_e2262374278774 : check e2262374278774 [[],[.under]] .smaller = true := by decide
def e2262374278778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374278778 : Closed e2262374278778 ∧ code e2262374278778 = 11058467300986 := by decide
theorem cert_e2262374278778 : check e2262374278778 [[],[.under]] .smaller = true := by decide
def e2262374278966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374278966 : Closed e2262374278966 ∧ code e2262374278966 = 11058467301174 := by decide
theorem cert_e2262374278966 : check e2262374278966 [[],[.under]] .smaller = true := by decide
def e2262374278970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374278970 : Closed e2262374278970 ∧ code e2262374278970 = 11058467301178 := by decide
theorem cert_e2262374278970 : check e2262374278970 [[],[.under]] .smaller = true := by decide
def e2262374279066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374279066 : Closed e2262374279066 ∧ code e2262374279066 = 11058467301274 := by decide
theorem cert_e2262374279066 : check e2262374279066 [[],[.under]] .smaller = true := by decide
def e2262374281942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2262374281942 : Closed e2262374281942 ∧ code e2262374281942 = 11058467304150 := by decide
theorem cert_e2262374281942 : check e2262374281942 [[],[.under]] .three = true := by decide
def e2262374281946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2262374281946 : Closed e2262374281946 ∧ code e2262374281946 = 11058467304154 := by decide
theorem cert_e2262374281946 : check e2262374281946 [[],[.under]] .three = true := by decide
def e2262374281962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2262374281962 : Closed e2262374281962 ∧ code e2262374281962 = 11058467304170 := by decide
theorem cert_e2262374281962 : check e2262374281962 [[],[.under]] .three = true := by decide
def e2262374282038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374282038 : Closed e2262374282038 ∧ code e2262374282038 = 11058467304246 := by decide
theorem cert_e2262374282038 : check e2262374282038 [[],[.under]] .three = true := by decide
def e2262374282042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374282042 : Closed e2262374282042 ∧ code e2262374282042 = 11058467304250 := by decide
theorem cert_e2262374282042 : check e2262374282042 [[],[.under]] .three = true := by decide
def e2262374282138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374282138 : Closed e2262374282138 ∧ code e2262374282138 = 11058467304346 := by decide
theorem cert_e2262374282138 : check e2262374282138 [[],[.under]] .three = true := by decide
def e2262374724974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2262374724974 : Closed e2262374724974 ∧ code e2262374724974 = 11058467747182 := by decide
theorem cert_e2262374724974 : check e2262374724974 [[],[.under]] .smaller = true := by decide
def e2262374724982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2262374724982 : Closed e2262374724982 ∧ code e2262374724982 = 11058467747190 := by decide
theorem cert_e2262374724982 : check e2262374724982 [[],[.under]] .smaller = true := by decide
def e2262374725038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2262374725038 : Closed e2262374725038 ∧ code e2262374725038 = 11058467747246 := by decide
theorem cert_e2262374725038 : check e2262374725038 [[],[.under]] .smaller = true := by decide
def e2262374725050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2262374725050 : Closed e2262374725050 ∧ code e2262374725050 = 11058467747258 := by decide
theorem cert_e2262374725050 : check e2262374725050 [[],[.under]] .smaller = true := by decide
def e2262374725078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2262374725078 : Closed e2262374725078 ∧ code e2262374725078 = 11058467747286 := by decide
theorem cert_e2262374725078 : check e2262374725078 [[],[.under]] .smaller = true := by decide
def e2262374725082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2262374725082 : Closed e2262374725082 ∧ code e2262374725082 = 11058467747290 := by decide
theorem cert_e2262374725082 : check e2262374725082 [[],[.under]] .smaller = true := by decide
def e2262374725294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2262374725294 : Closed e2262374725294 ∧ code e2262374725294 = 11058467747502 := by decide
theorem cert_e2262374725294 : check e2262374725294 [[],[.under]] .smaller = true := by decide
def e2262374725306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2262374725306 : Closed e2262374725306 ∧ code e2262374725306 = 11058467747514 := by decide
theorem cert_e2262374725306 : check e2262374725306 [[],[.under]] .smaller = true := by decide
def e2262374725354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2262374725354 : Closed e2262374725354 ∧ code e2262374725354 = 11058467747562 := by decide
theorem cert_e2262374725354 : check e2262374725354 [[],[.under]] .smaller = true := by decide
def e2262374725462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2262374725462 : Closed e2262374725462 ∧ code e2262374725462 = 11058467747670 := by decide
theorem cert_e2262374725462 : check e2262374725462 [[],[.under]] .smaller = true := by decide
def e2262374725466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2262374725466 : Closed e2262374725466 ∧ code e2262374725466 = 11058467747674 := by decide
theorem cert_e2262374725466 : check e2262374725466 [[],[.under]] .smaller = true := by decide
def e2262374725482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2262374725482 : Closed e2262374725482 ∧ code e2262374725482 = 11058467747690 := by decide
theorem cert_e2262374725482 : check e2262374725482 [[],[.under]] .smaller = true := by decide
def e2262374726318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2262374726318 : Closed e2262374726318 ∧ code e2262374726318 = 11058467748526 := by decide
theorem cert_e2262374726318 : check e2262374726318 [[],[.under]] .smaller = true := by decide
def e2262374726330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2262374726330 : Closed e2262374726330 ∧ code e2262374726330 = 11058467748538 := by decide
theorem cert_e2262374726330 : check e2262374726330 [[],[.under]] .smaller = true := by decide
def e2262374726378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2262374726378 : Closed e2262374726378 ∧ code e2262374726378 = 11058467748586 := by decide
theorem cert_e2262374726378 : check e2262374726378 [[],[.under]] .smaller = true := by decide
def e2262374726570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2262374726570 : Closed e2262374726570 ∧ code e2262374726570 = 11058467748778 := by decide
theorem cert_e2262374726570 : check e2262374726570 [[],[.under]] .smaller = true := by decide
def e2262374726998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2262374726998 : Closed e2262374726998 ∧ code e2262374726998 = 11058467749206 := by decide
theorem cert_e2262374726998 : check e2262374726998 [[],[.under]] .smaller = true := by decide
def e2262374727002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2262374727002 : Closed e2262374727002 ∧ code e2262374727002 = 11058467749210 := by decide
theorem cert_e2262374727002 : check e2262374727002 [[],[.under]] .smaller = true := by decide
def e2262374727018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2262374727018 : Closed e2262374727018 ∧ code e2262374727018 = 11058467749226 := by decide
theorem cert_e2262374727018 : check e2262374727018 [[],[.under]] .smaller = true := by decide
def e2262374727082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2262374727082 : Closed e2262374727082 ∧ code e2262374727082 = 11058467749290 := by decide
theorem cert_e2262374727082 : check e2262374727082 [[],[.under]] .smaller = true := by decide
def e2262374729438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e2262374729438 : Closed e2262374729438 ∧ code e2262374729438 = 11058467751646 := by decide
theorem cert_e2262374729438 : check e2262374729438 [[],[.under]] .three = true := by decide
def e2262374729462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e2262374729462 : Closed e2262374729462 ∧ code e2262374729462 = 11058467751670 := by decide
theorem cert_e2262374729462 : check e2262374729462 [[],[.under]] .three = true := by decide
end Blc.Floor43
