import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2214566173034 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2214566173034 : Closed e2214566173034 ∧ code e2214566173034 = 11010659195242 := by decide
theorem cert_e2214566173034 : check e2214566173034 [[]] .width = true := by decide
def e2214566173058 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2214566173058 : Closed e2214566173058 ∧ code e2214566173058 = 11010659195266 := by decide
theorem cert_e2214566173058 : check e2214566173058 [[]] .width = true := by decide
def e2214566173082 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2214566173082 : Closed e2214566173082 ∧ code e2214566173082 = 11010659195290 := by decide
theorem cert_e2214566173082 : check e2214566173082 [[]] .width = true := by decide
def e2214566871238 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2214566871238 : Closed e2214566871238 ∧ code e2214566871238 = 11010659893446 := by decide
theorem cert_e2214566871238 : check e2214566871238 [[]] .width = true := by decide
def e2214566928410 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214566928410 : Closed e2214566928410 ∧ code e2214566928410 = 11010659950618 := by decide
theorem cert_e2214566928410 : check e2214566928410 [[]] .width = true := by decide
def e2214566928502 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214566928502 : Closed e2214566928502 ∧ code e2214566928502 = 11010659950710 := by decide
theorem cert_e2214566928502 : check e2214566928502 [[]] .width = true := by decide
def e2214566928746 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214566928746 : Closed e2214566928746 ∧ code e2214566928746 = 11010659950954 := by decide
theorem cert_e2214566928746 : check e2214566928746 [[]] .width = true := by decide
def e2214566928794 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214566928794 : Closed e2214566928794 ∧ code e2214566928794 = 11010659951002 := by decide
theorem cert_e2214566928794 : check e2214566928794 [[]] .width = true := by decide
def e2214566934554 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214566934554 : Closed e2214566934554 ∧ code e2214566934554 = 11010659956762 := by decide
theorem cert_e2214566934554 : check e2214566934554 [[]] .width = true := by decide
def e2214566946842 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214566946842 : Closed e2214566946842 ∧ code e2214566946842 = 11010659969050 := by decide
theorem cert_e2214566946842 : check e2214566946842 [[]] .width = true := by decide
def e2214566952986 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2214566952986 : Closed e2214566952986 ∧ code e2214566952986 = 11010659975194 := by decide
theorem cert_e2214566952986 : check e2214566952986 [[]] .width = true := by decide
def e2214566953078 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2214566953078 : Closed e2214566953078 ∧ code e2214566953078 = 11010659975286 := by decide
theorem cert_e2214566953078 : check e2214566953078 [[]] .width = true := by decide
def e2214566953322 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2214566953322 : Closed e2214566953322 ∧ code e2214566953322 = 11010659975530 := by decide
theorem cert_e2214566953322 : check e2214566953322 [[]] .width = true := by decide
def e2214566953370 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2214566953370 : Closed e2214566953370 ∧ code e2214566953370 = 11010659975578 := by decide
theorem cert_e2214566953370 : check e2214566953370 [[]] .width = true := by decide
def e2214566953454 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2214566953454 : Closed e2214566953454 ∧ code e2214566953454 = 11010659975662 := by decide
theorem cert_e2214566953454 : check e2214566953454 [[]] .width = true := by decide
def e2214566954378 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2214566954378 : Closed e2214566954378 ∧ code e2214566954378 = 11010659976586 := by decide
theorem cert_e2214566954378 : check e2214566954378 [[]] .width = true := by decide
def e2214566954402 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2214566954402 : Closed e2214566954402 ∧ code e2214566954402 = 11010659976610 := by decide
theorem cert_e2214566954402 : check e2214566954402 [[]] .width = true := by decide
def e2214566954422 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2214566954422 : Closed e2214566954422 ∧ code e2214566954422 = 11010659976630 := by decide
theorem cert_e2214566954422 : check e2214566954422 [[]] .width = true := by decide
def e2214566954454 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2214566954454 : Closed e2214566954454 ∧ code e2214566954454 = 11010659976662 := by decide
theorem cert_e2214566954454 : check e2214566954454 [[]] .width = true := by decide
def e2214566954458 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2214566954458 : Closed e2214566954458 ∧ code e2214566954458 = 11010659976666 := by decide
theorem cert_e2214566954458 : check e2214566954458 [[]] .width = true := by decide
def e2214566954510 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2214566954510 : Closed e2214566954510 ∧ code e2214566954510 = 11010659976718 := by decide
theorem cert_e2214566954510 : check e2214566954510 [[]] .width = true := by decide
def e2214566954522 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2214566954522 : Closed e2214566954522 ∧ code e2214566954522 = 11010659976730 := by decide
theorem cert_e2214566954522 : check e2214566954522 [[]] .width = true := by decide
def e2214566954594 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2214566954594 : Closed e2214566954594 ∧ code e2214566954594 = 11010659976802 := by decide
theorem cert_e2214566954594 : check e2214566954594 [[]] .width = true := by decide
def e2214566954614 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2214566954614 : Closed e2214566954614 ∧ code e2214566954614 = 11010659976822 := by decide
theorem cert_e2214566954614 : check e2214566954614 [[]] .width = true := by decide
def e2214566954806 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2214566954806 : Closed e2214566954806 ∧ code e2214566954806 = 11010659977014 := by decide
theorem cert_e2214566954806 : check e2214566954806 [[]] .width = true := by decide
def e2214566954810 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2214566954810 : Closed e2214566954810 ∧ code e2214566954810 = 11010659977018 := by decide
theorem cert_e2214566954810 : check e2214566954810 [[]] .width = true := by decide
def e2214566958506 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2214566958506 : Closed e2214566958506 ∧ code e2214566958506 = 11010659980714 := by decide
theorem cert_e2214566958506 : check e2214566958506 [[]] .width = true := by decide
def e2214566958602 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2214566958602 : Closed e2214566958602 ∧ code e2214566958602 = 11010659980810 := by decide
theorem cert_e2214566958602 : check e2214566958602 [[]] .width = true := by decide
def e2214566958698 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2214566958698 : Closed e2214566958698 ∧ code e2214566958698 = 11010659980906 := by decide
theorem cert_e2214566958698 : check e2214566958698 [[]] .width = true := by decide
def e2214566958722 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2214566958722 : Closed e2214566958722 ∧ code e2214566958722 = 11010659980930 := by decide
theorem cert_e2214566958722 : check e2214566958722 [[]] .width = true := by decide
def e2214566958746 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2214566958746 : Closed e2214566958746 ∧ code e2214566958746 = 11010659980954 := by decide
theorem cert_e2214566958746 : check e2214566958746 [[]] .width = true := by decide
def e2214566959130 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2214566959130 : Closed e2214566959130 ∧ code e2214566959130 = 11010659981338 := by decide
theorem cert_e2214566959130 : check e2214566959130 [[]] .width = true := by decide
def e2214566959222 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2214566959222 : Closed e2214566959222 ∧ code e2214566959222 = 11010659981430 := by decide
theorem cert_e2214566959222 : check e2214566959222 [[]] .width = true := by decide
def e2214566959466 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2214566959466 : Closed e2214566959466 ∧ code e2214566959466 = 11010659981674 := by decide
theorem cert_e2214566959466 : check e2214566959466 [[]] .width = true := by decide
def e2214566959490 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2214566959490 : Closed e2214566959490 ∧ code e2214566959490 = 11010659981698 := by decide
theorem cert_e2214566959490 : check e2214566959490 [[]] .width = true := by decide
def e2214566959514 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2214566959514 : Closed e2214566959514 ∧ code e2214566959514 = 11010659981722 := by decide
theorem cert_e2214566959514 : check e2214566959514 [[]] .width = true := by decide
def e2215177339078 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215177339078 : Closed e2215177339078 ∧ code e2215177339078 = 11011270361286 := by decide
theorem cert_e2215177339078 : check e2215177339078 [[]] .width = true := by decide
def e2215177535686 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215177535686 : Closed e2215177535686 ∧ code e2215177535686 = 11011270557894 := by decide
theorem cert_e2215177535686 : check e2215177535686 [[]] .width = true := by decide
def e2215178387654 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215178387654 : Closed e2215178387654 ∧ code e2215178387654 = 11011271409862 := by decide
theorem cert_e2215178387654 : check e2215178387654 [[]] .width = true := by decide
def e2215178617030 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215178617030 : Closed e2215178617030 ∧ code e2215178617030 = 11011271639238 := by decide
theorem cert_e2215178617030 : check e2215178617030 [[]] .width = true := by decide
def e2215179370694 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215179370694 : Closed e2215179370694 ∧ code e2215179370694 = 11011272392902 := by decide
theorem cert_e2215179370694 : check e2215179370694 [[]] .width = true := by decide
def e2215179403462 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215179403462 : Closed e2215179403462 ∧ code e2215179403462 = 11011272425670 := by decide
theorem cert_e2215179403462 : check e2215179403462 [[]] .width = true := by decide
def e2215183630534 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215183630534 : Closed e2215183630534 ∧ code e2215183630534 = 11011276652742 := by decide
theorem cert_e2215183630534 : check e2215183630534 [[]] .width = true := by decide
def e2215183827142 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215183827142 : Closed e2215183827142 ∧ code e2215183827142 = 11011276849350 := by decide
theorem cert_e2215183827142 : check e2215183827142 [[]] .width = true := by decide
def e2215189921990 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215189921990 : Closed e2215189921990 ∧ code e2215189921990 = 11011282944198 := by decide
theorem cert_e2215189921990 : check e2215189921990 [[]] .width = true := by decide
def e2215190151366 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215190151366 : Closed e2215190151366 ∧ code e2215190151366 = 11011283173574 := by decide
theorem cert_e2215190151366 : check e2215190151366 [[]] .width = true := by decide
def e2215194837190 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215194837190 : Closed e2215194837190 ∧ code e2215194837190 = 11011287859398 := by decide
theorem cert_e2215194837190 : check e2215194837190 [[]] .width = true := by decide
def e2215194869958 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215194869958 : Closed e2215194869958 ∧ code e2215194869958 = 11011287892166 := by decide
theorem cert_e2215194869958 : check e2215194869958 [[]] .width = true := by decide
def e2215311237146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215311237146 : Closed e2215311237146 ∧ code e2215311237146 = 11011404259354 := by decide
theorem cert_e2215311237146 : check e2215311237146 [[]] .width = true := by decide
def e2215311237238 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215311237238 : Closed e2215311237238 ∧ code e2215311237238 = 11011404259446 := by decide
theorem cert_e2215311237238 : check e2215311237238 [[]] .width = true := by decide
def e2215311237482 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215311237482 : Closed e2215311237482 ∧ code e2215311237482 = 11011404259690 := by decide
theorem cert_e2215311237482 : check e2215311237482 [[]] .width = true := by decide
def e2215311237530 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215311237530 : Closed e2215311237530 ∧ code e2215311237530 = 11011404259738 := by decide
theorem cert_e2215311237530 : check e2215311237530 [[]] .width = true := by decide
def e2215311269914 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215311269914 : Closed e2215311269914 ∧ code e2215311269914 = 11011404292122 := by decide
theorem cert_e2215311269914 : check e2215311269914 [[]] .width = true := by decide
def e2215311270006 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215311270006 : Closed e2215311270006 ∧ code e2215311270006 = 11011404292214 := by decide
theorem cert_e2215311270006 : check e2215311270006 [[]] .width = true := by decide
def e2215311270250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215311270250 : Closed e2215311270250 ∧ code e2215311270250 = 11011404292458 := by decide
theorem cert_e2215311270250 : check e2215311270250 [[]] .width = true := by decide
def e2215311270298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215311270298 : Closed e2215311270298 ∧ code e2215311270298 = 11011404292506 := by decide
theorem cert_e2215311270298 : check e2215311270298 [[]] .width = true := by decide
def e2215311499290 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215311499290 : Closed e2215311499290 ∧ code e2215311499290 = 11011404521498 := by decide
theorem cert_e2215311499290 : check e2215311499290 [[]] .width = true := by decide
def e2215311499382 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215311499382 : Closed e2215311499382 ∧ code e2215311499382 = 11011404521590 := by decide
theorem cert_e2215311499382 : check e2215311499382 [[]] .width = true := by decide
def e2215311499626 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215311499626 : Closed e2215311499626 ∧ code e2215311499626 = 11011404521834 := by decide
theorem cert_e2215311499626 : check e2215311499626 [[]] .width = true := by decide
def e2215311499674 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215311499674 : Closed e2215311499674 ∧ code e2215311499674 = 11011404521882 := by decide
theorem cert_e2215311499674 : check e2215311499674 [[]] .width = true := by decide
def e2215311548442 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215311548442 : Closed e2215311548442 ∧ code e2215311548442 = 11011404570650 := by decide
theorem cert_e2215311548442 : check e2215311548442 [[]] .width = true := by decide
def e2215311548534 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215311548534 : Closed e2215311548534 ∧ code e2215311548534 = 11011404570742 := by decide
theorem cert_e2215311548534 : check e2215311548534 [[]] .width = true := by decide
def e2215311548778 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215311548778 : Closed e2215311548778 ∧ code e2215311548778 = 11011404570986 := by decide
theorem cert_e2215311548778 : check e2215311548778 [[]] .width = true := by decide
def e2215311548826 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215311548826 : Closed e2215311548826 ∧ code e2215311548826 = 11011404571034 := by decide
theorem cert_e2215311548826 : check e2215311548826 [[]] .width = true := by decide
def e2215311554586 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215311554586 : Closed e2215311554586 ∧ code e2215311554586 = 11011404576794 := by decide
theorem cert_e2215311554586 : check e2215311554586 [[]] .width = true := by decide
def e2215311663130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215311663130 : Closed e2215311663130 ∧ code e2215311663130 = 11011404685338 := by decide
theorem cert_e2215311663130 : check e2215311663130 [[]] .width = true := by decide
def e2215311663222 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215311663222 : Closed e2215311663222 ∧ code e2215311663222 = 11011404685430 := by decide
theorem cert_e2215311663222 : check e2215311663222 [[]] .width = true := by decide
def e2215311663466 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215311663466 : Closed e2215311663466 ∧ code e2215311663466 = 11011404685674 := by decide
theorem cert_e2215311663466 : check e2215311663466 [[]] .width = true := by decide
def e2215311663514 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215311663514 : Closed e2215311663514 ∧ code e2215311663514 = 11011404685722 := by decide
theorem cert_e2215311663514 : check e2215311663514 [[]] .width = true := by decide
def e2215311679514 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215311679514 : Closed e2215311679514 ∧ code e2215311679514 = 11011404701722 := by decide
theorem cert_e2215311679514 : check e2215311679514 [[]] .width = true := by decide
def e2215311679606 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215311679606 : Closed e2215311679606 ∧ code e2215311679606 = 11011404701814 := by decide
theorem cert_e2215311679606 : check e2215311679606 [[]] .width = true := by decide
def e2215311679850 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215311679850 : Closed e2215311679850 ∧ code e2215311679850 = 11011404702058 := by decide
theorem cert_e2215311679850 : check e2215311679850 [[]] .width = true := by decide
def e2215311679898 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215311679898 : Closed e2215311679898 ∧ code e2215311679898 = 11011404702106 := by decide
theorem cert_e2215311679898 : check e2215311679898 [[]] .width = true := by decide
def e2215311685658 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215311685658 : Closed e2215311685658 ∧ code e2215311685658 = 11011404707866 := by decide
theorem cert_e2215311685658 : check e2215311685658 [[]] .width = true := by decide
def e2215311693850 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215311693850 : Closed e2215311693850 ∧ code e2215311693850 = 11011404716058 := by decide
theorem cert_e2215311693850 : check e2215311693850 [[]] .width = true := by decide
def e2215312547866 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215312547866 : Closed e2215312547866 ∧ code e2215312547866 = 11011405570074 := by decide
theorem cert_e2215312547866 : check e2215312547866 [[]] .width = true := by decide
def e2215312547958 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215312547958 : Closed e2215312547958 ∧ code e2215312547958 = 11011405570166 := by decide
theorem cert_e2215312547958 : check e2215312547958 [[]] .width = true := by decide
def e2215312548202 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215312548202 : Closed e2215312548202 ∧ code e2215312548202 = 11011405570410 := by decide
theorem cert_e2215312548202 : check e2215312548202 [[]] .width = true := by decide
def e2215312548250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215312548250 : Closed e2215312548250 ∧ code e2215312548250 = 11011405570458 := by decide
theorem cert_e2215312548250 : check e2215312548250 [[]] .width = true := by decide
def e2215312597018 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215312597018 : Closed e2215312597018 ∧ code e2215312597018 = 11011405619226 := by decide
theorem cert_e2215312597018 : check e2215312597018 [[]] .width = true := by decide
def e2215312597110 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215312597110 : Closed e2215312597110 ∧ code e2215312597110 = 11011405619318 := by decide
theorem cert_e2215312597110 : check e2215312597110 [[]] .width = true := by decide
def e2215312597354 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215312597354 : Closed e2215312597354 ∧ code e2215312597354 = 11011405619562 := by decide
theorem cert_e2215312597354 : check e2215312597354 [[]] .width = true := by decide
def e2215312597402 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215312597402 : Closed e2215312597402 ∧ code e2215312597402 = 11011405619610 := by decide
theorem cert_e2215312597402 : check e2215312597402 [[]] .width = true := by decide
def e2215312603162 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215312603162 : Closed e2215312603162 ∧ code e2215312603162 = 11011405625370 := by decide
theorem cert_e2215312603162 : check e2215312603162 [[]] .width = true := by decide
def e2215312793626 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215312793626 : Closed e2215312793626 ∧ code e2215312793626 = 11011405815834 := by decide
theorem cert_e2215312793626 : check e2215312793626 [[]] .width = true := by decide
def e2215312793718 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215312793718 : Closed e2215312793718 ∧ code e2215312793718 = 11011405815926 := by decide
theorem cert_e2215312793718 : check e2215312793718 [[]] .width = true := by decide
def e2215312793962 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215312793962 : Closed e2215312793962 ∧ code e2215312793962 = 11011405816170 := by decide
theorem cert_e2215312793962 : check e2215312793962 [[]] .width = true := by decide
def e2215312794010 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215312794010 : Closed e2215312794010 ∧ code e2215312794010 = 11011405816218 := by decide
theorem cert_e2215312794010 : check e2215312794010 [[]] .width = true := by decide
def e2215312799770 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215312799770 : Closed e2215312799770 ∧ code e2215312799770 = 11011405821978 := by decide
theorem cert_e2215312799770 : check e2215312799770 [[]] .width = true := by decide
def e2215312812058 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215312812058 : Closed e2215312812058 ∧ code e2215312812058 = 11011405834266 := by decide
theorem cert_e2215312812058 : check e2215312812058 [[]] .width = true := by decide
def e2215313235994 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215313235994 : Closed e2215313235994 ∧ code e2215313235994 = 11011406258202 := by decide
theorem cert_e2215313235994 : check e2215313235994 [[]] .width = true := by decide
def e2215313236086 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215313236086 : Closed e2215313236086 ∧ code e2215313236086 = 11011406258294 := by decide
theorem cert_e2215313236086 : check e2215313236086 [[]] .width = true := by decide
def e2215313236330 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215313236330 : Closed e2215313236330 ∧ code e2215313236330 = 11011406258538 := by decide
theorem cert_e2215313236330 : check e2215313236330 [[]] .width = true := by decide
def e2215313236378 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215313236378 : Closed e2215313236378 ∧ code e2215313236378 = 11011406258586 := by decide
theorem cert_e2215313236378 : check e2215313236378 [[]] .width = true := by decide
def e2215313252378 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215313252378 : Closed e2215313252378 ∧ code e2215313252378 = 11011406274586 := by decide
theorem cert_e2215313252378 : check e2215313252378 [[]] .width = true := by decide
def e2215313252470 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215313252470 : Closed e2215313252470 ∧ code e2215313252470 = 11011406274678 := by decide
theorem cert_e2215313252470 : check e2215313252470 [[]] .width = true := by decide
def e2215313252714 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215313252714 : Closed e2215313252714 ∧ code e2215313252714 = 11011406274922 := by decide
theorem cert_e2215313252714 : check e2215313252714 [[]] .width = true := by decide
def e2215313252762 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215313252762 : Closed e2215313252762 ∧ code e2215313252762 = 11011406274970 := by decide
theorem cert_e2215313252762 : check e2215313252762 [[]] .width = true := by decide
def e2215313258522 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215313258522 : Closed e2215313258522 ∧ code e2215313258522 = 11011406280730 := by decide
theorem cert_e2215313258522 : check e2215313258522 [[]] .width = true := by decide
def e2215313266714 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215313266714 : Closed e2215313266714 ∧ code e2215313266714 = 11011406288922 := by decide
theorem cert_e2215313266714 : check e2215313266714 [[]] .width = true := by decide
def e2215313317914 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215313317914 : Closed e2215313317914 ∧ code e2215313317914 = 11011406340122 := by decide
theorem cert_e2215313317914 : check e2215313317914 [[]] .width = true := by decide
def e2215313318006 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215313318006 : Closed e2215313318006 ∧ code e2215313318006 = 11011406340214 := by decide
theorem cert_e2215313318006 : check e2215313318006 [[]] .width = true := by decide
def e2215313318250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215313318250 : Closed e2215313318250 ∧ code e2215313318250 = 11011406340458 := by decide
theorem cert_e2215313318250 : check e2215313318250 [[]] .width = true := by decide
def e2215313318298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215313318298 : Closed e2215313318298 ∧ code e2215313318298 = 11011406340506 := by decide
theorem cert_e2215313318298 : check e2215313318298 [[]] .width = true := by decide
def e2215313324058 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215313324058 : Closed e2215313324058 ∧ code e2215313324058 = 11011406346266 := by decide
theorem cert_e2215313324058 : check e2215313324058 [[]] .width = true := by decide
def e2215313336346 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215313336346 : Closed e2215313336346 ∧ code e2215313336346 = 11011406358554 := by decide
theorem cert_e2215313336346 : check e2215313336346 [[]] .width = true := by decide
def e2215313365018 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215313365018 : Closed e2215313365018 ∧ code e2215313365018 = 11011406387226 := by decide
theorem cert_e2215313365018 : check e2215313365018 [[]] .width = true := by decide
def e2215313369114 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215313369114 : Closed e2215313369114 ∧ code e2215313369114 = 11011406391322 := by decide
theorem cert_e2215313369114 : check e2215313369114 [[]] .width = true := by decide
def e2215315882182 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215315882182 : Closed e2215315882182 ∧ code e2215315882182 = 11011408904390 := by decide
theorem cert_e2215315882182 : check e2215315882182 [[]] .width = true := by decide
def e2215315947718 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215315947718 : Closed e2215315947718 ∧ code e2215315947718 = 11011408969926 := by decide
theorem cert_e2215315947718 : check e2215315947718 [[]] .width = true := by decide
def e2215317528602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215317528602 : Closed e2215317528602 ∧ code e2215317528602 = 11011410550810 := by decide
theorem cert_e2215317528602 : check e2215317528602 [[]] .width = true := by decide
def e2215317528694 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215317528694 : Closed e2215317528694 ∧ code e2215317528694 = 11011410550902 := by decide
theorem cert_e2215317528694 : check e2215317528694 [[]] .width = true := by decide
def e2215317528938 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215317528938 : Closed e2215317528938 ∧ code e2215317528938 = 11011410551146 := by decide
theorem cert_e2215317528938 : check e2215317528938 [[]] .width = true := by decide
def e2215317528986 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215317528986 : Closed e2215317528986 ∧ code e2215317528986 = 11011410551194 := by decide
theorem cert_e2215317528986 : check e2215317528986 [[]] .width = true := by decide
def e2215317561370 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215317561370 : Closed e2215317561370 ∧ code e2215317561370 = 11011410583578 := by decide
theorem cert_e2215317561370 : check e2215317561370 [[]] .width = true := by decide
def e2215317561462 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215317561462 : Closed e2215317561462 ∧ code e2215317561462 = 11011410583670 := by decide
theorem cert_e2215317561462 : check e2215317561462 [[]] .width = true := by decide
def e2215317561706 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215317561706 : Closed e2215317561706 ∧ code e2215317561706 = 11011410583914 := by decide
theorem cert_e2215317561706 : check e2215317561706 [[]] .width = true := by decide
def e2215317561754 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215317561754 : Closed e2215317561754 ∧ code e2215317561754 = 11011410583962 := by decide
theorem cert_e2215317561754 : check e2215317561754 [[]] .width = true := by decide
def e2215317790746 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215317790746 : Closed e2215317790746 ∧ code e2215317790746 = 11011410812954 := by decide
theorem cert_e2215317790746 : check e2215317790746 [[]] .width = true := by decide
def e2215317790838 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215317790838 : Closed e2215317790838 ∧ code e2215317790838 = 11011410813046 := by decide
theorem cert_e2215317790838 : check e2215317790838 [[]] .width = true := by decide
def e2215317791082 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215317791082 : Closed e2215317791082 ∧ code e2215317791082 = 11011410813290 := by decide
theorem cert_e2215317791082 : check e2215317791082 [[]] .width = true := by decide
def e2215317791130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215317791130 : Closed e2215317791130 ∧ code e2215317791130 = 11011410813338 := by decide
theorem cert_e2215317791130 : check e2215317791130 [[]] .width = true := by decide
def e2215317839898 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215317839898 : Closed e2215317839898 ∧ code e2215317839898 = 11011410862106 := by decide
theorem cert_e2215317839898 : check e2215317839898 [[]] .width = true := by decide
def e2215317839990 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215317839990 : Closed e2215317839990 ∧ code e2215317839990 = 11011410862198 := by decide
theorem cert_e2215317839990 : check e2215317839990 [[]] .width = true := by decide
def e2215317840234 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215317840234 : Closed e2215317840234 ∧ code e2215317840234 = 11011410862442 := by decide
theorem cert_e2215317840234 : check e2215317840234 [[]] .width = true := by decide
def e2215317840282 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215317840282 : Closed e2215317840282 ∧ code e2215317840282 = 11011410862490 := by decide
theorem cert_e2215317840282 : check e2215317840282 [[]] .width = true := by decide
def e2215317846042 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215317846042 : Closed e2215317846042 ∧ code e2215317846042 = 11011410868250 := by decide
theorem cert_e2215317846042 : check e2215317846042 [[]] .width = true := by decide
def e2215317954586 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215317954586 : Closed e2215317954586 ∧ code e2215317954586 = 11011410976794 := by decide
theorem cert_e2215317954586 : check e2215317954586 [[]] .width = true := by decide
def e2215317954678 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215317954678 : Closed e2215317954678 ∧ code e2215317954678 = 11011410976886 := by decide
theorem cert_e2215317954678 : check e2215317954678 [[]] .width = true := by decide
def e2215317954922 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215317954922 : Closed e2215317954922 ∧ code e2215317954922 = 11011410977130 := by decide
theorem cert_e2215317954922 : check e2215317954922 [[]] .width = true := by decide
def e2215317954970 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215317954970 : Closed e2215317954970 ∧ code e2215317954970 = 11011410977178 := by decide
theorem cert_e2215317954970 : check e2215317954970 [[]] .width = true := by decide
def e2215317970970 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215317970970 : Closed e2215317970970 ∧ code e2215317970970 = 11011410993178 := by decide
theorem cert_e2215317970970 : check e2215317970970 [[]] .width = true := by decide
def e2215317971062 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215317971062 : Closed e2215317971062 ∧ code e2215317971062 = 11011410993270 := by decide
theorem cert_e2215317971062 : check e2215317971062 [[]] .width = true := by decide
def e2215317971306 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215317971306 : Closed e2215317971306 ∧ code e2215317971306 = 11011410993514 := by decide
theorem cert_e2215317971306 : check e2215317971306 [[]] .width = true := by decide
def e2215317971354 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215317971354 : Closed e2215317971354 ∧ code e2215317971354 = 11011410993562 := by decide
theorem cert_e2215317971354 : check e2215317971354 [[]] .width = true := by decide
def e2215317977114 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215317977114 : Closed e2215317977114 ∧ code e2215317977114 = 11011410999322 := by decide
theorem cert_e2215317977114 : check e2215317977114 [[]] .width = true := by decide
def e2215317985306 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215317985306 : Closed e2215317985306 ∧ code e2215317985306 = 11011411007514 := by decide
theorem cert_e2215317985306 : check e2215317985306 [[]] .width = true := by decide
def e2215319101466 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215319101466 : Closed e2215319101466 ∧ code e2215319101466 = 11011412123674 := by decide
theorem cert_e2215319101466 : check e2215319101466 [[]] .width = true := by decide
def e2215319101558 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215319101558 : Closed e2215319101558 ∧ code e2215319101558 = 11011412123766 := by decide
theorem cert_e2215319101558 : check e2215319101558 [[]] .width = true := by decide
def e2215319101802 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215319101802 : Closed e2215319101802 ∧ code e2215319101802 = 11011412124010 := by decide
theorem cert_e2215319101802 : check e2215319101802 [[]] .width = true := by decide
def e2215319101850 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215319101850 : Closed e2215319101850 ∧ code e2215319101850 = 11011412124058 := by decide
theorem cert_e2215319101850 : check e2215319101850 [[]] .width = true := by decide
def e2215319134234 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215319134234 : Closed e2215319134234 ∧ code e2215319134234 = 11011412156442 := by decide
theorem cert_e2215319134234 : check e2215319134234 [[]] .width = true := by decide
def e2215319134326 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215319134326 : Closed e2215319134326 ∧ code e2215319134326 = 11011412156534 := by decide
theorem cert_e2215319134326 : check e2215319134326 [[]] .width = true := by decide
def e2215319134570 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215319134570 : Closed e2215319134570 ∧ code e2215319134570 = 11011412156778 := by decide
theorem cert_e2215319134570 : check e2215319134570 [[]] .width = true := by decide
def e2215319134618 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215319134618 : Closed e2215319134618 ∧ code e2215319134618 = 11011412156826 := by decide
theorem cert_e2215319134618 : check e2215319134618 [[]] .width = true := by decide
def e2215320469702 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215320469702 : Closed e2215320469702 ∧ code e2215320469702 = 11011413491910 := by decide
theorem cert_e2215320469702 : check e2215320469702 [[]] .width = true := by decide
def e2215320674330 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215320674330 : Closed e2215320674330 ∧ code e2215320674330 = 11011413696538 := by decide
theorem cert_e2215320674330 : check e2215320674330 [[]] .width = true := by decide
def e2215320674422 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215320674422 : Closed e2215320674422 ∧ code e2215320674422 = 11011413696630 := by decide
theorem cert_e2215320674422 : check e2215320674422 [[]] .width = true := by decide
def e2215320674666 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215320674666 : Closed e2215320674666 ∧ code e2215320674666 = 11011413696874 := by decide
theorem cert_e2215320674666 : check e2215320674666 [[]] .width = true := by decide
def e2215320674714 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215320674714 : Closed e2215320674714 ∧ code e2215320674714 = 11011413696922 := by decide
theorem cert_e2215320674714 : check e2215320674714 [[]] .width = true := by decide
def e2215320723482 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215320723482 : Closed e2215320723482 ∧ code e2215320723482 = 11011413745690 := by decide
theorem cert_e2215320723482 : check e2215320723482 [[]] .width = true := by decide
def e2215320723574 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215320723574 : Closed e2215320723574 ∧ code e2215320723574 = 11011413745782 := by decide
theorem cert_e2215320723574 : check e2215320723574 [[]] .width = true := by decide
def e2215320723818 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215320723818 : Closed e2215320723818 ∧ code e2215320723818 = 11011413746026 := by decide
theorem cert_e2215320723818 : check e2215320723818 [[]] .width = true := by decide
def e2215320723866 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215320723866 : Closed e2215320723866 ∧ code e2215320723866 = 11011413746074 := by decide
theorem cert_e2215320723866 : check e2215320723866 [[]] .width = true := by decide
def e2215320729626 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215320729626 : Closed e2215320729626 ∧ code e2215320729626 = 11011413751834 := by decide
theorem cert_e2215320729626 : check e2215320729626 [[]] .width = true := by decide
def e2215321141274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2215321141274 : Closed e2215321141274 ∧ code e2215321141274 = 11011414163482 := by decide
theorem cert_e2215321141274 : check e2215321141274 [[]] .width = true := by decide
def e2215321141366 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2215321141366 : Closed e2215321141366 ∧ code e2215321141366 = 11011414163574 := by decide
theorem cert_e2215321141366 : check e2215321141366 [[]] .width = true := by decide
def e2215321141610 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2215321141610 : Closed e2215321141610 ∧ code e2215321141610 = 11011414163818 := by decide
theorem cert_e2215321141610 : check e2215321141610 [[]] .width = true := by decide
def e2215321141658 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2215321141658 : Closed e2215321141658 ∧ code e2215321141658 = 11011414163866 := by decide
theorem cert_e2215321141658 : check e2215321141658 [[]] .width = true := by decide
def e2215321141742 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2215321141742 : Closed e2215321141742 ∧ code e2215321141742 = 11011414163950 := by decide
theorem cert_e2215321141742 : check e2215321141742 [[]] .width = true := by decide
end Blc.Floor43
