import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419143261046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2419143261046 : Closed e2419143261046 ∧ code e2419143261046 = 11215236283254 := by decide
theorem cert_e2419143261046 : check e2419143261046 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143261066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143261066 : Closed e2419143261066 ∧ code e2419143261066 = 11215236283274 := by decide
theorem cert_e2419143261066 : check e2419143261066 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143261090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143261090 : Closed e2419143261090 ∧ code e2419143261090 = 11215236283298 := by decide
theorem cert_e2419143261090 : check e2419143261090 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143261102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2419143261102 : Closed e2419143261102 ∧ code e2419143261102 = 11215236283310 := by decide
theorem cert_e2419143261102 : check e2419143261102 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143261110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2419143261110 : Closed e2419143261110 ∧ code e2419143261110 = 11215236283318 := by decide
theorem cert_e2419143261110 : check e2419143261110 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143261114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2419143261114 : Closed e2419143261114 ∧ code e2419143261114 = 11215236283322 := by decide
theorem cert_e2419143261114 : check e2419143261114 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143261270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2419143261270 : Closed e2419143261270 ∧ code e2419143261270 = 11215236283478 := by decide
theorem cert_e2419143261270 : check e2419143261270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143261274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2419143261274 : Closed e2419143261274 ∧ code e2419143261274 = 11215236283482 := by decide
theorem cert_e2419143261274 : check e2419143261274 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143261462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2419143261462 : Closed e2419143261462 ∧ code e2419143261462 = 11215236283670 := by decide
theorem cert_e2419143261462 : check e2419143261462 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143261538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2419143261538 : Closed e2419143261538 ∧ code e2419143261538 = 11215236283746 := by decide
theorem cert_e2419143261538 : check e2419143261538 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143261550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2419143261550 : Closed e2419143261550 ∧ code e2419143261550 = 11215236283758 := by decide
theorem cert_e2419143261550 : check e2419143261550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143261558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2419143261558 : Closed e2419143261558 ∧ code e2419143261558 = 11215236283766 := by decide
theorem cert_e2419143261558 : check e2419143261558 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143261578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143261578 : Closed e2419143261578 ∧ code e2419143261578 = 11215236283786 := by decide
theorem cert_e2419143261578 : check e2419143261578 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143261602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143261602 : Closed e2419143261602 ∧ code e2419143261602 = 11215236283810 := by decide
theorem cert_e2419143261602 : check e2419143261602 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143261614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2419143261614 : Closed e2419143261614 ∧ code e2419143261614 = 11215236283822 := by decide
theorem cert_e2419143261614 : check e2419143261614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143261622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2419143261622 : Closed e2419143261622 ∧ code e2419143261622 = 11215236283830 := by decide
theorem cert_e2419143261622 : check e2419143261622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143261626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2419143261626 : Closed e2419143261626 ∧ code e2419143261626 = 11215236283834 := by decide
def e2419143261654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2419143261654 : Closed e2419143261654 ∧ code e2419143261654 = 11215236283862 := by decide
theorem cert_e2419143261654 : check e2419143261654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143261658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2419143261658 : Closed e2419143261658 ∧ code e2419143261658 = 11215236283866 := by decide
theorem cert_e2419143261658 : check e2419143261658 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143262702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2419143262702 : Closed e2419143262702 ∧ code e2419143262702 = 11215236284910 := by decide
theorem cert_e2419143262702 : check e2419143262702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143262710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2419143262710 : Closed e2419143262710 ∧ code e2419143262710 = 11215236284918 := by decide
theorem cert_e2419143262710 : check e2419143262710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143263470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143263470 : Closed e2419143263470 ∧ code e2419143263470 = 11215236285678 := by decide
theorem cert_e2419143263470 : check e2419143263470 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143263478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143263478 : Closed e2419143263478 ∧ code e2419143263478 = 11215236285686 := by decide
theorem cert_e2419143263478 : check e2419143263478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143264030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2419143264030 : Closed e2419143264030 ∧ code e2419143264030 = 11215236286238 := by decide
theorem cert_e2419143264030 : check e2419143264030 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143264142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2419143264142 : Closed e2419143264142 ∧ code e2419143264142 = 11215236286350 := by decide
theorem cert_e2419143264142 : check e2419143264142 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143265838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2419143265838 : Closed e2419143265838 ∧ code e2419143265838 = 11215236288046 := by decide
theorem cert_e2419143265838 : check e2419143265838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143266018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2419143266018 : Closed e2419143266018 ∧ code e2419143266018 = 11215236288226 := by decide
theorem cert_e2419143266018 : check e2419143266018 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143266030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2419143266030 : Closed e2419143266030 ∧ code e2419143266030 = 11215236288238 := by decide
theorem cert_e2419143266030 : check e2419143266030 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143266070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2419143266070 : Closed e2419143266070 ∧ code e2419143266070 = 11215236288278 := by decide
theorem cert_e2419143266070 : check e2419143266070 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143266146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2419143266146 : Closed e2419143266146 ∧ code e2419143266146 = 11215236288354 := by decide
theorem cert_e2419143266146 : check e2419143266146 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143266158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2419143266158 : Closed e2419143266158 ∧ code e2419143266158 = 11215236288366 := by decide
theorem cert_e2419143266158 : check e2419143266158 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143266166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2419143266166 : Closed e2419143266166 ∧ code e2419143266166 = 11215236288374 := by decide
theorem cert_e2419143266166 : check e2419143266166 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143268414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2419143268414 : Closed e2419143268414 ∧ code e2419143268414 = 11215236290622 := by decide
theorem cert_e2419143268414 : check e2419143268414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143268834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2419143268834 : Closed e2419143268834 ∧ code e2419143268834 = 11215236291042 := by decide
theorem cert_e2419143268834 : check e2419143268834 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143268846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2419143268846 : Closed e2419143268846 ∧ code e2419143268846 = 11215236291054 := by decide
theorem cert_e2419143268846 : check e2419143268846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143269406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2419143269406 : Closed e2419143269406 ∧ code e2419143269406 = 11215236291614 := by decide
theorem cert_e2419143269406 : check e2419143269406 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143269602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2419143269602 : Closed e2419143269602 ∧ code e2419143269602 = 11215236291810 := by decide
theorem cert_e2419143269602 : check e2419143269602 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143269614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143269614 : Closed e2419143269614 ∧ code e2419143269614 = 11215236291822 := by decide
theorem cert_e2419143269614 : check e2419143269614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143269622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143269622 : Closed e2419143269622 ∧ code e2419143269622 = 11215236291830 := by decide
theorem cert_e2419143269622 : check e2419143269622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143270638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2419143270638 : Closed e2419143270638 ∧ code e2419143270638 = 11215236292846 := by decide
theorem cert_e2419143270638 : check e2419143270638 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143270650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2419143270650 : Closed e2419143270650 ∧ code e2419143270650 = 11215236292858 := by decide
theorem cert_e2419143270650 : check e2419143270650 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143270830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2419143270830 : Closed e2419143270830 ∧ code e2419143270830 = 11215236293038 := by decide
theorem cert_e2419143270830 : check e2419143270830 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143271022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143271022 : Closed e2419143271022 ∧ code e2419143271022 = 11215236293230 := by decide
theorem cert_e2419143271022 : check e2419143271022 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143271034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143271034 : Closed e2419143271034 ∧ code e2419143271034 = 11215236293242 := by decide
theorem cert_e2419143271034 : check e2419143271034 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143271198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2419143271198 : Closed e2419143271198 ∧ code e2419143271198 = 11215236293406 := by decide
theorem cert_e2419143271198 : check e2419143271198 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143271366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2419143271366 : Closed e2419143271366 ∧ code e2419143271366 = 11215236293574 := by decide
theorem cert_e2419143271366 : check e2419143271366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143271982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2419143271982 : Closed e2419143271982 ∧ code e2419143271982 = 11215236294190 := by decide
theorem cert_e2419143271982 : check e2419143271982 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2419143272162 : Closed e2419143272162 ∧ code e2419143272162 = 11215236294370 := by decide
theorem cert_e2419143272162 : check e2419143272162 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2419143272174 : Closed e2419143272174 ∧ code e2419143272174 = 11215236294382 := by decide
theorem cert_e2419143272174 : check e2419143272174 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2419143272302 : Closed e2419143272302 ∧ code e2419143272302 = 11215236294510 := by decide
theorem cert_e2419143272302 : check e2419143272302 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2419143272310 : Closed e2419143272310 ∧ code e2419143272310 = 11215236294518 := by decide
theorem cert_e2419143272310 : check e2419143272310 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2419143272330 : Closed e2419143272330 ∧ code e2419143272330 = 11215236294538 := by decide
theorem cert_e2419143272330 : check e2419143272330 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2419143272354 : Closed e2419143272354 ∧ code e2419143272354 = 11215236294562 := by decide
theorem cert_e2419143272354 : check e2419143272354 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2419143272366 : Closed e2419143272366 ∧ code e2419143272366 = 11215236294574 := by decide
theorem cert_e2419143272366 : check e2419143272366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2419143272374 : Closed e2419143272374 ∧ code e2419143272374 = 11215236294582 := by decide
theorem cert_e2419143272374 : check e2419143272374 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2419143272378 : Closed e2419143272378 ∧ code e2419143272378 = 11215236294586 := by decide
theorem cert_e2419143272378 : check e2419143272378 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2419143272510 : Closed e2419143272510 ∧ code e2419143272510 = 11215236294718 := by decide
theorem cert_e2419143272510 : check e2419143272510 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2419143272930 : Closed e2419143272930 ∧ code e2419143272930 = 11215236295138 := by decide
theorem cert_e2419143272930 : check e2419143272930 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143272942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2419143272942 : Closed e2419143272942 ∧ code e2419143272942 = 11215236295150 := by decide
theorem cert_e2419143272942 : check e2419143272942 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143273710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143273710 : Closed e2419143273710 ∧ code e2419143273710 = 11215236295918 := by decide
theorem cert_e2419143273710 : check e2419143273710 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143273718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143273718 : Closed e2419143273718 ∧ code e2419143273718 = 11215236295926 := by decide
theorem cert_e2419143273718 : check e2419143273718 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143273998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2419143273998 : Closed e2419143273998 ∧ code e2419143273998 = 11215236296206 := by decide
theorem cert_e2419143273998 : check e2419143273998 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143274010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143274010 : Closed e2419143274010 ∧ code e2419143274010 = 11215236296218 := by decide
theorem cert_e2419143274010 : check e2419143274010 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143274082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143274082 : Closed e2419143274082 ∧ code e2419143274082 = 11215236296290 := by decide
theorem cert_e2419143274082 : check e2419143274082 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143274094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143274094 : Closed e2419143274094 ∧ code e2419143274094 = 11215236296302 := by decide
theorem cert_e2419143274094 : check e2419143274094 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143274102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143274102 : Closed e2419143274102 ∧ code e2419143274102 = 11215236296310 := by decide
theorem cert_e2419143274102 : check e2419143274102 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143274106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143274106 : Closed e2419143274106 ∧ code e2419143274106 = 11215236296314 := by decide
theorem cert_e2419143274106 : check e2419143274106 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143274614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2419143274614 : Closed e2419143274614 ∧ code e2419143274614 = 11215236296822 := by decide
theorem cert_e2419143274614 : checkPay e2419143274614 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143274618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2419143274618 : Closed e2419143274618 ∧ code e2419143274618 = 11215236296826 := by decide
theorem cert_e2419143274618 : check e2419143274618 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143274710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2419143274710 : Closed e2419143274710 ∧ code e2419143274710 = 11215236296918 := by decide
theorem cert_e2419143274710 : checkPay e2419143274710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2419143274806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143274806 : Closed e2419143274806 ∧ code e2419143274806 = 11215236297014 := by decide
theorem cert_e2419143274806 : check e2419143274806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143274810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143274810 : Closed e2419143274810 ∧ code e2419143274810 = 11215236297018 := by decide
theorem cert_e2419143274810 : check e2419143274810 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143274894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2419143274894 : Closed e2419143274894 ∧ code e2419143274894 = 11215236297102 := by decide
theorem cert_e2419143274894 : check e2419143274894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143274950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2419143274950 : Closed e2419143274950 ∧ code e2419143274950 = 11215236297158 := by decide
theorem cert_e2419143274950 : check e2419143274950 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143275286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2419143275286 : Closed e2419143275286 ∧ code e2419143275286 = 11215236297494 := by decide
theorem cert_e2419143275286 : checkPay e2419143275286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[]] = true := by decide
def e2419143275362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2419143275362 : Closed e2419143275362 ∧ code e2419143275362 = 11215236297570 := by decide
theorem cert_e2419143275362 : check e2419143275362 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2419143275374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2419143275374 : Closed e2419143275374 ∧ code e2419143275374 = 11215236297582 := by decide
theorem cert_e2419143275374 : check e2419143275374 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2419143275382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2419143275382 : Closed e2419143275382 ∧ code e2419143275382 = 11215236297590 := by decide
theorem cert_e2419143275382 : checkPay e2419143275382 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[]] = true := by decide
def e2419143275402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2419143275402 : Closed e2419143275402 ∧ code e2419143275402 = 11215236297610 := by decide
theorem cert_e2419143275402 : check e2419143275402 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143275426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2419143275426 : Closed e2419143275426 ∧ code e2419143275426 = 11215236297634 := by decide
theorem cert_e2419143275426 : check e2419143275426 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143275438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2419143275438 : Closed e2419143275438 ∧ code e2419143275438 = 11215236297646 := by decide
theorem cert_e2419143275438 : check e2419143275438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143275446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2419143275446 : Closed e2419143275446 ∧ code e2419143275446 = 11215236297654 := by decide
theorem cert_e2419143275446 : checkPay e2419143275446 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.left],[.right,.left,.left],[.right,.left],[.right]] = true := by decide
def e2419143275450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2419143275450 : Closed e2419143275450 ∧ code e2419143275450 = 11215236297658 := by decide
theorem cert_e2419143275450 : check e2419143275450 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143275478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2419143275478 : Closed e2419143275478 ∧ code e2419143275478 = 11215236297686 := by decide
theorem cert_e2419143275478 : checkPay e2419143275478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right],[.under,.left,.right,.under],[.under,.right,.left],[.under,.right],[.under,.right,.under,.left,.right],[.under,.right,.under,.left,.right,.under]] = true := by decide
def e2419143275482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2419143275482 : Closed e2419143275482 ∧ code e2419143275482 = 11215236297690 := by decide
def e2419143275550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2419143275550 : Closed e2419143275550 ∧ code e2419143275550 = 11215236297758 := by decide
theorem cert_e2419143275550 : check e2419143275550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143275746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2419143275746 : Closed e2419143275746 ∧ code e2419143275746 = 11215236297954 := by decide
theorem cert_e2419143275746 : check e2419143275746 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143275758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143275758 : Closed e2419143275758 ∧ code e2419143275758 = 11215236297966 := by decide
theorem cert_e2419143275758 : check e2419143275758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143275766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143275766 : Closed e2419143275766 ∧ code e2419143275766 = 11215236297974 := by decide
theorem cert_e2419143275766 : check e2419143275766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143276046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2419143276046 : Closed e2419143276046 ∧ code e2419143276046 = 11215236298254 := by decide
theorem cert_e2419143276046 : check e2419143276046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143276058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143276058 : Closed e2419143276058 ∧ code e2419143276058 = 11215236298266 := by decide
theorem cert_e2419143276058 : check e2419143276058 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143276130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143276130 : Closed e2419143276130 ∧ code e2419143276130 = 11215236298338 := by decide
theorem cert_e2419143276130 : check e2419143276130 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143276142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143276142 : Closed e2419143276142 ∧ code e2419143276142 = 11215236298350 := by decide
theorem cert_e2419143276142 : check e2419143276142 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143276150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143276150 : Closed e2419143276150 ∧ code e2419143276150 = 11215236298358 := by decide
theorem cert_e2419143276150 : check e2419143276150 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143276154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143276154 : Closed e2419143276154 ∧ code e2419143276154 = 11215236298362 := by decide
theorem cert_e2419143276154 : check e2419143276154 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143276342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143276342 : Closed e2419143276342 ∧ code e2419143276342 = 11215236298550 := by decide
theorem cert_e2419143276342 : check e2419143276342 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143276346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143276346 : Closed e2419143276346 ∧ code e2419143276346 = 11215236298554 := by decide
theorem cert_e2419143276346 : check e2419143276346 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143281518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419143281518 : Closed e2419143281518 ∧ code e2419143281518 = 11215236303726 := by decide
theorem cert_e2419143281518 : check e2419143281518 [[],[]] .smaller = true := by decide
def e2419143281526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419143281526 : Closed e2419143281526 ∧ code e2419143281526 = 11215236303734 := by decide
theorem cert_e2419143281526 : check e2419143281526 [[],[]] .smaller = true := by decide
def e2419143281582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419143281582 : Closed e2419143281582 ∧ code e2419143281582 = 11215236303790 := by decide
theorem cert_e2419143281582 : check e2419143281582 [[],[]] .smaller = true := by decide
def e2419143281594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419143281594 : Closed e2419143281594 ∧ code e2419143281594 = 11215236303802 := by decide
theorem cert_e2419143281594 : check e2419143281594 [[],[]] .smaller = true := by decide
def e2419143281622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419143281622 : Closed e2419143281622 ∧ code e2419143281622 = 11215236303830 := by decide
theorem cert_e2419143281622 : check e2419143281622 [[],[]] .smaller = true := by decide
def e2419143281626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419143281626 : Closed e2419143281626 ∧ code e2419143281626 = 11215236303834 := by decide
theorem cert_e2419143281626 : check e2419143281626 [[],[]] .smaller = true := by decide
def e2419143281902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419143281902 : Closed e2419143281902 ∧ code e2419143281902 = 11215236304110 := by decide
theorem cert_e2419143281902 : check e2419143281902 [[],[]] .smaller = true := by decide
def e2419143281910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419143281910 : Closed e2419143281910 ∧ code e2419143281910 = 11215236304118 := by decide
theorem cert_e2419143281910 : check e2419143281910 [[],[]] .smaller = true := by decide
def e2419143282286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419143282286 : Closed e2419143282286 ∧ code e2419143282286 = 11215236304494 := by decide
theorem cert_e2419143282286 : check e2419143282286 [[],[]] .smaller = true := by decide
def e2419143282298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419143282298 : Closed e2419143282298 ∧ code e2419143282298 = 11215236304506 := by decide
theorem cert_e2419143282298 : check e2419143282298 [[],[]] .smaller = true := by decide
def e2419143282486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419143282486 : Closed e2419143282486 ∧ code e2419143282486 = 11215236304694 := by decide
theorem cert_e2419143282486 : check e2419143282486 [[],[]] .smaller = true := by decide
def e2419143282490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419143282490 : Closed e2419143282490 ∧ code e2419143282490 = 11215236304698 := by decide
theorem cert_e2419143282490 : check e2419143282490 [[],[]] .smaller = true := by decide
def e2419143290414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419143290414 : Closed e2419143290414 ∧ code e2419143290414 = 11215236312622 := by decide
theorem cert_e2419143290414 : check e2419143290414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143290594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419143290594 : Closed e2419143290594 ∧ code e2419143290594 = 11215236312802 := by decide
theorem cert_e2419143290594 : check e2419143290594 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143290606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2419143290606 : Closed e2419143290606 ∧ code e2419143290606 = 11215236312814 := by decide
theorem cert_e2419143290606 : check e2419143290606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143290646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419143290646 : Closed e2419143290646 ∧ code e2419143290646 = 11215236312854 := by decide
theorem cert_e2419143290646 : check e2419143290646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143290722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419143290722 : Closed e2419143290722 ∧ code e2419143290722 = 11215236312930 := by decide
theorem cert_e2419143290722 : check e2419143290722 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143290734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2419143290734 : Closed e2419143290734 ∧ code e2419143290734 = 11215236312942 := by decide
theorem cert_e2419143290734 : check e2419143290734 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143290742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2419143290742 : Closed e2419143290742 ∧ code e2419143290742 = 11215236312950 := by decide
theorem cert_e2419143290742 : check e2419143290742 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143292990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2419143292990 : Closed e2419143292990 ∧ code e2419143292990 = 11215236315198 := by decide
theorem cert_e2419143292990 : check e2419143292990 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143293410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419143293410 : Closed e2419143293410 ∧ code e2419143293410 = 11215236315618 := by decide
theorem cert_e2419143293410 : check e2419143293410 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143293422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2419143293422 : Closed e2419143293422 ∧ code e2419143293422 = 11215236315630 := by decide
theorem cert_e2419143293422 : check e2419143293422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143293982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2419143293982 : Closed e2419143293982 ∧ code e2419143293982 = 11215236316190 := by decide
theorem cert_e2419143293982 : check e2419143293982 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143294178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419143294178 : Closed e2419143294178 ∧ code e2419143294178 = 11215236316386 := by decide
theorem cert_e2419143294178 : check e2419143294178 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143294190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143294190 : Closed e2419143294190 ∧ code e2419143294190 = 11215236316398 := by decide
theorem cert_e2419143294190 : check e2419143294190 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143294198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143294198 : Closed e2419143294198 ∧ code e2419143294198 = 11215236316406 := by decide
theorem cert_e2419143294198 : check e2419143294198 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143313374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2419143313374 : Closed e2419143313374 ∧ code e2419143313374 = 11215236335582 := by decide
theorem cert_e2419143313374 : check e2419143313374 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419143317038 : Closed e2419143317038 ∧ code e2419143317038 = 11215236339246 := by decide
theorem cert_e2419143317038 : check e2419143317038 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419143317218 : Closed e2419143317218 ∧ code e2419143317218 = 11215236339426 := by decide
theorem cert_e2419143317218 : check e2419143317218 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2419143317230 : Closed e2419143317230 ∧ code e2419143317230 = 11215236339438 := by decide
theorem cert_e2419143317230 : check e2419143317230 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2419143317358 : Closed e2419143317358 ∧ code e2419143317358 = 11215236339566 := by decide
theorem cert_e2419143317358 : check e2419143317358 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2419143317366 : Closed e2419143317366 ∧ code e2419143317366 = 11215236339574 := by decide
theorem cert_e2419143317366 : check e2419143317366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143317386 : Closed e2419143317386 ∧ code e2419143317386 = 11215236339594 := by decide
theorem cert_e2419143317386 : check e2419143317386 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143317410 : Closed e2419143317410 ∧ code e2419143317410 = 11215236339618 := by decide
theorem cert_e2419143317410 : check e2419143317410 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2419143317422 : Closed e2419143317422 ∧ code e2419143317422 = 11215236339630 := by decide
theorem cert_e2419143317422 : check e2419143317422 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2419143317430 : Closed e2419143317430 ∧ code e2419143317430 = 11215236339638 := by decide
theorem cert_e2419143317430 : check e2419143317430 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2419143317434 : Closed e2419143317434 ∧ code e2419143317434 = 11215236339642 := by decide
theorem cert_e2419143317434 : check e2419143317434 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2419143317566 : Closed e2419143317566 ∧ code e2419143317566 = 11215236339774 := by decide
theorem cert_e2419143317566 : check e2419143317566 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419143317986 : Closed e2419143317986 ∧ code e2419143317986 = 11215236340194 := by decide
theorem cert_e2419143317986 : check e2419143317986 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143317998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2419143317998 : Closed e2419143317998 ∧ code e2419143317998 = 11215236340206 := by decide
theorem cert_e2419143317998 : check e2419143317998 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143318766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143318766 : Closed e2419143318766 ∧ code e2419143318766 = 11215236340974 := by decide
theorem cert_e2419143318766 : check e2419143318766 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143318774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143318774 : Closed e2419143318774 ∧ code e2419143318774 = 11215236340982 := by decide
theorem cert_e2419143318774 : check e2419143318774 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143319054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143319054 : Closed e2419143319054 ∧ code e2419143319054 = 11215236341262 := by decide
theorem cert_e2419143319054 : check e2419143319054 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143319066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143319066 : Closed e2419143319066 ∧ code e2419143319066 = 11215236341274 := by decide
theorem cert_e2419143319066 : check e2419143319066 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143319138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143319138 : Closed e2419143319138 ∧ code e2419143319138 = 11215236341346 := by decide
theorem cert_e2419143319138 : check e2419143319138 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143319150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143319150 : Closed e2419143319150 ∧ code e2419143319150 = 11215236341358 := by decide
theorem cert_e2419143319150 : check e2419143319150 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143319158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143319158 : Closed e2419143319158 ∧ code e2419143319158 = 11215236341366 := by decide
theorem cert_e2419143319158 : check e2419143319158 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143319162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143319162 : Closed e2419143319162 ∧ code e2419143319162 = 11215236341370 := by decide
theorem cert_e2419143319162 : check e2419143319162 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143328734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2419143328734 : Closed e2419143328734 ∧ code e2419143328734 = 11215236350942 := by decide
theorem cert_e2419143328734 : check e2419143328734 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143328750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2419143328750 : Closed e2419143328750 ∧ code e2419143328750 = 11215236350958 := by decide
theorem cert_e2419143328750 : check e2419143328750 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[],[.under]] .identityHead = true := by decide
def e2419143330582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419143330582 : Closed e2419143330582 ∧ code e2419143330582 = 11215236352790 := by decide
theorem cert_e2419143330582 : check e2419143330582 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143330658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419143330658 : Closed e2419143330658 ∧ code e2419143330658 = 11215236352866 := by decide
theorem cert_e2419143330658 : check e2419143330658 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2419143330670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419143330670 : Closed e2419143330670 ∧ code e2419143330670 = 11215236352878 := by decide
theorem cert_e2419143330670 : check e2419143330670 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143330678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419143330678 : Closed e2419143330678 ∧ code e2419143330678 = 11215236352886 := by decide
theorem cert_e2419143330678 : check e2419143330678 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2419143330698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143330698 : Closed e2419143330698 ∧ code e2419143330698 = 11215236352906 := by decide
theorem cert_e2419143330698 : check e2419143330698 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143330722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143330722 : Closed e2419143330722 ∧ code e2419143330722 = 11215236352930 := by decide
theorem cert_e2419143330722 : check e2419143330722 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143330734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419143330734 : Closed e2419143330734 ∧ code e2419143330734 = 11215236352942 := by decide
theorem cert_e2419143330734 : check e2419143330734 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143330742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2419143330742 : Closed e2419143330742 ∧ code e2419143330742 = 11215236352950 := by decide
theorem cert_e2419143330742 : check e2419143330742 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143330746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419143330746 : Closed e2419143330746 ∧ code e2419143330746 = 11215236352954 := by decide
theorem cert_e2419143330746 : check e2419143330746 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143330774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419143330774 : Closed e2419143330774 ∧ code e2419143330774 = 11215236352982 := by decide
theorem cert_e2419143330774 : checkPay e2419143330774 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143330778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419143330778 : Closed e2419143330778 ∧ code e2419143330778 = 11215236352986 := by decide
theorem cert_e2419143330778 : check e2419143330778 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143330846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2419143330846 : Closed e2419143330846 ∧ code e2419143330846 = 11215236353054 := by decide
theorem cert_e2419143330846 : check e2419143330846 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under,.left],[.under]] .identityHead = true := by decide
def e2419143331042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419143331042 : Closed e2419143331042 ∧ code e2419143331042 = 11215236353250 := by decide
theorem cert_e2419143331042 : check e2419143331042 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
end Blc.Floor43
