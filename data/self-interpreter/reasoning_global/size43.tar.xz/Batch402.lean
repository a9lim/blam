import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372989666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372989666 : Closed e2422372989666 ∧ code e2422372989666 = 11218466011874 := by decide
theorem cert_e2422372989666 : check e2422372989666 [[],[]] .smaller = true := by decide
def e2422372989678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e2422372989678 : Closed e2422372989678 ∧ code e2422372989678 = 11218466011886 := by decide
theorem cert_e2422372989678 : check e2422372989678 [[],[]] .smaller = true := by decide
def e2422372989686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e2422372989686 : Closed e2422372989686 ∧ code e2422372989686 = 11218466011894 := by decide
theorem cert_e2422372989686 : check e2422372989686 [[],[]] .three = true := by decide
def e2422372989722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372989722 : Closed e2422372989722 ∧ code e2422372989722 = 11218466011930 := by decide
theorem cert_e2422372989722 : check e2422372989722 [[],[]] .smaller = true := by decide
def e2422372989766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372989766 : Closed e2422372989766 ∧ code e2422372989766 = 11218466011974 := by decide
theorem cert_e2422372989766 : check e2422372989766 [[],[]] .smaller = true := by decide
def e2422372989790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2422372989790 : Closed e2422372989790 ∧ code e2422372989790 = 11218466011998 := by decide
theorem cert_e2422372989790 : check e2422372989790 [[],[]] .three = true := by decide
def e2422372989818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2422372989818 : Closed e2422372989818 ∧ code e2422372989818 = 11218466012026 := by decide
theorem cert_e2422372989818 : check e2422372989818 [[],[]] .three = true := by decide
def e2422372989834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372989834 : Closed e2422372989834 ∧ code e2422372989834 = 11218466012042 := by decide
theorem cert_e2422372989834 : check e2422372989834 [[],[]] .smaller = true := by decide
def e2422372989858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372989858 : Closed e2422372989858 ∧ code e2422372989858 = 11218466012066 := by decide
theorem cert_e2422372989858 : check e2422372989858 [[],[]] .smaller = true := by decide
def e2422372989870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2422372989870 : Closed e2422372989870 ∧ code e2422372989870 = 11218466012078 := by decide
theorem cert_e2422372989870 : check e2422372989870 [[],[]] .smaller = true := by decide
def e2422372989882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2422372989882 : Closed e2422372989882 ∧ code e2422372989882 = 11218466012090 := by decide
theorem cert_e2422372989882 : check e2422372989882 [[],[]] .smaller = true := by decide
def e2422372989910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2422372989910 : Closed e2422372989910 ∧ code e2422372989910 = 11218466012118 := by decide
theorem cert_e2422372989910 : check e2422372989910 [[],[]] .three = true := by decide
def e2422372989914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2422372989914 : Closed e2422372989914 ∧ code e2422372989914 = 11218466012122 := by decide
theorem cert_e2422372989914 : check e2422372989914 [[],[]] .three = true := by decide
def e2422372990038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372990038 : Closed e2422372990038 ∧ code e2422372990038 = 11218466012246 := by decide
theorem cert_e2422372990038 : check e2422372990038 [[],[]] .three = true := by decide
def e2422372990042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372990042 : Closed e2422372990042 ∧ code e2422372990042 = 11218466012250 := by decide
theorem cert_e2422372990042 : check e2422372990042 [[],[]] .three = true := by decide
def e2422372990058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372990058 : Closed e2422372990058 ∧ code e2422372990058 = 11218466012266 := by decide
theorem cert_e2422372990058 : check e2422372990058 [[],[]] .three = true := by decide
def e2422372990230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372990230 : Closed e2422372990230 ∧ code e2422372990230 = 11218466012438 := by decide
theorem cert_e2422372990230 : check e2422372990230 [[],[]] .three = true := by decide
def e2422372990234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372990234 : Closed e2422372990234 ∧ code e2422372990234 = 11218466012442 := by decide
theorem cert_e2422372990234 : check e2422372990234 [[],[]] .three = true := by decide
def e2422372990278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372990278 : Closed e2422372990278 ∧ code e2422372990278 = 11218466012486 := by decide
theorem cert_e2422372990278 : check e2422372990278 [[],[]] .three = true := by decide
def e2422372990302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2422372990302 : Closed e2422372990302 ∧ code e2422372990302 = 11218466012510 := by decide
theorem cert_e2422372990302 : check e2422372990302 [[],[]] .three = true := by decide
def e2422372990306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372990306 : Closed e2422372990306 ∧ code e2422372990306 = 11218466012514 := by decide
theorem cert_e2422372990306 : check e2422372990306 [[],[]] .three = true := by decide
def e2422372990318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2422372990318 : Closed e2422372990318 ∧ code e2422372990318 = 11218466012526 := by decide
theorem cert_e2422372990318 : check e2422372990318 [[],[]] .three = true := by decide
def e2422372990326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2422372990326 : Closed e2422372990326 ∧ code e2422372990326 = 11218466012534 := by decide
theorem cert_e2422372990326 : check e2422372990326 [[],[]] .three = true := by decide
def e2422372990330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2422372990330 : Closed e2422372990330 ∧ code e2422372990330 = 11218466012538 := by decide
theorem cert_e2422372990330 : check e2422372990330 [[],[]] .three = true := by decide
def e2422372990346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372990346 : Closed e2422372990346 ∧ code e2422372990346 = 11218466012554 := by decide
theorem cert_e2422372990346 : check e2422372990346 [[],[]] .three = true := by decide
def e2422372990370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372990370 : Closed e2422372990370 ∧ code e2422372990370 = 11218466012578 := by decide
theorem cert_e2422372990370 : check e2422372990370 [[],[]] .three = true := by decide
def e2422372990382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2422372990382 : Closed e2422372990382 ∧ code e2422372990382 = 11218466012590 := by decide
theorem cert_e2422372990382 : check e2422372990382 [[],[]] .three = true := by decide
def e2422372990394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2422372990394 : Closed e2422372990394 ∧ code e2422372990394 = 11218466012602 := by decide
theorem cert_e2422372990394 : check e2422372990394 [[],[]] .three = true := by decide
def e2422372990422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2422372990422 : Closed e2422372990422 ∧ code e2422372990422 = 11218466012630 := by decide
theorem cert_e2422372990422 : check e2422372990422 [[],[]] .three = true := by decide
def e2422372990426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2422372990426 : Closed e2422372990426 ∧ code e2422372990426 = 11218466012634 := by decide
theorem cert_e2422372990426 : check e2422372990426 [[],[]] .three = true := by decide
def e2422372990442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2422372990442 : Closed e2422372990442 ∧ code e2422372990442 = 11218466012650 := by decide
theorem cert_e2422372990442 : check e2422372990442 [[],[]] .three = true := by decide
def e2422372991406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e2422372991406 : Closed e2422372991406 ∧ code e2422372991406 = 11218466013614 := by decide
theorem cert_e2422372991406 : check e2422372991406 [[],[]] .smaller = true := by decide
def e2422372991598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372991598 : Closed e2422372991598 ∧ code e2422372991598 = 11218466013806 := by decide
theorem cert_e2422372991598 : check e2422372991598 [[],[]] .smaller = true := by decide
def e2422372991610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372991610 : Closed e2422372991610 ∧ code e2422372991610 = 11218466013818 := by decide
theorem cert_e2422372991610 : check e2422372991610 [[],[]] .smaller = true := by decide
def e2422372991966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3)))) (.var 3)))))))
theorem wire_e2422372991966 : Closed e2422372991966 ∧ code e2422372991966 = 11218466014174 := by decide
theorem cert_e2422372991966 : check e2422372991966 [[],[]] .three = true := by decide
def e2422372991982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 2)))))))
theorem wire_e2422372991982 : Closed e2422372991982 ∧ code e2422372991982 = 11218466014190 := by decide
theorem cert_e2422372991982 : check e2422372991982 [[],[]] .smaller = true := by decide
def e2422372991990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 5)))) (.var 1)))))))
theorem wire_e2422372991990 : Closed e2422372991990 ∧ code e2422372991990 = 11218466014198 := by decide
theorem cert_e2422372991990 : check e2422372991990 [[],[]] .three = true := by decide
def e2422372992734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e2422372992734 : Closed e2422372992734 ∧ code e2422372992734 = 11218466014942 := by decide
theorem cert_e2422372992734 : check e2422372992734 [[],[]] .three = true := by decide
def e2422372992750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2422372992750 : Closed e2422372992750 ∧ code e2422372992750 = 11218466014958 := by decide
theorem cert_e2422372992750 : check e2422372992750 [[],[]] .smaller = true := by decide
def e2422372992758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2422372992758 : Closed e2422372992758 ∧ code e2422372992758 = 11218466014966 := by decide
theorem cert_e2422372992758 : check e2422372992758 [[],[]] .smaller = true := by decide
def e2422372992762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 4)))) (.var 0)))))))
theorem wire_e2422372992762 : Closed e2422372992762 ∧ code e2422372992762 = 11218466014970 := by decide
theorem cert_e2422372992762 : check e2422372992762 [[],[]] .three = true := by decide
def e2422372992862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e2422372992862 : Closed e2422372992862 ∧ code e2422372992862 = 11218466015070 := by decide
theorem cert_e2422372992862 : check e2422372992862 [[],[]] .three = true := by decide
def e2422372992878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2422372992878 : Closed e2422372992878 ∧ code e2422372992878 = 11218466015086 := by decide
theorem cert_e2422372992878 : check e2422372992878 [[],[]] .smaller = true := by decide
def e2422372992890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2422372992890 : Closed e2422372992890 ∧ code e2422372992890 = 11218466015098 := by decide
theorem cert_e2422372992890 : check e2422372992890 [[],[]] .smaller = true := by decide
def e2422372992942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2422372992942 : Closed e2422372992942 ∧ code e2422372992942 = 11218466015150 := by decide
theorem cert_e2422372992942 : check e2422372992942 [[],[]] .smaller = true := by decide
def e2422372992982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2422372992982 : Closed e2422372992982 ∧ code e2422372992982 = 11218466015190 := by decide
theorem cert_e2422372992982 : check e2422372992982 [[],[]] .smaller = true := by decide
def e2422372992986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2422372992986 : Closed e2422372992986 ∧ code e2422372992986 = 11218466015194 := by decide
theorem cert_e2422372992986 : check e2422372992986 [[],[]] .smaller = true := by decide
def e2422372993002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 0)))) (.var 0)))))))
theorem wire_e2422372993002 : Closed e2422372993002 ∧ code e2422372993002 = 11218466015210 := by decide
theorem cert_e2422372993002 : check e2422372993002 [[],[]] .three = true := by decide
def e2422372993502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372993502 : Closed e2422372993502 ∧ code e2422372993502 = 11218466015710 := by decide
theorem cert_e2422372993502 : check e2422372993502 [[],[]] .three = true := by decide
def e2422372993518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372993518 : Closed e2422372993518 ∧ code e2422372993518 = 11218466015726 := by decide
theorem cert_e2422372993518 : check e2422372993518 [[],[]] .smaller = true := by decide
def e2422372993526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372993526 : Closed e2422372993526 ∧ code e2422372993526 = 11218466015734 := by decide
theorem cert_e2422372993526 : check e2422372993526 [[],[]] .three = true := by decide
def e2422372994270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372994270 : Closed e2422372994270 ∧ code e2422372994270 = 11218466016478 := by decide
theorem cert_e2422372994270 : check e2422372994270 [[],[]] .three = true := by decide
def e2422372994286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372994286 : Closed e2422372994286 ∧ code e2422372994286 = 11218466016494 := by decide
theorem cert_e2422372994286 : check e2422372994286 [[],[]] .smaller = true := by decide
def e2422372994294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372994294 : Closed e2422372994294 ∧ code e2422372994294 = 11218466016502 := by decide
theorem cert_e2422372994294 : check e2422372994294 [[],[]] .smaller = true := by decide
def e2422372994298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372994298 : Closed e2422372994298 ∧ code e2422372994298 = 11218466016506 := by decide
theorem cert_e2422372994298 : check e2422372994298 [[],[]] .three = true := by decide
def e2422372994622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.lam (.var 4))))))))
theorem wire_e2422372994622 : Closed e2422372994622 ∧ code e2422372994622 = 11218466016830 := by decide
theorem cert_e2422372994622 : check e2422372994622 [[],[]] .three = true := by decide
def e2422372994670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372994670 : Closed e2422372994670 ∧ code e2422372994670 = 11218466016878 := by decide
theorem cert_e2422372994670 : check e2422372994670 [[],[]] .smaller = true := by decide
def e2422372994682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372994682 : Closed e2422372994682 ∧ code e2422372994682 = 11218466016890 := by decide
theorem cert_e2422372994682 : check e2422372994682 [[],[]] .smaller = true := by decide
def e2422372994846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 3))))))))
theorem wire_e2422372994846 : Closed e2422372994846 ∧ code e2422372994846 = 11218466017054 := by decide
theorem cert_e2422372994846 : check e2422372994846 [[],[]] .smaller = true := by decide
def e2422372994870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372994870 : Closed e2422372994870 ∧ code e2422372994870 = 11218466017078 := by decide
theorem cert_e2422372994870 : check e2422372994870 [[],[]] .smaller = true := by decide
def e2422372994874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372994874 : Closed e2422372994874 ∧ code e2422372994874 = 11218466017082 := by decide
theorem cert_e2422372994874 : check e2422372994874 [[],[]] .smaller = true := by decide
def e2422372994958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.lam (.var 2))))))))
theorem wire_e2422372994958 : Closed e2422372994958 ∧ code e2422372994958 = 11218466017166 := by decide
theorem cert_e2422372994958 : check e2422372994958 [[],[]] .three = true := by decide
def e2422372994970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372994970 : Closed e2422372994970 ∧ code e2422372994970 = 11218466017178 := by decide
theorem cert_e2422372994970 : check e2422372994970 [[],[]] .three = true := by decide
def e2422372996782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422372996782 : Closed e2422372996782 ∧ code e2422372996782 = 11218466018990 := by decide
theorem cert_e2422372996782 : check e2422372996782 [[],[]] .smaller = true := by decide
def e2422372996794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422372996794 : Closed e2422372996794 ∧ code e2422372996794 = 11218466019002 := by decide
theorem cert_e2422372996794 : check e2422372996794 [[],[]] .smaller = true := by decide
def e2422372996842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422372996842 : Closed e2422372996842 ∧ code e2422372996842 = 11218466019050 := by decide
theorem cert_e2422372996842 : check e2422372996842 [[],[]] .smaller = true := by decide
def e2422372997034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422372997034 : Closed e2422372997034 ∧ code e2422372997034 = 11218466019242 := by decide
theorem cert_e2422372997034 : check e2422372997034 [[],[]] .smaller = true := by decide
def e2422372997166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422372997166 : Closed e2422372997166 ∧ code e2422372997166 = 11218466019374 := by decide
theorem cert_e2422372997166 : check e2422372997166 [[],[]] .smaller = true := by decide
def e2422372997342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422372997342 : Closed e2422372997342 ∧ code e2422372997342 = 11218466019550 := by decide
theorem cert_e2422372997342 : check e2422372997342 [[],[]] .three = true := by decide
def e2422372997358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422372997358 : Closed e2422372997358 ∧ code e2422372997358 = 11218466019566 := by decide
theorem cert_e2422372997358 : check e2422372997358 [[],[]] .smaller = true := by decide
def e2422372997366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422372997366 : Closed e2422372997366 ∧ code e2422372997366 = 11218466019574 := by decide
theorem cert_e2422372997366 : check e2422372997366 [[],[]] .smaller = true := by decide
def e2422372997370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422372997370 : Closed e2422372997370 ∧ code e2422372997370 = 11218466019578 := by decide
theorem cert_e2422372997370 : check e2422372997370 [[],[]] .three = true := by decide
def e2422372997550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422372997550 : Closed e2422372997550 ∧ code e2422372997550 = 11218466019758 := by decide
theorem cert_e2422372997550 : check e2422372997550 [[],[]] .smaller = true := by decide
def e2422372997562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422372997562 : Closed e2422372997562 ∧ code e2422372997562 = 11218466019770 := by decide
theorem cert_e2422372997562 : check e2422372997562 [[],[]] .smaller = true := by decide
def e2422372997610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422372997610 : Closed e2422372997610 ∧ code e2422372997610 = 11218466019818 := by decide
theorem cert_e2422372997610 : check e2422372997610 [[],[]] .smaller = true := by decide
def e2422372997694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422372997694 : Closed e2422372997694 ∧ code e2422372997694 = 11218466019902 := by decide
theorem cert_e2422372997694 : check e2422372997694 [[],[]] .three = true := by decide
def e2422372997742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372997742 : Closed e2422372997742 ∧ code e2422372997742 = 11218466019950 := by decide
theorem cert_e2422372997742 : check e2422372997742 [[],[]] .smaller = true := by decide
def e2422372997754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372997754 : Closed e2422372997754 ∧ code e2422372997754 = 11218466019962 := by decide
theorem cert_e2422372997754 : check e2422372997754 [[],[]] .smaller = true := by decide
def e2422372997918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422372997918 : Closed e2422372997918 ∧ code e2422372997918 = 11218466020126 := by decide
theorem cert_e2422372997918 : check e2422372997918 [[],[]] .smaller = true := by decide
def e2422372998018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372998018 : Closed e2422372998018 ∧ code e2422372998018 = 11218466020226 := by decide
theorem cert_e2422372998018 : check e2422372998018 [[],[]] .smaller = true := by decide
def e2422372998030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422372998030 : Closed e2422372998030 ∧ code e2422372998030 = 11218466020238 := by decide
theorem cert_e2422372998030 : check e2422372998030 [[],[]] .smaller = true := by decide
def e2422372998042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372998042 : Closed e2422372998042 ∧ code e2422372998042 = 11218466020250 := by decide
theorem cert_e2422372998042 : check e2422372998042 [[],[]] .smaller = true := by decide
def e2422372998086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422372998086 : Closed e2422372998086 ∧ code e2422372998086 = 11218466020294 := by decide
theorem cert_e2422372998086 : check e2422372998086 [[],[]] .three = true := by decide
def e2422372998110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e2422372998110 : Closed e2422372998110 ∧ code e2422372998110 = 11218466020318 := by decide
theorem cert_e2422372998110 : check e2422372998110 [[],[]] .three = true := by decide
def e2422372998238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422372998238 : Closed e2422372998238 ∧ code e2422372998238 = 11218466020446 := by decide
theorem cert_e2422372998238 : check e2422372998238 [[],[]] .three = true := by decide
def e2422372998254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2422372998254 : Closed e2422372998254 ∧ code e2422372998254 = 11218466020462 := by decide
theorem cert_e2422372998254 : check e2422372998254 [[],[]] .smaller = true := by decide
def e2422372998266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422372998266 : Closed e2422372998266 ∧ code e2422372998266 = 11218466020474 := by decide
theorem cert_e2422372998266 : check e2422372998266 [[],[]] .smaller = true := by decide
def e2422372998430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2422372998430 : Closed e2422372998430 ∧ code e2422372998430 = 11218466020638 := by decide
theorem cert_e2422372998430 : check e2422372998430 [[],[]] .smaller = true := by decide
def e2422372998598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422372998598 : Closed e2422372998598 ∧ code e2422372998598 = 11218466020806 := by decide
theorem cert_e2422372998598 : check e2422372998598 [[],[]] .smaller = true := by decide
def e2422372998622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e2422372998622 : Closed e2422372998622 ∧ code e2422372998622 = 11218466020830 := by decide
theorem cert_e2422372998622 : check e2422372998622 [[],[]] .three = true := by decide
def e2422372998626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422372998626 : Closed e2422372998626 ∧ code e2422372998626 = 11218466020834 := by decide
theorem cert_e2422372998626 : check e2422372998626 [[],[]] .three = true := by decide
def e2422372998638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e2422372998638 : Closed e2422372998638 ∧ code e2422372998638 = 11218466020846 := by decide
theorem cert_e2422372998638 : check e2422372998638 [[],[]] .three = true := by decide
def e2422372998666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422372998666 : Closed e2422372998666 ∧ code e2422372998666 = 11218466020874 := by decide
theorem cert_e2422372998666 : check e2422372998666 [[],[]] .smaller = true := by decide
def e2422372998702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372998702 : Closed e2422372998702 ∧ code e2422372998702 = 11218466020910 := by decide
theorem cert_e2422372998702 : check e2422372998702 [[],[]] .smaller = true := by decide
def e2422372998710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422372998710 : Closed e2422372998710 ∧ code e2422372998710 = 11218466020918 := by decide
theorem cert_e2422372998710 : check e2422372998710 [[],[]] .smaller = true := by decide
def e2422372998714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422372998714 : Closed e2422372998714 ∧ code e2422372998714 = 11218466020922 := by decide
theorem cert_e2422372998714 : check e2422372998714 [[],[]] .smaller = true := by decide
def e2422372998762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422372998762 : Closed e2422372998762 ∧ code e2422372998762 = 11218466020970 := by decide
theorem cert_e2422372998762 : check e2422372998762 [[],[]] .smaller = true := by decide
def e2422372998786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372998786 : Closed e2422372998786 ∧ code e2422372998786 = 11218466020994 := by decide
theorem cert_e2422372998786 : check e2422372998786 [[],[]] .smaller = true := by decide
def e2422372998798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422372998798 : Closed e2422372998798 ∧ code e2422372998798 = 11218466021006 := by decide
theorem cert_e2422372998798 : check e2422372998798 [[],[]] .smaller = true := by decide
def e2422372998810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372998810 : Closed e2422372998810 ∧ code e2422372998810 = 11218466021018 := by decide
theorem cert_e2422372998810 : check e2422372998810 [[],[]] .smaller = true := by decide
def e2422372998854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422372998854 : Closed e2422372998854 ∧ code e2422372998854 = 11218466021062 := by decide
theorem cert_e2422372998854 : check e2422372998854 [[],[]] .smaller = true := by decide
def e2422372998878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e2422372998878 : Closed e2422372998878 ∧ code e2422372998878 = 11218466021086 := by decide
theorem cert_e2422372998878 : check e2422372998878 [[],[]] .three = true := by decide
def e2422372998882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422372998882 : Closed e2422372998882 ∧ code e2422372998882 = 11218466021090 := by decide
theorem cert_e2422372998882 : check e2422372998882 [[],[]] .smaller = true := by decide
def e2422372998894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 2)))))))
theorem wire_e2422372998894 : Closed e2422372998894 ∧ code e2422372998894 = 11218466021102 := by decide
theorem cert_e2422372998894 : check e2422372998894 [[],[]] .smaller = true := by decide
def e2422372998902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e2422372998902 : Closed e2422372998902 ∧ code e2422372998902 = 11218466021110 := by decide
theorem cert_e2422372998902 : check e2422372998902 [[],[]] .three = true := by decide
def e2422372998934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372998934 : Closed e2422372998934 ∧ code e2422372998934 = 11218466021142 := by decide
theorem cert_e2422372998934 : check e2422372998934 [[],[]] .three = true := by decide
def e2422372998938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422372998938 : Closed e2422372998938 ∧ code e2422372998938 = 11218466021146 := by decide
theorem cert_e2422372998938 : check e2422372998938 [[],[]] .three = true := by decide
def e2422372998982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422372998982 : Closed e2422372998982 ∧ code e2422372998982 = 11218466021190 := by decide
theorem cert_e2422372998982 : check e2422372998982 [[],[]] .three = true := by decide
def e2422372999006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e2422372999006 : Closed e2422372999006 ∧ code e2422372999006 = 11218466021214 := by decide
theorem cert_e2422372999006 : check e2422372999006 [[],[]] .three = true := by decide
def e2422372999010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422372999010 : Closed e2422372999010 ∧ code e2422372999010 = 11218466021218 := by decide
theorem cert_e2422372999010 : check e2422372999010 [[],[]] .three = true := by decide
def e2422372999022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e2422372999022 : Closed e2422372999022 ∧ code e2422372999022 = 11218466021230 := by decide
theorem cert_e2422372999022 : check e2422372999022 [[],[]] .three = true := by decide
def e2422372999030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e2422372999030 : Closed e2422372999030 ∧ code e2422372999030 = 11218466021238 := by decide
theorem cert_e2422372999030 : check e2422372999030 [[],[]] .three = true := by decide
def e2422372999034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e2422372999034 : Closed e2422372999034 ∧ code e2422372999034 = 11218466021242 := by decide
theorem cert_e2422372999034 : check e2422372999034 [[],[]] .three = true := by decide
def e2422372999614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422372999614 : Closed e2422372999614 ∧ code e2422372999614 = 11218466021822 := by decide
theorem cert_e2422372999614 : check e2422372999614 [[],[]] .three = true := by decide
def e2422372999646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422372999646 : Closed e2422372999646 ∧ code e2422372999646 = 11218466021854 := by decide
theorem cert_e2422372999646 : check e2422372999646 [[],[]] .smaller = true := by decide
def e2422372999670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422372999670 : Closed e2422372999670 ∧ code e2422372999670 = 11218466021878 := by decide
theorem cert_e2422372999670 : check e2422372999670 [[],[]] .smaller = true := by decide
def e2422372999674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422372999674 : Closed e2422372999674 ∧ code e2422372999674 = 11218466021882 := by decide
theorem cert_e2422372999674 : check e2422372999674 [[],[]] .three = true := by decide
def e2422373000622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422373000622 : Closed e2422373000622 ∧ code e2422373000622 = 11218466022830 := by decide
theorem cert_e2422373000622 : check e2422373000622 [[],[]] .smaller = true := by decide
def e2422373000634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422373000634 : Closed e2422373000634 ∧ code e2422373000634 = 11218466022842 := by decide
theorem cert_e2422373000634 : check e2422373000634 [[],[]] .smaller = true := by decide
def e2422373000682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422373000682 : Closed e2422373000682 ∧ code e2422373000682 = 11218466022890 := by decide
theorem cert_e2422373000682 : check e2422373000682 [[],[]] .smaller = true := by decide
def e2422373000766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422373000766 : Closed e2422373000766 ∧ code e2422373000766 = 11218466022974 := by decide
theorem cert_e2422373000766 : check e2422373000766 [[],[]] .three = true := by decide
def e2422373000814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373000814 : Closed e2422373000814 ∧ code e2422373000814 = 11218466023022 := by decide
theorem cert_e2422373000814 : check e2422373000814 [[],[]] .smaller = true := by decide
def e2422373000826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373000826 : Closed e2422373000826 ∧ code e2422373000826 = 11218466023034 := by decide
theorem cert_e2422373000826 : check e2422373000826 [[],[]] .smaller = true := by decide
def e2422373000990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422373000990 : Closed e2422373000990 ∧ code e2422373000990 = 11218466023198 := by decide
theorem cert_e2422373000990 : check e2422373000990 [[],[]] .smaller = true := by decide
def e2422373001090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373001090 : Closed e2422373001090 ∧ code e2422373001090 = 11218466023298 := by decide
theorem cert_e2422373001090 : check e2422373001090 [[],[]] .smaller = true := by decide
def e2422373001102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422373001102 : Closed e2422373001102 ∧ code e2422373001102 = 11218466023310 := by decide
theorem cert_e2422373001102 : check e2422373001102 [[],[]] .smaller = true := by decide
def e2422373001114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373001114 : Closed e2422373001114 ∧ code e2422373001114 = 11218466023322 := by decide
theorem cert_e2422373001114 : check e2422373001114 [[],[]] .smaller = true := by decide
def e2422373001158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422373001158 : Closed e2422373001158 ∧ code e2422373001158 = 11218466023366 := by decide
theorem cert_e2422373001158 : check e2422373001158 [[],[]] .three = true := by decide
def e2422373001182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e2422373001182 : Closed e2422373001182 ∧ code e2422373001182 = 11218466023390 := by decide
theorem cert_e2422373001182 : check e2422373001182 [[],[]] .three = true := by decide
def e2422373003390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373003390 : Closed e2422373003390 ∧ code e2422373003390 = 11218466025598 := by decide
theorem cert_e2422373003390 : check e2422373003390 [[],[]] .three = true := by decide
def e2422373003486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373003486 : Closed e2422373003486 ∧ code e2422373003486 = 11218466025694 := by decide
theorem cert_e2422373003486 : check e2422373003486 [[],[]] .smaller = true := by decide
def e2422373003514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373003514 : Closed e2422373003514 ∧ code e2422373003514 = 11218466025722 := by decide
theorem cert_e2422373003514 : check e2422373003514 [[],[]] .smaller = true := by decide
def e2422373004062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373004062 : Closed e2422373004062 ∧ code e2422373004062 = 11218466026270 := by decide
theorem cert_e2422373004062 : check e2422373004062 [[],[]] .smaller = true := by decide
def e2422373004230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373004230 : Closed e2422373004230 ∧ code e2422373004230 = 11218466026438 := by decide
theorem cert_e2422373004230 : check e2422373004230 [[],[]] .smaller = true := by decide
def e2422373004254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373004254 : Closed e2422373004254 ∧ code e2422373004254 = 11218466026462 := by decide
theorem cert_e2422373004254 : check e2422373004254 [[],[]] .three = true := by decide
def e2422373004258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373004258 : Closed e2422373004258 ∧ code e2422373004258 = 11218466026466 := by decide
theorem cert_e2422373004258 : check e2422373004258 [[],[]] .three = true := by decide
def e2422373004270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373004270 : Closed e2422373004270 ∧ code e2422373004270 = 11218466026478 := by decide
theorem cert_e2422373004270 : check e2422373004270 [[],[]] .three = true := by decide
def e2422373005338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373005338 : Closed e2422373005338 ∧ code e2422373005338 = 11218466027546 := by decide
theorem cert_e2422373005338 : check e2422373005338 [[],[]] .smaller = true := by decide
def e2422373005374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373005374 : Closed e2422373005374 ∧ code e2422373005374 = 11218466027582 := by decide
theorem cert_e2422373005374 : check e2422373005374 [[],[]] .smaller = true := by decide
def e2422373005422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373005422 : Closed e2422373005422 ∧ code e2422373005422 = 11218466027630 := by decide
theorem cert_e2422373005422 : check e2422373005422 [[],[]] .smaller = true := by decide
def e2422373005430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373005430 : Closed e2422373005430 ∧ code e2422373005430 = 11218466027638 := by decide
theorem cert_e2422373005430 : check e2422373005430 [[],[]] .smaller = true := by decide
def e2422373005434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373005434 : Closed e2422373005434 ∧ code e2422373005434 = 11218466027642 := by decide
theorem cert_e2422373005434 : check e2422373005434 [[],[]] .smaller = true := by decide
def e2422373005674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373005674 : Closed e2422373005674 ∧ code e2422373005674 = 11218466027882 := by decide
theorem cert_e2422373005674 : check e2422373005674 [[],[]] .smaller = true := by decide
def e2422373005698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373005698 : Closed e2422373005698 ∧ code e2422373005698 = 11218466027906 := by decide
theorem cert_e2422373005698 : check e2422373005698 [[],[]] .smaller = true := by decide
def e2422373005710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373005710 : Closed e2422373005710 ∧ code e2422373005710 = 11218466027918 := by decide
theorem cert_e2422373005710 : check e2422373005710 [[],[]] .smaller = true := by decide
def e2422373005722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373005722 : Closed e2422373005722 ∧ code e2422373005722 = 11218466027930 := by decide
theorem cert_e2422373005722 : check e2422373005722 [[],[]] .smaller = true := by decide
def e2422373005766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373005766 : Closed e2422373005766 ∧ code e2422373005766 = 11218466027974 := by decide
theorem cert_e2422373005766 : check e2422373005766 [[],[]] .smaller = true := by decide
def e2422373005790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373005790 : Closed e2422373005790 ∧ code e2422373005790 = 11218466027998 := by decide
theorem cert_e2422373005790 : check e2422373005790 [[],[]] .three = true := by decide
def e2422373005794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373005794 : Closed e2422373005794 ∧ code e2422373005794 = 11218466028002 := by decide
theorem cert_e2422373005794 : check e2422373005794 [[],[]] .smaller = true := by decide
def e2422373005806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373005806 : Closed e2422373005806 ∧ code e2422373005806 = 11218466028014 := by decide
theorem cert_e2422373005806 : check e2422373005806 [[],[]] .smaller = true := by decide
def e2422373005814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373005814 : Closed e2422373005814 ∧ code e2422373005814 = 11218466028022 := by decide
theorem cert_e2422373005814 : check e2422373005814 [[],[]] .three = true := by decide
def e2422373006366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373006366 : Closed e2422373006366 ∧ code e2422373006366 = 11218466028574 := by decide
theorem cert_e2422373006366 : check e2422373006366 [[],[]] .three = true := by decide
def e2422373006390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373006390 : Closed e2422373006390 ∧ code e2422373006390 = 11218466028598 := by decide
theorem cert_e2422373006390 : check e2422373006390 [[],[]] .three = true := by decide
def e2422373006394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373006394 : Closed e2422373006394 ∧ code e2422373006394 = 11218466028602 := by decide
theorem cert_e2422373006394 : check e2422373006394 [[],[]] .three = true := by decide
def e2422373006534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373006534 : Closed e2422373006534 ∧ code e2422373006534 = 11218466028742 := by decide
theorem cert_e2422373006534 : check e2422373006534 [[],[]] .three = true := by decide
def e2422373006558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373006558 : Closed e2422373006558 ∧ code e2422373006558 = 11218466028766 := by decide
theorem cert_e2422373006558 : check e2422373006558 [[],[]] .three = true := by decide
def e2422373006562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373006562 : Closed e2422373006562 ∧ code e2422373006562 = 11218466028770 := by decide
theorem cert_e2422373006562 : check e2422373006562 [[],[]] .three = true := by decide
def e2422373006574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373006574 : Closed e2422373006574 ∧ code e2422373006574 = 11218466028782 := by decide
theorem cert_e2422373006574 : check e2422373006574 [[],[]] .three = true := by decide
def e2422373006582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373006582 : Closed e2422373006582 ∧ code e2422373006582 = 11218466028790 := by decide
theorem cert_e2422373006582 : check e2422373006582 [[],[]] .three = true := by decide
def e2422373006586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373006586 : Closed e2422373006586 ∧ code e2422373006586 = 11218466028794 := by decide
theorem cert_e2422373006586 : check e2422373006586 [[],[]] .three = true := by decide
end Blc.Floor43
