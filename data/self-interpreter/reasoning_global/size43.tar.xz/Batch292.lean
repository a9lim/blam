import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411625572982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625572982 : Closed e2411625572982 ∧ code e2411625572982 = 11207718595190 := by decide
theorem cert_e2411625572982 : check e2411625572982 [[],[]] .smaller = true := by decide
def e2411625573150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411625573150 : Closed e2411625573150 ∧ code e2411625573150 = 11207718595358 := by decide
theorem cert_e2411625573150 : check e2411625573150 [[],[]] .smaller = true := by decide
def e2411625573174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625573174 : Closed e2411625573174 ∧ code e2411625573174 = 11207718595382 := by decide
theorem cert_e2411625573174 : check e2411625573174 [[],[]] .smaller = true := by decide
def e2411625573178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625573178 : Closed e2411625573178 ∧ code e2411625573178 = 11207718595386 := by decide
theorem cert_e2411625573178 : check e2411625573178 [[],[]] .smaller = true := by decide
def e2411625573262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411625573262 : Closed e2411625573262 ∧ code e2411625573262 = 11207718595470 := by decide
theorem cert_e2411625573262 : check e2411625573262 [[],[]] .smaller = true := by decide
def e2411625573318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2411625573318 : Closed e2411625573318 ∧ code e2411625573318 = 11207718595526 := by decide
theorem cert_e2411625573318 : check e2411625573318 [[],[]] .three = true := by decide
def e2411625573342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e2411625573342 : Closed e2411625573342 ∧ code e2411625573342 = 11207718595550 := by decide
theorem cert_e2411625573342 : check e2411625573342 [[],[]] .three = true := by decide
def e2411625573486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411625573486 : Closed e2411625573486 ∧ code e2411625573486 = 11207718595694 := by decide
theorem cert_e2411625573486 : check e2411625573486 [[],[]] .smaller = true := by decide
def e2411625573498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411625573498 : Closed e2411625573498 ∧ code e2411625573498 = 11207718595706 := by decide
theorem cert_e2411625573498 : check e2411625573498 [[],[]] .smaller = true := by decide
def e2411625573590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2411625573590 : Closed e2411625573590 ∧ code e2411625573590 = 11207718595798 := by decide
theorem cert_e2411625573590 : check e2411625573590 [[],[]] .smaller = true := by decide
def e2411625573594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2411625573594 : Closed e2411625573594 ∧ code e2411625573594 = 11207718595802 := by decide
theorem cert_e2411625573594 : check e2411625573594 [[],[]] .smaller = true := by decide
def e2411625573610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2411625573610 : Closed e2411625573610 ∧ code e2411625573610 = 11207718595818 := by decide
theorem cert_e2411625573610 : check e2411625573610 [[],[]] .smaller = true := by decide
def e2411625573662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411625573662 : Closed e2411625573662 ∧ code e2411625573662 = 11207718595870 := by decide
theorem cert_e2411625573662 : check e2411625573662 [[],[]] .smaller = true := by decide
def e2411625573686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625573686 : Closed e2411625573686 ∧ code e2411625573686 = 11207718595894 := by decide
theorem cert_e2411625573686 : check e2411625573686 [[],[]] .smaller = true := by decide
def e2411625573690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625573690 : Closed e2411625573690 ∧ code e2411625573690 = 11207718595898 := by decide
theorem cert_e2411625573690 : check e2411625573690 [[],[]] .smaller = true := by decide
def e2411625573786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625573786 : Closed e2411625573786 ∧ code e2411625573786 = 11207718595994 := by decide
theorem cert_e2411625573786 : check e2411625573786 [[],[]] .smaller = true := by decide
def e2411625573830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411625573830 : Closed e2411625573830 ∧ code e2411625573830 = 11207718596038 := by decide
theorem cert_e2411625573830 : check e2411625573830 [[],[]] .smaller = true := by decide
def e2411625573854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e2411625573854 : Closed e2411625573854 ∧ code e2411625573854 = 11207718596062 := by decide
theorem cert_e2411625573854 : check e2411625573854 [[],[]] .three = true := by decide
def e2411625573870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e2411625573870 : Closed e2411625573870 ∧ code e2411625573870 = 11207718596078 := by decide
theorem cert_e2411625573870 : check e2411625573870 [[],[]] .three = true := by decide
def e2411625573942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411625573942 : Closed e2411625573942 ∧ code e2411625573942 = 11207718596150 := by decide
theorem cert_e2411625573942 : check e2411625573942 [[],[]] .smaller = true := by decide
def e2411625573946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411625573946 : Closed e2411625573946 ∧ code e2411625573946 = 11207718596154 := by decide
theorem cert_e2411625573946 : check e2411625573946 [[],[]] .smaller = true := by decide
def e2411625574030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411625574030 : Closed e2411625574030 ∧ code e2411625574030 = 11207718596238 := by decide
theorem cert_e2411625574030 : check e2411625574030 [[],[]] .smaller = true := by decide
def e2411625574086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411625574086 : Closed e2411625574086 ∧ code e2411625574086 = 11207718596294 := by decide
theorem cert_e2411625574086 : check e2411625574086 [[],[]] .smaller = true := by decide
def e2411625574110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e2411625574110 : Closed e2411625574110 ∧ code e2411625574110 = 11207718596318 := by decide
theorem cert_e2411625574110 : check e2411625574110 [[],[]] .three = true := by decide
def e2411625574134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e2411625574134 : Closed e2411625574134 ∧ code e2411625574134 = 11207718596342 := by decide
theorem cert_e2411625574134 : check e2411625574134 [[],[]] .three = true := by decide
def e2411625574170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411625574170 : Closed e2411625574170 ∧ code e2411625574170 = 11207718596378 := by decide
theorem cert_e2411625574170 : check e2411625574170 [[],[]] .three = true := by decide
def e2411625574214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411625574214 : Closed e2411625574214 ∧ code e2411625574214 = 11207718596422 := by decide
theorem cert_e2411625574214 : check e2411625574214 [[],[]] .three = true := by decide
def e2411625574238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e2411625574238 : Closed e2411625574238 ∧ code e2411625574238 = 11207718596446 := by decide
theorem cert_e2411625574238 : check e2411625574238 [[],[]] .three = true := by decide
def e2411625574254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e2411625574254 : Closed e2411625574254 ∧ code e2411625574254 = 11207718596462 := by decide
theorem cert_e2411625574254 : check e2411625574254 [[],[]] .three = true := by decide
def e2411625574262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e2411625574262 : Closed e2411625574262 ∧ code e2411625574262 = 11207718596470 := by decide
theorem cert_e2411625574262 : check e2411625574262 [[],[]] .three = true := by decide
def e2411625574266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e2411625574266 : Closed e2411625574266 ∧ code e2411625574266 = 11207718596474 := by decide
theorem cert_e2411625574266 : check e2411625574266 [[],[]] .three = true := by decide
def e2411625574830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2411625574830 : Closed e2411625574830 ∧ code e2411625574830 = 11207718597038 := by decide
theorem cert_e2411625574830 : check e2411625574830 [[],[]] .three = true := by decide
def e2411625574838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e2411625574838 : Closed e2411625574838 ∧ code e2411625574838 = 11207718597046 := by decide
theorem cert_e2411625574838 : check e2411625574838 [[],[]] .three = true := by decide
def e2411625574842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2411625574842 : Closed e2411625574842 ∧ code e2411625574842 = 11207718597050 := by decide
theorem cert_e2411625574842 : check e2411625574842 [[],[]] .three = true := by decide
def e2411625574870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2411625574870 : Closed e2411625574870 ∧ code e2411625574870 = 11207718597078 := by decide
theorem cert_e2411625574870 : check e2411625574870 [[],[]] .three = true := by decide
def e2411625574874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2411625574874 : Closed e2411625574874 ∧ code e2411625574874 = 11207718597082 := by decide
theorem cert_e2411625574874 : check e2411625574874 [[],[]] .three = true := by decide
def e2411625574890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2411625574890 : Closed e2411625574890 ∧ code e2411625574890 = 11207718597098 := by decide
theorem cert_e2411625574890 : check e2411625574890 [[],[]] .three = true := by decide
def e2411625575254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2411625575254 : Closed e2411625575254 ∧ code e2411625575254 = 11207718597462 := by decide
theorem cert_e2411625575254 : check e2411625575254 [[],[]] .three = true := by decide
def e2411625575258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2411625575258 : Closed e2411625575258 ∧ code e2411625575258 = 11207718597466 := by decide
theorem cert_e2411625575258 : check e2411625575258 [[],[]] .three = true := by decide
def e2411625575274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2411625575274 : Closed e2411625575274 ∧ code e2411625575274 = 11207718597482 := by decide
theorem cert_e2411625575274 : check e2411625575274 [[],[]] .three = true := by decide
def e2411625575338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2411625575338 : Closed e2411625575338 ∧ code e2411625575338 = 11207718597546 := by decide
theorem cert_e2411625575338 : check e2411625575338 [[],[]] .three = true := by decide
def e2411625575534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411625575534 : Closed e2411625575534 ∧ code e2411625575534 = 11207718597742 := by decide
theorem cert_e2411625575534 : check e2411625575534 [[],[]] .three = true := by decide
def e2411625575542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2411625575542 : Closed e2411625575542 ∧ code e2411625575542 = 11207718597750 := by decide
theorem cert_e2411625575542 : check e2411625575542 [[],[]] .three = true := by decide
def e2411625575546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411625575546 : Closed e2411625575546 ∧ code e2411625575546 = 11207718597754 := by decide
theorem cert_e2411625575546 : check e2411625575546 [[],[]] .three = true := by decide
def e2411625575638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2411625575638 : Closed e2411625575638 ∧ code e2411625575638 = 11207718597846 := by decide
theorem cert_e2411625575638 : check e2411625575638 [[],[]] .three = true := by decide
def e2411625575642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2411625575642 : Closed e2411625575642 ∧ code e2411625575642 = 11207718597850 := by decide
theorem cert_e2411625575642 : check e2411625575642 [[],[]] .three = true := by decide
def e2411625575658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2411625575658 : Closed e2411625575658 ∧ code e2411625575658 = 11207718597866 := by decide
theorem cert_e2411625575658 : check e2411625575658 [[],[]] .three = true := by decide
def e2411625575710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411625575710 : Closed e2411625575710 ∧ code e2411625575710 = 11207718597918 := by decide
theorem cert_e2411625575710 : check e2411625575710 [[],[]] .three = true := by decide
def e2411625575734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625575734 : Closed e2411625575734 ∧ code e2411625575734 = 11207718597942 := by decide
theorem cert_e2411625575734 : check e2411625575734 [[],[]] .three = true := by decide
def e2411625575738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625575738 : Closed e2411625575738 ∧ code e2411625575738 = 11207718597946 := by decide
theorem cert_e2411625575738 : check e2411625575738 [[],[]] .three = true := by decide
def e2411625575822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2411625575822 : Closed e2411625575822 ∧ code e2411625575822 = 11207718598030 := by decide
theorem cert_e2411625575822 : check e2411625575822 [[],[]] .three = true := by decide
def e2411625575834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625575834 : Closed e2411625575834 ∧ code e2411625575834 = 11207718598042 := by decide
theorem cert_e2411625575834 : check e2411625575834 [[],[]] .three = true := by decide
def e2411625575878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411625575878 : Closed e2411625575878 ∧ code e2411625575878 = 11207718598086 := by decide
theorem cert_e2411625575878 : check e2411625575878 [[],[]] .three = true := by decide
def e2411625575902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2411625575902 : Closed e2411625575902 ∧ code e2411625575902 = 11207718598110 := by decide
theorem cert_e2411625575902 : check e2411625575902 [[],[]] .three = true := by decide
def e2411625575918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2411625575918 : Closed e2411625575918 ∧ code e2411625575918 = 11207718598126 := by decide
theorem cert_e2411625575918 : check e2411625575918 [[],[]] .three = true := by decide
def e2411625575990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411625575990 : Closed e2411625575990 ∧ code e2411625575990 = 11207718598198 := by decide
theorem cert_e2411625575990 : check e2411625575990 [[],[]] .three = true := by decide
def e2411625575994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411625575994 : Closed e2411625575994 ∧ code e2411625575994 = 11207718598202 := by decide
theorem cert_e2411625575994 : check e2411625575994 [[],[]] .three = true := by decide
def e2411625576042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2411625576042 : Closed e2411625576042 ∧ code e2411625576042 = 11207718598250 := by decide
theorem cert_e2411625576042 : check e2411625576042 [[],[]] .three = true := by decide
def e2411625576078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411625576078 : Closed e2411625576078 ∧ code e2411625576078 = 11207718598286 := by decide
theorem cert_e2411625576078 : check e2411625576078 [[],[]] .three = true := by decide
def e2411625576090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625576090 : Closed e2411625576090 ∧ code e2411625576090 = 11207718598298 := by decide
theorem cert_e2411625576090 : check e2411625576090 [[],[]] .three = true := by decide
def e2411625576134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411625576134 : Closed e2411625576134 ∧ code e2411625576134 = 11207718598342 := by decide
theorem cert_e2411625576134 : check e2411625576134 [[],[]] .three = true := by decide
def e2411625576174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2411625576174 : Closed e2411625576174 ∧ code e2411625576174 = 11207718598382 := by decide
theorem cert_e2411625576174 : check e2411625576174 [[],[]] .three = true := by decide
def e2411625576218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411625576218 : Closed e2411625576218 ∧ code e2411625576218 = 11207718598426 := by decide
theorem cert_e2411625576218 : check e2411625576218 [[],[]] .three = true := by decide
def e2411625576262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411625576262 : Closed e2411625576262 ∧ code e2411625576262 = 11207718598470 := by decide
theorem cert_e2411625576262 : check e2411625576262 [[],[]] .three = true := by decide
def e2411625576286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2411625576286 : Closed e2411625576286 ∧ code e2411625576286 = 11207718598494 := by decide
theorem cert_e2411625576286 : check e2411625576286 [[],[]] .three = true := by decide
def e2411625576302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2411625576302 : Closed e2411625576302 ∧ code e2411625576302 = 11207718598510 := by decide
theorem cert_e2411625576302 : check e2411625576302 [[],[]] .three = true := by decide
def e2411625576310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2411625576310 : Closed e2411625576310 ∧ code e2411625576310 = 11207718598518 := by decide
theorem cert_e2411625576310 : check e2411625576310 [[],[]] .three = true := by decide
def e2411625576314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2411625576314 : Closed e2411625576314 ∧ code e2411625576314 = 11207718598522 := by decide
theorem cert_e2411625576314 : check e2411625576314 [[],[]] .three = true := by decide
def e2411625576366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2411625576366 : Closed e2411625576366 ∧ code e2411625576366 = 11207718598574 := by decide
theorem cert_e2411625576366 : check e2411625576366 [[],[]] .three = true := by decide
def e2411625576378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2411625576378 : Closed e2411625576378 ∧ code e2411625576378 = 11207718598586 := by decide
theorem cert_e2411625576378 : check e2411625576378 [[],[]] .three = true := by decide
def e2411625586142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e2411625586142 : Closed e2411625586142 ∧ code e2411625586142 = 11207718608350 := by decide
theorem cert_e2411625586142 : check e2411625586142 [[],[]] .three = true := by decide
def e2411625586166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 4)))) (.var 1)))))))
theorem wire_e2411625586166 : Closed e2411625586166 ∧ code e2411625586166 = 11207718608374 := by decide
theorem cert_e2411625586166 : check e2411625586166 [[],[]] .three = true := by decide
def e2411625586398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e2411625586398 : Closed e2411625586398 ∧ code e2411625586398 = 11207718608606 := by decide
theorem cert_e2411625586398 : check e2411625586398 [[],[]] .three = true := by decide
def e2411625586414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e2411625586414 : Closed e2411625586414 ∧ code e2411625586414 = 11207718608622 := by decide
theorem cert_e2411625586414 : check e2411625586414 [[],[]] .smaller = true := by decide
def e2411625586422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e2411625586422 : Closed e2411625586422 ∧ code e2411625586422 = 11207718608630 := by decide
theorem cert_e2411625586422 : check e2411625586422 [[],[]] .smaller = true := by decide
def e2411625586426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 4)))) (.var 0)))))))
theorem wire_e2411625586426 : Closed e2411625586426 ∧ code e2411625586426 = 11207718608634 := by decide
theorem cert_e2411625586426 : check e2411625586426 [[],[]] .three = true := by decide
def e2411625586550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e2411625586550 : Closed e2411625586550 ∧ code e2411625586550 = 11207718608758 := by decide
theorem cert_e2411625586550 : check e2411625586550 [[],[]] .smaller = true := by decide
def e2411625586614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 1)))) (.var 1)))))))
theorem wire_e2411625586614 : Closed e2411625586614 ∧ code e2411625586614 = 11207718608822 := by decide
theorem cert_e2411625586614 : check e2411625586614 [[],[]] .three = true := by decide
def e2411625586618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 2)))) (.var 0)))))))
theorem wire_e2411625586618 : Closed e2411625586618 ∧ code e2411625586618 = 11207718608826 := by decide
theorem cert_e2411625586618 : check e2411625586618 [[],[]] .three = true := by decide
def e2411625591774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e2411625591774 : Closed e2411625591774 ∧ code e2411625591774 = 11207718613982 := by decide
theorem cert_e2411625591774 : check e2411625591774 [[],[]] .three = true := by decide
def e2411625591790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e2411625591790 : Closed e2411625591790 ∧ code e2411625591790 = 11207718613998 := by decide
theorem cert_e2411625591790 : check e2411625591790 [[],[]] .three = true := by decide
def e2411625593310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e2411625593310 : Closed e2411625593310 ∧ code e2411625593310 = 11207718615518 := by decide
theorem cert_e2411625593310 : check e2411625593310 [[],[]] .three = true := by decide
def e2411625593326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e2411625593326 : Closed e2411625593326 ∧ code e2411625593326 = 11207718615534 := by decide
theorem cert_e2411625593326 : check e2411625593326 [[],[]] .smaller = true := by decide
def e2411625593334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e2411625593334 : Closed e2411625593334 ∧ code e2411625593334 = 11207718615542 := by decide
theorem cert_e2411625593334 : check e2411625593334 [[],[]] .three = true := by decide
def e2411625594078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625594078 : Closed e2411625594078 ∧ code e2411625594078 = 11207718616286 := by decide
theorem cert_e2411625594078 : check e2411625594078 [[],[]] .three = true := by decide
def e2411625594094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625594094 : Closed e2411625594094 ∧ code e2411625594094 = 11207718616302 := by decide
theorem cert_e2411625594094 : check e2411625594094 [[],[]] .smaller = true := by decide
def e2411625594102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625594102 : Closed e2411625594102 ∧ code e2411625594102 = 11207718616310 := by decide
theorem cert_e2411625594102 : check e2411625594102 [[],[]] .smaller = true := by decide
def e2411625594106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625594106 : Closed e2411625594106 ∧ code e2411625594106 = 11207718616314 := by decide
theorem cert_e2411625594106 : check e2411625594106 [[],[]] .three = true := by decide
def e2411625594478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625594478 : Closed e2411625594478 ∧ code e2411625594478 = 11207718616686 := by decide
theorem cert_e2411625594478 : check e2411625594478 [[],[]] .three = true := by decide
def e2411625594486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625594486 : Closed e2411625594486 ∧ code e2411625594486 = 11207718616694 := by decide
theorem cert_e2411625594486 : check e2411625594486 [[],[]] .three = true := by decide
def e2411625594490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625594490 : Closed e2411625594490 ∧ code e2411625594490 = 11207718616698 := by decide
theorem cert_e2411625594490 : check e2411625594490 [[],[]] .three = true := by decide
def e2411625601758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e2411625601758 : Closed e2411625601758 ∧ code e2411625601758 = 11207718623966 := by decide
theorem cert_e2411625601758 : check e2411625601758 [[],[]] .three = true := by decide
def e2411625601782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e2411625601782 : Closed e2411625601782 ∧ code e2411625601782 = 11207718623990 := by decide
theorem cert_e2411625601782 : check e2411625601782 [[],[]] .three = true := by decide
def e2411625601886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e2411625601886 : Closed e2411625601886 ∧ code e2411625601886 = 11207718624094 := by decide
theorem cert_e2411625601886 : check e2411625601886 [[],[]] .three = true := by decide
def e2411625601902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e2411625601902 : Closed e2411625601902 ∧ code e2411625601902 = 11207718624110 := by decide
theorem cert_e2411625601902 : check e2411625601902 [[],[]] .smaller = true := by decide
def e2411625601910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e2411625601910 : Closed e2411625601910 ∧ code e2411625601910 = 11207718624118 := by decide
theorem cert_e2411625601910 : check e2411625601910 [[],[]] .smaller = true := by decide
def e2411625601914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e2411625601914 : Closed e2411625601914 ∧ code e2411625601914 = 11207718624122 := by decide
theorem cert_e2411625601914 : check e2411625601914 [[],[]] .three = true := by decide
def e2411625601974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e2411625601974 : Closed e2411625601974 ∧ code e2411625601974 = 11207718624182 := by decide
theorem cert_e2411625601974 : check e2411625601974 [[],[]] .smaller = true := by decide
def e2411625602006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e2411625602006 : Closed e2411625602006 ∧ code e2411625602006 = 11207718624214 := by decide
theorem cert_e2411625602006 : check e2411625602006 [[],[]] .three = true := by decide
def e2411625602010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e2411625602010 : Closed e2411625602010 ∧ code e2411625602010 = 11207718624218 := by decide
theorem cert_e2411625602010 : check e2411625602010 [[],[]] .three = true := by decide
def e2411625602398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e2411625602398 : Closed e2411625602398 ∧ code e2411625602398 = 11207718624606 := by decide
theorem cert_e2411625602398 : check e2411625602398 [[],[]] .three = true := by decide
def e2411625602414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2411625602414 : Closed e2411625602414 ∧ code e2411625602414 = 11207718624622 := by decide
theorem cert_e2411625602414 : check e2411625602414 [[],[]] .smaller = true := by decide
def e2411625602422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2411625602422 : Closed e2411625602422 ∧ code e2411625602422 = 11207718624630 := by decide
theorem cert_e2411625602422 : check e2411625602422 [[],[]] .smaller = true := by decide
def e2411625602426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e2411625602426 : Closed e2411625602426 ∧ code e2411625602426 = 11207718624634 := by decide
theorem cert_e2411625602426 : check e2411625602426 [[],[]] .three = true := by decide
def e2411625602478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2411625602478 : Closed e2411625602478 ∧ code e2411625602478 = 11207718624686 := by decide
theorem cert_e2411625602478 : check e2411625602478 [[],[]] .smaller = true := by decide
def e2411625602490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2411625602490 : Closed e2411625602490 ∧ code e2411625602490 = 11207718624698 := by decide
theorem cert_e2411625602490 : check e2411625602490 [[],[]] .smaller = true := by decide
def e2411625602518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2411625602518 : Closed e2411625602518 ∧ code e2411625602518 = 11207718624726 := by decide
theorem cert_e2411625602518 : check e2411625602518 [[],[]] .smaller = true := by decide
def e2411625602522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2411625602522 : Closed e2411625602522 ∧ code e2411625602522 = 11207718624730 := by decide
theorem cert_e2411625602522 : check e2411625602522 [[],[]] .smaller = true := by decide
def e2411625602538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e2411625602538 : Closed e2411625602538 ∧ code e2411625602538 = 11207718624746 := by decide
theorem cert_e2411625602538 : check e2411625602538 [[],[]] .three = true := by decide
def e2411625602742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e2411625602742 : Closed e2411625602742 ∧ code e2411625602742 = 11207718624950 := by decide
theorem cert_e2411625602742 : check e2411625602742 [[],[]] .smaller = true := by decide
def e2411625602774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e2411625602774 : Closed e2411625602774 ∧ code e2411625602774 = 11207718624982 := by decide
theorem cert_e2411625602774 : check e2411625602774 [[],[]] .smaller = true := by decide
def e2411625602778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e2411625602778 : Closed e2411625602778 ∧ code e2411625602778 = 11207718624986 := by decide
theorem cert_e2411625602778 : check e2411625602778 [[],[]] .smaller = true := by decide
def e2411625602902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2411625602902 : Closed e2411625602902 ∧ code e2411625602902 = 11207718625110 := by decide
theorem cert_e2411625602902 : check e2411625602902 [[],[]] .three = true := by decide
def e2411625602906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2411625602906 : Closed e2411625602906 ∧ code e2411625602906 = 11207718625114 := by decide
theorem cert_e2411625602906 : check e2411625602906 [[],[]] .three = true := by decide
def e2411625602922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2411625602922 : Closed e2411625602922 ∧ code e2411625602922 = 11207718625130 := by decide
theorem cert_e2411625602922 : check e2411625602922 [[],[]] .three = true := by decide
def e2411625604062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e2411625604062 : Closed e2411625604062 ∧ code e2411625604062 = 11207718626270 := by decide
theorem cert_e2411625604062 : check e2411625604062 [[],[]] .three = true := by decide
def e2411625604078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e2411625604078 : Closed e2411625604078 ∧ code e2411625604078 = 11207718626286 := by decide
theorem cert_e2411625604078 : check e2411625604078 [[],[]] .three = true := by decide
def e2411625604830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e2411625604830 : Closed e2411625604830 ∧ code e2411625604830 = 11207718627038 := by decide
theorem cert_e2411625604830 : check e2411625604830 [[],[]] .three = true := by decide
def e2411625604854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2411625604854 : Closed e2411625604854 ∧ code e2411625604854 = 11207718627062 := by decide
theorem cert_e2411625604854 : check e2411625604854 [[],[]] .three = true := by decide
def e2411625604958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e2411625604958 : Closed e2411625604958 ∧ code e2411625604958 = 11207718627166 := by decide
theorem cert_e2411625604958 : check e2411625604958 [[],[]] .three = true := by decide
def e2411625604974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2411625604974 : Closed e2411625604974 ∧ code e2411625604974 = 11207718627182 := by decide
theorem cert_e2411625604974 : check e2411625604974 [[],[]] .smaller = true := by decide
def e2411625604982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e2411625604982 : Closed e2411625604982 ∧ code e2411625604982 = 11207718627190 := by decide
theorem cert_e2411625604982 : check e2411625604982 [[],[]] .smaller = true := by decide
def e2411625604986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2411625604986 : Closed e2411625604986 ∧ code e2411625604986 = 11207718627194 := by decide
theorem cert_e2411625604986 : check e2411625604986 [[],[]] .three = true := by decide
def e2411625605046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e2411625605046 : Closed e2411625605046 ∧ code e2411625605046 = 11207718627254 := by decide
theorem cert_e2411625605046 : check e2411625605046 [[],[]] .smaller = true := by decide
def e2411625605078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2411625605078 : Closed e2411625605078 ∧ code e2411625605078 = 11207718627286 := by decide
theorem cert_e2411625605078 : check e2411625605078 [[],[]] .three = true := by decide
def e2411625605082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2411625605082 : Closed e2411625605082 ∧ code e2411625605082 = 11207718627290 := by decide
theorem cert_e2411625605082 : check e2411625605082 [[],[]] .three = true := by decide
def e2411625605598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2411625605598 : Closed e2411625605598 ∧ code e2411625605598 = 11207718627806 := by decide
theorem cert_e2411625605598 : check e2411625605598 [[],[]] .three = true := by decide
def e2411625605622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2411625605622 : Closed e2411625605622 ∧ code e2411625605622 = 11207718627830 := by decide
theorem cert_e2411625605622 : check e2411625605622 [[],[]] .three = true := by decide
def e2411625606366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625606366 : Closed e2411625606366 ∧ code e2411625606366 = 11207718628574 := by decide
theorem cert_e2411625606366 : check e2411625606366 [[],[]] .three = true := by decide
def e2411625606382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625606382 : Closed e2411625606382 ∧ code e2411625606382 = 11207718628590 := by decide
theorem cert_e2411625606382 : check e2411625606382 [[],[]] .smaller = true := by decide
def e2411625606390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625606390 : Closed e2411625606390 ∧ code e2411625606390 = 11207718628598 := by decide
theorem cert_e2411625606390 : check e2411625606390 [[],[]] .smaller = true := by decide
def e2411625606394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625606394 : Closed e2411625606394 ∧ code e2411625606394 = 11207718628602 := by decide
theorem cert_e2411625606394 : check e2411625606394 [[],[]] .three = true := by decide
def e2411625606718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 4))))))))
theorem wire_e2411625606718 : Closed e2411625606718 ∧ code e2411625606718 = 11207718628926 := by decide
theorem cert_e2411625606718 : check e2411625606718 [[],[]] .three = true := by decide
def e2411625606774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625606774 : Closed e2411625606774 ∧ code e2411625606774 = 11207718628982 := by decide
theorem cert_e2411625606774 : check e2411625606774 [[],[]] .smaller = true := by decide
def e2411625606942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 3))))))))
theorem wire_e2411625606942 : Closed e2411625606942 ∧ code e2411625606942 = 11207718629150 := by decide
theorem cert_e2411625606942 : check e2411625606942 [[],[]] .three = true := by decide
def e2411625606966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625606966 : Closed e2411625606966 ∧ code e2411625606966 = 11207718629174 := by decide
theorem cert_e2411625606966 : check e2411625606966 [[],[]] .three = true := by decide
def e2411625606970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625606970 : Closed e2411625606970 ∧ code e2411625606970 = 11207718629178 := by decide
theorem cert_e2411625606970 : check e2411625606970 [[],[]] .three = true := by decide
def e2411625607646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2411625607646 : Closed e2411625607646 ∧ code e2411625607646 = 11207718629854 := by decide
theorem cert_e2411625607646 : check e2411625607646 [[],[]] .three = true := by decide
def e2411625607662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2411625607662 : Closed e2411625607662 ∧ code e2411625607662 = 11207718629870 := by decide
theorem cert_e2411625607662 : check e2411625607662 [[],[]] .smaller = true := by decide
def e2411625607670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2411625607670 : Closed e2411625607670 ∧ code e2411625607670 = 11207718629878 := by decide
theorem cert_e2411625607670 : check e2411625607670 [[],[]] .three = true := by decide
def e2411625608030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e2411625608030 : Closed e2411625608030 ∧ code e2411625608030 = 11207718630238 := by decide
theorem cert_e2411625608030 : check e2411625608030 [[],[]] .three = true := by decide
def e2411625608046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2411625608046 : Closed e2411625608046 ∧ code e2411625608046 = 11207718630254 := by decide
theorem cert_e2411625608046 : check e2411625608046 [[],[]] .smaller = true := by decide
def e2411625608054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2411625608054 : Closed e2411625608054 ∧ code e2411625608054 = 11207718630262 := by decide
theorem cert_e2411625608054 : check e2411625608054 [[],[]] .smaller = true := by decide
def e2411625608058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2411625608058 : Closed e2411625608058 ∧ code e2411625608058 = 11207718630266 := by decide
theorem cert_e2411625608058 : check e2411625608058 [[],[]] .three = true := by decide
def e2411625608110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2411625608110 : Closed e2411625608110 ∧ code e2411625608110 = 11207718630318 := by decide
theorem cert_e2411625608110 : check e2411625608110 [[],[]] .smaller = true := by decide
def e2411625608122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2411625608122 : Closed e2411625608122 ∧ code e2411625608122 = 11207718630330 := by decide
theorem cert_e2411625608122 : check e2411625608122 [[],[]] .smaller = true := by decide
def e2411625608150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2411625608150 : Closed e2411625608150 ∧ code e2411625608150 = 11207718630358 := by decide
theorem cert_e2411625608150 : check e2411625608150 [[],[]] .smaller = true := by decide
def e2411625608154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2411625608154 : Closed e2411625608154 ∧ code e2411625608154 = 11207718630362 := by decide
theorem cert_e2411625608154 : check e2411625608154 [[],[]] .smaller = true := by decide
def e2411625608170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2411625608170 : Closed e2411625608170 ∧ code e2411625608170 = 11207718630378 := by decide
theorem cert_e2411625608170 : check e2411625608170 [[],[]] .three = true := by decide
def e2411625608414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625608414 : Closed e2411625608414 ∧ code e2411625608414 = 11207718630622 := by decide
theorem cert_e2411625608414 : check e2411625608414 [[],[]] .three = true := by decide
def e2411625608430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625608430 : Closed e2411625608430 ∧ code e2411625608430 = 11207718630638 := by decide
theorem cert_e2411625608430 : check e2411625608430 [[],[]] .smaller = true := by decide
def e2411625608438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625608438 : Closed e2411625608438 ∧ code e2411625608438 = 11207718630646 := by decide
theorem cert_e2411625608438 : check e2411625608438 [[],[]] .smaller = true := by decide
def e2411625608442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625608442 : Closed e2411625608442 ∧ code e2411625608442 = 11207718630650 := by decide
theorem cert_e2411625608442 : check e2411625608442 [[],[]] .three = true := by decide
def e2411625608766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2411625608766 : Closed e2411625608766 ∧ code e2411625608766 = 11207718630974 := by decide
theorem cert_e2411625608766 : check e2411625608766 [[],[]] .three = true := by decide
def e2411625608814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625608814 : Closed e2411625608814 ∧ code e2411625608814 = 11207718631022 := by decide
theorem cert_e2411625608814 : check e2411625608814 [[],[]] .smaller = true := by decide
def e2411625608826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625608826 : Closed e2411625608826 ∧ code e2411625608826 = 11207718631034 := by decide
theorem cert_e2411625608826 : check e2411625608826 [[],[]] .smaller = true := by decide
def e2411625608990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))))))))
theorem wire_e2411625608990 : Closed e2411625608990 ∧ code e2411625608990 = 11207718631198 := by decide
theorem cert_e2411625608990 : check e2411625608990 [[],[]] .smaller = true := by decide
def e2411625609014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625609014 : Closed e2411625609014 ∧ code e2411625609014 = 11207718631222 := by decide
theorem cert_e2411625609014 : check e2411625609014 [[],[]] .smaller = true := by decide
def e2411625609018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625609018 : Closed e2411625609018 ∧ code e2411625609018 = 11207718631226 := by decide
theorem cert_e2411625609018 : check e2411625609018 [[],[]] .smaller = true := by decide
def e2411625609102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2411625609102 : Closed e2411625609102 ∧ code e2411625609102 = 11207718631310 := by decide
theorem cert_e2411625609102 : check e2411625609102 [[],[]] .three = true := by decide
end Blc.Floor43
